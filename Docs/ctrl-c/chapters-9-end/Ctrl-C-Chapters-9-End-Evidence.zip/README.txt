Ctrl C 1.12.2 (146), Chapters 9 through end.
The .dart files are annotated ARM64 disassembly, not original Dart source.
Addresses refer to this compiled build. Resolved annotations are convenience data; nested annotations are not extra game objects.
No game execution, personal save, or live remote configuration was used.
See the reference for code/text disagreements and unresolved behavior.
