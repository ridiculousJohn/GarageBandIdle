// lib: , url: package:pretentious/data/Chapters/Chapter12GameState.dart

// class id: 1049449, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46d444, size: 0x168
    // 0x46d444: cmp             w1, NULL
    // 0x46d448: b.ne            #0x46d454
    // 0x46d44c: r0 = ""
    //     0x46d44c: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46d450: ret
    //     0x46d450: ret             
    // 0x46d454: r16 = Instance_Chapter12Stat
    //     0x46d454: add             x16, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x46d458: ldr             x16, [x16, #0x488]
    // 0x46d45c: cmp             w1, w16
    // 0x46d460: b.ne            #0x46d470
    // 0x46d464: r0 = "Research"
    //     0x46d464: add             x0, PP, #0x11, lsl #12  ; [pp+0x11490] "Research"
    //     0x46d468: ldr             x0, [x0, #0x490]
    // 0x46d46c: ret
    //     0x46d46c: ret             
    // 0x46d470: r16 = Instance_Chapter12Stat
    //     0x46d470: add             x16, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x46d474: ldr             x16, [x16, #0x498]
    // 0x46d478: cmp             w1, w16
    // 0x46d47c: b.ne            #0x46d48c
    // 0x46d480: r0 = "Discovery"
    //     0x46d480: add             x0, PP, #0x11, lsl #12  ; [pp+0x114a0] "Discovery"
    //     0x46d484: ldr             x0, [x0, #0x4a0]
    // 0x46d488: ret
    //     0x46d488: ret             
    // 0x46d48c: r16 = Instance_Chapter12Stat
    //     0x46d48c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11408] Obj!Chapter12Stat@85fc61
    //     0x46d490: ldr             x16, [x16, #0x408]
    // 0x46d494: cmp             w1, w16
    // 0x46d498: b.ne            #0x46d4a8
    // 0x46d49c: r0 = "Reverse Engineering"
    //     0x46d49c: add             x0, PP, #0x11, lsl #12  ; [pp+0x114a8] "Reverse Engineering"
    //     0x46d4a0: ldr             x0, [x0, #0x4a8]
    // 0x46d4a4: ret
    //     0x46d4a4: ret             
    // 0x46d4a8: r16 = Instance_Chapter12Stat
    //     0x46d4a8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x46d4ac: ldr             x16, [x16, #0x410]
    // 0x46d4b0: cmp             w1, w16
    // 0x46d4b4: b.ne            #0x46d4c4
    // 0x46d4b8: r0 = "Port Prober"
    //     0x46d4b8: add             x0, PP, #0x11, lsl #12  ; [pp+0x114b0] "Port Prober"
    //     0x46d4bc: ldr             x0, [x0, #0x4b0]
    // 0x46d4c0: ret
    //     0x46d4c0: ret             
    // 0x46d4c4: r16 = Instance_Chapter12Stat
    //     0x46d4c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x113f0] Obj!Chapter12Stat@85fcc1
    //     0x46d4c8: ldr             x16, [x16, #0x3f0]
    // 0x46d4cc: cmp             w1, w16
    // 0x46d4d0: b.ne            #0x46d4e0
    // 0x46d4d4: r0 = "Scripts"
    //     0x46d4d4: add             x0, PP, #0x11, lsl #12  ; [pp+0x114b8] "Scripts"
    //     0x46d4d8: ldr             x0, [x0, #0x4b8]
    // 0x46d4dc: ret
    //     0x46d4dc: ret             
    // 0x46d4e0: r16 = Instance_Chapter12Stat
    //     0x46d4e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x113f8] Obj!Chapter12Stat@85fca1
    //     0x46d4e4: ldr             x16, [x16, #0x3f8]
    // 0x46d4e8: cmp             w1, w16
    // 0x46d4ec: b.ne            #0x46d4fc
    // 0x46d4f0: r0 = "Network Scanner"
    //     0x46d4f0: add             x0, PP, #0x11, lsl #12  ; [pp+0x114c0] "Network Scanner"
    //     0x46d4f4: ldr             x0, [x0, #0x4c0]
    // 0x46d4f8: ret
    //     0x46d4f8: ret             
    // 0x46d4fc: r16 = Instance_Chapter12Stat
    //     0x46d4fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11400] Obj!Chapter12Stat@85fc81
    //     0x46d500: ldr             x16, [x16, #0x400]
    // 0x46d504: cmp             w1, w16
    // 0x46d508: b.ne            #0x46d518
    // 0x46d50c: r0 = "Log Analyzer"
    //     0x46d50c: add             x0, PP, #0x11, lsl #12  ; [pp+0x114c8] "Log Analyzer"
    //     0x46d510: ldr             x0, [x0, #0x4c8]
    // 0x46d514: ret
    //     0x46d514: ret             
    // 0x46d518: r16 = Instance_Chapter12Stat
    //     0x46d518: add             x16, PP, #0x11, lsl #12  ; [pp+0x11418] Obj!Chapter12Stat@85fc21
    //     0x46d51c: ldr             x16, [x16, #0x418]
    // 0x46d520: cmp             w1, w16
    // 0x46d524: b.ne            #0x46d534
    // 0x46d528: r0 = "Phishing Simulator"
    //     0x46d528: add             x0, PP, #0x11, lsl #12  ; [pp+0x114d0] "Phishing Simulator"
    //     0x46d52c: ldr             x0, [x0, #0x4d0]
    // 0x46d530: ret
    //     0x46d530: ret             
    // 0x46d534: r16 = Instance_Chapter12Stat
    //     0x46d534: add             x16, PP, #0x11, lsl #12  ; [pp+0x11420] Obj!Chapter12Stat@85fc01
    //     0x46d538: ldr             x16, [x16, #0x420]
    // 0x46d53c: cmp             w1, w16
    // 0x46d540: b.ne            #0x46d550
    // 0x46d544: r0 = "Vulnerability Scanner"
    //     0x46d544: add             x0, PP, #0x11, lsl #12  ; [pp+0x114d8] "Vulnerability Scanner"
    //     0x46d548: ldr             x0, [x0, #0x4d8]
    // 0x46d54c: ret
    //     0x46d54c: ret             
    // 0x46d550: r16 = Instance_Chapter12Stat
    //     0x46d550: add             x16, PP, #0x11, lsl #12  ; [pp+0x11428] Obj!Chapter12Stat@85fbe1
    //     0x46d554: ldr             x16, [x16, #0x428]
    // 0x46d558: cmp             w1, w16
    // 0x46d55c: b.ne            #0x46d56c
    // 0x46d560: r0 = "Credential Scanner"
    //     0x46d560: add             x0, PP, #0x11, lsl #12  ; [pp+0x114e0] "Credential Scanner"
    //     0x46d564: ldr             x0, [x0, #0x4e0]
    // 0x46d568: ret
    //     0x46d568: ret             
    // 0x46d56c: r16 = Instance_Chapter12Stat
    //     0x46d56c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11430] Obj!Chapter12Stat@85fbc1
    //     0x46d570: ldr             x16, [x16, #0x430]
    // 0x46d574: cmp             w1, w16
    // 0x46d578: b.ne            #0x46d588
    // 0x46d57c: r0 = "API Mapping"
    //     0x46d57c: add             x0, PP, #0x11, lsl #12  ; [pp+0x114e8] "API Mapping"
    //     0x46d580: ldr             x0, [x0, #0x4e8]
    // 0x46d584: ret
    //     0x46d584: ret             
    // 0x46d588: r16 = Instance_Chapter12Stat
    //     0x46d588: add             x16, PP, #0x11, lsl #12  ; [pp+0x11438] Obj!Chapter12Stat@85fba1
    //     0x46d58c: ldr             x16, [x16, #0x438]
    // 0x46d590: cmp             w1, w16
    // 0x46d594: b.ne            #0x46d5a4
    // 0x46d598: r0 = "Threat Profiler"
    //     0x46d598: add             x0, PP, #0x11, lsl #12  ; [pp+0x114f0] "Threat Profiler"
    //     0x46d59c: ldr             x0, [x0, #0x4f0]
    // 0x46d5a0: ret
    //     0x46d5a0: ret             
    // 0x46d5a4: r0 = Null
    //     0x46d5a4: mov             x0, NULL
    // 0x46d5a8: ret
    //     0x46d5a8: ret             
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46d5dc, size: 0x158
    // 0x46d5dc: r16 = Instance_Chapter12Stat
    //     0x46d5dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x46d5e0: ldr             x16, [x16, #0x488]
    // 0x46d5e4: cmp             w1, w16
    // 0x46d5e8: b.ne            #0x46d5f8
    // 0x46d5ec: r0 = "Rsrch"
    //     0x46d5ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x114f8] "Rsrch"
    //     0x46d5f0: ldr             x0, [x0, #0x4f8]
    // 0x46d5f4: ret
    //     0x46d5f4: ret             
    // 0x46d5f8: r16 = Instance_Chapter12Stat
    //     0x46d5f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x46d5fc: ldr             x16, [x16, #0x498]
    // 0x46d600: cmp             w1, w16
    // 0x46d604: b.ne            #0x46d614
    // 0x46d608: r0 = "Dscvry"
    //     0x46d608: add             x0, PP, #0x11, lsl #12  ; [pp+0x11500] "Dscvry"
    //     0x46d60c: ldr             x0, [x0, #0x500]
    // 0x46d610: ret
    //     0x46d610: ret             
    // 0x46d614: r16 = Instance_Chapter12Stat
    //     0x46d614: add             x16, PP, #0x11, lsl #12  ; [pp+0x11408] Obj!Chapter12Stat@85fc61
    //     0x46d618: ldr             x16, [x16, #0x408]
    // 0x46d61c: cmp             w1, w16
    // 0x46d620: b.ne            #0x46d630
    // 0x46d624: r0 = "RvrsEng"
    //     0x46d624: add             x0, PP, #0x11, lsl #12  ; [pp+0x11508] "RvrsEng"
    //     0x46d628: ldr             x0, [x0, #0x508]
    // 0x46d62c: ret
    //     0x46d62c: ret             
    // 0x46d630: r16 = Instance_Chapter12Stat
    //     0x46d630: add             x16, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x46d634: ldr             x16, [x16, #0x410]
    // 0x46d638: cmp             w1, w16
    // 0x46d63c: b.ne            #0x46d64c
    // 0x46d640: r0 = "PrtPrbr"
    //     0x46d640: add             x0, PP, #0x11, lsl #12  ; [pp+0x11510] "PrtPrbr"
    //     0x46d644: ldr             x0, [x0, #0x510]
    // 0x46d648: ret
    //     0x46d648: ret             
    // 0x46d64c: r16 = Instance_Chapter12Stat
    //     0x46d64c: add             x16, PP, #0x11, lsl #12  ; [pp+0x113f0] Obj!Chapter12Stat@85fcc1
    //     0x46d650: ldr             x16, [x16, #0x3f0]
    // 0x46d654: cmp             w1, w16
    // 0x46d658: b.ne            #0x46d668
    // 0x46d65c: r0 = "Scrpts"
    //     0x46d65c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11518] "Scrpts"
    //     0x46d660: ldr             x0, [x0, #0x518]
    // 0x46d664: ret
    //     0x46d664: ret             
    // 0x46d668: r16 = Instance_Chapter12Stat
    //     0x46d668: add             x16, PP, #0x11, lsl #12  ; [pp+0x113f8] Obj!Chapter12Stat@85fca1
    //     0x46d66c: ldr             x16, [x16, #0x3f8]
    // 0x46d670: cmp             w1, w16
    // 0x46d674: b.ne            #0x46d684
    // 0x46d678: r0 = "NtwrkScnr"
    //     0x46d678: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] "NtwrkScnr"
    //     0x46d67c: ldr             x0, [x0, #0x520]
    // 0x46d680: ret
    //     0x46d680: ret             
    // 0x46d684: r16 = Instance_Chapter12Stat
    //     0x46d684: add             x16, PP, #0x11, lsl #12  ; [pp+0x11400] Obj!Chapter12Stat@85fc81
    //     0x46d688: ldr             x16, [x16, #0x400]
    // 0x46d68c: cmp             w1, w16
    // 0x46d690: b.ne            #0x46d6a0
    // 0x46d694: r0 = "LgAnlzr"
    //     0x46d694: add             x0, PP, #0x11, lsl #12  ; [pp+0x11528] "LgAnlzr"
    //     0x46d698: ldr             x0, [x0, #0x528]
    // 0x46d69c: ret
    //     0x46d69c: ret             
    // 0x46d6a0: r16 = Instance_Chapter12Stat
    //     0x46d6a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11418] Obj!Chapter12Stat@85fc21
    //     0x46d6a4: ldr             x16, [x16, #0x418]
    // 0x46d6a8: cmp             w1, w16
    // 0x46d6ac: b.ne            #0x46d6bc
    // 0x46d6b0: r0 = "Phshng"
    //     0x46d6b0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11530] "Phshng"
    //     0x46d6b4: ldr             x0, [x0, #0x530]
    // 0x46d6b8: ret
    //     0x46d6b8: ret             
    // 0x46d6bc: r16 = Instance_Chapter12Stat
    //     0x46d6bc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11420] Obj!Chapter12Stat@85fc01
    //     0x46d6c0: ldr             x16, [x16, #0x420]
    // 0x46d6c4: cmp             w1, w16
    // 0x46d6c8: b.ne            #0x46d6d8
    // 0x46d6cc: r0 = "Vlnrblty"
    //     0x46d6cc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11538] "Vlnrblty"
    //     0x46d6d0: ldr             x0, [x0, #0x538]
    // 0x46d6d4: ret
    //     0x46d6d4: ret             
    // 0x46d6d8: r16 = Instance_Chapter12Stat
    //     0x46d6d8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11428] Obj!Chapter12Stat@85fbe1
    //     0x46d6dc: ldr             x16, [x16, #0x428]
    // 0x46d6e0: cmp             w1, w16
    // 0x46d6e4: b.ne            #0x46d6f4
    // 0x46d6e8: r0 = "CrdlScnr"
    //     0x46d6e8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11540] "CrdlScnr"
    //     0x46d6ec: ldr             x0, [x0, #0x540]
    // 0x46d6f0: ret
    //     0x46d6f0: ret             
    // 0x46d6f4: r16 = Instance_Chapter12Stat
    //     0x46d6f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11430] Obj!Chapter12Stat@85fbc1
    //     0x46d6f8: ldr             x16, [x16, #0x430]
    // 0x46d6fc: cmp             w1, w16
    // 0x46d700: b.ne            #0x46d710
    // 0x46d704: r0 = "API"
    //     0x46d704: add             x0, PP, #0x11, lsl #12  ; [pp+0x11548] "API"
    //     0x46d708: ldr             x0, [x0, #0x548]
    // 0x46d70c: ret
    //     0x46d70c: ret             
    // 0x46d710: r16 = Instance_Chapter12Stat
    //     0x46d710: add             x16, PP, #0x11, lsl #12  ; [pp+0x11438] Obj!Chapter12Stat@85fba1
    //     0x46d714: ldr             x16, [x16, #0x438]
    // 0x46d718: cmp             w1, w16
    // 0x46d71c: b.ne            #0x46d72c
    // 0x46d720: r0 = "ThrPrflr"
    //     0x46d720: add             x0, PP, #0x11, lsl #12  ; [pp+0x11550] "ThrPrflr"
    //     0x46d724: ldr             x0, [x0, #0x550]
    // 0x46d728: ret
    //     0x46d728: ret             
    // 0x46d72c: r0 = Null
    //     0x46d72c: mov             x0, NULL
    // 0x46d730: ret
    //     0x46d730: ret             
  }
}

// class id: 283, size: 0xa0, field offset: 0x8c
class Chapter12GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter12Stat>> generators; // offset: 0x90
  late Map<int, UpgradeData<Chapter12Stat>> allUpgradeData; // offset: 0x94

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3da7a0, size: 0x4b8
    // 0x3da7a0: EnterFrame
    //     0x3da7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x3da7a4: mov             fp, SP
    // 0x3da7a8: AllocStack(0x58)
    //     0x3da7a8: sub             SP, SP, #0x58
    // 0x3da7ac: SetupParameters(Chapter12GameState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x3da7ac: mov             x4, x1
    //     0x3da7b0: mov             x0, x2
    //     0x3da7b4: stur            x1, [fp, #-8]
    //     0x3da7b8: stur            x2, [fp, #-0x10]
    //     0x3da7bc: stur            x3, [fp, #-0x18]
    // 0x3da7c0: CheckStackOverflow
    //     0x3da7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da7c4: cmp             SP, x16
    //     0x3da7c8: b.ls            #0x3dac30
    // 0x3da7cc: mov             x1, x4
    // 0x3da7d0: mov             x2, x0
    // 0x3da7d4: r0 = getGeneratorInfo()
    //     0x3da7d4: bl              #0x80d210  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getGeneratorInfo
    // 0x3da7d8: LoadField: r3 = r0->field_27
    //     0x3da7d8: ldur            w3, [x0, #0x27]
    // 0x3da7dc: DecompressPointer r3
    //     0x3da7dc: add             x3, x3, HEAP, lsl #32
    // 0x3da7e0: stur            x3, [fp, #-0x30]
    // 0x3da7e4: cmp             w3, NULL
    // 0x3da7e8: b.eq            #0x3dac38
    // 0x3da7ec: ldur            x0, [fp, #-0x10]
    // 0x3da7f0: r4 = LoadInt32Instr(r0)
    //     0x3da7f0: sbfx            x4, x0, #1, #0x1f
    //     0x3da7f4: tbz             w0, #0, #0x3da7fc
    //     0x3da7f8: ldur            x4, [x0, #7]
    // 0x3da7fc: stur            x4, [fp, #-0x28]
    // 0x3da800: cmp             x4, #6
    // 0x3da804: b.lt            #0x3daaa8
    // 0x3da808: ldur            x5, [fp, #-8]
    // 0x3da80c: LoadField: r6 = r5->field_47
    //     0x3da80c: ldur            w6, [x5, #0x47]
    // 0x3da810: DecompressPointer r6
    //     0x3da810: add             x6, x6, HEAP, lsl #32
    // 0x3da814: mov             x1, x6
    // 0x3da818: stur            x6, [fp, #-0x20]
    // 0x3da81c: r2 = 12
    //     0x3da81c: movz            x2, #0xc
    // 0x3da820: r0 = _getValueOrData()
    //     0x3da820: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3da824: mov             x1, x0
    // 0x3da828: ldur            x0, [fp, #-0x20]
    // 0x3da82c: LoadField: r2 = r0->field_f
    //     0x3da82c: ldur            w2, [x0, #0xf]
    // 0x3da830: DecompressPointer r2
    //     0x3da830: add             x2, x2, HEAP, lsl #32
    // 0x3da834: cmp             w2, w1
    // 0x3da838: b.ne            #0x3da844
    // 0x3da83c: r0 = Null
    //     0x3da83c: mov             x0, NULL
    // 0x3da840: b               #0x3da848
    // 0x3da844: mov             x0, x1
    // 0x3da848: cmp             w0, NULL
    // 0x3da84c: b.ne            #0x3da858
    // 0x3da850: d0 = 0.000000
    //     0x3da850: eor             v0.16b, v0.16b, v0.16b
    // 0x3da854: b               #0x3da85c
    // 0x3da858: LoadField: d0 = r0->field_7
    //     0x3da858: ldur            d0, [x0, #7]
    // 0x3da85c: ldur            x0, [fp, #-8]
    // 0x3da860: stur            d0, [fp, #-0x48]
    // 0x3da864: LoadField: r3 = r0->field_47
    //     0x3da864: ldur            w3, [x0, #0x47]
    // 0x3da868: DecompressPointer r3
    //     0x3da868: add             x3, x3, HEAP, lsl #32
    // 0x3da86c: mov             x1, x3
    // 0x3da870: stur            x3, [fp, #-0x20]
    // 0x3da874: r2 = 14
    //     0x3da874: movz            x2, #0xe
    // 0x3da878: r0 = _getValueOrData()
    //     0x3da878: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3da87c: mov             x1, x0
    // 0x3da880: ldur            x0, [fp, #-0x20]
    // 0x3da884: LoadField: r2 = r0->field_f
    //     0x3da884: ldur            w2, [x0, #0xf]
    // 0x3da888: DecompressPointer r2
    //     0x3da888: add             x2, x2, HEAP, lsl #32
    // 0x3da88c: cmp             w2, w1
    // 0x3da890: b.ne            #0x3da89c
    // 0x3da894: r0 = Null
    //     0x3da894: mov             x0, NULL
    // 0x3da898: b               #0x3da8a0
    // 0x3da89c: mov             x0, x1
    // 0x3da8a0: cmp             w0, NULL
    // 0x3da8a4: b.ne            #0x3da8b0
    // 0x3da8a8: r1 = 0
    //     0x3da8a8: movz            x1, #0
    // 0x3da8ac: b               #0x3da8b4
    // 0x3da8b0: mov             x1, x0
    // 0x3da8b4: ldur            x0, [fp, #-8]
    // 0x3da8b8: ldur            d0, [fp, #-0x48]
    // 0x3da8bc: r2 = inline_Allocate_Double()
    //     0x3da8bc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x3da8c0: add             x2, x2, #0x10
    //     0x3da8c4: cmp             x3, x2
    //     0x3da8c8: b.ls            #0x3dac3c
    //     0x3da8cc: str             x2, [THR, #0x60]  ; THR::top
    //     0x3da8d0: sub             x2, x2, #0xf
    //     0x3da8d4: movz            x3, #0xe19c
    //     0x3da8d8: movk            x3, #0x3, lsl #16
    //     0x3da8dc: stur            x3, [x2, #-1]
    // 0x3da8e0: dmb             ishst
    // 0x3da8e4: StoreField: r2->field_7 = d0
    //     0x3da8e4: stur            d0, [x2, #7]
    // 0x3da8e8: stp             x1, x2, [SP]
    // 0x3da8ec: r0 = +()
    //     0x3da8ec: bl              #0x824a84  ; [dart:core] _Double::+
    // 0x3da8f0: mov             x3, x0
    // 0x3da8f4: ldur            x0, [fp, #-8]
    // 0x3da8f8: stur            x3, [fp, #-0x38]
    // 0x3da8fc: LoadField: r4 = r0->field_47
    //     0x3da8fc: ldur            w4, [x0, #0x47]
    // 0x3da900: DecompressPointer r4
    //     0x3da900: add             x4, x4, HEAP, lsl #32
    // 0x3da904: mov             x1, x4
    // 0x3da908: stur            x4, [fp, #-0x20]
    // 0x3da90c: r2 = 16
    //     0x3da90c: movz            x2, #0x10
    // 0x3da910: r0 = _getValueOrData()
    //     0x3da910: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3da914: mov             x1, x0
    // 0x3da918: ldur            x0, [fp, #-0x20]
    // 0x3da91c: LoadField: r2 = r0->field_f
    //     0x3da91c: ldur            w2, [x0, #0xf]
    // 0x3da920: DecompressPointer r2
    //     0x3da920: add             x2, x2, HEAP, lsl #32
    // 0x3da924: cmp             w2, w1
    // 0x3da928: b.ne            #0x3da934
    // 0x3da92c: r0 = Null
    //     0x3da92c: mov             x0, NULL
    // 0x3da930: b               #0x3da938
    // 0x3da934: mov             x0, x1
    // 0x3da938: cmp             w0, NULL
    // 0x3da93c: b.ne            #0x3da948
    // 0x3da940: r1 = 0
    //     0x3da940: movz            x1, #0
    // 0x3da944: b               #0x3da94c
    // 0x3da948: mov             x1, x0
    // 0x3da94c: ldur            x0, [fp, #-8]
    // 0x3da950: ldur            x16, [fp, #-0x38]
    // 0x3da954: stp             x1, x16, [SP]
    // 0x3da958: r0 = +()
    //     0x3da958: bl              #0x824a84  ; [dart:core] _Double::+
    // 0x3da95c: mov             x3, x0
    // 0x3da960: ldur            x0, [fp, #-8]
    // 0x3da964: stur            x3, [fp, #-0x38]
    // 0x3da968: LoadField: r4 = r0->field_47
    //     0x3da968: ldur            w4, [x0, #0x47]
    // 0x3da96c: DecompressPointer r4
    //     0x3da96c: add             x4, x4, HEAP, lsl #32
    // 0x3da970: mov             x1, x4
    // 0x3da974: stur            x4, [fp, #-0x20]
    // 0x3da978: r2 = 18
    //     0x3da978: movz            x2, #0x12
    // 0x3da97c: r0 = _getValueOrData()
    //     0x3da97c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3da980: mov             x1, x0
    // 0x3da984: ldur            x0, [fp, #-0x20]
    // 0x3da988: LoadField: r2 = r0->field_f
    //     0x3da988: ldur            w2, [x0, #0xf]
    // 0x3da98c: DecompressPointer r2
    //     0x3da98c: add             x2, x2, HEAP, lsl #32
    // 0x3da990: cmp             w2, w1
    // 0x3da994: b.ne            #0x3da9a0
    // 0x3da998: r0 = Null
    //     0x3da998: mov             x0, NULL
    // 0x3da99c: b               #0x3da9a4
    // 0x3da9a0: mov             x0, x1
    // 0x3da9a4: cmp             w0, NULL
    // 0x3da9a8: b.ne            #0x3da9b4
    // 0x3da9ac: r1 = 0
    //     0x3da9ac: movz            x1, #0
    // 0x3da9b0: b               #0x3da9b8
    // 0x3da9b4: mov             x1, x0
    // 0x3da9b8: ldur            x0, [fp, #-8]
    // 0x3da9bc: ldur            x16, [fp, #-0x38]
    // 0x3da9c0: stp             x1, x16, [SP]
    // 0x3da9c4: r0 = +()
    //     0x3da9c4: bl              #0x824a84  ; [dart:core] _Double::+
    // 0x3da9c8: mov             x3, x0
    // 0x3da9cc: ldur            x0, [fp, #-8]
    // 0x3da9d0: stur            x3, [fp, #-0x38]
    // 0x3da9d4: LoadField: r4 = r0->field_47
    //     0x3da9d4: ldur            w4, [x0, #0x47]
    // 0x3da9d8: DecompressPointer r4
    //     0x3da9d8: add             x4, x4, HEAP, lsl #32
    // 0x3da9dc: mov             x1, x4
    // 0x3da9e0: stur            x4, [fp, #-0x20]
    // 0x3da9e4: r2 = 20
    //     0x3da9e4: movz            x2, #0x14
    // 0x3da9e8: r0 = _getValueOrData()
    //     0x3da9e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3da9ec: mov             x1, x0
    // 0x3da9f0: ldur            x0, [fp, #-0x20]
    // 0x3da9f4: LoadField: r2 = r0->field_f
    //     0x3da9f4: ldur            w2, [x0, #0xf]
    // 0x3da9f8: DecompressPointer r2
    //     0x3da9f8: add             x2, x2, HEAP, lsl #32
    // 0x3da9fc: cmp             w2, w1
    // 0x3daa00: b.ne            #0x3daa0c
    // 0x3daa04: r0 = Null
    //     0x3daa04: mov             x0, NULL
    // 0x3daa08: b               #0x3daa10
    // 0x3daa0c: mov             x0, x1
    // 0x3daa10: cmp             w0, NULL
    // 0x3daa14: b.ne            #0x3daa20
    // 0x3daa18: r1 = 0
    //     0x3daa18: movz            x1, #0
    // 0x3daa1c: b               #0x3daa24
    // 0x3daa20: mov             x1, x0
    // 0x3daa24: ldur            x0, [fp, #-8]
    // 0x3daa28: ldur            x16, [fp, #-0x38]
    // 0x3daa2c: stp             x1, x16, [SP]
    // 0x3daa30: r0 = +()
    //     0x3daa30: bl              #0x824a84  ; [dart:core] _Double::+
    // 0x3daa34: mov             x3, x0
    // 0x3daa38: ldur            x0, [fp, #-8]
    // 0x3daa3c: stur            x3, [fp, #-0x38]
    // 0x3daa40: LoadField: r4 = r0->field_47
    //     0x3daa40: ldur            w4, [x0, #0x47]
    // 0x3daa44: DecompressPointer r4
    //     0x3daa44: add             x4, x4, HEAP, lsl #32
    // 0x3daa48: mov             x1, x4
    // 0x3daa4c: ldur            x2, [fp, #-0x10]
    // 0x3daa50: stur            x4, [fp, #-0x20]
    // 0x3daa54: r0 = _getValueOrData()
    //     0x3daa54: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3daa58: mov             x1, x0
    // 0x3daa5c: ldur            x0, [fp, #-0x20]
    // 0x3daa60: LoadField: r2 = r0->field_f
    //     0x3daa60: ldur            w2, [x0, #0xf]
    // 0x3daa64: DecompressPointer r2
    //     0x3daa64: add             x2, x2, HEAP, lsl #32
    // 0x3daa68: cmp             w2, w1
    // 0x3daa6c: b.ne            #0x3daa78
    // 0x3daa70: r0 = Null
    //     0x3daa70: mov             x0, NULL
    // 0x3daa74: b               #0x3daa7c
    // 0x3daa78: mov             x0, x1
    // 0x3daa7c: cmp             w0, NULL
    // 0x3daa80: b.ne            #0x3daa88
    // 0x3daa84: r0 = 0
    //     0x3daa84: movz            x0, #0
    // 0x3daa88: ldur            x16, [fp, #-0x38]
    // 0x3daa8c: stp             x0, x16, [SP]
    // 0x3daa90: r0 = -()
    //     0x3daa90: bl              #0x81c7e4  ; [dart:core] _Double::-
    // 0x3daa94: ldur            x16, [fp, #-0x18]
    // 0x3daa98: stp             x16, x0, [SP]
    // 0x3daa9c: r0 = +()
    //     0x3daa9c: bl              #0x824a84  ; [dart:core] _Double::+
    // 0x3daaa0: mov             x2, x0
    // 0x3daaa4: b               #0x3daaac
    // 0x3daaa8: ldur            x2, [fp, #-0x18]
    // 0x3daaac: ldur            x0, [fp, #-8]
    // 0x3daab0: LoadField: r1 = r0->field_3f
    //     0x3daab0: ldur            w1, [x0, #0x3f]
    // 0x3daab4: DecompressPointer r1
    //     0x3daab4: add             x1, x1, HEAP, lsl #32
    // 0x3daab8: LoadField: r3 = r1->field_7
    //     0x3daab8: ldur            w3, [x1, #7]
    // 0x3daabc: DecompressPointer r3
    //     0x3daabc: add             x3, x3, HEAP, lsl #32
    // 0x3daac0: cmp             w3, #2
    // 0x3daac4: b.ne            #0x3dab4c
    // 0x3daac8: ldur            x1, [fp, #-0x28]
    // 0x3daacc: cmp             x1, #6
    // 0x3daad0: b.lt            #0x3dab44
    // 0x3daad4: ldur            x3, [fp, #-0x30]
    // 0x3daad8: LoadField: r0 = r3->field_b
    //     0x3daad8: ldur            w0, [x3, #0xb]
    // 0x3daadc: DecompressPointer r0
    //     0x3daadc: add             x0, x0, HEAP, lsl #32
    // 0x3daae0: stur            x0, [fp, #-0x20]
    // 0x3daae4: LoadField: r4 = r3->field_f
    //     0x3daae4: ldur            w4, [x3, #0xf]
    // 0x3daae8: DecompressPointer r4
    //     0x3daae8: add             x4, x4, HEAP, lsl #32
    // 0x3daaec: stur            x4, [fp, #-0x18]
    // 0x3daaf0: r1 = Instance_CustomNum
    //     0x3daaf0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3daaf4: ldr             x1, [x1, #0x2f0]
    // 0x3daaf8: r0 = pow()
    //     0x3daaf8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3daafc: ldur            x1, [fp, #-0x18]
    // 0x3dab00: mov             x2, x0
    // 0x3dab04: r3 = Instance_CustomNum
    //     0x3dab04: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cb40] Obj!CustomNum@828b21
    //     0x3dab08: ldr             x3, [x3, #0xb40]
    // 0x3dab0c: r0 = mult3()
    //     0x3dab0c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x3dab10: r1 = <Chapter12Stat, CustomNum>
    //     0x3dab10: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e88] TypeArguments: <Chapter12Stat, CustomNum>
    //     0x3dab14: ldr             x1, [x1, #0xe88]
    // 0x3dab18: stur            x0, [fp, #-0x18]
    // 0x3dab1c: r0 = Tuple2()
    //     0x3dab1c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3dab20: mov             x1, x0
    // 0x3dab24: ldur            x0, [fp, #-0x20]
    // 0x3dab28: StoreField: r1->field_b = r0
    //     0x3dab28: stur            w0, [x1, #0xb]
    // 0x3dab2c: ldur            x0, [fp, #-0x18]
    // 0x3dab30: StoreField: r1->field_f = r0
    //     0x3dab30: stur            w0, [x1, #0xf]
    // 0x3dab34: mov             x0, x1
    // 0x3dab38: LeaveFrame
    //     0x3dab38: mov             SP, fp
    //     0x3dab3c: ldp             fp, lr, [SP], #0x10
    // 0x3dab40: ret
    //     0x3dab40: ret             
    // 0x3dab44: ldur            x3, [fp, #-0x30]
    // 0x3dab48: b               #0x3dab50
    // 0x3dab4c: ldur            x3, [fp, #-0x30]
    // 0x3dab50: LoadField: r4 = r3->field_b
    //     0x3dab50: ldur            w4, [x3, #0xb]
    // 0x3dab54: DecompressPointer r4
    //     0x3dab54: add             x4, x4, HEAP, lsl #32
    // 0x3dab58: stur            x4, [fp, #-0x18]
    // 0x3dab5c: r1 = Instance_CustomNum
    //     0x3dab5c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3dab60: ldr             x1, [x1, #0x2f0]
    // 0x3dab64: r0 = pow()
    //     0x3dab64: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3dab68: mov             x3, x0
    // 0x3dab6c: ldur            x0, [fp, #-0x30]
    // 0x3dab70: stur            x3, [fp, #-0x40]
    // 0x3dab74: LoadField: r4 = r0->field_f
    //     0x3dab74: ldur            w4, [x0, #0xf]
    // 0x3dab78: DecompressPointer r4
    //     0x3dab78: add             x4, x4, HEAP, lsl #32
    // 0x3dab7c: ldur            x0, [fp, #-8]
    // 0x3dab80: stur            x4, [fp, #-0x38]
    // 0x3dab84: LoadField: r5 = r0->field_33
    //     0x3dab84: ldur            w5, [x0, #0x33]
    // 0x3dab88: DecompressPointer r5
    //     0x3dab88: add             x5, x5, HEAP, lsl #32
    // 0x3dab8c: mov             x1, x5
    // 0x3dab90: ldur            x2, [fp, #-0x10]
    // 0x3dab94: stur            x5, [fp, #-0x20]
    // 0x3dab98: r0 = _getValueOrData()
    //     0x3dab98: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3dab9c: mov             x1, x0
    // 0x3daba0: ldur            x0, [fp, #-0x20]
    // 0x3daba4: LoadField: r2 = r0->field_f
    //     0x3daba4: ldur            w2, [x0, #0xf]
    // 0x3daba8: DecompressPointer r2
    //     0x3daba8: add             x2, x2, HEAP, lsl #32
    // 0x3dabac: cmp             w2, w1
    // 0x3dabb0: b.ne            #0x3dabbc
    // 0x3dabb4: r0 = Null
    //     0x3dabb4: mov             x0, NULL
    // 0x3dabb8: b               #0x3dabc0
    // 0x3dabbc: mov             x0, x1
    // 0x3dabc0: cmp             w0, NULL
    // 0x3dabc4: b.ne            #0x3dabd0
    // 0x3dabc8: r0 = Null
    //     0x3dabc8: mov             x0, NULL
    // 0x3dabcc: b               #0x3dabdc
    // 0x3dabd0: LoadField: r1 = r0->field_b
    //     0x3dabd0: ldur            w1, [x0, #0xb]
    // 0x3dabd4: DecompressPointer r1
    //     0x3dabd4: add             x1, x1, HEAP, lsl #32
    // 0x3dabd8: mov             x0, x1
    // 0x3dabdc: cmp             w0, NULL
    // 0x3dabe0: b.ne            #0x3dabf0
    // 0x3dabe4: r3 = Instance_CustomNum
    //     0x3dabe4: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3dabe8: ldr             x3, [x3, #0xa70]
    // 0x3dabec: b               #0x3dabf4
    // 0x3dabf0: mov             x3, x0
    // 0x3dabf4: ldur            x0, [fp, #-0x18]
    // 0x3dabf8: ldur            x1, [fp, #-0x40]
    // 0x3dabfc: ldur            x2, [fp, #-0x38]
    // 0x3dac00: r0 = mult3()
    //     0x3dac00: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x3dac04: r1 = <Chapter12Stat, CustomNum>
    //     0x3dac04: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e88] TypeArguments: <Chapter12Stat, CustomNum>
    //     0x3dac08: ldr             x1, [x1, #0xe88]
    // 0x3dac0c: stur            x0, [fp, #-8]
    // 0x3dac10: r0 = Tuple2()
    //     0x3dac10: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3dac14: ldur            x1, [fp, #-0x18]
    // 0x3dac18: StoreField: r0->field_b = r1
    //     0x3dac18: stur            w1, [x0, #0xb]
    // 0x3dac1c: ldur            x1, [fp, #-8]
    // 0x3dac20: StoreField: r0->field_f = r1
    //     0x3dac20: stur            w1, [x0, #0xf]
    // 0x3dac24: LeaveFrame
    //     0x3dac24: mov             SP, fp
    //     0x3dac28: ldp             fp, lr, [SP], #0x10
    // 0x3dac2c: ret
    //     0x3dac2c: ret             
    // 0x3dac30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dac30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dac34: b               #0x3da7cc
    // 0x3dac38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3dac38: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x3dac3c: SaveReg d0
    //     0x3dac3c: str             q0, [SP, #-0x10]!
    // 0x3dac40: stp             x0, x1, [SP, #-0x10]!
    // 0x3dac44: r0 = AllocateDouble()
    //     0x3dac44: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x3dac48: mov             x2, x0
    // 0x3dac4c: ldp             x0, x1, [SP], #0x10
    // 0x3dac50: RestoreReg d0
    //     0x3dac50: ldr             q0, [SP], #0x10
    // 0x3dac54: b               #0x3da8e4
  }
  [closure] Tuple2<Chapter12Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3dac58, size: 0x40
    // 0x3dac58: EnterFrame
    //     0x3dac58: stp             fp, lr, [SP, #-0x10]!
    //     0x3dac5c: mov             fp, SP
    // 0x3dac60: ldr             x0, [fp, #0x20]
    // 0x3dac64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3dac64: ldur            w1, [x0, #0x17]
    // 0x3dac68: DecompressPointer r1
    //     0x3dac68: add             x1, x1, HEAP, lsl #32
    // 0x3dac6c: CheckStackOverflow
    //     0x3dac6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dac70: cmp             SP, x16
    //     0x3dac74: b.ls            #0x3dac90
    // 0x3dac78: ldr             x2, [fp, #0x18]
    // 0x3dac7c: ldr             x3, [fp, #0x10]
    // 0x3dac80: r0 = getCostToBuyOneMoreGenerator()
    //     0x3dac80: bl              #0x3da7a0  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getCostToBuyOneMoreGenerator
    // 0x3dac84: LeaveFrame
    //     0x3dac84: mov             SP, fp
    //     0x3dac88: ldp             fp, lr, [SP], #0x10
    // 0x3dac8c: ret
    //     0x3dac8c: ret             
    // 0x3dac90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dac90: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dac94: b               #0x3dac78
  }
  _ Chapter12GameState(/* No info */) {
    // ** addr: 0x46d16c, size: 0x2a8
    // 0x46d16c: EnterFrame
    //     0x46d16c: stp             fp, lr, [SP, #-0x10]!
    //     0x46d170: mov             fp, SP
    // 0x46d174: AllocStack(0x38)
    //     0x46d174: sub             SP, SP, #0x38
    // 0x46d178: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0x46d17c: r0 = false
    //     0x46d17c: add             x0, NULL, #0x30  ; false
    // 0x46d180: mov             x5, x1
    // 0x46d184: mov             x4, x2
    // 0x46d188: stur            x1, [fp, #-8]
    // 0x46d18c: stur            x2, [fp, #-0x10]
    // 0x46d190: CheckStackOverflow
    //     0x46d190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46d194: cmp             SP, x16
    //     0x46d198: b.ls            #0x46d40c
    // 0x46d19c: StoreField: r5->field_8f = r3
    //     0x46d19c: stur            w3, [x5, #0x8f]
    // 0x46d1a0: StoreField: r5->field_93 = r3
    //     0x46d1a0: stur            w3, [x5, #0x93]
    // 0x46d1a4: StoreField: r5->field_97 = r0
    //     0x46d1a4: stur            w0, [x5, #0x97]
    // 0x46d1a8: r1 = Null
    //     0x46d1a8: mov             x1, NULL
    // 0x46d1ac: r2 = 40
    //     0x46d1ac: movz            x2, #0x28
    // 0x46d1b0: r0 = AllocateArray()
    //     0x46d1b0: bl              #0x82746c  ; AllocateArrayStub
    // 0x46d1b4: r16 = 2
    //     0x46d1b4: movz            x16, #0x2
    // 0x46d1b8: StoreField: r0->field_f = r16
    //     0x46d1b8: stur            w16, [x0, #0xf]
    // 0x46d1bc: r16 = Instance_Chapter12Stat
    //     0x46d1bc: add             x16, PP, #0x11, lsl #12  ; [pp+0x113f0] Obj!Chapter12Stat@85fcc1
    //     0x46d1c0: ldr             x16, [x16, #0x3f0]
    // 0x46d1c4: StoreField: r0->field_13 = r16
    //     0x46d1c4: stur            w16, [x0, #0x13]
    // 0x46d1c8: r16 = 4
    //     0x46d1c8: movz            x16, #0x4
    // 0x46d1cc: ArrayStore: r0[0] = r16  ; List_4
    //     0x46d1cc: stur            w16, [x0, #0x17]
    // 0x46d1d0: r16 = Instance_Chapter12Stat
    //     0x46d1d0: add             x16, PP, #0x11, lsl #12  ; [pp+0x113f8] Obj!Chapter12Stat@85fca1
    //     0x46d1d4: ldr             x16, [x16, #0x3f8]
    // 0x46d1d8: StoreField: r0->field_1b = r16
    //     0x46d1d8: stur            w16, [x0, #0x1b]
    // 0x46d1dc: r16 = 6
    //     0x46d1dc: movz            x16, #0x6
    // 0x46d1e0: StoreField: r0->field_1f = r16
    //     0x46d1e0: stur            w16, [x0, #0x1f]
    // 0x46d1e4: r16 = Instance_Chapter12Stat
    //     0x46d1e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11400] Obj!Chapter12Stat@85fc81
    //     0x46d1e8: ldr             x16, [x16, #0x400]
    // 0x46d1ec: StoreField: r0->field_23 = r16
    //     0x46d1ec: stur            w16, [x0, #0x23]
    // 0x46d1f0: r16 = 8
    //     0x46d1f0: movz            x16, #0x8
    // 0x46d1f4: StoreField: r0->field_27 = r16
    //     0x46d1f4: stur            w16, [x0, #0x27]
    // 0x46d1f8: r16 = Instance_Chapter12Stat
    //     0x46d1f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11408] Obj!Chapter12Stat@85fc61
    //     0x46d1fc: ldr             x16, [x16, #0x408]
    // 0x46d200: StoreField: r0->field_2b = r16
    //     0x46d200: stur            w16, [x0, #0x2b]
    // 0x46d204: r16 = 10
    //     0x46d204: movz            x16, #0xa
    // 0x46d208: StoreField: r0->field_2f = r16
    //     0x46d208: stur            w16, [x0, #0x2f]
    // 0x46d20c: r16 = Instance_Chapter12Stat
    //     0x46d20c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x46d210: ldr             x16, [x16, #0x410]
    // 0x46d214: StoreField: r0->field_33 = r16
    //     0x46d214: stur            w16, [x0, #0x33]
    // 0x46d218: r16 = 12
    //     0x46d218: movz            x16, #0xc
    // 0x46d21c: StoreField: r0->field_37 = r16
    //     0x46d21c: stur            w16, [x0, #0x37]
    // 0x46d220: r16 = Instance_Chapter12Stat
    //     0x46d220: add             x16, PP, #0x11, lsl #12  ; [pp+0x11418] Obj!Chapter12Stat@85fc21
    //     0x46d224: ldr             x16, [x16, #0x418]
    // 0x46d228: StoreField: r0->field_3b = r16
    //     0x46d228: stur            w16, [x0, #0x3b]
    // 0x46d22c: r16 = 14
    //     0x46d22c: movz            x16, #0xe
    // 0x46d230: StoreField: r0->field_3f = r16
    //     0x46d230: stur            w16, [x0, #0x3f]
    // 0x46d234: r16 = Instance_Chapter12Stat
    //     0x46d234: add             x16, PP, #0x11, lsl #12  ; [pp+0x11420] Obj!Chapter12Stat@85fc01
    //     0x46d238: ldr             x16, [x16, #0x420]
    // 0x46d23c: StoreField: r0->field_43 = r16
    //     0x46d23c: stur            w16, [x0, #0x43]
    // 0x46d240: r16 = 16
    //     0x46d240: movz            x16, #0x10
    // 0x46d244: StoreField: r0->field_47 = r16
    //     0x46d244: stur            w16, [x0, #0x47]
    // 0x46d248: r16 = Instance_Chapter12Stat
    //     0x46d248: add             x16, PP, #0x11, lsl #12  ; [pp+0x11428] Obj!Chapter12Stat@85fbe1
    //     0x46d24c: ldr             x16, [x16, #0x428]
    // 0x46d250: StoreField: r0->field_4b = r16
    //     0x46d250: stur            w16, [x0, #0x4b]
    // 0x46d254: r16 = 18
    //     0x46d254: movz            x16, #0x12
    // 0x46d258: StoreField: r0->field_4f = r16
    //     0x46d258: stur            w16, [x0, #0x4f]
    // 0x46d25c: r16 = Instance_Chapter12Stat
    //     0x46d25c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11430] Obj!Chapter12Stat@85fbc1
    //     0x46d260: ldr             x16, [x16, #0x430]
    // 0x46d264: StoreField: r0->field_53 = r16
    //     0x46d264: stur            w16, [x0, #0x53]
    // 0x46d268: r16 = 20
    //     0x46d268: movz            x16, #0x14
    // 0x46d26c: StoreField: r0->field_57 = r16
    //     0x46d26c: stur            w16, [x0, #0x57]
    // 0x46d270: r16 = Instance_Chapter12Stat
    //     0x46d270: add             x16, PP, #0x11, lsl #12  ; [pp+0x11438] Obj!Chapter12Stat@85fba1
    //     0x46d274: ldr             x16, [x16, #0x438]
    // 0x46d278: StoreField: r0->field_5b = r16
    //     0x46d278: stur            w16, [x0, #0x5b]
    // 0x46d27c: r16 = <int, Chapter12Stat>
    //     0x46d27c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11440] TypeArguments: <int, Chapter12Stat>
    //     0x46d280: ldr             x16, [x16, #0x440]
    // 0x46d284: stp             x0, x16, [SP]
    // 0x46d288: r0 = Map._fromLiteral()
    //     0x46d288: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46d28c: ldur            x3, [fp, #-8]
    // 0x46d290: StoreField: r3->field_9b = r0
    //     0x46d290: stur            w0, [x3, #0x9b]
    //     0x46d294: ldurb           w16, [x3, #-1]
    //     0x46d298: ldurb           w17, [x0, #-1]
    //     0x46d29c: and             x16, x17, x16, lsr #2
    //     0x46d2a0: tst             x16, HEAP, lsr #32
    //     0x46d2a4: b.eq            #0x46d2ac
    //     0x46d2a8: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46d2ac: r1 = Function '<anonymous closure>':.
    //     0x46d2ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11448] AnonymousClosure: (0x46d734), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x46d2b0: ldr             x1, [x1, #0x448]
    // 0x46d2b4: r2 = Null
    //     0x46d2b4: mov             x2, NULL
    // 0x46d2b8: r0 = AllocateClosure()
    //     0x46d2b8: bl              #0x826750  ; AllocateClosureStub
    // 0x46d2bc: r1 = Function '<anonymous closure>':.
    //     0x46d2bc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11450] AnonymousClosure: (0x46d5ac), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x46d2c0: ldr             x1, [x1, #0x450]
    // 0x46d2c4: r2 = Null
    //     0x46d2c4: mov             x2, NULL
    // 0x46d2c8: stur            x0, [fp, #-0x18]
    // 0x46d2cc: r0 = AllocateClosure()
    //     0x46d2cc: bl              #0x826750  ; AllocateClosureStub
    // 0x46d2d0: r1 = Function '<anonymous closure>':.
    //     0x46d2d0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11458] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x46d2d4: ldr             x1, [x1, #0x458]
    // 0x46d2d8: r2 = Null
    //     0x46d2d8: mov             x2, NULL
    // 0x46d2dc: stur            x0, [fp, #-0x20]
    // 0x46d2e0: r0 = AllocateClosure()
    //     0x46d2e0: bl              #0x826750  ; AllocateClosureStub
    // 0x46d2e4: r1 = Function '<anonymous closure>':.
    //     0x46d2e4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11460] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46d2e8: ldr             x1, [x1, #0x460]
    // 0x46d2ec: r2 = Null
    //     0x46d2ec: mov             x2, NULL
    // 0x46d2f0: stur            x0, [fp, #-0x28]
    // 0x46d2f4: r0 = AllocateClosure()
    //     0x46d2f4: bl              #0x826750  ; AllocateClosureStub
    // 0x46d2f8: ldur            x1, [fp, #-8]
    // 0x46d2fc: ldur            x2, [fp, #-0x10]
    // 0x46d300: ldur            x3, [fp, #-0x18]
    // 0x46d304: ldur            x5, [fp, #-0x20]
    // 0x46d308: ldur            x6, [fp, #-0x28]
    // 0x46d30c: mov             x7, x0
    // 0x46d310: r0 = IPlayableGameState()
    //     0x46d310: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46d314: ldur            x1, [fp, #-0x10]
    // 0x46d318: cmp             w1, NULL
    // 0x46d31c: b.ne            #0x46d328
    // 0x46d320: r3 = Null
    //     0x46d320: mov             x3, NULL
    // 0x46d324: b               #0x46d344
    // 0x46d328: r0 = LoadClassIdInstr(r1)
    //     0x46d328: ldur            x0, [x1, #-1]
    //     0x46d32c: ubfx            x0, x0, #0xc, #0x14
    // 0x46d330: r2 = 38
    //     0x46d330: movz            x2, #0x26
    // 0x46d334: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46d334: sub             lr, x0, #1, lsl #12
    //     0x46d338: ldr             lr, [x21, lr, lsl #3]
    //     0x46d33c: blr             lr
    // 0x46d340: mov             x3, x0
    // 0x46d344: mov             x0, x3
    // 0x46d348: stur            x3, [fp, #-0x10]
    // 0x46d34c: r2 = Null
    //     0x46d34c: mov             x2, NULL
    // 0x46d350: r1 = Null
    //     0x46d350: mov             x1, NULL
    // 0x46d354: r8 = Map?
    //     0x46d354: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x46d358: ldr             x8, [x8, #0x38]
    // 0x46d35c: r3 = Null
    //     0x46d35c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11468] Null
    //     0x46d360: ldr             x3, [x3, #0x468]
    // 0x46d364: r0 = Map?()
    //     0x46d364: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x46d368: ldur            x1, [fp, #-0x10]
    // 0x46d36c: cmp             w1, NULL
    // 0x46d370: b.ne            #0x46d37c
    // 0x46d374: r4 = Null
    //     0x46d374: mov             x4, NULL
    // 0x46d378: b               #0x46d398
    // 0x46d37c: r0 = LoadClassIdInstr(r1)
    //     0x46d37c: ldur            x0, [x1, #-1]
    //     0x46d380: ubfx            x0, x0, #0xc, #0x14
    // 0x46d384: r2 = 0
    //     0x46d384: movz            x2, #0
    // 0x46d388: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46d388: sub             lr, x0, #1, lsl #12
    //     0x46d38c: ldr             lr, [x21, lr, lsl #3]
    //     0x46d390: blr             lr
    // 0x46d394: mov             x4, x0
    // 0x46d398: ldur            x3, [fp, #-8]
    // 0x46d39c: mov             x0, x4
    // 0x46d3a0: stur            x4, [fp, #-0x10]
    // 0x46d3a4: r2 = Null
    //     0x46d3a4: mov             x2, NULL
    // 0x46d3a8: r1 = Null
    //     0x46d3a8: mov             x1, NULL
    // 0x46d3ac: r4 = 60
    //     0x46d3ac: movz            x4, #0x3c
    // 0x46d3b0: branchIfSmi(r0, 0x46d3bc)
    //     0x46d3b0: tbz             w0, #0, #0x46d3bc
    // 0x46d3b4: r4 = LoadClassIdInstr(r0)
    //     0x46d3b4: ldur            x4, [x0, #-1]
    //     0x46d3b8: ubfx            x4, x4, #0xc, #0x14
    // 0x46d3bc: cmp             x4, #0x3e
    // 0x46d3c0: b.eq            #0x46d3d4
    // 0x46d3c4: r8 = double?
    //     0x46d3c4: ldr             x8, [PP, #0xb88]  ; [pp+0xb88] Type: double?
    // 0x46d3c8: r3 = Null
    //     0x46d3c8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11478] Null
    //     0x46d3cc: ldr             x3, [x3, #0x478]
    // 0x46d3d0: r0 = double?()
    //     0x46d3d0: bl              #0x82b4a0  ; IsType_double?_Stub
    // 0x46d3d4: ldur            x0, [fp, #-0x10]
    // 0x46d3d8: ldur            x1, [fp, #-8]
    // 0x46d3dc: StoreField: r1->field_8b = r0
    //     0x46d3dc: stur            w0, [x1, #0x8b]
    //     0x46d3e0: tbz             w0, #0, #0x46d3fc
    //     0x46d3e4: ldurb           w16, [x1, #-1]
    //     0x46d3e8: ldurb           w17, [x0, #-1]
    //     0x46d3ec: and             x16, x17, x16, lsr #2
    //     0x46d3f0: tst             x16, HEAP, lsr #32
    //     0x46d3f4: b.eq            #0x46d3fc
    //     0x46d3f8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x46d3fc: r0 = Null
    //     0x46d3fc: mov             x0, NULL
    // 0x46d400: LeaveFrame
    //     0x46d400: mov             SP, fp
    //     0x46d404: ldp             fp, lr, [SP], #0x10
    // 0x46d408: ret
    //     0x46d408: ret             
    // 0x46d40c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46d40c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46d410: b               #0x46d19c
  }
  [closure] String <anonymous closure>(dynamic, Chapter12Stat) {
    // ** addr: 0x46d414, size: 0x30
    // 0x46d414: EnterFrame
    //     0x46d414: stp             fp, lr, [SP, #-0x10]!
    //     0x46d418: mov             fp, SP
    // 0x46d41c: CheckStackOverflow
    //     0x46d41c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46d420: cmp             SP, x16
    //     0x46d424: b.ls            #0x46d43c
    // 0x46d428: ldr             x1, [fp, #0x10]
    // 0x46d42c: r0 = humanName()
    //     0x46d42c: bl              #0x46d444  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] ::humanName
    // 0x46d430: LeaveFrame
    //     0x46d430: mov             SP, fp
    //     0x46d434: ldp             fp, lr, [SP], #0x10
    // 0x46d438: ret
    //     0x46d438: ret             
    // 0x46d43c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46d43c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46d440: b               #0x46d428
  }
  [closure] String <anonymous closure>(dynamic, Chapter12Stat) {
    // ** addr: 0x46d5ac, size: 0x30
    // 0x46d5ac: EnterFrame
    //     0x46d5ac: stp             fp, lr, [SP, #-0x10]!
    //     0x46d5b0: mov             fp, SP
    // 0x46d5b4: CheckStackOverflow
    //     0x46d5b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46d5b8: cmp             SP, x16
    //     0x46d5bc: b.ls            #0x46d5d4
    // 0x46d5c0: ldr             x1, [fp, #0x10]
    // 0x46d5c4: r0 = shortenedName()
    //     0x46d5c4: bl              #0x46d5dc  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] ::shortenedName
    // 0x46d5c8: LeaveFrame
    //     0x46d5c8: mov             SP, fp
    //     0x46d5cc: ldp             fp, lr, [SP], #0x10
    // 0x46d5d0: ret
    //     0x46d5d0: ret             
    // 0x46d5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46d5d4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46d5d8: b               #0x46d5c0
  }
  [closure] Chapter12Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46d734, size: 0x44
    // 0x46d734: r2 = const [Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat', Instance of 'Chapter12Stat']
    //     0x46d734: add             x2, PP, #0x11, lsl #12  ; [pp+0x11558] List<Chapter12Stat>(12)
    //     0x46d738: ldr             x2, [x2, #0x558]
    // 0x46d73c: ldr             x3, [SP]
    // 0x46d740: r4 = LoadInt32Instr(r3)
    //     0x46d740: sbfx            x4, x3, #1, #0x1f
    //     0x46d744: tbz             w3, #0, #0x46d74c
    //     0x46d748: ldur            x4, [x3, #7]
    // 0x46d74c: mov             x1, x4
    // 0x46d750: r0 = 12
    //     0x46d750: movz            x0, #0xc
    // 0x46d754: cmp             x1, x0
    // 0x46d758: b.hs            #0x46d76c
    // 0x46d75c: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46d75c: add             x16, x2, x4, lsl #2
    //     0x46d760: ldur            w0, [x16, #0xf]
    // 0x46d764: DecompressPointer r0
    //     0x46d764: add             x0, x0, HEAP, lsl #32
    // 0x46d768: ret
    //     0x46d768: ret             
    // 0x46d76c: EnterFrame
    //     0x46d76c: stp             fp, lr, [SP, #-0x10]!
    //     0x46d770: mov             fp, SP
    // 0x46d774: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46d774: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toMapFile(/* No info */) {
    // ** addr: 0x4e2f08, size: 0xc8
    // 0x4e2f08: EnterFrame
    //     0x4e2f08: stp             fp, lr, [SP, #-0x10]!
    //     0x4e2f0c: mov             fp, SP
    // 0x4e2f10: AllocStack(0x20)
    //     0x4e2f10: sub             SP, SP, #0x20
    // 0x4e2f14: SetupParameters(Chapter12GameState this /* r1 => r0, fp-0x8 */, {dynamic zeroOutIdleTime = false /* r1 */})
    //     0x4e2f14: mov             x0, x1
    //     0x4e2f18: stur            x1, [fp, #-8]
    //     0x4e2f1c: ldur            w1, [x4, #0x13]
    //     0x4e2f20: ldur            w2, [x4, #0x1f]
    //     0x4e2f24: add             x2, x2, HEAP, lsl #32
    //     0x4e2f28: add             x16, PP, #0x14, lsl #12  ; [pp+0x143e8] "zeroOutIdleTime"
    //     0x4e2f2c: ldr             x16, [x16, #0x3e8]
    //     0x4e2f30: cmp             w2, w16
    //     0x4e2f34: b.ne            #0x4e2f50
    //     0x4e2f38: ldur            w2, [x4, #0x23]
    //     0x4e2f3c: add             x2, x2, HEAP, lsl #32
    //     0x4e2f40: sub             w3, w1, w2
    //     0x4e2f44: add             x1, fp, w3, sxtw #2
    //     0x4e2f48: ldr             x1, [x1, #8]
    //     0x4e2f4c: b               #0x4e2f54
    //     0x4e2f50: add             x1, NULL, #0x30  ; false
    // 0x4e2f54: CheckStackOverflow
    //     0x4e2f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e2f58: cmp             SP, x16
    //     0x4e2f5c: b.ls            #0x4e2fc8
    // 0x4e2f60: str             x1, [SP]
    // 0x4e2f64: mov             x1, x0
    // 0x4e2f68: r4 = const [0, 0x2, 0x1, 0x1, zeroOutIdleTime, 0x1, null]
    //     0x4e2f68: add             x4, PP, #0xe, lsl #12  ; [pp+0xeb78] List(7) [0, 0x2, 0x1, 0x1, "zeroOutIdleTime", 0x1, Null]
    //     0x4e2f6c: ldr             x4, [x4, #0xb78]
    // 0x4e2f70: r0 = toMapFile()
    //     0x4e2f70: bl              #0x4e365c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::toMapFile
    // 0x4e2f74: r1 = Null
    //     0x4e2f74: mov             x1, NULL
    // 0x4e2f78: r2 = 4
    //     0x4e2f78: movz            x2, #0x4
    // 0x4e2f7c: stur            x0, [fp, #-0x10]
    // 0x4e2f80: r0 = AllocateArray()
    //     0x4e2f80: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e2f84: StoreField: r0->field_f = rZR
    //     0x4e2f84: stur            wzr, [x0, #0xf]
    // 0x4e2f88: ldur            x1, [fp, #-8]
    // 0x4e2f8c: LoadField: r2 = r1->field_8b
    //     0x4e2f8c: ldur            w2, [x1, #0x8b]
    // 0x4e2f90: DecompressPointer r2
    //     0x4e2f90: add             x2, x2, HEAP, lsl #32
    // 0x4e2f94: StoreField: r0->field_13 = r2
    //     0x4e2f94: stur            w2, [x0, #0x13]
    // 0x4e2f98: r16 = <int, dynamic>
    //     0x4e2f98: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x4e2f9c: ldr             x16, [x16, #0x4f0]
    // 0x4e2fa0: stp             x0, x16, [SP]
    // 0x4e2fa4: r0 = Map._fromLiteral()
    //     0x4e2fa4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e2fa8: ldur            x1, [fp, #-0x10]
    // 0x4e2fac: mov             x3, x0
    // 0x4e2fb0: r2 = 38
    //     0x4e2fb0: movz            x2, #0x26
    // 0x4e2fb4: r0 = []=()
    //     0x4e2fb4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4e2fb8: ldur            x0, [fp, #-0x10]
    // 0x4e2fbc: LeaveFrame
    //     0x4e2fbc: mov             SP, fp
    //     0x4e2fc0: ldp             fp, lr, [SP], #0x10
    // 0x4e2fc4: ret
    //     0x4e2fc4: ret             
    // 0x4e2fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e2fc8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e2fcc: b               #0x4e2f60
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e6b1c, size: 0x78
    // 0x4e6b1c: EnterFrame
    //     0x4e6b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6b20: mov             fp, SP
    // 0x4e6b24: AllocStack(0x18)
    //     0x4e6b24: sub             SP, SP, #0x18
    // 0x4e6b28: SetupParameters(Chapter12GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e6b28: stur            x1, [fp, #-8]
    // 0x4e6b2c: r1 = 1
    //     0x4e6b2c: movz            x1, #0x1
    // 0x4e6b30: r0 = AllocateContext()
    //     0x4e6b30: bl              #0x82637c  ; AllocateContextStub
    // 0x4e6b34: mov             x3, x0
    // 0x4e6b38: ldur            x0, [fp, #-8]
    // 0x4e6b3c: stur            x3, [fp, #-0x10]
    // 0x4e6b40: StoreField: r3->field_f = r0
    //     0x4e6b40: stur            w0, [x3, #0xf]
    // 0x4e6b44: mov             x2, x3
    // 0x4e6b48: r1 = Function '<anonymous closure>':.
    //     0x4e6b48: add             x1, PP, #0x25, lsl #12  ; [pp+0x25768] AnonymousClosure: (0x4e6c94), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::makeHeader (0x4e6b1c)
    //     0x4e6b4c: ldr             x1, [x1, #0x768]
    // 0x4e6b50: r0 = AllocateClosure()
    //     0x4e6b50: bl              #0x826750  ; AllocateClosureStub
    // 0x4e6b54: stur            x0, [fp, #-8]
    // 0x4e6b58: r0 = MainStatDisplay()
    //     0x4e6b58: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e6b5c: mov             x3, x0
    // 0x4e6b60: ldur            x0, [fp, #-8]
    // 0x4e6b64: stur            x3, [fp, #-0x18]
    // 0x4e6b68: StoreField: r3->field_b = r0
    //     0x4e6b68: stur            w0, [x3, #0xb]
    // 0x4e6b6c: ldur            x2, [fp, #-0x10]
    // 0x4e6b70: r1 = Function '<anonymous closure>':.
    //     0x4e6b70: add             x1, PP, #0x25, lsl #12  ; [pp+0x25770] AnonymousClosure: (0x4e6b94), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::makeHeader (0x4e6b1c)
    //     0x4e6b74: ldr             x1, [x1, #0x770]
    // 0x4e6b78: r0 = AllocateClosure()
    //     0x4e6b78: bl              #0x826750  ; AllocateClosureStub
    // 0x4e6b7c: mov             x1, x0
    // 0x4e6b80: ldur            x0, [fp, #-0x18]
    // 0x4e6b84: StoreField: r0->field_f = r1
    //     0x4e6b84: stur            w1, [x0, #0xf]
    // 0x4e6b88: LeaveFrame
    //     0x4e6b88: mov             SP, fp
    //     0x4e6b8c: ldp             fp, lr, [SP], #0x10
    // 0x4e6b90: ret
    //     0x4e6b90: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e6b94, size: 0x100
    // 0x4e6b94: EnterFrame
    //     0x4e6b94: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6b98: mov             fp, SP
    // 0x4e6b9c: AllocStack(0x18)
    //     0x4e6b9c: sub             SP, SP, #0x18
    // 0x4e6ba0: SetupParameters([dynamic _ /* r0 */])
    //     0x4e6ba0: ldr             x0, [fp, #0x10]
    //     0x4e6ba4: ldur            w1, [x0, #0x17]
    //     0x4e6ba8: add             x1, x1, HEAP, lsl #32
    // 0x4e6bac: CheckStackOverflow
    //     0x4e6bac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e6bb0: cmp             SP, x16
    //     0x4e6bb4: b.ls            #0x4e6c8c
    // 0x4e6bb8: LoadField: r0 = r1->field_f
    //     0x4e6bb8: ldur            w0, [x1, #0xf]
    // 0x4e6bbc: DecompressPointer r0
    //     0x4e6bbc: add             x0, x0, HEAP, lsl #32
    // 0x4e6bc0: LoadField: r3 = r0->field_57
    //     0x4e6bc0: ldur            w3, [x0, #0x57]
    // 0x4e6bc4: DecompressPointer r3
    //     0x4e6bc4: add             x3, x3, HEAP, lsl #32
    // 0x4e6bc8: mov             x1, x3
    // 0x4e6bcc: stur            x3, [fp, #-8]
    // 0x4e6bd0: r2 = Instance_Chapter12Stat
    //     0x4e6bd0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x4e6bd4: ldr             x2, [x2, #0x488]
    // 0x4e6bd8: r0 = _getValueOrData()
    //     0x4e6bd8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e6bdc: mov             x1, x0
    // 0x4e6be0: ldur            x0, [fp, #-8]
    // 0x4e6be4: LoadField: r2 = r0->field_f
    //     0x4e6be4: ldur            w2, [x0, #0xf]
    // 0x4e6be8: DecompressPointer r2
    //     0x4e6be8: add             x2, x2, HEAP, lsl #32
    // 0x4e6bec: cmp             w2, w1
    // 0x4e6bf0: b.ne            #0x4e6bfc
    // 0x4e6bf4: r0 = Null
    //     0x4e6bf4: mov             x0, NULL
    // 0x4e6bf8: b               #0x4e6c00
    // 0x4e6bfc: mov             x0, x1
    // 0x4e6c00: stur            x0, [fp, #-8]
    // 0x4e6c04: cmp             w0, NULL
    // 0x4e6c08: b.eq            #0x4e6c7c
    // 0x4e6c0c: r1 = Null
    //     0x4e6c0c: mov             x1, NULL
    // 0x4e6c10: r2 = 6
    //     0x4e6c10: movz            x2, #0x6
    // 0x4e6c14: r0 = AllocateArray()
    //     0x4e6c14: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e6c18: stur            x0, [fp, #-0x10]
    // 0x4e6c1c: r16 = "("
    //     0x4e6c1c: ldr             x16, [PP, #0x2218]  ; [pp+0x2218] "("
    // 0x4e6c20: StoreField: r0->field_f = r16
    //     0x4e6c20: stur            w16, [x0, #0xf]
    // 0x4e6c24: ldur            x1, [fp, #-8]
    // 0x4e6c28: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e6c28: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e6c2c: r0 = toStringConsistentDecimalPlaces()
    //     0x4e6c2c: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e6c30: ldur            x1, [fp, #-0x10]
    // 0x4e6c34: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e6c34: add             x25, x1, #0x13
    //     0x4e6c38: str             w0, [x25]
    //     0x4e6c3c: tbz             w0, #0, #0x4e6c58
    //     0x4e6c40: ldurb           w16, [x1, #-1]
    //     0x4e6c44: ldurb           w17, [x0, #-1]
    //     0x4e6c48: and             x16, x17, x16, lsr #2
    //     0x4e6c4c: tst             x16, HEAP, lsr #32
    //     0x4e6c50: b.eq            #0x4e6c58
    //     0x4e6c54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6c58: ldur            x0, [fp, #-0x10]
    // 0x4e6c5c: r16 = "/s)"
    //     0x4e6c5c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a568] "/s)"
    //     0x4e6c60: ldr             x16, [x16, #0x568]
    // 0x4e6c64: ArrayStore: r0[0] = r16  ; List_4
    //     0x4e6c64: stur            w16, [x0, #0x17]
    // 0x4e6c68: str             x0, [SP]
    // 0x4e6c6c: r0 = _interpolate()
    //     0x4e6c6c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e6c70: LeaveFrame
    //     0x4e6c70: mov             SP, fp
    //     0x4e6c74: ldp             fp, lr, [SP], #0x10
    // 0x4e6c78: ret
    //     0x4e6c78: ret             
    // 0x4e6c7c: r0 = ""
    //     0x4e6c7c: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x4e6c80: LeaveFrame
    //     0x4e6c80: mov             SP, fp
    //     0x4e6c84: ldp             fp, lr, [SP], #0x10
    // 0x4e6c88: ret
    //     0x4e6c88: ret             
    // 0x4e6c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6c8c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e6c90: b               #0x4e6bb8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e6c94, size: 0xf4
    // 0x4e6c94: EnterFrame
    //     0x4e6c94: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6c98: mov             fp, SP
    // 0x4e6c9c: AllocStack(0x18)
    //     0x4e6c9c: sub             SP, SP, #0x18
    // 0x4e6ca0: SetupParameters([dynamic _ /* r0 */])
    //     0x4e6ca0: ldr             x0, [fp, #0x10]
    //     0x4e6ca4: ldur            w3, [x0, #0x17]
    //     0x4e6ca8: add             x3, x3, HEAP, lsl #32
    //     0x4e6cac: stur            x3, [fp, #-8]
    // 0x4e6cb0: CheckStackOverflow
    //     0x4e6cb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e6cb4: cmp             SP, x16
    //     0x4e6cb8: b.ls            #0x4e6d80
    // 0x4e6cbc: r1 = Null
    //     0x4e6cbc: mov             x1, NULL
    // 0x4e6cc0: r2 = 4
    //     0x4e6cc0: movz            x2, #0x4
    // 0x4e6cc4: r0 = AllocateArray()
    //     0x4e6cc4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e6cc8: stur            x0, [fp, #-0x10]
    // 0x4e6ccc: r16 = "Research: "
    //     0x4e6ccc: add             x16, PP, #0x25, lsl #12  ; [pp+0x25778] "Research: "
    //     0x4e6cd0: ldr             x16, [x16, #0x778]
    // 0x4e6cd4: StoreField: r0->field_f = r16
    //     0x4e6cd4: stur            w16, [x0, #0xf]
    // 0x4e6cd8: ldur            x1, [fp, #-8]
    // 0x4e6cdc: LoadField: r2 = r1->field_f
    //     0x4e6cdc: ldur            w2, [x1, #0xf]
    // 0x4e6ce0: DecompressPointer r2
    //     0x4e6ce0: add             x2, x2, HEAP, lsl #32
    // 0x4e6ce4: LoadField: r3 = r2->field_37
    //     0x4e6ce4: ldur            w3, [x2, #0x37]
    // 0x4e6ce8: DecompressPointer r3
    //     0x4e6ce8: add             x3, x3, HEAP, lsl #32
    // 0x4e6cec: mov             x1, x3
    // 0x4e6cf0: stur            x3, [fp, #-8]
    // 0x4e6cf4: r2 = Instance_Chapter12Stat
    //     0x4e6cf4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x4e6cf8: ldr             x2, [x2, #0x488]
    // 0x4e6cfc: r0 = _getValueOrData()
    //     0x4e6cfc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e6d00: mov             x1, x0
    // 0x4e6d04: ldur            x0, [fp, #-8]
    // 0x4e6d08: LoadField: r2 = r0->field_f
    //     0x4e6d08: ldur            w2, [x0, #0xf]
    // 0x4e6d0c: DecompressPointer r2
    //     0x4e6d0c: add             x2, x2, HEAP, lsl #32
    // 0x4e6d10: cmp             w2, w1
    // 0x4e6d14: b.ne            #0x4e6d1c
    // 0x4e6d18: r1 = Null
    //     0x4e6d18: mov             x1, NULL
    // 0x4e6d1c: cmp             w1, NULL
    // 0x4e6d20: b.ne            #0x4e6d2c
    // 0x4e6d24: r0 = Null
    //     0x4e6d24: mov             x0, NULL
    // 0x4e6d28: b               #0x4e6d34
    // 0x4e6d2c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e6d2c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e6d30: r0 = toStringConsistentDecimalPlaces()
    //     0x4e6d30: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e6d34: cmp             w0, NULL
    // 0x4e6d38: b.ne            #0x4e6d40
    // 0x4e6d3c: r0 = 0
    //     0x4e6d3c: movz            x0, #0
    // 0x4e6d40: ldur            x1, [fp, #-0x10]
    // 0x4e6d44: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e6d44: add             x25, x1, #0x13
    //     0x4e6d48: str             w0, [x25]
    //     0x4e6d4c: tbz             w0, #0, #0x4e6d68
    //     0x4e6d50: ldurb           w16, [x1, #-1]
    //     0x4e6d54: ldurb           w17, [x0, #-1]
    //     0x4e6d58: and             x16, x17, x16, lsr #2
    //     0x4e6d5c: tst             x16, HEAP, lsr #32
    //     0x4e6d60: b.eq            #0x4e6d68
    //     0x4e6d64: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6d68: ldur            x16, [fp, #-0x10]
    // 0x4e6d6c: str             x16, [SP]
    // 0x4e6d70: r0 = _interpolate()
    //     0x4e6d70: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e6d74: LeaveFrame
    //     0x4e6d74: mov             SP, fp
    //     0x4e6d78: ldp             fp, lr, [SP], #0x10
    // 0x4e6d7c: ret
    //     0x4e6d7c: ret             
    // 0x4e6d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6d80: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e6d84: b               #0x4e6cbc
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4f69b0, size: 0x2a58
    // 0x4f69b0: EnterFrame
    //     0x4f69b0: stp             fp, lr, [SP, #-0x10]!
    //     0x4f69b4: mov             fp, SP
    // 0x4f69b8: AllocStack(0x48)
    //     0x4f69b8: sub             SP, SP, #0x48
    // 0x4f69bc: SetupParameters(Chapter12GameState this /* r1 => r1, fp-0x8 */)
    //     0x4f69bc: stur            x1, [fp, #-8]
    // 0x4f69c0: CheckStackOverflow
    //     0x4f69c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f69c4: cmp             SP, x16
    //     0x4f69c8: b.ls            #0x4f9400
    // 0x4f69cc: r1 = 1
    //     0x4f69cc: movz            x1, #0x1
    // 0x4f69d0: r0 = AllocateContext()
    //     0x4f69d0: bl              #0x82637c  ; AllocateContextStub
    // 0x4f69d4: mov             x3, x0
    // 0x4f69d8: ldur            x0, [fp, #-8]
    // 0x4f69dc: stur            x3, [fp, #-0x10]
    // 0x4f69e0: StoreField: r3->field_f = r0
    //     0x4f69e0: stur            w0, [x3, #0xf]
    // 0x4f69e4: r1 = Null
    //     0x4f69e4: mov             x1, NULL
    // 0x4f69e8: r2 = 40
    //     0x4f69e8: movz            x2, #0x28
    // 0x4f69ec: r0 = AllocateArray()
    //     0x4f69ec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f69f0: r16 = 2
    //     0x4f69f0: movz            x16, #0x2
    // 0x4f69f4: StoreField: r0->field_f = r16
    //     0x4f69f4: stur            w16, [x0, #0xf]
    // 0x4f69f8: r16 = Instance_GeneratorInfo
    //     0x4f69f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15bd0] Obj!GeneratorInfo<Chapter12Stat>@82d051
    //     0x4f69fc: ldr             x16, [x16, #0xbd0]
    // 0x4f6a00: StoreField: r0->field_13 = r16
    //     0x4f6a00: stur            w16, [x0, #0x13]
    // 0x4f6a04: r16 = 4
    //     0x4f6a04: movz            x16, #0x4
    // 0x4f6a08: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f6a08: stur            w16, [x0, #0x17]
    // 0x4f6a0c: r16 = Instance_GeneratorInfo
    //     0x4f6a0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15bd8] Obj!GeneratorInfo<Chapter12Stat>@82d011
    //     0x4f6a10: ldr             x16, [x16, #0xbd8]
    // 0x4f6a14: StoreField: r0->field_1b = r16
    //     0x4f6a14: stur            w16, [x0, #0x1b]
    // 0x4f6a18: r16 = 6
    //     0x4f6a18: movz            x16, #0x6
    // 0x4f6a1c: StoreField: r0->field_1f = r16
    //     0x4f6a1c: stur            w16, [x0, #0x1f]
    // 0x4f6a20: r16 = Instance_GeneratorInfo
    //     0x4f6a20: add             x16, PP, #0x15, lsl #12  ; [pp+0x15be0] Obj!GeneratorInfo<Chapter12Stat>@82cfd1
    //     0x4f6a24: ldr             x16, [x16, #0xbe0]
    // 0x4f6a28: StoreField: r0->field_23 = r16
    //     0x4f6a28: stur            w16, [x0, #0x23]
    // 0x4f6a2c: r16 = 8
    //     0x4f6a2c: movz            x16, #0x8
    // 0x4f6a30: StoreField: r0->field_27 = r16
    //     0x4f6a30: stur            w16, [x0, #0x27]
    // 0x4f6a34: r16 = Instance_GeneratorInfo
    //     0x4f6a34: add             x16, PP, #0x15, lsl #12  ; [pp+0x15be8] Obj!GeneratorInfo<Chapter12Stat>@82cf91
    //     0x4f6a38: ldr             x16, [x16, #0xbe8]
    // 0x4f6a3c: StoreField: r0->field_2b = r16
    //     0x4f6a3c: stur            w16, [x0, #0x2b]
    // 0x4f6a40: r16 = 10
    //     0x4f6a40: movz            x16, #0xa
    // 0x4f6a44: StoreField: r0->field_2f = r16
    //     0x4f6a44: stur            w16, [x0, #0x2f]
    // 0x4f6a48: r16 = Instance_GeneratorInfo
    //     0x4f6a48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15bf0] Obj!GeneratorInfo<Chapter12Stat>@82cf51
    //     0x4f6a4c: ldr             x16, [x16, #0xbf0]
    // 0x4f6a50: StoreField: r0->field_33 = r16
    //     0x4f6a50: stur            w16, [x0, #0x33]
    // 0x4f6a54: r16 = 12
    //     0x4f6a54: movz            x16, #0xc
    // 0x4f6a58: StoreField: r0->field_37 = r16
    //     0x4f6a58: stur            w16, [x0, #0x37]
    // 0x4f6a5c: r16 = Instance_GeneratorInfo
    //     0x4f6a5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15bf8] Obj!GeneratorInfo<Chapter12Stat>@82cf11
    //     0x4f6a60: ldr             x16, [x16, #0xbf8]
    // 0x4f6a64: StoreField: r0->field_3b = r16
    //     0x4f6a64: stur            w16, [x0, #0x3b]
    // 0x4f6a68: r16 = 14
    //     0x4f6a68: movz            x16, #0xe
    // 0x4f6a6c: StoreField: r0->field_3f = r16
    //     0x4f6a6c: stur            w16, [x0, #0x3f]
    // 0x4f6a70: r16 = Instance_GeneratorInfo
    //     0x4f6a70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c00] Obj!GeneratorInfo<Chapter12Stat>@82ced1
    //     0x4f6a74: ldr             x16, [x16, #0xc00]
    // 0x4f6a78: StoreField: r0->field_43 = r16
    //     0x4f6a78: stur            w16, [x0, #0x43]
    // 0x4f6a7c: r16 = 16
    //     0x4f6a7c: movz            x16, #0x10
    // 0x4f6a80: StoreField: r0->field_47 = r16
    //     0x4f6a80: stur            w16, [x0, #0x47]
    // 0x4f6a84: r16 = Instance_GeneratorInfo
    //     0x4f6a84: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c08] Obj!GeneratorInfo<Chapter12Stat>@82ce91
    //     0x4f6a88: ldr             x16, [x16, #0xc08]
    // 0x4f6a8c: StoreField: r0->field_4b = r16
    //     0x4f6a8c: stur            w16, [x0, #0x4b]
    // 0x4f6a90: r16 = 18
    //     0x4f6a90: movz            x16, #0x12
    // 0x4f6a94: StoreField: r0->field_4f = r16
    //     0x4f6a94: stur            w16, [x0, #0x4f]
    // 0x4f6a98: r16 = Instance_GeneratorInfo
    //     0x4f6a98: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c10] Obj!GeneratorInfo<Chapter12Stat>@82ce51
    //     0x4f6a9c: ldr             x16, [x16, #0xc10]
    // 0x4f6aa0: StoreField: r0->field_53 = r16
    //     0x4f6aa0: stur            w16, [x0, #0x53]
    // 0x4f6aa4: r16 = 20
    //     0x4f6aa4: movz            x16, #0x14
    // 0x4f6aa8: StoreField: r0->field_57 = r16
    //     0x4f6aa8: stur            w16, [x0, #0x57]
    // 0x4f6aac: r16 = Instance_GeneratorInfo
    //     0x4f6aac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c18] Obj!GeneratorInfo<Chapter12Stat>@82ce11
    //     0x4f6ab0: ldr             x16, [x16, #0xc18]
    // 0x4f6ab4: StoreField: r0->field_5b = r16
    //     0x4f6ab4: stur            w16, [x0, #0x5b]
    // 0x4f6ab8: r16 = <int, GeneratorInfo<Chapter12Stat>>
    //     0x4f6ab8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c20] TypeArguments: <int, GeneratorInfo<Chapter12Stat>>
    //     0x4f6abc: ldr             x16, [x16, #0xc20]
    // 0x4f6ac0: stp             x0, x16, [SP]
    // 0x4f6ac4: r0 = Map._fromLiteral()
    //     0x4f6ac4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4f6ac8: ldur            x3, [fp, #-8]
    // 0x4f6acc: StoreField: r3->field_8f = r0
    //     0x4f6acc: stur            w0, [x3, #0x8f]
    //     0x4f6ad0: ldurb           w16, [x3, #-1]
    //     0x4f6ad4: ldurb           w17, [x0, #-1]
    //     0x4f6ad8: and             x16, x17, x16, lsr #2
    //     0x4f6adc: tst             x16, HEAP, lsr #32
    //     0x4f6ae0: b.eq            #0x4f6ae8
    //     0x4f6ae4: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4f6ae8: r1 = Null
    //     0x4f6ae8: mov             x1, NULL
    // 0x4f6aec: r2 = 132
    //     0x4f6aec: movz            x2, #0x84
    // 0x4f6af0: r0 = AllocateArray()
    //     0x4f6af0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f6af4: stur            x0, [fp, #-0x18]
    // 0x4f6af8: r16 = 2
    //     0x4f6af8: movz            x16, #0x2
    // 0x4f6afc: StoreField: r0->field_f = r16
    //     0x4f6afc: stur            w16, [x0, #0xf]
    // 0x4f6b00: r1 = "Rolling Investigation"
    //     0x4f6b00: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c28] "Rolling Investigation"
    //     0x4f6b04: ldr             x1, [x1, #0xc28]
    // 0x4f6b08: r0 = autoString()
    //     0x4f6b08: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f6b0c: ldur            x2, [fp, #-0x10]
    // 0x4f6b10: r1 = Function '<anonymous closure>':.
    //     0x4f6b10: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c30] AnonymousClosure: (0x4fa2f4), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f6b14: ldr             x1, [x1, #0xc30]
    // 0x4f6b18: stur            x0, [fp, #-0x20]
    // 0x4f6b1c: r0 = AllocateClosure()
    //     0x4f6b1c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f6b20: r1 = <String>
    //     0x4f6b20: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f6b24: stur            x0, [fp, #-0x28]
    // 0x4f6b28: r0 = Generator()
    //     0x4f6b28: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f6b2c: ldur            x2, [fp, #-0x28]
    // 0x4f6b30: r3 = Null
    //     0x4f6b30: mov             x3, NULL
    // 0x4f6b34: stur            x0, [fp, #-0x28]
    // 0x4f6b38: r0 = AllocateRecord2()
    //     0x4f6b38: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f6b3c: mov             x1, x0
    // 0x4f6b40: ldur            x0, [fp, #-0x28]
    // 0x4f6b44: StoreField: r0->field_f = r1
    //     0x4f6b44: stur            w1, [x0, #0xf]
    // 0x4f6b48: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6b48: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6b4c: ldr             x1, [x1, #0xc38]
    // 0x4f6b50: r2 = 50
    //     0x4f6b50: movz            x2, #0x32
    // 0x4f6b54: r0 = AllocateArray()
    //     0x4f6b54: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f6b58: stur            x0, [fp, #-0x30]
    // 0x4f6b5c: r16 = Instance_Tuple2
    //     0x4f6b5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c40] Obj!Tuple2<Chapter12Stat, CustomNum>@823611
    //     0x4f6b60: ldr             x16, [x16, #0xc40]
    // 0x4f6b64: StoreField: r0->field_f = r16
    //     0x4f6b64: stur            w16, [x0, #0xf]
    // 0x4f6b68: r16 = Instance_Tuple2
    //     0x4f6b68: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c48] Obj!Tuple2<Chapter12Stat, CustomNum>@8235f1
    //     0x4f6b6c: ldr             x16, [x16, #0xc48]
    // 0x4f6b70: StoreField: r0->field_13 = r16
    //     0x4f6b70: stur            w16, [x0, #0x13]
    // 0x4f6b74: r16 = Instance_Tuple2
    //     0x4f6b74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c50] Obj!Tuple2<Chapter12Stat, CustomNum>@8235d1
    //     0x4f6b78: ldr             x16, [x16, #0xc50]
    // 0x4f6b7c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f6b7c: stur            w16, [x0, #0x17]
    // 0x4f6b80: r16 = Instance_Tuple2
    //     0x4f6b80: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c58] Obj!Tuple2<Chapter12Stat, CustomNum>@8235b1
    //     0x4f6b84: ldr             x16, [x16, #0xc58]
    // 0x4f6b88: StoreField: r0->field_1b = r16
    //     0x4f6b88: stur            w16, [x0, #0x1b]
    // 0x4f6b8c: r16 = Instance_Tuple2
    //     0x4f6b8c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Tuple2<Chapter12Stat, CustomNum>@823591
    //     0x4f6b90: ldr             x16, [x16, #0xc60]
    // 0x4f6b94: StoreField: r0->field_1f = r16
    //     0x4f6b94: stur            w16, [x0, #0x1f]
    // 0x4f6b98: r16 = Instance_Tuple2
    //     0x4f6b98: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c68] Obj!Tuple2<Chapter12Stat, CustomNum>@823571
    //     0x4f6b9c: ldr             x16, [x16, #0xc68]
    // 0x4f6ba0: StoreField: r0->field_23 = r16
    //     0x4f6ba0: stur            w16, [x0, #0x23]
    // 0x4f6ba4: r16 = Instance_Tuple2
    //     0x4f6ba4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c70] Obj!Tuple2<Chapter12Stat, CustomNum>@823551
    //     0x4f6ba8: ldr             x16, [x16, #0xc70]
    // 0x4f6bac: StoreField: r0->field_27 = r16
    //     0x4f6bac: stur            w16, [x0, #0x27]
    // 0x4f6bb0: r16 = Instance_Tuple2
    //     0x4f6bb0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c78] Obj!Tuple2<Chapter12Stat, CustomNum>@823531
    //     0x4f6bb4: ldr             x16, [x16, #0xc78]
    // 0x4f6bb8: StoreField: r0->field_2b = r16
    //     0x4f6bb8: stur            w16, [x0, #0x2b]
    // 0x4f6bbc: r16 = Instance_Tuple2
    //     0x4f6bbc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c80] Obj!Tuple2<Chapter12Stat, CustomNum>@823511
    //     0x4f6bc0: ldr             x16, [x16, #0xc80]
    // 0x4f6bc4: StoreField: r0->field_2f = r16
    //     0x4f6bc4: stur            w16, [x0, #0x2f]
    // 0x4f6bc8: r16 = Instance_Tuple2
    //     0x4f6bc8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c88] Obj!Tuple2<Chapter12Stat, CustomNum>@8234f1
    //     0x4f6bcc: ldr             x16, [x16, #0xc88]
    // 0x4f6bd0: StoreField: r0->field_33 = r16
    //     0x4f6bd0: stur            w16, [x0, #0x33]
    // 0x4f6bd4: r16 = Instance_Tuple2
    //     0x4f6bd4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c90] Obj!Tuple2<Chapter12Stat, CustomNum>@8234d1
    //     0x4f6bd8: ldr             x16, [x16, #0xc90]
    // 0x4f6bdc: StoreField: r0->field_37 = r16
    //     0x4f6bdc: stur            w16, [x0, #0x37]
    // 0x4f6be0: r16 = Instance_Tuple2
    //     0x4f6be0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c98] Obj!Tuple2<Chapter12Stat, CustomNum>@8234b1
    //     0x4f6be4: ldr             x16, [x16, #0xc98]
    // 0x4f6be8: StoreField: r0->field_3b = r16
    //     0x4f6be8: stur            w16, [x0, #0x3b]
    // 0x4f6bec: r16 = Instance_Tuple2
    //     0x4f6bec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ca0] Obj!Tuple2<Chapter12Stat, CustomNum>@823491
    //     0x4f6bf0: ldr             x16, [x16, #0xca0]
    // 0x4f6bf4: StoreField: r0->field_3f = r16
    //     0x4f6bf4: stur            w16, [x0, #0x3f]
    // 0x4f6bf8: r16 = Instance_Tuple2
    //     0x4f6bf8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ca8] Obj!Tuple2<Chapter12Stat, CustomNum>@823471
    //     0x4f6bfc: ldr             x16, [x16, #0xca8]
    // 0x4f6c00: StoreField: r0->field_43 = r16
    //     0x4f6c00: stur            w16, [x0, #0x43]
    // 0x4f6c04: r16 = Instance_Tuple2
    //     0x4f6c04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cb0] Obj!Tuple2<Chapter12Stat, CustomNum>@823451
    //     0x4f6c08: ldr             x16, [x16, #0xcb0]
    // 0x4f6c0c: StoreField: r0->field_47 = r16
    //     0x4f6c0c: stur            w16, [x0, #0x47]
    // 0x4f6c10: r16 = Instance_Tuple2
    //     0x4f6c10: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cb8] Obj!Tuple2<Chapter12Stat, CustomNum>@823431
    //     0x4f6c14: ldr             x16, [x16, #0xcb8]
    // 0x4f6c18: StoreField: r0->field_4b = r16
    //     0x4f6c18: stur            w16, [x0, #0x4b]
    // 0x4f6c1c: r16 = Instance_Tuple2
    //     0x4f6c1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cc0] Obj!Tuple2<Chapter12Stat, CustomNum>@823411
    //     0x4f6c20: ldr             x16, [x16, #0xcc0]
    // 0x4f6c24: StoreField: r0->field_4f = r16
    //     0x4f6c24: stur            w16, [x0, #0x4f]
    // 0x4f6c28: r16 = Instance_Tuple2
    //     0x4f6c28: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ca0] Obj!Tuple2<Chapter12Stat, CustomNum>@823491
    //     0x4f6c2c: ldr             x16, [x16, #0xca0]
    // 0x4f6c30: StoreField: r0->field_53 = r16
    //     0x4f6c30: stur            w16, [x0, #0x53]
    // 0x4f6c34: r16 = Instance_Tuple2
    //     0x4f6c34: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cc8] Obj!Tuple2<Chapter12Stat, CustomNum>@8233f1
    //     0x4f6c38: ldr             x16, [x16, #0xcc8]
    // 0x4f6c3c: StoreField: r0->field_57 = r16
    //     0x4f6c3c: stur            w16, [x0, #0x57]
    // 0x4f6c40: r16 = Instance_Tuple2
    //     0x4f6c40: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cd0] Obj!Tuple2<Chapter12Stat, CustomNum>@8233d1
    //     0x4f6c44: ldr             x16, [x16, #0xcd0]
    // 0x4f6c48: StoreField: r0->field_5b = r16
    //     0x4f6c48: stur            w16, [x0, #0x5b]
    // 0x4f6c4c: r16 = Instance_Tuple2
    //     0x4f6c4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cd8] Obj!Tuple2<Chapter12Stat, CustomNum>@8233b1
    //     0x4f6c50: ldr             x16, [x16, #0xcd8]
    // 0x4f6c54: StoreField: r0->field_5f = r16
    //     0x4f6c54: stur            w16, [x0, #0x5f]
    // 0x4f6c58: r16 = Instance_Tuple2
    //     0x4f6c58: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ce0] Obj!Tuple2<Chapter12Stat, CustomNum>@823391
    //     0x4f6c5c: ldr             x16, [x16, #0xce0]
    // 0x4f6c60: StoreField: r0->field_63 = r16
    //     0x4f6c60: stur            w16, [x0, #0x63]
    // 0x4f6c64: r16 = Instance_Tuple2
    //     0x4f6c64: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ce8] Obj!Tuple2<Chapter12Stat, CustomNum>@823371
    //     0x4f6c68: ldr             x16, [x16, #0xce8]
    // 0x4f6c6c: StoreField: r0->field_67 = r16
    //     0x4f6c6c: stur            w16, [x0, #0x67]
    // 0x4f6c70: r16 = Instance_Tuple2
    //     0x4f6c70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cf0] Obj!Tuple2<Chapter12Stat, CustomNum>@823351
    //     0x4f6c74: ldr             x16, [x16, #0xcf0]
    // 0x4f6c78: StoreField: r0->field_6b = r16
    //     0x4f6c78: stur            w16, [x0, #0x6b]
    // 0x4f6c7c: r16 = Instance_Tuple2
    //     0x4f6c7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15cf8] Obj!Tuple2<Chapter12Stat, CustomNum>@823331
    //     0x4f6c80: ldr             x16, [x16, #0xcf8]
    // 0x4f6c84: StoreField: r0->field_6f = r16
    //     0x4f6c84: stur            w16, [x0, #0x6f]
    // 0x4f6c88: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6c88: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6c8c: ldr             x1, [x1, #0xc38]
    // 0x4f6c90: r0 = AllocateGrowableArray()
    //     0x4f6c90: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f6c94: mov             x2, x0
    // 0x4f6c98: ldur            x0, [fp, #-0x30]
    // 0x4f6c9c: stur            x2, [fp, #-0x38]
    // 0x4f6ca0: StoreField: r2->field_f = r0
    //     0x4f6ca0: stur            w0, [x2, #0xf]
    // 0x4f6ca4: r0 = 50
    //     0x4f6ca4: movz            x0, #0x32
    // 0x4f6ca8: StoreField: r2->field_b = r0
    //     0x4f6ca8: stur            w0, [x2, #0xb]
    // 0x4f6cac: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6cac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6cb0: ldr             x1, [x1, #0xc38]
    // 0x4f6cb4: r0 = Generator()
    //     0x4f6cb4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f6cb8: mov             x2, x0
    // 0x4f6cbc: ldur            x0, [fp, #-0x38]
    // 0x4f6cc0: stur            x2, [fp, #-0x30]
    // 0x4f6cc4: StoreField: r2->field_b = r0
    //     0x4f6cc4: stur            w0, [x2, #0xb]
    // 0x4f6cc8: r1 = <Chapter12Stat>
    //     0x4f6cc8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f6ccc: ldr             x1, [x1, #0xef0]
    // 0x4f6cd0: r0 = UpgradeData()
    //     0x4f6cd0: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f6cd4: mov             x1, x0
    // 0x4f6cd8: ldur            x0, [fp, #-0x20]
    // 0x4f6cdc: StoreField: r1->field_b = r0
    //     0x4f6cdc: stur            w0, [x1, #0xb]
    // 0x4f6ce0: ldur            x0, [fp, #-0x28]
    // 0x4f6ce4: ArrayStore: r1[0] = r0  ; List_4
    //     0x4f6ce4: stur            w0, [x1, #0x17]
    // 0x4f6ce8: r0 = Instance_IconData
    //     0x4f6ce8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d00] Obj!IconData@830131
    //     0x4f6cec: ldr             x0, [x0, #0xd00]
    // 0x4f6cf0: StoreField: r1->field_13 = r0
    //     0x4f6cf0: stur            w0, [x1, #0x13]
    // 0x4f6cf4: ldur            x0, [fp, #-0x30]
    // 0x4f6cf8: StoreField: r1->field_f = r0
    //     0x4f6cf8: stur            w0, [x1, #0xf]
    // 0x4f6cfc: mov             x0, x1
    // 0x4f6d00: ldur            x1, [fp, #-0x18]
    // 0x4f6d04: ArrayStore: r1[1] = r0  ; List_4
    //     0x4f6d04: add             x25, x1, #0x13
    //     0x4f6d08: str             w0, [x25]
    //     0x4f6d0c: tbz             w0, #0, #0x4f6d28
    //     0x4f6d10: ldurb           w16, [x1, #-1]
    //     0x4f6d14: ldurb           w17, [x0, #-1]
    //     0x4f6d18: and             x16, x17, x16, lsr #2
    //     0x4f6d1c: tst             x16, HEAP, lsr #32
    //     0x4f6d20: b.eq            #0x4f6d28
    //     0x4f6d24: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f6d28: ldur            x0, [fp, #-0x18]
    // 0x4f6d2c: r16 = 4
    //     0x4f6d2c: movz            x16, #0x4
    // 0x4f6d30: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f6d30: stur            w16, [x0, #0x17]
    // 0x4f6d34: r1 = "Deep Research"
    //     0x4f6d34: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d08] "Deep Research"
    //     0x4f6d38: ldr             x1, [x1, #0xd08]
    // 0x4f6d3c: r0 = autoString()
    //     0x4f6d3c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f6d40: ldur            x2, [fp, #-0x10]
    // 0x4f6d44: r1 = Function '<anonymous closure>':.
    //     0x4f6d44: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d10] AnonymousClosure: (0x4f9f94), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f6d48: ldr             x1, [x1, #0xd10]
    // 0x4f6d4c: stur            x0, [fp, #-0x20]
    // 0x4f6d50: r0 = AllocateClosure()
    //     0x4f6d50: bl              #0x826750  ; AllocateClosureStub
    // 0x4f6d54: r1 = <String>
    //     0x4f6d54: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f6d58: stur            x0, [fp, #-0x28]
    // 0x4f6d5c: r0 = Generator()
    //     0x4f6d5c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f6d60: ldur            x2, [fp, #-0x28]
    // 0x4f6d64: r3 = Null
    //     0x4f6d64: mov             x3, NULL
    // 0x4f6d68: stur            x0, [fp, #-0x28]
    // 0x4f6d6c: r0 = AllocateRecord2()
    //     0x4f6d6c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f6d70: mov             x1, x0
    // 0x4f6d74: ldur            x0, [fp, #-0x28]
    // 0x4f6d78: StoreField: r0->field_f = r1
    //     0x4f6d78: stur            w1, [x0, #0xf]
    // 0x4f6d7c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6d7c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6d80: ldr             x1, [x1, #0xc38]
    // 0x4f6d84: r2 = 18
    //     0x4f6d84: movz            x2, #0x12
    // 0x4f6d88: r0 = AllocateArray()
    //     0x4f6d88: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f6d8c: stur            x0, [fp, #-0x30]
    // 0x4f6d90: r16 = Instance_Tuple2
    //     0x4f6d90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d18] Obj!Tuple2<Chapter12Stat, CustomNum>@823311
    //     0x4f6d94: ldr             x16, [x16, #0xd18]
    // 0x4f6d98: StoreField: r0->field_f = r16
    //     0x4f6d98: stur            w16, [x0, #0xf]
    // 0x4f6d9c: r16 = Instance_Tuple2
    //     0x4f6d9c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d20] Obj!Tuple2<Chapter12Stat, CustomNum>@8232f1
    //     0x4f6da0: ldr             x16, [x16, #0xd20]
    // 0x4f6da4: StoreField: r0->field_13 = r16
    //     0x4f6da4: stur            w16, [x0, #0x13]
    // 0x4f6da8: r16 = Instance_Tuple2
    //     0x4f6da8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d28] Obj!Tuple2<Chapter12Stat, CustomNum>@8232d1
    //     0x4f6dac: ldr             x16, [x16, #0xd28]
    // 0x4f6db0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f6db0: stur            w16, [x0, #0x17]
    // 0x4f6db4: r16 = Instance_Tuple2
    //     0x4f6db4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d30] Obj!Tuple2<Chapter12Stat, CustomNum>@8232b1
    //     0x4f6db8: ldr             x16, [x16, #0xd30]
    // 0x4f6dbc: StoreField: r0->field_1b = r16
    //     0x4f6dbc: stur            w16, [x0, #0x1b]
    // 0x4f6dc0: r16 = Instance_Tuple2
    //     0x4f6dc0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d38] Obj!Tuple2<Chapter12Stat, CustomNum>@823291
    //     0x4f6dc4: ldr             x16, [x16, #0xd38]
    // 0x4f6dc8: StoreField: r0->field_1f = r16
    //     0x4f6dc8: stur            w16, [x0, #0x1f]
    // 0x4f6dcc: r16 = Instance_Tuple2
    //     0x4f6dcc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d40] Obj!Tuple2<Chapter12Stat, CustomNum>@823271
    //     0x4f6dd0: ldr             x16, [x16, #0xd40]
    // 0x4f6dd4: StoreField: r0->field_23 = r16
    //     0x4f6dd4: stur            w16, [x0, #0x23]
    // 0x4f6dd8: r16 = Instance_Tuple2
    //     0x4f6dd8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d48] Obj!Tuple2<Chapter12Stat, CustomNum>@823251
    //     0x4f6ddc: ldr             x16, [x16, #0xd48]
    // 0x4f6de0: StoreField: r0->field_27 = r16
    //     0x4f6de0: stur            w16, [x0, #0x27]
    // 0x4f6de4: r16 = Instance_Tuple2
    //     0x4f6de4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d50] Obj!Tuple2<Chapter12Stat, CustomNum>@823231
    //     0x4f6de8: ldr             x16, [x16, #0xd50]
    // 0x4f6dec: StoreField: r0->field_2b = r16
    //     0x4f6dec: stur            w16, [x0, #0x2b]
    // 0x4f6df0: r16 = Instance_Tuple2
    //     0x4f6df0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d58] Obj!Tuple2<Chapter12Stat, CustomNum>@823211
    //     0x4f6df4: ldr             x16, [x16, #0xd58]
    // 0x4f6df8: StoreField: r0->field_2f = r16
    //     0x4f6df8: stur            w16, [x0, #0x2f]
    // 0x4f6dfc: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6dfc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6e00: ldr             x1, [x1, #0xc38]
    // 0x4f6e04: r0 = AllocateGrowableArray()
    //     0x4f6e04: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f6e08: mov             x2, x0
    // 0x4f6e0c: ldur            x0, [fp, #-0x30]
    // 0x4f6e10: stur            x2, [fp, #-0x38]
    // 0x4f6e14: StoreField: r2->field_f = r0
    //     0x4f6e14: stur            w0, [x2, #0xf]
    // 0x4f6e18: r0 = 18
    //     0x4f6e18: movz            x0, #0x12
    // 0x4f6e1c: StoreField: r2->field_b = r0
    //     0x4f6e1c: stur            w0, [x2, #0xb]
    // 0x4f6e20: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6e20: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6e24: ldr             x1, [x1, #0xc38]
    // 0x4f6e28: r0 = Generator()
    //     0x4f6e28: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f6e2c: mov             x2, x0
    // 0x4f6e30: ldur            x0, [fp, #-0x38]
    // 0x4f6e34: stur            x2, [fp, #-0x30]
    // 0x4f6e38: StoreField: r2->field_b = r0
    //     0x4f6e38: stur            w0, [x2, #0xb]
    // 0x4f6e3c: r1 = <Chapter12Stat>
    //     0x4f6e3c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f6e40: ldr             x1, [x1, #0xef0]
    // 0x4f6e44: r0 = UpgradeData()
    //     0x4f6e44: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f6e48: mov             x3, x0
    // 0x4f6e4c: ldur            x0, [fp, #-0x20]
    // 0x4f6e50: stur            x3, [fp, #-0x38]
    // 0x4f6e54: StoreField: r3->field_b = r0
    //     0x4f6e54: stur            w0, [x3, #0xb]
    // 0x4f6e58: ldur            x0, [fp, #-0x28]
    // 0x4f6e5c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f6e5c: stur            w0, [x3, #0x17]
    // 0x4f6e60: r0 = Instance_IconData
    //     0x4f6e60: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d60] Obj!IconData@830111
    //     0x4f6e64: ldr             x0, [x0, #0xd60]
    // 0x4f6e68: StoreField: r3->field_13 = r0
    //     0x4f6e68: stur            w0, [x3, #0x13]
    // 0x4f6e6c: ldur            x0, [fp, #-0x30]
    // 0x4f6e70: StoreField: r3->field_f = r0
    //     0x4f6e70: stur            w0, [x3, #0xf]
    // 0x4f6e74: ldur            x2, [fp, #-0x10]
    // 0x4f6e78: r1 = Function '<anonymous closure>':.
    //     0x4f6e78: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d68] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f6e7c: ldr             x1, [x1, #0xd68]
    // 0x4f6e80: r0 = AllocateClosure()
    //     0x4f6e80: bl              #0x826750  ; AllocateClosureStub
    // 0x4f6e84: mov             x1, x0
    // 0x4f6e88: ldur            x0, [fp, #-0x38]
    // 0x4f6e8c: StoreField: r0->field_1b = r1
    //     0x4f6e8c: stur            w1, [x0, #0x1b]
    // 0x4f6e90: ldur            x1, [fp, #-0x18]
    // 0x4f6e94: ArrayStore: r1[3] = r0  ; List_4
    //     0x4f6e94: add             x25, x1, #0x1b
    //     0x4f6e98: str             w0, [x25]
    //     0x4f6e9c: tbz             w0, #0, #0x4f6eb8
    //     0x4f6ea0: ldurb           w16, [x1, #-1]
    //     0x4f6ea4: ldurb           w17, [x0, #-1]
    //     0x4f6ea8: and             x16, x17, x16, lsr #2
    //     0x4f6eac: tst             x16, HEAP, lsr #32
    //     0x4f6eb0: b.eq            #0x4f6eb8
    //     0x4f6eb4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f6eb8: ldur            x0, [fp, #-0x18]
    // 0x4f6ebc: r16 = 202
    //     0x4f6ebc: movz            x16, #0xca
    // 0x4f6ec0: StoreField: r0->field_1f = r16
    //     0x4f6ec0: stur            w16, [x0, #0x1f]
    // 0x4f6ec4: r1 = "Faster Investigation"
    //     0x4f6ec4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d70] "Faster Investigation"
    //     0x4f6ec8: ldr             x1, [x1, #0xd70]
    // 0x4f6ecc: r0 = autoString()
    //     0x4f6ecc: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f6ed0: r1 = Function '<anonymous closure>':.
    //     0x4f6ed0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d78] AnonymousClosure: (0x4f9f88), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f6ed4: ldr             x1, [x1, #0xd78]
    // 0x4f6ed8: r2 = Null
    //     0x4f6ed8: mov             x2, NULL
    // 0x4f6edc: stur            x0, [fp, #-0x20]
    // 0x4f6ee0: r0 = AllocateClosure()
    //     0x4f6ee0: bl              #0x826750  ; AllocateClosureStub
    // 0x4f6ee4: r1 = <String>
    //     0x4f6ee4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f6ee8: stur            x0, [fp, #-0x28]
    // 0x4f6eec: r0 = Generator()
    //     0x4f6eec: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f6ef0: ldur            x2, [fp, #-0x28]
    // 0x4f6ef4: r3 = Null
    //     0x4f6ef4: mov             x3, NULL
    // 0x4f6ef8: stur            x0, [fp, #-0x28]
    // 0x4f6efc: r0 = AllocateRecord2()
    //     0x4f6efc: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f6f00: mov             x1, x0
    // 0x4f6f04: ldur            x0, [fp, #-0x28]
    // 0x4f6f08: StoreField: r0->field_f = r1
    //     0x4f6f08: stur            w1, [x0, #0xf]
    // 0x4f6f0c: r1 = Null
    //     0x4f6f0c: mov             x1, NULL
    // 0x4f6f10: r2 = 2
    //     0x4f6f10: movz            x2, #0x2
    // 0x4f6f14: r0 = AllocateArray()
    //     0x4f6f14: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f6f18: stur            x0, [fp, #-0x30]
    // 0x4f6f1c: r16 = Instance_Tuple2
    //     0x4f6f1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d80] Obj!Tuple2<Chapter12Stat, CustomNum>@8231f1
    //     0x4f6f20: ldr             x16, [x16, #0xd80]
    // 0x4f6f24: StoreField: r0->field_f = r16
    //     0x4f6f24: stur            w16, [x0, #0xf]
    // 0x4f6f28: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6f28: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6f2c: ldr             x1, [x1, #0xc38]
    // 0x4f6f30: r0 = AllocateGrowableArray()
    //     0x4f6f30: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f6f34: mov             x2, x0
    // 0x4f6f38: ldur            x0, [fp, #-0x30]
    // 0x4f6f3c: stur            x2, [fp, #-0x38]
    // 0x4f6f40: StoreField: r2->field_f = r0
    //     0x4f6f40: stur            w0, [x2, #0xf]
    // 0x4f6f44: r0 = 2
    //     0x4f6f44: movz            x0, #0x2
    // 0x4f6f48: StoreField: r2->field_b = r0
    //     0x4f6f48: stur            w0, [x2, #0xb]
    // 0x4f6f4c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6f4c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f6f50: ldr             x1, [x1, #0xc38]
    // 0x4f6f54: r0 = Generator()
    //     0x4f6f54: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f6f58: mov             x2, x0
    // 0x4f6f5c: ldur            x0, [fp, #-0x38]
    // 0x4f6f60: stur            x2, [fp, #-0x30]
    // 0x4f6f64: StoreField: r2->field_b = r0
    //     0x4f6f64: stur            w0, [x2, #0xb]
    // 0x4f6f68: r1 = <Chapter12Stat>
    //     0x4f6f68: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f6f6c: ldr             x1, [x1, #0xef0]
    // 0x4f6f70: r0 = UpgradeData()
    //     0x4f6f70: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f6f74: mov             x3, x0
    // 0x4f6f78: ldur            x0, [fp, #-0x20]
    // 0x4f6f7c: stur            x3, [fp, #-0x38]
    // 0x4f6f80: StoreField: r3->field_b = r0
    //     0x4f6f80: stur            w0, [x3, #0xb]
    // 0x4f6f84: ldur            x0, [fp, #-0x28]
    // 0x4f6f88: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f6f88: stur            w0, [x3, #0x17]
    // 0x4f6f8c: r0 = Instance_IconData
    //     0x4f6f8c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!IconData@8300f1
    //     0x4f6f90: ldr             x0, [x0, #0xd88]
    // 0x4f6f94: StoreField: r3->field_13 = r0
    //     0x4f6f94: stur            w0, [x3, #0x13]
    // 0x4f6f98: ldur            x0, [fp, #-0x30]
    // 0x4f6f9c: StoreField: r3->field_f = r0
    //     0x4f6f9c: stur            w0, [x3, #0xf]
    // 0x4f6fa0: ldur            x2, [fp, #-0x10]
    // 0x4f6fa4: r1 = Function '<anonymous closure>':.
    //     0x4f6fa4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d90] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f6fa8: ldr             x1, [x1, #0xd90]
    // 0x4f6fac: r0 = AllocateClosure()
    //     0x4f6fac: bl              #0x826750  ; AllocateClosureStub
    // 0x4f6fb0: mov             x1, x0
    // 0x4f6fb4: ldur            x0, [fp, #-0x38]
    // 0x4f6fb8: StoreField: r0->field_1b = r1
    //     0x4f6fb8: stur            w1, [x0, #0x1b]
    // 0x4f6fbc: ldur            x1, [fp, #-0x18]
    // 0x4f6fc0: ArrayStore: r1[5] = r0  ; List_4
    //     0x4f6fc0: add             x25, x1, #0x23
    //     0x4f6fc4: str             w0, [x25]
    //     0x4f6fc8: tbz             w0, #0, #0x4f6fe4
    //     0x4f6fcc: ldurb           w16, [x1, #-1]
    //     0x4f6fd0: ldurb           w17, [x0, #-1]
    //     0x4f6fd4: and             x16, x17, x16, lsr #2
    //     0x4f6fd8: tst             x16, HEAP, lsr #32
    //     0x4f6fdc: b.eq            #0x4f6fe4
    //     0x4f6fe0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f6fe4: ldur            x0, [fp, #-0x18]
    // 0x4f6fe8: r16 = 204
    //     0x4f6fe8: movz            x16, #0xcc
    // 0x4f6fec: StoreField: r0->field_27 = r16
    //     0x4f6fec: stur            w16, [x0, #0x27]
    // 0x4f6ff0: r1 = "Faster Scripts"
    //     0x4f6ff0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15d98] "Faster Scripts"
    //     0x4f6ff4: ldr             x1, [x1, #0xd98]
    // 0x4f6ff8: r0 = autoString()
    //     0x4f6ff8: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f6ffc: r1 = Function '<anonymous closure>':.
    //     0x4f6ffc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15da0] AnonymousClosure: (0x4f9f7c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7000: ldr             x1, [x1, #0xda0]
    // 0x4f7004: r2 = Null
    //     0x4f7004: mov             x2, NULL
    // 0x4f7008: stur            x0, [fp, #-0x20]
    // 0x4f700c: r0 = AllocateClosure()
    //     0x4f700c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7010: r1 = <String>
    //     0x4f7010: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7014: stur            x0, [fp, #-0x28]
    // 0x4f7018: r0 = Generator()
    //     0x4f7018: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f701c: ldur            x2, [fp, #-0x28]
    // 0x4f7020: r3 = Null
    //     0x4f7020: mov             x3, NULL
    // 0x4f7024: stur            x0, [fp, #-0x28]
    // 0x4f7028: r0 = AllocateRecord2()
    //     0x4f7028: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f702c: mov             x1, x0
    // 0x4f7030: ldur            x0, [fp, #-0x28]
    // 0x4f7034: StoreField: r0->field_f = r1
    //     0x4f7034: stur            w1, [x0, #0xf]
    // 0x4f7038: r1 = Null
    //     0x4f7038: mov             x1, NULL
    // 0x4f703c: r2 = 2
    //     0x4f703c: movz            x2, #0x2
    // 0x4f7040: r0 = AllocateArray()
    //     0x4f7040: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7044: stur            x0, [fp, #-0x30]
    // 0x4f7048: r16 = Instance_Tuple2
    //     0x4f7048: add             x16, PP, #0x15, lsl #12  ; [pp+0x15da8] Obj!Tuple2<Chapter12Stat, CustomNum>@8231d1
    //     0x4f704c: ldr             x16, [x16, #0xda8]
    // 0x4f7050: StoreField: r0->field_f = r16
    //     0x4f7050: stur            w16, [x0, #0xf]
    // 0x4f7054: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7054: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7058: ldr             x1, [x1, #0xc38]
    // 0x4f705c: r0 = AllocateGrowableArray()
    //     0x4f705c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f7060: mov             x2, x0
    // 0x4f7064: ldur            x0, [fp, #-0x30]
    // 0x4f7068: stur            x2, [fp, #-0x38]
    // 0x4f706c: StoreField: r2->field_f = r0
    //     0x4f706c: stur            w0, [x2, #0xf]
    // 0x4f7070: r0 = 2
    //     0x4f7070: movz            x0, #0x2
    // 0x4f7074: StoreField: r2->field_b = r0
    //     0x4f7074: stur            w0, [x2, #0xb]
    // 0x4f7078: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7078: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f707c: ldr             x1, [x1, #0xc38]
    // 0x4f7080: r0 = Generator()
    //     0x4f7080: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7084: mov             x2, x0
    // 0x4f7088: ldur            x0, [fp, #-0x38]
    // 0x4f708c: stur            x2, [fp, #-0x30]
    // 0x4f7090: StoreField: r2->field_b = r0
    //     0x4f7090: stur            w0, [x2, #0xb]
    // 0x4f7094: r1 = <Chapter12Stat>
    //     0x4f7094: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7098: ldr             x1, [x1, #0xef0]
    // 0x4f709c: r0 = UpgradeData()
    //     0x4f709c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f70a0: mov             x3, x0
    // 0x4f70a4: ldur            x0, [fp, #-0x20]
    // 0x4f70a8: stur            x3, [fp, #-0x38]
    // 0x4f70ac: StoreField: r3->field_b = r0
    //     0x4f70ac: stur            w0, [x3, #0xb]
    // 0x4f70b0: ldur            x0, [fp, #-0x28]
    // 0x4f70b4: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f70b4: stur            w0, [x3, #0x17]
    // 0x4f70b8: r0 = Instance_IconData
    //     0x4f70b8: add             x0, PP, #0x15, lsl #12  ; [pp+0x153f0] Obj!IconData@82f3b1
    //     0x4f70bc: ldr             x0, [x0, #0x3f0]
    // 0x4f70c0: StoreField: r3->field_13 = r0
    //     0x4f70c0: stur            w0, [x3, #0x13]
    // 0x4f70c4: ldur            x0, [fp, #-0x30]
    // 0x4f70c8: StoreField: r3->field_f = r0
    //     0x4f70c8: stur            w0, [x3, #0xf]
    // 0x4f70cc: ldur            x2, [fp, #-0x10]
    // 0x4f70d0: r1 = Function '<anonymous closure>':.
    //     0x4f70d0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15db0] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f70d4: ldr             x1, [x1, #0xdb0]
    // 0x4f70d8: r0 = AllocateClosure()
    //     0x4f70d8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f70dc: mov             x1, x0
    // 0x4f70e0: ldur            x0, [fp, #-0x38]
    // 0x4f70e4: StoreField: r0->field_1b = r1
    //     0x4f70e4: stur            w1, [x0, #0x1b]
    // 0x4f70e8: ldur            x1, [fp, #-0x18]
    // 0x4f70ec: ArrayStore: r1[7] = r0  ; List_4
    //     0x4f70ec: add             x25, x1, #0x2b
    //     0x4f70f0: str             w0, [x25]
    //     0x4f70f4: tbz             w0, #0, #0x4f7110
    //     0x4f70f8: ldurb           w16, [x1, #-1]
    //     0x4f70fc: ldurb           w17, [x0, #-1]
    //     0x4f7100: and             x16, x17, x16, lsr #2
    //     0x4f7104: tst             x16, HEAP, lsr #32
    //     0x4f7108: b.eq            #0x4f7110
    //     0x4f710c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7110: ldur            x0, [fp, #-0x18]
    // 0x4f7114: r16 = 206
    //     0x4f7114: movz            x16, #0xce
    // 0x4f7118: StoreField: r0->field_2f = r16
    //     0x4f7118: stur            w16, [x0, #0x2f]
    // 0x4f711c: r1 = "Stronger Network Scanner"
    //     0x4f711c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15db8] "Stronger Network Scanner"
    //     0x4f7120: ldr             x1, [x1, #0xdb8]
    // 0x4f7124: r0 = autoString()
    //     0x4f7124: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7128: r1 = Function '<anonymous closure>':.
    //     0x4f7128: add             x1, PP, #0x15, lsl #12  ; [pp+0x15dc0] AnonymousClosure: (0x4f9f70), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f712c: ldr             x1, [x1, #0xdc0]
    // 0x4f7130: r2 = Null
    //     0x4f7130: mov             x2, NULL
    // 0x4f7134: stur            x0, [fp, #-0x20]
    // 0x4f7138: r0 = AllocateClosure()
    //     0x4f7138: bl              #0x826750  ; AllocateClosureStub
    // 0x4f713c: r1 = <String>
    //     0x4f713c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7140: stur            x0, [fp, #-0x28]
    // 0x4f7144: r0 = Generator()
    //     0x4f7144: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7148: ldur            x2, [fp, #-0x28]
    // 0x4f714c: r3 = Null
    //     0x4f714c: mov             x3, NULL
    // 0x4f7150: stur            x0, [fp, #-0x28]
    // 0x4f7154: r0 = AllocateRecord2()
    //     0x4f7154: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7158: mov             x1, x0
    // 0x4f715c: ldur            x0, [fp, #-0x28]
    // 0x4f7160: StoreField: r0->field_f = r1
    //     0x4f7160: stur            w1, [x0, #0xf]
    // 0x4f7164: r1 = Null
    //     0x4f7164: mov             x1, NULL
    // 0x4f7168: r2 = 2
    //     0x4f7168: movz            x2, #0x2
    // 0x4f716c: r0 = AllocateArray()
    //     0x4f716c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7170: stur            x0, [fp, #-0x30]
    // 0x4f7174: r16 = Instance_Tuple2
    //     0x4f7174: add             x16, PP, #0x15, lsl #12  ; [pp+0x15dc8] Obj!Tuple2<Chapter12Stat, CustomNum>@8231b1
    //     0x4f7178: ldr             x16, [x16, #0xdc8]
    // 0x4f717c: StoreField: r0->field_f = r16
    //     0x4f717c: stur            w16, [x0, #0xf]
    // 0x4f7180: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7180: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7184: ldr             x1, [x1, #0xc38]
    // 0x4f7188: r0 = AllocateGrowableArray()
    //     0x4f7188: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f718c: mov             x2, x0
    // 0x4f7190: ldur            x0, [fp, #-0x30]
    // 0x4f7194: stur            x2, [fp, #-0x38]
    // 0x4f7198: StoreField: r2->field_f = r0
    //     0x4f7198: stur            w0, [x2, #0xf]
    // 0x4f719c: r0 = 2
    //     0x4f719c: movz            x0, #0x2
    // 0x4f71a0: StoreField: r2->field_b = r0
    //     0x4f71a0: stur            w0, [x2, #0xb]
    // 0x4f71a4: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f71a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f71a8: ldr             x1, [x1, #0xc38]
    // 0x4f71ac: r0 = Generator()
    //     0x4f71ac: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f71b0: mov             x2, x0
    // 0x4f71b4: ldur            x0, [fp, #-0x38]
    // 0x4f71b8: stur            x2, [fp, #-0x30]
    // 0x4f71bc: StoreField: r2->field_b = r0
    //     0x4f71bc: stur            w0, [x2, #0xb]
    // 0x4f71c0: r1 = <Chapter12Stat>
    //     0x4f71c0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f71c4: ldr             x1, [x1, #0xef0]
    // 0x4f71c8: r0 = UpgradeData()
    //     0x4f71c8: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f71cc: mov             x3, x0
    // 0x4f71d0: ldur            x0, [fp, #-0x20]
    // 0x4f71d4: stur            x3, [fp, #-0x38]
    // 0x4f71d8: StoreField: r3->field_b = r0
    //     0x4f71d8: stur            w0, [x3, #0xb]
    // 0x4f71dc: ldur            x0, [fp, #-0x28]
    // 0x4f71e0: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f71e0: stur            w0, [x3, #0x17]
    // 0x4f71e4: r0 = Instance_IconData
    //     0x4f71e4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15dd0] Obj!IconData@8300d1
    //     0x4f71e8: ldr             x0, [x0, #0xdd0]
    // 0x4f71ec: StoreField: r3->field_13 = r0
    //     0x4f71ec: stur            w0, [x3, #0x13]
    // 0x4f71f0: ldur            x0, [fp, #-0x30]
    // 0x4f71f4: StoreField: r3->field_f = r0
    //     0x4f71f4: stur            w0, [x3, #0xf]
    // 0x4f71f8: ldur            x2, [fp, #-0x10]
    // 0x4f71fc: r1 = Function '<anonymous closure>':.
    //     0x4f71fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15dd8] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7200: ldr             x1, [x1, #0xdd8]
    // 0x4f7204: r0 = AllocateClosure()
    //     0x4f7204: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7208: mov             x1, x0
    // 0x4f720c: ldur            x0, [fp, #-0x38]
    // 0x4f7210: StoreField: r0->field_1b = r1
    //     0x4f7210: stur            w1, [x0, #0x1b]
    // 0x4f7214: ldur            x1, [fp, #-0x18]
    // 0x4f7218: ArrayStore: r1[9] = r0  ; List_4
    //     0x4f7218: add             x25, x1, #0x33
    //     0x4f721c: str             w0, [x25]
    //     0x4f7220: tbz             w0, #0, #0x4f723c
    //     0x4f7224: ldurb           w16, [x1, #-1]
    //     0x4f7228: ldurb           w17, [x0, #-1]
    //     0x4f722c: and             x16, x17, x16, lsr #2
    //     0x4f7230: tst             x16, HEAP, lsr #32
    //     0x4f7234: b.eq            #0x4f723c
    //     0x4f7238: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f723c: ldur            x0, [fp, #-0x18]
    // 0x4f7240: r16 = 402
    //     0x4f7240: movz            x16, #0x192
    // 0x4f7244: StoreField: r0->field_37 = r16
    //     0x4f7244: stur            w16, [x0, #0x37]
    // 0x4f7248: r1 = "Better Scanner"
    //     0x4f7248: add             x1, PP, #0x15, lsl #12  ; [pp+0x15de0] "Better Scanner"
    //     0x4f724c: ldr             x1, [x1, #0xde0]
    // 0x4f7250: r0 = autoString()
    //     0x4f7250: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7254: r1 = Function '<anonymous closure>':.
    //     0x4f7254: add             x1, PP, #0x15, lsl #12  ; [pp+0x15de8] AnonymousClosure: (0x4f9f64), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7258: ldr             x1, [x1, #0xde8]
    // 0x4f725c: r2 = Null
    //     0x4f725c: mov             x2, NULL
    // 0x4f7260: stur            x0, [fp, #-0x20]
    // 0x4f7264: r0 = AllocateClosure()
    //     0x4f7264: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7268: r1 = <String>
    //     0x4f7268: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f726c: stur            x0, [fp, #-0x28]
    // 0x4f7270: r0 = Generator()
    //     0x4f7270: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7274: ldur            x2, [fp, #-0x28]
    // 0x4f7278: r3 = Null
    //     0x4f7278: mov             x3, NULL
    // 0x4f727c: stur            x0, [fp, #-0x28]
    // 0x4f7280: r0 = AllocateRecord2()
    //     0x4f7280: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7284: mov             x1, x0
    // 0x4f7288: ldur            x0, [fp, #-0x28]
    // 0x4f728c: StoreField: r0->field_f = r1
    //     0x4f728c: stur            w1, [x0, #0xf]
    // 0x4f7290: r1 = Null
    //     0x4f7290: mov             x1, NULL
    // 0x4f7294: r2 = 2
    //     0x4f7294: movz            x2, #0x2
    // 0x4f7298: r0 = AllocateArray()
    //     0x4f7298: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f729c: stur            x0, [fp, #-0x30]
    // 0x4f72a0: r16 = Instance_Tuple2
    //     0x4f72a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15df0] Obj!Tuple2<Chapter12Stat, CustomNum>@823191
    //     0x4f72a4: ldr             x16, [x16, #0xdf0]
    // 0x4f72a8: StoreField: r0->field_f = r16
    //     0x4f72a8: stur            w16, [x0, #0xf]
    // 0x4f72ac: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f72ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f72b0: ldr             x1, [x1, #0xc38]
    // 0x4f72b4: r0 = AllocateGrowableArray()
    //     0x4f72b4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f72b8: mov             x2, x0
    // 0x4f72bc: ldur            x0, [fp, #-0x30]
    // 0x4f72c0: stur            x2, [fp, #-0x38]
    // 0x4f72c4: StoreField: r2->field_f = r0
    //     0x4f72c4: stur            w0, [x2, #0xf]
    // 0x4f72c8: r0 = 2
    //     0x4f72c8: movz            x0, #0x2
    // 0x4f72cc: StoreField: r2->field_b = r0
    //     0x4f72cc: stur            w0, [x2, #0xb]
    // 0x4f72d0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f72d0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f72d4: ldr             x1, [x1, #0xc38]
    // 0x4f72d8: r0 = Generator()
    //     0x4f72d8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f72dc: mov             x2, x0
    // 0x4f72e0: ldur            x0, [fp, #-0x38]
    // 0x4f72e4: stur            x2, [fp, #-0x30]
    // 0x4f72e8: StoreField: r2->field_b = r0
    //     0x4f72e8: stur            w0, [x2, #0xb]
    // 0x4f72ec: r1 = <Chapter12Stat>
    //     0x4f72ec: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f72f0: ldr             x1, [x1, #0xef0]
    // 0x4f72f4: r0 = UpgradeData()
    //     0x4f72f4: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f72f8: mov             x3, x0
    // 0x4f72fc: ldur            x0, [fp, #-0x20]
    // 0x4f7300: stur            x3, [fp, #-0x38]
    // 0x4f7304: StoreField: r3->field_b = r0
    //     0x4f7304: stur            w0, [x3, #0xb]
    // 0x4f7308: ldur            x0, [fp, #-0x28]
    // 0x4f730c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f730c: stur            w0, [x3, #0x17]
    // 0x4f7310: r0 = Instance_IconData
    //     0x4f7310: add             x0, PP, #0x15, lsl #12  ; [pp+0x15df8] Obj!IconData@8300b1
    //     0x4f7314: ldr             x0, [x0, #0xdf8]
    // 0x4f7318: StoreField: r3->field_13 = r0
    //     0x4f7318: stur            w0, [x3, #0x13]
    // 0x4f731c: ldur            x0, [fp, #-0x30]
    // 0x4f7320: StoreField: r3->field_f = r0
    //     0x4f7320: stur            w0, [x3, #0xf]
    // 0x4f7324: ldur            x2, [fp, #-0x10]
    // 0x4f7328: r1 = Function '<anonymous closure>':.
    //     0x4f7328: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e00] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f732c: ldr             x1, [x1, #0xe00]
    // 0x4f7330: r0 = AllocateClosure()
    //     0x4f7330: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7334: mov             x1, x0
    // 0x4f7338: ldur            x0, [fp, #-0x38]
    // 0x4f733c: StoreField: r0->field_1b = r1
    //     0x4f733c: stur            w1, [x0, #0x1b]
    // 0x4f7340: ldur            x1, [fp, #-0x18]
    // 0x4f7344: ArrayStore: r1[11] = r0  ; List_4
    //     0x4f7344: add             x25, x1, #0x3b
    //     0x4f7348: str             w0, [x25]
    //     0x4f734c: tbz             w0, #0, #0x4f7368
    //     0x4f7350: ldurb           w16, [x1, #-1]
    //     0x4f7354: ldurb           w17, [x0, #-1]
    //     0x4f7358: and             x16, x17, x16, lsr #2
    //     0x4f735c: tst             x16, HEAP, lsr #32
    //     0x4f7360: b.eq            #0x4f7368
    //     0x4f7364: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7368: ldur            x0, [fp, #-0x18]
    // 0x4f736c: r16 = 208
    //     0x4f736c: movz            x16, #0xd0
    // 0x4f7370: StoreField: r0->field_3f = r16
    //     0x4f7370: stur            w16, [x0, #0x3f]
    // 0x4f7374: r1 = "Documents"
    //     0x4f7374: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e08] "Documents"
    //     0x4f7378: ldr             x1, [x1, #0xe08]
    // 0x4f737c: r0 = autoString()
    //     0x4f737c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7380: r1 = Function '<anonymous closure>':.
    //     0x4f7380: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e10] AnonymousClosure: (0x4f9f58), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7384: ldr             x1, [x1, #0xe10]
    // 0x4f7388: r2 = Null
    //     0x4f7388: mov             x2, NULL
    // 0x4f738c: stur            x0, [fp, #-0x20]
    // 0x4f7390: r0 = AllocateClosure()
    //     0x4f7390: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7394: r1 = <String>
    //     0x4f7394: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7398: stur            x0, [fp, #-0x28]
    // 0x4f739c: r0 = Generator()
    //     0x4f739c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f73a0: ldur            x2, [fp, #-0x28]
    // 0x4f73a4: r3 = Null
    //     0x4f73a4: mov             x3, NULL
    // 0x4f73a8: stur            x0, [fp, #-0x28]
    // 0x4f73ac: r0 = AllocateRecord2()
    //     0x4f73ac: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f73b0: mov             x1, x0
    // 0x4f73b4: ldur            x0, [fp, #-0x28]
    // 0x4f73b8: StoreField: r0->field_f = r1
    //     0x4f73b8: stur            w1, [x0, #0xf]
    // 0x4f73bc: r1 = Null
    //     0x4f73bc: mov             x1, NULL
    // 0x4f73c0: r2 = 2
    //     0x4f73c0: movz            x2, #0x2
    // 0x4f73c4: r0 = AllocateArray()
    //     0x4f73c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f73c8: stur            x0, [fp, #-0x30]
    // 0x4f73cc: r16 = Instance_Tuple2
    //     0x4f73cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e18] Obj!Tuple2<Chapter12Stat, CustomNum>@823171
    //     0x4f73d0: ldr             x16, [x16, #0xe18]
    // 0x4f73d4: StoreField: r0->field_f = r16
    //     0x4f73d4: stur            w16, [x0, #0xf]
    // 0x4f73d8: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f73d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f73dc: ldr             x1, [x1, #0xc38]
    // 0x4f73e0: r0 = AllocateGrowableArray()
    //     0x4f73e0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f73e4: mov             x2, x0
    // 0x4f73e8: ldur            x0, [fp, #-0x30]
    // 0x4f73ec: stur            x2, [fp, #-0x38]
    // 0x4f73f0: StoreField: r2->field_f = r0
    //     0x4f73f0: stur            w0, [x2, #0xf]
    // 0x4f73f4: r0 = 2
    //     0x4f73f4: movz            x0, #0x2
    // 0x4f73f8: StoreField: r2->field_b = r0
    //     0x4f73f8: stur            w0, [x2, #0xb]
    // 0x4f73fc: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f73fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7400: ldr             x1, [x1, #0xc38]
    // 0x4f7404: r0 = Generator()
    //     0x4f7404: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7408: mov             x2, x0
    // 0x4f740c: ldur            x0, [fp, #-0x38]
    // 0x4f7410: stur            x2, [fp, #-0x30]
    // 0x4f7414: StoreField: r2->field_b = r0
    //     0x4f7414: stur            w0, [x2, #0xb]
    // 0x4f7418: r1 = <Chapter12Stat>
    //     0x4f7418: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f741c: ldr             x1, [x1, #0xef0]
    // 0x4f7420: r0 = UpgradeData()
    //     0x4f7420: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7424: mov             x3, x0
    // 0x4f7428: ldur            x0, [fp, #-0x20]
    // 0x4f742c: stur            x3, [fp, #-0x38]
    // 0x4f7430: StoreField: r3->field_b = r0
    //     0x4f7430: stur            w0, [x3, #0xb]
    // 0x4f7434: ldur            x0, [fp, #-0x28]
    // 0x4f7438: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7438: stur            w0, [x3, #0x17]
    // 0x4f743c: r0 = Instance_IconData
    //     0x4f743c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e20] Obj!IconData@830091
    //     0x4f7440: ldr             x0, [x0, #0xe20]
    // 0x4f7444: StoreField: r3->field_13 = r0
    //     0x4f7444: stur            w0, [x3, #0x13]
    // 0x4f7448: ldur            x0, [fp, #-0x30]
    // 0x4f744c: StoreField: r3->field_f = r0
    //     0x4f744c: stur            w0, [x3, #0xf]
    // 0x4f7450: ldur            x2, [fp, #-0x10]
    // 0x4f7454: r1 = Function '<anonymous closure>':.
    //     0x4f7454: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e28] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7458: ldr             x1, [x1, #0xe28]
    // 0x4f745c: r0 = AllocateClosure()
    //     0x4f745c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7460: mov             x1, x0
    // 0x4f7464: ldur            x0, [fp, #-0x38]
    // 0x4f7468: StoreField: r0->field_1b = r1
    //     0x4f7468: stur            w1, [x0, #0x1b]
    // 0x4f746c: ldur            x1, [fp, #-0x18]
    // 0x4f7470: ArrayStore: r1[13] = r0  ; List_4
    //     0x4f7470: add             x25, x1, #0x43
    //     0x4f7474: str             w0, [x25]
    //     0x4f7478: tbz             w0, #0, #0x4f7494
    //     0x4f747c: ldurb           w16, [x1, #-1]
    //     0x4f7480: ldurb           w17, [x0, #-1]
    //     0x4f7484: and             x16, x17, x16, lsr #2
    //     0x4f7488: tst             x16, HEAP, lsr #32
    //     0x4f748c: b.eq            #0x4f7494
    //     0x4f7490: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7494: ldur            x0, [fp, #-0x18]
    // 0x4f7498: r16 = 210
    //     0x4f7498: movz            x16, #0xd2
    // 0x4f749c: StoreField: r0->field_47 = r16
    //     0x4f749c: stur            w16, [x0, #0x47]
    // 0x4f74a0: r1 = "Detailed Logs"
    //     0x4f74a0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e30] "Detailed Logs"
    //     0x4f74a4: ldr             x1, [x1, #0xe30]
    // 0x4f74a8: r0 = autoString()
    //     0x4f74a8: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f74ac: r1 = Function '<anonymous closure>':.
    //     0x4f74ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] AnonymousClosure: (0x4f9f4c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f74b0: ldr             x1, [x1, #0xe38]
    // 0x4f74b4: r2 = Null
    //     0x4f74b4: mov             x2, NULL
    // 0x4f74b8: stur            x0, [fp, #-0x20]
    // 0x4f74bc: r0 = AllocateClosure()
    //     0x4f74bc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f74c0: r1 = <String>
    //     0x4f74c0: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f74c4: stur            x0, [fp, #-0x28]
    // 0x4f74c8: r0 = Generator()
    //     0x4f74c8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f74cc: ldur            x2, [fp, #-0x28]
    // 0x4f74d0: r3 = Null
    //     0x4f74d0: mov             x3, NULL
    // 0x4f74d4: stur            x0, [fp, #-0x28]
    // 0x4f74d8: r0 = AllocateRecord2()
    //     0x4f74d8: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f74dc: mov             x1, x0
    // 0x4f74e0: ldur            x0, [fp, #-0x28]
    // 0x4f74e4: StoreField: r0->field_f = r1
    //     0x4f74e4: stur            w1, [x0, #0xf]
    // 0x4f74e8: r1 = Null
    //     0x4f74e8: mov             x1, NULL
    // 0x4f74ec: r2 = 2
    //     0x4f74ec: movz            x2, #0x2
    // 0x4f74f0: r0 = AllocateArray()
    //     0x4f74f0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f74f4: stur            x0, [fp, #-0x30]
    // 0x4f74f8: r16 = Instance_Tuple2
    //     0x4f74f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e40] Obj!Tuple2<Chapter12Stat, CustomNum>@823151
    //     0x4f74fc: ldr             x16, [x16, #0xe40]
    // 0x4f7500: StoreField: r0->field_f = r16
    //     0x4f7500: stur            w16, [x0, #0xf]
    // 0x4f7504: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7504: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7508: ldr             x1, [x1, #0xc38]
    // 0x4f750c: r0 = AllocateGrowableArray()
    //     0x4f750c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f7510: mov             x2, x0
    // 0x4f7514: ldur            x0, [fp, #-0x30]
    // 0x4f7518: stur            x2, [fp, #-0x38]
    // 0x4f751c: StoreField: r2->field_f = r0
    //     0x4f751c: stur            w0, [x2, #0xf]
    // 0x4f7520: r0 = 2
    //     0x4f7520: movz            x0, #0x2
    // 0x4f7524: StoreField: r2->field_b = r0
    //     0x4f7524: stur            w0, [x2, #0xb]
    // 0x4f7528: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7528: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f752c: ldr             x1, [x1, #0xc38]
    // 0x4f7530: r0 = Generator()
    //     0x4f7530: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7534: mov             x2, x0
    // 0x4f7538: ldur            x0, [fp, #-0x38]
    // 0x4f753c: stur            x2, [fp, #-0x30]
    // 0x4f7540: StoreField: r2->field_b = r0
    //     0x4f7540: stur            w0, [x2, #0xb]
    // 0x4f7544: r1 = <Chapter12Stat>
    //     0x4f7544: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7548: ldr             x1, [x1, #0xef0]
    // 0x4f754c: r0 = UpgradeData()
    //     0x4f754c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7550: mov             x3, x0
    // 0x4f7554: ldur            x0, [fp, #-0x20]
    // 0x4f7558: stur            x3, [fp, #-0x38]
    // 0x4f755c: StoreField: r3->field_b = r0
    //     0x4f755c: stur            w0, [x3, #0xb]
    // 0x4f7560: ldur            x0, [fp, #-0x28]
    // 0x4f7564: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7564: stur            w0, [x3, #0x17]
    // 0x4f7568: r0 = Instance_IconData
    //     0x4f7568: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e48] Obj!IconData@830071
    //     0x4f756c: ldr             x0, [x0, #0xe48]
    // 0x4f7570: StoreField: r3->field_13 = r0
    //     0x4f7570: stur            w0, [x3, #0x13]
    // 0x4f7574: ldur            x0, [fp, #-0x30]
    // 0x4f7578: StoreField: r3->field_f = r0
    //     0x4f7578: stur            w0, [x3, #0xf]
    // 0x4f757c: ldur            x2, [fp, #-0x10]
    // 0x4f7580: r1 = Function '<anonymous closure>':.
    //     0x4f7580: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e50] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7584: ldr             x1, [x1, #0xe50]
    // 0x4f7588: r0 = AllocateClosure()
    //     0x4f7588: bl              #0x826750  ; AllocateClosureStub
    // 0x4f758c: mov             x1, x0
    // 0x4f7590: ldur            x0, [fp, #-0x38]
    // 0x4f7594: StoreField: r0->field_1b = r1
    //     0x4f7594: stur            w1, [x0, #0x1b]
    // 0x4f7598: ldur            x1, [fp, #-0x18]
    // 0x4f759c: ArrayStore: r1[15] = r0  ; List_4
    //     0x4f759c: add             x25, x1, #0x4b
    //     0x4f75a0: str             w0, [x25]
    //     0x4f75a4: tbz             w0, #0, #0x4f75c0
    //     0x4f75a8: ldurb           w16, [x1, #-1]
    //     0x4f75ac: ldurb           w17, [x0, #-1]
    //     0x4f75b0: and             x16, x17, x16, lsr #2
    //     0x4f75b4: tst             x16, HEAP, lsr #32
    //     0x4f75b8: b.eq            #0x4f75c0
    //     0x4f75bc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f75c0: ldur            x0, [fp, #-0x18]
    // 0x4f75c4: r16 = 212
    //     0x4f75c4: movz            x16, #0xd4
    // 0x4f75c8: StoreField: r0->field_4f = r16
    //     0x4f75c8: stur            w16, [x0, #0x4f]
    // 0x4f75cc: r1 = "Hex Dump"
    //     0x4f75cc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e58] "Hex Dump"
    //     0x4f75d0: ldr             x1, [x1, #0xe58]
    // 0x4f75d4: r0 = autoString()
    //     0x4f75d4: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f75d8: r1 = Function '<anonymous closure>':.
    //     0x4f75d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e60] AnonymousClosure: (0x4f9f40), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f75dc: ldr             x1, [x1, #0xe60]
    // 0x4f75e0: r2 = Null
    //     0x4f75e0: mov             x2, NULL
    // 0x4f75e4: stur            x0, [fp, #-0x20]
    // 0x4f75e8: r0 = AllocateClosure()
    //     0x4f75e8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f75ec: r1 = <String>
    //     0x4f75ec: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f75f0: stur            x0, [fp, #-0x28]
    // 0x4f75f4: r0 = Generator()
    //     0x4f75f4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f75f8: ldur            x2, [fp, #-0x28]
    // 0x4f75fc: r3 = Null
    //     0x4f75fc: mov             x3, NULL
    // 0x4f7600: stur            x0, [fp, #-0x28]
    // 0x4f7604: r0 = AllocateRecord2()
    //     0x4f7604: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7608: mov             x1, x0
    // 0x4f760c: ldur            x0, [fp, #-0x28]
    // 0x4f7610: StoreField: r0->field_f = r1
    //     0x4f7610: stur            w1, [x0, #0xf]
    // 0x4f7614: r1 = Null
    //     0x4f7614: mov             x1, NULL
    // 0x4f7618: r2 = 2
    //     0x4f7618: movz            x2, #0x2
    // 0x4f761c: r0 = AllocateArray()
    //     0x4f761c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7620: stur            x0, [fp, #-0x30]
    // 0x4f7624: r16 = Instance_Tuple2
    //     0x4f7624: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e68] Obj!Tuple2<Chapter12Stat, CustomNum>@823131
    //     0x4f7628: ldr             x16, [x16, #0xe68]
    // 0x4f762c: StoreField: r0->field_f = r16
    //     0x4f762c: stur            w16, [x0, #0xf]
    // 0x4f7630: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7630: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7634: ldr             x1, [x1, #0xc38]
    // 0x4f7638: r0 = AllocateGrowableArray()
    //     0x4f7638: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f763c: mov             x2, x0
    // 0x4f7640: ldur            x0, [fp, #-0x30]
    // 0x4f7644: stur            x2, [fp, #-0x38]
    // 0x4f7648: StoreField: r2->field_f = r0
    //     0x4f7648: stur            w0, [x2, #0xf]
    // 0x4f764c: r0 = 2
    //     0x4f764c: movz            x0, #0x2
    // 0x4f7650: StoreField: r2->field_b = r0
    //     0x4f7650: stur            w0, [x2, #0xb]
    // 0x4f7654: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7654: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7658: ldr             x1, [x1, #0xc38]
    // 0x4f765c: r0 = Generator()
    //     0x4f765c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7660: mov             x2, x0
    // 0x4f7664: ldur            x0, [fp, #-0x38]
    // 0x4f7668: stur            x2, [fp, #-0x30]
    // 0x4f766c: StoreField: r2->field_b = r0
    //     0x4f766c: stur            w0, [x2, #0xb]
    // 0x4f7670: r1 = <Chapter12Stat>
    //     0x4f7670: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7674: ldr             x1, [x1, #0xef0]
    // 0x4f7678: r0 = UpgradeData()
    //     0x4f7678: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f767c: mov             x3, x0
    // 0x4f7680: ldur            x0, [fp, #-0x20]
    // 0x4f7684: stur            x3, [fp, #-0x38]
    // 0x4f7688: StoreField: r3->field_b = r0
    //     0x4f7688: stur            w0, [x3, #0xb]
    // 0x4f768c: ldur            x0, [fp, #-0x28]
    // 0x4f7690: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7690: stur            w0, [x3, #0x17]
    // 0x4f7694: r0 = Instance_IconData
    //     0x4f7694: add             x0, PP, #0x14, lsl #12  ; [pp+0x14d60] Obj!IconData@82f9f1
    //     0x4f7698: ldr             x0, [x0, #0xd60]
    // 0x4f769c: StoreField: r3->field_13 = r0
    //     0x4f769c: stur            w0, [x3, #0x13]
    // 0x4f76a0: ldur            x0, [fp, #-0x30]
    // 0x4f76a4: StoreField: r3->field_f = r0
    //     0x4f76a4: stur            w0, [x3, #0xf]
    // 0x4f76a8: ldur            x2, [fp, #-0x10]
    // 0x4f76ac: r1 = Function '<anonymous closure>':.
    //     0x4f76ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e70] AnonymousClosure: (0x4f9e50), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f76b0: ldr             x1, [x1, #0xe70]
    // 0x4f76b4: r0 = AllocateClosure()
    //     0x4f76b4: bl              #0x826750  ; AllocateClosureStub
    // 0x4f76b8: mov             x1, x0
    // 0x4f76bc: ldur            x0, [fp, #-0x38]
    // 0x4f76c0: StoreField: r0->field_23 = r1
    //     0x4f76c0: stur            w1, [x0, #0x23]
    // 0x4f76c4: ldur            x1, [fp, #-0x18]
    // 0x4f76c8: ArrayStore: r1[17] = r0  ; List_4
    //     0x4f76c8: add             x25, x1, #0x53
    //     0x4f76cc: str             w0, [x25]
    //     0x4f76d0: tbz             w0, #0, #0x4f76ec
    //     0x4f76d4: ldurb           w16, [x1, #-1]
    //     0x4f76d8: ldurb           w17, [x0, #-1]
    //     0x4f76dc: and             x16, x17, x16, lsr #2
    //     0x4f76e0: tst             x16, HEAP, lsr #32
    //     0x4f76e4: b.eq            #0x4f76ec
    //     0x4f76e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f76ec: ldur            x0, [fp, #-0x18]
    // 0x4f76f0: r16 = 214
    //     0x4f76f0: movz            x16, #0xd6
    // 0x4f76f4: StoreField: r0->field_57 = r16
    //     0x4f76f4: stur            w16, [x0, #0x57]
    // 0x4f76f8: r1 = "Improved Foundation"
    //     0x4f76f8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e78] "Improved Foundation"
    //     0x4f76fc: ldr             x1, [x1, #0xe78]
    // 0x4f7700: r0 = autoString()
    //     0x4f7700: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7704: r1 = Function '<anonymous closure>':.
    //     0x4f7704: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e80] AnonymousClosure: (0x4f9e44), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7708: ldr             x1, [x1, #0xe80]
    // 0x4f770c: r2 = Null
    //     0x4f770c: mov             x2, NULL
    // 0x4f7710: stur            x0, [fp, #-0x20]
    // 0x4f7714: r0 = AllocateClosure()
    //     0x4f7714: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7718: r1 = <String>
    //     0x4f7718: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f771c: stur            x0, [fp, #-0x28]
    // 0x4f7720: r0 = Generator()
    //     0x4f7720: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7724: ldur            x2, [fp, #-0x28]
    // 0x4f7728: r3 = Null
    //     0x4f7728: mov             x3, NULL
    // 0x4f772c: stur            x0, [fp, #-0x28]
    // 0x4f7730: r0 = AllocateRecord2()
    //     0x4f7730: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7734: mov             x1, x0
    // 0x4f7738: ldur            x0, [fp, #-0x28]
    // 0x4f773c: StoreField: r0->field_f = r1
    //     0x4f773c: stur            w1, [x0, #0xf]
    // 0x4f7740: r1 = Null
    //     0x4f7740: mov             x1, NULL
    // 0x4f7744: r2 = 20
    //     0x4f7744: movz            x2, #0x14
    // 0x4f7748: r0 = CustomNum()
    //     0x4f7748: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f774c: r1 = <Chapter12Stat, CustomNum>
    //     0x4f774c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e88] TypeArguments: <Chapter12Stat, CustomNum>
    //     0x4f7750: ldr             x1, [x1, #0xe88]
    // 0x4f7754: stur            x0, [fp, #-0x30]
    // 0x4f7758: r0 = Tuple2()
    //     0x4f7758: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4f775c: mov             x3, x0
    // 0x4f7760: r0 = Instance_Chapter12Stat
    //     0x4f7760: add             x0, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x4f7764: ldr             x0, [x0, #0x498]
    // 0x4f7768: stur            x3, [fp, #-0x38]
    // 0x4f776c: StoreField: r3->field_b = r0
    //     0x4f776c: stur            w0, [x3, #0xb]
    // 0x4f7770: ldur            x1, [fp, #-0x30]
    // 0x4f7774: StoreField: r3->field_f = r1
    //     0x4f7774: stur            w1, [x3, #0xf]
    // 0x4f7778: r1 = Null
    //     0x4f7778: mov             x1, NULL
    // 0x4f777c: r2 = 2
    //     0x4f777c: movz            x2, #0x2
    // 0x4f7780: r0 = AllocateArray()
    //     0x4f7780: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7784: mov             x2, x0
    // 0x4f7788: ldur            x0, [fp, #-0x38]
    // 0x4f778c: stur            x2, [fp, #-0x30]
    // 0x4f7790: StoreField: r2->field_f = r0
    //     0x4f7790: stur            w0, [x2, #0xf]
    // 0x4f7794: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7794: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7798: ldr             x1, [x1, #0xc38]
    // 0x4f779c: r0 = AllocateGrowableArray()
    //     0x4f779c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f77a0: mov             x2, x0
    // 0x4f77a4: ldur            x0, [fp, #-0x30]
    // 0x4f77a8: stur            x2, [fp, #-0x38]
    // 0x4f77ac: StoreField: r2->field_f = r0
    //     0x4f77ac: stur            w0, [x2, #0xf]
    // 0x4f77b0: r0 = 2
    //     0x4f77b0: movz            x0, #0x2
    // 0x4f77b4: StoreField: r2->field_b = r0
    //     0x4f77b4: stur            w0, [x2, #0xb]
    // 0x4f77b8: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f77b8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f77bc: ldr             x1, [x1, #0xc38]
    // 0x4f77c0: r0 = Generator()
    //     0x4f77c0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f77c4: mov             x2, x0
    // 0x4f77c8: ldur            x0, [fp, #-0x38]
    // 0x4f77cc: stur            x2, [fp, #-0x30]
    // 0x4f77d0: StoreField: r2->field_b = r0
    //     0x4f77d0: stur            w0, [x2, #0xb]
    // 0x4f77d4: r1 = <Chapter12Stat>
    //     0x4f77d4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f77d8: ldr             x1, [x1, #0xef0]
    // 0x4f77dc: r0 = UpgradeData()
    //     0x4f77dc: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f77e0: mov             x3, x0
    // 0x4f77e4: ldur            x0, [fp, #-0x20]
    // 0x4f77e8: stur            x3, [fp, #-0x38]
    // 0x4f77ec: StoreField: r3->field_b = r0
    //     0x4f77ec: stur            w0, [x3, #0xb]
    // 0x4f77f0: ldur            x0, [fp, #-0x28]
    // 0x4f77f4: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f77f4: stur            w0, [x3, #0x17]
    // 0x4f77f8: r0 = Instance_IconData
    //     0x4f77f8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e90] Obj!IconData@830051
    //     0x4f77fc: ldr             x0, [x0, #0xe90]
    // 0x4f7800: StoreField: r3->field_13 = r0
    //     0x4f7800: stur            w0, [x3, #0x13]
    // 0x4f7804: ldur            x0, [fp, #-0x30]
    // 0x4f7808: StoreField: r3->field_f = r0
    //     0x4f7808: stur            w0, [x3, #0xf]
    // 0x4f780c: ldur            x2, [fp, #-0x10]
    // 0x4f7810: r1 = Function '<anonymous closure>':.
    //     0x4f7810: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e98] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7814: ldr             x1, [x1, #0xe98]
    // 0x4f7818: r0 = AllocateClosure()
    //     0x4f7818: bl              #0x826750  ; AllocateClosureStub
    // 0x4f781c: mov             x1, x0
    // 0x4f7820: ldur            x0, [fp, #-0x38]
    // 0x4f7824: StoreField: r0->field_1b = r1
    //     0x4f7824: stur            w1, [x0, #0x1b]
    // 0x4f7828: ldur            x1, [fp, #-0x18]
    // 0x4f782c: ArrayStore: r1[19] = r0  ; List_4
    //     0x4f782c: add             x25, x1, #0x5b
    //     0x4f7830: str             w0, [x25]
    //     0x4f7834: tbz             w0, #0, #0x4f7850
    //     0x4f7838: ldurb           w16, [x1, #-1]
    //     0x4f783c: ldurb           w17, [x0, #-1]
    //     0x4f7840: and             x16, x17, x16, lsr #2
    //     0x4f7844: tst             x16, HEAP, lsr #32
    //     0x4f7848: b.eq            #0x4f7850
    //     0x4f784c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7850: ldur            x0, [fp, #-0x18]
    // 0x4f7854: r16 = 216
    //     0x4f7854: movz            x16, #0xd8
    // 0x4f7858: StoreField: r0->field_5f = r16
    //     0x4f7858: stur            w16, [x0, #0x5f]
    // 0x4f785c: r1 = "Lookup Table"
    //     0x4f785c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ea0] "Lookup Table"
    //     0x4f7860: ldr             x1, [x1, #0xea0]
    // 0x4f7864: r0 = autoString()
    //     0x4f7864: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7868: r1 = Function '<anonymous closure>':.
    //     0x4f7868: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ea8] AnonymousClosure: (0x4f9e38), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f786c: ldr             x1, [x1, #0xea8]
    // 0x4f7870: r2 = Null
    //     0x4f7870: mov             x2, NULL
    // 0x4f7874: stur            x0, [fp, #-0x20]
    // 0x4f7878: r0 = AllocateClosure()
    //     0x4f7878: bl              #0x826750  ; AllocateClosureStub
    // 0x4f787c: r1 = <String>
    //     0x4f787c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7880: stur            x0, [fp, #-0x28]
    // 0x4f7884: r0 = Generator()
    //     0x4f7884: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7888: ldur            x2, [fp, #-0x28]
    // 0x4f788c: r3 = Null
    //     0x4f788c: mov             x3, NULL
    // 0x4f7890: stur            x0, [fp, #-0x28]
    // 0x4f7894: r0 = AllocateRecord2()
    //     0x4f7894: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7898: mov             x1, x0
    // 0x4f789c: ldur            x0, [fp, #-0x28]
    // 0x4f78a0: StoreField: r0->field_f = r1
    //     0x4f78a0: stur            w1, [x0, #0xf]
    // 0x4f78a4: r1 = Null
    //     0x4f78a4: mov             x1, NULL
    // 0x4f78a8: r2 = 2
    //     0x4f78a8: movz            x2, #0x2
    // 0x4f78ac: r0 = AllocateArray()
    //     0x4f78ac: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f78b0: stur            x0, [fp, #-0x30]
    // 0x4f78b4: r16 = Instance_Tuple2
    //     0x4f78b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15eb0] Obj!Tuple2<Chapter12Stat, CustomNum>@823111
    //     0x4f78b8: ldr             x16, [x16, #0xeb0]
    // 0x4f78bc: StoreField: r0->field_f = r16
    //     0x4f78bc: stur            w16, [x0, #0xf]
    // 0x4f78c0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f78c0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f78c4: ldr             x1, [x1, #0xc38]
    // 0x4f78c8: r0 = AllocateGrowableArray()
    //     0x4f78c8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f78cc: mov             x2, x0
    // 0x4f78d0: ldur            x0, [fp, #-0x30]
    // 0x4f78d4: stur            x2, [fp, #-0x38]
    // 0x4f78d8: StoreField: r2->field_f = r0
    //     0x4f78d8: stur            w0, [x2, #0xf]
    // 0x4f78dc: r0 = 2
    //     0x4f78dc: movz            x0, #0x2
    // 0x4f78e0: StoreField: r2->field_b = r0
    //     0x4f78e0: stur            w0, [x2, #0xb]
    // 0x4f78e4: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f78e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f78e8: ldr             x1, [x1, #0xc38]
    // 0x4f78ec: r0 = Generator()
    //     0x4f78ec: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f78f0: mov             x2, x0
    // 0x4f78f4: ldur            x0, [fp, #-0x38]
    // 0x4f78f8: stur            x2, [fp, #-0x30]
    // 0x4f78fc: StoreField: r2->field_b = r0
    //     0x4f78fc: stur            w0, [x2, #0xb]
    // 0x4f7900: r1 = <Chapter12Stat>
    //     0x4f7900: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7904: ldr             x1, [x1, #0xef0]
    // 0x4f7908: r0 = UpgradeData()
    //     0x4f7908: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f790c: mov             x3, x0
    // 0x4f7910: ldur            x0, [fp, #-0x20]
    // 0x4f7914: stur            x3, [fp, #-0x38]
    // 0x4f7918: StoreField: r3->field_b = r0
    //     0x4f7918: stur            w0, [x3, #0xb]
    // 0x4f791c: ldur            x0, [fp, #-0x28]
    // 0x4f7920: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7920: stur            w0, [x3, #0x17]
    // 0x4f7924: r0 = Instance_IconData
    //     0x4f7924: add             x0, PP, #0x15, lsl #12  ; [pp+0x15eb8] Obj!IconData@830031
    //     0x4f7928: ldr             x0, [x0, #0xeb8]
    // 0x4f792c: StoreField: r3->field_13 = r0
    //     0x4f792c: stur            w0, [x3, #0x13]
    // 0x4f7930: ldur            x0, [fp, #-0x30]
    // 0x4f7934: StoreField: r3->field_f = r0
    //     0x4f7934: stur            w0, [x3, #0xf]
    // 0x4f7938: ldur            x2, [fp, #-0x10]
    // 0x4f793c: r1 = Function '<anonymous closure>':.
    //     0x4f793c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ec0] AnonymousClosure: (0x4f9d48), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7940: ldr             x1, [x1, #0xec0]
    // 0x4f7944: r0 = AllocateClosure()
    //     0x4f7944: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7948: mov             x1, x0
    // 0x4f794c: ldur            x0, [fp, #-0x38]
    // 0x4f7950: StoreField: r0->field_23 = r1
    //     0x4f7950: stur            w1, [x0, #0x23]
    // 0x4f7954: ldur            x1, [fp, #-0x18]
    // 0x4f7958: ArrayStore: r1[21] = r0  ; List_4
    //     0x4f7958: add             x25, x1, #0x63
    //     0x4f795c: str             w0, [x25]
    //     0x4f7960: tbz             w0, #0, #0x4f797c
    //     0x4f7964: ldurb           w16, [x1, #-1]
    //     0x4f7968: ldurb           w17, [x0, #-1]
    //     0x4f796c: and             x16, x17, x16, lsr #2
    //     0x4f7970: tst             x16, HEAP, lsr #32
    //     0x4f7974: b.eq            #0x4f797c
    //     0x4f7978: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f797c: ldur            x0, [fp, #-0x18]
    // 0x4f7980: r16 = 218
    //     0x4f7980: movz            x16, #0xda
    // 0x4f7984: StoreField: r0->field_67 = r16
    //     0x4f7984: stur            w16, [x0, #0x67]
    // 0x4f7988: r1 = "Boosted Research"
    //     0x4f7988: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ec8] "Boosted Research"
    //     0x4f798c: ldr             x1, [x1, #0xec8]
    // 0x4f7990: r0 = autoString()
    //     0x4f7990: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7994: r1 = Function '<anonymous closure>':.
    //     0x4f7994: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ed0] AnonymousClosure: (0x4f9d3c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7998: ldr             x1, [x1, #0xed0]
    // 0x4f799c: r2 = Null
    //     0x4f799c: mov             x2, NULL
    // 0x4f79a0: stur            x0, [fp, #-0x20]
    // 0x4f79a4: r0 = AllocateClosure()
    //     0x4f79a4: bl              #0x826750  ; AllocateClosureStub
    // 0x4f79a8: r1 = <String>
    //     0x4f79a8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f79ac: stur            x0, [fp, #-0x28]
    // 0x4f79b0: r0 = Generator()
    //     0x4f79b0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f79b4: ldur            x2, [fp, #-0x28]
    // 0x4f79b8: r3 = Null
    //     0x4f79b8: mov             x3, NULL
    // 0x4f79bc: stur            x0, [fp, #-0x28]
    // 0x4f79c0: r0 = AllocateRecord2()
    //     0x4f79c0: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f79c4: mov             x1, x0
    // 0x4f79c8: ldur            x0, [fp, #-0x28]
    // 0x4f79cc: StoreField: r0->field_f = r1
    //     0x4f79cc: stur            w1, [x0, #0xf]
    // 0x4f79d0: r1 = Null
    //     0x4f79d0: mov             x1, NULL
    // 0x4f79d4: r2 = 2
    //     0x4f79d4: movz            x2, #0x2
    // 0x4f79d8: r0 = AllocateArray()
    //     0x4f79d8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f79dc: stur            x0, [fp, #-0x30]
    // 0x4f79e0: r16 = Instance_Tuple2
    //     0x4f79e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ed8] Obj!Tuple2<Chapter12Stat, CustomNum>@8230f1
    //     0x4f79e4: ldr             x16, [x16, #0xed8]
    // 0x4f79e8: StoreField: r0->field_f = r16
    //     0x4f79e8: stur            w16, [x0, #0xf]
    // 0x4f79ec: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f79ec: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f79f0: ldr             x1, [x1, #0xc38]
    // 0x4f79f4: r0 = AllocateGrowableArray()
    //     0x4f79f4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f79f8: mov             x2, x0
    // 0x4f79fc: ldur            x0, [fp, #-0x30]
    // 0x4f7a00: stur            x2, [fp, #-0x38]
    // 0x4f7a04: StoreField: r2->field_f = r0
    //     0x4f7a04: stur            w0, [x2, #0xf]
    // 0x4f7a08: r0 = 2
    //     0x4f7a08: movz            x0, #0x2
    // 0x4f7a0c: StoreField: r2->field_b = r0
    //     0x4f7a0c: stur            w0, [x2, #0xb]
    // 0x4f7a10: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7a10: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7a14: ldr             x1, [x1, #0xc38]
    // 0x4f7a18: r0 = Generator()
    //     0x4f7a18: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7a1c: mov             x2, x0
    // 0x4f7a20: ldur            x0, [fp, #-0x38]
    // 0x4f7a24: stur            x2, [fp, #-0x30]
    // 0x4f7a28: StoreField: r2->field_b = r0
    //     0x4f7a28: stur            w0, [x2, #0xb]
    // 0x4f7a2c: r1 = <Chapter12Stat>
    //     0x4f7a2c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7a30: ldr             x1, [x1, #0xef0]
    // 0x4f7a34: r0 = UpgradeData()
    //     0x4f7a34: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7a38: mov             x3, x0
    // 0x4f7a3c: ldur            x0, [fp, #-0x20]
    // 0x4f7a40: stur            x3, [fp, #-0x38]
    // 0x4f7a44: StoreField: r3->field_b = r0
    //     0x4f7a44: stur            w0, [x3, #0xb]
    // 0x4f7a48: ldur            x0, [fp, #-0x28]
    // 0x4f7a4c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7a4c: stur            w0, [x3, #0x17]
    // 0x4f7a50: r0 = Instance_IconData
    //     0x4f7a50: add             x0, PP, #0x15, lsl #12  ; [pp+0x153a0] Obj!IconData@830171
    //     0x4f7a54: ldr             x0, [x0, #0x3a0]
    // 0x4f7a58: StoreField: r3->field_13 = r0
    //     0x4f7a58: stur            w0, [x3, #0x13]
    // 0x4f7a5c: ldur            x0, [fp, #-0x30]
    // 0x4f7a60: StoreField: r3->field_f = r0
    //     0x4f7a60: stur            w0, [x3, #0xf]
    // 0x4f7a64: ldur            x2, [fp, #-0x10]
    // 0x4f7a68: r1 = Function '<anonymous closure>':.
    //     0x4f7a68: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee0] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7a6c: ldr             x1, [x1, #0xee0]
    // 0x4f7a70: r0 = AllocateClosure()
    //     0x4f7a70: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7a74: mov             x1, x0
    // 0x4f7a78: ldur            x0, [fp, #-0x38]
    // 0x4f7a7c: StoreField: r0->field_1b = r1
    //     0x4f7a7c: stur            w1, [x0, #0x1b]
    // 0x4f7a80: ldur            x1, [fp, #-0x18]
    // 0x4f7a84: ArrayStore: r1[23] = r0  ; List_4
    //     0x4f7a84: add             x25, x1, #0x6b
    //     0x4f7a88: str             w0, [x25]
    //     0x4f7a8c: tbz             w0, #0, #0x4f7aa8
    //     0x4f7a90: ldurb           w16, [x1, #-1]
    //     0x4f7a94: ldurb           w17, [x0, #-1]
    //     0x4f7a98: and             x16, x17, x16, lsr #2
    //     0x4f7a9c: tst             x16, HEAP, lsr #32
    //     0x4f7aa0: b.eq            #0x4f7aa8
    //     0x4f7aa4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7aa8: ldur            x0, [fp, #-0x18]
    // 0x4f7aac: r16 = 220
    //     0x4f7aac: movz            x16, #0xdc
    // 0x4f7ab0: StoreField: r0->field_6f = r16
    //     0x4f7ab0: stur            w16, [x0, #0x6f]
    // 0x4f7ab4: r1 = "Black Friday"
    //     0x4f7ab4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] "Black Friday"
    //     0x4f7ab8: ldr             x1, [x1, #0xee8]
    // 0x4f7abc: r0 = autoString()
    //     0x4f7abc: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7ac0: r1 = Function '<anonymous closure>':.
    //     0x4f7ac0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ef0] AnonymousClosure: (0x4f9d30), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7ac4: ldr             x1, [x1, #0xef0]
    // 0x4f7ac8: r2 = Null
    //     0x4f7ac8: mov             x2, NULL
    // 0x4f7acc: stur            x0, [fp, #-0x20]
    // 0x4f7ad0: r0 = AllocateClosure()
    //     0x4f7ad0: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7ad4: r1 = <String>
    //     0x4f7ad4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7ad8: stur            x0, [fp, #-0x28]
    // 0x4f7adc: r0 = Generator()
    //     0x4f7adc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7ae0: ldur            x2, [fp, #-0x28]
    // 0x4f7ae4: r3 = Null
    //     0x4f7ae4: mov             x3, NULL
    // 0x4f7ae8: stur            x0, [fp, #-0x28]
    // 0x4f7aec: r0 = AllocateRecord2()
    //     0x4f7aec: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7af0: mov             x1, x0
    // 0x4f7af4: ldur            x0, [fp, #-0x28]
    // 0x4f7af8: StoreField: r0->field_f = r1
    //     0x4f7af8: stur            w1, [x0, #0xf]
    // 0x4f7afc: r1 = Null
    //     0x4f7afc: mov             x1, NULL
    // 0x4f7b00: r2 = 400
    //     0x4f7b00: movz            x2, #0x190
    // 0x4f7b04: r0 = CustomNum()
    //     0x4f7b04: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f7b08: r1 = <Chapter12Stat, CustomNum>
    //     0x4f7b08: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e88] TypeArguments: <Chapter12Stat, CustomNum>
    //     0x4f7b0c: ldr             x1, [x1, #0xe88]
    // 0x4f7b10: stur            x0, [fp, #-0x30]
    // 0x4f7b14: r0 = Tuple2()
    //     0x4f7b14: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4f7b18: mov             x3, x0
    // 0x4f7b1c: r0 = Instance_Chapter12Stat
    //     0x4f7b1c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x4f7b20: ldr             x0, [x0, #0x498]
    // 0x4f7b24: stur            x3, [fp, #-0x38]
    // 0x4f7b28: StoreField: r3->field_b = r0
    //     0x4f7b28: stur            w0, [x3, #0xb]
    // 0x4f7b2c: ldur            x1, [fp, #-0x30]
    // 0x4f7b30: StoreField: r3->field_f = r1
    //     0x4f7b30: stur            w1, [x3, #0xf]
    // 0x4f7b34: r1 = Null
    //     0x4f7b34: mov             x1, NULL
    // 0x4f7b38: r2 = 2
    //     0x4f7b38: movz            x2, #0x2
    // 0x4f7b3c: r0 = AllocateArray()
    //     0x4f7b3c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7b40: mov             x2, x0
    // 0x4f7b44: ldur            x0, [fp, #-0x38]
    // 0x4f7b48: stur            x2, [fp, #-0x30]
    // 0x4f7b4c: StoreField: r2->field_f = r0
    //     0x4f7b4c: stur            w0, [x2, #0xf]
    // 0x4f7b50: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7b50: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7b54: ldr             x1, [x1, #0xc38]
    // 0x4f7b58: r0 = AllocateGrowableArray()
    //     0x4f7b58: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f7b5c: mov             x2, x0
    // 0x4f7b60: ldur            x0, [fp, #-0x30]
    // 0x4f7b64: stur            x2, [fp, #-0x38]
    // 0x4f7b68: StoreField: r2->field_f = r0
    //     0x4f7b68: stur            w0, [x2, #0xf]
    // 0x4f7b6c: r0 = 2
    //     0x4f7b6c: movz            x0, #0x2
    // 0x4f7b70: StoreField: r2->field_b = r0
    //     0x4f7b70: stur            w0, [x2, #0xb]
    // 0x4f7b74: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7b74: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7b78: ldr             x1, [x1, #0xc38]
    // 0x4f7b7c: r0 = Generator()
    //     0x4f7b7c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7b80: mov             x2, x0
    // 0x4f7b84: ldur            x0, [fp, #-0x38]
    // 0x4f7b88: stur            x2, [fp, #-0x30]
    // 0x4f7b8c: StoreField: r2->field_b = r0
    //     0x4f7b8c: stur            w0, [x2, #0xb]
    // 0x4f7b90: r1 = <Chapter12Stat>
    //     0x4f7b90: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7b94: ldr             x1, [x1, #0xef0]
    // 0x4f7b98: r0 = UpgradeData()
    //     0x4f7b98: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7b9c: mov             x3, x0
    // 0x4f7ba0: ldur            x0, [fp, #-0x20]
    // 0x4f7ba4: stur            x3, [fp, #-0x38]
    // 0x4f7ba8: StoreField: r3->field_b = r0
    //     0x4f7ba8: stur            w0, [x3, #0xb]
    // 0x4f7bac: ldur            x0, [fp, #-0x28]
    // 0x4f7bb0: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7bb0: stur            w0, [x3, #0x17]
    // 0x4f7bb4: r0 = Instance_IconData
    //     0x4f7bb4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ef8] Obj!IconData@830011
    //     0x4f7bb8: ldr             x0, [x0, #0xef8]
    // 0x4f7bbc: StoreField: r3->field_13 = r0
    //     0x4f7bbc: stur            w0, [x3, #0x13]
    // 0x4f7bc0: ldur            x0, [fp, #-0x30]
    // 0x4f7bc4: StoreField: r3->field_f = r0
    //     0x4f7bc4: stur            w0, [x3, #0xf]
    // 0x4f7bc8: ldur            x2, [fp, #-0x10]
    // 0x4f7bcc: r1 = Function '<anonymous closure>':.
    //     0x4f7bcc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f00] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7bd0: ldr             x1, [x1, #0xf00]
    // 0x4f7bd4: r0 = AllocateClosure()
    //     0x4f7bd4: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7bd8: mov             x1, x0
    // 0x4f7bdc: ldur            x0, [fp, #-0x38]
    // 0x4f7be0: StoreField: r0->field_1b = r1
    //     0x4f7be0: stur            w1, [x0, #0x1b]
    // 0x4f7be4: ldur            x1, [fp, #-0x18]
    // 0x4f7be8: ArrayStore: r1[25] = r0  ; List_4
    //     0x4f7be8: add             x25, x1, #0x73
    //     0x4f7bec: str             w0, [x25]
    //     0x4f7bf0: tbz             w0, #0, #0x4f7c0c
    //     0x4f7bf4: ldurb           w16, [x1, #-1]
    //     0x4f7bf8: ldurb           w17, [x0, #-1]
    //     0x4f7bfc: and             x16, x17, x16, lsr #2
    //     0x4f7c00: tst             x16, HEAP, lsr #32
    //     0x4f7c04: b.eq            #0x4f7c0c
    //     0x4f7c08: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7c0c: ldur            x0, [fp, #-0x18]
    // 0x4f7c10: r16 = 222
    //     0x4f7c10: movz            x16, #0xde
    // 0x4f7c14: StoreField: r0->field_77 = r16
    //     0x4f7c14: stur            w16, [x0, #0x77]
    // 0x4f7c18: r1 = "Macros"
    //     0x4f7c18: add             x1, PP, #0x11, lsl #12  ; [pp+0x11918] "Macros"
    //     0x4f7c1c: ldr             x1, [x1, #0x918]
    // 0x4f7c20: r0 = autoString()
    //     0x4f7c20: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7c24: r1 = Function '<anonymous closure>':.
    //     0x4f7c24: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f08] AnonymousClosure: (0x4f9d24), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7c28: ldr             x1, [x1, #0xf08]
    // 0x4f7c2c: r2 = Null
    //     0x4f7c2c: mov             x2, NULL
    // 0x4f7c30: stur            x0, [fp, #-0x20]
    // 0x4f7c34: r0 = AllocateClosure()
    //     0x4f7c34: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7c38: r1 = <String>
    //     0x4f7c38: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7c3c: stur            x0, [fp, #-0x28]
    // 0x4f7c40: r0 = Generator()
    //     0x4f7c40: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7c44: ldur            x2, [fp, #-0x28]
    // 0x4f7c48: r3 = Null
    //     0x4f7c48: mov             x3, NULL
    // 0x4f7c4c: stur            x0, [fp, #-0x28]
    // 0x4f7c50: r0 = AllocateRecord2()
    //     0x4f7c50: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7c54: mov             x1, x0
    // 0x4f7c58: ldur            x0, [fp, #-0x28]
    // 0x4f7c5c: StoreField: r0->field_f = r1
    //     0x4f7c5c: stur            w1, [x0, #0xf]
    // 0x4f7c60: r1 = Null
    //     0x4f7c60: mov             x1, NULL
    // 0x4f7c64: r2 = 2
    //     0x4f7c64: movz            x2, #0x2
    // 0x4f7c68: r0 = AllocateArray()
    //     0x4f7c68: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7c6c: stur            x0, [fp, #-0x30]
    // 0x4f7c70: r16 = Instance_Tuple2
    //     0x4f7c70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15f10] Obj!Tuple2<Chapter12Stat, CustomNum>@8230d1
    //     0x4f7c74: ldr             x16, [x16, #0xf10]
    // 0x4f7c78: StoreField: r0->field_f = r16
    //     0x4f7c78: stur            w16, [x0, #0xf]
    // 0x4f7c7c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7c7c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7c80: ldr             x1, [x1, #0xc38]
    // 0x4f7c84: r0 = AllocateGrowableArray()
    //     0x4f7c84: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f7c88: mov             x2, x0
    // 0x4f7c8c: ldur            x0, [fp, #-0x30]
    // 0x4f7c90: stur            x2, [fp, #-0x38]
    // 0x4f7c94: StoreField: r2->field_f = r0
    //     0x4f7c94: stur            w0, [x2, #0xf]
    // 0x4f7c98: r0 = 2
    //     0x4f7c98: movz            x0, #0x2
    // 0x4f7c9c: StoreField: r2->field_b = r0
    //     0x4f7c9c: stur            w0, [x2, #0xb]
    // 0x4f7ca0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7ca0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7ca4: ldr             x1, [x1, #0xc38]
    // 0x4f7ca8: r0 = Generator()
    //     0x4f7ca8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7cac: mov             x2, x0
    // 0x4f7cb0: ldur            x0, [fp, #-0x38]
    // 0x4f7cb4: stur            x2, [fp, #-0x30]
    // 0x4f7cb8: StoreField: r2->field_b = r0
    //     0x4f7cb8: stur            w0, [x2, #0xb]
    // 0x4f7cbc: r1 = <Chapter12Stat>
    //     0x4f7cbc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7cc0: ldr             x1, [x1, #0xef0]
    // 0x4f7cc4: r0 = UpgradeData()
    //     0x4f7cc4: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7cc8: mov             x3, x0
    // 0x4f7ccc: ldur            x0, [fp, #-0x20]
    // 0x4f7cd0: stur            x3, [fp, #-0x38]
    // 0x4f7cd4: StoreField: r3->field_b = r0
    //     0x4f7cd4: stur            w0, [x3, #0xb]
    // 0x4f7cd8: ldur            x0, [fp, #-0x28]
    // 0x4f7cdc: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7cdc: stur            w0, [x3, #0x17]
    // 0x4f7ce0: r0 = Instance_IconData
    //     0x4f7ce0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15f18] Obj!IconData@82fff1
    //     0x4f7ce4: ldr             x0, [x0, #0xf18]
    // 0x4f7ce8: StoreField: r3->field_13 = r0
    //     0x4f7ce8: stur            w0, [x3, #0x13]
    // 0x4f7cec: ldur            x0, [fp, #-0x30]
    // 0x4f7cf0: StoreField: r3->field_f = r0
    //     0x4f7cf0: stur            w0, [x3, #0xf]
    // 0x4f7cf4: ldur            x2, [fp, #-0x10]
    // 0x4f7cf8: r1 = Function '<anonymous closure>':.
    //     0x4f7cf8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f20] AnonymousClosure: (0x4f9c34), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7cfc: ldr             x1, [x1, #0xf20]
    // 0x4f7d00: r0 = AllocateClosure()
    //     0x4f7d00: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7d04: mov             x1, x0
    // 0x4f7d08: ldur            x0, [fp, #-0x38]
    // 0x4f7d0c: StoreField: r0->field_23 = r1
    //     0x4f7d0c: stur            w1, [x0, #0x23]
    // 0x4f7d10: ldur            x1, [fp, #-0x18]
    // 0x4f7d14: ArrayStore: r1[27] = r0  ; List_4
    //     0x4f7d14: add             x25, x1, #0x7b
    //     0x4f7d18: str             w0, [x25]
    //     0x4f7d1c: tbz             w0, #0, #0x4f7d38
    //     0x4f7d20: ldurb           w16, [x1, #-1]
    //     0x4f7d24: ldurb           w17, [x0, #-1]
    //     0x4f7d28: and             x16, x17, x16, lsr #2
    //     0x4f7d2c: tst             x16, HEAP, lsr #32
    //     0x4f7d30: b.eq            #0x4f7d38
    //     0x4f7d34: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7d38: ldur            x0, [fp, #-0x18]
    // 0x4f7d3c: r16 = 224
    //     0x4f7d3c: movz            x16, #0xe0
    // 0x4f7d40: StoreField: r0->field_7f = r16
    //     0x4f7d40: stur            w16, [x0, #0x7f]
    // 0x4f7d44: r1 = "Fast Follow"
    //     0x4f7d44: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f28] "Fast Follow"
    //     0x4f7d48: ldr             x1, [x1, #0xf28]
    // 0x4f7d4c: r0 = autoString()
    //     0x4f7d4c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7d50: r1 = Function '<anonymous closure>':.
    //     0x4f7d50: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f30] AnonymousClosure: (0x4f9c28), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7d54: ldr             x1, [x1, #0xf30]
    // 0x4f7d58: r2 = Null
    //     0x4f7d58: mov             x2, NULL
    // 0x4f7d5c: stur            x0, [fp, #-0x20]
    // 0x4f7d60: r0 = AllocateClosure()
    //     0x4f7d60: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7d64: r1 = <String>
    //     0x4f7d64: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7d68: stur            x0, [fp, #-0x28]
    // 0x4f7d6c: r0 = Generator()
    //     0x4f7d6c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7d70: ldur            x2, [fp, #-0x28]
    // 0x4f7d74: r3 = Null
    //     0x4f7d74: mov             x3, NULL
    // 0x4f7d78: stur            x0, [fp, #-0x28]
    // 0x4f7d7c: r0 = AllocateRecord2()
    //     0x4f7d7c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7d80: mov             x1, x0
    // 0x4f7d84: ldur            x0, [fp, #-0x28]
    // 0x4f7d88: StoreField: r0->field_f = r1
    //     0x4f7d88: stur            w1, [x0, #0xf]
    // 0x4f7d8c: r1 = Null
    //     0x4f7d8c: mov             x1, NULL
    // 0x4f7d90: r2 = 10000
    //     0x4f7d90: movz            x2, #0x2710
    // 0x4f7d94: r0 = CustomNum()
    //     0x4f7d94: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f7d98: r1 = <Chapter12Stat, CustomNum>
    //     0x4f7d98: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e88] TypeArguments: <Chapter12Stat, CustomNum>
    //     0x4f7d9c: ldr             x1, [x1, #0xe88]
    // 0x4f7da0: stur            x0, [fp, #-0x30]
    // 0x4f7da4: r0 = Tuple2()
    //     0x4f7da4: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4f7da8: mov             x3, x0
    // 0x4f7dac: r0 = Instance_Chapter12Stat
    //     0x4f7dac: add             x0, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x4f7db0: ldr             x0, [x0, #0x498]
    // 0x4f7db4: stur            x3, [fp, #-0x38]
    // 0x4f7db8: StoreField: r3->field_b = r0
    //     0x4f7db8: stur            w0, [x3, #0xb]
    // 0x4f7dbc: ldur            x0, [fp, #-0x30]
    // 0x4f7dc0: StoreField: r3->field_f = r0
    //     0x4f7dc0: stur            w0, [x3, #0xf]
    // 0x4f7dc4: r1 = Null
    //     0x4f7dc4: mov             x1, NULL
    // 0x4f7dc8: r2 = 2
    //     0x4f7dc8: movz            x2, #0x2
    // 0x4f7dcc: r0 = AllocateArray()
    //     0x4f7dcc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7dd0: mov             x2, x0
    // 0x4f7dd4: ldur            x0, [fp, #-0x38]
    // 0x4f7dd8: stur            x2, [fp, #-0x30]
    // 0x4f7ddc: StoreField: r2->field_f = r0
    //     0x4f7ddc: stur            w0, [x2, #0xf]
    // 0x4f7de0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7de0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7de4: ldr             x1, [x1, #0xc38]
    // 0x4f7de8: r0 = AllocateGrowableArray()
    //     0x4f7de8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f7dec: mov             x2, x0
    // 0x4f7df0: ldur            x0, [fp, #-0x30]
    // 0x4f7df4: stur            x2, [fp, #-0x38]
    // 0x4f7df8: StoreField: r2->field_f = r0
    //     0x4f7df8: stur            w0, [x2, #0xf]
    // 0x4f7dfc: r0 = 2
    //     0x4f7dfc: movz            x0, #0x2
    // 0x4f7e00: StoreField: r2->field_b = r0
    //     0x4f7e00: stur            w0, [x2, #0xb]
    // 0x4f7e04: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7e04: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7e08: ldr             x1, [x1, #0xc38]
    // 0x4f7e0c: r0 = Generator()
    //     0x4f7e0c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7e10: mov             x2, x0
    // 0x4f7e14: ldur            x0, [fp, #-0x38]
    // 0x4f7e18: stur            x2, [fp, #-0x30]
    // 0x4f7e1c: StoreField: r2->field_b = r0
    //     0x4f7e1c: stur            w0, [x2, #0xb]
    // 0x4f7e20: r1 = <Chapter12Stat>
    //     0x4f7e20: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7e24: ldr             x1, [x1, #0xef0]
    // 0x4f7e28: r0 = UpgradeData()
    //     0x4f7e28: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7e2c: mov             x3, x0
    // 0x4f7e30: ldur            x0, [fp, #-0x20]
    // 0x4f7e34: stur            x3, [fp, #-0x38]
    // 0x4f7e38: StoreField: r3->field_b = r0
    //     0x4f7e38: stur            w0, [x3, #0xb]
    // 0x4f7e3c: ldur            x0, [fp, #-0x28]
    // 0x4f7e40: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7e40: stur            w0, [x3, #0x17]
    // 0x4f7e44: r0 = Instance_IconData
    //     0x4f7e44: add             x0, PP, #0x15, lsl #12  ; [pp+0x15f38] Obj!IconData@82ffd1
    //     0x4f7e48: ldr             x0, [x0, #0xf38]
    // 0x4f7e4c: StoreField: r3->field_13 = r0
    //     0x4f7e4c: stur            w0, [x3, #0x13]
    // 0x4f7e50: ldur            x0, [fp, #-0x30]
    // 0x4f7e54: StoreField: r3->field_f = r0
    //     0x4f7e54: stur            w0, [x3, #0xf]
    // 0x4f7e58: ldur            x2, [fp, #-0x10]
    // 0x4f7e5c: r1 = Function '<anonymous closure>':.
    //     0x4f7e5c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f40] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7e60: ldr             x1, [x1, #0xf40]
    // 0x4f7e64: r0 = AllocateClosure()
    //     0x4f7e64: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7e68: mov             x1, x0
    // 0x4f7e6c: ldur            x0, [fp, #-0x38]
    // 0x4f7e70: StoreField: r0->field_1b = r1
    //     0x4f7e70: stur            w1, [x0, #0x1b]
    // 0x4f7e74: ldur            x1, [fp, #-0x18]
    // 0x4f7e78: ArrayStore: r1[29] = r0  ; List_4
    //     0x4f7e78: add             x25, x1, #0x83
    //     0x4f7e7c: str             w0, [x25]
    //     0x4f7e80: tbz             w0, #0, #0x4f7e9c
    //     0x4f7e84: ldurb           w16, [x1, #-1]
    //     0x4f7e88: ldurb           w17, [x0, #-1]
    //     0x4f7e8c: and             x16, x17, x16, lsr #2
    //     0x4f7e90: tst             x16, HEAP, lsr #32
    //     0x4f7e94: b.eq            #0x4f7e9c
    //     0x4f7e98: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7e9c: ldur            x0, [fp, #-0x18]
    // 0x4f7ea0: r16 = 404
    //     0x4f7ea0: movz            x16, #0x194
    // 0x4f7ea4: StoreField: r0->field_87 = r16
    //     0x4f7ea4: stur            w16, [x0, #0x87]
    // 0x4f7ea8: r1 = "Lower Prices"
    //     0x4f7ea8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f48] "Lower Prices"
    //     0x4f7eac: ldr             x1, [x1, #0xf48]
    // 0x4f7eb0: r0 = autoString()
    //     0x4f7eb0: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7eb4: r1 = Function '<anonymous closure>':.
    //     0x4f7eb4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f50] AnonymousClosure: (0x4f9c1c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7eb8: ldr             x1, [x1, #0xf50]
    // 0x4f7ebc: r2 = Null
    //     0x4f7ebc: mov             x2, NULL
    // 0x4f7ec0: stur            x0, [fp, #-0x20]
    // 0x4f7ec4: r0 = AllocateClosure()
    //     0x4f7ec4: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7ec8: r1 = <String>
    //     0x4f7ec8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7ecc: stur            x0, [fp, #-0x28]
    // 0x4f7ed0: r0 = Generator()
    //     0x4f7ed0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7ed4: ldur            x2, [fp, #-0x28]
    // 0x4f7ed8: r3 = Null
    //     0x4f7ed8: mov             x3, NULL
    // 0x4f7edc: stur            x0, [fp, #-0x28]
    // 0x4f7ee0: r0 = AllocateRecord2()
    //     0x4f7ee0: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f7ee4: mov             x1, x0
    // 0x4f7ee8: ldur            x0, [fp, #-0x28]
    // 0x4f7eec: StoreField: r0->field_f = r1
    //     0x4f7eec: stur            w1, [x0, #0xf]
    // 0x4f7ef0: r1 = Null
    //     0x4f7ef0: mov             x1, NULL
    // 0x4f7ef4: r2 = 2
    //     0x4f7ef4: movz            x2, #0x2
    // 0x4f7ef8: r0 = AllocateArray()
    //     0x4f7ef8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f7efc: stur            x0, [fp, #-0x30]
    // 0x4f7f00: r16 = Instance_Tuple2
    //     0x4f7f00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15f58] Obj!Tuple2<Chapter12Stat, CustomNum>@8230b1
    //     0x4f7f04: ldr             x16, [x16, #0xf58]
    // 0x4f7f08: StoreField: r0->field_f = r16
    //     0x4f7f08: stur            w16, [x0, #0xf]
    // 0x4f7f0c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7f0c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7f10: ldr             x1, [x1, #0xc38]
    // 0x4f7f14: r0 = AllocateGrowableArray()
    //     0x4f7f14: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f7f18: mov             x2, x0
    // 0x4f7f1c: ldur            x0, [fp, #-0x30]
    // 0x4f7f20: stur            x2, [fp, #-0x38]
    // 0x4f7f24: StoreField: r2->field_f = r0
    //     0x4f7f24: stur            w0, [x2, #0xf]
    // 0x4f7f28: r0 = 2
    //     0x4f7f28: movz            x0, #0x2
    // 0x4f7f2c: StoreField: r2->field_b = r0
    //     0x4f7f2c: stur            w0, [x2, #0xb]
    // 0x4f7f30: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7f30: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f7f34: ldr             x1, [x1, #0xc38]
    // 0x4f7f38: r0 = Generator()
    //     0x4f7f38: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f7f3c: mov             x2, x0
    // 0x4f7f40: ldur            x0, [fp, #-0x38]
    // 0x4f7f44: stur            x2, [fp, #-0x30]
    // 0x4f7f48: StoreField: r2->field_b = r0
    //     0x4f7f48: stur            w0, [x2, #0xb]
    // 0x4f7f4c: r1 = <Chapter12Stat>
    //     0x4f7f4c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f7f50: ldr             x1, [x1, #0xef0]
    // 0x4f7f54: r0 = UpgradeData()
    //     0x4f7f54: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f7f58: mov             x3, x0
    // 0x4f7f5c: ldur            x0, [fp, #-0x20]
    // 0x4f7f60: stur            x3, [fp, #-0x38]
    // 0x4f7f64: StoreField: r3->field_b = r0
    //     0x4f7f64: stur            w0, [x3, #0xb]
    // 0x4f7f68: ldur            x0, [fp, #-0x28]
    // 0x4f7f6c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f7f6c: stur            w0, [x3, #0x17]
    // 0x4f7f70: r0 = Instance_IconData
    //     0x4f7f70: add             x0, PP, #0x15, lsl #12  ; [pp+0x15f60] Obj!IconData@82ffb1
    //     0x4f7f74: ldr             x0, [x0, #0xf60]
    // 0x4f7f78: StoreField: r3->field_13 = r0
    //     0x4f7f78: stur            w0, [x3, #0x13]
    // 0x4f7f7c: ldur            x0, [fp, #-0x30]
    // 0x4f7f80: StoreField: r3->field_f = r0
    //     0x4f7f80: stur            w0, [x3, #0xf]
    // 0x4f7f84: ldur            x2, [fp, #-0x10]
    // 0x4f7f88: r1 = Function '<anonymous closure>':.
    //     0x4f7f88: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f68] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f7f8c: ldr             x1, [x1, #0xf68]
    // 0x4f7f90: r0 = AllocateClosure()
    //     0x4f7f90: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7f94: mov             x1, x0
    // 0x4f7f98: ldur            x0, [fp, #-0x38]
    // 0x4f7f9c: StoreField: r0->field_1b = r1
    //     0x4f7f9c: stur            w1, [x0, #0x1b]
    // 0x4f7fa0: ldur            x1, [fp, #-0x18]
    // 0x4f7fa4: ArrayStore: r1[31] = r0  ; List_4
    //     0x4f7fa4: add             x25, x1, #0x8b
    //     0x4f7fa8: str             w0, [x25]
    //     0x4f7fac: tbz             w0, #0, #0x4f7fc8
    //     0x4f7fb0: ldurb           w16, [x1, #-1]
    //     0x4f7fb4: ldurb           w17, [x0, #-1]
    //     0x4f7fb8: and             x16, x17, x16, lsr #2
    //     0x4f7fbc: tst             x16, HEAP, lsr #32
    //     0x4f7fc0: b.eq            #0x4f7fc8
    //     0x4f7fc4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f7fc8: ldur            x0, [fp, #-0x18]
    // 0x4f7fcc: r16 = 226
    //     0x4f7fcc: movz            x16, #0xe2
    // 0x4f7fd0: StoreField: r0->field_8f = r16
    //     0x4f7fd0: stur            w16, [x0, #0x8f]
    // 0x4f7fd4: r1 = "More Logs"
    //     0x4f7fd4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f70] "More Logs"
    //     0x4f7fd8: ldr             x1, [x1, #0xf70]
    // 0x4f7fdc: r0 = autoString()
    //     0x4f7fdc: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f7fe0: r1 = Function '<anonymous closure>':.
    //     0x4f7fe0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f78] AnonymousClosure: (0x4f9c10), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f7fe4: ldr             x1, [x1, #0xf78]
    // 0x4f7fe8: r2 = Null
    //     0x4f7fe8: mov             x2, NULL
    // 0x4f7fec: stur            x0, [fp, #-0x20]
    // 0x4f7ff0: r0 = AllocateClosure()
    //     0x4f7ff0: bl              #0x826750  ; AllocateClosureStub
    // 0x4f7ff4: r1 = <String>
    //     0x4f7ff4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f7ff8: stur            x0, [fp, #-0x28]
    // 0x4f7ffc: r0 = Generator()
    //     0x4f7ffc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8000: ldur            x2, [fp, #-0x28]
    // 0x4f8004: r3 = Null
    //     0x4f8004: mov             x3, NULL
    // 0x4f8008: stur            x0, [fp, #-0x28]
    // 0x4f800c: r0 = AllocateRecord2()
    //     0x4f800c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8010: mov             x1, x0
    // 0x4f8014: ldur            x0, [fp, #-0x28]
    // 0x4f8018: StoreField: r0->field_f = r1
    //     0x4f8018: stur            w1, [x0, #0xf]
    // 0x4f801c: r1 = Null
    //     0x4f801c: mov             x1, NULL
    // 0x4f8020: r2 = 2
    //     0x4f8020: movz            x2, #0x2
    // 0x4f8024: r0 = AllocateArray()
    //     0x4f8024: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8028: stur            x0, [fp, #-0x30]
    // 0x4f802c: r16 = Instance_Tuple2
    //     0x4f802c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15f80] Obj!Tuple2<Chapter12Stat, CustomNum>@823091
    //     0x4f8030: ldr             x16, [x16, #0xf80]
    // 0x4f8034: StoreField: r0->field_f = r16
    //     0x4f8034: stur            w16, [x0, #0xf]
    // 0x4f8038: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8038: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f803c: ldr             x1, [x1, #0xc38]
    // 0x4f8040: r0 = AllocateGrowableArray()
    //     0x4f8040: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8044: mov             x2, x0
    // 0x4f8048: ldur            x0, [fp, #-0x30]
    // 0x4f804c: stur            x2, [fp, #-0x38]
    // 0x4f8050: StoreField: r2->field_f = r0
    //     0x4f8050: stur            w0, [x2, #0xf]
    // 0x4f8054: r0 = 2
    //     0x4f8054: movz            x0, #0x2
    // 0x4f8058: StoreField: r2->field_b = r0
    //     0x4f8058: stur            w0, [x2, #0xb]
    // 0x4f805c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f805c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8060: ldr             x1, [x1, #0xc38]
    // 0x4f8064: r0 = Generator()
    //     0x4f8064: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8068: mov             x2, x0
    // 0x4f806c: ldur            x0, [fp, #-0x38]
    // 0x4f8070: stur            x2, [fp, #-0x30]
    // 0x4f8074: StoreField: r2->field_b = r0
    //     0x4f8074: stur            w0, [x2, #0xb]
    // 0x4f8078: r1 = <Chapter12Stat>
    //     0x4f8078: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f807c: ldr             x1, [x1, #0xef0]
    // 0x4f8080: r0 = UpgradeData()
    //     0x4f8080: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8084: mov             x3, x0
    // 0x4f8088: ldur            x0, [fp, #-0x20]
    // 0x4f808c: stur            x3, [fp, #-0x38]
    // 0x4f8090: StoreField: r3->field_b = r0
    //     0x4f8090: stur            w0, [x3, #0xb]
    // 0x4f8094: ldur            x0, [fp, #-0x28]
    // 0x4f8098: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8098: stur            w0, [x3, #0x17]
    // 0x4f809c: r0 = Instance_IconData
    //     0x4f809c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15f88] Obj!IconData@82ff91
    //     0x4f80a0: ldr             x0, [x0, #0xf88]
    // 0x4f80a4: StoreField: r3->field_13 = r0
    //     0x4f80a4: stur            w0, [x3, #0x13]
    // 0x4f80a8: ldur            x0, [fp, #-0x30]
    // 0x4f80ac: StoreField: r3->field_f = r0
    //     0x4f80ac: stur            w0, [x3, #0xf]
    // 0x4f80b0: ldur            x2, [fp, #-0x10]
    // 0x4f80b4: r1 = Function '<anonymous closure>':.
    //     0x4f80b4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f90] AnonymousClosure: (0x4f9b20), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f80b8: ldr             x1, [x1, #0xf90]
    // 0x4f80bc: r0 = AllocateClosure()
    //     0x4f80bc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f80c0: mov             x1, x0
    // 0x4f80c4: ldur            x0, [fp, #-0x38]
    // 0x4f80c8: StoreField: r0->field_23 = r1
    //     0x4f80c8: stur            w1, [x0, #0x23]
    // 0x4f80cc: ldur            x1, [fp, #-0x18]
    // 0x4f80d0: ArrayStore: r1[33] = r0  ; List_4
    //     0x4f80d0: add             x25, x1, #0x93
    //     0x4f80d4: str             w0, [x25]
    //     0x4f80d8: tbz             w0, #0, #0x4f80f4
    //     0x4f80dc: ldurb           w16, [x1, #-1]
    //     0x4f80e0: ldurb           w17, [x0, #-1]
    //     0x4f80e4: and             x16, x17, x16, lsr #2
    //     0x4f80e8: tst             x16, HEAP, lsr #32
    //     0x4f80ec: b.eq            #0x4f80f4
    //     0x4f80f0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f80f4: ldur            x0, [fp, #-0x18]
    // 0x4f80f8: r16 = 228
    //     0x4f80f8: movz            x16, #0xe4
    // 0x4f80fc: StoreField: r0->field_97 = r16
    //     0x4f80fc: stur            w16, [x0, #0x97]
    // 0x4f8100: r1 = "More Ports"
    //     0x4f8100: add             x1, PP, #0x15, lsl #12  ; [pp+0x15f98] "More Ports"
    //     0x4f8104: ldr             x1, [x1, #0xf98]
    // 0x4f8108: r0 = autoString()
    //     0x4f8108: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f810c: r1 = Function '<anonymous closure>':.
    //     0x4f810c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fa0] AnonymousClosure: (0x4f9b14), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8110: ldr             x1, [x1, #0xfa0]
    // 0x4f8114: r2 = Null
    //     0x4f8114: mov             x2, NULL
    // 0x4f8118: stur            x0, [fp, #-0x20]
    // 0x4f811c: r0 = AllocateClosure()
    //     0x4f811c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8120: r1 = <String>
    //     0x4f8120: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8124: stur            x0, [fp, #-0x28]
    // 0x4f8128: r0 = Generator()
    //     0x4f8128: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f812c: ldur            x2, [fp, #-0x28]
    // 0x4f8130: r3 = Null
    //     0x4f8130: mov             x3, NULL
    // 0x4f8134: stur            x0, [fp, #-0x28]
    // 0x4f8138: r0 = AllocateRecord2()
    //     0x4f8138: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f813c: mov             x1, x0
    // 0x4f8140: ldur            x0, [fp, #-0x28]
    // 0x4f8144: StoreField: r0->field_f = r1
    //     0x4f8144: stur            w1, [x0, #0xf]
    // 0x4f8148: r1 = Null
    //     0x4f8148: mov             x1, NULL
    // 0x4f814c: r2 = 2
    //     0x4f814c: movz            x2, #0x2
    // 0x4f8150: r0 = AllocateArray()
    //     0x4f8150: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8154: stur            x0, [fp, #-0x30]
    // 0x4f8158: r16 = Instance_Tuple2
    //     0x4f8158: add             x16, PP, #0x15, lsl #12  ; [pp+0x15fa8] Obj!Tuple2<Chapter12Stat, CustomNum>@823071
    //     0x4f815c: ldr             x16, [x16, #0xfa8]
    // 0x4f8160: StoreField: r0->field_f = r16
    //     0x4f8160: stur            w16, [x0, #0xf]
    // 0x4f8164: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8164: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8168: ldr             x1, [x1, #0xc38]
    // 0x4f816c: r0 = AllocateGrowableArray()
    //     0x4f816c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8170: mov             x2, x0
    // 0x4f8174: ldur            x0, [fp, #-0x30]
    // 0x4f8178: stur            x2, [fp, #-0x38]
    // 0x4f817c: StoreField: r2->field_f = r0
    //     0x4f817c: stur            w0, [x2, #0xf]
    // 0x4f8180: r0 = 2
    //     0x4f8180: movz            x0, #0x2
    // 0x4f8184: StoreField: r2->field_b = r0
    //     0x4f8184: stur            w0, [x2, #0xb]
    // 0x4f8188: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8188: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f818c: ldr             x1, [x1, #0xc38]
    // 0x4f8190: r0 = Generator()
    //     0x4f8190: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8194: mov             x2, x0
    // 0x4f8198: ldur            x0, [fp, #-0x38]
    // 0x4f819c: stur            x2, [fp, #-0x30]
    // 0x4f81a0: StoreField: r2->field_b = r0
    //     0x4f81a0: stur            w0, [x2, #0xb]
    // 0x4f81a4: r1 = <Chapter12Stat>
    //     0x4f81a4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f81a8: ldr             x1, [x1, #0xef0]
    // 0x4f81ac: r0 = UpgradeData()
    //     0x4f81ac: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f81b0: mov             x3, x0
    // 0x4f81b4: ldur            x0, [fp, #-0x20]
    // 0x4f81b8: stur            x3, [fp, #-0x38]
    // 0x4f81bc: StoreField: r3->field_b = r0
    //     0x4f81bc: stur            w0, [x3, #0xb]
    // 0x4f81c0: ldur            x0, [fp, #-0x28]
    // 0x4f81c4: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f81c4: stur            w0, [x3, #0x17]
    // 0x4f81c8: r0 = Instance_IconData
    //     0x4f81c8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14808] Obj!IconData@830151
    //     0x4f81cc: ldr             x0, [x0, #0x808]
    // 0x4f81d0: StoreField: r3->field_13 = r0
    //     0x4f81d0: stur            w0, [x3, #0x13]
    // 0x4f81d4: ldur            x0, [fp, #-0x30]
    // 0x4f81d8: StoreField: r3->field_f = r0
    //     0x4f81d8: stur            w0, [x3, #0xf]
    // 0x4f81dc: ldur            x2, [fp, #-0x10]
    // 0x4f81e0: r1 = Function '<anonymous closure>':.
    //     0x4f81e0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fb0] AnonymousClosure: (0x4f9a24), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f81e4: ldr             x1, [x1, #0xfb0]
    // 0x4f81e8: r0 = AllocateClosure()
    //     0x4f81e8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f81ec: mov             x1, x0
    // 0x4f81f0: ldur            x0, [fp, #-0x38]
    // 0x4f81f4: StoreField: r0->field_23 = r1
    //     0x4f81f4: stur            w1, [x0, #0x23]
    // 0x4f81f8: ldur            x1, [fp, #-0x18]
    // 0x4f81fc: ArrayStore: r1[35] = r0  ; List_4
    //     0x4f81fc: add             x25, x1, #0x9b
    //     0x4f8200: str             w0, [x25]
    //     0x4f8204: tbz             w0, #0, #0x4f8220
    //     0x4f8208: ldurb           w16, [x1, #-1]
    //     0x4f820c: ldurb           w17, [x0, #-1]
    //     0x4f8210: and             x16, x17, x16, lsr #2
    //     0x4f8214: tst             x16, HEAP, lsr #32
    //     0x4f8218: b.eq            #0x4f8220
    //     0x4f821c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8220: ldur            x0, [fp, #-0x18]
    // 0x4f8224: r16 = 230
    //     0x4f8224: movz            x16, #0xe6
    // 0x4f8228: StoreField: r0->field_9f = r16
    //     0x4f8228: stur            w16, [x0, #0x9f]
    // 0x4f822c: r1 = "Advanced Methods"
    //     0x4f822c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fb8] "Advanced Methods"
    //     0x4f8230: ldr             x1, [x1, #0xfb8]
    // 0x4f8234: r0 = autoString()
    //     0x4f8234: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8238: r1 = Function '<anonymous closure>':.
    //     0x4f8238: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fc0] AnonymousClosure: (0x4f9a18), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f823c: ldr             x1, [x1, #0xfc0]
    // 0x4f8240: r2 = Null
    //     0x4f8240: mov             x2, NULL
    // 0x4f8244: stur            x0, [fp, #-0x20]
    // 0x4f8248: r0 = AllocateClosure()
    //     0x4f8248: bl              #0x826750  ; AllocateClosureStub
    // 0x4f824c: r1 = <String>
    //     0x4f824c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8250: stur            x0, [fp, #-0x28]
    // 0x4f8254: r0 = Generator()
    //     0x4f8254: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8258: ldur            x2, [fp, #-0x28]
    // 0x4f825c: r3 = Null
    //     0x4f825c: mov             x3, NULL
    // 0x4f8260: stur            x0, [fp, #-0x28]
    // 0x4f8264: r0 = AllocateRecord2()
    //     0x4f8264: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8268: mov             x1, x0
    // 0x4f826c: ldur            x0, [fp, #-0x28]
    // 0x4f8270: StoreField: r0->field_f = r1
    //     0x4f8270: stur            w1, [x0, #0xf]
    // 0x4f8274: r1 = Null
    //     0x4f8274: mov             x1, NULL
    // 0x4f8278: r2 = 2
    //     0x4f8278: movz            x2, #0x2
    // 0x4f827c: r0 = AllocateArray()
    //     0x4f827c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8280: stur            x0, [fp, #-0x30]
    // 0x4f8284: r16 = Instance_Tuple2
    //     0x4f8284: add             x16, PP, #0x15, lsl #12  ; [pp+0x15fc8] Obj!Tuple2<Chapter12Stat, CustomNum>@823051
    //     0x4f8288: ldr             x16, [x16, #0xfc8]
    // 0x4f828c: StoreField: r0->field_f = r16
    //     0x4f828c: stur            w16, [x0, #0xf]
    // 0x4f8290: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8290: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8294: ldr             x1, [x1, #0xc38]
    // 0x4f8298: r0 = AllocateGrowableArray()
    //     0x4f8298: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f829c: mov             x2, x0
    // 0x4f82a0: ldur            x0, [fp, #-0x30]
    // 0x4f82a4: stur            x2, [fp, #-0x38]
    // 0x4f82a8: StoreField: r2->field_f = r0
    //     0x4f82a8: stur            w0, [x2, #0xf]
    // 0x4f82ac: r0 = 2
    //     0x4f82ac: movz            x0, #0x2
    // 0x4f82b0: StoreField: r2->field_b = r0
    //     0x4f82b0: stur            w0, [x2, #0xb]
    // 0x4f82b4: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f82b4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f82b8: ldr             x1, [x1, #0xc38]
    // 0x4f82bc: r0 = Generator()
    //     0x4f82bc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f82c0: mov             x2, x0
    // 0x4f82c4: ldur            x0, [fp, #-0x38]
    // 0x4f82c8: stur            x2, [fp, #-0x30]
    // 0x4f82cc: StoreField: r2->field_b = r0
    //     0x4f82cc: stur            w0, [x2, #0xb]
    // 0x4f82d0: r1 = <Chapter12Stat>
    //     0x4f82d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f82d4: ldr             x1, [x1, #0xef0]
    // 0x4f82d8: r0 = UpgradeData()
    //     0x4f82d8: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f82dc: mov             x3, x0
    // 0x4f82e0: ldur            x0, [fp, #-0x20]
    // 0x4f82e4: stur            x3, [fp, #-0x38]
    // 0x4f82e8: StoreField: r3->field_b = r0
    //     0x4f82e8: stur            w0, [x3, #0xb]
    // 0x4f82ec: ldur            x0, [fp, #-0x28]
    // 0x4f82f0: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f82f0: stur            w0, [x3, #0x17]
    // 0x4f82f4: r0 = Instance_IconData
    //     0x4f82f4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15fd0] Obj!IconData@82ff71
    //     0x4f82f8: ldr             x0, [x0, #0xfd0]
    // 0x4f82fc: StoreField: r3->field_13 = r0
    //     0x4f82fc: stur            w0, [x3, #0x13]
    // 0x4f8300: ldur            x0, [fp, #-0x30]
    // 0x4f8304: StoreField: r3->field_f = r0
    //     0x4f8304: stur            w0, [x3, #0xf]
    // 0x4f8308: r1 = Function '<anonymous closure>':.
    //     0x4f8308: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fd8] AnonymousClosure: (0x4f99c0), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f830c: ldr             x1, [x1, #0xfd8]
    // 0x4f8310: r2 = Null
    //     0x4f8310: mov             x2, NULL
    // 0x4f8314: r0 = AllocateClosure()
    //     0x4f8314: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8318: mov             x1, x0
    // 0x4f831c: ldur            x0, [fp, #-0x38]
    // 0x4f8320: StoreField: r0->field_1b = r1
    //     0x4f8320: stur            w1, [x0, #0x1b]
    // 0x4f8324: ldur            x1, [fp, #-0x18]
    // 0x4f8328: ArrayStore: r1[37] = r0  ; List_4
    //     0x4f8328: add             x25, x1, #0xa3
    //     0x4f832c: str             w0, [x25]
    //     0x4f8330: tbz             w0, #0, #0x4f834c
    //     0x4f8334: ldurb           w16, [x1, #-1]
    //     0x4f8338: ldurb           w17, [x0, #-1]
    //     0x4f833c: and             x16, x17, x16, lsr #2
    //     0x4f8340: tst             x16, HEAP, lsr #32
    //     0x4f8344: b.eq            #0x4f834c
    //     0x4f8348: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f834c: ldur            x0, [fp, #-0x18]
    // 0x4f8350: r16 = 232
    //     0x4f8350: movz            x16, #0xe8
    // 0x4f8354: StoreField: r0->field_a7 = r16
    //     0x4f8354: stur            w16, [x0, #0xa7]
    // 0x4f8358: r1 = "Foresnics"
    //     0x4f8358: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fe0] "Foresnics"
    //     0x4f835c: ldr             x1, [x1, #0xfe0]
    // 0x4f8360: r0 = autoString()
    //     0x4f8360: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8364: r1 = Function '<anonymous closure>':.
    //     0x4f8364: add             x1, PP, #0x15, lsl #12  ; [pp+0x15fe8] AnonymousClosure: (0x4f99b4), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8368: ldr             x1, [x1, #0xfe8]
    // 0x4f836c: r2 = Null
    //     0x4f836c: mov             x2, NULL
    // 0x4f8370: stur            x0, [fp, #-0x20]
    // 0x4f8374: r0 = AllocateClosure()
    //     0x4f8374: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8378: r1 = <String>
    //     0x4f8378: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f837c: stur            x0, [fp, #-0x28]
    // 0x4f8380: r0 = Generator()
    //     0x4f8380: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8384: ldur            x2, [fp, #-0x28]
    // 0x4f8388: r3 = Null
    //     0x4f8388: mov             x3, NULL
    // 0x4f838c: stur            x0, [fp, #-0x28]
    // 0x4f8390: r0 = AllocateRecord2()
    //     0x4f8390: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8394: mov             x1, x0
    // 0x4f8398: ldur            x0, [fp, #-0x28]
    // 0x4f839c: StoreField: r0->field_f = r1
    //     0x4f839c: stur            w1, [x0, #0xf]
    // 0x4f83a0: r1 = Null
    //     0x4f83a0: mov             x1, NULL
    // 0x4f83a4: r2 = 2
    //     0x4f83a4: movz            x2, #0x2
    // 0x4f83a8: r0 = AllocateArray()
    //     0x4f83a8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f83ac: stur            x0, [fp, #-0x30]
    // 0x4f83b0: r16 = Instance_Tuple2
    //     0x4f83b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ff0] Obj!Tuple2<Chapter12Stat, CustomNum>@823031
    //     0x4f83b4: ldr             x16, [x16, #0xff0]
    // 0x4f83b8: StoreField: r0->field_f = r16
    //     0x4f83b8: stur            w16, [x0, #0xf]
    // 0x4f83bc: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f83bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f83c0: ldr             x1, [x1, #0xc38]
    // 0x4f83c4: r0 = AllocateGrowableArray()
    //     0x4f83c4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f83c8: mov             x2, x0
    // 0x4f83cc: ldur            x0, [fp, #-0x30]
    // 0x4f83d0: stur            x2, [fp, #-0x38]
    // 0x4f83d4: StoreField: r2->field_f = r0
    //     0x4f83d4: stur            w0, [x2, #0xf]
    // 0x4f83d8: r0 = 2
    //     0x4f83d8: movz            x0, #0x2
    // 0x4f83dc: StoreField: r2->field_b = r0
    //     0x4f83dc: stur            w0, [x2, #0xb]
    // 0x4f83e0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f83e0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f83e4: ldr             x1, [x1, #0xc38]
    // 0x4f83e8: r0 = Generator()
    //     0x4f83e8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f83ec: mov             x2, x0
    // 0x4f83f0: ldur            x0, [fp, #-0x38]
    // 0x4f83f4: stur            x2, [fp, #-0x30]
    // 0x4f83f8: StoreField: r2->field_b = r0
    //     0x4f83f8: stur            w0, [x2, #0xb]
    // 0x4f83fc: r1 = <Chapter12Stat>
    //     0x4f83fc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8400: ldr             x1, [x1, #0xef0]
    // 0x4f8404: r0 = UpgradeData()
    //     0x4f8404: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8408: mov             x3, x0
    // 0x4f840c: ldur            x0, [fp, #-0x20]
    // 0x4f8410: stur            x3, [fp, #-0x38]
    // 0x4f8414: StoreField: r3->field_b = r0
    //     0x4f8414: stur            w0, [x3, #0xb]
    // 0x4f8418: ldur            x0, [fp, #-0x28]
    // 0x4f841c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f841c: stur            w0, [x3, #0x17]
    // 0x4f8420: r0 = Instance_IconData
    //     0x4f8420: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ff8] Obj!IconData@82ff51
    //     0x4f8424: ldr             x0, [x0, #0xff8]
    // 0x4f8428: StoreField: r3->field_13 = r0
    //     0x4f8428: stur            w0, [x3, #0x13]
    // 0x4f842c: ldur            x0, [fp, #-0x30]
    // 0x4f8430: StoreField: r3->field_f = r0
    //     0x4f8430: stur            w0, [x3, #0xf]
    // 0x4f8434: ldur            x2, [fp, #-0x10]
    // 0x4f8438: r1 = Function '<anonymous closure>':.
    //     0x4f8438: add             x1, PP, #0x16, lsl #12  ; [pp+0x16000] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f843c: ldr             x1, [x1]
    // 0x4f8440: r0 = AllocateClosure()
    //     0x4f8440: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8444: mov             x1, x0
    // 0x4f8448: ldur            x0, [fp, #-0x38]
    // 0x4f844c: StoreField: r0->field_1b = r1
    //     0x4f844c: stur            w1, [x0, #0x1b]
    // 0x4f8450: ldur            x1, [fp, #-0x18]
    // 0x4f8454: ArrayStore: r1[39] = r0  ; List_4
    //     0x4f8454: add             x25, x1, #0xab
    //     0x4f8458: str             w0, [x25]
    //     0x4f845c: tbz             w0, #0, #0x4f8478
    //     0x4f8460: ldurb           w16, [x1, #-1]
    //     0x4f8464: ldurb           w17, [x0, #-1]
    //     0x4f8468: and             x16, x17, x16, lsr #2
    //     0x4f846c: tst             x16, HEAP, lsr #32
    //     0x4f8470: b.eq            #0x4f8478
    //     0x4f8474: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8478: ldur            x0, [fp, #-0x18]
    // 0x4f847c: r16 = 234
    //     0x4f847c: movz            x16, #0xea
    // 0x4f8480: StoreField: r0->field_af = r16
    //     0x4f8480: stur            w16, [x0, #0xaf]
    // 0x4f8484: r1 = "Code Analysis"
    //     0x4f8484: add             x1, PP, #0x16, lsl #12  ; [pp+0x16008] "Code Analysis"
    //     0x4f8488: ldr             x1, [x1, #8]
    // 0x4f848c: r0 = autoString()
    //     0x4f848c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8490: r1 = Function '<anonymous closure>':.
    //     0x4f8490: add             x1, PP, #0x16, lsl #12  ; [pp+0x16010] AnonymousClosure: (0x4f99a8), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8494: ldr             x1, [x1, #0x10]
    // 0x4f8498: r2 = Null
    //     0x4f8498: mov             x2, NULL
    // 0x4f849c: stur            x0, [fp, #-0x20]
    // 0x4f84a0: r0 = AllocateClosure()
    //     0x4f84a0: bl              #0x826750  ; AllocateClosureStub
    // 0x4f84a4: r1 = <String>
    //     0x4f84a4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f84a8: stur            x0, [fp, #-0x28]
    // 0x4f84ac: r0 = Generator()
    //     0x4f84ac: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f84b0: ldur            x2, [fp, #-0x28]
    // 0x4f84b4: r3 = Null
    //     0x4f84b4: mov             x3, NULL
    // 0x4f84b8: stur            x0, [fp, #-0x28]
    // 0x4f84bc: r0 = AllocateRecord2()
    //     0x4f84bc: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f84c0: mov             x1, x0
    // 0x4f84c4: ldur            x0, [fp, #-0x28]
    // 0x4f84c8: StoreField: r0->field_f = r1
    //     0x4f84c8: stur            w1, [x0, #0xf]
    // 0x4f84cc: r1 = Null
    //     0x4f84cc: mov             x1, NULL
    // 0x4f84d0: r2 = 2
    //     0x4f84d0: movz            x2, #0x2
    // 0x4f84d4: r0 = AllocateArray()
    //     0x4f84d4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f84d8: stur            x0, [fp, #-0x30]
    // 0x4f84dc: r16 = Instance_Tuple2
    //     0x4f84dc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16018] Obj!Tuple2<Chapter12Stat, CustomNum>@823011
    //     0x4f84e0: ldr             x16, [x16, #0x18]
    // 0x4f84e4: StoreField: r0->field_f = r16
    //     0x4f84e4: stur            w16, [x0, #0xf]
    // 0x4f84e8: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f84e8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f84ec: ldr             x1, [x1, #0xc38]
    // 0x4f84f0: r0 = AllocateGrowableArray()
    //     0x4f84f0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f84f4: mov             x2, x0
    // 0x4f84f8: ldur            x0, [fp, #-0x30]
    // 0x4f84fc: stur            x2, [fp, #-0x38]
    // 0x4f8500: StoreField: r2->field_f = r0
    //     0x4f8500: stur            w0, [x2, #0xf]
    // 0x4f8504: r0 = 2
    //     0x4f8504: movz            x0, #0x2
    // 0x4f8508: StoreField: r2->field_b = r0
    //     0x4f8508: stur            w0, [x2, #0xb]
    // 0x4f850c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f850c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8510: ldr             x1, [x1, #0xc38]
    // 0x4f8514: r0 = Generator()
    //     0x4f8514: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8518: mov             x2, x0
    // 0x4f851c: ldur            x0, [fp, #-0x38]
    // 0x4f8520: stur            x2, [fp, #-0x30]
    // 0x4f8524: StoreField: r2->field_b = r0
    //     0x4f8524: stur            w0, [x2, #0xb]
    // 0x4f8528: r1 = <Chapter12Stat>
    //     0x4f8528: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f852c: ldr             x1, [x1, #0xef0]
    // 0x4f8530: r0 = UpgradeData()
    //     0x4f8530: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8534: mov             x3, x0
    // 0x4f8538: ldur            x0, [fp, #-0x20]
    // 0x4f853c: stur            x3, [fp, #-0x38]
    // 0x4f8540: StoreField: r3->field_b = r0
    //     0x4f8540: stur            w0, [x3, #0xb]
    // 0x4f8544: ldur            x0, [fp, #-0x28]
    // 0x4f8548: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8548: stur            w0, [x3, #0x17]
    // 0x4f854c: r0 = Instance_IconData
    //     0x4f854c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14ba0] Obj!IconData@82fb91
    //     0x4f8550: ldr             x0, [x0, #0xba0]
    // 0x4f8554: StoreField: r3->field_13 = r0
    //     0x4f8554: stur            w0, [x3, #0x13]
    // 0x4f8558: ldur            x0, [fp, #-0x30]
    // 0x4f855c: StoreField: r3->field_f = r0
    //     0x4f855c: stur            w0, [x3, #0xf]
    // 0x4f8560: ldur            x2, [fp, #-0x10]
    // 0x4f8564: r1 = Function '<anonymous closure>':.
    //     0x4f8564: add             x1, PP, #0x16, lsl #12  ; [pp+0x16020] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8568: ldr             x1, [x1, #0x20]
    // 0x4f856c: r0 = AllocateClosure()
    //     0x4f856c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8570: mov             x1, x0
    // 0x4f8574: ldur            x0, [fp, #-0x38]
    // 0x4f8578: StoreField: r0->field_1b = r1
    //     0x4f8578: stur            w1, [x0, #0x1b]
    // 0x4f857c: ldur            x1, [fp, #-0x18]
    // 0x4f8580: ArrayStore: r1[41] = r0  ; List_4
    //     0x4f8580: add             x25, x1, #0xb3
    //     0x4f8584: str             w0, [x25]
    //     0x4f8588: tbz             w0, #0, #0x4f85a4
    //     0x4f858c: ldurb           w16, [x1, #-1]
    //     0x4f8590: ldurb           w17, [x0, #-1]
    //     0x4f8594: and             x16, x17, x16, lsr #2
    //     0x4f8598: tst             x16, HEAP, lsr #32
    //     0x4f859c: b.eq            #0x4f85a4
    //     0x4f85a0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f85a4: ldur            x0, [fp, #-0x18]
    // 0x4f85a8: r16 = 236
    //     0x4f85a8: movz            x16, #0xec
    // 0x4f85ac: StoreField: r0->field_b7 = r16
    //     0x4f85ac: stur            w16, [x0, #0xb7]
    // 0x4f85b0: r1 = "Records"
    //     0x4f85b0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16028] "Records"
    //     0x4f85b4: ldr             x1, [x1, #0x28]
    // 0x4f85b8: r0 = autoString()
    //     0x4f85b8: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f85bc: r1 = Function '<anonymous closure>':.
    //     0x4f85bc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16030] AnonymousClosure: (0x4f999c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f85c0: ldr             x1, [x1, #0x30]
    // 0x4f85c4: r2 = Null
    //     0x4f85c4: mov             x2, NULL
    // 0x4f85c8: stur            x0, [fp, #-0x20]
    // 0x4f85cc: r0 = AllocateClosure()
    //     0x4f85cc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f85d0: r1 = <String>
    //     0x4f85d0: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f85d4: stur            x0, [fp, #-0x28]
    // 0x4f85d8: r0 = Generator()
    //     0x4f85d8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f85dc: ldur            x2, [fp, #-0x28]
    // 0x4f85e0: r3 = Null
    //     0x4f85e0: mov             x3, NULL
    // 0x4f85e4: stur            x0, [fp, #-0x28]
    // 0x4f85e8: r0 = AllocateRecord2()
    //     0x4f85e8: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f85ec: mov             x1, x0
    // 0x4f85f0: ldur            x0, [fp, #-0x28]
    // 0x4f85f4: StoreField: r0->field_f = r1
    //     0x4f85f4: stur            w1, [x0, #0xf]
    // 0x4f85f8: r1 = Null
    //     0x4f85f8: mov             x1, NULL
    // 0x4f85fc: r2 = 2
    //     0x4f85fc: movz            x2, #0x2
    // 0x4f8600: r0 = AllocateArray()
    //     0x4f8600: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8604: stur            x0, [fp, #-0x30]
    // 0x4f8608: r16 = Instance_Tuple2
    //     0x4f8608: add             x16, PP, #0x16, lsl #12  ; [pp+0x16038] Obj!Tuple2<Chapter12Stat, CustomNum>@822ff1
    //     0x4f860c: ldr             x16, [x16, #0x38]
    // 0x4f8610: StoreField: r0->field_f = r16
    //     0x4f8610: stur            w16, [x0, #0xf]
    // 0x4f8614: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8614: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8618: ldr             x1, [x1, #0xc38]
    // 0x4f861c: r0 = AllocateGrowableArray()
    //     0x4f861c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8620: mov             x2, x0
    // 0x4f8624: ldur            x0, [fp, #-0x30]
    // 0x4f8628: stur            x2, [fp, #-0x38]
    // 0x4f862c: StoreField: r2->field_f = r0
    //     0x4f862c: stur            w0, [x2, #0xf]
    // 0x4f8630: r0 = 2
    //     0x4f8630: movz            x0, #0x2
    // 0x4f8634: StoreField: r2->field_b = r0
    //     0x4f8634: stur            w0, [x2, #0xb]
    // 0x4f8638: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8638: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f863c: ldr             x1, [x1, #0xc38]
    // 0x4f8640: r0 = Generator()
    //     0x4f8640: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8644: mov             x2, x0
    // 0x4f8648: ldur            x0, [fp, #-0x38]
    // 0x4f864c: stur            x2, [fp, #-0x30]
    // 0x4f8650: StoreField: r2->field_b = r0
    //     0x4f8650: stur            w0, [x2, #0xb]
    // 0x4f8654: r1 = <Chapter12Stat>
    //     0x4f8654: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8658: ldr             x1, [x1, #0xef0]
    // 0x4f865c: r0 = UpgradeData()
    //     0x4f865c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8660: mov             x3, x0
    // 0x4f8664: ldur            x0, [fp, #-0x20]
    // 0x4f8668: stur            x3, [fp, #-0x38]
    // 0x4f866c: StoreField: r3->field_b = r0
    //     0x4f866c: stur            w0, [x3, #0xb]
    // 0x4f8670: ldur            x0, [fp, #-0x28]
    // 0x4f8674: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8674: stur            w0, [x3, #0x17]
    // 0x4f8678: r0 = Instance_IconData
    //     0x4f8678: add             x0, PP, #0x14, lsl #12  ; [pp+0x14c40] Obj!IconData@82fb11
    //     0x4f867c: ldr             x0, [x0, #0xc40]
    // 0x4f8680: StoreField: r3->field_13 = r0
    //     0x4f8680: stur            w0, [x3, #0x13]
    // 0x4f8684: ldur            x0, [fp, #-0x30]
    // 0x4f8688: StoreField: r3->field_f = r0
    //     0x4f8688: stur            w0, [x3, #0xf]
    // 0x4f868c: ldur            x2, [fp, #-0x10]
    // 0x4f8690: r1 = Function '<anonymous closure>':.
    //     0x4f8690: add             x1, PP, #0x16, lsl #12  ; [pp+0x16040] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8694: ldr             x1, [x1, #0x40]
    // 0x4f8698: r0 = AllocateClosure()
    //     0x4f8698: bl              #0x826750  ; AllocateClosureStub
    // 0x4f869c: mov             x1, x0
    // 0x4f86a0: ldur            x0, [fp, #-0x38]
    // 0x4f86a4: StoreField: r0->field_1b = r1
    //     0x4f86a4: stur            w1, [x0, #0x1b]
    // 0x4f86a8: ldur            x1, [fp, #-0x18]
    // 0x4f86ac: ArrayStore: r1[43] = r0  ; List_4
    //     0x4f86ac: add             x25, x1, #0xbb
    //     0x4f86b0: str             w0, [x25]
    //     0x4f86b4: tbz             w0, #0, #0x4f86d0
    //     0x4f86b8: ldurb           w16, [x1, #-1]
    //     0x4f86bc: ldurb           w17, [x0, #-1]
    //     0x4f86c0: and             x16, x17, x16, lsr #2
    //     0x4f86c4: tst             x16, HEAP, lsr #32
    //     0x4f86c8: b.eq            #0x4f86d0
    //     0x4f86cc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f86d0: ldur            x0, [fp, #-0x18]
    // 0x4f86d4: r16 = 238
    //     0x4f86d4: movz            x16, #0xee
    // 0x4f86d8: StoreField: r0->field_bf = r16
    //     0x4f86d8: stur            w16, [x0, #0xbf]
    // 0x4f86dc: r1 = "Backend Logistics"
    //     0x4f86dc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16048] "Backend Logistics"
    //     0x4f86e0: ldr             x1, [x1, #0x48]
    // 0x4f86e4: r0 = autoString()
    //     0x4f86e4: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f86e8: r1 = Function '<anonymous closure>':.
    //     0x4f86e8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16050] AnonymousClosure: (0x4f9990), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f86ec: ldr             x1, [x1, #0x50]
    // 0x4f86f0: r2 = Null
    //     0x4f86f0: mov             x2, NULL
    // 0x4f86f4: stur            x0, [fp, #-0x20]
    // 0x4f86f8: r0 = AllocateClosure()
    //     0x4f86f8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f86fc: r1 = <String>
    //     0x4f86fc: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8700: stur            x0, [fp, #-0x28]
    // 0x4f8704: r0 = Generator()
    //     0x4f8704: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8708: ldur            x2, [fp, #-0x28]
    // 0x4f870c: r3 = Null
    //     0x4f870c: mov             x3, NULL
    // 0x4f8710: stur            x0, [fp, #-0x28]
    // 0x4f8714: r0 = AllocateRecord2()
    //     0x4f8714: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8718: mov             x1, x0
    // 0x4f871c: ldur            x0, [fp, #-0x28]
    // 0x4f8720: StoreField: r0->field_f = r1
    //     0x4f8720: stur            w1, [x0, #0xf]
    // 0x4f8724: r1 = Null
    //     0x4f8724: mov             x1, NULL
    // 0x4f8728: r2 = 2
    //     0x4f8728: movz            x2, #0x2
    // 0x4f872c: r0 = AllocateArray()
    //     0x4f872c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8730: stur            x0, [fp, #-0x30]
    // 0x4f8734: r16 = Instance_Tuple2
    //     0x4f8734: add             x16, PP, #0x16, lsl #12  ; [pp+0x16058] Obj!Tuple2<Chapter12Stat, CustomNum>@822fd1
    //     0x4f8738: ldr             x16, [x16, #0x58]
    // 0x4f873c: StoreField: r0->field_f = r16
    //     0x4f873c: stur            w16, [x0, #0xf]
    // 0x4f8740: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8740: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8744: ldr             x1, [x1, #0xc38]
    // 0x4f8748: r0 = AllocateGrowableArray()
    //     0x4f8748: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f874c: mov             x2, x0
    // 0x4f8750: ldur            x0, [fp, #-0x30]
    // 0x4f8754: stur            x2, [fp, #-0x38]
    // 0x4f8758: StoreField: r2->field_f = r0
    //     0x4f8758: stur            w0, [x2, #0xf]
    // 0x4f875c: r0 = 2
    //     0x4f875c: movz            x0, #0x2
    // 0x4f8760: StoreField: r2->field_b = r0
    //     0x4f8760: stur            w0, [x2, #0xb]
    // 0x4f8764: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8764: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8768: ldr             x1, [x1, #0xc38]
    // 0x4f876c: r0 = Generator()
    //     0x4f876c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8770: mov             x2, x0
    // 0x4f8774: ldur            x0, [fp, #-0x38]
    // 0x4f8778: stur            x2, [fp, #-0x30]
    // 0x4f877c: StoreField: r2->field_b = r0
    //     0x4f877c: stur            w0, [x2, #0xb]
    // 0x4f8780: r1 = <Chapter12Stat>
    //     0x4f8780: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8784: ldr             x1, [x1, #0xef0]
    // 0x4f8788: r0 = UpgradeData()
    //     0x4f8788: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f878c: mov             x3, x0
    // 0x4f8790: ldur            x0, [fp, #-0x20]
    // 0x4f8794: stur            x3, [fp, #-0x38]
    // 0x4f8798: StoreField: r3->field_b = r0
    //     0x4f8798: stur            w0, [x3, #0xb]
    // 0x4f879c: ldur            x0, [fp, #-0x28]
    // 0x4f87a0: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f87a0: stur            w0, [x3, #0x17]
    // 0x4f87a4: r0 = Instance_IconData
    //     0x4f87a4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16060] Obj!IconData@82ff31
    //     0x4f87a8: ldr             x0, [x0, #0x60]
    // 0x4f87ac: StoreField: r3->field_13 = r0
    //     0x4f87ac: stur            w0, [x3, #0x13]
    // 0x4f87b0: ldur            x0, [fp, #-0x30]
    // 0x4f87b4: StoreField: r3->field_f = r0
    //     0x4f87b4: stur            w0, [x3, #0xf]
    // 0x4f87b8: ldur            x2, [fp, #-0x10]
    // 0x4f87bc: r1 = Function '<anonymous closure>':.
    //     0x4f87bc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16068] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f87c0: ldr             x1, [x1, #0x68]
    // 0x4f87c4: r0 = AllocateClosure()
    //     0x4f87c4: bl              #0x826750  ; AllocateClosureStub
    // 0x4f87c8: mov             x1, x0
    // 0x4f87cc: ldur            x0, [fp, #-0x38]
    // 0x4f87d0: StoreField: r0->field_1b = r1
    //     0x4f87d0: stur            w1, [x0, #0x1b]
    // 0x4f87d4: ldur            x1, [fp, #-0x18]
    // 0x4f87d8: ArrayStore: r1[45] = r0  ; List_4
    //     0x4f87d8: add             x25, x1, #0xc3
    //     0x4f87dc: str             w0, [x25]
    //     0x4f87e0: tbz             w0, #0, #0x4f87fc
    //     0x4f87e4: ldurb           w16, [x1, #-1]
    //     0x4f87e8: ldurb           w17, [x0, #-1]
    //     0x4f87ec: and             x16, x17, x16, lsr #2
    //     0x4f87f0: tst             x16, HEAP, lsr #32
    //     0x4f87f4: b.eq            #0x4f87fc
    //     0x4f87f8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f87fc: ldur            x0, [fp, #-0x18]
    // 0x4f8800: r16 = 406
    //     0x4f8800: movz            x16, #0x196
    // 0x4f8804: StoreField: r0->field_c7 = r16
    //     0x4f8804: stur            w16, [x0, #0xc7]
    // 0x4f8808: r1 = "Network Analysis"
    //     0x4f8808: add             x1, PP, #0x16, lsl #12  ; [pp+0x16070] "Network Analysis"
    //     0x4f880c: ldr             x1, [x1, #0x70]
    // 0x4f8810: r0 = autoString()
    //     0x4f8810: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8814: r1 = Function '<anonymous closure>':.
    //     0x4f8814: add             x1, PP, #0x16, lsl #12  ; [pp+0x16078] AnonymousClosure: (0x4f9984), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8818: ldr             x1, [x1, #0x78]
    // 0x4f881c: r2 = Null
    //     0x4f881c: mov             x2, NULL
    // 0x4f8820: stur            x0, [fp, #-0x20]
    // 0x4f8824: r0 = AllocateClosure()
    //     0x4f8824: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8828: r1 = <String>
    //     0x4f8828: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f882c: stur            x0, [fp, #-0x28]
    // 0x4f8830: r0 = Generator()
    //     0x4f8830: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8834: ldur            x2, [fp, #-0x28]
    // 0x4f8838: r3 = Null
    //     0x4f8838: mov             x3, NULL
    // 0x4f883c: stur            x0, [fp, #-0x28]
    // 0x4f8840: r0 = AllocateRecord2()
    //     0x4f8840: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8844: mov             x1, x0
    // 0x4f8848: ldur            x0, [fp, #-0x28]
    // 0x4f884c: StoreField: r0->field_f = r1
    //     0x4f884c: stur            w1, [x0, #0xf]
    // 0x4f8850: r1 = Null
    //     0x4f8850: mov             x1, NULL
    // 0x4f8854: r2 = 2
    //     0x4f8854: movz            x2, #0x2
    // 0x4f8858: r0 = AllocateArray()
    //     0x4f8858: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f885c: stur            x0, [fp, #-0x30]
    // 0x4f8860: r16 = Instance_Tuple2
    //     0x4f8860: add             x16, PP, #0x16, lsl #12  ; [pp+0x16080] Obj!Tuple2<Chapter12Stat, CustomNum>@822fb1
    //     0x4f8864: ldr             x16, [x16, #0x80]
    // 0x4f8868: StoreField: r0->field_f = r16
    //     0x4f8868: stur            w16, [x0, #0xf]
    // 0x4f886c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f886c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8870: ldr             x1, [x1, #0xc38]
    // 0x4f8874: r0 = AllocateGrowableArray()
    //     0x4f8874: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8878: mov             x2, x0
    // 0x4f887c: ldur            x0, [fp, #-0x30]
    // 0x4f8880: stur            x2, [fp, #-0x38]
    // 0x4f8884: StoreField: r2->field_f = r0
    //     0x4f8884: stur            w0, [x2, #0xf]
    // 0x4f8888: r0 = 2
    //     0x4f8888: movz            x0, #0x2
    // 0x4f888c: StoreField: r2->field_b = r0
    //     0x4f888c: stur            w0, [x2, #0xb]
    // 0x4f8890: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8890: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8894: ldr             x1, [x1, #0xc38]
    // 0x4f8898: r0 = Generator()
    //     0x4f8898: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f889c: mov             x2, x0
    // 0x4f88a0: ldur            x0, [fp, #-0x38]
    // 0x4f88a4: stur            x2, [fp, #-0x30]
    // 0x4f88a8: StoreField: r2->field_b = r0
    //     0x4f88a8: stur            w0, [x2, #0xb]
    // 0x4f88ac: r1 = <Chapter12Stat>
    //     0x4f88ac: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f88b0: ldr             x1, [x1, #0xef0]
    // 0x4f88b4: r0 = UpgradeData()
    //     0x4f88b4: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f88b8: mov             x3, x0
    // 0x4f88bc: ldur            x0, [fp, #-0x20]
    // 0x4f88c0: stur            x3, [fp, #-0x38]
    // 0x4f88c4: StoreField: r3->field_b = r0
    //     0x4f88c4: stur            w0, [x3, #0xb]
    // 0x4f88c8: ldur            x0, [fp, #-0x28]
    // 0x4f88cc: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f88cc: stur            w0, [x3, #0x17]
    // 0x4f88d0: r0 = Instance_IconData
    //     0x4f88d0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16088] Obj!IconData@82f3d1
    //     0x4f88d4: ldr             x0, [x0, #0x88]
    // 0x4f88d8: StoreField: r3->field_13 = r0
    //     0x4f88d8: stur            w0, [x3, #0x13]
    // 0x4f88dc: ldur            x0, [fp, #-0x30]
    // 0x4f88e0: StoreField: r3->field_f = r0
    //     0x4f88e0: stur            w0, [x3, #0xf]
    // 0x4f88e4: ldur            x2, [fp, #-0x10]
    // 0x4f88e8: r1 = Function '<anonymous closure>':.
    //     0x4f88e8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16090] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f88ec: ldr             x1, [x1, #0x90]
    // 0x4f88f0: r0 = AllocateClosure()
    //     0x4f88f0: bl              #0x826750  ; AllocateClosureStub
    // 0x4f88f4: mov             x1, x0
    // 0x4f88f8: ldur            x0, [fp, #-0x38]
    // 0x4f88fc: StoreField: r0->field_1b = r1
    //     0x4f88fc: stur            w1, [x0, #0x1b]
    // 0x4f8900: ldur            x1, [fp, #-0x18]
    // 0x4f8904: ArrayStore: r1[47] = r0  ; List_4
    //     0x4f8904: add             x25, x1, #0xcb
    //     0x4f8908: str             w0, [x25]
    //     0x4f890c: tbz             w0, #0, #0x4f8928
    //     0x4f8910: ldurb           w16, [x1, #-1]
    //     0x4f8914: ldurb           w17, [x0, #-1]
    //     0x4f8918: and             x16, x17, x16, lsr #2
    //     0x4f891c: tst             x16, HEAP, lsr #32
    //     0x4f8920: b.eq            #0x4f8928
    //     0x4f8924: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8928: ldur            x0, [fp, #-0x18]
    // 0x4f892c: r16 = 240
    //     0x4f892c: movz            x16, #0xf0
    // 0x4f8930: StoreField: r0->field_cf = r16
    //     0x4f8930: stur            w16, [x0, #0xcf]
    // 0x4f8934: r1 = "Efficiency Gains"
    //     0x4f8934: add             x1, PP, #0x16, lsl #12  ; [pp+0x16098] "Efficiency Gains"
    //     0x4f8938: ldr             x1, [x1, #0x98]
    // 0x4f893c: r0 = autoString()
    //     0x4f893c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8940: r1 = Function '<anonymous closure>':.
    //     0x4f8940: add             x1, PP, #0x16, lsl #12  ; [pp+0x160a0] AnonymousClosure: (0x4f9978), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8944: ldr             x1, [x1, #0xa0]
    // 0x4f8948: r2 = Null
    //     0x4f8948: mov             x2, NULL
    // 0x4f894c: stur            x0, [fp, #-0x20]
    // 0x4f8950: r0 = AllocateClosure()
    //     0x4f8950: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8954: r1 = <String>
    //     0x4f8954: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8958: stur            x0, [fp, #-0x28]
    // 0x4f895c: r0 = Generator()
    //     0x4f895c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8960: ldur            x2, [fp, #-0x28]
    // 0x4f8964: r3 = Null
    //     0x4f8964: mov             x3, NULL
    // 0x4f8968: stur            x0, [fp, #-0x28]
    // 0x4f896c: r0 = AllocateRecord2()
    //     0x4f896c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8970: mov             x1, x0
    // 0x4f8974: ldur            x0, [fp, #-0x28]
    // 0x4f8978: StoreField: r0->field_f = r1
    //     0x4f8978: stur            w1, [x0, #0xf]
    // 0x4f897c: r1 = Null
    //     0x4f897c: mov             x1, NULL
    // 0x4f8980: r2 = 2
    //     0x4f8980: movz            x2, #0x2
    // 0x4f8984: r0 = AllocateArray()
    //     0x4f8984: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8988: stur            x0, [fp, #-0x30]
    // 0x4f898c: r16 = Instance_Tuple2
    //     0x4f898c: add             x16, PP, #0x16, lsl #12  ; [pp+0x160a8] Obj!Tuple2<Chapter12Stat, CustomNum>@822f91
    //     0x4f8990: ldr             x16, [x16, #0xa8]
    // 0x4f8994: StoreField: r0->field_f = r16
    //     0x4f8994: stur            w16, [x0, #0xf]
    // 0x4f8998: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8998: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f899c: ldr             x1, [x1, #0xc38]
    // 0x4f89a0: r0 = AllocateGrowableArray()
    //     0x4f89a0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f89a4: mov             x2, x0
    // 0x4f89a8: ldur            x0, [fp, #-0x30]
    // 0x4f89ac: stur            x2, [fp, #-0x38]
    // 0x4f89b0: StoreField: r2->field_f = r0
    //     0x4f89b0: stur            w0, [x2, #0xf]
    // 0x4f89b4: r0 = 2
    //     0x4f89b4: movz            x0, #0x2
    // 0x4f89b8: StoreField: r2->field_b = r0
    //     0x4f89b8: stur            w0, [x2, #0xb]
    // 0x4f89bc: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f89bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f89c0: ldr             x1, [x1, #0xc38]
    // 0x4f89c4: r0 = Generator()
    //     0x4f89c4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f89c8: mov             x2, x0
    // 0x4f89cc: ldur            x0, [fp, #-0x38]
    // 0x4f89d0: stur            x2, [fp, #-0x30]
    // 0x4f89d4: StoreField: r2->field_b = r0
    //     0x4f89d4: stur            w0, [x2, #0xb]
    // 0x4f89d8: r1 = <Chapter12Stat>
    //     0x4f89d8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f89dc: ldr             x1, [x1, #0xef0]
    // 0x4f89e0: r0 = UpgradeData()
    //     0x4f89e0: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f89e4: mov             x3, x0
    // 0x4f89e8: ldur            x0, [fp, #-0x20]
    // 0x4f89ec: stur            x3, [fp, #-0x38]
    // 0x4f89f0: StoreField: r3->field_b = r0
    //     0x4f89f0: stur            w0, [x3, #0xb]
    // 0x4f89f4: ldur            x0, [fp, #-0x28]
    // 0x4f89f8: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f89f8: stur            w0, [x3, #0x17]
    // 0x4f89fc: r0 = Instance_IconData
    //     0x4f89fc: add             x0, PP, #0x16, lsl #12  ; [pp+0x160b0] Obj!IconData@82ff11
    //     0x4f8a00: ldr             x0, [x0, #0xb0]
    // 0x4f8a04: StoreField: r3->field_13 = r0
    //     0x4f8a04: stur            w0, [x3, #0x13]
    // 0x4f8a08: ldur            x0, [fp, #-0x30]
    // 0x4f8a0c: StoreField: r3->field_f = r0
    //     0x4f8a0c: stur            w0, [x3, #0xf]
    // 0x4f8a10: ldur            x2, [fp, #-0x10]
    // 0x4f8a14: r1 = Function '<anonymous closure>':.
    //     0x4f8a14: add             x1, PP, #0x16, lsl #12  ; [pp+0x160b8] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8a18: ldr             x1, [x1, #0xb8]
    // 0x4f8a1c: r0 = AllocateClosure()
    //     0x4f8a1c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8a20: mov             x1, x0
    // 0x4f8a24: ldur            x0, [fp, #-0x38]
    // 0x4f8a28: StoreField: r0->field_1b = r1
    //     0x4f8a28: stur            w1, [x0, #0x1b]
    // 0x4f8a2c: ldur            x1, [fp, #-0x18]
    // 0x4f8a30: ArrayStore: r1[49] = r0  ; List_4
    //     0x4f8a30: add             x25, x1, #0xd3
    //     0x4f8a34: str             w0, [x25]
    //     0x4f8a38: tbz             w0, #0, #0x4f8a54
    //     0x4f8a3c: ldurb           w16, [x1, #-1]
    //     0x4f8a40: ldurb           w17, [x0, #-1]
    //     0x4f8a44: and             x16, x17, x16, lsr #2
    //     0x4f8a48: tst             x16, HEAP, lsr #32
    //     0x4f8a4c: b.eq            #0x4f8a54
    //     0x4f8a50: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8a54: ldur            x0, [fp, #-0x18]
    // 0x4f8a58: r16 = 242
    //     0x4f8a58: movz            x16, #0xf2
    // 0x4f8a5c: StoreField: r0->field_d7 = r16
    //     0x4f8a5c: stur            w16, [x0, #0xd7]
    // 0x4f8a60: r1 = "Speedy Analysis"
    //     0x4f8a60: add             x1, PP, #0x16, lsl #12  ; [pp+0x160c0] "Speedy Analysis"
    //     0x4f8a64: ldr             x1, [x1, #0xc0]
    // 0x4f8a68: r0 = autoString()
    //     0x4f8a68: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8a6c: r1 = Function '<anonymous closure>':.
    //     0x4f8a6c: add             x1, PP, #0x16, lsl #12  ; [pp+0x160c8] AnonymousClosure: (0x4f996c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8a70: ldr             x1, [x1, #0xc8]
    // 0x4f8a74: r2 = Null
    //     0x4f8a74: mov             x2, NULL
    // 0x4f8a78: stur            x0, [fp, #-0x20]
    // 0x4f8a7c: r0 = AllocateClosure()
    //     0x4f8a7c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8a80: r1 = <String>
    //     0x4f8a80: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8a84: stur            x0, [fp, #-0x28]
    // 0x4f8a88: r0 = Generator()
    //     0x4f8a88: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8a8c: ldur            x2, [fp, #-0x28]
    // 0x4f8a90: r3 = Null
    //     0x4f8a90: mov             x3, NULL
    // 0x4f8a94: stur            x0, [fp, #-0x28]
    // 0x4f8a98: r0 = AllocateRecord2()
    //     0x4f8a98: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8a9c: mov             x1, x0
    // 0x4f8aa0: ldur            x0, [fp, #-0x28]
    // 0x4f8aa4: StoreField: r0->field_f = r1
    //     0x4f8aa4: stur            w1, [x0, #0xf]
    // 0x4f8aa8: r1 = Null
    //     0x4f8aa8: mov             x1, NULL
    // 0x4f8aac: r2 = 2
    //     0x4f8aac: movz            x2, #0x2
    // 0x4f8ab0: r0 = AllocateArray()
    //     0x4f8ab0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8ab4: stur            x0, [fp, #-0x30]
    // 0x4f8ab8: r16 = Instance_Tuple2
    //     0x4f8ab8: add             x16, PP, #0x16, lsl #12  ; [pp+0x160d0] Obj!Tuple2<Chapter12Stat, CustomNum>@822f71
    //     0x4f8abc: ldr             x16, [x16, #0xd0]
    // 0x4f8ac0: StoreField: r0->field_f = r16
    //     0x4f8ac0: stur            w16, [x0, #0xf]
    // 0x4f8ac4: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8ac4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8ac8: ldr             x1, [x1, #0xc38]
    // 0x4f8acc: r0 = AllocateGrowableArray()
    //     0x4f8acc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8ad0: mov             x2, x0
    // 0x4f8ad4: ldur            x0, [fp, #-0x30]
    // 0x4f8ad8: stur            x2, [fp, #-0x38]
    // 0x4f8adc: StoreField: r2->field_f = r0
    //     0x4f8adc: stur            w0, [x2, #0xf]
    // 0x4f8ae0: r0 = 2
    //     0x4f8ae0: movz            x0, #0x2
    // 0x4f8ae4: StoreField: r2->field_b = r0
    //     0x4f8ae4: stur            w0, [x2, #0xb]
    // 0x4f8ae8: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8ae8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8aec: ldr             x1, [x1, #0xc38]
    // 0x4f8af0: r0 = Generator()
    //     0x4f8af0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8af4: mov             x2, x0
    // 0x4f8af8: ldur            x0, [fp, #-0x38]
    // 0x4f8afc: stur            x2, [fp, #-0x30]
    // 0x4f8b00: StoreField: r2->field_b = r0
    //     0x4f8b00: stur            w0, [x2, #0xb]
    // 0x4f8b04: r1 = <Chapter12Stat>
    //     0x4f8b04: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8b08: ldr             x1, [x1, #0xef0]
    // 0x4f8b0c: r0 = UpgradeData()
    //     0x4f8b0c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8b10: mov             x3, x0
    // 0x4f8b14: ldur            x0, [fp, #-0x20]
    // 0x4f8b18: stur            x3, [fp, #-0x38]
    // 0x4f8b1c: StoreField: r3->field_b = r0
    //     0x4f8b1c: stur            w0, [x3, #0xb]
    // 0x4f8b20: ldur            x0, [fp, #-0x28]
    // 0x4f8b24: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8b24: stur            w0, [x3, #0x17]
    // 0x4f8b28: r0 = Instance_IconData
    //     0x4f8b28: add             x0, PP, #0x13, lsl #12  ; [pp+0x13fa8] Obj!IconData@82f411
    //     0x4f8b2c: ldr             x0, [x0, #0xfa8]
    // 0x4f8b30: StoreField: r3->field_13 = r0
    //     0x4f8b30: stur            w0, [x3, #0x13]
    // 0x4f8b34: ldur            x0, [fp, #-0x30]
    // 0x4f8b38: StoreField: r3->field_f = r0
    //     0x4f8b38: stur            w0, [x3, #0xf]
    // 0x4f8b3c: ldur            x2, [fp, #-0x10]
    // 0x4f8b40: r1 = Function '<anonymous closure>':.
    //     0x4f8b40: add             x1, PP, #0x16, lsl #12  ; [pp+0x160d8] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8b44: ldr             x1, [x1, #0xd8]
    // 0x4f8b48: r0 = AllocateClosure()
    //     0x4f8b48: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8b4c: mov             x1, x0
    // 0x4f8b50: ldur            x0, [fp, #-0x38]
    // 0x4f8b54: StoreField: r0->field_1b = r1
    //     0x4f8b54: stur            w1, [x0, #0x1b]
    // 0x4f8b58: ldur            x1, [fp, #-0x18]
    // 0x4f8b5c: ArrayStore: r1[51] = r0  ; List_4
    //     0x4f8b5c: add             x25, x1, #0xdb
    //     0x4f8b60: str             w0, [x25]
    //     0x4f8b64: tbz             w0, #0, #0x4f8b80
    //     0x4f8b68: ldurb           w16, [x1, #-1]
    //     0x4f8b6c: ldurb           w17, [x0, #-1]
    //     0x4f8b70: and             x16, x17, x16, lsr #2
    //     0x4f8b74: tst             x16, HEAP, lsr #32
    //     0x4f8b78: b.eq            #0x4f8b80
    //     0x4f8b7c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8b80: ldur            x0, [fp, #-0x18]
    // 0x4f8b84: r16 = 244
    //     0x4f8b84: movz            x16, #0xf4
    // 0x4f8b88: StoreField: r0->field_df = r16
    //     0x4f8b88: stur            w16, [x0, #0xdf]
    // 0x4f8b8c: r1 = "Reverse Development"
    //     0x4f8b8c: add             x1, PP, #0x16, lsl #12  ; [pp+0x160e0] "Reverse Development"
    //     0x4f8b90: ldr             x1, [x1, #0xe0]
    // 0x4f8b94: r0 = autoString()
    //     0x4f8b94: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8b98: r1 = Function '<anonymous closure>':.
    //     0x4f8b98: add             x1, PP, #0x16, lsl #12  ; [pp+0x160e8] AnonymousClosure: (0x4f9960), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8b9c: ldr             x1, [x1, #0xe8]
    // 0x4f8ba0: r2 = Null
    //     0x4f8ba0: mov             x2, NULL
    // 0x4f8ba4: stur            x0, [fp, #-0x20]
    // 0x4f8ba8: r0 = AllocateClosure()
    //     0x4f8ba8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8bac: r1 = <String>
    //     0x4f8bac: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8bb0: stur            x0, [fp, #-0x28]
    // 0x4f8bb4: r0 = Generator()
    //     0x4f8bb4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8bb8: ldur            x2, [fp, #-0x28]
    // 0x4f8bbc: r3 = Null
    //     0x4f8bbc: mov             x3, NULL
    // 0x4f8bc0: stur            x0, [fp, #-0x28]
    // 0x4f8bc4: r0 = AllocateRecord2()
    //     0x4f8bc4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8bc8: mov             x1, x0
    // 0x4f8bcc: ldur            x0, [fp, #-0x28]
    // 0x4f8bd0: StoreField: r0->field_f = r1
    //     0x4f8bd0: stur            w1, [x0, #0xf]
    // 0x4f8bd4: r1 = Null
    //     0x4f8bd4: mov             x1, NULL
    // 0x4f8bd8: r2 = 2
    //     0x4f8bd8: movz            x2, #0x2
    // 0x4f8bdc: r0 = AllocateArray()
    //     0x4f8bdc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8be0: stur            x0, [fp, #-0x30]
    // 0x4f8be4: r16 = Instance_Tuple2
    //     0x4f8be4: add             x16, PP, #0x16, lsl #12  ; [pp+0x160f0] Obj!Tuple2<Chapter12Stat, CustomNum>@822f51
    //     0x4f8be8: ldr             x16, [x16, #0xf0]
    // 0x4f8bec: StoreField: r0->field_f = r16
    //     0x4f8bec: stur            w16, [x0, #0xf]
    // 0x4f8bf0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8bf0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8bf4: ldr             x1, [x1, #0xc38]
    // 0x4f8bf8: r0 = AllocateGrowableArray()
    //     0x4f8bf8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8bfc: mov             x2, x0
    // 0x4f8c00: ldur            x0, [fp, #-0x30]
    // 0x4f8c04: stur            x2, [fp, #-0x38]
    // 0x4f8c08: StoreField: r2->field_f = r0
    //     0x4f8c08: stur            w0, [x2, #0xf]
    // 0x4f8c0c: r0 = 2
    //     0x4f8c0c: movz            x0, #0x2
    // 0x4f8c10: StoreField: r2->field_b = r0
    //     0x4f8c10: stur            w0, [x2, #0xb]
    // 0x4f8c14: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8c14: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8c18: ldr             x1, [x1, #0xc38]
    // 0x4f8c1c: r0 = Generator()
    //     0x4f8c1c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8c20: mov             x2, x0
    // 0x4f8c24: ldur            x0, [fp, #-0x38]
    // 0x4f8c28: stur            x2, [fp, #-0x30]
    // 0x4f8c2c: StoreField: r2->field_b = r0
    //     0x4f8c2c: stur            w0, [x2, #0xb]
    // 0x4f8c30: r1 = <Chapter12Stat>
    //     0x4f8c30: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8c34: ldr             x1, [x1, #0xef0]
    // 0x4f8c38: r0 = UpgradeData()
    //     0x4f8c38: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8c3c: mov             x3, x0
    // 0x4f8c40: ldur            x0, [fp, #-0x20]
    // 0x4f8c44: stur            x3, [fp, #-0x38]
    // 0x4f8c48: StoreField: r3->field_b = r0
    //     0x4f8c48: stur            w0, [x3, #0xb]
    // 0x4f8c4c: ldur            x0, [fp, #-0x28]
    // 0x4f8c50: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8c50: stur            w0, [x3, #0x17]
    // 0x4f8c54: r0 = Instance_IconData
    //     0x4f8c54: add             x0, PP, #0x16, lsl #12  ; [pp+0x160f8] Obj!IconData@82fef1
    //     0x4f8c58: ldr             x0, [x0, #0xf8]
    // 0x4f8c5c: StoreField: r3->field_13 = r0
    //     0x4f8c5c: stur            w0, [x3, #0x13]
    // 0x4f8c60: ldur            x0, [fp, #-0x30]
    // 0x4f8c64: StoreField: r3->field_f = r0
    //     0x4f8c64: stur            w0, [x3, #0xf]
    // 0x4f8c68: ldur            x2, [fp, #-0x10]
    // 0x4f8c6c: r1 = Function '<anonymous closure>':.
    //     0x4f8c6c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16100] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8c70: ldr             x1, [x1, #0x100]
    // 0x4f8c74: r0 = AllocateClosure()
    //     0x4f8c74: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8c78: mov             x1, x0
    // 0x4f8c7c: ldur            x0, [fp, #-0x38]
    // 0x4f8c80: StoreField: r0->field_1b = r1
    //     0x4f8c80: stur            w1, [x0, #0x1b]
    // 0x4f8c84: ldur            x1, [fp, #-0x18]
    // 0x4f8c88: ArrayStore: r1[53] = r0  ; List_4
    //     0x4f8c88: add             x25, x1, #0xe3
    //     0x4f8c8c: str             w0, [x25]
    //     0x4f8c90: tbz             w0, #0, #0x4f8cac
    //     0x4f8c94: ldurb           w16, [x1, #-1]
    //     0x4f8c98: ldurb           w17, [x0, #-1]
    //     0x4f8c9c: and             x16, x17, x16, lsr #2
    //     0x4f8ca0: tst             x16, HEAP, lsr #32
    //     0x4f8ca4: b.eq            #0x4f8cac
    //     0x4f8ca8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8cac: ldur            x0, [fp, #-0x18]
    // 0x4f8cb0: r16 = 246
    //     0x4f8cb0: movz            x16, #0xf6
    // 0x4f8cb4: StoreField: r0->field_e7 = r16
    //     0x4f8cb4: stur            w16, [x0, #0xe7]
    // 0x4f8cb8: r1 = "Downward Pressure"
    //     0x4f8cb8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16108] "Downward Pressure"
    //     0x4f8cbc: ldr             x1, [x1, #0x108]
    // 0x4f8cc0: r0 = autoString()
    //     0x4f8cc0: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8cc4: r1 = Function '<anonymous closure>':.
    //     0x4f8cc4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16110] AnonymousClosure: (0x4f9954), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8cc8: ldr             x1, [x1, #0x110]
    // 0x4f8ccc: r2 = Null
    //     0x4f8ccc: mov             x2, NULL
    // 0x4f8cd0: stur            x0, [fp, #-0x20]
    // 0x4f8cd4: r0 = AllocateClosure()
    //     0x4f8cd4: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8cd8: r1 = <String>
    //     0x4f8cd8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8cdc: stur            x0, [fp, #-0x28]
    // 0x4f8ce0: r0 = Generator()
    //     0x4f8ce0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8ce4: ldur            x2, [fp, #-0x28]
    // 0x4f8ce8: r3 = Null
    //     0x4f8ce8: mov             x3, NULL
    // 0x4f8cec: stur            x0, [fp, #-0x28]
    // 0x4f8cf0: r0 = AllocateRecord2()
    //     0x4f8cf0: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8cf4: mov             x1, x0
    // 0x4f8cf8: ldur            x0, [fp, #-0x28]
    // 0x4f8cfc: StoreField: r0->field_f = r1
    //     0x4f8cfc: stur            w1, [x0, #0xf]
    // 0x4f8d00: r1 = Null
    //     0x4f8d00: mov             x1, NULL
    // 0x4f8d04: r2 = 2
    //     0x4f8d04: movz            x2, #0x2
    // 0x4f8d08: r0 = AllocateArray()
    //     0x4f8d08: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8d0c: stur            x0, [fp, #-0x30]
    // 0x4f8d10: r16 = Instance_Tuple2
    //     0x4f8d10: add             x16, PP, #0x16, lsl #12  ; [pp+0x16118] Obj!Tuple2<Chapter12Stat, CustomNum>@822f31
    //     0x4f8d14: ldr             x16, [x16, #0x118]
    // 0x4f8d18: StoreField: r0->field_f = r16
    //     0x4f8d18: stur            w16, [x0, #0xf]
    // 0x4f8d1c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8d1c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8d20: ldr             x1, [x1, #0xc38]
    // 0x4f8d24: r0 = AllocateGrowableArray()
    //     0x4f8d24: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8d28: mov             x2, x0
    // 0x4f8d2c: ldur            x0, [fp, #-0x30]
    // 0x4f8d30: stur            x2, [fp, #-0x38]
    // 0x4f8d34: StoreField: r2->field_f = r0
    //     0x4f8d34: stur            w0, [x2, #0xf]
    // 0x4f8d38: r0 = 2
    //     0x4f8d38: movz            x0, #0x2
    // 0x4f8d3c: StoreField: r2->field_b = r0
    //     0x4f8d3c: stur            w0, [x2, #0xb]
    // 0x4f8d40: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8d40: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8d44: ldr             x1, [x1, #0xc38]
    // 0x4f8d48: r0 = Generator()
    //     0x4f8d48: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8d4c: mov             x2, x0
    // 0x4f8d50: ldur            x0, [fp, #-0x38]
    // 0x4f8d54: stur            x2, [fp, #-0x30]
    // 0x4f8d58: StoreField: r2->field_b = r0
    //     0x4f8d58: stur            w0, [x2, #0xb]
    // 0x4f8d5c: r1 = <Chapter12Stat>
    //     0x4f8d5c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8d60: ldr             x1, [x1, #0xef0]
    // 0x4f8d64: r0 = UpgradeData()
    //     0x4f8d64: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8d68: mov             x3, x0
    // 0x4f8d6c: ldur            x0, [fp, #-0x20]
    // 0x4f8d70: stur            x3, [fp, #-0x38]
    // 0x4f8d74: StoreField: r3->field_b = r0
    //     0x4f8d74: stur            w0, [x3, #0xb]
    // 0x4f8d78: ldur            x0, [fp, #-0x28]
    // 0x4f8d7c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8d7c: stur            w0, [x3, #0x17]
    // 0x4f8d80: r0 = Instance_IconData
    //     0x4f8d80: add             x0, PP, #0x16, lsl #12  ; [pp+0x16120] Obj!IconData@82fed1
    //     0x4f8d84: ldr             x0, [x0, #0x120]
    // 0x4f8d88: StoreField: r3->field_13 = r0
    //     0x4f8d88: stur            w0, [x3, #0x13]
    // 0x4f8d8c: ldur            x0, [fp, #-0x30]
    // 0x4f8d90: StoreField: r3->field_f = r0
    //     0x4f8d90: stur            w0, [x3, #0xf]
    // 0x4f8d94: ldur            x2, [fp, #-0x10]
    // 0x4f8d98: r1 = Function '<anonymous closure>':.
    //     0x4f8d98: add             x1, PP, #0x16, lsl #12  ; [pp+0x16128] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8d9c: ldr             x1, [x1, #0x128]
    // 0x4f8da0: r0 = AllocateClosure()
    //     0x4f8da0: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8da4: mov             x1, x0
    // 0x4f8da8: ldur            x0, [fp, #-0x38]
    // 0x4f8dac: StoreField: r0->field_1b = r1
    //     0x4f8dac: stur            w1, [x0, #0x1b]
    // 0x4f8db0: ldur            x1, [fp, #-0x18]
    // 0x4f8db4: ArrayStore: r1[55] = r0  ; List_4
    //     0x4f8db4: add             x25, x1, #0xeb
    //     0x4f8db8: str             w0, [x25]
    //     0x4f8dbc: tbz             w0, #0, #0x4f8dd8
    //     0x4f8dc0: ldurb           w16, [x1, #-1]
    //     0x4f8dc4: ldurb           w17, [x0, #-1]
    //     0x4f8dc8: and             x16, x17, x16, lsr #2
    //     0x4f8dcc: tst             x16, HEAP, lsr #32
    //     0x4f8dd0: b.eq            #0x4f8dd8
    //     0x4f8dd4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8dd8: ldur            x0, [fp, #-0x18]
    // 0x4f8ddc: r16 = 248
    //     0x4f8ddc: movz            x16, #0xf8
    // 0x4f8de0: StoreField: r0->field_ef = r16
    //     0x4f8de0: stur            w16, [x0, #0xef]
    // 0x4f8de4: r1 = "Reverse Development 2"
    //     0x4f8de4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16130] "Reverse Development 2"
    //     0x4f8de8: ldr             x1, [x1, #0x130]
    // 0x4f8dec: r0 = autoString()
    //     0x4f8dec: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8df0: r1 = Function '<anonymous closure>':.
    //     0x4f8df0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16138] AnonymousClosure: (0x4f9948), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8df4: ldr             x1, [x1, #0x138]
    // 0x4f8df8: r2 = Null
    //     0x4f8df8: mov             x2, NULL
    // 0x4f8dfc: stur            x0, [fp, #-0x20]
    // 0x4f8e00: r0 = AllocateClosure()
    //     0x4f8e00: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8e04: r1 = <String>
    //     0x4f8e04: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8e08: stur            x0, [fp, #-0x28]
    // 0x4f8e0c: r0 = Generator()
    //     0x4f8e0c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8e10: ldur            x2, [fp, #-0x28]
    // 0x4f8e14: r3 = Null
    //     0x4f8e14: mov             x3, NULL
    // 0x4f8e18: stur            x0, [fp, #-0x28]
    // 0x4f8e1c: r0 = AllocateRecord2()
    //     0x4f8e1c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8e20: mov             x1, x0
    // 0x4f8e24: ldur            x0, [fp, #-0x28]
    // 0x4f8e28: StoreField: r0->field_f = r1
    //     0x4f8e28: stur            w1, [x0, #0xf]
    // 0x4f8e2c: r1 = Null
    //     0x4f8e2c: mov             x1, NULL
    // 0x4f8e30: r2 = 2
    //     0x4f8e30: movz            x2, #0x2
    // 0x4f8e34: r0 = AllocateArray()
    //     0x4f8e34: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8e38: stur            x0, [fp, #-0x30]
    // 0x4f8e3c: r16 = Instance_Tuple2
    //     0x4f8e3c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16140] Obj!Tuple2<Chapter12Stat, CustomNum>@822f11
    //     0x4f8e40: ldr             x16, [x16, #0x140]
    // 0x4f8e44: StoreField: r0->field_f = r16
    //     0x4f8e44: stur            w16, [x0, #0xf]
    // 0x4f8e48: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8e48: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8e4c: ldr             x1, [x1, #0xc38]
    // 0x4f8e50: r0 = AllocateGrowableArray()
    //     0x4f8e50: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8e54: mov             x2, x0
    // 0x4f8e58: ldur            x0, [fp, #-0x30]
    // 0x4f8e5c: stur            x2, [fp, #-0x38]
    // 0x4f8e60: StoreField: r2->field_f = r0
    //     0x4f8e60: stur            w0, [x2, #0xf]
    // 0x4f8e64: r0 = 2
    //     0x4f8e64: movz            x0, #0x2
    // 0x4f8e68: StoreField: r2->field_b = r0
    //     0x4f8e68: stur            w0, [x2, #0xb]
    // 0x4f8e6c: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8e6c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8e70: ldr             x1, [x1, #0xc38]
    // 0x4f8e74: r0 = Generator()
    //     0x4f8e74: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8e78: mov             x2, x0
    // 0x4f8e7c: ldur            x0, [fp, #-0x38]
    // 0x4f8e80: stur            x2, [fp, #-0x30]
    // 0x4f8e84: StoreField: r2->field_b = r0
    //     0x4f8e84: stur            w0, [x2, #0xb]
    // 0x4f8e88: r1 = <Chapter12Stat>
    //     0x4f8e88: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8e8c: ldr             x1, [x1, #0xef0]
    // 0x4f8e90: r0 = UpgradeData()
    //     0x4f8e90: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8e94: mov             x3, x0
    // 0x4f8e98: ldur            x0, [fp, #-0x20]
    // 0x4f8e9c: stur            x3, [fp, #-0x38]
    // 0x4f8ea0: StoreField: r3->field_b = r0
    //     0x4f8ea0: stur            w0, [x3, #0xb]
    // 0x4f8ea4: ldur            x0, [fp, #-0x28]
    // 0x4f8ea8: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8ea8: stur            w0, [x3, #0x17]
    // 0x4f8eac: r0 = Instance_IconData
    //     0x4f8eac: add             x0, PP, #0x16, lsl #12  ; [pp+0x16148] Obj!IconData@82feb1
    //     0x4f8eb0: ldr             x0, [x0, #0x148]
    // 0x4f8eb4: StoreField: r3->field_13 = r0
    //     0x4f8eb4: stur            w0, [x3, #0x13]
    // 0x4f8eb8: ldur            x0, [fp, #-0x30]
    // 0x4f8ebc: StoreField: r3->field_f = r0
    //     0x4f8ebc: stur            w0, [x3, #0xf]
    // 0x4f8ec0: ldur            x2, [fp, #-0x10]
    // 0x4f8ec4: r1 = Function '<anonymous closure>':.
    //     0x4f8ec4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16150] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8ec8: ldr             x1, [x1, #0x150]
    // 0x4f8ecc: r0 = AllocateClosure()
    //     0x4f8ecc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8ed0: mov             x1, x0
    // 0x4f8ed4: ldur            x0, [fp, #-0x38]
    // 0x4f8ed8: StoreField: r0->field_1b = r1
    //     0x4f8ed8: stur            w1, [x0, #0x1b]
    // 0x4f8edc: ldur            x1, [fp, #-0x18]
    // 0x4f8ee0: ArrayStore: r1[57] = r0  ; List_4
    //     0x4f8ee0: add             x25, x1, #0xf3
    //     0x4f8ee4: str             w0, [x25]
    //     0x4f8ee8: tbz             w0, #0, #0x4f8f04
    //     0x4f8eec: ldurb           w16, [x1, #-1]
    //     0x4f8ef0: ldurb           w17, [x0, #-1]
    //     0x4f8ef4: and             x16, x17, x16, lsr #2
    //     0x4f8ef8: tst             x16, HEAP, lsr #32
    //     0x4f8efc: b.eq            #0x4f8f04
    //     0x4f8f00: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f8f04: ldur            x0, [fp, #-0x18]
    // 0x4f8f08: r16 = 250
    //     0x4f8f08: movz            x16, #0xfa
    // 0x4f8f0c: StoreField: r0->field_f7 = r16
    //     0x4f8f0c: stur            w16, [x0, #0xf7]
    // 0x4f8f10: r1 = "Overcharge"
    //     0x4f8f10: add             x1, PP, #0x16, lsl #12  ; [pp+0x16158] "Overcharge"
    //     0x4f8f14: ldr             x1, [x1, #0x158]
    // 0x4f8f18: r0 = autoString()
    //     0x4f8f18: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f8f1c: r1 = Function '<anonymous closure>':.
    //     0x4f8f1c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16160] AnonymousClosure: (0x4f993c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f8f20: ldr             x1, [x1, #0x160]
    // 0x4f8f24: r2 = Null
    //     0x4f8f24: mov             x2, NULL
    // 0x4f8f28: stur            x0, [fp, #-0x20]
    // 0x4f8f2c: r0 = AllocateClosure()
    //     0x4f8f2c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8f30: r1 = <String>
    //     0x4f8f30: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f8f34: stur            x0, [fp, #-0x28]
    // 0x4f8f38: r0 = Generator()
    //     0x4f8f38: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8f3c: ldur            x2, [fp, #-0x28]
    // 0x4f8f40: r3 = Null
    //     0x4f8f40: mov             x3, NULL
    // 0x4f8f44: stur            x0, [fp, #-0x28]
    // 0x4f8f48: r0 = AllocateRecord2()
    //     0x4f8f48: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f8f4c: mov             x1, x0
    // 0x4f8f50: ldur            x0, [fp, #-0x28]
    // 0x4f8f54: StoreField: r0->field_f = r1
    //     0x4f8f54: stur            w1, [x0, #0xf]
    // 0x4f8f58: r1 = Null
    //     0x4f8f58: mov             x1, NULL
    // 0x4f8f5c: r2 = 2
    //     0x4f8f5c: movz            x2, #0x2
    // 0x4f8f60: r0 = AllocateArray()
    //     0x4f8f60: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f8f64: stur            x0, [fp, #-0x30]
    // 0x4f8f68: r16 = Instance_Tuple2
    //     0x4f8f68: add             x16, PP, #0x16, lsl #12  ; [pp+0x16168] Obj!Tuple2<Chapter12Stat, CustomNum>@822ef1
    //     0x4f8f6c: ldr             x16, [x16, #0x168]
    // 0x4f8f70: StoreField: r0->field_f = r16
    //     0x4f8f70: stur            w16, [x0, #0xf]
    // 0x4f8f74: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8f74: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8f78: ldr             x1, [x1, #0xc38]
    // 0x4f8f7c: r0 = AllocateGrowableArray()
    //     0x4f8f7c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f8f80: mov             x2, x0
    // 0x4f8f84: ldur            x0, [fp, #-0x30]
    // 0x4f8f88: stur            x2, [fp, #-0x38]
    // 0x4f8f8c: StoreField: r2->field_f = r0
    //     0x4f8f8c: stur            w0, [x2, #0xf]
    // 0x4f8f90: r0 = 2
    //     0x4f8f90: movz            x0, #0x2
    // 0x4f8f94: StoreField: r2->field_b = r0
    //     0x4f8f94: stur            w0, [x2, #0xb]
    // 0x4f8f98: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8f98: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f8f9c: ldr             x1, [x1, #0xc38]
    // 0x4f8fa0: r0 = Generator()
    //     0x4f8fa0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f8fa4: mov             x2, x0
    // 0x4f8fa8: ldur            x0, [fp, #-0x38]
    // 0x4f8fac: stur            x2, [fp, #-0x30]
    // 0x4f8fb0: StoreField: r2->field_b = r0
    //     0x4f8fb0: stur            w0, [x2, #0xb]
    // 0x4f8fb4: r1 = <Chapter12Stat>
    //     0x4f8fb4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f8fb8: ldr             x1, [x1, #0xef0]
    // 0x4f8fbc: r0 = UpgradeData()
    //     0x4f8fbc: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f8fc0: mov             x3, x0
    // 0x4f8fc4: ldur            x0, [fp, #-0x20]
    // 0x4f8fc8: stur            x3, [fp, #-0x38]
    // 0x4f8fcc: StoreField: r3->field_b = r0
    //     0x4f8fcc: stur            w0, [x3, #0xb]
    // 0x4f8fd0: ldur            x0, [fp, #-0x28]
    // 0x4f8fd4: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f8fd4: stur            w0, [x3, #0x17]
    // 0x4f8fd8: r0 = Instance_IconData
    //     0x4f8fd8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16170] Obj!IconData@82fe91
    //     0x4f8fdc: ldr             x0, [x0, #0x170]
    // 0x4f8fe0: StoreField: r3->field_13 = r0
    //     0x4f8fe0: stur            w0, [x3, #0x13]
    // 0x4f8fe4: ldur            x0, [fp, #-0x30]
    // 0x4f8fe8: StoreField: r3->field_f = r0
    //     0x4f8fe8: stur            w0, [x3, #0xf]
    // 0x4f8fec: ldur            x2, [fp, #-0x10]
    // 0x4f8ff0: r1 = Function '<anonymous closure>':.
    //     0x4f8ff0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16178] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f8ff4: ldr             x1, [x1, #0x178]
    // 0x4f8ff8: r0 = AllocateClosure()
    //     0x4f8ff8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f8ffc: mov             x1, x0
    // 0x4f9000: ldur            x0, [fp, #-0x38]
    // 0x4f9004: StoreField: r0->field_1b = r1
    //     0x4f9004: stur            w1, [x0, #0x1b]
    // 0x4f9008: ldur            x1, [fp, #-0x18]
    // 0x4f900c: ArrayStore: r1[59] = r0  ; List_4
    //     0x4f900c: add             x25, x1, #0xfb
    //     0x4f9010: str             w0, [x25]
    //     0x4f9014: tbz             w0, #0, #0x4f9030
    //     0x4f9018: ldurb           w16, [x1, #-1]
    //     0x4f901c: ldurb           w17, [x0, #-1]
    //     0x4f9020: and             x16, x17, x16, lsr #2
    //     0x4f9024: tst             x16, HEAP, lsr #32
    //     0x4f9028: b.eq            #0x4f9030
    //     0x4f902c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f9030: ldur            x0, [fp, #-0x18]
    // 0x4f9034: r16 = 252
    //     0x4f9034: movz            x16, #0xfc
    // 0x4f9038: StoreField: r0->field_ff = r16
    //     0x4f9038: stur            w16, [x0, #0xff]
    // 0x4f903c: r1 = "Network Analysis 2"
    //     0x4f903c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16180] "Network Analysis 2"
    //     0x4f9040: ldr             x1, [x1, #0x180]
    // 0x4f9044: r0 = autoString()
    //     0x4f9044: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f9048: r1 = Function '<anonymous closure>':.
    //     0x4f9048: add             x1, PP, #0x16, lsl #12  ; [pp+0x16188] AnonymousClosure: (0x4f9930), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f904c: ldr             x1, [x1, #0x188]
    // 0x4f9050: r2 = Null
    //     0x4f9050: mov             x2, NULL
    // 0x4f9054: stur            x0, [fp, #-0x20]
    // 0x4f9058: r0 = AllocateClosure()
    //     0x4f9058: bl              #0x826750  ; AllocateClosureStub
    // 0x4f905c: r1 = <String>
    //     0x4f905c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f9060: stur            x0, [fp, #-0x28]
    // 0x4f9064: r0 = Generator()
    //     0x4f9064: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f9068: ldur            x2, [fp, #-0x28]
    // 0x4f906c: r3 = Null
    //     0x4f906c: mov             x3, NULL
    // 0x4f9070: stur            x0, [fp, #-0x28]
    // 0x4f9074: r0 = AllocateRecord2()
    //     0x4f9074: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f9078: mov             x1, x0
    // 0x4f907c: ldur            x0, [fp, #-0x28]
    // 0x4f9080: StoreField: r0->field_f = r1
    //     0x4f9080: stur            w1, [x0, #0xf]
    // 0x4f9084: r1 = Null
    //     0x4f9084: mov             x1, NULL
    // 0x4f9088: r2 = 2
    //     0x4f9088: movz            x2, #0x2
    // 0x4f908c: r0 = AllocateArray()
    //     0x4f908c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f9090: stur            x0, [fp, #-0x30]
    // 0x4f9094: r16 = Instance_Tuple2
    //     0x4f9094: add             x16, PP, #0x16, lsl #12  ; [pp+0x16190] Obj!Tuple2<Chapter12Stat, CustomNum>@822ed1
    //     0x4f9098: ldr             x16, [x16, #0x190]
    // 0x4f909c: StoreField: r0->field_f = r16
    //     0x4f909c: stur            w16, [x0, #0xf]
    // 0x4f90a0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f90a0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f90a4: ldr             x1, [x1, #0xc38]
    // 0x4f90a8: r0 = AllocateGrowableArray()
    //     0x4f90a8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f90ac: mov             x2, x0
    // 0x4f90b0: ldur            x0, [fp, #-0x30]
    // 0x4f90b4: stur            x2, [fp, #-0x38]
    // 0x4f90b8: StoreField: r2->field_f = r0
    //     0x4f90b8: stur            w0, [x2, #0xf]
    // 0x4f90bc: r0 = 2
    //     0x4f90bc: movz            x0, #0x2
    // 0x4f90c0: StoreField: r2->field_b = r0
    //     0x4f90c0: stur            w0, [x2, #0xb]
    // 0x4f90c4: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f90c4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f90c8: ldr             x1, [x1, #0xc38]
    // 0x4f90cc: r0 = Generator()
    //     0x4f90cc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f90d0: mov             x2, x0
    // 0x4f90d4: ldur            x0, [fp, #-0x38]
    // 0x4f90d8: stur            x2, [fp, #-0x30]
    // 0x4f90dc: StoreField: r2->field_b = r0
    //     0x4f90dc: stur            w0, [x2, #0xb]
    // 0x4f90e0: r1 = <Chapter12Stat>
    //     0x4f90e0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f90e4: ldr             x1, [x1, #0xef0]
    // 0x4f90e8: r0 = UpgradeData()
    //     0x4f90e8: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f90ec: mov             x3, x0
    // 0x4f90f0: ldur            x0, [fp, #-0x20]
    // 0x4f90f4: stur            x3, [fp, #-0x38]
    // 0x4f90f8: StoreField: r3->field_b = r0
    //     0x4f90f8: stur            w0, [x3, #0xb]
    // 0x4f90fc: ldur            x0, [fp, #-0x28]
    // 0x4f9100: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f9100: stur            w0, [x3, #0x17]
    // 0x4f9104: r0 = Instance_IconData
    //     0x4f9104: add             x0, PP, #0x16, lsl #12  ; [pp+0x16198] Obj!IconData@82fe71
    //     0x4f9108: ldr             x0, [x0, #0x198]
    // 0x4f910c: StoreField: r3->field_13 = r0
    //     0x4f910c: stur            w0, [x3, #0x13]
    // 0x4f9110: ldur            x0, [fp, #-0x30]
    // 0x4f9114: StoreField: r3->field_f = r0
    //     0x4f9114: stur            w0, [x3, #0xf]
    // 0x4f9118: ldur            x2, [fp, #-0x10]
    // 0x4f911c: r1 = Function '<anonymous closure>':.
    //     0x4f911c: add             x1, PP, #0x16, lsl #12  ; [pp+0x161a0] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f9120: ldr             x1, [x1, #0x1a0]
    // 0x4f9124: r0 = AllocateClosure()
    //     0x4f9124: bl              #0x826750  ; AllocateClosureStub
    // 0x4f9128: mov             x1, x0
    // 0x4f912c: ldur            x0, [fp, #-0x38]
    // 0x4f9130: StoreField: r0->field_1b = r1
    //     0x4f9130: stur            w1, [x0, #0x1b]
    // 0x4f9134: ldur            x1, [fp, #-0x18]
    // 0x4f9138: ArrayStore: r1[61] = r0  ; List_4
    //     0x4f9138: add             x25, x1, #0x103
    //     0x4f913c: str             w0, [x25]
    //     0x4f9140: tbz             w0, #0, #0x4f915c
    //     0x4f9144: ldurb           w16, [x1, #-1]
    //     0x4f9148: ldurb           w17, [x0, #-1]
    //     0x4f914c: and             x16, x17, x16, lsr #2
    //     0x4f9150: tst             x16, HEAP, lsr #32
    //     0x4f9154: b.eq            #0x4f915c
    //     0x4f9158: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f915c: ldur            x0, [fp, #-0x18]
    // 0x4f9160: r16 = 254
    //     0x4f9160: movz            x16, #0xfe
    // 0x4f9164: r17 = 263
    //     0x4f9164: movz            x17, #0x107
    // 0x4f9168: str             w16, [x0, x17]
    // 0x4f916c: r1 = "Bonuses"
    //     0x4f916c: add             x1, PP, #0x16, lsl #12  ; [pp+0x161a8] "Bonuses"
    //     0x4f9170: ldr             x1, [x1, #0x1a8]
    // 0x4f9174: r0 = autoString()
    //     0x4f9174: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f9178: r1 = Function '<anonymous closure>':.
    //     0x4f9178: add             x1, PP, #0x16, lsl #12  ; [pp+0x161b0] AnonymousClosure: (0x4f9924), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f917c: ldr             x1, [x1, #0x1b0]
    // 0x4f9180: r2 = Null
    //     0x4f9180: mov             x2, NULL
    // 0x4f9184: stur            x0, [fp, #-0x20]
    // 0x4f9188: r0 = AllocateClosure()
    //     0x4f9188: bl              #0x826750  ; AllocateClosureStub
    // 0x4f918c: r1 = <String>
    //     0x4f918c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f9190: stur            x0, [fp, #-0x28]
    // 0x4f9194: r0 = Generator()
    //     0x4f9194: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f9198: ldur            x2, [fp, #-0x28]
    // 0x4f919c: r3 = Null
    //     0x4f919c: mov             x3, NULL
    // 0x4f91a0: stur            x0, [fp, #-0x28]
    // 0x4f91a4: r0 = AllocateRecord2()
    //     0x4f91a4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f91a8: mov             x1, x0
    // 0x4f91ac: ldur            x0, [fp, #-0x28]
    // 0x4f91b0: StoreField: r0->field_f = r1
    //     0x4f91b0: stur            w1, [x0, #0xf]
    // 0x4f91b4: r1 = Null
    //     0x4f91b4: mov             x1, NULL
    // 0x4f91b8: r2 = 2
    //     0x4f91b8: movz            x2, #0x2
    // 0x4f91bc: r0 = AllocateArray()
    //     0x4f91bc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f91c0: stur            x0, [fp, #-0x30]
    // 0x4f91c4: r16 = Instance_Tuple2
    //     0x4f91c4: add             x16, PP, #0x16, lsl #12  ; [pp+0x161b8] Obj!Tuple2<Chapter12Stat, CustomNum>@822eb1
    //     0x4f91c8: ldr             x16, [x16, #0x1b8]
    // 0x4f91cc: StoreField: r0->field_f = r16
    //     0x4f91cc: stur            w16, [x0, #0xf]
    // 0x4f91d0: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f91d0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f91d4: ldr             x1, [x1, #0xc38]
    // 0x4f91d8: r0 = AllocateGrowableArray()
    //     0x4f91d8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f91dc: mov             x2, x0
    // 0x4f91e0: ldur            x0, [fp, #-0x30]
    // 0x4f91e4: stur            x2, [fp, #-0x38]
    // 0x4f91e8: StoreField: r2->field_f = r0
    //     0x4f91e8: stur            w0, [x2, #0xf]
    // 0x4f91ec: r0 = 2
    //     0x4f91ec: movz            x0, #0x2
    // 0x4f91f0: StoreField: r2->field_b = r0
    //     0x4f91f0: stur            w0, [x2, #0xb]
    // 0x4f91f4: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f91f4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f91f8: ldr             x1, [x1, #0xc38]
    // 0x4f91fc: r0 = Generator()
    //     0x4f91fc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f9200: mov             x2, x0
    // 0x4f9204: ldur            x0, [fp, #-0x38]
    // 0x4f9208: stur            x2, [fp, #-0x30]
    // 0x4f920c: StoreField: r2->field_b = r0
    //     0x4f920c: stur            w0, [x2, #0xb]
    // 0x4f9210: r1 = <Chapter12Stat>
    //     0x4f9210: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f9214: ldr             x1, [x1, #0xef0]
    // 0x4f9218: r0 = UpgradeData()
    //     0x4f9218: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f921c: mov             x3, x0
    // 0x4f9220: ldur            x0, [fp, #-0x20]
    // 0x4f9224: stur            x3, [fp, #-0x38]
    // 0x4f9228: StoreField: r3->field_b = r0
    //     0x4f9228: stur            w0, [x3, #0xb]
    // 0x4f922c: ldur            x0, [fp, #-0x28]
    // 0x4f9230: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f9230: stur            w0, [x3, #0x17]
    // 0x4f9234: r0 = Instance_IconData
    //     0x4f9234: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!IconData@82f471
    //     0x4f9238: ldr             x0, [x0, #0xee8]
    // 0x4f923c: StoreField: r3->field_13 = r0
    //     0x4f923c: stur            w0, [x3, #0x13]
    // 0x4f9240: ldur            x0, [fp, #-0x30]
    // 0x4f9244: StoreField: r3->field_f = r0
    //     0x4f9244: stur            w0, [x3, #0xf]
    // 0x4f9248: ldur            x2, [fp, #-0x10]
    // 0x4f924c: r1 = Function '<anonymous closure>':.
    //     0x4f924c: add             x1, PP, #0x16, lsl #12  ; [pp+0x161c0] AnonymousClosure: (0x4f9490), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f9250: ldr             x1, [x1, #0x1c0]
    // 0x4f9254: r0 = AllocateClosure()
    //     0x4f9254: bl              #0x826750  ; AllocateClosureStub
    // 0x4f9258: mov             x1, x0
    // 0x4f925c: ldur            x0, [fp, #-0x38]
    // 0x4f9260: StoreField: r0->field_23 = r1
    //     0x4f9260: stur            w1, [x0, #0x23]
    // 0x4f9264: ldur            x1, [fp, #-0x18]
    // 0x4f9268: ArrayStore: r1[63] = r0  ; List_4
    //     0x4f9268: add             x25, x1, #0x10b
    //     0x4f926c: str             w0, [x25]
    //     0x4f9270: tbz             w0, #0, #0x4f928c
    //     0x4f9274: ldurb           w16, [x1, #-1]
    //     0x4f9278: ldurb           w17, [x0, #-1]
    //     0x4f927c: and             x16, x17, x16, lsr #2
    //     0x4f9280: tst             x16, HEAP, lsr #32
    //     0x4f9284: b.eq            #0x4f928c
    //     0x4f9288: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f928c: ldur            x0, [fp, #-0x18]
    // 0x4f9290: r16 = 256
    //     0x4f9290: movz            x16, #0x100
    // 0x4f9294: r17 = 271
    //     0x4f9294: movz            x17, #0x10f
    // 0x4f9298: str             w16, [x0, x17]
    // 0x4f929c: r1 = "Hyperspeed"
    //     0x4f929c: add             x1, PP, #0x16, lsl #12  ; [pp+0x161c8] "Hyperspeed"
    //     0x4f92a0: ldr             x1, [x1, #0x1c8]
    // 0x4f92a4: r0 = autoString()
    //     0x4f92a4: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f92a8: r1 = Function '<anonymous closure>':.
    //     0x4f92a8: add             x1, PP, #0x16, lsl #12  ; [pp+0x161d0] AnonymousClosure: (0x4f9484), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::ensureInitialized (0x4f69b0)
    //     0x4f92ac: ldr             x1, [x1, #0x1d0]
    // 0x4f92b0: r2 = Null
    //     0x4f92b0: mov             x2, NULL
    // 0x4f92b4: stur            x0, [fp, #-0x20]
    // 0x4f92b8: r0 = AllocateClosure()
    //     0x4f92b8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f92bc: r1 = <String>
    //     0x4f92bc: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f92c0: stur            x0, [fp, #-0x28]
    // 0x4f92c4: r0 = Generator()
    //     0x4f92c4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f92c8: ldur            x2, [fp, #-0x28]
    // 0x4f92cc: r3 = Null
    //     0x4f92cc: mov             x3, NULL
    // 0x4f92d0: stur            x0, [fp, #-0x28]
    // 0x4f92d4: r0 = AllocateRecord2()
    //     0x4f92d4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f92d8: mov             x1, x0
    // 0x4f92dc: ldur            x0, [fp, #-0x28]
    // 0x4f92e0: StoreField: r0->field_f = r1
    //     0x4f92e0: stur            w1, [x0, #0xf]
    // 0x4f92e4: r1 = Null
    //     0x4f92e4: mov             x1, NULL
    // 0x4f92e8: r2 = 2
    //     0x4f92e8: movz            x2, #0x2
    // 0x4f92ec: r0 = AllocateArray()
    //     0x4f92ec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f92f0: stur            x0, [fp, #-0x30]
    // 0x4f92f4: r16 = Instance_Tuple2
    //     0x4f92f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x161d8] Obj!Tuple2<Chapter12Stat, CustomNum>@822e91
    //     0x4f92f8: ldr             x16, [x16, #0x1d8]
    // 0x4f92fc: StoreField: r0->field_f = r16
    //     0x4f92fc: stur            w16, [x0, #0xf]
    // 0x4f9300: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f9300: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f9304: ldr             x1, [x1, #0xc38]
    // 0x4f9308: r0 = AllocateGrowableArray()
    //     0x4f9308: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f930c: mov             x2, x0
    // 0x4f9310: ldur            x0, [fp, #-0x30]
    // 0x4f9314: stur            x2, [fp, #-0x38]
    // 0x4f9318: StoreField: r2->field_f = r0
    //     0x4f9318: stur            w0, [x2, #0xf]
    // 0x4f931c: r0 = 2
    //     0x4f931c: movz            x0, #0x2
    // 0x4f9320: StoreField: r2->field_b = r0
    //     0x4f9320: stur            w0, [x2, #0xb]
    // 0x4f9324: r1 = <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f9324: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c38] TypeArguments: <Tuple2<Chapter12Stat, CustomNum>>
    //     0x4f9328: ldr             x1, [x1, #0xc38]
    // 0x4f932c: r0 = Generator()
    //     0x4f932c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f9330: mov             x2, x0
    // 0x4f9334: ldur            x0, [fp, #-0x38]
    // 0x4f9338: stur            x2, [fp, #-0x30]
    // 0x4f933c: StoreField: r2->field_b = r0
    //     0x4f933c: stur            w0, [x2, #0xb]
    // 0x4f9340: r1 = <Chapter12Stat>
    //     0x4f9340: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x4f9344: ldr             x1, [x1, #0xef0]
    // 0x4f9348: r0 = UpgradeData()
    //     0x4f9348: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f934c: mov             x3, x0
    // 0x4f9350: ldur            x0, [fp, #-0x20]
    // 0x4f9354: stur            x3, [fp, #-0x38]
    // 0x4f9358: StoreField: r3->field_b = r0
    //     0x4f9358: stur            w0, [x3, #0xb]
    // 0x4f935c: ldur            x0, [fp, #-0x28]
    // 0x4f9360: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f9360: stur            w0, [x3, #0x17]
    // 0x4f9364: r0 = Instance_IconData
    //     0x4f9364: add             x0, PP, #0x16, lsl #12  ; [pp+0x161e0] Obj!IconData@82fe51
    //     0x4f9368: ldr             x0, [x0, #0x1e0]
    // 0x4f936c: StoreField: r3->field_13 = r0
    //     0x4f936c: stur            w0, [x3, #0x13]
    // 0x4f9370: ldur            x0, [fp, #-0x30]
    // 0x4f9374: StoreField: r3->field_f = r0
    //     0x4f9374: stur            w0, [x3, #0xf]
    // 0x4f9378: ldur            x2, [fp, #-0x10]
    // 0x4f937c: r1 = Function '<anonymous closure>':.
    //     0x4f937c: add             x1, PP, #0x16, lsl #12  ; [pp+0x161e8] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f9380: ldr             x1, [x1, #0x1e8]
    // 0x4f9384: r0 = AllocateClosure()
    //     0x4f9384: bl              #0x826750  ; AllocateClosureStub
    // 0x4f9388: mov             x1, x0
    // 0x4f938c: ldur            x0, [fp, #-0x38]
    // 0x4f9390: StoreField: r0->field_1b = r1
    //     0x4f9390: stur            w1, [x0, #0x1b]
    // 0x4f9394: ldur            x1, [fp, #-0x18]
    // 0x4f9398: ArrayStore: r1[65] = r0  ; List_4
    //     0x4f9398: add             x25, x1, #0x113
    //     0x4f939c: str             w0, [x25]
    //     0x4f93a0: tbz             w0, #0, #0x4f93bc
    //     0x4f93a4: ldurb           w16, [x1, #-1]
    //     0x4f93a8: ldurb           w17, [x0, #-1]
    //     0x4f93ac: and             x16, x17, x16, lsr #2
    //     0x4f93b0: tst             x16, HEAP, lsr #32
    //     0x4f93b4: b.eq            #0x4f93bc
    //     0x4f93b8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f93bc: r16 = <int, UpgradeData<Chapter12Stat>>
    //     0x4f93bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x161f0] TypeArguments: <int, UpgradeData<Chapter12Stat>>
    //     0x4f93c0: ldr             x16, [x16, #0x1f0]
    // 0x4f93c4: ldur            lr, [fp, #-0x18]
    // 0x4f93c8: stp             lr, x16, [SP]
    // 0x4f93cc: r0 = Map._fromLiteral()
    //     0x4f93cc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4f93d0: ldur            x1, [fp, #-8]
    // 0x4f93d4: StoreField: r1->field_93 = r0
    //     0x4f93d4: stur            w0, [x1, #0x93]
    //     0x4f93d8: ldurb           w16, [x1, #-1]
    //     0x4f93dc: ldurb           w17, [x0, #-1]
    //     0x4f93e0: and             x16, x17, x16, lsr #2
    //     0x4f93e4: tst             x16, HEAP, lsr #32
    //     0x4f93e8: b.eq            #0x4f93f0
    //     0x4f93ec: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4f93f0: r0 = Null
    //     0x4f93f0: mov             x0, NULL
    // 0x4f93f4: LeaveFrame
    //     0x4f93f4: mov             SP, fp
    //     0x4f93f8: ldp             fp, lr, [SP], #0x10
    // 0x4f93fc: ret
    //     0x4f93fc: ret             
    // 0x4f9400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9400: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9404: b               #0x4f69cc
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9484, size: 0xc
    // 0x4f9484: r0 = "10× the speed of all tier 2 generators."
    //     0x4f9484: add             x0, PP, #0x16, lsl #12  ; [pp+0x161f8] "10× the speed of all tier 2 generators."
    //     0x4f9488: ldr             x0, [x0, #0x1f8]
    // 0x4f948c: ret
    //     0x4f948c: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f9490, size: 0x2bc
    // 0x4f9490: EnterFrame
    //     0x4f9490: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9494: mov             fp, SP
    // 0x4f9498: AllocStack(0x10)
    //     0x4f9498: sub             SP, SP, #0x10
    // 0x4f949c: SetupParameters([dynamic _ /* r0 */])
    //     0x4f949c: ldr             x0, [fp, #0x18]
    //     0x4f94a0: ldur            w3, [x0, #0x17]
    //     0x4f94a4: add             x3, x3, HEAP, lsl #32
    //     0x4f94a8: stur            x3, [fp, #-0x10]
    // 0x4f94ac: CheckStackOverflow
    //     0x4f94ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f94b0: cmp             SP, x16
    //     0x4f94b4: b.ls            #0x4f9744
    // 0x4f94b8: LoadField: r0 = r3->field_f
    //     0x4f94b8: ldur            w0, [x3, #0xf]
    // 0x4f94bc: DecompressPointer r0
    //     0x4f94bc: add             x0, x0, HEAP, lsl #32
    // 0x4f94c0: LoadField: r4 = r0->field_37
    //     0x4f94c0: ldur            w4, [x0, #0x37]
    // 0x4f94c4: DecompressPointer r4
    //     0x4f94c4: add             x4, x4, HEAP, lsl #32
    // 0x4f94c8: mov             x1, x4
    // 0x4f94cc: stur            x4, [fp, #-8]
    // 0x4f94d0: r2 = Instance_Chapter12Stat
    //     0x4f94d0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11418] Obj!Chapter12Stat@85fc21
    //     0x4f94d4: ldr             x2, [x2, #0x418]
    // 0x4f94d8: r0 = _getValueOrData()
    //     0x4f94d8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f94dc: mov             x1, x0
    // 0x4f94e0: ldur            x0, [fp, #-8]
    // 0x4f94e4: LoadField: r2 = r0->field_f
    //     0x4f94e4: ldur            w2, [x0, #0xf]
    // 0x4f94e8: DecompressPointer r2
    //     0x4f94e8: add             x2, x2, HEAP, lsl #32
    // 0x4f94ec: cmp             w2, w1
    // 0x4f94f0: b.ne            #0x4f94f8
    // 0x4f94f4: r1 = Null
    //     0x4f94f4: mov             x1, NULL
    // 0x4f94f8: cmp             w1, NULL
    // 0x4f94fc: b.ne            #0x4f9508
    // 0x4f9500: r1 = Instance_CustomNum
    //     0x4f9500: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f9504: ldr             x1, [x1, #0xaf8]
    // 0x4f9508: ldur            x3, [fp, #-0x10]
    // 0x4f950c: r2 = Instance_CustomNum
    //     0x4f950c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4f9510: ldr             x2, [x2, #0x970]
    // 0x4f9514: r0 = add()
    //     0x4f9514: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9518: ldur            x1, [fp, #-8]
    // 0x4f951c: mov             x3, x0
    // 0x4f9520: r2 = Instance_Chapter12Stat
    //     0x4f9520: add             x2, PP, #0x11, lsl #12  ; [pp+0x11418] Obj!Chapter12Stat@85fc21
    //     0x4f9524: ldr             x2, [x2, #0x418]
    // 0x4f9528: r0 = []=()
    //     0x4f9528: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f952c: ldur            x0, [fp, #-0x10]
    // 0x4f9530: LoadField: r1 = r0->field_f
    //     0x4f9530: ldur            w1, [x0, #0xf]
    // 0x4f9534: DecompressPointer r1
    //     0x4f9534: add             x1, x1, HEAP, lsl #32
    // 0x4f9538: LoadField: r3 = r1->field_37
    //     0x4f9538: ldur            w3, [x1, #0x37]
    // 0x4f953c: DecompressPointer r3
    //     0x4f953c: add             x3, x3, HEAP, lsl #32
    // 0x4f9540: mov             x1, x3
    // 0x4f9544: stur            x3, [fp, #-8]
    // 0x4f9548: r2 = Instance_Chapter12Stat
    //     0x4f9548: add             x2, PP, #0x11, lsl #12  ; [pp+0x11420] Obj!Chapter12Stat@85fc01
    //     0x4f954c: ldr             x2, [x2, #0x420]
    // 0x4f9550: r0 = _getValueOrData()
    //     0x4f9550: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9554: mov             x1, x0
    // 0x4f9558: ldur            x0, [fp, #-8]
    // 0x4f955c: LoadField: r2 = r0->field_f
    //     0x4f955c: ldur            w2, [x0, #0xf]
    // 0x4f9560: DecompressPointer r2
    //     0x4f9560: add             x2, x2, HEAP, lsl #32
    // 0x4f9564: cmp             w2, w1
    // 0x4f9568: b.ne            #0x4f9570
    // 0x4f956c: r1 = Null
    //     0x4f956c: mov             x1, NULL
    // 0x4f9570: cmp             w1, NULL
    // 0x4f9574: b.ne            #0x4f9580
    // 0x4f9578: r1 = Instance_CustomNum
    //     0x4f9578: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f957c: ldr             x1, [x1, #0xaf8]
    // 0x4f9580: ldur            x3, [fp, #-0x10]
    // 0x4f9584: r2 = Instance_CustomNum
    //     0x4f9584: add             x2, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4f9588: ldr             x2, [x2, #0x970]
    // 0x4f958c: r0 = add()
    //     0x4f958c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9590: ldur            x1, [fp, #-8]
    // 0x4f9594: mov             x3, x0
    // 0x4f9598: r2 = Instance_Chapter12Stat
    //     0x4f9598: add             x2, PP, #0x11, lsl #12  ; [pp+0x11420] Obj!Chapter12Stat@85fc01
    //     0x4f959c: ldr             x2, [x2, #0x420]
    // 0x4f95a0: r0 = []=()
    //     0x4f95a0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f95a4: ldur            x0, [fp, #-0x10]
    // 0x4f95a8: LoadField: r1 = r0->field_f
    //     0x4f95a8: ldur            w1, [x0, #0xf]
    // 0x4f95ac: DecompressPointer r1
    //     0x4f95ac: add             x1, x1, HEAP, lsl #32
    // 0x4f95b0: LoadField: r3 = r1->field_37
    //     0x4f95b0: ldur            w3, [x1, #0x37]
    // 0x4f95b4: DecompressPointer r3
    //     0x4f95b4: add             x3, x3, HEAP, lsl #32
    // 0x4f95b8: mov             x1, x3
    // 0x4f95bc: stur            x3, [fp, #-8]
    // 0x4f95c0: r2 = Instance_Chapter12Stat
    //     0x4f95c0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11428] Obj!Chapter12Stat@85fbe1
    //     0x4f95c4: ldr             x2, [x2, #0x428]
    // 0x4f95c8: r0 = _getValueOrData()
    //     0x4f95c8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f95cc: mov             x1, x0
    // 0x4f95d0: ldur            x0, [fp, #-8]
    // 0x4f95d4: LoadField: r2 = r0->field_f
    //     0x4f95d4: ldur            w2, [x0, #0xf]
    // 0x4f95d8: DecompressPointer r2
    //     0x4f95d8: add             x2, x2, HEAP, lsl #32
    // 0x4f95dc: cmp             w2, w1
    // 0x4f95e0: b.ne            #0x4f95e8
    // 0x4f95e4: r1 = Null
    //     0x4f95e4: mov             x1, NULL
    // 0x4f95e8: cmp             w1, NULL
    // 0x4f95ec: b.ne            #0x4f95f8
    // 0x4f95f0: r1 = Instance_CustomNum
    //     0x4f95f0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f95f4: ldr             x1, [x1, #0xaf8]
    // 0x4f95f8: ldur            x3, [fp, #-0x10]
    // 0x4f95fc: r2 = Instance_CustomNum
    //     0x4f95fc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4f9600: ldr             x2, [x2, #0x970]
    // 0x4f9604: r0 = add()
    //     0x4f9604: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9608: ldur            x1, [fp, #-8]
    // 0x4f960c: mov             x3, x0
    // 0x4f9610: r2 = Instance_Chapter12Stat
    //     0x4f9610: add             x2, PP, #0x11, lsl #12  ; [pp+0x11428] Obj!Chapter12Stat@85fbe1
    //     0x4f9614: ldr             x2, [x2, #0x428]
    // 0x4f9618: r0 = []=()
    //     0x4f9618: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f961c: ldur            x0, [fp, #-0x10]
    // 0x4f9620: LoadField: r1 = r0->field_f
    //     0x4f9620: ldur            w1, [x0, #0xf]
    // 0x4f9624: DecompressPointer r1
    //     0x4f9624: add             x1, x1, HEAP, lsl #32
    // 0x4f9628: LoadField: r3 = r1->field_37
    //     0x4f9628: ldur            w3, [x1, #0x37]
    // 0x4f962c: DecompressPointer r3
    //     0x4f962c: add             x3, x3, HEAP, lsl #32
    // 0x4f9630: mov             x1, x3
    // 0x4f9634: stur            x3, [fp, #-8]
    // 0x4f9638: r2 = Instance_Chapter12Stat
    //     0x4f9638: add             x2, PP, #0x11, lsl #12  ; [pp+0x11430] Obj!Chapter12Stat@85fbc1
    //     0x4f963c: ldr             x2, [x2, #0x430]
    // 0x4f9640: r0 = _getValueOrData()
    //     0x4f9640: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9644: mov             x1, x0
    // 0x4f9648: ldur            x0, [fp, #-8]
    // 0x4f964c: LoadField: r2 = r0->field_f
    //     0x4f964c: ldur            w2, [x0, #0xf]
    // 0x4f9650: DecompressPointer r2
    //     0x4f9650: add             x2, x2, HEAP, lsl #32
    // 0x4f9654: cmp             w2, w1
    // 0x4f9658: b.ne            #0x4f9660
    // 0x4f965c: r1 = Null
    //     0x4f965c: mov             x1, NULL
    // 0x4f9660: cmp             w1, NULL
    // 0x4f9664: b.ne            #0x4f9670
    // 0x4f9668: r1 = Instance_CustomNum
    //     0x4f9668: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f966c: ldr             x1, [x1, #0xaf8]
    // 0x4f9670: ldur            x3, [fp, #-0x10]
    // 0x4f9674: r2 = Instance_CustomNum
    //     0x4f9674: add             x2, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4f9678: ldr             x2, [x2, #0x970]
    // 0x4f967c: r0 = add()
    //     0x4f967c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9680: ldur            x1, [fp, #-8]
    // 0x4f9684: mov             x3, x0
    // 0x4f9688: r2 = Instance_Chapter12Stat
    //     0x4f9688: add             x2, PP, #0x11, lsl #12  ; [pp+0x11430] Obj!Chapter12Stat@85fbc1
    //     0x4f968c: ldr             x2, [x2, #0x430]
    // 0x4f9690: r0 = []=()
    //     0x4f9690: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9694: ldur            x0, [fp, #-0x10]
    // 0x4f9698: LoadField: r1 = r0->field_f
    //     0x4f9698: ldur            w1, [x0, #0xf]
    // 0x4f969c: DecompressPointer r1
    //     0x4f969c: add             x1, x1, HEAP, lsl #32
    // 0x4f96a0: LoadField: r0 = r1->field_37
    //     0x4f96a0: ldur            w0, [x1, #0x37]
    // 0x4f96a4: DecompressPointer r0
    //     0x4f96a4: add             x0, x0, HEAP, lsl #32
    // 0x4f96a8: mov             x1, x0
    // 0x4f96ac: stur            x0, [fp, #-8]
    // 0x4f96b0: r2 = Instance_Chapter12Stat
    //     0x4f96b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11438] Obj!Chapter12Stat@85fba1
    //     0x4f96b4: ldr             x2, [x2, #0x438]
    // 0x4f96b8: r0 = _getValueOrData()
    //     0x4f96b8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f96bc: mov             x1, x0
    // 0x4f96c0: ldur            x0, [fp, #-8]
    // 0x4f96c4: LoadField: r2 = r0->field_f
    //     0x4f96c4: ldur            w2, [x0, #0xf]
    // 0x4f96c8: DecompressPointer r2
    //     0x4f96c8: add             x2, x2, HEAP, lsl #32
    // 0x4f96cc: cmp             w2, w1
    // 0x4f96d0: b.ne            #0x4f96d8
    // 0x4f96d4: r1 = Null
    //     0x4f96d4: mov             x1, NULL
    // 0x4f96d8: cmp             w1, NULL
    // 0x4f96dc: b.ne            #0x4f96e8
    // 0x4f96e0: r1 = Instance_CustomNum
    //     0x4f96e0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f96e4: ldr             x1, [x1, #0xaf8]
    // 0x4f96e8: r2 = Instance_CustomNum
    //     0x4f96e8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4f96ec: ldr             x2, [x2, #0x970]
    // 0x4f96f0: r0 = add()
    //     0x4f96f0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f96f4: ldur            x1, [fp, #-8]
    // 0x4f96f8: mov             x3, x0
    // 0x4f96fc: r2 = Instance_Chapter12Stat
    //     0x4f96fc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11438] Obj!Chapter12Stat@85fba1
    //     0x4f9700: ldr             x2, [x2, #0x438]
    // 0x4f9704: r0 = []=()
    //     0x4f9704: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9708: r0 = LoadStaticField(0xfb4)
    //     0x4f9708: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f970c: ldr             x0, [x0, #0x1f68]
    // 0x4f9710: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f9714: cmp             w0, w16
    // 0x4f9718: b.ne            #0x4f9728
    // 0x4f971c: r2 = generatorStateGroup
    //     0x4f971c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x4f9720: ldr             x2, [x2, #0x138]
    // 0x4f9724: r0 = InitLateStaticField()
    //     0x4f9724: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f9728: mov             x1, x0
    // 0x4f972c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f972c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f9730: r0 = notifyAll()
    //     0x4f9730: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9734: r0 = Null
    //     0x4f9734: mov             x0, NULL
    // 0x4f9738: LeaveFrame
    //     0x4f9738: mov             SP, fp
    //     0x4f973c: ldp             fp, lr, [SP], #0x10
    // 0x4f9740: ret
    //     0x4f9740: ret             
    // 0x4f9744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9744: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9748: b               #0x4f94b8
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9924, size: 0xc
    // 0x4f9924: r0 = "Awards 2 bonus generators for each tier 2 generator. They are not reset upon prestiging."
    //     0x4f9924: add             x0, PP, #0x16, lsl #12  ; [pp+0x16200] "Awards 2 bonus generators for each tier 2 generator. They are not reset upon prestiging."
    //     0x4f9928: ldr             x0, [x0, #0x200]
    // 0x4f992c: ret
    //     0x4f992c: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9930, size: 0xc
    // 0x4f9930: r0 = "Increased yields from scripts and network scanner."
    //     0x4f9930: add             x0, PP, #0x16, lsl #12  ; [pp+0x16208] "Increased yields from scripts and network scanner."
    //     0x4f9934: ldr             x0, [x0, #0x208]
    // 0x4f9938: ret
    //     0x4f9938: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f993c, size: 0xc
    // 0x4f993c: r0 = "8× the speed of all tier 2 generators."
    //     0x4f993c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16210] "8× the speed of all tier 2 generators."
    //     0x4f9940: ldr             x0, [x0, #0x210]
    // 0x4f9944: ret
    //     0x4f9944: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9948, size: 0xc
    // 0x4f9948: r0 = "Significantly increases script, reverse engineering, and port prober yields."
    //     0x4f9948: add             x0, PP, #0x16, lsl #12  ; [pp+0x16218] "Significantly increases script, reverse engineering, and port prober yields."
    //     0x4f994c: ldr             x0, [x0, #0x218]
    // 0x4f9950: ret
    //     0x4f9950: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9954, size: 0xc
    // 0x4f9954: r0 = "Drops the price of tier 2 generators."
    //     0x4f9954: add             x0, PP, #0x16, lsl #12  ; [pp+0x16220] "Drops the price of tier 2 generators."
    //     0x4f9958: ldr             x0, [x0, #0x220]
    // 0x4f995c: ret
    //     0x4f995c: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9960, size: 0xc
    // 0x4f9960: r0 = "Significantly increases script and reverse engineering yields."
    //     0x4f9960: add             x0, PP, #0x16, lsl #12  ; [pp+0x16228] "Significantly increases script and reverse engineering yields."
    //     0x4f9964: ldr             x0, [x0, #0x228]
    // 0x4f9968: ret
    //     0x4f9968: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f996c, size: 0xc
    // 0x4f996c: r0 = "4× the speed of all tier 2 generators."
    //     0x4f996c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16230] "4× the speed of all tier 2 generators."
    //     0x4f9970: ldr             x0, [x0, #0x230]
    // 0x4f9974: ret
    //     0x4f9974: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9978, size: 0xc
    // 0x4f9978: r0 = "Reduces the cost of most progress generators by 90%."
    //     0x4f9978: add             x0, PP, #0x16, lsl #12  ; [pp+0x16238] "Reduces the cost of most progress generators by 90%."
    //     0x4f997c: ldr             x0, [x0, #0x238]
    // 0x4f9980: ret
    //     0x4f9980: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9984, size: 0xc
    // 0x4f9984: r0 = "Increased yields from network scanner and port prober."
    //     0x4f9984: add             x0, PP, #0x16, lsl #12  ; [pp+0x16240] "Increased yields from network scanner and port prober."
    //     0x4f9988: ldr             x0, [x0, #0x240]
    // 0x4f998c: ret
    //     0x4f998c: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9990, size: 0xc
    // 0x4f9990: r0 = "Increased yields from network scanner, log analyzer, and reverse engineering."
    //     0x4f9990: add             x0, PP, #0x16, lsl #12  ; [pp+0x16248] "Increased yields from network scanner, log analyzer, and reverse engineering."
    //     0x4f9994: ldr             x0, [x0, #0x248]
    // 0x4f9998: ret
    //     0x4f9998: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f999c, size: 0xc
    // 0x4f999c: r0 = "Doubles the discovery gained by prestiging."
    //     0x4f999c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16250] "Doubles the discovery gained by prestiging."
    //     0x4f99a0: ldr             x0, [x0, #0x250]
    // 0x4f99a4: ret
    //     0x4f99a4: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f99a8, size: 0xc
    // 0x4f99a8: r0 = "All progress bars are twice as fast."
    //     0x4f99a8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16258] "All progress bars are twice as fast."
    //     0x4f99ac: ldr             x0, [x0, #0x258]
    // 0x4f99b0: ret
    //     0x4f99b0: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f99b4, size: 0xc
    // 0x4f99b4: r0 = "10× yields for log analyzer and log scanner."
    //     0x4f99b4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16260] "10× yields for log analyzer and log scanner."
    //     0x4f99b8: ldr             x0, [x0, #0x260]
    // 0x4f99bc: ret
    //     0x4f99bc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4f99c0, size: 0x58
    // 0x4f99c0: EnterFrame
    //     0x4f99c0: stp             fp, lr, [SP, #-0x10]!
    //     0x4f99c4: mov             fp, SP
    // 0x4f99c8: CheckStackOverflow
    //     0x4f99c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f99cc: cmp             SP, x16
    //     0x4f99d0: b.ls            #0x4f9a10
    // 0x4f99d4: r0 = LoadStaticField(0x1040)
    //     0x4f99d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f99d8: ldr             x0, [x0, #0x2080]
    // 0x4f99dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f99e0: cmp             w0, w16
    // 0x4f99e4: b.ne            #0x4f99f4
    // 0x4f99e8: r2 = fragments
    //     0x4f99e8: add             x2, PP, #0x10, lsl #12  ; [pp+0x100b8] Field <::.fragments>: static late (offset: 0x1040)
    //     0x4f99ec: ldr             x2, [x2, #0xb8]
    // 0x4f99f0: r0 = InitLateStaticField()
    //     0x4f99f0: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f99f4: mov             x1, x0
    // 0x4f99f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f99f8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f99fc: r0 = notifyAll()
    //     0x4f99fc: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9a00: r0 = Null
    //     0x4f9a00: mov             x0, NULL
    // 0x4f9a04: LeaveFrame
    //     0x4f9a04: mov             SP, fp
    //     0x4f9a08: ldp             fp, lr, [SP], #0x10
    // 0x4f9a0c: ret
    //     0x4f9a0c: ret             
    // 0x4f9a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9a10: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9a14: b               #0x4f99d4
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9a18, size: 0xc
    // 0x4f9a18: r0 = "Unlocks generator generators. These generators have their cost linked so buying one increases the cost of all of them."
    //     0x4f9a18: add             x0, PP, #0x16, lsl #12  ; [pp+0x16268] "Unlocks generator generators. These generators have their cost linked so buying one increases the cost of all of them."
    //     0x4f9a1c: ldr             x0, [x0, #0x268]
    // 0x4f9a20: ret
    //     0x4f9a20: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f9a24, size: 0xf0
    // 0x4f9a24: EnterFrame
    //     0x4f9a24: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9a28: mov             fp, SP
    // 0x4f9a2c: AllocStack(0x10)
    //     0x4f9a2c: sub             SP, SP, #0x10
    // 0x4f9a30: SetupParameters([dynamic _ /* r0 */])
    //     0x4f9a30: ldr             x0, [fp, #0x18]
    //     0x4f9a34: ldur            w1, [x0, #0x17]
    //     0x4f9a38: add             x1, x1, HEAP, lsl #32
    // 0x4f9a3c: CheckStackOverflow
    //     0x4f9a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9a40: cmp             SP, x16
    //     0x4f9a44: b.ls            #0x4f9b0c
    // 0x4f9a48: LoadField: r0 = r1->field_f
    //     0x4f9a48: ldur            w0, [x1, #0xf]
    // 0x4f9a4c: DecompressPointer r0
    //     0x4f9a4c: add             x0, x0, HEAP, lsl #32
    // 0x4f9a50: LoadField: r3 = r0->field_37
    //     0x4f9a50: ldur            w3, [x0, #0x37]
    // 0x4f9a54: DecompressPointer r3
    //     0x4f9a54: add             x3, x3, HEAP, lsl #32
    // 0x4f9a58: mov             x1, x3
    // 0x4f9a5c: stur            x3, [fp, #-8]
    // 0x4f9a60: r2 = Instance_Chapter12Stat
    //     0x4f9a60: add             x2, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x4f9a64: ldr             x2, [x2, #0x410]
    // 0x4f9a68: r0 = _getValueOrData()
    //     0x4f9a68: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9a6c: mov             x1, x0
    // 0x4f9a70: ldur            x0, [fp, #-8]
    // 0x4f9a74: LoadField: r2 = r0->field_f
    //     0x4f9a74: ldur            w2, [x0, #0xf]
    // 0x4f9a78: DecompressPointer r2
    //     0x4f9a78: add             x2, x2, HEAP, lsl #32
    // 0x4f9a7c: cmp             w2, w1
    // 0x4f9a80: b.ne            #0x4f9a88
    // 0x4f9a84: r1 = Null
    //     0x4f9a84: mov             x1, NULL
    // 0x4f9a88: cmp             w1, NULL
    // 0x4f9a8c: b.ne            #0x4f9a9c
    // 0x4f9a90: r3 = Instance_CustomNum
    //     0x4f9a90: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f9a94: ldr             x3, [x3, #0xaf8]
    // 0x4f9a98: b               #0x4f9aa0
    // 0x4f9a9c: mov             x3, x1
    // 0x4f9aa0: stur            x3, [fp, #-0x10]
    // 0x4f9aa4: r1 = Null
    //     0x4f9aa4: mov             x1, NULL
    // 0x4f9aa8: r2 = 40
    //     0x4f9aa8: movz            x2, #0x28
    // 0x4f9aac: r0 = CustomNum()
    //     0x4f9aac: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f9ab0: ldur            x1, [fp, #-0x10]
    // 0x4f9ab4: mov             x2, x0
    // 0x4f9ab8: r0 = add()
    //     0x4f9ab8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9abc: ldur            x1, [fp, #-8]
    // 0x4f9ac0: mov             x3, x0
    // 0x4f9ac4: r2 = Instance_Chapter12Stat
    //     0x4f9ac4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x4f9ac8: ldr             x2, [x2, #0x410]
    // 0x4f9acc: r0 = []=()
    //     0x4f9acc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9ad0: r0 = LoadStaticField(0xfb4)
    //     0x4f9ad0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f9ad4: ldr             x0, [x0, #0x1f68]
    // 0x4f9ad8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f9adc: cmp             w0, w16
    // 0x4f9ae0: b.ne            #0x4f9af0
    // 0x4f9ae4: r2 = generatorStateGroup
    //     0x4f9ae4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x4f9ae8: ldr             x2, [x2, #0x138]
    // 0x4f9aec: r0 = InitLateStaticField()
    //     0x4f9aec: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f9af0: mov             x1, x0
    // 0x4f9af4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f9af4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f9af8: r0 = notifyAll()
    //     0x4f9af8: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9afc: r0 = Null
    //     0x4f9afc: mov             x0, NULL
    // 0x4f9b00: LeaveFrame
    //     0x4f9b00: mov             SP, fp
    //     0x4f9b04: ldp             fp, lr, [SP], #0x10
    // 0x4f9b08: ret
    //     0x4f9b08: ret             
    // 0x4f9b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9b0c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9b10: b               #0x4f9a48
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9b14, size: 0xc
    // 0x4f9b14: r0 = "20 Port Prober generators."
    //     0x4f9b14: add             x0, PP, #0x16, lsl #12  ; [pp+0x16270] "20 Port Prober generators."
    //     0x4f9b18: ldr             x0, [x0, #0x270]
    // 0x4f9b1c: ret
    //     0x4f9b1c: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f9b20, size: 0xf0
    // 0x4f9b20: EnterFrame
    //     0x4f9b20: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9b24: mov             fp, SP
    // 0x4f9b28: AllocStack(0x10)
    //     0x4f9b28: sub             SP, SP, #0x10
    // 0x4f9b2c: SetupParameters([dynamic _ /* r0 */])
    //     0x4f9b2c: ldr             x0, [fp, #0x18]
    //     0x4f9b30: ldur            w1, [x0, #0x17]
    //     0x4f9b34: add             x1, x1, HEAP, lsl #32
    // 0x4f9b38: CheckStackOverflow
    //     0x4f9b38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9b3c: cmp             SP, x16
    //     0x4f9b40: b.ls            #0x4f9c08
    // 0x4f9b44: LoadField: r0 = r1->field_f
    //     0x4f9b44: ldur            w0, [x1, #0xf]
    // 0x4f9b48: DecompressPointer r0
    //     0x4f9b48: add             x0, x0, HEAP, lsl #32
    // 0x4f9b4c: LoadField: r3 = r0->field_37
    //     0x4f9b4c: ldur            w3, [x0, #0x37]
    // 0x4f9b50: DecompressPointer r3
    //     0x4f9b50: add             x3, x3, HEAP, lsl #32
    // 0x4f9b54: mov             x1, x3
    // 0x4f9b58: stur            x3, [fp, #-8]
    // 0x4f9b5c: r2 = Instance_Chapter12Stat
    //     0x4f9b5c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11400] Obj!Chapter12Stat@85fc81
    //     0x4f9b60: ldr             x2, [x2, #0x400]
    // 0x4f9b64: r0 = _getValueOrData()
    //     0x4f9b64: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9b68: mov             x1, x0
    // 0x4f9b6c: ldur            x0, [fp, #-8]
    // 0x4f9b70: LoadField: r2 = r0->field_f
    //     0x4f9b70: ldur            w2, [x0, #0xf]
    // 0x4f9b74: DecompressPointer r2
    //     0x4f9b74: add             x2, x2, HEAP, lsl #32
    // 0x4f9b78: cmp             w2, w1
    // 0x4f9b7c: b.ne            #0x4f9b84
    // 0x4f9b80: r1 = Null
    //     0x4f9b80: mov             x1, NULL
    // 0x4f9b84: cmp             w1, NULL
    // 0x4f9b88: b.ne            #0x4f9b98
    // 0x4f9b8c: r3 = Instance_CustomNum
    //     0x4f9b8c: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f9b90: ldr             x3, [x3, #0xaf8]
    // 0x4f9b94: b               #0x4f9b9c
    // 0x4f9b98: mov             x3, x1
    // 0x4f9b9c: stur            x3, [fp, #-0x10]
    // 0x4f9ba0: r1 = Null
    //     0x4f9ba0: mov             x1, NULL
    // 0x4f9ba4: r2 = 200
    //     0x4f9ba4: movz            x2, #0xc8
    // 0x4f9ba8: r0 = CustomNum()
    //     0x4f9ba8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f9bac: ldur            x1, [fp, #-0x10]
    // 0x4f9bb0: mov             x2, x0
    // 0x4f9bb4: r0 = add()
    //     0x4f9bb4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9bb8: ldur            x1, [fp, #-8]
    // 0x4f9bbc: mov             x3, x0
    // 0x4f9bc0: r2 = Instance_Chapter12Stat
    //     0x4f9bc0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11400] Obj!Chapter12Stat@85fc81
    //     0x4f9bc4: ldr             x2, [x2, #0x400]
    // 0x4f9bc8: r0 = []=()
    //     0x4f9bc8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9bcc: r0 = LoadStaticField(0xfb4)
    //     0x4f9bcc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f9bd0: ldr             x0, [x0, #0x1f68]
    // 0x4f9bd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f9bd8: cmp             w0, w16
    // 0x4f9bdc: b.ne            #0x4f9bec
    // 0x4f9be0: r2 = generatorStateGroup
    //     0x4f9be0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x4f9be4: ldr             x2, [x2, #0x138]
    // 0x4f9be8: r0 = InitLateStaticField()
    //     0x4f9be8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f9bec: mov             x1, x0
    // 0x4f9bf0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f9bf0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f9bf4: r0 = notifyAll()
    //     0x4f9bf4: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9bf8: r0 = Null
    //     0x4f9bf8: mov             x0, NULL
    // 0x4f9bfc: LeaveFrame
    //     0x4f9bfc: mov             SP, fp
    //     0x4f9c00: ldp             fp, lr, [SP], #0x10
    // 0x4f9c04: ret
    //     0x4f9c04: ret             
    // 0x4f9c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9c08: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9c0c: b               #0x4f9b44
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9c10, size: 0xc
    // 0x4f9c10: r0 = "100 Log Analyzer generators."
    //     0x4f9c10: add             x0, PP, #0x16, lsl #12  ; [pp+0x16278] "100 Log Analyzer generators."
    //     0x4f9c14: ldr             x0, [x0, #0x278]
    // 0x4f9c18: ret
    //     0x4f9c18: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9c1c, size: 0xc
    // 0x4f9c1c: r0 = "Drops all prices by another 99.9%."
    //     0x4f9c1c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16280] "Drops all prices by another 99.9%."
    //     0x4f9c20: ldr             x0, [x0, #0x280]
    // 0x4f9c24: ret
    //     0x4f9c24: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9c28, size: 0xc
    // 0x4f9c28: r0 = "10× yields on tier 1 generators"
    //     0x4f9c28: add             x0, PP, #0x16, lsl #12  ; [pp+0x16288] "10× yields on tier 1 generators"
    //     0x4f9c2c: ldr             x0, [x0, #0x288]
    // 0x4f9c30: ret
    //     0x4f9c30: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f9c34, size: 0xf0
    // 0x4f9c34: EnterFrame
    //     0x4f9c34: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9c38: mov             fp, SP
    // 0x4f9c3c: AllocStack(0x10)
    //     0x4f9c3c: sub             SP, SP, #0x10
    // 0x4f9c40: SetupParameters([dynamic _ /* r0 */])
    //     0x4f9c40: ldr             x0, [fp, #0x18]
    //     0x4f9c44: ldur            w1, [x0, #0x17]
    //     0x4f9c48: add             x1, x1, HEAP, lsl #32
    // 0x4f9c4c: CheckStackOverflow
    //     0x4f9c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9c50: cmp             SP, x16
    //     0x4f9c54: b.ls            #0x4f9d1c
    // 0x4f9c58: LoadField: r0 = r1->field_f
    //     0x4f9c58: ldur            w0, [x1, #0xf]
    // 0x4f9c5c: DecompressPointer r0
    //     0x4f9c5c: add             x0, x0, HEAP, lsl #32
    // 0x4f9c60: LoadField: r3 = r0->field_37
    //     0x4f9c60: ldur            w3, [x0, #0x37]
    // 0x4f9c64: DecompressPointer r3
    //     0x4f9c64: add             x3, x3, HEAP, lsl #32
    // 0x4f9c68: mov             x1, x3
    // 0x4f9c6c: stur            x3, [fp, #-8]
    // 0x4f9c70: r2 = Instance_Chapter12Stat
    //     0x4f9c70: add             x2, PP, #0x11, lsl #12  ; [pp+0x113f0] Obj!Chapter12Stat@85fcc1
    //     0x4f9c74: ldr             x2, [x2, #0x3f0]
    // 0x4f9c78: r0 = _getValueOrData()
    //     0x4f9c78: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9c7c: mov             x1, x0
    // 0x4f9c80: ldur            x0, [fp, #-8]
    // 0x4f9c84: LoadField: r2 = r0->field_f
    //     0x4f9c84: ldur            w2, [x0, #0xf]
    // 0x4f9c88: DecompressPointer r2
    //     0x4f9c88: add             x2, x2, HEAP, lsl #32
    // 0x4f9c8c: cmp             w2, w1
    // 0x4f9c90: b.ne            #0x4f9c98
    // 0x4f9c94: r1 = Null
    //     0x4f9c94: mov             x1, NULL
    // 0x4f9c98: cmp             w1, NULL
    // 0x4f9c9c: b.ne            #0x4f9cac
    // 0x4f9ca0: r3 = Instance_CustomNum
    //     0x4f9ca0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f9ca4: ldr             x3, [x3, #0xaf8]
    // 0x4f9ca8: b               #0x4f9cb0
    // 0x4f9cac: mov             x3, x1
    // 0x4f9cb0: stur            x3, [fp, #-0x10]
    // 0x4f9cb4: r1 = Null
    //     0x4f9cb4: mov             x1, NULL
    // 0x4f9cb8: r2 = 600
    //     0x4f9cb8: movz            x2, #0x258
    // 0x4f9cbc: r0 = CustomNum()
    //     0x4f9cbc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f9cc0: ldur            x1, [fp, #-0x10]
    // 0x4f9cc4: mov             x2, x0
    // 0x4f9cc8: r0 = add()
    //     0x4f9cc8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9ccc: ldur            x1, [fp, #-8]
    // 0x4f9cd0: mov             x3, x0
    // 0x4f9cd4: r2 = Instance_Chapter12Stat
    //     0x4f9cd4: add             x2, PP, #0x11, lsl #12  ; [pp+0x113f0] Obj!Chapter12Stat@85fcc1
    //     0x4f9cd8: ldr             x2, [x2, #0x3f0]
    // 0x4f9cdc: r0 = []=()
    //     0x4f9cdc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9ce0: r0 = LoadStaticField(0xfb4)
    //     0x4f9ce0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f9ce4: ldr             x0, [x0, #0x1f68]
    // 0x4f9ce8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f9cec: cmp             w0, w16
    // 0x4f9cf0: b.ne            #0x4f9d00
    // 0x4f9cf4: r2 = generatorStateGroup
    //     0x4f9cf4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x4f9cf8: ldr             x2, [x2, #0x138]
    // 0x4f9cfc: r0 = InitLateStaticField()
    //     0x4f9cfc: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f9d00: mov             x1, x0
    // 0x4f9d04: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f9d04: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f9d08: r0 = notifyAll()
    //     0x4f9d08: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9d0c: r0 = Null
    //     0x4f9d0c: mov             x0, NULL
    // 0x4f9d10: LeaveFrame
    //     0x4f9d10: mov             SP, fp
    //     0x4f9d14: ldp             fp, lr, [SP], #0x10
    // 0x4f9d18: ret
    //     0x4f9d18: ret             
    // 0x4f9d1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9d1c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9d20: b               #0x4f9c58
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9d24, size: 0xc
    // 0x4f9d24: r0 = "300 bonus script generators."
    //     0x4f9d24: add             x0, PP, #0x16, lsl #12  ; [pp+0x16290] "300 bonus script generators."
    //     0x4f9d28: ldr             x0, [x0, #0x290]
    // 0x4f9d2c: ret
    //     0x4f9d2c: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9d30, size: 0xc
    // 0x4f9d30: r0 = "Drops all prices by 99.9%."
    //     0x4f9d30: add             x0, PP, #0x16, lsl #12  ; [pp+0x16298] "Drops all prices by 99.9%."
    //     0x4f9d34: ldr             x0, [x0, #0x298]
    // 0x4f9d38: ret
    //     0x4f9d38: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9d3c, size: 0xc
    // 0x4f9d3c: r0 = "30× yields on first four generators."
    //     0x4f9d3c: add             x0, PP, #0x16, lsl #12  ; [pp+0x162a0] "30× yields on first four generators."
    //     0x4f9d40: ldr             x0, [x0, #0x2a0]
    // 0x4f9d44: ret
    //     0x4f9d44: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f9d48, size: 0xf0
    // 0x4f9d48: EnterFrame
    //     0x4f9d48: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9d4c: mov             fp, SP
    // 0x4f9d50: AllocStack(0x10)
    //     0x4f9d50: sub             SP, SP, #0x10
    // 0x4f9d54: SetupParameters([dynamic _ /* r0 */])
    //     0x4f9d54: ldr             x0, [fp, #0x18]
    //     0x4f9d58: ldur            w1, [x0, #0x17]
    //     0x4f9d5c: add             x1, x1, HEAP, lsl #32
    // 0x4f9d60: CheckStackOverflow
    //     0x4f9d60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9d64: cmp             SP, x16
    //     0x4f9d68: b.ls            #0x4f9e30
    // 0x4f9d6c: LoadField: r0 = r1->field_f
    //     0x4f9d6c: ldur            w0, [x1, #0xf]
    // 0x4f9d70: DecompressPointer r0
    //     0x4f9d70: add             x0, x0, HEAP, lsl #32
    // 0x4f9d74: LoadField: r3 = r0->field_37
    //     0x4f9d74: ldur            w3, [x0, #0x37]
    // 0x4f9d78: DecompressPointer r3
    //     0x4f9d78: add             x3, x3, HEAP, lsl #32
    // 0x4f9d7c: mov             x1, x3
    // 0x4f9d80: stur            x3, [fp, #-8]
    // 0x4f9d84: r2 = Instance_Chapter12Stat
    //     0x4f9d84: add             x2, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x4f9d88: ldr             x2, [x2, #0x410]
    // 0x4f9d8c: r0 = _getValueOrData()
    //     0x4f9d8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9d90: mov             x1, x0
    // 0x4f9d94: ldur            x0, [fp, #-8]
    // 0x4f9d98: LoadField: r2 = r0->field_f
    //     0x4f9d98: ldur            w2, [x0, #0xf]
    // 0x4f9d9c: DecompressPointer r2
    //     0x4f9d9c: add             x2, x2, HEAP, lsl #32
    // 0x4f9da0: cmp             w2, w1
    // 0x4f9da4: b.ne            #0x4f9dac
    // 0x4f9da8: r1 = Null
    //     0x4f9da8: mov             x1, NULL
    // 0x4f9dac: cmp             w1, NULL
    // 0x4f9db0: b.ne            #0x4f9dc0
    // 0x4f9db4: r3 = Instance_CustomNum
    //     0x4f9db4: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f9db8: ldr             x3, [x3, #0xaf8]
    // 0x4f9dbc: b               #0x4f9dc4
    // 0x4f9dc0: mov             x3, x1
    // 0x4f9dc4: stur            x3, [fp, #-0x10]
    // 0x4f9dc8: r1 = Null
    //     0x4f9dc8: mov             x1, NULL
    // 0x4f9dcc: r2 = 20
    //     0x4f9dcc: movz            x2, #0x14
    // 0x4f9dd0: r0 = CustomNum()
    //     0x4f9dd0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f9dd4: ldur            x1, [fp, #-0x10]
    // 0x4f9dd8: mov             x2, x0
    // 0x4f9ddc: r0 = add()
    //     0x4f9ddc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9de0: ldur            x1, [fp, #-8]
    // 0x4f9de4: mov             x3, x0
    // 0x4f9de8: r2 = Instance_Chapter12Stat
    //     0x4f9de8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x4f9dec: ldr             x2, [x2, #0x410]
    // 0x4f9df0: r0 = []=()
    //     0x4f9df0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9df4: r0 = LoadStaticField(0xfb4)
    //     0x4f9df4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f9df8: ldr             x0, [x0, #0x1f68]
    // 0x4f9dfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f9e00: cmp             w0, w16
    // 0x4f9e04: b.ne            #0x4f9e14
    // 0x4f9e08: r2 = generatorStateGroup
    //     0x4f9e08: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x4f9e0c: ldr             x2, [x2, #0x138]
    // 0x4f9e10: r0 = InitLateStaticField()
    //     0x4f9e10: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f9e14: mov             x1, x0
    // 0x4f9e18: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f9e18: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f9e1c: r0 = notifyAll()
    //     0x4f9e1c: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9e20: r0 = Null
    //     0x4f9e20: mov             x0, NULL
    // 0x4f9e24: LeaveFrame
    //     0x4f9e24: mov             SP, fp
    //     0x4f9e28: ldp             fp, lr, [SP], #0x10
    // 0x4f9e2c: ret
    //     0x4f9e2c: ret             
    // 0x4f9e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9e30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9e34: b               #0x4f9d6c
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9e38, size: 0xc
    // 0x4f9e38: r0 = "Awards 10 port prober generators."
    //     0x4f9e38: add             x0, PP, #0x16, lsl #12  ; [pp+0x162a8] "Awards 10 port prober generators."
    //     0x4f9e3c: ldr             x0, [x0, #0x2a8]
    // 0x4f9e40: ret
    //     0x4f9e40: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9e44, size: 0xc
    // 0x4f9e44: r0 = "Significantly improves rolling investigation and deep research upggrades."
    //     0x4f9e44: add             x0, PP, #0x16, lsl #12  ; [pp+0x162b0] "Significantly improves rolling investigation and deep research upggrades."
    //     0x4f9e48: ldr             x0, [x0, #0x2b0]
    // 0x4f9e4c: ret
    //     0x4f9e4c: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f9e50, size: 0xf0
    // 0x4f9e50: EnterFrame
    //     0x4f9e50: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9e54: mov             fp, SP
    // 0x4f9e58: AllocStack(0x10)
    //     0x4f9e58: sub             SP, SP, #0x10
    // 0x4f9e5c: SetupParameters([dynamic _ /* r0 */])
    //     0x4f9e5c: ldr             x0, [fp, #0x18]
    //     0x4f9e60: ldur            w1, [x0, #0x17]
    //     0x4f9e64: add             x1, x1, HEAP, lsl #32
    // 0x4f9e68: CheckStackOverflow
    //     0x4f9e68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9e6c: cmp             SP, x16
    //     0x4f9e70: b.ls            #0x4f9f38
    // 0x4f9e74: LoadField: r0 = r1->field_f
    //     0x4f9e74: ldur            w0, [x1, #0xf]
    // 0x4f9e78: DecompressPointer r0
    //     0x4f9e78: add             x0, x0, HEAP, lsl #32
    // 0x4f9e7c: LoadField: r3 = r0->field_37
    //     0x4f9e7c: ldur            w3, [x0, #0x37]
    // 0x4f9e80: DecompressPointer r3
    //     0x4f9e80: add             x3, x3, HEAP, lsl #32
    // 0x4f9e84: mov             x1, x3
    // 0x4f9e88: stur            x3, [fp, #-8]
    // 0x4f9e8c: r2 = Instance_Chapter12Stat
    //     0x4f9e8c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11408] Obj!Chapter12Stat@85fc61
    //     0x4f9e90: ldr             x2, [x2, #0x408]
    // 0x4f9e94: r0 = _getValueOrData()
    //     0x4f9e94: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4f9e98: mov             x1, x0
    // 0x4f9e9c: ldur            x0, [fp, #-8]
    // 0x4f9ea0: LoadField: r2 = r0->field_f
    //     0x4f9ea0: ldur            w2, [x0, #0xf]
    // 0x4f9ea4: DecompressPointer r2
    //     0x4f9ea4: add             x2, x2, HEAP, lsl #32
    // 0x4f9ea8: cmp             w2, w1
    // 0x4f9eac: b.ne            #0x4f9eb4
    // 0x4f9eb0: r1 = Null
    //     0x4f9eb0: mov             x1, NULL
    // 0x4f9eb4: cmp             w1, NULL
    // 0x4f9eb8: b.ne            #0x4f9ec8
    // 0x4f9ebc: r3 = Instance_CustomNum
    //     0x4f9ebc: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x4f9ec0: ldr             x3, [x3, #0xaf8]
    // 0x4f9ec4: b               #0x4f9ecc
    // 0x4f9ec8: mov             x3, x1
    // 0x4f9ecc: stur            x3, [fp, #-0x10]
    // 0x4f9ed0: r1 = Null
    //     0x4f9ed0: mov             x1, NULL
    // 0x4f9ed4: r2 = 200
    //     0x4f9ed4: movz            x2, #0xc8
    // 0x4f9ed8: r0 = CustomNum()
    //     0x4f9ed8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f9edc: ldur            x1, [fp, #-0x10]
    // 0x4f9ee0: mov             x2, x0
    // 0x4f9ee4: r0 = add()
    //     0x4f9ee4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4f9ee8: ldur            x1, [fp, #-8]
    // 0x4f9eec: mov             x3, x0
    // 0x4f9ef0: r2 = Instance_Chapter12Stat
    //     0x4f9ef0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11408] Obj!Chapter12Stat@85fc61
    //     0x4f9ef4: ldr             x2, [x2, #0x408]
    // 0x4f9ef8: r0 = []=()
    //     0x4f9ef8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4f9efc: r0 = LoadStaticField(0xfb4)
    //     0x4f9efc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f9f00: ldr             x0, [x0, #0x1f68]
    // 0x4f9f04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f9f08: cmp             w0, w16
    // 0x4f9f0c: b.ne            #0x4f9f1c
    // 0x4f9f10: r2 = generatorStateGroup
    //     0x4f9f10: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x4f9f14: ldr             x2, [x2, #0x138]
    // 0x4f9f18: r0 = InitLateStaticField()
    //     0x4f9f18: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f9f1c: mov             x1, x0
    // 0x4f9f20: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4f9f20: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4f9f24: r0 = notifyAll()
    //     0x4f9f24: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x4f9f28: r0 = Null
    //     0x4f9f28: mov             x0, NULL
    // 0x4f9f2c: LeaveFrame
    //     0x4f9f2c: mov             SP, fp
    //     0x4f9f30: ldp             fp, lr, [SP], #0x10
    // 0x4f9f34: ret
    //     0x4f9f34: ret             
    // 0x4f9f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f9f38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9f3c: b               #0x4f9e74
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f40, size: 0xc
    // 0x4f9f40: r0 = "Awards 100 bonus reverse engineering generators."
    //     0x4f9f40: add             x0, PP, #0x16, lsl #12  ; [pp+0x162b8] "Awards 100 bonus reverse engineering generators."
    //     0x4f9f44: ldr             x0, [x0, #0x2b8]
    // 0x4f9f48: ret
    //     0x4f9f48: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f4c, size: 0xc
    // 0x4f9f4c: r0 = "500× research gain from log analyzer."
    //     0x4f9f4c: add             x0, PP, #0x16, lsl #12  ; [pp+0x162c0] "500× research gain from log analyzer."
    //     0x4f9f50: ldr             x0, [x0, #0x2c0]
    // 0x4f9f54: ret
    //     0x4f9f54: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f58, size: 0xc
    // 0x4f9f58: r0 = "5,000× research gain from scripts."
    //     0x4f9f58: add             x0, PP, #0x16, lsl #12  ; [pp+0x162c8] "5,000× research gain from scripts."
    //     0x4f9f5c: ldr             x0, [x0, #0x2c8]
    // 0x4f9f60: ret
    //     0x4f9f60: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f64, size: 0xc
    // 0x4f9f64: r0 = "15× research points from the network scanner."
    //     0x4f9f64: add             x0, PP, #0x16, lsl #12  ; [pp+0x162d0] "15× research points from the network scanner."
    //     0x4f9f68: ldr             x0, [x0, #0x2d0]
    // 0x4f9f6c: ret
    //     0x4f9f6c: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f70, size: 0xc
    // 0x4f9f70: r0 = "1477× research points from long pressing the investigate button."
    //     0x4f9f70: add             x0, PP, #0x16, lsl #12  ; [pp+0x162d8] "1477× research points from long pressing the investigate button."
    //     0x4f9f74: ldr             x0, [x0, #0x2d8]
    // 0x4f9f78: ret
    //     0x4f9f78: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f7c, size: 0xc
    // 0x4f9f7c: r0 = "6× research gain from scripts."
    //     0x4f9f7c: add             x0, PP, #0x16, lsl #12  ; [pp+0x162e0] "6× research gain from scripts."
    //     0x4f9f80: ldr             x0, [x0, #0x2e0]
    // 0x4f9f84: ret
    //     0x4f9f84: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f88, size: 0xc
    // 0x4f9f88: r0 = "437× research gain from long pressing the investigate button."
    //     0x4f9f88: add             x0, PP, #0x16, lsl #12  ; [pp+0x162e8] "437× research gain from long pressing the investigate button."
    //     0x4f9f8c: ldr             x0, [x0, #0x2e8]
    // 0x4f9f90: ret
    //     0x4f9f90: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f9f94, size: 0xc8
    // 0x4f9f94: EnterFrame
    //     0x4f9f94: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9f98: mov             fp, SP
    // 0x4f9f9c: AllocStack(0x18)
    //     0x4f9f9c: sub             SP, SP, #0x18
    // 0x4f9fa0: SetupParameters([dynamic _ /* r0 */])
    //     0x4f9fa0: ldr             x0, [fp, #0x18]
    //     0x4f9fa4: ldur            w3, [x0, #0x17]
    //     0x4f9fa8: add             x3, x3, HEAP, lsl #32
    //     0x4f9fac: stur            x3, [fp, #-8]
    // 0x4f9fb0: CheckStackOverflow
    //     0x4f9fb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9fb4: cmp             SP, x16
    //     0x4f9fb8: b.ls            #0x4fa054
    // 0x4f9fbc: r1 = Null
    //     0x4f9fbc: mov             x1, NULL
    // 0x4f9fc0: r2 = 6
    //     0x4f9fc0: movz            x2, #0x6
    // 0x4f9fc4: r0 = AllocateArray()
    //     0x4f9fc4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f9fc8: stur            x0, [fp, #-0x10]
    // 0x4f9fcc: r16 = "Increases research gain by "
    //     0x4f9fcc: add             x16, PP, #0x16, lsl #12  ; [pp+0x162f0] "Increases research gain by "
    //     0x4f9fd0: ldr             x16, [x16, #0x2f0]
    // 0x4f9fd4: StoreField: r0->field_f = r16
    //     0x4f9fd4: stur            w16, [x0, #0xf]
    // 0x4f9fd8: ldur            x1, [fp, #-8]
    // 0x4f9fdc: LoadField: r2 = r1->field_f
    //     0x4f9fdc: ldur            w2, [x1, #0xf]
    // 0x4f9fe0: DecompressPointer r2
    //     0x4f9fe0: add             x2, x2, HEAP, lsl #32
    // 0x4f9fe4: ldr             x1, [fp, #0x10]
    // 0x4f9fe8: r3 = LoadInt32Instr(r1)
    //     0x4f9fe8: sbfx            x3, x1, #1, #0x1f
    //     0x4f9fec: tbz             w1, #0, #0x4f9ff4
    //     0x4f9ff0: ldur            x3, [x1, #7]
    // 0x4f9ff4: add             x1, x3, #1
    // 0x4f9ff8: mov             x16, x1
    // 0x4f9ffc: mov             x1, x2
    // 0x4fa000: mov             x2, x16
    // 0x4fa004: r0 = getBasicBoostHold()
    //     0x4fa004: bl              #0x4fa05c  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getBasicBoostHold
    // 0x4fa008: ldur            x1, [fp, #-0x10]
    // 0x4fa00c: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fa00c: add             x25, x1, #0x13
    //     0x4fa010: str             w0, [x25]
    //     0x4fa014: tbz             w0, #0, #0x4fa030
    //     0x4fa018: ldurb           w16, [x1, #-1]
    //     0x4fa01c: ldurb           w17, [x0, #-1]
    //     0x4fa020: and             x16, x17, x16, lsr #2
    //     0x4fa024: tst             x16, HEAP, lsr #32
    //     0x4fa028: b.eq            #0x4fa030
    //     0x4fa02c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fa030: ldur            x0, [fp, #-0x10]
    // 0x4fa034: r16 = "×."
    //     0x4fa034: add             x16, PP, #0x14, lsl #12  ; [pp+0x14008] "×."
    //     0x4fa038: ldr             x16, [x16, #8]
    // 0x4fa03c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fa03c: stur            w16, [x0, #0x17]
    // 0x4fa040: str             x0, [SP]
    // 0x4fa044: r0 = _interpolate()
    //     0x4fa044: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fa048: LeaveFrame
    //     0x4fa048: mov             SP, fp
    //     0x4fa04c: ldp             fp, lr, [SP], #0x10
    // 0x4fa050: ret
    //     0x4fa050: ret             
    // 0x4fa054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa054: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa058: b               #0x4f9fbc
  }
  _ getBasicBoostHold(/* No info */) {
    // ** addr: 0x4fa05c, size: 0x298
    // 0x4fa05c: EnterFrame
    //     0x4fa05c: stp             fp, lr, [SP, #-0x10]!
    //     0x4fa060: mov             fp, SP
    // 0x4fa064: AllocStack(0x20)
    //     0x4fa064: sub             SP, SP, #0x20
    // 0x4fa068: SetupParameters(Chapter12GameState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x4fa068: mov             x3, x1
    //     0x4fa06c: mov             x0, x2
    //     0x4fa070: stur            x1, [fp, #-8]
    //     0x4fa074: stur            x2, [fp, #-0x10]
    // 0x4fa078: CheckStackOverflow
    //     0x4fa078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fa07c: cmp             SP, x16
    //     0x4fa080: b.ls            #0x4fa2b4
    // 0x4fa084: LoadField: r1 = r3->field_43
    //     0x4fa084: ldur            w1, [x3, #0x43]
    // 0x4fa088: DecompressPointer r1
    //     0x4fa088: add             x1, x1, HEAP, lsl #32
    // 0x4fa08c: r2 = 214
    //     0x4fa08c: movz            x2, #0xd6
    // 0x4fa090: r0 = containsKey()
    //     0x4fa090: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x4fa094: tbnz            w0, #4, #0x4fa1a0
    // 0x4fa098: ldur            x0, [fp, #-8]
    // 0x4fa09c: r1 = Null
    //     0x4fa09c: mov             x1, NULL
    // 0x4fa0a0: r2 = 1.750000
    //     0x4fa0a0: add             x2, PP, #0x16, lsl #12  ; [pp+0x162f8] 1.75
    //     0x4fa0a4: ldr             x2, [x2, #0x2f8]
    // 0x4fa0a8: r0 = CustomNum()
    //     0x4fa0a8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fa0ac: mov             x3, x0
    // 0x4fa0b0: ldur            x0, [fp, #-8]
    // 0x4fa0b4: stur            x3, [fp, #-0x20]
    // 0x4fa0b8: LoadField: r1 = r0->field_3f
    //     0x4fa0b8: ldur            w1, [x0, #0x3f]
    // 0x4fa0bc: DecompressPointer r1
    //     0x4fa0bc: add             x1, x1, HEAP, lsl #32
    // 0x4fa0c0: LoadField: r0 = r1->field_b
    //     0x4fa0c0: ldur            w0, [x1, #0xb]
    // 0x4fa0c4: DecompressPointer r0
    //     0x4fa0c4: add             x0, x0, HEAP, lsl #32
    // 0x4fa0c8: mov             x1, x0
    // 0x4fa0cc: stur            x0, [fp, #-0x18]
    // 0x4fa0d0: r2 = 2
    //     0x4fa0d0: movz            x2, #0x2
    // 0x4fa0d4: r0 = _getValueOrData()
    //     0x4fa0d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fa0d8: mov             x1, x0
    // 0x4fa0dc: ldur            x0, [fp, #-0x18]
    // 0x4fa0e0: LoadField: r2 = r0->field_f
    //     0x4fa0e0: ldur            w2, [x0, #0xf]
    // 0x4fa0e4: DecompressPointer r2
    //     0x4fa0e4: add             x2, x2, HEAP, lsl #32
    // 0x4fa0e8: cmp             w2, w1
    // 0x4fa0ec: b.ne            #0x4fa0f8
    // 0x4fa0f0: r0 = Null
    //     0x4fa0f0: mov             x0, NULL
    // 0x4fa0f4: b               #0x4fa0fc
    // 0x4fa0f8: mov             x0, x1
    // 0x4fa0fc: cmp             w0, NULL
    // 0x4fa100: b.ne            #0x4fa10c
    // 0x4fa104: r1 = 0
    //     0x4fa104: movz            x1, #0
    // 0x4fa108: b               #0x4fa118
    // 0x4fa10c: r1 = LoadInt32Instr(r0)
    //     0x4fa10c: sbfx            x1, x0, #1, #0x1f
    //     0x4fa110: tbz             w0, #0, #0x4fa118
    //     0x4fa114: ldur            x1, [x0, #7]
    // 0x4fa118: ldur            x0, [fp, #-0x10]
    // 0x4fa11c: d0 = 0.200000
    //     0x4fa11c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(0.2) from 0x3fc999999999999a
    //     0x4fa120: ldr             d0, [x17, #0xfa8]
    // 0x4fa124: scvtf           d1, x1
    // 0x4fa128: fmul            d2, d1, d0
    // 0x4fa12c: r2 = inline_Allocate_Double()
    //     0x4fa12c: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x4fa130: add             x2, x2, #0x10
    //     0x4fa134: cmp             x1, x2
    //     0x4fa138: b.ls            #0x4fa2bc
    //     0x4fa13c: str             x2, [THR, #0x60]  ; THR::top
    //     0x4fa140: sub             x2, x2, #0xf
    //     0x4fa144: movz            x1, #0xe19c
    //     0x4fa148: movk            x1, #0x3, lsl #16
    //     0x4fa14c: stur            x1, [x2, #-1]
    // 0x4fa150: dmb             ishst
    // 0x4fa154: StoreField: r2->field_7 = d2
    //     0x4fa154: stur            d2, [x2, #7]
    // 0x4fa158: r1 = Null
    //     0x4fa158: mov             x1, NULL
    // 0x4fa15c: r0 = CustomNum()
    //     0x4fa15c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fa160: ldur            x1, [fp, #-0x20]
    // 0x4fa164: mov             x2, x0
    // 0x4fa168: r0 = add()
    //     0x4fa168: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4fa16c: mov             x2, x0
    // 0x4fa170: ldur            x3, [fp, #-0x10]
    // 0x4fa174: r0 = BoxInt64Instr(r3)
    //     0x4fa174: sbfiz           x0, x3, #1, #0x1f
    //     0x4fa178: cmp             x3, x0, asr #1
    //     0x4fa17c: b.eq            #0x4fa188
    //     0x4fa180: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4fa184: stur            x3, [x0, #7]
    // 0x4fa188: mov             x1, x2
    // 0x4fa18c: mov             x2, x0
    // 0x4fa190: r0 = pow()
    //     0x4fa190: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x4fa194: LeaveFrame
    //     0x4fa194: mov             SP, fp
    //     0x4fa198: ldp             fp, lr, [SP], #0x10
    // 0x4fa19c: ret
    //     0x4fa19c: ret             
    // 0x4fa1a0: ldur            x0, [fp, #-8]
    // 0x4fa1a4: ldur            x3, [fp, #-0x10]
    // 0x4fa1a8: d0 = 0.200000
    //     0x4fa1a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(0.2) from 0x3fc999999999999a
    //     0x4fa1ac: ldr             d0, [x17, #0xfa8]
    // 0x4fa1b0: r1 = Null
    //     0x4fa1b0: mov             x1, NULL
    // 0x4fa1b4: r2 = 1.500000
    //     0x4fa1b4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce8] 1.5
    //     0x4fa1b8: ldr             x2, [x2, #0xce8]
    // 0x4fa1bc: r0 = CustomNum()
    //     0x4fa1bc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fa1c0: mov             x3, x0
    // 0x4fa1c4: ldur            x0, [fp, #-8]
    // 0x4fa1c8: stur            x3, [fp, #-0x18]
    // 0x4fa1cc: LoadField: r1 = r0->field_3f
    //     0x4fa1cc: ldur            w1, [x0, #0x3f]
    // 0x4fa1d0: DecompressPointer r1
    //     0x4fa1d0: add             x1, x1, HEAP, lsl #32
    // 0x4fa1d4: LoadField: r0 = r1->field_b
    //     0x4fa1d4: ldur            w0, [x1, #0xb]
    // 0x4fa1d8: DecompressPointer r0
    //     0x4fa1d8: add             x0, x0, HEAP, lsl #32
    // 0x4fa1dc: mov             x1, x0
    // 0x4fa1e0: stur            x0, [fp, #-8]
    // 0x4fa1e4: r2 = 2
    //     0x4fa1e4: movz            x2, #0x2
    // 0x4fa1e8: r0 = _getValueOrData()
    //     0x4fa1e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fa1ec: mov             x1, x0
    // 0x4fa1f0: ldur            x0, [fp, #-8]
    // 0x4fa1f4: LoadField: r2 = r0->field_f
    //     0x4fa1f4: ldur            w2, [x0, #0xf]
    // 0x4fa1f8: DecompressPointer r2
    //     0x4fa1f8: add             x2, x2, HEAP, lsl #32
    // 0x4fa1fc: cmp             w2, w1
    // 0x4fa200: b.ne            #0x4fa20c
    // 0x4fa204: r0 = Null
    //     0x4fa204: mov             x0, NULL
    // 0x4fa208: b               #0x4fa210
    // 0x4fa20c: mov             x0, x1
    // 0x4fa210: cmp             w0, NULL
    // 0x4fa214: b.ne            #0x4fa220
    // 0x4fa218: r1 = 0
    //     0x4fa218: movz            x1, #0
    // 0x4fa21c: b               #0x4fa22c
    // 0x4fa220: r1 = LoadInt32Instr(r0)
    //     0x4fa220: sbfx            x1, x0, #1, #0x1f
    //     0x4fa224: tbz             w0, #0, #0x4fa22c
    //     0x4fa228: ldur            x1, [x0, #7]
    // 0x4fa22c: ldur            x0, [fp, #-0x10]
    // 0x4fa230: d0 = 0.200000
    //     0x4fa230: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(0.2) from 0x3fc999999999999a
    //     0x4fa234: ldr             d0, [x17, #0xfa8]
    // 0x4fa238: scvtf           d1, x1
    // 0x4fa23c: fmul            d2, d1, d0
    // 0x4fa240: r2 = inline_Allocate_Double()
    //     0x4fa240: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x4fa244: add             x2, x2, #0x10
    //     0x4fa248: cmp             x1, x2
    //     0x4fa24c: b.ls            #0x4fa2d8
    //     0x4fa250: str             x2, [THR, #0x60]  ; THR::top
    //     0x4fa254: sub             x2, x2, #0xf
    //     0x4fa258: movz            x1, #0xe19c
    //     0x4fa25c: movk            x1, #0x3, lsl #16
    //     0x4fa260: stur            x1, [x2, #-1]
    // 0x4fa264: dmb             ishst
    // 0x4fa268: StoreField: r2->field_7 = d2
    //     0x4fa268: stur            d2, [x2, #7]
    // 0x4fa26c: r1 = Null
    //     0x4fa26c: mov             x1, NULL
    // 0x4fa270: r0 = CustomNum()
    //     0x4fa270: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fa274: ldur            x1, [fp, #-0x18]
    // 0x4fa278: mov             x2, x0
    // 0x4fa27c: r0 = add()
    //     0x4fa27c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x4fa280: mov             x3, x0
    // 0x4fa284: ldur            x2, [fp, #-0x10]
    // 0x4fa288: r0 = BoxInt64Instr(r2)
    //     0x4fa288: sbfiz           x0, x2, #1, #0x1f
    //     0x4fa28c: cmp             x2, x0, asr #1
    //     0x4fa290: b.eq            #0x4fa29c
    //     0x4fa294: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4fa298: stur            x2, [x0, #7]
    // 0x4fa29c: mov             x1, x3
    // 0x4fa2a0: mov             x2, x0
    // 0x4fa2a4: r0 = pow()
    //     0x4fa2a4: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x4fa2a8: LeaveFrame
    //     0x4fa2a8: mov             SP, fp
    //     0x4fa2ac: ldp             fp, lr, [SP], #0x10
    // 0x4fa2b0: ret
    //     0x4fa2b0: ret             
    // 0x4fa2b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa2b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa2b8: b               #0x4fa084
    // 0x4fa2bc: SaveReg d2
    //     0x4fa2bc: str             q2, [SP, #-0x10]!
    // 0x4fa2c0: SaveReg r0
    //     0x4fa2c0: str             x0, [SP, #-8]!
    // 0x4fa2c4: r0 = AllocateDouble()
    //     0x4fa2c4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fa2c8: mov             x2, x0
    // 0x4fa2cc: RestoreReg r0
    //     0x4fa2cc: ldr             x0, [SP], #8
    // 0x4fa2d0: RestoreReg d2
    //     0x4fa2d0: ldr             q2, [SP], #0x10
    // 0x4fa2d4: b               #0x4fa154
    // 0x4fa2d8: SaveReg d2
    //     0x4fa2d8: str             q2, [SP, #-0x10]!
    // 0x4fa2dc: SaveReg r0
    //     0x4fa2dc: str             x0, [SP, #-8]!
    // 0x4fa2e0: r0 = AllocateDouble()
    //     0x4fa2e0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fa2e4: mov             x2, x0
    // 0x4fa2e8: RestoreReg r0
    //     0x4fa2e8: ldr             x0, [SP], #8
    // 0x4fa2ec: RestoreReg d2
    //     0x4fa2ec: ldr             q2, [SP], #0x10
    // 0x4fa2f0: b               #0x4fa268
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4fa2f4, size: 0xdc
    // 0x4fa2f4: EnterFrame
    //     0x4fa2f4: stp             fp, lr, [SP, #-0x10]!
    //     0x4fa2f8: mov             fp, SP
    // 0x4fa2fc: AllocStack(0x20)
    //     0x4fa2fc: sub             SP, SP, #0x20
    // 0x4fa300: SetupParameters([dynamic _ /* r0 */])
    //     0x4fa300: ldr             x0, [fp, #0x18]
    //     0x4fa304: ldur            w3, [x0, #0x17]
    //     0x4fa308: add             x3, x3, HEAP, lsl #32
    //     0x4fa30c: stur            x3, [fp, #-0x10]
    // 0x4fa310: CheckStackOverflow
    //     0x4fa310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fa314: cmp             SP, x16
    //     0x4fa318: b.ls            #0x4fa3c8
    // 0x4fa31c: ldr             x0, [fp, #0x10]
    // 0x4fa320: r4 = LoadInt32Instr(r0)
    //     0x4fa320: sbfx            x4, x0, #1, #0x1f
    //     0x4fa324: tbz             w0, #0, #0x4fa32c
    //     0x4fa328: ldur            x4, [x0, #7]
    // 0x4fa32c: stur            x4, [fp, #-8]
    // 0x4fa330: cbnz            x4, #0x4fa348
    // 0x4fa334: r0 = "Allows long pressing the investigate button."
    //     0x4fa334: add             x0, PP, #0x16, lsl #12  ; [pp+0x16300] "Allows long pressing the investigate button."
    //     0x4fa338: ldr             x0, [x0, #0x300]
    // 0x4fa33c: LeaveFrame
    //     0x4fa33c: mov             SP, fp
    //     0x4fa340: ldp             fp, lr, [SP], #0x10
    // 0x4fa344: ret
    //     0x4fa344: ret             
    // 0x4fa348: r1 = Null
    //     0x4fa348: mov             x1, NULL
    // 0x4fa34c: r2 = 6
    //     0x4fa34c: movz            x2, #0x6
    // 0x4fa350: r0 = AllocateArray()
    //     0x4fa350: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fa354: stur            x0, [fp, #-0x18]
    // 0x4fa358: r16 = "Long pressing the investigate button now gives "
    //     0x4fa358: add             x16, PP, #0x16, lsl #12  ; [pp+0x16308] "Long pressing the investigate button now gives "
    //     0x4fa35c: ldr             x16, [x16, #0x308]
    // 0x4fa360: StoreField: r0->field_f = r16
    //     0x4fa360: stur            w16, [x0, #0xf]
    // 0x4fa364: ldur            x1, [fp, #-0x10]
    // 0x4fa368: LoadField: r2 = r1->field_f
    //     0x4fa368: ldur            w2, [x1, #0xf]
    // 0x4fa36c: DecompressPointer r2
    //     0x4fa36c: add             x2, x2, HEAP, lsl #32
    // 0x4fa370: mov             x1, x2
    // 0x4fa374: ldur            x2, [fp, #-8]
    // 0x4fa378: r0 = getBasicBoostHold()
    //     0x4fa378: bl              #0x4fa05c  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getBasicBoostHold
    // 0x4fa37c: ldur            x1, [fp, #-0x18]
    // 0x4fa380: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fa380: add             x25, x1, #0x13
    //     0x4fa384: str             w0, [x25]
    //     0x4fa388: tbz             w0, #0, #0x4fa3a4
    //     0x4fa38c: ldurb           w16, [x1, #-1]
    //     0x4fa390: ldurb           w17, [x0, #-1]
    //     0x4fa394: and             x16, x17, x16, lsr #2
    //     0x4fa398: tst             x16, HEAP, lsr #32
    //     0x4fa39c: b.eq            #0x4fa3a4
    //     0x4fa3a0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fa3a4: ldur            x0, [fp, #-0x18]
    // 0x4fa3a8: r16 = "× more research."
    //     0x4fa3a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16310] "× more research."
    //     0x4fa3ac: ldr             x16, [x16, #0x310]
    // 0x4fa3b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fa3b0: stur            w16, [x0, #0x17]
    // 0x4fa3b4: str             x0, [SP]
    // 0x4fa3b8: r0 = _interpolate()
    //     0x4fa3b8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fa3bc: LeaveFrame
    //     0x4fa3bc: mov             SP, fp
    //     0x4fa3c0: ldp             fp, lr, [SP], #0x10
    // 0x4fa3c4: ret
    //     0x4fa3c4: ret             
    // 0x4fa3c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fa3c8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fa3cc: b               #0x4fa31c
  }
  _ postUpdateCallback(/* No info */) {
    // ** addr: 0x543cb0, size: 0x198
    // 0x543cb0: EnterFrame
    //     0x543cb0: stp             fp, lr, [SP, #-0x10]!
    //     0x543cb4: mov             fp, SP
    // 0x543cb8: AllocStack(0x28)
    //     0x543cb8: sub             SP, SP, #0x28
    // 0x543cbc: SetupParameters(Chapter12GameState this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x543cbc: mov             x4, x1
    //     0x543cc0: mov             x0, x2
    //     0x543cc4: stur            x1, [fp, #-0x18]
    //     0x543cc8: stur            x2, [fp, #-0x20]
    // 0x543ccc: CheckStackOverflow
    //     0x543ccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x543cd0: cmp             SP, x16
    //     0x543cd4: b.ls            #0x543e40
    // 0x543cd8: LoadField: r3 = r4->field_2f
    //     0x543cd8: ldur            w3, [x4, #0x2f]
    // 0x543cdc: DecompressPointer r3
    //     0x543cdc: add             x3, x3, HEAP, lsl #32
    // 0x543ce0: stur            x3, [fp, #-0x10]
    // 0x543ce4: LoadField: r5 = r4->field_43
    //     0x543ce4: ldur            w5, [x4, #0x43]
    // 0x543ce8: DecompressPointer r5
    //     0x543ce8: add             x5, x5, HEAP, lsl #32
    // 0x543cec: mov             x1, x5
    // 0x543cf0: stur            x5, [fp, #-8]
    // 0x543cf4: r2 = 4
    //     0x543cf4: movz            x2, #0x4
    // 0x543cf8: r0 = _getValueOrData()
    //     0x543cf8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x543cfc: mov             x1, x0
    // 0x543d00: ldur            x0, [fp, #-8]
    // 0x543d04: LoadField: r2 = r0->field_f
    //     0x543d04: ldur            w2, [x0, #0xf]
    // 0x543d08: DecompressPointer r2
    //     0x543d08: add             x2, x2, HEAP, lsl #32
    // 0x543d0c: cmp             w2, w1
    // 0x543d10: b.ne            #0x543d1c
    // 0x543d14: r0 = Null
    //     0x543d14: mov             x0, NULL
    // 0x543d18: b               #0x543d20
    // 0x543d1c: mov             x0, x1
    // 0x543d20: cmp             w0, NULL
    // 0x543d24: b.ne            #0x543d30
    // 0x543d28: r2 = 0
    //     0x543d28: movz            x2, #0
    // 0x543d2c: b               #0x543d40
    // 0x543d30: r1 = LoadInt32Instr(r0)
    //     0x543d30: sbfx            x1, x0, #1, #0x1f
    //     0x543d34: tbz             w0, #0, #0x543d3c
    //     0x543d38: ldur            x1, [x0, #7]
    // 0x543d3c: mov             x2, x1
    // 0x543d40: ldur            x0, [fp, #-0x18]
    // 0x543d44: mov             x1, x0
    // 0x543d48: r0 = getBasicBoostNormal()
    //     0x543d48: bl              #0x544188  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getBasicBoostNormal
    // 0x543d4c: mov             x3, x0
    // 0x543d50: ldur            x0, [fp, #-0x18]
    // 0x543d54: stur            x3, [fp, #-0x28]
    // 0x543d58: LoadField: r4 = r0->field_37
    //     0x543d58: ldur            w4, [x0, #0x37]
    // 0x543d5c: DecompressPointer r4
    //     0x543d5c: add             x4, x4, HEAP, lsl #32
    // 0x543d60: mov             x1, x4
    // 0x543d64: stur            x4, [fp, #-8]
    // 0x543d68: r2 = Instance_Chapter12Stat
    //     0x543d68: add             x2, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x543d6c: ldr             x2, [x2, #0x498]
    // 0x543d70: r0 = _getValueOrData()
    //     0x543d70: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x543d74: mov             x1, x0
    // 0x543d78: ldur            x0, [fp, #-8]
    // 0x543d7c: LoadField: r2 = r0->field_f
    //     0x543d7c: ldur            w2, [x0, #0xf]
    // 0x543d80: DecompressPointer r2
    //     0x543d80: add             x2, x2, HEAP, lsl #32
    // 0x543d84: cmp             w2, w1
    // 0x543d88: b.ne            #0x543d94
    // 0x543d8c: r0 = Null
    //     0x543d8c: mov             x0, NULL
    // 0x543d90: b               #0x543d98
    // 0x543d94: mov             x0, x1
    // 0x543d98: cmp             w0, NULL
    // 0x543d9c: b.ne            #0x543dac
    // 0x543da0: r1 = Instance_CustomNum
    //     0x543da0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x543da4: ldr             x1, [x1, #0xaf8]
    // 0x543da8: b               #0x543db0
    // 0x543dac: mov             x1, x0
    // 0x543db0: ldur            x0, [fp, #-0x18]
    // 0x543db4: r2 = Instance_CustomNum
    //     0x543db4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x543db8: ldr             x2, [x2, #0xce0]
    // 0x543dbc: r0 = mult2()
    //     0x543dbc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x543dc0: mov             x2, x0
    // 0x543dc4: r1 = Instance_CustomNum
    //     0x543dc4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543dc8: ldr             x1, [x1, #0xa70]
    // 0x543dcc: r0 = add()
    //     0x543dcc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x543dd0: ldur            x1, [fp, #-0x28]
    // 0x543dd4: mov             x2, x0
    // 0x543dd8: r0 = mult2()
    //     0x543dd8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x543ddc: stur            x0, [fp, #-8]
    // 0x543de0: r0 = Boost()
    //     0x543de0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543de4: mov             x1, x0
    // 0x543de8: r0 = Instance_CustomNum
    //     0x543de8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543dec: ldr             x0, [x0, #0xa70]
    // 0x543df0: StoreField: r1->field_7 = r0
    //     0x543df0: stur            w0, [x1, #7]
    // 0x543df4: StoreField: r1->field_b = r0
    //     0x543df4: stur            w0, [x1, #0xb]
    // 0x543df8: ldur            x2, [fp, #-8]
    // 0x543dfc: StoreField: r1->field_f = r2
    //     0x543dfc: stur            w2, [x1, #0xf]
    // 0x543e00: StoreField: r1->field_13 = r0
    //     0x543e00: stur            w0, [x1, #0x13]
    // 0x543e04: mov             x3, x1
    // 0x543e08: ldur            x1, [fp, #-0x10]
    // 0x543e0c: r2 = Instance_Chapter12Stat
    //     0x543e0c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x543e10: ldr             x2, [x2, #0x488]
    // 0x543e14: r0 = []=()
    //     0x543e14: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x543e18: ldur            x1, [fp, #-0x18]
    // 0x543e1c: LoadField: r0 = r1->field_97
    //     0x543e1c: ldur            w0, [x1, #0x97]
    // 0x543e20: DecompressPointer r0
    //     0x543e20: add             x0, x0, HEAP, lsl #32
    // 0x543e24: tbnz            w0, #4, #0x543e30
    // 0x543e28: ldur            x2, [fp, #-0x20]
    // 0x543e2c: r0 = longPressAction()
    //     0x543e2c: bl              #0x543e48  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::longPressAction
    // 0x543e30: r0 = Null
    //     0x543e30: mov             x0, NULL
    // 0x543e34: LeaveFrame
    //     0x543e34: mov             SP, fp
    //     0x543e38: ldp             fp, lr, [SP], #0x10
    // 0x543e3c: ret
    //     0x543e3c: ret             
    // 0x543e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x543e40: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x543e44: b               #0x543cd8
  }
  _ longPressAction(/* No info */) {
    // ** addr: 0x543e48, size: 0x2d8
    // 0x543e48: EnterFrame
    //     0x543e48: stp             fp, lr, [SP, #-0x10]!
    //     0x543e4c: mov             fp, SP
    // 0x543e50: AllocStack(0x50)
    //     0x543e50: sub             SP, SP, #0x50
    // 0x543e54: SetupParameters(Chapter12GameState this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x543e54: mov             x3, x1
    //     0x543e58: mov             x0, x2
    //     0x543e5c: stur            x1, [fp, #-0x10]
    //     0x543e60: stur            x2, [fp, #-0x18]
    // 0x543e64: CheckStackOverflow
    //     0x543e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x543e68: cmp             SP, x16
    //     0x543e6c: b.ls            #0x54410c
    // 0x543e70: LoadField: r4 = r3->field_43
    //     0x543e70: ldur            w4, [x3, #0x43]
    // 0x543e74: DecompressPointer r4
    //     0x543e74: add             x4, x4, HEAP, lsl #32
    // 0x543e78: mov             x1, x4
    // 0x543e7c: stur            x4, [fp, #-8]
    // 0x543e80: r2 = 2
    //     0x543e80: movz            x2, #0x2
    // 0x543e84: r0 = _getValueOrData()
    //     0x543e84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x543e88: mov             x1, x0
    // 0x543e8c: ldur            x0, [fp, #-8]
    // 0x543e90: LoadField: r2 = r0->field_f
    //     0x543e90: ldur            w2, [x0, #0xf]
    // 0x543e94: DecompressPointer r2
    //     0x543e94: add             x2, x2, HEAP, lsl #32
    // 0x543e98: cmp             w2, w1
    // 0x543e9c: b.ne            #0x543ea8
    // 0x543ea0: r0 = Null
    //     0x543ea0: mov             x0, NULL
    // 0x543ea4: b               #0x543eac
    // 0x543ea8: mov             x0, x1
    // 0x543eac: cmp             w0, NULL
    // 0x543eb0: b.ne            #0x543ebc
    // 0x543eb4: r0 = 0
    //     0x543eb4: movz            x0, #0
    // 0x543eb8: b               #0x543ecc
    // 0x543ebc: r1 = LoadInt32Instr(r0)
    //     0x543ebc: sbfx            x1, x0, #1, #0x1f
    //     0x543ec0: tbz             w0, #0, #0x543ec8
    //     0x543ec4: ldur            x1, [x0, #7]
    // 0x543ec8: mov             x0, x1
    // 0x543ecc: stur            x0, [fp, #-0x20]
    // 0x543ed0: cmp             x0, #0
    // 0x543ed4: b.le            #0x5440fc
    // 0x543ed8: ldur            x3, [fp, #-0x10]
    // 0x543edc: LoadField: r1 = r3->field_43
    //     0x543edc: ldur            w1, [x3, #0x43]
    // 0x543ee0: DecompressPointer r1
    //     0x543ee0: add             x1, x1, HEAP, lsl #32
    // 0x543ee4: r2 = 202
    //     0x543ee4: movz            x2, #0xca
    // 0x543ee8: r0 = containsKey()
    //     0x543ee8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x543eec: tbnz            w0, #4, #0x543f14
    // 0x543ef0: r1 = Null
    //     0x543ef0: mov             x1, NULL
    // 0x543ef4: r2 = 874
    //     0x543ef4: movz            x2, #0x36a
    // 0x543ef8: r0 = CustomNum()
    //     0x543ef8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x543efc: mov             x2, x0
    // 0x543f00: r1 = Instance_CustomNum
    //     0x543f00: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543f04: ldr             x1, [x1, #0xa70]
    // 0x543f08: r0 = mult2()
    //     0x543f08: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x543f0c: mov             x3, x0
    // 0x543f10: b               #0x543f1c
    // 0x543f14: r3 = Instance_CustomNum
    //     0x543f14: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543f18: ldr             x3, [x3, #0xa70]
    // 0x543f1c: ldur            x0, [fp, #-0x10]
    // 0x543f20: stur            x3, [fp, #-8]
    // 0x543f24: LoadField: r1 = r0->field_43
    //     0x543f24: ldur            w1, [x0, #0x43]
    // 0x543f28: DecompressPointer r1
    //     0x543f28: add             x1, x1, HEAP, lsl #32
    // 0x543f2c: r2 = 206
    //     0x543f2c: movz            x2, #0xce
    // 0x543f30: r0 = containsKey()
    //     0x543f30: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x543f34: tbnz            w0, #4, #0x543f58
    // 0x543f38: r1 = Null
    //     0x543f38: mov             x1, NULL
    // 0x543f3c: r2 = 2954
    //     0x543f3c: movz            x2, #0xb8a
    // 0x543f40: r0 = CustomNum()
    //     0x543f40: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x543f44: ldur            x1, [fp, #-8]
    // 0x543f48: mov             x2, x0
    // 0x543f4c: r0 = mult2()
    //     0x543f4c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x543f50: mov             x6, x0
    // 0x543f54: b               #0x543f5c
    // 0x543f58: ldur            x6, [fp, #-8]
    // 0x543f5c: ldur            x0, [fp, #-0x10]
    // 0x543f60: stur            x6, [fp, #-0x28]
    // 0x543f64: LoadField: r3 = r0->field_37
    //     0x543f64: ldur            w3, [x0, #0x37]
    // 0x543f68: DecompressPointer r3
    //     0x543f68: add             x3, x3, HEAP, lsl #32
    // 0x543f6c: mov             x1, x3
    // 0x543f70: stur            x3, [fp, #-8]
    // 0x543f74: r2 = Instance_Chapter12Stat
    //     0x543f74: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x543f78: ldr             x2, [x2, #0x488]
    // 0x543f7c: r0 = _getValueOrData()
    //     0x543f7c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x543f80: ldur            x3, [fp, #-8]
    // 0x543f84: LoadField: r1 = r3->field_f
    //     0x543f84: ldur            w1, [x3, #0xf]
    // 0x543f88: DecompressPointer r1
    //     0x543f88: add             x1, x1, HEAP, lsl #32
    // 0x543f8c: cmp             w1, w0
    // 0x543f90: b.ne            #0x543f98
    // 0x543f94: r0 = Null
    //     0x543f94: mov             x0, NULL
    // 0x543f98: cmp             w0, NULL
    // 0x543f9c: b.ne            #0x543fac
    // 0x543fa0: r5 = Instance_CustomNum
    //     0x543fa0: add             x5, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x543fa4: ldr             x5, [x5, #0xaf8]
    // 0x543fa8: b               #0x543fb0
    // 0x543fac: mov             x5, x0
    // 0x543fb0: ldur            x4, [fp, #-0x10]
    // 0x543fb4: ldur            x2, [fp, #-0x18]
    // 0x543fb8: stur            x5, [fp, #-0x30]
    // 0x543fbc: r0 = BoxInt64Instr(r2)
    //     0x543fbc: sbfiz           x0, x2, #1, #0x1f
    //     0x543fc0: cmp             x2, x0, asr #1
    //     0x543fc4: b.eq            #0x543fd0
    //     0x543fc8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x543fcc: stur            x2, [x0, #7]
    // 0x543fd0: mov             x2, x0
    // 0x543fd4: r1 = Null
    //     0x543fd4: mov             x1, NULL
    // 0x543fd8: r0 = CustomNum()
    //     0x543fd8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x543fdc: ldur            x1, [fp, #-0x10]
    // 0x543fe0: ldur            x2, [fp, #-0x20]
    // 0x543fe4: stur            x0, [fp, #-0x38]
    // 0x543fe8: r0 = getBasicBoostHold()
    //     0x543fe8: bl              #0x4fa05c  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getBasicBoostHold
    // 0x543fec: mov             x2, x0
    // 0x543ff0: stur            x2, [fp, #-0x48]
    // 0x543ff4: r0 = LoadStaticField(0xf7c)
    //     0x543ff4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x543ff8: ldr             x0, [x0, #0x1ef8]
    // 0x543ffc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x544000: cmp             w0, w16
    // 0x544004: b.eq            #0x544114
    // 0x544008: mov             x3, x0
    // 0x54400c: ldur            x0, [fp, #-0x10]
    // 0x544010: stur            x3, [fp, #-0x40]
    // 0x544014: LoadField: r1 = r0->field_23
    //     0x544014: ldur            x1, [x0, #0x23]
    // 0x544018: r0 = difficultyMultiplier()
    //     0x544018: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x54401c: ldur            x1, [fp, #-0x40]
    // 0x544020: mov             x2, x0
    // 0x544024: r3 = "12"
    //     0x544024: add             x3, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x544028: ldr             x3, [x3, #0x330]
    // 0x54402c: r0 = cachedCompletionTokenBoost()
    //     0x54402c: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x544030: mov             x3, x0
    // 0x544034: ldur            x0, [fp, #-0x10]
    // 0x544038: stur            x3, [fp, #-0x50]
    // 0x54403c: LoadField: r4 = r0->field_2f
    //     0x54403c: ldur            w4, [x0, #0x2f]
    // 0x544040: DecompressPointer r4
    //     0x544040: add             x4, x4, HEAP, lsl #32
    // 0x544044: mov             x1, x4
    // 0x544048: stur            x4, [fp, #-0x40]
    // 0x54404c: r2 = Instance_Chapter12Stat
    //     0x54404c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x544050: ldr             x2, [x2, #0x488]
    // 0x544054: r0 = _getValueOrData()
    //     0x544054: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x544058: mov             x1, x0
    // 0x54405c: ldur            x0, [fp, #-0x40]
    // 0x544060: LoadField: r2 = r0->field_f
    //     0x544060: ldur            w2, [x0, #0xf]
    // 0x544064: DecompressPointer r2
    //     0x544064: add             x2, x2, HEAP, lsl #32
    // 0x544068: cmp             w2, w1
    // 0x54406c: b.ne            #0x544078
    // 0x544070: r0 = Null
    //     0x544070: mov             x0, NULL
    // 0x544074: b               #0x54407c
    // 0x544078: mov             x0, x1
    // 0x54407c: cmp             w0, NULL
    // 0x544080: b.ne            #0x54408c
    // 0x544084: r0 = Null
    //     0x544084: mov             x0, NULL
    // 0x544088: b               #0x544098
    // 0x54408c: LoadField: r1 = r0->field_f
    //     0x54408c: ldur            w1, [x0, #0xf]
    // 0x544090: DecompressPointer r1
    //     0x544090: add             x1, x1, HEAP, lsl #32
    // 0x544094: mov             x0, x1
    // 0x544098: cmp             w0, NULL
    // 0x54409c: b.ne            #0x5440ac
    // 0x5440a0: r5 = Instance_CustomNum
    //     0x5440a0: add             x5, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x5440a4: ldr             x5, [x5, #0xa70]
    // 0x5440a8: b               #0x5440b0
    // 0x5440ac: mov             x5, x0
    // 0x5440b0: ldur            x1, [fp, #-0x38]
    // 0x5440b4: ldur            x2, [fp, #-0x48]
    // 0x5440b8: ldur            x3, [fp, #-0x50]
    // 0x5440bc: ldur            x6, [fp, #-0x28]
    // 0x5440c0: r0 = mult6()
    //     0x5440c0: bl              #0x544120  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult6
    // 0x5440c4: ldur            x1, [fp, #-0x30]
    // 0x5440c8: mov             x2, x0
    // 0x5440cc: r0 = add()
    //     0x5440cc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5440d0: ldur            x1, [fp, #-8]
    // 0x5440d4: mov             x3, x0
    // 0x5440d8: r2 = Instance_Chapter12Stat
    //     0x5440d8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x5440dc: ldr             x2, [x2, #0x488]
    // 0x5440e0: r0 = []=()
    //     0x5440e0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5440e4: ldur            x1, [fp, #-0x10]
    // 0x5440e8: r2 = Instance_Chapter12Stat
    //     0x5440e8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x5440ec: ldr             x2, [x2, #0x488]
    // 0x5440f0: r0 = notifyStatGained()
    //     0x5440f0: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x5440f4: ldur            x1, [fp, #-0x10]
    // 0x5440f8: r0 = saveDeferred()
    //     0x5440f8: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x5440fc: r0 = Null
    //     0x5440fc: mov             x0, NULL
    // 0x544100: LeaveFrame
    //     0x544100: mov             SP, fp
    //     0x544104: ldp             fp, lr, [SP], #0x10
    // 0x544108: ret
    //     0x544108: ret             
    // 0x54410c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54410c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x544110: b               #0x543e70
    // 0x544114: r9 = coreData
    //     0x544114: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x544118: ldr             x9, [x9, #0x530]
    // 0x54411c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x54411c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ getBasicBoostNormal(/* No info */) {
    // ** addr: 0x544188, size: 0x298
    // 0x544188: EnterFrame
    //     0x544188: stp             fp, lr, [SP, #-0x10]!
    //     0x54418c: mov             fp, SP
    // 0x544190: AllocStack(0x20)
    //     0x544190: sub             SP, SP, #0x20
    // 0x544194: SetupParameters(Chapter12GameState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x544194: mov             x3, x1
    //     0x544198: mov             x0, x2
    //     0x54419c: stur            x1, [fp, #-8]
    //     0x5441a0: stur            x2, [fp, #-0x10]
    // 0x5441a4: CheckStackOverflow
    //     0x5441a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5441a8: cmp             SP, x16
    //     0x5441ac: b.ls            #0x5443e0
    // 0x5441b0: LoadField: r1 = r3->field_43
    //     0x5441b0: ldur            w1, [x3, #0x43]
    // 0x5441b4: DecompressPointer r1
    //     0x5441b4: add             x1, x1, HEAP, lsl #32
    // 0x5441b8: r2 = 214
    //     0x5441b8: movz            x2, #0xd6
    // 0x5441bc: r0 = containsKey()
    //     0x5441bc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x5441c0: tbnz            w0, #4, #0x5442cc
    // 0x5441c4: ldur            x0, [fp, #-8]
    // 0x5441c8: r1 = Null
    //     0x5441c8: mov             x1, NULL
    // 0x5441cc: r2 = 1.750000
    //     0x5441cc: add             x2, PP, #0x16, lsl #12  ; [pp+0x162f8] 1.75
    //     0x5441d0: ldr             x2, [x2, #0x2f8]
    // 0x5441d4: r0 = CustomNum()
    //     0x5441d4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5441d8: mov             x3, x0
    // 0x5441dc: ldur            x0, [fp, #-8]
    // 0x5441e0: stur            x3, [fp, #-0x20]
    // 0x5441e4: LoadField: r1 = r0->field_3f
    //     0x5441e4: ldur            w1, [x0, #0x3f]
    // 0x5441e8: DecompressPointer r1
    //     0x5441e8: add             x1, x1, HEAP, lsl #32
    // 0x5441ec: LoadField: r0 = r1->field_b
    //     0x5441ec: ldur            w0, [x1, #0xb]
    // 0x5441f0: DecompressPointer r0
    //     0x5441f0: add             x0, x0, HEAP, lsl #32
    // 0x5441f4: mov             x1, x0
    // 0x5441f8: stur            x0, [fp, #-0x18]
    // 0x5441fc: r2 = 2
    //     0x5441fc: movz            x2, #0x2
    // 0x544200: r0 = _getValueOrData()
    //     0x544200: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x544204: mov             x1, x0
    // 0x544208: ldur            x0, [fp, #-0x18]
    // 0x54420c: LoadField: r2 = r0->field_f
    //     0x54420c: ldur            w2, [x0, #0xf]
    // 0x544210: DecompressPointer r2
    //     0x544210: add             x2, x2, HEAP, lsl #32
    // 0x544214: cmp             w2, w1
    // 0x544218: b.ne            #0x544224
    // 0x54421c: r0 = Null
    //     0x54421c: mov             x0, NULL
    // 0x544220: b               #0x544228
    // 0x544224: mov             x0, x1
    // 0x544228: cmp             w0, NULL
    // 0x54422c: b.ne            #0x544238
    // 0x544230: r1 = 0
    //     0x544230: movz            x1, #0
    // 0x544234: b               #0x544244
    // 0x544238: r1 = LoadInt32Instr(r0)
    //     0x544238: sbfx            x1, x0, #1, #0x1f
    //     0x54423c: tbz             w0, #0, #0x544244
    //     0x544240: ldur            x1, [x0, #7]
    // 0x544244: ldur            x0, [fp, #-0x10]
    // 0x544248: d0 = 0.100000
    //     0x544248: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x54424c: ldr             d0, [x17, #0xc30]
    // 0x544250: scvtf           d1, x1
    // 0x544254: fmul            d2, d1, d0
    // 0x544258: r2 = inline_Allocate_Double()
    //     0x544258: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x54425c: add             x2, x2, #0x10
    //     0x544260: cmp             x1, x2
    //     0x544264: b.ls            #0x5443e8
    //     0x544268: str             x2, [THR, #0x60]  ; THR::top
    //     0x54426c: sub             x2, x2, #0xf
    //     0x544270: movz            x1, #0xe19c
    //     0x544274: movk            x1, #0x3, lsl #16
    //     0x544278: stur            x1, [x2, #-1]
    // 0x54427c: dmb             ishst
    // 0x544280: StoreField: r2->field_7 = d2
    //     0x544280: stur            d2, [x2, #7]
    // 0x544284: r1 = Null
    //     0x544284: mov             x1, NULL
    // 0x544288: r0 = CustomNum()
    //     0x544288: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x54428c: ldur            x1, [fp, #-0x20]
    // 0x544290: mov             x2, x0
    // 0x544294: r0 = add()
    //     0x544294: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x544298: mov             x2, x0
    // 0x54429c: ldur            x3, [fp, #-0x10]
    // 0x5442a0: r0 = BoxInt64Instr(r3)
    //     0x5442a0: sbfiz           x0, x3, #1, #0x1f
    //     0x5442a4: cmp             x3, x0, asr #1
    //     0x5442a8: b.eq            #0x5442b4
    //     0x5442ac: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x5442b0: stur            x3, [x0, #7]
    // 0x5442b4: mov             x1, x2
    // 0x5442b8: mov             x2, x0
    // 0x5442bc: r0 = pow()
    //     0x5442bc: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x5442c0: LeaveFrame
    //     0x5442c0: mov             SP, fp
    //     0x5442c4: ldp             fp, lr, [SP], #0x10
    // 0x5442c8: ret
    //     0x5442c8: ret             
    // 0x5442cc: ldur            x0, [fp, #-8]
    // 0x5442d0: ldur            x3, [fp, #-0x10]
    // 0x5442d4: d0 = 0.100000
    //     0x5442d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x5442d8: ldr             d0, [x17, #0xc30]
    // 0x5442dc: r1 = Null
    //     0x5442dc: mov             x1, NULL
    // 0x5442e0: r2 = 1.500000
    //     0x5442e0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce8] 1.5
    //     0x5442e4: ldr             x2, [x2, #0xce8]
    // 0x5442e8: r0 = CustomNum()
    //     0x5442e8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5442ec: mov             x3, x0
    // 0x5442f0: ldur            x0, [fp, #-8]
    // 0x5442f4: stur            x3, [fp, #-0x18]
    // 0x5442f8: LoadField: r1 = r0->field_3f
    //     0x5442f8: ldur            w1, [x0, #0x3f]
    // 0x5442fc: DecompressPointer r1
    //     0x5442fc: add             x1, x1, HEAP, lsl #32
    // 0x544300: LoadField: r0 = r1->field_b
    //     0x544300: ldur            w0, [x1, #0xb]
    // 0x544304: DecompressPointer r0
    //     0x544304: add             x0, x0, HEAP, lsl #32
    // 0x544308: mov             x1, x0
    // 0x54430c: stur            x0, [fp, #-8]
    // 0x544310: r2 = 2
    //     0x544310: movz            x2, #0x2
    // 0x544314: r0 = _getValueOrData()
    //     0x544314: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x544318: mov             x1, x0
    // 0x54431c: ldur            x0, [fp, #-8]
    // 0x544320: LoadField: r2 = r0->field_f
    //     0x544320: ldur            w2, [x0, #0xf]
    // 0x544324: DecompressPointer r2
    //     0x544324: add             x2, x2, HEAP, lsl #32
    // 0x544328: cmp             w2, w1
    // 0x54432c: b.ne            #0x544338
    // 0x544330: r0 = Null
    //     0x544330: mov             x0, NULL
    // 0x544334: b               #0x54433c
    // 0x544338: mov             x0, x1
    // 0x54433c: cmp             w0, NULL
    // 0x544340: b.ne            #0x54434c
    // 0x544344: r1 = 0
    //     0x544344: movz            x1, #0
    // 0x544348: b               #0x544358
    // 0x54434c: r1 = LoadInt32Instr(r0)
    //     0x54434c: sbfx            x1, x0, #1, #0x1f
    //     0x544350: tbz             w0, #0, #0x544358
    //     0x544354: ldur            x1, [x0, #7]
    // 0x544358: ldur            x0, [fp, #-0x10]
    // 0x54435c: d0 = 0.100000
    //     0x54435c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x544360: ldr             d0, [x17, #0xc30]
    // 0x544364: scvtf           d1, x1
    // 0x544368: fmul            d2, d1, d0
    // 0x54436c: r2 = inline_Allocate_Double()
    //     0x54436c: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x544370: add             x2, x2, #0x10
    //     0x544374: cmp             x1, x2
    //     0x544378: b.ls            #0x544404
    //     0x54437c: str             x2, [THR, #0x60]  ; THR::top
    //     0x544380: sub             x2, x2, #0xf
    //     0x544384: movz            x1, #0xe19c
    //     0x544388: movk            x1, #0x3, lsl #16
    //     0x54438c: stur            x1, [x2, #-1]
    // 0x544390: dmb             ishst
    // 0x544394: StoreField: r2->field_7 = d2
    //     0x544394: stur            d2, [x2, #7]
    // 0x544398: r1 = Null
    //     0x544398: mov             x1, NULL
    // 0x54439c: r0 = CustomNum()
    //     0x54439c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5443a0: ldur            x1, [fp, #-0x18]
    // 0x5443a4: mov             x2, x0
    // 0x5443a8: r0 = add()
    //     0x5443a8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5443ac: mov             x3, x0
    // 0x5443b0: ldur            x2, [fp, #-0x10]
    // 0x5443b4: r0 = BoxInt64Instr(r2)
    //     0x5443b4: sbfiz           x0, x2, #1, #0x1f
    //     0x5443b8: cmp             x2, x0, asr #1
    //     0x5443bc: b.eq            #0x5443c8
    //     0x5443c0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x5443c4: stur            x2, [x0, #7]
    // 0x5443c8: mov             x1, x3
    // 0x5443cc: mov             x2, x0
    // 0x5443d0: r0 = pow()
    //     0x5443d0: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x5443d4: LeaveFrame
    //     0x5443d4: mov             SP, fp
    //     0x5443d8: ldp             fp, lr, [SP], #0x10
    // 0x5443dc: ret
    //     0x5443dc: ret             
    // 0x5443e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5443e0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5443e4: b               #0x5441b0
    // 0x5443e8: SaveReg d2
    //     0x5443e8: str             q2, [SP, #-0x10]!
    // 0x5443ec: SaveReg r0
    //     0x5443ec: str             x0, [SP, #-8]!
    // 0x5443f0: r0 = AllocateDouble()
    //     0x5443f0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5443f4: mov             x2, x0
    // 0x5443f8: RestoreReg r0
    //     0x5443f8: ldr             x0, [SP], #8
    // 0x5443fc: RestoreReg d2
    //     0x5443fc: ldr             q2, [SP], #0x10
    // 0x544400: b               #0x544280
    // 0x544404: SaveReg d2
    //     0x544404: str             q2, [SP, #-0x10]!
    // 0x544408: SaveReg r0
    //     0x544408: str             x0, [SP, #-8]!
    // 0x54440c: r0 = AllocateDouble()
    //     0x54440c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x544410: mov             x2, x0
    // 0x544414: RestoreReg r0
    //     0x544414: ldr             x0, [SP], #8
    // 0x544418: RestoreReg d2
    //     0x544418: ldr             q2, [SP], #0x10
    // 0x54441c: b               #0x544394
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55c710, size: 0x40
    // 0x55c710: EnterFrame
    //     0x55c710: stp             fp, lr, [SP, #-0x10]!
    //     0x55c714: mov             fp, SP
    // 0x55c718: AllocStack(0x10)
    //     0x55c718: sub             SP, SP, #0x10
    // 0x55c71c: CheckStackOverflow
    //     0x55c71c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55c720: cmp             SP, x16
    //     0x55c724: b.ls            #0x55c748
    // 0x55c728: r16 = <Chapter12Stat, CustomNum>
    //     0x55c728: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e88] TypeArguments: <Chapter12Stat, CustomNum>
    //     0x55c72c: ldr             x16, [x16, #0xe88]
    // 0x55c730: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x55c734: stp             lr, x16, [SP]
    // 0x55c738: r0 = Map._fromLiteral()
    //     0x55c738: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55c73c: LeaveFrame
    //     0x55c73c: mov             SP, fp
    //     0x55c740: ldp             fp, lr, [SP], #0x10
    // 0x55c744: ret
    //     0x55c744: ret             
    // 0x55c748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c748: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c74c: b               #0x55c728
  }
  _ checkAllBoosts(/* No info */) {
    // ** addr: 0x6868e0, size: 0x31a0
    // 0x6868e0: EnterFrame
    //     0x6868e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6868e4: mov             fp, SP
    // 0x6868e8: AllocStack(0x20)
    //     0x6868e8: sub             SP, SP, #0x20
    // 0x6868ec: SetupParameters(Chapter12GameState this /* r1 => r1, fp-0x10 */)
    //     0x6868ec: stur            x1, [fp, #-0x10]
    // 0x6868f0: CheckStackOverflow
    //     0x6868f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6868f4: cmp             SP, x16
    //     0x6868f8: b.ls            #0x689868
    // 0x6868fc: LoadField: r0 = r1->field_33
    //     0x6868fc: ldur            w0, [x1, #0x33]
    // 0x686900: DecompressPointer r0
    //     0x686900: add             x0, x0, HEAP, lsl #32
    // 0x686904: stur            x0, [fp, #-8]
    // 0x686908: r0 = Boost()
    //     0x686908: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68690c: mov             x1, x0
    // 0x686910: r0 = Instance_CustomNum
    //     0x686910: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686914: ldr             x0, [x0, #0xa70]
    // 0x686918: StoreField: r1->field_7 = r0
    //     0x686918: stur            w0, [x1, #7]
    // 0x68691c: StoreField: r1->field_b = r0
    //     0x68691c: stur            w0, [x1, #0xb]
    // 0x686920: StoreField: r1->field_f = r0
    //     0x686920: stur            w0, [x1, #0xf]
    // 0x686924: StoreField: r1->field_13 = r0
    //     0x686924: stur            w0, [x1, #0x13]
    // 0x686928: mov             x3, x1
    // 0x68692c: ldur            x1, [fp, #-8]
    // 0x686930: r2 = 2
    //     0x686930: movz            x2, #0x2
    // 0x686934: r0 = []=()
    //     0x686934: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686938: ldur            x0, [fp, #-0x10]
    // 0x68693c: LoadField: r1 = r0->field_43
    //     0x68693c: ldur            w1, [x0, #0x43]
    // 0x686940: DecompressPointer r1
    //     0x686940: add             x1, x1, HEAP, lsl #32
    // 0x686944: r2 = 208
    //     0x686944: movz            x2, #0xd0
    // 0x686948: r0 = containsKey()
    //     0x686948: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x68694c: tbnz            w0, #4, #0x686a04
    // 0x686950: ldur            x0, [fp, #-8]
    // 0x686954: mov             x1, x0
    // 0x686958: r2 = 2
    //     0x686958: movz            x2, #0x2
    // 0x68695c: r0 = _getValueOrData()
    //     0x68695c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686960: mov             x1, x0
    // 0x686964: ldur            x0, [fp, #-8]
    // 0x686968: LoadField: r2 = r0->field_f
    //     0x686968: ldur            w2, [x0, #0xf]
    // 0x68696c: DecompressPointer r2
    //     0x68696c: add             x2, x2, HEAP, lsl #32
    // 0x686970: cmp             w2, w1
    // 0x686974: b.ne            #0x686980
    // 0x686978: r3 = Null
    //     0x686978: mov             x3, NULL
    // 0x68697c: b               #0x686984
    // 0x686980: mov             x3, x1
    // 0x686984: stur            x3, [fp, #-0x18]
    // 0x686988: cmp             w3, NULL
    // 0x68698c: b.eq            #0x689870
    // 0x686990: r1 = Null
    //     0x686990: mov             x1, NULL
    // 0x686994: r2 = 10000
    //     0x686994: movz            x2, #0x2710
    // 0x686998: r0 = CustomNum()
    //     0x686998: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x68699c: ldur            x1, [fp, #-8]
    // 0x6869a0: r2 = 2
    //     0x6869a0: movz            x2, #0x2
    // 0x6869a4: stur            x0, [fp, #-0x20]
    // 0x6869a8: r0 = _getValueOrData()
    //     0x6869a8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6869ac: mov             x1, x0
    // 0x6869b0: ldur            x0, [fp, #-8]
    // 0x6869b4: LoadField: r2 = r0->field_f
    //     0x6869b4: ldur            w2, [x0, #0xf]
    // 0x6869b8: DecompressPointer r2
    //     0x6869b8: add             x2, x2, HEAP, lsl #32
    // 0x6869bc: cmp             w2, w1
    // 0x6869c0: b.ne            #0x6869c8
    // 0x6869c4: r1 = Null
    //     0x6869c4: mov             x1, NULL
    // 0x6869c8: ldur            x3, [fp, #-0x18]
    // 0x6869cc: cmp             w1, NULL
    // 0x6869d0: b.eq            #0x689874
    // 0x6869d4: LoadField: r2 = r1->field_f
    //     0x6869d4: ldur            w2, [x1, #0xf]
    // 0x6869d8: DecompressPointer r2
    //     0x6869d8: add             x2, x2, HEAP, lsl #32
    // 0x6869dc: ldur            x1, [fp, #-0x20]
    // 0x6869e0: r0 = mult2()
    //     0x6869e0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6869e4: ldur            x1, [fp, #-0x18]
    // 0x6869e8: StoreField: r1->field_f = r0
    //     0x6869e8: stur            w0, [x1, #0xf]
    //     0x6869ec: ldurb           w16, [x1, #-1]
    //     0x6869f0: ldurb           w17, [x0, #-1]
    //     0x6869f4: and             x16, x17, x16, lsr #2
    //     0x6869f8: tst             x16, HEAP, lsr #32
    //     0x6869fc: b.eq            #0x686a04
    //     0x686a00: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686a04: ldur            x0, [fp, #-0x10]
    // 0x686a08: LoadField: r1 = r0->field_43
    //     0x686a08: ldur            w1, [x0, #0x43]
    // 0x686a0c: DecompressPointer r1
    //     0x686a0c: add             x1, x1, HEAP, lsl #32
    // 0x686a10: r2 = 204
    //     0x686a10: movz            x2, #0xcc
    // 0x686a14: r0 = containsKey()
    //     0x686a14: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x686a18: tbnz            w0, #4, #0x686ad0
    // 0x686a1c: ldur            x0, [fp, #-8]
    // 0x686a20: mov             x1, x0
    // 0x686a24: r2 = 2
    //     0x686a24: movz            x2, #0x2
    // 0x686a28: r0 = _getValueOrData()
    //     0x686a28: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686a2c: mov             x1, x0
    // 0x686a30: ldur            x0, [fp, #-8]
    // 0x686a34: LoadField: r2 = r0->field_f
    //     0x686a34: ldur            w2, [x0, #0xf]
    // 0x686a38: DecompressPointer r2
    //     0x686a38: add             x2, x2, HEAP, lsl #32
    // 0x686a3c: cmp             w2, w1
    // 0x686a40: b.ne            #0x686a4c
    // 0x686a44: r3 = Null
    //     0x686a44: mov             x3, NULL
    // 0x686a48: b               #0x686a50
    // 0x686a4c: mov             x3, x1
    // 0x686a50: stur            x3, [fp, #-0x18]
    // 0x686a54: cmp             w3, NULL
    // 0x686a58: b.eq            #0x689878
    // 0x686a5c: r1 = Null
    //     0x686a5c: mov             x1, NULL
    // 0x686a60: r2 = 12
    //     0x686a60: movz            x2, #0xc
    // 0x686a64: r0 = CustomNum()
    //     0x686a64: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686a68: ldur            x1, [fp, #-8]
    // 0x686a6c: r2 = 2
    //     0x686a6c: movz            x2, #0x2
    // 0x686a70: stur            x0, [fp, #-0x20]
    // 0x686a74: r0 = _getValueOrData()
    //     0x686a74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686a78: mov             x1, x0
    // 0x686a7c: ldur            x0, [fp, #-8]
    // 0x686a80: LoadField: r2 = r0->field_f
    //     0x686a80: ldur            w2, [x0, #0xf]
    // 0x686a84: DecompressPointer r2
    //     0x686a84: add             x2, x2, HEAP, lsl #32
    // 0x686a88: cmp             w2, w1
    // 0x686a8c: b.ne            #0x686a94
    // 0x686a90: r1 = Null
    //     0x686a90: mov             x1, NULL
    // 0x686a94: ldur            x3, [fp, #-0x18]
    // 0x686a98: cmp             w1, NULL
    // 0x686a9c: b.eq            #0x68987c
    // 0x686aa0: LoadField: r2 = r1->field_f
    //     0x686aa0: ldur            w2, [x1, #0xf]
    // 0x686aa4: DecompressPointer r2
    //     0x686aa4: add             x2, x2, HEAP, lsl #32
    // 0x686aa8: ldur            x1, [fp, #-0x20]
    // 0x686aac: r0 = mult2()
    //     0x686aac: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x686ab0: ldur            x1, [fp, #-0x18]
    // 0x686ab4: StoreField: r1->field_f = r0
    //     0x686ab4: stur            w0, [x1, #0xf]
    //     0x686ab8: ldurb           w16, [x1, #-1]
    //     0x686abc: ldurb           w17, [x0, #-1]
    //     0x686ac0: and             x16, x17, x16, lsr #2
    //     0x686ac4: tst             x16, HEAP, lsr #32
    //     0x686ac8: b.eq            #0x686ad0
    //     0x686acc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686ad0: ldur            x0, [fp, #-0x10]
    // 0x686ad4: r0 = Boost()
    //     0x686ad4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686ad8: mov             x1, x0
    // 0x686adc: r0 = Instance_CustomNum
    //     0x686adc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686ae0: ldr             x0, [x0, #0xa70]
    // 0x686ae4: StoreField: r1->field_7 = r0
    //     0x686ae4: stur            w0, [x1, #7]
    // 0x686ae8: StoreField: r1->field_b = r0
    //     0x686ae8: stur            w0, [x1, #0xb]
    // 0x686aec: StoreField: r1->field_f = r0
    //     0x686aec: stur            w0, [x1, #0xf]
    // 0x686af0: StoreField: r1->field_13 = r0
    //     0x686af0: stur            w0, [x1, #0x13]
    // 0x686af4: mov             x3, x1
    // 0x686af8: ldur            x1, [fp, #-8]
    // 0x686afc: r2 = 4
    //     0x686afc: movz            x2, #0x4
    // 0x686b00: r0 = []=()
    //     0x686b00: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686b04: ldur            x0, [fp, #-0x10]
    // 0x686b08: LoadField: r1 = r0->field_43
    //     0x686b08: ldur            w1, [x0, #0x43]
    // 0x686b0c: DecompressPointer r1
    //     0x686b0c: add             x1, x1, HEAP, lsl #32
    // 0x686b10: r2 = 206
    //     0x686b10: movz            x2, #0xce
    // 0x686b14: r0 = containsKey()
    //     0x686b14: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x686b18: tbnz            w0, #4, #0x686bd0
    // 0x686b1c: ldur            x0, [fp, #-8]
    // 0x686b20: mov             x1, x0
    // 0x686b24: r2 = 4
    //     0x686b24: movz            x2, #0x4
    // 0x686b28: r0 = _getValueOrData()
    //     0x686b28: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686b2c: mov             x1, x0
    // 0x686b30: ldur            x0, [fp, #-8]
    // 0x686b34: LoadField: r2 = r0->field_f
    //     0x686b34: ldur            w2, [x0, #0xf]
    // 0x686b38: DecompressPointer r2
    //     0x686b38: add             x2, x2, HEAP, lsl #32
    // 0x686b3c: cmp             w2, w1
    // 0x686b40: b.ne            #0x686b4c
    // 0x686b44: r3 = Null
    //     0x686b44: mov             x3, NULL
    // 0x686b48: b               #0x686b50
    // 0x686b4c: mov             x3, x1
    // 0x686b50: stur            x3, [fp, #-0x18]
    // 0x686b54: cmp             w3, NULL
    // 0x686b58: b.eq            #0x689880
    // 0x686b5c: r1 = Null
    //     0x686b5c: mov             x1, NULL
    // 0x686b60: r2 = 40
    //     0x686b60: movz            x2, #0x28
    // 0x686b64: r0 = CustomNum()
    //     0x686b64: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686b68: ldur            x1, [fp, #-8]
    // 0x686b6c: r2 = 4
    //     0x686b6c: movz            x2, #0x4
    // 0x686b70: stur            x0, [fp, #-0x20]
    // 0x686b74: r0 = _getValueOrData()
    //     0x686b74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686b78: mov             x1, x0
    // 0x686b7c: ldur            x0, [fp, #-8]
    // 0x686b80: LoadField: r2 = r0->field_f
    //     0x686b80: ldur            w2, [x0, #0xf]
    // 0x686b84: DecompressPointer r2
    //     0x686b84: add             x2, x2, HEAP, lsl #32
    // 0x686b88: cmp             w2, w1
    // 0x686b8c: b.ne            #0x686b94
    // 0x686b90: r1 = Null
    //     0x686b90: mov             x1, NULL
    // 0x686b94: ldur            x3, [fp, #-0x18]
    // 0x686b98: cmp             w1, NULL
    // 0x686b9c: b.eq            #0x689884
    // 0x686ba0: LoadField: r2 = r1->field_f
    //     0x686ba0: ldur            w2, [x1, #0xf]
    // 0x686ba4: DecompressPointer r2
    //     0x686ba4: add             x2, x2, HEAP, lsl #32
    // 0x686ba8: ldur            x1, [fp, #-0x20]
    // 0x686bac: r0 = mult2()
    //     0x686bac: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x686bb0: ldur            x1, [fp, #-0x18]
    // 0x686bb4: StoreField: r1->field_f = r0
    //     0x686bb4: stur            w0, [x1, #0xf]
    //     0x686bb8: ldurb           w16, [x1, #-1]
    //     0x686bbc: ldurb           w17, [x0, #-1]
    //     0x686bc0: and             x16, x17, x16, lsr #2
    //     0x686bc4: tst             x16, HEAP, lsr #32
    //     0x686bc8: b.eq            #0x686bd0
    //     0x686bcc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686bd0: ldur            x0, [fp, #-0x10]
    // 0x686bd4: LoadField: r1 = r0->field_43
    //     0x686bd4: ldur            w1, [x0, #0x43]
    // 0x686bd8: DecompressPointer r1
    //     0x686bd8: add             x1, x1, HEAP, lsl #32
    // 0x686bdc: r2 = 202
    //     0x686bdc: movz            x2, #0xca
    // 0x686be0: r0 = containsKey()
    //     0x686be0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x686be4: tbnz            w0, #4, #0x686c9c
    // 0x686be8: ldur            x0, [fp, #-8]
    // 0x686bec: mov             x1, x0
    // 0x686bf0: r2 = 4
    //     0x686bf0: movz            x2, #0x4
    // 0x686bf4: r0 = _getValueOrData()
    //     0x686bf4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686bf8: mov             x1, x0
    // 0x686bfc: ldur            x0, [fp, #-8]
    // 0x686c00: LoadField: r2 = r0->field_f
    //     0x686c00: ldur            w2, [x0, #0xf]
    // 0x686c04: DecompressPointer r2
    //     0x686c04: add             x2, x2, HEAP, lsl #32
    // 0x686c08: cmp             w2, w1
    // 0x686c0c: b.ne            #0x686c18
    // 0x686c10: r3 = Null
    //     0x686c10: mov             x3, NULL
    // 0x686c14: b               #0x686c1c
    // 0x686c18: mov             x3, x1
    // 0x686c1c: stur            x3, [fp, #-0x18]
    // 0x686c20: cmp             w3, NULL
    // 0x686c24: b.eq            #0x689888
    // 0x686c28: r1 = Null
    //     0x686c28: mov             x1, NULL
    // 0x686c2c: r2 = 30
    //     0x686c2c: movz            x2, #0x1e
    // 0x686c30: r0 = CustomNum()
    //     0x686c30: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686c34: ldur            x1, [fp, #-8]
    // 0x686c38: r2 = 4
    //     0x686c38: movz            x2, #0x4
    // 0x686c3c: stur            x0, [fp, #-0x20]
    // 0x686c40: r0 = _getValueOrData()
    //     0x686c40: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686c44: mov             x1, x0
    // 0x686c48: ldur            x0, [fp, #-8]
    // 0x686c4c: LoadField: r2 = r0->field_f
    //     0x686c4c: ldur            w2, [x0, #0xf]
    // 0x686c50: DecompressPointer r2
    //     0x686c50: add             x2, x2, HEAP, lsl #32
    // 0x686c54: cmp             w2, w1
    // 0x686c58: b.ne            #0x686c60
    // 0x686c5c: r1 = Null
    //     0x686c5c: mov             x1, NULL
    // 0x686c60: ldur            x3, [fp, #-0x18]
    // 0x686c64: cmp             w1, NULL
    // 0x686c68: b.eq            #0x68988c
    // 0x686c6c: LoadField: r2 = r1->field_f
    //     0x686c6c: ldur            w2, [x1, #0xf]
    // 0x686c70: DecompressPointer r2
    //     0x686c70: add             x2, x2, HEAP, lsl #32
    // 0x686c74: ldur            x1, [fp, #-0x20]
    // 0x686c78: r0 = mult2()
    //     0x686c78: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x686c7c: ldur            x1, [fp, #-0x18]
    // 0x686c80: StoreField: r1->field_f = r0
    //     0x686c80: stur            w0, [x1, #0xf]
    //     0x686c84: ldurb           w16, [x1, #-1]
    //     0x686c88: ldurb           w17, [x0, #-1]
    //     0x686c8c: and             x16, x17, x16, lsr #2
    //     0x686c90: tst             x16, HEAP, lsr #32
    //     0x686c94: b.eq            #0x686c9c
    //     0x686c98: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686c9c: ldur            x0, [fp, #-0x10]
    // 0x686ca0: r0 = Boost()
    //     0x686ca0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686ca4: mov             x1, x0
    // 0x686ca8: r0 = Instance_CustomNum
    //     0x686ca8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686cac: ldr             x0, [x0, #0xa70]
    // 0x686cb0: StoreField: r1->field_7 = r0
    //     0x686cb0: stur            w0, [x1, #7]
    // 0x686cb4: StoreField: r1->field_b = r0
    //     0x686cb4: stur            w0, [x1, #0xb]
    // 0x686cb8: StoreField: r1->field_f = r0
    //     0x686cb8: stur            w0, [x1, #0xf]
    // 0x686cbc: StoreField: r1->field_13 = r0
    //     0x686cbc: stur            w0, [x1, #0x13]
    // 0x686cc0: mov             x3, x1
    // 0x686cc4: ldur            x1, [fp, #-8]
    // 0x686cc8: r2 = 6
    //     0x686cc8: movz            x2, #0x6
    // 0x686ccc: r0 = []=()
    //     0x686ccc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686cd0: ldur            x0, [fp, #-0x10]
    // 0x686cd4: LoadField: r1 = r0->field_43
    //     0x686cd4: ldur            w1, [x0, #0x43]
    // 0x686cd8: DecompressPointer r1
    //     0x686cd8: add             x1, x1, HEAP, lsl #32
    // 0x686cdc: r2 = 210
    //     0x686cdc: movz            x2, #0xd2
    // 0x686ce0: r0 = containsKey()
    //     0x686ce0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x686ce4: tbnz            w0, #4, #0x686d9c
    // 0x686ce8: ldur            x0, [fp, #-8]
    // 0x686cec: mov             x1, x0
    // 0x686cf0: r2 = 6
    //     0x686cf0: movz            x2, #0x6
    // 0x686cf4: r0 = _getValueOrData()
    //     0x686cf4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686cf8: mov             x1, x0
    // 0x686cfc: ldur            x0, [fp, #-8]
    // 0x686d00: LoadField: r2 = r0->field_f
    //     0x686d00: ldur            w2, [x0, #0xf]
    // 0x686d04: DecompressPointer r2
    //     0x686d04: add             x2, x2, HEAP, lsl #32
    // 0x686d08: cmp             w2, w1
    // 0x686d0c: b.ne            #0x686d18
    // 0x686d10: r3 = Null
    //     0x686d10: mov             x3, NULL
    // 0x686d14: b               #0x686d1c
    // 0x686d18: mov             x3, x1
    // 0x686d1c: stur            x3, [fp, #-0x18]
    // 0x686d20: cmp             w3, NULL
    // 0x686d24: b.eq            #0x689890
    // 0x686d28: r1 = Null
    //     0x686d28: mov             x1, NULL
    // 0x686d2c: r2 = 1000
    //     0x686d2c: movz            x2, #0x3e8
    // 0x686d30: r0 = CustomNum()
    //     0x686d30: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686d34: ldur            x1, [fp, #-8]
    // 0x686d38: r2 = 6
    //     0x686d38: movz            x2, #0x6
    // 0x686d3c: stur            x0, [fp, #-0x20]
    // 0x686d40: r0 = _getValueOrData()
    //     0x686d40: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686d44: mov             x1, x0
    // 0x686d48: ldur            x0, [fp, #-8]
    // 0x686d4c: LoadField: r2 = r0->field_f
    //     0x686d4c: ldur            w2, [x0, #0xf]
    // 0x686d50: DecompressPointer r2
    //     0x686d50: add             x2, x2, HEAP, lsl #32
    // 0x686d54: cmp             w2, w1
    // 0x686d58: b.ne            #0x686d60
    // 0x686d5c: r1 = Null
    //     0x686d5c: mov             x1, NULL
    // 0x686d60: ldur            x3, [fp, #-0x18]
    // 0x686d64: cmp             w1, NULL
    // 0x686d68: b.eq            #0x689894
    // 0x686d6c: LoadField: r2 = r1->field_f
    //     0x686d6c: ldur            w2, [x1, #0xf]
    // 0x686d70: DecompressPointer r2
    //     0x686d70: add             x2, x2, HEAP, lsl #32
    // 0x686d74: ldur            x1, [fp, #-0x20]
    // 0x686d78: r0 = mult2()
    //     0x686d78: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x686d7c: ldur            x1, [fp, #-0x18]
    // 0x686d80: StoreField: r1->field_f = r0
    //     0x686d80: stur            w0, [x1, #0xf]
    //     0x686d84: ldurb           w16, [x1, #-1]
    //     0x686d88: ldurb           w17, [x0, #-1]
    //     0x686d8c: and             x16, x17, x16, lsr #2
    //     0x686d90: tst             x16, HEAP, lsr #32
    //     0x686d94: b.eq            #0x686d9c
    //     0x686d98: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686d9c: ldur            x0, [fp, #-0x10]
    // 0x686da0: r0 = Boost()
    //     0x686da0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686da4: mov             x1, x0
    // 0x686da8: r0 = Instance_CustomNum
    //     0x686da8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686dac: ldr             x0, [x0, #0xa70]
    // 0x686db0: StoreField: r1->field_7 = r0
    //     0x686db0: stur            w0, [x1, #7]
    // 0x686db4: StoreField: r1->field_b = r0
    //     0x686db4: stur            w0, [x1, #0xb]
    // 0x686db8: StoreField: r1->field_f = r0
    //     0x686db8: stur            w0, [x1, #0xf]
    // 0x686dbc: StoreField: r1->field_13 = r0
    //     0x686dbc: stur            w0, [x1, #0x13]
    // 0x686dc0: mov             x3, x1
    // 0x686dc4: ldur            x1, [fp, #-8]
    // 0x686dc8: r2 = 8
    //     0x686dc8: movz            x2, #0x8
    // 0x686dcc: r0 = []=()
    //     0x686dcc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686dd0: r0 = Boost()
    //     0x686dd0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686dd4: mov             x1, x0
    // 0x686dd8: r0 = Instance_CustomNum
    //     0x686dd8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686ddc: ldr             x0, [x0, #0xa70]
    // 0x686de0: StoreField: r1->field_7 = r0
    //     0x686de0: stur            w0, [x1, #7]
    // 0x686de4: StoreField: r1->field_b = r0
    //     0x686de4: stur            w0, [x1, #0xb]
    // 0x686de8: StoreField: r1->field_f = r0
    //     0x686de8: stur            w0, [x1, #0xf]
    // 0x686dec: StoreField: r1->field_13 = r0
    //     0x686dec: stur            w0, [x1, #0x13]
    // 0x686df0: mov             x3, x1
    // 0x686df4: ldur            x1, [fp, #-8]
    // 0x686df8: r2 = 10
    //     0x686df8: movz            x2, #0xa
    // 0x686dfc: r0 = []=()
    //     0x686dfc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686e00: ldur            x0, [fp, #-0x10]
    // 0x686e04: LoadField: r1 = r0->field_43
    //     0x686e04: ldur            w1, [x0, #0x43]
    // 0x686e08: DecompressPointer r1
    //     0x686e08: add             x1, x1, HEAP, lsl #32
    // 0x686e0c: r2 = 218
    //     0x686e0c: movz            x2, #0xda
    // 0x686e10: r0 = containsKey()
    //     0x686e10: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x686e14: tbnz            w0, #4, #0x6870dc
    // 0x686e18: ldur            x0, [fp, #-8]
    // 0x686e1c: mov             x1, x0
    // 0x686e20: r2 = 2
    //     0x686e20: movz            x2, #0x2
    // 0x686e24: r0 = _getValueOrData()
    //     0x686e24: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686e28: mov             x1, x0
    // 0x686e2c: ldur            x0, [fp, #-8]
    // 0x686e30: LoadField: r2 = r0->field_f
    //     0x686e30: ldur            w2, [x0, #0xf]
    // 0x686e34: DecompressPointer r2
    //     0x686e34: add             x2, x2, HEAP, lsl #32
    // 0x686e38: cmp             w2, w1
    // 0x686e3c: b.ne            #0x686e48
    // 0x686e40: r3 = Null
    //     0x686e40: mov             x3, NULL
    // 0x686e44: b               #0x686e4c
    // 0x686e48: mov             x3, x1
    // 0x686e4c: stur            x3, [fp, #-0x18]
    // 0x686e50: cmp             w3, NULL
    // 0x686e54: b.eq            #0x689898
    // 0x686e58: r1 = Null
    //     0x686e58: mov             x1, NULL
    // 0x686e5c: r2 = 60
    //     0x686e5c: movz            x2, #0x3c
    // 0x686e60: r0 = CustomNum()
    //     0x686e60: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686e64: ldur            x1, [fp, #-8]
    // 0x686e68: r2 = 2
    //     0x686e68: movz            x2, #0x2
    // 0x686e6c: stur            x0, [fp, #-0x20]
    // 0x686e70: r0 = _getValueOrData()
    //     0x686e70: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686e74: mov             x1, x0
    // 0x686e78: ldur            x0, [fp, #-8]
    // 0x686e7c: LoadField: r2 = r0->field_f
    //     0x686e7c: ldur            w2, [x0, #0xf]
    // 0x686e80: DecompressPointer r2
    //     0x686e80: add             x2, x2, HEAP, lsl #32
    // 0x686e84: cmp             w2, w1
    // 0x686e88: b.ne            #0x686e90
    // 0x686e8c: r1 = Null
    //     0x686e8c: mov             x1, NULL
    // 0x686e90: ldur            x3, [fp, #-0x18]
    // 0x686e94: cmp             w1, NULL
    // 0x686e98: b.eq            #0x68989c
    // 0x686e9c: LoadField: r2 = r1->field_f
    //     0x686e9c: ldur            w2, [x1, #0xf]
    // 0x686ea0: DecompressPointer r2
    //     0x686ea0: add             x2, x2, HEAP, lsl #32
    // 0x686ea4: ldur            x1, [fp, #-0x20]
    // 0x686ea8: r0 = mult2()
    //     0x686ea8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x686eac: ldur            x1, [fp, #-0x18]
    // 0x686eb0: StoreField: r1->field_f = r0
    //     0x686eb0: stur            w0, [x1, #0xf]
    //     0x686eb4: ldurb           w16, [x1, #-1]
    //     0x686eb8: ldurb           w17, [x0, #-1]
    //     0x686ebc: and             x16, x17, x16, lsr #2
    //     0x686ec0: tst             x16, HEAP, lsr #32
    //     0x686ec4: b.eq            #0x686ecc
    //     0x686ec8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686ecc: ldur            x1, [fp, #-8]
    // 0x686ed0: r2 = 4
    //     0x686ed0: movz            x2, #0x4
    // 0x686ed4: r0 = _getValueOrData()
    //     0x686ed4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686ed8: mov             x1, x0
    // 0x686edc: ldur            x0, [fp, #-8]
    // 0x686ee0: LoadField: r2 = r0->field_f
    //     0x686ee0: ldur            w2, [x0, #0xf]
    // 0x686ee4: DecompressPointer r2
    //     0x686ee4: add             x2, x2, HEAP, lsl #32
    // 0x686ee8: cmp             w2, w1
    // 0x686eec: b.ne            #0x686ef8
    // 0x686ef0: r3 = Null
    //     0x686ef0: mov             x3, NULL
    // 0x686ef4: b               #0x686efc
    // 0x686ef8: mov             x3, x1
    // 0x686efc: stur            x3, [fp, #-0x18]
    // 0x686f00: cmp             w3, NULL
    // 0x686f04: b.eq            #0x6898a0
    // 0x686f08: r1 = Null
    //     0x686f08: mov             x1, NULL
    // 0x686f0c: r2 = 60
    //     0x686f0c: movz            x2, #0x3c
    // 0x686f10: r0 = CustomNum()
    //     0x686f10: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686f14: ldur            x1, [fp, #-8]
    // 0x686f18: r2 = 4
    //     0x686f18: movz            x2, #0x4
    // 0x686f1c: stur            x0, [fp, #-0x20]
    // 0x686f20: r0 = _getValueOrData()
    //     0x686f20: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686f24: mov             x1, x0
    // 0x686f28: ldur            x0, [fp, #-8]
    // 0x686f2c: LoadField: r2 = r0->field_f
    //     0x686f2c: ldur            w2, [x0, #0xf]
    // 0x686f30: DecompressPointer r2
    //     0x686f30: add             x2, x2, HEAP, lsl #32
    // 0x686f34: cmp             w2, w1
    // 0x686f38: b.ne            #0x686f40
    // 0x686f3c: r1 = Null
    //     0x686f3c: mov             x1, NULL
    // 0x686f40: ldur            x3, [fp, #-0x18]
    // 0x686f44: cmp             w1, NULL
    // 0x686f48: b.eq            #0x6898a4
    // 0x686f4c: LoadField: r2 = r1->field_f
    //     0x686f4c: ldur            w2, [x1, #0xf]
    // 0x686f50: DecompressPointer r2
    //     0x686f50: add             x2, x2, HEAP, lsl #32
    // 0x686f54: ldur            x1, [fp, #-0x20]
    // 0x686f58: r0 = mult2()
    //     0x686f58: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x686f5c: ldur            x1, [fp, #-0x18]
    // 0x686f60: StoreField: r1->field_f = r0
    //     0x686f60: stur            w0, [x1, #0xf]
    //     0x686f64: ldurb           w16, [x1, #-1]
    //     0x686f68: ldurb           w17, [x0, #-1]
    //     0x686f6c: and             x16, x17, x16, lsr #2
    //     0x686f70: tst             x16, HEAP, lsr #32
    //     0x686f74: b.eq            #0x686f7c
    //     0x686f78: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x686f7c: ldur            x1, [fp, #-8]
    // 0x686f80: r2 = 6
    //     0x686f80: movz            x2, #0x6
    // 0x686f84: r0 = _getValueOrData()
    //     0x686f84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686f88: mov             x1, x0
    // 0x686f8c: ldur            x0, [fp, #-8]
    // 0x686f90: LoadField: r2 = r0->field_f
    //     0x686f90: ldur            w2, [x0, #0xf]
    // 0x686f94: DecompressPointer r2
    //     0x686f94: add             x2, x2, HEAP, lsl #32
    // 0x686f98: cmp             w2, w1
    // 0x686f9c: b.ne            #0x686fa8
    // 0x686fa0: r3 = Null
    //     0x686fa0: mov             x3, NULL
    // 0x686fa4: b               #0x686fac
    // 0x686fa8: mov             x3, x1
    // 0x686fac: stur            x3, [fp, #-0x18]
    // 0x686fb0: cmp             w3, NULL
    // 0x686fb4: b.eq            #0x6898a8
    // 0x686fb8: r1 = Null
    //     0x686fb8: mov             x1, NULL
    // 0x686fbc: r2 = 60
    //     0x686fbc: movz            x2, #0x3c
    // 0x686fc0: r0 = CustomNum()
    //     0x686fc0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686fc4: ldur            x1, [fp, #-8]
    // 0x686fc8: r2 = 6
    //     0x686fc8: movz            x2, #0x6
    // 0x686fcc: stur            x0, [fp, #-0x20]
    // 0x686fd0: r0 = _getValueOrData()
    //     0x686fd0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686fd4: mov             x1, x0
    // 0x686fd8: ldur            x0, [fp, #-8]
    // 0x686fdc: LoadField: r2 = r0->field_f
    //     0x686fdc: ldur            w2, [x0, #0xf]
    // 0x686fe0: DecompressPointer r2
    //     0x686fe0: add             x2, x2, HEAP, lsl #32
    // 0x686fe4: cmp             w2, w1
    // 0x686fe8: b.ne            #0x686ff0
    // 0x686fec: r1 = Null
    //     0x686fec: mov             x1, NULL
    // 0x686ff0: ldur            x3, [fp, #-0x18]
    // 0x686ff4: cmp             w1, NULL
    // 0x686ff8: b.eq            #0x6898ac
    // 0x686ffc: LoadField: r2 = r1->field_f
    //     0x686ffc: ldur            w2, [x1, #0xf]
    // 0x687000: DecompressPointer r2
    //     0x687000: add             x2, x2, HEAP, lsl #32
    // 0x687004: ldur            x1, [fp, #-0x20]
    // 0x687008: r0 = mult2()
    //     0x687008: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68700c: ldur            x1, [fp, #-0x18]
    // 0x687010: StoreField: r1->field_f = r0
    //     0x687010: stur            w0, [x1, #0xf]
    //     0x687014: ldurb           w16, [x1, #-1]
    //     0x687018: ldurb           w17, [x0, #-1]
    //     0x68701c: and             x16, x17, x16, lsr #2
    //     0x687020: tst             x16, HEAP, lsr #32
    //     0x687024: b.eq            #0x68702c
    //     0x687028: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68702c: ldur            x1, [fp, #-8]
    // 0x687030: r2 = 8
    //     0x687030: movz            x2, #0x8
    // 0x687034: r0 = _getValueOrData()
    //     0x687034: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687038: mov             x1, x0
    // 0x68703c: ldur            x0, [fp, #-8]
    // 0x687040: LoadField: r2 = r0->field_f
    //     0x687040: ldur            w2, [x0, #0xf]
    // 0x687044: DecompressPointer r2
    //     0x687044: add             x2, x2, HEAP, lsl #32
    // 0x687048: cmp             w2, w1
    // 0x68704c: b.ne            #0x687058
    // 0x687050: r3 = Null
    //     0x687050: mov             x3, NULL
    // 0x687054: b               #0x68705c
    // 0x687058: mov             x3, x1
    // 0x68705c: stur            x3, [fp, #-0x18]
    // 0x687060: cmp             w3, NULL
    // 0x687064: b.eq            #0x6898b0
    // 0x687068: r1 = Null
    //     0x687068: mov             x1, NULL
    // 0x68706c: r2 = 60
    //     0x68706c: movz            x2, #0x3c
    // 0x687070: r0 = CustomNum()
    //     0x687070: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x687074: ldur            x1, [fp, #-8]
    // 0x687078: r2 = 8
    //     0x687078: movz            x2, #0x8
    // 0x68707c: stur            x0, [fp, #-0x20]
    // 0x687080: r0 = _getValueOrData()
    //     0x687080: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687084: mov             x1, x0
    // 0x687088: ldur            x0, [fp, #-8]
    // 0x68708c: LoadField: r2 = r0->field_f
    //     0x68708c: ldur            w2, [x0, #0xf]
    // 0x687090: DecompressPointer r2
    //     0x687090: add             x2, x2, HEAP, lsl #32
    // 0x687094: cmp             w2, w1
    // 0x687098: b.ne            #0x6870a0
    // 0x68709c: r1 = Null
    //     0x68709c: mov             x1, NULL
    // 0x6870a0: ldur            x3, [fp, #-0x18]
    // 0x6870a4: cmp             w1, NULL
    // 0x6870a8: b.eq            #0x6898b4
    // 0x6870ac: LoadField: r2 = r1->field_f
    //     0x6870ac: ldur            w2, [x1, #0xf]
    // 0x6870b0: DecompressPointer r2
    //     0x6870b0: add             x2, x2, HEAP, lsl #32
    // 0x6870b4: ldur            x1, [fp, #-0x20]
    // 0x6870b8: r0 = mult2()
    //     0x6870b8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6870bc: ldur            x1, [fp, #-0x18]
    // 0x6870c0: StoreField: r1->field_f = r0
    //     0x6870c0: stur            w0, [x1, #0xf]
    //     0x6870c4: ldurb           w16, [x1, #-1]
    //     0x6870c8: ldurb           w17, [x0, #-1]
    //     0x6870cc: and             x16, x17, x16, lsr #2
    //     0x6870d0: tst             x16, HEAP, lsr #32
    //     0x6870d4: b.eq            #0x6870dc
    //     0x6870d8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6870dc: ldur            x0, [fp, #-0x10]
    // 0x6870e0: LoadField: r1 = r0->field_43
    //     0x6870e0: ldur            w1, [x0, #0x43]
    // 0x6870e4: DecompressPointer r1
    //     0x6870e4: add             x1, x1, HEAP, lsl #32
    // 0x6870e8: r2 = 220
    //     0x6870e8: movz            x2, #0xdc
    // 0x6870ec: r0 = containsKey()
    //     0x6870ec: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6870f0: tbnz            w0, #4, #0x68742c
    // 0x6870f4: ldur            x0, [fp, #-8]
    // 0x6870f8: mov             x1, x0
    // 0x6870fc: r2 = 2
    //     0x6870fc: movz            x2, #0x2
    // 0x687100: r0 = _getValueOrData()
    //     0x687100: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687104: mov             x1, x0
    // 0x687108: ldur            x0, [fp, #-8]
    // 0x68710c: LoadField: r2 = r0->field_f
    //     0x68710c: ldur            w2, [x0, #0xf]
    // 0x687110: DecompressPointer r2
    //     0x687110: add             x2, x2, HEAP, lsl #32
    // 0x687114: cmp             w2, w1
    // 0x687118: b.ne            #0x687124
    // 0x68711c: r3 = Null
    //     0x68711c: mov             x3, NULL
    // 0x687120: b               #0x687128
    // 0x687124: mov             x3, x1
    // 0x687128: stur            x3, [fp, #-0x18]
    // 0x68712c: cmp             w3, NULL
    // 0x687130: b.eq            #0x6898b8
    // 0x687134: mov             x1, x0
    // 0x687138: r2 = 2
    //     0x687138: movz            x2, #0x2
    // 0x68713c: r0 = _getValueOrData()
    //     0x68713c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687140: mov             x1, x0
    // 0x687144: ldur            x0, [fp, #-8]
    // 0x687148: LoadField: r2 = r0->field_f
    //     0x687148: ldur            w2, [x0, #0xf]
    // 0x68714c: DecompressPointer r2
    //     0x68714c: add             x2, x2, HEAP, lsl #32
    // 0x687150: cmp             w2, w1
    // 0x687154: b.ne            #0x68715c
    // 0x687158: r1 = Null
    //     0x687158: mov             x1, NULL
    // 0x68715c: ldur            x3, [fp, #-0x18]
    // 0x687160: cmp             w1, NULL
    // 0x687164: b.eq            #0x6898bc
    // 0x687168: LoadField: r2 = r1->field_b
    //     0x687168: ldur            w2, [x1, #0xb]
    // 0x68716c: DecompressPointer r2
    //     0x68716c: add             x2, x2, HEAP, lsl #32
    // 0x687170: r1 = Instance_CustomNum
    //     0x687170: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x687174: ldr             x1, [x1, #0x60]
    // 0x687178: r0 = mult2()
    //     0x687178: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68717c: ldur            x1, [fp, #-0x18]
    // 0x687180: StoreField: r1->field_b = r0
    //     0x687180: stur            w0, [x1, #0xb]
    //     0x687184: ldurb           w16, [x1, #-1]
    //     0x687188: ldurb           w17, [x0, #-1]
    //     0x68718c: and             x16, x17, x16, lsr #2
    //     0x687190: tst             x16, HEAP, lsr #32
    //     0x687194: b.eq            #0x68719c
    //     0x687198: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68719c: ldur            x1, [fp, #-8]
    // 0x6871a0: r2 = 4
    //     0x6871a0: movz            x2, #0x4
    // 0x6871a4: r0 = _getValueOrData()
    //     0x6871a4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6871a8: mov             x1, x0
    // 0x6871ac: ldur            x0, [fp, #-8]
    // 0x6871b0: LoadField: r2 = r0->field_f
    //     0x6871b0: ldur            w2, [x0, #0xf]
    // 0x6871b4: DecompressPointer r2
    //     0x6871b4: add             x2, x2, HEAP, lsl #32
    // 0x6871b8: cmp             w2, w1
    // 0x6871bc: b.ne            #0x6871c8
    // 0x6871c0: r3 = Null
    //     0x6871c0: mov             x3, NULL
    // 0x6871c4: b               #0x6871cc
    // 0x6871c8: mov             x3, x1
    // 0x6871cc: stur            x3, [fp, #-0x18]
    // 0x6871d0: cmp             w3, NULL
    // 0x6871d4: b.eq            #0x6898c0
    // 0x6871d8: mov             x1, x0
    // 0x6871dc: r2 = 4
    //     0x6871dc: movz            x2, #0x4
    // 0x6871e0: r0 = _getValueOrData()
    //     0x6871e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6871e4: mov             x1, x0
    // 0x6871e8: ldur            x0, [fp, #-8]
    // 0x6871ec: LoadField: r2 = r0->field_f
    //     0x6871ec: ldur            w2, [x0, #0xf]
    // 0x6871f0: DecompressPointer r2
    //     0x6871f0: add             x2, x2, HEAP, lsl #32
    // 0x6871f4: cmp             w2, w1
    // 0x6871f8: b.ne            #0x687200
    // 0x6871fc: r1 = Null
    //     0x6871fc: mov             x1, NULL
    // 0x687200: ldur            x3, [fp, #-0x18]
    // 0x687204: cmp             w1, NULL
    // 0x687208: b.eq            #0x6898c4
    // 0x68720c: LoadField: r2 = r1->field_b
    //     0x68720c: ldur            w2, [x1, #0xb]
    // 0x687210: DecompressPointer r2
    //     0x687210: add             x2, x2, HEAP, lsl #32
    // 0x687214: r1 = Instance_CustomNum
    //     0x687214: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x687218: ldr             x1, [x1, #0x60]
    // 0x68721c: r0 = mult2()
    //     0x68721c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687220: ldur            x1, [fp, #-0x18]
    // 0x687224: StoreField: r1->field_b = r0
    //     0x687224: stur            w0, [x1, #0xb]
    //     0x687228: ldurb           w16, [x1, #-1]
    //     0x68722c: ldurb           w17, [x0, #-1]
    //     0x687230: and             x16, x17, x16, lsr #2
    //     0x687234: tst             x16, HEAP, lsr #32
    //     0x687238: b.eq            #0x687240
    //     0x68723c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687240: ldur            x1, [fp, #-8]
    // 0x687244: r2 = 6
    //     0x687244: movz            x2, #0x6
    // 0x687248: r0 = _getValueOrData()
    //     0x687248: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68724c: mov             x1, x0
    // 0x687250: ldur            x0, [fp, #-8]
    // 0x687254: LoadField: r2 = r0->field_f
    //     0x687254: ldur            w2, [x0, #0xf]
    // 0x687258: DecompressPointer r2
    //     0x687258: add             x2, x2, HEAP, lsl #32
    // 0x68725c: cmp             w2, w1
    // 0x687260: b.ne            #0x68726c
    // 0x687264: r3 = Null
    //     0x687264: mov             x3, NULL
    // 0x687268: b               #0x687270
    // 0x68726c: mov             x3, x1
    // 0x687270: stur            x3, [fp, #-0x18]
    // 0x687274: cmp             w3, NULL
    // 0x687278: b.eq            #0x6898c8
    // 0x68727c: mov             x1, x0
    // 0x687280: r2 = 6
    //     0x687280: movz            x2, #0x6
    // 0x687284: r0 = _getValueOrData()
    //     0x687284: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687288: mov             x1, x0
    // 0x68728c: ldur            x0, [fp, #-8]
    // 0x687290: LoadField: r2 = r0->field_f
    //     0x687290: ldur            w2, [x0, #0xf]
    // 0x687294: DecompressPointer r2
    //     0x687294: add             x2, x2, HEAP, lsl #32
    // 0x687298: cmp             w2, w1
    // 0x68729c: b.ne            #0x6872a4
    // 0x6872a0: r1 = Null
    //     0x6872a0: mov             x1, NULL
    // 0x6872a4: ldur            x3, [fp, #-0x18]
    // 0x6872a8: cmp             w1, NULL
    // 0x6872ac: b.eq            #0x6898cc
    // 0x6872b0: LoadField: r2 = r1->field_b
    //     0x6872b0: ldur            w2, [x1, #0xb]
    // 0x6872b4: DecompressPointer r2
    //     0x6872b4: add             x2, x2, HEAP, lsl #32
    // 0x6872b8: r1 = Instance_CustomNum
    //     0x6872b8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x6872bc: ldr             x1, [x1, #0x60]
    // 0x6872c0: r0 = mult2()
    //     0x6872c0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6872c4: ldur            x1, [fp, #-0x18]
    // 0x6872c8: StoreField: r1->field_b = r0
    //     0x6872c8: stur            w0, [x1, #0xb]
    //     0x6872cc: ldurb           w16, [x1, #-1]
    //     0x6872d0: ldurb           w17, [x0, #-1]
    //     0x6872d4: and             x16, x17, x16, lsr #2
    //     0x6872d8: tst             x16, HEAP, lsr #32
    //     0x6872dc: b.eq            #0x6872e4
    //     0x6872e0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6872e4: ldur            x1, [fp, #-8]
    // 0x6872e8: r2 = 8
    //     0x6872e8: movz            x2, #0x8
    // 0x6872ec: r0 = _getValueOrData()
    //     0x6872ec: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6872f0: mov             x1, x0
    // 0x6872f4: ldur            x0, [fp, #-8]
    // 0x6872f8: LoadField: r2 = r0->field_f
    //     0x6872f8: ldur            w2, [x0, #0xf]
    // 0x6872fc: DecompressPointer r2
    //     0x6872fc: add             x2, x2, HEAP, lsl #32
    // 0x687300: cmp             w2, w1
    // 0x687304: b.ne            #0x687310
    // 0x687308: r3 = Null
    //     0x687308: mov             x3, NULL
    // 0x68730c: b               #0x687314
    // 0x687310: mov             x3, x1
    // 0x687314: stur            x3, [fp, #-0x18]
    // 0x687318: cmp             w3, NULL
    // 0x68731c: b.eq            #0x6898d0
    // 0x687320: mov             x1, x0
    // 0x687324: r2 = 8
    //     0x687324: movz            x2, #0x8
    // 0x687328: r0 = _getValueOrData()
    //     0x687328: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68732c: mov             x1, x0
    // 0x687330: ldur            x0, [fp, #-8]
    // 0x687334: LoadField: r2 = r0->field_f
    //     0x687334: ldur            w2, [x0, #0xf]
    // 0x687338: DecompressPointer r2
    //     0x687338: add             x2, x2, HEAP, lsl #32
    // 0x68733c: cmp             w2, w1
    // 0x687340: b.ne            #0x687348
    // 0x687344: r1 = Null
    //     0x687344: mov             x1, NULL
    // 0x687348: ldur            x3, [fp, #-0x18]
    // 0x68734c: cmp             w1, NULL
    // 0x687350: b.eq            #0x6898d4
    // 0x687354: LoadField: r2 = r1->field_b
    //     0x687354: ldur            w2, [x1, #0xb]
    // 0x687358: DecompressPointer r2
    //     0x687358: add             x2, x2, HEAP, lsl #32
    // 0x68735c: r1 = Instance_CustomNum
    //     0x68735c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x687360: ldr             x1, [x1, #0x60]
    // 0x687364: r0 = mult2()
    //     0x687364: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687368: ldur            x1, [fp, #-0x18]
    // 0x68736c: StoreField: r1->field_b = r0
    //     0x68736c: stur            w0, [x1, #0xb]
    //     0x687370: ldurb           w16, [x1, #-1]
    //     0x687374: ldurb           w17, [x0, #-1]
    //     0x687378: and             x16, x17, x16, lsr #2
    //     0x68737c: tst             x16, HEAP, lsr #32
    //     0x687380: b.eq            #0x687388
    //     0x687384: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687388: ldur            x1, [fp, #-8]
    // 0x68738c: r2 = 10
    //     0x68738c: movz            x2, #0xa
    // 0x687390: r0 = _getValueOrData()
    //     0x687390: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687394: mov             x1, x0
    // 0x687398: ldur            x0, [fp, #-8]
    // 0x68739c: LoadField: r2 = r0->field_f
    //     0x68739c: ldur            w2, [x0, #0xf]
    // 0x6873a0: DecompressPointer r2
    //     0x6873a0: add             x2, x2, HEAP, lsl #32
    // 0x6873a4: cmp             w2, w1
    // 0x6873a8: b.ne            #0x6873b4
    // 0x6873ac: r3 = Null
    //     0x6873ac: mov             x3, NULL
    // 0x6873b0: b               #0x6873b8
    // 0x6873b4: mov             x3, x1
    // 0x6873b8: stur            x3, [fp, #-0x18]
    // 0x6873bc: cmp             w3, NULL
    // 0x6873c0: b.eq            #0x6898d8
    // 0x6873c4: mov             x1, x0
    // 0x6873c8: r2 = 10
    //     0x6873c8: movz            x2, #0xa
    // 0x6873cc: r0 = _getValueOrData()
    //     0x6873cc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6873d0: mov             x1, x0
    // 0x6873d4: ldur            x0, [fp, #-8]
    // 0x6873d8: LoadField: r2 = r0->field_f
    //     0x6873d8: ldur            w2, [x0, #0xf]
    // 0x6873dc: DecompressPointer r2
    //     0x6873dc: add             x2, x2, HEAP, lsl #32
    // 0x6873e0: cmp             w2, w1
    // 0x6873e4: b.ne            #0x6873ec
    // 0x6873e8: r1 = Null
    //     0x6873e8: mov             x1, NULL
    // 0x6873ec: ldur            x3, [fp, #-0x18]
    // 0x6873f0: cmp             w1, NULL
    // 0x6873f4: b.eq            #0x6898dc
    // 0x6873f8: LoadField: r2 = r1->field_b
    //     0x6873f8: ldur            w2, [x1, #0xb]
    // 0x6873fc: DecompressPointer r2
    //     0x6873fc: add             x2, x2, HEAP, lsl #32
    // 0x687400: r1 = Instance_CustomNum
    //     0x687400: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x687404: ldr             x1, [x1, #0x60]
    // 0x687408: r0 = mult2()
    //     0x687408: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68740c: ldur            x1, [fp, #-0x18]
    // 0x687410: StoreField: r1->field_b = r0
    //     0x687410: stur            w0, [x1, #0xb]
    //     0x687414: ldurb           w16, [x1, #-1]
    //     0x687418: ldurb           w17, [x0, #-1]
    //     0x68741c: and             x16, x17, x16, lsr #2
    //     0x687420: tst             x16, HEAP, lsr #32
    //     0x687424: b.eq            #0x68742c
    //     0x687428: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68742c: ldur            x0, [fp, #-0x10]
    // 0x687430: LoadField: r1 = r0->field_43
    //     0x687430: ldur            w1, [x0, #0x43]
    // 0x687434: DecompressPointer r1
    //     0x687434: add             x1, x1, HEAP, lsl #32
    // 0x687438: r2 = 404
    //     0x687438: movz            x2, #0x194
    // 0x68743c: r0 = containsKey()
    //     0x68743c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x687440: tbnz            w0, #4, #0x68777c
    // 0x687444: ldur            x0, [fp, #-8]
    // 0x687448: mov             x1, x0
    // 0x68744c: r2 = 2
    //     0x68744c: movz            x2, #0x2
    // 0x687450: r0 = _getValueOrData()
    //     0x687450: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687454: mov             x1, x0
    // 0x687458: ldur            x0, [fp, #-8]
    // 0x68745c: LoadField: r2 = r0->field_f
    //     0x68745c: ldur            w2, [x0, #0xf]
    // 0x687460: DecompressPointer r2
    //     0x687460: add             x2, x2, HEAP, lsl #32
    // 0x687464: cmp             w2, w1
    // 0x687468: b.ne            #0x687474
    // 0x68746c: r3 = Null
    //     0x68746c: mov             x3, NULL
    // 0x687470: b               #0x687478
    // 0x687474: mov             x3, x1
    // 0x687478: stur            x3, [fp, #-0x18]
    // 0x68747c: cmp             w3, NULL
    // 0x687480: b.eq            #0x6898e0
    // 0x687484: mov             x1, x0
    // 0x687488: r2 = 2
    //     0x687488: movz            x2, #0x2
    // 0x68748c: r0 = _getValueOrData()
    //     0x68748c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687490: mov             x1, x0
    // 0x687494: ldur            x0, [fp, #-8]
    // 0x687498: LoadField: r2 = r0->field_f
    //     0x687498: ldur            w2, [x0, #0xf]
    // 0x68749c: DecompressPointer r2
    //     0x68749c: add             x2, x2, HEAP, lsl #32
    // 0x6874a0: cmp             w2, w1
    // 0x6874a4: b.ne            #0x6874ac
    // 0x6874a8: r1 = Null
    //     0x6874a8: mov             x1, NULL
    // 0x6874ac: ldur            x3, [fp, #-0x18]
    // 0x6874b0: cmp             w1, NULL
    // 0x6874b4: b.eq            #0x6898e4
    // 0x6874b8: LoadField: r2 = r1->field_b
    //     0x6874b8: ldur            w2, [x1, #0xb]
    // 0x6874bc: DecompressPointer r2
    //     0x6874bc: add             x2, x2, HEAP, lsl #32
    // 0x6874c0: r1 = Instance_CustomNum
    //     0x6874c0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x6874c4: ldr             x1, [x1, #0x60]
    // 0x6874c8: r0 = mult2()
    //     0x6874c8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6874cc: ldur            x1, [fp, #-0x18]
    // 0x6874d0: StoreField: r1->field_b = r0
    //     0x6874d0: stur            w0, [x1, #0xb]
    //     0x6874d4: ldurb           w16, [x1, #-1]
    //     0x6874d8: ldurb           w17, [x0, #-1]
    //     0x6874dc: and             x16, x17, x16, lsr #2
    //     0x6874e0: tst             x16, HEAP, lsr #32
    //     0x6874e4: b.eq            #0x6874ec
    //     0x6874e8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6874ec: ldur            x1, [fp, #-8]
    // 0x6874f0: r2 = 4
    //     0x6874f0: movz            x2, #0x4
    // 0x6874f4: r0 = _getValueOrData()
    //     0x6874f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6874f8: mov             x1, x0
    // 0x6874fc: ldur            x0, [fp, #-8]
    // 0x687500: LoadField: r2 = r0->field_f
    //     0x687500: ldur            w2, [x0, #0xf]
    // 0x687504: DecompressPointer r2
    //     0x687504: add             x2, x2, HEAP, lsl #32
    // 0x687508: cmp             w2, w1
    // 0x68750c: b.ne            #0x687518
    // 0x687510: r3 = Null
    //     0x687510: mov             x3, NULL
    // 0x687514: b               #0x68751c
    // 0x687518: mov             x3, x1
    // 0x68751c: stur            x3, [fp, #-0x18]
    // 0x687520: cmp             w3, NULL
    // 0x687524: b.eq            #0x6898e8
    // 0x687528: mov             x1, x0
    // 0x68752c: r2 = 4
    //     0x68752c: movz            x2, #0x4
    // 0x687530: r0 = _getValueOrData()
    //     0x687530: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687534: mov             x1, x0
    // 0x687538: ldur            x0, [fp, #-8]
    // 0x68753c: LoadField: r2 = r0->field_f
    //     0x68753c: ldur            w2, [x0, #0xf]
    // 0x687540: DecompressPointer r2
    //     0x687540: add             x2, x2, HEAP, lsl #32
    // 0x687544: cmp             w2, w1
    // 0x687548: b.ne            #0x687550
    // 0x68754c: r1 = Null
    //     0x68754c: mov             x1, NULL
    // 0x687550: ldur            x3, [fp, #-0x18]
    // 0x687554: cmp             w1, NULL
    // 0x687558: b.eq            #0x6898ec
    // 0x68755c: LoadField: r2 = r1->field_b
    //     0x68755c: ldur            w2, [x1, #0xb]
    // 0x687560: DecompressPointer r2
    //     0x687560: add             x2, x2, HEAP, lsl #32
    // 0x687564: r1 = Instance_CustomNum
    //     0x687564: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x687568: ldr             x1, [x1, #0x60]
    // 0x68756c: r0 = mult2()
    //     0x68756c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687570: ldur            x1, [fp, #-0x18]
    // 0x687574: StoreField: r1->field_b = r0
    //     0x687574: stur            w0, [x1, #0xb]
    //     0x687578: ldurb           w16, [x1, #-1]
    //     0x68757c: ldurb           w17, [x0, #-1]
    //     0x687580: and             x16, x17, x16, lsr #2
    //     0x687584: tst             x16, HEAP, lsr #32
    //     0x687588: b.eq            #0x687590
    //     0x68758c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687590: ldur            x1, [fp, #-8]
    // 0x687594: r2 = 6
    //     0x687594: movz            x2, #0x6
    // 0x687598: r0 = _getValueOrData()
    //     0x687598: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68759c: mov             x1, x0
    // 0x6875a0: ldur            x0, [fp, #-8]
    // 0x6875a4: LoadField: r2 = r0->field_f
    //     0x6875a4: ldur            w2, [x0, #0xf]
    // 0x6875a8: DecompressPointer r2
    //     0x6875a8: add             x2, x2, HEAP, lsl #32
    // 0x6875ac: cmp             w2, w1
    // 0x6875b0: b.ne            #0x6875bc
    // 0x6875b4: r3 = Null
    //     0x6875b4: mov             x3, NULL
    // 0x6875b8: b               #0x6875c0
    // 0x6875bc: mov             x3, x1
    // 0x6875c0: stur            x3, [fp, #-0x18]
    // 0x6875c4: cmp             w3, NULL
    // 0x6875c8: b.eq            #0x6898f0
    // 0x6875cc: mov             x1, x0
    // 0x6875d0: r2 = 6
    //     0x6875d0: movz            x2, #0x6
    // 0x6875d4: r0 = _getValueOrData()
    //     0x6875d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6875d8: mov             x1, x0
    // 0x6875dc: ldur            x0, [fp, #-8]
    // 0x6875e0: LoadField: r2 = r0->field_f
    //     0x6875e0: ldur            w2, [x0, #0xf]
    // 0x6875e4: DecompressPointer r2
    //     0x6875e4: add             x2, x2, HEAP, lsl #32
    // 0x6875e8: cmp             w2, w1
    // 0x6875ec: b.ne            #0x6875f4
    // 0x6875f0: r1 = Null
    //     0x6875f0: mov             x1, NULL
    // 0x6875f4: ldur            x3, [fp, #-0x18]
    // 0x6875f8: cmp             w1, NULL
    // 0x6875fc: b.eq            #0x6898f4
    // 0x687600: LoadField: r2 = r1->field_b
    //     0x687600: ldur            w2, [x1, #0xb]
    // 0x687604: DecompressPointer r2
    //     0x687604: add             x2, x2, HEAP, lsl #32
    // 0x687608: r1 = Instance_CustomNum
    //     0x687608: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x68760c: ldr             x1, [x1, #0x60]
    // 0x687610: r0 = mult2()
    //     0x687610: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687614: ldur            x1, [fp, #-0x18]
    // 0x687618: StoreField: r1->field_b = r0
    //     0x687618: stur            w0, [x1, #0xb]
    //     0x68761c: ldurb           w16, [x1, #-1]
    //     0x687620: ldurb           w17, [x0, #-1]
    //     0x687624: and             x16, x17, x16, lsr #2
    //     0x687628: tst             x16, HEAP, lsr #32
    //     0x68762c: b.eq            #0x687634
    //     0x687630: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687634: ldur            x1, [fp, #-8]
    // 0x687638: r2 = 8
    //     0x687638: movz            x2, #0x8
    // 0x68763c: r0 = _getValueOrData()
    //     0x68763c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687640: mov             x1, x0
    // 0x687644: ldur            x0, [fp, #-8]
    // 0x687648: LoadField: r2 = r0->field_f
    //     0x687648: ldur            w2, [x0, #0xf]
    // 0x68764c: DecompressPointer r2
    //     0x68764c: add             x2, x2, HEAP, lsl #32
    // 0x687650: cmp             w2, w1
    // 0x687654: b.ne            #0x687660
    // 0x687658: r3 = Null
    //     0x687658: mov             x3, NULL
    // 0x68765c: b               #0x687664
    // 0x687660: mov             x3, x1
    // 0x687664: stur            x3, [fp, #-0x18]
    // 0x687668: cmp             w3, NULL
    // 0x68766c: b.eq            #0x6898f8
    // 0x687670: mov             x1, x0
    // 0x687674: r2 = 8
    //     0x687674: movz            x2, #0x8
    // 0x687678: r0 = _getValueOrData()
    //     0x687678: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68767c: mov             x1, x0
    // 0x687680: ldur            x0, [fp, #-8]
    // 0x687684: LoadField: r2 = r0->field_f
    //     0x687684: ldur            w2, [x0, #0xf]
    // 0x687688: DecompressPointer r2
    //     0x687688: add             x2, x2, HEAP, lsl #32
    // 0x68768c: cmp             w2, w1
    // 0x687690: b.ne            #0x687698
    // 0x687694: r1 = Null
    //     0x687694: mov             x1, NULL
    // 0x687698: ldur            x3, [fp, #-0x18]
    // 0x68769c: cmp             w1, NULL
    // 0x6876a0: b.eq            #0x6898fc
    // 0x6876a4: LoadField: r2 = r1->field_b
    //     0x6876a4: ldur            w2, [x1, #0xb]
    // 0x6876a8: DecompressPointer r2
    //     0x6876a8: add             x2, x2, HEAP, lsl #32
    // 0x6876ac: r1 = Instance_CustomNum
    //     0x6876ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x6876b0: ldr             x1, [x1, #0x60]
    // 0x6876b4: r0 = mult2()
    //     0x6876b4: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6876b8: ldur            x1, [fp, #-0x18]
    // 0x6876bc: StoreField: r1->field_b = r0
    //     0x6876bc: stur            w0, [x1, #0xb]
    //     0x6876c0: ldurb           w16, [x1, #-1]
    //     0x6876c4: ldurb           w17, [x0, #-1]
    //     0x6876c8: and             x16, x17, x16, lsr #2
    //     0x6876cc: tst             x16, HEAP, lsr #32
    //     0x6876d0: b.eq            #0x6876d8
    //     0x6876d4: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6876d8: ldur            x1, [fp, #-8]
    // 0x6876dc: r2 = 10
    //     0x6876dc: movz            x2, #0xa
    // 0x6876e0: r0 = _getValueOrData()
    //     0x6876e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6876e4: mov             x1, x0
    // 0x6876e8: ldur            x0, [fp, #-8]
    // 0x6876ec: LoadField: r2 = r0->field_f
    //     0x6876ec: ldur            w2, [x0, #0xf]
    // 0x6876f0: DecompressPointer r2
    //     0x6876f0: add             x2, x2, HEAP, lsl #32
    // 0x6876f4: cmp             w2, w1
    // 0x6876f8: b.ne            #0x687704
    // 0x6876fc: r3 = Null
    //     0x6876fc: mov             x3, NULL
    // 0x687700: b               #0x687708
    // 0x687704: mov             x3, x1
    // 0x687708: stur            x3, [fp, #-0x18]
    // 0x68770c: cmp             w3, NULL
    // 0x687710: b.eq            #0x689900
    // 0x687714: mov             x1, x0
    // 0x687718: r2 = 10
    //     0x687718: movz            x2, #0xa
    // 0x68771c: r0 = _getValueOrData()
    //     0x68771c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687720: mov             x1, x0
    // 0x687724: ldur            x0, [fp, #-8]
    // 0x687728: LoadField: r2 = r0->field_f
    //     0x687728: ldur            w2, [x0, #0xf]
    // 0x68772c: DecompressPointer r2
    //     0x68772c: add             x2, x2, HEAP, lsl #32
    // 0x687730: cmp             w2, w1
    // 0x687734: b.ne            #0x68773c
    // 0x687738: r1 = Null
    //     0x687738: mov             x1, NULL
    // 0x68773c: ldur            x3, [fp, #-0x18]
    // 0x687740: cmp             w1, NULL
    // 0x687744: b.eq            #0x689904
    // 0x687748: LoadField: r2 = r1->field_b
    //     0x687748: ldur            w2, [x1, #0xb]
    // 0x68774c: DecompressPointer r2
    //     0x68774c: add             x2, x2, HEAP, lsl #32
    // 0x687750: r1 = Instance_CustomNum
    //     0x687750: add             x1, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x687754: ldr             x1, [x1, #0x60]
    // 0x687758: r0 = mult2()
    //     0x687758: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68775c: ldur            x1, [fp, #-0x18]
    // 0x687760: StoreField: r1->field_b = r0
    //     0x687760: stur            w0, [x1, #0xb]
    //     0x687764: ldurb           w16, [x1, #-1]
    //     0x687768: ldurb           w17, [x0, #-1]
    //     0x68776c: and             x16, x17, x16, lsr #2
    //     0x687770: tst             x16, HEAP, lsr #32
    //     0x687774: b.eq            #0x68777c
    //     0x687778: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68777c: ldur            x0, [fp, #-0x10]
    // 0x687780: LoadField: r1 = r0->field_43
    //     0x687780: ldur            w1, [x0, #0x43]
    // 0x687784: DecompressPointer r1
    //     0x687784: add             x1, x1, HEAP, lsl #32
    // 0x687788: r2 = 224
    //     0x687788: movz            x2, #0xe0
    // 0x68778c: r0 = containsKey()
    //     0x68778c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x687790: tbnz            w0, #4, #0x687acc
    // 0x687794: ldur            x0, [fp, #-8]
    // 0x687798: mov             x1, x0
    // 0x68779c: r2 = 2
    //     0x68779c: movz            x2, #0x2
    // 0x6877a0: r0 = _getValueOrData()
    //     0x6877a0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6877a4: mov             x1, x0
    // 0x6877a8: ldur            x0, [fp, #-8]
    // 0x6877ac: LoadField: r2 = r0->field_f
    //     0x6877ac: ldur            w2, [x0, #0xf]
    // 0x6877b0: DecompressPointer r2
    //     0x6877b0: add             x2, x2, HEAP, lsl #32
    // 0x6877b4: cmp             w2, w1
    // 0x6877b8: b.ne            #0x6877c4
    // 0x6877bc: r3 = Null
    //     0x6877bc: mov             x3, NULL
    // 0x6877c0: b               #0x6877c8
    // 0x6877c4: mov             x3, x1
    // 0x6877c8: stur            x3, [fp, #-0x18]
    // 0x6877cc: cmp             w3, NULL
    // 0x6877d0: b.eq            #0x689908
    // 0x6877d4: mov             x1, x0
    // 0x6877d8: r2 = 2
    //     0x6877d8: movz            x2, #0x2
    // 0x6877dc: r0 = _getValueOrData()
    //     0x6877dc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6877e0: mov             x1, x0
    // 0x6877e4: ldur            x0, [fp, #-8]
    // 0x6877e8: LoadField: r2 = r0->field_f
    //     0x6877e8: ldur            w2, [x0, #0xf]
    // 0x6877ec: DecompressPointer r2
    //     0x6877ec: add             x2, x2, HEAP, lsl #32
    // 0x6877f0: cmp             w2, w1
    // 0x6877f4: b.ne            #0x6877fc
    // 0x6877f8: r1 = Null
    //     0x6877f8: mov             x1, NULL
    // 0x6877fc: ldur            x3, [fp, #-0x18]
    // 0x687800: cmp             w1, NULL
    // 0x687804: b.eq            #0x68990c
    // 0x687808: LoadField: r2 = r1->field_f
    //     0x687808: ldur            w2, [x1, #0xf]
    // 0x68780c: DecompressPointer r2
    //     0x68780c: add             x2, x2, HEAP, lsl #32
    // 0x687810: r1 = Instance_CustomNum
    //     0x687810: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x687814: ldr             x1, [x1, #0x448]
    // 0x687818: r0 = mult2()
    //     0x687818: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68781c: ldur            x1, [fp, #-0x18]
    // 0x687820: StoreField: r1->field_f = r0
    //     0x687820: stur            w0, [x1, #0xf]
    //     0x687824: ldurb           w16, [x1, #-1]
    //     0x687828: ldurb           w17, [x0, #-1]
    //     0x68782c: and             x16, x17, x16, lsr #2
    //     0x687830: tst             x16, HEAP, lsr #32
    //     0x687834: b.eq            #0x68783c
    //     0x687838: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68783c: ldur            x1, [fp, #-8]
    // 0x687840: r2 = 4
    //     0x687840: movz            x2, #0x4
    // 0x687844: r0 = _getValueOrData()
    //     0x687844: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687848: mov             x1, x0
    // 0x68784c: ldur            x0, [fp, #-8]
    // 0x687850: LoadField: r2 = r0->field_f
    //     0x687850: ldur            w2, [x0, #0xf]
    // 0x687854: DecompressPointer r2
    //     0x687854: add             x2, x2, HEAP, lsl #32
    // 0x687858: cmp             w2, w1
    // 0x68785c: b.ne            #0x687868
    // 0x687860: r3 = Null
    //     0x687860: mov             x3, NULL
    // 0x687864: b               #0x68786c
    // 0x687868: mov             x3, x1
    // 0x68786c: stur            x3, [fp, #-0x18]
    // 0x687870: cmp             w3, NULL
    // 0x687874: b.eq            #0x689910
    // 0x687878: mov             x1, x0
    // 0x68787c: r2 = 4
    //     0x68787c: movz            x2, #0x4
    // 0x687880: r0 = _getValueOrData()
    //     0x687880: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687884: mov             x1, x0
    // 0x687888: ldur            x0, [fp, #-8]
    // 0x68788c: LoadField: r2 = r0->field_f
    //     0x68788c: ldur            w2, [x0, #0xf]
    // 0x687890: DecompressPointer r2
    //     0x687890: add             x2, x2, HEAP, lsl #32
    // 0x687894: cmp             w2, w1
    // 0x687898: b.ne            #0x6878a0
    // 0x68789c: r1 = Null
    //     0x68789c: mov             x1, NULL
    // 0x6878a0: ldur            x3, [fp, #-0x18]
    // 0x6878a4: cmp             w1, NULL
    // 0x6878a8: b.eq            #0x689914
    // 0x6878ac: LoadField: r2 = r1->field_f
    //     0x6878ac: ldur            w2, [x1, #0xf]
    // 0x6878b0: DecompressPointer r2
    //     0x6878b0: add             x2, x2, HEAP, lsl #32
    // 0x6878b4: r1 = Instance_CustomNum
    //     0x6878b4: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x6878b8: ldr             x1, [x1, #0x448]
    // 0x6878bc: r0 = mult2()
    //     0x6878bc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6878c0: ldur            x1, [fp, #-0x18]
    // 0x6878c4: StoreField: r1->field_f = r0
    //     0x6878c4: stur            w0, [x1, #0xf]
    //     0x6878c8: ldurb           w16, [x1, #-1]
    //     0x6878cc: ldurb           w17, [x0, #-1]
    //     0x6878d0: and             x16, x17, x16, lsr #2
    //     0x6878d4: tst             x16, HEAP, lsr #32
    //     0x6878d8: b.eq            #0x6878e0
    //     0x6878dc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6878e0: ldur            x1, [fp, #-8]
    // 0x6878e4: r2 = 6
    //     0x6878e4: movz            x2, #0x6
    // 0x6878e8: r0 = _getValueOrData()
    //     0x6878e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6878ec: mov             x1, x0
    // 0x6878f0: ldur            x0, [fp, #-8]
    // 0x6878f4: LoadField: r2 = r0->field_f
    //     0x6878f4: ldur            w2, [x0, #0xf]
    // 0x6878f8: DecompressPointer r2
    //     0x6878f8: add             x2, x2, HEAP, lsl #32
    // 0x6878fc: cmp             w2, w1
    // 0x687900: b.ne            #0x68790c
    // 0x687904: r3 = Null
    //     0x687904: mov             x3, NULL
    // 0x687908: b               #0x687910
    // 0x68790c: mov             x3, x1
    // 0x687910: stur            x3, [fp, #-0x18]
    // 0x687914: cmp             w3, NULL
    // 0x687918: b.eq            #0x689918
    // 0x68791c: mov             x1, x0
    // 0x687920: r2 = 6
    //     0x687920: movz            x2, #0x6
    // 0x687924: r0 = _getValueOrData()
    //     0x687924: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687928: mov             x1, x0
    // 0x68792c: ldur            x0, [fp, #-8]
    // 0x687930: LoadField: r2 = r0->field_f
    //     0x687930: ldur            w2, [x0, #0xf]
    // 0x687934: DecompressPointer r2
    //     0x687934: add             x2, x2, HEAP, lsl #32
    // 0x687938: cmp             w2, w1
    // 0x68793c: b.ne            #0x687944
    // 0x687940: r1 = Null
    //     0x687940: mov             x1, NULL
    // 0x687944: ldur            x3, [fp, #-0x18]
    // 0x687948: cmp             w1, NULL
    // 0x68794c: b.eq            #0x68991c
    // 0x687950: LoadField: r2 = r1->field_f
    //     0x687950: ldur            w2, [x1, #0xf]
    // 0x687954: DecompressPointer r2
    //     0x687954: add             x2, x2, HEAP, lsl #32
    // 0x687958: r1 = Instance_CustomNum
    //     0x687958: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x68795c: ldr             x1, [x1, #0x448]
    // 0x687960: r0 = mult2()
    //     0x687960: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687964: ldur            x1, [fp, #-0x18]
    // 0x687968: StoreField: r1->field_f = r0
    //     0x687968: stur            w0, [x1, #0xf]
    //     0x68796c: ldurb           w16, [x1, #-1]
    //     0x687970: ldurb           w17, [x0, #-1]
    //     0x687974: and             x16, x17, x16, lsr #2
    //     0x687978: tst             x16, HEAP, lsr #32
    //     0x68797c: b.eq            #0x687984
    //     0x687980: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687984: ldur            x1, [fp, #-8]
    // 0x687988: r2 = 8
    //     0x687988: movz            x2, #0x8
    // 0x68798c: r0 = _getValueOrData()
    //     0x68798c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687990: mov             x1, x0
    // 0x687994: ldur            x0, [fp, #-8]
    // 0x687998: LoadField: r2 = r0->field_f
    //     0x687998: ldur            w2, [x0, #0xf]
    // 0x68799c: DecompressPointer r2
    //     0x68799c: add             x2, x2, HEAP, lsl #32
    // 0x6879a0: cmp             w2, w1
    // 0x6879a4: b.ne            #0x6879b0
    // 0x6879a8: r3 = Null
    //     0x6879a8: mov             x3, NULL
    // 0x6879ac: b               #0x6879b4
    // 0x6879b0: mov             x3, x1
    // 0x6879b4: stur            x3, [fp, #-0x18]
    // 0x6879b8: cmp             w3, NULL
    // 0x6879bc: b.eq            #0x689920
    // 0x6879c0: mov             x1, x0
    // 0x6879c4: r2 = 8
    //     0x6879c4: movz            x2, #0x8
    // 0x6879c8: r0 = _getValueOrData()
    //     0x6879c8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6879cc: mov             x1, x0
    // 0x6879d0: ldur            x0, [fp, #-8]
    // 0x6879d4: LoadField: r2 = r0->field_f
    //     0x6879d4: ldur            w2, [x0, #0xf]
    // 0x6879d8: DecompressPointer r2
    //     0x6879d8: add             x2, x2, HEAP, lsl #32
    // 0x6879dc: cmp             w2, w1
    // 0x6879e0: b.ne            #0x6879e8
    // 0x6879e4: r1 = Null
    //     0x6879e4: mov             x1, NULL
    // 0x6879e8: ldur            x3, [fp, #-0x18]
    // 0x6879ec: cmp             w1, NULL
    // 0x6879f0: b.eq            #0x689924
    // 0x6879f4: LoadField: r2 = r1->field_f
    //     0x6879f4: ldur            w2, [x1, #0xf]
    // 0x6879f8: DecompressPointer r2
    //     0x6879f8: add             x2, x2, HEAP, lsl #32
    // 0x6879fc: r1 = Instance_CustomNum
    //     0x6879fc: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x687a00: ldr             x1, [x1, #0x448]
    // 0x687a04: r0 = mult2()
    //     0x687a04: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687a08: ldur            x1, [fp, #-0x18]
    // 0x687a0c: StoreField: r1->field_f = r0
    //     0x687a0c: stur            w0, [x1, #0xf]
    //     0x687a10: ldurb           w16, [x1, #-1]
    //     0x687a14: ldurb           w17, [x0, #-1]
    //     0x687a18: and             x16, x17, x16, lsr #2
    //     0x687a1c: tst             x16, HEAP, lsr #32
    //     0x687a20: b.eq            #0x687a28
    //     0x687a24: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687a28: ldur            x1, [fp, #-8]
    // 0x687a2c: r2 = 10
    //     0x687a2c: movz            x2, #0xa
    // 0x687a30: r0 = _getValueOrData()
    //     0x687a30: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687a34: mov             x1, x0
    // 0x687a38: ldur            x0, [fp, #-8]
    // 0x687a3c: LoadField: r2 = r0->field_f
    //     0x687a3c: ldur            w2, [x0, #0xf]
    // 0x687a40: DecompressPointer r2
    //     0x687a40: add             x2, x2, HEAP, lsl #32
    // 0x687a44: cmp             w2, w1
    // 0x687a48: b.ne            #0x687a54
    // 0x687a4c: r3 = Null
    //     0x687a4c: mov             x3, NULL
    // 0x687a50: b               #0x687a58
    // 0x687a54: mov             x3, x1
    // 0x687a58: stur            x3, [fp, #-0x18]
    // 0x687a5c: cmp             w3, NULL
    // 0x687a60: b.eq            #0x689928
    // 0x687a64: mov             x1, x0
    // 0x687a68: r2 = 10
    //     0x687a68: movz            x2, #0xa
    // 0x687a6c: r0 = _getValueOrData()
    //     0x687a6c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687a70: mov             x1, x0
    // 0x687a74: ldur            x0, [fp, #-8]
    // 0x687a78: LoadField: r2 = r0->field_f
    //     0x687a78: ldur            w2, [x0, #0xf]
    // 0x687a7c: DecompressPointer r2
    //     0x687a7c: add             x2, x2, HEAP, lsl #32
    // 0x687a80: cmp             w2, w1
    // 0x687a84: b.ne            #0x687a8c
    // 0x687a88: r1 = Null
    //     0x687a88: mov             x1, NULL
    // 0x687a8c: ldur            x3, [fp, #-0x18]
    // 0x687a90: cmp             w1, NULL
    // 0x687a94: b.eq            #0x68992c
    // 0x687a98: LoadField: r2 = r1->field_f
    //     0x687a98: ldur            w2, [x1, #0xf]
    // 0x687a9c: DecompressPointer r2
    //     0x687a9c: add             x2, x2, HEAP, lsl #32
    // 0x687aa0: r1 = Instance_CustomNum
    //     0x687aa0: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x687aa4: ldr             x1, [x1, #0x448]
    // 0x687aa8: r0 = mult2()
    //     0x687aa8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687aac: ldur            x1, [fp, #-0x18]
    // 0x687ab0: StoreField: r1->field_f = r0
    //     0x687ab0: stur            w0, [x1, #0xf]
    //     0x687ab4: ldurb           w16, [x1, #-1]
    //     0x687ab8: ldurb           w17, [x0, #-1]
    //     0x687abc: and             x16, x17, x16, lsr #2
    //     0x687ac0: tst             x16, HEAP, lsr #32
    //     0x687ac4: b.eq            #0x687acc
    //     0x687ac8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687acc: ldur            x0, [fp, #-0x10]
    // 0x687ad0: LoadField: r1 = r0->field_43
    //     0x687ad0: ldur            w1, [x0, #0x43]
    // 0x687ad4: DecompressPointer r1
    //     0x687ad4: add             x1, x1, HEAP, lsl #32
    // 0x687ad8: r2 = 232
    //     0x687ad8: movz            x2, #0xe8
    // 0x687adc: r0 = containsKey()
    //     0x687adc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x687ae0: tbnz            w0, #4, #0x687c30
    // 0x687ae4: ldur            x0, [fp, #-8]
    // 0x687ae8: mov             x1, x0
    // 0x687aec: r2 = 4
    //     0x687aec: movz            x2, #0x4
    // 0x687af0: r0 = _getValueOrData()
    //     0x687af0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687af4: mov             x1, x0
    // 0x687af8: ldur            x0, [fp, #-8]
    // 0x687afc: LoadField: r2 = r0->field_f
    //     0x687afc: ldur            w2, [x0, #0xf]
    // 0x687b00: DecompressPointer r2
    //     0x687b00: add             x2, x2, HEAP, lsl #32
    // 0x687b04: cmp             w2, w1
    // 0x687b08: b.ne            #0x687b14
    // 0x687b0c: r3 = Null
    //     0x687b0c: mov             x3, NULL
    // 0x687b10: b               #0x687b18
    // 0x687b14: mov             x3, x1
    // 0x687b18: stur            x3, [fp, #-0x18]
    // 0x687b1c: cmp             w3, NULL
    // 0x687b20: b.eq            #0x689930
    // 0x687b24: mov             x1, x0
    // 0x687b28: r2 = 4
    //     0x687b28: movz            x2, #0x4
    // 0x687b2c: r0 = _getValueOrData()
    //     0x687b2c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687b30: mov             x1, x0
    // 0x687b34: ldur            x0, [fp, #-8]
    // 0x687b38: LoadField: r2 = r0->field_f
    //     0x687b38: ldur            w2, [x0, #0xf]
    // 0x687b3c: DecompressPointer r2
    //     0x687b3c: add             x2, x2, HEAP, lsl #32
    // 0x687b40: cmp             w2, w1
    // 0x687b44: b.ne            #0x687b4c
    // 0x687b48: r1 = Null
    //     0x687b48: mov             x1, NULL
    // 0x687b4c: ldur            x3, [fp, #-0x18]
    // 0x687b50: cmp             w1, NULL
    // 0x687b54: b.eq            #0x689934
    // 0x687b58: LoadField: r2 = r1->field_f
    //     0x687b58: ldur            w2, [x1, #0xf]
    // 0x687b5c: DecompressPointer r2
    //     0x687b5c: add             x2, x2, HEAP, lsl #32
    // 0x687b60: r1 = Instance_CustomNum
    //     0x687b60: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x687b64: ldr             x1, [x1, #0x448]
    // 0x687b68: r0 = mult2()
    //     0x687b68: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687b6c: ldur            x1, [fp, #-0x18]
    // 0x687b70: StoreField: r1->field_f = r0
    //     0x687b70: stur            w0, [x1, #0xf]
    //     0x687b74: ldurb           w16, [x1, #-1]
    //     0x687b78: ldurb           w17, [x0, #-1]
    //     0x687b7c: and             x16, x17, x16, lsr #2
    //     0x687b80: tst             x16, HEAP, lsr #32
    //     0x687b84: b.eq            #0x687b8c
    //     0x687b88: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687b8c: ldur            x1, [fp, #-8]
    // 0x687b90: r2 = 6
    //     0x687b90: movz            x2, #0x6
    // 0x687b94: r0 = _getValueOrData()
    //     0x687b94: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687b98: mov             x1, x0
    // 0x687b9c: ldur            x0, [fp, #-8]
    // 0x687ba0: LoadField: r2 = r0->field_f
    //     0x687ba0: ldur            w2, [x0, #0xf]
    // 0x687ba4: DecompressPointer r2
    //     0x687ba4: add             x2, x2, HEAP, lsl #32
    // 0x687ba8: cmp             w2, w1
    // 0x687bac: b.ne            #0x687bb8
    // 0x687bb0: r3 = Null
    //     0x687bb0: mov             x3, NULL
    // 0x687bb4: b               #0x687bbc
    // 0x687bb8: mov             x3, x1
    // 0x687bbc: stur            x3, [fp, #-0x18]
    // 0x687bc0: cmp             w3, NULL
    // 0x687bc4: b.eq            #0x689938
    // 0x687bc8: mov             x1, x0
    // 0x687bcc: r2 = 6
    //     0x687bcc: movz            x2, #0x6
    // 0x687bd0: r0 = _getValueOrData()
    //     0x687bd0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687bd4: mov             x1, x0
    // 0x687bd8: ldur            x0, [fp, #-8]
    // 0x687bdc: LoadField: r2 = r0->field_f
    //     0x687bdc: ldur            w2, [x0, #0xf]
    // 0x687be0: DecompressPointer r2
    //     0x687be0: add             x2, x2, HEAP, lsl #32
    // 0x687be4: cmp             w2, w1
    // 0x687be8: b.ne            #0x687bf0
    // 0x687bec: r1 = Null
    //     0x687bec: mov             x1, NULL
    // 0x687bf0: ldur            x3, [fp, #-0x18]
    // 0x687bf4: cmp             w1, NULL
    // 0x687bf8: b.eq            #0x68993c
    // 0x687bfc: LoadField: r2 = r1->field_f
    //     0x687bfc: ldur            w2, [x1, #0xf]
    // 0x687c00: DecompressPointer r2
    //     0x687c00: add             x2, x2, HEAP, lsl #32
    // 0x687c04: r1 = Instance_CustomNum
    //     0x687c04: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x687c08: ldr             x1, [x1, #0x448]
    // 0x687c0c: r0 = mult2()
    //     0x687c0c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687c10: ldur            x1, [fp, #-0x18]
    // 0x687c14: StoreField: r1->field_f = r0
    //     0x687c14: stur            w0, [x1, #0xf]
    //     0x687c18: ldurb           w16, [x1, #-1]
    //     0x687c1c: ldurb           w17, [x0, #-1]
    //     0x687c20: and             x16, x17, x16, lsr #2
    //     0x687c24: tst             x16, HEAP, lsr #32
    //     0x687c28: b.eq            #0x687c30
    //     0x687c2c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687c30: ldur            x0, [fp, #-0x10]
    // 0x687c34: r0 = Boost()
    //     0x687c34: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x687c38: mov             x1, x0
    // 0x687c3c: r0 = Instance_CustomNum
    //     0x687c3c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x687c40: ldr             x0, [x0, #0xa70]
    // 0x687c44: StoreField: r1->field_7 = r0
    //     0x687c44: stur            w0, [x1, #7]
    // 0x687c48: StoreField: r1->field_b = r0
    //     0x687c48: stur            w0, [x1, #0xb]
    // 0x687c4c: StoreField: r1->field_f = r0
    //     0x687c4c: stur            w0, [x1, #0xf]
    // 0x687c50: StoreField: r1->field_13 = r0
    //     0x687c50: stur            w0, [x1, #0x13]
    // 0x687c54: mov             x3, x1
    // 0x687c58: ldur            x1, [fp, #-8]
    // 0x687c5c: r2 = 12
    //     0x687c5c: movz            x2, #0xc
    // 0x687c60: r0 = []=()
    //     0x687c60: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x687c64: r0 = Boost()
    //     0x687c64: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x687c68: mov             x1, x0
    // 0x687c6c: r0 = Instance_CustomNum
    //     0x687c6c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x687c70: ldr             x0, [x0, #0xa70]
    // 0x687c74: StoreField: r1->field_7 = r0
    //     0x687c74: stur            w0, [x1, #7]
    // 0x687c78: StoreField: r1->field_b = r0
    //     0x687c78: stur            w0, [x1, #0xb]
    // 0x687c7c: StoreField: r1->field_f = r0
    //     0x687c7c: stur            w0, [x1, #0xf]
    // 0x687c80: StoreField: r1->field_13 = r0
    //     0x687c80: stur            w0, [x1, #0x13]
    // 0x687c84: mov             x3, x1
    // 0x687c88: ldur            x1, [fp, #-8]
    // 0x687c8c: r2 = 14
    //     0x687c8c: movz            x2, #0xe
    // 0x687c90: r0 = []=()
    //     0x687c90: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x687c94: r0 = Boost()
    //     0x687c94: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x687c98: mov             x1, x0
    // 0x687c9c: r0 = Instance_CustomNum
    //     0x687c9c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x687ca0: ldr             x0, [x0, #0xa70]
    // 0x687ca4: StoreField: r1->field_7 = r0
    //     0x687ca4: stur            w0, [x1, #7]
    // 0x687ca8: StoreField: r1->field_b = r0
    //     0x687ca8: stur            w0, [x1, #0xb]
    // 0x687cac: StoreField: r1->field_f = r0
    //     0x687cac: stur            w0, [x1, #0xf]
    // 0x687cb0: StoreField: r1->field_13 = r0
    //     0x687cb0: stur            w0, [x1, #0x13]
    // 0x687cb4: mov             x3, x1
    // 0x687cb8: ldur            x1, [fp, #-8]
    // 0x687cbc: r2 = 16
    //     0x687cbc: movz            x2, #0x10
    // 0x687cc0: r0 = []=()
    //     0x687cc0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x687cc4: r0 = Boost()
    //     0x687cc4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x687cc8: mov             x1, x0
    // 0x687ccc: r0 = Instance_CustomNum
    //     0x687ccc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x687cd0: ldr             x0, [x0, #0xa70]
    // 0x687cd4: StoreField: r1->field_7 = r0
    //     0x687cd4: stur            w0, [x1, #7]
    // 0x687cd8: StoreField: r1->field_b = r0
    //     0x687cd8: stur            w0, [x1, #0xb]
    // 0x687cdc: StoreField: r1->field_f = r0
    //     0x687cdc: stur            w0, [x1, #0xf]
    // 0x687ce0: StoreField: r1->field_13 = r0
    //     0x687ce0: stur            w0, [x1, #0x13]
    // 0x687ce4: mov             x3, x1
    // 0x687ce8: ldur            x1, [fp, #-8]
    // 0x687cec: r2 = 18
    //     0x687cec: movz            x2, #0x12
    // 0x687cf0: r0 = []=()
    //     0x687cf0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x687cf4: r0 = Boost()
    //     0x687cf4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x687cf8: mov             x1, x0
    // 0x687cfc: r0 = Instance_CustomNum
    //     0x687cfc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x687d00: ldr             x0, [x0, #0xa70]
    // 0x687d04: StoreField: r1->field_7 = r0
    //     0x687d04: stur            w0, [x1, #7]
    // 0x687d08: StoreField: r1->field_b = r0
    //     0x687d08: stur            w0, [x1, #0xb]
    // 0x687d0c: StoreField: r1->field_f = r0
    //     0x687d0c: stur            w0, [x1, #0xf]
    // 0x687d10: StoreField: r1->field_13 = r0
    //     0x687d10: stur            w0, [x1, #0x13]
    // 0x687d14: mov             x3, x1
    // 0x687d18: ldur            x1, [fp, #-8]
    // 0x687d1c: r2 = 20
    //     0x687d1c: movz            x2, #0x14
    // 0x687d20: r0 = []=()
    //     0x687d20: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x687d24: ldur            x0, [fp, #-0x10]
    // 0x687d28: LoadField: r1 = r0->field_43
    //     0x687d28: ldur            w1, [x0, #0x43]
    // 0x687d2c: DecompressPointer r1
    //     0x687d2c: add             x1, x1, HEAP, lsl #32
    // 0x687d30: r2 = 234
    //     0x687d30: movz            x2, #0xea
    // 0x687d34: r0 = containsKey()
    //     0x687d34: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x687d38: tbnz            w0, #4, #0x688074
    // 0x687d3c: ldur            x0, [fp, #-8]
    // 0x687d40: mov             x1, x0
    // 0x687d44: r2 = 12
    //     0x687d44: movz            x2, #0xc
    // 0x687d48: r0 = _getValueOrData()
    //     0x687d48: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687d4c: mov             x1, x0
    // 0x687d50: ldur            x0, [fp, #-8]
    // 0x687d54: LoadField: r2 = r0->field_f
    //     0x687d54: ldur            w2, [x0, #0xf]
    // 0x687d58: DecompressPointer r2
    //     0x687d58: add             x2, x2, HEAP, lsl #32
    // 0x687d5c: cmp             w2, w1
    // 0x687d60: b.ne            #0x687d6c
    // 0x687d64: r3 = Null
    //     0x687d64: mov             x3, NULL
    // 0x687d68: b               #0x687d70
    // 0x687d6c: mov             x3, x1
    // 0x687d70: stur            x3, [fp, #-0x18]
    // 0x687d74: cmp             w3, NULL
    // 0x687d78: b.eq            #0x689940
    // 0x687d7c: mov             x1, x0
    // 0x687d80: r2 = 12
    //     0x687d80: movz            x2, #0xc
    // 0x687d84: r0 = _getValueOrData()
    //     0x687d84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687d88: mov             x1, x0
    // 0x687d8c: ldur            x0, [fp, #-8]
    // 0x687d90: LoadField: r2 = r0->field_f
    //     0x687d90: ldur            w2, [x0, #0xf]
    // 0x687d94: DecompressPointer r2
    //     0x687d94: add             x2, x2, HEAP, lsl #32
    // 0x687d98: cmp             w2, w1
    // 0x687d9c: b.ne            #0x687da4
    // 0x687da0: r1 = Null
    //     0x687da0: mov             x1, NULL
    // 0x687da4: ldur            x3, [fp, #-0x18]
    // 0x687da8: cmp             w1, NULL
    // 0x687dac: b.eq            #0x689944
    // 0x687db0: LoadField: r2 = r1->field_7
    //     0x687db0: ldur            w2, [x1, #7]
    // 0x687db4: DecompressPointer r2
    //     0x687db4: add             x2, x2, HEAP, lsl #32
    // 0x687db8: r1 = Instance_CustomNum
    //     0x687db8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x687dbc: ldr             x1, [x1, #0x970]
    // 0x687dc0: r0 = mult2()
    //     0x687dc0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687dc4: ldur            x1, [fp, #-0x18]
    // 0x687dc8: StoreField: r1->field_7 = r0
    //     0x687dc8: stur            w0, [x1, #7]
    //     0x687dcc: ldurb           w16, [x1, #-1]
    //     0x687dd0: ldurb           w17, [x0, #-1]
    //     0x687dd4: and             x16, x17, x16, lsr #2
    //     0x687dd8: tst             x16, HEAP, lsr #32
    //     0x687ddc: b.eq            #0x687de4
    //     0x687de0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687de4: ldur            x1, [fp, #-8]
    // 0x687de8: r2 = 14
    //     0x687de8: movz            x2, #0xe
    // 0x687dec: r0 = _getValueOrData()
    //     0x687dec: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687df0: mov             x1, x0
    // 0x687df4: ldur            x0, [fp, #-8]
    // 0x687df8: LoadField: r2 = r0->field_f
    //     0x687df8: ldur            w2, [x0, #0xf]
    // 0x687dfc: DecompressPointer r2
    //     0x687dfc: add             x2, x2, HEAP, lsl #32
    // 0x687e00: cmp             w2, w1
    // 0x687e04: b.ne            #0x687e10
    // 0x687e08: r3 = Null
    //     0x687e08: mov             x3, NULL
    // 0x687e0c: b               #0x687e14
    // 0x687e10: mov             x3, x1
    // 0x687e14: stur            x3, [fp, #-0x18]
    // 0x687e18: cmp             w3, NULL
    // 0x687e1c: b.eq            #0x689948
    // 0x687e20: mov             x1, x0
    // 0x687e24: r2 = 14
    //     0x687e24: movz            x2, #0xe
    // 0x687e28: r0 = _getValueOrData()
    //     0x687e28: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687e2c: mov             x1, x0
    // 0x687e30: ldur            x0, [fp, #-8]
    // 0x687e34: LoadField: r2 = r0->field_f
    //     0x687e34: ldur            w2, [x0, #0xf]
    // 0x687e38: DecompressPointer r2
    //     0x687e38: add             x2, x2, HEAP, lsl #32
    // 0x687e3c: cmp             w2, w1
    // 0x687e40: b.ne            #0x687e48
    // 0x687e44: r1 = Null
    //     0x687e44: mov             x1, NULL
    // 0x687e48: ldur            x3, [fp, #-0x18]
    // 0x687e4c: cmp             w1, NULL
    // 0x687e50: b.eq            #0x68994c
    // 0x687e54: LoadField: r2 = r1->field_7
    //     0x687e54: ldur            w2, [x1, #7]
    // 0x687e58: DecompressPointer r2
    //     0x687e58: add             x2, x2, HEAP, lsl #32
    // 0x687e5c: r1 = Instance_CustomNum
    //     0x687e5c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x687e60: ldr             x1, [x1, #0x970]
    // 0x687e64: r0 = mult2()
    //     0x687e64: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687e68: ldur            x1, [fp, #-0x18]
    // 0x687e6c: StoreField: r1->field_7 = r0
    //     0x687e6c: stur            w0, [x1, #7]
    //     0x687e70: ldurb           w16, [x1, #-1]
    //     0x687e74: ldurb           w17, [x0, #-1]
    //     0x687e78: and             x16, x17, x16, lsr #2
    //     0x687e7c: tst             x16, HEAP, lsr #32
    //     0x687e80: b.eq            #0x687e88
    //     0x687e84: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687e88: ldur            x1, [fp, #-8]
    // 0x687e8c: r2 = 16
    //     0x687e8c: movz            x2, #0x10
    // 0x687e90: r0 = _getValueOrData()
    //     0x687e90: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687e94: mov             x1, x0
    // 0x687e98: ldur            x0, [fp, #-8]
    // 0x687e9c: LoadField: r2 = r0->field_f
    //     0x687e9c: ldur            w2, [x0, #0xf]
    // 0x687ea0: DecompressPointer r2
    //     0x687ea0: add             x2, x2, HEAP, lsl #32
    // 0x687ea4: cmp             w2, w1
    // 0x687ea8: b.ne            #0x687eb4
    // 0x687eac: r3 = Null
    //     0x687eac: mov             x3, NULL
    // 0x687eb0: b               #0x687eb8
    // 0x687eb4: mov             x3, x1
    // 0x687eb8: stur            x3, [fp, #-0x18]
    // 0x687ebc: cmp             w3, NULL
    // 0x687ec0: b.eq            #0x689950
    // 0x687ec4: mov             x1, x0
    // 0x687ec8: r2 = 16
    //     0x687ec8: movz            x2, #0x10
    // 0x687ecc: r0 = _getValueOrData()
    //     0x687ecc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687ed0: mov             x1, x0
    // 0x687ed4: ldur            x0, [fp, #-8]
    // 0x687ed8: LoadField: r2 = r0->field_f
    //     0x687ed8: ldur            w2, [x0, #0xf]
    // 0x687edc: DecompressPointer r2
    //     0x687edc: add             x2, x2, HEAP, lsl #32
    // 0x687ee0: cmp             w2, w1
    // 0x687ee4: b.ne            #0x687eec
    // 0x687ee8: r1 = Null
    //     0x687ee8: mov             x1, NULL
    // 0x687eec: ldur            x3, [fp, #-0x18]
    // 0x687ef0: cmp             w1, NULL
    // 0x687ef4: b.eq            #0x689954
    // 0x687ef8: LoadField: r2 = r1->field_7
    //     0x687ef8: ldur            w2, [x1, #7]
    // 0x687efc: DecompressPointer r2
    //     0x687efc: add             x2, x2, HEAP, lsl #32
    // 0x687f00: r1 = Instance_CustomNum
    //     0x687f00: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x687f04: ldr             x1, [x1, #0x970]
    // 0x687f08: r0 = mult2()
    //     0x687f08: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687f0c: ldur            x1, [fp, #-0x18]
    // 0x687f10: StoreField: r1->field_7 = r0
    //     0x687f10: stur            w0, [x1, #7]
    //     0x687f14: ldurb           w16, [x1, #-1]
    //     0x687f18: ldurb           w17, [x0, #-1]
    //     0x687f1c: and             x16, x17, x16, lsr #2
    //     0x687f20: tst             x16, HEAP, lsr #32
    //     0x687f24: b.eq            #0x687f2c
    //     0x687f28: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687f2c: ldur            x1, [fp, #-8]
    // 0x687f30: r2 = 18
    //     0x687f30: movz            x2, #0x12
    // 0x687f34: r0 = _getValueOrData()
    //     0x687f34: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687f38: mov             x1, x0
    // 0x687f3c: ldur            x0, [fp, #-8]
    // 0x687f40: LoadField: r2 = r0->field_f
    //     0x687f40: ldur            w2, [x0, #0xf]
    // 0x687f44: DecompressPointer r2
    //     0x687f44: add             x2, x2, HEAP, lsl #32
    // 0x687f48: cmp             w2, w1
    // 0x687f4c: b.ne            #0x687f58
    // 0x687f50: r3 = Null
    //     0x687f50: mov             x3, NULL
    // 0x687f54: b               #0x687f5c
    // 0x687f58: mov             x3, x1
    // 0x687f5c: stur            x3, [fp, #-0x18]
    // 0x687f60: cmp             w3, NULL
    // 0x687f64: b.eq            #0x689958
    // 0x687f68: mov             x1, x0
    // 0x687f6c: r2 = 18
    //     0x687f6c: movz            x2, #0x12
    // 0x687f70: r0 = _getValueOrData()
    //     0x687f70: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687f74: mov             x1, x0
    // 0x687f78: ldur            x0, [fp, #-8]
    // 0x687f7c: LoadField: r2 = r0->field_f
    //     0x687f7c: ldur            w2, [x0, #0xf]
    // 0x687f80: DecompressPointer r2
    //     0x687f80: add             x2, x2, HEAP, lsl #32
    // 0x687f84: cmp             w2, w1
    // 0x687f88: b.ne            #0x687f90
    // 0x687f8c: r1 = Null
    //     0x687f8c: mov             x1, NULL
    // 0x687f90: ldur            x3, [fp, #-0x18]
    // 0x687f94: cmp             w1, NULL
    // 0x687f98: b.eq            #0x68995c
    // 0x687f9c: LoadField: r2 = r1->field_7
    //     0x687f9c: ldur            w2, [x1, #7]
    // 0x687fa0: DecompressPointer r2
    //     0x687fa0: add             x2, x2, HEAP, lsl #32
    // 0x687fa4: r1 = Instance_CustomNum
    //     0x687fa4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x687fa8: ldr             x1, [x1, #0x970]
    // 0x687fac: r0 = mult2()
    //     0x687fac: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x687fb0: ldur            x1, [fp, #-0x18]
    // 0x687fb4: StoreField: r1->field_7 = r0
    //     0x687fb4: stur            w0, [x1, #7]
    //     0x687fb8: ldurb           w16, [x1, #-1]
    //     0x687fbc: ldurb           w17, [x0, #-1]
    //     0x687fc0: and             x16, x17, x16, lsr #2
    //     0x687fc4: tst             x16, HEAP, lsr #32
    //     0x687fc8: b.eq            #0x687fd0
    //     0x687fcc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x687fd0: ldur            x1, [fp, #-8]
    // 0x687fd4: r2 = 20
    //     0x687fd4: movz            x2, #0x14
    // 0x687fd8: r0 = _getValueOrData()
    //     0x687fd8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x687fdc: mov             x1, x0
    // 0x687fe0: ldur            x0, [fp, #-8]
    // 0x687fe4: LoadField: r2 = r0->field_f
    //     0x687fe4: ldur            w2, [x0, #0xf]
    // 0x687fe8: DecompressPointer r2
    //     0x687fe8: add             x2, x2, HEAP, lsl #32
    // 0x687fec: cmp             w2, w1
    // 0x687ff0: b.ne            #0x687ffc
    // 0x687ff4: r3 = Null
    //     0x687ff4: mov             x3, NULL
    // 0x687ff8: b               #0x688000
    // 0x687ffc: mov             x3, x1
    // 0x688000: stur            x3, [fp, #-0x18]
    // 0x688004: cmp             w3, NULL
    // 0x688008: b.eq            #0x689960
    // 0x68800c: mov             x1, x0
    // 0x688010: r2 = 20
    //     0x688010: movz            x2, #0x14
    // 0x688014: r0 = _getValueOrData()
    //     0x688014: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688018: mov             x1, x0
    // 0x68801c: ldur            x0, [fp, #-8]
    // 0x688020: LoadField: r2 = r0->field_f
    //     0x688020: ldur            w2, [x0, #0xf]
    // 0x688024: DecompressPointer r2
    //     0x688024: add             x2, x2, HEAP, lsl #32
    // 0x688028: cmp             w2, w1
    // 0x68802c: b.ne            #0x688034
    // 0x688030: r1 = Null
    //     0x688030: mov             x1, NULL
    // 0x688034: ldur            x3, [fp, #-0x18]
    // 0x688038: cmp             w1, NULL
    // 0x68803c: b.eq            #0x689964
    // 0x688040: LoadField: r2 = r1->field_7
    //     0x688040: ldur            w2, [x1, #7]
    // 0x688044: DecompressPointer r2
    //     0x688044: add             x2, x2, HEAP, lsl #32
    // 0x688048: r1 = Instance_CustomNum
    //     0x688048: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x68804c: ldr             x1, [x1, #0x970]
    // 0x688050: r0 = mult2()
    //     0x688050: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688054: ldur            x1, [fp, #-0x18]
    // 0x688058: StoreField: r1->field_7 = r0
    //     0x688058: stur            w0, [x1, #7]
    //     0x68805c: ldurb           w16, [x1, #-1]
    //     0x688060: ldurb           w17, [x0, #-1]
    //     0x688064: and             x16, x17, x16, lsr #2
    //     0x688068: tst             x16, HEAP, lsr #32
    //     0x68806c: b.eq            #0x688074
    //     0x688070: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688074: ldur            x0, [fp, #-0x10]
    // 0x688078: LoadField: r1 = r0->field_43
    //     0x688078: ldur            w1, [x0, #0x43]
    // 0x68807c: DecompressPointer r1
    //     0x68807c: add             x1, x1, HEAP, lsl #32
    // 0x688080: r2 = 238
    //     0x688080: movz            x2, #0xee
    // 0x688084: r0 = containsKey()
    //     0x688084: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x688088: tbnz            w0, #4, #0x688288
    // 0x68808c: ldur            x0, [fp, #-8]
    // 0x688090: mov             x1, x0
    // 0x688094: r2 = 4
    //     0x688094: movz            x2, #0x4
    // 0x688098: r0 = _getValueOrData()
    //     0x688098: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68809c: mov             x1, x0
    // 0x6880a0: ldur            x0, [fp, #-8]
    // 0x6880a4: LoadField: r2 = r0->field_f
    //     0x6880a4: ldur            w2, [x0, #0xf]
    // 0x6880a8: DecompressPointer r2
    //     0x6880a8: add             x2, x2, HEAP, lsl #32
    // 0x6880ac: cmp             w2, w1
    // 0x6880b0: b.ne            #0x6880bc
    // 0x6880b4: r3 = Null
    //     0x6880b4: mov             x3, NULL
    // 0x6880b8: b               #0x6880c0
    // 0x6880bc: mov             x3, x1
    // 0x6880c0: stur            x3, [fp, #-0x18]
    // 0x6880c4: cmp             w3, NULL
    // 0x6880c8: b.eq            #0x689968
    // 0x6880cc: mov             x1, x0
    // 0x6880d0: r2 = 4
    //     0x6880d0: movz            x2, #0x4
    // 0x6880d4: r0 = _getValueOrData()
    //     0x6880d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6880d8: mov             x1, x0
    // 0x6880dc: ldur            x0, [fp, #-8]
    // 0x6880e0: LoadField: r2 = r0->field_f
    //     0x6880e0: ldur            w2, [x0, #0xf]
    // 0x6880e4: DecompressPointer r2
    //     0x6880e4: add             x2, x2, HEAP, lsl #32
    // 0x6880e8: cmp             w2, w1
    // 0x6880ec: b.ne            #0x6880f4
    // 0x6880f0: r1 = Null
    //     0x6880f0: mov             x1, NULL
    // 0x6880f4: ldur            x3, [fp, #-0x18]
    // 0x6880f8: cmp             w1, NULL
    // 0x6880fc: b.eq            #0x68996c
    // 0x688100: LoadField: r2 = r1->field_f
    //     0x688100: ldur            w2, [x1, #0xf]
    // 0x688104: DecompressPointer r2
    //     0x688104: add             x2, x2, HEAP, lsl #32
    // 0x688108: r1 = Instance_CustomNum
    //     0x688108: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x68810c: ldr             x1, [x1, #0x448]
    // 0x688110: r0 = mult2()
    //     0x688110: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688114: ldur            x1, [fp, #-0x18]
    // 0x688118: StoreField: r1->field_f = r0
    //     0x688118: stur            w0, [x1, #0xf]
    //     0x68811c: ldurb           w16, [x1, #-1]
    //     0x688120: ldurb           w17, [x0, #-1]
    //     0x688124: and             x16, x17, x16, lsr #2
    //     0x688128: tst             x16, HEAP, lsr #32
    //     0x68812c: b.eq            #0x688134
    //     0x688130: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688134: ldur            x1, [fp, #-8]
    // 0x688138: r2 = 6
    //     0x688138: movz            x2, #0x6
    // 0x68813c: r0 = _getValueOrData()
    //     0x68813c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688140: mov             x1, x0
    // 0x688144: ldur            x0, [fp, #-8]
    // 0x688148: LoadField: r2 = r0->field_f
    //     0x688148: ldur            w2, [x0, #0xf]
    // 0x68814c: DecompressPointer r2
    //     0x68814c: add             x2, x2, HEAP, lsl #32
    // 0x688150: cmp             w2, w1
    // 0x688154: b.ne            #0x688160
    // 0x688158: r3 = Null
    //     0x688158: mov             x3, NULL
    // 0x68815c: b               #0x688164
    // 0x688160: mov             x3, x1
    // 0x688164: stur            x3, [fp, #-0x18]
    // 0x688168: cmp             w3, NULL
    // 0x68816c: b.eq            #0x689970
    // 0x688170: mov             x1, x0
    // 0x688174: r2 = 6
    //     0x688174: movz            x2, #0x6
    // 0x688178: r0 = _getValueOrData()
    //     0x688178: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68817c: mov             x1, x0
    // 0x688180: ldur            x0, [fp, #-8]
    // 0x688184: LoadField: r2 = r0->field_f
    //     0x688184: ldur            w2, [x0, #0xf]
    // 0x688188: DecompressPointer r2
    //     0x688188: add             x2, x2, HEAP, lsl #32
    // 0x68818c: cmp             w2, w1
    // 0x688190: b.ne            #0x688198
    // 0x688194: r1 = Null
    //     0x688194: mov             x1, NULL
    // 0x688198: ldur            x3, [fp, #-0x18]
    // 0x68819c: cmp             w1, NULL
    // 0x6881a0: b.eq            #0x689974
    // 0x6881a4: LoadField: r2 = r1->field_f
    //     0x6881a4: ldur            w2, [x1, #0xf]
    // 0x6881a8: DecompressPointer r2
    //     0x6881a8: add             x2, x2, HEAP, lsl #32
    // 0x6881ac: r1 = Instance_CustomNum
    //     0x6881ac: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x6881b0: ldr             x1, [x1, #0x448]
    // 0x6881b4: r0 = mult2()
    //     0x6881b4: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6881b8: ldur            x1, [fp, #-0x18]
    // 0x6881bc: StoreField: r1->field_f = r0
    //     0x6881bc: stur            w0, [x1, #0xf]
    //     0x6881c0: ldurb           w16, [x1, #-1]
    //     0x6881c4: ldurb           w17, [x0, #-1]
    //     0x6881c8: and             x16, x17, x16, lsr #2
    //     0x6881cc: tst             x16, HEAP, lsr #32
    //     0x6881d0: b.eq            #0x6881d8
    //     0x6881d4: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6881d8: ldur            x1, [fp, #-8]
    // 0x6881dc: r2 = 8
    //     0x6881dc: movz            x2, #0x8
    // 0x6881e0: r0 = _getValueOrData()
    //     0x6881e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6881e4: mov             x1, x0
    // 0x6881e8: ldur            x0, [fp, #-8]
    // 0x6881ec: LoadField: r2 = r0->field_f
    //     0x6881ec: ldur            w2, [x0, #0xf]
    // 0x6881f0: DecompressPointer r2
    //     0x6881f0: add             x2, x2, HEAP, lsl #32
    // 0x6881f4: cmp             w2, w1
    // 0x6881f8: b.ne            #0x688204
    // 0x6881fc: r3 = Null
    //     0x6881fc: mov             x3, NULL
    // 0x688200: b               #0x688208
    // 0x688204: mov             x3, x1
    // 0x688208: stur            x3, [fp, #-0x18]
    // 0x68820c: cmp             w3, NULL
    // 0x688210: b.eq            #0x689978
    // 0x688214: r1 = Null
    //     0x688214: mov             x1, NULL
    // 0x688218: r2 = 2000
    //     0x688218: movz            x2, #0x7d0
    // 0x68821c: r0 = CustomNum()
    //     0x68821c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x688220: ldur            x1, [fp, #-8]
    // 0x688224: r2 = 8
    //     0x688224: movz            x2, #0x8
    // 0x688228: stur            x0, [fp, #-0x20]
    // 0x68822c: r0 = _getValueOrData()
    //     0x68822c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688230: mov             x1, x0
    // 0x688234: ldur            x0, [fp, #-8]
    // 0x688238: LoadField: r2 = r0->field_f
    //     0x688238: ldur            w2, [x0, #0xf]
    // 0x68823c: DecompressPointer r2
    //     0x68823c: add             x2, x2, HEAP, lsl #32
    // 0x688240: cmp             w2, w1
    // 0x688244: b.ne            #0x68824c
    // 0x688248: r1 = Null
    //     0x688248: mov             x1, NULL
    // 0x68824c: ldur            x3, [fp, #-0x18]
    // 0x688250: cmp             w1, NULL
    // 0x688254: b.eq            #0x68997c
    // 0x688258: LoadField: r2 = r1->field_f
    //     0x688258: ldur            w2, [x1, #0xf]
    // 0x68825c: DecompressPointer r2
    //     0x68825c: add             x2, x2, HEAP, lsl #32
    // 0x688260: ldur            x1, [fp, #-0x20]
    // 0x688264: r0 = mult2()
    //     0x688264: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688268: ldur            x1, [fp, #-0x18]
    // 0x68826c: StoreField: r1->field_f = r0
    //     0x68826c: stur            w0, [x1, #0xf]
    //     0x688270: ldurb           w16, [x1, #-1]
    //     0x688274: ldurb           w17, [x0, #-1]
    //     0x688278: and             x16, x17, x16, lsr #2
    //     0x68827c: tst             x16, HEAP, lsr #32
    //     0x688280: b.eq            #0x688288
    //     0x688284: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688288: ldur            x0, [fp, #-0x10]
    // 0x68828c: LoadField: r1 = r0->field_43
    //     0x68828c: ldur            w1, [x0, #0x43]
    // 0x688290: DecompressPointer r1
    //     0x688290: add             x1, x1, HEAP, lsl #32
    // 0x688294: r2 = 406
    //     0x688294: movz            x2, #0x196
    // 0x688298: r0 = containsKey()
    //     0x688298: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x68829c: tbnz            w0, #4, #0x6883f8
    // 0x6882a0: ldur            x0, [fp, #-8]
    // 0x6882a4: mov             x1, x0
    // 0x6882a8: r2 = 6
    //     0x6882a8: movz            x2, #0x6
    // 0x6882ac: r0 = _getValueOrData()
    //     0x6882ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6882b0: mov             x1, x0
    // 0x6882b4: ldur            x0, [fp, #-8]
    // 0x6882b8: LoadField: r2 = r0->field_f
    //     0x6882b8: ldur            w2, [x0, #0xf]
    // 0x6882bc: DecompressPointer r2
    //     0x6882bc: add             x2, x2, HEAP, lsl #32
    // 0x6882c0: cmp             w2, w1
    // 0x6882c4: b.ne            #0x6882d0
    // 0x6882c8: r3 = Null
    //     0x6882c8: mov             x3, NULL
    // 0x6882cc: b               #0x6882d4
    // 0x6882d0: mov             x3, x1
    // 0x6882d4: stur            x3, [fp, #-0x18]
    // 0x6882d8: cmp             w3, NULL
    // 0x6882dc: b.eq            #0x689980
    // 0x6882e0: r1 = Null
    //     0x6882e0: mov             x1, NULL
    // 0x6882e4: r2 = 40
    //     0x6882e4: movz            x2, #0x28
    // 0x6882e8: r0 = CustomNum()
    //     0x6882e8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6882ec: ldur            x1, [fp, #-8]
    // 0x6882f0: r2 = 6
    //     0x6882f0: movz            x2, #0x6
    // 0x6882f4: stur            x0, [fp, #-0x20]
    // 0x6882f8: r0 = _getValueOrData()
    //     0x6882f8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6882fc: mov             x1, x0
    // 0x688300: ldur            x0, [fp, #-8]
    // 0x688304: LoadField: r2 = r0->field_f
    //     0x688304: ldur            w2, [x0, #0xf]
    // 0x688308: DecompressPointer r2
    //     0x688308: add             x2, x2, HEAP, lsl #32
    // 0x68830c: cmp             w2, w1
    // 0x688310: b.ne            #0x688318
    // 0x688314: r1 = Null
    //     0x688314: mov             x1, NULL
    // 0x688318: ldur            x3, [fp, #-0x18]
    // 0x68831c: cmp             w1, NULL
    // 0x688320: b.eq            #0x689984
    // 0x688324: LoadField: r2 = r1->field_f
    //     0x688324: ldur            w2, [x1, #0xf]
    // 0x688328: DecompressPointer r2
    //     0x688328: add             x2, x2, HEAP, lsl #32
    // 0x68832c: ldur            x1, [fp, #-0x20]
    // 0x688330: r0 = mult2()
    //     0x688330: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688334: ldur            x1, [fp, #-0x18]
    // 0x688338: StoreField: r1->field_f = r0
    //     0x688338: stur            w0, [x1, #0xf]
    //     0x68833c: ldurb           w16, [x1, #-1]
    //     0x688340: ldurb           w17, [x0, #-1]
    //     0x688344: and             x16, x17, x16, lsr #2
    //     0x688348: tst             x16, HEAP, lsr #32
    //     0x68834c: b.eq            #0x688354
    //     0x688350: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688354: ldur            x1, [fp, #-8]
    // 0x688358: r2 = 10
    //     0x688358: movz            x2, #0xa
    // 0x68835c: r0 = _getValueOrData()
    //     0x68835c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688360: mov             x1, x0
    // 0x688364: ldur            x0, [fp, #-8]
    // 0x688368: LoadField: r2 = r0->field_f
    //     0x688368: ldur            w2, [x0, #0xf]
    // 0x68836c: DecompressPointer r2
    //     0x68836c: add             x2, x2, HEAP, lsl #32
    // 0x688370: cmp             w2, w1
    // 0x688374: b.ne            #0x688380
    // 0x688378: r3 = Null
    //     0x688378: mov             x3, NULL
    // 0x68837c: b               #0x688384
    // 0x688380: mov             x3, x1
    // 0x688384: stur            x3, [fp, #-0x18]
    // 0x688388: cmp             w3, NULL
    // 0x68838c: b.eq            #0x689988
    // 0x688390: mov             x1, x0
    // 0x688394: r2 = 10
    //     0x688394: movz            x2, #0xa
    // 0x688398: r0 = _getValueOrData()
    //     0x688398: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68839c: mov             x1, x0
    // 0x6883a0: ldur            x0, [fp, #-8]
    // 0x6883a4: LoadField: r2 = r0->field_f
    //     0x6883a4: ldur            w2, [x0, #0xf]
    // 0x6883a8: DecompressPointer r2
    //     0x6883a8: add             x2, x2, HEAP, lsl #32
    // 0x6883ac: cmp             w2, w1
    // 0x6883b0: b.ne            #0x6883b8
    // 0x6883b4: r1 = Null
    //     0x6883b4: mov             x1, NULL
    // 0x6883b8: ldur            x3, [fp, #-0x18]
    // 0x6883bc: cmp             w1, NULL
    // 0x6883c0: b.eq            #0x68998c
    // 0x6883c4: LoadField: r2 = r1->field_f
    //     0x6883c4: ldur            w2, [x1, #0xf]
    // 0x6883c8: DecompressPointer r2
    //     0x6883c8: add             x2, x2, HEAP, lsl #32
    // 0x6883cc: r1 = Instance_CustomNum
    //     0x6883cc: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x6883d0: ldr             x1, [x1, #0x448]
    // 0x6883d4: r0 = mult2()
    //     0x6883d4: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6883d8: ldur            x1, [fp, #-0x18]
    // 0x6883dc: StoreField: r1->field_f = r0
    //     0x6883dc: stur            w0, [x1, #0xf]
    //     0x6883e0: ldurb           w16, [x1, #-1]
    //     0x6883e4: ldurb           w17, [x0, #-1]
    //     0x6883e8: and             x16, x17, x16, lsr #2
    //     0x6883ec: tst             x16, HEAP, lsr #32
    //     0x6883f0: b.eq            #0x6883f8
    //     0x6883f4: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6883f8: ldur            x0, [fp, #-0x10]
    // 0x6883fc: LoadField: r1 = r0->field_43
    //     0x6883fc: ldur            w1, [x0, #0x43]
    // 0x688400: DecompressPointer r1
    //     0x688400: add             x1, x1, HEAP, lsl #32
    // 0x688404: r2 = 240
    //     0x688404: movz            x2, #0xf0
    // 0x688408: r0 = containsKey()
    //     0x688408: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x68840c: tbnz            w0, #4, #0x688748
    // 0x688410: ldur            x0, [fp, #-8]
    // 0x688414: mov             x1, x0
    // 0x688418: r2 = 12
    //     0x688418: movz            x2, #0xc
    // 0x68841c: r0 = _getValueOrData()
    //     0x68841c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688420: mov             x1, x0
    // 0x688424: ldur            x0, [fp, #-8]
    // 0x688428: LoadField: r2 = r0->field_f
    //     0x688428: ldur            w2, [x0, #0xf]
    // 0x68842c: DecompressPointer r2
    //     0x68842c: add             x2, x2, HEAP, lsl #32
    // 0x688430: cmp             w2, w1
    // 0x688434: b.ne            #0x688440
    // 0x688438: r3 = Null
    //     0x688438: mov             x3, NULL
    // 0x68843c: b               #0x688444
    // 0x688440: mov             x3, x1
    // 0x688444: stur            x3, [fp, #-0x18]
    // 0x688448: cmp             w3, NULL
    // 0x68844c: b.eq            #0x689990
    // 0x688450: mov             x1, x0
    // 0x688454: r2 = 12
    //     0x688454: movz            x2, #0xc
    // 0x688458: r0 = _getValueOrData()
    //     0x688458: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68845c: mov             x1, x0
    // 0x688460: ldur            x0, [fp, #-8]
    // 0x688464: LoadField: r2 = r0->field_f
    //     0x688464: ldur            w2, [x0, #0xf]
    // 0x688468: DecompressPointer r2
    //     0x688468: add             x2, x2, HEAP, lsl #32
    // 0x68846c: cmp             w2, w1
    // 0x688470: b.ne            #0x688478
    // 0x688474: r1 = Null
    //     0x688474: mov             x1, NULL
    // 0x688478: ldur            x3, [fp, #-0x18]
    // 0x68847c: cmp             w1, NULL
    // 0x688480: b.eq            #0x689994
    // 0x688484: LoadField: r2 = r1->field_b
    //     0x688484: ldur            w2, [x1, #0xb]
    // 0x688488: DecompressPointer r2
    //     0x688488: add             x2, x2, HEAP, lsl #32
    // 0x68848c: r1 = Instance_CustomNum
    //     0x68848c: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x688490: ldr             x1, [x1, #0x6f0]
    // 0x688494: r0 = mult2()
    //     0x688494: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688498: ldur            x1, [fp, #-0x18]
    // 0x68849c: StoreField: r1->field_b = r0
    //     0x68849c: stur            w0, [x1, #0xb]
    //     0x6884a0: ldurb           w16, [x1, #-1]
    //     0x6884a4: ldurb           w17, [x0, #-1]
    //     0x6884a8: and             x16, x17, x16, lsr #2
    //     0x6884ac: tst             x16, HEAP, lsr #32
    //     0x6884b0: b.eq            #0x6884b8
    //     0x6884b4: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6884b8: ldur            x1, [fp, #-8]
    // 0x6884bc: r2 = 14
    //     0x6884bc: movz            x2, #0xe
    // 0x6884c0: r0 = _getValueOrData()
    //     0x6884c0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6884c4: mov             x1, x0
    // 0x6884c8: ldur            x0, [fp, #-8]
    // 0x6884cc: LoadField: r2 = r0->field_f
    //     0x6884cc: ldur            w2, [x0, #0xf]
    // 0x6884d0: DecompressPointer r2
    //     0x6884d0: add             x2, x2, HEAP, lsl #32
    // 0x6884d4: cmp             w2, w1
    // 0x6884d8: b.ne            #0x6884e4
    // 0x6884dc: r3 = Null
    //     0x6884dc: mov             x3, NULL
    // 0x6884e0: b               #0x6884e8
    // 0x6884e4: mov             x3, x1
    // 0x6884e8: stur            x3, [fp, #-0x18]
    // 0x6884ec: cmp             w3, NULL
    // 0x6884f0: b.eq            #0x689998
    // 0x6884f4: mov             x1, x0
    // 0x6884f8: r2 = 14
    //     0x6884f8: movz            x2, #0xe
    // 0x6884fc: r0 = _getValueOrData()
    //     0x6884fc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688500: mov             x1, x0
    // 0x688504: ldur            x0, [fp, #-8]
    // 0x688508: LoadField: r2 = r0->field_f
    //     0x688508: ldur            w2, [x0, #0xf]
    // 0x68850c: DecompressPointer r2
    //     0x68850c: add             x2, x2, HEAP, lsl #32
    // 0x688510: cmp             w2, w1
    // 0x688514: b.ne            #0x68851c
    // 0x688518: r1 = Null
    //     0x688518: mov             x1, NULL
    // 0x68851c: ldur            x3, [fp, #-0x18]
    // 0x688520: cmp             w1, NULL
    // 0x688524: b.eq            #0x68999c
    // 0x688528: LoadField: r2 = r1->field_b
    //     0x688528: ldur            w2, [x1, #0xb]
    // 0x68852c: DecompressPointer r2
    //     0x68852c: add             x2, x2, HEAP, lsl #32
    // 0x688530: r1 = Instance_CustomNum
    //     0x688530: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x688534: ldr             x1, [x1, #0x6f0]
    // 0x688538: r0 = mult2()
    //     0x688538: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68853c: ldur            x1, [fp, #-0x18]
    // 0x688540: StoreField: r1->field_b = r0
    //     0x688540: stur            w0, [x1, #0xb]
    //     0x688544: ldurb           w16, [x1, #-1]
    //     0x688548: ldurb           w17, [x0, #-1]
    //     0x68854c: and             x16, x17, x16, lsr #2
    //     0x688550: tst             x16, HEAP, lsr #32
    //     0x688554: b.eq            #0x68855c
    //     0x688558: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68855c: ldur            x1, [fp, #-8]
    // 0x688560: r2 = 16
    //     0x688560: movz            x2, #0x10
    // 0x688564: r0 = _getValueOrData()
    //     0x688564: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688568: mov             x1, x0
    // 0x68856c: ldur            x0, [fp, #-8]
    // 0x688570: LoadField: r2 = r0->field_f
    //     0x688570: ldur            w2, [x0, #0xf]
    // 0x688574: DecompressPointer r2
    //     0x688574: add             x2, x2, HEAP, lsl #32
    // 0x688578: cmp             w2, w1
    // 0x68857c: b.ne            #0x688588
    // 0x688580: r3 = Null
    //     0x688580: mov             x3, NULL
    // 0x688584: b               #0x68858c
    // 0x688588: mov             x3, x1
    // 0x68858c: stur            x3, [fp, #-0x18]
    // 0x688590: cmp             w3, NULL
    // 0x688594: b.eq            #0x6899a0
    // 0x688598: mov             x1, x0
    // 0x68859c: r2 = 16
    //     0x68859c: movz            x2, #0x10
    // 0x6885a0: r0 = _getValueOrData()
    //     0x6885a0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6885a4: mov             x1, x0
    // 0x6885a8: ldur            x0, [fp, #-8]
    // 0x6885ac: LoadField: r2 = r0->field_f
    //     0x6885ac: ldur            w2, [x0, #0xf]
    // 0x6885b0: DecompressPointer r2
    //     0x6885b0: add             x2, x2, HEAP, lsl #32
    // 0x6885b4: cmp             w2, w1
    // 0x6885b8: b.ne            #0x6885c0
    // 0x6885bc: r1 = Null
    //     0x6885bc: mov             x1, NULL
    // 0x6885c0: ldur            x3, [fp, #-0x18]
    // 0x6885c4: cmp             w1, NULL
    // 0x6885c8: b.eq            #0x6899a4
    // 0x6885cc: LoadField: r2 = r1->field_b
    //     0x6885cc: ldur            w2, [x1, #0xb]
    // 0x6885d0: DecompressPointer r2
    //     0x6885d0: add             x2, x2, HEAP, lsl #32
    // 0x6885d4: r1 = Instance_CustomNum
    //     0x6885d4: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x6885d8: ldr             x1, [x1, #0x6f0]
    // 0x6885dc: r0 = mult2()
    //     0x6885dc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6885e0: ldur            x1, [fp, #-0x18]
    // 0x6885e4: StoreField: r1->field_b = r0
    //     0x6885e4: stur            w0, [x1, #0xb]
    //     0x6885e8: ldurb           w16, [x1, #-1]
    //     0x6885ec: ldurb           w17, [x0, #-1]
    //     0x6885f0: and             x16, x17, x16, lsr #2
    //     0x6885f4: tst             x16, HEAP, lsr #32
    //     0x6885f8: b.eq            #0x688600
    //     0x6885fc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688600: ldur            x1, [fp, #-8]
    // 0x688604: r2 = 18
    //     0x688604: movz            x2, #0x12
    // 0x688608: r0 = _getValueOrData()
    //     0x688608: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68860c: mov             x1, x0
    // 0x688610: ldur            x0, [fp, #-8]
    // 0x688614: LoadField: r2 = r0->field_f
    //     0x688614: ldur            w2, [x0, #0xf]
    // 0x688618: DecompressPointer r2
    //     0x688618: add             x2, x2, HEAP, lsl #32
    // 0x68861c: cmp             w2, w1
    // 0x688620: b.ne            #0x68862c
    // 0x688624: r3 = Null
    //     0x688624: mov             x3, NULL
    // 0x688628: b               #0x688630
    // 0x68862c: mov             x3, x1
    // 0x688630: stur            x3, [fp, #-0x18]
    // 0x688634: cmp             w3, NULL
    // 0x688638: b.eq            #0x6899a8
    // 0x68863c: mov             x1, x0
    // 0x688640: r2 = 18
    //     0x688640: movz            x2, #0x12
    // 0x688644: r0 = _getValueOrData()
    //     0x688644: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688648: mov             x1, x0
    // 0x68864c: ldur            x0, [fp, #-8]
    // 0x688650: LoadField: r2 = r0->field_f
    //     0x688650: ldur            w2, [x0, #0xf]
    // 0x688654: DecompressPointer r2
    //     0x688654: add             x2, x2, HEAP, lsl #32
    // 0x688658: cmp             w2, w1
    // 0x68865c: b.ne            #0x688664
    // 0x688660: r1 = Null
    //     0x688660: mov             x1, NULL
    // 0x688664: ldur            x3, [fp, #-0x18]
    // 0x688668: cmp             w1, NULL
    // 0x68866c: b.eq            #0x6899ac
    // 0x688670: LoadField: r2 = r1->field_b
    //     0x688670: ldur            w2, [x1, #0xb]
    // 0x688674: DecompressPointer r2
    //     0x688674: add             x2, x2, HEAP, lsl #32
    // 0x688678: r1 = Instance_CustomNum
    //     0x688678: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x68867c: ldr             x1, [x1, #0x6f0]
    // 0x688680: r0 = mult2()
    //     0x688680: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688684: ldur            x1, [fp, #-0x18]
    // 0x688688: StoreField: r1->field_b = r0
    //     0x688688: stur            w0, [x1, #0xb]
    //     0x68868c: ldurb           w16, [x1, #-1]
    //     0x688690: ldurb           w17, [x0, #-1]
    //     0x688694: and             x16, x17, x16, lsr #2
    //     0x688698: tst             x16, HEAP, lsr #32
    //     0x68869c: b.eq            #0x6886a4
    //     0x6886a0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6886a4: ldur            x1, [fp, #-8]
    // 0x6886a8: r2 = 20
    //     0x6886a8: movz            x2, #0x14
    // 0x6886ac: r0 = _getValueOrData()
    //     0x6886ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6886b0: mov             x1, x0
    // 0x6886b4: ldur            x0, [fp, #-8]
    // 0x6886b8: LoadField: r2 = r0->field_f
    //     0x6886b8: ldur            w2, [x0, #0xf]
    // 0x6886bc: DecompressPointer r2
    //     0x6886bc: add             x2, x2, HEAP, lsl #32
    // 0x6886c0: cmp             w2, w1
    // 0x6886c4: b.ne            #0x6886d0
    // 0x6886c8: r3 = Null
    //     0x6886c8: mov             x3, NULL
    // 0x6886cc: b               #0x6886d4
    // 0x6886d0: mov             x3, x1
    // 0x6886d4: stur            x3, [fp, #-0x18]
    // 0x6886d8: cmp             w3, NULL
    // 0x6886dc: b.eq            #0x6899b0
    // 0x6886e0: mov             x1, x0
    // 0x6886e4: r2 = 20
    //     0x6886e4: movz            x2, #0x14
    // 0x6886e8: r0 = _getValueOrData()
    //     0x6886e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6886ec: mov             x1, x0
    // 0x6886f0: ldur            x0, [fp, #-8]
    // 0x6886f4: LoadField: r2 = r0->field_f
    //     0x6886f4: ldur            w2, [x0, #0xf]
    // 0x6886f8: DecompressPointer r2
    //     0x6886f8: add             x2, x2, HEAP, lsl #32
    // 0x6886fc: cmp             w2, w1
    // 0x688700: b.ne            #0x688708
    // 0x688704: r1 = Null
    //     0x688704: mov             x1, NULL
    // 0x688708: ldur            x3, [fp, #-0x18]
    // 0x68870c: cmp             w1, NULL
    // 0x688710: b.eq            #0x6899b4
    // 0x688714: LoadField: r2 = r1->field_b
    //     0x688714: ldur            w2, [x1, #0xb]
    // 0x688718: DecompressPointer r2
    //     0x688718: add             x2, x2, HEAP, lsl #32
    // 0x68871c: r1 = Instance_CustomNum
    //     0x68871c: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x688720: ldr             x1, [x1, #0x6f0]
    // 0x688724: r0 = mult2()
    //     0x688724: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688728: ldur            x1, [fp, #-0x18]
    // 0x68872c: StoreField: r1->field_b = r0
    //     0x68872c: stur            w0, [x1, #0xb]
    //     0x688730: ldurb           w16, [x1, #-1]
    //     0x688734: ldurb           w17, [x0, #-1]
    //     0x688738: and             x16, x17, x16, lsr #2
    //     0x68873c: tst             x16, HEAP, lsr #32
    //     0x688740: b.eq            #0x688748
    //     0x688744: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688748: ldur            x0, [fp, #-0x10]
    // 0x68874c: LoadField: r1 = r0->field_43
    //     0x68874c: ldur            w1, [x0, #0x43]
    // 0x688750: DecompressPointer r1
    //     0x688750: add             x1, x1, HEAP, lsl #32
    // 0x688754: r2 = 242
    //     0x688754: movz            x2, #0xf2
    // 0x688758: r0 = containsKey()
    //     0x688758: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x68875c: tbnz            w0, #4, #0x688a98
    // 0x688760: ldur            x0, [fp, #-8]
    // 0x688764: mov             x1, x0
    // 0x688768: r2 = 12
    //     0x688768: movz            x2, #0xc
    // 0x68876c: r0 = _getValueOrData()
    //     0x68876c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688770: mov             x1, x0
    // 0x688774: ldur            x0, [fp, #-8]
    // 0x688778: LoadField: r2 = r0->field_f
    //     0x688778: ldur            w2, [x0, #0xf]
    // 0x68877c: DecompressPointer r2
    //     0x68877c: add             x2, x2, HEAP, lsl #32
    // 0x688780: cmp             w2, w1
    // 0x688784: b.ne            #0x688790
    // 0x688788: r3 = Null
    //     0x688788: mov             x3, NULL
    // 0x68878c: b               #0x688794
    // 0x688790: mov             x3, x1
    // 0x688794: stur            x3, [fp, #-0x18]
    // 0x688798: cmp             w3, NULL
    // 0x68879c: b.eq            #0x6899b8
    // 0x6887a0: mov             x1, x0
    // 0x6887a4: r2 = 12
    //     0x6887a4: movz            x2, #0xc
    // 0x6887a8: r0 = _getValueOrData()
    //     0x6887a8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6887ac: mov             x1, x0
    // 0x6887b0: ldur            x0, [fp, #-8]
    // 0x6887b4: LoadField: r2 = r0->field_f
    //     0x6887b4: ldur            w2, [x0, #0xf]
    // 0x6887b8: DecompressPointer r2
    //     0x6887b8: add             x2, x2, HEAP, lsl #32
    // 0x6887bc: cmp             w2, w1
    // 0x6887c0: b.ne            #0x6887c8
    // 0x6887c4: r1 = Null
    //     0x6887c4: mov             x1, NULL
    // 0x6887c8: ldur            x3, [fp, #-0x18]
    // 0x6887cc: cmp             w1, NULL
    // 0x6887d0: b.eq            #0x6899bc
    // 0x6887d4: LoadField: r2 = r1->field_7
    //     0x6887d4: ldur            w2, [x1, #7]
    // 0x6887d8: DecompressPointer r2
    //     0x6887d8: add             x2, x2, HEAP, lsl #32
    // 0x6887dc: r1 = Instance_CustomNum
    //     0x6887dc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6887e0: ldr             x1, [x1, #0xdd0]
    // 0x6887e4: r0 = mult2()
    //     0x6887e4: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6887e8: ldur            x1, [fp, #-0x18]
    // 0x6887ec: StoreField: r1->field_7 = r0
    //     0x6887ec: stur            w0, [x1, #7]
    //     0x6887f0: ldurb           w16, [x1, #-1]
    //     0x6887f4: ldurb           w17, [x0, #-1]
    //     0x6887f8: and             x16, x17, x16, lsr #2
    //     0x6887fc: tst             x16, HEAP, lsr #32
    //     0x688800: b.eq            #0x688808
    //     0x688804: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688808: ldur            x1, [fp, #-8]
    // 0x68880c: r2 = 14
    //     0x68880c: movz            x2, #0xe
    // 0x688810: r0 = _getValueOrData()
    //     0x688810: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688814: mov             x1, x0
    // 0x688818: ldur            x0, [fp, #-8]
    // 0x68881c: LoadField: r2 = r0->field_f
    //     0x68881c: ldur            w2, [x0, #0xf]
    // 0x688820: DecompressPointer r2
    //     0x688820: add             x2, x2, HEAP, lsl #32
    // 0x688824: cmp             w2, w1
    // 0x688828: b.ne            #0x688834
    // 0x68882c: r3 = Null
    //     0x68882c: mov             x3, NULL
    // 0x688830: b               #0x688838
    // 0x688834: mov             x3, x1
    // 0x688838: stur            x3, [fp, #-0x18]
    // 0x68883c: cmp             w3, NULL
    // 0x688840: b.eq            #0x6899c0
    // 0x688844: mov             x1, x0
    // 0x688848: r2 = 14
    //     0x688848: movz            x2, #0xe
    // 0x68884c: r0 = _getValueOrData()
    //     0x68884c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688850: mov             x1, x0
    // 0x688854: ldur            x0, [fp, #-8]
    // 0x688858: LoadField: r2 = r0->field_f
    //     0x688858: ldur            w2, [x0, #0xf]
    // 0x68885c: DecompressPointer r2
    //     0x68885c: add             x2, x2, HEAP, lsl #32
    // 0x688860: cmp             w2, w1
    // 0x688864: b.ne            #0x68886c
    // 0x688868: r1 = Null
    //     0x688868: mov             x1, NULL
    // 0x68886c: ldur            x3, [fp, #-0x18]
    // 0x688870: cmp             w1, NULL
    // 0x688874: b.eq            #0x6899c4
    // 0x688878: LoadField: r2 = r1->field_7
    //     0x688878: ldur            w2, [x1, #7]
    // 0x68887c: DecompressPointer r2
    //     0x68887c: add             x2, x2, HEAP, lsl #32
    // 0x688880: r1 = Instance_CustomNum
    //     0x688880: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x688884: ldr             x1, [x1, #0xdd0]
    // 0x688888: r0 = mult2()
    //     0x688888: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68888c: ldur            x1, [fp, #-0x18]
    // 0x688890: StoreField: r1->field_7 = r0
    //     0x688890: stur            w0, [x1, #7]
    //     0x688894: ldurb           w16, [x1, #-1]
    //     0x688898: ldurb           w17, [x0, #-1]
    //     0x68889c: and             x16, x17, x16, lsr #2
    //     0x6888a0: tst             x16, HEAP, lsr #32
    //     0x6888a4: b.eq            #0x6888ac
    //     0x6888a8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6888ac: ldur            x1, [fp, #-8]
    // 0x6888b0: r2 = 16
    //     0x6888b0: movz            x2, #0x10
    // 0x6888b4: r0 = _getValueOrData()
    //     0x6888b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6888b8: mov             x1, x0
    // 0x6888bc: ldur            x0, [fp, #-8]
    // 0x6888c0: LoadField: r2 = r0->field_f
    //     0x6888c0: ldur            w2, [x0, #0xf]
    // 0x6888c4: DecompressPointer r2
    //     0x6888c4: add             x2, x2, HEAP, lsl #32
    // 0x6888c8: cmp             w2, w1
    // 0x6888cc: b.ne            #0x6888d8
    // 0x6888d0: r3 = Null
    //     0x6888d0: mov             x3, NULL
    // 0x6888d4: b               #0x6888dc
    // 0x6888d8: mov             x3, x1
    // 0x6888dc: stur            x3, [fp, #-0x18]
    // 0x6888e0: cmp             w3, NULL
    // 0x6888e4: b.eq            #0x6899c8
    // 0x6888e8: mov             x1, x0
    // 0x6888ec: r2 = 16
    //     0x6888ec: movz            x2, #0x10
    // 0x6888f0: r0 = _getValueOrData()
    //     0x6888f0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6888f4: mov             x1, x0
    // 0x6888f8: ldur            x0, [fp, #-8]
    // 0x6888fc: LoadField: r2 = r0->field_f
    //     0x6888fc: ldur            w2, [x0, #0xf]
    // 0x688900: DecompressPointer r2
    //     0x688900: add             x2, x2, HEAP, lsl #32
    // 0x688904: cmp             w2, w1
    // 0x688908: b.ne            #0x688910
    // 0x68890c: r1 = Null
    //     0x68890c: mov             x1, NULL
    // 0x688910: ldur            x3, [fp, #-0x18]
    // 0x688914: cmp             w1, NULL
    // 0x688918: b.eq            #0x6899cc
    // 0x68891c: LoadField: r2 = r1->field_7
    //     0x68891c: ldur            w2, [x1, #7]
    // 0x688920: DecompressPointer r2
    //     0x688920: add             x2, x2, HEAP, lsl #32
    // 0x688924: r1 = Instance_CustomNum
    //     0x688924: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x688928: ldr             x1, [x1, #0xdd0]
    // 0x68892c: r0 = mult2()
    //     0x68892c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688930: ldur            x1, [fp, #-0x18]
    // 0x688934: StoreField: r1->field_7 = r0
    //     0x688934: stur            w0, [x1, #7]
    //     0x688938: ldurb           w16, [x1, #-1]
    //     0x68893c: ldurb           w17, [x0, #-1]
    //     0x688940: and             x16, x17, x16, lsr #2
    //     0x688944: tst             x16, HEAP, lsr #32
    //     0x688948: b.eq            #0x688950
    //     0x68894c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688950: ldur            x1, [fp, #-8]
    // 0x688954: r2 = 18
    //     0x688954: movz            x2, #0x12
    // 0x688958: r0 = _getValueOrData()
    //     0x688958: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68895c: mov             x1, x0
    // 0x688960: ldur            x0, [fp, #-8]
    // 0x688964: LoadField: r2 = r0->field_f
    //     0x688964: ldur            w2, [x0, #0xf]
    // 0x688968: DecompressPointer r2
    //     0x688968: add             x2, x2, HEAP, lsl #32
    // 0x68896c: cmp             w2, w1
    // 0x688970: b.ne            #0x68897c
    // 0x688974: r3 = Null
    //     0x688974: mov             x3, NULL
    // 0x688978: b               #0x688980
    // 0x68897c: mov             x3, x1
    // 0x688980: stur            x3, [fp, #-0x18]
    // 0x688984: cmp             w3, NULL
    // 0x688988: b.eq            #0x6899d0
    // 0x68898c: mov             x1, x0
    // 0x688990: r2 = 18
    //     0x688990: movz            x2, #0x12
    // 0x688994: r0 = _getValueOrData()
    //     0x688994: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688998: mov             x1, x0
    // 0x68899c: ldur            x0, [fp, #-8]
    // 0x6889a0: LoadField: r2 = r0->field_f
    //     0x6889a0: ldur            w2, [x0, #0xf]
    // 0x6889a4: DecompressPointer r2
    //     0x6889a4: add             x2, x2, HEAP, lsl #32
    // 0x6889a8: cmp             w2, w1
    // 0x6889ac: b.ne            #0x6889b4
    // 0x6889b0: r1 = Null
    //     0x6889b0: mov             x1, NULL
    // 0x6889b4: ldur            x3, [fp, #-0x18]
    // 0x6889b8: cmp             w1, NULL
    // 0x6889bc: b.eq            #0x6899d4
    // 0x6889c0: LoadField: r2 = r1->field_7
    //     0x6889c0: ldur            w2, [x1, #7]
    // 0x6889c4: DecompressPointer r2
    //     0x6889c4: add             x2, x2, HEAP, lsl #32
    // 0x6889c8: r1 = Instance_CustomNum
    //     0x6889c8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6889cc: ldr             x1, [x1, #0xdd0]
    // 0x6889d0: r0 = mult2()
    //     0x6889d0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6889d4: ldur            x1, [fp, #-0x18]
    // 0x6889d8: StoreField: r1->field_7 = r0
    //     0x6889d8: stur            w0, [x1, #7]
    //     0x6889dc: ldurb           w16, [x1, #-1]
    //     0x6889e0: ldurb           w17, [x0, #-1]
    //     0x6889e4: and             x16, x17, x16, lsr #2
    //     0x6889e8: tst             x16, HEAP, lsr #32
    //     0x6889ec: b.eq            #0x6889f4
    //     0x6889f0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6889f4: ldur            x1, [fp, #-8]
    // 0x6889f8: r2 = 20
    //     0x6889f8: movz            x2, #0x14
    // 0x6889fc: r0 = _getValueOrData()
    //     0x6889fc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688a00: mov             x1, x0
    // 0x688a04: ldur            x0, [fp, #-8]
    // 0x688a08: LoadField: r2 = r0->field_f
    //     0x688a08: ldur            w2, [x0, #0xf]
    // 0x688a0c: DecompressPointer r2
    //     0x688a0c: add             x2, x2, HEAP, lsl #32
    // 0x688a10: cmp             w2, w1
    // 0x688a14: b.ne            #0x688a20
    // 0x688a18: r3 = Null
    //     0x688a18: mov             x3, NULL
    // 0x688a1c: b               #0x688a24
    // 0x688a20: mov             x3, x1
    // 0x688a24: stur            x3, [fp, #-0x18]
    // 0x688a28: cmp             w3, NULL
    // 0x688a2c: b.eq            #0x6899d8
    // 0x688a30: mov             x1, x0
    // 0x688a34: r2 = 20
    //     0x688a34: movz            x2, #0x14
    // 0x688a38: r0 = _getValueOrData()
    //     0x688a38: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688a3c: mov             x1, x0
    // 0x688a40: ldur            x0, [fp, #-8]
    // 0x688a44: LoadField: r2 = r0->field_f
    //     0x688a44: ldur            w2, [x0, #0xf]
    // 0x688a48: DecompressPointer r2
    //     0x688a48: add             x2, x2, HEAP, lsl #32
    // 0x688a4c: cmp             w2, w1
    // 0x688a50: b.ne            #0x688a58
    // 0x688a54: r1 = Null
    //     0x688a54: mov             x1, NULL
    // 0x688a58: ldur            x3, [fp, #-0x18]
    // 0x688a5c: cmp             w1, NULL
    // 0x688a60: b.eq            #0x6899dc
    // 0x688a64: LoadField: r2 = r1->field_7
    //     0x688a64: ldur            w2, [x1, #7]
    // 0x688a68: DecompressPointer r2
    //     0x688a68: add             x2, x2, HEAP, lsl #32
    // 0x688a6c: r1 = Instance_CustomNum
    //     0x688a6c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x688a70: ldr             x1, [x1, #0xdd0]
    // 0x688a74: r0 = mult2()
    //     0x688a74: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688a78: ldur            x1, [fp, #-0x18]
    // 0x688a7c: StoreField: r1->field_7 = r0
    //     0x688a7c: stur            w0, [x1, #7]
    //     0x688a80: ldurb           w16, [x1, #-1]
    //     0x688a84: ldurb           w17, [x0, #-1]
    //     0x688a88: and             x16, x17, x16, lsr #2
    //     0x688a8c: tst             x16, HEAP, lsr #32
    //     0x688a90: b.eq            #0x688a98
    //     0x688a94: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688a98: ldur            x0, [fp, #-0x10]
    // 0x688a9c: LoadField: r1 = r0->field_43
    //     0x688a9c: ldur            w1, [x0, #0x43]
    // 0x688aa0: DecompressPointer r1
    //     0x688aa0: add             x1, x1, HEAP, lsl #32
    // 0x688aa4: r2 = 250
    //     0x688aa4: movz            x2, #0xfa
    // 0x688aa8: r0 = containsKey()
    //     0x688aa8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x688aac: tbnz            w0, #4, #0x688e24
    // 0x688ab0: ldur            x0, [fp, #-8]
    // 0x688ab4: mov             x1, x0
    // 0x688ab8: r2 = 12
    //     0x688ab8: movz            x2, #0xc
    // 0x688abc: r0 = _getValueOrData()
    //     0x688abc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688ac0: mov             x1, x0
    // 0x688ac4: ldur            x0, [fp, #-8]
    // 0x688ac8: LoadField: r2 = r0->field_f
    //     0x688ac8: ldur            w2, [x0, #0xf]
    // 0x688acc: DecompressPointer r2
    //     0x688acc: add             x2, x2, HEAP, lsl #32
    // 0x688ad0: cmp             w2, w1
    // 0x688ad4: b.ne            #0x688ae0
    // 0x688ad8: r3 = Null
    //     0x688ad8: mov             x3, NULL
    // 0x688adc: b               #0x688ae4
    // 0x688ae0: mov             x3, x1
    // 0x688ae4: stur            x3, [fp, #-0x18]
    // 0x688ae8: cmp             w3, NULL
    // 0x688aec: b.eq            #0x6899e0
    // 0x688af0: r1 = Null
    //     0x688af0: mov             x1, NULL
    // 0x688af4: r2 = 16
    //     0x688af4: movz            x2, #0x10
    // 0x688af8: r0 = CustomNum()
    //     0x688af8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x688afc: ldur            x1, [fp, #-8]
    // 0x688b00: r2 = 12
    //     0x688b00: movz            x2, #0xc
    // 0x688b04: stur            x0, [fp, #-0x20]
    // 0x688b08: r0 = _getValueOrData()
    //     0x688b08: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688b0c: mov             x1, x0
    // 0x688b10: ldur            x0, [fp, #-8]
    // 0x688b14: LoadField: r2 = r0->field_f
    //     0x688b14: ldur            w2, [x0, #0xf]
    // 0x688b18: DecompressPointer r2
    //     0x688b18: add             x2, x2, HEAP, lsl #32
    // 0x688b1c: cmp             w2, w1
    // 0x688b20: b.ne            #0x688b28
    // 0x688b24: r1 = Null
    //     0x688b24: mov             x1, NULL
    // 0x688b28: ldur            x3, [fp, #-0x18]
    // 0x688b2c: cmp             w1, NULL
    // 0x688b30: b.eq            #0x6899e4
    // 0x688b34: LoadField: r2 = r1->field_7
    //     0x688b34: ldur            w2, [x1, #7]
    // 0x688b38: DecompressPointer r2
    //     0x688b38: add             x2, x2, HEAP, lsl #32
    // 0x688b3c: ldur            x1, [fp, #-0x20]
    // 0x688b40: r0 = mult2()
    //     0x688b40: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688b44: ldur            x1, [fp, #-0x18]
    // 0x688b48: StoreField: r1->field_7 = r0
    //     0x688b48: stur            w0, [x1, #7]
    //     0x688b4c: ldurb           w16, [x1, #-1]
    //     0x688b50: ldurb           w17, [x0, #-1]
    //     0x688b54: and             x16, x17, x16, lsr #2
    //     0x688b58: tst             x16, HEAP, lsr #32
    //     0x688b5c: b.eq            #0x688b64
    //     0x688b60: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688b64: ldur            x1, [fp, #-8]
    // 0x688b68: r2 = 14
    //     0x688b68: movz            x2, #0xe
    // 0x688b6c: r0 = _getValueOrData()
    //     0x688b6c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688b70: mov             x1, x0
    // 0x688b74: ldur            x0, [fp, #-8]
    // 0x688b78: LoadField: r2 = r0->field_f
    //     0x688b78: ldur            w2, [x0, #0xf]
    // 0x688b7c: DecompressPointer r2
    //     0x688b7c: add             x2, x2, HEAP, lsl #32
    // 0x688b80: cmp             w2, w1
    // 0x688b84: b.ne            #0x688b90
    // 0x688b88: r3 = Null
    //     0x688b88: mov             x3, NULL
    // 0x688b8c: b               #0x688b94
    // 0x688b90: mov             x3, x1
    // 0x688b94: stur            x3, [fp, #-0x18]
    // 0x688b98: cmp             w3, NULL
    // 0x688b9c: b.eq            #0x6899e8
    // 0x688ba0: r1 = Null
    //     0x688ba0: mov             x1, NULL
    // 0x688ba4: r2 = 16
    //     0x688ba4: movz            x2, #0x10
    // 0x688ba8: r0 = CustomNum()
    //     0x688ba8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x688bac: ldur            x1, [fp, #-8]
    // 0x688bb0: r2 = 14
    //     0x688bb0: movz            x2, #0xe
    // 0x688bb4: stur            x0, [fp, #-0x20]
    // 0x688bb8: r0 = _getValueOrData()
    //     0x688bb8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688bbc: mov             x1, x0
    // 0x688bc0: ldur            x0, [fp, #-8]
    // 0x688bc4: LoadField: r2 = r0->field_f
    //     0x688bc4: ldur            w2, [x0, #0xf]
    // 0x688bc8: DecompressPointer r2
    //     0x688bc8: add             x2, x2, HEAP, lsl #32
    // 0x688bcc: cmp             w2, w1
    // 0x688bd0: b.ne            #0x688bd8
    // 0x688bd4: r1 = Null
    //     0x688bd4: mov             x1, NULL
    // 0x688bd8: ldur            x3, [fp, #-0x18]
    // 0x688bdc: cmp             w1, NULL
    // 0x688be0: b.eq            #0x6899ec
    // 0x688be4: LoadField: r2 = r1->field_7
    //     0x688be4: ldur            w2, [x1, #7]
    // 0x688be8: DecompressPointer r2
    //     0x688be8: add             x2, x2, HEAP, lsl #32
    // 0x688bec: ldur            x1, [fp, #-0x20]
    // 0x688bf0: r0 = mult2()
    //     0x688bf0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688bf4: ldur            x1, [fp, #-0x18]
    // 0x688bf8: StoreField: r1->field_7 = r0
    //     0x688bf8: stur            w0, [x1, #7]
    //     0x688bfc: ldurb           w16, [x1, #-1]
    //     0x688c00: ldurb           w17, [x0, #-1]
    //     0x688c04: and             x16, x17, x16, lsr #2
    //     0x688c08: tst             x16, HEAP, lsr #32
    //     0x688c0c: b.eq            #0x688c14
    //     0x688c10: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688c14: ldur            x1, [fp, #-8]
    // 0x688c18: r2 = 16
    //     0x688c18: movz            x2, #0x10
    // 0x688c1c: r0 = _getValueOrData()
    //     0x688c1c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688c20: mov             x1, x0
    // 0x688c24: ldur            x0, [fp, #-8]
    // 0x688c28: LoadField: r2 = r0->field_f
    //     0x688c28: ldur            w2, [x0, #0xf]
    // 0x688c2c: DecompressPointer r2
    //     0x688c2c: add             x2, x2, HEAP, lsl #32
    // 0x688c30: cmp             w2, w1
    // 0x688c34: b.ne            #0x688c40
    // 0x688c38: r3 = Null
    //     0x688c38: mov             x3, NULL
    // 0x688c3c: b               #0x688c44
    // 0x688c40: mov             x3, x1
    // 0x688c44: stur            x3, [fp, #-0x18]
    // 0x688c48: cmp             w3, NULL
    // 0x688c4c: b.eq            #0x6899f0
    // 0x688c50: r1 = Null
    //     0x688c50: mov             x1, NULL
    // 0x688c54: r2 = 16
    //     0x688c54: movz            x2, #0x10
    // 0x688c58: r0 = CustomNum()
    //     0x688c58: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x688c5c: ldur            x1, [fp, #-8]
    // 0x688c60: r2 = 16
    //     0x688c60: movz            x2, #0x10
    // 0x688c64: stur            x0, [fp, #-0x20]
    // 0x688c68: r0 = _getValueOrData()
    //     0x688c68: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688c6c: mov             x1, x0
    // 0x688c70: ldur            x0, [fp, #-8]
    // 0x688c74: LoadField: r2 = r0->field_f
    //     0x688c74: ldur            w2, [x0, #0xf]
    // 0x688c78: DecompressPointer r2
    //     0x688c78: add             x2, x2, HEAP, lsl #32
    // 0x688c7c: cmp             w2, w1
    // 0x688c80: b.ne            #0x688c88
    // 0x688c84: r1 = Null
    //     0x688c84: mov             x1, NULL
    // 0x688c88: ldur            x3, [fp, #-0x18]
    // 0x688c8c: cmp             w1, NULL
    // 0x688c90: b.eq            #0x6899f4
    // 0x688c94: LoadField: r2 = r1->field_7
    //     0x688c94: ldur            w2, [x1, #7]
    // 0x688c98: DecompressPointer r2
    //     0x688c98: add             x2, x2, HEAP, lsl #32
    // 0x688c9c: ldur            x1, [fp, #-0x20]
    // 0x688ca0: r0 = mult2()
    //     0x688ca0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688ca4: ldur            x1, [fp, #-0x18]
    // 0x688ca8: StoreField: r1->field_7 = r0
    //     0x688ca8: stur            w0, [x1, #7]
    //     0x688cac: ldurb           w16, [x1, #-1]
    //     0x688cb0: ldurb           w17, [x0, #-1]
    //     0x688cb4: and             x16, x17, x16, lsr #2
    //     0x688cb8: tst             x16, HEAP, lsr #32
    //     0x688cbc: b.eq            #0x688cc4
    //     0x688cc0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688cc4: ldur            x1, [fp, #-8]
    // 0x688cc8: r2 = 18
    //     0x688cc8: movz            x2, #0x12
    // 0x688ccc: r0 = _getValueOrData()
    //     0x688ccc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688cd0: mov             x1, x0
    // 0x688cd4: ldur            x0, [fp, #-8]
    // 0x688cd8: LoadField: r2 = r0->field_f
    //     0x688cd8: ldur            w2, [x0, #0xf]
    // 0x688cdc: DecompressPointer r2
    //     0x688cdc: add             x2, x2, HEAP, lsl #32
    // 0x688ce0: cmp             w2, w1
    // 0x688ce4: b.ne            #0x688cf0
    // 0x688ce8: r3 = Null
    //     0x688ce8: mov             x3, NULL
    // 0x688cec: b               #0x688cf4
    // 0x688cf0: mov             x3, x1
    // 0x688cf4: stur            x3, [fp, #-0x18]
    // 0x688cf8: cmp             w3, NULL
    // 0x688cfc: b.eq            #0x6899f8
    // 0x688d00: r1 = Null
    //     0x688d00: mov             x1, NULL
    // 0x688d04: r2 = 16
    //     0x688d04: movz            x2, #0x10
    // 0x688d08: r0 = CustomNum()
    //     0x688d08: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x688d0c: ldur            x1, [fp, #-8]
    // 0x688d10: r2 = 18
    //     0x688d10: movz            x2, #0x12
    // 0x688d14: stur            x0, [fp, #-0x20]
    // 0x688d18: r0 = _getValueOrData()
    //     0x688d18: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688d1c: mov             x1, x0
    // 0x688d20: ldur            x0, [fp, #-8]
    // 0x688d24: LoadField: r2 = r0->field_f
    //     0x688d24: ldur            w2, [x0, #0xf]
    // 0x688d28: DecompressPointer r2
    //     0x688d28: add             x2, x2, HEAP, lsl #32
    // 0x688d2c: cmp             w2, w1
    // 0x688d30: b.ne            #0x688d38
    // 0x688d34: r1 = Null
    //     0x688d34: mov             x1, NULL
    // 0x688d38: ldur            x3, [fp, #-0x18]
    // 0x688d3c: cmp             w1, NULL
    // 0x688d40: b.eq            #0x6899fc
    // 0x688d44: LoadField: r2 = r1->field_7
    //     0x688d44: ldur            w2, [x1, #7]
    // 0x688d48: DecompressPointer r2
    //     0x688d48: add             x2, x2, HEAP, lsl #32
    // 0x688d4c: ldur            x1, [fp, #-0x20]
    // 0x688d50: r0 = mult2()
    //     0x688d50: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688d54: ldur            x1, [fp, #-0x18]
    // 0x688d58: StoreField: r1->field_7 = r0
    //     0x688d58: stur            w0, [x1, #7]
    //     0x688d5c: ldurb           w16, [x1, #-1]
    //     0x688d60: ldurb           w17, [x0, #-1]
    //     0x688d64: and             x16, x17, x16, lsr #2
    //     0x688d68: tst             x16, HEAP, lsr #32
    //     0x688d6c: b.eq            #0x688d74
    //     0x688d70: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688d74: ldur            x1, [fp, #-8]
    // 0x688d78: r2 = 20
    //     0x688d78: movz            x2, #0x14
    // 0x688d7c: r0 = _getValueOrData()
    //     0x688d7c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688d80: mov             x1, x0
    // 0x688d84: ldur            x0, [fp, #-8]
    // 0x688d88: LoadField: r2 = r0->field_f
    //     0x688d88: ldur            w2, [x0, #0xf]
    // 0x688d8c: DecompressPointer r2
    //     0x688d8c: add             x2, x2, HEAP, lsl #32
    // 0x688d90: cmp             w2, w1
    // 0x688d94: b.ne            #0x688da0
    // 0x688d98: r3 = Null
    //     0x688d98: mov             x3, NULL
    // 0x688d9c: b               #0x688da4
    // 0x688da0: mov             x3, x1
    // 0x688da4: stur            x3, [fp, #-0x18]
    // 0x688da8: cmp             w3, NULL
    // 0x688dac: b.eq            #0x689a00
    // 0x688db0: r1 = Null
    //     0x688db0: mov             x1, NULL
    // 0x688db4: r2 = 16
    //     0x688db4: movz            x2, #0x10
    // 0x688db8: r0 = CustomNum()
    //     0x688db8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x688dbc: ldur            x1, [fp, #-8]
    // 0x688dc0: r2 = 20
    //     0x688dc0: movz            x2, #0x14
    // 0x688dc4: stur            x0, [fp, #-0x20]
    // 0x688dc8: r0 = _getValueOrData()
    //     0x688dc8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688dcc: mov             x1, x0
    // 0x688dd0: ldur            x0, [fp, #-8]
    // 0x688dd4: LoadField: r2 = r0->field_f
    //     0x688dd4: ldur            w2, [x0, #0xf]
    // 0x688dd8: DecompressPointer r2
    //     0x688dd8: add             x2, x2, HEAP, lsl #32
    // 0x688ddc: cmp             w2, w1
    // 0x688de0: b.ne            #0x688de8
    // 0x688de4: r1 = Null
    //     0x688de4: mov             x1, NULL
    // 0x688de8: ldur            x3, [fp, #-0x18]
    // 0x688dec: cmp             w1, NULL
    // 0x688df0: b.eq            #0x689a04
    // 0x688df4: LoadField: r2 = r1->field_7
    //     0x688df4: ldur            w2, [x1, #7]
    // 0x688df8: DecompressPointer r2
    //     0x688df8: add             x2, x2, HEAP, lsl #32
    // 0x688dfc: ldur            x1, [fp, #-0x20]
    // 0x688e00: r0 = mult2()
    //     0x688e00: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688e04: ldur            x1, [fp, #-0x18]
    // 0x688e08: StoreField: r1->field_7 = r0
    //     0x688e08: stur            w0, [x1, #7]
    //     0x688e0c: ldurb           w16, [x1, #-1]
    //     0x688e10: ldurb           w17, [x0, #-1]
    //     0x688e14: and             x16, x17, x16, lsr #2
    //     0x688e18: tst             x16, HEAP, lsr #32
    //     0x688e1c: b.eq            #0x688e24
    //     0x688e20: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688e24: ldur            x0, [fp, #-0x10]
    // 0x688e28: LoadField: r1 = r0->field_43
    //     0x688e28: ldur            w1, [x0, #0x43]
    // 0x688e2c: DecompressPointer r1
    //     0x688e2c: add             x1, x1, HEAP, lsl #32
    // 0x688e30: r2 = 256
    //     0x688e30: movz            x2, #0x100
    // 0x688e34: r0 = containsKey()
    //     0x688e34: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x688e38: tbnz            w0, #4, #0x689174
    // 0x688e3c: ldur            x0, [fp, #-8]
    // 0x688e40: mov             x1, x0
    // 0x688e44: r2 = 12
    //     0x688e44: movz            x2, #0xc
    // 0x688e48: r0 = _getValueOrData()
    //     0x688e48: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688e4c: mov             x1, x0
    // 0x688e50: ldur            x0, [fp, #-8]
    // 0x688e54: LoadField: r2 = r0->field_f
    //     0x688e54: ldur            w2, [x0, #0xf]
    // 0x688e58: DecompressPointer r2
    //     0x688e58: add             x2, x2, HEAP, lsl #32
    // 0x688e5c: cmp             w2, w1
    // 0x688e60: b.ne            #0x688e6c
    // 0x688e64: r3 = Null
    //     0x688e64: mov             x3, NULL
    // 0x688e68: b               #0x688e70
    // 0x688e6c: mov             x3, x1
    // 0x688e70: stur            x3, [fp, #-0x18]
    // 0x688e74: cmp             w3, NULL
    // 0x688e78: b.eq            #0x689a08
    // 0x688e7c: mov             x1, x0
    // 0x688e80: r2 = 12
    //     0x688e80: movz            x2, #0xc
    // 0x688e84: r0 = _getValueOrData()
    //     0x688e84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688e88: mov             x1, x0
    // 0x688e8c: ldur            x0, [fp, #-8]
    // 0x688e90: LoadField: r2 = r0->field_f
    //     0x688e90: ldur            w2, [x0, #0xf]
    // 0x688e94: DecompressPointer r2
    //     0x688e94: add             x2, x2, HEAP, lsl #32
    // 0x688e98: cmp             w2, w1
    // 0x688e9c: b.ne            #0x688ea4
    // 0x688ea0: r1 = Null
    //     0x688ea0: mov             x1, NULL
    // 0x688ea4: ldur            x3, [fp, #-0x18]
    // 0x688ea8: cmp             w1, NULL
    // 0x688eac: b.eq            #0x689a0c
    // 0x688eb0: LoadField: r2 = r1->field_7
    //     0x688eb0: ldur            w2, [x1, #7]
    // 0x688eb4: DecompressPointer r2
    //     0x688eb4: add             x2, x2, HEAP, lsl #32
    // 0x688eb8: r1 = Instance_CustomNum
    //     0x688eb8: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x688ebc: ldr             x1, [x1, #0x448]
    // 0x688ec0: r0 = mult2()
    //     0x688ec0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688ec4: ldur            x1, [fp, #-0x18]
    // 0x688ec8: StoreField: r1->field_7 = r0
    //     0x688ec8: stur            w0, [x1, #7]
    //     0x688ecc: ldurb           w16, [x1, #-1]
    //     0x688ed0: ldurb           w17, [x0, #-1]
    //     0x688ed4: and             x16, x17, x16, lsr #2
    //     0x688ed8: tst             x16, HEAP, lsr #32
    //     0x688edc: b.eq            #0x688ee4
    //     0x688ee0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688ee4: ldur            x1, [fp, #-8]
    // 0x688ee8: r2 = 14
    //     0x688ee8: movz            x2, #0xe
    // 0x688eec: r0 = _getValueOrData()
    //     0x688eec: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688ef0: mov             x1, x0
    // 0x688ef4: ldur            x0, [fp, #-8]
    // 0x688ef8: LoadField: r2 = r0->field_f
    //     0x688ef8: ldur            w2, [x0, #0xf]
    // 0x688efc: DecompressPointer r2
    //     0x688efc: add             x2, x2, HEAP, lsl #32
    // 0x688f00: cmp             w2, w1
    // 0x688f04: b.ne            #0x688f10
    // 0x688f08: r3 = Null
    //     0x688f08: mov             x3, NULL
    // 0x688f0c: b               #0x688f14
    // 0x688f10: mov             x3, x1
    // 0x688f14: stur            x3, [fp, #-0x18]
    // 0x688f18: cmp             w3, NULL
    // 0x688f1c: b.eq            #0x689a10
    // 0x688f20: mov             x1, x0
    // 0x688f24: r2 = 14
    //     0x688f24: movz            x2, #0xe
    // 0x688f28: r0 = _getValueOrData()
    //     0x688f28: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688f2c: mov             x1, x0
    // 0x688f30: ldur            x0, [fp, #-8]
    // 0x688f34: LoadField: r2 = r0->field_f
    //     0x688f34: ldur            w2, [x0, #0xf]
    // 0x688f38: DecompressPointer r2
    //     0x688f38: add             x2, x2, HEAP, lsl #32
    // 0x688f3c: cmp             w2, w1
    // 0x688f40: b.ne            #0x688f48
    // 0x688f44: r1 = Null
    //     0x688f44: mov             x1, NULL
    // 0x688f48: ldur            x3, [fp, #-0x18]
    // 0x688f4c: cmp             w1, NULL
    // 0x688f50: b.eq            #0x689a14
    // 0x688f54: LoadField: r2 = r1->field_7
    //     0x688f54: ldur            w2, [x1, #7]
    // 0x688f58: DecompressPointer r2
    //     0x688f58: add             x2, x2, HEAP, lsl #32
    // 0x688f5c: r1 = Instance_CustomNum
    //     0x688f5c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x688f60: ldr             x1, [x1, #0x448]
    // 0x688f64: r0 = mult2()
    //     0x688f64: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x688f68: ldur            x1, [fp, #-0x18]
    // 0x688f6c: StoreField: r1->field_7 = r0
    //     0x688f6c: stur            w0, [x1, #7]
    //     0x688f70: ldurb           w16, [x1, #-1]
    //     0x688f74: ldurb           w17, [x0, #-1]
    //     0x688f78: and             x16, x17, x16, lsr #2
    //     0x688f7c: tst             x16, HEAP, lsr #32
    //     0x688f80: b.eq            #0x688f88
    //     0x688f84: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x688f88: ldur            x1, [fp, #-8]
    // 0x688f8c: r2 = 16
    //     0x688f8c: movz            x2, #0x10
    // 0x688f90: r0 = _getValueOrData()
    //     0x688f90: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688f94: mov             x1, x0
    // 0x688f98: ldur            x0, [fp, #-8]
    // 0x688f9c: LoadField: r2 = r0->field_f
    //     0x688f9c: ldur            w2, [x0, #0xf]
    // 0x688fa0: DecompressPointer r2
    //     0x688fa0: add             x2, x2, HEAP, lsl #32
    // 0x688fa4: cmp             w2, w1
    // 0x688fa8: b.ne            #0x688fb4
    // 0x688fac: r3 = Null
    //     0x688fac: mov             x3, NULL
    // 0x688fb0: b               #0x688fb8
    // 0x688fb4: mov             x3, x1
    // 0x688fb8: stur            x3, [fp, #-0x18]
    // 0x688fbc: cmp             w3, NULL
    // 0x688fc0: b.eq            #0x689a18
    // 0x688fc4: mov             x1, x0
    // 0x688fc8: r2 = 16
    //     0x688fc8: movz            x2, #0x10
    // 0x688fcc: r0 = _getValueOrData()
    //     0x688fcc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x688fd0: mov             x1, x0
    // 0x688fd4: ldur            x0, [fp, #-8]
    // 0x688fd8: LoadField: r2 = r0->field_f
    //     0x688fd8: ldur            w2, [x0, #0xf]
    // 0x688fdc: DecompressPointer r2
    //     0x688fdc: add             x2, x2, HEAP, lsl #32
    // 0x688fe0: cmp             w2, w1
    // 0x688fe4: b.ne            #0x688fec
    // 0x688fe8: r1 = Null
    //     0x688fe8: mov             x1, NULL
    // 0x688fec: ldur            x3, [fp, #-0x18]
    // 0x688ff0: cmp             w1, NULL
    // 0x688ff4: b.eq            #0x689a1c
    // 0x688ff8: LoadField: r2 = r1->field_7
    //     0x688ff8: ldur            w2, [x1, #7]
    // 0x688ffc: DecompressPointer r2
    //     0x688ffc: add             x2, x2, HEAP, lsl #32
    // 0x689000: r1 = Instance_CustomNum
    //     0x689000: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x689004: ldr             x1, [x1, #0x448]
    // 0x689008: r0 = mult2()
    //     0x689008: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68900c: ldur            x1, [fp, #-0x18]
    // 0x689010: StoreField: r1->field_7 = r0
    //     0x689010: stur            w0, [x1, #7]
    //     0x689014: ldurb           w16, [x1, #-1]
    //     0x689018: ldurb           w17, [x0, #-1]
    //     0x68901c: and             x16, x17, x16, lsr #2
    //     0x689020: tst             x16, HEAP, lsr #32
    //     0x689024: b.eq            #0x68902c
    //     0x689028: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68902c: ldur            x1, [fp, #-8]
    // 0x689030: r2 = 18
    //     0x689030: movz            x2, #0x12
    // 0x689034: r0 = _getValueOrData()
    //     0x689034: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689038: mov             x1, x0
    // 0x68903c: ldur            x0, [fp, #-8]
    // 0x689040: LoadField: r2 = r0->field_f
    //     0x689040: ldur            w2, [x0, #0xf]
    // 0x689044: DecompressPointer r2
    //     0x689044: add             x2, x2, HEAP, lsl #32
    // 0x689048: cmp             w2, w1
    // 0x68904c: b.ne            #0x689058
    // 0x689050: r3 = Null
    //     0x689050: mov             x3, NULL
    // 0x689054: b               #0x68905c
    // 0x689058: mov             x3, x1
    // 0x68905c: stur            x3, [fp, #-0x18]
    // 0x689060: cmp             w3, NULL
    // 0x689064: b.eq            #0x689a20
    // 0x689068: mov             x1, x0
    // 0x68906c: r2 = 18
    //     0x68906c: movz            x2, #0x12
    // 0x689070: r0 = _getValueOrData()
    //     0x689070: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689074: mov             x1, x0
    // 0x689078: ldur            x0, [fp, #-8]
    // 0x68907c: LoadField: r2 = r0->field_f
    //     0x68907c: ldur            w2, [x0, #0xf]
    // 0x689080: DecompressPointer r2
    //     0x689080: add             x2, x2, HEAP, lsl #32
    // 0x689084: cmp             w2, w1
    // 0x689088: b.ne            #0x689090
    // 0x68908c: r1 = Null
    //     0x68908c: mov             x1, NULL
    // 0x689090: ldur            x3, [fp, #-0x18]
    // 0x689094: cmp             w1, NULL
    // 0x689098: b.eq            #0x689a24
    // 0x68909c: LoadField: r2 = r1->field_7
    //     0x68909c: ldur            w2, [x1, #7]
    // 0x6890a0: DecompressPointer r2
    //     0x6890a0: add             x2, x2, HEAP, lsl #32
    // 0x6890a4: r1 = Instance_CustomNum
    //     0x6890a4: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x6890a8: ldr             x1, [x1, #0x448]
    // 0x6890ac: r0 = mult2()
    //     0x6890ac: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6890b0: ldur            x1, [fp, #-0x18]
    // 0x6890b4: StoreField: r1->field_7 = r0
    //     0x6890b4: stur            w0, [x1, #7]
    //     0x6890b8: ldurb           w16, [x1, #-1]
    //     0x6890bc: ldurb           w17, [x0, #-1]
    //     0x6890c0: and             x16, x17, x16, lsr #2
    //     0x6890c4: tst             x16, HEAP, lsr #32
    //     0x6890c8: b.eq            #0x6890d0
    //     0x6890cc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6890d0: ldur            x1, [fp, #-8]
    // 0x6890d4: r2 = 20
    //     0x6890d4: movz            x2, #0x14
    // 0x6890d8: r0 = _getValueOrData()
    //     0x6890d8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6890dc: mov             x1, x0
    // 0x6890e0: ldur            x0, [fp, #-8]
    // 0x6890e4: LoadField: r2 = r0->field_f
    //     0x6890e4: ldur            w2, [x0, #0xf]
    // 0x6890e8: DecompressPointer r2
    //     0x6890e8: add             x2, x2, HEAP, lsl #32
    // 0x6890ec: cmp             w2, w1
    // 0x6890f0: b.ne            #0x6890fc
    // 0x6890f4: r3 = Null
    //     0x6890f4: mov             x3, NULL
    // 0x6890f8: b               #0x689100
    // 0x6890fc: mov             x3, x1
    // 0x689100: stur            x3, [fp, #-0x18]
    // 0x689104: cmp             w3, NULL
    // 0x689108: b.eq            #0x689a28
    // 0x68910c: mov             x1, x0
    // 0x689110: r2 = 20
    //     0x689110: movz            x2, #0x14
    // 0x689114: r0 = _getValueOrData()
    //     0x689114: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689118: mov             x1, x0
    // 0x68911c: ldur            x0, [fp, #-8]
    // 0x689120: LoadField: r2 = r0->field_f
    //     0x689120: ldur            w2, [x0, #0xf]
    // 0x689124: DecompressPointer r2
    //     0x689124: add             x2, x2, HEAP, lsl #32
    // 0x689128: cmp             w2, w1
    // 0x68912c: b.ne            #0x689134
    // 0x689130: r1 = Null
    //     0x689130: mov             x1, NULL
    // 0x689134: ldur            x3, [fp, #-0x18]
    // 0x689138: cmp             w1, NULL
    // 0x68913c: b.eq            #0x689a2c
    // 0x689140: LoadField: r2 = r1->field_7
    //     0x689140: ldur            w2, [x1, #7]
    // 0x689144: DecompressPointer r2
    //     0x689144: add             x2, x2, HEAP, lsl #32
    // 0x689148: r1 = Instance_CustomNum
    //     0x689148: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x68914c: ldr             x1, [x1, #0x448]
    // 0x689150: r0 = mult2()
    //     0x689150: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689154: ldur            x1, [fp, #-0x18]
    // 0x689158: StoreField: r1->field_7 = r0
    //     0x689158: stur            w0, [x1, #7]
    //     0x68915c: ldurb           w16, [x1, #-1]
    //     0x689160: ldurb           w17, [x0, #-1]
    //     0x689164: and             x16, x17, x16, lsr #2
    //     0x689168: tst             x16, HEAP, lsr #32
    //     0x68916c: b.eq            #0x689174
    //     0x689170: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x689174: ldur            x0, [fp, #-0x10]
    // 0x689178: LoadField: r1 = r0->field_43
    //     0x689178: ldur            w1, [x0, #0x43]
    // 0x68917c: DecompressPointer r1
    //     0x68917c: add             x1, x1, HEAP, lsl #32
    // 0x689180: r2 = 244
    //     0x689180: movz            x2, #0xf4
    // 0x689184: r0 = containsKey()
    //     0x689184: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x689188: tbnz            w0, #4, #0x6892e4
    // 0x68918c: ldur            x0, [fp, #-8]
    // 0x689190: mov             x1, x0
    // 0x689194: r2 = 2
    //     0x689194: movz            x2, #0x2
    // 0x689198: r0 = _getValueOrData()
    //     0x689198: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68919c: mov             x1, x0
    // 0x6891a0: ldur            x0, [fp, #-8]
    // 0x6891a4: LoadField: r2 = r0->field_f
    //     0x6891a4: ldur            w2, [x0, #0xf]
    // 0x6891a8: DecompressPointer r2
    //     0x6891a8: add             x2, x2, HEAP, lsl #32
    // 0x6891ac: cmp             w2, w1
    // 0x6891b0: b.ne            #0x6891bc
    // 0x6891b4: r3 = Null
    //     0x6891b4: mov             x3, NULL
    // 0x6891b8: b               #0x6891c0
    // 0x6891bc: mov             x3, x1
    // 0x6891c0: stur            x3, [fp, #-0x18]
    // 0x6891c4: cmp             w3, NULL
    // 0x6891c8: b.eq            #0x689a30
    // 0x6891cc: r1 = Null
    //     0x6891cc: mov             x1, NULL
    // 0x6891d0: r2 = 20000
    //     0x6891d0: movz            x2, #0x4e20
    // 0x6891d4: r0 = CustomNum()
    //     0x6891d4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6891d8: ldur            x1, [fp, #-8]
    // 0x6891dc: r2 = 2
    //     0x6891dc: movz            x2, #0x2
    // 0x6891e0: stur            x0, [fp, #-0x20]
    // 0x6891e4: r0 = _getValueOrData()
    //     0x6891e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6891e8: mov             x1, x0
    // 0x6891ec: ldur            x0, [fp, #-8]
    // 0x6891f0: LoadField: r2 = r0->field_f
    //     0x6891f0: ldur            w2, [x0, #0xf]
    // 0x6891f4: DecompressPointer r2
    //     0x6891f4: add             x2, x2, HEAP, lsl #32
    // 0x6891f8: cmp             w2, w1
    // 0x6891fc: b.ne            #0x689204
    // 0x689200: r1 = Null
    //     0x689200: mov             x1, NULL
    // 0x689204: ldur            x3, [fp, #-0x18]
    // 0x689208: cmp             w1, NULL
    // 0x68920c: b.eq            #0x689a34
    // 0x689210: LoadField: r2 = r1->field_f
    //     0x689210: ldur            w2, [x1, #0xf]
    // 0x689214: DecompressPointer r2
    //     0x689214: add             x2, x2, HEAP, lsl #32
    // 0x689218: ldur            x1, [fp, #-0x20]
    // 0x68921c: r0 = mult2()
    //     0x68921c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689220: ldur            x1, [fp, #-0x18]
    // 0x689224: StoreField: r1->field_f = r0
    //     0x689224: stur            w0, [x1, #0xf]
    //     0x689228: ldurb           w16, [x1, #-1]
    //     0x68922c: ldurb           w17, [x0, #-1]
    //     0x689230: and             x16, x17, x16, lsr #2
    //     0x689234: tst             x16, HEAP, lsr #32
    //     0x689238: b.eq            #0x689240
    //     0x68923c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x689240: ldur            x1, [fp, #-8]
    // 0x689244: r2 = 8
    //     0x689244: movz            x2, #0x8
    // 0x689248: r0 = _getValueOrData()
    //     0x689248: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68924c: mov             x1, x0
    // 0x689250: ldur            x0, [fp, #-8]
    // 0x689254: LoadField: r2 = r0->field_f
    //     0x689254: ldur            w2, [x0, #0xf]
    // 0x689258: DecompressPointer r2
    //     0x689258: add             x2, x2, HEAP, lsl #32
    // 0x68925c: cmp             w2, w1
    // 0x689260: b.ne            #0x68926c
    // 0x689264: r3 = Null
    //     0x689264: mov             x3, NULL
    // 0x689268: b               #0x689270
    // 0x68926c: mov             x3, x1
    // 0x689270: stur            x3, [fp, #-0x18]
    // 0x689274: cmp             w3, NULL
    // 0x689278: b.eq            #0x689a38
    // 0x68927c: mov             x1, x0
    // 0x689280: r2 = 8
    //     0x689280: movz            x2, #0x8
    // 0x689284: r0 = _getValueOrData()
    //     0x689284: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689288: mov             x1, x0
    // 0x68928c: ldur            x0, [fp, #-8]
    // 0x689290: LoadField: r2 = r0->field_f
    //     0x689290: ldur            w2, [x0, #0xf]
    // 0x689294: DecompressPointer r2
    //     0x689294: add             x2, x2, HEAP, lsl #32
    // 0x689298: cmp             w2, w1
    // 0x68929c: b.ne            #0x6892a4
    // 0x6892a0: r1 = Null
    //     0x6892a0: mov             x1, NULL
    // 0x6892a4: ldur            x3, [fp, #-0x18]
    // 0x6892a8: cmp             w1, NULL
    // 0x6892ac: b.eq            #0x689a3c
    // 0x6892b0: LoadField: r2 = r1->field_f
    //     0x6892b0: ldur            w2, [x1, #0xf]
    // 0x6892b4: DecompressPointer r2
    //     0x6892b4: add             x2, x2, HEAP, lsl #32
    // 0x6892b8: r1 = Instance_CustomNum
    //     0x6892b8: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x6892bc: ldr             x1, [x1, #0x448]
    // 0x6892c0: r0 = mult2()
    //     0x6892c0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6892c4: ldur            x1, [fp, #-0x18]
    // 0x6892c8: StoreField: r1->field_f = r0
    //     0x6892c8: stur            w0, [x1, #0xf]
    //     0x6892cc: ldurb           w16, [x1, #-1]
    //     0x6892d0: ldurb           w17, [x0, #-1]
    //     0x6892d4: and             x16, x17, x16, lsr #2
    //     0x6892d8: tst             x16, HEAP, lsr #32
    //     0x6892dc: b.eq            #0x6892e4
    //     0x6892e0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6892e4: ldur            x0, [fp, #-0x10]
    // 0x6892e8: LoadField: r1 = r0->field_43
    //     0x6892e8: ldur            w1, [x0, #0x43]
    // 0x6892ec: DecompressPointer r1
    //     0x6892ec: add             x1, x1, HEAP, lsl #32
    // 0x6892f0: r2 = 246
    //     0x6892f0: movz            x2, #0xf6
    // 0x6892f4: r0 = containsKey()
    //     0x6892f4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6892f8: tbnz            w0, #4, #0x6894ec
    // 0x6892fc: ldur            x0, [fp, #-8]
    // 0x689300: mov             x1, x0
    // 0x689304: r2 = 12
    //     0x689304: movz            x2, #0xc
    // 0x689308: r0 = _getValueOrData()
    //     0x689308: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68930c: mov             x1, x0
    // 0x689310: ldur            x0, [fp, #-8]
    // 0x689314: LoadField: r2 = r0->field_f
    //     0x689314: ldur            w2, [x0, #0xf]
    // 0x689318: DecompressPointer r2
    //     0x689318: add             x2, x2, HEAP, lsl #32
    // 0x68931c: cmp             w2, w1
    // 0x689320: b.ne            #0x68932c
    // 0x689324: r3 = Null
    //     0x689324: mov             x3, NULL
    // 0x689328: b               #0x689330
    // 0x68932c: mov             x3, x1
    // 0x689330: stur            x3, [fp, #-0x18]
    // 0x689334: cmp             w3, NULL
    // 0x689338: b.eq            #0x689a40
    // 0x68933c: mov             x1, x0
    // 0x689340: r2 = 12
    //     0x689340: movz            x2, #0xc
    // 0x689344: r0 = _getValueOrData()
    //     0x689344: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689348: mov             x1, x0
    // 0x68934c: ldur            x0, [fp, #-8]
    // 0x689350: LoadField: r2 = r0->field_f
    //     0x689350: ldur            w2, [x0, #0xf]
    // 0x689354: DecompressPointer r2
    //     0x689354: add             x2, x2, HEAP, lsl #32
    // 0x689358: cmp             w2, w1
    // 0x68935c: b.ne            #0x689364
    // 0x689360: r1 = Null
    //     0x689360: mov             x1, NULL
    // 0x689364: ldur            x3, [fp, #-0x18]
    // 0x689368: cmp             w1, NULL
    // 0x68936c: b.eq            #0x689a44
    // 0x689370: LoadField: r2 = r1->field_b
    //     0x689370: ldur            w2, [x1, #0xb]
    // 0x689374: DecompressPointer r2
    //     0x689374: add             x2, x2, HEAP, lsl #32
    // 0x689378: r1 = Instance_CustomNum
    //     0x689378: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x68937c: ldr             x1, [x1, #0xce0]
    // 0x689380: r0 = mult2()
    //     0x689380: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689384: ldur            x1, [fp, #-0x18]
    // 0x689388: StoreField: r1->field_b = r0
    //     0x689388: stur            w0, [x1, #0xb]
    //     0x68938c: ldurb           w16, [x1, #-1]
    //     0x689390: ldurb           w17, [x0, #-1]
    //     0x689394: and             x16, x17, x16, lsr #2
    //     0x689398: tst             x16, HEAP, lsr #32
    //     0x68939c: b.eq            #0x6893a4
    //     0x6893a0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6893a4: ldur            x1, [fp, #-8]
    // 0x6893a8: r2 = 16
    //     0x6893a8: movz            x2, #0x10
    // 0x6893ac: r0 = _getValueOrData()
    //     0x6893ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6893b0: mov             x1, x0
    // 0x6893b4: ldur            x0, [fp, #-8]
    // 0x6893b8: LoadField: r2 = r0->field_f
    //     0x6893b8: ldur            w2, [x0, #0xf]
    // 0x6893bc: DecompressPointer r2
    //     0x6893bc: add             x2, x2, HEAP, lsl #32
    // 0x6893c0: cmp             w2, w1
    // 0x6893c4: b.ne            #0x6893d0
    // 0x6893c8: r3 = Null
    //     0x6893c8: mov             x3, NULL
    // 0x6893cc: b               #0x6893d4
    // 0x6893d0: mov             x3, x1
    // 0x6893d4: stur            x3, [fp, #-0x18]
    // 0x6893d8: cmp             w3, NULL
    // 0x6893dc: b.eq            #0x689a48
    // 0x6893e0: mov             x1, x0
    // 0x6893e4: r2 = 16
    //     0x6893e4: movz            x2, #0x10
    // 0x6893e8: r0 = _getValueOrData()
    //     0x6893e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6893ec: mov             x1, x0
    // 0x6893f0: ldur            x0, [fp, #-8]
    // 0x6893f4: LoadField: r2 = r0->field_f
    //     0x6893f4: ldur            w2, [x0, #0xf]
    // 0x6893f8: DecompressPointer r2
    //     0x6893f8: add             x2, x2, HEAP, lsl #32
    // 0x6893fc: cmp             w2, w1
    // 0x689400: b.ne            #0x689408
    // 0x689404: r1 = Null
    //     0x689404: mov             x1, NULL
    // 0x689408: ldur            x3, [fp, #-0x18]
    // 0x68940c: cmp             w1, NULL
    // 0x689410: b.eq            #0x689a4c
    // 0x689414: LoadField: r2 = r1->field_b
    //     0x689414: ldur            w2, [x1, #0xb]
    // 0x689418: DecompressPointer r2
    //     0x689418: add             x2, x2, HEAP, lsl #32
    // 0x68941c: r1 = Instance_CustomNum
    //     0x68941c: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x689420: ldr             x1, [x1, #0x6f0]
    // 0x689424: r0 = mult2()
    //     0x689424: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689428: ldur            x1, [fp, #-0x18]
    // 0x68942c: StoreField: r1->field_b = r0
    //     0x68942c: stur            w0, [x1, #0xb]
    //     0x689430: ldurb           w16, [x1, #-1]
    //     0x689434: ldurb           w17, [x0, #-1]
    //     0x689438: and             x16, x17, x16, lsr #2
    //     0x68943c: tst             x16, HEAP, lsr #32
    //     0x689440: b.eq            #0x689448
    //     0x689444: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x689448: ldur            x1, [fp, #-8]
    // 0x68944c: r2 = 18
    //     0x68944c: movz            x2, #0x12
    // 0x689450: r0 = _getValueOrData()
    //     0x689450: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689454: mov             x1, x0
    // 0x689458: ldur            x0, [fp, #-8]
    // 0x68945c: LoadField: r2 = r0->field_f
    //     0x68945c: ldur            w2, [x0, #0xf]
    // 0x689460: DecompressPointer r2
    //     0x689460: add             x2, x2, HEAP, lsl #32
    // 0x689464: cmp             w2, w1
    // 0x689468: b.ne            #0x689474
    // 0x68946c: r3 = Null
    //     0x68946c: mov             x3, NULL
    // 0x689470: b               #0x689478
    // 0x689474: mov             x3, x1
    // 0x689478: stur            x3, [fp, #-0x18]
    // 0x68947c: cmp             w3, NULL
    // 0x689480: b.eq            #0x689a50
    // 0x689484: mov             x1, x0
    // 0x689488: r2 = 18
    //     0x689488: movz            x2, #0x12
    // 0x68948c: r0 = _getValueOrData()
    //     0x68948c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689490: mov             x1, x0
    // 0x689494: ldur            x0, [fp, #-8]
    // 0x689498: LoadField: r2 = r0->field_f
    //     0x689498: ldur            w2, [x0, #0xf]
    // 0x68949c: DecompressPointer r2
    //     0x68949c: add             x2, x2, HEAP, lsl #32
    // 0x6894a0: cmp             w2, w1
    // 0x6894a4: b.ne            #0x6894ac
    // 0x6894a8: r1 = Null
    //     0x6894a8: mov             x1, NULL
    // 0x6894ac: ldur            x3, [fp, #-0x18]
    // 0x6894b0: cmp             w1, NULL
    // 0x6894b4: b.eq            #0x689a54
    // 0x6894b8: LoadField: r2 = r1->field_b
    //     0x6894b8: ldur            w2, [x1, #0xb]
    // 0x6894bc: DecompressPointer r2
    //     0x6894bc: add             x2, x2, HEAP, lsl #32
    // 0x6894c0: r1 = Instance_CustomNum
    //     0x6894c0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x6894c4: ldr             x1, [x1, #0xce0]
    // 0x6894c8: r0 = mult2()
    //     0x6894c8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6894cc: ldur            x1, [fp, #-0x18]
    // 0x6894d0: StoreField: r1->field_b = r0
    //     0x6894d0: stur            w0, [x1, #0xb]
    //     0x6894d4: ldurb           w16, [x1, #-1]
    //     0x6894d8: ldurb           w17, [x0, #-1]
    //     0x6894dc: and             x16, x17, x16, lsr #2
    //     0x6894e0: tst             x16, HEAP, lsr #32
    //     0x6894e4: b.eq            #0x6894ec
    //     0x6894e8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6894ec: ldur            x0, [fp, #-0x10]
    // 0x6894f0: LoadField: r1 = r0->field_43
    //     0x6894f0: ldur            w1, [x0, #0x43]
    // 0x6894f4: DecompressPointer r1
    //     0x6894f4: add             x1, x1, HEAP, lsl #32
    // 0x6894f8: r2 = 248
    //     0x6894f8: movz            x2, #0xf8
    // 0x6894fc: r0 = containsKey()
    //     0x6894fc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x689500: tbnz            w0, #4, #0x6896f4
    // 0x689504: ldur            x0, [fp, #-8]
    // 0x689508: mov             x1, x0
    // 0x68950c: r2 = 2
    //     0x68950c: movz            x2, #0x2
    // 0x689510: r0 = _getValueOrData()
    //     0x689510: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689514: mov             x1, x0
    // 0x689518: ldur            x0, [fp, #-8]
    // 0x68951c: LoadField: r2 = r0->field_f
    //     0x68951c: ldur            w2, [x0, #0xf]
    // 0x689520: DecompressPointer r2
    //     0x689520: add             x2, x2, HEAP, lsl #32
    // 0x689524: cmp             w2, w1
    // 0x689528: b.ne            #0x689534
    // 0x68952c: r3 = Null
    //     0x68952c: mov             x3, NULL
    // 0x689530: b               #0x689538
    // 0x689534: mov             x3, x1
    // 0x689538: stur            x3, [fp, #-0x18]
    // 0x68953c: cmp             w3, NULL
    // 0x689540: b.eq            #0x689a58
    // 0x689544: mov             x1, x0
    // 0x689548: r2 = 2
    //     0x689548: movz            x2, #0x2
    // 0x68954c: r0 = _getValueOrData()
    //     0x68954c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689550: mov             x1, x0
    // 0x689554: ldur            x0, [fp, #-8]
    // 0x689558: LoadField: r2 = r0->field_f
    //     0x689558: ldur            w2, [x0, #0xf]
    // 0x68955c: DecompressPointer r2
    //     0x68955c: add             x2, x2, HEAP, lsl #32
    // 0x689560: cmp             w2, w1
    // 0x689564: b.ne            #0x68956c
    // 0x689568: r1 = Null
    //     0x689568: mov             x1, NULL
    // 0x68956c: ldur            x3, [fp, #-0x18]
    // 0x689570: cmp             w1, NULL
    // 0x689574: b.eq            #0x689a5c
    // 0x689578: LoadField: r2 = r1->field_f
    //     0x689578: ldur            w2, [x1, #0xf]
    // 0x68957c: DecompressPointer r2
    //     0x68957c: add             x2, x2, HEAP, lsl #32
    // 0x689580: r1 = Instance_CustomNum
    //     0x689580: add             x1, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x689584: ldr             x1, [x1, #0x2a0]
    // 0x689588: r0 = mult2()
    //     0x689588: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68958c: ldur            x1, [fp, #-0x18]
    // 0x689590: StoreField: r1->field_f = r0
    //     0x689590: stur            w0, [x1, #0xf]
    //     0x689594: ldurb           w16, [x1, #-1]
    //     0x689598: ldurb           w17, [x0, #-1]
    //     0x68959c: and             x16, x17, x16, lsr #2
    //     0x6895a0: tst             x16, HEAP, lsr #32
    //     0x6895a4: b.eq            #0x6895ac
    //     0x6895a8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6895ac: ldur            x1, [fp, #-8]
    // 0x6895b0: r2 = 8
    //     0x6895b0: movz            x2, #0x8
    // 0x6895b4: r0 = _getValueOrData()
    //     0x6895b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6895b8: mov             x1, x0
    // 0x6895bc: ldur            x0, [fp, #-8]
    // 0x6895c0: LoadField: r2 = r0->field_f
    //     0x6895c0: ldur            w2, [x0, #0xf]
    // 0x6895c4: DecompressPointer r2
    //     0x6895c4: add             x2, x2, HEAP, lsl #32
    // 0x6895c8: cmp             w2, w1
    // 0x6895cc: b.ne            #0x6895d8
    // 0x6895d0: r3 = Null
    //     0x6895d0: mov             x3, NULL
    // 0x6895d4: b               #0x6895dc
    // 0x6895d8: mov             x3, x1
    // 0x6895dc: stur            x3, [fp, #-0x18]
    // 0x6895e0: cmp             w3, NULL
    // 0x6895e4: b.eq            #0x689a60
    // 0x6895e8: mov             x1, x0
    // 0x6895ec: r2 = 8
    //     0x6895ec: movz            x2, #0x8
    // 0x6895f0: r0 = _getValueOrData()
    //     0x6895f0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6895f4: mov             x1, x0
    // 0x6895f8: ldur            x0, [fp, #-8]
    // 0x6895fc: LoadField: r2 = r0->field_f
    //     0x6895fc: ldur            w2, [x0, #0xf]
    // 0x689600: DecompressPointer r2
    //     0x689600: add             x2, x2, HEAP, lsl #32
    // 0x689604: cmp             w2, w1
    // 0x689608: b.ne            #0x689610
    // 0x68960c: r1 = Null
    //     0x68960c: mov             x1, NULL
    // 0x689610: ldur            x3, [fp, #-0x18]
    // 0x689614: cmp             w1, NULL
    // 0x689618: b.eq            #0x689a64
    // 0x68961c: LoadField: r2 = r1->field_f
    //     0x68961c: ldur            w2, [x1, #0xf]
    // 0x689620: DecompressPointer r2
    //     0x689620: add             x2, x2, HEAP, lsl #32
    // 0x689624: r1 = Instance_CustomNum
    //     0x689624: add             x1, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x689628: ldr             x1, [x1, #0x2a0]
    // 0x68962c: r0 = mult2()
    //     0x68962c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689630: ldur            x1, [fp, #-0x18]
    // 0x689634: StoreField: r1->field_f = r0
    //     0x689634: stur            w0, [x1, #0xf]
    //     0x689638: ldurb           w16, [x1, #-1]
    //     0x68963c: ldurb           w17, [x0, #-1]
    //     0x689640: and             x16, x17, x16, lsr #2
    //     0x689644: tst             x16, HEAP, lsr #32
    //     0x689648: b.eq            #0x689650
    //     0x68964c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x689650: ldur            x1, [fp, #-8]
    // 0x689654: r2 = 10
    //     0x689654: movz            x2, #0xa
    // 0x689658: r0 = _getValueOrData()
    //     0x689658: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68965c: mov             x1, x0
    // 0x689660: ldur            x0, [fp, #-8]
    // 0x689664: LoadField: r2 = r0->field_f
    //     0x689664: ldur            w2, [x0, #0xf]
    // 0x689668: DecompressPointer r2
    //     0x689668: add             x2, x2, HEAP, lsl #32
    // 0x68966c: cmp             w2, w1
    // 0x689670: b.ne            #0x68967c
    // 0x689674: r3 = Null
    //     0x689674: mov             x3, NULL
    // 0x689678: b               #0x689680
    // 0x68967c: mov             x3, x1
    // 0x689680: stur            x3, [fp, #-0x18]
    // 0x689684: cmp             w3, NULL
    // 0x689688: b.eq            #0x689a68
    // 0x68968c: mov             x1, x0
    // 0x689690: r2 = 10
    //     0x689690: movz            x2, #0xa
    // 0x689694: r0 = _getValueOrData()
    //     0x689694: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689698: mov             x1, x0
    // 0x68969c: ldur            x0, [fp, #-8]
    // 0x6896a0: LoadField: r2 = r0->field_f
    //     0x6896a0: ldur            w2, [x0, #0xf]
    // 0x6896a4: DecompressPointer r2
    //     0x6896a4: add             x2, x2, HEAP, lsl #32
    // 0x6896a8: cmp             w2, w1
    // 0x6896ac: b.ne            #0x6896b4
    // 0x6896b0: r1 = Null
    //     0x6896b0: mov             x1, NULL
    // 0x6896b4: ldur            x3, [fp, #-0x18]
    // 0x6896b8: cmp             w1, NULL
    // 0x6896bc: b.eq            #0x689a6c
    // 0x6896c0: LoadField: r2 = r1->field_f
    //     0x6896c0: ldur            w2, [x1, #0xf]
    // 0x6896c4: DecompressPointer r2
    //     0x6896c4: add             x2, x2, HEAP, lsl #32
    // 0x6896c8: r1 = Instance_CustomNum
    //     0x6896c8: add             x1, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x6896cc: ldr             x1, [x1, #0x2a0]
    // 0x6896d0: r0 = mult2()
    //     0x6896d0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6896d4: ldur            x1, [fp, #-0x18]
    // 0x6896d8: StoreField: r1->field_f = r0
    //     0x6896d8: stur            w0, [x1, #0xf]
    //     0x6896dc: ldurb           w16, [x1, #-1]
    //     0x6896e0: ldurb           w17, [x0, #-1]
    //     0x6896e4: and             x16, x17, x16, lsr #2
    //     0x6896e8: tst             x16, HEAP, lsr #32
    //     0x6896ec: b.eq            #0x6896f4
    //     0x6896f0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6896f4: ldur            x0, [fp, #-0x10]
    // 0x6896f8: LoadField: r1 = r0->field_43
    //     0x6896f8: ldur            w1, [x0, #0x43]
    // 0x6896fc: DecompressPointer r1
    //     0x6896fc: add             x1, x1, HEAP, lsl #32
    // 0x689700: r2 = 252
    //     0x689700: movz            x2, #0xfc
    // 0x689704: r0 = containsKey()
    //     0x689704: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x689708: tbnz            w0, #4, #0x689858
    // 0x68970c: ldur            x0, [fp, #-8]
    // 0x689710: mov             x1, x0
    // 0x689714: r2 = 2
    //     0x689714: movz            x2, #0x2
    // 0x689718: r0 = _getValueOrData()
    //     0x689718: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68971c: mov             x1, x0
    // 0x689720: ldur            x0, [fp, #-8]
    // 0x689724: LoadField: r2 = r0->field_f
    //     0x689724: ldur            w2, [x0, #0xf]
    // 0x689728: DecompressPointer r2
    //     0x689728: add             x2, x2, HEAP, lsl #32
    // 0x68972c: cmp             w2, w1
    // 0x689730: b.ne            #0x68973c
    // 0x689734: r3 = Null
    //     0x689734: mov             x3, NULL
    // 0x689738: b               #0x689740
    // 0x68973c: mov             x3, x1
    // 0x689740: stur            x3, [fp, #-0x10]
    // 0x689744: cmp             w3, NULL
    // 0x689748: b.eq            #0x689a70
    // 0x68974c: mov             x1, x0
    // 0x689750: r2 = 2
    //     0x689750: movz            x2, #0x2
    // 0x689754: r0 = _getValueOrData()
    //     0x689754: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689758: mov             x1, x0
    // 0x68975c: ldur            x0, [fp, #-8]
    // 0x689760: LoadField: r2 = r0->field_f
    //     0x689760: ldur            w2, [x0, #0xf]
    // 0x689764: DecompressPointer r2
    //     0x689764: add             x2, x2, HEAP, lsl #32
    // 0x689768: cmp             w2, w1
    // 0x68976c: b.ne            #0x689774
    // 0x689770: r1 = Null
    //     0x689770: mov             x1, NULL
    // 0x689774: ldur            x3, [fp, #-0x10]
    // 0x689778: cmp             w1, NULL
    // 0x68977c: b.eq            #0x689a74
    // 0x689780: LoadField: r2 = r1->field_f
    //     0x689780: ldur            w2, [x1, #0xf]
    // 0x689784: DecompressPointer r2
    //     0x689784: add             x2, x2, HEAP, lsl #32
    // 0x689788: r1 = Instance_CustomNum
    //     0x689788: add             x1, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x68978c: ldr             x1, [x1, #0x2a0]
    // 0x689790: r0 = mult2()
    //     0x689790: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689794: ldur            x1, [fp, #-0x10]
    // 0x689798: StoreField: r1->field_f = r0
    //     0x689798: stur            w0, [x1, #0xf]
    //     0x68979c: ldurb           w16, [x1, #-1]
    //     0x6897a0: ldurb           w17, [x0, #-1]
    //     0x6897a4: and             x16, x17, x16, lsr #2
    //     0x6897a8: tst             x16, HEAP, lsr #32
    //     0x6897ac: b.eq            #0x6897b4
    //     0x6897b0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6897b4: ldur            x1, [fp, #-8]
    // 0x6897b8: r2 = 4
    //     0x6897b8: movz            x2, #0x4
    // 0x6897bc: r0 = _getValueOrData()
    //     0x6897bc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6897c0: mov             x1, x0
    // 0x6897c4: ldur            x0, [fp, #-8]
    // 0x6897c8: LoadField: r2 = r0->field_f
    //     0x6897c8: ldur            w2, [x0, #0xf]
    // 0x6897cc: DecompressPointer r2
    //     0x6897cc: add             x2, x2, HEAP, lsl #32
    // 0x6897d0: cmp             w2, w1
    // 0x6897d4: b.ne            #0x6897e0
    // 0x6897d8: r3 = Null
    //     0x6897d8: mov             x3, NULL
    // 0x6897dc: b               #0x6897e4
    // 0x6897e0: mov             x3, x1
    // 0x6897e4: stur            x3, [fp, #-0x10]
    // 0x6897e8: cmp             w3, NULL
    // 0x6897ec: b.eq            #0x689a78
    // 0x6897f0: mov             x1, x0
    // 0x6897f4: r2 = 8
    //     0x6897f4: movz            x2, #0x8
    // 0x6897f8: r0 = _getValueOrData()
    //     0x6897f8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6897fc: mov             x1, x0
    // 0x689800: ldur            x0, [fp, #-8]
    // 0x689804: LoadField: r2 = r0->field_f
    //     0x689804: ldur            w2, [x0, #0xf]
    // 0x689808: DecompressPointer r2
    //     0x689808: add             x2, x2, HEAP, lsl #32
    // 0x68980c: cmp             w2, w1
    // 0x689810: b.ne            #0x689818
    // 0x689814: r1 = Null
    //     0x689814: mov             x1, NULL
    // 0x689818: ldur            x0, [fp, #-0x10]
    // 0x68981c: cmp             w1, NULL
    // 0x689820: b.eq            #0x689a7c
    // 0x689824: LoadField: r2 = r1->field_f
    //     0x689824: ldur            w2, [x1, #0xf]
    // 0x689828: DecompressPointer r2
    //     0x689828: add             x2, x2, HEAP, lsl #32
    // 0x68982c: r1 = Instance_CustomNum
    //     0x68982c: add             x1, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x689830: ldr             x1, [x1, #0x2a0]
    // 0x689834: r0 = mult2()
    //     0x689834: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x689838: ldur            x1, [fp, #-0x10]
    // 0x68983c: StoreField: r1->field_f = r0
    //     0x68983c: stur            w0, [x1, #0xf]
    //     0x689840: ldurb           w16, [x1, #-1]
    //     0x689844: ldurb           w17, [x0, #-1]
    //     0x689848: and             x16, x17, x16, lsr #2
    //     0x68984c: tst             x16, HEAP, lsr #32
    //     0x689850: b.eq            #0x689858
    //     0x689854: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x689858: r0 = Null
    //     0x689858: mov             x0, NULL
    // 0x68985c: LeaveFrame
    //     0x68985c: mov             SP, fp
    //     0x689860: ldp             fp, lr, [SP], #0x10
    // 0x689864: ret
    //     0x689864: ret             
    // 0x689868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x689868: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68986c: b               #0x6868fc
    // 0x689870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689870: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689874: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689878: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689878: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68987c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68987c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689880: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689880: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689884: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689888: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689888: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68988c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68988c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689890: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689894: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689898: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68989c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68989c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898a0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898a4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898a8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898ac: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898b0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898b4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898b8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898bc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898c0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898c4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898c8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898cc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898d0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898d4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898d8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898dc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898e0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898e4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898e8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898ec: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898f0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898f4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898f8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6898fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6898fc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689900: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689904: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689908: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68990c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68990c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689910: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689910: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689914: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689914: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689918: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68991c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68991c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689920: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689920: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689924: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689928: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689928: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68992c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68992c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689930: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689930: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689934: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689934: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689938: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689938: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68993c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68993c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689940: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689940: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689944: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689944: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689948: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689948: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68994c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68994c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689950: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689950: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689954: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689954: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689958: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68995c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68995c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689960: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689964: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689968: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689968: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68996c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68996c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689970: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689974: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689978: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68997c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68997c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689980: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689980: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689984: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689988: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68998c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68998c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689990: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689994: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689998: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68999c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68999c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899a0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899a4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899a8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899ac: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899b0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899b4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899b8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899bc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899c0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899c4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899c8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899cc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899d0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899d4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899d8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899dc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899e0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899e4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899e8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899ec: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899f0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899f4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899f8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6899fc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a00: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a04: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a08: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a0c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a10: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a14: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a18: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a1c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a20: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a24: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a28: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a2c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a30: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a34: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a38: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a3c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a40: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a44: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a48: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a4c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a50: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a54: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a58: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a5c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a60: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a64: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a68: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a6c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a70: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a74: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a78: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689a7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689a7c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x699c00, size: 0xcc4
    // 0x699c00: EnterFrame
    //     0x699c00: stp             fp, lr, [SP, #-0x10]!
    //     0x699c04: mov             fp, SP
    // 0x699c08: AllocStack(0xb0)
    //     0x699c08: sub             SP, SP, #0xb0
    // 0x699c0c: SetupParameters(Chapter12GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x699c0c: mov             x0, x1
    //     0x699c10: stur            x1, [fp, #-8]
    //     0x699c14: stur            x2, [fp, #-0x10]
    // 0x699c18: CheckStackOverflow
    //     0x699c18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699c1c: cmp             SP, x16
    //     0x699c20: b.ls            #0x69a8b0
    // 0x699c24: r1 = 2
    //     0x699c24: movz            x1, #0x2
    // 0x699c28: r0 = AllocateContext()
    //     0x699c28: bl              #0x82637c  ; AllocateContextStub
    // 0x699c2c: mov             x3, x0
    // 0x699c30: ldur            x0, [fp, #-8]
    // 0x699c34: stur            x3, [fp, #-0x18]
    // 0x699c38: StoreField: r3->field_f = r0
    //     0x699c38: stur            w0, [x3, #0xf]
    // 0x699c3c: ldur            x1, [fp, #-0x10]
    // 0x699c40: StoreField: r3->field_13 = r1
    //     0x699c40: stur            w1, [x3, #0x13]
    // 0x699c44: mov             x2, x3
    // 0x699c48: r1 = Function '<anonymous closure>':.
    //     0x699c48: add             x1, PP, #0x29, lsl #12  ; [pp+0x29020] AnonymousClosure: (0x69b4e0), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x699c4c: ldr             x1, [x1, #0x20]
    // 0x699c50: r0 = AllocateClosure()
    //     0x699c50: bl              #0x826750  ; AllocateClosureStub
    // 0x699c54: ldur            x2, [fp, #-0x18]
    // 0x699c58: r1 = Function '<anonymous closure>':.
    //     0x699c58: add             x1, PP, #0x29, lsl #12  ; [pp+0x29028] AnonymousClosure: (0x69b494), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x699c5c: ldr             x1, [x1, #0x28]
    // 0x699c60: stur            x0, [fp, #-0x10]
    // 0x699c64: r0 = AllocateClosure()
    //     0x699c64: bl              #0x826750  ; AllocateClosureStub
    // 0x699c68: stur            x0, [fp, #-0x20]
    // 0x699c6c: r0 = ManualButton()
    //     0x699c6c: bl              #0x69a8c4  ; AllocateManualButtonStub -> ManualButton (size=0x24)
    // 0x699c70: ldur            x2, [fp, #-0x18]
    // 0x699c74: r1 = Function '<anonymous closure>':.
    //     0x699c74: add             x1, PP, #0x29, lsl #12  ; [pp+0x29030] AnonymousClosure: (0x69b2d0), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x699c78: ldr             x1, [x1, #0x30]
    // 0x699c7c: stur            x0, [fp, #-0x28]
    // 0x699c80: r0 = AllocateClosure()
    //     0x699c80: bl              #0x826750  ; AllocateClosureStub
    // 0x699c84: mov             x1, x0
    // 0x699c88: ldur            x0, [fp, #-0x28]
    // 0x699c8c: StoreField: r0->field_b = r1
    //     0x699c8c: stur            w1, [x0, #0xb]
    // 0x699c90: r1 = "Investigate"
    //     0x699c90: add             x1, PP, #0x29, lsl #12  ; [pp+0x29038] "Investigate"
    //     0x699c94: ldr             x1, [x1, #0x38]
    // 0x699c98: StoreField: r0->field_f = r1
    //     0x699c98: stur            w1, [x0, #0xf]
    // 0x699c9c: ldur            x2, [fp, #-0x10]
    // 0x699ca0: ldur            x3, [fp, #-0x20]
    // 0x699ca4: r0 = AllocateRecord2()
    //     0x699ca4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x699ca8: mov             x1, x0
    // 0x699cac: ldur            x0, [fp, #-0x28]
    // 0x699cb0: StoreField: r0->field_13 = r1
    //     0x699cb0: stur            w1, [x0, #0x13]
    // 0x699cb4: r1 = Instance_TextStyle
    //     0x699cb4: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d0] Obj!TextStyle@8490c1
    //     0x699cb8: ldr             x1, [x1, #0xd0]
    // 0x699cbc: ArrayStore: r0[0] = r1  ; List_4
    //     0x699cbc: stur            w1, [x0, #0x17]
    // 0x699cc0: r1 = Function '<anonymous closure>':.
    //     0x699cc0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29040] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x699cc4: ldr             x1, [x1, #0x40]
    // 0x699cc8: r2 = Null
    //     0x699cc8: mov             x2, NULL
    // 0x699ccc: r0 = AllocateClosure()
    //     0x699ccc: bl              #0x826750  ; AllocateClosureStub
    // 0x699cd0: r16 = false
    //     0x699cd0: add             x16, NULL, #0x30  ; false
    // 0x699cd4: str             x16, [SP]
    // 0x699cd8: ldur            x2, [fp, #-0x28]
    // 0x699cdc: mov             x5, x0
    // 0x699ce0: r1 = Null
    //     0x699ce0: mov             x1, NULL
    // 0x699ce4: r3 = "Chapter 12 Investigate"
    //     0x699ce4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29048] "Chapter 12 Investigate"
    //     0x699ce8: ldr             x3, [x3, #0x48]
    // 0x699cec: r4 = const [0, 0x5, 0x1, 0x4, drawBackground, 0x4, null]
    //     0x699cec: add             x4, PP, #0x29, lsl #12  ; [pp+0x29050] List(7) [0, 0x5, 0x1, 0x4, "drawBackground", 0x4, Null]
    //     0x699cf0: ldr             x4, [x4, #0x50]
    // 0x699cf4: r0 = IdleFragment()
    //     0x699cf4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x699cf8: r1 = <Widget>
    //     0x699cf8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x699cfc: r2 = 18
    //     0x699cfc: movz            x2, #0x12
    // 0x699d00: stur            x0, [fp, #-0x10]
    // 0x699d04: r0 = AllocateArray()
    //     0x699d04: bl              #0x82746c  ; AllocateArrayStub
    // 0x699d08: mov             x2, x0
    // 0x699d0c: ldur            x0, [fp, #-0x10]
    // 0x699d10: stur            x2, [fp, #-0x30]
    // 0x699d14: StoreField: r2->field_f = r0
    //     0x699d14: stur            w0, [x2, #0xf]
    // 0x699d18: ldur            x0, [fp, #-8]
    // 0x699d1c: LoadField: r3 = r0->field_37
    //     0x699d1c: ldur            w3, [x0, #0x37]
    // 0x699d20: DecompressPointer r3
    //     0x699d20: add             x3, x3, HEAP, lsl #32
    // 0x699d24: stur            x3, [fp, #-0x28]
    // 0x699d28: LoadField: r4 = r0->field_43
    //     0x699d28: ldur            w4, [x0, #0x43]
    // 0x699d2c: DecompressPointer r4
    //     0x699d2c: add             x4, x4, HEAP, lsl #32
    // 0x699d30: stur            x4, [fp, #-0x20]
    // 0x699d34: LoadField: r5 = r0->field_93
    //     0x699d34: ldur            w5, [x0, #0x93]
    // 0x699d38: DecompressPointer r5
    //     0x699d38: add             x5, x5, HEAP, lsl #32
    // 0x699d3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x699d40: cmp             w5, w16
    // 0x699d44: b.eq            #0x69a8b8
    // 0x699d48: stur            x5, [fp, #-0x10]
    // 0x699d4c: r1 = <Chapter12Stat>
    //     0x699d4c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x699d50: ldr             x1, [x1, #0xef0]
    // 0x699d54: r0 = UpgradeGroup()
    //     0x699d54: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x699d58: mov             x3, x0
    // 0x699d5c: r0 = 1
    //     0x699d5c: movz            x0, #0x1
    // 0x699d60: stur            x3, [fp, #-0x38]
    // 0x699d64: StoreField: r3->field_13 = r0
    //     0x699d64: stur            x0, [x3, #0x13]
    // 0x699d68: ldur            x1, [fp, #-0x10]
    // 0x699d6c: StoreField: r3->field_1b = r1
    //     0x699d6c: stur            w1, [x3, #0x1b]
    // 0x699d70: ldur            x1, [fp, #-0x28]
    // 0x699d74: StoreField: r3->field_1f = r1
    //     0x699d74: stur            w1, [x3, #0x1f]
    // 0x699d78: ldur            x1, [fp, #-0x20]
    // 0x699d7c: StoreField: r3->field_23 = r1
    //     0x699d7c: stur            w1, [x3, #0x23]
    // 0x699d80: r1 = Function '<anonymous closure>':.
    //     0x699d80: add             x1, PP, #0x29, lsl #12  ; [pp+0x29058] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x699d84: ldr             x1, [x1, #0x58]
    // 0x699d88: r2 = Null
    //     0x699d88: mov             x2, NULL
    // 0x699d8c: r0 = AllocateClosure()
    //     0x699d8c: bl              #0x826750  ; AllocateClosureStub
    // 0x699d90: mov             x1, x0
    // 0x699d94: ldur            x0, [fp, #-0x38]
    // 0x699d98: StoreField: r0->field_2b = r1
    //     0x699d98: stur            w1, [x0, #0x2b]
    // 0x699d9c: r1 = const [0x1, 0x2]
    //     0x699d9c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] List<int>(2)
    //     0x699da0: ldr             x1, [x1, #0x170]
    // 0x699da4: StoreField: r0->field_f = r1
    //     0x699da4: stur            w1, [x0, #0xf]
    // 0x699da8: r3 = true
    //     0x699da8: add             x3, NULL, #0x20  ; true
    // 0x699dac: StoreField: r0->field_27 = r3
    //     0x699dac: stur            w3, [x0, #0x27]
    // 0x699db0: r4 = Instance_UpgradeDisplayMode
    //     0x699db0: add             x4, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x699db4: ldr             x4, [x4, #0x608]
    // 0x699db8: StoreField: r0->field_2f = r4
    //     0x699db8: stur            w4, [x0, #0x2f]
    // 0x699dbc: r5 = false
    //     0x699dbc: add             x5, NULL, #0x30  ; false
    // 0x699dc0: StoreField: r0->field_33 = r5
    //     0x699dc0: stur            w5, [x0, #0x33]
    // 0x699dc4: ldur            x2, [fp, #-0x18]
    // 0x699dc8: r1 = Function '<anonymous closure>':.
    //     0x699dc8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29060] AnonymousClosure: (0x6999a8), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x699dcc: ldr             x1, [x1, #0x60]
    // 0x699dd0: r0 = AllocateClosure()
    //     0x699dd0: bl              #0x826750  ; AllocateClosureStub
    // 0x699dd4: ldur            x2, [fp, #-0x38]
    // 0x699dd8: mov             x5, x0
    // 0x699ddc: r1 = Null
    //     0x699ddc: mov             x1, NULL
    // 0x699de0: r3 = "Chapter 12 Upgrades 1"
    //     0x699de0: add             x3, PP, #0x29, lsl #12  ; [pp+0x29068] "Chapter 12 Upgrades 1"
    //     0x699de4: ldr             x3, [x3, #0x68]
    // 0x699de8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x699de8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x699dec: r0 = IdleFragment()
    //     0x699dec: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x699df0: ldur            x1, [fp, #-0x30]
    // 0x699df4: ArrayStore: r1[1] = r0  ; List_4
    //     0x699df4: add             x25, x1, #0x13
    //     0x699df8: str             w0, [x25]
    //     0x699dfc: tbz             w0, #0, #0x699e18
    //     0x699e00: ldurb           w16, [x1, #-1]
    //     0x699e04: ldurb           w17, [x0, #-1]
    //     0x699e08: and             x16, x17, x16, lsr #2
    //     0x699e0c: tst             x16, HEAP, lsr #32
    //     0x699e10: b.eq            #0x699e18
    //     0x699e14: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x699e18: ldur            x2, [fp, #-8]
    // 0x699e1c: LoadField: r0 = r2->field_2b
    //     0x699e1c: ldur            w0, [x2, #0x2b]
    // 0x699e20: DecompressPointer r0
    //     0x699e20: add             x0, x0, HEAP, lsl #32
    // 0x699e24: stur            x0, [fp, #-0x60]
    // 0x699e28: LoadField: r3 = r2->field_37
    //     0x699e28: ldur            w3, [x2, #0x37]
    // 0x699e2c: DecompressPointer r3
    //     0x699e2c: add             x3, x3, HEAP, lsl #32
    // 0x699e30: stur            x3, [fp, #-0x58]
    // 0x699e34: LoadField: r4 = r2->field_7
    //     0x699e34: ldur            w4, [x2, #7]
    // 0x699e38: DecompressPointer r4
    //     0x699e38: add             x4, x4, HEAP, lsl #32
    // 0x699e3c: stur            x4, [fp, #-0x50]
    // 0x699e40: LoadField: r5 = r2->field_4b
    //     0x699e40: ldur            w5, [x2, #0x4b]
    // 0x699e44: DecompressPointer r5
    //     0x699e44: add             x5, x5, HEAP, lsl #32
    // 0x699e48: stur            x5, [fp, #-0x48]
    // 0x699e4c: LoadField: r6 = r2->field_47
    //     0x699e4c: ldur            w6, [x2, #0x47]
    // 0x699e50: DecompressPointer r6
    //     0x699e50: add             x6, x6, HEAP, lsl #32
    // 0x699e54: stur            x6, [fp, #-0x40]
    // 0x699e58: LoadField: r7 = r2->field_53
    //     0x699e58: ldur            w7, [x2, #0x53]
    // 0x699e5c: DecompressPointer r7
    //     0x699e5c: add             x7, x7, HEAP, lsl #32
    // 0x699e60: stur            x7, [fp, #-0x38]
    // 0x699e64: LoadField: r8 = r2->field_33
    //     0x699e64: ldur            w8, [x2, #0x33]
    // 0x699e68: DecompressPointer r8
    //     0x699e68: add             x8, x8, HEAP, lsl #32
    // 0x699e6c: stur            x8, [fp, #-0x28]
    // 0x699e70: LoadField: r9 = r2->field_2f
    //     0x699e70: ldur            w9, [x2, #0x2f]
    // 0x699e74: DecompressPointer r9
    //     0x699e74: add             x9, x9, HEAP, lsl #32
    // 0x699e78: stur            x9, [fp, #-0x20]
    // 0x699e7c: LoadField: r10 = r2->field_9b
    //     0x699e7c: ldur            w10, [x2, #0x9b]
    // 0x699e80: DecompressPointer r10
    //     0x699e80: add             x10, x10, HEAP, lsl #32
    // 0x699e84: stur            x10, [fp, #-0x10]
    // 0x699e88: r1 = <Chapter12Stat>
    //     0x699e88: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x699e8c: ldr             x1, [x1, #0xef0]
    // 0x699e90: r0 = GeneratorGroup()
    //     0x699e90: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x699e94: mov             x3, x0
    // 0x699e98: ldur            x0, [fp, #-0x58]
    // 0x699e9c: stur            x3, [fp, #-0x68]
    // 0x699ea0: StoreField: r3->field_1f = r0
    //     0x699ea0: stur            w0, [x3, #0x1f]
    // 0x699ea4: ldur            x2, [fp, #-8]
    // 0x699ea8: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x699ea8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb38] AnonymousClosure: (0x3dac58), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getCostToBuyOneMoreGenerator (0x3da7a0)
    //     0x699eac: ldr             x1, [x1, #0xb38]
    // 0x699eb0: r0 = AllocateClosure()
    //     0x699eb0: bl              #0x826750  ; AllocateClosureStub
    // 0x699eb4: mov             x3, x0
    // 0x699eb8: ldur            x0, [fp, #-0x68]
    // 0x699ebc: stur            x3, [fp, #-0x58]
    // 0x699ec0: StoreField: r0->field_23 = r3
    //     0x699ec0: stur            w3, [x0, #0x23]
    // 0x699ec4: ldur            x2, [fp, #-8]
    // 0x699ec8: r1 = Function 'getGeneratorInfo':.
    //     0x699ec8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29070] AnonymousClosure: (0x69b294), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getGeneratorInfo (0x80d210)
    //     0x699ecc: ldr             x1, [x1, #0x70]
    // 0x699ed0: r0 = AllocateClosure()
    //     0x699ed0: bl              #0x826750  ; AllocateClosureStub
    // 0x699ed4: mov             x3, x0
    // 0x699ed8: ldur            x0, [fp, #-0x68]
    // 0x699edc: stur            x3, [fp, #-0x70]
    // 0x699ee0: StoreField: r0->field_27 = r3
    //     0x699ee0: stur            w3, [x0, #0x27]
    // 0x699ee4: ldur            x1, [fp, #-0x48]
    // 0x699ee8: StoreField: r0->field_2b = r1
    //     0x699ee8: stur            w1, [x0, #0x2b]
    // 0x699eec: ldur            x1, [fp, #-0x40]
    // 0x699ef0: StoreField: r0->field_2f = r1
    //     0x699ef0: stur            w1, [x0, #0x2f]
    // 0x699ef4: ldur            x1, [fp, #-0x38]
    // 0x699ef8: StoreField: r0->field_33 = r1
    //     0x699ef8: stur            w1, [x0, #0x33]
    // 0x699efc: r1 = Function '<anonymous closure>':.
    //     0x699efc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29078] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x699f00: ldr             x1, [x1, #0x78]
    // 0x699f04: r2 = Null
    //     0x699f04: mov             x2, NULL
    // 0x699f08: r0 = AllocateClosure()
    //     0x699f08: bl              #0x826750  ; AllocateClosureStub
    // 0x699f0c: mov             x1, x0
    // 0x699f10: ldur            x0, [fp, #-0x68]
    // 0x699f14: StoreField: r0->field_3b = r1
    //     0x699f14: stur            w1, [x0, #0x3b]
    // 0x699f18: ldur            x3, [fp, #-0x28]
    // 0x699f1c: StoreField: r0->field_43 = r3
    //     0x699f1c: stur            w3, [x0, #0x43]
    // 0x699f20: ldur            x4, [fp, #-0x20]
    // 0x699f24: StoreField: r0->field_47 = r4
    //     0x699f24: stur            w4, [x0, #0x47]
    // 0x699f28: ldur            x2, [fp, #-8]
    // 0x699f2c: r1 = Function 'buyGenerator':.
    //     0x699f2c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x699f30: ldr             x1, [x1, #0x108]
    // 0x699f34: r0 = AllocateClosure()
    //     0x699f34: bl              #0x826750  ; AllocateClosureStub
    // 0x699f38: mov             x3, x0
    // 0x699f3c: ldur            x0, [fp, #-0x68]
    // 0x699f40: stur            x3, [fp, #-0x38]
    // 0x699f44: StoreField: r0->field_5b = r3
    //     0x699f44: stur            w3, [x0, #0x5b]
    // 0x699f48: r1 = Function '<anonymous closure>':.
    //     0x699f48: add             x1, PP, #0x29, lsl #12  ; [pp+0x29080] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x699f4c: ldr             x1, [x1, #0x80]
    // 0x699f50: r2 = Null
    //     0x699f50: mov             x2, NULL
    // 0x699f54: r0 = AllocateClosure()
    //     0x699f54: bl              #0x826750  ; AllocateClosureStub
    // 0x699f58: mov             x1, x0
    // 0x699f5c: ldur            x0, [fp, #-0x68]
    // 0x699f60: ArrayStore: r0[0] = r1  ; List_4
    //     0x699f60: stur            w1, [x0, #0x17]
    // 0x699f64: r1 = Function '<anonymous closure>':.
    //     0x699f64: add             x1, PP, #0x29, lsl #12  ; [pp+0x29088] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x699f68: ldr             x1, [x1, #0x88]
    // 0x699f6c: r2 = Null
    //     0x699f6c: mov             x2, NULL
    // 0x699f70: r0 = AllocateClosure()
    //     0x699f70: bl              #0x826750  ; AllocateClosureStub
    // 0x699f74: mov             x1, x0
    // 0x699f78: ldur            x0, [fp, #-0x68]
    // 0x699f7c: StoreField: r0->field_1b = r1
    //     0x699f7c: stur            w1, [x0, #0x1b]
    // 0x699f80: ldur            x2, [fp, #-8]
    // 0x699f84: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x699f84: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x699f88: ldr             x1, [x1, #0x120]
    // 0x699f8c: r0 = AllocateClosure()
    //     0x699f8c: bl              #0x826750  ; AllocateClosureStub
    // 0x699f90: mov             x4, x0
    // 0x699f94: ldur            x0, [fp, #-0x68]
    // 0x699f98: stur            x4, [fp, #-0x40]
    // 0x699f9c: StoreField: r0->field_57 = r4
    //     0x699f9c: stur            w4, [x0, #0x57]
    // 0x699fa0: r1 = const [0x1, 0x2, 0x3, 0x4, 0x5]
    //     0x699fa0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] List<int>(5)
    //     0x699fa4: ldr             x1, [x1, #0x128]
    // 0x699fa8: StoreField: r0->field_53 = r1
    //     0x699fa8: stur            w1, [x0, #0x53]
    // 0x699fac: ldur            x2, [fp, #-8]
    // 0x699fb0: ldur            x3, [fp, #-0x50]
    // 0x699fb4: r1 = Function 'getGeneratorSingleYieldsBoosted':.
    //     0x699fb4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0x54a720), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted (0x54a520)
    //     0x699fb8: ldr             x1, [x1, #0x130]
    // 0x699fbc: r0 = AllocateClosureTA()
    //     0x699fbc: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x699fc0: mov             x4, x0
    // 0x699fc4: ldur            x0, [fp, #-0x68]
    // 0x699fc8: stur            x4, [fp, #-0x48]
    // 0x699fcc: StoreField: r0->field_6b = r4
    //     0x699fcc: stur            w4, [x0, #0x6b]
    // 0x699fd0: ldur            x1, [fp, #-0x60]
    // 0x699fd4: StoreField: r0->field_4b = r1
    //     0x699fd4: stur            w1, [x0, #0x4b]
    // 0x699fd8: ldur            x1, [fp, #-0x10]
    // 0x699fdc: StoreField: r0->field_67 = r1
    //     0x699fdc: stur            w1, [x0, #0x67]
    // 0x699fe0: ldur            x2, [fp, #-8]
    // 0x699fe4: ldur            x3, [fp, #-0x50]
    // 0x699fe8: r1 = Function 'getGeneratorBaseCost':.
    //     0x699fe8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x699fec: ldr             x1, [x1, #0x138]
    // 0x699ff0: r0 = AllocateClosureTA()
    //     0x699ff0: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x699ff4: mov             x3, x0
    // 0x699ff8: ldur            x0, [fp, #-0x68]
    // 0x699ffc: stur            x3, [fp, #-0x10]
    // 0x69a000: StoreField: r0->field_77 = r3
    //     0x69a000: stur            w3, [x0, #0x77]
    // 0x69a004: ldur            x2, [fp, #-8]
    // 0x69a008: r1 = Function 'getGeneratorMultiplier':.
    //     0x69a008: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x69a00c: ldr             x1, [x1, #0x140]
    // 0x69a010: r0 = AllocateClosure()
    //     0x69a010: bl              #0x826750  ; AllocateClosureStub
    // 0x69a014: mov             x3, x0
    // 0x69a018: ldur            x0, [fp, #-0x68]
    // 0x69a01c: stur            x3, [fp, #-0x50]
    // 0x69a020: StoreField: r0->field_7b = r3
    //     0x69a020: stur            w3, [x0, #0x7b]
    // 0x69a024: r4 = "Chapter 12 Generators 1"
    //     0x69a024: add             x4, PP, #0x29, lsl #12  ; [pp+0x29090] "Chapter 12 Generators 1"
    //     0x69a028: ldr             x4, [x4, #0x90]
    // 0x69a02c: StoreField: r0->field_73 = r4
    //     0x69a02c: stur            w4, [x0, #0x73]
    // 0x69a030: ldur            x2, [fp, #-0x18]
    // 0x69a034: r1 = Function '<anonymous closure>':.
    //     0x69a034: add             x1, PP, #0x29, lsl #12  ; [pp+0x29098] AnonymousClosure: (0x69b214), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a038: ldr             x1, [x1, #0x98]
    // 0x69a03c: r0 = AllocateClosure()
    //     0x69a03c: bl              #0x826750  ; AllocateClosureStub
    // 0x69a040: ldur            x2, [fp, #-0x68]
    // 0x69a044: mov             x5, x0
    // 0x69a048: r1 = Null
    //     0x69a048: mov             x1, NULL
    // 0x69a04c: r3 = "Chapter 12 Generators 1"
    //     0x69a04c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29090] "Chapter 12 Generators 1"
    //     0x69a050: ldr             x3, [x3, #0x90]
    // 0x69a054: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69a054: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69a058: r0 = IdleFragment()
    //     0x69a058: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a05c: ldur            x1, [fp, #-0x30]
    // 0x69a060: ArrayStore: r1[2] = r0  ; List_4
    //     0x69a060: add             x25, x1, #0x17
    //     0x69a064: str             w0, [x25]
    //     0x69a068: tbz             w0, #0, #0x69a084
    //     0x69a06c: ldurb           w16, [x1, #-1]
    //     0x69a070: ldurb           w17, [x0, #-1]
    //     0x69a074: and             x16, x17, x16, lsr #2
    //     0x69a078: tst             x16, HEAP, lsr #32
    //     0x69a07c: b.eq            #0x69a084
    //     0x69a080: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a084: ldur            x2, [fp, #-8]
    // 0x69a088: LoadField: r0 = r2->field_37
    //     0x69a088: ldur            w0, [x2, #0x37]
    // 0x69a08c: DecompressPointer r0
    //     0x69a08c: add             x0, x0, HEAP, lsl #32
    // 0x69a090: stur            x0, [fp, #-0x78]
    // 0x69a094: LoadField: r3 = r2->field_43
    //     0x69a094: ldur            w3, [x2, #0x43]
    // 0x69a098: DecompressPointer r3
    //     0x69a098: add             x3, x3, HEAP, lsl #32
    // 0x69a09c: stur            x3, [fp, #-0x68]
    // 0x69a0a0: LoadField: r4 = r2->field_93
    //     0x69a0a0: ldur            w4, [x2, #0x93]
    // 0x69a0a4: DecompressPointer r4
    //     0x69a0a4: add             x4, x4, HEAP, lsl #32
    // 0x69a0a8: stur            x4, [fp, #-0x60]
    // 0x69a0ac: r1 = <Chapter12Stat>
    //     0x69a0ac: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x69a0b0: ldr             x1, [x1, #0xef0]
    // 0x69a0b4: r0 = UpgradeGroup()
    //     0x69a0b4: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x69a0b8: mov             x3, x0
    // 0x69a0bc: r0 = 1
    //     0x69a0bc: movz            x0, #0x1
    // 0x69a0c0: stur            x3, [fp, #-0x80]
    // 0x69a0c4: StoreField: r3->field_13 = r0
    //     0x69a0c4: stur            x0, [x3, #0x13]
    // 0x69a0c8: ldur            x1, [fp, #-0x60]
    // 0x69a0cc: StoreField: r3->field_1b = r1
    //     0x69a0cc: stur            w1, [x3, #0x1b]
    // 0x69a0d0: ldur            x1, [fp, #-0x78]
    // 0x69a0d4: StoreField: r3->field_1f = r1
    //     0x69a0d4: stur            w1, [x3, #0x1f]
    // 0x69a0d8: ldur            x1, [fp, #-0x68]
    // 0x69a0dc: StoreField: r3->field_23 = r1
    //     0x69a0dc: stur            w1, [x3, #0x23]
    // 0x69a0e0: r1 = Function '<anonymous closure>':.
    //     0x69a0e0: add             x1, PP, #0x29, lsl #12  ; [pp+0x290a0] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x69a0e4: ldr             x1, [x1, #0xa0]
    // 0x69a0e8: r2 = Null
    //     0x69a0e8: mov             x2, NULL
    // 0x69a0ec: r0 = AllocateClosure()
    //     0x69a0ec: bl              #0x826750  ; AllocateClosureStub
    // 0x69a0f0: mov             x1, x0
    // 0x69a0f4: ldur            x0, [fp, #-0x80]
    // 0x69a0f8: StoreField: r0->field_2b = r1
    //     0x69a0f8: stur            w1, [x0, #0x2b]
    // 0x69a0fc: r1 = const [0x65, 0x66, 0x67, 0xc9, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70, 0xca, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0xcb, 0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f, 0x80]
    //     0x69a0fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x290a8] List<int>(31)
    //     0x69a100: ldr             x1, [x1, #0xa8]
    // 0x69a104: StoreField: r0->field_f = r1
    //     0x69a104: stur            w1, [x0, #0xf]
    // 0x69a108: r3 = false
    //     0x69a108: add             x3, NULL, #0x30  ; false
    // 0x69a10c: StoreField: r0->field_27 = r3
    //     0x69a10c: stur            w3, [x0, #0x27]
    // 0x69a110: r1 = Instance_UpgradeDisplayMode
    //     0x69a110: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x69a114: ldr             x1, [x1, #0x608]
    // 0x69a118: StoreField: r0->field_2f = r1
    //     0x69a118: stur            w1, [x0, #0x2f]
    // 0x69a11c: StoreField: r0->field_33 = r3
    //     0x69a11c: stur            w3, [x0, #0x33]
    // 0x69a120: ldur            x2, [fp, #-0x18]
    // 0x69a124: r1 = Function '<anonymous closure>':.
    //     0x69a124: add             x1, PP, #0x29, lsl #12  ; [pp+0x290b0] AnonymousClosure: (0x69b1c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x69a128: ldr             x1, [x1, #0xb0]
    // 0x69a12c: r0 = AllocateClosure()
    //     0x69a12c: bl              #0x826750  ; AllocateClosureStub
    // 0x69a130: ldur            x2, [fp, #-0x80]
    // 0x69a134: mov             x5, x0
    // 0x69a138: r1 = Null
    //     0x69a138: mov             x1, NULL
    // 0x69a13c: r3 = "Chapter 12 Upgrades 2"
    //     0x69a13c: add             x3, PP, #0x29, lsl #12  ; [pp+0x290b8] "Chapter 12 Upgrades 2"
    //     0x69a140: ldr             x3, [x3, #0xb8]
    // 0x69a144: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69a144: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69a148: r0 = IdleFragment()
    //     0x69a148: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a14c: ldur            x1, [fp, #-0x30]
    // 0x69a150: ArrayStore: r1[3] = r0  ; List_4
    //     0x69a150: add             x25, x1, #0x1b
    //     0x69a154: str             w0, [x25]
    //     0x69a158: tbz             w0, #0, #0x69a174
    //     0x69a15c: ldurb           w16, [x1, #-1]
    //     0x69a160: ldurb           w17, [x0, #-1]
    //     0x69a164: and             x16, x17, x16, lsr #2
    //     0x69a168: tst             x16, HEAP, lsr #32
    //     0x69a16c: b.eq            #0x69a174
    //     0x69a170: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a174: ldur            x2, [fp, #-8]
    // 0x69a178: LoadField: r0 = r2->field_37
    //     0x69a178: ldur            w0, [x2, #0x37]
    // 0x69a17c: DecompressPointer r0
    //     0x69a17c: add             x0, x0, HEAP, lsl #32
    // 0x69a180: stur            x0, [fp, #-0x60]
    // 0x69a184: r1 = <Chapter12Stat>
    //     0x69a184: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x69a188: ldr             x1, [x1, #0xef0]
    // 0x69a18c: r0 = IntermissionButton()
    //     0x69a18c: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x69a190: mov             x3, x0
    // 0x69a194: ldur            x0, [fp, #-0x60]
    // 0x69a198: stur            x3, [fp, #-0x68]
    // 0x69a19c: StoreField: r3->field_1b = r0
    //     0x69a19c: stur            w0, [x3, #0x1b]
    // 0x69a1a0: r0 = Instance_Tuple2
    //     0x69a1a0: add             x0, PP, #0x29, lsl #12  ; [pp+0x290c0] Obj!Tuple2<Chapter12Stat, CustomNum>@826711
    //     0x69a1a4: ldr             x0, [x0, #0xc0]
    // 0x69a1a8: StoreField: r3->field_1f = r0
    //     0x69a1a8: stur            w0, [x3, #0x1f]
    // 0x69a1ac: ldur            x2, [fp, #-0x18]
    // 0x69a1b0: r1 = Function '<anonymous closure>':.
    //     0x69a1b0: add             x1, PP, #0x29, lsl #12  ; [pp+0x290c8] AnonymousClosure: (0x69b0d8), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a1b4: ldr             x1, [x1, #0xc8]
    // 0x69a1b8: r0 = AllocateClosure()
    //     0x69a1b8: bl              #0x826750  ; AllocateClosureStub
    // 0x69a1bc: mov             x1, x0
    // 0x69a1c0: ldur            x0, [fp, #-0x68]
    // 0x69a1c4: StoreField: r0->field_23 = r1
    //     0x69a1c4: stur            w1, [x0, #0x23]
    // 0x69a1c8: r1 = Function '<anonymous closure>':.
    //     0x69a1c8: add             x1, PP, #0x29, lsl #12  ; [pp+0x290d0] AnonymousClosure: (0x69b080), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a1cc: ldr             x1, [x1, #0xd0]
    // 0x69a1d0: r2 = Null
    //     0x69a1d0: mov             x2, NULL
    // 0x69a1d4: r0 = AllocateClosure()
    //     0x69a1d4: bl              #0x826750  ; AllocateClosureStub
    // 0x69a1d8: mov             x1, x0
    // 0x69a1dc: ldur            x0, [fp, #-0x68]
    // 0x69a1e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x69a1e0: stur            w1, [x0, #0x17]
    // 0x69a1e4: r3 = Closure: (Chapter12Stat?) => String from Function 'humanName': static.
    //     0x69a1e4: add             x3, PP, #0x29, lsl #12  ; [pp+0x290d8] Closure: (Chapter12Stat?) => String from Function 'humanName': static. (0x248ed99d414)
    //     0x69a1e8: ldr             x3, [x3, #0xd8]
    // 0x69a1ec: StoreField: r0->field_f = r3
    //     0x69a1ec: stur            w3, [x0, #0xf]
    // 0x69a1f0: ldur            x2, [fp, #-0x18]
    // 0x69a1f4: r1 = Function '<anonymous closure>':.
    //     0x69a1f4: add             x1, PP, #0x29, lsl #12  ; [pp+0x290e0] AnonymousClosure: (0x69b034), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a1f8: ldr             x1, [x1, #0xe0]
    // 0x69a1fc: r0 = AllocateClosure()
    //     0x69a1fc: bl              #0x826750  ; AllocateClosureStub
    // 0x69a200: ldur            x2, [fp, #-0x18]
    // 0x69a204: r1 = Function '<anonymous closure>':.
    //     0x69a204: add             x1, PP, #0x29, lsl #12  ; [pp+0x290e8] AnonymousClosure: (0x69af88), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a208: ldr             x1, [x1, #0xe8]
    // 0x69a20c: stur            x0, [fp, #-0x60]
    // 0x69a210: r0 = AllocateClosure()
    //     0x69a210: bl              #0x826750  ; AllocateClosureStub
    // 0x69a214: str             x0, [SP]
    // 0x69a218: ldur            x2, [fp, #-0x68]
    // 0x69a21c: ldur            x5, [fp, #-0x60]
    // 0x69a220: r1 = Null
    //     0x69a220: mov             x1, NULL
    // 0x69a224: r3 = "Chapter 12 Intermission 1"
    //     0x69a224: add             x3, PP, #0x29, lsl #12  ; [pp+0x290f0] "Chapter 12 Intermission 1"
    //     0x69a228: ldr             x3, [x3, #0xf0]
    // 0x69a22c: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x69a22c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x69a230: ldr             x4, [x4, #0x160]
    // 0x69a234: r0 = IdleFragment()
    //     0x69a234: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a238: ldur            x1, [fp, #-0x30]
    // 0x69a23c: ArrayStore: r1[4] = r0  ; List_4
    //     0x69a23c: add             x25, x1, #0x1f
    //     0x69a240: str             w0, [x25]
    //     0x69a244: tbz             w0, #0, #0x69a260
    //     0x69a248: ldurb           w16, [x1, #-1]
    //     0x69a24c: ldurb           w17, [x0, #-1]
    //     0x69a250: and             x16, x17, x16, lsr #2
    //     0x69a254: tst             x16, HEAP, lsr #32
    //     0x69a258: b.eq            #0x69a260
    //     0x69a25c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a260: ldur            x2, [fp, #-8]
    // 0x69a264: LoadField: r0 = r2->field_37
    //     0x69a264: ldur            w0, [x2, #0x37]
    // 0x69a268: DecompressPointer r0
    //     0x69a268: add             x0, x0, HEAP, lsl #32
    // 0x69a26c: stur            x0, [fp, #-0x60]
    // 0x69a270: LoadField: r1 = r2->field_8b
    //     0x69a270: ldur            w1, [x2, #0x8b]
    // 0x69a274: DecompressPointer r1
    //     0x69a274: add             x1, x1, HEAP, lsl #32
    // 0x69a278: cmp             w1, NULL
    // 0x69a27c: b.ne            #0x69a290
    // 0x69a280: mov             x3, x0
    // 0x69a284: mov             x0, x2
    // 0x69a288: r14 = Null
    //     0x69a288: mov             x14, NULL
    // 0x69a28c: b               #0x69a2b0
    // 0x69a290: LoadField: d0 = r1->field_7
    //     0x69a290: ldur            d0, [x1, #7]
    // 0x69a294: stur            d0, [fp, #-0xa8]
    // 0x69a298: r0 = CustomNum()
    //     0x69a298: bl              #0x3da324  ; AllocateCustomNumStub -> CustomNum (size=0x10)
    // 0x69a29c: ldur            d0, [fp, #-0xa8]
    // 0x69a2a0: StoreField: r0->field_7 = d0
    //     0x69a2a0: stur            d0, [x0, #7]
    // 0x69a2a4: mov             x14, x0
    // 0x69a2a8: ldur            x0, [fp, #-8]
    // 0x69a2ac: ldur            x3, [fp, #-0x60]
    // 0x69a2b0: ldur            x13, [fp, #-0x30]
    // 0x69a2b4: ldur            x9, [fp, #-0x28]
    // 0x69a2b8: ldur            x10, [fp, #-0x20]
    // 0x69a2bc: ldur            x12, [fp, #-0x58]
    // 0x69a2c0: ldur            x6, [fp, #-0x48]
    // 0x69a2c4: ldur            x11, [fp, #-0x70]
    // 0x69a2c8: ldur            x8, [fp, #-0x38]
    // 0x69a2cc: ldur            x7, [fp, #-0x40]
    // 0x69a2d0: ldur            x5, [fp, #-0x10]
    // 0x69a2d4: ldur            x4, [fp, #-0x50]
    // 0x69a2d8: stur            x14, [fp, #-0x68]
    // 0x69a2dc: r1 = Function '<anonymous closure>':.
    //     0x69a2dc: add             x1, PP, #0x29, lsl #12  ; [pp+0x290f8] AnonymousClosure: (0x69af7c), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a2e0: ldr             x1, [x1, #0xf8]
    // 0x69a2e4: r2 = Null
    //     0x69a2e4: mov             x2, NULL
    // 0x69a2e8: r0 = AllocateClosure()
    //     0x69a2e8: bl              #0x826750  ; AllocateClosureStub
    // 0x69a2ec: r1 = <Chapter12Stat>
    //     0x69a2ec: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x69a2f0: ldr             x1, [x1, #0xef0]
    // 0x69a2f4: stur            x0, [fp, #-0x78]
    // 0x69a2f8: r0 = PrestigeButton()
    //     0x69a2f8: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x69a2fc: mov             x3, x0
    // 0x69a300: ldur            x0, [fp, #-0x78]
    // 0x69a304: stur            x3, [fp, #-0x80]
    // 0x69a308: StoreField: r3->field_1f = r0
    //     0x69a308: stur            w0, [x3, #0x1f]
    // 0x69a30c: r0 = Instance_Chapter12Stat
    //     0x69a30c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x69a310: ldr             x0, [x0, #0x498]
    // 0x69a314: StoreField: r3->field_1b = r0
    //     0x69a314: stur            w0, [x3, #0x1b]
    // 0x69a318: ldur            x2, [fp, #-8]
    // 0x69a31c: r1 = Function 'getResearchPrestigePoints':.
    //     0x69a31c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29100] AnonymousClosure: (0x69af44), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getResearchPrestigePoints (0x69ae78)
    //     0x69a320: ldr             x1, [x1, #0x100]
    // 0x69a324: r0 = AllocateClosure()
    //     0x69a324: bl              #0x826750  ; AllocateClosureStub
    // 0x69a328: mov             x1, x0
    // 0x69a32c: ldur            x0, [fp, #-0x80]
    // 0x69a330: StoreField: r0->field_2f = r1
    //     0x69a330: stur            w1, [x0, #0x2f]
    // 0x69a334: ldur            x2, [fp, #-8]
    // 0x69a338: r1 = Function 'applyResearchPrestige':.
    //     0x69a338: add             x1, PP, #0x29, lsl #12  ; [pp+0x29108] AnonymousClosure: (0x69aaf8), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::applyResearchPrestige (0x69ab30)
    //     0x69a33c: ldr             x1, [x1, #0x108]
    // 0x69a340: r0 = AllocateClosure()
    //     0x69a340: bl              #0x826750  ; AllocateClosureStub
    // 0x69a344: mov             x3, x0
    // 0x69a348: ldur            x0, [fp, #-0x80]
    // 0x69a34c: stur            x3, [fp, #-0x78]
    // 0x69a350: StoreField: r0->field_33 = r3
    //     0x69a350: stur            w3, [x0, #0x33]
    // 0x69a354: ldur            x1, [fp, #-0x60]
    // 0x69a358: ArrayStore: r0[0] = r1  ; List_4
    //     0x69a358: stur            w1, [x0, #0x17]
    // 0x69a35c: r4 = Closure: (Chapter12Stat?) => String from Function 'humanName': static.
    //     0x69a35c: add             x4, PP, #0x29, lsl #12  ; [pp+0x290d8] Closure: (Chapter12Stat?) => String from Function 'humanName': static. (0x248ed99d414)
    //     0x69a360: ldr             x4, [x4, #0xd8]
    // 0x69a364: StoreField: r0->field_43 = r4
    //     0x69a364: stur            w4, [x0, #0x43]
    // 0x69a368: r1 = Function '<anonymous closure>':.
    //     0x69a368: add             x1, PP, #0x29, lsl #12  ; [pp+0x29110] AnonymousClosure: (0x69aaec), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a36c: ldr             x1, [x1, #0x110]
    // 0x69a370: r2 = Null
    //     0x69a370: mov             x2, NULL
    // 0x69a374: r0 = AllocateClosure()
    //     0x69a374: bl              #0x826750  ; AllocateClosureStub
    // 0x69a378: mov             x1, x0
    // 0x69a37c: ldur            x0, [fp, #-0x80]
    // 0x69a380: StoreField: r0->field_23 = r1
    //     0x69a380: stur            w1, [x0, #0x23]
    // 0x69a384: r1 = "everything above"
    //     0x69a384: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x69a388: ldr             x1, [x1, #0x1b0]
    // 0x69a38c: StoreField: r0->field_3f = r1
    //     0x69a38c: stur            w1, [x0, #0x3f]
    // 0x69a390: r1 = false
    //     0x69a390: add             x1, NULL, #0x30  ; false
    // 0x69a394: StoreField: r0->field_f = r1
    //     0x69a394: stur            w1, [x0, #0xf]
    // 0x69a398: StoreField: r0->field_4f = r1
    //     0x69a398: stur            w1, [x0, #0x4f]
    // 0x69a39c: r3 = true
    //     0x69a39c: add             x3, NULL, #0x20  ; true
    // 0x69a3a0: StoreField: r0->field_2b = r3
    //     0x69a3a0: stur            w3, [x0, #0x2b]
    // 0x69a3a4: StoreField: r0->field_53 = r1
    //     0x69a3a4: stur            w1, [x0, #0x53]
    // 0x69a3a8: ldur            x1, [fp, #-0x68]
    // 0x69a3ac: StoreField: r0->field_57 = r1
    //     0x69a3ac: stur            w1, [x0, #0x57]
    // 0x69a3b0: StoreField: r0->field_5b = r3
    //     0x69a3b0: stur            w3, [x0, #0x5b]
    // 0x69a3b4: r1 = "Gain"
    //     0x69a3b4: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x69a3b8: ldr             x1, [x1, #0x1b8]
    // 0x69a3bc: StoreField: r0->field_5f = r1
    //     0x69a3bc: stur            w1, [x0, #0x5f]
    // 0x69a3c0: ldur            x2, [fp, #-0x18]
    // 0x69a3c4: r1 = Function '<anonymous closure>':.
    //     0x69a3c4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29118] AnonymousClosure: (0x69aaa0), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a3c8: ldr             x1, [x1, #0x118]
    // 0x69a3cc: r0 = AllocateClosure()
    //     0x69a3cc: bl              #0x826750  ; AllocateClosureStub
    // 0x69a3d0: ldur            x2, [fp, #-0x80]
    // 0x69a3d4: mov             x5, x0
    // 0x69a3d8: r1 = Null
    //     0x69a3d8: mov             x1, NULL
    // 0x69a3dc: r3 = "Chapter 12 Prestige 1"
    //     0x69a3dc: add             x3, PP, #0x29, lsl #12  ; [pp+0x29120] "Chapter 12 Prestige 1"
    //     0x69a3e0: ldr             x3, [x3, #0x120]
    // 0x69a3e4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69a3e4: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69a3e8: r0 = IdleFragment()
    //     0x69a3e8: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a3ec: ldur            x1, [fp, #-0x30]
    // 0x69a3f0: ArrayStore: r1[5] = r0  ; List_4
    //     0x69a3f0: add             x25, x1, #0x23
    //     0x69a3f4: str             w0, [x25]
    //     0x69a3f8: tbz             w0, #0, #0x69a414
    //     0x69a3fc: ldurb           w16, [x1, #-1]
    //     0x69a400: ldurb           w17, [x0, #-1]
    //     0x69a404: and             x16, x17, x16, lsr #2
    //     0x69a408: tst             x16, HEAP, lsr #32
    //     0x69a40c: b.eq            #0x69a414
    //     0x69a410: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a414: ldur            x0, [fp, #-8]
    // 0x69a418: LoadField: r2 = r0->field_2b
    //     0x69a418: ldur            w2, [x0, #0x2b]
    // 0x69a41c: DecompressPointer r2
    //     0x69a41c: add             x2, x2, HEAP, lsl #32
    // 0x69a420: stur            x2, [fp, #-0x98]
    // 0x69a424: LoadField: r3 = r0->field_37
    //     0x69a424: ldur            w3, [x0, #0x37]
    // 0x69a428: DecompressPointer r3
    //     0x69a428: add             x3, x3, HEAP, lsl #32
    // 0x69a42c: stur            x3, [fp, #-0x90]
    // 0x69a430: LoadField: r4 = r0->field_4b
    //     0x69a430: ldur            w4, [x0, #0x4b]
    // 0x69a434: DecompressPointer r4
    //     0x69a434: add             x4, x4, HEAP, lsl #32
    // 0x69a438: stur            x4, [fp, #-0x88]
    // 0x69a43c: LoadField: r5 = r0->field_47
    //     0x69a43c: ldur            w5, [x0, #0x47]
    // 0x69a440: DecompressPointer r5
    //     0x69a440: add             x5, x5, HEAP, lsl #32
    // 0x69a444: stur            x5, [fp, #-0x80]
    // 0x69a448: LoadField: r6 = r0->field_53
    //     0x69a448: ldur            w6, [x0, #0x53]
    // 0x69a44c: DecompressPointer r6
    //     0x69a44c: add             x6, x6, HEAP, lsl #32
    // 0x69a450: stur            x6, [fp, #-0x68]
    // 0x69a454: LoadField: r7 = r0->field_9b
    //     0x69a454: ldur            w7, [x0, #0x9b]
    // 0x69a458: DecompressPointer r7
    //     0x69a458: add             x7, x7, HEAP, lsl #32
    // 0x69a45c: stur            x7, [fp, #-0x60]
    // 0x69a460: r1 = <Chapter12Stat>
    //     0x69a460: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x69a464: ldr             x1, [x1, #0xef0]
    // 0x69a468: r0 = GeneratorGroup()
    //     0x69a468: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69a46c: mov             x3, x0
    // 0x69a470: ldur            x0, [fp, #-0x90]
    // 0x69a474: stur            x3, [fp, #-0xa0]
    // 0x69a478: StoreField: r3->field_1f = r0
    //     0x69a478: stur            w0, [x3, #0x1f]
    // 0x69a47c: ldur            x0, [fp, #-0x58]
    // 0x69a480: StoreField: r3->field_23 = r0
    //     0x69a480: stur            w0, [x3, #0x23]
    // 0x69a484: ldur            x0, [fp, #-0x70]
    // 0x69a488: StoreField: r3->field_27 = r0
    //     0x69a488: stur            w0, [x3, #0x27]
    // 0x69a48c: ldur            x0, [fp, #-0x88]
    // 0x69a490: StoreField: r3->field_2b = r0
    //     0x69a490: stur            w0, [x3, #0x2b]
    // 0x69a494: ldur            x0, [fp, #-0x80]
    // 0x69a498: StoreField: r3->field_2f = r0
    //     0x69a498: stur            w0, [x3, #0x2f]
    // 0x69a49c: ldur            x0, [fp, #-0x68]
    // 0x69a4a0: StoreField: r3->field_33 = r0
    //     0x69a4a0: stur            w0, [x3, #0x33]
    // 0x69a4a4: r1 = Function '<anonymous closure>':.
    //     0x69a4a4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29128] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69a4a8: ldr             x1, [x1, #0x128]
    // 0x69a4ac: r2 = Null
    //     0x69a4ac: mov             x2, NULL
    // 0x69a4b0: r0 = AllocateClosure()
    //     0x69a4b0: bl              #0x826750  ; AllocateClosureStub
    // 0x69a4b4: mov             x1, x0
    // 0x69a4b8: ldur            x0, [fp, #-0xa0]
    // 0x69a4bc: StoreField: r0->field_3b = r1
    //     0x69a4bc: stur            w1, [x0, #0x3b]
    // 0x69a4c0: ldur            x1, [fp, #-0x28]
    // 0x69a4c4: StoreField: r0->field_43 = r1
    //     0x69a4c4: stur            w1, [x0, #0x43]
    // 0x69a4c8: ldur            x1, [fp, #-0x20]
    // 0x69a4cc: StoreField: r0->field_47 = r1
    //     0x69a4cc: stur            w1, [x0, #0x47]
    // 0x69a4d0: ldur            x1, [fp, #-0x38]
    // 0x69a4d4: StoreField: r0->field_5b = r1
    //     0x69a4d4: stur            w1, [x0, #0x5b]
    // 0x69a4d8: r1 = Function '<anonymous closure>':.
    //     0x69a4d8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29130] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x69a4dc: ldr             x1, [x1, #0x130]
    // 0x69a4e0: r2 = Null
    //     0x69a4e0: mov             x2, NULL
    // 0x69a4e4: r0 = AllocateClosure()
    //     0x69a4e4: bl              #0x826750  ; AllocateClosureStub
    // 0x69a4e8: mov             x1, x0
    // 0x69a4ec: ldur            x0, [fp, #-0xa0]
    // 0x69a4f0: ArrayStore: r0[0] = r1  ; List_4
    //     0x69a4f0: stur            w1, [x0, #0x17]
    // 0x69a4f4: r1 = Function '<anonymous closure>':.
    //     0x69a4f4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29138] AnonymousClosure: (0x46d414), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState (0x46d16c)
    //     0x69a4f8: ldr             x1, [x1, #0x138]
    // 0x69a4fc: r2 = Null
    //     0x69a4fc: mov             x2, NULL
    // 0x69a500: r0 = AllocateClosure()
    //     0x69a500: bl              #0x826750  ; AllocateClosureStub
    // 0x69a504: mov             x1, x0
    // 0x69a508: ldur            x0, [fp, #-0xa0]
    // 0x69a50c: StoreField: r0->field_1b = r1
    //     0x69a50c: stur            w1, [x0, #0x1b]
    // 0x69a510: ldur            x1, [fp, #-0x40]
    // 0x69a514: StoreField: r0->field_57 = r1
    //     0x69a514: stur            w1, [x0, #0x57]
    // 0x69a518: r1 = const [0x6, 0x7, 0x8, 0x9, 0xa]
    //     0x69a518: add             x1, PP, #0x29, lsl #12  ; [pp+0x29140] List<int>(5)
    //     0x69a51c: ldr             x1, [x1, #0x140]
    // 0x69a520: StoreField: r0->field_53 = r1
    //     0x69a520: stur            w1, [x0, #0x53]
    // 0x69a524: ldur            x1, [fp, #-0x48]
    // 0x69a528: StoreField: r0->field_6b = r1
    //     0x69a528: stur            w1, [x0, #0x6b]
    // 0x69a52c: ldur            x1, [fp, #-0x98]
    // 0x69a530: StoreField: r0->field_4b = r1
    //     0x69a530: stur            w1, [x0, #0x4b]
    // 0x69a534: ldur            x1, [fp, #-0x60]
    // 0x69a538: StoreField: r0->field_67 = r1
    //     0x69a538: stur            w1, [x0, #0x67]
    // 0x69a53c: ldur            x1, [fp, #-0x10]
    // 0x69a540: StoreField: r0->field_77 = r1
    //     0x69a540: stur            w1, [x0, #0x77]
    // 0x69a544: ldur            x1, [fp, #-0x50]
    // 0x69a548: StoreField: r0->field_7b = r1
    //     0x69a548: stur            w1, [x0, #0x7b]
    // 0x69a54c: r3 = "Chapter 12 Generators 2"
    //     0x69a54c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29148] "Chapter 12 Generators 2"
    //     0x69a550: ldr             x3, [x3, #0x148]
    // 0x69a554: StoreField: r0->field_73 = r3
    //     0x69a554: stur            w3, [x0, #0x73]
    // 0x69a558: ldur            x2, [fp, #-0x18]
    // 0x69a55c: r1 = Function '<anonymous closure>':.
    //     0x69a55c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29150] AnonymousClosure: (0x69aa10), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a560: ldr             x1, [x1, #0x150]
    // 0x69a564: r0 = AllocateClosure()
    //     0x69a564: bl              #0x826750  ; AllocateClosureStub
    // 0x69a568: ldur            x2, [fp, #-0xa0]
    // 0x69a56c: mov             x5, x0
    // 0x69a570: r1 = Null
    //     0x69a570: mov             x1, NULL
    // 0x69a574: r3 = "Chapter 12 Generators 2"
    //     0x69a574: add             x3, PP, #0x29, lsl #12  ; [pp+0x29148] "Chapter 12 Generators 2"
    //     0x69a578: ldr             x3, [x3, #0x148]
    // 0x69a57c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69a57c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69a580: r0 = IdleFragment()
    //     0x69a580: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a584: ldur            x1, [fp, #-0x30]
    // 0x69a588: ArrayStore: r1[6] = r0  ; List_4
    //     0x69a588: add             x25, x1, #0x27
    //     0x69a58c: str             w0, [x25]
    //     0x69a590: tbz             w0, #0, #0x69a5ac
    //     0x69a594: ldurb           w16, [x1, #-1]
    //     0x69a598: ldurb           w17, [x0, #-1]
    //     0x69a59c: and             x16, x17, x16, lsr #2
    //     0x69a5a0: tst             x16, HEAP, lsr #32
    //     0x69a5a4: b.eq            #0x69a5ac
    //     0x69a5a8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a5ac: ldur            x0, [fp, #-8]
    // 0x69a5b0: LoadField: r2 = r0->field_37
    //     0x69a5b0: ldur            w2, [x0, #0x37]
    // 0x69a5b4: DecompressPointer r2
    //     0x69a5b4: add             x2, x2, HEAP, lsl #32
    // 0x69a5b8: stur            x2, [fp, #-0x20]
    // 0x69a5bc: LoadField: r3 = r0->field_3f
    //     0x69a5bc: ldur            w3, [x0, #0x3f]
    // 0x69a5c0: DecompressPointer r3
    //     0x69a5c0: add             x3, x3, HEAP, lsl #32
    // 0x69a5c4: stur            x3, [fp, #-0x10]
    // 0x69a5c8: r1 = <Chapter12Stat>
    //     0x69a5c8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x69a5cc: ldr             x1, [x1, #0xef0]
    // 0x69a5d0: r0 = QuestButton()
    //     0x69a5d0: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x69a5d4: mov             x3, x0
    // 0x69a5d8: ldur            x0, [fp, #-0x78]
    // 0x69a5dc: stur            x3, [fp, #-0x28]
    // 0x69a5e0: StoreField: r3->field_2f = r0
    //     0x69a5e0: stur            w0, [x3, #0x2f]
    // 0x69a5e4: ldur            x0, [fp, #-0x20]
    // 0x69a5e8: StoreField: r3->field_1b = r0
    //     0x69a5e8: stur            w0, [x3, #0x1b]
    // 0x69a5ec: r0 = Instance_IconData
    //     0x69a5ec: add             x0, PP, #0x29, lsl #12  ; [pp+0x29158] Obj!IconData@8308d1
    //     0x69a5f0: ldr             x0, [x0, #0x158]
    // 0x69a5f4: StoreField: r3->field_1f = r0
    //     0x69a5f4: stur            w0, [x3, #0x1f]
    // 0x69a5f8: ldur            x0, [fp, #-0x10]
    // 0x69a5fc: StoreField: r3->field_2b = r0
    //     0x69a5fc: stur            w0, [x3, #0x2b]
    // 0x69a600: r0 = 1
    //     0x69a600: movz            x0, #0x1
    // 0x69a604: StoreField: r3->field_23 = r0
    //     0x69a604: stur            x0, [x3, #0x23]
    // 0x69a608: r0 = Closure: (Chapter12Stat?) => String from Function 'humanName': static.
    //     0x69a608: add             x0, PP, #0x29, lsl #12  ; [pp+0x290d8] Closure: (Chapter12Stat?) => String from Function 'humanName': static. (0x248ed99d414)
    //     0x69a60c: ldr             x0, [x0, #0xd8]
    // 0x69a610: StoreField: r3->field_f = r0
    //     0x69a610: stur            w0, [x3, #0xf]
    // 0x69a614: r1 = const [Instance of 'QuestLevel<Chapter12Stat>', Instance of 'QuestLevel<Chapter12Stat>', Instance of 'QuestLevel<Chapter12Stat>', Instance of 'QuestLevel<Chapter12Stat>', Instance of 'QuestLevel<Chapter12Stat>']
    //     0x69a614: add             x1, PP, #0x29, lsl #12  ; [pp+0x29160] List<QuestLevel<Chapter12Stat>>(5)
    //     0x69a618: ldr             x1, [x1, #0x160]
    // 0x69a61c: StoreField: r3->field_37 = r1
    //     0x69a61c: stur            w1, [x3, #0x37]
    // 0x69a620: r1 = true
    //     0x69a620: add             x1, NULL, #0x20  ; true
    // 0x69a624: StoreField: r3->field_13 = r1
    //     0x69a624: stur            w1, [x3, #0x13]
    // 0x69a628: r1 = Null
    //     0x69a628: mov             x1, NULL
    // 0x69a62c: r2 = 2
    //     0x69a62c: movz            x2, #0x2
    // 0x69a630: r0 = AllocateArray()
    //     0x69a630: bl              #0x82746c  ; AllocateArrayStub
    // 0x69a634: mov             x2, x0
    // 0x69a638: ldur            x0, [fp, #-0x28]
    // 0x69a63c: stur            x2, [fp, #-0x10]
    // 0x69a640: StoreField: r2->field_f = r0
    //     0x69a640: stur            w0, [x2, #0xf]
    // 0x69a644: r1 = <Widget>
    //     0x69a644: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69a648: r0 = AllocateGrowableArray()
    //     0x69a648: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69a64c: mov             x1, x0
    // 0x69a650: ldur            x0, [fp, #-0x10]
    // 0x69a654: stur            x1, [fp, #-0x20]
    // 0x69a658: StoreField: r1->field_f = r0
    //     0x69a658: stur            w0, [x1, #0xf]
    // 0x69a65c: r2 = 2
    //     0x69a65c: movz            x2, #0x2
    // 0x69a660: StoreField: r1->field_b = r2
    //     0x69a660: stur            w2, [x1, #0xb]
    // 0x69a664: r0 = Column()
    //     0x69a664: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x69a668: mov             x1, x0
    // 0x69a66c: r0 = Instance_Axis
    //     0x69a66c: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x69a670: stur            x1, [fp, #-0x10]
    // 0x69a674: StoreField: r1->field_f = r0
    //     0x69a674: stur            w0, [x1, #0xf]
    // 0x69a678: r2 = Instance_MainAxisAlignment
    //     0x69a678: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x69a67c: ldr             x2, [x2, #0x200]
    // 0x69a680: StoreField: r1->field_13 = r2
    //     0x69a680: stur            w2, [x1, #0x13]
    // 0x69a684: r3 = Instance_MainAxisSize
    //     0x69a684: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x69a688: ldr             x3, [x3, #0x70]
    // 0x69a68c: ArrayStore: r1[0] = r3  ; List_4
    //     0x69a68c: stur            w3, [x1, #0x17]
    // 0x69a690: r4 = Instance_CrossAxisAlignment
    //     0x69a690: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x69a694: ldr             x4, [x4, #0x78]
    // 0x69a698: StoreField: r1->field_1b = r4
    //     0x69a698: stur            w4, [x1, #0x1b]
    // 0x69a69c: r5 = Instance_VerticalDirection
    //     0x69a69c: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x69a6a0: ldr             x5, [x5, #0x1e8]
    // 0x69a6a4: StoreField: r1->field_23 = r5
    //     0x69a6a4: stur            w5, [x1, #0x23]
    // 0x69a6a8: r6 = Instance_Clip
    //     0x69a6a8: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x69a6ac: ldr             x6, [x6, #0x1b0]
    // 0x69a6b0: StoreField: r1->field_2b = r6
    //     0x69a6b0: stur            w6, [x1, #0x2b]
    // 0x69a6b4: StoreField: r1->field_2f = rZR
    //     0x69a6b4: stur            xzr, [x1, #0x2f]
    // 0x69a6b8: ldur            x7, [fp, #-0x20]
    // 0x69a6bc: StoreField: r1->field_b = r7
    //     0x69a6bc: stur            w7, [x1, #0xb]
    // 0x69a6c0: r0 = Padding()
    //     0x69a6c0: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x69a6c4: mov             x3, x0
    // 0x69a6c8: r0 = Instance_EdgeInsets
    //     0x69a6c8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a08] Obj!EdgeInsets@831da1
    //     0x69a6cc: ldr             x0, [x0, #0xa08]
    // 0x69a6d0: stur            x3, [fp, #-0x20]
    // 0x69a6d4: StoreField: r3->field_f = r0
    //     0x69a6d4: stur            w0, [x3, #0xf]
    // 0x69a6d8: ldur            x0, [fp, #-0x10]
    // 0x69a6dc: StoreField: r3->field_b = r0
    //     0x69a6dc: stur            w0, [x3, #0xb]
    // 0x69a6e0: ldur            x2, [fp, #-0x18]
    // 0x69a6e4: r1 = Function '<anonymous closure>':.
    //     0x69a6e4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29168] AnonymousClosure: (0x69a924), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a6e8: ldr             x1, [x1, #0x168]
    // 0x69a6ec: r0 = AllocateClosure()
    //     0x69a6ec: bl              #0x826750  ; AllocateClosureStub
    // 0x69a6f0: ldur            x2, [fp, #-0x20]
    // 0x69a6f4: mov             x5, x0
    // 0x69a6f8: r1 = Null
    //     0x69a6f8: mov             x1, NULL
    // 0x69a6fc: r3 = "Chapter 12 Quests 1"
    //     0x69a6fc: add             x3, PP, #0x29, lsl #12  ; [pp+0x29170] "Chapter 12 Quests 1"
    //     0x69a700: ldr             x3, [x3, #0x170]
    // 0x69a704: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69a704: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69a708: r0 = IdleFragment()
    //     0x69a708: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a70c: ldur            x1, [fp, #-0x30]
    // 0x69a710: ArrayStore: r1[7] = r0  ; List_4
    //     0x69a710: add             x25, x1, #0x2b
    //     0x69a714: str             w0, [x25]
    //     0x69a718: tbz             w0, #0, #0x69a734
    //     0x69a71c: ldurb           w16, [x1, #-1]
    //     0x69a720: ldurb           w17, [x0, #-1]
    //     0x69a724: and             x16, x17, x16, lsr #2
    //     0x69a728: tst             x16, HEAP, lsr #32
    //     0x69a72c: b.eq            #0x69a734
    //     0x69a730: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a734: ldur            x0, [fp, #-8]
    // 0x69a738: LoadField: r2 = r0->field_37
    //     0x69a738: ldur            w2, [x0, #0x37]
    // 0x69a73c: DecompressPointer r2
    //     0x69a73c: add             x2, x2, HEAP, lsl #32
    // 0x69a740: stur            x2, [fp, #-0x10]
    // 0x69a744: r1 = <Chapter12Stat>
    //     0x69a744: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x69a748: ldr             x1, [x1, #0xef0]
    // 0x69a74c: r0 = CompleteChapterButtons()
    //     0x69a74c: bl              #0x697edc  ; AllocateCompleteChapterButtonsStub -> CompleteChapterButtons<X0> (size=0x24)
    // 0x69a750: mov             x3, x0
    // 0x69a754: ldur            x0, [fp, #-0x10]
    // 0x69a758: stur            x3, [fp, #-8]
    // 0x69a75c: StoreField: r3->field_f = r0
    //     0x69a75c: stur            w0, [x3, #0xf]
    // 0x69a760: r0 = Instance_Tuple2
    //     0x69a760: add             x0, PP, #0x29, lsl #12  ; [pp+0x29178] Obj!Tuple2<Chapter12Stat, CustomNum>@826651
    //     0x69a764: ldr             x0, [x0, #0x178]
    // 0x69a768: StoreField: r3->field_13 = r0
    //     0x69a768: stur            w0, [x3, #0x13]
    // 0x69a76c: ldur            x2, [fp, #-0x18]
    // 0x69a770: r1 = Function '<anonymous closure>':.
    //     0x69a770: add             x1, PP, #0x29, lsl #12  ; [pp+0x29180] AnonymousClosure: (0x69a8d0), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69a774: ldr             x1, [x1, #0x180]
    // 0x69a778: r0 = AllocateClosure()
    //     0x69a778: bl              #0x826750  ; AllocateClosureStub
    // 0x69a77c: mov             x1, x0
    // 0x69a780: ldur            x0, [fp, #-8]
    // 0x69a784: ArrayStore: r0[0] = r1  ; List_4
    //     0x69a784: stur            w1, [x0, #0x17]
    // 0x69a788: r1 = Closure: (Chapter12Stat?) => String from Function 'humanName': static.
    //     0x69a788: add             x1, PP, #0x29, lsl #12  ; [pp+0x290d8] Closure: (Chapter12Stat?) => String from Function 'humanName': static. (0x248ed99d414)
    //     0x69a78c: ldr             x1, [x1, #0xd8]
    // 0x69a790: StoreField: r0->field_1f = r1
    //     0x69a790: stur            w1, [x0, #0x1f]
    // 0x69a794: r1 = Instance_ChapterCompleteButtonType
    //     0x69a794: add             x1, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!ChapterCompleteButtonType@85ea61
    //     0x69a798: ldr             x1, [x1, #0x330]
    // 0x69a79c: StoreField: r0->field_1b = r1
    //     0x69a79c: stur            w1, [x0, #0x1b]
    // 0x69a7a0: r1 = Null
    //     0x69a7a0: mov             x1, NULL
    // 0x69a7a4: r2 = 2
    //     0x69a7a4: movz            x2, #0x2
    // 0x69a7a8: r0 = AllocateArray()
    //     0x69a7a8: bl              #0x82746c  ; AllocateArrayStub
    // 0x69a7ac: mov             x2, x0
    // 0x69a7b0: ldur            x0, [fp, #-8]
    // 0x69a7b4: stur            x2, [fp, #-0x10]
    // 0x69a7b8: StoreField: r2->field_f = r0
    //     0x69a7b8: stur            w0, [x2, #0xf]
    // 0x69a7bc: r1 = <Widget>
    //     0x69a7bc: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69a7c0: r0 = AllocateGrowableArray()
    //     0x69a7c0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69a7c4: mov             x1, x0
    // 0x69a7c8: ldur            x0, [fp, #-0x10]
    // 0x69a7cc: stur            x1, [fp, #-8]
    // 0x69a7d0: StoreField: r1->field_f = r0
    //     0x69a7d0: stur            w0, [x1, #0xf]
    // 0x69a7d4: r0 = 2
    //     0x69a7d4: movz            x0, #0x2
    // 0x69a7d8: StoreField: r1->field_b = r0
    //     0x69a7d8: stur            w0, [x1, #0xb]
    // 0x69a7dc: r0 = Column()
    //     0x69a7dc: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x69a7e0: mov             x3, x0
    // 0x69a7e4: r0 = Instance_Axis
    //     0x69a7e4: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x69a7e8: stur            x3, [fp, #-0x10]
    // 0x69a7ec: StoreField: r3->field_f = r0
    //     0x69a7ec: stur            w0, [x3, #0xf]
    // 0x69a7f0: r0 = Instance_MainAxisAlignment
    //     0x69a7f0: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x69a7f4: ldr             x0, [x0, #0x200]
    // 0x69a7f8: StoreField: r3->field_13 = r0
    //     0x69a7f8: stur            w0, [x3, #0x13]
    // 0x69a7fc: r0 = Instance_MainAxisSize
    //     0x69a7fc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x69a800: ldr             x0, [x0, #0x70]
    // 0x69a804: ArrayStore: r3[0] = r0  ; List_4
    //     0x69a804: stur            w0, [x3, #0x17]
    // 0x69a808: r0 = Instance_CrossAxisAlignment
    //     0x69a808: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x69a80c: ldr             x0, [x0, #0x78]
    // 0x69a810: StoreField: r3->field_1b = r0
    //     0x69a810: stur            w0, [x3, #0x1b]
    // 0x69a814: r0 = Instance_VerticalDirection
    //     0x69a814: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x69a818: ldr             x0, [x0, #0x1e8]
    // 0x69a81c: StoreField: r3->field_23 = r0
    //     0x69a81c: stur            w0, [x3, #0x23]
    // 0x69a820: r0 = Instance_Clip
    //     0x69a820: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x69a824: ldr             x0, [x0, #0x1b0]
    // 0x69a828: StoreField: r3->field_2b = r0
    //     0x69a828: stur            w0, [x3, #0x2b]
    // 0x69a82c: StoreField: r3->field_2f = rZR
    //     0x69a82c: stur            xzr, [x3, #0x2f]
    // 0x69a830: ldur            x0, [fp, #-8]
    // 0x69a834: StoreField: r3->field_b = r0
    //     0x69a834: stur            w0, [x3, #0xb]
    // 0x69a838: ldur            x2, [fp, #-0x18]
    // 0x69a83c: r1 = Function '<anonymous closure>':.
    //     0x69a83c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29188] AnonymousClosure: (0x69940c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x69a840: ldr             x1, [x1, #0x188]
    // 0x69a844: r0 = AllocateClosure()
    //     0x69a844: bl              #0x826750  ; AllocateClosureStub
    // 0x69a848: ldur            x2, [fp, #-0x10]
    // 0x69a84c: mov             x5, x0
    // 0x69a850: r1 = Null
    //     0x69a850: mov             x1, NULL
    // 0x69a854: r3 = "Chapter 12 Complete Chapter"
    //     0x69a854: add             x3, PP, #0x29, lsl #12  ; [pp+0x29190] "Chapter 12 Complete Chapter"
    //     0x69a858: ldr             x3, [x3, #0x190]
    // 0x69a85c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69a85c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69a860: r0 = IdleFragment()
    //     0x69a860: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69a864: ldur            x1, [fp, #-0x30]
    // 0x69a868: ArrayStore: r1[8] = r0  ; List_4
    //     0x69a868: add             x25, x1, #0x2f
    //     0x69a86c: str             w0, [x25]
    //     0x69a870: tbz             w0, #0, #0x69a88c
    //     0x69a874: ldurb           w16, [x1, #-1]
    //     0x69a878: ldurb           w17, [x0, #-1]
    //     0x69a87c: and             x16, x17, x16, lsr #2
    //     0x69a880: tst             x16, HEAP, lsr #32
    //     0x69a884: b.eq            #0x69a88c
    //     0x69a888: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69a88c: r1 = <Widget>
    //     0x69a88c: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69a890: r0 = AllocateGrowableArray()
    //     0x69a890: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69a894: ldur            x1, [fp, #-0x30]
    // 0x69a898: StoreField: r0->field_f = r1
    //     0x69a898: stur            w1, [x0, #0xf]
    // 0x69a89c: r1 = 18
    //     0x69a89c: movz            x1, #0x12
    // 0x69a8a0: StoreField: r0->field_b = r1
    //     0x69a8a0: stur            w1, [x0, #0xb]
    // 0x69a8a4: LeaveFrame
    //     0x69a8a4: mov             SP, fp
    //     0x69a8a8: ldp             fp, lr, [SP], #0x10
    // 0x69a8ac: ret
    //     0x69a8ac: ret             
    // 0x69a8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69a8b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69a8b4: b               #0x699c24
    // 0x69a8b8: r9 = allUpgradeData
    //     0x69a8b8: add             x9, PP, #0x29, lsl #12  ; [pp+0x29198] Field <Chapter12GameState.allUpgradeData>: late (offset: 0x94)
    //     0x69a8bc: ldr             x9, [x9, #0x198]
    // 0x69a8c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69a8c0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x69a8d0, size: 0x54
    // 0x69a8d0: EnterFrame
    //     0x69a8d0: stp             fp, lr, [SP, #-0x10]!
    //     0x69a8d4: mov             fp, SP
    // 0x69a8d8: ldr             x0, [fp, #0x18]
    // 0x69a8dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69a8dc: ldur            w1, [x0, #0x17]
    // 0x69a8e0: DecompressPointer r1
    //     0x69a8e0: add             x1, x1, HEAP, lsl #32
    // 0x69a8e4: CheckStackOverflow
    //     0x69a8e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69a8e8: cmp             SP, x16
    //     0x69a8ec: b.ls            #0x69a91c
    // 0x69a8f0: LoadField: r0 = r1->field_f
    //     0x69a8f0: ldur            w0, [x1, #0xf]
    // 0x69a8f4: DecompressPointer r0
    //     0x69a8f4: add             x0, x0, HEAP, lsl #32
    // 0x69a8f8: LoadField: r2 = r1->field_13
    //     0x69a8f8: ldur            w2, [x1, #0x13]
    // 0x69a8fc: DecompressPointer r2
    //     0x69a8fc: add             x2, x2, HEAP, lsl #32
    // 0x69a900: mov             x1, x0
    // 0x69a904: r3 = Instance_Tuple2
    //     0x69a904: add             x3, PP, #0x29, lsl #12  ; [pp+0x291a0] Obj!Tuple2<int, String>@826631
    //     0x69a908: ldr             x3, [x3, #0x1a0]
    // 0x69a90c: r0 = completeChapter()
    //     0x69a90c: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x69a910: LeaveFrame
    //     0x69a910: mov             SP, fp
    //     0x69a914: ldp             fp, lr, [SP], #0x10
    // 0x69a918: ret
    //     0x69a918: ret             
    // 0x69a91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69a91c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69a920: b               #0x69a8f0
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69a924, size: 0xec
    // 0x69a924: EnterFrame
    //     0x69a924: stp             fp, lr, [SP, #-0x10]!
    //     0x69a928: mov             fp, SP
    // 0x69a92c: AllocStack(0x8)
    //     0x69a92c: sub             SP, SP, #8
    // 0x69a930: SetupParameters([dynamic _ /* r0 */])
    //     0x69a930: ldr             x0, [fp, #0x10]
    //     0x69a934: ldur            w3, [x0, #0x17]
    //     0x69a938: add             x3, x3, HEAP, lsl #32
    //     0x69a93c: stur            x3, [fp, #-8]
    // 0x69a940: CheckStackOverflow
    //     0x69a940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69a944: cmp             SP, x16
    //     0x69a948: b.ls            #0x69aa08
    // 0x69a94c: LoadField: r0 = r3->field_f
    //     0x69a94c: ldur            w0, [x3, #0xf]
    // 0x69a950: DecompressPointer r0
    //     0x69a950: add             x0, x0, HEAP, lsl #32
    // 0x69a954: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69a954: ldur            w1, [x0, #0x17]
    // 0x69a958: DecompressPointer r1
    //     0x69a958: add             x1, x1, HEAP, lsl #32
    // 0x69a95c: r2 = 12
    //     0x69a95c: movz            x2, #0xc
    // 0x69a960: r0 = contains()
    //     0x69a960: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69a964: tbz             w0, #4, #0x69a9d4
    // 0x69a968: ldur            x0, [fp, #-8]
    // 0x69a96c: LoadField: r1 = r0->field_f
    //     0x69a96c: ldur            w1, [x0, #0xf]
    // 0x69a970: DecompressPointer r1
    //     0x69a970: add             x1, x1, HEAP, lsl #32
    // 0x69a974: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69a974: ldur            w2, [x1, #0x17]
    // 0x69a978: DecompressPointer r2
    //     0x69a978: add             x2, x2, HEAP, lsl #32
    // 0x69a97c: mov             x1, x2
    // 0x69a980: r2 = 14
    //     0x69a980: movz            x2, #0xe
    // 0x69a984: r0 = contains()
    //     0x69a984: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69a988: tbz             w0, #4, #0x69a9d4
    // 0x69a98c: ldur            x0, [fp, #-8]
    // 0x69a990: LoadField: r1 = r0->field_f
    //     0x69a990: ldur            w1, [x0, #0xf]
    // 0x69a994: DecompressPointer r1
    //     0x69a994: add             x1, x1, HEAP, lsl #32
    // 0x69a998: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69a998: ldur            w2, [x1, #0x17]
    // 0x69a99c: DecompressPointer r2
    //     0x69a99c: add             x2, x2, HEAP, lsl #32
    // 0x69a9a0: mov             x1, x2
    // 0x69a9a4: r2 = 16
    //     0x69a9a4: movz            x2, #0x10
    // 0x69a9a8: r0 = contains()
    //     0x69a9a8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69a9ac: tbz             w0, #4, #0x69a9d4
    // 0x69a9b0: ldur            x0, [fp, #-8]
    // 0x69a9b4: LoadField: r1 = r0->field_f
    //     0x69a9b4: ldur            w1, [x0, #0xf]
    // 0x69a9b8: DecompressPointer r1
    //     0x69a9b8: add             x1, x1, HEAP, lsl #32
    // 0x69a9bc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69a9bc: ldur            w2, [x1, #0x17]
    // 0x69a9c0: DecompressPointer r2
    //     0x69a9c0: add             x2, x2, HEAP, lsl #32
    // 0x69a9c4: mov             x1, x2
    // 0x69a9c8: r2 = 18
    //     0x69a9c8: movz            x2, #0x12
    // 0x69a9cc: r0 = contains()
    //     0x69a9cc: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69a9d0: tbnz            w0, #4, #0x69a9dc
    // 0x69a9d4: r0 = true
    //     0x69a9d4: add             x0, NULL, #0x20  ; true
    // 0x69a9d8: b               #0x69a9fc
    // 0x69a9dc: ldur            x0, [fp, #-8]
    // 0x69a9e0: LoadField: r1 = r0->field_f
    //     0x69a9e0: ldur            w1, [x0, #0xf]
    // 0x69a9e4: DecompressPointer r1
    //     0x69a9e4: add             x1, x1, HEAP, lsl #32
    // 0x69a9e8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x69a9e8: ldur            w0, [x1, #0x17]
    // 0x69a9ec: DecompressPointer r0
    //     0x69a9ec: add             x0, x0, HEAP, lsl #32
    // 0x69a9f0: mov             x1, x0
    // 0x69a9f4: r2 = 20
    //     0x69a9f4: movz            x2, #0x14
    // 0x69a9f8: r0 = contains()
    //     0x69a9f8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69a9fc: LeaveFrame
    //     0x69a9fc: mov             SP, fp
    //     0x69aa00: ldp             fp, lr, [SP], #0x10
    // 0x69aa04: ret
    //     0x69aa04: ret             
    // 0x69aa08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69aa08: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69aa0c: b               #0x69a94c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69aa10, size: 0x90
    // 0x69aa10: EnterFrame
    //     0x69aa10: stp             fp, lr, [SP, #-0x10]!
    //     0x69aa14: mov             fp, SP
    // 0x69aa18: AllocStack(0x8)
    //     0x69aa18: sub             SP, SP, #8
    // 0x69aa1c: SetupParameters([dynamic _ /* r0 */])
    //     0x69aa1c: ldr             x0, [fp, #0x10]
    //     0x69aa20: ldur            w3, [x0, #0x17]
    //     0x69aa24: add             x3, x3, HEAP, lsl #32
    //     0x69aa28: stur            x3, [fp, #-8]
    // 0x69aa2c: CheckStackOverflow
    //     0x69aa2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69aa30: cmp             SP, x16
    //     0x69aa34: b.ls            #0x69aa98
    // 0x69aa38: LoadField: r0 = r3->field_f
    //     0x69aa38: ldur            w0, [x3, #0xf]
    // 0x69aa3c: DecompressPointer r0
    //     0x69aa3c: add             x0, x0, HEAP, lsl #32
    // 0x69aa40: LoadField: r1 = r0->field_43
    //     0x69aa40: ldur            w1, [x0, #0x43]
    // 0x69aa44: DecompressPointer r1
    //     0x69aa44: add             x1, x1, HEAP, lsl #32
    // 0x69aa48: r2 = 230
    //     0x69aa48: movz            x2, #0xe6
    // 0x69aa4c: r0 = containsKey()
    //     0x69aa4c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69aa50: tbnz            w0, #4, #0x69aa88
    // 0x69aa54: ldur            x1, [fp, #-8]
    // 0x69aa58: LoadField: r2 = r1->field_f
    //     0x69aa58: ldur            w2, [x1, #0xf]
    // 0x69aa5c: DecompressPointer r2
    //     0x69aa5c: add             x2, x2, HEAP, lsl #32
    // 0x69aa60: LoadField: r1 = r2->field_3f
    //     0x69aa60: ldur            w1, [x2, #0x3f]
    // 0x69aa64: DecompressPointer r1
    //     0x69aa64: add             x1, x1, HEAP, lsl #32
    // 0x69aa68: LoadField: r2 = r1->field_7
    //     0x69aa68: ldur            w2, [x1, #7]
    // 0x69aa6c: DecompressPointer r2
    //     0x69aa6c: add             x2, x2, HEAP, lsl #32
    // 0x69aa70: cmp             w2, #2
    // 0x69aa74: r16 = true
    //     0x69aa74: add             x16, NULL, #0x20  ; true
    // 0x69aa78: r17 = false
    //     0x69aa78: add             x17, NULL, #0x30  ; false
    // 0x69aa7c: csel            x1, x16, x17, ne
    // 0x69aa80: mov             x0, x1
    // 0x69aa84: b               #0x69aa8c
    // 0x69aa88: r0 = false
    //     0x69aa88: add             x0, NULL, #0x30  ; false
    // 0x69aa8c: LeaveFrame
    //     0x69aa8c: mov             SP, fp
    //     0x69aa90: ldp             fp, lr, [SP], #0x10
    // 0x69aa94: ret
    //     0x69aa94: ret             
    // 0x69aa98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69aa98: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69aa9c: b               #0x69aa38
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69aaa0, size: 0x4c
    // 0x69aaa0: EnterFrame
    //     0x69aaa0: stp             fp, lr, [SP, #-0x10]!
    //     0x69aaa4: mov             fp, SP
    // 0x69aaa8: ldr             x0, [fp, #0x10]
    // 0x69aaac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69aaac: ldur            w1, [x0, #0x17]
    // 0x69aab0: DecompressPointer r1
    //     0x69aab0: add             x1, x1, HEAP, lsl #32
    // 0x69aab4: CheckStackOverflow
    //     0x69aab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69aab8: cmp             SP, x16
    //     0x69aabc: b.ls            #0x69aae4
    // 0x69aac0: LoadField: r0 = r1->field_f
    //     0x69aac0: ldur            w0, [x1, #0xf]
    // 0x69aac4: DecompressPointer r0
    //     0x69aac4: add             x0, x0, HEAP, lsl #32
    // 0x69aac8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69aac8: ldur            w1, [x0, #0x17]
    // 0x69aacc: DecompressPointer r1
    //     0x69aacc: add             x1, x1, HEAP, lsl #32
    // 0x69aad0: r2 = 8
    //     0x69aad0: movz            x2, #0x8
    // 0x69aad4: r0 = contains()
    //     0x69aad4: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69aad8: LeaveFrame
    //     0x69aad8: mov             SP, fp
    //     0x69aadc: ldp             fp, lr, [SP], #0x10
    // 0x69aae0: ret
    //     0x69aae0: ret             
    // 0x69aae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69aae4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69aae8: b               #0x69aac0
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69aaec, size: 0xc
    // 0x69aaec: r0 = "Each discovery increases research gained by 1%"
    //     0x69aaec: add             x0, PP, #0x29, lsl #12  ; [pp+0x291a8] "Each discovery increases research gained by 1%"
    //     0x69aaf0: ldr             x0, [x0, #0x1a8]
    // 0x69aaf4: ret
    //     0x69aaf4: ret             
  }
  [closure] void applyResearchPrestige(dynamic) {
    // ** addr: 0x69aaf8, size: 0x38
    // 0x69aaf8: EnterFrame
    //     0x69aaf8: stp             fp, lr, [SP, #-0x10]!
    //     0x69aafc: mov             fp, SP
    // 0x69ab00: ldr             x0, [fp, #0x10]
    // 0x69ab04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69ab04: ldur            w1, [x0, #0x17]
    // 0x69ab08: DecompressPointer r1
    //     0x69ab08: add             x1, x1, HEAP, lsl #32
    // 0x69ab0c: CheckStackOverflow
    //     0x69ab0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ab10: cmp             SP, x16
    //     0x69ab14: b.ls            #0x69ab28
    // 0x69ab18: r0 = applyResearchPrestige()
    //     0x69ab18: bl              #0x69ab30  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::applyResearchPrestige
    // 0x69ab1c: LeaveFrame
    //     0x69ab1c: mov             SP, fp
    //     0x69ab20: ldp             fp, lr, [SP], #0x10
    // 0x69ab24: ret
    //     0x69ab24: ret             
    // 0x69ab28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69ab28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ab2c: b               #0x69ab18
  }
  _ applyResearchPrestige(/* No info */) {
    // ** addr: 0x69ab30, size: 0x348
    // 0x69ab30: EnterFrame
    //     0x69ab30: stp             fp, lr, [SP, #-0x10]!
    //     0x69ab34: mov             fp, SP
    // 0x69ab38: AllocStack(0x28)
    //     0x69ab38: sub             SP, SP, #0x28
    // 0x69ab3c: SetupParameters(Chapter12GameState this /* r1 => r0, fp-0x8 */)
    //     0x69ab3c: mov             x0, x1
    //     0x69ab40: stur            x1, [fp, #-8]
    // 0x69ab44: CheckStackOverflow
    //     0x69ab44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ab48: cmp             SP, x16
    //     0x69ab4c: b.ls            #0x69ae48
    // 0x69ab50: mov             x1, x0
    // 0x69ab54: r0 = getResearchPrestigePoints()
    //     0x69ab54: bl              #0x69ae78  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getResearchPrestigePoints
    // 0x69ab58: mov             x3, x0
    // 0x69ab5c: ldur            x0, [fp, #-8]
    // 0x69ab60: stur            x3, [fp, #-0x18]
    // 0x69ab64: LoadField: r4 = r0->field_37
    //     0x69ab64: ldur            w4, [x0, #0x37]
    // 0x69ab68: DecompressPointer r4
    //     0x69ab68: add             x4, x4, HEAP, lsl #32
    // 0x69ab6c: mov             x1, x4
    // 0x69ab70: stur            x4, [fp, #-0x10]
    // 0x69ab74: r2 = Instance_Chapter12Stat
    //     0x69ab74: add             x2, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x69ab78: ldr             x2, [x2, #0x498]
    // 0x69ab7c: r0 = _getValueOrData()
    //     0x69ab7c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69ab80: mov             x1, x0
    // 0x69ab84: ldur            x0, [fp, #-0x10]
    // 0x69ab88: LoadField: r2 = r0->field_f
    //     0x69ab88: ldur            w2, [x0, #0xf]
    // 0x69ab8c: DecompressPointer r2
    //     0x69ab8c: add             x2, x2, HEAP, lsl #32
    // 0x69ab90: cmp             w2, w1
    // 0x69ab94: b.ne            #0x69ab9c
    // 0x69ab98: r1 = Null
    //     0x69ab98: mov             x1, NULL
    // 0x69ab9c: cmp             w1, NULL
    // 0x69aba0: b.ne            #0x69abac
    // 0x69aba4: r1 = Instance_CustomNum
    //     0x69aba4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69aba8: ldr             x1, [x1, #0xaf8]
    // 0x69abac: ldur            x3, [fp, #-8]
    // 0x69abb0: ldur            x2, [fp, #-0x18]
    // 0x69abb4: r0 = add()
    //     0x69abb4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x69abb8: ldur            x1, [fp, #-0x10]
    // 0x69abbc: mov             x3, x0
    // 0x69abc0: r2 = Instance_Chapter12Stat
    //     0x69abc0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x69abc4: ldr             x2, [x2, #0x498]
    // 0x69abc8: r0 = []=()
    //     0x69abc8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69abcc: ldur            x0, [fp, #-8]
    // 0x69abd0: LoadField: r3 = r0->field_3b
    //     0x69abd0: ldur            w3, [x0, #0x3b]
    // 0x69abd4: DecompressPointer r3
    //     0x69abd4: add             x3, x3, HEAP, lsl #32
    // 0x69abd8: mov             x1, x3
    // 0x69abdc: stur            x3, [fp, #-0x10]
    // 0x69abe0: r2 = Instance_Chapter12Stat
    //     0x69abe0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x69abe4: ldr             x2, [x2, #0x498]
    // 0x69abe8: r0 = _getValueOrData()
    //     0x69abe8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69abec: mov             x1, x0
    // 0x69abf0: ldur            x0, [fp, #-0x10]
    // 0x69abf4: LoadField: r2 = r0->field_f
    //     0x69abf4: ldur            w2, [x0, #0xf]
    // 0x69abf8: DecompressPointer r2
    //     0x69abf8: add             x2, x2, HEAP, lsl #32
    // 0x69abfc: cmp             w2, w1
    // 0x69ac00: b.ne            #0x69ac08
    // 0x69ac04: r1 = Null
    //     0x69ac04: mov             x1, NULL
    // 0x69ac08: cmp             w1, NULL
    // 0x69ac0c: b.ne            #0x69ac18
    // 0x69ac10: r1 = Instance_CustomNum
    //     0x69ac10: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69ac14: ldr             x1, [x1, #0xaf8]
    // 0x69ac18: ldur            x3, [fp, #-8]
    // 0x69ac1c: ldur            x2, [fp, #-0x18]
    // 0x69ac20: r0 = add()
    //     0x69ac20: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x69ac24: ldur            x1, [fp, #-0x10]
    // 0x69ac28: mov             x3, x0
    // 0x69ac2c: r2 = Instance_Chapter12Stat
    //     0x69ac2c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x69ac30: ldr             x2, [x2, #0x498]
    // 0x69ac34: r0 = []=()
    //     0x69ac34: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ac38: ldur            x0, [fp, #-8]
    // 0x69ac3c: LoadField: r1 = r0->field_8b
    //     0x69ac3c: ldur            w1, [x0, #0x8b]
    // 0x69ac40: DecompressPointer r1
    //     0x69ac40: add             x1, x1, HEAP, lsl #32
    // 0x69ac44: cmp             w1, NULL
    // 0x69ac48: b.ne            #0x69ac54
    // 0x69ac4c: d0 = 0.000000
    //     0x69ac4c: eor             v0.16b, v0.16b, v0.16b
    // 0x69ac50: b               #0x69ac58
    // 0x69ac54: LoadField: d0 = r1->field_7
    //     0x69ac54: ldur            d0, [x1, #7]
    // 0x69ac58: stur            d0, [fp, #-0x20]
    // 0x69ac5c: LoadField: r3 = r0->field_37
    //     0x69ac5c: ldur            w3, [x0, #0x37]
    // 0x69ac60: DecompressPointer r3
    //     0x69ac60: add             x3, x3, HEAP, lsl #32
    // 0x69ac64: mov             x1, x3
    // 0x69ac68: stur            x3, [fp, #-0x10]
    // 0x69ac6c: r2 = Instance_Chapter12Stat
    //     0x69ac6c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11498] Obj!Chapter12Stat@85fb61
    //     0x69ac70: ldr             x2, [x2, #0x498]
    // 0x69ac74: r0 = _getValueOrData()
    //     0x69ac74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69ac78: mov             x1, x0
    // 0x69ac7c: ldur            x0, [fp, #-0x10]
    // 0x69ac80: LoadField: r2 = r0->field_f
    //     0x69ac80: ldur            w2, [x0, #0xf]
    // 0x69ac84: DecompressPointer r2
    //     0x69ac84: add             x2, x2, HEAP, lsl #32
    // 0x69ac88: cmp             w2, w1
    // 0x69ac8c: b.ne            #0x69ac98
    // 0x69ac90: r0 = Null
    //     0x69ac90: mov             x0, NULL
    // 0x69ac94: b               #0x69ac9c
    // 0x69ac98: mov             x0, x1
    // 0x69ac9c: cmp             w0, NULL
    // 0x69aca0: b.ne            #0x69acac
    // 0x69aca4: r0 = Null
    //     0x69aca4: mov             x0, NULL
    // 0x69aca8: b               #0x69acdc
    // 0x69acac: LoadField: d0 = r0->field_7
    //     0x69acac: ldur            d0, [x0, #7]
    // 0x69acb0: r0 = inline_Allocate_Double()
    //     0x69acb0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69acb4: add             x0, x0, #0x10
    //     0x69acb8: cmp             x1, x0
    //     0x69acbc: b.ls            #0x69ae50
    //     0x69acc0: str             x0, [THR, #0x60]  ; THR::top
    //     0x69acc4: sub             x0, x0, #0xf
    //     0x69acc8: movz            x1, #0xe19c
    //     0x69accc: movk            x1, #0x3, lsl #16
    //     0x69acd0: stur            x1, [x0, #-1]
    // 0x69acd4: dmb             ishst
    // 0x69acd8: StoreField: r0->field_7 = d0
    //     0x69acd8: stur            d0, [x0, #7]
    // 0x69acdc: cmp             w0, NULL
    // 0x69ace0: b.ne            #0x69acec
    // 0x69ace4: d1 = 0.000000
    //     0x69ace4: eor             v1.16b, v1.16b, v1.16b
    // 0x69ace8: b               #0x69acf4
    // 0x69acec: LoadField: d0 = r0->field_7
    //     0x69acec: ldur            d0, [x0, #7]
    // 0x69acf0: mov             v1.16b, v0.16b
    // 0x69acf4: ldur            x3, [fp, #-8]
    // 0x69acf8: ldur            d0, [fp, #-0x20]
    // 0x69acfc: fmax            v2.2d, v0.2d, v1.2d
    // 0x69ad00: r0 = inline_Allocate_Double()
    //     0x69ad00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69ad04: add             x0, x0, #0x10
    //     0x69ad08: cmp             x1, x0
    //     0x69ad0c: b.ls            #0x69ae60
    //     0x69ad10: str             x0, [THR, #0x60]  ; THR::top
    //     0x69ad14: sub             x0, x0, #0xf
    //     0x69ad18: movz            x1, #0xe19c
    //     0x69ad1c: movk            x1, #0x3, lsl #16
    //     0x69ad20: stur            x1, [x0, #-1]
    // 0x69ad24: dmb             ishst
    // 0x69ad28: StoreField: r0->field_7 = d2
    //     0x69ad28: stur            d2, [x0, #7]
    // 0x69ad2c: StoreField: r3->field_8b = r0
    //     0x69ad2c: stur            w0, [x3, #0x8b]
    //     0x69ad30: ldurb           w16, [x3, #-1]
    //     0x69ad34: ldurb           w17, [x0, #-1]
    //     0x69ad38: and             x16, x17, x16, lsr #2
    //     0x69ad3c: tst             x16, HEAP, lsr #32
    //     0x69ad40: b.eq            #0x69ad48
    //     0x69ad44: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x69ad48: LoadField: r1 = r3->field_37
    //     0x69ad48: ldur            w1, [x3, #0x37]
    // 0x69ad4c: DecompressPointer r1
    //     0x69ad4c: add             x1, x1, HEAP, lsl #32
    // 0x69ad50: r2 = Instance_Chapter12Stat
    //     0x69ad50: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69ad54: ldr             x2, [x2, #0x488]
    // 0x69ad58: r0 = remove()
    //     0x69ad58: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69ad5c: ldur            x0, [fp, #-8]
    // 0x69ad60: LoadField: r1 = r0->field_3b
    //     0x69ad60: ldur            w1, [x0, #0x3b]
    // 0x69ad64: DecompressPointer r1
    //     0x69ad64: add             x1, x1, HEAP, lsl #32
    // 0x69ad68: r2 = Instance_Chapter12Stat
    //     0x69ad68: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69ad6c: ldr             x2, [x2, #0x488]
    // 0x69ad70: r0 = remove()
    //     0x69ad70: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69ad74: ldur            x0, [fp, #-8]
    // 0x69ad78: LoadField: r1 = r0->field_37
    //     0x69ad78: ldur            w1, [x0, #0x37]
    // 0x69ad7c: DecompressPointer r1
    //     0x69ad7c: add             x1, x1, HEAP, lsl #32
    // 0x69ad80: r2 = Instance_Chapter12Stat
    //     0x69ad80: add             x2, PP, #0x11, lsl #12  ; [pp+0x113f0] Obj!Chapter12Stat@85fcc1
    //     0x69ad84: ldr             x2, [x2, #0x3f0]
    // 0x69ad88: r0 = remove()
    //     0x69ad88: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69ad8c: ldur            x0, [fp, #-8]
    // 0x69ad90: LoadField: r1 = r0->field_37
    //     0x69ad90: ldur            w1, [x0, #0x37]
    // 0x69ad94: DecompressPointer r1
    //     0x69ad94: add             x1, x1, HEAP, lsl #32
    // 0x69ad98: r2 = Instance_Chapter12Stat
    //     0x69ad98: add             x2, PP, #0x11, lsl #12  ; [pp+0x113f8] Obj!Chapter12Stat@85fca1
    //     0x69ad9c: ldr             x2, [x2, #0x3f8]
    // 0x69ada0: r0 = remove()
    //     0x69ada0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69ada4: ldur            x0, [fp, #-8]
    // 0x69ada8: LoadField: r1 = r0->field_37
    //     0x69ada8: ldur            w1, [x0, #0x37]
    // 0x69adac: DecompressPointer r1
    //     0x69adac: add             x1, x1, HEAP, lsl #32
    // 0x69adb0: r2 = Instance_Chapter12Stat
    //     0x69adb0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11400] Obj!Chapter12Stat@85fc81
    //     0x69adb4: ldr             x2, [x2, #0x400]
    // 0x69adb8: r0 = remove()
    //     0x69adb8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69adbc: ldur            x0, [fp, #-8]
    // 0x69adc0: LoadField: r1 = r0->field_37
    //     0x69adc0: ldur            w1, [x0, #0x37]
    // 0x69adc4: DecompressPointer r1
    //     0x69adc4: add             x1, x1, HEAP, lsl #32
    // 0x69adc8: r2 = Instance_Chapter12Stat
    //     0x69adc8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11408] Obj!Chapter12Stat@85fc61
    //     0x69adcc: ldr             x2, [x2, #0x408]
    // 0x69add0: r0 = remove()
    //     0x69add0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69add4: ldur            x0, [fp, #-8]
    // 0x69add8: LoadField: r1 = r0->field_37
    //     0x69add8: ldur            w1, [x0, #0x37]
    // 0x69addc: DecompressPointer r1
    //     0x69addc: add             x1, x1, HEAP, lsl #32
    // 0x69ade0: r2 = Instance_Chapter12Stat
    //     0x69ade0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11410] Obj!Chapter12Stat@85fc41
    //     0x69ade4: ldr             x2, [x2, #0x410]
    // 0x69ade8: r0 = remove()
    //     0x69ade8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69adec: ldur            x0, [fp, #-8]
    // 0x69adf0: LoadField: r1 = r0->field_43
    //     0x69adf0: ldur            w1, [x0, #0x43]
    // 0x69adf4: DecompressPointer r1
    //     0x69adf4: add             x1, x1, HEAP, lsl #32
    // 0x69adf8: r0 = clear()
    //     0x69adf8: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x69adfc: ldur            x0, [fp, #-8]
    // 0x69ae00: LoadField: r1 = r0->field_47
    //     0x69ae00: ldur            w1, [x0, #0x47]
    // 0x69ae04: DecompressPointer r1
    //     0x69ae04: add             x1, x1, HEAP, lsl #32
    // 0x69ae08: r0 = clear()
    //     0x69ae08: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x69ae0c: r16 = <ChapterViewportState>
    //     0x69ae0c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9e0] TypeArguments: <ChapterViewportState>
    //     0x69ae10: ldr             x16, [x16, #0x9e0]
    // 0x69ae14: str             x16, [SP]
    // 0x69ae18: r4 = const [0x1, 0, 0, 0, null]
    //     0x69ae18: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x69ae1c: r0 = updateAll()
    //     0x69ae1c: bl              #0x4589c0  ; [package:state_groups/src/sync_state.dart] ::updateAll
    // 0x69ae20: ldur            x1, [fp, #-8]
    // 0x69ae24: r0 = resetAndRecomputeBoosts()
    //     0x69ae24: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x69ae28: ldur            x0, [fp, #-8]
    // 0x69ae2c: LoadField: r1 = r0->field_4b
    //     0x69ae2c: ldur            w1, [x0, #0x4b]
    // 0x69ae30: DecompressPointer r1
    //     0x69ae30: add             x1, x1, HEAP, lsl #32
    // 0x69ae34: r0 = clear()
    //     0x69ae34: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x69ae38: r0 = Null
    //     0x69ae38: mov             x0, NULL
    // 0x69ae3c: LeaveFrame
    //     0x69ae3c: mov             SP, fp
    //     0x69ae40: ldp             fp, lr, [SP], #0x10
    // 0x69ae44: ret
    //     0x69ae44: ret             
    // 0x69ae48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69ae48: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ae4c: b               #0x69ab50
    // 0x69ae50: SaveReg d0
    //     0x69ae50: str             q0, [SP, #-0x10]!
    // 0x69ae54: r0 = AllocateDouble()
    //     0x69ae54: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x69ae58: RestoreReg d0
    //     0x69ae58: ldr             q0, [SP], #0x10
    // 0x69ae5c: b               #0x69acd8
    // 0x69ae60: SaveReg d2
    //     0x69ae60: str             q2, [SP, #-0x10]!
    // 0x69ae64: SaveReg r3
    //     0x69ae64: str             x3, [SP, #-8]!
    // 0x69ae68: r0 = AllocateDouble()
    //     0x69ae68: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x69ae6c: RestoreReg r3
    //     0x69ae6c: ldr             x3, [SP], #8
    // 0x69ae70: RestoreReg d2
    //     0x69ae70: ldr             q2, [SP], #0x10
    // 0x69ae74: b               #0x69ad28
  }
  _ getResearchPrestigePoints(/* No info */) {
    // ** addr: 0x69ae78, size: 0xcc
    // 0x69ae78: EnterFrame
    //     0x69ae78: stp             fp, lr, [SP, #-0x10]!
    //     0x69ae7c: mov             fp, SP
    // 0x69ae80: AllocStack(0x10)
    //     0x69ae80: sub             SP, SP, #0x10
    // 0x69ae84: SetupParameters(Chapter12GameState this /* r1 => r0, fp-0x10 */)
    //     0x69ae84: mov             x0, x1
    //     0x69ae88: stur            x1, [fp, #-0x10]
    // 0x69ae8c: CheckStackOverflow
    //     0x69ae8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ae90: cmp             SP, x16
    //     0x69ae94: b.ls            #0x69af3c
    // 0x69ae98: LoadField: r3 = r0->field_3b
    //     0x69ae98: ldur            w3, [x0, #0x3b]
    // 0x69ae9c: DecompressPointer r3
    //     0x69ae9c: add             x3, x3, HEAP, lsl #32
    // 0x69aea0: mov             x1, x3
    // 0x69aea4: stur            x3, [fp, #-8]
    // 0x69aea8: r2 = Instance_Chapter12Stat
    //     0x69aea8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69aeac: ldr             x2, [x2, #0x488]
    // 0x69aeb0: r0 = _getValueOrData()
    //     0x69aeb0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69aeb4: mov             x1, x0
    // 0x69aeb8: ldur            x0, [fp, #-8]
    // 0x69aebc: LoadField: r2 = r0->field_f
    //     0x69aebc: ldur            w2, [x0, #0xf]
    // 0x69aec0: DecompressPointer r2
    //     0x69aec0: add             x2, x2, HEAP, lsl #32
    // 0x69aec4: cmp             w2, w1
    // 0x69aec8: b.ne            #0x69aed4
    // 0x69aecc: r0 = Null
    //     0x69aecc: mov             x0, NULL
    // 0x69aed0: b               #0x69aed8
    // 0x69aed4: mov             x0, x1
    // 0x69aed8: cmp             w0, NULL
    // 0x69aedc: b.ne            #0x69aeec
    // 0x69aee0: r3 = Instance_CustomNum
    //     0x69aee0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69aee4: ldr             x3, [x3, #0xaf8]
    // 0x69aee8: b               #0x69aef0
    // 0x69aeec: mov             x3, x0
    // 0x69aef0: ldur            x0, [fp, #-0x10]
    // 0x69aef4: stur            x3, [fp, #-8]
    // 0x69aef8: LoadField: r1 = r0->field_43
    //     0x69aef8: ldur            w1, [x0, #0x43]
    // 0x69aefc: DecompressPointer r1
    //     0x69aefc: add             x1, x1, HEAP, lsl #32
    // 0x69af00: r2 = 236
    //     0x69af00: movz            x2, #0xec
    // 0x69af04: r0 = containsKey()
    //     0x69af04: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69af08: tbnz            w0, #4, #0x69af18
    // 0x69af0c: r3 = Instance_CustomNum
    //     0x69af0c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x69af10: ldr             x3, [x3, #0x970]
    // 0x69af14: b               #0x69af20
    // 0x69af18: r3 = Instance_CustomNum
    //     0x69af18: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69af1c: ldr             x3, [x3, #0xa70]
    // 0x69af20: ldur            x2, [fp, #-8]
    // 0x69af24: r1 = Instance_CustomNum
    //     0x69af24: add             x1, PP, #0x29, lsl #12  ; [pp+0x291b0] Obj!CustomNum@82b6e1
    //     0x69af28: ldr             x1, [x1, #0x1b0]
    // 0x69af2c: r0 = mult3()
    //     0x69af2c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x69af30: LeaveFrame
    //     0x69af30: mov             SP, fp
    //     0x69af34: ldp             fp, lr, [SP], #0x10
    // 0x69af38: ret
    //     0x69af38: ret             
    // 0x69af3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69af3c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69af40: b               #0x69ae98
  }
  [closure] CustomNum getResearchPrestigePoints(dynamic) {
    // ** addr: 0x69af44, size: 0x38
    // 0x69af44: EnterFrame
    //     0x69af44: stp             fp, lr, [SP, #-0x10]!
    //     0x69af48: mov             fp, SP
    // 0x69af4c: ldr             x0, [fp, #0x10]
    // 0x69af50: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69af50: ldur            w1, [x0, #0x17]
    // 0x69af54: DecompressPointer r1
    //     0x69af54: add             x1, x1, HEAP, lsl #32
    // 0x69af58: CheckStackOverflow
    //     0x69af58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69af5c: cmp             SP, x16
    //     0x69af60: b.ls            #0x69af74
    // 0x69af64: r0 = getResearchPrestigePoints()
    //     0x69af64: bl              #0x69ae78  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getResearchPrestigePoints
    // 0x69af68: LeaveFrame
    //     0x69af68: mov             SP, fp
    //     0x69af6c: ldp             fp, lr, [SP], #0x10
    // 0x69af70: ret
    //     0x69af70: ret             
    // 0x69af74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69af74: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69af78: b               #0x69af64
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69af7c, size: 0xc
    // 0x69af7c: r0 = "Record Research"
    //     0x69af7c: add             x0, PP, #0x29, lsl #12  ; [pp+0x291b8] "Record Research"
    //     0x69af80: ldr             x0, [x0, #0x1b8]
    // 0x69af84: ret
    //     0x69af84: ret             
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x69af88, size: 0xac
    // 0x69af88: EnterFrame
    //     0x69af88: stp             fp, lr, [SP, #-0x10]!
    //     0x69af8c: mov             fp, SP
    // 0x69af90: AllocStack(0x10)
    //     0x69af90: sub             SP, SP, #0x10
    // 0x69af94: SetupParameters([dynamic _ /* r0 */])
    //     0x69af94: ldr             x0, [fp, #0x10]
    //     0x69af98: ldur            w3, [x0, #0x17]
    //     0x69af9c: add             x3, x3, HEAP, lsl #32
    //     0x69afa0: stur            x3, [fp, #-8]
    // 0x69afa4: CheckStackOverflow
    //     0x69afa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69afa8: cmp             SP, x16
    //     0x69afac: b.ls            #0x69b020
    // 0x69afb0: r0 = LoadStaticField(0xf7c)
    //     0x69afb0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69afb4: ldr             x0, [x0, #0x1ef8]
    // 0x69afb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69afbc: cmp             w0, w16
    // 0x69afc0: b.eq            #0x69b028
    // 0x69afc4: LoadField: r1 = r0->field_13
    //     0x69afc4: ldur            w1, [x0, #0x13]
    // 0x69afc8: DecompressPointer r1
    //     0x69afc8: add             x1, x1, HEAP, lsl #32
    // 0x69afcc: r2 = 50
    //     0x69afcc: movz            x2, #0x32
    // 0x69afd0: r0 = containsKey()
    //     0x69afd0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69afd4: tbnz            w0, #4, #0x69b010
    // 0x69afd8: ldur            x0, [fp, #-8]
    // 0x69afdc: LoadField: r1 = r0->field_f
    //     0x69afdc: ldur            w1, [x0, #0xf]
    // 0x69afe0: DecompressPointer r1
    //     0x69afe0: add             x1, x1, HEAP, lsl #32
    // 0x69afe4: r16 = false
    //     0x69afe4: add             x16, NULL, #0x30  ; false
    // 0x69afe8: str             x16, [SP]
    // 0x69afec: r2 = 25
    //     0x69afec: movz            x2, #0x19
    // 0x69aff0: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x69aff0: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x69aff4: ldr             x4, [x4, #0x5c0]
    // 0x69aff8: r0 = notifyDialoguePoint()
    //     0x69aff8: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x69affc: r0 = "Intermission"
    //     0x69affc: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x69b000: ldr             x0, [x0, #0x5c8]
    // 0x69b004: LeaveFrame
    //     0x69b004: mov             SP, fp
    //     0x69b008: ldp             fp, lr, [SP], #0x10
    // 0x69b00c: ret
    //     0x69b00c: ret             
    // 0x69b010: r0 = Null
    //     0x69b010: mov             x0, NULL
    // 0x69b014: LeaveFrame
    //     0x69b014: mov             SP, fp
    //     0x69b018: ldp             fp, lr, [SP], #0x10
    // 0x69b01c: ret
    //     0x69b01c: ret             
    // 0x69b020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b020: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b024: b               #0x69afb0
    // 0x69b028: r9 = coreData
    //     0x69b028: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69b02c: ldr             x9, [x9, #0x530]
    // 0x69b030: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69b030: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69b034, size: 0x4c
    // 0x69b034: EnterFrame
    //     0x69b034: stp             fp, lr, [SP, #-0x10]!
    //     0x69b038: mov             fp, SP
    // 0x69b03c: ldr             x0, [fp, #0x10]
    // 0x69b040: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69b040: ldur            w1, [x0, #0x17]
    // 0x69b044: DecompressPointer r1
    //     0x69b044: add             x1, x1, HEAP, lsl #32
    // 0x69b048: CheckStackOverflow
    //     0x69b048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b04c: cmp             SP, x16
    //     0x69b050: b.ls            #0x69b078
    // 0x69b054: LoadField: r0 = r1->field_f
    //     0x69b054: ldur            w0, [x1, #0xf]
    // 0x69b058: DecompressPointer r0
    //     0x69b058: add             x0, x0, HEAP, lsl #32
    // 0x69b05c: LoadField: r1 = r0->field_1b
    //     0x69b05c: ldur            w1, [x0, #0x1b]
    // 0x69b060: DecompressPointer r1
    //     0x69b060: add             x1, x1, HEAP, lsl #32
    // 0x69b064: r2 = 202
    //     0x69b064: movz            x2, #0xca
    // 0x69b068: r0 = contains()
    //     0x69b068: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69b06c: LeaveFrame
    //     0x69b06c: mov             SP, fp
    //     0x69b070: ldp             fp, lr, [SP], #0x10
    // 0x69b074: ret
    //     0x69b074: ret             
    // 0x69b078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b078: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b07c: b               #0x69b054
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69b080, size: 0x58
    // 0x69b080: EnterFrame
    //     0x69b080: stp             fp, lr, [SP, #-0x10]!
    //     0x69b084: mov             fp, SP
    // 0x69b088: CheckStackOverflow
    //     0x69b088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b08c: cmp             SP, x16
    //     0x69b090: b.ls            #0x69b0c4
    // 0x69b094: r0 = LoadStaticField(0xf7c)
    //     0x69b094: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69b098: ldr             x0, [x0, #0x1ef8]
    // 0x69b09c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69b0a0: cmp             w0, w16
    // 0x69b0a4: b.eq            #0x69b0cc
    // 0x69b0a8: LoadField: r1 = r0->field_13
    //     0x69b0a8: ldur            w1, [x0, #0x13]
    // 0x69b0ac: DecompressPointer r1
    //     0x69b0ac: add             x1, x1, HEAP, lsl #32
    // 0x69b0b0: r2 = 50
    //     0x69b0b0: movz            x2, #0x32
    // 0x69b0b4: r0 = containsKey()
    //     0x69b0b4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69b0b8: LeaveFrame
    //     0x69b0b8: mov             SP, fp
    //     0x69b0bc: ldp             fp, lr, [SP], #0x10
    // 0x69b0c0: ret
    //     0x69b0c0: ret             
    // 0x69b0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b0c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b0c8: b               #0x69b094
    // 0x69b0cc: r9 = coreData
    //     0x69b0cc: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69b0d0: ldr             x9, [x9, #0x530]
    // 0x69b0d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69b0d4: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x69b0d8, size: 0x78
    // 0x69b0d8: EnterFrame
    //     0x69b0d8: stp             fp, lr, [SP, #-0x10]!
    //     0x69b0dc: mov             fp, SP
    // 0x69b0e0: AllocStack(0x18)
    //     0x69b0e0: sub             SP, SP, #0x18
    // 0x69b0e4: SetupParameters(Chapter12GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x69b0e4: stur            NULL, [fp, #-8]
    //     0x69b0e8: movz            x0, #0
    //     0x69b0ec: add             x1, fp, w0, sxtw #2
    //     0x69b0f0: ldr             x1, [x1, #0x18]
    //     0x69b0f4: add             x2, fp, w0, sxtw #2
    //     0x69b0f8: ldr             x2, [x2, #0x10]
    //     0x69b0fc: stur            x2, [fp, #-0x18]
    //     0x69b100: ldur            w3, [x1, #0x17]
    //     0x69b104: add             x3, x3, HEAP, lsl #32
    //     0x69b108: stur            x3, [fp, #-0x10]
    // 0x69b10c: CheckStackOverflow
    //     0x69b10c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b110: cmp             SP, x16
    //     0x69b114: b.ls            #0x69b148
    // 0x69b118: InitAsync() -> Future<void?>
    //     0x69b118: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x69b11c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x69b120: ldur            x2, [fp, #-0x10]
    // 0x69b124: r1 = Function '<anonymous closure>':.
    //     0x69b124: add             x1, PP, #0x29, lsl #12  ; [pp+0x291c0] AnonymousClosure: (0x69b150), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::build (0x699c00)
    //     0x69b128: ldr             x1, [x1, #0x1c0]
    // 0x69b12c: r0 = AllocateClosure()
    //     0x69b12c: bl              #0x826750  ; AllocateClosureStub
    // 0x69b130: ldur            x1, [fp, #-0x18]
    // 0x69b134: mov             x3, x0
    // 0x69b138: r2 = 25
    //     0x69b138: movz            x2, #0x19
    // 0x69b13c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x69b13c: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x69b140: r0 = displaySlackPage()
    //     0x69b140: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x69b144: r0 = ReturnAsync()
    //     0x69b144: b               #0x353380  ; ReturnAsyncStub
    // 0x69b148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b148: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b14c: b               #0x69b118
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x69b150, size: 0x78
    // 0x69b150: EnterFrame
    //     0x69b150: stp             fp, lr, [SP, #-0x10]!
    //     0x69b154: mov             fp, SP
    // 0x69b158: AllocStack(0x8)
    //     0x69b158: sub             SP, SP, #8
    // 0x69b15c: SetupParameters([dynamic _ /* r0 */])
    //     0x69b15c: ldr             x0, [fp, #0x20]
    //     0x69b160: ldur            w3, [x0, #0x17]
    //     0x69b164: add             x3, x3, HEAP, lsl #32
    //     0x69b168: stur            x3, [fp, #-8]
    // 0x69b16c: CheckStackOverflow
    //     0x69b16c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b170: cmp             SP, x16
    //     0x69b174: b.ls            #0x69b1c0
    // 0x69b178: LoadField: r1 = r3->field_f
    //     0x69b178: ldur            w1, [x3, #0xf]
    // 0x69b17c: DecompressPointer r1
    //     0x69b17c: add             x1, x1, HEAP, lsl #32
    // 0x69b180: r2 = 25
    //     0x69b180: movz            x2, #0x19
    // 0x69b184: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x69b184: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x69b188: r0 = notifyDialoguePoint()
    //     0x69b188: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x69b18c: ldr             x0, [fp, #0x10]
    // 0x69b190: r1 = LoadInt32Instr(r0)
    //     0x69b190: sbfx            x1, x0, #1, #0x1f
    //     0x69b194: tbz             w0, #0, #0x69b19c
    //     0x69b198: ldur            x1, [x0, #7]
    // 0x69b19c: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x69b19c: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x69b1a0: ldur            x0, [fp, #-8]
    // 0x69b1a4: LoadField: r1 = r0->field_f
    //     0x69b1a4: ldur            w1, [x0, #0xf]
    // 0x69b1a8: DecompressPointer r1
    //     0x69b1a8: add             x1, x1, HEAP, lsl #32
    // 0x69b1ac: r0 = saveDeferred()
    //     0x69b1ac: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x69b1b0: r0 = Null
    //     0x69b1b0: mov             x0, NULL
    // 0x69b1b4: LeaveFrame
    //     0x69b1b4: mov             SP, fp
    //     0x69b1b8: ldp             fp, lr, [SP], #0x10
    // 0x69b1bc: ret
    //     0x69b1bc: ret             
    // 0x69b1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b1c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b1c4: b               #0x69b178
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69b214, size: 0x80
    // 0x69b214: EnterFrame
    //     0x69b214: stp             fp, lr, [SP, #-0x10]!
    //     0x69b218: mov             fp, SP
    // 0x69b21c: AllocStack(0x8)
    //     0x69b21c: sub             SP, SP, #8
    // 0x69b220: SetupParameters([dynamic _ /* r0 */])
    //     0x69b220: ldr             x0, [fp, #0x10]
    //     0x69b224: ldur            w3, [x0, #0x17]
    //     0x69b228: add             x3, x3, HEAP, lsl #32
    //     0x69b22c: stur            x3, [fp, #-8]
    // 0x69b230: CheckStackOverflow
    //     0x69b230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b234: cmp             SP, x16
    //     0x69b238: b.ls            #0x69b28c
    // 0x69b23c: LoadField: r0 = r3->field_f
    //     0x69b23c: ldur            w0, [x3, #0xf]
    // 0x69b240: DecompressPointer r0
    //     0x69b240: add             x0, x0, HEAP, lsl #32
    // 0x69b244: LoadField: r1 = r0->field_1b
    //     0x69b244: ldur            w1, [x0, #0x1b]
    // 0x69b248: DecompressPointer r1
    //     0x69b248: add             x1, x1, HEAP, lsl #32
    // 0x69b24c: r2 = 2
    //     0x69b24c: movz            x2, #0x2
    // 0x69b250: r0 = contains()
    //     0x69b250: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69b254: tbnz            w0, #4, #0x69b27c
    // 0x69b258: ldur            x0, [fp, #-8]
    // 0x69b25c: LoadField: r1 = r0->field_f
    //     0x69b25c: ldur            w1, [x0, #0xf]
    // 0x69b260: DecompressPointer r1
    //     0x69b260: add             x1, x1, HEAP, lsl #32
    // 0x69b264: LoadField: r0 = r1->field_1b
    //     0x69b264: ldur            w0, [x1, #0x1b]
    // 0x69b268: DecompressPointer r0
    //     0x69b268: add             x0, x0, HEAP, lsl #32
    // 0x69b26c: mov             x1, x0
    // 0x69b270: r2 = 4
    //     0x69b270: movz            x2, #0x4
    // 0x69b274: r0 = contains()
    //     0x69b274: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69b278: b               #0x69b280
    // 0x69b27c: r0 = false
    //     0x69b27c: add             x0, NULL, #0x30  ; false
    // 0x69b280: LeaveFrame
    //     0x69b280: mov             SP, fp
    //     0x69b284: ldp             fp, lr, [SP], #0x10
    // 0x69b288: ret
    //     0x69b288: ret             
    // 0x69b28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b28c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b290: b               #0x69b23c
  }
  [closure] GeneratorInfo<Chapter12Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x69b294, size: 0x3c
    // 0x69b294: EnterFrame
    //     0x69b294: stp             fp, lr, [SP, #-0x10]!
    //     0x69b298: mov             fp, SP
    // 0x69b29c: ldr             x0, [fp, #0x18]
    // 0x69b2a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69b2a0: ldur            w1, [x0, #0x17]
    // 0x69b2a4: DecompressPointer r1
    //     0x69b2a4: add             x1, x1, HEAP, lsl #32
    // 0x69b2a8: CheckStackOverflow
    //     0x69b2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b2ac: cmp             SP, x16
    //     0x69b2b0: b.ls            #0x69b2c8
    // 0x69b2b4: ldr             x2, [fp, #0x10]
    // 0x69b2b8: r0 = getGeneratorInfo()
    //     0x69b2b8: bl              #0x80d210  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getGeneratorInfo
    // 0x69b2bc: LeaveFrame
    //     0x69b2bc: mov             SP, fp
    //     0x69b2c0: ldp             fp, lr, [SP], #0x10
    // 0x69b2c4: ret
    //     0x69b2c4: ret             
    // 0x69b2c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b2c8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b2cc: b               #0x69b2b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x69b2d0, size: 0x1c4
    // 0x69b2d0: EnterFrame
    //     0x69b2d0: stp             fp, lr, [SP, #-0x10]!
    //     0x69b2d4: mov             fp, SP
    // 0x69b2d8: AllocStack(0x28)
    //     0x69b2d8: sub             SP, SP, #0x28
    // 0x69b2dc: SetupParameters([dynamic _ /* r0 */])
    //     0x69b2dc: ldr             x0, [fp, #0x10]
    //     0x69b2e0: ldur            w3, [x0, #0x17]
    //     0x69b2e4: add             x3, x3, HEAP, lsl #32
    //     0x69b2e8: stur            x3, [fp, #-0x10]
    // 0x69b2ec: CheckStackOverflow
    //     0x69b2ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b2f0: cmp             SP, x16
    //     0x69b2f4: b.ls            #0x69b480
    // 0x69b2f8: LoadField: r0 = r3->field_f
    //     0x69b2f8: ldur            w0, [x3, #0xf]
    // 0x69b2fc: DecompressPointer r0
    //     0x69b2fc: add             x0, x0, HEAP, lsl #32
    // 0x69b300: LoadField: r4 = r0->field_37
    //     0x69b300: ldur            w4, [x0, #0x37]
    // 0x69b304: DecompressPointer r4
    //     0x69b304: add             x4, x4, HEAP, lsl #32
    // 0x69b308: mov             x1, x4
    // 0x69b30c: stur            x4, [fp, #-8]
    // 0x69b310: r2 = Instance_Chapter12Stat
    //     0x69b310: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69b314: ldr             x2, [x2, #0x488]
    // 0x69b318: r0 = _getValueOrData()
    //     0x69b318: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69b31c: ldur            x2, [fp, #-8]
    // 0x69b320: LoadField: r1 = r2->field_f
    //     0x69b320: ldur            w1, [x2, #0xf]
    // 0x69b324: DecompressPointer r1
    //     0x69b324: add             x1, x1, HEAP, lsl #32
    // 0x69b328: cmp             w1, w0
    // 0x69b32c: b.ne            #0x69b334
    // 0x69b330: r0 = Null
    //     0x69b330: mov             x0, NULL
    // 0x69b334: cmp             w0, NULL
    // 0x69b338: b.ne            #0x69b348
    // 0x69b33c: r5 = Instance_CustomNum
    //     0x69b33c: add             x5, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69b340: ldr             x5, [x5, #0xaf8]
    // 0x69b344: b               #0x69b34c
    // 0x69b348: mov             x5, x0
    // 0x69b34c: ldur            x3, [fp, #-0x10]
    // 0x69b350: stur            x5, [fp, #-0x20]
    // 0x69b354: r0 = LoadStaticField(0xf7c)
    //     0x69b354: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69b358: ldr             x0, [x0, #0x1ef8]
    // 0x69b35c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69b360: cmp             w0, w16
    // 0x69b364: b.eq            #0x69b488
    // 0x69b368: stur            x0, [fp, #-0x18]
    // 0x69b36c: LoadField: r1 = r3->field_f
    //     0x69b36c: ldur            w1, [x3, #0xf]
    // 0x69b370: DecompressPointer r1
    //     0x69b370: add             x1, x1, HEAP, lsl #32
    // 0x69b374: LoadField: r4 = r1->field_23
    //     0x69b374: ldur            x4, [x1, #0x23]
    // 0x69b378: mov             x1, x4
    // 0x69b37c: r0 = difficultyMultiplier()
    //     0x69b37c: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x69b380: ldur            x1, [fp, #-0x18]
    // 0x69b384: mov             x2, x0
    // 0x69b388: r3 = "12"
    //     0x69b388: add             x3, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x69b38c: ldr             x3, [x3, #0x330]
    // 0x69b390: r0 = cachedCompletionTokenBoost()
    //     0x69b390: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x69b394: mov             x3, x0
    // 0x69b398: ldur            x0, [fp, #-0x10]
    // 0x69b39c: stur            x3, [fp, #-0x28]
    // 0x69b3a0: LoadField: r1 = r0->field_f
    //     0x69b3a0: ldur            w1, [x0, #0xf]
    // 0x69b3a4: DecompressPointer r1
    //     0x69b3a4: add             x1, x1, HEAP, lsl #32
    // 0x69b3a8: LoadField: r4 = r1->field_2f
    //     0x69b3a8: ldur            w4, [x1, #0x2f]
    // 0x69b3ac: DecompressPointer r4
    //     0x69b3ac: add             x4, x4, HEAP, lsl #32
    // 0x69b3b0: mov             x1, x4
    // 0x69b3b4: stur            x4, [fp, #-0x18]
    // 0x69b3b8: r2 = Instance_Chapter12Stat
    //     0x69b3b8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69b3bc: ldr             x2, [x2, #0x488]
    // 0x69b3c0: r0 = _getValueOrData()
    //     0x69b3c0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69b3c4: mov             x1, x0
    // 0x69b3c8: ldur            x0, [fp, #-0x18]
    // 0x69b3cc: LoadField: r2 = r0->field_f
    //     0x69b3cc: ldur            w2, [x0, #0xf]
    // 0x69b3d0: DecompressPointer r2
    //     0x69b3d0: add             x2, x2, HEAP, lsl #32
    // 0x69b3d4: cmp             w2, w1
    // 0x69b3d8: b.ne            #0x69b3e4
    // 0x69b3dc: r0 = Null
    //     0x69b3dc: mov             x0, NULL
    // 0x69b3e0: b               #0x69b3e8
    // 0x69b3e4: mov             x0, x1
    // 0x69b3e8: cmp             w0, NULL
    // 0x69b3ec: b.ne            #0x69b3f8
    // 0x69b3f0: r0 = Null
    //     0x69b3f0: mov             x0, NULL
    // 0x69b3f4: b               #0x69b404
    // 0x69b3f8: LoadField: r1 = r0->field_f
    //     0x69b3f8: ldur            w1, [x0, #0xf]
    // 0x69b3fc: DecompressPointer r1
    //     0x69b3fc: add             x1, x1, HEAP, lsl #32
    // 0x69b400: mov             x0, x1
    // 0x69b404: cmp             w0, NULL
    // 0x69b408: b.ne            #0x69b418
    // 0x69b40c: r2 = Instance_CustomNum
    //     0x69b40c: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69b410: ldr             x2, [x2, #0xa70]
    // 0x69b414: b               #0x69b41c
    // 0x69b418: mov             x2, x0
    // 0x69b41c: ldur            x0, [fp, #-0x10]
    // 0x69b420: ldur            x1, [fp, #-0x28]
    // 0x69b424: r0 = mult2()
    //     0x69b424: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x69b428: ldur            x1, [fp, #-0x20]
    // 0x69b42c: mov             x2, x0
    // 0x69b430: r0 = add()
    //     0x69b430: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x69b434: ldur            x1, [fp, #-8]
    // 0x69b438: mov             x3, x0
    // 0x69b43c: r2 = Instance_Chapter12Stat
    //     0x69b43c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69b440: ldr             x2, [x2, #0x488]
    // 0x69b444: r0 = []=()
    //     0x69b444: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69b448: ldur            x0, [fp, #-0x10]
    // 0x69b44c: LoadField: r1 = r0->field_f
    //     0x69b44c: ldur            w1, [x0, #0xf]
    // 0x69b450: DecompressPointer r1
    //     0x69b450: add             x1, x1, HEAP, lsl #32
    // 0x69b454: r2 = Instance_Chapter12Stat
    //     0x69b454: add             x2, PP, #0x11, lsl #12  ; [pp+0x11488] Obj!Chapter12Stat@85fb81
    //     0x69b458: ldr             x2, [x2, #0x488]
    // 0x69b45c: r0 = notifyStatGained()
    //     0x69b45c: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x69b460: ldur            x0, [fp, #-0x10]
    // 0x69b464: LoadField: r1 = r0->field_f
    //     0x69b464: ldur            w1, [x0, #0xf]
    // 0x69b468: DecompressPointer r1
    //     0x69b468: add             x1, x1, HEAP, lsl #32
    // 0x69b46c: r0 = saveDeferred()
    //     0x69b46c: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x69b470: r0 = Null
    //     0x69b470: mov             x0, NULL
    // 0x69b474: LeaveFrame
    //     0x69b474: mov             SP, fp
    //     0x69b478: ldp             fp, lr, [SP], #0x10
    // 0x69b47c: ret
    //     0x69b47c: ret             
    // 0x69b480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b480: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b484: b               #0x69b2f8
    // 0x69b488: r9 = coreData
    //     0x69b488: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69b48c: ldr             x9, [x9, #0x530]
    // 0x69b490: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69b490: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x69b494, size: 0x4c
    // 0x69b494: EnterFrame
    //     0x69b494: stp             fp, lr, [SP, #-0x10]!
    //     0x69b498: mov             fp, SP
    // 0x69b49c: ldr             x0, [fp, #0x10]
    // 0x69b4a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69b4a0: ldur            w1, [x0, #0x17]
    // 0x69b4a4: DecompressPointer r1
    //     0x69b4a4: add             x1, x1, HEAP, lsl #32
    // 0x69b4a8: CheckStackOverflow
    //     0x69b4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b4ac: cmp             SP, x16
    //     0x69b4b0: b.ls            #0x69b4d8
    // 0x69b4b4: LoadField: r0 = r1->field_f
    //     0x69b4b4: ldur            w0, [x1, #0xf]
    // 0x69b4b8: DecompressPointer r0
    //     0x69b4b8: add             x0, x0, HEAP, lsl #32
    // 0x69b4bc: mov             x1, x0
    // 0x69b4c0: r2 = 5000
    //     0x69b4c0: movz            x2, #0x1388
    // 0x69b4c4: r0 = longPressAction()
    //     0x69b4c4: bl              #0x543e48  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::longPressAction
    // 0x69b4c8: r0 = Null
    //     0x69b4c8: mov             x0, NULL
    // 0x69b4cc: LeaveFrame
    //     0x69b4cc: mov             SP, fp
    //     0x69b4d0: ldp             fp, lr, [SP], #0x10
    // 0x69b4d4: ret
    //     0x69b4d4: ret             
    // 0x69b4d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b4d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b4dc: b               #0x69b4b4
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x69b4e0, size: 0x24
    // 0x69b4e0: ldr             x1, [SP, #8]
    // 0x69b4e4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69b4e4: ldur            w2, [x1, #0x17]
    // 0x69b4e8: DecompressPointer r2
    //     0x69b4e8: add             x2, x2, HEAP, lsl #32
    // 0x69b4ec: LoadField: r1 = r2->field_f
    //     0x69b4ec: ldur            w1, [x2, #0xf]
    // 0x69b4f0: DecompressPointer r1
    //     0x69b4f0: add             x1, x1, HEAP, lsl #32
    // 0x69b4f4: ldr             x2, [SP]
    // 0x69b4f8: StoreField: r1->field_97 = r2
    //     0x69b4f8: stur            w2, [x1, #0x97]
    // 0x69b4fc: r0 = Null
    //     0x69b4fc: mov             x0, NULL
    // 0x69b500: ret
    //     0x69b500: ret             
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d210, size: 0x7c
    // 0x80d210: EnterFrame
    //     0x80d210: stp             fp, lr, [SP, #-0x10]!
    //     0x80d214: mov             fp, SP
    // 0x80d218: AllocStack(0x8)
    //     0x80d218: sub             SP, SP, #8
    // 0x80d21c: CheckStackOverflow
    //     0x80d21c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d220: cmp             SP, x16
    //     0x80d224: b.ls            #0x80d274
    // 0x80d228: LoadField: r0 = r1->field_8f
    //     0x80d228: ldur            w0, [x1, #0x8f]
    // 0x80d22c: DecompressPointer r0
    //     0x80d22c: add             x0, x0, HEAP, lsl #32
    // 0x80d230: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d234: cmp             w0, w16
    // 0x80d238: b.eq            #0x80d27c
    // 0x80d23c: mov             x1, x0
    // 0x80d240: stur            x0, [fp, #-8]
    // 0x80d244: r0 = _getValueOrData()
    //     0x80d244: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d248: ldur            x1, [fp, #-8]
    // 0x80d24c: LoadField: r2 = r1->field_f
    //     0x80d24c: ldur            w2, [x1, #0xf]
    // 0x80d250: DecompressPointer r2
    //     0x80d250: add             x2, x2, HEAP, lsl #32
    // 0x80d254: cmp             w2, w0
    // 0x80d258: b.ne            #0x80d260
    // 0x80d25c: r0 = Null
    //     0x80d25c: mov             x0, NULL
    // 0x80d260: cmp             w0, NULL
    // 0x80d264: b.eq            #0x80d288
    // 0x80d268: LeaveFrame
    //     0x80d268: mov             SP, fp
    //     0x80d26c: ldp             fp, lr, [SP], #0x10
    // 0x80d270: ret
    //     0x80d270: ret             
    // 0x80d274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d274: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d278: b               #0x80d228
    // 0x80d27c: r9 = generators
    //     0x80d27c: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a6d8] Field <Chapter12GameState.generators>: late (offset: 0x90)
    //     0x80d280: ldr             x9, [x9, #0x6d8]
    // 0x80d284: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d284: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d288: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d288: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d120, size: 0xc
    // 0x81d120: r0 = "12"
    //     0x81d120: add             x0, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x81d124: ldr             x0, [x0, #0x330]
    // 0x81d128: ret
    //     0x81d128: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f684, size: 0x24
    // 0x81f684: EnterFrame
    //     0x81f684: stp             fp, lr, [SP, #-0x10]!
    //     0x81f688: mov             fp, SP
    // 0x81f68c: ldr             x2, [fp, #0x10]
    // 0x81f690: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f690: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb38] AnonymousClosure: (0x3dac58), in [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::getCostToBuyOneMoreGenerator (0x3da7a0)
    //     0x81f694: ldr             x1, [x1, #0xb38]
    // 0x81f698: r0 = AllocateClosure()
    //     0x81f698: bl              #0x826750  ; AllocateClosureStub
    // 0x81f69c: LeaveFrame
    //     0x81f69c: mov             SP, fp
    //     0x81f6a0: ldp             fp, lr, [SP], #0x10
    // 0x81f6a4: ret
    //     0x81f6a4: ret             
  }
}

// class id: 4186, size: 0x14, field offset: 0x14
enum Chapter12Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724880, size: 0x64
    // 0x724880: EnterFrame
    //     0x724880: stp             fp, lr, [SP, #-0x10]!
    //     0x724884: mov             fp, SP
    // 0x724888: AllocStack(0x10)
    //     0x724888: sub             SP, SP, #0x10
    // 0x72488c: SetupParameters(Chapter12Stat this /* r1 => r0, fp-0x8 */)
    //     0x72488c: mov             x0, x1
    //     0x724890: stur            x1, [fp, #-8]
    // 0x724894: CheckStackOverflow
    //     0x724894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724898: cmp             SP, x16
    //     0x72489c: b.ls            #0x7248dc
    // 0x7248a0: r1 = Null
    //     0x7248a0: mov             x1, NULL
    // 0x7248a4: r2 = 4
    //     0x7248a4: movz            x2, #0x4
    // 0x7248a8: r0 = AllocateArray()
    //     0x7248a8: bl              #0x82746c  ; AllocateArrayStub
    // 0x7248ac: r16 = "Chapter12Stat."
    //     0x7248ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15bc8] "Chapter12Stat."
    //     0x7248b0: ldr             x16, [x16, #0xbc8]
    // 0x7248b4: StoreField: r0->field_f = r16
    //     0x7248b4: stur            w16, [x0, #0xf]
    // 0x7248b8: ldur            x1, [fp, #-8]
    // 0x7248bc: LoadField: r2 = r1->field_f
    //     0x7248bc: ldur            w2, [x1, #0xf]
    // 0x7248c0: DecompressPointer r2
    //     0x7248c0: add             x2, x2, HEAP, lsl #32
    // 0x7248c4: StoreField: r0->field_13 = r2
    //     0x7248c4: stur            w2, [x0, #0x13]
    // 0x7248c8: str             x0, [SP]
    // 0x7248cc: r0 = _interpolate()
    //     0x7248cc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x7248d0: LeaveFrame
    //     0x7248d0: mov             SP, fp
    //     0x7248d4: ldp             fp, lr, [SP], #0x10
    // 0x7248d8: ret
    //     0x7248d8: ret             
    // 0x7248dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7248dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7248e0: b               #0x7248a0
  }
}
