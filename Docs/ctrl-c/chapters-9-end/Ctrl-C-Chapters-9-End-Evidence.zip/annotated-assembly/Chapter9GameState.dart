// lib: , url: package:pretentious/data/Chapters/Chapter9GameState.dart

// class id: 1049463, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46e638, size: 0x1a0
    // 0x46e638: cmp             w1, NULL
    // 0x46e63c: b.ne            #0x46e648
    // 0x46e640: r0 = ""
    //     0x46e640: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46e644: ret
    //     0x46e644: ret             
    // 0x46e648: r16 = Instance_Chapter9Stat
    //     0x46e648: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x46e64c: ldr             x16, [x16, #0x890]
    // 0x46e650: cmp             w1, w16
    // 0x46e654: b.ne            #0x46e664
    // 0x46e658: r0 = "Lines"
    //     0x46e658: add             x0, PP, #0x11, lsl #12  ; [pp+0x11898] "Lines"
    //     0x46e65c: ldr             x0, [x0, #0x898]
    // 0x46e660: ret
    //     0x46e660: ret             
    // 0x46e664: r16 = Instance_Chapter9Stat
    //     0x46e664: add             x16, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x46e668: ldr             x16, [x16, #0x8a0]
    // 0x46e66c: cmp             w1, w16
    // 0x46e670: b.ne            #0x46e680
    // 0x46e674: r0 = "Knowledge"
    //     0x46e674: add             x0, PP, #0x11, lsl #12  ; [pp+0x118a8] "Knowledge"
    //     0x46e678: ldr             x0, [x0, #0x8a8]
    // 0x46e67c: ret
    //     0x46e67c: ret             
    // 0x46e680: r16 = Instance_Chapter9Stat
    //     0x46e680: add             x16, PP, #0x11, lsl #12  ; [pp+0x11820] Obj!Chapter9Stat@85f101
    //     0x46e684: ldr             x16, [x16, #0x820]
    // 0x46e688: cmp             w1, w16
    // 0x46e68c: b.ne            #0x46e69c
    // 0x46e690: r0 = "Mouse"
    //     0x46e690: add             x0, PP, #0x11, lsl #12  ; [pp+0x118b0] "Mouse"
    //     0x46e694: ldr             x0, [x0, #0x8b0]
    // 0x46e698: ret
    //     0x46e698: ret             
    // 0x46e69c: r16 = Instance_Chapter9Stat
    //     0x46e69c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11828] Obj!Chapter9Stat@85f0e1
    //     0x46e6a0: ldr             x16, [x16, #0x828]
    // 0x46e6a4: cmp             w1, w16
    // 0x46e6a8: b.ne            #0x46e6b8
    // 0x46e6ac: r0 = "Keyboard"
    //     0x46e6ac: add             x0, PP, #0x11, lsl #12  ; [pp+0x118b8] "Keyboard"
    //     0x46e6b0: ldr             x0, [x0, #0x8b8]
    // 0x46e6b4: ret
    //     0x46e6b4: ret             
    // 0x46e6b8: r16 = Instance_Chapter9Stat
    //     0x46e6b8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] Obj!Chapter9Stat@85f0c1
    //     0x46e6bc: ldr             x16, [x16, #0x830]
    // 0x46e6c0: cmp             w1, w16
    // 0x46e6c4: b.ne            #0x46e6d4
    // 0x46e6c8: r0 = "Mechanical Keyboard"
    //     0x46e6c8: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c0] "Mechanical Keyboard"
    //     0x46e6cc: ldr             x0, [x0, #0x8c0]
    // 0x46e6d0: ret
    //     0x46e6d0: ret             
    // 0x46e6d4: r16 = Instance_Chapter9Stat
    //     0x46e6d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11838] Obj!Chapter9Stat@85f0a1
    //     0x46e6d8: ldr             x16, [x16, #0x838]
    // 0x46e6dc: cmp             w1, w16
    // 0x46e6e0: b.ne            #0x46e6f0
    // 0x46e6e4: r0 = "Clickier Keyboard"
    //     0x46e6e4: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c8] "Clickier Keyboard"
    //     0x46e6e8: ldr             x0, [x0, #0x8c8]
    // 0x46e6ec: ret
    //     0x46e6ec: ret             
    // 0x46e6f0: r16 = Instance_Chapter9Stat
    //     0x46e6f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11840] Obj!Chapter9Stat@85f081
    //     0x46e6f4: ldr             x16, [x16, #0x840]
    // 0x46e6f8: cmp             w1, w16
    // 0x46e6fc: b.ne            #0x46e70c
    // 0x46e700: r0 = "RGB Keyboard"
    //     0x46e700: add             x0, PP, #0x11, lsl #12  ; [pp+0x118d0] "RGB Keyboard"
    //     0x46e704: ldr             x0, [x0, #0x8d0]
    // 0x46e708: ret
    //     0x46e708: ret             
    // 0x46e70c: r16 = Instance_Chapter9Stat
    //     0x46e70c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x46e710: ldr             x16, [x16, #0x8d8]
    // 0x46e714: cmp             w1, w16
    // 0x46e718: b.ne            #0x46e728
    // 0x46e71c: r0 = "Data"
    //     0x46e71c: add             x0, PP, #0x11, lsl #12  ; [pp+0x113a8] "Data"
    //     0x46e720: ldr             x0, [x0, #0x3a8]
    // 0x46e724: ret
    //     0x46e724: ret             
    // 0x46e728: r16 = Instance_Chapter9Stat
    //     0x46e728: add             x16, PP, #0x11, lsl #12  ; [pp+0x118e0] Obj!Chapter9Stat@85ef81
    //     0x46e72c: ldr             x16, [x16, #0x8e0]
    // 0x46e730: cmp             w1, w16
    // 0x46e734: b.ne            #0x46e744
    // 0x46e738: r0 = "Tools"
    //     0x46e738: add             x0, PP, #0x11, lsl #12  ; [pp+0x118e8] "Tools"
    //     0x46e73c: ldr             x0, [x0, #0x8e8]
    // 0x46e740: ret
    //     0x46e740: ret             
    // 0x46e744: r16 = Instance_Chapter9Stat
    //     0x46e744: add             x16, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x46e748: ldr             x16, [x16, #0x8f0]
    // 0x46e74c: cmp             w1, w16
    // 0x46e750: b.ne            #0x46e760
    // 0x46e754: r0 = "Career Capital"
    //     0x46e754: add             x0, PP, #0x11, lsl #12  ; [pp+0x118f8] "Career Capital"
    //     0x46e758: ldr             x0, [x0, #0x8f8]
    // 0x46e75c: ret
    //     0x46e75c: ret             
    // 0x46e760: r16 = Instance_Chapter9Stat
    //     0x46e760: add             x16, PP, #0x11, lsl #12  ; [pp+0x11848] Obj!Chapter9Stat@85f061
    //     0x46e764: ldr             x16, [x16, #0x848]
    // 0x46e768: cmp             w1, w16
    // 0x46e76c: b.ne            #0x46e77c
    // 0x46e770: r0 = "Notes"
    //     0x46e770: add             x0, PP, #0x11, lsl #12  ; [pp+0x11900] "Notes"
    //     0x46e774: ldr             x0, [x0, #0x900]
    // 0x46e778: ret
    //     0x46e778: ret             
    // 0x46e77c: r16 = Instance_Chapter9Stat
    //     0x46e77c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11850] Obj!Chapter9Stat@85f041
    //     0x46e780: ldr             x16, [x16, #0x850]
    // 0x46e784: cmp             w1, w16
    // 0x46e788: b.ne            #0x46e798
    // 0x46e78c: r0 = "Files"
    //     0x46e78c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11908] "Files"
    //     0x46e790: ldr             x0, [x0, #0x908]
    // 0x46e794: ret
    //     0x46e794: ret             
    // 0x46e798: r16 = Instance_Chapter9Stat
    //     0x46e798: add             x16, PP, #0x11, lsl #12  ; [pp+0x11858] Obj!Chapter9Stat@85f021
    //     0x46e79c: ldr             x16, [x16, #0x858]
    // 0x46e7a0: cmp             w1, w16
    // 0x46e7a4: b.ne            #0x46e7b4
    // 0x46e7a8: r0 = "Code Snippets"
    //     0x46e7a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11910] "Code Snippets"
    //     0x46e7ac: ldr             x0, [x0, #0x910]
    // 0x46e7b0: ret
    //     0x46e7b0: ret             
    // 0x46e7b4: r16 = Instance_Chapter9Stat
    //     0x46e7b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11860] Obj!Chapter9Stat@85f001
    //     0x46e7b8: ldr             x16, [x16, #0x860]
    // 0x46e7bc: cmp             w1, w16
    // 0x46e7c0: b.ne            #0x46e7d0
    // 0x46e7c4: r0 = "Macros"
    //     0x46e7c4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11918] "Macros"
    //     0x46e7c8: ldr             x0, [x0, #0x918]
    // 0x46e7cc: ret
    //     0x46e7cc: ret             
    // 0x46e7d0: r0 = Null
    //     0x46e7d0: mov             x0, NULL
    // 0x46e7d4: ret
    //     0x46e7d4: ret             
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46e808, size: 0x190
    // 0x46e808: r16 = Instance_Chapter9Stat
    //     0x46e808: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x46e80c: ldr             x16, [x16, #0x890]
    // 0x46e810: cmp             w1, w16
    // 0x46e814: b.ne            #0x46e824
    // 0x46e818: r0 = "Lines"
    //     0x46e818: add             x0, PP, #0x11, lsl #12  ; [pp+0x11898] "Lines"
    //     0x46e81c: ldr             x0, [x0, #0x898]
    // 0x46e820: ret
    //     0x46e820: ret             
    // 0x46e824: r16 = Instance_Chapter9Stat
    //     0x46e824: add             x16, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x46e828: ldr             x16, [x16, #0x8a0]
    // 0x46e82c: cmp             w1, w16
    // 0x46e830: b.ne            #0x46e840
    // 0x46e834: r0 = "Knw"
    //     0x46e834: add             x0, PP, #0x11, lsl #12  ; [pp+0x11920] "Knw"
    //     0x46e838: ldr             x0, [x0, #0x920]
    // 0x46e83c: ret
    //     0x46e83c: ret             
    // 0x46e840: r16 = Instance_Chapter9Stat
    //     0x46e840: add             x16, PP, #0x11, lsl #12  ; [pp+0x11820] Obj!Chapter9Stat@85f101
    //     0x46e844: ldr             x16, [x16, #0x820]
    // 0x46e848: cmp             w1, w16
    // 0x46e84c: b.ne            #0x46e85c
    // 0x46e850: r0 = "Mouse"
    //     0x46e850: add             x0, PP, #0x11, lsl #12  ; [pp+0x118b0] "Mouse"
    //     0x46e854: ldr             x0, [x0, #0x8b0]
    // 0x46e858: ret
    //     0x46e858: ret             
    // 0x46e85c: r16 = Instance_Chapter9Stat
    //     0x46e85c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11828] Obj!Chapter9Stat@85f0e1
    //     0x46e860: ldr             x16, [x16, #0x828]
    // 0x46e864: cmp             w1, w16
    // 0x46e868: b.ne            #0x46e878
    // 0x46e86c: r0 = "Keyboard"
    //     0x46e86c: add             x0, PP, #0x11, lsl #12  ; [pp+0x118b8] "Keyboard"
    //     0x46e870: ldr             x0, [x0, #0x8b8]
    // 0x46e874: ret
    //     0x46e874: ret             
    // 0x46e878: r16 = Instance_Chapter9Stat
    //     0x46e878: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] Obj!Chapter9Stat@85f0c1
    //     0x46e87c: ldr             x16, [x16, #0x830]
    // 0x46e880: cmp             w1, w16
    // 0x46e884: b.ne            #0x46e894
    // 0x46e888: r0 = "Mechanical Keyboard"
    //     0x46e888: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c0] "Mechanical Keyboard"
    //     0x46e88c: ldr             x0, [x0, #0x8c0]
    // 0x46e890: ret
    //     0x46e890: ret             
    // 0x46e894: r16 = Instance_Chapter9Stat
    //     0x46e894: add             x16, PP, #0x11, lsl #12  ; [pp+0x11838] Obj!Chapter9Stat@85f0a1
    //     0x46e898: ldr             x16, [x16, #0x838]
    // 0x46e89c: cmp             w1, w16
    // 0x46e8a0: b.ne            #0x46e8b0
    // 0x46e8a4: r0 = "Clickier Keyboard"
    //     0x46e8a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c8] "Clickier Keyboard"
    //     0x46e8a8: ldr             x0, [x0, #0x8c8]
    // 0x46e8ac: ret
    //     0x46e8ac: ret             
    // 0x46e8b0: r16 = Instance_Chapter9Stat
    //     0x46e8b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11840] Obj!Chapter9Stat@85f081
    //     0x46e8b4: ldr             x16, [x16, #0x840]
    // 0x46e8b8: cmp             w1, w16
    // 0x46e8bc: b.ne            #0x46e8cc
    // 0x46e8c0: r0 = "RGB Keyboard"
    //     0x46e8c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x118d0] "RGB Keyboard"
    //     0x46e8c4: ldr             x0, [x0, #0x8d0]
    // 0x46e8c8: ret
    //     0x46e8c8: ret             
    // 0x46e8cc: r16 = Instance_Chapter9Stat
    //     0x46e8cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x46e8d0: ldr             x16, [x16, #0x8d8]
    // 0x46e8d4: cmp             w1, w16
    // 0x46e8d8: b.ne            #0x46e8e8
    // 0x46e8dc: r0 = "Data"
    //     0x46e8dc: add             x0, PP, #0x11, lsl #12  ; [pp+0x113a8] "Data"
    //     0x46e8e0: ldr             x0, [x0, #0x3a8]
    // 0x46e8e4: ret
    //     0x46e8e4: ret             
    // 0x46e8e8: r16 = Instance_Chapter9Stat
    //     0x46e8e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x118e0] Obj!Chapter9Stat@85ef81
    //     0x46e8ec: ldr             x16, [x16, #0x8e0]
    // 0x46e8f0: cmp             w1, w16
    // 0x46e8f4: b.ne            #0x46e904
    // 0x46e8f8: r0 = "Tools"
    //     0x46e8f8: add             x0, PP, #0x11, lsl #12  ; [pp+0x118e8] "Tools"
    //     0x46e8fc: ldr             x0, [x0, #0x8e8]
    // 0x46e900: ret
    //     0x46e900: ret             
    // 0x46e904: r16 = Instance_Chapter9Stat
    //     0x46e904: add             x16, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x46e908: ldr             x16, [x16, #0x8f0]
    // 0x46e90c: cmp             w1, w16
    // 0x46e910: b.ne            #0x46e920
    // 0x46e914: r0 = "Career Capital"
    //     0x46e914: add             x0, PP, #0x11, lsl #12  ; [pp+0x118f8] "Career Capital"
    //     0x46e918: ldr             x0, [x0, #0x8f8]
    // 0x46e91c: ret
    //     0x46e91c: ret             
    // 0x46e920: r16 = Instance_Chapter9Stat
    //     0x46e920: add             x16, PP, #0x11, lsl #12  ; [pp+0x11848] Obj!Chapter9Stat@85f061
    //     0x46e924: ldr             x16, [x16, #0x848]
    // 0x46e928: cmp             w1, w16
    // 0x46e92c: b.ne            #0x46e93c
    // 0x46e930: r0 = "Notes"
    //     0x46e930: add             x0, PP, #0x11, lsl #12  ; [pp+0x11900] "Notes"
    //     0x46e934: ldr             x0, [x0, #0x900]
    // 0x46e938: ret
    //     0x46e938: ret             
    // 0x46e93c: r16 = Instance_Chapter9Stat
    //     0x46e93c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11850] Obj!Chapter9Stat@85f041
    //     0x46e940: ldr             x16, [x16, #0x850]
    // 0x46e944: cmp             w1, w16
    // 0x46e948: b.ne            #0x46e958
    // 0x46e94c: r0 = "Files"
    //     0x46e94c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11908] "Files"
    //     0x46e950: ldr             x0, [x0, #0x908]
    // 0x46e954: ret
    //     0x46e954: ret             
    // 0x46e958: r16 = Instance_Chapter9Stat
    //     0x46e958: add             x16, PP, #0x11, lsl #12  ; [pp+0x11858] Obj!Chapter9Stat@85f021
    //     0x46e95c: ldr             x16, [x16, #0x858]
    // 0x46e960: cmp             w1, w16
    // 0x46e964: b.ne            #0x46e974
    // 0x46e968: r0 = "Code Snippets"
    //     0x46e968: add             x0, PP, #0x11, lsl #12  ; [pp+0x11910] "Code Snippets"
    //     0x46e96c: ldr             x0, [x0, #0x910]
    // 0x46e970: ret
    //     0x46e970: ret             
    // 0x46e974: r16 = Instance_Chapter9Stat
    //     0x46e974: add             x16, PP, #0x11, lsl #12  ; [pp+0x11860] Obj!Chapter9Stat@85f001
    //     0x46e978: ldr             x16, [x16, #0x860]
    // 0x46e97c: cmp             w1, w16
    // 0x46e980: b.ne            #0x46e990
    // 0x46e984: r0 = "Macros"
    //     0x46e984: add             x0, PP, #0x11, lsl #12  ; [pp+0x11918] "Macros"
    //     0x46e988: ldr             x0, [x0, #0x918]
    // 0x46e98c: ret
    //     0x46e98c: ret             
    // 0x46e990: r0 = Null
    //     0x46e990: mov             x0, NULL
    // 0x46e994: ret
    //     0x46e994: ret             
  }
}

// class id: 269, size: 0x98, field offset: 0x8c
class Chapter9GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter9Stat>> generators; // offset: 0x8c
  late Map<int, UpgradeData<Chapter9Stat>> allUpgradeData; // offset: 0x90

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3dd774, size: 0x154
    // 0x3dd774: EnterFrame
    //     0x3dd774: stp             fp, lr, [SP, #-0x10]!
    //     0x3dd778: mov             fp, SP
    // 0x3dd77c: AllocStack(0x38)
    //     0x3dd77c: sub             SP, SP, #0x38
    // 0x3dd780: SetupParameters(Chapter9GameState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x3dd780: mov             x4, x1
    //     0x3dd784: mov             x0, x3
    //     0x3dd788: stur            x3, [fp, #-0x18]
    //     0x3dd78c: mov             x3, x2
    //     0x3dd790: stur            x1, [fp, #-8]
    //     0x3dd794: stur            x2, [fp, #-0x10]
    // 0x3dd798: CheckStackOverflow
    //     0x3dd798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dd79c: cmp             SP, x16
    //     0x3dd7a0: b.ls            #0x3dd8bc
    // 0x3dd7a4: mov             x1, x4
    // 0x3dd7a8: mov             x2, x3
    // 0x3dd7ac: r0 = getGeneratorInfo()
    //     0x3dd7ac: bl              #0x80dac0  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getGeneratorInfo
    // 0x3dd7b0: LoadField: r3 = r0->field_27
    //     0x3dd7b0: ldur            w3, [x0, #0x27]
    // 0x3dd7b4: DecompressPointer r3
    //     0x3dd7b4: add             x3, x3, HEAP, lsl #32
    // 0x3dd7b8: stur            x3, [fp, #-0x28]
    // 0x3dd7bc: cmp             w3, NULL
    // 0x3dd7c0: b.eq            #0x3dd8c4
    // 0x3dd7c4: LoadField: r0 = r3->field_b
    //     0x3dd7c4: ldur            w0, [x3, #0xb]
    // 0x3dd7c8: DecompressPointer r0
    //     0x3dd7c8: add             x0, x0, HEAP, lsl #32
    // 0x3dd7cc: ldur            x2, [fp, #-0x18]
    // 0x3dd7d0: stur            x0, [fp, #-0x20]
    // 0x3dd7d4: r1 = Instance_CustomNum
    //     0x3dd7d4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3dd7d8: ldr             x1, [x1, #0x2f0]
    // 0x3dd7dc: r0 = pow()
    //     0x3dd7dc: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3dd7e0: mov             x3, x0
    // 0x3dd7e4: ldur            x0, [fp, #-0x28]
    // 0x3dd7e8: stur            x3, [fp, #-0x38]
    // 0x3dd7ec: LoadField: r4 = r0->field_f
    //     0x3dd7ec: ldur            w4, [x0, #0xf]
    // 0x3dd7f0: DecompressPointer r4
    //     0x3dd7f0: add             x4, x4, HEAP, lsl #32
    // 0x3dd7f4: ldur            x0, [fp, #-8]
    // 0x3dd7f8: stur            x4, [fp, #-0x30]
    // 0x3dd7fc: LoadField: r5 = r0->field_33
    //     0x3dd7fc: ldur            w5, [x0, #0x33]
    // 0x3dd800: DecompressPointer r5
    //     0x3dd800: add             x5, x5, HEAP, lsl #32
    // 0x3dd804: mov             x1, x5
    // 0x3dd808: ldur            x2, [fp, #-0x10]
    // 0x3dd80c: stur            x5, [fp, #-0x18]
    // 0x3dd810: r0 = _getValueOrData()
    //     0x3dd810: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3dd814: mov             x1, x0
    // 0x3dd818: ldur            x0, [fp, #-0x18]
    // 0x3dd81c: LoadField: r2 = r0->field_f
    //     0x3dd81c: ldur            w2, [x0, #0xf]
    // 0x3dd820: DecompressPointer r2
    //     0x3dd820: add             x2, x2, HEAP, lsl #32
    // 0x3dd824: cmp             w2, w1
    // 0x3dd828: b.ne            #0x3dd834
    // 0x3dd82c: r0 = Null
    //     0x3dd82c: mov             x0, NULL
    // 0x3dd830: b               #0x3dd838
    // 0x3dd834: mov             x0, x1
    // 0x3dd838: cmp             w0, NULL
    // 0x3dd83c: b.ne            #0x3dd848
    // 0x3dd840: r0 = Null
    //     0x3dd840: mov             x0, NULL
    // 0x3dd844: b               #0x3dd854
    // 0x3dd848: LoadField: r1 = r0->field_b
    //     0x3dd848: ldur            w1, [x0, #0xb]
    // 0x3dd84c: DecompressPointer r1
    //     0x3dd84c: add             x1, x1, HEAP, lsl #32
    // 0x3dd850: mov             x0, x1
    // 0x3dd854: cmp             w0, NULL
    // 0x3dd858: b.ne            #0x3dd868
    // 0x3dd85c: r3 = Instance_CustomNum
    //     0x3dd85c: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3dd860: ldr             x3, [x3, #0xa70]
    // 0x3dd864: b               #0x3dd86c
    // 0x3dd868: mov             x3, x0
    // 0x3dd86c: ldur            x0, [fp, #-8]
    // 0x3dd870: ldur            x4, [fp, #-0x20]
    // 0x3dd874: LoadField: r1 = r0->field_2b
    //     0x3dd874: ldur            w1, [x0, #0x2b]
    // 0x3dd878: DecompressPointer r1
    //     0x3dd878: add             x1, x1, HEAP, lsl #32
    // 0x3dd87c: LoadField: r5 = r1->field_b
    //     0x3dd87c: ldur            w5, [x1, #0xb]
    // 0x3dd880: DecompressPointer r5
    //     0x3dd880: add             x5, x5, HEAP, lsl #32
    // 0x3dd884: ldur            x1, [fp, #-0x38]
    // 0x3dd888: ldur            x2, [fp, #-0x30]
    // 0x3dd88c: r0 = mult4()
    //     0x3dd88c: bl              #0x3dda04  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult4
    // 0x3dd890: r1 = <Chapter9Stat, CustomNum>
    //     0x3dd890: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d00] TypeArguments: <Chapter9Stat, CustomNum>
    //     0x3dd894: ldr             x1, [x1, #0xd00]
    // 0x3dd898: stur            x0, [fp, #-8]
    // 0x3dd89c: r0 = Tuple2()
    //     0x3dd89c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3dd8a0: ldur            x1, [fp, #-0x20]
    // 0x3dd8a4: StoreField: r0->field_b = r1
    //     0x3dd8a4: stur            w1, [x0, #0xb]
    // 0x3dd8a8: ldur            x1, [fp, #-8]
    // 0x3dd8ac: StoreField: r0->field_f = r1
    //     0x3dd8ac: stur            w1, [x0, #0xf]
    // 0x3dd8b0: LeaveFrame
    //     0x3dd8b0: mov             SP, fp
    //     0x3dd8b4: ldp             fp, lr, [SP], #0x10
    // 0x3dd8b8: ret
    //     0x3dd8b8: ret             
    // 0x3dd8bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dd8bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dd8c0: b               #0x3dd7a4
    // 0x3dd8c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3dd8c4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter9Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3dd8c8, size: 0x40
    // 0x3dd8c8: EnterFrame
    //     0x3dd8c8: stp             fp, lr, [SP, #-0x10]!
    //     0x3dd8cc: mov             fp, SP
    // 0x3dd8d0: ldr             x0, [fp, #0x20]
    // 0x3dd8d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3dd8d4: ldur            w1, [x0, #0x17]
    // 0x3dd8d8: DecompressPointer r1
    //     0x3dd8d8: add             x1, x1, HEAP, lsl #32
    // 0x3dd8dc: CheckStackOverflow
    //     0x3dd8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dd8e0: cmp             SP, x16
    //     0x3dd8e4: b.ls            #0x3dd900
    // 0x3dd8e8: ldr             x2, [fp, #0x18]
    // 0x3dd8ec: ldr             x3, [fp, #0x10]
    // 0x3dd8f0: r0 = getCostToBuyOneMoreGenerator()
    //     0x3dd8f0: bl              #0x3dd774  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getCostToBuyOneMoreGenerator
    // 0x3dd8f4: LeaveFrame
    //     0x3dd8f4: mov             SP, fp
    //     0x3dd8f8: ldp             fp, lr, [SP], #0x10
    // 0x3dd8fc: ret
    //     0x3dd8fc: ret             
    // 0x3dd900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dd900: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dd904: b               #0x3dd8e8
  }
  _ Chapter9GameState(/* No info */) {
    // ** addr: 0x46e464, size: 0x1a4
    // 0x46e464: EnterFrame
    //     0x46e464: stp             fp, lr, [SP, #-0x10]!
    //     0x46e468: mov             fp, SP
    // 0x46e46c: AllocStack(0x38)
    //     0x46e46c: sub             SP, SP, #0x38
    // 0x46e470: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46e474: mov             x4, x1
    // 0x46e478: mov             x3, x2
    // 0x46e47c: stur            x1, [fp, #-8]
    // 0x46e480: stur            x2, [fp, #-0x10]
    // 0x46e484: CheckStackOverflow
    //     0x46e484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46e488: cmp             SP, x16
    //     0x46e48c: b.ls            #0x46e600
    // 0x46e490: StoreField: r4->field_8b = r0
    //     0x46e490: stur            w0, [x4, #0x8b]
    // 0x46e494: StoreField: r4->field_8f = r0
    //     0x46e494: stur            w0, [x4, #0x8f]
    // 0x46e498: r1 = Null
    //     0x46e498: mov             x1, NULL
    // 0x46e49c: r2 = 36
    //     0x46e49c: movz            x2, #0x24
    // 0x46e4a0: r0 = AllocateArray()
    //     0x46e4a0: bl              #0x82746c  ; AllocateArrayStub
    // 0x46e4a4: r16 = 2
    //     0x46e4a4: movz            x16, #0x2
    // 0x46e4a8: StoreField: r0->field_f = r16
    //     0x46e4a8: stur            w16, [x0, #0xf]
    // 0x46e4ac: r16 = Instance_Chapter9Stat
    //     0x46e4ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11820] Obj!Chapter9Stat@85f101
    //     0x46e4b0: ldr             x16, [x16, #0x820]
    // 0x46e4b4: StoreField: r0->field_13 = r16
    //     0x46e4b4: stur            w16, [x0, #0x13]
    // 0x46e4b8: r16 = 4
    //     0x46e4b8: movz            x16, #0x4
    // 0x46e4bc: ArrayStore: r0[0] = r16  ; List_4
    //     0x46e4bc: stur            w16, [x0, #0x17]
    // 0x46e4c0: r16 = Instance_Chapter9Stat
    //     0x46e4c0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11828] Obj!Chapter9Stat@85f0e1
    //     0x46e4c4: ldr             x16, [x16, #0x828]
    // 0x46e4c8: StoreField: r0->field_1b = r16
    //     0x46e4c8: stur            w16, [x0, #0x1b]
    // 0x46e4cc: r16 = 6
    //     0x46e4cc: movz            x16, #0x6
    // 0x46e4d0: StoreField: r0->field_1f = r16
    //     0x46e4d0: stur            w16, [x0, #0x1f]
    // 0x46e4d4: r16 = Instance_Chapter9Stat
    //     0x46e4d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] Obj!Chapter9Stat@85f0c1
    //     0x46e4d8: ldr             x16, [x16, #0x830]
    // 0x46e4dc: StoreField: r0->field_23 = r16
    //     0x46e4dc: stur            w16, [x0, #0x23]
    // 0x46e4e0: r16 = 8
    //     0x46e4e0: movz            x16, #0x8
    // 0x46e4e4: StoreField: r0->field_27 = r16
    //     0x46e4e4: stur            w16, [x0, #0x27]
    // 0x46e4e8: r16 = Instance_Chapter9Stat
    //     0x46e4e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11838] Obj!Chapter9Stat@85f0a1
    //     0x46e4ec: ldr             x16, [x16, #0x838]
    // 0x46e4f0: StoreField: r0->field_2b = r16
    //     0x46e4f0: stur            w16, [x0, #0x2b]
    // 0x46e4f4: r16 = 10
    //     0x46e4f4: movz            x16, #0xa
    // 0x46e4f8: StoreField: r0->field_2f = r16
    //     0x46e4f8: stur            w16, [x0, #0x2f]
    // 0x46e4fc: r16 = Instance_Chapter9Stat
    //     0x46e4fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11840] Obj!Chapter9Stat@85f081
    //     0x46e500: ldr             x16, [x16, #0x840]
    // 0x46e504: StoreField: r0->field_33 = r16
    //     0x46e504: stur            w16, [x0, #0x33]
    // 0x46e508: r16 = 22
    //     0x46e508: movz            x16, #0x16
    // 0x46e50c: StoreField: r0->field_37 = r16
    //     0x46e50c: stur            w16, [x0, #0x37]
    // 0x46e510: r16 = Instance_Chapter9Stat
    //     0x46e510: add             x16, PP, #0x11, lsl #12  ; [pp+0x11848] Obj!Chapter9Stat@85f061
    //     0x46e514: ldr             x16, [x16, #0x848]
    // 0x46e518: StoreField: r0->field_3b = r16
    //     0x46e518: stur            w16, [x0, #0x3b]
    // 0x46e51c: r16 = 24
    //     0x46e51c: movz            x16, #0x18
    // 0x46e520: StoreField: r0->field_3f = r16
    //     0x46e520: stur            w16, [x0, #0x3f]
    // 0x46e524: r16 = Instance_Chapter9Stat
    //     0x46e524: add             x16, PP, #0x11, lsl #12  ; [pp+0x11850] Obj!Chapter9Stat@85f041
    //     0x46e528: ldr             x16, [x16, #0x850]
    // 0x46e52c: StoreField: r0->field_43 = r16
    //     0x46e52c: stur            w16, [x0, #0x43]
    // 0x46e530: r16 = 26
    //     0x46e530: movz            x16, #0x1a
    // 0x46e534: StoreField: r0->field_47 = r16
    //     0x46e534: stur            w16, [x0, #0x47]
    // 0x46e538: r16 = Instance_Chapter9Stat
    //     0x46e538: add             x16, PP, #0x11, lsl #12  ; [pp+0x11858] Obj!Chapter9Stat@85f021
    //     0x46e53c: ldr             x16, [x16, #0x858]
    // 0x46e540: StoreField: r0->field_4b = r16
    //     0x46e540: stur            w16, [x0, #0x4b]
    // 0x46e544: r16 = 28
    //     0x46e544: movz            x16, #0x1c
    // 0x46e548: StoreField: r0->field_4f = r16
    //     0x46e548: stur            w16, [x0, #0x4f]
    // 0x46e54c: r16 = Instance_Chapter9Stat
    //     0x46e54c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11860] Obj!Chapter9Stat@85f001
    //     0x46e550: ldr             x16, [x16, #0x860]
    // 0x46e554: StoreField: r0->field_53 = r16
    //     0x46e554: stur            w16, [x0, #0x53]
    // 0x46e558: r16 = <int, Chapter9Stat>
    //     0x46e558: add             x16, PP, #0x11, lsl #12  ; [pp+0x11868] TypeArguments: <int, Chapter9Stat>
    //     0x46e55c: ldr             x16, [x16, #0x868]
    // 0x46e560: stp             x0, x16, [SP]
    // 0x46e564: r0 = Map._fromLiteral()
    //     0x46e564: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46e568: ldur            x3, [fp, #-8]
    // 0x46e56c: StoreField: r3->field_93 = r0
    //     0x46e56c: stur            w0, [x3, #0x93]
    //     0x46e570: ldurb           w16, [x3, #-1]
    //     0x46e574: ldurb           w17, [x0, #-1]
    //     0x46e578: and             x16, x17, x16, lsr #2
    //     0x46e57c: tst             x16, HEAP, lsr #32
    //     0x46e580: b.eq            #0x46e588
    //     0x46e584: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46e588: r1 = Function '<anonymous closure>':.
    //     0x46e588: add             x1, PP, #0x11, lsl #12  ; [pp+0x11870] AnonymousClosure: (0x46e998), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x46e58c: ldr             x1, [x1, #0x870]
    // 0x46e590: r2 = Null
    //     0x46e590: mov             x2, NULL
    // 0x46e594: r0 = AllocateClosure()
    //     0x46e594: bl              #0x826750  ; AllocateClosureStub
    // 0x46e598: r1 = Function '<anonymous closure>':.
    //     0x46e598: add             x1, PP, #0x11, lsl #12  ; [pp+0x11878] AnonymousClosure: (0x46e7d8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x46e59c: ldr             x1, [x1, #0x878]
    // 0x46e5a0: r2 = Null
    //     0x46e5a0: mov             x2, NULL
    // 0x46e5a4: stur            x0, [fp, #-0x18]
    // 0x46e5a8: r0 = AllocateClosure()
    //     0x46e5a8: bl              #0x826750  ; AllocateClosureStub
    // 0x46e5ac: r1 = Function '<anonymous closure>':.
    //     0x46e5ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11880] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x46e5b0: ldr             x1, [x1, #0x880]
    // 0x46e5b4: r2 = Null
    //     0x46e5b4: mov             x2, NULL
    // 0x46e5b8: stur            x0, [fp, #-0x20]
    // 0x46e5bc: r0 = AllocateClosure()
    //     0x46e5bc: bl              #0x826750  ; AllocateClosureStub
    // 0x46e5c0: r1 = Function '<anonymous closure>':.
    //     0x46e5c0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11888] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46e5c4: ldr             x1, [x1, #0x888]
    // 0x46e5c8: r2 = Null
    //     0x46e5c8: mov             x2, NULL
    // 0x46e5cc: stur            x0, [fp, #-0x28]
    // 0x46e5d0: r0 = AllocateClosure()
    //     0x46e5d0: bl              #0x826750  ; AllocateClosureStub
    // 0x46e5d4: ldur            x1, [fp, #-8]
    // 0x46e5d8: ldur            x2, [fp, #-0x10]
    // 0x46e5dc: ldur            x3, [fp, #-0x18]
    // 0x46e5e0: ldur            x5, [fp, #-0x20]
    // 0x46e5e4: ldur            x6, [fp, #-0x28]
    // 0x46e5e8: mov             x7, x0
    // 0x46e5ec: r0 = IPlayableGameState()
    //     0x46e5ec: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46e5f0: r0 = Null
    //     0x46e5f0: mov             x0, NULL
    // 0x46e5f4: LeaveFrame
    //     0x46e5f4: mov             SP, fp
    //     0x46e5f8: ldp             fp, lr, [SP], #0x10
    // 0x46e5fc: ret
    //     0x46e5fc: ret             
    // 0x46e600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46e600: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46e604: b               #0x46e490
  }
  [closure] String <anonymous closure>(dynamic, Chapter9Stat) {
    // ** addr: 0x46e608, size: 0x30
    // 0x46e608: EnterFrame
    //     0x46e608: stp             fp, lr, [SP, #-0x10]!
    //     0x46e60c: mov             fp, SP
    // 0x46e610: CheckStackOverflow
    //     0x46e610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46e614: cmp             SP, x16
    //     0x46e618: b.ls            #0x46e630
    // 0x46e61c: ldr             x1, [fp, #0x10]
    // 0x46e620: r0 = humanName()
    //     0x46e620: bl              #0x46e638  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] ::humanName
    // 0x46e624: LeaveFrame
    //     0x46e624: mov             SP, fp
    //     0x46e628: ldp             fp, lr, [SP], #0x10
    // 0x46e62c: ret
    //     0x46e62c: ret             
    // 0x46e630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46e630: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46e634: b               #0x46e61c
  }
  [closure] String <anonymous closure>(dynamic, Chapter9Stat) {
    // ** addr: 0x46e7d8, size: 0x30
    // 0x46e7d8: EnterFrame
    //     0x46e7d8: stp             fp, lr, [SP, #-0x10]!
    //     0x46e7dc: mov             fp, SP
    // 0x46e7e0: CheckStackOverflow
    //     0x46e7e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46e7e4: cmp             SP, x16
    //     0x46e7e8: b.ls            #0x46e800
    // 0x46e7ec: ldr             x1, [fp, #0x10]
    // 0x46e7f0: r0 = shortenedName()
    //     0x46e7f0: bl              #0x46e808  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] ::shortenedName
    // 0x46e7f4: LeaveFrame
    //     0x46e7f4: mov             SP, fp
    //     0x46e7f8: ldp             fp, lr, [SP], #0x10
    // 0x46e7fc: ret
    //     0x46e7fc: ret             
    // 0x46e800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46e800: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46e804: b               #0x46e7ec
  }
  [closure] Chapter9Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46e998, size: 0x44
    // 0x46e998: r2 = const [Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat', Instance of 'Chapter9Stat']
    //     0x46e998: add             x2, PP, #0x11, lsl #12  ; [pp+0x11928] List<Chapter9Stat>(14)
    //     0x46e99c: ldr             x2, [x2, #0x928]
    // 0x46e9a0: ldr             x3, [SP]
    // 0x46e9a4: r4 = LoadInt32Instr(r3)
    //     0x46e9a4: sbfx            x4, x3, #1, #0x1f
    //     0x46e9a8: tbz             w3, #0, #0x46e9b0
    //     0x46e9ac: ldur            x4, [x3, #7]
    // 0x46e9b0: mov             x1, x4
    // 0x46e9b4: r0 = 14
    //     0x46e9b4: movz            x0, #0xe
    // 0x46e9b8: cmp             x1, x0
    // 0x46e9bc: b.hs            #0x46e9d0
    // 0x46e9c0: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46e9c0: add             x16, x2, x4, lsl #2
    //     0x46e9c4: ldur            w0, [x16, #0xf]
    // 0x46e9c8: DecompressPointer r0
    //     0x46e9c8: add             x0, x0, HEAP, lsl #32
    // 0x46e9cc: ret
    //     0x46e9cc: ret             
    // 0x46e9d0: EnterFrame
    //     0x46e9d0: stp             fp, lr, [SP, #-0x10]!
    //     0x46e9d4: mov             fp, SP
    // 0x46e9d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46e9d8: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e8594, size: 0x78
    // 0x4e8594: EnterFrame
    //     0x4e8594: stp             fp, lr, [SP, #-0x10]!
    //     0x4e8598: mov             fp, SP
    // 0x4e859c: AllocStack(0x18)
    //     0x4e859c: sub             SP, SP, #0x18
    // 0x4e85a0: SetupParameters(Chapter9GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e85a0: stur            x1, [fp, #-8]
    // 0x4e85a4: r1 = 1
    //     0x4e85a4: movz            x1, #0x1
    // 0x4e85a8: r0 = AllocateContext()
    //     0x4e85a8: bl              #0x82637c  ; AllocateContextStub
    // 0x4e85ac: mov             x3, x0
    // 0x4e85b0: ldur            x0, [fp, #-8]
    // 0x4e85b4: stur            x3, [fp, #-0x10]
    // 0x4e85b8: StoreField: r3->field_f = r0
    //     0x4e85b8: stur            w0, [x3, #0xf]
    // 0x4e85bc: mov             x2, x3
    // 0x4e85c0: r1 = Function '<anonymous closure>':.
    //     0x4e85c0: add             x1, PP, #0x25, lsl #12  ; [pp+0x25658] AnonymousClosure: (0x4e870c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::makeHeader (0x4e8594)
    //     0x4e85c4: ldr             x1, [x1, #0x658]
    // 0x4e85c8: r0 = AllocateClosure()
    //     0x4e85c8: bl              #0x826750  ; AllocateClosureStub
    // 0x4e85cc: stur            x0, [fp, #-8]
    // 0x4e85d0: r0 = MainStatDisplay()
    //     0x4e85d0: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e85d4: mov             x3, x0
    // 0x4e85d8: ldur            x0, [fp, #-8]
    // 0x4e85dc: stur            x3, [fp, #-0x18]
    // 0x4e85e0: StoreField: r3->field_b = r0
    //     0x4e85e0: stur            w0, [x3, #0xb]
    // 0x4e85e4: ldur            x2, [fp, #-0x10]
    // 0x4e85e8: r1 = Function '<anonymous closure>':.
    //     0x4e85e8: add             x1, PP, #0x25, lsl #12  ; [pp+0x25660] AnonymousClosure: (0x4e860c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::makeHeader (0x4e8594)
    //     0x4e85ec: ldr             x1, [x1, #0x660]
    // 0x4e85f0: r0 = AllocateClosure()
    //     0x4e85f0: bl              #0x826750  ; AllocateClosureStub
    // 0x4e85f4: mov             x1, x0
    // 0x4e85f8: ldur            x0, [fp, #-0x18]
    // 0x4e85fc: StoreField: r0->field_f = r1
    //     0x4e85fc: stur            w1, [x0, #0xf]
    // 0x4e8600: LeaveFrame
    //     0x4e8600: mov             SP, fp
    //     0x4e8604: ldp             fp, lr, [SP], #0x10
    // 0x4e8608: ret
    //     0x4e8608: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e860c, size: 0x100
    // 0x4e860c: EnterFrame
    //     0x4e860c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e8610: mov             fp, SP
    // 0x4e8614: AllocStack(0x18)
    //     0x4e8614: sub             SP, SP, #0x18
    // 0x4e8618: SetupParameters([dynamic _ /* r0 */])
    //     0x4e8618: ldr             x0, [fp, #0x10]
    //     0x4e861c: ldur            w1, [x0, #0x17]
    //     0x4e8620: add             x1, x1, HEAP, lsl #32
    // 0x4e8624: CheckStackOverflow
    //     0x4e8624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e8628: cmp             SP, x16
    //     0x4e862c: b.ls            #0x4e8704
    // 0x4e8630: LoadField: r0 = r1->field_f
    //     0x4e8630: ldur            w0, [x1, #0xf]
    // 0x4e8634: DecompressPointer r0
    //     0x4e8634: add             x0, x0, HEAP, lsl #32
    // 0x4e8638: LoadField: r3 = r0->field_57
    //     0x4e8638: ldur            w3, [x0, #0x57]
    // 0x4e863c: DecompressPointer r3
    //     0x4e863c: add             x3, x3, HEAP, lsl #32
    // 0x4e8640: mov             x1, x3
    // 0x4e8644: stur            x3, [fp, #-8]
    // 0x4e8648: r2 = Instance_Chapter9Stat
    //     0x4e8648: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x4e864c: ldr             x2, [x2, #0x890]
    // 0x4e8650: r0 = _getValueOrData()
    //     0x4e8650: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e8654: mov             x1, x0
    // 0x4e8658: ldur            x0, [fp, #-8]
    // 0x4e865c: LoadField: r2 = r0->field_f
    //     0x4e865c: ldur            w2, [x0, #0xf]
    // 0x4e8660: DecompressPointer r2
    //     0x4e8660: add             x2, x2, HEAP, lsl #32
    // 0x4e8664: cmp             w2, w1
    // 0x4e8668: b.ne            #0x4e8674
    // 0x4e866c: r0 = Null
    //     0x4e866c: mov             x0, NULL
    // 0x4e8670: b               #0x4e8678
    // 0x4e8674: mov             x0, x1
    // 0x4e8678: stur            x0, [fp, #-8]
    // 0x4e867c: cmp             w0, NULL
    // 0x4e8680: b.eq            #0x4e86f4
    // 0x4e8684: r1 = Null
    //     0x4e8684: mov             x1, NULL
    // 0x4e8688: r2 = 6
    //     0x4e8688: movz            x2, #0x6
    // 0x4e868c: r0 = AllocateArray()
    //     0x4e868c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e8690: stur            x0, [fp, #-0x10]
    // 0x4e8694: r16 = "("
    //     0x4e8694: ldr             x16, [PP, #0x2218]  ; [pp+0x2218] "("
    // 0x4e8698: StoreField: r0->field_f = r16
    //     0x4e8698: stur            w16, [x0, #0xf]
    // 0x4e869c: ldur            x1, [fp, #-8]
    // 0x4e86a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e86a0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e86a4: r0 = toStringConsistentDecimalPlaces()
    //     0x4e86a4: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e86a8: ldur            x1, [fp, #-0x10]
    // 0x4e86ac: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e86ac: add             x25, x1, #0x13
    //     0x4e86b0: str             w0, [x25]
    //     0x4e86b4: tbz             w0, #0, #0x4e86d0
    //     0x4e86b8: ldurb           w16, [x1, #-1]
    //     0x4e86bc: ldurb           w17, [x0, #-1]
    //     0x4e86c0: and             x16, x17, x16, lsr #2
    //     0x4e86c4: tst             x16, HEAP, lsr #32
    //     0x4e86c8: b.eq            #0x4e86d0
    //     0x4e86cc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e86d0: ldur            x0, [fp, #-0x10]
    // 0x4e86d4: r16 = "/s)"
    //     0x4e86d4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a568] "/s)"
    //     0x4e86d8: ldr             x16, [x16, #0x568]
    // 0x4e86dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4e86dc: stur            w16, [x0, #0x17]
    // 0x4e86e0: str             x0, [SP]
    // 0x4e86e4: r0 = _interpolate()
    //     0x4e86e4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e86e8: LeaveFrame
    //     0x4e86e8: mov             SP, fp
    //     0x4e86ec: ldp             fp, lr, [SP], #0x10
    // 0x4e86f0: ret
    //     0x4e86f0: ret             
    // 0x4e86f4: r0 = ""
    //     0x4e86f4: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x4e86f8: LeaveFrame
    //     0x4e86f8: mov             SP, fp
    //     0x4e86fc: ldp             fp, lr, [SP], #0x10
    // 0x4e8700: ret
    //     0x4e8700: ret             
    // 0x4e8704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e8704: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e8708: b               #0x4e8630
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e870c, size: 0xf4
    // 0x4e870c: EnterFrame
    //     0x4e870c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e8710: mov             fp, SP
    // 0x4e8714: AllocStack(0x18)
    //     0x4e8714: sub             SP, SP, #0x18
    // 0x4e8718: SetupParameters([dynamic _ /* r0 */])
    //     0x4e8718: ldr             x0, [fp, #0x10]
    //     0x4e871c: ldur            w3, [x0, #0x17]
    //     0x4e8720: add             x3, x3, HEAP, lsl #32
    //     0x4e8724: stur            x3, [fp, #-8]
    // 0x4e8728: CheckStackOverflow
    //     0x4e8728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e872c: cmp             SP, x16
    //     0x4e8730: b.ls            #0x4e87f8
    // 0x4e8734: r1 = Null
    //     0x4e8734: mov             x1, NULL
    // 0x4e8738: r2 = 4
    //     0x4e8738: movz            x2, #0x4
    // 0x4e873c: r0 = AllocateArray()
    //     0x4e873c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e8740: stur            x0, [fp, #-0x10]
    // 0x4e8744: r16 = "Lines: "
    //     0x4e8744: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a560] "Lines: "
    //     0x4e8748: ldr             x16, [x16, #0x560]
    // 0x4e874c: StoreField: r0->field_f = r16
    //     0x4e874c: stur            w16, [x0, #0xf]
    // 0x4e8750: ldur            x1, [fp, #-8]
    // 0x4e8754: LoadField: r2 = r1->field_f
    //     0x4e8754: ldur            w2, [x1, #0xf]
    // 0x4e8758: DecompressPointer r2
    //     0x4e8758: add             x2, x2, HEAP, lsl #32
    // 0x4e875c: LoadField: r3 = r2->field_37
    //     0x4e875c: ldur            w3, [x2, #0x37]
    // 0x4e8760: DecompressPointer r3
    //     0x4e8760: add             x3, x3, HEAP, lsl #32
    // 0x4e8764: mov             x1, x3
    // 0x4e8768: stur            x3, [fp, #-8]
    // 0x4e876c: r2 = Instance_Chapter9Stat
    //     0x4e876c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x4e8770: ldr             x2, [x2, #0x890]
    // 0x4e8774: r0 = _getValueOrData()
    //     0x4e8774: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e8778: mov             x1, x0
    // 0x4e877c: ldur            x0, [fp, #-8]
    // 0x4e8780: LoadField: r2 = r0->field_f
    //     0x4e8780: ldur            w2, [x0, #0xf]
    // 0x4e8784: DecompressPointer r2
    //     0x4e8784: add             x2, x2, HEAP, lsl #32
    // 0x4e8788: cmp             w2, w1
    // 0x4e878c: b.ne            #0x4e8794
    // 0x4e8790: r1 = Null
    //     0x4e8790: mov             x1, NULL
    // 0x4e8794: cmp             w1, NULL
    // 0x4e8798: b.ne            #0x4e87a4
    // 0x4e879c: r0 = Null
    //     0x4e879c: mov             x0, NULL
    // 0x4e87a0: b               #0x4e87ac
    // 0x4e87a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e87a4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e87a8: r0 = toStringConsistentDecimalPlaces()
    //     0x4e87a8: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e87ac: cmp             w0, NULL
    // 0x4e87b0: b.ne            #0x4e87b8
    // 0x4e87b4: r0 = 0
    //     0x4e87b4: movz            x0, #0
    // 0x4e87b8: ldur            x1, [fp, #-0x10]
    // 0x4e87bc: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e87bc: add             x25, x1, #0x13
    //     0x4e87c0: str             w0, [x25]
    //     0x4e87c4: tbz             w0, #0, #0x4e87e0
    //     0x4e87c8: ldurb           w16, [x1, #-1]
    //     0x4e87cc: ldurb           w17, [x0, #-1]
    //     0x4e87d0: and             x16, x17, x16, lsr #2
    //     0x4e87d4: tst             x16, HEAP, lsr #32
    //     0x4e87d8: b.eq            #0x4e87e0
    //     0x4e87dc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e87e0: ldur            x16, [fp, #-0x10]
    // 0x4e87e4: str             x16, [SP]
    // 0x4e87e8: r0 = _interpolate()
    //     0x4e87e8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e87ec: LeaveFrame
    //     0x4e87ec: mov             SP, fp
    //     0x4e87f0: ldp             fp, lr, [SP], #0x10
    // 0x4e87f4: ret
    //     0x4e87f4: ret             
    // 0x4e87f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e87f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e87fc: b               #0x4e8734
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4f4f1c, size: 0x48
    // 0x4f4f1c: EnterFrame
    //     0x4f4f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x4f4f20: mov             fp, SP
    // 0x4f4f24: ldr             x0, [fp, #0x18]
    // 0x4f4f28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x4f4f28: ldur            w1, [x0, #0x17]
    // 0x4f4f2c: DecompressPointer r1
    //     0x4f4f2c: add             x1, x1, HEAP, lsl #32
    // 0x4f4f30: CheckStackOverflow
    //     0x4f4f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f4f34: cmp             SP, x16
    //     0x4f4f38: b.ls            #0x4f4f5c
    // 0x4f4f3c: LoadField: r0 = r1->field_f
    //     0x4f4f3c: ldur            w0, [x1, #0xf]
    // 0x4f4f40: DecompressPointer r0
    //     0x4f4f40: add             x0, x0, HEAP, lsl #32
    // 0x4f4f44: mov             x1, x0
    // 0x4f4f48: r0 = resetAndRecomputeBoosts()
    //     0x4f4f48: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x4f4f4c: r0 = Null
    //     0x4f4f4c: mov             x0, NULL
    // 0x4f4f50: LeaveFrame
    //     0x4f4f50: mov             SP, fp
    //     0x4f4f54: ldp             fp, lr, [SP], #0x10
    // 0x4f4f58: ret
    //     0x4f4f58: ret             
    // 0x4f4f5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f4f5c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f4f60: b               #0x4f4f3c
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x50a2f8, size: 0x10e8
    // 0x50a2f8: EnterFrame
    //     0x50a2f8: stp             fp, lr, [SP, #-0x10]!
    //     0x50a2fc: mov             fp, SP
    // 0x50a300: AllocStack(0x50)
    //     0x50a300: sub             SP, SP, #0x50
    // 0x50a304: SetupParameters(Chapter9GameState this /* r1 => r2, fp-0x8 */)
    //     0x50a304: mov             x2, x1
    //     0x50a308: stur            x1, [fp, #-8]
    // 0x50a30c: CheckStackOverflow
    //     0x50a30c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50a310: cmp             SP, x16
    //     0x50a314: b.ls            #0x50b3d8
    // 0x50a318: r1 = 1
    //     0x50a318: movz            x1, #0x1
    // 0x50a31c: r0 = AllocateContext()
    //     0x50a31c: bl              #0x82637c  ; AllocateContextStub
    // 0x50a320: mov             x3, x0
    // 0x50a324: ldur            x0, [fp, #-8]
    // 0x50a328: stur            x3, [fp, #-0x10]
    // 0x50a32c: StoreField: r3->field_f = r0
    //     0x50a32c: stur            w0, [x3, #0xf]
    // 0x50a330: r1 = Null
    //     0x50a330: mov             x1, NULL
    // 0x50a334: r2 = 72
    //     0x50a334: movz            x2, #0x48
    // 0x50a338: r0 = AllocateArray()
    //     0x50a338: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a33c: stur            x0, [fp, #-0x18]
    // 0x50a340: r16 = 2
    //     0x50a340: movz            x16, #0x2
    // 0x50a344: StoreField: r0->field_f = r16
    //     0x50a344: stur            w16, [x0, #0xf]
    // 0x50a348: r16 = Instance_GeneratorInfo
    //     0x50a348: add             x16, PP, #0x13, lsl #12  ; [pp+0x13cf0] Obj!GeneratorInfo<Chapter9Stat>@82e991
    //     0x50a34c: ldr             x16, [x16, #0xcf0]
    // 0x50a350: StoreField: r0->field_13 = r16
    //     0x50a350: stur            w16, [x0, #0x13]
    // 0x50a354: r16 = 4
    //     0x50a354: movz            x16, #0x4
    // 0x50a358: ArrayStore: r0[0] = r16  ; List_4
    //     0x50a358: stur            w16, [x0, #0x17]
    // 0x50a35c: r1 = Null
    //     0x50a35c: mov             x1, NULL
    // 0x50a360: r2 = 4
    //     0x50a360: movz            x2, #0x4
    // 0x50a364: r0 = AllocateArray()
    //     0x50a364: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a368: stur            x0, [fp, #-0x20]
    // 0x50a36c: r16 = Instance_Chapter9Stat
    //     0x50a36c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x50a370: ldr             x16, [x16, #0x890]
    // 0x50a374: StoreField: r0->field_f = r16
    //     0x50a374: stur            w16, [x0, #0xf]
    // 0x50a378: r1 = Null
    //     0x50a378: mov             x1, NULL
    // 0x50a37c: r2 = 1.200000
    //     0x50a37c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13cf8] 1.2
    //     0x50a380: ldr             x2, [x2, #0xcf8]
    // 0x50a384: r0 = CustomNum()
    //     0x50a384: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x50a388: ldur            x1, [fp, #-0x20]
    // 0x50a38c: ArrayStore: r1[1] = r0  ; List_4
    //     0x50a38c: add             x25, x1, #0x13
    //     0x50a390: str             w0, [x25]
    //     0x50a394: tbz             w0, #0, #0x50a3b0
    //     0x50a398: ldurb           w16, [x1, #-1]
    //     0x50a39c: ldurb           w17, [x0, #-1]
    //     0x50a3a0: and             x16, x17, x16, lsr #2
    //     0x50a3a4: tst             x16, HEAP, lsr #32
    //     0x50a3a8: b.eq            #0x50a3b0
    //     0x50a3ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a3b0: r16 = <Chapter9Stat, CustomNum>
    //     0x50a3b0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d00] TypeArguments: <Chapter9Stat, CustomNum>
    //     0x50a3b4: ldr             x16, [x16, #0xd00]
    // 0x50a3b8: ldur            lr, [fp, #-0x20]
    // 0x50a3bc: stp             lr, x16, [SP]
    // 0x50a3c0: r0 = Map._fromLiteral()
    //     0x50a3c0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x50a3c4: r1 = <Chapter9Stat>
    //     0x50a3c4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50a3c8: ldr             x1, [x1, #0xe48]
    // 0x50a3cc: stur            x0, [fp, #-0x20]
    // 0x50a3d0: r0 = GeneratorInfo()
    //     0x50a3d0: bl              #0x5013d0  ; AllocateGeneratorInfoStub -> GeneratorInfo<X0> (size=0x38)
    // 0x50a3d4: mov             x1, x0
    // 0x50a3d8: r0 = "Keyboard"
    //     0x50a3d8: add             x0, PP, #0x11, lsl #12  ; [pp+0x118b8] "Keyboard"
    //     0x50a3dc: ldr             x0, [x0, #0x8b8]
    // 0x50a3e0: StoreField: r1->field_1b = r0
    //     0x50a3e0: stur            w0, [x1, #0x1b]
    // 0x50a3e4: r0 = Instance_Tuple2
    //     0x50a3e4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d08] Obj!Tuple2<Chapter9Stat, CustomNum>@826311
    //     0x50a3e8: ldr             x0, [x0, #0xd08]
    // 0x50a3ec: StoreField: r1->field_27 = r0
    //     0x50a3ec: stur            w0, [x1, #0x27]
    // 0x50a3f0: ldur            x0, [fp, #-0x20]
    // 0x50a3f4: StoreField: r1->field_23 = r0
    //     0x50a3f4: stur            w0, [x1, #0x23]
    // 0x50a3f8: r3 = false
    //     0x50a3f8: add             x3, NULL, #0x30  ; false
    // 0x50a3fc: StoreField: r1->field_f = r3
    //     0x50a3fc: stur            w3, [x1, #0xf]
    // 0x50a400: r4 = true
    //     0x50a400: add             x4, NULL, #0x20  ; true
    // 0x50a404: StoreField: r1->field_13 = r4
    //     0x50a404: stur            w4, [x1, #0x13]
    // 0x50a408: StoreField: r1->field_b = r4
    //     0x50a408: stur            w4, [x1, #0xb]
    // 0x50a40c: mov             x0, x1
    // 0x50a410: ldur            x1, [fp, #-0x18]
    // 0x50a414: ArrayStore: r1[3] = r0  ; List_4
    //     0x50a414: add             x25, x1, #0x1b
    //     0x50a418: str             w0, [x25]
    //     0x50a41c: tbz             w0, #0, #0x50a438
    //     0x50a420: ldurb           w16, [x1, #-1]
    //     0x50a424: ldurb           w17, [x0, #-1]
    //     0x50a428: and             x16, x17, x16, lsr #2
    //     0x50a42c: tst             x16, HEAP, lsr #32
    //     0x50a430: b.eq            #0x50a438
    //     0x50a434: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a438: ldur            x0, [fp, #-0x18]
    // 0x50a43c: r16 = 6
    //     0x50a43c: movz            x16, #0x6
    // 0x50a440: StoreField: r0->field_1f = r16
    //     0x50a440: stur            w16, [x0, #0x1f]
    // 0x50a444: r1 = Null
    //     0x50a444: mov             x1, NULL
    // 0x50a448: r2 = 4
    //     0x50a448: movz            x2, #0x4
    // 0x50a44c: r0 = AllocateArray()
    //     0x50a44c: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a450: stur            x0, [fp, #-0x20]
    // 0x50a454: r16 = Instance_Chapter9Stat
    //     0x50a454: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x50a458: ldr             x16, [x16, #0x890]
    // 0x50a45c: StoreField: r0->field_f = r16
    //     0x50a45c: stur            w16, [x0, #0xf]
    // 0x50a460: r1 = Null
    //     0x50a460: mov             x1, NULL
    // 0x50a464: r2 = 1.400000
    //     0x50a464: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d10] 1.4
    //     0x50a468: ldr             x2, [x2, #0xd10]
    // 0x50a46c: r0 = CustomNum()
    //     0x50a46c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x50a470: ldur            x1, [fp, #-0x20]
    // 0x50a474: ArrayStore: r1[1] = r0  ; List_4
    //     0x50a474: add             x25, x1, #0x13
    //     0x50a478: str             w0, [x25]
    //     0x50a47c: tbz             w0, #0, #0x50a498
    //     0x50a480: ldurb           w16, [x1, #-1]
    //     0x50a484: ldurb           w17, [x0, #-1]
    //     0x50a488: and             x16, x17, x16, lsr #2
    //     0x50a48c: tst             x16, HEAP, lsr #32
    //     0x50a490: b.eq            #0x50a498
    //     0x50a494: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a498: r16 = <Chapter9Stat, CustomNum>
    //     0x50a498: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d00] TypeArguments: <Chapter9Stat, CustomNum>
    //     0x50a49c: ldr             x16, [x16, #0xd00]
    // 0x50a4a0: ldur            lr, [fp, #-0x20]
    // 0x50a4a4: stp             lr, x16, [SP]
    // 0x50a4a8: r0 = Map._fromLiteral()
    //     0x50a4a8: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x50a4ac: r1 = <Chapter9Stat>
    //     0x50a4ac: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50a4b0: ldr             x1, [x1, #0xe48]
    // 0x50a4b4: stur            x0, [fp, #-0x20]
    // 0x50a4b8: r0 = GeneratorInfo()
    //     0x50a4b8: bl              #0x5013d0  ; AllocateGeneratorInfoStub -> GeneratorInfo<X0> (size=0x38)
    // 0x50a4bc: mov             x1, x0
    // 0x50a4c0: r0 = "Mechanical Keyboard"
    //     0x50a4c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c0] "Mechanical Keyboard"
    //     0x50a4c4: ldr             x0, [x0, #0x8c0]
    // 0x50a4c8: StoreField: r1->field_1b = r0
    //     0x50a4c8: stur            w0, [x1, #0x1b]
    // 0x50a4cc: r0 = Instance_Tuple2
    //     0x50a4cc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d18] Obj!Tuple2<Chapter9Stat, CustomNum>@8262f1
    //     0x50a4d0: ldr             x0, [x0, #0xd18]
    // 0x50a4d4: StoreField: r1->field_27 = r0
    //     0x50a4d4: stur            w0, [x1, #0x27]
    // 0x50a4d8: ldur            x0, [fp, #-0x20]
    // 0x50a4dc: StoreField: r1->field_23 = r0
    //     0x50a4dc: stur            w0, [x1, #0x23]
    // 0x50a4e0: r3 = false
    //     0x50a4e0: add             x3, NULL, #0x30  ; false
    // 0x50a4e4: StoreField: r1->field_f = r3
    //     0x50a4e4: stur            w3, [x1, #0xf]
    // 0x50a4e8: r4 = true
    //     0x50a4e8: add             x4, NULL, #0x20  ; true
    // 0x50a4ec: StoreField: r1->field_13 = r4
    //     0x50a4ec: stur            w4, [x1, #0x13]
    // 0x50a4f0: StoreField: r1->field_b = r4
    //     0x50a4f0: stur            w4, [x1, #0xb]
    // 0x50a4f4: mov             x0, x1
    // 0x50a4f8: ldur            x1, [fp, #-0x18]
    // 0x50a4fc: ArrayStore: r1[5] = r0  ; List_4
    //     0x50a4fc: add             x25, x1, #0x23
    //     0x50a500: str             w0, [x25]
    //     0x50a504: tbz             w0, #0, #0x50a520
    //     0x50a508: ldurb           w16, [x1, #-1]
    //     0x50a50c: ldurb           w17, [x0, #-1]
    //     0x50a510: and             x16, x17, x16, lsr #2
    //     0x50a514: tst             x16, HEAP, lsr #32
    //     0x50a518: b.eq            #0x50a520
    //     0x50a51c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a520: ldur            x0, [fp, #-0x18]
    // 0x50a524: r16 = 8
    //     0x50a524: movz            x16, #0x8
    // 0x50a528: StoreField: r0->field_27 = r16
    //     0x50a528: stur            w16, [x0, #0x27]
    // 0x50a52c: r1 = Null
    //     0x50a52c: mov             x1, NULL
    // 0x50a530: r2 = 4
    //     0x50a530: movz            x2, #0x4
    // 0x50a534: r0 = AllocateArray()
    //     0x50a534: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a538: stur            x0, [fp, #-0x20]
    // 0x50a53c: r16 = Instance_Chapter9Stat
    //     0x50a53c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x50a540: ldr             x16, [x16, #0x890]
    // 0x50a544: StoreField: r0->field_f = r16
    //     0x50a544: stur            w16, [x0, #0xf]
    // 0x50a548: r1 = Null
    //     0x50a548: mov             x1, NULL
    // 0x50a54c: r2 = 1.700000
    //     0x50a54c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d20] 1.7
    //     0x50a550: ldr             x2, [x2, #0xd20]
    // 0x50a554: r0 = CustomNum()
    //     0x50a554: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x50a558: ldur            x1, [fp, #-0x20]
    // 0x50a55c: ArrayStore: r1[1] = r0  ; List_4
    //     0x50a55c: add             x25, x1, #0x13
    //     0x50a560: str             w0, [x25]
    //     0x50a564: tbz             w0, #0, #0x50a580
    //     0x50a568: ldurb           w16, [x1, #-1]
    //     0x50a56c: ldurb           w17, [x0, #-1]
    //     0x50a570: and             x16, x17, x16, lsr #2
    //     0x50a574: tst             x16, HEAP, lsr #32
    //     0x50a578: b.eq            #0x50a580
    //     0x50a57c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a580: r16 = <Chapter9Stat, CustomNum>
    //     0x50a580: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d00] TypeArguments: <Chapter9Stat, CustomNum>
    //     0x50a584: ldr             x16, [x16, #0xd00]
    // 0x50a588: ldur            lr, [fp, #-0x20]
    // 0x50a58c: stp             lr, x16, [SP]
    // 0x50a590: r0 = Map._fromLiteral()
    //     0x50a590: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x50a594: r1 = <Chapter9Stat>
    //     0x50a594: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50a598: ldr             x1, [x1, #0xe48]
    // 0x50a59c: stur            x0, [fp, #-0x20]
    // 0x50a5a0: r0 = GeneratorInfo()
    //     0x50a5a0: bl              #0x5013d0  ; AllocateGeneratorInfoStub -> GeneratorInfo<X0> (size=0x38)
    // 0x50a5a4: mov             x1, x0
    // 0x50a5a8: r0 = "Clickier Keyboard"
    //     0x50a5a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c8] "Clickier Keyboard"
    //     0x50a5ac: ldr             x0, [x0, #0x8c8]
    // 0x50a5b0: StoreField: r1->field_1b = r0
    //     0x50a5b0: stur            w0, [x1, #0x1b]
    // 0x50a5b4: r0 = Instance_Tuple2
    //     0x50a5b4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Tuple2<Chapter9Stat, CustomNum>@8262d1
    //     0x50a5b8: ldr             x0, [x0, #0xd28]
    // 0x50a5bc: StoreField: r1->field_27 = r0
    //     0x50a5bc: stur            w0, [x1, #0x27]
    // 0x50a5c0: ldur            x0, [fp, #-0x20]
    // 0x50a5c4: StoreField: r1->field_23 = r0
    //     0x50a5c4: stur            w0, [x1, #0x23]
    // 0x50a5c8: r3 = false
    //     0x50a5c8: add             x3, NULL, #0x30  ; false
    // 0x50a5cc: StoreField: r1->field_f = r3
    //     0x50a5cc: stur            w3, [x1, #0xf]
    // 0x50a5d0: r4 = true
    //     0x50a5d0: add             x4, NULL, #0x20  ; true
    // 0x50a5d4: StoreField: r1->field_13 = r4
    //     0x50a5d4: stur            w4, [x1, #0x13]
    // 0x50a5d8: StoreField: r1->field_b = r4
    //     0x50a5d8: stur            w4, [x1, #0xb]
    // 0x50a5dc: mov             x0, x1
    // 0x50a5e0: ldur            x1, [fp, #-0x18]
    // 0x50a5e4: ArrayStore: r1[7] = r0  ; List_4
    //     0x50a5e4: add             x25, x1, #0x2b
    //     0x50a5e8: str             w0, [x25]
    //     0x50a5ec: tbz             w0, #0, #0x50a608
    //     0x50a5f0: ldurb           w16, [x1, #-1]
    //     0x50a5f4: ldurb           w17, [x0, #-1]
    //     0x50a5f8: and             x16, x17, x16, lsr #2
    //     0x50a5fc: tst             x16, HEAP, lsr #32
    //     0x50a600: b.eq            #0x50a608
    //     0x50a604: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a608: ldur            x0, [fp, #-0x18]
    // 0x50a60c: r16 = 10
    //     0x50a60c: movz            x16, #0xa
    // 0x50a610: StoreField: r0->field_2f = r16
    //     0x50a610: stur            w16, [x0, #0x2f]
    // 0x50a614: r1 = Null
    //     0x50a614: mov             x1, NULL
    // 0x50a618: r2 = 4
    //     0x50a618: movz            x2, #0x4
    // 0x50a61c: r0 = AllocateArray()
    //     0x50a61c: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a620: stur            x0, [fp, #-0x20]
    // 0x50a624: r16 = Instance_Chapter9Stat
    //     0x50a624: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x50a628: ldr             x16, [x16, #0x890]
    // 0x50a62c: StoreField: r0->field_f = r16
    //     0x50a62c: stur            w16, [x0, #0xf]
    // 0x50a630: r1 = Null
    //     0x50a630: mov             x1, NULL
    // 0x50a634: r2 = 4
    //     0x50a634: movz            x2, #0x4
    // 0x50a638: r0 = CustomNum()
    //     0x50a638: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x50a63c: ldur            x1, [fp, #-0x20]
    // 0x50a640: ArrayStore: r1[1] = r0  ; List_4
    //     0x50a640: add             x25, x1, #0x13
    //     0x50a644: str             w0, [x25]
    //     0x50a648: tbz             w0, #0, #0x50a664
    //     0x50a64c: ldurb           w16, [x1, #-1]
    //     0x50a650: ldurb           w17, [x0, #-1]
    //     0x50a654: and             x16, x17, x16, lsr #2
    //     0x50a658: tst             x16, HEAP, lsr #32
    //     0x50a65c: b.eq            #0x50a664
    //     0x50a660: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a664: r16 = <Chapter9Stat, CustomNum>
    //     0x50a664: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d00] TypeArguments: <Chapter9Stat, CustomNum>
    //     0x50a668: ldr             x16, [x16, #0xd00]
    // 0x50a66c: ldur            lr, [fp, #-0x20]
    // 0x50a670: stp             lr, x16, [SP]
    // 0x50a674: r0 = Map._fromLiteral()
    //     0x50a674: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x50a678: r1 = <Chapter9Stat>
    //     0x50a678: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50a67c: ldr             x1, [x1, #0xe48]
    // 0x50a680: stur            x0, [fp, #-0x20]
    // 0x50a684: r0 = GeneratorInfo()
    //     0x50a684: bl              #0x5013d0  ; AllocateGeneratorInfoStub -> GeneratorInfo<X0> (size=0x38)
    // 0x50a688: mov             x1, x0
    // 0x50a68c: r0 = "RGB Keyboard"
    //     0x50a68c: add             x0, PP, #0x11, lsl #12  ; [pp+0x118d0] "RGB Keyboard"
    //     0x50a690: ldr             x0, [x0, #0x8d0]
    // 0x50a694: StoreField: r1->field_1b = r0
    //     0x50a694: stur            w0, [x1, #0x1b]
    // 0x50a698: r0 = Instance_Tuple2
    //     0x50a698: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d30] Obj!Tuple2<Chapter9Stat, CustomNum>@8262b1
    //     0x50a69c: ldr             x0, [x0, #0xd30]
    // 0x50a6a0: StoreField: r1->field_27 = r0
    //     0x50a6a0: stur            w0, [x1, #0x27]
    // 0x50a6a4: ldur            x0, [fp, #-0x20]
    // 0x50a6a8: StoreField: r1->field_23 = r0
    //     0x50a6a8: stur            w0, [x1, #0x23]
    // 0x50a6ac: r0 = false
    //     0x50a6ac: add             x0, NULL, #0x30  ; false
    // 0x50a6b0: StoreField: r1->field_f = r0
    //     0x50a6b0: stur            w0, [x1, #0xf]
    // 0x50a6b4: r0 = true
    //     0x50a6b4: add             x0, NULL, #0x20  ; true
    // 0x50a6b8: StoreField: r1->field_13 = r0
    //     0x50a6b8: stur            w0, [x1, #0x13]
    // 0x50a6bc: StoreField: r1->field_b = r0
    //     0x50a6bc: stur            w0, [x1, #0xb]
    // 0x50a6c0: mov             x0, x1
    // 0x50a6c4: ldur            x1, [fp, #-0x18]
    // 0x50a6c8: ArrayStore: r1[9] = r0  ; List_4
    //     0x50a6c8: add             x25, x1, #0x33
    //     0x50a6cc: str             w0, [x25]
    //     0x50a6d0: tbz             w0, #0, #0x50a6ec
    //     0x50a6d4: ldurb           w16, [x1, #-1]
    //     0x50a6d8: ldurb           w17, [x0, #-1]
    //     0x50a6dc: and             x16, x17, x16, lsr #2
    //     0x50a6e0: tst             x16, HEAP, lsr #32
    //     0x50a6e4: b.eq            #0x50a6ec
    //     0x50a6e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a6ec: ldur            x0, [fp, #-0x18]
    // 0x50a6f0: r16 = 22
    //     0x50a6f0: movz            x16, #0x16
    // 0x50a6f4: StoreField: r0->field_37 = r16
    //     0x50a6f4: stur            w16, [x0, #0x37]
    // 0x50a6f8: r16 = Instance_GeneratorInfo
    //     0x50a6f8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d38] Obj!GeneratorInfo<Chapter9Stat>@82e951
    //     0x50a6fc: ldr             x16, [x16, #0xd38]
    // 0x50a700: StoreField: r0->field_3b = r16
    //     0x50a700: stur            w16, [x0, #0x3b]
    // 0x50a704: r16 = 24
    //     0x50a704: movz            x16, #0x18
    // 0x50a708: StoreField: r0->field_3f = r16
    //     0x50a708: stur            w16, [x0, #0x3f]
    // 0x50a70c: r16 = Instance_GeneratorInfo
    //     0x50a70c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d40] Obj!GeneratorInfo<Chapter9Stat>@82e911
    //     0x50a710: ldr             x16, [x16, #0xd40]
    // 0x50a714: StoreField: r0->field_43 = r16
    //     0x50a714: stur            w16, [x0, #0x43]
    // 0x50a718: r16 = 26
    //     0x50a718: movz            x16, #0x1a
    // 0x50a71c: StoreField: r0->field_47 = r16
    //     0x50a71c: stur            w16, [x0, #0x47]
    // 0x50a720: r16 = Instance_GeneratorInfo
    //     0x50a720: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d48] Obj!GeneratorInfo<Chapter9Stat>@82e8d1
    //     0x50a724: ldr             x16, [x16, #0xd48]
    // 0x50a728: StoreField: r0->field_4b = r16
    //     0x50a728: stur            w16, [x0, #0x4b]
    // 0x50a72c: r16 = 28
    //     0x50a72c: movz            x16, #0x1c
    // 0x50a730: StoreField: r0->field_4f = r16
    //     0x50a730: stur            w16, [x0, #0x4f]
    // 0x50a734: r16 = Instance_GeneratorInfo
    //     0x50a734: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d50] Obj!GeneratorInfo<Chapter9Stat>@82e891
    //     0x50a738: ldr             x16, [x16, #0xd50]
    // 0x50a73c: StoreField: r0->field_53 = r16
    //     0x50a73c: stur            w16, [x0, #0x53]
    // 0x50a740: r16 = 42
    //     0x50a740: movz            x16, #0x2a
    // 0x50a744: StoreField: r0->field_57 = r16
    //     0x50a744: stur            w16, [x0, #0x57]
    // 0x50a748: r16 = Instance_GeneratorInfo
    //     0x50a748: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] Obj!GeneratorInfo<Chapter9Stat>@82e851
    //     0x50a74c: ldr             x16, [x16, #0xd58]
    // 0x50a750: StoreField: r0->field_5b = r16
    //     0x50a750: stur            w16, [x0, #0x5b]
    // 0x50a754: r16 = 44
    //     0x50a754: movz            x16, #0x2c
    // 0x50a758: StoreField: r0->field_5f = r16
    //     0x50a758: stur            w16, [x0, #0x5f]
    // 0x50a75c: r16 = Instance_GeneratorInfo
    //     0x50a75c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d60] Obj!GeneratorInfo<Chapter9Stat>@82e811
    //     0x50a760: ldr             x16, [x16, #0xd60]
    // 0x50a764: StoreField: r0->field_63 = r16
    //     0x50a764: stur            w16, [x0, #0x63]
    // 0x50a768: r16 = 46
    //     0x50a768: movz            x16, #0x2e
    // 0x50a76c: StoreField: r0->field_67 = r16
    //     0x50a76c: stur            w16, [x0, #0x67]
    // 0x50a770: r16 = Instance_GeneratorInfo
    //     0x50a770: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d68] Obj!GeneratorInfo<Chapter9Stat>@82e7d1
    //     0x50a774: ldr             x16, [x16, #0xd68]
    // 0x50a778: StoreField: r0->field_6b = r16
    //     0x50a778: stur            w16, [x0, #0x6b]
    // 0x50a77c: r16 = 48
    //     0x50a77c: movz            x16, #0x30
    // 0x50a780: StoreField: r0->field_6f = r16
    //     0x50a780: stur            w16, [x0, #0x6f]
    // 0x50a784: r16 = Instance_GeneratorInfo
    //     0x50a784: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d70] Obj!GeneratorInfo<Chapter9Stat>@82e791
    //     0x50a788: ldr             x16, [x16, #0xd70]
    // 0x50a78c: StoreField: r0->field_73 = r16
    //     0x50a78c: stur            w16, [x0, #0x73]
    // 0x50a790: r16 = 50
    //     0x50a790: movz            x16, #0x32
    // 0x50a794: StoreField: r0->field_77 = r16
    //     0x50a794: stur            w16, [x0, #0x77]
    // 0x50a798: r16 = Instance_GeneratorInfo
    //     0x50a798: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d78] Obj!GeneratorInfo<Chapter9Stat>@82e751
    //     0x50a79c: ldr             x16, [x16, #0xd78]
    // 0x50a7a0: StoreField: r0->field_7b = r16
    //     0x50a7a0: stur            w16, [x0, #0x7b]
    // 0x50a7a4: r16 = 62
    //     0x50a7a4: movz            x16, #0x3e
    // 0x50a7a8: StoreField: r0->field_7f = r16
    //     0x50a7a8: stur            w16, [x0, #0x7f]
    // 0x50a7ac: r16 = Instance_GeneratorInfo
    //     0x50a7ac: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d80] Obj!GeneratorInfo<Chapter9Stat>@82e711
    //     0x50a7b0: ldr             x16, [x16, #0xd80]
    // 0x50a7b4: StoreField: r0->field_83 = r16
    //     0x50a7b4: stur            w16, [x0, #0x83]
    // 0x50a7b8: r16 = 64
    //     0x50a7b8: movz            x16, #0x40
    // 0x50a7bc: StoreField: r0->field_87 = r16
    //     0x50a7bc: stur            w16, [x0, #0x87]
    // 0x50a7c0: r16 = Instance_GeneratorInfo
    //     0x50a7c0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d88] Obj!GeneratorInfo<Chapter9Stat>@82e6d1
    //     0x50a7c4: ldr             x16, [x16, #0xd88]
    // 0x50a7c8: StoreField: r0->field_8b = r16
    //     0x50a7c8: stur            w16, [x0, #0x8b]
    // 0x50a7cc: r16 = 66
    //     0x50a7cc: movz            x16, #0x42
    // 0x50a7d0: StoreField: r0->field_8f = r16
    //     0x50a7d0: stur            w16, [x0, #0x8f]
    // 0x50a7d4: r16 = Instance_GeneratorInfo
    //     0x50a7d4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d90] Obj!GeneratorInfo<Chapter9Stat>@82e691
    //     0x50a7d8: ldr             x16, [x16, #0xd90]
    // 0x50a7dc: StoreField: r0->field_93 = r16
    //     0x50a7dc: stur            w16, [x0, #0x93]
    // 0x50a7e0: r16 = 68
    //     0x50a7e0: movz            x16, #0x44
    // 0x50a7e4: StoreField: r0->field_97 = r16
    //     0x50a7e4: stur            w16, [x0, #0x97]
    // 0x50a7e8: r16 = Instance_GeneratorInfo
    //     0x50a7e8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d98] Obj!GeneratorInfo<Chapter9Stat>@82e651
    //     0x50a7ec: ldr             x16, [x16, #0xd98]
    // 0x50a7f0: StoreField: r0->field_9b = r16
    //     0x50a7f0: stur            w16, [x0, #0x9b]
    // 0x50a7f4: r16 = <int, GeneratorInfo<Chapter9Stat>>
    //     0x50a7f4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13da0] TypeArguments: <int, GeneratorInfo<Chapter9Stat>>
    //     0x50a7f8: ldr             x16, [x16, #0xda0]
    // 0x50a7fc: stp             x0, x16, [SP]
    // 0x50a800: r0 = Map._fromLiteral()
    //     0x50a800: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x50a804: ldur            x3, [fp, #-8]
    // 0x50a808: StoreField: r3->field_8b = r0
    //     0x50a808: stur            w0, [x3, #0x8b]
    //     0x50a80c: ldurb           w16, [x3, #-1]
    //     0x50a810: ldurb           w17, [x0, #-1]
    //     0x50a814: and             x16, x17, x16, lsr #2
    //     0x50a818: tst             x16, HEAP, lsr #32
    //     0x50a81c: b.eq            #0x50a824
    //     0x50a820: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x50a824: r1 = Null
    //     0x50a824: mov             x1, NULL
    // 0x50a828: r2 = 36
    //     0x50a828: movz            x2, #0x24
    // 0x50a82c: r0 = AllocateArray()
    //     0x50a82c: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a830: stur            x0, [fp, #-0x18]
    // 0x50a834: r16 = 2
    //     0x50a834: movz            x16, #0x2
    // 0x50a838: StoreField: r0->field_f = r16
    //     0x50a838: stur            w16, [x0, #0xf]
    // 0x50a83c: r1 = "OSHA Standards"
    //     0x50a83c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13da8] "OSHA Standards"
    //     0x50a840: ldr             x1, [x1, #0xda8]
    // 0x50a844: r0 = autoString()
    //     0x50a844: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50a848: r1 = Function '<anonymous closure>':.
    //     0x50a848: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db0] AnonymousClosure: (0x50be98), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50a84c: ldr             x1, [x1, #0xdb0]
    // 0x50a850: r2 = Null
    //     0x50a850: mov             x2, NULL
    // 0x50a854: stur            x0, [fp, #-0x20]
    // 0x50a858: r0 = AllocateClosure()
    //     0x50a858: bl              #0x826750  ; AllocateClosureStub
    // 0x50a85c: r1 = <String>
    //     0x50a85c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50a860: stur            x0, [fp, #-0x28]
    // 0x50a864: r0 = Generator()
    //     0x50a864: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50a868: ldur            x2, [fp, #-0x28]
    // 0x50a86c: r3 = Null
    //     0x50a86c: mov             x3, NULL
    // 0x50a870: stur            x0, [fp, #-0x28]
    // 0x50a874: r0 = AllocateRecord2()
    //     0x50a874: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50a878: mov             x1, x0
    // 0x50a87c: ldur            x0, [fp, #-0x28]
    // 0x50a880: StoreField: r0->field_f = r1
    //     0x50a880: stur            w1, [x0, #0xf]
    // 0x50a884: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50a884: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50a888: ldr             x1, [x1, #0xdb8]
    // 0x50a88c: r2 = 18
    //     0x50a88c: movz            x2, #0x12
    // 0x50a890: r0 = AllocateArray()
    //     0x50a890: bl              #0x82746c  ; AllocateArrayStub
    // 0x50a894: stur            x0, [fp, #-0x30]
    // 0x50a898: r16 = Instance_Tuple2
    //     0x50a898: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc0] Obj!Tuple2<Chapter9Stat, CustomNum>@8260f1
    //     0x50a89c: ldr             x16, [x16, #0xdc0]
    // 0x50a8a0: StoreField: r0->field_f = r16
    //     0x50a8a0: stur            w16, [x0, #0xf]
    // 0x50a8a4: r16 = Instance_Tuple2
    //     0x50a8a4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!Tuple2<Chapter9Stat, CustomNum>@8260d1
    //     0x50a8a8: ldr             x16, [x16, #0xdc8]
    // 0x50a8ac: StoreField: r0->field_13 = r16
    //     0x50a8ac: stur            w16, [x0, #0x13]
    // 0x50a8b0: r16 = Instance_Tuple2
    //     0x50a8b0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dd0] Obj!Tuple2<Chapter9Stat, CustomNum>@8260b1
    //     0x50a8b4: ldr             x16, [x16, #0xdd0]
    // 0x50a8b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x50a8b8: stur            w16, [x0, #0x17]
    // 0x50a8bc: r16 = Instance_Tuple2
    //     0x50a8bc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13dd8] Obj!Tuple2<Chapter9Stat, CustomNum>@826091
    //     0x50a8c0: ldr             x16, [x16, #0xdd8]
    // 0x50a8c4: StoreField: r0->field_1b = r16
    //     0x50a8c4: stur            w16, [x0, #0x1b]
    // 0x50a8c8: r16 = Instance_Tuple2
    //     0x50a8c8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13de0] Obj!Tuple2<Chapter9Stat, CustomNum>@826071
    //     0x50a8cc: ldr             x16, [x16, #0xde0]
    // 0x50a8d0: StoreField: r0->field_1f = r16
    //     0x50a8d0: stur            w16, [x0, #0x1f]
    // 0x50a8d4: r16 = Instance_Tuple2
    //     0x50a8d4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13de8] Obj!Tuple2<Chapter9Stat, CustomNum>@826051
    //     0x50a8d8: ldr             x16, [x16, #0xde8]
    // 0x50a8dc: StoreField: r0->field_23 = r16
    //     0x50a8dc: stur            w16, [x0, #0x23]
    // 0x50a8e0: r16 = Instance_Tuple2
    //     0x50a8e0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!Tuple2<Chapter9Stat, CustomNum>@826031
    //     0x50a8e4: ldr             x16, [x16, #0xdf0]
    // 0x50a8e8: StoreField: r0->field_27 = r16
    //     0x50a8e8: stur            w16, [x0, #0x27]
    // 0x50a8ec: r16 = Instance_Tuple2
    //     0x50a8ec: add             x16, PP, #0x13, lsl #12  ; [pp+0x13df8] Obj!Tuple2<Chapter9Stat, CustomNum>@826011
    //     0x50a8f0: ldr             x16, [x16, #0xdf8]
    // 0x50a8f4: StoreField: r0->field_2b = r16
    //     0x50a8f4: stur            w16, [x0, #0x2b]
    // 0x50a8f8: r16 = Instance_Tuple2
    //     0x50a8f8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e00] Obj!Tuple2<Chapter9Stat, CustomNum>@825ff1
    //     0x50a8fc: ldr             x16, [x16, #0xe00]
    // 0x50a900: StoreField: r0->field_2f = r16
    //     0x50a900: stur            w16, [x0, #0x2f]
    // 0x50a904: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50a904: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50a908: ldr             x1, [x1, #0xdb8]
    // 0x50a90c: r0 = AllocateGrowableArray()
    //     0x50a90c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50a910: mov             x1, x0
    // 0x50a914: ldur            x0, [fp, #-0x30]
    // 0x50a918: StoreField: r1->field_f = r0
    //     0x50a918: stur            w0, [x1, #0xf]
    // 0x50a91c: r0 = 18
    //     0x50a91c: movz            x0, #0x12
    // 0x50a920: StoreField: r1->field_b = r0
    //     0x50a920: stur            w0, [x1, #0xb]
    // 0x50a924: mov             x2, x1
    // 0x50a928: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50a928: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50a92c: ldr             x1, [x1, #0xdb8]
    // 0x50a930: r0 = Generator.fromList()
    //     0x50a930: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50a934: r1 = <Chapter9Stat>
    //     0x50a934: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50a938: ldr             x1, [x1, #0xe48]
    // 0x50a93c: stur            x0, [fp, #-0x30]
    // 0x50a940: r0 = UpgradeData()
    //     0x50a940: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50a944: mov             x3, x0
    // 0x50a948: ldur            x0, [fp, #-0x20]
    // 0x50a94c: stur            x3, [fp, #-0x38]
    // 0x50a950: StoreField: r3->field_b = r0
    //     0x50a950: stur            w0, [x3, #0xb]
    // 0x50a954: ldur            x0, [fp, #-0x28]
    // 0x50a958: ArrayStore: r3[0] = r0  ; List_4
    //     0x50a958: stur            w0, [x3, #0x17]
    // 0x50a95c: r0 = Instance_IconData
    //     0x50a95c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!IconData@82f4d1
    //     0x50a960: ldr             x0, [x0, #0xe08]
    // 0x50a964: StoreField: r3->field_13 = r0
    //     0x50a964: stur            w0, [x3, #0x13]
    // 0x50a968: ldur            x0, [fp, #-0x30]
    // 0x50a96c: StoreField: r3->field_f = r0
    //     0x50a96c: stur            w0, [x3, #0xf]
    // 0x50a970: ldur            x2, [fp, #-0x10]
    // 0x50a974: r1 = Function '<anonymous closure>':.
    //     0x50a974: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e10] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50a978: ldr             x1, [x1, #0xe10]
    // 0x50a97c: r0 = AllocateClosure()
    //     0x50a97c: bl              #0x826750  ; AllocateClosureStub
    // 0x50a980: mov             x1, x0
    // 0x50a984: ldur            x0, [fp, #-0x38]
    // 0x50a988: StoreField: r0->field_23 = r1
    //     0x50a988: stur            w1, [x0, #0x23]
    // 0x50a98c: ldur            x1, [fp, #-0x18]
    // 0x50a990: ArrayStore: r1[1] = r0  ; List_4
    //     0x50a990: add             x25, x1, #0x13
    //     0x50a994: str             w0, [x25]
    //     0x50a998: tbz             w0, #0, #0x50a9b4
    //     0x50a99c: ldurb           w16, [x1, #-1]
    //     0x50a9a0: ldurb           w17, [x0, #-1]
    //     0x50a9a4: and             x16, x17, x16, lsr #2
    //     0x50a9a8: tst             x16, HEAP, lsr #32
    //     0x50a9ac: b.eq            #0x50a9b4
    //     0x50a9b0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50a9b4: ldur            x0, [fp, #-0x18]
    // 0x50a9b8: r16 = 4
    //     0x50a9b8: movz            x16, #0x4
    // 0x50a9bc: ArrayStore: r0[0] = r16  ; List_4
    //     0x50a9bc: stur            w16, [x0, #0x17]
    // 0x50a9c0: r1 = "Auction"
    //     0x50a9c0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e18] "Auction"
    //     0x50a9c4: ldr             x1, [x1, #0xe18]
    // 0x50a9c8: r0 = autoString()
    //     0x50a9c8: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50a9cc: r1 = Function '<anonymous closure>':.
    //     0x50a9cc: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e20] AnonymousClosure: (0x50be08), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50a9d0: ldr             x1, [x1, #0xe20]
    // 0x50a9d4: r2 = Null
    //     0x50a9d4: mov             x2, NULL
    // 0x50a9d8: stur            x0, [fp, #-0x20]
    // 0x50a9dc: r0 = AllocateClosure()
    //     0x50a9dc: bl              #0x826750  ; AllocateClosureStub
    // 0x50a9e0: r1 = <String>
    //     0x50a9e0: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50a9e4: stur            x0, [fp, #-0x28]
    // 0x50a9e8: r0 = Generator()
    //     0x50a9e8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50a9ec: ldur            x2, [fp, #-0x28]
    // 0x50a9f0: r3 = Null
    //     0x50a9f0: mov             x3, NULL
    // 0x50a9f4: stur            x0, [fp, #-0x28]
    // 0x50a9f8: r0 = AllocateRecord2()
    //     0x50a9f8: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50a9fc: mov             x1, x0
    // 0x50aa00: ldur            x0, [fp, #-0x28]
    // 0x50aa04: StoreField: r0->field_f = r1
    //     0x50aa04: stur            w1, [x0, #0xf]
    // 0x50aa08: r1 = Null
    //     0x50aa08: mov             x1, NULL
    // 0x50aa0c: r2 = 14
    //     0x50aa0c: movz            x2, #0xe
    // 0x50aa10: r0 = AllocateArray()
    //     0x50aa10: bl              #0x82746c  ; AllocateArrayStub
    // 0x50aa14: stur            x0, [fp, #-0x30]
    // 0x50aa18: r16 = Instance_Tuple2
    //     0x50aa18: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e28] Obj!Tuple2<Chapter9Stat, CustomNum>@825fd1
    //     0x50aa1c: ldr             x16, [x16, #0xe28]
    // 0x50aa20: StoreField: r0->field_f = r16
    //     0x50aa20: stur            w16, [x0, #0xf]
    // 0x50aa24: r16 = Instance_Tuple2
    //     0x50aa24: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e30] Obj!Tuple2<Chapter9Stat, CustomNum>@825fb1
    //     0x50aa28: ldr             x16, [x16, #0xe30]
    // 0x50aa2c: StoreField: r0->field_13 = r16
    //     0x50aa2c: stur            w16, [x0, #0x13]
    // 0x50aa30: r16 = Instance_Tuple2
    //     0x50aa30: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e38] Obj!Tuple2<Chapter9Stat, CustomNum>@825f91
    //     0x50aa34: ldr             x16, [x16, #0xe38]
    // 0x50aa38: ArrayStore: r0[0] = r16  ; List_4
    //     0x50aa38: stur            w16, [x0, #0x17]
    // 0x50aa3c: r16 = Instance_Tuple2
    //     0x50aa3c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e40] Obj!Tuple2<Chapter9Stat, CustomNum>@825f71
    //     0x50aa40: ldr             x16, [x16, #0xe40]
    // 0x50aa44: StoreField: r0->field_1b = r16
    //     0x50aa44: stur            w16, [x0, #0x1b]
    // 0x50aa48: r16 = Instance_Tuple2
    //     0x50aa48: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e48] Obj!Tuple2<Chapter9Stat, CustomNum>@825f51
    //     0x50aa4c: ldr             x16, [x16, #0xe48]
    // 0x50aa50: StoreField: r0->field_1f = r16
    //     0x50aa50: stur            w16, [x0, #0x1f]
    // 0x50aa54: r16 = Instance_Tuple2
    //     0x50aa54: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e50] Obj!Tuple2<Chapter9Stat, CustomNum>@825f31
    //     0x50aa58: ldr             x16, [x16, #0xe50]
    // 0x50aa5c: StoreField: r0->field_23 = r16
    //     0x50aa5c: stur            w16, [x0, #0x23]
    // 0x50aa60: r16 = Instance_Tuple2
    //     0x50aa60: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e58] Obj!Tuple2<Chapter9Stat, CustomNum>@825f11
    //     0x50aa64: ldr             x16, [x16, #0xe58]
    // 0x50aa68: StoreField: r0->field_27 = r16
    //     0x50aa68: stur            w16, [x0, #0x27]
    // 0x50aa6c: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50aa6c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50aa70: ldr             x1, [x1, #0xdb8]
    // 0x50aa74: r0 = AllocateGrowableArray()
    //     0x50aa74: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50aa78: mov             x1, x0
    // 0x50aa7c: ldur            x0, [fp, #-0x30]
    // 0x50aa80: StoreField: r1->field_f = r0
    //     0x50aa80: stur            w0, [x1, #0xf]
    // 0x50aa84: r0 = 14
    //     0x50aa84: movz            x0, #0xe
    // 0x50aa88: StoreField: r1->field_b = r0
    //     0x50aa88: stur            w0, [x1, #0xb]
    // 0x50aa8c: mov             x2, x1
    // 0x50aa90: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50aa90: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50aa94: ldr             x1, [x1, #0xdb8]
    // 0x50aa98: r0 = Generator.fromList()
    //     0x50aa98: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50aa9c: r1 = <Chapter9Stat>
    //     0x50aa9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50aaa0: ldr             x1, [x1, #0xe48]
    // 0x50aaa4: stur            x0, [fp, #-0x30]
    // 0x50aaa8: r0 = UpgradeData()
    //     0x50aaa8: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50aaac: mov             x3, x0
    // 0x50aab0: ldur            x0, [fp, #-0x20]
    // 0x50aab4: stur            x3, [fp, #-0x38]
    // 0x50aab8: StoreField: r3->field_b = r0
    //     0x50aab8: stur            w0, [x3, #0xb]
    // 0x50aabc: ldur            x0, [fp, #-0x28]
    // 0x50aac0: ArrayStore: r3[0] = r0  ; List_4
    //     0x50aac0: stur            w0, [x3, #0x17]
    // 0x50aac4: r0 = Instance_IconData
    //     0x50aac4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e60] Obj!IconData@82f4b1
    //     0x50aac8: ldr             x0, [x0, #0xe60]
    // 0x50aacc: StoreField: r3->field_13 = r0
    //     0x50aacc: stur            w0, [x3, #0x13]
    // 0x50aad0: ldur            x0, [fp, #-0x30]
    // 0x50aad4: StoreField: r3->field_f = r0
    //     0x50aad4: stur            w0, [x3, #0xf]
    // 0x50aad8: ldur            x2, [fp, #-8]
    // 0x50aadc: r1 = Function 'applyAuctionBonus':.
    //     0x50aadc: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e68] AnonymousClosure: (0x50b860), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::applyAuctionBonus (0x50b898)
    //     0x50aae0: ldr             x1, [x1, #0xe68]
    // 0x50aae4: r0 = AllocateClosure()
    //     0x50aae4: bl              #0x826750  ; AllocateClosureStub
    // 0x50aae8: mov             x2, x0
    // 0x50aaec: ldur            x0, [fp, #-0x38]
    // 0x50aaf0: stur            x2, [fp, #-0x20]
    // 0x50aaf4: StoreField: r0->field_1b = r2
    //     0x50aaf4: stur            w2, [x0, #0x1b]
    // 0x50aaf8: ldur            x1, [fp, #-0x18]
    // 0x50aafc: ArrayStore: r1[3] = r0  ; List_4
    //     0x50aafc: add             x25, x1, #0x1b
    //     0x50ab00: str             w0, [x25]
    //     0x50ab04: tbz             w0, #0, #0x50ab20
    //     0x50ab08: ldurb           w16, [x1, #-1]
    //     0x50ab0c: ldurb           w17, [x0, #-1]
    //     0x50ab10: and             x16, x17, x16, lsr #2
    //     0x50ab14: tst             x16, HEAP, lsr #32
    //     0x50ab18: b.eq            #0x50ab20
    //     0x50ab1c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50ab20: ldur            x0, [fp, #-0x18]
    // 0x50ab24: r16 = 22
    //     0x50ab24: movz            x16, #0x16
    // 0x50ab28: StoreField: r0->field_1f = r16
    //     0x50ab28: stur            w16, [x0, #0x1f]
    // 0x50ab2c: r1 = "Interest"
    //     0x50ab2c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e70] "Interest"
    //     0x50ab30: ldr             x1, [x1, #0xe70]
    // 0x50ab34: r0 = autoString()
    //     0x50ab34: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50ab38: r1 = Function '<anonymous closure>':.
    //     0x50ab38: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e78] AnonymousClosure: (0x50b7d8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50ab3c: ldr             x1, [x1, #0xe78]
    // 0x50ab40: r2 = Null
    //     0x50ab40: mov             x2, NULL
    // 0x50ab44: stur            x0, [fp, #-0x28]
    // 0x50ab48: r0 = AllocateClosure()
    //     0x50ab48: bl              #0x826750  ; AllocateClosureStub
    // 0x50ab4c: r1 = <String>
    //     0x50ab4c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50ab50: stur            x0, [fp, #-0x30]
    // 0x50ab54: r0 = Generator()
    //     0x50ab54: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50ab58: ldur            x2, [fp, #-0x30]
    // 0x50ab5c: r3 = Null
    //     0x50ab5c: mov             x3, NULL
    // 0x50ab60: stur            x0, [fp, #-0x30]
    // 0x50ab64: r0 = AllocateRecord2()
    //     0x50ab64: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50ab68: mov             x1, x0
    // 0x50ab6c: ldur            x0, [fp, #-0x30]
    // 0x50ab70: StoreField: r0->field_f = r1
    //     0x50ab70: stur            w1, [x0, #0xf]
    // 0x50ab74: r1 = Null
    //     0x50ab74: mov             x1, NULL
    // 0x50ab78: r2 = 6
    //     0x50ab78: movz            x2, #0x6
    // 0x50ab7c: r0 = AllocateArray()
    //     0x50ab7c: bl              #0x82746c  ; AllocateArrayStub
    // 0x50ab80: stur            x0, [fp, #-0x38]
    // 0x50ab84: r16 = Instance_Tuple2
    //     0x50ab84: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e80] Obj!Tuple2<Chapter9Stat, CustomNum>@825ef1
    //     0x50ab88: ldr             x16, [x16, #0xe80]
    // 0x50ab8c: StoreField: r0->field_f = r16
    //     0x50ab8c: stur            w16, [x0, #0xf]
    // 0x50ab90: r16 = Instance_Tuple2
    //     0x50ab90: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e88] Obj!Tuple2<Chapter9Stat, CustomNum>@825ed1
    //     0x50ab94: ldr             x16, [x16, #0xe88]
    // 0x50ab98: StoreField: r0->field_13 = r16
    //     0x50ab98: stur            w16, [x0, #0x13]
    // 0x50ab9c: r16 = Instance_Tuple2
    //     0x50ab9c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e90] Obj!Tuple2<Chapter9Stat, CustomNum>@825eb1
    //     0x50aba0: ldr             x16, [x16, #0xe90]
    // 0x50aba4: ArrayStore: r0[0] = r16  ; List_4
    //     0x50aba4: stur            w16, [x0, #0x17]
    // 0x50aba8: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50aba8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50abac: ldr             x1, [x1, #0xdb8]
    // 0x50abb0: r0 = AllocateGrowableArray()
    //     0x50abb0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50abb4: mov             x1, x0
    // 0x50abb8: ldur            x0, [fp, #-0x38]
    // 0x50abbc: StoreField: r1->field_f = r0
    //     0x50abbc: stur            w0, [x1, #0xf]
    // 0x50abc0: r0 = 6
    //     0x50abc0: movz            x0, #0x6
    // 0x50abc4: StoreField: r1->field_b = r0
    //     0x50abc4: stur            w0, [x1, #0xb]
    // 0x50abc8: mov             x2, x1
    // 0x50abcc: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50abcc: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50abd0: ldr             x1, [x1, #0xdb8]
    // 0x50abd4: r0 = Generator.fromList()
    //     0x50abd4: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50abd8: r1 = <Chapter9Stat>
    //     0x50abd8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50abdc: ldr             x1, [x1, #0xe48]
    // 0x50abe0: stur            x0, [fp, #-0x38]
    // 0x50abe4: r0 = UpgradeData()
    //     0x50abe4: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50abe8: mov             x1, x0
    // 0x50abec: ldur            x0, [fp, #-0x28]
    // 0x50abf0: StoreField: r1->field_b = r0
    //     0x50abf0: stur            w0, [x1, #0xb]
    // 0x50abf4: ldur            x0, [fp, #-0x30]
    // 0x50abf8: ArrayStore: r1[0] = r0  ; List_4
    //     0x50abf8: stur            w0, [x1, #0x17]
    // 0x50abfc: r0 = Instance_IconData
    //     0x50abfc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e98] Obj!IconData@82f491
    //     0x50ac00: ldr             x0, [x0, #0xe98]
    // 0x50ac04: StoreField: r1->field_13 = r0
    //     0x50ac04: stur            w0, [x1, #0x13]
    // 0x50ac08: ldur            x0, [fp, #-0x38]
    // 0x50ac0c: StoreField: r1->field_f = r0
    //     0x50ac0c: stur            w0, [x1, #0xf]
    // 0x50ac10: mov             x0, x1
    // 0x50ac14: ldur            x1, [fp, #-0x18]
    // 0x50ac18: ArrayStore: r1[5] = r0  ; List_4
    //     0x50ac18: add             x25, x1, #0x23
    //     0x50ac1c: str             w0, [x25]
    //     0x50ac20: tbz             w0, #0, #0x50ac3c
    //     0x50ac24: ldurb           w16, [x1, #-1]
    //     0x50ac28: ldurb           w17, [x0, #-1]
    //     0x50ac2c: and             x16, x17, x16, lsr #2
    //     0x50ac30: tst             x16, HEAP, lsr #32
    //     0x50ac34: b.eq            #0x50ac3c
    //     0x50ac38: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50ac3c: ldur            x0, [fp, #-0x18]
    // 0x50ac40: r16 = 24
    //     0x50ac40: movz            x16, #0x18
    // 0x50ac44: StoreField: r0->field_27 = r16
    //     0x50ac44: stur            w16, [x0, #0x27]
    // 0x50ac48: r1 = "Bonus"
    //     0x50ac48: add             x1, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x50ac4c: ldr             x1, [x1, #0xa68]
    // 0x50ac50: r0 = autoString()
    //     0x50ac50: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50ac54: r1 = Function '<anonymous closure>':.
    //     0x50ac54: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ea0] AnonymousClosure: (0x50b5e4), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50ac58: ldr             x1, [x1, #0xea0]
    // 0x50ac5c: r2 = Null
    //     0x50ac5c: mov             x2, NULL
    // 0x50ac60: stur            x0, [fp, #-0x28]
    // 0x50ac64: r0 = AllocateClosure()
    //     0x50ac64: bl              #0x826750  ; AllocateClosureStub
    // 0x50ac68: r1 = <String>
    //     0x50ac68: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50ac6c: stur            x0, [fp, #-0x30]
    // 0x50ac70: r0 = Generator()
    //     0x50ac70: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50ac74: ldur            x2, [fp, #-0x30]
    // 0x50ac78: r3 = Null
    //     0x50ac78: mov             x3, NULL
    // 0x50ac7c: stur            x0, [fp, #-0x30]
    // 0x50ac80: r0 = AllocateRecord2()
    //     0x50ac80: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50ac84: mov             x1, x0
    // 0x50ac88: ldur            x0, [fp, #-0x30]
    // 0x50ac8c: StoreField: r0->field_f = r1
    //     0x50ac8c: stur            w1, [x0, #0xf]
    // 0x50ac90: r1 = Null
    //     0x50ac90: mov             x1, NULL
    // 0x50ac94: r2 = 16
    //     0x50ac94: movz            x2, #0x10
    // 0x50ac98: r0 = AllocateArray()
    //     0x50ac98: bl              #0x82746c  ; AllocateArrayStub
    // 0x50ac9c: stur            x0, [fp, #-0x38]
    // 0x50aca0: r16 = Instance_Tuple2
    //     0x50aca0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ea8] Obj!Tuple2<Chapter9Stat, CustomNum>@825e91
    //     0x50aca4: ldr             x16, [x16, #0xea8]
    // 0x50aca8: StoreField: r0->field_f = r16
    //     0x50aca8: stur            w16, [x0, #0xf]
    // 0x50acac: r16 = Instance_Tuple2
    //     0x50acac: add             x16, PP, #0x13, lsl #12  ; [pp+0x13eb0] Obj!Tuple2<Chapter9Stat, CustomNum>@825e71
    //     0x50acb0: ldr             x16, [x16, #0xeb0]
    // 0x50acb4: StoreField: r0->field_13 = r16
    //     0x50acb4: stur            w16, [x0, #0x13]
    // 0x50acb8: r16 = Instance_Tuple2
    //     0x50acb8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13eb8] Obj!Tuple2<Chapter9Stat, CustomNum>@825e51
    //     0x50acbc: ldr             x16, [x16, #0xeb8]
    // 0x50acc0: ArrayStore: r0[0] = r16  ; List_4
    //     0x50acc0: stur            w16, [x0, #0x17]
    // 0x50acc4: r16 = Instance_Tuple2
    //     0x50acc4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ec0] Obj!Tuple2<Chapter9Stat, CustomNum>@825e31
    //     0x50acc8: ldr             x16, [x16, #0xec0]
    // 0x50accc: StoreField: r0->field_1b = r16
    //     0x50accc: stur            w16, [x0, #0x1b]
    // 0x50acd0: r16 = Instance_Tuple2
    //     0x50acd0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!Tuple2<Chapter9Stat, CustomNum>@825e11
    //     0x50acd4: ldr             x16, [x16, #0xec8]
    // 0x50acd8: StoreField: r0->field_1f = r16
    //     0x50acd8: stur            w16, [x0, #0x1f]
    // 0x50acdc: r16 = Instance_Tuple2
    //     0x50acdc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ed0] Obj!Tuple2<Chapter9Stat, CustomNum>@825df1
    //     0x50ace0: ldr             x16, [x16, #0xed0]
    // 0x50ace4: StoreField: r0->field_23 = r16
    //     0x50ace4: stur            w16, [x0, #0x23]
    // 0x50ace8: r16 = Instance_Tuple2
    //     0x50ace8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ed8] Obj!Tuple2<Chapter9Stat, CustomNum>@825dd1
    //     0x50acec: ldr             x16, [x16, #0xed8]
    // 0x50acf0: StoreField: r0->field_27 = r16
    //     0x50acf0: stur            w16, [x0, #0x27]
    // 0x50acf4: r16 = Instance_Tuple2
    //     0x50acf4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!Tuple2<Chapter9Stat, CustomNum>@825db1
    //     0x50acf8: ldr             x16, [x16, #0xee0]
    // 0x50acfc: StoreField: r0->field_2b = r16
    //     0x50acfc: stur            w16, [x0, #0x2b]
    // 0x50ad00: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ad00: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ad04: ldr             x1, [x1, #0xdb8]
    // 0x50ad08: r0 = AllocateGrowableArray()
    //     0x50ad08: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50ad0c: mov             x1, x0
    // 0x50ad10: ldur            x0, [fp, #-0x38]
    // 0x50ad14: StoreField: r1->field_f = r0
    //     0x50ad14: stur            w0, [x1, #0xf]
    // 0x50ad18: r0 = 16
    //     0x50ad18: movz            x0, #0x10
    // 0x50ad1c: StoreField: r1->field_b = r0
    //     0x50ad1c: stur            w0, [x1, #0xb]
    // 0x50ad20: mov             x2, x1
    // 0x50ad24: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ad24: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ad28: ldr             x1, [x1, #0xdb8]
    // 0x50ad2c: r0 = Generator.fromList()
    //     0x50ad2c: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50ad30: r1 = <Chapter9Stat>
    //     0x50ad30: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50ad34: ldr             x1, [x1, #0xe48]
    // 0x50ad38: stur            x0, [fp, #-0x38]
    // 0x50ad3c: r0 = UpgradeData()
    //     0x50ad3c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50ad40: mov             x3, x0
    // 0x50ad44: ldur            x0, [fp, #-0x28]
    // 0x50ad48: stur            x3, [fp, #-0x40]
    // 0x50ad4c: StoreField: r3->field_b = r0
    //     0x50ad4c: stur            w0, [x3, #0xb]
    // 0x50ad50: ldur            x0, [fp, #-0x30]
    // 0x50ad54: ArrayStore: r3[0] = r0  ; List_4
    //     0x50ad54: stur            w0, [x3, #0x17]
    // 0x50ad58: r0 = Instance_IconData
    //     0x50ad58: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!IconData@82f471
    //     0x50ad5c: ldr             x0, [x0, #0xee8]
    // 0x50ad60: StoreField: r3->field_13 = r0
    //     0x50ad60: stur            w0, [x3, #0x13]
    // 0x50ad64: ldur            x0, [fp, #-0x38]
    // 0x50ad68: StoreField: r3->field_f = r0
    //     0x50ad68: stur            w0, [x3, #0xf]
    // 0x50ad6c: ldur            x2, [fp, #-0x10]
    // 0x50ad70: r1 = Function '<anonymous closure>':.
    //     0x50ad70: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ef0] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50ad74: ldr             x1, [x1, #0xef0]
    // 0x50ad78: r0 = AllocateClosure()
    //     0x50ad78: bl              #0x826750  ; AllocateClosureStub
    // 0x50ad7c: mov             x1, x0
    // 0x50ad80: ldur            x0, [fp, #-0x40]
    // 0x50ad84: StoreField: r0->field_23 = r1
    //     0x50ad84: stur            w1, [x0, #0x23]
    // 0x50ad88: ldur            x1, [fp, #-0x18]
    // 0x50ad8c: ArrayStore: r1[7] = r0  ; List_4
    //     0x50ad8c: add             x25, x1, #0x2b
    //     0x50ad90: str             w0, [x25]
    //     0x50ad94: tbz             w0, #0, #0x50adb0
    //     0x50ad98: ldurb           w16, [x1, #-1]
    //     0x50ad9c: ldurb           w17, [x0, #-1]
    //     0x50ada0: and             x16, x17, x16, lsr #2
    //     0x50ada4: tst             x16, HEAP, lsr #32
    //     0x50ada8: b.eq            #0x50adb0
    //     0x50adac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50adb0: ldur            x0, [fp, #-0x18]
    // 0x50adb4: r16 = 42
    //     0x50adb4: movz            x16, #0x2a
    // 0x50adb8: StoreField: r0->field_2f = r16
    //     0x50adb8: stur            w16, [x0, #0x2f]
    // 0x50adbc: r1 = "Compliance Officers"
    //     0x50adbc: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ef8] "Compliance Officers"
    //     0x50adc0: ldr             x1, [x1, #0xef8]
    // 0x50adc4: r0 = autoString()
    //     0x50adc4: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50adc8: r1 = Null
    //     0x50adc8: mov             x1, NULL
    // 0x50adcc: r2 = 4
    //     0x50adcc: movz            x2, #0x4
    // 0x50add0: stur            x0, [fp, #-0x28]
    // 0x50add4: r0 = AllocateArray()
    //     0x50add4: bl              #0x82746c  ; AllocateArrayStub
    // 0x50add8: stur            x0, [fp, #-0x30]
    // 0x50addc: r16 = "Sets OSHA standards to level 7 and Auction to 2 and tier 1 upgrades do not reset on prestige. And significantly increases yields."
    //     0x50addc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f00] "Sets OSHA standards to level 7 and Auction to 2 and tier 1 upgrades do not reset on prestige. And significantly increases yields."
    //     0x50ade0: ldr             x16, [x16, #0xf00]
    // 0x50ade4: StoreField: r0->field_f = r16
    //     0x50ade4: stur            w16, [x0, #0xf]
    // 0x50ade8: r16 = "Tier 2 upgrades no longer reset on prestige. And increases yields even further."
    //     0x50ade8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f08] "Tier 2 upgrades no longer reset on prestige. And increases yields even further."
    //     0x50adec: ldr             x16, [x16, #0xf08]
    // 0x50adf0: StoreField: r0->field_13 = r16
    //     0x50adf0: stur            w16, [x0, #0x13]
    // 0x50adf4: r1 = <String>
    //     0x50adf4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50adf8: r0 = AllocateGrowableArray()
    //     0x50adf8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50adfc: mov             x1, x0
    // 0x50ae00: ldur            x0, [fp, #-0x30]
    // 0x50ae04: StoreField: r1->field_f = r0
    //     0x50ae04: stur            w0, [x1, #0xf]
    // 0x50ae08: r0 = 4
    //     0x50ae08: movz            x0, #0x4
    // 0x50ae0c: StoreField: r1->field_b = r0
    //     0x50ae0c: stur            w0, [x1, #0xb]
    // 0x50ae10: mov             x2, x1
    // 0x50ae14: r1 = <String>
    //     0x50ae14: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50ae18: r0 = Generator.fromList()
    //     0x50ae18: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50ae1c: r1 = Null
    //     0x50ae1c: mov             x1, NULL
    // 0x50ae20: r2 = 4
    //     0x50ae20: movz            x2, #0x4
    // 0x50ae24: stur            x0, [fp, #-0x30]
    // 0x50ae28: r0 = AllocateArray()
    //     0x50ae28: bl              #0x82746c  ; AllocateArrayStub
    // 0x50ae2c: stur            x0, [fp, #-0x38]
    // 0x50ae30: r16 = Instance_Tuple2
    //     0x50ae30: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f10] Obj!Tuple2<Chapter9Stat, CustomNum>@825d91
    //     0x50ae34: ldr             x16, [x16, #0xf10]
    // 0x50ae38: StoreField: r0->field_f = r16
    //     0x50ae38: stur            w16, [x0, #0xf]
    // 0x50ae3c: r16 = Instance_Tuple2
    //     0x50ae3c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f18] Obj!Tuple2<Chapter9Stat, CustomNum>@825d71
    //     0x50ae40: ldr             x16, [x16, #0xf18]
    // 0x50ae44: StoreField: r0->field_13 = r16
    //     0x50ae44: stur            w16, [x0, #0x13]
    // 0x50ae48: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ae48: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ae4c: ldr             x1, [x1, #0xdb8]
    // 0x50ae50: r0 = AllocateGrowableArray()
    //     0x50ae50: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50ae54: mov             x1, x0
    // 0x50ae58: ldur            x0, [fp, #-0x38]
    // 0x50ae5c: StoreField: r1->field_f = r0
    //     0x50ae5c: stur            w0, [x1, #0xf]
    // 0x50ae60: r0 = 4
    //     0x50ae60: movz            x0, #0x4
    // 0x50ae64: StoreField: r1->field_b = r0
    //     0x50ae64: stur            w0, [x1, #0xb]
    // 0x50ae68: mov             x2, x1
    // 0x50ae6c: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ae6c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50ae70: ldr             x1, [x1, #0xdb8]
    // 0x50ae74: r0 = Generator.fromList()
    //     0x50ae74: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50ae78: r1 = <Chapter9Stat>
    //     0x50ae78: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50ae7c: ldr             x1, [x1, #0xe48]
    // 0x50ae80: stur            x0, [fp, #-0x38]
    // 0x50ae84: r0 = UpgradeData()
    //     0x50ae84: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50ae88: mov             x3, x0
    // 0x50ae8c: ldur            x0, [fp, #-0x28]
    // 0x50ae90: stur            x3, [fp, #-0x40]
    // 0x50ae94: StoreField: r3->field_b = r0
    //     0x50ae94: stur            w0, [x3, #0xb]
    // 0x50ae98: ldur            x0, [fp, #-0x30]
    // 0x50ae9c: ArrayStore: r3[0] = r0  ; List_4
    //     0x50ae9c: stur            w0, [x3, #0x17]
    // 0x50aea0: r0 = Instance_IconData
    //     0x50aea0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!IconData@82f451
    //     0x50aea4: ldr             x0, [x0, #0xf20]
    // 0x50aea8: StoreField: r3->field_13 = r0
    //     0x50aea8: stur            w0, [x3, #0x13]
    // 0x50aeac: ldur            x0, [fp, #-0x38]
    // 0x50aeb0: StoreField: r3->field_f = r0
    //     0x50aeb0: stur            w0, [x3, #0xf]
    // 0x50aeb4: ldur            x2, [fp, #-0x10]
    // 0x50aeb8: r1 = Function '<anonymous closure>':.
    //     0x50aeb8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f28] AnonymousClosure: (0x50b480), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50aebc: ldr             x1, [x1, #0xf28]
    // 0x50aec0: r0 = AllocateClosure()
    //     0x50aec0: bl              #0x826750  ; AllocateClosureStub
    // 0x50aec4: mov             x1, x0
    // 0x50aec8: ldur            x0, [fp, #-0x40]
    // 0x50aecc: StoreField: r0->field_23 = r1
    //     0x50aecc: stur            w1, [x0, #0x23]
    // 0x50aed0: ldur            x1, [fp, #-0x18]
    // 0x50aed4: ArrayStore: r1[9] = r0  ; List_4
    //     0x50aed4: add             x25, x1, #0x33
    //     0x50aed8: str             w0, [x25]
    //     0x50aedc: tbz             w0, #0, #0x50aef8
    //     0x50aee0: ldurb           w16, [x1, #-1]
    //     0x50aee4: ldurb           w17, [x0, #-1]
    //     0x50aee8: and             x16, x17, x16, lsr #2
    //     0x50aeec: tst             x16, HEAP, lsr #32
    //     0x50aef0: b.eq            #0x50aef8
    //     0x50aef4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50aef8: ldur            x0, [fp, #-0x18]
    // 0x50aefc: r16 = 44
    //     0x50aefc: movz            x16, #0x2c
    // 0x50af00: StoreField: r0->field_37 = r16
    //     0x50af00: stur            w16, [x0, #0x37]
    // 0x50af04: r1 = "Data Warehouse"
    //     0x50af04: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f30] "Data Warehouse"
    //     0x50af08: ldr             x1, [x1, #0xf30]
    // 0x50af0c: r0 = autoString()
    //     0x50af0c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50af10: r1 = Function '<anonymous closure>':.
    //     0x50af10: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f38] AnonymousClosure: (0x50b474), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50af14: ldr             x1, [x1, #0xf38]
    // 0x50af18: r2 = Null
    //     0x50af18: mov             x2, NULL
    // 0x50af1c: stur            x0, [fp, #-0x28]
    // 0x50af20: r0 = AllocateClosure()
    //     0x50af20: bl              #0x826750  ; AllocateClosureStub
    // 0x50af24: r1 = <String>
    //     0x50af24: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50af28: stur            x0, [fp, #-0x30]
    // 0x50af2c: r0 = Generator()
    //     0x50af2c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50af30: ldur            x2, [fp, #-0x30]
    // 0x50af34: r3 = Null
    //     0x50af34: mov             x3, NULL
    // 0x50af38: stur            x0, [fp, #-0x30]
    // 0x50af3c: r0 = AllocateRecord2()
    //     0x50af3c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50af40: mov             x1, x0
    // 0x50af44: ldur            x0, [fp, #-0x30]
    // 0x50af48: StoreField: r0->field_f = r1
    //     0x50af48: stur            w1, [x0, #0xf]
    // 0x50af4c: r1 = Null
    //     0x50af4c: mov             x1, NULL
    // 0x50af50: r2 = 2
    //     0x50af50: movz            x2, #0x2
    // 0x50af54: r0 = AllocateArray()
    //     0x50af54: bl              #0x82746c  ; AllocateArrayStub
    // 0x50af58: stur            x0, [fp, #-0x38]
    // 0x50af5c: r16 = Instance_Tuple2
    //     0x50af5c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f40] Obj!Tuple2<Chapter9Stat, CustomNum>@825d51
    //     0x50af60: ldr             x16, [x16, #0xf40]
    // 0x50af64: StoreField: r0->field_f = r16
    //     0x50af64: stur            w16, [x0, #0xf]
    // 0x50af68: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50af68: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50af6c: ldr             x1, [x1, #0xdb8]
    // 0x50af70: r0 = AllocateGrowableArray()
    //     0x50af70: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50af74: mov             x1, x0
    // 0x50af78: ldur            x0, [fp, #-0x38]
    // 0x50af7c: StoreField: r1->field_f = r0
    //     0x50af7c: stur            w0, [x1, #0xf]
    // 0x50af80: r0 = 2
    //     0x50af80: movz            x0, #0x2
    // 0x50af84: StoreField: r1->field_b = r0
    //     0x50af84: stur            w0, [x1, #0xb]
    // 0x50af88: mov             x2, x1
    // 0x50af8c: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50af8c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50af90: ldr             x1, [x1, #0xdb8]
    // 0x50af94: r0 = Generator.fromList()
    //     0x50af94: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50af98: r1 = <Chapter9Stat>
    //     0x50af98: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50af9c: ldr             x1, [x1, #0xe48]
    // 0x50afa0: stur            x0, [fp, #-0x38]
    // 0x50afa4: r0 = UpgradeData()
    //     0x50afa4: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50afa8: mov             x1, x0
    // 0x50afac: ldur            x0, [fp, #-0x28]
    // 0x50afb0: StoreField: r1->field_b = r0
    //     0x50afb0: stur            w0, [x1, #0xb]
    // 0x50afb4: ldur            x0, [fp, #-0x30]
    // 0x50afb8: ArrayStore: r1[0] = r0  ; List_4
    //     0x50afb8: stur            w0, [x1, #0x17]
    // 0x50afbc: r0 = Instance_IconData
    //     0x50afbc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f48] Obj!IconData@82f431
    //     0x50afc0: ldr             x0, [x0, #0xf48]
    // 0x50afc4: StoreField: r1->field_13 = r0
    //     0x50afc4: stur            w0, [x1, #0x13]
    // 0x50afc8: ldur            x0, [fp, #-0x38]
    // 0x50afcc: StoreField: r1->field_f = r0
    //     0x50afcc: stur            w0, [x1, #0xf]
    // 0x50afd0: ldur            x0, [fp, #-0x20]
    // 0x50afd4: StoreField: r1->field_1b = r0
    //     0x50afd4: stur            w0, [x1, #0x1b]
    // 0x50afd8: mov             x0, x1
    // 0x50afdc: ldur            x1, [fp, #-0x18]
    // 0x50afe0: ArrayStore: r1[11] = r0  ; List_4
    //     0x50afe0: add             x25, x1, #0x3b
    //     0x50afe4: str             w0, [x25]
    //     0x50afe8: tbz             w0, #0, #0x50b004
    //     0x50afec: ldurb           w16, [x1, #-1]
    //     0x50aff0: ldurb           w17, [x0, #-1]
    //     0x50aff4: and             x16, x17, x16, lsr #2
    //     0x50aff8: tst             x16, HEAP, lsr #32
    //     0x50affc: b.eq            #0x50b004
    //     0x50b000: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50b004: ldur            x0, [fp, #-0x18]
    // 0x50b008: r16 = 46
    //     0x50b008: movz            x16, #0x2e
    // 0x50b00c: StoreField: r0->field_3f = r16
    //     0x50b00c: stur            w16, [x0, #0x3f]
    // 0x50b010: r1 = "Mechanics"
    //     0x50b010: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f50] "Mechanics"
    //     0x50b014: ldr             x1, [x1, #0xf50]
    // 0x50b018: r0 = autoString()
    //     0x50b018: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50b01c: r1 = Function '<anonymous closure>':.
    //     0x50b01c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f58] AnonymousClosure: (0x50b468), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50b020: ldr             x1, [x1, #0xf58]
    // 0x50b024: r2 = Null
    //     0x50b024: mov             x2, NULL
    // 0x50b028: stur            x0, [fp, #-0x20]
    // 0x50b02c: r0 = AllocateClosure()
    //     0x50b02c: bl              #0x826750  ; AllocateClosureStub
    // 0x50b030: r1 = <String>
    //     0x50b030: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50b034: stur            x0, [fp, #-0x28]
    // 0x50b038: r0 = Generator()
    //     0x50b038: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50b03c: ldur            x2, [fp, #-0x28]
    // 0x50b040: r3 = Null
    //     0x50b040: mov             x3, NULL
    // 0x50b044: stur            x0, [fp, #-0x28]
    // 0x50b048: r0 = AllocateRecord2()
    //     0x50b048: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50b04c: mov             x1, x0
    // 0x50b050: ldur            x0, [fp, #-0x28]
    // 0x50b054: StoreField: r0->field_f = r1
    //     0x50b054: stur            w1, [x0, #0xf]
    // 0x50b058: r1 = Null
    //     0x50b058: mov             x1, NULL
    // 0x50b05c: r2 = 2
    //     0x50b05c: movz            x2, #0x2
    // 0x50b060: r0 = AllocateArray()
    //     0x50b060: bl              #0x82746c  ; AllocateArrayStub
    // 0x50b064: stur            x0, [fp, #-0x30]
    // 0x50b068: r16 = Instance_Tuple2
    //     0x50b068: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f60] Obj!Tuple2<Chapter9Stat, CustomNum>@825d31
    //     0x50b06c: ldr             x16, [x16, #0xf60]
    // 0x50b070: StoreField: r0->field_f = r16
    //     0x50b070: stur            w16, [x0, #0xf]
    // 0x50b074: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b074: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b078: ldr             x1, [x1, #0xdb8]
    // 0x50b07c: r0 = AllocateGrowableArray()
    //     0x50b07c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50b080: mov             x1, x0
    // 0x50b084: ldur            x0, [fp, #-0x30]
    // 0x50b088: StoreField: r1->field_f = r0
    //     0x50b088: stur            w0, [x1, #0xf]
    // 0x50b08c: r0 = 2
    //     0x50b08c: movz            x0, #0x2
    // 0x50b090: StoreField: r1->field_b = r0
    //     0x50b090: stur            w0, [x1, #0xb]
    // 0x50b094: mov             x2, x1
    // 0x50b098: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b098: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b09c: ldr             x1, [x1, #0xdb8]
    // 0x50b0a0: r0 = Generator.fromList()
    //     0x50b0a0: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50b0a4: r1 = <Chapter9Stat>
    //     0x50b0a4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50b0a8: ldr             x1, [x1, #0xe48]
    // 0x50b0ac: stur            x0, [fp, #-0x30]
    // 0x50b0b0: r0 = UpgradeData()
    //     0x50b0b0: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50b0b4: mov             x3, x0
    // 0x50b0b8: ldur            x0, [fp, #-0x20]
    // 0x50b0bc: stur            x3, [fp, #-0x38]
    // 0x50b0c0: StoreField: r3->field_b = r0
    //     0x50b0c0: stur            w0, [x3, #0xb]
    // 0x50b0c4: ldur            x0, [fp, #-0x28]
    // 0x50b0c8: ArrayStore: r3[0] = r0  ; List_4
    //     0x50b0c8: stur            w0, [x3, #0x17]
    // 0x50b0cc: r0 = Instance_IconData
    //     0x50b0cc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f68] Obj!IconData@82fbb1
    //     0x50b0d0: ldr             x0, [x0, #0xf68]
    // 0x50b0d4: StoreField: r3->field_13 = r0
    //     0x50b0d4: stur            w0, [x3, #0x13]
    // 0x50b0d8: ldur            x0, [fp, #-0x30]
    // 0x50b0dc: StoreField: r3->field_f = r0
    //     0x50b0dc: stur            w0, [x3, #0xf]
    // 0x50b0e0: ldur            x2, [fp, #-0x10]
    // 0x50b0e4: r1 = Function '<anonymous closure>':.
    //     0x50b0e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f70] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50b0e8: ldr             x1, [x1, #0xf70]
    // 0x50b0ec: r0 = AllocateClosure()
    //     0x50b0ec: bl              #0x826750  ; AllocateClosureStub
    // 0x50b0f0: mov             x1, x0
    // 0x50b0f4: ldur            x0, [fp, #-0x38]
    // 0x50b0f8: StoreField: r0->field_23 = r1
    //     0x50b0f8: stur            w1, [x0, #0x23]
    // 0x50b0fc: ldur            x1, [fp, #-0x18]
    // 0x50b100: ArrayStore: r1[13] = r0  ; List_4
    //     0x50b100: add             x25, x1, #0x43
    //     0x50b104: str             w0, [x25]
    //     0x50b108: tbz             w0, #0, #0x50b124
    //     0x50b10c: ldurb           w16, [x1, #-1]
    //     0x50b110: ldurb           w17, [x0, #-1]
    //     0x50b114: and             x16, x17, x16, lsr #2
    //     0x50b118: tst             x16, HEAP, lsr #32
    //     0x50b11c: b.eq            #0x50b124
    //     0x50b120: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50b124: ldur            x0, [fp, #-0x18]
    // 0x50b128: r16 = 48
    //     0x50b128: movz            x16, #0x30
    // 0x50b12c: StoreField: r0->field_47 = r16
    //     0x50b12c: stur            w16, [x0, #0x47]
    // 0x50b130: r1 = "Effective Management"
    //     0x50b130: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f78] "Effective Management"
    //     0x50b134: ldr             x1, [x1, #0xf78]
    // 0x50b138: r0 = autoString()
    //     0x50b138: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50b13c: r1 = Null
    //     0x50b13c: mov             x1, NULL
    // 0x50b140: r2 = 6
    //     0x50b140: movz            x2, #0x6
    // 0x50b144: stur            x0, [fp, #-0x20]
    // 0x50b148: r0 = AllocateArray()
    //     0x50b148: bl              #0x82746c  ; AllocateArrayStub
    // 0x50b14c: stur            x0, [fp, #-0x28]
    // 0x50b150: r16 = "Lines also contribute to career capital a little"
    //     0x50b150: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f80] "Lines also contribute to career capital a little"
    //     0x50b154: ldr             x16, [x16, #0xf80]
    // 0x50b158: StoreField: r0->field_f = r16
    //     0x50b158: stur            w16, [x0, #0xf]
    // 0x50b15c: r16 = "Significantly increases the impact of lines on career capital"
    //     0x50b15c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f88] "Significantly increases the impact of lines on career capital"
    //     0x50b160: ldr             x16, [x16, #0xf88]
    // 0x50b164: StoreField: r0->field_13 = r16
    //     0x50b164: stur            w16, [x0, #0x13]
    // 0x50b168: r16 = "Significantly increases the impact of lines on career capital"
    //     0x50b168: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f88] "Significantly increases the impact of lines on career capital"
    //     0x50b16c: ldr             x16, [x16, #0xf88]
    // 0x50b170: ArrayStore: r0[0] = r16  ; List_4
    //     0x50b170: stur            w16, [x0, #0x17]
    // 0x50b174: r1 = <String>
    //     0x50b174: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50b178: r0 = AllocateGrowableArray()
    //     0x50b178: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50b17c: mov             x1, x0
    // 0x50b180: ldur            x0, [fp, #-0x28]
    // 0x50b184: StoreField: r1->field_f = r0
    //     0x50b184: stur            w0, [x1, #0xf]
    // 0x50b188: r0 = 6
    //     0x50b188: movz            x0, #0x6
    // 0x50b18c: StoreField: r1->field_b = r0
    //     0x50b18c: stur            w0, [x1, #0xb]
    // 0x50b190: mov             x2, x1
    // 0x50b194: r1 = <String>
    //     0x50b194: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50b198: r0 = Generator.fromList()
    //     0x50b198: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50b19c: r1 = Null
    //     0x50b19c: mov             x1, NULL
    // 0x50b1a0: r2 = 6
    //     0x50b1a0: movz            x2, #0x6
    // 0x50b1a4: stur            x0, [fp, #-0x28]
    // 0x50b1a8: r0 = AllocateArray()
    //     0x50b1a8: bl              #0x82746c  ; AllocateArrayStub
    // 0x50b1ac: stur            x0, [fp, #-0x30]
    // 0x50b1b0: r16 = Instance_Tuple2
    //     0x50b1b0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f90] Obj!Tuple2<Chapter9Stat, CustomNum>@825d11
    //     0x50b1b4: ldr             x16, [x16, #0xf90]
    // 0x50b1b8: StoreField: r0->field_f = r16
    //     0x50b1b8: stur            w16, [x0, #0xf]
    // 0x50b1bc: r16 = Instance_Tuple2
    //     0x50b1bc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f98] Obj!Tuple2<Chapter9Stat, CustomNum>@825cf1
    //     0x50b1c0: ldr             x16, [x16, #0xf98]
    // 0x50b1c4: StoreField: r0->field_13 = r16
    //     0x50b1c4: stur            w16, [x0, #0x13]
    // 0x50b1c8: r16 = Instance_Tuple2
    //     0x50b1c8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fa0] Obj!Tuple2<Chapter9Stat, CustomNum>@825cd1
    //     0x50b1cc: ldr             x16, [x16, #0xfa0]
    // 0x50b1d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x50b1d0: stur            w16, [x0, #0x17]
    // 0x50b1d4: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b1d4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b1d8: ldr             x1, [x1, #0xdb8]
    // 0x50b1dc: r0 = AllocateGrowableArray()
    //     0x50b1dc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50b1e0: mov             x1, x0
    // 0x50b1e4: ldur            x0, [fp, #-0x30]
    // 0x50b1e8: StoreField: r1->field_f = r0
    //     0x50b1e8: stur            w0, [x1, #0xf]
    // 0x50b1ec: r0 = 6
    //     0x50b1ec: movz            x0, #0x6
    // 0x50b1f0: StoreField: r1->field_b = r0
    //     0x50b1f0: stur            w0, [x1, #0xb]
    // 0x50b1f4: mov             x2, x1
    // 0x50b1f8: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b1f8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b1fc: ldr             x1, [x1, #0xdb8]
    // 0x50b200: r0 = Generator.fromList()
    //     0x50b200: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50b204: r1 = <Chapter9Stat>
    //     0x50b204: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50b208: ldr             x1, [x1, #0xe48]
    // 0x50b20c: stur            x0, [fp, #-0x30]
    // 0x50b210: r0 = UpgradeData()
    //     0x50b210: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50b214: mov             x1, x0
    // 0x50b218: ldur            x0, [fp, #-0x20]
    // 0x50b21c: StoreField: r1->field_b = r0
    //     0x50b21c: stur            w0, [x1, #0xb]
    // 0x50b220: ldur            x0, [fp, #-0x28]
    // 0x50b224: ArrayStore: r1[0] = r0  ; List_4
    //     0x50b224: stur            w0, [x1, #0x17]
    // 0x50b228: r0 = Instance_IconData
    //     0x50b228: add             x0, PP, #0x13, lsl #12  ; [pp+0x13fa8] Obj!IconData@82f411
    //     0x50b22c: ldr             x0, [x0, #0xfa8]
    // 0x50b230: StoreField: r1->field_13 = r0
    //     0x50b230: stur            w0, [x1, #0x13]
    // 0x50b234: ldur            x0, [fp, #-0x30]
    // 0x50b238: StoreField: r1->field_f = r0
    //     0x50b238: stur            w0, [x1, #0xf]
    // 0x50b23c: mov             x0, x1
    // 0x50b240: ldur            x1, [fp, #-0x18]
    // 0x50b244: ArrayStore: r1[15] = r0  ; List_4
    //     0x50b244: add             x25, x1, #0x4b
    //     0x50b248: str             w0, [x25]
    //     0x50b24c: tbz             w0, #0, #0x50b268
    //     0x50b250: ldurb           w16, [x1, #-1]
    //     0x50b254: ldurb           w17, [x0, #-1]
    //     0x50b258: and             x16, x17, x16, lsr #2
    //     0x50b25c: tst             x16, HEAP, lsr #32
    //     0x50b260: b.eq            #0x50b268
    //     0x50b264: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50b268: ldur            x0, [fp, #-0x18]
    // 0x50b26c: r16 = 50
    //     0x50b26c: movz            x16, #0x32
    // 0x50b270: StoreField: r0->field_4f = r16
    //     0x50b270: stur            w16, [x0, #0x4f]
    // 0x50b274: r1 = "N-Key Rollover"
    //     0x50b274: add             x1, PP, #0x13, lsl #12  ; [pp+0x13fb0] "N-Key Rollover"
    //     0x50b278: ldr             x1, [x1, #0xfb0]
    // 0x50b27c: r0 = autoString()
    //     0x50b27c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x50b280: r1 = Function '<anonymous closure>':.
    //     0x50b280: add             x1, PP, #0x13, lsl #12  ; [pp+0x13fb8] AnonymousClosure: (0x50b45c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50b284: ldr             x1, [x1, #0xfb8]
    // 0x50b288: r2 = Null
    //     0x50b288: mov             x2, NULL
    // 0x50b28c: stur            x0, [fp, #-0x20]
    // 0x50b290: r0 = AllocateClosure()
    //     0x50b290: bl              #0x826750  ; AllocateClosureStub
    // 0x50b294: r1 = <String>
    //     0x50b294: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x50b298: stur            x0, [fp, #-0x28]
    // 0x50b29c: r0 = Generator()
    //     0x50b29c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x50b2a0: ldur            x2, [fp, #-0x28]
    // 0x50b2a4: r3 = Null
    //     0x50b2a4: mov             x3, NULL
    // 0x50b2a8: stur            x0, [fp, #-0x28]
    // 0x50b2ac: r0 = AllocateRecord2()
    //     0x50b2ac: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x50b2b0: mov             x1, x0
    // 0x50b2b4: ldur            x0, [fp, #-0x28]
    // 0x50b2b8: StoreField: r0->field_f = r1
    //     0x50b2b8: stur            w1, [x0, #0xf]
    // 0x50b2bc: r1 = Null
    //     0x50b2bc: mov             x1, NULL
    // 0x50b2c0: r2 = 4
    //     0x50b2c0: movz            x2, #0x4
    // 0x50b2c4: r0 = AllocateArray()
    //     0x50b2c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x50b2c8: stur            x0, [fp, #-0x30]
    // 0x50b2cc: r16 = Instance_Tuple2
    //     0x50b2cc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] Obj!Tuple2<Chapter9Stat, CustomNum>@825cb1
    //     0x50b2d0: ldr             x16, [x16, #0xfc0]
    // 0x50b2d4: StoreField: r0->field_f = r16
    //     0x50b2d4: stur            w16, [x0, #0xf]
    // 0x50b2d8: r16 = Instance_Tuple2
    //     0x50b2d8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc8] Obj!Tuple2<Chapter9Stat, CustomNum>@825c91
    //     0x50b2dc: ldr             x16, [x16, #0xfc8]
    // 0x50b2e0: StoreField: r0->field_13 = r16
    //     0x50b2e0: stur            w16, [x0, #0x13]
    // 0x50b2e4: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b2e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b2e8: ldr             x1, [x1, #0xdb8]
    // 0x50b2ec: r0 = AllocateGrowableArray()
    //     0x50b2ec: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x50b2f0: mov             x1, x0
    // 0x50b2f4: ldur            x0, [fp, #-0x30]
    // 0x50b2f8: StoreField: r1->field_f = r0
    //     0x50b2f8: stur            w0, [x1, #0xf]
    // 0x50b2fc: r0 = 4
    //     0x50b2fc: movz            x0, #0x4
    // 0x50b300: StoreField: r1->field_b = r0
    //     0x50b300: stur            w0, [x1, #0xb]
    // 0x50b304: mov             x2, x1
    // 0x50b308: r1 = <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b308: add             x1, PP, #0x13, lsl #12  ; [pp+0x13db8] TypeArguments: <Tuple2<Chapter9Stat, CustomNum>>
    //     0x50b30c: ldr             x1, [x1, #0xdb8]
    // 0x50b310: r0 = Generator.fromList()
    //     0x50b310: bl              #0x4f4d40  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::Generator.fromList
    // 0x50b314: r1 = <Chapter9Stat>
    //     0x50b314: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x50b318: ldr             x1, [x1, #0xe48]
    // 0x50b31c: stur            x0, [fp, #-0x30]
    // 0x50b320: r0 = UpgradeData()
    //     0x50b320: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x50b324: mov             x3, x0
    // 0x50b328: ldur            x0, [fp, #-0x20]
    // 0x50b32c: stur            x3, [fp, #-0x38]
    // 0x50b330: StoreField: r3->field_b = r0
    //     0x50b330: stur            w0, [x3, #0xb]
    // 0x50b334: ldur            x0, [fp, #-0x28]
    // 0x50b338: ArrayStore: r3[0] = r0  ; List_4
    //     0x50b338: stur            w0, [x3, #0x17]
    // 0x50b33c: r0 = Instance_IconData
    //     0x50b33c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13fd0] Obj!IconData@82f3f1
    //     0x50b340: ldr             x0, [x0, #0xfd0]
    // 0x50b344: StoreField: r3->field_13 = r0
    //     0x50b344: stur            w0, [x3, #0x13]
    // 0x50b348: ldur            x0, [fp, #-0x30]
    // 0x50b34c: StoreField: r3->field_f = r0
    //     0x50b34c: stur            w0, [x3, #0xf]
    // 0x50b350: ldur            x2, [fp, #-0x10]
    // 0x50b354: r1 = Function '<anonymous closure>':.
    //     0x50b354: add             x1, PP, #0x13, lsl #12  ; [pp+0x13fd8] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x50b358: ldr             x1, [x1, #0xfd8]
    // 0x50b35c: r0 = AllocateClosure()
    //     0x50b35c: bl              #0x826750  ; AllocateClosureStub
    // 0x50b360: mov             x1, x0
    // 0x50b364: ldur            x0, [fp, #-0x38]
    // 0x50b368: StoreField: r0->field_23 = r1
    //     0x50b368: stur            w1, [x0, #0x23]
    // 0x50b36c: ldur            x1, [fp, #-0x18]
    // 0x50b370: ArrayStore: r1[17] = r0  ; List_4
    //     0x50b370: add             x25, x1, #0x53
    //     0x50b374: str             w0, [x25]
    //     0x50b378: tbz             w0, #0, #0x50b394
    //     0x50b37c: ldurb           w16, [x1, #-1]
    //     0x50b380: ldurb           w17, [x0, #-1]
    //     0x50b384: and             x16, x17, x16, lsr #2
    //     0x50b388: tst             x16, HEAP, lsr #32
    //     0x50b38c: b.eq            #0x50b394
    //     0x50b390: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50b394: r16 = <int, UpgradeData<Chapter9Stat>>
    //     0x50b394: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fe0] TypeArguments: <int, UpgradeData<Chapter9Stat>>
    //     0x50b398: ldr             x16, [x16, #0xfe0]
    // 0x50b39c: ldur            lr, [fp, #-0x18]
    // 0x50b3a0: stp             lr, x16, [SP]
    // 0x50b3a4: r0 = Map._fromLiteral()
    //     0x50b3a4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x50b3a8: ldur            x1, [fp, #-8]
    // 0x50b3ac: StoreField: r1->field_8f = r0
    //     0x50b3ac: stur            w0, [x1, #0x8f]
    //     0x50b3b0: ldurb           w16, [x1, #-1]
    //     0x50b3b4: ldurb           w17, [x0, #-1]
    //     0x50b3b8: and             x16, x17, x16, lsr #2
    //     0x50b3bc: tst             x16, HEAP, lsr #32
    //     0x50b3c0: b.eq            #0x50b3c8
    //     0x50b3c4: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x50b3c8: r0 = Null
    //     0x50b3c8: mov             x0, NULL
    // 0x50b3cc: LeaveFrame
    //     0x50b3cc: mov             SP, fp
    //     0x50b3d0: ldp             fp, lr, [SP], #0x10
    // 0x50b3d4: ret
    //     0x50b3d4: ret             
    // 0x50b3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50b3d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50b3dc: b               #0x50a318
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50b45c, size: 0xc
    // 0x50b45c: r0 = "4× the speed of all progress generators."
    //     0x50b45c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13fe8] "4× the speed of all progress generators."
    //     0x50b460: ldr             x0, [x0, #0xfe8]
    // 0x50b464: ret
    //     0x50b464: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50b468, size: 0xc
    // 0x50b468: r0 = "Autobuys line generators. Increases all yields."
    //     0x50b468: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ff0] "Autobuys line generators. Increases all yields."
    //     0x50b46c: ldr             x0, [x0, #0xff0]
    // 0x50b470: ret
    //     0x50b470: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50b474, size: 0xc
    // 0x50b474: r0 = "Auction bonuses apply to tier 2 generators as well"
    //     0x50b474: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ff8] "Auction bonuses apply to tier 2 generators as well"
    //     0x50b478: ldr             x0, [x0, #0xff8]
    // 0x50b47c: ret
    //     0x50b47c: ret             
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x50b480, size: 0x164
    // 0x50b480: EnterFrame
    //     0x50b480: stp             fp, lr, [SP, #-0x10]!
    //     0x50b484: mov             fp, SP
    // 0x50b488: AllocStack(0x10)
    //     0x50b488: sub             SP, SP, #0x10
    // 0x50b48c: SetupParameters([dynamic _ /* r0 */])
    //     0x50b48c: ldr             x0, [fp, #0x18]
    //     0x50b490: ldur            w3, [x0, #0x17]
    //     0x50b494: add             x3, x3, HEAP, lsl #32
    //     0x50b498: stur            x3, [fp, #-0x10]
    // 0x50b49c: CheckStackOverflow
    //     0x50b49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50b4a0: cmp             SP, x16
    //     0x50b4a4: b.ls            #0x50b5dc
    // 0x50b4a8: LoadField: r0 = r3->field_f
    //     0x50b4a8: ldur            w0, [x3, #0xf]
    // 0x50b4ac: DecompressPointer r0
    //     0x50b4ac: add             x0, x0, HEAP, lsl #32
    // 0x50b4b0: LoadField: r4 = r0->field_43
    //     0x50b4b0: ldur            w4, [x0, #0x43]
    // 0x50b4b4: DecompressPointer r4
    //     0x50b4b4: add             x4, x4, HEAP, lsl #32
    // 0x50b4b8: mov             x1, x4
    // 0x50b4bc: stur            x4, [fp, #-8]
    // 0x50b4c0: r2 = 2
    //     0x50b4c0: movz            x2, #0x2
    // 0x50b4c4: r0 = _getValueOrData()
    //     0x50b4c4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50b4c8: ldur            x2, [fp, #-8]
    // 0x50b4cc: LoadField: r1 = r2->field_f
    //     0x50b4cc: ldur            w1, [x2, #0xf]
    // 0x50b4d0: DecompressPointer r1
    //     0x50b4d0: add             x1, x1, HEAP, lsl #32
    // 0x50b4d4: cmp             w1, w0
    // 0x50b4d8: b.ne            #0x50b4e0
    // 0x50b4dc: r0 = Null
    //     0x50b4dc: mov             x0, NULL
    // 0x50b4e0: cmp             w0, NULL
    // 0x50b4e4: b.ne            #0x50b4f0
    // 0x50b4e8: r1 = 0
    //     0x50b4e8: movz            x1, #0
    // 0x50b4ec: b               #0x50b4fc
    // 0x50b4f0: r1 = LoadInt32Instr(r0)
    //     0x50b4f0: sbfx            x1, x0, #1, #0x1f
    //     0x50b4f4: tbz             w0, #0, #0x50b4fc
    //     0x50b4f8: ldur            x1, [x0, #7]
    // 0x50b4fc: ldur            x4, [fp, #-0x10]
    // 0x50b500: r0 = 7
    //     0x50b500: movz            x0, #0x7
    // 0x50b504: cmp             x0, x1
    // 0x50b508: csel            x3, x1, x0, lt
    // 0x50b50c: r0 = BoxInt64Instr(r3)
    //     0x50b50c: sbfiz           x0, x3, #1, #0x1f
    //     0x50b510: cmp             x3, x0, asr #1
    //     0x50b514: b.eq            #0x50b520
    //     0x50b518: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x50b51c: stur            x3, [x0, #7]
    // 0x50b520: mov             x1, x2
    // 0x50b524: mov             x3, x0
    // 0x50b528: r2 = 2
    //     0x50b528: movz            x2, #0x2
    // 0x50b52c: r0 = []=()
    //     0x50b52c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50b530: ldur            x0, [fp, #-0x10]
    // 0x50b534: LoadField: r1 = r0->field_f
    //     0x50b534: ldur            w1, [x0, #0xf]
    // 0x50b538: DecompressPointer r1
    //     0x50b538: add             x1, x1, HEAP, lsl #32
    // 0x50b53c: LoadField: r3 = r1->field_43
    //     0x50b53c: ldur            w3, [x1, #0x43]
    // 0x50b540: DecompressPointer r3
    //     0x50b540: add             x3, x3, HEAP, lsl #32
    // 0x50b544: mov             x1, x3
    // 0x50b548: stur            x3, [fp, #-8]
    // 0x50b54c: r2 = 4
    //     0x50b54c: movz            x2, #0x4
    // 0x50b550: r0 = _getValueOrData()
    //     0x50b550: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50b554: ldur            x2, [fp, #-8]
    // 0x50b558: LoadField: r1 = r2->field_f
    //     0x50b558: ldur            w1, [x2, #0xf]
    // 0x50b55c: DecompressPointer r1
    //     0x50b55c: add             x1, x1, HEAP, lsl #32
    // 0x50b560: cmp             w1, w0
    // 0x50b564: b.ne            #0x50b56c
    // 0x50b568: r0 = Null
    //     0x50b568: mov             x0, NULL
    // 0x50b56c: cmp             w0, NULL
    // 0x50b570: b.ne            #0x50b57c
    // 0x50b574: r1 = 0
    //     0x50b574: movz            x1, #0
    // 0x50b578: b               #0x50b588
    // 0x50b57c: r1 = LoadInt32Instr(r0)
    //     0x50b57c: sbfx            x1, x0, #1, #0x1f
    //     0x50b580: tbz             w0, #0, #0x50b588
    //     0x50b584: ldur            x1, [x0, #7]
    // 0x50b588: ldur            x4, [fp, #-0x10]
    // 0x50b58c: r0 = 2
    //     0x50b58c: movz            x0, #0x2
    // 0x50b590: cmp             x0, x1
    // 0x50b594: csel            x3, x1, x0, lt
    // 0x50b598: r0 = BoxInt64Instr(r3)
    //     0x50b598: sbfiz           x0, x3, #1, #0x1f
    //     0x50b59c: cmp             x3, x0, asr #1
    //     0x50b5a0: b.eq            #0x50b5ac
    //     0x50b5a4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x50b5a8: stur            x3, [x0, #7]
    // 0x50b5ac: mov             x1, x2
    // 0x50b5b0: mov             x3, x0
    // 0x50b5b4: r2 = 4
    //     0x50b5b4: movz            x2, #0x4
    // 0x50b5b8: r0 = []=()
    //     0x50b5b8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50b5bc: ldur            x0, [fp, #-0x10]
    // 0x50b5c0: LoadField: r1 = r0->field_f
    //     0x50b5c0: ldur            w1, [x0, #0xf]
    // 0x50b5c4: DecompressPointer r1
    //     0x50b5c4: add             x1, x1, HEAP, lsl #32
    // 0x50b5c8: r0 = resetAndRecomputeBoosts()
    //     0x50b5c8: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x50b5cc: r0 = Null
    //     0x50b5cc: mov             x0, NULL
    // 0x50b5d0: LeaveFrame
    //     0x50b5d0: mov             SP, fp
    //     0x50b5d4: ldp             fp, lr, [SP], #0x10
    // 0x50b5d8: ret
    //     0x50b5d8: ret             
    // 0x50b5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50b5dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50b5e0: b               #0x50b4a8
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50b5e4, size: 0x1f4
    // 0x50b5e4: EnterFrame
    //     0x50b5e4: stp             fp, lr, [SP, #-0x10]!
    //     0x50b5e8: mov             fp, SP
    // 0x50b5ec: AllocStack(0x10)
    //     0x50b5ec: sub             SP, SP, #0x10
    // 0x50b5f0: CheckStackOverflow
    //     0x50b5f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50b5f4: cmp             SP, x16
    //     0x50b5f8: b.ls            #0x50b7c0
    // 0x50b5fc: r1 = Null
    //     0x50b5fc: mov             x1, NULL
    // 0x50b600: r2 = 6
    //     0x50b600: movz            x2, #0x6
    // 0x50b604: r0 = AllocateArray()
    //     0x50b604: bl              #0x82746c  ; AllocateArrayStub
    // 0x50b608: mov             x2, x0
    // 0x50b60c: stur            x2, [fp, #-8]
    // 0x50b610: r16 = "Increases yields of all generators by "
    //     0x50b610: add             x16, PP, #0x14, lsl #12  ; [pp+0x14000] "Increases yields of all generators by "
    //     0x50b614: ldr             x16, [x16]
    // 0x50b618: StoreField: r2->field_f = r16
    //     0x50b618: stur            w16, [x2, #0xf]
    // 0x50b61c: ldr             x0, [fp, #0x10]
    // 0x50b620: r1 = LoadInt32Instr(r0)
    //     0x50b620: sbfx            x1, x0, #1, #0x1f
    //     0x50b624: tbz             w0, #0, #0x50b62c
    //     0x50b628: ldur            x1, [x0, #7]
    // 0x50b62c: add             x3, x1, #1
    // 0x50b630: r0 = BoxInt64Instr(r3)
    //     0x50b630: sbfiz           x0, x3, #1, #0x1f
    //     0x50b634: cmp             x3, x0, asr #1
    //     0x50b638: b.eq            #0x50b644
    //     0x50b63c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x50b640: stur            x3, [x0, #7]
    // 0x50b644: r1 = 60
    //     0x50b644: movz            x1, #0x3c
    // 0x50b648: branchIfSmi(r0, 0x50b654)
    //     0x50b648: tbz             w0, #0, #0x50b654
    // 0x50b64c: r1 = LoadClassIdInstr(r0)
    //     0x50b64c: ldur            x1, [x0, #-1]
    //     0x50b650: ubfx            x1, x1, #0xc, #0x14
    // 0x50b654: str             x0, [SP]
    // 0x50b658: mov             x0, x1
    // 0x50b65c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x50b65c: sub             lr, x0, #1, lsl #12
    //     0x50b660: ldr             lr, [x21, lr, lsl #3]
    //     0x50b664: blr             lr
    // 0x50b668: LoadField: d1 = r0->field_7
    //     0x50b668: ldur            d1, [x0, #7]
    // 0x50b66c: d0 = 1.500000
    //     0x50b66c: fmov            d0, #1.50000000
    // 0x50b670: d30 = 0.000000
    //     0x50b670: fmov            d30, d0
    // 0x50b674: d0 = 1.000000
    //     0x50b674: fmov            d0, #1.00000000
    // 0x50b678: fcmp            d1, #0.0
    // 0x50b67c: b.vs            #0x50b6c0
    // 0x50b680: b.eq            #0x50b748
    // 0x50b684: fcmp            d1, d0
    // 0x50b688: b.eq            #0x50b6b0
    // 0x50b68c: d31 = 2.000000
    //     0x50b68c: fmov            d31, #2.00000000
    // 0x50b690: fcmp            d1, d31
    // 0x50b694: b.eq            #0x50b6b8
    // 0x50b698: d31 = 3.000000
    //     0x50b698: fmov            d31, #3.00000000
    // 0x50b69c: fcmp            d1, d31
    // 0x50b6a0: b.ne            #0x50b6c0
    // 0x50b6a4: fmul            d0, d30, d30
    // 0x50b6a8: fmul            d0, d0, d30
    // 0x50b6ac: b               #0x50b748
    // 0x50b6b0: d0 = 0.000000
    //     0x50b6b0: fmov            d0, d30
    // 0x50b6b4: b               #0x50b748
    // 0x50b6b8: fmul            d0, d30, d30
    // 0x50b6bc: b               #0x50b748
    // 0x50b6c0: fcmp            d30, d0
    // 0x50b6c4: b.vs            #0x50b6d4
    // 0x50b6c8: b.eq            #0x50b748
    // 0x50b6cc: fcmp            d30, d1
    // 0x50b6d0: b.vc            #0x50b6e0
    // 0x50b6d4: d0 = nan
    //     0x50b6d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x50b6d8: ldr             d0, [x17, #0xe48]
    // 0x50b6dc: b               #0x50b748
    // 0x50b6e0: d0 = -inf
    //     0x50b6e0: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x50b6e4: fcmp            d30, d0
    // 0x50b6e8: b.eq            #0x50b710
    // 0x50b6ec: d0 = 0.500000
    //     0x50b6ec: fmov            d0, #0.50000000
    // 0x50b6f0: fcmp            d1, d0
    // 0x50b6f4: b.ne            #0x50b710
    // 0x50b6f8: fcmp            d30, #0.0
    // 0x50b6fc: b.eq            #0x50b708
    // 0x50b700: fsqrt           d0, d30
    // 0x50b704: b               #0x50b748
    // 0x50b708: d0 = 0.000000
    //     0x50b708: eor             v0.16b, v0.16b, v0.16b
    // 0x50b70c: b               #0x50b748
    // 0x50b710: d0 = 0.000000
    //     0x50b710: fmov            d0, d30
    // 0x50b714: stp             fp, lr, [SP, #-0x10]!
    // 0x50b718: mov             fp, SP
    // 0x50b71c: CallRuntime_LibcPow(double, double) -> double
    //     0x50b71c: and             SP, SP, #0xfffffffffffffff0
    //     0x50b720: mov             sp, SP
    //     0x50b724: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x50b728: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x50b72c: blr             x16
    //     0x50b730: movz            x16, #0x8
    //     0x50b734: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x50b738: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x50b73c: sub             sp, x16, #1, lsl #12
    //     0x50b740: mov             SP, fp
    //     0x50b744: ldp             fp, lr, [SP], #0x10
    // 0x50b748: r0 = inline_Allocate_Double()
    //     0x50b748: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x50b74c: add             x0, x0, #0x10
    //     0x50b750: cmp             x1, x0
    //     0x50b754: b.ls            #0x50b7c8
    //     0x50b758: str             x0, [THR, #0x60]  ; THR::top
    //     0x50b75c: sub             x0, x0, #0xf
    //     0x50b760: movz            x1, #0xe19c
    //     0x50b764: movk            x1, #0x3, lsl #16
    //     0x50b768: stur            x1, [x0, #-1]
    // 0x50b76c: dmb             ishst
    // 0x50b770: StoreField: r0->field_7 = d0
    //     0x50b770: stur            d0, [x0, #7]
    // 0x50b774: ldur            x1, [fp, #-8]
    // 0x50b778: ArrayStore: r1[1] = r0  ; List_4
    //     0x50b778: add             x25, x1, #0x13
    //     0x50b77c: str             w0, [x25]
    //     0x50b780: tbz             w0, #0, #0x50b79c
    //     0x50b784: ldurb           w16, [x1, #-1]
    //     0x50b788: ldurb           w17, [x0, #-1]
    //     0x50b78c: and             x16, x17, x16, lsr #2
    //     0x50b790: tst             x16, HEAP, lsr #32
    //     0x50b794: b.eq            #0x50b79c
    //     0x50b798: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x50b79c: ldur            x0, [fp, #-8]
    // 0x50b7a0: r16 = "×."
    //     0x50b7a0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14008] "×."
    //     0x50b7a4: ldr             x16, [x16, #8]
    // 0x50b7a8: ArrayStore: r0[0] = r16  ; List_4
    //     0x50b7a8: stur            w16, [x0, #0x17]
    // 0x50b7ac: str             x0, [SP]
    // 0x50b7b0: r0 = _interpolate()
    //     0x50b7b0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x50b7b4: LeaveFrame
    //     0x50b7b4: mov             SP, fp
    //     0x50b7b8: ldp             fp, lr, [SP], #0x10
    // 0x50b7bc: ret
    //     0x50b7bc: ret             
    // 0x50b7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50b7c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50b7c4: b               #0x50b5fc
    // 0x50b7c8: SaveReg d0
    //     0x50b7c8: str             q0, [SP, #-0x10]!
    // 0x50b7cc: r0 = AllocateDouble()
    //     0x50b7cc: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x50b7d0: RestoreReg d0
    //     0x50b7d0: ldr             q0, [SP], #0x10
    // 0x50b7d4: b               #0x50b770
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50b7d8, size: 0x88
    // 0x50b7d8: EnterFrame
    //     0x50b7d8: stp             fp, lr, [SP, #-0x10]!
    //     0x50b7dc: mov             fp, SP
    // 0x50b7e0: AllocStack(0x8)
    //     0x50b7e0: sub             SP, SP, #8
    // 0x50b7e4: CheckStackOverflow
    //     0x50b7e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50b7e8: cmp             SP, x16
    //     0x50b7ec: b.ls            #0x50b858
    // 0x50b7f0: r1 = Null
    //     0x50b7f0: mov             x1, NULL
    // 0x50b7f4: r2 = 6
    //     0x50b7f4: movz            x2, #0x6
    // 0x50b7f8: r0 = AllocateArray()
    //     0x50b7f8: bl              #0x82746c  ; AllocateArrayStub
    // 0x50b7fc: mov             x2, x0
    // 0x50b800: r16 = "Increase rate of all generators by "
    //     0x50b800: add             x16, PP, #0x14, lsl #12  ; [pp+0x14010] "Increase rate of all generators by "
    //     0x50b804: ldr             x16, [x16, #0x10]
    // 0x50b808: StoreField: r2->field_f = r16
    //     0x50b808: stur            w16, [x2, #0xf]
    // 0x50b80c: ldr             x0, [fp, #0x10]
    // 0x50b810: r1 = LoadInt32Instr(r0)
    //     0x50b810: sbfx            x1, x0, #1, #0x1f
    //     0x50b814: tbz             w0, #0, #0x50b81c
    //     0x50b818: ldur            x1, [x0, #7]
    // 0x50b81c: add             x3, x1, #1
    // 0x50b820: r0 = BoxInt64Instr(r3)
    //     0x50b820: sbfiz           x0, x3, #1, #0x1f
    //     0x50b824: cmp             x3, x0, asr #1
    //     0x50b828: b.eq            #0x50b834
    //     0x50b82c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x50b830: stur            x3, [x0, #7]
    // 0x50b834: StoreField: r2->field_13 = r0
    //     0x50b834: stur            w0, [x2, #0x13]
    // 0x50b838: r16 = "% per owned generator."
    //     0x50b838: add             x16, PP, #0x14, lsl #12  ; [pp+0x14018] "% per owned generator."
    //     0x50b83c: ldr             x16, [x16, #0x18]
    // 0x50b840: ArrayStore: r2[0] = r16  ; List_4
    //     0x50b840: stur            w16, [x2, #0x17]
    // 0x50b844: str             x2, [SP]
    // 0x50b848: r0 = _interpolate()
    //     0x50b848: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x50b84c: LeaveFrame
    //     0x50b84c: mov             SP, fp
    //     0x50b850: ldp             fp, lr, [SP], #0x10
    // 0x50b854: ret
    //     0x50b854: ret             
    // 0x50b858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50b858: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50b85c: b               #0x50b7f0
  }
  [closure] void applyAuctionBonus(dynamic) {
    // ** addr: 0x50b860, size: 0x38
    // 0x50b860: EnterFrame
    //     0x50b860: stp             fp, lr, [SP, #-0x10]!
    //     0x50b864: mov             fp, SP
    // 0x50b868: ldr             x0, [fp, #0x10]
    // 0x50b86c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x50b86c: ldur            w1, [x0, #0x17]
    // 0x50b870: DecompressPointer r1
    //     0x50b870: add             x1, x1, HEAP, lsl #32
    // 0x50b874: CheckStackOverflow
    //     0x50b874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50b878: cmp             SP, x16
    //     0x50b87c: b.ls            #0x50b890
    // 0x50b880: r0 = applyAuctionBonus()
    //     0x50b880: bl              #0x50b898  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::applyAuctionBonus
    // 0x50b884: LeaveFrame
    //     0x50b884: mov             SP, fp
    //     0x50b888: ldp             fp, lr, [SP], #0x10
    // 0x50b88c: ret
    //     0x50b88c: ret             
    // 0x50b890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50b890: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50b894: b               #0x50b880
  }
  _ applyAuctionBonus(/* No info */) {
    // ** addr: 0x50b898, size: 0x570
    // 0x50b898: EnterFrame
    //     0x50b898: stp             fp, lr, [SP, #-0x10]!
    //     0x50b89c: mov             fp, SP
    // 0x50b8a0: AllocStack(0x20)
    //     0x50b8a0: sub             SP, SP, #0x20
    // 0x50b8a4: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x10 */)
    //     0x50b8a4: mov             x0, x1
    //     0x50b8a8: stur            x1, [fp, #-0x10]
    // 0x50b8ac: CheckStackOverflow
    //     0x50b8ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50b8b0: cmp             SP, x16
    //     0x50b8b4: b.ls            #0x50be00
    // 0x50b8b8: LoadField: r3 = r0->field_43
    //     0x50b8b8: ldur            w3, [x0, #0x43]
    // 0x50b8bc: DecompressPointer r3
    //     0x50b8bc: add             x3, x3, HEAP, lsl #32
    // 0x50b8c0: mov             x1, x3
    // 0x50b8c4: stur            x3, [fp, #-8]
    // 0x50b8c8: r2 = 4
    //     0x50b8c8: movz            x2, #0x4
    // 0x50b8cc: r0 = _getValueOrData()
    //     0x50b8cc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50b8d0: mov             x1, x0
    // 0x50b8d4: ldur            x0, [fp, #-8]
    // 0x50b8d8: LoadField: r2 = r0->field_f
    //     0x50b8d8: ldur            w2, [x0, #0xf]
    // 0x50b8dc: DecompressPointer r2
    //     0x50b8dc: add             x2, x2, HEAP, lsl #32
    // 0x50b8e0: cmp             w2, w1
    // 0x50b8e4: b.ne            #0x50b8f0
    // 0x50b8e8: r0 = Null
    //     0x50b8e8: mov             x0, NULL
    // 0x50b8ec: b               #0x50b8f4
    // 0x50b8f0: mov             x0, x1
    // 0x50b8f4: cmp             w0, NULL
    // 0x50b8f8: b.ne            #0x50b904
    // 0x50b8fc: r0 = 0
    //     0x50b8fc: movz            x0, #0
    // 0x50b900: b               #0x50b914
    // 0x50b904: r1 = LoadInt32Instr(r0)
    //     0x50b904: sbfx            x1, x0, #1, #0x1f
    //     0x50b908: tbz             w0, #0, #0x50b910
    //     0x50b90c: ldur            x1, [x0, #7]
    // 0x50b910: mov             x0, x1
    // 0x50b914: ldur            x3, [fp, #-0x10]
    // 0x50b918: r16 = 50
    //     0x50b918: movz            x16, #0x32
    // 0x50b91c: mul             x2, x0, x16
    // 0x50b920: r0 = BoxInt64Instr(r2)
    //     0x50b920: sbfiz           x0, x2, #1, #0x1f
    //     0x50b924: cmp             x2, x0, asr #1
    //     0x50b928: b.eq            #0x50b934
    //     0x50b92c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x50b930: stur            x2, [x0, #7]
    // 0x50b934: mov             x2, x0
    // 0x50b938: r1 = Null
    //     0x50b938: mov             x1, NULL
    // 0x50b93c: r0 = CustomNum()
    //     0x50b93c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x50b940: mov             x3, x0
    // 0x50b944: ldur            x0, [fp, #-0x10]
    // 0x50b948: stur            x3, [fp, #-0x18]
    // 0x50b94c: LoadField: r4 = r0->field_37
    //     0x50b94c: ldur            w4, [x0, #0x37]
    // 0x50b950: DecompressPointer r4
    //     0x50b950: add             x4, x4, HEAP, lsl #32
    // 0x50b954: mov             x1, x4
    // 0x50b958: stur            x4, [fp, #-8]
    // 0x50b95c: r2 = Instance_Chapter9Stat
    //     0x50b95c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11820] Obj!Chapter9Stat@85f101
    //     0x50b960: ldr             x2, [x2, #0x820]
    // 0x50b964: r0 = _getValueOrData()
    //     0x50b964: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50b968: mov             x1, x0
    // 0x50b96c: ldur            x0, [fp, #-8]
    // 0x50b970: LoadField: r2 = r0->field_f
    //     0x50b970: ldur            w2, [x0, #0xf]
    // 0x50b974: DecompressPointer r2
    //     0x50b974: add             x2, x2, HEAP, lsl #32
    // 0x50b978: cmp             w2, w1
    // 0x50b97c: b.ne            #0x50b988
    // 0x50b980: r0 = Null
    //     0x50b980: mov             x0, NULL
    // 0x50b984: b               #0x50b98c
    // 0x50b988: mov             x0, x1
    // 0x50b98c: cmp             w0, NULL
    // 0x50b990: b.ne            #0x50b9a0
    // 0x50b994: r1 = Instance_CustomNum
    //     0x50b994: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50b998: ldr             x1, [x1, #0xaf8]
    // 0x50b99c: b               #0x50b9a4
    // 0x50b9a0: mov             x1, x0
    // 0x50b9a4: ldur            x0, [fp, #-0x18]
    // 0x50b9a8: LoadField: d0 = r0->field_7
    //     0x50b9a8: ldur            d0, [x0, #7]
    // 0x50b9ac: stur            d0, [fp, #-0x20]
    // 0x50b9b0: LoadField: d1 = r1->field_7
    //     0x50b9b0: ldur            d1, [x1, #7]
    // 0x50b9b4: fcmp            d0, d1
    // 0x50b9b8: b.le            #0x50b9d8
    // 0x50b9bc: ldur            x4, [fp, #-0x10]
    // 0x50b9c0: LoadField: r1 = r4->field_37
    //     0x50b9c0: ldur            w1, [x4, #0x37]
    // 0x50b9c4: DecompressPointer r1
    //     0x50b9c4: add             x1, x1, HEAP, lsl #32
    // 0x50b9c8: mov             x3, x0
    // 0x50b9cc: r2 = Instance_Chapter9Stat
    //     0x50b9cc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11820] Obj!Chapter9Stat@85f101
    //     0x50b9d0: ldr             x2, [x2, #0x820]
    // 0x50b9d4: r0 = []=()
    //     0x50b9d4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50b9d8: ldur            x0, [fp, #-0x10]
    // 0x50b9dc: LoadField: r3 = r0->field_37
    //     0x50b9dc: ldur            w3, [x0, #0x37]
    // 0x50b9e0: DecompressPointer r3
    //     0x50b9e0: add             x3, x3, HEAP, lsl #32
    // 0x50b9e4: mov             x1, x3
    // 0x50b9e8: stur            x3, [fp, #-8]
    // 0x50b9ec: r2 = Instance_Chapter9Stat
    //     0x50b9ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11828] Obj!Chapter9Stat@85f0e1
    //     0x50b9f0: ldr             x2, [x2, #0x828]
    // 0x50b9f4: r0 = _getValueOrData()
    //     0x50b9f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50b9f8: mov             x1, x0
    // 0x50b9fc: ldur            x0, [fp, #-8]
    // 0x50ba00: LoadField: r2 = r0->field_f
    //     0x50ba00: ldur            w2, [x0, #0xf]
    // 0x50ba04: DecompressPointer r2
    //     0x50ba04: add             x2, x2, HEAP, lsl #32
    // 0x50ba08: cmp             w2, w1
    // 0x50ba0c: b.ne            #0x50ba18
    // 0x50ba10: r0 = Null
    //     0x50ba10: mov             x0, NULL
    // 0x50ba14: b               #0x50ba1c
    // 0x50ba18: mov             x0, x1
    // 0x50ba1c: cmp             w0, NULL
    // 0x50ba20: b.ne            #0x50ba2c
    // 0x50ba24: r0 = Instance_CustomNum
    //     0x50ba24: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50ba28: ldr             x0, [x0, #0xaf8]
    // 0x50ba2c: ldur            d0, [fp, #-0x20]
    // 0x50ba30: LoadField: d1 = r0->field_7
    //     0x50ba30: ldur            d1, [x0, #7]
    // 0x50ba34: fcmp            d0, d1
    // 0x50ba38: b.le            #0x50ba58
    // 0x50ba3c: ldur            x0, [fp, #-0x10]
    // 0x50ba40: LoadField: r1 = r0->field_37
    //     0x50ba40: ldur            w1, [x0, #0x37]
    // 0x50ba44: DecompressPointer r1
    //     0x50ba44: add             x1, x1, HEAP, lsl #32
    // 0x50ba48: ldur            x3, [fp, #-0x18]
    // 0x50ba4c: r2 = Instance_Chapter9Stat
    //     0x50ba4c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11828] Obj!Chapter9Stat@85f0e1
    //     0x50ba50: ldr             x2, [x2, #0x828]
    // 0x50ba54: r0 = []=()
    //     0x50ba54: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50ba58: ldur            x0, [fp, #-0x10]
    // 0x50ba5c: LoadField: r3 = r0->field_37
    //     0x50ba5c: ldur            w3, [x0, #0x37]
    // 0x50ba60: DecompressPointer r3
    //     0x50ba60: add             x3, x3, HEAP, lsl #32
    // 0x50ba64: mov             x1, x3
    // 0x50ba68: stur            x3, [fp, #-8]
    // 0x50ba6c: r2 = Instance_Chapter9Stat
    //     0x50ba6c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11830] Obj!Chapter9Stat@85f0c1
    //     0x50ba70: ldr             x2, [x2, #0x830]
    // 0x50ba74: r0 = _getValueOrData()
    //     0x50ba74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50ba78: mov             x1, x0
    // 0x50ba7c: ldur            x0, [fp, #-8]
    // 0x50ba80: LoadField: r2 = r0->field_f
    //     0x50ba80: ldur            w2, [x0, #0xf]
    // 0x50ba84: DecompressPointer r2
    //     0x50ba84: add             x2, x2, HEAP, lsl #32
    // 0x50ba88: cmp             w2, w1
    // 0x50ba8c: b.ne            #0x50ba98
    // 0x50ba90: r0 = Null
    //     0x50ba90: mov             x0, NULL
    // 0x50ba94: b               #0x50ba9c
    // 0x50ba98: mov             x0, x1
    // 0x50ba9c: cmp             w0, NULL
    // 0x50baa0: b.ne            #0x50baac
    // 0x50baa4: r0 = Instance_CustomNum
    //     0x50baa4: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50baa8: ldr             x0, [x0, #0xaf8]
    // 0x50baac: ldur            d0, [fp, #-0x20]
    // 0x50bab0: LoadField: d1 = r0->field_7
    //     0x50bab0: ldur            d1, [x0, #7]
    // 0x50bab4: fcmp            d0, d1
    // 0x50bab8: b.le            #0x50bad8
    // 0x50babc: ldur            x0, [fp, #-0x10]
    // 0x50bac0: LoadField: r1 = r0->field_37
    //     0x50bac0: ldur            w1, [x0, #0x37]
    // 0x50bac4: DecompressPointer r1
    //     0x50bac4: add             x1, x1, HEAP, lsl #32
    // 0x50bac8: ldur            x3, [fp, #-0x18]
    // 0x50bacc: r2 = Instance_Chapter9Stat
    //     0x50bacc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11830] Obj!Chapter9Stat@85f0c1
    //     0x50bad0: ldr             x2, [x2, #0x830]
    // 0x50bad4: r0 = []=()
    //     0x50bad4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bad8: ldur            x0, [fp, #-0x10]
    // 0x50badc: LoadField: r3 = r0->field_37
    //     0x50badc: ldur            w3, [x0, #0x37]
    // 0x50bae0: DecompressPointer r3
    //     0x50bae0: add             x3, x3, HEAP, lsl #32
    // 0x50bae4: mov             x1, x3
    // 0x50bae8: stur            x3, [fp, #-8]
    // 0x50baec: r2 = Instance_Chapter9Stat
    //     0x50baec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11838] Obj!Chapter9Stat@85f0a1
    //     0x50baf0: ldr             x2, [x2, #0x838]
    // 0x50baf4: r0 = _getValueOrData()
    //     0x50baf4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50baf8: mov             x1, x0
    // 0x50bafc: ldur            x0, [fp, #-8]
    // 0x50bb00: LoadField: r2 = r0->field_f
    //     0x50bb00: ldur            w2, [x0, #0xf]
    // 0x50bb04: DecompressPointer r2
    //     0x50bb04: add             x2, x2, HEAP, lsl #32
    // 0x50bb08: cmp             w2, w1
    // 0x50bb0c: b.ne            #0x50bb18
    // 0x50bb10: r0 = Null
    //     0x50bb10: mov             x0, NULL
    // 0x50bb14: b               #0x50bb1c
    // 0x50bb18: mov             x0, x1
    // 0x50bb1c: cmp             w0, NULL
    // 0x50bb20: b.ne            #0x50bb2c
    // 0x50bb24: r0 = Instance_CustomNum
    //     0x50bb24: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50bb28: ldr             x0, [x0, #0xaf8]
    // 0x50bb2c: ldur            d0, [fp, #-0x20]
    // 0x50bb30: LoadField: d1 = r0->field_7
    //     0x50bb30: ldur            d1, [x0, #7]
    // 0x50bb34: fcmp            d0, d1
    // 0x50bb38: b.le            #0x50bb58
    // 0x50bb3c: ldur            x0, [fp, #-0x10]
    // 0x50bb40: LoadField: r1 = r0->field_37
    //     0x50bb40: ldur            w1, [x0, #0x37]
    // 0x50bb44: DecompressPointer r1
    //     0x50bb44: add             x1, x1, HEAP, lsl #32
    // 0x50bb48: ldur            x3, [fp, #-0x18]
    // 0x50bb4c: r2 = Instance_Chapter9Stat
    //     0x50bb4c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11838] Obj!Chapter9Stat@85f0a1
    //     0x50bb50: ldr             x2, [x2, #0x838]
    // 0x50bb54: r0 = []=()
    //     0x50bb54: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bb58: ldur            x0, [fp, #-0x10]
    // 0x50bb5c: LoadField: r3 = r0->field_37
    //     0x50bb5c: ldur            w3, [x0, #0x37]
    // 0x50bb60: DecompressPointer r3
    //     0x50bb60: add             x3, x3, HEAP, lsl #32
    // 0x50bb64: mov             x1, x3
    // 0x50bb68: stur            x3, [fp, #-8]
    // 0x50bb6c: r2 = Instance_Chapter9Stat
    //     0x50bb6c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11840] Obj!Chapter9Stat@85f081
    //     0x50bb70: ldr             x2, [x2, #0x840]
    // 0x50bb74: r0 = _getValueOrData()
    //     0x50bb74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50bb78: mov             x1, x0
    // 0x50bb7c: ldur            x0, [fp, #-8]
    // 0x50bb80: LoadField: r2 = r0->field_f
    //     0x50bb80: ldur            w2, [x0, #0xf]
    // 0x50bb84: DecompressPointer r2
    //     0x50bb84: add             x2, x2, HEAP, lsl #32
    // 0x50bb88: cmp             w2, w1
    // 0x50bb8c: b.ne            #0x50bb98
    // 0x50bb90: r0 = Null
    //     0x50bb90: mov             x0, NULL
    // 0x50bb94: b               #0x50bb9c
    // 0x50bb98: mov             x0, x1
    // 0x50bb9c: cmp             w0, NULL
    // 0x50bba0: b.ne            #0x50bbac
    // 0x50bba4: r0 = Instance_CustomNum
    //     0x50bba4: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50bba8: ldr             x0, [x0, #0xaf8]
    // 0x50bbac: ldur            d0, [fp, #-0x20]
    // 0x50bbb0: LoadField: d1 = r0->field_7
    //     0x50bbb0: ldur            d1, [x0, #7]
    // 0x50bbb4: fcmp            d0, d1
    // 0x50bbb8: b.le            #0x50bbd8
    // 0x50bbbc: ldur            x0, [fp, #-0x10]
    // 0x50bbc0: LoadField: r1 = r0->field_37
    //     0x50bbc0: ldur            w1, [x0, #0x37]
    // 0x50bbc4: DecompressPointer r1
    //     0x50bbc4: add             x1, x1, HEAP, lsl #32
    // 0x50bbc8: ldur            x3, [fp, #-0x18]
    // 0x50bbcc: r2 = Instance_Chapter9Stat
    //     0x50bbcc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11840] Obj!Chapter9Stat@85f081
    //     0x50bbd0: ldr             x2, [x2, #0x840]
    // 0x50bbd4: r0 = []=()
    //     0x50bbd4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bbd8: ldur            x0, [fp, #-0x10]
    // 0x50bbdc: LoadField: r1 = r0->field_43
    //     0x50bbdc: ldur            w1, [x0, #0x43]
    // 0x50bbe0: DecompressPointer r1
    //     0x50bbe0: add             x1, x1, HEAP, lsl #32
    // 0x50bbe4: r2 = 44
    //     0x50bbe4: movz            x2, #0x2c
    // 0x50bbe8: r0 = containsKey()
    //     0x50bbe8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x50bbec: tbnz            w0, #4, #0x50bdf0
    // 0x50bbf0: ldur            x0, [fp, #-0x10]
    // 0x50bbf4: LoadField: r3 = r0->field_37
    //     0x50bbf4: ldur            w3, [x0, #0x37]
    // 0x50bbf8: DecompressPointer r3
    //     0x50bbf8: add             x3, x3, HEAP, lsl #32
    // 0x50bbfc: mov             x1, x3
    // 0x50bc00: stur            x3, [fp, #-8]
    // 0x50bc04: r2 = Instance_Chapter9Stat
    //     0x50bc04: add             x2, PP, #0x11, lsl #12  ; [pp+0x11848] Obj!Chapter9Stat@85f061
    //     0x50bc08: ldr             x2, [x2, #0x848]
    // 0x50bc0c: r0 = _getValueOrData()
    //     0x50bc0c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50bc10: mov             x1, x0
    // 0x50bc14: ldur            x0, [fp, #-8]
    // 0x50bc18: LoadField: r2 = r0->field_f
    //     0x50bc18: ldur            w2, [x0, #0xf]
    // 0x50bc1c: DecompressPointer r2
    //     0x50bc1c: add             x2, x2, HEAP, lsl #32
    // 0x50bc20: cmp             w2, w1
    // 0x50bc24: b.ne            #0x50bc30
    // 0x50bc28: r0 = Null
    //     0x50bc28: mov             x0, NULL
    // 0x50bc2c: b               #0x50bc34
    // 0x50bc30: mov             x0, x1
    // 0x50bc34: cmp             w0, NULL
    // 0x50bc38: b.ne            #0x50bc44
    // 0x50bc3c: r0 = Instance_CustomNum
    //     0x50bc3c: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50bc40: ldr             x0, [x0, #0xaf8]
    // 0x50bc44: ldur            d0, [fp, #-0x20]
    // 0x50bc48: LoadField: d1 = r0->field_7
    //     0x50bc48: ldur            d1, [x0, #7]
    // 0x50bc4c: fcmp            d0, d1
    // 0x50bc50: b.le            #0x50bc70
    // 0x50bc54: ldur            x0, [fp, #-0x10]
    // 0x50bc58: LoadField: r1 = r0->field_37
    //     0x50bc58: ldur            w1, [x0, #0x37]
    // 0x50bc5c: DecompressPointer r1
    //     0x50bc5c: add             x1, x1, HEAP, lsl #32
    // 0x50bc60: ldur            x3, [fp, #-0x18]
    // 0x50bc64: r2 = Instance_Chapter9Stat
    //     0x50bc64: add             x2, PP, #0x11, lsl #12  ; [pp+0x11848] Obj!Chapter9Stat@85f061
    //     0x50bc68: ldr             x2, [x2, #0x848]
    // 0x50bc6c: r0 = []=()
    //     0x50bc6c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bc70: ldur            x0, [fp, #-0x10]
    // 0x50bc74: LoadField: r3 = r0->field_37
    //     0x50bc74: ldur            w3, [x0, #0x37]
    // 0x50bc78: DecompressPointer r3
    //     0x50bc78: add             x3, x3, HEAP, lsl #32
    // 0x50bc7c: mov             x1, x3
    // 0x50bc80: stur            x3, [fp, #-8]
    // 0x50bc84: r2 = Instance_Chapter9Stat
    //     0x50bc84: add             x2, PP, #0x11, lsl #12  ; [pp+0x11850] Obj!Chapter9Stat@85f041
    //     0x50bc88: ldr             x2, [x2, #0x850]
    // 0x50bc8c: r0 = _getValueOrData()
    //     0x50bc8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50bc90: mov             x1, x0
    // 0x50bc94: ldur            x0, [fp, #-8]
    // 0x50bc98: LoadField: r2 = r0->field_f
    //     0x50bc98: ldur            w2, [x0, #0xf]
    // 0x50bc9c: DecompressPointer r2
    //     0x50bc9c: add             x2, x2, HEAP, lsl #32
    // 0x50bca0: cmp             w2, w1
    // 0x50bca4: b.ne            #0x50bcb0
    // 0x50bca8: r0 = Null
    //     0x50bca8: mov             x0, NULL
    // 0x50bcac: b               #0x50bcb4
    // 0x50bcb0: mov             x0, x1
    // 0x50bcb4: cmp             w0, NULL
    // 0x50bcb8: b.ne            #0x50bcc4
    // 0x50bcbc: r0 = Instance_CustomNum
    //     0x50bcbc: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50bcc0: ldr             x0, [x0, #0xaf8]
    // 0x50bcc4: ldur            d0, [fp, #-0x20]
    // 0x50bcc8: LoadField: d1 = r0->field_7
    //     0x50bcc8: ldur            d1, [x0, #7]
    // 0x50bccc: fcmp            d0, d1
    // 0x50bcd0: b.le            #0x50bcf0
    // 0x50bcd4: ldur            x0, [fp, #-0x10]
    // 0x50bcd8: LoadField: r1 = r0->field_37
    //     0x50bcd8: ldur            w1, [x0, #0x37]
    // 0x50bcdc: DecompressPointer r1
    //     0x50bcdc: add             x1, x1, HEAP, lsl #32
    // 0x50bce0: ldur            x3, [fp, #-0x18]
    // 0x50bce4: r2 = Instance_Chapter9Stat
    //     0x50bce4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11850] Obj!Chapter9Stat@85f041
    //     0x50bce8: ldr             x2, [x2, #0x850]
    // 0x50bcec: r0 = []=()
    //     0x50bcec: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bcf0: ldur            x0, [fp, #-0x10]
    // 0x50bcf4: LoadField: r3 = r0->field_37
    //     0x50bcf4: ldur            w3, [x0, #0x37]
    // 0x50bcf8: DecompressPointer r3
    //     0x50bcf8: add             x3, x3, HEAP, lsl #32
    // 0x50bcfc: mov             x1, x3
    // 0x50bd00: stur            x3, [fp, #-8]
    // 0x50bd04: r2 = Instance_Chapter9Stat
    //     0x50bd04: add             x2, PP, #0x11, lsl #12  ; [pp+0x11858] Obj!Chapter9Stat@85f021
    //     0x50bd08: ldr             x2, [x2, #0x858]
    // 0x50bd0c: r0 = _getValueOrData()
    //     0x50bd0c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50bd10: mov             x1, x0
    // 0x50bd14: ldur            x0, [fp, #-8]
    // 0x50bd18: LoadField: r2 = r0->field_f
    //     0x50bd18: ldur            w2, [x0, #0xf]
    // 0x50bd1c: DecompressPointer r2
    //     0x50bd1c: add             x2, x2, HEAP, lsl #32
    // 0x50bd20: cmp             w2, w1
    // 0x50bd24: b.ne            #0x50bd30
    // 0x50bd28: r0 = Null
    //     0x50bd28: mov             x0, NULL
    // 0x50bd2c: b               #0x50bd34
    // 0x50bd30: mov             x0, x1
    // 0x50bd34: cmp             w0, NULL
    // 0x50bd38: b.ne            #0x50bd44
    // 0x50bd3c: r0 = Instance_CustomNum
    //     0x50bd3c: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50bd40: ldr             x0, [x0, #0xaf8]
    // 0x50bd44: ldur            d0, [fp, #-0x20]
    // 0x50bd48: LoadField: d1 = r0->field_7
    //     0x50bd48: ldur            d1, [x0, #7]
    // 0x50bd4c: fcmp            d0, d1
    // 0x50bd50: b.le            #0x50bd70
    // 0x50bd54: ldur            x0, [fp, #-0x10]
    // 0x50bd58: LoadField: r1 = r0->field_37
    //     0x50bd58: ldur            w1, [x0, #0x37]
    // 0x50bd5c: DecompressPointer r1
    //     0x50bd5c: add             x1, x1, HEAP, lsl #32
    // 0x50bd60: ldur            x3, [fp, #-0x18]
    // 0x50bd64: r2 = Instance_Chapter9Stat
    //     0x50bd64: add             x2, PP, #0x11, lsl #12  ; [pp+0x11858] Obj!Chapter9Stat@85f021
    //     0x50bd68: ldr             x2, [x2, #0x858]
    // 0x50bd6c: r0 = []=()
    //     0x50bd6c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bd70: ldur            x0, [fp, #-0x10]
    // 0x50bd74: LoadField: r3 = r0->field_37
    //     0x50bd74: ldur            w3, [x0, #0x37]
    // 0x50bd78: DecompressPointer r3
    //     0x50bd78: add             x3, x3, HEAP, lsl #32
    // 0x50bd7c: mov             x1, x3
    // 0x50bd80: stur            x3, [fp, #-8]
    // 0x50bd84: r2 = Instance_Chapter9Stat
    //     0x50bd84: add             x2, PP, #0x11, lsl #12  ; [pp+0x11860] Obj!Chapter9Stat@85f001
    //     0x50bd88: ldr             x2, [x2, #0x860]
    // 0x50bd8c: r0 = _getValueOrData()
    //     0x50bd8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50bd90: mov             x1, x0
    // 0x50bd94: ldur            x0, [fp, #-8]
    // 0x50bd98: LoadField: r2 = r0->field_f
    //     0x50bd98: ldur            w2, [x0, #0xf]
    // 0x50bd9c: DecompressPointer r2
    //     0x50bd9c: add             x2, x2, HEAP, lsl #32
    // 0x50bda0: cmp             w2, w1
    // 0x50bda4: b.ne            #0x50bdb0
    // 0x50bda8: r0 = Null
    //     0x50bda8: mov             x0, NULL
    // 0x50bdac: b               #0x50bdb4
    // 0x50bdb0: mov             x0, x1
    // 0x50bdb4: cmp             w0, NULL
    // 0x50bdb8: b.ne            #0x50bdc4
    // 0x50bdbc: r0 = Instance_CustomNum
    //     0x50bdbc: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x50bdc0: ldr             x0, [x0, #0xaf8]
    // 0x50bdc4: ldur            d0, [fp, #-0x20]
    // 0x50bdc8: LoadField: d1 = r0->field_7
    //     0x50bdc8: ldur            d1, [x0, #7]
    // 0x50bdcc: fcmp            d0, d1
    // 0x50bdd0: b.le            #0x50bdf0
    // 0x50bdd4: ldur            x0, [fp, #-0x10]
    // 0x50bdd8: LoadField: r1 = r0->field_37
    //     0x50bdd8: ldur            w1, [x0, #0x37]
    // 0x50bddc: DecompressPointer r1
    //     0x50bddc: add             x1, x1, HEAP, lsl #32
    // 0x50bde0: ldur            x3, [fp, #-0x18]
    // 0x50bde4: r2 = Instance_Chapter9Stat
    //     0x50bde4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11860] Obj!Chapter9Stat@85f001
    //     0x50bde8: ldr             x2, [x2, #0x860]
    // 0x50bdec: r0 = []=()
    //     0x50bdec: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x50bdf0: r0 = Null
    //     0x50bdf0: mov             x0, NULL
    // 0x50bdf4: LeaveFrame
    //     0x50bdf4: mov             SP, fp
    //     0x50bdf8: ldp             fp, lr, [SP], #0x10
    // 0x50bdfc: ret
    //     0x50bdfc: ret             
    // 0x50be00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50be00: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50be04: b               #0x50b8b8
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50be08, size: 0x90
    // 0x50be08: EnterFrame
    //     0x50be08: stp             fp, lr, [SP, #-0x10]!
    //     0x50be0c: mov             fp, SP
    // 0x50be10: AllocStack(0x8)
    //     0x50be10: sub             SP, SP, #8
    // 0x50be14: CheckStackOverflow
    //     0x50be14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50be18: cmp             SP, x16
    //     0x50be1c: b.ls            #0x50be90
    // 0x50be20: r1 = Null
    //     0x50be20: mov             x1, NULL
    // 0x50be24: r2 = 6
    //     0x50be24: movz            x2, #0x6
    // 0x50be28: r0 = AllocateArray()
    //     0x50be28: bl              #0x82746c  ; AllocateArrayStub
    // 0x50be2c: mov             x2, x0
    // 0x50be30: r16 = "Awards "
    //     0x50be30: add             x16, PP, #0x14, lsl #12  ; [pp+0x14020] "Awards "
    //     0x50be34: ldr             x16, [x16, #0x20]
    // 0x50be38: StoreField: r2->field_f = r16
    //     0x50be38: stur            w16, [x2, #0xf]
    // 0x50be3c: ldr             x0, [fp, #0x10]
    // 0x50be40: r1 = LoadInt32Instr(r0)
    //     0x50be40: sbfx            x1, x0, #1, #0x1f
    //     0x50be44: tbz             w0, #0, #0x50be4c
    //     0x50be48: ldur            x1, [x0, #7]
    // 0x50be4c: add             x0, x1, #1
    // 0x50be50: r16 = 50
    //     0x50be50: movz            x16, #0x32
    // 0x50be54: mul             x3, x0, x16
    // 0x50be58: r0 = BoxInt64Instr(r3)
    //     0x50be58: sbfiz           x0, x3, #1, #0x1f
    //     0x50be5c: cmp             x3, x0, asr #1
    //     0x50be60: b.eq            #0x50be6c
    //     0x50be64: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x50be68: stur            x3, [x0, #7]
    // 0x50be6c: StoreField: r2->field_13 = r0
    //     0x50be6c: stur            w0, [x2, #0x13]
    // 0x50be70: r16 = " bonus generators to tier 1 generators."
    //     0x50be70: add             x16, PP, #0x14, lsl #12  ; [pp+0x14028] " bonus generators to tier 1 generators."
    //     0x50be74: ldr             x16, [x16, #0x28]
    // 0x50be78: ArrayStore: r2[0] = r16  ; List_4
    //     0x50be78: stur            w16, [x2, #0x17]
    // 0x50be7c: str             x2, [SP]
    // 0x50be80: r0 = _interpolate()
    //     0x50be80: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x50be84: LeaveFrame
    //     0x50be84: mov             SP, fp
    //     0x50be88: ldp             fp, lr, [SP], #0x10
    // 0x50be8c: ret
    //     0x50be8c: ret             
    // 0x50be90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50be90: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50be94: b               #0x50be20
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x50be98, size: 0xc
    // 0x50be98: r0 = "Decreases all generator costs by 99%."
    //     0x50be98: add             x0, PP, #0x14, lsl #12  ; [pp+0x14030] "Decreases all generator costs by 99%."
    //     0x50be9c: ldr             x0, [x0, #0x30]
    // 0x50bea0: ret
    //     0x50bea0: ret             
  }
  _ postUpdateCallback(/* No info */) {
    // ** addr: 0x54cb80, size: 0x550
    // 0x54cb80: EnterFrame
    //     0x54cb80: stp             fp, lr, [SP, #-0x10]!
    //     0x54cb84: mov             fp, SP
    // 0x54cb88: AllocStack(0x40)
    //     0x54cb88: sub             SP, SP, #0x40
    // 0x54cb8c: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x8 */)
    //     0x54cb8c: mov             x0, x1
    //     0x54cb90: stur            x1, [fp, #-8]
    // 0x54cb94: CheckStackOverflow
    //     0x54cb94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54cb98: cmp             SP, x16
    //     0x54cb9c: b.ls            #0x54d0a8
    // 0x54cba0: LoadField: r1 = r0->field_43
    //     0x54cba0: ldur            w1, [x0, #0x43]
    // 0x54cba4: DecompressPointer r1
    //     0x54cba4: add             x1, x1, HEAP, lsl #32
    // 0x54cba8: r2 = 46
    //     0x54cba8: movz            x2, #0x2e
    // 0x54cbac: r0 = containsKey()
    //     0x54cbac: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54cbb0: tbnz            w0, #4, #0x54cc20
    // 0x54cbb4: r0 = 10
    //     0x54cbb4: movz            x0, #0xa
    // 0x54cbb8: mov             x2, x0
    // 0x54cbbc: r1 = Null
    //     0x54cbbc: mov             x1, NULL
    // 0x54cbc0: r0 = AllocateArray()
    //     0x54cbc0: bl              #0x82746c  ; AllocateArrayStub
    // 0x54cbc4: stur            x0, [fp, #-0x10]
    // 0x54cbc8: r16 = 2
    //     0x54cbc8: movz            x16, #0x2
    // 0x54cbcc: StoreField: r0->field_f = r16
    //     0x54cbcc: stur            w16, [x0, #0xf]
    // 0x54cbd0: r16 = 4
    //     0x54cbd0: movz            x16, #0x4
    // 0x54cbd4: StoreField: r0->field_13 = r16
    //     0x54cbd4: stur            w16, [x0, #0x13]
    // 0x54cbd8: r16 = 6
    //     0x54cbd8: movz            x16, #0x6
    // 0x54cbdc: ArrayStore: r0[0] = r16  ; List_4
    //     0x54cbdc: stur            w16, [x0, #0x17]
    // 0x54cbe0: r16 = 8
    //     0x54cbe0: movz            x16, #0x8
    // 0x54cbe4: StoreField: r0->field_1b = r16
    //     0x54cbe4: stur            w16, [x0, #0x1b]
    // 0x54cbe8: r16 = 10
    //     0x54cbe8: movz            x16, #0xa
    // 0x54cbec: StoreField: r0->field_1f = r16
    //     0x54cbec: stur            w16, [x0, #0x1f]
    // 0x54cbf0: r1 = <int>
    //     0x54cbf0: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x54cbf4: r0 = AllocateGrowableArray()
    //     0x54cbf4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x54cbf8: mov             x1, x0
    // 0x54cbfc: ldur            x0, [fp, #-0x10]
    // 0x54cc00: StoreField: r1->field_f = r0
    //     0x54cc00: stur            w0, [x1, #0xf]
    // 0x54cc04: r0 = 10
    //     0x54cc04: movz            x0, #0xa
    // 0x54cc08: StoreField: r1->field_b = r0
    //     0x54cc08: stur            w0, [x1, #0xb]
    // 0x54cc0c: mov             x2, x1
    // 0x54cc10: ldur            x1, [fp, #-8]
    // 0x54cc14: r3 = false
    //     0x54cc14: add             x3, NULL, #0x30  ; false
    // 0x54cc18: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x54cc18: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x54cc1c: r0 = buyAll()
    //     0x54cc1c: bl              #0x544a08  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll
    // 0x54cc20: ldur            x0, [fp, #-8]
    // 0x54cc24: LoadField: r3 = r0->field_2f
    //     0x54cc24: ldur            w3, [x0, #0x2f]
    // 0x54cc28: DecompressPointer r3
    //     0x54cc28: add             x3, x3, HEAP, lsl #32
    // 0x54cc2c: stur            x3, [fp, #-0x18]
    // 0x54cc30: LoadField: r4 = r0->field_37
    //     0x54cc30: ldur            w4, [x0, #0x37]
    // 0x54cc34: DecompressPointer r4
    //     0x54cc34: add             x4, x4, HEAP, lsl #32
    // 0x54cc38: mov             x1, x4
    // 0x54cc3c: stur            x4, [fp, #-0x10]
    // 0x54cc40: r2 = Instance_Chapter9Stat
    //     0x54cc40: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x54cc44: ldr             x2, [x2, #0x8a0]
    // 0x54cc48: r0 = _getValueOrData()
    //     0x54cc48: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54cc4c: mov             x1, x0
    // 0x54cc50: ldur            x0, [fp, #-0x10]
    // 0x54cc54: LoadField: r2 = r0->field_f
    //     0x54cc54: ldur            w2, [x0, #0xf]
    // 0x54cc58: DecompressPointer r2
    //     0x54cc58: add             x2, x2, HEAP, lsl #32
    // 0x54cc5c: cmp             w2, w1
    // 0x54cc60: b.ne            #0x54cc6c
    // 0x54cc64: r0 = Null
    //     0x54cc64: mov             x0, NULL
    // 0x54cc68: b               #0x54cc70
    // 0x54cc6c: mov             x0, x1
    // 0x54cc70: cmp             w0, NULL
    // 0x54cc74: b.ne            #0x54cc84
    // 0x54cc78: r1 = Instance_CustomNum
    //     0x54cc78: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54cc7c: ldr             x1, [x1, #0xaf8]
    // 0x54cc80: b               #0x54cc88
    // 0x54cc84: mov             x1, x0
    // 0x54cc88: ldur            x0, [fp, #-8]
    // 0x54cc8c: r2 = Instance_CustomNum
    //     0x54cc8c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x54cc90: ldr             x2, [x2, #0xce0]
    // 0x54cc94: r0 = mult2()
    //     0x54cc94: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54cc98: mov             x3, x0
    // 0x54cc9c: ldur            x0, [fp, #-8]
    // 0x54cca0: stur            x3, [fp, #-0x20]
    // 0x54cca4: LoadField: r4 = r0->field_37
    //     0x54cca4: ldur            w4, [x0, #0x37]
    // 0x54cca8: DecompressPointer r4
    //     0x54cca8: add             x4, x4, HEAP, lsl #32
    // 0x54ccac: mov             x1, x4
    // 0x54ccb0: stur            x4, [fp, #-0x10]
    // 0x54ccb4: r2 = Instance_Chapter9Stat
    //     0x54ccb4: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x54ccb8: ldr             x2, [x2, #0x8f0]
    // 0x54ccbc: r0 = _getValueOrData()
    //     0x54ccbc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54ccc0: mov             x1, x0
    // 0x54ccc4: ldur            x0, [fp, #-0x10]
    // 0x54ccc8: LoadField: r2 = r0->field_f
    //     0x54ccc8: ldur            w2, [x0, #0xf]
    // 0x54cccc: DecompressPointer r2
    //     0x54cccc: add             x2, x2, HEAP, lsl #32
    // 0x54ccd0: cmp             w2, w1
    // 0x54ccd4: b.ne            #0x54cce0
    // 0x54ccd8: r0 = Null
    //     0x54ccd8: mov             x0, NULL
    // 0x54ccdc: b               #0x54cce4
    // 0x54cce0: mov             x0, x1
    // 0x54cce4: cmp             w0, NULL
    // 0x54cce8: b.ne            #0x54ccf8
    // 0x54ccec: r1 = Instance_CustomNum
    //     0x54ccec: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54ccf0: ldr             x1, [x1, #0xaf8]
    // 0x54ccf4: b               #0x54ccfc
    // 0x54ccf8: mov             x1, x0
    // 0x54ccfc: ldur            x0, [fp, #-8]
    // 0x54cd00: r2 = Instance_CustomNum
    //     0x54cd00: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x54cd04: ldr             x2, [x2, #0xce0]
    // 0x54cd08: r0 = mult2()
    //     0x54cd08: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54cd0c: ldur            x1, [fp, #-0x20]
    // 0x54cd10: mov             x2, x0
    // 0x54cd14: r0 = add()
    //     0x54cd14: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54cd18: mov             x2, x0
    // 0x54cd1c: r1 = Instance_CustomNum
    //     0x54cd1c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54cd20: ldr             x1, [x1, #0xa70]
    // 0x54cd24: r0 = add()
    //     0x54cd24: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54cd28: mov             x3, x0
    // 0x54cd2c: ldur            x0, [fp, #-8]
    // 0x54cd30: stur            x3, [fp, #-0x20]
    // 0x54cd34: LoadField: r4 = r0->field_37
    //     0x54cd34: ldur            w4, [x0, #0x37]
    // 0x54cd38: DecompressPointer r4
    //     0x54cd38: add             x4, x4, HEAP, lsl #32
    // 0x54cd3c: mov             x1, x4
    // 0x54cd40: stur            x4, [fp, #-0x10]
    // 0x54cd44: r2 = Instance_Chapter9Stat
    //     0x54cd44: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x54cd48: ldr             x2, [x2, #0x8d8]
    // 0x54cd4c: r0 = _getValueOrData()
    //     0x54cd4c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54cd50: mov             x1, x0
    // 0x54cd54: ldur            x0, [fp, #-0x10]
    // 0x54cd58: LoadField: r2 = r0->field_f
    //     0x54cd58: ldur            w2, [x0, #0xf]
    // 0x54cd5c: DecompressPointer r2
    //     0x54cd5c: add             x2, x2, HEAP, lsl #32
    // 0x54cd60: cmp             w2, w1
    // 0x54cd64: b.ne            #0x54cd70
    // 0x54cd68: r0 = Null
    //     0x54cd68: mov             x0, NULL
    // 0x54cd6c: b               #0x54cd74
    // 0x54cd70: mov             x0, x1
    // 0x54cd74: cmp             w0, NULL
    // 0x54cd78: b.ne            #0x54cd88
    // 0x54cd7c: r1 = Instance_CustomNum
    //     0x54cd7c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54cd80: ldr             x1, [x1, #0xaf8]
    // 0x54cd84: b               #0x54cd8c
    // 0x54cd88: mov             x1, x0
    // 0x54cd8c: ldur            x0, [fp, #-8]
    // 0x54cd90: r2 = Instance_CustomNum
    //     0x54cd90: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x54cd94: ldr             x2, [x2, #0xce0]
    // 0x54cd98: r0 = mult2()
    //     0x54cd98: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54cd9c: ldur            x1, [fp, #-0x20]
    // 0x54cda0: mov             x2, x0
    // 0x54cda4: r0 = add()
    //     0x54cda4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54cda8: stur            x0, [fp, #-0x10]
    // 0x54cdac: r0 = Boost()
    //     0x54cdac: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x54cdb0: mov             x1, x0
    // 0x54cdb4: r0 = Instance_CustomNum
    //     0x54cdb4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54cdb8: ldr             x0, [x0, #0xa70]
    // 0x54cdbc: StoreField: r1->field_7 = r0
    //     0x54cdbc: stur            w0, [x1, #7]
    // 0x54cdc0: StoreField: r1->field_b = r0
    //     0x54cdc0: stur            w0, [x1, #0xb]
    // 0x54cdc4: ldur            x2, [fp, #-0x10]
    // 0x54cdc8: StoreField: r1->field_f = r2
    //     0x54cdc8: stur            w2, [x1, #0xf]
    // 0x54cdcc: StoreField: r1->field_13 = r0
    //     0x54cdcc: stur            w0, [x1, #0x13]
    // 0x54cdd0: mov             x3, x1
    // 0x54cdd4: ldur            x1, [fp, #-0x18]
    // 0x54cdd8: r2 = Instance_Chapter9Stat
    //     0x54cdd8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x54cddc: ldr             x2, [x2, #0x890]
    // 0x54cde0: r0 = []=()
    //     0x54cde0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x54cde4: ldur            x0, [fp, #-8]
    // 0x54cde8: LoadField: r3 = r0->field_37
    //     0x54cde8: ldur            w3, [x0, #0x37]
    // 0x54cdec: DecompressPointer r3
    //     0x54cdec: add             x3, x3, HEAP, lsl #32
    // 0x54cdf0: mov             x1, x3
    // 0x54cdf4: stur            x3, [fp, #-0x10]
    // 0x54cdf8: r2 = Instance_Chapter9Stat
    //     0x54cdf8: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x54cdfc: ldr             x2, [x2, #0x8f0]
    // 0x54ce00: r0 = _getValueOrData()
    //     0x54ce00: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54ce04: mov             x1, x0
    // 0x54ce08: ldur            x0, [fp, #-0x10]
    // 0x54ce0c: LoadField: r2 = r0->field_f
    //     0x54ce0c: ldur            w2, [x0, #0xf]
    // 0x54ce10: DecompressPointer r2
    //     0x54ce10: add             x2, x2, HEAP, lsl #32
    // 0x54ce14: cmp             w2, w1
    // 0x54ce18: b.ne            #0x54ce24
    // 0x54ce1c: r0 = Null
    //     0x54ce1c: mov             x0, NULL
    // 0x54ce20: b               #0x54ce28
    // 0x54ce24: mov             x0, x1
    // 0x54ce28: cmp             w0, NULL
    // 0x54ce2c: b.ne            #0x54ce3c
    // 0x54ce30: r1 = Instance_CustomNum
    //     0x54ce30: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54ce34: ldr             x1, [x1, #0xaf8]
    // 0x54ce38: b               #0x54ce40
    // 0x54ce3c: mov             x1, x0
    // 0x54ce40: ldur            x0, [fp, #-8]
    // 0x54ce44: r2 = Instance_CustomNum
    //     0x54ce44: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x54ce48: ldr             x2, [x2, #0xce0]
    // 0x54ce4c: r0 = mult2()
    //     0x54ce4c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54ce50: mov             x2, x0
    // 0x54ce54: r1 = Instance_CustomNum
    //     0x54ce54: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54ce58: ldr             x1, [x1, #0xa70]
    // 0x54ce5c: r0 = add()
    //     0x54ce5c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54ce60: stur            x0, [fp, #-0x10]
    // 0x54ce64: r0 = Boost()
    //     0x54ce64: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x54ce68: mov             x1, x0
    // 0x54ce6c: r0 = Instance_CustomNum
    //     0x54ce6c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54ce70: ldr             x0, [x0, #0xa70]
    // 0x54ce74: StoreField: r1->field_7 = r0
    //     0x54ce74: stur            w0, [x1, #7]
    // 0x54ce78: StoreField: r1->field_b = r0
    //     0x54ce78: stur            w0, [x1, #0xb]
    // 0x54ce7c: ldur            x2, [fp, #-0x10]
    // 0x54ce80: StoreField: r1->field_f = r2
    //     0x54ce80: stur            w2, [x1, #0xf]
    // 0x54ce84: StoreField: r1->field_13 = r0
    //     0x54ce84: stur            w0, [x1, #0x13]
    // 0x54ce88: mov             x3, x1
    // 0x54ce8c: ldur            x1, [fp, #-0x18]
    // 0x54ce90: r2 = Instance_Chapter9Stat
    //     0x54ce90: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x54ce94: ldr             x2, [x2, #0x8d8]
    // 0x54ce98: r0 = []=()
    //     0x54ce98: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x54ce9c: ldur            x0, [fp, #-8]
    // 0x54cea0: LoadField: r4 = r0->field_47
    //     0x54cea0: ldur            w4, [x0, #0x47]
    // 0x54cea4: DecompressPointer r4
    //     0x54cea4: add             x4, x4, HEAP, lsl #32
    // 0x54cea8: stur            x4, [fp, #-0x10]
    // 0x54ceac: LoadField: r2 = r4->field_7
    //     0x54ceac: ldur            w2, [x4, #7]
    // 0x54ceb0: DecompressPointer r2
    //     0x54ceb0: add             x2, x2, HEAP, lsl #32
    // 0x54ceb4: r1 = Null
    //     0x54ceb4: mov             x1, NULL
    // 0x54ceb8: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x54ceb8: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x54cebc: r30 = InstantiateTypeArgumentsStub
    //     0x54cebc: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x54cec0: LoadField: r30 = r30->field_7
    //     0x54cec0: ldur            lr, [lr, #7]
    // 0x54cec4: blr             lr
    // 0x54cec8: mov             x1, x0
    // 0x54cecc: r0 = _CompactEntriesIterable()
    //     0x54cecc: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x54ced0: mov             x1, x0
    // 0x54ced4: ldur            x0, [fp, #-0x10]
    // 0x54ced8: StoreField: r1->field_b = r0
    //     0x54ced8: stur            w0, [x1, #0xb]
    // 0x54cedc: r0 = iterator()
    //     0x54cedc: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x54cee0: mov             x2, x0
    // 0x54cee4: ldur            x0, [fp, #-8]
    // 0x54cee8: stur            x2, [fp, #-0x18]
    // 0x54ceec: LoadField: r3 = r0->field_33
    //     0x54ceec: ldur            w3, [x0, #0x33]
    // 0x54cef0: DecompressPointer r3
    //     0x54cef0: add             x3, x3, HEAP, lsl #32
    // 0x54cef4: stur            x3, [fp, #-0x10]
    // 0x54cef8: CheckStackOverflow
    //     0x54cef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54cefc: cmp             SP, x16
    //     0x54cf00: b.ls            #0x54d0b0
    // 0x54cf04: mov             x1, x2
    // 0x54cf08: r0 = moveNext()
    //     0x54cf08: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x54cf0c: tbnz            w0, #4, #0x54d08c
    // 0x54cf10: ldur            x0, [fp, #-0x18]
    // 0x54cf14: LoadField: r3 = r0->field_2b
    //     0x54cf14: ldur            w3, [x0, #0x2b]
    // 0x54cf18: DecompressPointer r3
    //     0x54cf18: add             x3, x3, HEAP, lsl #32
    // 0x54cf1c: stur            x3, [fp, #-0x30]
    // 0x54cf20: cmp             w3, NULL
    // 0x54cf24: b.eq            #0x54d09c
    // 0x54cf28: ldur            x4, [fp, #-8]
    // 0x54cf2c: LoadField: r5 = r3->field_b
    //     0x54cf2c: ldur            w5, [x3, #0xb]
    // 0x54cf30: DecompressPointer r5
    //     0x54cf30: add             x5, x5, HEAP, lsl #32
    // 0x54cf34: stur            x5, [fp, #-0x28]
    // 0x54cf38: LoadField: r6 = r4->field_43
    //     0x54cf38: ldur            w6, [x4, #0x43]
    // 0x54cf3c: DecompressPointer r6
    //     0x54cf3c: add             x6, x6, HEAP, lsl #32
    // 0x54cf40: mov             x1, x6
    // 0x54cf44: stur            x6, [fp, #-0x20]
    // 0x54cf48: r2 = 22
    //     0x54cf48: movz            x2, #0x16
    // 0x54cf4c: r0 = _getValueOrData()
    //     0x54cf4c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54cf50: mov             x1, x0
    // 0x54cf54: ldur            x0, [fp, #-0x20]
    // 0x54cf58: LoadField: r2 = r0->field_f
    //     0x54cf58: ldur            w2, [x0, #0xf]
    // 0x54cf5c: DecompressPointer r2
    //     0x54cf5c: add             x2, x2, HEAP, lsl #32
    // 0x54cf60: cmp             w2, w1
    // 0x54cf64: b.ne            #0x54cf70
    // 0x54cf68: r0 = Null
    //     0x54cf68: mov             x0, NULL
    // 0x54cf6c: b               #0x54cf74
    // 0x54cf70: mov             x0, x1
    // 0x54cf74: cmp             w0, NULL
    // 0x54cf78: b.ne            #0x54cf84
    // 0x54cf7c: r1 = 0
    //     0x54cf7c: movz            x1, #0
    // 0x54cf80: b               #0x54cf90
    // 0x54cf84: r1 = LoadInt32Instr(r0)
    //     0x54cf84: sbfx            x1, x0, #1, #0x1f
    //     0x54cf88: tbz             w0, #0, #0x54cf90
    //     0x54cf8c: ldur            x1, [x0, #7]
    // 0x54cf90: ldur            x0, [fp, #-0x30]
    // 0x54cf94: d0 = 0.010000
    //     0x54cf94: add             x17, PP, #0xd, lsl #12  ; [pp+0xd108] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0x54cf98: ldr             d0, [x17, #0x108]
    // 0x54cf9c: scvtf           d1, x1
    // 0x54cfa0: fmul            d2, d1, d0
    // 0x54cfa4: LoadField: r1 = r0->field_f
    //     0x54cfa4: ldur            w1, [x0, #0xf]
    // 0x54cfa8: DecompressPointer r1
    //     0x54cfa8: add             x1, x1, HEAP, lsl #32
    // 0x54cfac: r0 = inline_Allocate_Double()
    //     0x54cfac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x54cfb0: add             x0, x0, #0x10
    //     0x54cfb4: cmp             x2, x0
    //     0x54cfb8: b.ls            #0x54d0b8
    //     0x54cfbc: str             x0, [THR, #0x60]  ; THR::top
    //     0x54cfc0: sub             x0, x0, #0xf
    //     0x54cfc4: movz            x2, #0xe19c
    //     0x54cfc8: movk            x2, #0x3, lsl #16
    //     0x54cfcc: stur            x2, [x0, #-1]
    // 0x54cfd0: dmb             ishst
    // 0x54cfd4: StoreField: r0->field_7 = d2
    //     0x54cfd4: stur            d2, [x0, #7]
    // 0x54cfd8: stp             x1, x0, [SP]
    // 0x54cfdc: r0 = *()
    //     0x54cfdc: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x54cfe0: mov             x2, x0
    // 0x54cfe4: r1 = Null
    //     0x54cfe4: mov             x1, NULL
    // 0x54cfe8: r0 = CustomNum()
    //     0x54cfe8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x54cfec: mov             x2, x0
    // 0x54cff0: r1 = Instance_CustomNum
    //     0x54cff0: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54cff4: ldr             x1, [x1, #0xa70]
    // 0x54cff8: r0 = add()
    //     0x54cff8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54cffc: stur            x0, [fp, #-0x20]
    // 0x54d000: r0 = Boost()
    //     0x54d000: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x54d004: mov             x4, x0
    // 0x54d008: r3 = Instance_CustomNum
    //     0x54d008: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54d00c: ldr             x3, [x3, #0xa70]
    // 0x54d010: stur            x4, [fp, #-0x30]
    // 0x54d014: StoreField: r4->field_7 = r3
    //     0x54d014: stur            w3, [x4, #7]
    // 0x54d018: StoreField: r4->field_b = r3
    //     0x54d018: stur            w3, [x4, #0xb]
    // 0x54d01c: ldur            x0, [fp, #-0x20]
    // 0x54d020: StoreField: r4->field_f = r0
    //     0x54d020: stur            w0, [x4, #0xf]
    // 0x54d024: StoreField: r4->field_13 = r3
    //     0x54d024: stur            w3, [x4, #0x13]
    // 0x54d028: ldur            x0, [fp, #-0x28]
    // 0x54d02c: r2 = Null
    //     0x54d02c: mov             x2, NULL
    // 0x54d030: r1 = Null
    //     0x54d030: mov             x1, NULL
    // 0x54d034: branchIfSmi(r0, 0x54d05c)
    //     0x54d034: tbz             w0, #0, #0x54d05c
    // 0x54d038: r4 = LoadClassIdInstr(r0)
    //     0x54d038: ldur            x4, [x0, #-1]
    //     0x54d03c: ubfx            x4, x4, #0xc, #0x14
    // 0x54d040: sub             x4, x4, #0x3c
    // 0x54d044: cmp             x4, #1
    // 0x54d048: b.ls            #0x54d05c
    // 0x54d04c: r8 = int?
    //     0x54d04c: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x54d050: r3 = Null
    //     0x54d050: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a1c0] Null
    //     0x54d054: ldr             x3, [x3, #0x1c0]
    // 0x54d058: r0 = int?()
    //     0x54d058: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x54d05c: ldur            x1, [fp, #-0x10]
    // 0x54d060: ldur            x2, [fp, #-0x28]
    // 0x54d064: r0 = _hashCode()
    //     0x54d064: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x54d068: ldur            x1, [fp, #-0x10]
    // 0x54d06c: ldur            x2, [fp, #-0x28]
    // 0x54d070: ldur            x3, [fp, #-0x30]
    // 0x54d074: mov             x5, x0
    // 0x54d078: r0 = _set()
    //     0x54d078: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x54d07c: ldur            x0, [fp, #-8]
    // 0x54d080: ldur            x2, [fp, #-0x18]
    // 0x54d084: ldur            x3, [fp, #-0x10]
    // 0x54d088: b               #0x54cef8
    // 0x54d08c: r0 = Null
    //     0x54d08c: mov             x0, NULL
    // 0x54d090: LeaveFrame
    //     0x54d090: mov             SP, fp
    //     0x54d094: ldp             fp, lr, [SP], #0x10
    // 0x54d098: ret
    //     0x54d098: ret             
    // 0x54d09c: r0 = noElement()
    //     0x54d09c: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x54d0a0: r0 = Throw()
    //     0x54d0a0: bl              #0x825670  ; ThrowStub
    // 0x54d0a4: brk             #0
    // 0x54d0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d0a8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d0ac: b               #0x54cba0
    // 0x54d0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d0b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d0b4: b               #0x54cf04
    // 0x54d0b8: stp             q0, q2, [SP, #-0x20]!
    // 0x54d0bc: SaveReg r1
    //     0x54d0bc: str             x1, [SP, #-8]!
    // 0x54d0c0: r0 = AllocateDouble()
    //     0x54d0c0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x54d0c4: RestoreReg r1
    //     0x54d0c4: ldr             x1, [SP], #8
    // 0x54d0c8: ldp             q0, q2, [SP], #0x20
    // 0x54d0cc: b               #0x54cfd4
  }
  get _ bonusGeneratorMapping(/* No info */) {
    // ** addr: 0x55c2c4, size: 0xc
    // 0x55c2c4: LoadField: r0 = r1->field_93
    //     0x55c2c4: ldur            w0, [x1, #0x93]
    // 0x55c2c8: DecompressPointer r0
    //     0x55c2c8: add             x0, x0, HEAP, lsl #32
    // 0x55c2cc: ret
    //     0x55c2cc: ret             
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55deb4, size: 0x40
    // 0x55deb4: EnterFrame
    //     0x55deb4: stp             fp, lr, [SP, #-0x10]!
    //     0x55deb8: mov             fp, SP
    // 0x55debc: AllocStack(0x10)
    //     0x55debc: sub             SP, SP, #0x10
    // 0x55dec0: CheckStackOverflow
    //     0x55dec0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55dec4: cmp             SP, x16
    //     0x55dec8: b.ls            #0x55deec
    // 0x55decc: r16 = <Chapter9Stat, CustomNum>
    //     0x55decc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d00] TypeArguments: <Chapter9Stat, CustomNum>
    //     0x55ded0: ldr             x16, [x16, #0xd00]
    // 0x55ded4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x55ded8: stp             lr, x16, [SP]
    // 0x55dedc: r0 = Map._fromLiteral()
    //     0x55dedc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55dee0: LeaveFrame
    //     0x55dee0: mov             SP, fp
    //     0x55dee4: ldp             fp, lr, [SP], #0x10
    // 0x55dee8: ret
    //     0x55dee8: ret             
    // 0x55deec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55deec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55def0: b               #0x55decc
  }
  _ checkAllBoosts(/* No info */) {
    // ** addr: 0x68e848, size: 0x320
    // 0x68e848: EnterFrame
    //     0x68e848: stp             fp, lr, [SP, #-0x10]!
    //     0x68e84c: mov             fp, SP
    // 0x68e850: AllocStack(0x30)
    //     0x68e850: sub             SP, SP, #0x30
    // 0x68e854: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x10 */)
    //     0x68e854: mov             x0, x1
    //     0x68e858: stur            x1, [fp, #-0x10]
    // 0x68e85c: CheckStackOverflow
    //     0x68e85c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x68e860: cmp             SP, x16
    //     0x68e864: b.ls            #0x68eb60
    // 0x68e868: LoadField: r3 = r0->field_43
    //     0x68e868: ldur            w3, [x0, #0x43]
    // 0x68e86c: DecompressPointer r3
    //     0x68e86c: add             x3, x3, HEAP, lsl #32
    // 0x68e870: mov             x1, x3
    // 0x68e874: stur            x3, [fp, #-8]
    // 0x68e878: r2 = 2
    //     0x68e878: movz            x2, #0x2
    // 0x68e87c: r0 = _getValueOrData()
    //     0x68e87c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68e880: mov             x1, x0
    // 0x68e884: ldur            x0, [fp, #-8]
    // 0x68e888: LoadField: r2 = r0->field_f
    //     0x68e888: ldur            w2, [x0, #0xf]
    // 0x68e88c: DecompressPointer r2
    //     0x68e88c: add             x2, x2, HEAP, lsl #32
    // 0x68e890: cmp             w2, w1
    // 0x68e894: b.ne            #0x68e8a0
    // 0x68e898: r0 = Null
    //     0x68e898: mov             x0, NULL
    // 0x68e89c: b               #0x68e8a4
    // 0x68e8a0: mov             x0, x1
    // 0x68e8a4: cmp             w0, NULL
    // 0x68e8a8: b.ne            #0x68e8b4
    // 0x68e8ac: r2 = 0
    //     0x68e8ac: movz            x2, #0
    // 0x68e8b0: b               #0x68e8c4
    // 0x68e8b4: r1 = LoadInt32Instr(r0)
    //     0x68e8b4: sbfx            x1, x0, #1, #0x1f
    //     0x68e8b8: tbz             w0, #0, #0x68e8c0
    //     0x68e8bc: ldur            x1, [x0, #7]
    // 0x68e8c0: mov             x2, x1
    // 0x68e8c4: ldur            x3, [fp, #-0x10]
    // 0x68e8c8: r0 = BoxInt64Instr(r2)
    //     0x68e8c8: sbfiz           x0, x2, #1, #0x1f
    //     0x68e8cc: cmp             x2, x0, asr #1
    //     0x68e8d0: b.eq            #0x68e8dc
    //     0x68e8d4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68e8d8: stur            x2, [x0, #7]
    // 0x68e8dc: mov             x2, x0
    // 0x68e8e0: r1 = Instance_CustomNum
    //     0x68e8e0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x68e8e4: ldr             x1, [x1, #0xce0]
    // 0x68e8e8: r0 = pow()
    //     0x68e8e8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x68e8ec: r1 = Null
    //     0x68e8ec: mov             x1, NULL
    // 0x68e8f0: r2 = 1.500000
    //     0x68e8f0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce8] 1.5
    //     0x68e8f4: ldr             x2, [x2, #0xce8]
    // 0x68e8f8: stur            x0, [fp, #-8]
    // 0x68e8fc: r0 = CustomNum()
    //     0x68e8fc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x68e900: mov             x3, x0
    // 0x68e904: ldur            x0, [fp, #-0x10]
    // 0x68e908: stur            x3, [fp, #-0x20]
    // 0x68e90c: LoadField: r4 = r0->field_43
    //     0x68e90c: ldur            w4, [x0, #0x43]
    // 0x68e910: DecompressPointer r4
    //     0x68e910: add             x4, x4, HEAP, lsl #32
    // 0x68e914: mov             x1, x4
    // 0x68e918: stur            x4, [fp, #-0x18]
    // 0x68e91c: r2 = 24
    //     0x68e91c: movz            x2, #0x18
    // 0x68e920: r0 = _getValueOrData()
    //     0x68e920: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68e924: mov             x1, x0
    // 0x68e928: ldur            x0, [fp, #-0x18]
    // 0x68e92c: LoadField: r2 = r0->field_f
    //     0x68e92c: ldur            w2, [x0, #0xf]
    // 0x68e930: DecompressPointer r2
    //     0x68e930: add             x2, x2, HEAP, lsl #32
    // 0x68e934: cmp             w2, w1
    // 0x68e938: b.ne            #0x68e944
    // 0x68e93c: r0 = Null
    //     0x68e93c: mov             x0, NULL
    // 0x68e940: b               #0x68e948
    // 0x68e944: mov             x0, x1
    // 0x68e948: cmp             w0, NULL
    // 0x68e94c: b.ne            #0x68e958
    // 0x68e950: r3 = 0
    //     0x68e950: movz            x3, #0
    // 0x68e954: b               #0x68e968
    // 0x68e958: r1 = LoadInt32Instr(r0)
    //     0x68e958: sbfx            x1, x0, #1, #0x1f
    //     0x68e95c: tbz             w0, #0, #0x68e964
    //     0x68e960: ldur            x1, [x0, #7]
    // 0x68e964: mov             x3, x1
    // 0x68e968: ldur            x0, [fp, #-0x10]
    // 0x68e96c: stur            x3, [fp, #-0x28]
    // 0x68e970: LoadField: r4 = r0->field_43
    //     0x68e970: ldur            w4, [x0, #0x43]
    // 0x68e974: DecompressPointer r4
    //     0x68e974: add             x4, x4, HEAP, lsl #32
    // 0x68e978: mov             x1, x4
    // 0x68e97c: stur            x4, [fp, #-0x18]
    // 0x68e980: r2 = 42
    //     0x68e980: movz            x2, #0x2a
    // 0x68e984: r0 = _getValueOrData()
    //     0x68e984: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68e988: mov             x1, x0
    // 0x68e98c: ldur            x0, [fp, #-0x18]
    // 0x68e990: LoadField: r2 = r0->field_f
    //     0x68e990: ldur            w2, [x0, #0xf]
    // 0x68e994: DecompressPointer r2
    //     0x68e994: add             x2, x2, HEAP, lsl #32
    // 0x68e998: cmp             w2, w1
    // 0x68e99c: b.ne            #0x68e9a8
    // 0x68e9a0: r0 = Null
    //     0x68e9a0: mov             x0, NULL
    // 0x68e9a4: b               #0x68e9ac
    // 0x68e9a8: mov             x0, x1
    // 0x68e9ac: cmp             w0, NULL
    // 0x68e9b0: b.ne            #0x68e9bc
    // 0x68e9b4: r2 = 0
    //     0x68e9b4: movz            x2, #0
    // 0x68e9b8: b               #0x68e9cc
    // 0x68e9bc: r1 = LoadInt32Instr(r0)
    //     0x68e9bc: sbfx            x1, x0, #1, #0x1f
    //     0x68e9c0: tbz             w0, #0, #0x68e9c8
    //     0x68e9c4: ldur            x1, [x0, #7]
    // 0x68e9c8: mov             x2, x1
    // 0x68e9cc: ldur            x0, [fp, #-0x10]
    // 0x68e9d0: ldur            x1, [fp, #-0x28]
    // 0x68e9d4: lsl             x3, x2, #1
    // 0x68e9d8: add             x4, x1, x3
    // 0x68e9dc: stur            x4, [fp, #-0x30]
    // 0x68e9e0: LoadField: r3 = r0->field_43
    //     0x68e9e0: ldur            w3, [x0, #0x43]
    // 0x68e9e4: DecompressPointer r3
    //     0x68e9e4: add             x3, x3, HEAP, lsl #32
    // 0x68e9e8: mov             x1, x3
    // 0x68e9ec: stur            x3, [fp, #-0x18]
    // 0x68e9f0: r2 = 46
    //     0x68e9f0: movz            x2, #0x2e
    // 0x68e9f4: r0 = _getValueOrData()
    //     0x68e9f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68e9f8: mov             x1, x0
    // 0x68e9fc: ldur            x0, [fp, #-0x18]
    // 0x68ea00: LoadField: r2 = r0->field_f
    //     0x68ea00: ldur            w2, [x0, #0xf]
    // 0x68ea04: DecompressPointer r2
    //     0x68ea04: add             x2, x2, HEAP, lsl #32
    // 0x68ea08: cmp             w2, w1
    // 0x68ea0c: b.ne            #0x68ea18
    // 0x68ea10: r0 = Null
    //     0x68ea10: mov             x0, NULL
    // 0x68ea14: b               #0x68ea1c
    // 0x68ea18: mov             x0, x1
    // 0x68ea1c: cmp             w0, NULL
    // 0x68ea20: b.ne            #0x68ea2c
    // 0x68ea24: r1 = 0
    //     0x68ea24: movz            x1, #0
    // 0x68ea28: b               #0x68ea38
    // 0x68ea2c: r1 = LoadInt32Instr(r0)
    //     0x68ea2c: sbfx            x1, x0, #1, #0x1f
    //     0x68ea30: tbz             w0, #0, #0x68ea38
    //     0x68ea34: ldur            x1, [x0, #7]
    // 0x68ea38: ldur            x3, [fp, #-0x10]
    // 0x68ea3c: ldur            x0, [fp, #-0x30]
    // 0x68ea40: r16 = 5
    //     0x68ea40: movz            x16, #0x5
    // 0x68ea44: mul             x2, x1, x16
    // 0x68ea48: add             x4, x0, x2
    // 0x68ea4c: r0 = BoxInt64Instr(r4)
    //     0x68ea4c: sbfiz           x0, x4, #1, #0x1f
    //     0x68ea50: cmp             x4, x0, asr #1
    //     0x68ea54: b.eq            #0x68ea60
    //     0x68ea58: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68ea5c: stur            x4, [x0, #7]
    // 0x68ea60: ldur            x1, [fp, #-0x20]
    // 0x68ea64: mov             x2, x0
    // 0x68ea68: r0 = pow()
    //     0x68ea68: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x68ea6c: mov             x3, x0
    // 0x68ea70: ldur            x0, [fp, #-0x10]
    // 0x68ea74: stur            x3, [fp, #-0x20]
    // 0x68ea78: LoadField: r4 = r0->field_43
    //     0x68ea78: ldur            w4, [x0, #0x43]
    // 0x68ea7c: DecompressPointer r4
    //     0x68ea7c: add             x4, x4, HEAP, lsl #32
    // 0x68ea80: mov             x1, x4
    // 0x68ea84: stur            x4, [fp, #-0x18]
    // 0x68ea88: r2 = 50
    //     0x68ea88: movz            x2, #0x32
    // 0x68ea8c: r0 = _getValueOrData()
    //     0x68ea8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68ea90: mov             x1, x0
    // 0x68ea94: ldur            x0, [fp, #-0x18]
    // 0x68ea98: LoadField: r2 = r0->field_f
    //     0x68ea98: ldur            w2, [x0, #0xf]
    // 0x68ea9c: DecompressPointer r2
    //     0x68ea9c: add             x2, x2, HEAP, lsl #32
    // 0x68eaa0: cmp             w2, w1
    // 0x68eaa4: b.ne            #0x68eab0
    // 0x68eaa8: r0 = Null
    //     0x68eaa8: mov             x0, NULL
    // 0x68eaac: b               #0x68eab4
    // 0x68eab0: mov             x0, x1
    // 0x68eab4: cmp             w0, NULL
    // 0x68eab8: b.ne            #0x68eac4
    // 0x68eabc: r2 = 0
    //     0x68eabc: movz            x2, #0
    // 0x68eac0: b               #0x68ead4
    // 0x68eac4: r1 = LoadInt32Instr(r0)
    //     0x68eac4: sbfx            x1, x0, #1, #0x1f
    //     0x68eac8: tbz             w0, #0, #0x68ead0
    //     0x68eacc: ldur            x1, [x0, #7]
    // 0x68ead0: mov             x2, x1
    // 0x68ead4: ldur            x3, [fp, #-0x10]
    // 0x68ead8: ldur            x5, [fp, #-8]
    // 0x68eadc: ldur            x4, [fp, #-0x20]
    // 0x68eae0: r0 = BoxInt64Instr(r2)
    //     0x68eae0: sbfiz           x0, x2, #1, #0x1f
    //     0x68eae4: cmp             x2, x0, asr #1
    //     0x68eae8: b.eq            #0x68eaf4
    //     0x68eaec: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68eaf0: stur            x2, [x0, #7]
    // 0x68eaf4: mov             x2, x0
    // 0x68eaf8: r1 = Instance_CustomNum
    //     0x68eaf8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x68eafc: ldr             x1, [x1, #0xdd0]
    // 0x68eb00: r0 = pow()
    //     0x68eb00: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x68eb04: stur            x0, [fp, #-0x18]
    // 0x68eb08: r0 = Boost()
    //     0x68eb08: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68eb0c: ldur            x1, [fp, #-0x18]
    // 0x68eb10: StoreField: r0->field_7 = r1
    //     0x68eb10: stur            w1, [x0, #7]
    // 0x68eb14: ldur            x1, [fp, #-8]
    // 0x68eb18: StoreField: r0->field_b = r1
    //     0x68eb18: stur            w1, [x0, #0xb]
    // 0x68eb1c: ldur            x1, [fp, #-0x20]
    // 0x68eb20: StoreField: r0->field_f = r1
    //     0x68eb20: stur            w1, [x0, #0xf]
    // 0x68eb24: r1 = Instance_CustomNum
    //     0x68eb24: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68eb28: ldr             x1, [x1, #0xa70]
    // 0x68eb2c: StoreField: r0->field_13 = r1
    //     0x68eb2c: stur            w1, [x0, #0x13]
    // 0x68eb30: ldur            x1, [fp, #-0x10]
    // 0x68eb34: StoreField: r1->field_2b = r0
    //     0x68eb34: stur            w0, [x1, #0x2b]
    //     0x68eb38: ldurb           w16, [x1, #-1]
    //     0x68eb3c: ldurb           w17, [x0, #-1]
    //     0x68eb40: and             x16, x17, x16, lsr #2
    //     0x68eb44: tst             x16, HEAP, lsr #32
    //     0x68eb48: b.eq            #0x68eb50
    //     0x68eb4c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x68eb50: r0 = Null
    //     0x68eb50: mov             x0, NULL
    // 0x68eb54: LeaveFrame
    //     0x68eb54: mov             SP, fp
    //     0x68eb58: ldp             fp, lr, [SP], #0x10
    // 0x68eb5c: ret
    //     0x68eb5c: ret             
    // 0x68eb60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68eb60: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68eb64: b               #0x68e868
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x69473c, size: 0x68
    // 0x69473c: EnterFrame
    //     0x69473c: stp             fp, lr, [SP, #-0x10]!
    //     0x694740: mov             fp, SP
    // 0x694744: ldr             x0, [fp, #0x10]
    // 0x694748: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x694748: ldur            w1, [x0, #0x17]
    // 0x69474c: DecompressPointer r1
    //     0x69474c: add             x1, x1, HEAP, lsl #32
    // 0x694750: CheckStackOverflow
    //     0x694750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694754: cmp             SP, x16
    //     0x694758: b.ls            #0x69479c
    // 0x69475c: LoadField: r0 = r1->field_f
    //     0x69475c: ldur            w0, [x1, #0xf]
    // 0x694760: DecompressPointer r0
    //     0x694760: add             x0, x0, HEAP, lsl #32
    // 0x694764: LoadField: r1 = r0->field_43
    //     0x694764: ldur            w1, [x0, #0x43]
    // 0x694768: DecompressPointer r1
    //     0x694768: add             x1, x1, HEAP, lsl #32
    // 0x69476c: r2 = 46
    //     0x69476c: movz            x2, #0x2e
    // 0x694770: r0 = containsKey()
    //     0x694770: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x694774: tbnz            w0, #4, #0x69478c
    // 0x694778: r0 = "Generators"
    //     0x694778: add             x0, PP, #0x26, lsl #12  ; [pp+0x26558] "Generators"
    //     0x69477c: ldr             x0, [x0, #0x558]
    // 0x694780: LeaveFrame
    //     0x694780: mov             SP, fp
    //     0x694784: ldp             fp, lr, [SP], #0x10
    // 0x694788: ret
    //     0x694788: ret             
    // 0x69478c: r0 = Null
    //     0x69478c: mov             x0, NULL
    // 0x694790: LeaveFrame
    //     0x694790: mov             SP, fp
    //     0x694794: ldp             fp, lr, [SP], #0x10
    // 0x694798: ret
    //     0x694798: ret             
    // 0x69479c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69479c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6947a0: b               #0x69475c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x697f00, size: 0x4c
    // 0x697f00: EnterFrame
    //     0x697f00: stp             fp, lr, [SP, #-0x10]!
    //     0x697f04: mov             fp, SP
    // 0x697f08: ldr             x0, [fp, #0x10]
    // 0x697f0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x697f0c: ldur            w1, [x0, #0x17]
    // 0x697f10: DecompressPointer r1
    //     0x697f10: add             x1, x1, HEAP, lsl #32
    // 0x697f14: CheckStackOverflow
    //     0x697f14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x697f18: cmp             SP, x16
    //     0x697f1c: b.ls            #0x697f44
    // 0x697f20: LoadField: r0 = r1->field_f
    //     0x697f20: ldur            w0, [x1, #0xf]
    // 0x697f24: DecompressPointer r0
    //     0x697f24: add             x0, x0, HEAP, lsl #32
    // 0x697f28: LoadField: r1 = r0->field_13
    //     0x697f28: ldur            w1, [x0, #0x13]
    // 0x697f2c: DecompressPointer r1
    //     0x697f2c: add             x1, x1, HEAP, lsl #32
    // 0x697f30: r2 = 16
    //     0x697f30: movz            x2, #0x10
    // 0x697f34: r0 = contains()
    //     0x697f34: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x697f38: LeaveFrame
    //     0x697f38: mov             SP, fp
    //     0x697f3c: ldp             fp, lr, [SP], #0x10
    // 0x697f40: ret
    //     0x697f40: ret             
    // 0x697f44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x697f44: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x697f48: b               #0x697f20
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x699680, size: 0x4c
    // 0x699680: EnterFrame
    //     0x699680: stp             fp, lr, [SP, #-0x10]!
    //     0x699684: mov             fp, SP
    // 0x699688: ldr             x0, [fp, #0x10]
    // 0x69968c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69968c: ldur            w1, [x0, #0x17]
    // 0x699690: DecompressPointer r1
    //     0x699690: add             x1, x1, HEAP, lsl #32
    // 0x699694: CheckStackOverflow
    //     0x699694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699698: cmp             SP, x16
    //     0x69969c: b.ls            #0x6996c4
    // 0x6996a0: LoadField: r0 = r1->field_f
    //     0x6996a0: ldur            w0, [x1, #0xf]
    // 0x6996a4: DecompressPointer r0
    //     0x6996a4: add             x0, x0, HEAP, lsl #32
    // 0x6996a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6996a8: ldur            w1, [x0, #0x17]
    // 0x6996ac: DecompressPointer r1
    //     0x6996ac: add             x1, x1, HEAP, lsl #32
    // 0x6996b0: r2 = 24
    //     0x6996b0: movz            x2, #0x18
    // 0x6996b4: r0 = contains()
    //     0x6996b4: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6996b8: LeaveFrame
    //     0x6996b8: mov             SP, fp
    //     0x6996bc: ldp             fp, lr, [SP], #0x10
    // 0x6996c0: ret
    //     0x6996c0: ret             
    // 0x6996c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6996c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6996c8: b               #0x6996a0
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69b1c8, size: 0x4c
    // 0x69b1c8: EnterFrame
    //     0x69b1c8: stp             fp, lr, [SP, #-0x10]!
    //     0x69b1cc: mov             fp, SP
    // 0x69b1d0: ldr             x0, [fp, #0x10]
    // 0x69b1d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69b1d4: ldur            w1, [x0, #0x17]
    // 0x69b1d8: DecompressPointer r1
    //     0x69b1d8: add             x1, x1, HEAP, lsl #32
    // 0x69b1dc: CheckStackOverflow
    //     0x69b1dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b1e0: cmp             SP, x16
    //     0x69b1e4: b.ls            #0x69b20c
    // 0x69b1e8: LoadField: r0 = r1->field_f
    //     0x69b1e8: ldur            w0, [x1, #0xf]
    // 0x69b1ec: DecompressPointer r0
    //     0x69b1ec: add             x0, x0, HEAP, lsl #32
    // 0x69b1f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69b1f0: ldur            w1, [x0, #0x17]
    // 0x69b1f4: DecompressPointer r1
    //     0x69b1f4: add             x1, x1, HEAP, lsl #32
    // 0x69b1f8: r2 = 4
    //     0x69b1f8: movz            x2, #0x4
    // 0x69b1fc: r0 = contains()
    //     0x69b1fc: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69b200: LeaveFrame
    //     0x69b200: mov             SP, fp
    //     0x69b204: ldp             fp, lr, [SP], #0x10
    // 0x69b208: ret
    //     0x69b208: ret             
    // 0x69b20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b20c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b210: b               #0x69b1e8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6aa0c8, size: 0xc
    // 0x6aa0c8: r0 = "New Project"
    //     0x6aa0c8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26530] "New Project"
    //     0x6aa0cc: ldr             x0, [x0, #0x530]
    // 0x6aa0d0: ret
    //     0x6aa0d0: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6aafac, size: 0xc
    // 0x6aafac: r0 = "Rewrite"
    //     0x6aafac: add             x0, PP, #0x26, lsl #12  ; [pp+0x26550] "Rewrite"
    //     0x6aafb0: ldr             x0, [x0, #0x550]
    // 0x6aafb4: ret
    //     0x6aafb4: ret             
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6c4390, size: 0x4c
    // 0x6c4390: EnterFrame
    //     0x6c4390: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4394: mov             fp, SP
    // 0x6c4398: ldr             x0, [fp, #0x10]
    // 0x6c439c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c439c: ldur            w1, [x0, #0x17]
    // 0x6c43a0: DecompressPointer r1
    //     0x6c43a0: add             x1, x1, HEAP, lsl #32
    // 0x6c43a4: CheckStackOverflow
    //     0x6c43a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c43a8: cmp             SP, x16
    //     0x6c43ac: b.ls            #0x6c43d4
    // 0x6c43b0: LoadField: r0 = r1->field_f
    //     0x6c43b0: ldur            w0, [x1, #0xf]
    // 0x6c43b4: DecompressPointer r0
    //     0x6c43b4: add             x0, x0, HEAP, lsl #32
    // 0x6c43b8: LoadField: r1 = r0->field_1b
    //     0x6c43b8: ldur            w1, [x0, #0x1b]
    // 0x6c43bc: DecompressPointer r1
    //     0x6c43bc: add             x1, x1, HEAP, lsl #32
    // 0x6c43c0: r2 = 2
    //     0x6c43c0: movz            x2, #0x2
    // 0x6c43c4: r0 = contains()
    //     0x6c43c4: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6c43c8: LeaveFrame
    //     0x6c43c8: mov             SP, fp
    //     0x6c43cc: ldp             fp, lr, [SP], #0x10
    // 0x6c43d0: ret
    //     0x6c43d0: ret             
    // 0x6c43d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c43d4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c43d8: b               #0x6c43b0
  }
  _ build(/* No info */) {
    // ** addr: 0x6c4f2c, size: 0x1204
    // 0x6c4f2c: EnterFrame
    //     0x6c4f2c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4f30: mov             fp, SP
    // 0x6c4f34: AllocStack(0xb0)
    //     0x6c4f34: sub             SP, SP, #0xb0
    // 0x6c4f38: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x6c4f38: mov             x0, x1
    //     0x6c4f3c: stur            x1, [fp, #-8]
    //     0x6c4f40: stur            x2, [fp, #-0x10]
    // 0x6c4f44: CheckStackOverflow
    //     0x6c4f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c4f48: cmp             SP, x16
    //     0x6c4f4c: b.ls            #0x6c611c
    // 0x6c4f50: r1 = 2
    //     0x6c4f50: movz            x1, #0x2
    // 0x6c4f54: r0 = AllocateContext()
    //     0x6c4f54: bl              #0x82637c  ; AllocateContextStub
    // 0x6c4f58: ldur            x2, [fp, #-8]
    // 0x6c4f5c: stur            x0, [fp, #-0x18]
    // 0x6c4f60: StoreField: r0->field_f = r2
    //     0x6c4f60: stur            w2, [x0, #0xf]
    // 0x6c4f64: ldur            x1, [fp, #-0x10]
    // 0x6c4f68: StoreField: r0->field_13 = r1
    //     0x6c4f68: stur            w1, [x0, #0x13]
    // 0x6c4f6c: LoadField: r3 = r2->field_37
    //     0x6c4f6c: ldur            w3, [x2, #0x37]
    // 0x6c4f70: DecompressPointer r3
    //     0x6c4f70: add             x3, x3, HEAP, lsl #32
    // 0x6c4f74: stur            x3, [fp, #-0x10]
    // 0x6c4f78: r1 = <Chapter9Stat>
    //     0x6c4f78: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c4f7c: ldr             x1, [x1, #0xe48]
    // 0x6c4f80: r0 = IntermissionButton()
    //     0x6c4f80: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x6c4f84: mov             x3, x0
    // 0x6c4f88: ldur            x0, [fp, #-0x10]
    // 0x6c4f8c: stur            x3, [fp, #-0x20]
    // 0x6c4f90: StoreField: r3->field_1b = r0
    //     0x6c4f90: stur            w0, [x3, #0x1b]
    // 0x6c4f94: ldur            x2, [fp, #-0x18]
    // 0x6c4f98: r1 = Function '<anonymous closure>':.
    //     0x6c4f98: add             x1, PP, #0x26, lsl #12  ; [pp+0x26090] AnonymousClosure: (0x6c7414), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c4f9c: ldr             x1, [x1, #0x90]
    // 0x6c4fa0: r0 = AllocateClosure()
    //     0x6c4fa0: bl              #0x826750  ; AllocateClosureStub
    // 0x6c4fa4: mov             x1, x0
    // 0x6c4fa8: ldur            x0, [fp, #-0x20]
    // 0x6c4fac: StoreField: r0->field_23 = r1
    //     0x6c4fac: stur            w1, [x0, #0x23]
    // 0x6c4fb0: r1 = Function '<anonymous closure>':.
    //     0x6c4fb0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26098] AnonymousClosure: (0x6c71a4), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c4fb4: ldr             x1, [x1, #0x98]
    // 0x6c4fb8: r2 = Null
    //     0x6c4fb8: mov             x2, NULL
    // 0x6c4fbc: r0 = AllocateClosure()
    //     0x6c4fbc: bl              #0x826750  ; AllocateClosureStub
    // 0x6c4fc0: mov             x1, x0
    // 0x6c4fc4: ldur            x0, [fp, #-0x20]
    // 0x6c4fc8: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c4fc8: stur            w1, [x0, #0x17]
    // 0x6c4fcc: r3 = Closure: (Chapter9Stat?) => String from Function 'humanName': static.
    //     0x6c4fcc: add             x3, PP, #0x26, lsl #12  ; [pp+0x260a0] Closure: (Chapter9Stat?) => String from Function 'humanName': static. (0x248ed99e608)
    //     0x6c4fd0: ldr             x3, [x3, #0xa0]
    // 0x6c4fd4: StoreField: r0->field_f = r3
    //     0x6c4fd4: stur            w3, [x0, #0xf]
    // 0x6c4fd8: r1 = Function '<anonymous closure>':.
    //     0x6c4fd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x260a8] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6c4fdc: ldr             x1, [x1, #0xa8]
    // 0x6c4fe0: r2 = Null
    //     0x6c4fe0: mov             x2, NULL
    // 0x6c4fe4: r0 = AllocateClosure()
    //     0x6c4fe4: bl              #0x826750  ; AllocateClosureStub
    // 0x6c4fe8: ldur            x2, [fp, #-0x18]
    // 0x6c4fec: r1 = Function '<anonymous closure>':.
    //     0x6c4fec: add             x1, PP, #0x26, lsl #12  ; [pp+0x260b0] AnonymousClosure: (0x6c7368), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c4ff0: ldr             x1, [x1, #0xb0]
    // 0x6c4ff4: stur            x0, [fp, #-0x10]
    // 0x6c4ff8: r0 = AllocateClosure()
    //     0x6c4ff8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c4ffc: r16 = false
    //     0x6c4ffc: add             x16, NULL, #0x30  ; false
    // 0x6c5000: stp             x0, x16, [SP]
    // 0x6c5004: ldur            x2, [fp, #-0x20]
    // 0x6c5008: ldur            x5, [fp, #-0x10]
    // 0x6c500c: r1 = Null
    //     0x6c500c: mov             x1, NULL
    // 0x6c5010: r3 = "Chapter 9 Intermission 1"
    //     0x6c5010: add             x3, PP, #0x26, lsl #12  ; [pp+0x260b8] "Chapter 9 Intermission 1"
    //     0x6c5014: ldr             x3, [x3, #0xb8]
    // 0x6c5018: r4 = const [0, 0x6, 0x2, 0x4, generateMinimizedName, 0x5, scrollToBottomOnUnlock, 0x4, null]
    //     0x6c5018: add             x4, PP, #0x26, lsl #12  ; [pp+0x260c0] List(9) [0, 0x6, 0x2, 0x4, "generateMinimizedName", 0x5, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6c501c: ldr             x4, [x4, #0xc0]
    // 0x6c5020: r0 = IdleFragment()
    //     0x6c5020: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5024: r1 = <Widget>
    //     0x6c5024: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6c5028: r2 = 26
    //     0x6c5028: movz            x2, #0x1a
    // 0x6c502c: stur            x0, [fp, #-0x10]
    // 0x6c5030: r0 = AllocateArray()
    //     0x6c5030: bl              #0x82746c  ; AllocateArrayStub
    // 0x6c5034: mov             x1, x0
    // 0x6c5038: ldur            x0, [fp, #-0x10]
    // 0x6c503c: stur            x1, [fp, #-0x20]
    // 0x6c5040: StoreField: r1->field_f = r0
    //     0x6c5040: stur            w0, [x1, #0xf]
    // 0x6c5044: r0 = ManualButton()
    //     0x6c5044: bl              #0x69a8c4  ; AllocateManualButtonStub -> ManualButton (size=0x24)
    // 0x6c5048: ldur            x2, [fp, #-8]
    // 0x6c504c: r1 = Function 'pastedText':.
    //     0x6c504c: add             x1, PP, #0x26, lsl #12  ; [pp+0x260c8] AnonymousClosure: (0x6c71fc), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::pastedText (0x6c7234)
    //     0x6c5050: ldr             x1, [x1, #0xc8]
    // 0x6c5054: stur            x0, [fp, #-0x10]
    // 0x6c5058: r0 = AllocateClosure()
    //     0x6c5058: bl              #0x826750  ; AllocateClosureStub
    // 0x6c505c: mov             x1, x0
    // 0x6c5060: ldur            x0, [fp, #-0x10]
    // 0x6c5064: StoreField: r0->field_b = r1
    //     0x6c5064: stur            w1, [x0, #0xb]
    // 0x6c5068: r1 = Instance_TextStyle
    //     0x6c5068: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d0] Obj!TextStyle@8490c1
    //     0x6c506c: ldr             x1, [x1, #0xd0]
    // 0x6c5070: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5070: stur            w1, [x0, #0x17]
    // 0x6c5074: r1 = Instance_ValueKey
    //     0x6c5074: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d8] Obj!ValueKey<String>@833f81
    //     0x6c5078: ldr             x1, [x1, #0xd8]
    // 0x6c507c: StoreField: r0->field_7 = r1
    //     0x6c507c: stur            w1, [x0, #7]
    // 0x6c5080: r0 = Padding()
    //     0x6c5080: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6c5084: mov             x3, x0
    // 0x6c5088: r0 = Instance_EdgeInsets
    //     0x6c5088: add             x0, PP, #0x25, lsl #12  ; [pp+0x25a28] Obj!EdgeInsets@832041
    //     0x6c508c: ldr             x0, [x0, #0xa28]
    // 0x6c5090: stur            x3, [fp, #-0x28]
    // 0x6c5094: StoreField: r3->field_f = r0
    //     0x6c5094: stur            w0, [x3, #0xf]
    // 0x6c5098: ldur            x0, [fp, #-0x10]
    // 0x6c509c: StoreField: r3->field_b = r0
    //     0x6c509c: stur            w0, [x3, #0xb]
    // 0x6c50a0: r1 = Function '<anonymous closure>':.
    //     0x6c50a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x260e0] AnonymousClosure: (0x6c71a4), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c50a4: ldr             x1, [x1, #0xe0]
    // 0x6c50a8: r2 = Null
    //     0x6c50a8: mov             x2, NULL
    // 0x6c50ac: r0 = AllocateClosure()
    //     0x6c50ac: bl              #0x826750  ; AllocateClosureStub
    // 0x6c50b0: r16 = false
    //     0x6c50b0: add             x16, NULL, #0x30  ; false
    // 0x6c50b4: str             x16, [SP]
    // 0x6c50b8: ldur            x2, [fp, #-0x28]
    // 0x6c50bc: mov             x5, x0
    // 0x6c50c0: r1 = Null
    //     0x6c50c0: mov             x1, NULL
    // 0x6c50c4: r3 = "Ch9 Copy Paste"
    //     0x6c50c4: add             x3, PP, #0x26, lsl #12  ; [pp+0x260e8] "Ch9 Copy Paste"
    //     0x6c50c8: ldr             x3, [x3, #0xe8]
    // 0x6c50cc: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6c50cc: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6c50d0: ldr             x4, [x4, #0xf0]
    // 0x6c50d4: r0 = IdleFragment()
    //     0x6c50d4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c50d8: ldur            x1, [fp, #-0x20]
    // 0x6c50dc: ArrayStore: r1[1] = r0  ; List_4
    //     0x6c50dc: add             x25, x1, #0x13
    //     0x6c50e0: str             w0, [x25]
    //     0x6c50e4: tbz             w0, #0, #0x6c5100
    //     0x6c50e8: ldurb           w16, [x1, #-1]
    //     0x6c50ec: ldurb           w17, [x0, #-1]
    //     0x6c50f0: and             x16, x17, x16, lsr #2
    //     0x6c50f4: tst             x16, HEAP, lsr #32
    //     0x6c50f8: b.eq            #0x6c5100
    //     0x6c50fc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5100: ldur            x2, [fp, #-8]
    // 0x6c5104: LoadField: r0 = r2->field_2b
    //     0x6c5104: ldur            w0, [x2, #0x2b]
    // 0x6c5108: DecompressPointer r0
    //     0x6c5108: add             x0, x0, HEAP, lsl #32
    // 0x6c510c: stur            x0, [fp, #-0x60]
    // 0x6c5110: LoadField: r3 = r2->field_37
    //     0x6c5110: ldur            w3, [x2, #0x37]
    // 0x6c5114: DecompressPointer r3
    //     0x6c5114: add             x3, x3, HEAP, lsl #32
    // 0x6c5118: stur            x3, [fp, #-0x58]
    // 0x6c511c: LoadField: r4 = r2->field_7
    //     0x6c511c: ldur            w4, [x2, #7]
    // 0x6c5120: DecompressPointer r4
    //     0x6c5120: add             x4, x4, HEAP, lsl #32
    // 0x6c5124: stur            x4, [fp, #-0x50]
    // 0x6c5128: LoadField: r5 = r2->field_4b
    //     0x6c5128: ldur            w5, [x2, #0x4b]
    // 0x6c512c: DecompressPointer r5
    //     0x6c512c: add             x5, x5, HEAP, lsl #32
    // 0x6c5130: stur            x5, [fp, #-0x48]
    // 0x6c5134: LoadField: r6 = r2->field_47
    //     0x6c5134: ldur            w6, [x2, #0x47]
    // 0x6c5138: DecompressPointer r6
    //     0x6c5138: add             x6, x6, HEAP, lsl #32
    // 0x6c513c: stur            x6, [fp, #-0x40]
    // 0x6c5140: LoadField: r7 = r2->field_53
    //     0x6c5140: ldur            w7, [x2, #0x53]
    // 0x6c5144: DecompressPointer r7
    //     0x6c5144: add             x7, x7, HEAP, lsl #32
    // 0x6c5148: stur            x7, [fp, #-0x38]
    // 0x6c514c: LoadField: r8 = r2->field_33
    //     0x6c514c: ldur            w8, [x2, #0x33]
    // 0x6c5150: DecompressPointer r8
    //     0x6c5150: add             x8, x8, HEAP, lsl #32
    // 0x6c5154: stur            x8, [fp, #-0x30]
    // 0x6c5158: LoadField: r9 = r2->field_2f
    //     0x6c5158: ldur            w9, [x2, #0x2f]
    // 0x6c515c: DecompressPointer r9
    //     0x6c515c: add             x9, x9, HEAP, lsl #32
    // 0x6c5160: stur            x9, [fp, #-0x28]
    // 0x6c5164: LoadField: r10 = r2->field_93
    //     0x6c5164: ldur            w10, [x2, #0x93]
    // 0x6c5168: DecompressPointer r10
    //     0x6c5168: add             x10, x10, HEAP, lsl #32
    // 0x6c516c: stur            x10, [fp, #-0x10]
    // 0x6c5170: r1 = <Chapter9Stat>
    //     0x6c5170: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5174: ldr             x1, [x1, #0xe48]
    // 0x6c5178: r0 = GeneratorGroup()
    //     0x6c5178: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6c517c: mov             x3, x0
    // 0x6c5180: ldur            x0, [fp, #-0x58]
    // 0x6c5184: stur            x3, [fp, #-0x68]
    // 0x6c5188: StoreField: r3->field_1f = r0
    //     0x6c5188: stur            w0, [x3, #0x1f]
    // 0x6c518c: ldur            x2, [fp, #-8]
    // 0x6c5190: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x6c5190: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c918] AnonymousClosure: (0x3dd8c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getCostToBuyOneMoreGenerator (0x3dd774)
    //     0x6c5194: ldr             x1, [x1, #0x918]
    // 0x6c5198: r0 = AllocateClosure()
    //     0x6c5198: bl              #0x826750  ; AllocateClosureStub
    // 0x6c519c: mov             x3, x0
    // 0x6c51a0: ldur            x0, [fp, #-0x68]
    // 0x6c51a4: stur            x3, [fp, #-0x58]
    // 0x6c51a8: StoreField: r0->field_23 = r3
    //     0x6c51a8: stur            w3, [x0, #0x23]
    // 0x6c51ac: ldur            x2, [fp, #-8]
    // 0x6c51b0: r1 = Function 'getGeneratorInfo':.
    //     0x6c51b0: add             x1, PP, #0x26, lsl #12  ; [pp+0x260f8] AnonymousClosure: (0x6c7168), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getGeneratorInfo (0x80dac0)
    //     0x6c51b4: ldr             x1, [x1, #0xf8]
    // 0x6c51b8: r0 = AllocateClosure()
    //     0x6c51b8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c51bc: mov             x3, x0
    // 0x6c51c0: ldur            x0, [fp, #-0x68]
    // 0x6c51c4: stur            x3, [fp, #-0x70]
    // 0x6c51c8: StoreField: r0->field_27 = r3
    //     0x6c51c8: stur            w3, [x0, #0x27]
    // 0x6c51cc: ldur            x1, [fp, #-0x48]
    // 0x6c51d0: StoreField: r0->field_2b = r1
    //     0x6c51d0: stur            w1, [x0, #0x2b]
    // 0x6c51d4: ldur            x1, [fp, #-0x40]
    // 0x6c51d8: StoreField: r0->field_2f = r1
    //     0x6c51d8: stur            w1, [x0, #0x2f]
    // 0x6c51dc: ldur            x1, [fp, #-0x38]
    // 0x6c51e0: StoreField: r0->field_33 = r1
    //     0x6c51e0: stur            w1, [x0, #0x33]
    // 0x6c51e4: r1 = Function '<anonymous closure>':.
    //     0x6c51e4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26100] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6c51e8: ldr             x1, [x1, #0x100]
    // 0x6c51ec: r2 = Null
    //     0x6c51ec: mov             x2, NULL
    // 0x6c51f0: r0 = AllocateClosure()
    //     0x6c51f0: bl              #0x826750  ; AllocateClosureStub
    // 0x6c51f4: mov             x1, x0
    // 0x6c51f8: ldur            x0, [fp, #-0x68]
    // 0x6c51fc: StoreField: r0->field_3b = r1
    //     0x6c51fc: stur            w1, [x0, #0x3b]
    // 0x6c5200: ldur            x3, [fp, #-0x30]
    // 0x6c5204: StoreField: r0->field_43 = r3
    //     0x6c5204: stur            w3, [x0, #0x43]
    // 0x6c5208: ldur            x4, [fp, #-0x28]
    // 0x6c520c: StoreField: r0->field_47 = r4
    //     0x6c520c: stur            w4, [x0, #0x47]
    // 0x6c5210: ldur            x2, [fp, #-8]
    // 0x6c5214: r1 = Function 'buyGenerator':.
    //     0x6c5214: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x6c5218: ldr             x1, [x1, #0x108]
    // 0x6c521c: r0 = AllocateClosure()
    //     0x6c521c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5220: mov             x3, x0
    // 0x6c5224: ldur            x0, [fp, #-0x68]
    // 0x6c5228: stur            x3, [fp, #-0x38]
    // 0x6c522c: StoreField: r0->field_5b = r3
    //     0x6c522c: stur            w3, [x0, #0x5b]
    // 0x6c5230: r1 = Function '<anonymous closure>':.
    //     0x6c5230: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5234: ldr             x1, [x1, #0x110]
    // 0x6c5238: r2 = Null
    //     0x6c5238: mov             x2, NULL
    // 0x6c523c: r0 = AllocateClosure()
    //     0x6c523c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5240: mov             x1, x0
    // 0x6c5244: ldur            x0, [fp, #-0x68]
    // 0x6c5248: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5248: stur            w1, [x0, #0x17]
    // 0x6c524c: r1 = Function '<anonymous closure>':.
    //     0x6c524c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5250: ldr             x1, [x1, #0x118]
    // 0x6c5254: r2 = Null
    //     0x6c5254: mov             x2, NULL
    // 0x6c5258: r0 = AllocateClosure()
    //     0x6c5258: bl              #0x826750  ; AllocateClosureStub
    // 0x6c525c: mov             x1, x0
    // 0x6c5260: ldur            x0, [fp, #-0x68]
    // 0x6c5264: StoreField: r0->field_1b = r1
    //     0x6c5264: stur            w1, [x0, #0x1b]
    // 0x6c5268: ldur            x2, [fp, #-8]
    // 0x6c526c: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x6c526c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x6c5270: ldr             x1, [x1, #0x120]
    // 0x6c5274: r0 = AllocateClosure()
    //     0x6c5274: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5278: mov             x4, x0
    // 0x6c527c: ldur            x0, [fp, #-0x68]
    // 0x6c5280: stur            x4, [fp, #-0x40]
    // 0x6c5284: StoreField: r0->field_57 = r4
    //     0x6c5284: stur            w4, [x0, #0x57]
    // 0x6c5288: r1 = const [0x1, 0x2, 0x3, 0x4, 0x5]
    //     0x6c5288: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] List<int>(5)
    //     0x6c528c: ldr             x1, [x1, #0x128]
    // 0x6c5290: StoreField: r0->field_53 = r1
    //     0x6c5290: stur            w1, [x0, #0x53]
    // 0x6c5294: ldur            x2, [fp, #-8]
    // 0x6c5298: ldur            x3, [fp, #-0x50]
    // 0x6c529c: r1 = Function 'getGeneratorSingleYieldsBoosted':.
    //     0x6c529c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0x54a720), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted (0x54a520)
    //     0x6c52a0: ldr             x1, [x1, #0x130]
    // 0x6c52a4: r0 = AllocateClosureTA()
    //     0x6c52a4: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x6c52a8: mov             x4, x0
    // 0x6c52ac: ldur            x0, [fp, #-0x68]
    // 0x6c52b0: stur            x4, [fp, #-0x48]
    // 0x6c52b4: StoreField: r0->field_6b = r4
    //     0x6c52b4: stur            w4, [x0, #0x6b]
    // 0x6c52b8: ldur            x1, [fp, #-0x60]
    // 0x6c52bc: StoreField: r0->field_4b = r1
    //     0x6c52bc: stur            w1, [x0, #0x4b]
    // 0x6c52c0: ldur            x1, [fp, #-0x10]
    // 0x6c52c4: StoreField: r0->field_67 = r1
    //     0x6c52c4: stur            w1, [x0, #0x67]
    // 0x6c52c8: ldur            x2, [fp, #-8]
    // 0x6c52cc: ldur            x3, [fp, #-0x50]
    // 0x6c52d0: r1 = Function 'getGeneratorBaseCost':.
    //     0x6c52d0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x6c52d4: ldr             x1, [x1, #0x138]
    // 0x6c52d8: r0 = AllocateClosureTA()
    //     0x6c52d8: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x6c52dc: mov             x3, x0
    // 0x6c52e0: ldur            x0, [fp, #-0x68]
    // 0x6c52e4: stur            x3, [fp, #-0x10]
    // 0x6c52e8: StoreField: r0->field_77 = r3
    //     0x6c52e8: stur            w3, [x0, #0x77]
    // 0x6c52ec: ldur            x2, [fp, #-8]
    // 0x6c52f0: r1 = Function 'getGeneratorMultiplier':.
    //     0x6c52f0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x6c52f4: ldr             x1, [x1, #0x140]
    // 0x6c52f8: r0 = AllocateClosure()
    //     0x6c52f8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c52fc: mov             x3, x0
    // 0x6c5300: ldur            x0, [fp, #-0x68]
    // 0x6c5304: stur            x3, [fp, #-0x50]
    // 0x6c5308: StoreField: r0->field_7b = r3
    //     0x6c5308: stur            w3, [x0, #0x7b]
    // 0x6c530c: r4 = "Chapter 9 Generators 1"
    //     0x6c530c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26148] "Chapter 9 Generators 1"
    //     0x6c5310: ldr             x4, [x4, #0x148]
    // 0x6c5314: StoreField: r0->field_73 = r4
    //     0x6c5314: stur            w4, [x0, #0x73]
    // 0x6c5318: r1 = Function '<anonymous closure>':.
    //     0x6c5318: add             x1, PP, #0x26, lsl #12  ; [pp+0x26150] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6c531c: ldr             x1, [x1, #0x150]
    // 0x6c5320: r2 = Null
    //     0x6c5320: mov             x2, NULL
    // 0x6c5324: r0 = AllocateClosure()
    //     0x6c5324: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5328: ldur            x2, [fp, #-0x18]
    // 0x6c532c: r1 = Function '<anonymous closure>':.
    //     0x6c532c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26158] AnonymousClosure: (0x69473c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5330: ldr             x1, [x1, #0x158]
    // 0x6c5334: stur            x0, [fp, #-0x60]
    // 0x6c5338: r0 = AllocateClosure()
    //     0x6c5338: bl              #0x826750  ; AllocateClosureStub
    // 0x6c533c: str             x0, [SP]
    // 0x6c5340: ldur            x2, [fp, #-0x68]
    // 0x6c5344: ldur            x5, [fp, #-0x60]
    // 0x6c5348: r1 = Null
    //     0x6c5348: mov             x1, NULL
    // 0x6c534c: r3 = "Chapter 9 Generators 1"
    //     0x6c534c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26148] "Chapter 9 Generators 1"
    //     0x6c5350: ldr             x3, [x3, #0x148]
    // 0x6c5354: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6c5354: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6c5358: ldr             x4, [x4, #0x160]
    // 0x6c535c: r0 = IdleFragment()
    //     0x6c535c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5360: ldur            x1, [fp, #-0x20]
    // 0x6c5364: ArrayStore: r1[2] = r0  ; List_4
    //     0x6c5364: add             x25, x1, #0x17
    //     0x6c5368: str             w0, [x25]
    //     0x6c536c: tbz             w0, #0, #0x6c5388
    //     0x6c5370: ldurb           w16, [x1, #-1]
    //     0x6c5374: ldurb           w17, [x0, #-1]
    //     0x6c5378: and             x16, x17, x16, lsr #2
    //     0x6c537c: tst             x16, HEAP, lsr #32
    //     0x6c5380: b.eq            #0x6c5388
    //     0x6c5384: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5388: ldur            x2, [fp, #-8]
    // 0x6c538c: LoadField: r0 = r2->field_37
    //     0x6c538c: ldur            w0, [x2, #0x37]
    // 0x6c5390: DecompressPointer r0
    //     0x6c5390: add             x0, x0, HEAP, lsl #32
    // 0x6c5394: stur            x0, [fp, #-0x78]
    // 0x6c5398: LoadField: r3 = r2->field_43
    //     0x6c5398: ldur            w3, [x2, #0x43]
    // 0x6c539c: DecompressPointer r3
    //     0x6c539c: add             x3, x3, HEAP, lsl #32
    // 0x6c53a0: stur            x3, [fp, #-0x68]
    // 0x6c53a4: LoadField: r4 = r2->field_8f
    //     0x6c53a4: ldur            w4, [x2, #0x8f]
    // 0x6c53a8: DecompressPointer r4
    //     0x6c53a8: add             x4, x4, HEAP, lsl #32
    // 0x6c53ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c53b0: cmp             w4, w16
    // 0x6c53b4: b.eq            #0x6c6124
    // 0x6c53b8: stur            x4, [fp, #-0x60]
    // 0x6c53bc: r1 = <Chapter9Stat>
    //     0x6c53bc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c53c0: ldr             x1, [x1, #0xe48]
    // 0x6c53c4: r0 = UpgradeGroup()
    //     0x6c53c4: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6c53c8: mov             x3, x0
    // 0x6c53cc: r0 = 1
    //     0x6c53cc: movz            x0, #0x1
    // 0x6c53d0: stur            x3, [fp, #-0x80]
    // 0x6c53d4: StoreField: r3->field_13 = r0
    //     0x6c53d4: stur            x0, [x3, #0x13]
    // 0x6c53d8: ldur            x1, [fp, #-0x60]
    // 0x6c53dc: StoreField: r3->field_1b = r1
    //     0x6c53dc: stur            w1, [x3, #0x1b]
    // 0x6c53e0: ldur            x1, [fp, #-0x78]
    // 0x6c53e4: StoreField: r3->field_1f = r1
    //     0x6c53e4: stur            w1, [x3, #0x1f]
    // 0x6c53e8: ldur            x1, [fp, #-0x68]
    // 0x6c53ec: StoreField: r3->field_23 = r1
    //     0x6c53ec: stur            w1, [x3, #0x23]
    // 0x6c53f0: r1 = Function '<anonymous closure>':.
    //     0x6c53f0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26168] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c53f4: ldr             x1, [x1, #0x168]
    // 0x6c53f8: r2 = Null
    //     0x6c53f8: mov             x2, NULL
    // 0x6c53fc: r0 = AllocateClosure()
    //     0x6c53fc: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5400: mov             x1, x0
    // 0x6c5404: ldur            x0, [fp, #-0x80]
    // 0x6c5408: StoreField: r0->field_2b = r1
    //     0x6c5408: stur            w1, [x0, #0x2b]
    // 0x6c540c: r1 = const [0x1, 0x2]
    //     0x6c540c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] List<int>(2)
    //     0x6c5410: ldr             x1, [x1, #0x170]
    // 0x6c5414: StoreField: r0->field_f = r1
    //     0x6c5414: stur            w1, [x0, #0xf]
    // 0x6c5418: r3 = true
    //     0x6c5418: add             x3, NULL, #0x20  ; true
    // 0x6c541c: StoreField: r0->field_27 = r3
    //     0x6c541c: stur            w3, [x0, #0x27]
    // 0x6c5420: r4 = Instance_UpgradeDisplayMode
    //     0x6c5420: add             x4, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x6c5424: ldr             x4, [x4, #0x608]
    // 0x6c5428: StoreField: r0->field_2f = r4
    //     0x6c5428: stur            w4, [x0, #0x2f]
    // 0x6c542c: r5 = false
    //     0x6c542c: add             x5, NULL, #0x30  ; false
    // 0x6c5430: StoreField: r0->field_33 = r5
    //     0x6c5430: stur            w5, [x0, #0x33]
    // 0x6c5434: ldur            x2, [fp, #-0x18]
    // 0x6c5438: r1 = Function '<anonymous closure>':.
    //     0x6c5438: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0x69b1c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c543c: ldr             x1, [x1, #0x178]
    // 0x6c5440: r0 = AllocateClosure()
    //     0x6c5440: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5444: ldur            x2, [fp, #-0x18]
    // 0x6c5448: r1 = Function '<anonymous closure>':.
    //     0x6c5448: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0x6c703c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c544c: ldr             x1, [x1, #0x180]
    // 0x6c5450: stur            x0, [fp, #-0x60]
    // 0x6c5454: r0 = AllocateClosure()
    //     0x6c5454: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5458: r16 = false
    //     0x6c5458: add             x16, NULL, #0x30  ; false
    // 0x6c545c: stp             x0, x16, [SP]
    // 0x6c5460: ldur            x2, [fp, #-0x80]
    // 0x6c5464: ldur            x5, [fp, #-0x60]
    // 0x6c5468: r1 = Null
    //     0x6c5468: mov             x1, NULL
    // 0x6c546c: r3 = "Chapter 9 Upgrades 1"
    //     0x6c546c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26188] "Chapter 9 Upgrades 1"
    //     0x6c5470: ldr             x3, [x3, #0x188]
    // 0x6c5474: r4 = const [0, 0x6, 0x2, 0x4, generateMinimizedName, 0x5, scrollToBottomOnUnlock, 0x4, null]
    //     0x6c5474: add             x4, PP, #0x26, lsl #12  ; [pp+0x260c0] List(9) [0, 0x6, 0x2, 0x4, "generateMinimizedName", 0x5, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6c5478: ldr             x4, [x4, #0xc0]
    // 0x6c547c: r0 = IdleFragment()
    //     0x6c547c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5480: ldur            x1, [fp, #-0x20]
    // 0x6c5484: ArrayStore: r1[3] = r0  ; List_4
    //     0x6c5484: add             x25, x1, #0x1b
    //     0x6c5488: str             w0, [x25]
    //     0x6c548c: tbz             w0, #0, #0x6c54a8
    //     0x6c5490: ldurb           w16, [x1, #-1]
    //     0x6c5494: ldurb           w17, [x0, #-1]
    //     0x6c5498: and             x16, x17, x16, lsr #2
    //     0x6c549c: tst             x16, HEAP, lsr #32
    //     0x6c54a0: b.eq            #0x6c54a8
    //     0x6c54a4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c54a8: ldur            x0, [fp, #-8]
    // 0x6c54ac: LoadField: r3 = r0->field_37
    //     0x6c54ac: ldur            w3, [x0, #0x37]
    // 0x6c54b0: DecompressPointer r3
    //     0x6c54b0: add             x3, x3, HEAP, lsl #32
    // 0x6c54b4: stur            x3, [fp, #-0x60]
    // 0x6c54b8: r1 = Function '<anonymous closure>':.
    //     0x6c54b8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26190] AnonymousClosure: (0x6aafac), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c54bc: ldr             x1, [x1, #0x190]
    // 0x6c54c0: r2 = Null
    //     0x6c54c0: mov             x2, NULL
    // 0x6c54c4: r0 = AllocateClosure()
    //     0x6c54c4: bl              #0x826750  ; AllocateClosureStub
    // 0x6c54c8: r1 = <Chapter9Stat>
    //     0x6c54c8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c54cc: ldr             x1, [x1, #0xe48]
    // 0x6c54d0: stur            x0, [fp, #-0x68]
    // 0x6c54d4: r0 = PrestigeButton()
    //     0x6c54d4: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6c54d8: mov             x3, x0
    // 0x6c54dc: ldur            x0, [fp, #-0x68]
    // 0x6c54e0: stur            x3, [fp, #-0x78]
    // 0x6c54e4: StoreField: r3->field_1f = r0
    //     0x6c54e4: stur            w0, [x3, #0x1f]
    // 0x6c54e8: r0 = Instance_Chapter9Stat
    //     0x6c54e8: add             x0, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c54ec: ldr             x0, [x0, #0x8a0]
    // 0x6c54f0: StoreField: r3->field_1b = r0
    //     0x6c54f0: stur            w0, [x3, #0x1b]
    // 0x6c54f4: ldur            x2, [fp, #-8]
    // 0x6c54f8: r1 = Function 'knowledgeOnRewrite':.
    //     0x6c54f8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26198] AnonymousClosure: (0x6c7004), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::knowledgeOnRewrite (0x6c6b44)
    //     0x6c54fc: ldr             x1, [x1, #0x198]
    // 0x6c5500: r0 = AllocateClosure()
    //     0x6c5500: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5504: mov             x1, x0
    // 0x6c5508: ldur            x0, [fp, #-0x78]
    // 0x6c550c: StoreField: r0->field_2f = r1
    //     0x6c550c: stur            w1, [x0, #0x2f]
    // 0x6c5510: ldur            x2, [fp, #-8]
    // 0x6c5514: r1 = Function 'prestige1':.
    //     0x6c5514: add             x1, PP, #0x26, lsl #12  ; [pp+0x261a0] AnonymousClosure: (0x6c6fcc), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::prestige1 (0x6c6898)
    //     0x6c5518: ldr             x1, [x1, #0x1a0]
    // 0x6c551c: r0 = AllocateClosure()
    //     0x6c551c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5520: mov             x1, x0
    // 0x6c5524: ldur            x0, [fp, #-0x78]
    // 0x6c5528: StoreField: r0->field_33 = r1
    //     0x6c5528: stur            w1, [x0, #0x33]
    // 0x6c552c: ldur            x1, [fp, #-0x60]
    // 0x6c5530: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5530: stur            w1, [x0, #0x17]
    // 0x6c5534: r3 = Closure: (Chapter9Stat?) => String from Function 'humanName': static.
    //     0x6c5534: add             x3, PP, #0x26, lsl #12  ; [pp+0x260a0] Closure: (Chapter9Stat?) => String from Function 'humanName': static. (0x248ed99e608)
    //     0x6c5538: ldr             x3, [x3, #0xa0]
    // 0x6c553c: StoreField: r0->field_43 = r3
    //     0x6c553c: stur            w3, [x0, #0x43]
    // 0x6c5540: r1 = Function '<anonymous closure>':.
    //     0x6c5540: add             x1, PP, #0x26, lsl #12  ; [pp+0x261a8] AnonymousClosure: (0x6c6fc0), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5544: ldr             x1, [x1, #0x1a8]
    // 0x6c5548: r2 = Null
    //     0x6c5548: mov             x2, NULL
    // 0x6c554c: r0 = AllocateClosure()
    //     0x6c554c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5550: mov             x1, x0
    // 0x6c5554: ldur            x0, [fp, #-0x78]
    // 0x6c5558: StoreField: r0->field_23 = r1
    //     0x6c5558: stur            w1, [x0, #0x23]
    // 0x6c555c: r3 = "everything above"
    //     0x6c555c: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x6c5560: ldr             x3, [x3, #0x1b0]
    // 0x6c5564: StoreField: r0->field_3f = r3
    //     0x6c5564: stur            w3, [x0, #0x3f]
    // 0x6c5568: r4 = false
    //     0x6c5568: add             x4, NULL, #0x30  ; false
    // 0x6c556c: StoreField: r0->field_f = r4
    //     0x6c556c: stur            w4, [x0, #0xf]
    // 0x6c5570: StoreField: r0->field_4f = r4
    //     0x6c5570: stur            w4, [x0, #0x4f]
    // 0x6c5574: r5 = true
    //     0x6c5574: add             x5, NULL, #0x20  ; true
    // 0x6c5578: StoreField: r0->field_2b = r5
    //     0x6c5578: stur            w5, [x0, #0x2b]
    // 0x6c557c: StoreField: r0->field_53 = r4
    //     0x6c557c: stur            w4, [x0, #0x53]
    // 0x6c5580: StoreField: r0->field_5b = r5
    //     0x6c5580: stur            w5, [x0, #0x5b]
    // 0x6c5584: r6 = "Gain"
    //     0x6c5584: add             x6, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6c5588: ldr             x6, [x6, #0x1b8]
    // 0x6c558c: StoreField: r0->field_5f = r6
    //     0x6c558c: stur            w6, [x0, #0x5f]
    // 0x6c5590: ldur            x2, [fp, #-0x18]
    // 0x6c5594: r1 = Function '<anonymous closure>':.
    //     0x6c5594: add             x1, PP, #0x26, lsl #12  ; [pp+0x261c0] AnonymousClosure: (0x6c4390), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5598: ldr             x1, [x1, #0x1c0]
    // 0x6c559c: r0 = AllocateClosure()
    //     0x6c559c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c55a0: r16 = false
    //     0x6c55a0: add             x16, NULL, #0x30  ; false
    // 0x6c55a4: str             x16, [SP]
    // 0x6c55a8: ldur            x2, [fp, #-0x78]
    // 0x6c55ac: mov             x5, x0
    // 0x6c55b0: r1 = Null
    //     0x6c55b0: mov             x1, NULL
    // 0x6c55b4: r3 = "Chapter 9 Prestige 1"
    //     0x6c55b4: add             x3, PP, #0x26, lsl #12  ; [pp+0x261c8] "Chapter 9 Prestige 1"
    //     0x6c55b8: ldr             x3, [x3, #0x1c8]
    // 0x6c55bc: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6c55bc: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6c55c0: ldr             x4, [x4, #0xf0]
    // 0x6c55c4: r0 = IdleFragment()
    //     0x6c55c4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c55c8: ldur            x1, [fp, #-0x20]
    // 0x6c55cc: ArrayStore: r1[4] = r0  ; List_4
    //     0x6c55cc: add             x25, x1, #0x1f
    //     0x6c55d0: str             w0, [x25]
    //     0x6c55d4: tbz             w0, #0, #0x6c55f0
    //     0x6c55d8: ldurb           w16, [x1, #-1]
    //     0x6c55dc: ldurb           w17, [x0, #-1]
    //     0x6c55e0: and             x16, x17, x16, lsr #2
    //     0x6c55e4: tst             x16, HEAP, lsr #32
    //     0x6c55e8: b.eq            #0x6c55f0
    //     0x6c55ec: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c55f0: ldur            x2, [fp, #-8]
    // 0x6c55f4: LoadField: r0 = r2->field_2b
    //     0x6c55f4: ldur            w0, [x2, #0x2b]
    // 0x6c55f8: DecompressPointer r0
    //     0x6c55f8: add             x0, x0, HEAP, lsl #32
    // 0x6c55fc: stur            x0, [fp, #-0x60]
    // 0x6c5600: r0 = CurrencyCounter()
    //     0x6c5600: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x6c5604: mov             x3, x0
    // 0x6c5608: r0 = "Data"
    //     0x6c5608: add             x0, PP, #0x11, lsl #12  ; [pp+0x113a8] "Data"
    //     0x6c560c: ldr             x0, [x0, #0x3a8]
    // 0x6c5610: stur            x3, [fp, #-0x68]
    // 0x6c5614: StoreField: r3->field_b = r0
    //     0x6c5614: stur            w0, [x3, #0xb]
    // 0x6c5618: ldur            x2, [fp, #-0x18]
    // 0x6c561c: r1 = Function '<anonymous closure>':.
    //     0x6c561c: add             x1, PP, #0x26, lsl #12  ; [pp+0x261d0] AnonymousClosure: (0x6c6f08), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5620: ldr             x1, [x1, #0x1d0]
    // 0x6c5624: r0 = AllocateClosure()
    //     0x6c5624: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5628: mov             x1, x0
    // 0x6c562c: ldur            x0, [fp, #-0x68]
    // 0x6c5630: StoreField: r0->field_f = r1
    //     0x6c5630: stur            w1, [x0, #0xf]
    // 0x6c5634: r1 = Function '<anonymous closure>':.
    //     0x6c5634: add             x1, PP, #0x26, lsl #12  ; [pp+0x261d8] AnonymousClosure: (0x6c6efc), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5638: ldr             x1, [x1, #0x1d8]
    // 0x6c563c: r2 = Null
    //     0x6c563c: mov             x2, NULL
    // 0x6c5640: r0 = AllocateClosure()
    //     0x6c5640: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5644: mov             x1, x0
    // 0x6c5648: ldur            x0, [fp, #-0x68]
    // 0x6c564c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c564c: stur            w1, [x0, #0x17]
    // 0x6c5650: r2 = false
    //     0x6c5650: add             x2, NULL, #0x30  ; false
    // 0x6c5654: StoreField: r0->field_1f = r2
    //     0x6c5654: stur            w2, [x0, #0x1f]
    // 0x6c5658: ldur            x3, [fp, #-8]
    // 0x6c565c: LoadField: r4 = r3->field_37
    //     0x6c565c: ldur            w4, [x3, #0x37]
    // 0x6c5660: DecompressPointer r4
    //     0x6c5660: add             x4, x4, HEAP, lsl #32
    // 0x6c5664: stur            x4, [fp, #-0x98]
    // 0x6c5668: LoadField: r5 = r3->field_4b
    //     0x6c5668: ldur            w5, [x3, #0x4b]
    // 0x6c566c: DecompressPointer r5
    //     0x6c566c: add             x5, x5, HEAP, lsl #32
    // 0x6c5670: stur            x5, [fp, #-0x90]
    // 0x6c5674: LoadField: r6 = r3->field_47
    //     0x6c5674: ldur            w6, [x3, #0x47]
    // 0x6c5678: DecompressPointer r6
    //     0x6c5678: add             x6, x6, HEAP, lsl #32
    // 0x6c567c: stur            x6, [fp, #-0x88]
    // 0x6c5680: LoadField: r7 = r3->field_53
    //     0x6c5680: ldur            w7, [x3, #0x53]
    // 0x6c5684: DecompressPointer r7
    //     0x6c5684: add             x7, x7, HEAP, lsl #32
    // 0x6c5688: stur            x7, [fp, #-0x80]
    // 0x6c568c: LoadField: r8 = r3->field_93
    //     0x6c568c: ldur            w8, [x3, #0x93]
    // 0x6c5690: DecompressPointer r8
    //     0x6c5690: add             x8, x8, HEAP, lsl #32
    // 0x6c5694: stur            x8, [fp, #-0x78]
    // 0x6c5698: r1 = <Chapter9Stat>
    //     0x6c5698: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c569c: ldr             x1, [x1, #0xe48]
    // 0x6c56a0: r0 = GeneratorGroup()
    //     0x6c56a0: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6c56a4: mov             x3, x0
    // 0x6c56a8: ldur            x0, [fp, #-0x98]
    // 0x6c56ac: stur            x3, [fp, #-0xa0]
    // 0x6c56b0: StoreField: r3->field_1f = r0
    //     0x6c56b0: stur            w0, [x3, #0x1f]
    // 0x6c56b4: ldur            x0, [fp, #-0x58]
    // 0x6c56b8: StoreField: r3->field_23 = r0
    //     0x6c56b8: stur            w0, [x3, #0x23]
    // 0x6c56bc: ldur            x4, [fp, #-0x70]
    // 0x6c56c0: StoreField: r3->field_27 = r4
    //     0x6c56c0: stur            w4, [x3, #0x27]
    // 0x6c56c4: ldur            x1, [fp, #-0x90]
    // 0x6c56c8: StoreField: r3->field_2b = r1
    //     0x6c56c8: stur            w1, [x3, #0x2b]
    // 0x6c56cc: ldur            x1, [fp, #-0x88]
    // 0x6c56d0: StoreField: r3->field_2f = r1
    //     0x6c56d0: stur            w1, [x3, #0x2f]
    // 0x6c56d4: ldur            x1, [fp, #-0x80]
    // 0x6c56d8: StoreField: r3->field_33 = r1
    //     0x6c56d8: stur            w1, [x3, #0x33]
    // 0x6c56dc: r1 = Function '<anonymous closure>':.
    //     0x6c56dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x261e0] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6c56e0: ldr             x1, [x1, #0x1e0]
    // 0x6c56e4: r2 = Null
    //     0x6c56e4: mov             x2, NULL
    // 0x6c56e8: r0 = AllocateClosure()
    //     0x6c56e8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c56ec: mov             x1, x0
    // 0x6c56f0: ldur            x0, [fp, #-0xa0]
    // 0x6c56f4: StoreField: r0->field_3b = r1
    //     0x6c56f4: stur            w1, [x0, #0x3b]
    // 0x6c56f8: ldur            x3, [fp, #-0x30]
    // 0x6c56fc: StoreField: r0->field_43 = r3
    //     0x6c56fc: stur            w3, [x0, #0x43]
    // 0x6c5700: ldur            x4, [fp, #-0x28]
    // 0x6c5704: StoreField: r0->field_47 = r4
    //     0x6c5704: stur            w4, [x0, #0x47]
    // 0x6c5708: ldur            x5, [fp, #-0x38]
    // 0x6c570c: StoreField: r0->field_5b = r5
    //     0x6c570c: stur            w5, [x0, #0x5b]
    // 0x6c5710: r1 = Function '<anonymous closure>':.
    //     0x6c5710: add             x1, PP, #0x26, lsl #12  ; [pp+0x261e8] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5714: ldr             x1, [x1, #0x1e8]
    // 0x6c5718: r2 = Null
    //     0x6c5718: mov             x2, NULL
    // 0x6c571c: r0 = AllocateClosure()
    //     0x6c571c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5720: mov             x1, x0
    // 0x6c5724: ldur            x0, [fp, #-0xa0]
    // 0x6c5728: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5728: stur            w1, [x0, #0x17]
    // 0x6c572c: r1 = Function '<anonymous closure>':.
    //     0x6c572c: add             x1, PP, #0x26, lsl #12  ; [pp+0x261f0] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5730: ldr             x1, [x1, #0x1f0]
    // 0x6c5734: r2 = Null
    //     0x6c5734: mov             x2, NULL
    // 0x6c5738: r0 = AllocateClosure()
    //     0x6c5738: bl              #0x826750  ; AllocateClosureStub
    // 0x6c573c: mov             x1, x0
    // 0x6c5740: ldur            x0, [fp, #-0xa0]
    // 0x6c5744: StoreField: r0->field_1b = r1
    //     0x6c5744: stur            w1, [x0, #0x1b]
    // 0x6c5748: ldur            x3, [fp, #-0x40]
    // 0x6c574c: StoreField: r0->field_57 = r3
    //     0x6c574c: stur            w3, [x0, #0x57]
    // 0x6c5750: r1 = const [0xb, 0xc, 0xd, 0xe]
    //     0x6c5750: add             x1, PP, #0x26, lsl #12  ; [pp+0x261f8] List<int>(4)
    //     0x6c5754: ldr             x1, [x1, #0x1f8]
    // 0x6c5758: StoreField: r0->field_53 = r1
    //     0x6c5758: stur            w1, [x0, #0x53]
    // 0x6c575c: ldur            x4, [fp, #-0x48]
    // 0x6c5760: StoreField: r0->field_6b = r4
    //     0x6c5760: stur            w4, [x0, #0x6b]
    // 0x6c5764: ldur            x1, [fp, #-0x60]
    // 0x6c5768: StoreField: r0->field_4b = r1
    //     0x6c5768: stur            w1, [x0, #0x4b]
    // 0x6c576c: ldur            x1, [fp, #-0x68]
    // 0x6c5770: StoreField: r0->field_f = r1
    //     0x6c5770: stur            w1, [x0, #0xf]
    // 0x6c5774: ldur            x1, [fp, #-0x78]
    // 0x6c5778: StoreField: r0->field_67 = r1
    //     0x6c5778: stur            w1, [x0, #0x67]
    // 0x6c577c: ldur            x5, [fp, #-0x10]
    // 0x6c5780: StoreField: r0->field_77 = r5
    //     0x6c5780: stur            w5, [x0, #0x77]
    // 0x6c5784: ldur            x6, [fp, #-0x50]
    // 0x6c5788: StoreField: r0->field_7b = r6
    //     0x6c5788: stur            w6, [x0, #0x7b]
    // 0x6c578c: r7 = "Chapter 9 Generators 2"
    //     0x6c578c: add             x7, PP, #0x26, lsl #12  ; [pp+0x26200] "Chapter 9 Generators 2"
    //     0x6c5790: ldr             x7, [x7, #0x200]
    // 0x6c5794: StoreField: r0->field_73 = r7
    //     0x6c5794: stur            w7, [x0, #0x73]
    // 0x6c5798: ldur            x2, [fp, #-0x18]
    // 0x6c579c: r1 = Function '<anonymous closure>':.
    //     0x6c579c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26208] AnonymousClosure: (0x6c4390), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c57a0: ldr             x1, [x1, #0x208]
    // 0x6c57a4: r0 = AllocateClosure()
    //     0x6c57a4: bl              #0x826750  ; AllocateClosureStub
    // 0x6c57a8: r16 = false
    //     0x6c57a8: add             x16, NULL, #0x30  ; false
    // 0x6c57ac: str             x16, [SP]
    // 0x6c57b0: ldur            x2, [fp, #-0xa0]
    // 0x6c57b4: mov             x5, x0
    // 0x6c57b8: r1 = Null
    //     0x6c57b8: mov             x1, NULL
    // 0x6c57bc: r3 = "Chapter 9 Generators 2"
    //     0x6c57bc: add             x3, PP, #0x26, lsl #12  ; [pp+0x26200] "Chapter 9 Generators 2"
    //     0x6c57c0: ldr             x3, [x3, #0x200]
    // 0x6c57c4: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6c57c4: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6c57c8: ldr             x4, [x4, #0xf0]
    // 0x6c57cc: r0 = IdleFragment()
    //     0x6c57cc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c57d0: ldur            x1, [fp, #-0x20]
    // 0x6c57d4: ArrayStore: r1[5] = r0  ; List_4
    //     0x6c57d4: add             x25, x1, #0x23
    //     0x6c57d8: str             w0, [x25]
    //     0x6c57dc: tbz             w0, #0, #0x6c57f8
    //     0x6c57e0: ldurb           w16, [x1, #-1]
    //     0x6c57e4: ldurb           w17, [x0, #-1]
    //     0x6c57e8: and             x16, x17, x16, lsr #2
    //     0x6c57ec: tst             x16, HEAP, lsr #32
    //     0x6c57f0: b.eq            #0x6c57f8
    //     0x6c57f4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c57f8: ldur            x2, [fp, #-8]
    // 0x6c57fc: LoadField: r0 = r2->field_37
    //     0x6c57fc: ldur            w0, [x2, #0x37]
    // 0x6c5800: DecompressPointer r0
    //     0x6c5800: add             x0, x0, HEAP, lsl #32
    // 0x6c5804: stur            x0, [fp, #-0x78]
    // 0x6c5808: LoadField: r3 = r2->field_43
    //     0x6c5808: ldur            w3, [x2, #0x43]
    // 0x6c580c: DecompressPointer r3
    //     0x6c580c: add             x3, x3, HEAP, lsl #32
    // 0x6c5810: stur            x3, [fp, #-0x68]
    // 0x6c5814: LoadField: r4 = r2->field_8f
    //     0x6c5814: ldur            w4, [x2, #0x8f]
    // 0x6c5818: DecompressPointer r4
    //     0x6c5818: add             x4, x4, HEAP, lsl #32
    // 0x6c581c: stur            x4, [fp, #-0x60]
    // 0x6c5820: r1 = <Chapter9Stat>
    //     0x6c5820: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5824: ldr             x1, [x1, #0xe48]
    // 0x6c5828: r0 = UpgradeGroup()
    //     0x6c5828: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6c582c: mov             x3, x0
    // 0x6c5830: r0 = 1
    //     0x6c5830: movz            x0, #0x1
    // 0x6c5834: stur            x3, [fp, #-0x80]
    // 0x6c5838: StoreField: r3->field_13 = r0
    //     0x6c5838: stur            x0, [x3, #0x13]
    // 0x6c583c: ldur            x1, [fp, #-0x60]
    // 0x6c5840: StoreField: r3->field_1b = r1
    //     0x6c5840: stur            w1, [x3, #0x1b]
    // 0x6c5844: ldur            x1, [fp, #-0x78]
    // 0x6c5848: StoreField: r3->field_1f = r1
    //     0x6c5848: stur            w1, [x3, #0x1f]
    // 0x6c584c: ldur            x1, [fp, #-0x68]
    // 0x6c5850: StoreField: r3->field_23 = r1
    //     0x6c5850: stur            w1, [x3, #0x23]
    // 0x6c5854: r1 = Function '<anonymous closure>':.
    //     0x6c5854: add             x1, PP, #0x26, lsl #12  ; [pp+0x26210] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5858: ldr             x1, [x1, #0x210]
    // 0x6c585c: r2 = Null
    //     0x6c585c: mov             x2, NULL
    // 0x6c5860: r0 = AllocateClosure()
    //     0x6c5860: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5864: mov             x1, x0
    // 0x6c5868: ldur            x0, [fp, #-0x80]
    // 0x6c586c: StoreField: r0->field_2b = r1
    //     0x6c586c: stur            w1, [x0, #0x2b]
    // 0x6c5870: r1 = const [0xb, 0xc]
    //     0x6c5870: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] List<int>(2)
    //     0x6c5874: ldr             x1, [x1, #0x218]
    // 0x6c5878: StoreField: r0->field_f = r1
    //     0x6c5878: stur            w1, [x0, #0xf]
    // 0x6c587c: r3 = true
    //     0x6c587c: add             x3, NULL, #0x20  ; true
    // 0x6c5880: StoreField: r0->field_27 = r3
    //     0x6c5880: stur            w3, [x0, #0x27]
    // 0x6c5884: r4 = Instance_UpgradeDisplayMode
    //     0x6c5884: add             x4, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x6c5888: ldr             x4, [x4, #0x608]
    // 0x6c588c: StoreField: r0->field_2f = r4
    //     0x6c588c: stur            w4, [x0, #0x2f]
    // 0x6c5890: r5 = false
    //     0x6c5890: add             x5, NULL, #0x30  ; false
    // 0x6c5894: StoreField: r0->field_33 = r5
    //     0x6c5894: stur            w5, [x0, #0x33]
    // 0x6c5898: ldur            x2, [fp, #-0x18]
    // 0x6c589c: r1 = Function '<anonymous closure>':.
    //     0x6c589c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26220] AnonymousClosure: (0x699680), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c58a0: ldr             x1, [x1, #0x220]
    // 0x6c58a4: r0 = AllocateClosure()
    //     0x6c58a4: bl              #0x826750  ; AllocateClosureStub
    // 0x6c58a8: ldur            x2, [fp, #-0x18]
    // 0x6c58ac: r1 = Function '<anonymous closure>':.
    //     0x6c58ac: add             x1, PP, #0x26, lsl #12  ; [pp+0x26228] AnonymousClosure: (0x6c6dd0), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c58b0: ldr             x1, [x1, #0x228]
    // 0x6c58b4: stur            x0, [fp, #-0x60]
    // 0x6c58b8: r0 = AllocateClosure()
    //     0x6c58b8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c58bc: str             x0, [SP]
    // 0x6c58c0: ldur            x2, [fp, #-0x80]
    // 0x6c58c4: ldur            x5, [fp, #-0x60]
    // 0x6c58c8: r1 = Null
    //     0x6c58c8: mov             x1, NULL
    // 0x6c58cc: r3 = "Chapter 9 Upgrades 2"
    //     0x6c58cc: add             x3, PP, #0x26, lsl #12  ; [pp+0x26230] "Chapter 9 Upgrades 2"
    //     0x6c58d0: ldr             x3, [x3, #0x230]
    // 0x6c58d4: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6c58d4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6c58d8: ldr             x4, [x4, #0x160]
    // 0x6c58dc: r0 = IdleFragment()
    //     0x6c58dc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c58e0: ldur            x1, [fp, #-0x20]
    // 0x6c58e4: ArrayStore: r1[6] = r0  ; List_4
    //     0x6c58e4: add             x25, x1, #0x27
    //     0x6c58e8: str             w0, [x25]
    //     0x6c58ec: tbz             w0, #0, #0x6c5908
    //     0x6c58f0: ldurb           w16, [x1, #-1]
    //     0x6c58f4: ldurb           w17, [x0, #-1]
    //     0x6c58f8: and             x16, x17, x16, lsr #2
    //     0x6c58fc: tst             x16, HEAP, lsr #32
    //     0x6c5900: b.eq            #0x6c5908
    //     0x6c5904: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5908: ldur            x0, [fp, #-8]
    // 0x6c590c: LoadField: r3 = r0->field_37
    //     0x6c590c: ldur            w3, [x0, #0x37]
    // 0x6c5910: DecompressPointer r3
    //     0x6c5910: add             x3, x3, HEAP, lsl #32
    // 0x6c5914: stur            x3, [fp, #-0x60]
    // 0x6c5918: r1 = Function '<anonymous closure>':.
    //     0x6c5918: add             x1, PP, #0x26, lsl #12  ; [pp+0x26238] AnonymousClosure: (0x6aa0c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c591c: ldr             x1, [x1, #0x238]
    // 0x6c5920: r2 = Null
    //     0x6c5920: mov             x2, NULL
    // 0x6c5924: r0 = AllocateClosure()
    //     0x6c5924: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5928: r1 = <Chapter9Stat>
    //     0x6c5928: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c592c: ldr             x1, [x1, #0xe48]
    // 0x6c5930: stur            x0, [fp, #-0x68]
    // 0x6c5934: r0 = PrestigeButton()
    //     0x6c5934: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6c5938: mov             x3, x0
    // 0x6c593c: ldur            x0, [fp, #-0x68]
    // 0x6c5940: stur            x3, [fp, #-0x78]
    // 0x6c5944: StoreField: r3->field_1f = r0
    //     0x6c5944: stur            w0, [x3, #0x1f]
    // 0x6c5948: r0 = Instance_Chapter9Stat
    //     0x6c5948: add             x0, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x6c594c: ldr             x0, [x0, #0x8f0]
    // 0x6c5950: StoreField: r3->field_1b = r0
    //     0x6c5950: stur            w0, [x3, #0x1b]
    // 0x6c5954: ldur            x2, [fp, #-8]
    // 0x6c5958: r1 = Function 'capitalOnProject':.
    //     0x6c5958: add             x1, PP, #0x26, lsl #12  ; [pp+0x26240] AnonymousClosure: (0x6c6d98), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::capitalOnProject (0x6c6bd4)
    //     0x6c595c: ldr             x1, [x1, #0x240]
    // 0x6c5960: r0 = AllocateClosure()
    //     0x6c5960: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5964: mov             x1, x0
    // 0x6c5968: ldur            x0, [fp, #-0x78]
    // 0x6c596c: StoreField: r0->field_2f = r1
    //     0x6c596c: stur            w1, [x0, #0x2f]
    // 0x6c5970: ldur            x2, [fp, #-8]
    // 0x6c5974: r1 = Function 'prestige2':.
    //     0x6c5974: add             x1, PP, #0x26, lsl #12  ; [pp+0x26248] AnonymousClosure: (0x6c653c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::prestige2 (0x6c6574)
    //     0x6c5978: ldr             x1, [x1, #0x248]
    // 0x6c597c: r0 = AllocateClosure()
    //     0x6c597c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5980: mov             x1, x0
    // 0x6c5984: ldur            x0, [fp, #-0x78]
    // 0x6c5988: StoreField: r0->field_33 = r1
    //     0x6c5988: stur            w1, [x0, #0x33]
    // 0x6c598c: ldur            x1, [fp, #-0x60]
    // 0x6c5990: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5990: stur            w1, [x0, #0x17]
    // 0x6c5994: r3 = Closure: (Chapter9Stat?) => String from Function 'humanName': static.
    //     0x6c5994: add             x3, PP, #0x26, lsl #12  ; [pp+0x260a0] Closure: (Chapter9Stat?) => String from Function 'humanName': static. (0x248ed99e608)
    //     0x6c5998: ldr             x3, [x3, #0xa0]
    // 0x6c599c: StoreField: r0->field_43 = r3
    //     0x6c599c: stur            w3, [x0, #0x43]
    // 0x6c59a0: r1 = Function '<anonymous closure>':.
    //     0x6c59a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26250] AnonymousClosure: (0x6c6530), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c59a4: ldr             x1, [x1, #0x250]
    // 0x6c59a8: r2 = Null
    //     0x6c59a8: mov             x2, NULL
    // 0x6c59ac: r0 = AllocateClosure()
    //     0x6c59ac: bl              #0x826750  ; AllocateClosureStub
    // 0x6c59b0: mov             x1, x0
    // 0x6c59b4: ldur            x0, [fp, #-0x78]
    // 0x6c59b8: StoreField: r0->field_23 = r1
    //     0x6c59b8: stur            w1, [x0, #0x23]
    // 0x6c59bc: r1 = "everything above"
    //     0x6c59bc: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x6c59c0: ldr             x1, [x1, #0x1b0]
    // 0x6c59c4: StoreField: r0->field_3f = r1
    //     0x6c59c4: stur            w1, [x0, #0x3f]
    // 0x6c59c8: r3 = false
    //     0x6c59c8: add             x3, NULL, #0x30  ; false
    // 0x6c59cc: StoreField: r0->field_f = r3
    //     0x6c59cc: stur            w3, [x0, #0xf]
    // 0x6c59d0: StoreField: r0->field_4f = r3
    //     0x6c59d0: stur            w3, [x0, #0x4f]
    // 0x6c59d4: r4 = true
    //     0x6c59d4: add             x4, NULL, #0x20  ; true
    // 0x6c59d8: StoreField: r0->field_2b = r4
    //     0x6c59d8: stur            w4, [x0, #0x2b]
    // 0x6c59dc: StoreField: r0->field_53 = r3
    //     0x6c59dc: stur            w3, [x0, #0x53]
    // 0x6c59e0: StoreField: r0->field_5b = r4
    //     0x6c59e0: stur            w4, [x0, #0x5b]
    // 0x6c59e4: r1 = "Gain"
    //     0x6c59e4: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6c59e8: ldr             x1, [x1, #0x1b8]
    // 0x6c59ec: StoreField: r0->field_5f = r1
    //     0x6c59ec: stur            w1, [x0, #0x5f]
    // 0x6c59f0: ldur            x2, [fp, #-0x18]
    // 0x6c59f4: r1 = Function '<anonymous closure>':.
    //     0x6c59f4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26258] AnonymousClosure: (0x6c64e4), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c59f8: ldr             x1, [x1, #0x258]
    // 0x6c59fc: r0 = AllocateClosure()
    //     0x6c59fc: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5a00: r16 = false
    //     0x6c5a00: add             x16, NULL, #0x30  ; false
    // 0x6c5a04: str             x16, [SP]
    // 0x6c5a08: ldur            x2, [fp, #-0x78]
    // 0x6c5a0c: mov             x5, x0
    // 0x6c5a10: r1 = Null
    //     0x6c5a10: mov             x1, NULL
    // 0x6c5a14: r3 = "Chapter 9 Prestige 2"
    //     0x6c5a14: add             x3, PP, #0x26, lsl #12  ; [pp+0x26260] "Chapter 9 Prestige 2"
    //     0x6c5a18: ldr             x3, [x3, #0x260]
    // 0x6c5a1c: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6c5a1c: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6c5a20: ldr             x4, [x4, #0xf0]
    // 0x6c5a24: r0 = IdleFragment()
    //     0x6c5a24: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5a28: ldur            x1, [fp, #-0x20]
    // 0x6c5a2c: ArrayStore: r1[7] = r0  ; List_4
    //     0x6c5a2c: add             x25, x1, #0x2b
    //     0x6c5a30: str             w0, [x25]
    //     0x6c5a34: tbz             w0, #0, #0x6c5a50
    //     0x6c5a38: ldurb           w16, [x1, #-1]
    //     0x6c5a3c: ldurb           w17, [x0, #-1]
    //     0x6c5a40: and             x16, x17, x16, lsr #2
    //     0x6c5a44: tst             x16, HEAP, lsr #32
    //     0x6c5a48: b.eq            #0x6c5a50
    //     0x6c5a4c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5a50: ldur            x0, [fp, #-8]
    // 0x6c5a54: LoadField: r2 = r0->field_2b
    //     0x6c5a54: ldur            w2, [x0, #0x2b]
    // 0x6c5a58: DecompressPointer r2
    //     0x6c5a58: add             x2, x2, HEAP, lsl #32
    // 0x6c5a5c: stur            x2, [fp, #-0x90]
    // 0x6c5a60: LoadField: r3 = r0->field_37
    //     0x6c5a60: ldur            w3, [x0, #0x37]
    // 0x6c5a64: DecompressPointer r3
    //     0x6c5a64: add             x3, x3, HEAP, lsl #32
    // 0x6c5a68: stur            x3, [fp, #-0x88]
    // 0x6c5a6c: LoadField: r4 = r0->field_4b
    //     0x6c5a6c: ldur            w4, [x0, #0x4b]
    // 0x6c5a70: DecompressPointer r4
    //     0x6c5a70: add             x4, x4, HEAP, lsl #32
    // 0x6c5a74: stur            x4, [fp, #-0x80]
    // 0x6c5a78: LoadField: r5 = r0->field_47
    //     0x6c5a78: ldur            w5, [x0, #0x47]
    // 0x6c5a7c: DecompressPointer r5
    //     0x6c5a7c: add             x5, x5, HEAP, lsl #32
    // 0x6c5a80: stur            x5, [fp, #-0x78]
    // 0x6c5a84: LoadField: r6 = r0->field_53
    //     0x6c5a84: ldur            w6, [x0, #0x53]
    // 0x6c5a88: DecompressPointer r6
    //     0x6c5a88: add             x6, x6, HEAP, lsl #32
    // 0x6c5a8c: stur            x6, [fp, #-0x68]
    // 0x6c5a90: LoadField: r7 = r0->field_93
    //     0x6c5a90: ldur            w7, [x0, #0x93]
    // 0x6c5a94: DecompressPointer r7
    //     0x6c5a94: add             x7, x7, HEAP, lsl #32
    // 0x6c5a98: stur            x7, [fp, #-0x60]
    // 0x6c5a9c: r1 = <Chapter9Stat>
    //     0x6c5a9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5aa0: ldr             x1, [x1, #0xe48]
    // 0x6c5aa4: r0 = GeneratorGroup()
    //     0x6c5aa4: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6c5aa8: mov             x3, x0
    // 0x6c5aac: ldur            x0, [fp, #-0x88]
    // 0x6c5ab0: stur            x3, [fp, #-0x98]
    // 0x6c5ab4: StoreField: r3->field_1f = r0
    //     0x6c5ab4: stur            w0, [x3, #0x1f]
    // 0x6c5ab8: ldur            x0, [fp, #-0x58]
    // 0x6c5abc: StoreField: r3->field_23 = r0
    //     0x6c5abc: stur            w0, [x3, #0x23]
    // 0x6c5ac0: ldur            x4, [fp, #-0x70]
    // 0x6c5ac4: StoreField: r3->field_27 = r4
    //     0x6c5ac4: stur            w4, [x3, #0x27]
    // 0x6c5ac8: ldur            x1, [fp, #-0x80]
    // 0x6c5acc: StoreField: r3->field_2b = r1
    //     0x6c5acc: stur            w1, [x3, #0x2b]
    // 0x6c5ad0: ldur            x1, [fp, #-0x78]
    // 0x6c5ad4: StoreField: r3->field_2f = r1
    //     0x6c5ad4: stur            w1, [x3, #0x2f]
    // 0x6c5ad8: ldur            x1, [fp, #-0x68]
    // 0x6c5adc: StoreField: r3->field_33 = r1
    //     0x6c5adc: stur            w1, [x3, #0x33]
    // 0x6c5ae0: r1 = Function '<anonymous closure>':.
    //     0x6c5ae0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26268] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6c5ae4: ldr             x1, [x1, #0x268]
    // 0x6c5ae8: r2 = Null
    //     0x6c5ae8: mov             x2, NULL
    // 0x6c5aec: r0 = AllocateClosure()
    //     0x6c5aec: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5af0: mov             x1, x0
    // 0x6c5af4: ldur            x0, [fp, #-0x98]
    // 0x6c5af8: StoreField: r0->field_3b = r1
    //     0x6c5af8: stur            w1, [x0, #0x3b]
    // 0x6c5afc: ldur            x3, [fp, #-0x30]
    // 0x6c5b00: StoreField: r0->field_43 = r3
    //     0x6c5b00: stur            w3, [x0, #0x43]
    // 0x6c5b04: ldur            x4, [fp, #-0x28]
    // 0x6c5b08: StoreField: r0->field_47 = r4
    //     0x6c5b08: stur            w4, [x0, #0x47]
    // 0x6c5b0c: ldur            x5, [fp, #-0x38]
    // 0x6c5b10: StoreField: r0->field_5b = r5
    //     0x6c5b10: stur            w5, [x0, #0x5b]
    // 0x6c5b14: r1 = Function '<anonymous closure>':.
    //     0x6c5b14: add             x1, PP, #0x26, lsl #12  ; [pp+0x26270] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5b18: ldr             x1, [x1, #0x270]
    // 0x6c5b1c: r2 = Null
    //     0x6c5b1c: mov             x2, NULL
    // 0x6c5b20: r0 = AllocateClosure()
    //     0x6c5b20: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5b24: mov             x1, x0
    // 0x6c5b28: ldur            x0, [fp, #-0x98]
    // 0x6c5b2c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5b2c: stur            w1, [x0, #0x17]
    // 0x6c5b30: r1 = Function '<anonymous closure>':.
    //     0x6c5b30: add             x1, PP, #0x26, lsl #12  ; [pp+0x26278] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5b34: ldr             x1, [x1, #0x278]
    // 0x6c5b38: r2 = Null
    //     0x6c5b38: mov             x2, NULL
    // 0x6c5b3c: r0 = AllocateClosure()
    //     0x6c5b3c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5b40: mov             x1, x0
    // 0x6c5b44: ldur            x0, [fp, #-0x98]
    // 0x6c5b48: StoreField: r0->field_1b = r1
    //     0x6c5b48: stur            w1, [x0, #0x1b]
    // 0x6c5b4c: ldur            x3, [fp, #-0x40]
    // 0x6c5b50: StoreField: r0->field_57 = r3
    //     0x6c5b50: stur            w3, [x0, #0x57]
    // 0x6c5b54: r1 = const [0x15, 0x16, 0x17, 0x18, 0x19]
    //     0x6c5b54: add             x1, PP, #0x26, lsl #12  ; [pp+0x26280] List<int>(5)
    //     0x6c5b58: ldr             x1, [x1, #0x280]
    // 0x6c5b5c: StoreField: r0->field_53 = r1
    //     0x6c5b5c: stur            w1, [x0, #0x53]
    // 0x6c5b60: ldur            x4, [fp, #-0x48]
    // 0x6c5b64: StoreField: r0->field_6b = r4
    //     0x6c5b64: stur            w4, [x0, #0x6b]
    // 0x6c5b68: ldur            x1, [fp, #-0x90]
    // 0x6c5b6c: StoreField: r0->field_4b = r1
    //     0x6c5b6c: stur            w1, [x0, #0x4b]
    // 0x6c5b70: ldur            x1, [fp, #-0x60]
    // 0x6c5b74: StoreField: r0->field_67 = r1
    //     0x6c5b74: stur            w1, [x0, #0x67]
    // 0x6c5b78: ldur            x5, [fp, #-0x10]
    // 0x6c5b7c: StoreField: r0->field_77 = r5
    //     0x6c5b7c: stur            w5, [x0, #0x77]
    // 0x6c5b80: ldur            x6, [fp, #-0x50]
    // 0x6c5b84: StoreField: r0->field_7b = r6
    //     0x6c5b84: stur            w6, [x0, #0x7b]
    // 0x6c5b88: r7 = "Chapter 9 Generators 3"
    //     0x6c5b88: add             x7, PP, #0x26, lsl #12  ; [pp+0x26288] "Chapter 9 Generators 3"
    //     0x6c5b8c: ldr             x7, [x7, #0x288]
    // 0x6c5b90: StoreField: r0->field_73 = r7
    //     0x6c5b90: stur            w7, [x0, #0x73]
    // 0x6c5b94: ldur            x2, [fp, #-0x18]
    // 0x6c5b98: r1 = Function '<anonymous closure>':.
    //     0x6c5b98: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0x697f00), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5b9c: ldr             x1, [x1, #0x290]
    // 0x6c5ba0: r0 = AllocateClosure()
    //     0x6c5ba0: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5ba4: ldur            x2, [fp, #-0x98]
    // 0x6c5ba8: mov             x5, x0
    // 0x6c5bac: r1 = Null
    //     0x6c5bac: mov             x1, NULL
    // 0x6c5bb0: r3 = "Chapter 9 Generators 3"
    //     0x6c5bb0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26288] "Chapter 9 Generators 3"
    //     0x6c5bb4: ldr             x3, [x3, #0x288]
    // 0x6c5bb8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6c5bb8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6c5bbc: r0 = IdleFragment()
    //     0x6c5bbc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5bc0: ldur            x1, [fp, #-0x20]
    // 0x6c5bc4: ArrayStore: r1[8] = r0  ; List_4
    //     0x6c5bc4: add             x25, x1, #0x2f
    //     0x6c5bc8: str             w0, [x25]
    //     0x6c5bcc: tbz             w0, #0, #0x6c5be8
    //     0x6c5bd0: ldurb           w16, [x1, #-1]
    //     0x6c5bd4: ldurb           w17, [x0, #-1]
    //     0x6c5bd8: and             x16, x17, x16, lsr #2
    //     0x6c5bdc: tst             x16, HEAP, lsr #32
    //     0x6c5be0: b.eq            #0x6c5be8
    //     0x6c5be4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5be8: ldur            x0, [fp, #-8]
    // 0x6c5bec: LoadField: r2 = r0->field_37
    //     0x6c5bec: ldur            w2, [x0, #0x37]
    // 0x6c5bf0: DecompressPointer r2
    //     0x6c5bf0: add             x2, x2, HEAP, lsl #32
    // 0x6c5bf4: stur            x2, [fp, #-0x78]
    // 0x6c5bf8: LoadField: r3 = r0->field_43
    //     0x6c5bf8: ldur            w3, [x0, #0x43]
    // 0x6c5bfc: DecompressPointer r3
    //     0x6c5bfc: add             x3, x3, HEAP, lsl #32
    // 0x6c5c00: stur            x3, [fp, #-0x68]
    // 0x6c5c04: LoadField: r4 = r0->field_8f
    //     0x6c5c04: ldur            w4, [x0, #0x8f]
    // 0x6c5c08: DecompressPointer r4
    //     0x6c5c08: add             x4, x4, HEAP, lsl #32
    // 0x6c5c0c: stur            x4, [fp, #-0x60]
    // 0x6c5c10: r1 = <Chapter9Stat>
    //     0x6c5c10: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5c14: ldr             x1, [x1, #0xe48]
    // 0x6c5c18: r0 = UpgradeGroup()
    //     0x6c5c18: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6c5c1c: mov             x3, x0
    // 0x6c5c20: r0 = 1
    //     0x6c5c20: movz            x0, #0x1
    // 0x6c5c24: stur            x3, [fp, #-0x80]
    // 0x6c5c28: StoreField: r3->field_13 = r0
    //     0x6c5c28: stur            x0, [x3, #0x13]
    // 0x6c5c2c: ldur            x1, [fp, #-0x60]
    // 0x6c5c30: StoreField: r3->field_1b = r1
    //     0x6c5c30: stur            w1, [x3, #0x1b]
    // 0x6c5c34: ldur            x1, [fp, #-0x78]
    // 0x6c5c38: StoreField: r3->field_1f = r1
    //     0x6c5c38: stur            w1, [x3, #0x1f]
    // 0x6c5c3c: ldur            x1, [fp, #-0x68]
    // 0x6c5c40: StoreField: r3->field_23 = r1
    //     0x6c5c40: stur            w1, [x3, #0x23]
    // 0x6c5c44: r1 = Function '<anonymous closure>':.
    //     0x6c5c44: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5c48: ldr             x1, [x1, #0x298]
    // 0x6c5c4c: r2 = Null
    //     0x6c5c4c: mov             x2, NULL
    // 0x6c5c50: r0 = AllocateClosure()
    //     0x6c5c50: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5c54: mov             x1, x0
    // 0x6c5c58: ldur            x0, [fp, #-0x80]
    // 0x6c5c5c: StoreField: r0->field_2b = r1
    //     0x6c5c5c: stur            w1, [x0, #0x2b]
    // 0x6c5c60: r1 = const [0x15, 0x16]
    //     0x6c5c60: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] List<int>(2)
    //     0x6c5c64: ldr             x1, [x1, #0x2a0]
    // 0x6c5c68: StoreField: r0->field_f = r1
    //     0x6c5c68: stur            w1, [x0, #0xf]
    // 0x6c5c6c: r3 = true
    //     0x6c5c6c: add             x3, NULL, #0x20  ; true
    // 0x6c5c70: StoreField: r0->field_27 = r3
    //     0x6c5c70: stur            w3, [x0, #0x27]
    // 0x6c5c74: r1 = Instance_UpgradeDisplayMode
    //     0x6c5c74: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x6c5c78: ldr             x1, [x1, #0x608]
    // 0x6c5c7c: StoreField: r0->field_2f = r1
    //     0x6c5c7c: stur            w1, [x0, #0x2f]
    // 0x6c5c80: r4 = false
    //     0x6c5c80: add             x4, NULL, #0x30  ; false
    // 0x6c5c84: StoreField: r0->field_33 = r4
    //     0x6c5c84: stur            w4, [x0, #0x33]
    // 0x6c5c88: ldur            x2, [fp, #-0x18]
    // 0x6c5c8c: r1 = Function '<anonymous closure>':.
    //     0x6c5c8c: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a8] AnonymousClosure: (0x697f00), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5c90: ldr             x1, [x1, #0x2a8]
    // 0x6c5c94: r0 = AllocateClosure()
    //     0x6c5c94: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5c98: ldur            x2, [fp, #-0x18]
    // 0x6c5c9c: r1 = Function '<anonymous closure>':.
    //     0x6c5c9c: add             x1, PP, #0x26, lsl #12  ; [pp+0x262b0] AnonymousClosure: (0x6c63b8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5ca0: ldr             x1, [x1, #0x2b0]
    // 0x6c5ca4: stur            x0, [fp, #-0x60]
    // 0x6c5ca8: r0 = AllocateClosure()
    //     0x6c5ca8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5cac: str             x0, [SP]
    // 0x6c5cb0: ldur            x2, [fp, #-0x80]
    // 0x6c5cb4: ldur            x5, [fp, #-0x60]
    // 0x6c5cb8: r1 = Null
    //     0x6c5cb8: mov             x1, NULL
    // 0x6c5cbc: r3 = "Chapter 9 Upgrades 3"
    //     0x6c5cbc: add             x3, PP, #0x26, lsl #12  ; [pp+0x262b8] "Chapter 9 Upgrades 3"
    //     0x6c5cc0: ldr             x3, [x3, #0x2b8]
    // 0x6c5cc4: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6c5cc4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6c5cc8: ldr             x4, [x4, #0x160]
    // 0x6c5ccc: r0 = IdleFragment()
    //     0x6c5ccc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5cd0: ldur            x1, [fp, #-0x20]
    // 0x6c5cd4: ArrayStore: r1[9] = r0  ; List_4
    //     0x6c5cd4: add             x25, x1, #0x33
    //     0x6c5cd8: str             w0, [x25]
    //     0x6c5cdc: tbz             w0, #0, #0x6c5cf8
    //     0x6c5ce0: ldurb           w16, [x1, #-1]
    //     0x6c5ce4: ldurb           w17, [x0, #-1]
    //     0x6c5ce8: and             x16, x17, x16, lsr #2
    //     0x6c5cec: tst             x16, HEAP, lsr #32
    //     0x6c5cf0: b.eq            #0x6c5cf8
    //     0x6c5cf4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5cf8: ldur            x0, [fp, #-8]
    // 0x6c5cfc: LoadField: r2 = r0->field_2b
    //     0x6c5cfc: ldur            w2, [x0, #0x2b]
    // 0x6c5d00: DecompressPointer r2
    //     0x6c5d00: add             x2, x2, HEAP, lsl #32
    // 0x6c5d04: stur            x2, [fp, #-0x90]
    // 0x6c5d08: LoadField: r3 = r0->field_37
    //     0x6c5d08: ldur            w3, [x0, #0x37]
    // 0x6c5d0c: DecompressPointer r3
    //     0x6c5d0c: add             x3, x3, HEAP, lsl #32
    // 0x6c5d10: stur            x3, [fp, #-0x88]
    // 0x6c5d14: LoadField: r4 = r0->field_4b
    //     0x6c5d14: ldur            w4, [x0, #0x4b]
    // 0x6c5d18: DecompressPointer r4
    //     0x6c5d18: add             x4, x4, HEAP, lsl #32
    // 0x6c5d1c: stur            x4, [fp, #-0x80]
    // 0x6c5d20: LoadField: r5 = r0->field_47
    //     0x6c5d20: ldur            w5, [x0, #0x47]
    // 0x6c5d24: DecompressPointer r5
    //     0x6c5d24: add             x5, x5, HEAP, lsl #32
    // 0x6c5d28: stur            x5, [fp, #-0x78]
    // 0x6c5d2c: LoadField: r6 = r0->field_53
    //     0x6c5d2c: ldur            w6, [x0, #0x53]
    // 0x6c5d30: DecompressPointer r6
    //     0x6c5d30: add             x6, x6, HEAP, lsl #32
    // 0x6c5d34: stur            x6, [fp, #-0x68]
    // 0x6c5d38: LoadField: r7 = r0->field_93
    //     0x6c5d38: ldur            w7, [x0, #0x93]
    // 0x6c5d3c: DecompressPointer r7
    //     0x6c5d3c: add             x7, x7, HEAP, lsl #32
    // 0x6c5d40: stur            x7, [fp, #-0x60]
    // 0x6c5d44: r1 = <Chapter9Stat>
    //     0x6c5d44: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5d48: ldr             x1, [x1, #0xe48]
    // 0x6c5d4c: r0 = GeneratorGroup()
    //     0x6c5d4c: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6c5d50: mov             x3, x0
    // 0x6c5d54: ldur            x0, [fp, #-0x88]
    // 0x6c5d58: stur            x3, [fp, #-0x98]
    // 0x6c5d5c: StoreField: r3->field_1f = r0
    //     0x6c5d5c: stur            w0, [x3, #0x1f]
    // 0x6c5d60: ldur            x0, [fp, #-0x58]
    // 0x6c5d64: StoreField: r3->field_23 = r0
    //     0x6c5d64: stur            w0, [x3, #0x23]
    // 0x6c5d68: ldur            x0, [fp, #-0x70]
    // 0x6c5d6c: StoreField: r3->field_27 = r0
    //     0x6c5d6c: stur            w0, [x3, #0x27]
    // 0x6c5d70: ldur            x0, [fp, #-0x80]
    // 0x6c5d74: StoreField: r3->field_2b = r0
    //     0x6c5d74: stur            w0, [x3, #0x2b]
    // 0x6c5d78: ldur            x0, [fp, #-0x78]
    // 0x6c5d7c: StoreField: r3->field_2f = r0
    //     0x6c5d7c: stur            w0, [x3, #0x2f]
    // 0x6c5d80: ldur            x0, [fp, #-0x68]
    // 0x6c5d84: StoreField: r3->field_33 = r0
    //     0x6c5d84: stur            w0, [x3, #0x33]
    // 0x6c5d88: r1 = Function '<anonymous closure>':.
    //     0x6c5d88: add             x1, PP, #0x26, lsl #12  ; [pp+0x262c0] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6c5d8c: ldr             x1, [x1, #0x2c0]
    // 0x6c5d90: r2 = Null
    //     0x6c5d90: mov             x2, NULL
    // 0x6c5d94: r0 = AllocateClosure()
    //     0x6c5d94: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5d98: mov             x1, x0
    // 0x6c5d9c: ldur            x0, [fp, #-0x98]
    // 0x6c5da0: StoreField: r0->field_3b = r1
    //     0x6c5da0: stur            w1, [x0, #0x3b]
    // 0x6c5da4: ldur            x1, [fp, #-0x30]
    // 0x6c5da8: StoreField: r0->field_43 = r1
    //     0x6c5da8: stur            w1, [x0, #0x43]
    // 0x6c5dac: ldur            x1, [fp, #-0x28]
    // 0x6c5db0: StoreField: r0->field_47 = r1
    //     0x6c5db0: stur            w1, [x0, #0x47]
    // 0x6c5db4: ldur            x1, [fp, #-0x38]
    // 0x6c5db8: StoreField: r0->field_5b = r1
    //     0x6c5db8: stur            w1, [x0, #0x5b]
    // 0x6c5dbc: r1 = Function '<anonymous closure>':.
    //     0x6c5dbc: add             x1, PP, #0x26, lsl #12  ; [pp+0x262c8] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5dc0: ldr             x1, [x1, #0x2c8]
    // 0x6c5dc4: r2 = Null
    //     0x6c5dc4: mov             x2, NULL
    // 0x6c5dc8: r0 = AllocateClosure()
    //     0x6c5dc8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5dcc: mov             x1, x0
    // 0x6c5dd0: ldur            x0, [fp, #-0x98]
    // 0x6c5dd4: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5dd4: stur            w1, [x0, #0x17]
    // 0x6c5dd8: r1 = Function '<anonymous closure>':.
    //     0x6c5dd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x262d0] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5ddc: ldr             x1, [x1, #0x2d0]
    // 0x6c5de0: r2 = Null
    //     0x6c5de0: mov             x2, NULL
    // 0x6c5de4: r0 = AllocateClosure()
    //     0x6c5de4: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5de8: mov             x1, x0
    // 0x6c5dec: ldur            x0, [fp, #-0x98]
    // 0x6c5df0: StoreField: r0->field_1b = r1
    //     0x6c5df0: stur            w1, [x0, #0x1b]
    // 0x6c5df4: ldur            x1, [fp, #-0x40]
    // 0x6c5df8: StoreField: r0->field_57 = r1
    //     0x6c5df8: stur            w1, [x0, #0x57]
    // 0x6c5dfc: r1 = const [0x1f, 0x20, 0x21, 0x22]
    //     0x6c5dfc: add             x1, PP, #0x26, lsl #12  ; [pp+0x262d8] List<int>(4)
    //     0x6c5e00: ldr             x1, [x1, #0x2d8]
    // 0x6c5e04: StoreField: r0->field_53 = r1
    //     0x6c5e04: stur            w1, [x0, #0x53]
    // 0x6c5e08: ldur            x1, [fp, #-0x48]
    // 0x6c5e0c: StoreField: r0->field_6b = r1
    //     0x6c5e0c: stur            w1, [x0, #0x6b]
    // 0x6c5e10: ldur            x1, [fp, #-0x90]
    // 0x6c5e14: StoreField: r0->field_4b = r1
    //     0x6c5e14: stur            w1, [x0, #0x4b]
    // 0x6c5e18: ldur            x1, [fp, #-0x60]
    // 0x6c5e1c: StoreField: r0->field_67 = r1
    //     0x6c5e1c: stur            w1, [x0, #0x67]
    // 0x6c5e20: ldur            x1, [fp, #-0x10]
    // 0x6c5e24: StoreField: r0->field_77 = r1
    //     0x6c5e24: stur            w1, [x0, #0x77]
    // 0x6c5e28: ldur            x1, [fp, #-0x50]
    // 0x6c5e2c: StoreField: r0->field_7b = r1
    //     0x6c5e2c: stur            w1, [x0, #0x7b]
    // 0x6c5e30: r3 = "Chapter 9 Generators 4"
    //     0x6c5e30: add             x3, PP, #0x26, lsl #12  ; [pp+0x262e0] "Chapter 9 Generators 4"
    //     0x6c5e34: ldr             x3, [x3, #0x2e0]
    // 0x6c5e38: StoreField: r0->field_73 = r3
    //     0x6c5e38: stur            w3, [x0, #0x73]
    // 0x6c5e3c: ldur            x2, [fp, #-0x18]
    // 0x6c5e40: r1 = Function '<anonymous closure>':.
    //     0x6c5e40: add             x1, PP, #0x26, lsl #12  ; [pp+0x262e8] AnonymousClosure: (0x6c636c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5e44: ldr             x1, [x1, #0x2e8]
    // 0x6c5e48: r0 = AllocateClosure()
    //     0x6c5e48: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5e4c: ldur            x2, [fp, #-0x98]
    // 0x6c5e50: mov             x5, x0
    // 0x6c5e54: r1 = Null
    //     0x6c5e54: mov             x1, NULL
    // 0x6c5e58: r3 = "Chapter 9 Generators 4"
    //     0x6c5e58: add             x3, PP, #0x26, lsl #12  ; [pp+0x262e0] "Chapter 9 Generators 4"
    //     0x6c5e5c: ldr             x3, [x3, #0x2e0]
    // 0x6c5e60: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6c5e60: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6c5e64: r0 = IdleFragment()
    //     0x6c5e64: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5e68: ldur            x1, [fp, #-0x20]
    // 0x6c5e6c: ArrayStore: r1[10] = r0  ; List_4
    //     0x6c5e6c: add             x25, x1, #0x37
    //     0x6c5e70: str             w0, [x25]
    //     0x6c5e74: tbz             w0, #0, #0x6c5e90
    //     0x6c5e78: ldurb           w16, [x1, #-1]
    //     0x6c5e7c: ldurb           w17, [x0, #-1]
    //     0x6c5e80: and             x16, x17, x16, lsr #2
    //     0x6c5e84: tst             x16, HEAP, lsr #32
    //     0x6c5e88: b.eq            #0x6c5e90
    //     0x6c5e8c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5e90: ldur            x0, [fp, #-8]
    // 0x6c5e94: LoadField: r2 = r0->field_37
    //     0x6c5e94: ldur            w2, [x0, #0x37]
    // 0x6c5e98: DecompressPointer r2
    //     0x6c5e98: add             x2, x2, HEAP, lsl #32
    // 0x6c5e9c: stur            x2, [fp, #-0x30]
    // 0x6c5ea0: LoadField: r3 = r0->field_43
    //     0x6c5ea0: ldur            w3, [x0, #0x43]
    // 0x6c5ea4: DecompressPointer r3
    //     0x6c5ea4: add             x3, x3, HEAP, lsl #32
    // 0x6c5ea8: stur            x3, [fp, #-0x28]
    // 0x6c5eac: LoadField: r4 = r0->field_8f
    //     0x6c5eac: ldur            w4, [x0, #0x8f]
    // 0x6c5eb0: DecompressPointer r4
    //     0x6c5eb0: add             x4, x4, HEAP, lsl #32
    // 0x6c5eb4: stur            x4, [fp, #-0x10]
    // 0x6c5eb8: r1 = <Chapter9Stat>
    //     0x6c5eb8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5ebc: ldr             x1, [x1, #0xe48]
    // 0x6c5ec0: r0 = UpgradeGroup()
    //     0x6c5ec0: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6c5ec4: mov             x3, x0
    // 0x6c5ec8: r0 = 1
    //     0x6c5ec8: movz            x0, #0x1
    // 0x6c5ecc: stur            x3, [fp, #-0x38]
    // 0x6c5ed0: StoreField: r3->field_13 = r0
    //     0x6c5ed0: stur            x0, [x3, #0x13]
    // 0x6c5ed4: ldur            x0, [fp, #-0x10]
    // 0x6c5ed8: StoreField: r3->field_1b = r0
    //     0x6c5ed8: stur            w0, [x3, #0x1b]
    // 0x6c5edc: ldur            x0, [fp, #-0x30]
    // 0x6c5ee0: StoreField: r3->field_1f = r0
    //     0x6c5ee0: stur            w0, [x3, #0x1f]
    // 0x6c5ee4: ldur            x0, [fp, #-0x28]
    // 0x6c5ee8: StoreField: r3->field_23 = r0
    //     0x6c5ee8: stur            w0, [x3, #0x23]
    // 0x6c5eec: r1 = Function '<anonymous closure>':.
    //     0x6c5eec: add             x1, PP, #0x26, lsl #12  ; [pp+0x262f0] AnonymousClosure: (0x46e608), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState (0x46e464)
    //     0x6c5ef0: ldr             x1, [x1, #0x2f0]
    // 0x6c5ef4: r2 = Null
    //     0x6c5ef4: mov             x2, NULL
    // 0x6c5ef8: r0 = AllocateClosure()
    //     0x6c5ef8: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5efc: mov             x1, x0
    // 0x6c5f00: ldur            x0, [fp, #-0x38]
    // 0x6c5f04: StoreField: r0->field_2b = r1
    //     0x6c5f04: stur            w1, [x0, #0x2b]
    // 0x6c5f08: r1 = const [0x18, 0x17, 0x19]
    //     0x6c5f08: add             x1, PP, #0x26, lsl #12  ; [pp+0x262f8] List<int>(3)
    //     0x6c5f0c: ldr             x1, [x1, #0x2f8]
    // 0x6c5f10: StoreField: r0->field_f = r1
    //     0x6c5f10: stur            w1, [x0, #0xf]
    // 0x6c5f14: r1 = true
    //     0x6c5f14: add             x1, NULL, #0x20  ; true
    // 0x6c5f18: StoreField: r0->field_27 = r1
    //     0x6c5f18: stur            w1, [x0, #0x27]
    // 0x6c5f1c: r1 = Instance_UpgradeDisplayMode
    //     0x6c5f1c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26300] Obj!UpgradeDisplayMode@85e861
    //     0x6c5f20: ldr             x1, [x1, #0x300]
    // 0x6c5f24: StoreField: r0->field_2f = r1
    //     0x6c5f24: stur            w1, [x0, #0x2f]
    // 0x6c5f28: r1 = false
    //     0x6c5f28: add             x1, NULL, #0x30  ; false
    // 0x6c5f2c: StoreField: r0->field_33 = r1
    //     0x6c5f2c: stur            w1, [x0, #0x33]
    // 0x6c5f30: ldur            x2, [fp, #-0x18]
    // 0x6c5f34: r1 = Function '<anonymous closure>':.
    //     0x6c5f34: add             x1, PP, #0x26, lsl #12  ; [pp+0x26308] AnonymousClosure: (0x6c636c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5f38: ldr             x1, [x1, #0x308]
    // 0x6c5f3c: r0 = AllocateClosure()
    //     0x6c5f3c: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5f40: ldur            x2, [fp, #-0x18]
    // 0x6c5f44: r1 = Function '<anonymous closure>':.
    //     0x6c5f44: add             x1, PP, #0x26, lsl #12  ; [pp+0x26310] AnonymousClosure: (0x6c61d0), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5f48: ldr             x1, [x1, #0x310]
    // 0x6c5f4c: stur            x0, [fp, #-0x10]
    // 0x6c5f50: r0 = AllocateClosure()
    //     0x6c5f50: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5f54: str             x0, [SP]
    // 0x6c5f58: ldur            x2, [fp, #-0x38]
    // 0x6c5f5c: ldur            x5, [fp, #-0x10]
    // 0x6c5f60: r1 = Null
    //     0x6c5f60: mov             x1, NULL
    // 0x6c5f64: r3 = "Chapter 9 Upgrades 4"
    //     0x6c5f64: add             x3, PP, #0x26, lsl #12  ; [pp+0x26318] "Chapter 9 Upgrades 4"
    //     0x6c5f68: ldr             x3, [x3, #0x318]
    // 0x6c5f6c: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6c5f6c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6c5f70: ldr             x4, [x4, #0x160]
    // 0x6c5f74: r0 = IdleFragment()
    //     0x6c5f74: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c5f78: ldur            x1, [fp, #-0x20]
    // 0x6c5f7c: ArrayStore: r1[11] = r0  ; List_4
    //     0x6c5f7c: add             x25, x1, #0x3b
    //     0x6c5f80: str             w0, [x25]
    //     0x6c5f84: tbz             w0, #0, #0x6c5fa0
    //     0x6c5f88: ldurb           w16, [x1, #-1]
    //     0x6c5f8c: ldurb           w17, [x0, #-1]
    //     0x6c5f90: and             x16, x17, x16, lsr #2
    //     0x6c5f94: tst             x16, HEAP, lsr #32
    //     0x6c5f98: b.eq            #0x6c5fa0
    //     0x6c5f9c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c5fa0: ldur            x0, [fp, #-8]
    // 0x6c5fa4: LoadField: r2 = r0->field_37
    //     0x6c5fa4: ldur            w2, [x0, #0x37]
    // 0x6c5fa8: DecompressPointer r2
    //     0x6c5fa8: add             x2, x2, HEAP, lsl #32
    // 0x6c5fac: stur            x2, [fp, #-0x10]
    // 0x6c5fb0: r1 = <Chapter9Stat>
    //     0x6c5fb0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x6c5fb4: ldr             x1, [x1, #0xe48]
    // 0x6c5fb8: r0 = CompleteChapterButtons()
    //     0x6c5fb8: bl              #0x697edc  ; AllocateCompleteChapterButtonsStub -> CompleteChapterButtons<X0> (size=0x24)
    // 0x6c5fbc: mov             x3, x0
    // 0x6c5fc0: ldur            x0, [fp, #-0x10]
    // 0x6c5fc4: stur            x3, [fp, #-8]
    // 0x6c5fc8: StoreField: r3->field_f = r0
    //     0x6c5fc8: stur            w0, [x3, #0xf]
    // 0x6c5fcc: r0 = Instance_Tuple2
    //     0x6c5fcc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26320] Obj!Tuple2<Chapter9Stat, CustomNum>@8280f1
    //     0x6c5fd0: ldr             x0, [x0, #0x320]
    // 0x6c5fd4: StoreField: r3->field_13 = r0
    //     0x6c5fd4: stur            w0, [x3, #0x13]
    // 0x6c5fd8: ldur            x2, [fp, #-0x18]
    // 0x6c5fdc: r1 = Function '<anonymous closure>':.
    //     0x6c5fdc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26328] AnonymousClosure: (0x6c617c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c5fe0: ldr             x1, [x1, #0x328]
    // 0x6c5fe4: r0 = AllocateClosure()
    //     0x6c5fe4: bl              #0x826750  ; AllocateClosureStub
    // 0x6c5fe8: mov             x1, x0
    // 0x6c5fec: ldur            x0, [fp, #-8]
    // 0x6c5ff0: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c5ff0: stur            w1, [x0, #0x17]
    // 0x6c5ff4: r1 = Closure: (Chapter9Stat?) => String from Function 'humanName': static.
    //     0x6c5ff4: add             x1, PP, #0x26, lsl #12  ; [pp+0x260a0] Closure: (Chapter9Stat?) => String from Function 'humanName': static. (0x248ed99e608)
    //     0x6c5ff8: ldr             x1, [x1, #0xa0]
    // 0x6c5ffc: StoreField: r0->field_1f = r1
    //     0x6c5ffc: stur            w1, [x0, #0x1f]
    // 0x6c6000: r1 = Instance_ChapterCompleteButtonType
    //     0x6c6000: add             x1, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!ChapterCompleteButtonType@85ea61
    //     0x6c6004: ldr             x1, [x1, #0x330]
    // 0x6c6008: StoreField: r0->field_1b = r1
    //     0x6c6008: stur            w1, [x0, #0x1b]
    // 0x6c600c: r1 = Null
    //     0x6c600c: mov             x1, NULL
    // 0x6c6010: r2 = 2
    //     0x6c6010: movz            x2, #0x2
    // 0x6c6014: r0 = AllocateArray()
    //     0x6c6014: bl              #0x82746c  ; AllocateArrayStub
    // 0x6c6018: mov             x2, x0
    // 0x6c601c: ldur            x0, [fp, #-8]
    // 0x6c6020: stur            x2, [fp, #-0x10]
    // 0x6c6024: StoreField: r2->field_f = r0
    //     0x6c6024: stur            w0, [x2, #0xf]
    // 0x6c6028: r1 = <Widget>
    //     0x6c6028: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6c602c: r0 = AllocateGrowableArray()
    //     0x6c602c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6c6030: mov             x1, x0
    // 0x6c6034: ldur            x0, [fp, #-0x10]
    // 0x6c6038: stur            x1, [fp, #-8]
    // 0x6c603c: StoreField: r1->field_f = r0
    //     0x6c603c: stur            w0, [x1, #0xf]
    // 0x6c6040: r0 = 2
    //     0x6c6040: movz            x0, #0x2
    // 0x6c6044: StoreField: r1->field_b = r0
    //     0x6c6044: stur            w0, [x1, #0xb]
    // 0x6c6048: r0 = Column()
    //     0x6c6048: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6c604c: mov             x3, x0
    // 0x6c6050: r0 = Instance_Axis
    //     0x6c6050: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6c6054: stur            x3, [fp, #-0x10]
    // 0x6c6058: StoreField: r3->field_f = r0
    //     0x6c6058: stur            w0, [x3, #0xf]
    // 0x6c605c: r0 = Instance_MainAxisAlignment
    //     0x6c605c: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6c6060: ldr             x0, [x0, #0x200]
    // 0x6c6064: StoreField: r3->field_13 = r0
    //     0x6c6064: stur            w0, [x3, #0x13]
    // 0x6c6068: r0 = Instance_MainAxisSize
    //     0x6c6068: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6c606c: ldr             x0, [x0, #0x70]
    // 0x6c6070: ArrayStore: r3[0] = r0  ; List_4
    //     0x6c6070: stur            w0, [x3, #0x17]
    // 0x6c6074: r0 = Instance_CrossAxisAlignment
    //     0x6c6074: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6c6078: ldr             x0, [x0, #0x78]
    // 0x6c607c: StoreField: r3->field_1b = r0
    //     0x6c607c: stur            w0, [x3, #0x1b]
    // 0x6c6080: r0 = Instance_VerticalDirection
    //     0x6c6080: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6c6084: ldr             x0, [x0, #0x1e8]
    // 0x6c6088: StoreField: r3->field_23 = r0
    //     0x6c6088: stur            w0, [x3, #0x23]
    // 0x6c608c: r0 = Instance_Clip
    //     0x6c608c: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6c6090: ldr             x0, [x0, #0x1b0]
    // 0x6c6094: StoreField: r3->field_2b = r0
    //     0x6c6094: stur            w0, [x3, #0x2b]
    // 0x6c6098: StoreField: r3->field_2f = rZR
    //     0x6c6098: stur            xzr, [x3, #0x2f]
    // 0x6c609c: ldur            x0, [fp, #-8]
    // 0x6c60a0: StoreField: r3->field_b = r0
    //     0x6c60a0: stur            w0, [x3, #0xb]
    // 0x6c60a4: ldur            x2, [fp, #-0x18]
    // 0x6c60a8: r1 = Function '<anonymous closure>':.
    //     0x6c60a8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26338] AnonymousClosure: (0x6c6130), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c60ac: ldr             x1, [x1, #0x338]
    // 0x6c60b0: r0 = AllocateClosure()
    //     0x6c60b0: bl              #0x826750  ; AllocateClosureStub
    // 0x6c60b4: ldur            x2, [fp, #-0x10]
    // 0x6c60b8: mov             x5, x0
    // 0x6c60bc: r1 = Null
    //     0x6c60bc: mov             x1, NULL
    // 0x6c60c0: r3 = "Chapter 9 Complete Chapter"
    //     0x6c60c0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26340] "Chapter 9 Complete Chapter"
    //     0x6c60c4: ldr             x3, [x3, #0x340]
    // 0x6c60c8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6c60c8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6c60cc: r0 = IdleFragment()
    //     0x6c60cc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6c60d0: ldur            x1, [fp, #-0x20]
    // 0x6c60d4: ArrayStore: r1[12] = r0  ; List_4
    //     0x6c60d4: add             x25, x1, #0x3f
    //     0x6c60d8: str             w0, [x25]
    //     0x6c60dc: tbz             w0, #0, #0x6c60f8
    //     0x6c60e0: ldurb           w16, [x1, #-1]
    //     0x6c60e4: ldurb           w17, [x0, #-1]
    //     0x6c60e8: and             x16, x17, x16, lsr #2
    //     0x6c60ec: tst             x16, HEAP, lsr #32
    //     0x6c60f0: b.eq            #0x6c60f8
    //     0x6c60f4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6c60f8: r1 = <Widget>
    //     0x6c60f8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6c60fc: r0 = AllocateGrowableArray()
    //     0x6c60fc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6c6100: ldur            x1, [fp, #-0x20]
    // 0x6c6104: StoreField: r0->field_f = r1
    //     0x6c6104: stur            w1, [x0, #0xf]
    // 0x6c6108: r1 = 26
    //     0x6c6108: movz            x1, #0x1a
    // 0x6c610c: StoreField: r0->field_b = r1
    //     0x6c610c: stur            w1, [x0, #0xb]
    // 0x6c6110: LeaveFrame
    //     0x6c6110: mov             SP, fp
    //     0x6c6114: ldp             fp, lr, [SP], #0x10
    // 0x6c6118: ret
    //     0x6c6118: ret             
    // 0x6c611c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c611c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6120: b               #0x6c4f50
    // 0x6c6124: r9 = allUpgradeData
    //     0x6c6124: add             x9, PP, #0x26, lsl #12  ; [pp+0x26348] Field <Chapter9GameState.allUpgradeData>: late (offset: 0x90)
    //     0x6c6128: ldr             x9, [x9, #0x348]
    // 0x6c612c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c612c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6c6130, size: 0x4c
    // 0x6c6130: EnterFrame
    //     0x6c6130: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6134: mov             fp, SP
    // 0x6c6138: ldr             x0, [fp, #0x10]
    // 0x6c613c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c613c: ldur            w1, [x0, #0x17]
    // 0x6c6140: DecompressPointer r1
    //     0x6c6140: add             x1, x1, HEAP, lsl #32
    // 0x6c6144: CheckStackOverflow
    //     0x6c6144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6148: cmp             SP, x16
    //     0x6c614c: b.ls            #0x6c6174
    // 0x6c6150: LoadField: r0 = r1->field_f
    //     0x6c6150: ldur            w0, [x1, #0xf]
    // 0x6c6154: DecompressPointer r0
    //     0x6c6154: add             x0, x0, HEAP, lsl #32
    // 0x6c6158: LoadField: r1 = r0->field_1b
    //     0x6c6158: ldur            w1, [x0, #0x1b]
    // 0x6c615c: DecompressPointer r1
    //     0x6c615c: add             x1, x1, HEAP, lsl #32
    // 0x6c6160: r2 = 50
    //     0x6c6160: movz            x2, #0x32
    // 0x6c6164: r0 = contains()
    //     0x6c6164: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6c6168: LeaveFrame
    //     0x6c6168: mov             SP, fp
    //     0x6c616c: ldp             fp, lr, [SP], #0x10
    // 0x6c6170: ret
    //     0x6c6170: ret             
    // 0x6c6174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6174: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6178: b               #0x6c6150
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6c617c, size: 0x54
    // 0x6c617c: EnterFrame
    //     0x6c617c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6180: mov             fp, SP
    // 0x6c6184: ldr             x0, [fp, #0x18]
    // 0x6c6188: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c6188: ldur            w1, [x0, #0x17]
    // 0x6c618c: DecompressPointer r1
    //     0x6c618c: add             x1, x1, HEAP, lsl #32
    // 0x6c6190: CheckStackOverflow
    //     0x6c6190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6194: cmp             SP, x16
    //     0x6c6198: b.ls            #0x6c61c8
    // 0x6c619c: LoadField: r0 = r1->field_f
    //     0x6c619c: ldur            w0, [x1, #0xf]
    // 0x6c61a0: DecompressPointer r0
    //     0x6c61a0: add             x0, x0, HEAP, lsl #32
    // 0x6c61a4: LoadField: r2 = r1->field_13
    //     0x6c61a4: ldur            w2, [x1, #0x13]
    // 0x6c61a8: DecompressPointer r2
    //     0x6c61a8: add             x2, x2, HEAP, lsl #32
    // 0x6c61ac: mov             x1, x0
    // 0x6c61b0: r3 = Instance_Tuple2
    //     0x6c61b0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26350] Obj!Tuple2<int, String>@8280d1
    //     0x6c61b4: ldr             x3, [x3, #0x350]
    // 0x6c61b8: r0 = completeChapter()
    //     0x6c61b8: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x6c61bc: LeaveFrame
    //     0x6c61bc: mov             SP, fp
    //     0x6c61c0: ldp             fp, lr, [SP], #0x10
    // 0x6c61c4: ret
    //     0x6c61c4: ret             
    // 0x6c61c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c61c8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c61cc: b               #0x6c619c
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6c61d0, size: 0x19c
    // 0x6c61d0: EnterFrame
    //     0x6c61d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c61d4: mov             fp, SP
    // 0x6c61d8: AllocStack(0x10)
    //     0x6c61d8: sub             SP, SP, #0x10
    // 0x6c61dc: SetupParameters([dynamic _ /* r0 */])
    //     0x6c61dc: ldr             x0, [fp, #0x10]
    //     0x6c61e0: ldur            w3, [x0, #0x17]
    //     0x6c61e4: add             x3, x3, HEAP, lsl #32
    //     0x6c61e8: stur            x3, [fp, #-0x10]
    // 0x6c61ec: CheckStackOverflow
    //     0x6c61ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c61f0: cmp             SP, x16
    //     0x6c61f4: b.ls            #0x6c6364
    // 0x6c61f8: LoadField: r0 = r3->field_f
    //     0x6c61f8: ldur            w0, [x3, #0xf]
    // 0x6c61fc: DecompressPointer r0
    //     0x6c61fc: add             x0, x0, HEAP, lsl #32
    // 0x6c6200: LoadField: r4 = r0->field_43
    //     0x6c6200: ldur            w4, [x0, #0x43]
    // 0x6c6204: DecompressPointer r4
    //     0x6c6204: add             x4, x4, HEAP, lsl #32
    // 0x6c6208: mov             x1, x4
    // 0x6c620c: stur            x4, [fp, #-8]
    // 0x6c6210: r2 = 48
    //     0x6c6210: movz            x2, #0x30
    // 0x6c6214: r0 = _getValueOrData()
    //     0x6c6214: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6218: mov             x1, x0
    // 0x6c621c: ldur            x0, [fp, #-8]
    // 0x6c6220: LoadField: r2 = r0->field_f
    //     0x6c6220: ldur            w2, [x0, #0xf]
    // 0x6c6224: DecompressPointer r2
    //     0x6c6224: add             x2, x2, HEAP, lsl #32
    // 0x6c6228: cmp             w2, w1
    // 0x6c622c: b.ne            #0x6c6238
    // 0x6c6230: r0 = Null
    //     0x6c6230: mov             x0, NULL
    // 0x6c6234: b               #0x6c623c
    // 0x6c6238: mov             x0, x1
    // 0x6c623c: cmp             w0, NULL
    // 0x6c6240: b.ne            #0x6c624c
    // 0x6c6244: r0 = 0
    //     0x6c6244: movz            x0, #0
    // 0x6c6248: b               #0x6c625c
    // 0x6c624c: r1 = LoadInt32Instr(r0)
    //     0x6c624c: sbfx            x1, x0, #1, #0x1f
    //     0x6c6250: tbz             w0, #0, #0x6c6258
    //     0x6c6254: ldur            x1, [x0, #7]
    // 0x6c6258: mov             x0, x1
    // 0x6c625c: cmp             x0, #3
    // 0x6c6260: b.lt            #0x6c6354
    // 0x6c6264: ldur            x0, [fp, #-0x10]
    // 0x6c6268: LoadField: r1 = r0->field_f
    //     0x6c6268: ldur            w1, [x0, #0xf]
    // 0x6c626c: DecompressPointer r1
    //     0x6c626c: add             x1, x1, HEAP, lsl #32
    // 0x6c6270: LoadField: r3 = r1->field_43
    //     0x6c6270: ldur            w3, [x1, #0x43]
    // 0x6c6274: DecompressPointer r3
    //     0x6c6274: add             x3, x3, HEAP, lsl #32
    // 0x6c6278: mov             x1, x3
    // 0x6c627c: stur            x3, [fp, #-8]
    // 0x6c6280: r2 = 46
    //     0x6c6280: movz            x2, #0x2e
    // 0x6c6284: r0 = _getValueOrData()
    //     0x6c6284: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6288: mov             x1, x0
    // 0x6c628c: ldur            x0, [fp, #-8]
    // 0x6c6290: LoadField: r2 = r0->field_f
    //     0x6c6290: ldur            w2, [x0, #0xf]
    // 0x6c6294: DecompressPointer r2
    //     0x6c6294: add             x2, x2, HEAP, lsl #32
    // 0x6c6298: cmp             w2, w1
    // 0x6c629c: b.ne            #0x6c62a8
    // 0x6c62a0: r0 = Null
    //     0x6c62a0: mov             x0, NULL
    // 0x6c62a4: b               #0x6c62ac
    // 0x6c62a8: mov             x0, x1
    // 0x6c62ac: cmp             w0, NULL
    // 0x6c62b0: b.ne            #0x6c62bc
    // 0x6c62b4: r0 = 0
    //     0x6c62b4: movz            x0, #0
    // 0x6c62b8: b               #0x6c62cc
    // 0x6c62bc: r1 = LoadInt32Instr(r0)
    //     0x6c62bc: sbfx            x1, x0, #1, #0x1f
    //     0x6c62c0: tbz             w0, #0, #0x6c62c8
    //     0x6c62c4: ldur            x1, [x0, #7]
    // 0x6c62c8: mov             x0, x1
    // 0x6c62cc: cmp             x0, #1
    // 0x6c62d0: b.lt            #0x6c6354
    // 0x6c62d4: ldur            x0, [fp, #-0x10]
    // 0x6c62d8: LoadField: r1 = r0->field_f
    //     0x6c62d8: ldur            w1, [x0, #0xf]
    // 0x6c62dc: DecompressPointer r1
    //     0x6c62dc: add             x1, x1, HEAP, lsl #32
    // 0x6c62e0: LoadField: r0 = r1->field_43
    //     0x6c62e0: ldur            w0, [x1, #0x43]
    // 0x6c62e4: DecompressPointer r0
    //     0x6c62e4: add             x0, x0, HEAP, lsl #32
    // 0x6c62e8: mov             x1, x0
    // 0x6c62ec: stur            x0, [fp, #-8]
    // 0x6c62f0: r2 = 50
    //     0x6c62f0: movz            x2, #0x32
    // 0x6c62f4: r0 = _getValueOrData()
    //     0x6c62f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c62f8: ldur            x1, [fp, #-8]
    // 0x6c62fc: LoadField: r2 = r1->field_f
    //     0x6c62fc: ldur            w2, [x1, #0xf]
    // 0x6c6300: DecompressPointer r2
    //     0x6c6300: add             x2, x2, HEAP, lsl #32
    // 0x6c6304: cmp             w2, w0
    // 0x6c6308: b.ne            #0x6c6314
    // 0x6c630c: r1 = Null
    //     0x6c630c: mov             x1, NULL
    // 0x6c6310: b               #0x6c6318
    // 0x6c6314: mov             x1, x0
    // 0x6c6318: cmp             w1, NULL
    // 0x6c631c: b.ne            #0x6c6328
    // 0x6c6320: r1 = 0
    //     0x6c6320: movz            x1, #0
    // 0x6c6324: b               #0x6c6338
    // 0x6c6328: r2 = LoadInt32Instr(r1)
    //     0x6c6328: sbfx            x2, x1, #1, #0x1f
    //     0x6c632c: tbz             w1, #0, #0x6c6334
    //     0x6c6330: ldur            x2, [x1, #7]
    // 0x6c6334: mov             x1, x2
    // 0x6c6338: cmp             x1, #2
    // 0x6c633c: b.lt            #0x6c6354
    // 0x6c6340: r0 = "Upgrades"
    //     0x6c6340: add             x0, PP, #0x26, lsl #12  ; [pp+0x26508] "Upgrades"
    //     0x6c6344: ldr             x0, [x0, #0x508]
    // 0x6c6348: LeaveFrame
    //     0x6c6348: mov             SP, fp
    //     0x6c634c: ldp             fp, lr, [SP], #0x10
    // 0x6c6350: ret
    //     0x6c6350: ret             
    // 0x6c6354: r0 = Null
    //     0x6c6354: mov             x0, NULL
    // 0x6c6358: LeaveFrame
    //     0x6c6358: mov             SP, fp
    //     0x6c635c: ldp             fp, lr, [SP], #0x10
    // 0x6c6360: ret
    //     0x6c6360: ret             
    // 0x6c6364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6364: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6368: b               #0x6c61f8
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6c636c, size: 0x4c
    // 0x6c636c: EnterFrame
    //     0x6c636c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6370: mov             fp, SP
    // 0x6c6374: ldr             x0, [fp, #0x10]
    // 0x6c6378: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c6378: ldur            w1, [x0, #0x17]
    // 0x6c637c: DecompressPointer r1
    //     0x6c637c: add             x1, x1, HEAP, lsl #32
    // 0x6c6380: CheckStackOverflow
    //     0x6c6380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6384: cmp             SP, x16
    //     0x6c6388: b.ls            #0x6c63b0
    // 0x6c638c: LoadField: r0 = r1->field_f
    //     0x6c638c: ldur            w0, [x1, #0xf]
    // 0x6c6390: DecompressPointer r0
    //     0x6c6390: add             x0, x0, HEAP, lsl #32
    // 0x6c6394: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c6394: ldur            w1, [x0, #0x17]
    // 0x6c6398: DecompressPointer r1
    //     0x6c6398: add             x1, x1, HEAP, lsl #32
    // 0x6c639c: r2 = 46
    //     0x6c639c: movz            x2, #0x2e
    // 0x6c63a0: r0 = contains()
    //     0x6c63a0: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6c63a4: LeaveFrame
    //     0x6c63a4: mov             SP, fp
    //     0x6c63a8: ldp             fp, lr, [SP], #0x10
    // 0x6c63ac: ret
    //     0x6c63ac: ret             
    // 0x6c63b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c63b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c63b4: b               #0x6c638c
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6c63b8, size: 0x12c
    // 0x6c63b8: EnterFrame
    //     0x6c63b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c63bc: mov             fp, SP
    // 0x6c63c0: AllocStack(0x10)
    //     0x6c63c0: sub             SP, SP, #0x10
    // 0x6c63c4: SetupParameters([dynamic _ /* r0 */])
    //     0x6c63c4: ldr             x0, [fp, #0x10]
    //     0x6c63c8: ldur            w3, [x0, #0x17]
    //     0x6c63cc: add             x3, x3, HEAP, lsl #32
    //     0x6c63d0: stur            x3, [fp, #-0x10]
    // 0x6c63d4: CheckStackOverflow
    //     0x6c63d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c63d8: cmp             SP, x16
    //     0x6c63dc: b.ls            #0x6c64dc
    // 0x6c63e0: LoadField: r0 = r3->field_f
    //     0x6c63e0: ldur            w0, [x3, #0xf]
    // 0x6c63e4: DecompressPointer r0
    //     0x6c63e4: add             x0, x0, HEAP, lsl #32
    // 0x6c63e8: LoadField: r4 = r0->field_43
    //     0x6c63e8: ldur            w4, [x0, #0x43]
    // 0x6c63ec: DecompressPointer r4
    //     0x6c63ec: add             x4, x4, HEAP, lsl #32
    // 0x6c63f0: mov             x1, x4
    // 0x6c63f4: stur            x4, [fp, #-8]
    // 0x6c63f8: r2 = 42
    //     0x6c63f8: movz            x2, #0x2a
    // 0x6c63fc: r0 = _getValueOrData()
    //     0x6c63fc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6400: mov             x1, x0
    // 0x6c6404: ldur            x0, [fp, #-8]
    // 0x6c6408: LoadField: r2 = r0->field_f
    //     0x6c6408: ldur            w2, [x0, #0xf]
    // 0x6c640c: DecompressPointer r2
    //     0x6c640c: add             x2, x2, HEAP, lsl #32
    // 0x6c6410: cmp             w2, w1
    // 0x6c6414: b.ne            #0x6c6420
    // 0x6c6418: r0 = Null
    //     0x6c6418: mov             x0, NULL
    // 0x6c641c: b               #0x6c6424
    // 0x6c6420: mov             x0, x1
    // 0x6c6424: cmp             w0, NULL
    // 0x6c6428: b.ne            #0x6c6434
    // 0x6c642c: r0 = 0
    //     0x6c642c: movz            x0, #0
    // 0x6c6430: b               #0x6c6444
    // 0x6c6434: r1 = LoadInt32Instr(r0)
    //     0x6c6434: sbfx            x1, x0, #1, #0x1f
    //     0x6c6438: tbz             w0, #0, #0x6c6440
    //     0x6c643c: ldur            x1, [x0, #7]
    // 0x6c6440: mov             x0, x1
    // 0x6c6444: cmp             x0, #2
    // 0x6c6448: b.lt            #0x6c64cc
    // 0x6c644c: ldur            x0, [fp, #-0x10]
    // 0x6c6450: LoadField: r1 = r0->field_f
    //     0x6c6450: ldur            w1, [x0, #0xf]
    // 0x6c6454: DecompressPointer r1
    //     0x6c6454: add             x1, x1, HEAP, lsl #32
    // 0x6c6458: LoadField: r0 = r1->field_43
    //     0x6c6458: ldur            w0, [x1, #0x43]
    // 0x6c645c: DecompressPointer r0
    //     0x6c645c: add             x0, x0, HEAP, lsl #32
    // 0x6c6460: mov             x1, x0
    // 0x6c6464: stur            x0, [fp, #-8]
    // 0x6c6468: r2 = 44
    //     0x6c6468: movz            x2, #0x2c
    // 0x6c646c: r0 = _getValueOrData()
    //     0x6c646c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6470: ldur            x1, [fp, #-8]
    // 0x6c6474: LoadField: r2 = r1->field_f
    //     0x6c6474: ldur            w2, [x1, #0xf]
    // 0x6c6478: DecompressPointer r2
    //     0x6c6478: add             x2, x2, HEAP, lsl #32
    // 0x6c647c: cmp             w2, w0
    // 0x6c6480: b.ne            #0x6c648c
    // 0x6c6484: r1 = Null
    //     0x6c6484: mov             x1, NULL
    // 0x6c6488: b               #0x6c6490
    // 0x6c648c: mov             x1, x0
    // 0x6c6490: cmp             w1, NULL
    // 0x6c6494: b.ne            #0x6c64a0
    // 0x6c6498: r1 = 0
    //     0x6c6498: movz            x1, #0
    // 0x6c649c: b               #0x6c64b0
    // 0x6c64a0: r2 = LoadInt32Instr(r1)
    //     0x6c64a0: sbfx            x2, x1, #1, #0x1f
    //     0x6c64a4: tbz             w1, #0, #0x6c64ac
    //     0x6c64a8: ldur            x2, [x1, #7]
    // 0x6c64ac: mov             x1, x2
    // 0x6c64b0: cmp             x1, #1
    // 0x6c64b4: b.lt            #0x6c64cc
    // 0x6c64b8: r0 = "Upgrades"
    //     0x6c64b8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26508] "Upgrades"
    //     0x6c64bc: ldr             x0, [x0, #0x508]
    // 0x6c64c0: LeaveFrame
    //     0x6c64c0: mov             SP, fp
    //     0x6c64c4: ldp             fp, lr, [SP], #0x10
    // 0x6c64c8: ret
    //     0x6c64c8: ret             
    // 0x6c64cc: r0 = Null
    //     0x6c64cc: mov             x0, NULL
    // 0x6c64d0: LeaveFrame
    //     0x6c64d0: mov             SP, fp
    //     0x6c64d4: ldp             fp, lr, [SP], #0x10
    // 0x6c64d8: ret
    //     0x6c64d8: ret             
    // 0x6c64dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c64dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c64e0: b               #0x6c63e0
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6c64e4, size: 0x4c
    // 0x6c64e4: EnterFrame
    //     0x6c64e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c64e8: mov             fp, SP
    // 0x6c64ec: ldr             x0, [fp, #0x10]
    // 0x6c64f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c64f0: ldur            w1, [x0, #0x17]
    // 0x6c64f4: DecompressPointer r1
    //     0x6c64f4: add             x1, x1, HEAP, lsl #32
    // 0x6c64f8: CheckStackOverflow
    //     0x6c64f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c64fc: cmp             SP, x16
    //     0x6c6500: b.ls            #0x6c6528
    // 0x6c6504: LoadField: r0 = r1->field_f
    //     0x6c6504: ldur            w0, [x1, #0xf]
    // 0x6c6508: DecompressPointer r0
    //     0x6c6508: add             x0, x0, HEAP, lsl #32
    // 0x6c650c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c650c: ldur            w1, [x0, #0x17]
    // 0x6c6510: DecompressPointer r1
    //     0x6c6510: add             x1, x1, HEAP, lsl #32
    // 0x6c6514: r2 = 28
    //     0x6c6514: movz            x2, #0x1c
    // 0x6c6518: r0 = contains()
    //     0x6c6518: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6c651c: LeaveFrame
    //     0x6c651c: mov             SP, fp
    //     0x6c6520: ldp             fp, lr, [SP], #0x10
    // 0x6c6524: ret
    //     0x6c6524: ret             
    // 0x6c6528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6528: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c652c: b               #0x6c6504
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6c6530, size: 0xc
    // 0x6c6530: r0 = "Resets all above generators, upgrades, and lines and grants career capital. Each career capital increases the speed you accumulate lines and data by 1%."
    //     0x6c6530: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] "Resets all above generators, upgrades, and lines and grants career capital. Each career capital increases the speed you accumulate lines and data by 1%."
    //     0x6c6534: ldr             x0, [x0, #0x510]
    // 0x6c6538: ret
    //     0x6c6538: ret             
  }
  [closure] void prestige2(dynamic) {
    // ** addr: 0x6c653c, size: 0x38
    // 0x6c653c: EnterFrame
    //     0x6c653c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6540: mov             fp, SP
    // 0x6c6544: ldr             x0, [fp, #0x10]
    // 0x6c6548: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c6548: ldur            w1, [x0, #0x17]
    // 0x6c654c: DecompressPointer r1
    //     0x6c654c: add             x1, x1, HEAP, lsl #32
    // 0x6c6550: CheckStackOverflow
    //     0x6c6550: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6554: cmp             SP, x16
    //     0x6c6558: b.ls            #0x6c656c
    // 0x6c655c: r0 = prestige2()
    //     0x6c655c: bl              #0x6c6574  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::prestige2
    // 0x6c6560: LeaveFrame
    //     0x6c6560: mov             SP, fp
    //     0x6c6564: ldp             fp, lr, [SP], #0x10
    // 0x6c6568: ret
    //     0x6c6568: ret             
    // 0x6c656c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c656c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6570: b               #0x6c655c
  }
  _ prestige2(/* No info */) {
    // ** addr: 0x6c6574, size: 0x324
    // 0x6c6574: EnterFrame
    //     0x6c6574: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6578: mov             fp, SP
    // 0x6c657c: AllocStack(0x20)
    //     0x6c657c: sub             SP, SP, #0x20
    // 0x6c6580: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x8 */)
    //     0x6c6580: mov             x0, x1
    //     0x6c6584: stur            x1, [fp, #-8]
    // 0x6c6588: CheckStackOverflow
    //     0x6c6588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c658c: cmp             SP, x16
    //     0x6c6590: b.ls            #0x6c6888
    // 0x6c6594: mov             x1, x0
    // 0x6c6598: r0 = capitalOnProject()
    //     0x6c6598: bl              #0x6c6bd4  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::capitalOnProject
    // 0x6c659c: mov             x3, x0
    // 0x6c65a0: ldur            x0, [fp, #-8]
    // 0x6c65a4: stur            x3, [fp, #-0x18]
    // 0x6c65a8: LoadField: r4 = r0->field_37
    //     0x6c65a8: ldur            w4, [x0, #0x37]
    // 0x6c65ac: DecompressPointer r4
    //     0x6c65ac: add             x4, x4, HEAP, lsl #32
    // 0x6c65b0: mov             x1, x4
    // 0x6c65b4: stur            x4, [fp, #-0x10]
    // 0x6c65b8: r2 = Instance_Chapter9Stat
    //     0x6c65b8: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x6c65bc: ldr             x2, [x2, #0x8f0]
    // 0x6c65c0: r0 = _getValueOrData()
    //     0x6c65c0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c65c4: mov             x1, x0
    // 0x6c65c8: ldur            x0, [fp, #-0x10]
    // 0x6c65cc: LoadField: r2 = r0->field_f
    //     0x6c65cc: ldur            w2, [x0, #0xf]
    // 0x6c65d0: DecompressPointer r2
    //     0x6c65d0: add             x2, x2, HEAP, lsl #32
    // 0x6c65d4: cmp             w2, w1
    // 0x6c65d8: b.ne            #0x6c65e0
    // 0x6c65dc: r1 = Null
    //     0x6c65dc: mov             x1, NULL
    // 0x6c65e0: cmp             w1, NULL
    // 0x6c65e4: b.ne            #0x6c65f0
    // 0x6c65e8: r1 = Instance_CustomNum
    //     0x6c65e8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c65ec: ldr             x1, [x1, #0xaf8]
    // 0x6c65f0: ldur            x3, [fp, #-8]
    // 0x6c65f4: ldur            x2, [fp, #-0x18]
    // 0x6c65f8: r0 = add()
    //     0x6c65f8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6c65fc: ldur            x1, [fp, #-0x10]
    // 0x6c6600: mov             x3, x0
    // 0x6c6604: r2 = Instance_Chapter9Stat
    //     0x6c6604: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x6c6608: ldr             x2, [x2, #0x8f0]
    // 0x6c660c: r0 = []=()
    //     0x6c660c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c6610: ldur            x0, [fp, #-8]
    // 0x6c6614: LoadField: r3 = r0->field_3b
    //     0x6c6614: ldur            w3, [x0, #0x3b]
    // 0x6c6618: DecompressPointer r3
    //     0x6c6618: add             x3, x3, HEAP, lsl #32
    // 0x6c661c: mov             x1, x3
    // 0x6c6620: stur            x3, [fp, #-0x10]
    // 0x6c6624: r2 = Instance_Chapter9Stat
    //     0x6c6624: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x6c6628: ldr             x2, [x2, #0x8f0]
    // 0x6c662c: r0 = _getValueOrData()
    //     0x6c662c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6630: mov             x1, x0
    // 0x6c6634: ldur            x0, [fp, #-0x10]
    // 0x6c6638: LoadField: r2 = r0->field_f
    //     0x6c6638: ldur            w2, [x0, #0xf]
    // 0x6c663c: DecompressPointer r2
    //     0x6c663c: add             x2, x2, HEAP, lsl #32
    // 0x6c6640: cmp             w2, w1
    // 0x6c6644: b.ne            #0x6c664c
    // 0x6c6648: r1 = Null
    //     0x6c6648: mov             x1, NULL
    // 0x6c664c: cmp             w1, NULL
    // 0x6c6650: b.ne            #0x6c665c
    // 0x6c6654: r1 = Instance_CustomNum
    //     0x6c6654: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c6658: ldr             x1, [x1, #0xaf8]
    // 0x6c665c: ldur            x3, [fp, #-8]
    // 0x6c6660: ldur            x2, [fp, #-0x18]
    // 0x6c6664: r0 = add()
    //     0x6c6664: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6c6668: ldur            x1, [fp, #-0x10]
    // 0x6c666c: mov             x3, x0
    // 0x6c6670: r2 = Instance_Chapter9Stat
    //     0x6c6670: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x6c6674: ldr             x2, [x2, #0x8f0]
    // 0x6c6678: r0 = []=()
    //     0x6c6678: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c667c: ldur            x1, [fp, #-8]
    // 0x6c6680: r2 = Instance_Chapter9Stat
    //     0x6c6680: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f0] Obj!Chapter9Stat@85ef61
    //     0x6c6684: ldr             x2, [x2, #0x8f0]
    // 0x6c6688: r0 = notifyStatGained()
    //     0x6c6688: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6c668c: ldur            x0, [fp, #-8]
    // 0x6c6690: LoadField: r1 = r0->field_37
    //     0x6c6690: ldur            w1, [x0, #0x37]
    // 0x6c6694: DecompressPointer r1
    //     0x6c6694: add             x1, x1, HEAP, lsl #32
    // 0x6c6698: r2 = Instance_Chapter9Stat
    //     0x6c6698: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c669c: ldr             x2, [x2, #0x8a0]
    // 0x6c66a0: r3 = Instance_CustomNum
    //     0x6c66a0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c66a4: ldr             x3, [x3, #0xaf8]
    // 0x6c66a8: r0 = []=()
    //     0x6c66a8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c66ac: ldur            x0, [fp, #-8]
    // 0x6c66b0: LoadField: r1 = r0->field_3b
    //     0x6c66b0: ldur            w1, [x0, #0x3b]
    // 0x6c66b4: DecompressPointer r1
    //     0x6c66b4: add             x1, x1, HEAP, lsl #32
    // 0x6c66b8: r2 = Instance_Chapter9Stat
    //     0x6c66b8: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c66bc: ldr             x2, [x2, #0x8a0]
    // 0x6c66c0: r3 = Instance_CustomNum
    //     0x6c66c0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c66c4: ldr             x3, [x3, #0xaf8]
    // 0x6c66c8: r0 = []=()
    //     0x6c66c8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c66cc: ldur            x0, [fp, #-8]
    // 0x6c66d0: LoadField: r1 = r0->field_37
    //     0x6c66d0: ldur            w1, [x0, #0x37]
    // 0x6c66d4: DecompressPointer r1
    //     0x6c66d4: add             x1, x1, HEAP, lsl #32
    // 0x6c66d8: r2 = Instance_Chapter9Stat
    //     0x6c66d8: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x6c66dc: ldr             x2, [x2, #0x8d8]
    // 0x6c66e0: r3 = Instance_CustomNum
    //     0x6c66e0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c66e4: ldr             x3, [x3, #0xaf8]
    // 0x6c66e8: r0 = []=()
    //     0x6c66e8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c66ec: ldur            x0, [fp, #-8]
    // 0x6c66f0: LoadField: r1 = r0->field_3b
    //     0x6c66f0: ldur            w1, [x0, #0x3b]
    // 0x6c66f4: DecompressPointer r1
    //     0x6c66f4: add             x1, x1, HEAP, lsl #32
    // 0x6c66f8: r2 = Instance_Chapter9Stat
    //     0x6c66f8: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x6c66fc: ldr             x2, [x2, #0x8d8]
    // 0x6c6700: r3 = Instance_CustomNum
    //     0x6c6700: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c6704: ldr             x3, [x3, #0xaf8]
    // 0x6c6708: r0 = []=()
    //     0x6c6708: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c670c: ldur            x0, [fp, #-8]
    // 0x6c6710: LoadField: r1 = r0->field_37
    //     0x6c6710: ldur            w1, [x0, #0x37]
    // 0x6c6714: DecompressPointer r1
    //     0x6c6714: add             x1, x1, HEAP, lsl #32
    // 0x6c6718: r2 = Instance_Chapter9Stat
    //     0x6c6718: add             x2, PP, #0x11, lsl #12  ; [pp+0x118e0] Obj!Chapter9Stat@85ef81
    //     0x6c671c: ldr             x2, [x2, #0x8e0]
    // 0x6c6720: r0 = remove()
    //     0x6c6720: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6724: r4 = 11
    //     0x6c6724: movz            x4, #0xb
    // 0x6c6728: ldur            x3, [fp, #-8]
    // 0x6c672c: stur            x4, [fp, #-0x20]
    // 0x6c6730: CheckStackOverflow
    //     0x6c6730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6734: cmp             SP, x16
    //     0x6c6738: b.ls            #0x6c6890
    // 0x6c673c: cmp             x4, #0xe
    // 0x6c6740: b.gt            #0x6c6778
    // 0x6c6744: LoadField: r2 = r3->field_47
    //     0x6c6744: ldur            w2, [x3, #0x47]
    // 0x6c6748: DecompressPointer r2
    //     0x6c6748: add             x2, x2, HEAP, lsl #32
    // 0x6c674c: r0 = BoxInt64Instr(r4)
    //     0x6c674c: sbfiz           x0, x4, #1, #0x1f
    //     0x6c6750: cmp             x4, x0, asr #1
    //     0x6c6754: b.eq            #0x6c6760
    //     0x6c6758: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6c675c: stur            x4, [x0, #7]
    // 0x6c6760: mov             x1, x2
    // 0x6c6764: mov             x2, x0
    // 0x6c6768: r0 = remove()
    //     0x6c6768: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c676c: ldur            x0, [fp, #-0x20]
    // 0x6c6770: add             x4, x0, #1
    // 0x6c6774: b               #0x6c6728
    // 0x6c6778: mov             x0, x3
    // 0x6c677c: LoadField: r3 = r0->field_43
    //     0x6c677c: ldur            w3, [x0, #0x43]
    // 0x6c6780: DecompressPointer r3
    //     0x6c6780: add             x3, x3, HEAP, lsl #32
    // 0x6c6784: mov             x1, x3
    // 0x6c6788: stur            x3, [fp, #-0x10]
    // 0x6c678c: r2 = 42
    //     0x6c678c: movz            x2, #0x2a
    // 0x6c6790: r0 = _getValueOrData()
    //     0x6c6790: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6794: mov             x1, x0
    // 0x6c6798: ldur            x0, [fp, #-0x10]
    // 0x6c679c: LoadField: r2 = r0->field_f
    //     0x6c679c: ldur            w2, [x0, #0xf]
    // 0x6c67a0: DecompressPointer r2
    //     0x6c67a0: add             x2, x2, HEAP, lsl #32
    // 0x6c67a4: cmp             w2, w1
    // 0x6c67a8: b.ne            #0x6c67b4
    // 0x6c67ac: r0 = Null
    //     0x6c67ac: mov             x0, NULL
    // 0x6c67b0: b               #0x6c67b8
    // 0x6c67b4: mov             x0, x1
    // 0x6c67b8: cmp             w0, NULL
    // 0x6c67bc: b.ne            #0x6c67c8
    // 0x6c67c0: r0 = 0
    //     0x6c67c0: movz            x0, #0
    // 0x6c67c4: b               #0x6c67d8
    // 0x6c67c8: r1 = LoadInt32Instr(r0)
    //     0x6c67c8: sbfx            x1, x0, #1, #0x1f
    //     0x6c67cc: tbz             w0, #0, #0x6c67d4
    //     0x6c67d0: ldur            x1, [x0, #7]
    // 0x6c67d4: mov             x0, x1
    // 0x6c67d8: cmp             x0, #2
    // 0x6c67dc: b.ge            #0x6c6808
    // 0x6c67e0: ldur            x0, [fp, #-8]
    // 0x6c67e4: LoadField: r1 = r0->field_43
    //     0x6c67e4: ldur            w1, [x0, #0x43]
    // 0x6c67e8: DecompressPointer r1
    //     0x6c67e8: add             x1, x1, HEAP, lsl #32
    // 0x6c67ec: r2 = 22
    //     0x6c67ec: movz            x2, #0x16
    // 0x6c67f0: r0 = remove()
    //     0x6c67f0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c67f4: ldur            x0, [fp, #-8]
    // 0x6c67f8: LoadField: r1 = r0->field_43
    //     0x6c67f8: ldur            w1, [x0, #0x43]
    // 0x6c67fc: DecompressPointer r1
    //     0x6c67fc: add             x1, x1, HEAP, lsl #32
    // 0x6c6800: r2 = 24
    //     0x6c6800: movz            x2, #0x18
    // 0x6c6804: r0 = remove()
    //     0x6c6804: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6808: ldur            x0, [fp, #-8]
    // 0x6c680c: LoadField: r1 = r0->field_37
    //     0x6c680c: ldur            w1, [x0, #0x37]
    // 0x6c6810: DecompressPointer r1
    //     0x6c6810: add             x1, x1, HEAP, lsl #32
    // 0x6c6814: r2 = Instance_Chapter9Stat
    //     0x6c6814: add             x2, PP, #0x11, lsl #12  ; [pp+0x11848] Obj!Chapter9Stat@85f061
    //     0x6c6818: ldr             x2, [x2, #0x848]
    // 0x6c681c: r0 = remove()
    //     0x6c681c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6820: ldur            x0, [fp, #-8]
    // 0x6c6824: LoadField: r1 = r0->field_37
    //     0x6c6824: ldur            w1, [x0, #0x37]
    // 0x6c6828: DecompressPointer r1
    //     0x6c6828: add             x1, x1, HEAP, lsl #32
    // 0x6c682c: r2 = Instance_Chapter9Stat
    //     0x6c682c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11850] Obj!Chapter9Stat@85f041
    //     0x6c6830: ldr             x2, [x2, #0x850]
    // 0x6c6834: r0 = remove()
    //     0x6c6834: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6838: ldur            x0, [fp, #-8]
    // 0x6c683c: LoadField: r1 = r0->field_37
    //     0x6c683c: ldur            w1, [x0, #0x37]
    // 0x6c6840: DecompressPointer r1
    //     0x6c6840: add             x1, x1, HEAP, lsl #32
    // 0x6c6844: r2 = Instance_Chapter9Stat
    //     0x6c6844: add             x2, PP, #0x11, lsl #12  ; [pp+0x11858] Obj!Chapter9Stat@85f021
    //     0x6c6848: ldr             x2, [x2, #0x858]
    // 0x6c684c: r0 = remove()
    //     0x6c684c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6850: ldur            x0, [fp, #-8]
    // 0x6c6854: LoadField: r1 = r0->field_37
    //     0x6c6854: ldur            w1, [x0, #0x37]
    // 0x6c6858: DecompressPointer r1
    //     0x6c6858: add             x1, x1, HEAP, lsl #32
    // 0x6c685c: r2 = Instance_Chapter9Stat
    //     0x6c685c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11860] Obj!Chapter9Stat@85f001
    //     0x6c6860: ldr             x2, [x2, #0x860]
    // 0x6c6864: r0 = remove()
    //     0x6c6864: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6868: ldur            x1, [fp, #-8]
    // 0x6c686c: r0 = resetAndRecomputeBoosts()
    //     0x6c686c: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x6c6870: ldur            x1, [fp, #-8]
    // 0x6c6874: r0 = prestige1()
    //     0x6c6874: bl              #0x6c6898  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::prestige1
    // 0x6c6878: r0 = Null
    //     0x6c6878: mov             x0, NULL
    // 0x6c687c: LeaveFrame
    //     0x6c687c: mov             SP, fp
    //     0x6c6880: ldp             fp, lr, [SP], #0x10
    // 0x6c6884: ret
    //     0x6c6884: ret             
    // 0x6c6888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6888: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c688c: b               #0x6c6594
    // 0x6c6890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6890: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6894: b               #0x6c673c
  }
  _ prestige1(/* No info */) {
    // ** addr: 0x6c6898, size: 0x2ac
    // 0x6c6898: EnterFrame
    //     0x6c6898: stp             fp, lr, [SP, #-0x10]!
    //     0x6c689c: mov             fp, SP
    // 0x6c68a0: AllocStack(0x20)
    //     0x6c68a0: sub             SP, SP, #0x20
    // 0x6c68a4: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x8 */)
    //     0x6c68a4: mov             x0, x1
    //     0x6c68a8: stur            x1, [fp, #-8]
    // 0x6c68ac: CheckStackOverflow
    //     0x6c68ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c68b0: cmp             SP, x16
    //     0x6c68b4: b.ls            #0x6c6b34
    // 0x6c68b8: mov             x1, x0
    // 0x6c68bc: r0 = knowledgeOnRewrite()
    //     0x6c68bc: bl              #0x6c6b44  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::knowledgeOnRewrite
    // 0x6c68c0: mov             x3, x0
    // 0x6c68c4: ldur            x0, [fp, #-8]
    // 0x6c68c8: stur            x3, [fp, #-0x18]
    // 0x6c68cc: LoadField: r4 = r0->field_37
    //     0x6c68cc: ldur            w4, [x0, #0x37]
    // 0x6c68d0: DecompressPointer r4
    //     0x6c68d0: add             x4, x4, HEAP, lsl #32
    // 0x6c68d4: mov             x1, x4
    // 0x6c68d8: stur            x4, [fp, #-0x10]
    // 0x6c68dc: r2 = Instance_Chapter9Stat
    //     0x6c68dc: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c68e0: ldr             x2, [x2, #0x8a0]
    // 0x6c68e4: r0 = _getValueOrData()
    //     0x6c68e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c68e8: mov             x1, x0
    // 0x6c68ec: ldur            x0, [fp, #-0x10]
    // 0x6c68f0: LoadField: r2 = r0->field_f
    //     0x6c68f0: ldur            w2, [x0, #0xf]
    // 0x6c68f4: DecompressPointer r2
    //     0x6c68f4: add             x2, x2, HEAP, lsl #32
    // 0x6c68f8: cmp             w2, w1
    // 0x6c68fc: b.ne            #0x6c6904
    // 0x6c6900: r1 = Null
    //     0x6c6900: mov             x1, NULL
    // 0x6c6904: cmp             w1, NULL
    // 0x6c6908: b.ne            #0x6c6914
    // 0x6c690c: r1 = Instance_CustomNum
    //     0x6c690c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c6910: ldr             x1, [x1, #0xaf8]
    // 0x6c6914: ldur            x3, [fp, #-8]
    // 0x6c6918: ldur            x2, [fp, #-0x18]
    // 0x6c691c: r0 = add()
    //     0x6c691c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6c6920: ldur            x1, [fp, #-0x10]
    // 0x6c6924: mov             x3, x0
    // 0x6c6928: r2 = Instance_Chapter9Stat
    //     0x6c6928: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c692c: ldr             x2, [x2, #0x8a0]
    // 0x6c6930: r0 = []=()
    //     0x6c6930: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c6934: ldur            x0, [fp, #-8]
    // 0x6c6938: LoadField: r3 = r0->field_3b
    //     0x6c6938: ldur            w3, [x0, #0x3b]
    // 0x6c693c: DecompressPointer r3
    //     0x6c693c: add             x3, x3, HEAP, lsl #32
    // 0x6c6940: mov             x1, x3
    // 0x6c6944: stur            x3, [fp, #-0x10]
    // 0x6c6948: r2 = Instance_Chapter9Stat
    //     0x6c6948: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c694c: ldr             x2, [x2, #0x8a0]
    // 0x6c6950: r0 = _getValueOrData()
    //     0x6c6950: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6954: mov             x1, x0
    // 0x6c6958: ldur            x0, [fp, #-0x10]
    // 0x6c695c: LoadField: r2 = r0->field_f
    //     0x6c695c: ldur            w2, [x0, #0xf]
    // 0x6c6960: DecompressPointer r2
    //     0x6c6960: add             x2, x2, HEAP, lsl #32
    // 0x6c6964: cmp             w2, w1
    // 0x6c6968: b.ne            #0x6c6970
    // 0x6c696c: r1 = Null
    //     0x6c696c: mov             x1, NULL
    // 0x6c6970: cmp             w1, NULL
    // 0x6c6974: b.ne            #0x6c6980
    // 0x6c6978: r1 = Instance_CustomNum
    //     0x6c6978: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c697c: ldr             x1, [x1, #0xaf8]
    // 0x6c6980: ldur            x3, [fp, #-8]
    // 0x6c6984: ldur            x2, [fp, #-0x18]
    // 0x6c6988: r0 = add()
    //     0x6c6988: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6c698c: ldur            x1, [fp, #-0x10]
    // 0x6c6990: mov             x3, x0
    // 0x6c6994: r2 = Instance_Chapter9Stat
    //     0x6c6994: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c6998: ldr             x2, [x2, #0x8a0]
    // 0x6c699c: r0 = []=()
    //     0x6c699c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c69a0: ldur            x1, [fp, #-8]
    // 0x6c69a4: r2 = Instance_Chapter9Stat
    //     0x6c69a4: add             x2, PP, #0x11, lsl #12  ; [pp+0x118a0] Obj!Chapter9Stat@85efc1
    //     0x6c69a8: ldr             x2, [x2, #0x8a0]
    // 0x6c69ac: r0 = notifyStatGained()
    //     0x6c69ac: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6c69b0: ldur            x0, [fp, #-8]
    // 0x6c69b4: LoadField: r1 = r0->field_37
    //     0x6c69b4: ldur            w1, [x0, #0x37]
    // 0x6c69b8: DecompressPointer r1
    //     0x6c69b8: add             x1, x1, HEAP, lsl #32
    // 0x6c69bc: r2 = Instance_Chapter9Stat
    //     0x6c69bc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c69c0: ldr             x2, [x2, #0x890]
    // 0x6c69c4: r3 = Instance_CustomNum
    //     0x6c69c4: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c69c8: ldr             x3, [x3, #0xaf8]
    // 0x6c69cc: r0 = []=()
    //     0x6c69cc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c69d0: ldur            x0, [fp, #-8]
    // 0x6c69d4: LoadField: r1 = r0->field_3b
    //     0x6c69d4: ldur            w1, [x0, #0x3b]
    // 0x6c69d8: DecompressPointer r1
    //     0x6c69d8: add             x1, x1, HEAP, lsl #32
    // 0x6c69dc: r2 = Instance_Chapter9Stat
    //     0x6c69dc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c69e0: ldr             x2, [x2, #0x890]
    // 0x6c69e4: r3 = Instance_CustomNum
    //     0x6c69e4: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c69e8: ldr             x3, [x3, #0xaf8]
    // 0x6c69ec: r0 = []=()
    //     0x6c69ec: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c69f0: ldur            x0, [fp, #-8]
    // 0x6c69f4: LoadField: r1 = r0->field_37
    //     0x6c69f4: ldur            w1, [x0, #0x37]
    // 0x6c69f8: DecompressPointer r1
    //     0x6c69f8: add             x1, x1, HEAP, lsl #32
    // 0x6c69fc: r2 = Instance_Chapter9Stat
    //     0x6c69fc: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x6c6a00: ldr             x2, [x2, #0x8d8]
    // 0x6c6a04: r0 = remove()
    //     0x6c6a04: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6a08: r4 = 1
    //     0x6c6a08: movz            x4, #0x1
    // 0x6c6a0c: ldur            x3, [fp, #-8]
    // 0x6c6a10: stur            x4, [fp, #-0x20]
    // 0x6c6a14: CheckStackOverflow
    //     0x6c6a14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6a18: cmp             SP, x16
    //     0x6c6a1c: b.ls            #0x6c6b3c
    // 0x6c6a20: cmp             x4, #5
    // 0x6c6a24: b.gt            #0x6c6a5c
    // 0x6c6a28: LoadField: r2 = r3->field_47
    //     0x6c6a28: ldur            w2, [x3, #0x47]
    // 0x6c6a2c: DecompressPointer r2
    //     0x6c6a2c: add             x2, x2, HEAP, lsl #32
    // 0x6c6a30: r0 = BoxInt64Instr(r4)
    //     0x6c6a30: sbfiz           x0, x4, #1, #0x1f
    //     0x6c6a34: cmp             x4, x0, asr #1
    //     0x6c6a38: b.eq            #0x6c6a44
    //     0x6c6a3c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6c6a40: stur            x4, [x0, #7]
    // 0x6c6a44: mov             x1, x2
    // 0x6c6a48: mov             x2, x0
    // 0x6c6a4c: r0 = remove()
    //     0x6c6a4c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6a50: ldur            x0, [fp, #-0x20]
    // 0x6c6a54: add             x4, x0, #1
    // 0x6c6a58: b               #0x6c6a0c
    // 0x6c6a5c: mov             x0, x3
    // 0x6c6a60: LoadField: r1 = r0->field_43
    //     0x6c6a60: ldur            w1, [x0, #0x43]
    // 0x6c6a64: DecompressPointer r1
    //     0x6c6a64: add             x1, x1, HEAP, lsl #32
    // 0x6c6a68: r2 = 42
    //     0x6c6a68: movz            x2, #0x2a
    // 0x6c6a6c: r0 = containsKey()
    //     0x6c6a6c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6c6a70: tbz             w0, #4, #0x6c6a9c
    // 0x6c6a74: ldur            x0, [fp, #-8]
    // 0x6c6a78: LoadField: r1 = r0->field_43
    //     0x6c6a78: ldur            w1, [x0, #0x43]
    // 0x6c6a7c: DecompressPointer r1
    //     0x6c6a7c: add             x1, x1, HEAP, lsl #32
    // 0x6c6a80: r2 = 2
    //     0x6c6a80: movz            x2, #0x2
    // 0x6c6a84: r0 = remove()
    //     0x6c6a84: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6a88: ldur            x0, [fp, #-8]
    // 0x6c6a8c: LoadField: r1 = r0->field_43
    //     0x6c6a8c: ldur            w1, [x0, #0x43]
    // 0x6c6a90: DecompressPointer r1
    //     0x6c6a90: add             x1, x1, HEAP, lsl #32
    // 0x6c6a94: r2 = 4
    //     0x6c6a94: movz            x2, #0x4
    // 0x6c6a98: r0 = remove()
    //     0x6c6a98: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6a9c: ldur            x0, [fp, #-8]
    // 0x6c6aa0: LoadField: r1 = r0->field_37
    //     0x6c6aa0: ldur            w1, [x0, #0x37]
    // 0x6c6aa4: DecompressPointer r1
    //     0x6c6aa4: add             x1, x1, HEAP, lsl #32
    // 0x6c6aa8: r2 = Instance_Chapter9Stat
    //     0x6c6aa8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11820] Obj!Chapter9Stat@85f101
    //     0x6c6aac: ldr             x2, [x2, #0x820]
    // 0x6c6ab0: r0 = remove()
    //     0x6c6ab0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6ab4: ldur            x0, [fp, #-8]
    // 0x6c6ab8: LoadField: r1 = r0->field_37
    //     0x6c6ab8: ldur            w1, [x0, #0x37]
    // 0x6c6abc: DecompressPointer r1
    //     0x6c6abc: add             x1, x1, HEAP, lsl #32
    // 0x6c6ac0: r2 = Instance_Chapter9Stat
    //     0x6c6ac0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11828] Obj!Chapter9Stat@85f0e1
    //     0x6c6ac4: ldr             x2, [x2, #0x828]
    // 0x6c6ac8: r0 = remove()
    //     0x6c6ac8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6acc: ldur            x0, [fp, #-8]
    // 0x6c6ad0: LoadField: r1 = r0->field_37
    //     0x6c6ad0: ldur            w1, [x0, #0x37]
    // 0x6c6ad4: DecompressPointer r1
    //     0x6c6ad4: add             x1, x1, HEAP, lsl #32
    // 0x6c6ad8: r2 = Instance_Chapter9Stat
    //     0x6c6ad8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11830] Obj!Chapter9Stat@85f0c1
    //     0x6c6adc: ldr             x2, [x2, #0x830]
    // 0x6c6ae0: r0 = remove()
    //     0x6c6ae0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6ae4: ldur            x0, [fp, #-8]
    // 0x6c6ae8: LoadField: r1 = r0->field_37
    //     0x6c6ae8: ldur            w1, [x0, #0x37]
    // 0x6c6aec: DecompressPointer r1
    //     0x6c6aec: add             x1, x1, HEAP, lsl #32
    // 0x6c6af0: r2 = Instance_Chapter9Stat
    //     0x6c6af0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11838] Obj!Chapter9Stat@85f0a1
    //     0x6c6af4: ldr             x2, [x2, #0x838]
    // 0x6c6af8: r0 = remove()
    //     0x6c6af8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6afc: ldur            x0, [fp, #-8]
    // 0x6c6b00: LoadField: r1 = r0->field_37
    //     0x6c6b00: ldur            w1, [x0, #0x37]
    // 0x6c6b04: DecompressPointer r1
    //     0x6c6b04: add             x1, x1, HEAP, lsl #32
    // 0x6c6b08: r2 = Instance_Chapter9Stat
    //     0x6c6b08: add             x2, PP, #0x11, lsl #12  ; [pp+0x11840] Obj!Chapter9Stat@85f081
    //     0x6c6b0c: ldr             x2, [x2, #0x840]
    // 0x6c6b10: r0 = remove()
    //     0x6c6b10: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6c6b14: ldur            x1, [fp, #-8]
    // 0x6c6b18: r0 = applyAuctionBonus()
    //     0x6c6b18: bl              #0x50b898  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::applyAuctionBonus
    // 0x6c6b1c: ldur            x1, [fp, #-8]
    // 0x6c6b20: r0 = resetAndRecomputeBoosts()
    //     0x6c6b20: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x6c6b24: r0 = Null
    //     0x6c6b24: mov             x0, NULL
    // 0x6c6b28: LeaveFrame
    //     0x6c6b28: mov             SP, fp
    //     0x6c6b2c: ldp             fp, lr, [SP], #0x10
    // 0x6c6b30: ret
    //     0x6c6b30: ret             
    // 0x6c6b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6b34: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6b38: b               #0x6c68b8
    // 0x6c6b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6b3c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6b40: b               #0x6c6a20
  }
  _ knowledgeOnRewrite(/* No info */) {
    // ** addr: 0x6c6b44, size: 0x90
    // 0x6c6b44: EnterFrame
    //     0x6c6b44: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6b48: mov             fp, SP
    // 0x6c6b4c: AllocStack(0x8)
    //     0x6c6b4c: sub             SP, SP, #8
    // 0x6c6b50: CheckStackOverflow
    //     0x6c6b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6b54: cmp             SP, x16
    //     0x6c6b58: b.ls            #0x6c6bcc
    // 0x6c6b5c: LoadField: r0 = r1->field_3b
    //     0x6c6b5c: ldur            w0, [x1, #0x3b]
    // 0x6c6b60: DecompressPointer r0
    //     0x6c6b60: add             x0, x0, HEAP, lsl #32
    // 0x6c6b64: mov             x1, x0
    // 0x6c6b68: stur            x0, [fp, #-8]
    // 0x6c6b6c: r2 = Instance_Chapter9Stat
    //     0x6c6b6c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c6b70: ldr             x2, [x2, #0x890]
    // 0x6c6b74: r0 = _getValueOrData()
    //     0x6c6b74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6b78: mov             x1, x0
    // 0x6c6b7c: ldur            x0, [fp, #-8]
    // 0x6c6b80: LoadField: r2 = r0->field_f
    //     0x6c6b80: ldur            w2, [x0, #0xf]
    // 0x6c6b84: DecompressPointer r2
    //     0x6c6b84: add             x2, x2, HEAP, lsl #32
    // 0x6c6b88: cmp             w2, w1
    // 0x6c6b8c: b.ne            #0x6c6b98
    // 0x6c6b90: r0 = Null
    //     0x6c6b90: mov             x0, NULL
    // 0x6c6b94: b               #0x6c6b9c
    // 0x6c6b98: mov             x0, x1
    // 0x6c6b9c: cmp             w0, NULL
    // 0x6c6ba0: b.ne            #0x6c6bb0
    // 0x6c6ba4: r1 = Instance_CustomNum
    //     0x6c6ba4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c6ba8: ldr             x1, [x1, #0xaf8]
    // 0x6c6bac: b               #0x6c6bb4
    // 0x6c6bb0: mov             x1, x0
    // 0x6c6bb4: r2 = Instance_CustomNum
    //     0x6c6bb4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26518] Obj!CustomNum@82c3e1
    //     0x6c6bb8: ldr             x2, [x2, #0x518]
    // 0x6c6bbc: r0 = mult2()
    //     0x6c6bbc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6c6bc0: LeaveFrame
    //     0x6c6bc0: mov             SP, fp
    //     0x6c6bc4: ldp             fp, lr, [SP], #0x10
    // 0x6c6bc8: ret
    //     0x6c6bc8: ret             
    // 0x6c6bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6bcc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6bd0: b               #0x6c6b5c
  }
  _ capitalOnProject(/* No info */) {
    // ** addr: 0x6c6bd4, size: 0x1c4
    // 0x6c6bd4: EnterFrame
    //     0x6c6bd4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6bd8: mov             fp, SP
    // 0x6c6bdc: AllocStack(0x28)
    //     0x6c6bdc: sub             SP, SP, #0x28
    // 0x6c6be0: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x10 */)
    //     0x6c6be0: mov             x0, x1
    //     0x6c6be4: stur            x1, [fp, #-0x10]
    // 0x6c6be8: CheckStackOverflow
    //     0x6c6be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6bec: cmp             SP, x16
    //     0x6c6bf0: b.ls            #0x6c6d90
    // 0x6c6bf4: LoadField: r3 = r0->field_3b
    //     0x6c6bf4: ldur            w3, [x0, #0x3b]
    // 0x6c6bf8: DecompressPointer r3
    //     0x6c6bf8: add             x3, x3, HEAP, lsl #32
    // 0x6c6bfc: mov             x1, x3
    // 0x6c6c00: stur            x3, [fp, #-8]
    // 0x6c6c04: r2 = Instance_Chapter9Stat
    //     0x6c6c04: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x6c6c08: ldr             x2, [x2, #0x8d8]
    // 0x6c6c0c: r0 = _getValueOrData()
    //     0x6c6c0c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6c10: mov             x1, x0
    // 0x6c6c14: ldur            x0, [fp, #-8]
    // 0x6c6c18: LoadField: r2 = r0->field_f
    //     0x6c6c18: ldur            w2, [x0, #0xf]
    // 0x6c6c1c: DecompressPointer r2
    //     0x6c6c1c: add             x2, x2, HEAP, lsl #32
    // 0x6c6c20: cmp             w2, w1
    // 0x6c6c24: b.ne            #0x6c6c30
    // 0x6c6c28: r0 = Null
    //     0x6c6c28: mov             x0, NULL
    // 0x6c6c2c: b               #0x6c6c34
    // 0x6c6c30: mov             x0, x1
    // 0x6c6c34: cmp             w0, NULL
    // 0x6c6c38: b.ne            #0x6c6c48
    // 0x6c6c3c: r3 = Instance_CustomNum
    //     0x6c6c3c: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c6c40: ldr             x3, [x3, #0xaf8]
    // 0x6c6c44: b               #0x6c6c4c
    // 0x6c6c48: mov             x3, x0
    // 0x6c6c4c: ldur            x0, [fp, #-0x10]
    // 0x6c6c50: stur            x3, [fp, #-8]
    // 0x6c6c54: LoadField: r1 = r0->field_43
    //     0x6c6c54: ldur            w1, [x0, #0x43]
    // 0x6c6c58: DecompressPointer r1
    //     0x6c6c58: add             x1, x1, HEAP, lsl #32
    // 0x6c6c5c: r2 = 48
    //     0x6c6c5c: movz            x2, #0x30
    // 0x6c6c60: r0 = containsKey()
    //     0x6c6c60: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6c6c64: tbnz            w0, #4, #0x6c6d6c
    // 0x6c6c68: ldur            x0, [fp, #-0x10]
    // 0x6c6c6c: LoadField: r3 = r0->field_3b
    //     0x6c6c6c: ldur            w3, [x0, #0x3b]
    // 0x6c6c70: DecompressPointer r3
    //     0x6c6c70: add             x3, x3, HEAP, lsl #32
    // 0x6c6c74: mov             x1, x3
    // 0x6c6c78: stur            x3, [fp, #-0x18]
    // 0x6c6c7c: r2 = Instance_Chapter9Stat
    //     0x6c6c7c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c6c80: ldr             x2, [x2, #0x890]
    // 0x6c6c84: r0 = _getValueOrData()
    //     0x6c6c84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6c88: mov             x1, x0
    // 0x6c6c8c: ldur            x0, [fp, #-0x18]
    // 0x6c6c90: LoadField: r2 = r0->field_f
    //     0x6c6c90: ldur            w2, [x0, #0xf]
    // 0x6c6c94: DecompressPointer r2
    //     0x6c6c94: add             x2, x2, HEAP, lsl #32
    // 0x6c6c98: cmp             w2, w1
    // 0x6c6c9c: b.ne            #0x6c6ca8
    // 0x6c6ca0: r0 = Null
    //     0x6c6ca0: mov             x0, NULL
    // 0x6c6ca4: b               #0x6c6cac
    // 0x6c6ca8: mov             x0, x1
    // 0x6c6cac: cmp             w0, NULL
    // 0x6c6cb0: b.ne            #0x6c6cc0
    // 0x6c6cb4: r3 = Instance_CustomNum
    //     0x6c6cb4: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c6cb8: ldr             x3, [x3, #0xaf8]
    // 0x6c6cbc: b               #0x6c6cc4
    // 0x6c6cc0: mov             x3, x0
    // 0x6c6cc4: ldur            x0, [fp, #-0x10]
    // 0x6c6cc8: stur            x3, [fp, #-0x20]
    // 0x6c6ccc: LoadField: r4 = r0->field_43
    //     0x6c6ccc: ldur            w4, [x0, #0x43]
    // 0x6c6cd0: DecompressPointer r4
    //     0x6c6cd0: add             x4, x4, HEAP, lsl #32
    // 0x6c6cd4: mov             x1, x4
    // 0x6c6cd8: stur            x4, [fp, #-0x18]
    // 0x6c6cdc: r2 = 48
    //     0x6c6cdc: movz            x2, #0x30
    // 0x6c6ce0: r0 = _getValueOrData()
    //     0x6c6ce0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6ce4: mov             x1, x0
    // 0x6c6ce8: ldur            x0, [fp, #-0x18]
    // 0x6c6cec: LoadField: r2 = r0->field_f
    //     0x6c6cec: ldur            w2, [x0, #0xf]
    // 0x6c6cf0: DecompressPointer r2
    //     0x6c6cf0: add             x2, x2, HEAP, lsl #32
    // 0x6c6cf4: cmp             w2, w1
    // 0x6c6cf8: b.ne            #0x6c6d04
    // 0x6c6cfc: r0 = Null
    //     0x6c6cfc: mov             x0, NULL
    // 0x6c6d00: b               #0x6c6d08
    // 0x6c6d04: mov             x0, x1
    // 0x6c6d08: cmp             w0, NULL
    // 0x6c6d0c: b.ne            #0x6c6d18
    // 0x6c6d10: r0 = 0
    //     0x6c6d10: movz            x0, #0
    // 0x6c6d14: b               #0x6c6d28
    // 0x6c6d18: r1 = LoadInt32Instr(r0)
    //     0x6c6d18: sbfx            x1, x0, #1, #0x1f
    //     0x6c6d1c: tbz             w0, #0, #0x6c6d24
    //     0x6c6d20: ldur            x1, [x0, #7]
    // 0x6c6d24: mov             x0, x1
    // 0x6c6d28: d0 = -35.600000
    //     0x6c6d28: add             x17, PP, #0x26, lsl #12  ; [pp+0x26520] IMM: double(-35.6) from 0xc041cccccccccccd
    //     0x6c6d2c: ldr             d0, [x17, #0x520]
    // 0x6c6d30: scvtf           d1, x0
    // 0x6c6d34: fadd            d2, d1, d0
    // 0x6c6d38: stur            d2, [fp, #-0x28]
    // 0x6c6d3c: r0 = CustomNum()
    //     0x6c6d3c: bl              #0x3da324  ; AllocateCustomNumStub -> CustomNum (size=0x10)
    // 0x6c6d40: ldur            d0, [fp, #-0x28]
    // 0x6c6d44: StoreField: r0->field_7 = d0
    //     0x6c6d44: stur            d0, [x0, #7]
    // 0x6c6d48: ldur            x1, [fp, #-0x20]
    // 0x6c6d4c: mov             x2, x0
    // 0x6c6d50: r0 = mult2()
    //     0x6c6d50: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6c6d54: mov             x1, x0
    // 0x6c6d58: r2 = Instance_CustomNum
    //     0x6c6d58: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6c6d5c: ldr             x2, [x2, #0xa70]
    // 0x6c6d60: r0 = add()
    //     0x6c6d60: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6c6d64: mov             x3, x0
    // 0x6c6d68: b               #0x6c6d74
    // 0x6c6d6c: r3 = Instance_CustomNum
    //     0x6c6d6c: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6c6d70: ldr             x3, [x3, #0xa70]
    // 0x6c6d74: ldur            x1, [fp, #-8]
    // 0x6c6d78: r2 = Instance_CustomNum
    //     0x6c6d78: add             x2, PP, #0x26, lsl #12  ; [pp+0x26528] Obj!CustomNum@82c3f1
    //     0x6c6d7c: ldr             x2, [x2, #0x528]
    // 0x6c6d80: r0 = mult3()
    //     0x6c6d80: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x6c6d84: LeaveFrame
    //     0x6c6d84: mov             SP, fp
    //     0x6c6d88: ldp             fp, lr, [SP], #0x10
    // 0x6c6d8c: ret
    //     0x6c6d8c: ret             
    // 0x6c6d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6d90: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6d94: b               #0x6c6bf4
  }
  [closure] CustomNum capitalOnProject(dynamic) {
    // ** addr: 0x6c6d98, size: 0x38
    // 0x6c6d98: EnterFrame
    //     0x6c6d98: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6d9c: mov             fp, SP
    // 0x6c6da0: ldr             x0, [fp, #0x10]
    // 0x6c6da4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c6da4: ldur            w1, [x0, #0x17]
    // 0x6c6da8: DecompressPointer r1
    //     0x6c6da8: add             x1, x1, HEAP, lsl #32
    // 0x6c6dac: CheckStackOverflow
    //     0x6c6dac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6db0: cmp             SP, x16
    //     0x6c6db4: b.ls            #0x6c6dc8
    // 0x6c6db8: r0 = capitalOnProject()
    //     0x6c6db8: bl              #0x6c6bd4  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::capitalOnProject
    // 0x6c6dbc: LeaveFrame
    //     0x6c6dbc: mov             SP, fp
    //     0x6c6dc0: ldp             fp, lr, [SP], #0x10
    // 0x6c6dc4: ret
    //     0x6c6dc4: ret             
    // 0x6c6dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6dc8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6dcc: b               #0x6c6db8
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6c6dd0, size: 0x12c
    // 0x6c6dd0: EnterFrame
    //     0x6c6dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6dd4: mov             fp, SP
    // 0x6c6dd8: AllocStack(0x10)
    //     0x6c6dd8: sub             SP, SP, #0x10
    // 0x6c6ddc: SetupParameters([dynamic _ /* r0 */])
    //     0x6c6ddc: ldr             x0, [fp, #0x10]
    //     0x6c6de0: ldur            w3, [x0, #0x17]
    //     0x6c6de4: add             x3, x3, HEAP, lsl #32
    //     0x6c6de8: stur            x3, [fp, #-0x10]
    // 0x6c6dec: CheckStackOverflow
    //     0x6c6dec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6df0: cmp             SP, x16
    //     0x6c6df4: b.ls            #0x6c6ef4
    // 0x6c6df8: LoadField: r0 = r3->field_f
    //     0x6c6df8: ldur            w0, [x3, #0xf]
    // 0x6c6dfc: DecompressPointer r0
    //     0x6c6dfc: add             x0, x0, HEAP, lsl #32
    // 0x6c6e00: LoadField: r4 = r0->field_43
    //     0x6c6e00: ldur            w4, [x0, #0x43]
    // 0x6c6e04: DecompressPointer r4
    //     0x6c6e04: add             x4, x4, HEAP, lsl #32
    // 0x6c6e08: mov             x1, x4
    // 0x6c6e0c: stur            x4, [fp, #-8]
    // 0x6c6e10: r2 = 22
    //     0x6c6e10: movz            x2, #0x16
    // 0x6c6e14: r0 = _getValueOrData()
    //     0x6c6e14: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6e18: mov             x1, x0
    // 0x6c6e1c: ldur            x0, [fp, #-8]
    // 0x6c6e20: LoadField: r2 = r0->field_f
    //     0x6c6e20: ldur            w2, [x0, #0xf]
    // 0x6c6e24: DecompressPointer r2
    //     0x6c6e24: add             x2, x2, HEAP, lsl #32
    // 0x6c6e28: cmp             w2, w1
    // 0x6c6e2c: b.ne            #0x6c6e38
    // 0x6c6e30: r0 = Null
    //     0x6c6e30: mov             x0, NULL
    // 0x6c6e34: b               #0x6c6e3c
    // 0x6c6e38: mov             x0, x1
    // 0x6c6e3c: cmp             w0, NULL
    // 0x6c6e40: b.ne            #0x6c6e4c
    // 0x6c6e44: r0 = 0
    //     0x6c6e44: movz            x0, #0
    // 0x6c6e48: b               #0x6c6e5c
    // 0x6c6e4c: r1 = LoadInt32Instr(r0)
    //     0x6c6e4c: sbfx            x1, x0, #1, #0x1f
    //     0x6c6e50: tbz             w0, #0, #0x6c6e58
    //     0x6c6e54: ldur            x1, [x0, #7]
    // 0x6c6e58: mov             x0, x1
    // 0x6c6e5c: cmp             x0, #3
    // 0x6c6e60: b.lt            #0x6c6ee4
    // 0x6c6e64: ldur            x0, [fp, #-0x10]
    // 0x6c6e68: LoadField: r1 = r0->field_f
    //     0x6c6e68: ldur            w1, [x0, #0xf]
    // 0x6c6e6c: DecompressPointer r1
    //     0x6c6e6c: add             x1, x1, HEAP, lsl #32
    // 0x6c6e70: LoadField: r0 = r1->field_43
    //     0x6c6e70: ldur            w0, [x1, #0x43]
    // 0x6c6e74: DecompressPointer r0
    //     0x6c6e74: add             x0, x0, HEAP, lsl #32
    // 0x6c6e78: mov             x1, x0
    // 0x6c6e7c: stur            x0, [fp, #-8]
    // 0x6c6e80: r2 = 24
    //     0x6c6e80: movz            x2, #0x18
    // 0x6c6e84: r0 = _getValueOrData()
    //     0x6c6e84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6e88: ldur            x1, [fp, #-8]
    // 0x6c6e8c: LoadField: r2 = r1->field_f
    //     0x6c6e8c: ldur            w2, [x1, #0xf]
    // 0x6c6e90: DecompressPointer r2
    //     0x6c6e90: add             x2, x2, HEAP, lsl #32
    // 0x6c6e94: cmp             w2, w0
    // 0x6c6e98: b.ne            #0x6c6ea4
    // 0x6c6e9c: r1 = Null
    //     0x6c6e9c: mov             x1, NULL
    // 0x6c6ea0: b               #0x6c6ea8
    // 0x6c6ea4: mov             x1, x0
    // 0x6c6ea8: cmp             w1, NULL
    // 0x6c6eac: b.ne            #0x6c6eb8
    // 0x6c6eb0: r1 = 0
    //     0x6c6eb0: movz            x1, #0
    // 0x6c6eb4: b               #0x6c6ec8
    // 0x6c6eb8: r2 = LoadInt32Instr(r1)
    //     0x6c6eb8: sbfx            x2, x1, #1, #0x1f
    //     0x6c6ebc: tbz             w1, #0, #0x6c6ec4
    //     0x6c6ec0: ldur            x2, [x1, #7]
    // 0x6c6ec4: mov             x1, x2
    // 0x6c6ec8: cmp             x1, #8
    // 0x6c6ecc: b.lt            #0x6c6ee4
    // 0x6c6ed0: r0 = "Upgrades"
    //     0x6c6ed0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26508] "Upgrades"
    //     0x6c6ed4: ldr             x0, [x0, #0x508]
    // 0x6c6ed8: LeaveFrame
    //     0x6c6ed8: mov             SP, fp
    //     0x6c6edc: ldp             fp, lr, [SP], #0x10
    // 0x6c6ee0: ret
    //     0x6c6ee0: ret             
    // 0x6c6ee4: r0 = Null
    //     0x6c6ee4: mov             x0, NULL
    // 0x6c6ee8: LeaveFrame
    //     0x6c6ee8: mov             SP, fp
    //     0x6c6eec: ldp             fp, lr, [SP], #0x10
    // 0x6c6ef0: ret
    //     0x6c6ef0: ret             
    // 0x6c6ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6ef4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6ef8: b               #0x6c6df8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6c6efc, size: 0xc
    // 0x6c6efc: r0 = "Data increases the speed at which you gain lines."
    //     0x6c6efc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26538] "Data increases the speed at which you gain lines."
    //     0x6c6f00: ldr             x0, [x0, #0x538]
    // 0x6c6f04: ret
    //     0x6c6f04: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6c6f08, size: 0xb8
    // 0x6c6f08: EnterFrame
    //     0x6c6f08: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6f0c: mov             fp, SP
    // 0x6c6f10: AllocStack(0x18)
    //     0x6c6f10: sub             SP, SP, #0x18
    // 0x6c6f14: SetupParameters([dynamic _ /* r0 */])
    //     0x6c6f14: ldr             x0, [fp, #0x10]
    //     0x6c6f18: ldur            w1, [x0, #0x17]
    //     0x6c6f1c: add             x1, x1, HEAP, lsl #32
    // 0x6c6f20: CheckStackOverflow
    //     0x6c6f20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6f24: cmp             SP, x16
    //     0x6c6f28: b.ls            #0x6c6fb8
    // 0x6c6f2c: LoadField: r0 = r1->field_f
    //     0x6c6f2c: ldur            w0, [x1, #0xf]
    // 0x6c6f30: DecompressPointer r0
    //     0x6c6f30: add             x0, x0, HEAP, lsl #32
    // 0x6c6f34: LoadField: r3 = r0->field_37
    //     0x6c6f34: ldur            w3, [x0, #0x37]
    // 0x6c6f38: DecompressPointer r3
    //     0x6c6f38: add             x3, x3, HEAP, lsl #32
    // 0x6c6f3c: mov             x1, x3
    // 0x6c6f40: stur            x3, [fp, #-8]
    // 0x6c6f44: r2 = Instance_Chapter9Stat
    //     0x6c6f44: add             x2, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!Chapter9Stat@85efa1
    //     0x6c6f48: ldr             x2, [x2, #0x8d8]
    // 0x6c6f4c: r0 = _getValueOrData()
    //     0x6c6f4c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c6f50: mov             x1, x0
    // 0x6c6f54: ldur            x0, [fp, #-8]
    // 0x6c6f58: LoadField: r2 = r0->field_f
    //     0x6c6f58: ldur            w2, [x0, #0xf]
    // 0x6c6f5c: DecompressPointer r2
    //     0x6c6f5c: add             x2, x2, HEAP, lsl #32
    // 0x6c6f60: cmp             w2, w1
    // 0x6c6f64: b.ne            #0x6c6f6c
    // 0x6c6f68: r1 = Null
    //     0x6c6f68: mov             x1, NULL
    // 0x6c6f6c: cmp             w1, NULL
    // 0x6c6f70: b.ne            #0x6c6f7c
    // 0x6c6f74: r1 = Null
    //     0x6c6f74: mov             x1, NULL
    // 0x6c6f78: b               #0x6c6f98
    // 0x6c6f7c: r16 = false
    //     0x6c6f7c: add             x16, NULL, #0x30  ; false
    // 0x6c6f80: r30 = 4
    //     0x6c6f80: movz            lr, #0x4
    // 0x6c6f84: stp             lr, x16, [SP]
    // 0x6c6f88: r4 = const [0, 0x3, 0x2, 0x1, allowNegativeExponents, 0x1, numDecimalPlaces, 0x2, null]
    //     0x6c6f88: add             x4, PP, #0x26, lsl #12  ; [pp+0x26540] List(9) [0, 0x3, 0x2, 0x1, "allowNegativeExponents", 0x1, "numDecimalPlaces", 0x2, Null]
    //     0x6c6f8c: ldr             x4, [x4, #0x540]
    // 0x6c6f90: r0 = toStringConsistentDecimalPlaces()
    //     0x6c6f90: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6c6f94: mov             x1, x0
    // 0x6c6f98: cmp             w1, NULL
    // 0x6c6f9c: b.ne            #0x6c6fa8
    // 0x6c6fa0: r0 = "0"
    //     0x6c6fa0: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6c6fa4: b               #0x6c6fac
    // 0x6c6fa8: mov             x0, x1
    // 0x6c6fac: LeaveFrame
    //     0x6c6fac: mov             SP, fp
    //     0x6c6fb0: ldp             fp, lr, [SP], #0x10
    // 0x6c6fb4: ret
    //     0x6c6fb4: ret             
    // 0x6c6fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6fb8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6fbc: b               #0x6c6f2c
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6c6fc0, size: 0xc
    // 0x6c6fc0: r0 = "Resets all above generators, upgrades, and lines and grants knowledge. Each knowledge increases the speed you accumulate lines by 1%."
    //     0x6c6fc0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26548] "Resets all above generators, upgrades, and lines and grants knowledge. Each knowledge increases the speed you accumulate lines by 1%."
    //     0x6c6fc4: ldr             x0, [x0, #0x548]
    // 0x6c6fc8: ret
    //     0x6c6fc8: ret             
  }
  [closure] void prestige1(dynamic) {
    // ** addr: 0x6c6fcc, size: 0x38
    // 0x6c6fcc: EnterFrame
    //     0x6c6fcc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6fd0: mov             fp, SP
    // 0x6c6fd4: ldr             x0, [fp, #0x10]
    // 0x6c6fd8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c6fd8: ldur            w1, [x0, #0x17]
    // 0x6c6fdc: DecompressPointer r1
    //     0x6c6fdc: add             x1, x1, HEAP, lsl #32
    // 0x6c6fe0: CheckStackOverflow
    //     0x6c6fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6fe4: cmp             SP, x16
    //     0x6c6fe8: b.ls            #0x6c6ffc
    // 0x6c6fec: r0 = prestige1()
    //     0x6c6fec: bl              #0x6c6898  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::prestige1
    // 0x6c6ff0: LeaveFrame
    //     0x6c6ff0: mov             SP, fp
    //     0x6c6ff4: ldp             fp, lr, [SP], #0x10
    // 0x6c6ff8: ret
    //     0x6c6ff8: ret             
    // 0x6c6ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6ffc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7000: b               #0x6c6fec
  }
  [closure] CustomNum knowledgeOnRewrite(dynamic) {
    // ** addr: 0x6c7004, size: 0x38
    // 0x6c7004: EnterFrame
    //     0x6c7004: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7008: mov             fp, SP
    // 0x6c700c: ldr             x0, [fp, #0x10]
    // 0x6c7010: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c7010: ldur            w1, [x0, #0x17]
    // 0x6c7014: DecompressPointer r1
    //     0x6c7014: add             x1, x1, HEAP, lsl #32
    // 0x6c7018: CheckStackOverflow
    //     0x6c7018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c701c: cmp             SP, x16
    //     0x6c7020: b.ls            #0x6c7034
    // 0x6c7024: r0 = knowledgeOnRewrite()
    //     0x6c7024: bl              #0x6c6b44  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::knowledgeOnRewrite
    // 0x6c7028: LeaveFrame
    //     0x6c7028: mov             SP, fp
    //     0x6c702c: ldp             fp, lr, [SP], #0x10
    // 0x6c7030: ret
    //     0x6c7030: ret             
    // 0x6c7034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7034: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7038: b               #0x6c7024
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6c703c, size: 0x12c
    // 0x6c703c: EnterFrame
    //     0x6c703c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7040: mov             fp, SP
    // 0x6c7044: AllocStack(0x10)
    //     0x6c7044: sub             SP, SP, #0x10
    // 0x6c7048: SetupParameters([dynamic _ /* r0 */])
    //     0x6c7048: ldr             x0, [fp, #0x10]
    //     0x6c704c: ldur            w3, [x0, #0x17]
    //     0x6c7050: add             x3, x3, HEAP, lsl #32
    //     0x6c7054: stur            x3, [fp, #-0x10]
    // 0x6c7058: CheckStackOverflow
    //     0x6c7058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c705c: cmp             SP, x16
    //     0x6c7060: b.ls            #0x6c7160
    // 0x6c7064: LoadField: r0 = r3->field_f
    //     0x6c7064: ldur            w0, [x3, #0xf]
    // 0x6c7068: DecompressPointer r0
    //     0x6c7068: add             x0, x0, HEAP, lsl #32
    // 0x6c706c: LoadField: r4 = r0->field_43
    //     0x6c706c: ldur            w4, [x0, #0x43]
    // 0x6c7070: DecompressPointer r4
    //     0x6c7070: add             x4, x4, HEAP, lsl #32
    // 0x6c7074: mov             x1, x4
    // 0x6c7078: stur            x4, [fp, #-8]
    // 0x6c707c: r2 = 2
    //     0x6c707c: movz            x2, #0x2
    // 0x6c7080: r0 = _getValueOrData()
    //     0x6c7080: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c7084: mov             x1, x0
    // 0x6c7088: ldur            x0, [fp, #-8]
    // 0x6c708c: LoadField: r2 = r0->field_f
    //     0x6c708c: ldur            w2, [x0, #0xf]
    // 0x6c7090: DecompressPointer r2
    //     0x6c7090: add             x2, x2, HEAP, lsl #32
    // 0x6c7094: cmp             w2, w1
    // 0x6c7098: b.ne            #0x6c70a4
    // 0x6c709c: r0 = Null
    //     0x6c709c: mov             x0, NULL
    // 0x6c70a0: b               #0x6c70a8
    // 0x6c70a4: mov             x0, x1
    // 0x6c70a8: cmp             w0, NULL
    // 0x6c70ac: b.ne            #0x6c70b8
    // 0x6c70b0: r0 = 0
    //     0x6c70b0: movz            x0, #0
    // 0x6c70b4: b               #0x6c70c8
    // 0x6c70b8: r1 = LoadInt32Instr(r0)
    //     0x6c70b8: sbfx            x1, x0, #1, #0x1f
    //     0x6c70bc: tbz             w0, #0, #0x6c70c4
    //     0x6c70c0: ldur            x1, [x0, #7]
    // 0x6c70c4: mov             x0, x1
    // 0x6c70c8: cmp             x0, #9
    // 0x6c70cc: b.lt            #0x6c7150
    // 0x6c70d0: ldur            x0, [fp, #-0x10]
    // 0x6c70d4: LoadField: r1 = r0->field_f
    //     0x6c70d4: ldur            w1, [x0, #0xf]
    // 0x6c70d8: DecompressPointer r1
    //     0x6c70d8: add             x1, x1, HEAP, lsl #32
    // 0x6c70dc: LoadField: r0 = r1->field_43
    //     0x6c70dc: ldur            w0, [x1, #0x43]
    // 0x6c70e0: DecompressPointer r0
    //     0x6c70e0: add             x0, x0, HEAP, lsl #32
    // 0x6c70e4: mov             x1, x0
    // 0x6c70e8: stur            x0, [fp, #-8]
    // 0x6c70ec: r2 = 4
    //     0x6c70ec: movz            x2, #0x4
    // 0x6c70f0: r0 = _getValueOrData()
    //     0x6c70f0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c70f4: ldur            x1, [fp, #-8]
    // 0x6c70f8: LoadField: r2 = r1->field_f
    //     0x6c70f8: ldur            w2, [x1, #0xf]
    // 0x6c70fc: DecompressPointer r2
    //     0x6c70fc: add             x2, x2, HEAP, lsl #32
    // 0x6c7100: cmp             w2, w0
    // 0x6c7104: b.ne            #0x6c7110
    // 0x6c7108: r1 = Null
    //     0x6c7108: mov             x1, NULL
    // 0x6c710c: b               #0x6c7114
    // 0x6c7110: mov             x1, x0
    // 0x6c7114: cmp             w1, NULL
    // 0x6c7118: b.ne            #0x6c7124
    // 0x6c711c: r1 = 0
    //     0x6c711c: movz            x1, #0
    // 0x6c7120: b               #0x6c7134
    // 0x6c7124: r2 = LoadInt32Instr(r1)
    //     0x6c7124: sbfx            x2, x1, #1, #0x1f
    //     0x6c7128: tbz             w1, #0, #0x6c7130
    //     0x6c712c: ldur            x2, [x1, #7]
    // 0x6c7130: mov             x1, x2
    // 0x6c7134: cmp             x1, #7
    // 0x6c7138: b.lt            #0x6c7150
    // 0x6c713c: r0 = "Upgrades"
    //     0x6c713c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26508] "Upgrades"
    //     0x6c7140: ldr             x0, [x0, #0x508]
    // 0x6c7144: LeaveFrame
    //     0x6c7144: mov             SP, fp
    //     0x6c7148: ldp             fp, lr, [SP], #0x10
    // 0x6c714c: ret
    //     0x6c714c: ret             
    // 0x6c7150: r0 = Null
    //     0x6c7150: mov             x0, NULL
    // 0x6c7154: LeaveFrame
    //     0x6c7154: mov             SP, fp
    //     0x6c7158: ldp             fp, lr, [SP], #0x10
    // 0x6c715c: ret
    //     0x6c715c: ret             
    // 0x6c7160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7160: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7164: b               #0x6c7064
  }
  [closure] GeneratorInfo<Chapter9Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x6c7168, size: 0x3c
    // 0x6c7168: EnterFrame
    //     0x6c7168: stp             fp, lr, [SP, #-0x10]!
    //     0x6c716c: mov             fp, SP
    // 0x6c7170: ldr             x0, [fp, #0x18]
    // 0x6c7174: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c7174: ldur            w1, [x0, #0x17]
    // 0x6c7178: DecompressPointer r1
    //     0x6c7178: add             x1, x1, HEAP, lsl #32
    // 0x6c717c: CheckStackOverflow
    //     0x6c717c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c7180: cmp             SP, x16
    //     0x6c7184: b.ls            #0x6c719c
    // 0x6c7188: ldr             x2, [fp, #0x10]
    // 0x6c718c: r0 = getGeneratorInfo()
    //     0x6c718c: bl              #0x80dac0  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getGeneratorInfo
    // 0x6c7190: LeaveFrame
    //     0x6c7190: mov             SP, fp
    //     0x6c7194: ldp             fp, lr, [SP], #0x10
    // 0x6c7198: ret
    //     0x6c7198: ret             
    // 0x6c719c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c719c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c71a0: b               #0x6c7188
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6c71a4, size: 0x58
    // 0x6c71a4: EnterFrame
    //     0x6c71a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c71a8: mov             fp, SP
    // 0x6c71ac: CheckStackOverflow
    //     0x6c71ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c71b0: cmp             SP, x16
    //     0x6c71b4: b.ls            #0x6c71e8
    // 0x6c71b8: r0 = LoadStaticField(0xf7c)
    //     0x6c71b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c71bc: ldr             x0, [x0, #0x1ef8]
    // 0x6c71c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c71c4: cmp             w0, w16
    // 0x6c71c8: b.eq            #0x6c71f0
    // 0x6c71cc: LoadField: r1 = r0->field_13
    //     0x6c71cc: ldur            w1, [x0, #0x13]
    // 0x6c71d0: DecompressPointer r1
    //     0x6c71d0: add             x1, x1, HEAP, lsl #32
    // 0x6c71d4: r2 = 38
    //     0x6c71d4: movz            x2, #0x26
    // 0x6c71d8: r0 = containsKey()
    //     0x6c71d8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6c71dc: LeaveFrame
    //     0x6c71dc: mov             SP, fp
    //     0x6c71e0: ldp             fp, lr, [SP], #0x10
    // 0x6c71e4: ret
    //     0x6c71e4: ret             
    // 0x6c71e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c71e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c71ec: b               #0x6c71b8
    // 0x6c71f0: r9 = coreData
    //     0x6c71f0: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6c71f4: ldr             x9, [x9, #0x530]
    // 0x6c71f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c71f8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void pastedText(dynamic) {
    // ** addr: 0x6c71fc, size: 0x38
    // 0x6c71fc: EnterFrame
    //     0x6c71fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7200: mov             fp, SP
    // 0x6c7204: ldr             x0, [fp, #0x10]
    // 0x6c7208: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6c7208: ldur            w1, [x0, #0x17]
    // 0x6c720c: DecompressPointer r1
    //     0x6c720c: add             x1, x1, HEAP, lsl #32
    // 0x6c7210: CheckStackOverflow
    //     0x6c7210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c7214: cmp             SP, x16
    //     0x6c7218: b.ls            #0x6c722c
    // 0x6c721c: r0 = pastedText()
    //     0x6c721c: bl              #0x6c7234  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::pastedText
    // 0x6c7220: LeaveFrame
    //     0x6c7220: mov             SP, fp
    //     0x6c7224: ldp             fp, lr, [SP], #0x10
    // 0x6c7228: ret
    //     0x6c7228: ret             
    // 0x6c722c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c722c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7230: b               #0x6c721c
  }
  _ pastedText(/* No info */) {
    // ** addr: 0x6c7234, size: 0x134
    // 0x6c7234: EnterFrame
    //     0x6c7234: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7238: mov             fp, SP
    // 0x6c723c: AllocStack(0x20)
    //     0x6c723c: sub             SP, SP, #0x20
    // 0x6c7240: SetupParameters(Chapter9GameState this /* r1 => r0, fp-0x10 */)
    //     0x6c7240: mov             x0, x1
    //     0x6c7244: stur            x1, [fp, #-0x10]
    // 0x6c7248: CheckStackOverflow
    //     0x6c7248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c724c: cmp             SP, x16
    //     0x6c7250: b.ls            #0x6c7360
    // 0x6c7254: LoadField: r3 = r0->field_37
    //     0x6c7254: ldur            w3, [x0, #0x37]
    // 0x6c7258: DecompressPointer r3
    //     0x6c7258: add             x3, x3, HEAP, lsl #32
    // 0x6c725c: mov             x1, x3
    // 0x6c7260: stur            x3, [fp, #-8]
    // 0x6c7264: r2 = Instance_Chapter9Stat
    //     0x6c7264: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c7268: ldr             x2, [x2, #0x890]
    // 0x6c726c: r0 = _getValueOrData()
    //     0x6c726c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c7270: mov             x1, x0
    // 0x6c7274: ldur            x0, [fp, #-8]
    // 0x6c7278: LoadField: r2 = r0->field_f
    //     0x6c7278: ldur            w2, [x0, #0xf]
    // 0x6c727c: DecompressPointer r2
    //     0x6c727c: add             x2, x2, HEAP, lsl #32
    // 0x6c7280: cmp             w2, w1
    // 0x6c7284: b.ne            #0x6c728c
    // 0x6c7288: r1 = Null
    //     0x6c7288: mov             x1, NULL
    // 0x6c728c: cmp             w1, NULL
    // 0x6c7290: b.ne            #0x6c72a0
    // 0x6c7294: r2 = Instance_CustomNum
    //     0x6c7294: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6c7298: ldr             x2, [x2, #0xaf8]
    // 0x6c729c: b               #0x6c72a4
    // 0x6c72a0: mov             x2, x1
    // 0x6c72a4: ldur            x1, [fp, #-0x10]
    // 0x6c72a8: stur            x2, [fp, #-0x18]
    // 0x6c72ac: r0 = getStatBoosts()
    //     0x6c72ac: bl              #0x55deb4  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getStatBoosts
    // 0x6c72b0: mov             x1, x0
    // 0x6c72b4: r2 = Instance_Chapter9Stat
    //     0x6c72b4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c72b8: ldr             x2, [x2, #0x890]
    // 0x6c72bc: stur            x0, [fp, #-0x20]
    // 0x6c72c0: r0 = _getValueOrData()
    //     0x6c72c0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6c72c4: mov             x1, x0
    // 0x6c72c8: ldur            x0, [fp, #-0x20]
    // 0x6c72cc: LoadField: r2 = r0->field_f
    //     0x6c72cc: ldur            w2, [x0, #0xf]
    // 0x6c72d0: DecompressPointer r2
    //     0x6c72d0: add             x2, x2, HEAP, lsl #32
    // 0x6c72d4: cmp             w2, w1
    // 0x6c72d8: b.ne            #0x6c72e4
    // 0x6c72dc: r0 = Null
    //     0x6c72dc: mov             x0, NULL
    // 0x6c72e0: b               #0x6c72e8
    // 0x6c72e4: mov             x0, x1
    // 0x6c72e8: cmp             w0, NULL
    // 0x6c72ec: b.ne            #0x6c72fc
    // 0x6c72f0: r2 = Instance_CustomNum
    //     0x6c72f0: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6c72f4: ldr             x2, [x2, #0xa70]
    // 0x6c72f8: b               #0x6c7300
    // 0x6c72fc: mov             x2, x0
    // 0x6c7300: ldur            x1, [fp, #-0x10]
    // 0x6c7304: r3 = Instance_Chapter9Stat
    //     0x6c7304: add             x3, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c7308: ldr             x3, [x3, #0x890]
    // 0x6c730c: r5 = Null
    //     0x6c730c: mov             x5, NULL
    // 0x6c7310: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6c7310: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6c7314: r0 = applyAllBoostsToYields()
    //     0x6c7314: bl              #0x54a950  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::applyAllBoostsToYields
    // 0x6c7318: ldur            x1, [fp, #-0x18]
    // 0x6c731c: mov             x2, x0
    // 0x6c7320: r0 = add()
    //     0x6c7320: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6c7324: ldur            x1, [fp, #-8]
    // 0x6c7328: mov             x3, x0
    // 0x6c732c: r2 = Instance_Chapter9Stat
    //     0x6c732c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c7330: ldr             x2, [x2, #0x890]
    // 0x6c7334: r0 = []=()
    //     0x6c7334: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c7338: ldur            x1, [fp, #-0x10]
    // 0x6c733c: r2 = Instance_Chapter9Stat
    //     0x6c733c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11890] Obj!Chapter9Stat@85efe1
    //     0x6c7340: ldr             x2, [x2, #0x890]
    // 0x6c7344: r0 = notifyStatGained()
    //     0x6c7344: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6c7348: ldur            x1, [fp, #-0x10]
    // 0x6c734c: r0 = saveDeferred()
    //     0x6c734c: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x6c7350: r0 = Null
    //     0x6c7350: mov             x0, NULL
    // 0x6c7354: LeaveFrame
    //     0x6c7354: mov             SP, fp
    //     0x6c7358: ldp             fp, lr, [SP], #0x10
    // 0x6c735c: ret
    //     0x6c735c: ret             
    // 0x6c7360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7360: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7364: b               #0x6c7254
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6c7368, size: 0xac
    // 0x6c7368: EnterFrame
    //     0x6c7368: stp             fp, lr, [SP, #-0x10]!
    //     0x6c736c: mov             fp, SP
    // 0x6c7370: AllocStack(0x10)
    //     0x6c7370: sub             SP, SP, #0x10
    // 0x6c7374: SetupParameters([dynamic _ /* r0 */])
    //     0x6c7374: ldr             x0, [fp, #0x10]
    //     0x6c7378: ldur            w3, [x0, #0x17]
    //     0x6c737c: add             x3, x3, HEAP, lsl #32
    //     0x6c7380: stur            x3, [fp, #-8]
    // 0x6c7384: CheckStackOverflow
    //     0x6c7384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c7388: cmp             SP, x16
    //     0x6c738c: b.ls            #0x6c7400
    // 0x6c7390: r0 = LoadStaticField(0xf7c)
    //     0x6c7390: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c7394: ldr             x0, [x0, #0x1ef8]
    // 0x6c7398: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c739c: cmp             w0, w16
    // 0x6c73a0: b.eq            #0x6c7408
    // 0x6c73a4: LoadField: r1 = r0->field_13
    //     0x6c73a4: ldur            w1, [x0, #0x13]
    // 0x6c73a8: DecompressPointer r1
    //     0x6c73a8: add             x1, x1, HEAP, lsl #32
    // 0x6c73ac: r2 = 38
    //     0x6c73ac: movz            x2, #0x26
    // 0x6c73b0: r0 = containsKey()
    //     0x6c73b0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6c73b4: tbnz            w0, #4, #0x6c73f0
    // 0x6c73b8: ldur            x0, [fp, #-8]
    // 0x6c73bc: LoadField: r1 = r0->field_f
    //     0x6c73bc: ldur            w1, [x0, #0xf]
    // 0x6c73c0: DecompressPointer r1
    //     0x6c73c0: add             x1, x1, HEAP, lsl #32
    // 0x6c73c4: r16 = false
    //     0x6c73c4: add             x16, NULL, #0x30  ; false
    // 0x6c73c8: str             x16, [SP]
    // 0x6c73cc: r2 = 19
    //     0x6c73cc: movz            x2, #0x13
    // 0x6c73d0: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x6c73d0: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x6c73d4: ldr             x4, [x4, #0x5c0]
    // 0x6c73d8: r0 = notifyDialoguePoint()
    //     0x6c73d8: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6c73dc: r0 = "Intermission"
    //     0x6c73dc: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x6c73e0: ldr             x0, [x0, #0x5c8]
    // 0x6c73e4: LeaveFrame
    //     0x6c73e4: mov             SP, fp
    //     0x6c73e8: ldp             fp, lr, [SP], #0x10
    // 0x6c73ec: ret
    //     0x6c73ec: ret             
    // 0x6c73f0: r0 = Null
    //     0x6c73f0: mov             x0, NULL
    // 0x6c73f4: LeaveFrame
    //     0x6c73f4: mov             SP, fp
    //     0x6c73f8: ldp             fp, lr, [SP], #0x10
    // 0x6c73fc: ret
    //     0x6c73fc: ret             
    // 0x6c7400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7400: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7404: b               #0x6c7390
    // 0x6c7408: r9 = coreData
    //     0x6c7408: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6c740c: ldr             x9, [x9, #0x530]
    // 0x6c7410: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c7410: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6c7414, size: 0x78
    // 0x6c7414: EnterFrame
    //     0x6c7414: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7418: mov             fp, SP
    // 0x6c741c: AllocStack(0x18)
    //     0x6c741c: sub             SP, SP, #0x18
    // 0x6c7420: SetupParameters(Chapter9GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x6c7420: stur            NULL, [fp, #-8]
    //     0x6c7424: movz            x0, #0
    //     0x6c7428: add             x1, fp, w0, sxtw #2
    //     0x6c742c: ldr             x1, [x1, #0x18]
    //     0x6c7430: add             x2, fp, w0, sxtw #2
    //     0x6c7434: ldr             x2, [x2, #0x10]
    //     0x6c7438: stur            x2, [fp, #-0x18]
    //     0x6c743c: ldur            w3, [x1, #0x17]
    //     0x6c7440: add             x3, x3, HEAP, lsl #32
    //     0x6c7444: stur            x3, [fp, #-0x10]
    // 0x6c7448: CheckStackOverflow
    //     0x6c7448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c744c: cmp             SP, x16
    //     0x6c7450: b.ls            #0x6c7484
    // 0x6c7454: InitAsync() -> Future<void?>
    //     0x6c7454: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6c7458: bl              #0x34b9a0  ; InitAsyncStub
    // 0x6c745c: ldur            x2, [fp, #-0x10]
    // 0x6c7460: r1 = Function '<anonymous closure>':.
    //     0x6c7460: add             x1, PP, #0x26, lsl #12  ; [pp+0x265d8] AnonymousClosure: (0x6c748c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6c7464: ldr             x1, [x1, #0x5d8]
    // 0x6c7468: r0 = AllocateClosure()
    //     0x6c7468: bl              #0x826750  ; AllocateClosureStub
    // 0x6c746c: ldur            x1, [fp, #-0x18]
    // 0x6c7470: mov             x3, x0
    // 0x6c7474: r2 = 19
    //     0x6c7474: movz            x2, #0x13
    // 0x6c7478: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6c7478: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6c747c: r0 = displaySlackPage()
    //     0x6c747c: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x6c7480: r0 = ReturnAsync()
    //     0x6c7480: b               #0x353380  ; ReturnAsyncStub
    // 0x6c7484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7484: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7488: b               #0x6c7454
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6c748c, size: 0x78
    // 0x6c748c: EnterFrame
    //     0x6c748c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7490: mov             fp, SP
    // 0x6c7494: AllocStack(0x8)
    //     0x6c7494: sub             SP, SP, #8
    // 0x6c7498: SetupParameters([dynamic _ /* r0 */])
    //     0x6c7498: ldr             x0, [fp, #0x20]
    //     0x6c749c: ldur            w3, [x0, #0x17]
    //     0x6c74a0: add             x3, x3, HEAP, lsl #32
    //     0x6c74a4: stur            x3, [fp, #-8]
    // 0x6c74a8: CheckStackOverflow
    //     0x6c74a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c74ac: cmp             SP, x16
    //     0x6c74b0: b.ls            #0x6c74fc
    // 0x6c74b4: LoadField: r1 = r3->field_f
    //     0x6c74b4: ldur            w1, [x3, #0xf]
    // 0x6c74b8: DecompressPointer r1
    //     0x6c74b8: add             x1, x1, HEAP, lsl #32
    // 0x6c74bc: r2 = 19
    //     0x6c74bc: movz            x2, #0x13
    // 0x6c74c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6c74c0: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6c74c4: r0 = notifyDialoguePoint()
    //     0x6c74c4: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6c74c8: ldr             x0, [fp, #0x10]
    // 0x6c74cc: r1 = LoadInt32Instr(r0)
    //     0x6c74cc: sbfx            x1, x0, #1, #0x1f
    //     0x6c74d0: tbz             w0, #0, #0x6c74d8
    //     0x6c74d4: ldur            x1, [x0, #7]
    // 0x6c74d8: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x6c74d8: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x6c74dc: ldur            x0, [fp, #-8]
    // 0x6c74e0: LoadField: r1 = r0->field_f
    //     0x6c74e0: ldur            w1, [x0, #0xf]
    // 0x6c74e4: DecompressPointer r1
    //     0x6c74e4: add             x1, x1, HEAP, lsl #32
    // 0x6c74e8: r0 = saveDeferred()
    //     0x6c74e8: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x6c74ec: r0 = Null
    //     0x6c74ec: mov             x0, NULL
    // 0x6c74f0: LeaveFrame
    //     0x6c74f0: mov             SP, fp
    //     0x6c74f4: ldp             fp, lr, [SP], #0x10
    // 0x6c74f8: ret
    //     0x6c74f8: ret             
    // 0x6c74fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c74fc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7500: b               #0x6c74b4
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80dac0, size: 0x7c
    // 0x80dac0: EnterFrame
    //     0x80dac0: stp             fp, lr, [SP, #-0x10]!
    //     0x80dac4: mov             fp, SP
    // 0x80dac8: AllocStack(0x8)
    //     0x80dac8: sub             SP, SP, #8
    // 0x80dacc: CheckStackOverflow
    //     0x80dacc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80dad0: cmp             SP, x16
    //     0x80dad4: b.ls            #0x80db24
    // 0x80dad8: LoadField: r0 = r1->field_8b
    //     0x80dad8: ldur            w0, [x1, #0x8b]
    // 0x80dadc: DecompressPointer r0
    //     0x80dadc: add             x0, x0, HEAP, lsl #32
    // 0x80dae0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80dae4: cmp             w0, w16
    // 0x80dae8: b.eq            #0x80db2c
    // 0x80daec: mov             x1, x0
    // 0x80daf0: stur            x0, [fp, #-8]
    // 0x80daf4: r0 = _getValueOrData()
    //     0x80daf4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80daf8: ldur            x1, [fp, #-8]
    // 0x80dafc: LoadField: r2 = r1->field_f
    //     0x80dafc: ldur            w2, [x1, #0xf]
    // 0x80db00: DecompressPointer r2
    //     0x80db00: add             x2, x2, HEAP, lsl #32
    // 0x80db04: cmp             w2, w0
    // 0x80db08: b.ne            #0x80db10
    // 0x80db0c: r0 = Null
    //     0x80db0c: mov             x0, NULL
    // 0x80db10: cmp             w0, NULL
    // 0x80db14: b.eq            #0x80db38
    // 0x80db18: LeaveFrame
    //     0x80db18: mov             SP, fp
    //     0x80db1c: ldp             fp, lr, [SP], #0x10
    // 0x80db20: ret
    //     0x80db20: ret             
    // 0x80db24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80db24: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80db28: b               #0x80dad8
    // 0x80db2c: r9 = generators
    //     0x80db2c: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a308] Field <Chapter9GameState.generators>: late (offset: 0x8c)
    //     0x80db30: ldr             x9, [x9, #0x308]
    // 0x80db34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80db34: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80db38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80db38: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d1c8, size: 0xc
    // 0x81d1c8: r0 = "9"
    //     0x81d1c8: add             x0, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x81d1cc: ldr             x0, [x0, #0x320]
    // 0x81d1d0: ret
    //     0x81d1d0: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f90c, size: 0x24
    // 0x81f90c: EnterFrame
    //     0x81f90c: stp             fp, lr, [SP, #-0x10]!
    //     0x81f910: mov             fp, SP
    // 0x81f914: ldr             x2, [fp, #0x10]
    // 0x81f918: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f918: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c918] AnonymousClosure: (0x3dd8c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::getCostToBuyOneMoreGenerator (0x3dd774)
    //     0x81f91c: ldr             x1, [x1, #0x918]
    // 0x81f920: r0 = AllocateClosure()
    //     0x81f920: bl              #0x826750  ; AllocateClosureStub
    // 0x81f924: LeaveFrame
    //     0x81f924: mov             SP, fp
    //     0x81f928: ldp             fp, lr, [SP], #0x10
    // 0x81f92c: ret
    //     0x81f92c: ret             
  }
}

// class id: 4175, size: 0x14, field offset: 0x14
enum Chapter9Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724ccc, size: 0x64
    // 0x724ccc: EnterFrame
    //     0x724ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x724cd0: mov             fp, SP
    // 0x724cd4: AllocStack(0x10)
    //     0x724cd4: sub             SP, SP, #0x10
    // 0x724cd8: SetupParameters(Chapter9Stat this /* r1 => r0, fp-0x8 */)
    //     0x724cd8: mov             x0, x1
    //     0x724cdc: stur            x1, [fp, #-8]
    // 0x724ce0: CheckStackOverflow
    //     0x724ce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724ce4: cmp             SP, x16
    //     0x724ce8: b.ls            #0x724d28
    // 0x724cec: r1 = Null
    //     0x724cec: mov             x1, NULL
    // 0x724cf0: r2 = 4
    //     0x724cf0: movz            x2, #0x4
    // 0x724cf4: r0 = AllocateArray()
    //     0x724cf4: bl              #0x82746c  ; AllocateArrayStub
    // 0x724cf8: r16 = "Chapter9Stat."
    //     0x724cf8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14040] "Chapter9Stat."
    //     0x724cfc: ldr             x16, [x16, #0x40]
    // 0x724d00: StoreField: r0->field_f = r16
    //     0x724d00: stur            w16, [x0, #0xf]
    // 0x724d04: ldur            x1, [fp, #-8]
    // 0x724d08: LoadField: r2 = r1->field_f
    //     0x724d08: ldur            w2, [x1, #0xf]
    // 0x724d0c: DecompressPointer r2
    //     0x724d0c: add             x2, x2, HEAP, lsl #32
    // 0x724d10: StoreField: r0->field_13 = r2
    //     0x724d10: stur            w2, [x0, #0x13]
    // 0x724d14: str             x0, [SP]
    // 0x724d18: r0 = _interpolate()
    //     0x724d18: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724d1c: LeaveFrame
    //     0x724d1c: mov             SP, fp
    //     0x724d20: ldp             fp, lr, [SP], #0x10
    // 0x724d24: ret
    //     0x724d24: ret             
    // 0x724d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724d28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724d2c: b               #0x724cec
  }
}
