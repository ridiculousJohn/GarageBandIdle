// lib: , url: package:pretentious/data/Chapters/Chapter14GameState.dart

// class id: 1049451, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46c550, size: 0x1a0
    // 0x46c550: cmp             w1, NULL
    // 0x46c554: b.ne            #0x46c560
    // 0x46c558: r0 = ""
    //     0x46c558: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46c55c: ret
    //     0x46c55c: ret             
    // 0x46c560: r16 = Instance_Chapter14Stat
    //     0x46c560: add             x16, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x46c564: ldr             x16, [x16, #0x1a8]
    // 0x46c568: cmp             w1, w16
    // 0x46c56c: b.ne            #0x46c57c
    // 0x46c570: r0 = "Segfaults"
    //     0x46c570: add             x0, PP, #0x11, lsl #12  ; [pp+0x111b0] "Segfaults"
    //     0x46c574: ldr             x0, [x0, #0x1b0]
    // 0x46c578: ret
    //     0x46c578: ret             
    // 0x46c57c: r16 = Instance_Chapter14Stat
    //     0x46c57c: add             x16, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x46c580: ldr             x16, [x16, #0x1b8]
    // 0x46c584: cmp             w1, w16
    // 0x46c588: b.ne            #0x46c598
    // 0x46c58c: r0 = "Navigation"
    //     0x46c58c: add             x0, PP, #0x11, lsl #12  ; [pp+0x111c0] "Navigation"
    //     0x46c590: ldr             x0, [x0, #0x1c0]
    // 0x46c594: ret
    //     0x46c594: ret             
    // 0x46c598: r16 = Instance_Chapter14Stat
    //     0x46c598: add             x16, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x46c59c: ldr             x16, [x16, #0x1c8]
    // 0x46c5a0: cmp             w1, w16
    // 0x46c5a4: b.ne            #0x46c5b4
    // 0x46c5a8: r0 = "Ops"
    //     0x46c5a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x111d0] "Ops"
    //     0x46c5ac: ldr             x0, [x0, #0x1d0]
    // 0x46c5b0: ret
    //     0x46c5b0: ret             
    // 0x46c5b4: r16 = Instance_Chapter14Stat
    //     0x46c5b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x46c5b8: ldr             x16, [x16, #0x1d8]
    // 0x46c5bc: cmp             w1, w16
    // 0x46c5c0: b.ne            #0x46c5d0
    // 0x46c5c4: r0 = "I/O"
    //     0x46c5c4: add             x0, PP, #0x11, lsl #12  ; [pp+0x111e0] "I/O"
    //     0x46c5c8: ldr             x0, [x0, #0x1e0]
    // 0x46c5cc: ret
    //     0x46c5cc: ret             
    // 0x46c5d0: r16 = Instance_Chapter14Stat
    //     0x46c5d0: add             x16, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x46c5d4: ldr             x16, [x16, #0x1e8]
    // 0x46c5d8: cmp             w1, w16
    // 0x46c5dc: b.ne            #0x46c5ec
    // 0x46c5e0: r0 = "Throughput"
    //     0x46c5e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x111f0] "Throughput"
    //     0x46c5e4: ldr             x0, [x0, #0x1f0]
    // 0x46c5e8: ret
    //     0x46c5e8: ret             
    // 0x46c5ec: r16 = Instance_Chapter14Stat
    //     0x46c5ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11140] Obj!Chapter14Stat@85f9c1
    //     0x46c5f0: ldr             x16, [x16, #0x140]
    // 0x46c5f4: cmp             w1, w16
    // 0x46c5f8: b.ne            #0x46c608
    // 0x46c5fc: r0 = "ls"
    //     0x46c5fc: add             x0, PP, #0x11, lsl #12  ; [pp+0x111f8] "ls"
    //     0x46c600: ldr             x0, [x0, #0x1f8]
    // 0x46c604: ret
    //     0x46c604: ret             
    // 0x46c608: r16 = Instance_Chapter14Stat
    //     0x46c608: add             x16, PP, #0x11, lsl #12  ; [pp+0x11148] Obj!Chapter14Stat@85f9a1
    //     0x46c60c: ldr             x16, [x16, #0x148]
    // 0x46c610: cmp             w1, w16
    // 0x46c614: b.ne            #0x46c624
    // 0x46c618: r0 = "pwd"
    //     0x46c618: add             x0, PP, #0x11, lsl #12  ; [pp+0x11200] "pwd"
    //     0x46c61c: ldr             x0, [x0, #0x200]
    // 0x46c620: ret
    //     0x46c620: ret             
    // 0x46c624: r16 = Instance_Chapter14Stat
    //     0x46c624: add             x16, PP, #0x11, lsl #12  ; [pp+0x11150] Obj!Chapter14Stat@85f981
    //     0x46c628: ldr             x16, [x16, #0x150]
    // 0x46c62c: cmp             w1, w16
    // 0x46c630: b.ne            #0x46c640
    // 0x46c634: r0 = "cd"
    //     0x46c634: add             x0, PP, #0x11, lsl #12  ; [pp+0x11208] "cd"
    //     0x46c638: ldr             x0, [x0, #0x208]
    // 0x46c63c: ret
    //     0x46c63c: ret             
    // 0x46c640: r16 = Instance_Chapter14Stat
    //     0x46c640: add             x16, PP, #0x11, lsl #12  ; [pp+0x11158] Obj!Chapter14Stat@85f961
    //     0x46c644: ldr             x16, [x16, #0x158]
    // 0x46c648: cmp             w1, w16
    // 0x46c64c: b.ne            #0x46c65c
    // 0x46c650: r0 = "touch"
    //     0x46c650: add             x0, PP, #0x11, lsl #12  ; [pp+0x11210] "touch"
    //     0x46c654: ldr             x0, [x0, #0x210]
    // 0x46c658: ret
    //     0x46c658: ret             
    // 0x46c65c: r16 = Instance_Chapter14Stat
    //     0x46c65c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11160] Obj!Chapter14Stat@85f941
    //     0x46c660: ldr             x16, [x16, #0x160]
    // 0x46c664: cmp             w1, w16
    // 0x46c668: b.ne            #0x46c678
    // 0x46c66c: r0 = "mv"
    //     0x46c66c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11218] "mv"
    //     0x46c670: ldr             x0, [x0, #0x218]
    // 0x46c674: ret
    //     0x46c674: ret             
    // 0x46c678: r16 = Instance_Chapter14Stat
    //     0x46c678: add             x16, PP, #0x11, lsl #12  ; [pp+0x11168] Obj!Chapter14Stat@85f921
    //     0x46c67c: ldr             x16, [x16, #0x168]
    // 0x46c680: cmp             w1, w16
    // 0x46c684: b.ne            #0x46c694
    // 0x46c688: r0 = "rm"
    //     0x46c688: add             x0, PP, #0x11, lsl #12  ; [pp+0x11220] "rm"
    //     0x46c68c: ldr             x0, [x0, #0x220]
    // 0x46c690: ret
    //     0x46c690: ret             
    // 0x46c694: r16 = Instance_Chapter14Stat
    //     0x46c694: add             x16, PP, #0x11, lsl #12  ; [pp+0x11170] Obj!Chapter14Stat@85f901
    //     0x46c698: ldr             x16, [x16, #0x170]
    // 0x46c69c: cmp             w1, w16
    // 0x46c6a0: b.ne            #0x46c6b0
    // 0x46c6a4: r0 = "mkdir"
    //     0x46c6a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11228] "mkdir"
    //     0x46c6a8: ldr             x0, [x0, #0x228]
    // 0x46c6ac: ret
    //     0x46c6ac: ret             
    // 0x46c6b0: r16 = Instance_Chapter14Stat
    //     0x46c6b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x46c6b4: ldr             x16, [x16, #0x230]
    // 0x46c6b8: cmp             w1, w16
    // 0x46c6bc: b.ne            #0x46c6cc
    // 0x46c6c0: r0 = "Stability"
    //     0x46c6c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11238] "Stability"
    //     0x46c6c4: ldr             x0, [x0, #0x238]
    // 0x46c6c8: ret
    //     0x46c6c8: ret             
    // 0x46c6cc: r16 = Instance_Chapter14Stat
    //     0x46c6cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c6d0: ldr             x16, [x16, #0x178]
    // 0x46c6d4: cmp             w1, w16
    // 0x46c6d8: b.ne            #0x46c6e8
    // 0x46c6dc: r0 = "Functionality"
    //     0x46c6dc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11240] "Functionality"
    //     0x46c6e0: ldr             x0, [x0, #0x240]
    // 0x46c6e4: ret
    //     0x46c6e4: ret             
    // 0x46c6e8: r0 = Null
    //     0x46c6e8: mov             x0, NULL
    // 0x46c6ec: ret
    //     0x46c6ec: ret             
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46c720, size: 0x190
    // 0x46c720: r16 = Instance_Chapter14Stat
    //     0x46c720: add             x16, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x46c724: ldr             x16, [x16, #0x1a8]
    // 0x46c728: cmp             w1, w16
    // 0x46c72c: b.ne            #0x46c73c
    // 0x46c730: r0 = "SF"
    //     0x46c730: add             x0, PP, #0x11, lsl #12  ; [pp+0x11248] "SF"
    //     0x46c734: ldr             x0, [x0, #0x248]
    // 0x46c738: ret
    //     0x46c738: ret             
    // 0x46c73c: r16 = Instance_Chapter14Stat
    //     0x46c73c: add             x16, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x46c740: ldr             x16, [x16, #0x1b8]
    // 0x46c744: cmp             w1, w16
    // 0x46c748: b.ne            #0x46c758
    // 0x46c74c: r0 = "Nav"
    //     0x46c74c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11250] "Nav"
    //     0x46c750: ldr             x0, [x0, #0x250]
    // 0x46c754: ret
    //     0x46c754: ret             
    // 0x46c758: r16 = Instance_Chapter14Stat
    //     0x46c758: add             x16, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x46c75c: ldr             x16, [x16, #0x1c8]
    // 0x46c760: cmp             w1, w16
    // 0x46c764: b.ne            #0x46c774
    // 0x46c768: r0 = "Ops"
    //     0x46c768: add             x0, PP, #0x11, lsl #12  ; [pp+0x111d0] "Ops"
    //     0x46c76c: ldr             x0, [x0, #0x1d0]
    // 0x46c770: ret
    //     0x46c770: ret             
    // 0x46c774: r16 = Instance_Chapter14Stat
    //     0x46c774: add             x16, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x46c778: ldr             x16, [x16, #0x1d8]
    // 0x46c77c: cmp             w1, w16
    // 0x46c780: b.ne            #0x46c790
    // 0x46c784: r0 = "I/O"
    //     0x46c784: add             x0, PP, #0x11, lsl #12  ; [pp+0x111e0] "I/O"
    //     0x46c788: ldr             x0, [x0, #0x1e0]
    // 0x46c78c: ret
    //     0x46c78c: ret             
    // 0x46c790: r16 = Instance_Chapter14Stat
    //     0x46c790: add             x16, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x46c794: ldr             x16, [x16, #0x1e8]
    // 0x46c798: cmp             w1, w16
    // 0x46c79c: b.ne            #0x46c7ac
    // 0x46c7a0: r0 = "TP"
    //     0x46c7a0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11258] "TP"
    //     0x46c7a4: ldr             x0, [x0, #0x258]
    // 0x46c7a8: ret
    //     0x46c7a8: ret             
    // 0x46c7ac: r16 = Instance_Chapter14Stat
    //     0x46c7ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11140] Obj!Chapter14Stat@85f9c1
    //     0x46c7b0: ldr             x16, [x16, #0x140]
    // 0x46c7b4: cmp             w1, w16
    // 0x46c7b8: b.ne            #0x46c7c8
    // 0x46c7bc: r0 = "ls"
    //     0x46c7bc: add             x0, PP, #0x11, lsl #12  ; [pp+0x111f8] "ls"
    //     0x46c7c0: ldr             x0, [x0, #0x1f8]
    // 0x46c7c4: ret
    //     0x46c7c4: ret             
    // 0x46c7c8: r16 = Instance_Chapter14Stat
    //     0x46c7c8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11148] Obj!Chapter14Stat@85f9a1
    //     0x46c7cc: ldr             x16, [x16, #0x148]
    // 0x46c7d0: cmp             w1, w16
    // 0x46c7d4: b.ne            #0x46c7e4
    // 0x46c7d8: r0 = "pwd"
    //     0x46c7d8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11200] "pwd"
    //     0x46c7dc: ldr             x0, [x0, #0x200]
    // 0x46c7e0: ret
    //     0x46c7e0: ret             
    // 0x46c7e4: r16 = Instance_Chapter14Stat
    //     0x46c7e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11150] Obj!Chapter14Stat@85f981
    //     0x46c7e8: ldr             x16, [x16, #0x150]
    // 0x46c7ec: cmp             w1, w16
    // 0x46c7f0: b.ne            #0x46c800
    // 0x46c7f4: r0 = "cd"
    //     0x46c7f4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11208] "cd"
    //     0x46c7f8: ldr             x0, [x0, #0x208]
    // 0x46c7fc: ret
    //     0x46c7fc: ret             
    // 0x46c800: r16 = Instance_Chapter14Stat
    //     0x46c800: add             x16, PP, #0x11, lsl #12  ; [pp+0x11158] Obj!Chapter14Stat@85f961
    //     0x46c804: ldr             x16, [x16, #0x158]
    // 0x46c808: cmp             w1, w16
    // 0x46c80c: b.ne            #0x46c81c
    // 0x46c810: r0 = "touch"
    //     0x46c810: add             x0, PP, #0x11, lsl #12  ; [pp+0x11210] "touch"
    //     0x46c814: ldr             x0, [x0, #0x210]
    // 0x46c818: ret
    //     0x46c818: ret             
    // 0x46c81c: r16 = Instance_Chapter14Stat
    //     0x46c81c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11160] Obj!Chapter14Stat@85f941
    //     0x46c820: ldr             x16, [x16, #0x160]
    // 0x46c824: cmp             w1, w16
    // 0x46c828: b.ne            #0x46c838
    // 0x46c82c: r0 = "mv"
    //     0x46c82c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11218] "mv"
    //     0x46c830: ldr             x0, [x0, #0x218]
    // 0x46c834: ret
    //     0x46c834: ret             
    // 0x46c838: r16 = Instance_Chapter14Stat
    //     0x46c838: add             x16, PP, #0x11, lsl #12  ; [pp+0x11168] Obj!Chapter14Stat@85f921
    //     0x46c83c: ldr             x16, [x16, #0x168]
    // 0x46c840: cmp             w1, w16
    // 0x46c844: b.ne            #0x46c854
    // 0x46c848: r0 = "rm"
    //     0x46c848: add             x0, PP, #0x11, lsl #12  ; [pp+0x11220] "rm"
    //     0x46c84c: ldr             x0, [x0, #0x220]
    // 0x46c850: ret
    //     0x46c850: ret             
    // 0x46c854: r16 = Instance_Chapter14Stat
    //     0x46c854: add             x16, PP, #0x11, lsl #12  ; [pp+0x11170] Obj!Chapter14Stat@85f901
    //     0x46c858: ldr             x16, [x16, #0x170]
    // 0x46c85c: cmp             w1, w16
    // 0x46c860: b.ne            #0x46c870
    // 0x46c864: r0 = "mkdir"
    //     0x46c864: add             x0, PP, #0x11, lsl #12  ; [pp+0x11228] "mkdir"
    //     0x46c868: ldr             x0, [x0, #0x228]
    // 0x46c86c: ret
    //     0x46c86c: ret             
    // 0x46c870: r16 = Instance_Chapter14Stat
    //     0x46c870: add             x16, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x46c874: ldr             x16, [x16, #0x230]
    // 0x46c878: cmp             w1, w16
    // 0x46c87c: b.ne            #0x46c88c
    // 0x46c880: r0 = "Staby"
    //     0x46c880: add             x0, PP, #0x11, lsl #12  ; [pp+0x11260] "Staby"
    //     0x46c884: ldr             x0, [x0, #0x260]
    // 0x46c888: ret
    //     0x46c888: ret             
    // 0x46c88c: r16 = Instance_Chapter14Stat
    //     0x46c88c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c890: ldr             x16, [x16, #0x178]
    // 0x46c894: cmp             w1, w16
    // 0x46c898: b.ne            #0x46c8a8
    // 0x46c89c: r0 = "Func"
    //     0x46c89c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11268] "Func"
    //     0x46c8a0: ldr             x0, [x0, #0x268]
    // 0x46c8a4: ret
    //     0x46c8a4: ret             
    // 0x46c8a8: r0 = Null
    //     0x46c8a8: mov             x0, NULL
    // 0x46c8ac: ret
    //     0x46c8ac: ret             
  }
}

// class id: 281, size: 0x98, field offset: 0x8c
class Chapter14GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter14Stat>> generators; // offset: 0x8c
  late Map<int, UpgradeData<Chapter14Stat>> allUpgradeData; // offset: 0x90

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3daf58, size: 0x184
    // 0x3daf58: EnterFrame
    //     0x3daf58: stp             fp, lr, [SP, #-0x10]!
    //     0x3daf5c: mov             fp, SP
    // 0x3daf60: AllocStack(0x30)
    //     0x3daf60: sub             SP, SP, #0x30
    // 0x3daf64: SetupParameters(Chapter14GameState this /* r1 => r3, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x3daf64: mov             x0, x3
    //     0x3daf68: stur            x3, [fp, #-0x10]
    //     0x3daf6c: mov             x3, x1
    //     0x3daf70: stur            x1, [fp, #-8]
    // 0x3daf74: CheckStackOverflow
    //     0x3daf74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3daf78: cmp             SP, x16
    //     0x3daf7c: b.ls            #0x3db0d0
    // 0x3daf80: mov             x1, x3
    // 0x3daf84: r0 = getGeneratorInfo()
    //     0x3daf84: bl              #0x80d308  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getGeneratorInfo
    // 0x3daf88: stur            x0, [fp, #-0x28]
    // 0x3daf8c: LoadField: r3 = r0->field_27
    //     0x3daf8c: ldur            w3, [x0, #0x27]
    // 0x3daf90: DecompressPointer r3
    //     0x3daf90: add             x3, x3, HEAP, lsl #32
    // 0x3daf94: stur            x3, [fp, #-0x20]
    // 0x3daf98: cmp             w3, NULL
    // 0x3daf9c: b.eq            #0x3db0d8
    // 0x3dafa0: LoadField: r4 = r3->field_b
    //     0x3dafa0: ldur            w4, [x3, #0xb]
    // 0x3dafa4: DecompressPointer r4
    //     0x3dafa4: add             x4, x4, HEAP, lsl #32
    // 0x3dafa8: ldur            x2, [fp, #-0x10]
    // 0x3dafac: stur            x4, [fp, #-0x18]
    // 0x3dafb0: r1 = Instance_CustomNum
    //     0x3dafb0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3dafb4: ldr             x1, [x1, #0x2f0]
    // 0x3dafb8: r0 = pow()
    //     0x3dafb8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3dafbc: mov             x3, x0
    // 0x3dafc0: ldur            x0, [fp, #-0x20]
    // 0x3dafc4: stur            x3, [fp, #-0x30]
    // 0x3dafc8: LoadField: r4 = r0->field_f
    //     0x3dafc8: ldur            w4, [x0, #0xf]
    // 0x3dafcc: DecompressPointer r4
    //     0x3dafcc: add             x4, x4, HEAP, lsl #32
    // 0x3dafd0: ldur            x0, [fp, #-0x28]
    // 0x3dafd4: stur            x4, [fp, #-0x10]
    // 0x3dafd8: LoadField: r1 = r0->field_23
    //     0x3dafd8: ldur            w1, [x0, #0x23]
    // 0x3dafdc: DecompressPointer r1
    //     0x3dafdc: add             x1, x1, HEAP, lsl #32
    // 0x3dafe0: r0 = LoadClassIdInstr(r1)
    //     0x3dafe0: ldur            x0, [x1, #-1]
    //     0x3dafe4: ubfx            x0, x0, #0xc, #0x14
    // 0x3dafe8: r2 = Instance_Chapter14Stat
    //     0x3dafe8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x3dafec: ldr             x2, [x2, #0x1d8]
    // 0x3daff0: r0 = GDT[cid_x0 + -0xf99]()
    //     0x3daff0: sub             lr, x0, #0xf99
    //     0x3daff4: ldr             lr, [x21, lr, lsl #3]
    //     0x3daff8: blr             lr
    // 0x3daffc: tbnz            w0, #4, #0x3db024
    // 0x3db000: ldur            x0, [fp, #-8]
    // 0x3db004: LoadField: r1 = r0->field_43
    //     0x3db004: ldur            w1, [x0, #0x43]
    // 0x3db008: DecompressPointer r1
    //     0x3db008: add             x1, x1, HEAP, lsl #32
    // 0x3db00c: r2 = 240
    //     0x3db00c: movz            x2, #0xf0
    // 0x3db010: r0 = containsKey()
    //     0x3db010: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x3db014: tbnz            w0, #4, #0x3db024
    // 0x3db018: r3 = Instance_CustomNum
    //     0x3db018: add             x3, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x3db01c: ldr             x3, [x3, #0x60]
    // 0x3db020: b               #0x3db02c
    // 0x3db024: r3 = Instance_CustomNum
    //     0x3db024: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3db028: ldr             x3, [x3, #0xa70]
    // 0x3db02c: ldur            x0, [fp, #-8]
    // 0x3db030: stur            x3, [fp, #-0x20]
    // 0x3db034: LoadField: r1 = r0->field_43
    //     0x3db034: ldur            w1, [x0, #0x43]
    // 0x3db038: DecompressPointer r1
    //     0x3db038: add             x1, x1, HEAP, lsl #32
    // 0x3db03c: r2 = 340
    //     0x3db03c: movz            x2, #0x154
    // 0x3db040: r0 = containsKey()
    //     0x3db040: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x3db044: tbnz            w0, #4, #0x3db054
    // 0x3db048: r5 = Instance_CustomNum
    //     0x3db048: add             x5, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x3db04c: ldr             x5, [x5, #0x60]
    // 0x3db050: b               #0x3db05c
    // 0x3db054: r5 = Instance_CustomNum
    //     0x3db054: add             x5, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3db058: ldr             x5, [x5, #0xa70]
    // 0x3db05c: ldur            x0, [fp, #-8]
    // 0x3db060: stur            x5, [fp, #-0x28]
    // 0x3db064: LoadField: r1 = r0->field_1b
    //     0x3db064: ldur            w1, [x0, #0x1b]
    // 0x3db068: DecompressPointer r1
    //     0x3db068: add             x1, x1, HEAP, lsl #32
    // 0x3db06c: r2 = 380
    //     0x3db06c: movz            x2, #0x17c
    // 0x3db070: r0 = contains()
    //     0x3db070: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x3db074: tbnz            w0, #4, #0x3db084
    // 0x3db078: r6 = Instance_CustomNum
    //     0x3db078: add             x6, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x3db07c: ldr             x6, [x6, #0x60]
    // 0x3db080: b               #0x3db08c
    // 0x3db084: r6 = Instance_CustomNum
    //     0x3db084: add             x6, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3db088: ldr             x6, [x6, #0xa70]
    // 0x3db08c: ldur            x0, [fp, #-0x18]
    // 0x3db090: ldur            x1, [fp, #-0x30]
    // 0x3db094: ldur            x2, [fp, #-0x10]
    // 0x3db098: ldur            x3, [fp, #-0x20]
    // 0x3db09c: ldur            x5, [fp, #-0x28]
    // 0x3db0a0: r0 = mult5()
    //     0x3db0a0: bl              #0x3db218  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult5
    // 0x3db0a4: r1 = <Chapter14Stat, CustomNum>
    //     0x3db0a4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a668] TypeArguments: <Chapter14Stat, CustomNum>
    //     0x3db0a8: ldr             x1, [x1, #0x668]
    // 0x3db0ac: stur            x0, [fp, #-8]
    // 0x3db0b0: r0 = Tuple2()
    //     0x3db0b0: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3db0b4: ldur            x1, [fp, #-0x18]
    // 0x3db0b8: StoreField: r0->field_b = r1
    //     0x3db0b8: stur            w1, [x0, #0xb]
    // 0x3db0bc: ldur            x1, [fp, #-8]
    // 0x3db0c0: StoreField: r0->field_f = r1
    //     0x3db0c0: stur            w1, [x0, #0xf]
    // 0x3db0c4: LeaveFrame
    //     0x3db0c4: mov             SP, fp
    //     0x3db0c8: ldp             fp, lr, [SP], #0x10
    // 0x3db0cc: ret
    //     0x3db0cc: ret             
    // 0x3db0d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3db0d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3db0d4: b               #0x3daf80
    // 0x3db0d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3db0d8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter14Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3db0dc, size: 0x40
    // 0x3db0dc: EnterFrame
    //     0x3db0dc: stp             fp, lr, [SP, #-0x10]!
    //     0x3db0e0: mov             fp, SP
    // 0x3db0e4: ldr             x0, [fp, #0x20]
    // 0x3db0e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3db0e8: ldur            w1, [x0, #0x17]
    // 0x3db0ec: DecompressPointer r1
    //     0x3db0ec: add             x1, x1, HEAP, lsl #32
    // 0x3db0f0: CheckStackOverflow
    //     0x3db0f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3db0f4: cmp             SP, x16
    //     0x3db0f8: b.ls            #0x3db114
    // 0x3db0fc: ldr             x2, [fp, #0x18]
    // 0x3db100: ldr             x3, [fp, #0x10]
    // 0x3db104: r0 = getCostToBuyOneMoreGenerator()
    //     0x3db104: bl              #0x3daf58  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getCostToBuyOneMoreGenerator
    // 0x3db108: LeaveFrame
    //     0x3db108: mov             SP, fp
    //     0x3db10c: ldp             fp, lr, [SP], #0x10
    // 0x3db110: ret
    //     0x3db110: ret             
    // 0x3db114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3db114: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3db118: b               #0x3db0fc
  }
  _ Chapter14GameState(/* No info */) {
    // ** addr: 0x46c318, size: 0x208
    // 0x46c318: EnterFrame
    //     0x46c318: stp             fp, lr, [SP, #-0x10]!
    //     0x46c31c: mov             fp, SP
    // 0x46c320: AllocStack(0x38)
    //     0x46c320: sub             SP, SP, #0x38
    // 0x46c324: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46c328: mov             x4, x1
    // 0x46c32c: mov             x3, x2
    // 0x46c330: stur            x1, [fp, #-8]
    // 0x46c334: stur            x2, [fp, #-0x10]
    // 0x46c338: CheckStackOverflow
    //     0x46c338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46c33c: cmp             SP, x16
    //     0x46c340: b.ls            #0x46c518
    // 0x46c344: StoreField: r4->field_8b = r0
    //     0x46c344: stur            w0, [x4, #0x8b]
    // 0x46c348: StoreField: r4->field_8f = r0
    //     0x46c348: stur            w0, [x4, #0x8f]
    // 0x46c34c: r1 = Null
    //     0x46c34c: mov             x1, NULL
    // 0x46c350: r2 = 56
    //     0x46c350: movz            x2, #0x38
    // 0x46c354: r0 = AllocateArray()
    //     0x46c354: bl              #0x82746c  ; AllocateArrayStub
    // 0x46c358: r16 = 2
    //     0x46c358: movz            x16, #0x2
    // 0x46c35c: StoreField: r0->field_f = r16
    //     0x46c35c: stur            w16, [x0, #0xf]
    // 0x46c360: r16 = Instance_Chapter14Stat
    //     0x46c360: add             x16, PP, #0x11, lsl #12  ; [pp+0x11140] Obj!Chapter14Stat@85f9c1
    //     0x46c364: ldr             x16, [x16, #0x140]
    // 0x46c368: StoreField: r0->field_13 = r16
    //     0x46c368: stur            w16, [x0, #0x13]
    // 0x46c36c: r16 = 4
    //     0x46c36c: movz            x16, #0x4
    // 0x46c370: ArrayStore: r0[0] = r16  ; List_4
    //     0x46c370: stur            w16, [x0, #0x17]
    // 0x46c374: r16 = Instance_Chapter14Stat
    //     0x46c374: add             x16, PP, #0x11, lsl #12  ; [pp+0x11148] Obj!Chapter14Stat@85f9a1
    //     0x46c378: ldr             x16, [x16, #0x148]
    // 0x46c37c: StoreField: r0->field_1b = r16
    //     0x46c37c: stur            w16, [x0, #0x1b]
    // 0x46c380: r16 = 6
    //     0x46c380: movz            x16, #0x6
    // 0x46c384: StoreField: r0->field_1f = r16
    //     0x46c384: stur            w16, [x0, #0x1f]
    // 0x46c388: r16 = Instance_Chapter14Stat
    //     0x46c388: add             x16, PP, #0x11, lsl #12  ; [pp+0x11150] Obj!Chapter14Stat@85f981
    //     0x46c38c: ldr             x16, [x16, #0x150]
    // 0x46c390: StoreField: r0->field_23 = r16
    //     0x46c390: stur            w16, [x0, #0x23]
    // 0x46c394: r16 = 8
    //     0x46c394: movz            x16, #0x8
    // 0x46c398: StoreField: r0->field_27 = r16
    //     0x46c398: stur            w16, [x0, #0x27]
    // 0x46c39c: r16 = Instance_Chapter14Stat
    //     0x46c39c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11158] Obj!Chapter14Stat@85f961
    //     0x46c3a0: ldr             x16, [x16, #0x158]
    // 0x46c3a4: StoreField: r0->field_2b = r16
    //     0x46c3a4: stur            w16, [x0, #0x2b]
    // 0x46c3a8: r16 = 10
    //     0x46c3a8: movz            x16, #0xa
    // 0x46c3ac: StoreField: r0->field_2f = r16
    //     0x46c3ac: stur            w16, [x0, #0x2f]
    // 0x46c3b0: r16 = Instance_Chapter14Stat
    //     0x46c3b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11160] Obj!Chapter14Stat@85f941
    //     0x46c3b4: ldr             x16, [x16, #0x160]
    // 0x46c3b8: StoreField: r0->field_33 = r16
    //     0x46c3b8: stur            w16, [x0, #0x33]
    // 0x46c3bc: r16 = 12
    //     0x46c3bc: movz            x16, #0xc
    // 0x46c3c0: StoreField: r0->field_37 = r16
    //     0x46c3c0: stur            w16, [x0, #0x37]
    // 0x46c3c4: r16 = Instance_Chapter14Stat
    //     0x46c3c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11168] Obj!Chapter14Stat@85f921
    //     0x46c3c8: ldr             x16, [x16, #0x168]
    // 0x46c3cc: StoreField: r0->field_3b = r16
    //     0x46c3cc: stur            w16, [x0, #0x3b]
    // 0x46c3d0: r16 = 14
    //     0x46c3d0: movz            x16, #0xe
    // 0x46c3d4: StoreField: r0->field_3f = r16
    //     0x46c3d4: stur            w16, [x0, #0x3f]
    // 0x46c3d8: r16 = Instance_Chapter14Stat
    //     0x46c3d8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11170] Obj!Chapter14Stat@85f901
    //     0x46c3dc: ldr             x16, [x16, #0x170]
    // 0x46c3e0: StoreField: r0->field_43 = r16
    //     0x46c3e0: stur            w16, [x0, #0x43]
    // 0x46c3e4: r16 = 202
    //     0x46c3e4: movz            x16, #0xca
    // 0x46c3e8: StoreField: r0->field_47 = r16
    //     0x46c3e8: stur            w16, [x0, #0x47]
    // 0x46c3ec: r16 = Instance_Chapter14Stat
    //     0x46c3ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c3f0: ldr             x16, [x16, #0x178]
    // 0x46c3f4: StoreField: r0->field_4b = r16
    //     0x46c3f4: stur            w16, [x0, #0x4b]
    // 0x46c3f8: r16 = 204
    //     0x46c3f8: movz            x16, #0xcc
    // 0x46c3fc: StoreField: r0->field_4f = r16
    //     0x46c3fc: stur            w16, [x0, #0x4f]
    // 0x46c400: r16 = Instance_Chapter14Stat
    //     0x46c400: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c404: ldr             x16, [x16, #0x178]
    // 0x46c408: StoreField: r0->field_53 = r16
    //     0x46c408: stur            w16, [x0, #0x53]
    // 0x46c40c: r16 = 206
    //     0x46c40c: movz            x16, #0xce
    // 0x46c410: StoreField: r0->field_57 = r16
    //     0x46c410: stur            w16, [x0, #0x57]
    // 0x46c414: r16 = Instance_Chapter14Stat
    //     0x46c414: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c418: ldr             x16, [x16, #0x178]
    // 0x46c41c: StoreField: r0->field_5b = r16
    //     0x46c41c: stur            w16, [x0, #0x5b]
    // 0x46c420: r16 = 208
    //     0x46c420: movz            x16, #0xd0
    // 0x46c424: StoreField: r0->field_5f = r16
    //     0x46c424: stur            w16, [x0, #0x5f]
    // 0x46c428: r16 = Instance_Chapter14Stat
    //     0x46c428: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c42c: ldr             x16, [x16, #0x178]
    // 0x46c430: StoreField: r0->field_63 = r16
    //     0x46c430: stur            w16, [x0, #0x63]
    // 0x46c434: r16 = 210
    //     0x46c434: movz            x16, #0xd2
    // 0x46c438: StoreField: r0->field_67 = r16
    //     0x46c438: stur            w16, [x0, #0x67]
    // 0x46c43c: r16 = Instance_Chapter14Stat
    //     0x46c43c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c440: ldr             x16, [x16, #0x178]
    // 0x46c444: StoreField: r0->field_6b = r16
    //     0x46c444: stur            w16, [x0, #0x6b]
    // 0x46c448: r16 = 212
    //     0x46c448: movz            x16, #0xd4
    // 0x46c44c: StoreField: r0->field_6f = r16
    //     0x46c44c: stur            w16, [x0, #0x6f]
    // 0x46c450: r16 = Instance_Chapter14Stat
    //     0x46c450: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c454: ldr             x16, [x16, #0x178]
    // 0x46c458: StoreField: r0->field_73 = r16
    //     0x46c458: stur            w16, [x0, #0x73]
    // 0x46c45c: r16 = 214
    //     0x46c45c: movz            x16, #0xd6
    // 0x46c460: StoreField: r0->field_77 = r16
    //     0x46c460: stur            w16, [x0, #0x77]
    // 0x46c464: r16 = Instance_Chapter14Stat
    //     0x46c464: add             x16, PP, #0x11, lsl #12  ; [pp+0x11178] Obj!Chapter14Stat@85f8e1
    //     0x46c468: ldr             x16, [x16, #0x178]
    // 0x46c46c: StoreField: r0->field_7b = r16
    //     0x46c46c: stur            w16, [x0, #0x7b]
    // 0x46c470: r16 = <int, Chapter14Stat>
    //     0x46c470: add             x16, PP, #0x11, lsl #12  ; [pp+0x11180] TypeArguments: <int, Chapter14Stat>
    //     0x46c474: ldr             x16, [x16, #0x180]
    // 0x46c478: stp             x0, x16, [SP]
    // 0x46c47c: r0 = Map._fromLiteral()
    //     0x46c47c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46c480: ldur            x3, [fp, #-8]
    // 0x46c484: StoreField: r3->field_93 = r0
    //     0x46c484: stur            w0, [x3, #0x93]
    //     0x46c488: ldurb           w16, [x3, #-1]
    //     0x46c48c: ldurb           w17, [x0, #-1]
    //     0x46c490: and             x16, x17, x16, lsr #2
    //     0x46c494: tst             x16, HEAP, lsr #32
    //     0x46c498: b.eq            #0x46c4a0
    //     0x46c49c: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46c4a0: r1 = Function '<anonymous closure>':.
    //     0x46c4a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11188] AnonymousClosure: (0x46c8b0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x46c4a4: ldr             x1, [x1, #0x188]
    // 0x46c4a8: r2 = Null
    //     0x46c4a8: mov             x2, NULL
    // 0x46c4ac: r0 = AllocateClosure()
    //     0x46c4ac: bl              #0x826750  ; AllocateClosureStub
    // 0x46c4b0: r1 = Function '<anonymous closure>':.
    //     0x46c4b0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11190] AnonymousClosure: (0x46c6f0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x46c4b4: ldr             x1, [x1, #0x190]
    // 0x46c4b8: r2 = Null
    //     0x46c4b8: mov             x2, NULL
    // 0x46c4bc: stur            x0, [fp, #-0x18]
    // 0x46c4c0: r0 = AllocateClosure()
    //     0x46c4c0: bl              #0x826750  ; AllocateClosureStub
    // 0x46c4c4: r1 = Function '<anonymous closure>':.
    //     0x46c4c4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11198] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x46c4c8: ldr             x1, [x1, #0x198]
    // 0x46c4cc: r2 = Null
    //     0x46c4cc: mov             x2, NULL
    // 0x46c4d0: stur            x0, [fp, #-0x20]
    // 0x46c4d4: r0 = AllocateClosure()
    //     0x46c4d4: bl              #0x826750  ; AllocateClosureStub
    // 0x46c4d8: r1 = Function '<anonymous closure>':.
    //     0x46c4d8: add             x1, PP, #0x11, lsl #12  ; [pp+0x111a0] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46c4dc: ldr             x1, [x1, #0x1a0]
    // 0x46c4e0: r2 = Null
    //     0x46c4e0: mov             x2, NULL
    // 0x46c4e4: stur            x0, [fp, #-0x28]
    // 0x46c4e8: r0 = AllocateClosure()
    //     0x46c4e8: bl              #0x826750  ; AllocateClosureStub
    // 0x46c4ec: ldur            x1, [fp, #-8]
    // 0x46c4f0: ldur            x2, [fp, #-0x10]
    // 0x46c4f4: ldur            x3, [fp, #-0x18]
    // 0x46c4f8: ldur            x5, [fp, #-0x20]
    // 0x46c4fc: ldur            x6, [fp, #-0x28]
    // 0x46c500: mov             x7, x0
    // 0x46c504: r0 = IPlayableGameState()
    //     0x46c504: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46c508: r0 = Null
    //     0x46c508: mov             x0, NULL
    // 0x46c50c: LeaveFrame
    //     0x46c50c: mov             SP, fp
    //     0x46c510: ldp             fp, lr, [SP], #0x10
    // 0x46c514: ret
    //     0x46c514: ret             
    // 0x46c518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46c518: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46c51c: b               #0x46c344
  }
  [closure] String <anonymous closure>(dynamic, Chapter14Stat) {
    // ** addr: 0x46c520, size: 0x30
    // 0x46c520: EnterFrame
    //     0x46c520: stp             fp, lr, [SP, #-0x10]!
    //     0x46c524: mov             fp, SP
    // 0x46c528: CheckStackOverflow
    //     0x46c528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46c52c: cmp             SP, x16
    //     0x46c530: b.ls            #0x46c548
    // 0x46c534: ldr             x1, [fp, #0x10]
    // 0x46c538: r0 = humanName()
    //     0x46c538: bl              #0x46c550  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] ::humanName
    // 0x46c53c: LeaveFrame
    //     0x46c53c: mov             SP, fp
    //     0x46c540: ldp             fp, lr, [SP], #0x10
    // 0x46c544: ret
    //     0x46c544: ret             
    // 0x46c548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46c548: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46c54c: b               #0x46c534
  }
  [closure] String <anonymous closure>(dynamic, Chapter14Stat) {
    // ** addr: 0x46c6f0, size: 0x30
    // 0x46c6f0: EnterFrame
    //     0x46c6f0: stp             fp, lr, [SP, #-0x10]!
    //     0x46c6f4: mov             fp, SP
    // 0x46c6f8: CheckStackOverflow
    //     0x46c6f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46c6fc: cmp             SP, x16
    //     0x46c700: b.ls            #0x46c718
    // 0x46c704: ldr             x1, [fp, #0x10]
    // 0x46c708: r0 = shortenedName()
    //     0x46c708: bl              #0x46c720  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] ::shortenedName
    // 0x46c70c: LeaveFrame
    //     0x46c70c: mov             SP, fp
    //     0x46c710: ldp             fp, lr, [SP], #0x10
    // 0x46c714: ret
    //     0x46c714: ret             
    // 0x46c718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46c718: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46c71c: b               #0x46c704
  }
  [closure] Chapter14Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46c8b0, size: 0x44
    // 0x46c8b0: r2 = const [Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat', Instance of 'Chapter14Stat']
    //     0x46c8b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11270] List<Chapter14Stat>(14)
    //     0x46c8b4: ldr             x2, [x2, #0x270]
    // 0x46c8b8: ldr             x3, [SP]
    // 0x46c8bc: r4 = LoadInt32Instr(r3)
    //     0x46c8bc: sbfx            x4, x3, #1, #0x1f
    //     0x46c8c0: tbz             w3, #0, #0x46c8c8
    //     0x46c8c4: ldur            x4, [x3, #7]
    // 0x46c8c8: mov             x1, x4
    // 0x46c8cc: r0 = 14
    //     0x46c8cc: movz            x0, #0xe
    // 0x46c8d0: cmp             x1, x0
    // 0x46c8d4: b.hs            #0x46c8e8
    // 0x46c8d8: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46c8d8: add             x16, x2, x4, lsl #2
    //     0x46c8dc: ldur            w0, [x16, #0xf]
    // 0x46c8e0: DecompressPointer r0
    //     0x46c8e0: add             x0, x0, HEAP, lsl #32
    // 0x46c8e4: ret
    //     0x46c8e4: ret             
    // 0x46c8e8: EnterFrame
    //     0x46c8e8: stp             fp, lr, [SP, #-0x10]!
    //     0x46c8ec: mov             fp, SP
    // 0x46c8f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46c8f0: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e6ff4, size: 0x74
    // 0x4e6ff4: EnterFrame
    //     0x4e6ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6ff8: mov             fp, SP
    // 0x4e6ffc: AllocStack(0x10)
    //     0x4e6ffc: sub             SP, SP, #0x10
    // 0x4e7000: SetupParameters(Chapter14GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e7000: stur            x1, [fp, #-8]
    // 0x4e7004: r1 = 1
    //     0x4e7004: movz            x1, #0x1
    // 0x4e7008: r0 = AllocateContext()
    //     0x4e7008: bl              #0x82637c  ; AllocateContextStub
    // 0x4e700c: mov             x1, x0
    // 0x4e7010: ldur            x0, [fp, #-8]
    // 0x4e7014: StoreField: r1->field_f = r0
    //     0x4e7014: stur            w0, [x1, #0xf]
    // 0x4e7018: mov             x2, x1
    // 0x4e701c: r1 = Function '<anonymous closure>':.
    //     0x4e701c: add             x1, PP, #0x25, lsl #12  ; [pp+0x25738] AnonymousClosure: (0x4e7068), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::makeHeader (0x4e6ff4)
    //     0x4e7020: ldr             x1, [x1, #0x738]
    // 0x4e7024: r0 = AllocateClosure()
    //     0x4e7024: bl              #0x826750  ; AllocateClosureStub
    // 0x4e7028: stur            x0, [fp, #-8]
    // 0x4e702c: r0 = MainStatDisplay()
    //     0x4e702c: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e7030: mov             x3, x0
    // 0x4e7034: ldur            x0, [fp, #-8]
    // 0x4e7038: stur            x3, [fp, #-0x10]
    // 0x4e703c: StoreField: r3->field_b = r0
    //     0x4e703c: stur            w0, [x3, #0xb]
    // 0x4e7040: r1 = Function '<anonymous closure>':.
    //     0x4e7040: add             x1, PP, #0x25, lsl #12  ; [pp+0x25740] AnonymousClosure: (0x7b6794), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::makeHeader (0x4e78b8)
    //     0x4e7044: ldr             x1, [x1, #0x740]
    // 0x4e7048: r2 = Null
    //     0x4e7048: mov             x2, NULL
    // 0x4e704c: r0 = AllocateClosure()
    //     0x4e704c: bl              #0x826750  ; AllocateClosureStub
    // 0x4e7050: mov             x1, x0
    // 0x4e7054: ldur            x0, [fp, #-0x10]
    // 0x4e7058: StoreField: r0->field_f = r1
    //     0x4e7058: stur            w1, [x0, #0xf]
    // 0x4e705c: LeaveFrame
    //     0x4e705c: mov             SP, fp
    //     0x4e7060: ldp             fp, lr, [SP], #0x10
    // 0x4e7064: ret
    //     0x4e7064: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e7068, size: 0xf4
    // 0x4e7068: EnterFrame
    //     0x4e7068: stp             fp, lr, [SP, #-0x10]!
    //     0x4e706c: mov             fp, SP
    // 0x4e7070: AllocStack(0x18)
    //     0x4e7070: sub             SP, SP, #0x18
    // 0x4e7074: SetupParameters([dynamic _ /* r0 */])
    //     0x4e7074: ldr             x0, [fp, #0x10]
    //     0x4e7078: ldur            w3, [x0, #0x17]
    //     0x4e707c: add             x3, x3, HEAP, lsl #32
    //     0x4e7080: stur            x3, [fp, #-8]
    // 0x4e7084: CheckStackOverflow
    //     0x4e7084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e7088: cmp             SP, x16
    //     0x4e708c: b.ls            #0x4e7154
    // 0x4e7090: r1 = Null
    //     0x4e7090: mov             x1, NULL
    // 0x4e7094: r2 = 4
    //     0x4e7094: movz            x2, #0x4
    // 0x4e7098: r0 = AllocateArray()
    //     0x4e7098: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e709c: stur            x0, [fp, #-0x10]
    // 0x4e70a0: r16 = "Segfaults: "
    //     0x4e70a0: add             x16, PP, #0x25, lsl #12  ; [pp+0x25748] "Segfaults: "
    //     0x4e70a4: ldr             x16, [x16, #0x748]
    // 0x4e70a8: StoreField: r0->field_f = r16
    //     0x4e70a8: stur            w16, [x0, #0xf]
    // 0x4e70ac: ldur            x1, [fp, #-8]
    // 0x4e70b0: LoadField: r2 = r1->field_f
    //     0x4e70b0: ldur            w2, [x1, #0xf]
    // 0x4e70b4: DecompressPointer r2
    //     0x4e70b4: add             x2, x2, HEAP, lsl #32
    // 0x4e70b8: LoadField: r3 = r2->field_37
    //     0x4e70b8: ldur            w3, [x2, #0x37]
    // 0x4e70bc: DecompressPointer r3
    //     0x4e70bc: add             x3, x3, HEAP, lsl #32
    // 0x4e70c0: mov             x1, x3
    // 0x4e70c4: stur            x3, [fp, #-8]
    // 0x4e70c8: r2 = Instance_Chapter14Stat
    //     0x4e70c8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x4e70cc: ldr             x2, [x2, #0x1a8]
    // 0x4e70d0: r0 = _getValueOrData()
    //     0x4e70d0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e70d4: mov             x1, x0
    // 0x4e70d8: ldur            x0, [fp, #-8]
    // 0x4e70dc: LoadField: r2 = r0->field_f
    //     0x4e70dc: ldur            w2, [x0, #0xf]
    // 0x4e70e0: DecompressPointer r2
    //     0x4e70e0: add             x2, x2, HEAP, lsl #32
    // 0x4e70e4: cmp             w2, w1
    // 0x4e70e8: b.ne            #0x4e70f0
    // 0x4e70ec: r1 = Null
    //     0x4e70ec: mov             x1, NULL
    // 0x4e70f0: cmp             w1, NULL
    // 0x4e70f4: b.ne            #0x4e7100
    // 0x4e70f8: r0 = Null
    //     0x4e70f8: mov             x0, NULL
    // 0x4e70fc: b               #0x4e7108
    // 0x4e7100: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e7100: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e7104: r0 = toStringConsistentDecimalPlaces()
    //     0x4e7104: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e7108: cmp             w0, NULL
    // 0x4e710c: b.ne            #0x4e7114
    // 0x4e7110: r0 = 0
    //     0x4e7110: movz            x0, #0
    // 0x4e7114: ldur            x1, [fp, #-0x10]
    // 0x4e7118: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e7118: add             x25, x1, #0x13
    //     0x4e711c: str             w0, [x25]
    //     0x4e7120: tbz             w0, #0, #0x4e713c
    //     0x4e7124: ldurb           w16, [x1, #-1]
    //     0x4e7128: ldurb           w17, [x0, #-1]
    //     0x4e712c: and             x16, x17, x16, lsr #2
    //     0x4e7130: tst             x16, HEAP, lsr #32
    //     0x4e7134: b.eq            #0x4e713c
    //     0x4e7138: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e713c: ldur            x16, [fp, #-0x10]
    // 0x4e7140: str             x16, [SP]
    // 0x4e7144: r0 = _interpolate()
    //     0x4e7144: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e7148: LeaveFrame
    //     0x4e7148: mov             SP, fp
    //     0x4e714c: ldp             fp, lr, [SP], #0x10
    // 0x4e7150: ret
    //     0x4e7150: ret             
    // 0x4e7154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e7154: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e7158: b               #0x4e7090
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4fb030, size: 0xc34
    // 0x4fb030: EnterFrame
    //     0x4fb030: stp             fp, lr, [SP, #-0x10]!
    //     0x4fb034: mov             fp, SP
    // 0x4fb038: AllocStack(0x48)
    //     0x4fb038: sub             SP, SP, #0x48
    // 0x4fb03c: SetupParameters(Chapter14GameState this /* r1 => r1, fp-0x8 */)
    //     0x4fb03c: stur            x1, [fp, #-8]
    // 0x4fb040: CheckStackOverflow
    //     0x4fb040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fb044: cmp             SP, x16
    //     0x4fb048: b.ls            #0x4fbc5c
    // 0x4fb04c: r1 = 1
    //     0x4fb04c: movz            x1, #0x1
    // 0x4fb050: r0 = AllocateContext()
    //     0x4fb050: bl              #0x82637c  ; AllocateContextStub
    // 0x4fb054: mov             x3, x0
    // 0x4fb058: ldur            x0, [fp, #-8]
    // 0x4fb05c: stur            x3, [fp, #-0x10]
    // 0x4fb060: StoreField: r3->field_f = r0
    //     0x4fb060: stur            w0, [x3, #0xf]
    // 0x4fb064: r1 = Null
    //     0x4fb064: mov             x1, NULL
    // 0x4fb068: r2 = 76
    //     0x4fb068: movz            x2, #0x4c
    // 0x4fb06c: r0 = AllocateArray()
    //     0x4fb06c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fb070: StoreField: r0->field_f = rZR
    //     0x4fb070: stur            wzr, [x0, #0xf]
    // 0x4fb074: r16 = Instance_GeneratorInfo
    //     0x4fb074: add             x16, PP, #0x15, lsl #12  ; [pp+0x155d0] Obj!GeneratorInfo<Chapter14Stat>@82dbd1
    //     0x4fb078: ldr             x16, [x16, #0x5d0]
    // 0x4fb07c: StoreField: r0->field_13 = r16
    //     0x4fb07c: stur            w16, [x0, #0x13]
    // 0x4fb080: r16 = 2
    //     0x4fb080: movz            x16, #0x2
    // 0x4fb084: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fb084: stur            w16, [x0, #0x17]
    // 0x4fb088: r16 = Instance_GeneratorInfo
    //     0x4fb088: add             x16, PP, #0x15, lsl #12  ; [pp+0x155d8] Obj!GeneratorInfo<Chapter14Stat>@82db91
    //     0x4fb08c: ldr             x16, [x16, #0x5d8]
    // 0x4fb090: StoreField: r0->field_1b = r16
    //     0x4fb090: stur            w16, [x0, #0x1b]
    // 0x4fb094: r16 = 4
    //     0x4fb094: movz            x16, #0x4
    // 0x4fb098: StoreField: r0->field_1f = r16
    //     0x4fb098: stur            w16, [x0, #0x1f]
    // 0x4fb09c: r16 = Instance_GeneratorInfo
    //     0x4fb09c: add             x16, PP, #0x15, lsl #12  ; [pp+0x155e0] Obj!GeneratorInfo<Chapter14Stat>@82db51
    //     0x4fb0a0: ldr             x16, [x16, #0x5e0]
    // 0x4fb0a4: StoreField: r0->field_23 = r16
    //     0x4fb0a4: stur            w16, [x0, #0x23]
    // 0x4fb0a8: r16 = 6
    //     0x4fb0a8: movz            x16, #0x6
    // 0x4fb0ac: StoreField: r0->field_27 = r16
    //     0x4fb0ac: stur            w16, [x0, #0x27]
    // 0x4fb0b0: r16 = Instance_GeneratorInfo
    //     0x4fb0b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x155e8] Obj!GeneratorInfo<Chapter14Stat>@82db11
    //     0x4fb0b4: ldr             x16, [x16, #0x5e8]
    // 0x4fb0b8: StoreField: r0->field_2b = r16
    //     0x4fb0b8: stur            w16, [x0, #0x2b]
    // 0x4fb0bc: r16 = 8
    //     0x4fb0bc: movz            x16, #0x8
    // 0x4fb0c0: StoreField: r0->field_2f = r16
    //     0x4fb0c0: stur            w16, [x0, #0x2f]
    // 0x4fb0c4: r16 = Instance_GeneratorInfo
    //     0x4fb0c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x155f0] Obj!GeneratorInfo<Chapter14Stat>@82dad1
    //     0x4fb0c8: ldr             x16, [x16, #0x5f0]
    // 0x4fb0cc: StoreField: r0->field_33 = r16
    //     0x4fb0cc: stur            w16, [x0, #0x33]
    // 0x4fb0d0: r16 = 10
    //     0x4fb0d0: movz            x16, #0xa
    // 0x4fb0d4: StoreField: r0->field_37 = r16
    //     0x4fb0d4: stur            w16, [x0, #0x37]
    // 0x4fb0d8: r16 = Instance_GeneratorInfo
    //     0x4fb0d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x155f8] Obj!GeneratorInfo<Chapter14Stat>@82da91
    //     0x4fb0dc: ldr             x16, [x16, #0x5f8]
    // 0x4fb0e0: StoreField: r0->field_3b = r16
    //     0x4fb0e0: stur            w16, [x0, #0x3b]
    // 0x4fb0e4: r16 = 12
    //     0x4fb0e4: movz            x16, #0xc
    // 0x4fb0e8: StoreField: r0->field_3f = r16
    //     0x4fb0e8: stur            w16, [x0, #0x3f]
    // 0x4fb0ec: r16 = Instance_GeneratorInfo
    //     0x4fb0ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15600] Obj!GeneratorInfo<Chapter14Stat>@82da51
    //     0x4fb0f0: ldr             x16, [x16, #0x600]
    // 0x4fb0f4: StoreField: r0->field_43 = r16
    //     0x4fb0f4: stur            w16, [x0, #0x43]
    // 0x4fb0f8: r16 = 14
    //     0x4fb0f8: movz            x16, #0xe
    // 0x4fb0fc: StoreField: r0->field_47 = r16
    //     0x4fb0fc: stur            w16, [x0, #0x47]
    // 0x4fb100: r16 = Instance_GeneratorInfo
    //     0x4fb100: add             x16, PP, #0x15, lsl #12  ; [pp+0x15608] Obj!GeneratorInfo<Chapter14Stat>@82da11
    //     0x4fb104: ldr             x16, [x16, #0x608]
    // 0x4fb108: StoreField: r0->field_4b = r16
    //     0x4fb108: stur            w16, [x0, #0x4b]
    // 0x4fb10c: r16 = 202
    //     0x4fb10c: movz            x16, #0xca
    // 0x4fb110: StoreField: r0->field_4f = r16
    //     0x4fb110: stur            w16, [x0, #0x4f]
    // 0x4fb114: r16 = Instance_GeneratorInfo
    //     0x4fb114: add             x16, PP, #0x15, lsl #12  ; [pp+0x15610] Obj!GeneratorInfo<Chapter14Stat>@82d9d1
    //     0x4fb118: ldr             x16, [x16, #0x610]
    // 0x4fb11c: StoreField: r0->field_53 = r16
    //     0x4fb11c: stur            w16, [x0, #0x53]
    // 0x4fb120: r16 = 204
    //     0x4fb120: movz            x16, #0xcc
    // 0x4fb124: StoreField: r0->field_57 = r16
    //     0x4fb124: stur            w16, [x0, #0x57]
    // 0x4fb128: r16 = Instance_GeneratorInfo
    //     0x4fb128: add             x16, PP, #0x15, lsl #12  ; [pp+0x15618] Obj!GeneratorInfo<Chapter14Stat>@82d991
    //     0x4fb12c: ldr             x16, [x16, #0x618]
    // 0x4fb130: StoreField: r0->field_5b = r16
    //     0x4fb130: stur            w16, [x0, #0x5b]
    // 0x4fb134: r16 = 206
    //     0x4fb134: movz            x16, #0xce
    // 0x4fb138: StoreField: r0->field_5f = r16
    //     0x4fb138: stur            w16, [x0, #0x5f]
    // 0x4fb13c: r16 = Instance_GeneratorInfo
    //     0x4fb13c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15620] Obj!GeneratorInfo<Chapter14Stat>@82d951
    //     0x4fb140: ldr             x16, [x16, #0x620]
    // 0x4fb144: StoreField: r0->field_63 = r16
    //     0x4fb144: stur            w16, [x0, #0x63]
    // 0x4fb148: r16 = 208
    //     0x4fb148: movz            x16, #0xd0
    // 0x4fb14c: StoreField: r0->field_67 = r16
    //     0x4fb14c: stur            w16, [x0, #0x67]
    // 0x4fb150: r16 = Instance_GeneratorInfo
    //     0x4fb150: add             x16, PP, #0x15, lsl #12  ; [pp+0x15628] Obj!GeneratorInfo<Chapter14Stat>@82d911
    //     0x4fb154: ldr             x16, [x16, #0x628]
    // 0x4fb158: StoreField: r0->field_6b = r16
    //     0x4fb158: stur            w16, [x0, #0x6b]
    // 0x4fb15c: r16 = 210
    //     0x4fb15c: movz            x16, #0xd2
    // 0x4fb160: StoreField: r0->field_6f = r16
    //     0x4fb160: stur            w16, [x0, #0x6f]
    // 0x4fb164: r16 = Instance_GeneratorInfo
    //     0x4fb164: add             x16, PP, #0x15, lsl #12  ; [pp+0x15630] Obj!GeneratorInfo<Chapter14Stat>@82d8d1
    //     0x4fb168: ldr             x16, [x16, #0x630]
    // 0x4fb16c: StoreField: r0->field_73 = r16
    //     0x4fb16c: stur            w16, [x0, #0x73]
    // 0x4fb170: r16 = 212
    //     0x4fb170: movz            x16, #0xd4
    // 0x4fb174: StoreField: r0->field_77 = r16
    //     0x4fb174: stur            w16, [x0, #0x77]
    // 0x4fb178: r16 = Instance_GeneratorInfo
    //     0x4fb178: add             x16, PP, #0x15, lsl #12  ; [pp+0x15638] Obj!GeneratorInfo<Chapter14Stat>@82d891
    //     0x4fb17c: ldr             x16, [x16, #0x638]
    // 0x4fb180: StoreField: r0->field_7b = r16
    //     0x4fb180: stur            w16, [x0, #0x7b]
    // 0x4fb184: r16 = 214
    //     0x4fb184: movz            x16, #0xd6
    // 0x4fb188: StoreField: r0->field_7f = r16
    //     0x4fb188: stur            w16, [x0, #0x7f]
    // 0x4fb18c: r16 = Instance_GeneratorInfo
    //     0x4fb18c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15640] Obj!GeneratorInfo<Chapter14Stat>@82d851
    //     0x4fb190: ldr             x16, [x16, #0x640]
    // 0x4fb194: StoreField: r0->field_83 = r16
    //     0x4fb194: stur            w16, [x0, #0x83]
    // 0x4fb198: r16 = 402
    //     0x4fb198: movz            x16, #0x192
    // 0x4fb19c: StoreField: r0->field_87 = r16
    //     0x4fb19c: stur            w16, [x0, #0x87]
    // 0x4fb1a0: r16 = Instance_GeneratorInfo
    //     0x4fb1a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15648] Obj!GeneratorInfo<Chapter14Stat>@82d811
    //     0x4fb1a4: ldr             x16, [x16, #0x648]
    // 0x4fb1a8: StoreField: r0->field_8b = r16
    //     0x4fb1a8: stur            w16, [x0, #0x8b]
    // 0x4fb1ac: r16 = 404
    //     0x4fb1ac: movz            x16, #0x194
    // 0x4fb1b0: StoreField: r0->field_8f = r16
    //     0x4fb1b0: stur            w16, [x0, #0x8f]
    // 0x4fb1b4: r16 = Instance_GeneratorInfo
    //     0x4fb1b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15650] Obj!GeneratorInfo<Chapter14Stat>@82d7d1
    //     0x4fb1b8: ldr             x16, [x16, #0x650]
    // 0x4fb1bc: StoreField: r0->field_93 = r16
    //     0x4fb1bc: stur            w16, [x0, #0x93]
    // 0x4fb1c0: r16 = 406
    //     0x4fb1c0: movz            x16, #0x196
    // 0x4fb1c4: StoreField: r0->field_97 = r16
    //     0x4fb1c4: stur            w16, [x0, #0x97]
    // 0x4fb1c8: r16 = Instance_GeneratorInfo
    //     0x4fb1c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15658] Obj!GeneratorInfo<Chapter14Stat>@82d791
    //     0x4fb1cc: ldr             x16, [x16, #0x658]
    // 0x4fb1d0: StoreField: r0->field_9b = r16
    //     0x4fb1d0: stur            w16, [x0, #0x9b]
    // 0x4fb1d4: r16 = 408
    //     0x4fb1d4: movz            x16, #0x198
    // 0x4fb1d8: StoreField: r0->field_9f = r16
    //     0x4fb1d8: stur            w16, [x0, #0x9f]
    // 0x4fb1dc: r16 = Instance_GeneratorInfo
    //     0x4fb1dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15660] Obj!GeneratorInfo<Chapter14Stat>@82d751
    //     0x4fb1e0: ldr             x16, [x16, #0x660]
    // 0x4fb1e4: StoreField: r0->field_a3 = r16
    //     0x4fb1e4: stur            w16, [x0, #0xa3]
    // 0x4fb1e8: r16 = <int, GeneratorInfo<Chapter14Stat>>
    //     0x4fb1e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15668] TypeArguments: <int, GeneratorInfo<Chapter14Stat>>
    //     0x4fb1ec: ldr             x16, [x16, #0x668]
    // 0x4fb1f0: stp             x0, x16, [SP]
    // 0x4fb1f4: r0 = Map._fromLiteral()
    //     0x4fb1f4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fb1f8: ldur            x3, [fp, #-8]
    // 0x4fb1fc: StoreField: r3->field_8b = r0
    //     0x4fb1fc: stur            w0, [x3, #0x8b]
    //     0x4fb200: ldurb           w16, [x3, #-1]
    //     0x4fb204: ldurb           w17, [x0, #-1]
    //     0x4fb208: and             x16, x17, x16, lsr #2
    //     0x4fb20c: tst             x16, HEAP, lsr #32
    //     0x4fb210: b.eq            #0x4fb218
    //     0x4fb214: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4fb218: r1 = Null
    //     0x4fb218: mov             x1, NULL
    // 0x4fb21c: r2 = 80
    //     0x4fb21c: movz            x2, #0x50
    // 0x4fb220: r0 = AllocateArray()
    //     0x4fb220: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fb224: stur            x0, [fp, #-0x18]
    // 0x4fb228: r16 = 20
    //     0x4fb228: movz            x16, #0x14
    // 0x4fb22c: StoreField: r0->field_f = r16
    //     0x4fb22c: stur            w16, [x0, #0xf]
    // 0x4fb230: r1 = "Coffee Break"
    //     0x4fb230: add             x1, PP, #0x15, lsl #12  ; [pp+0x15670] "Coffee Break"
    //     0x4fb234: ldr             x1, [x1, #0x670]
    // 0x4fb238: r0 = autoString()
    //     0x4fb238: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fb23c: r1 = Null
    //     0x4fb23c: mov             x1, NULL
    // 0x4fb240: r2 = 4
    //     0x4fb240: movz            x2, #0x4
    // 0x4fb244: stur            x0, [fp, #-0x20]
    // 0x4fb248: r0 = AllocateArray()
    //     0x4fb248: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fb24c: stur            x0, [fp, #-0x28]
    // 0x4fb250: r16 = "Tapping the compile bar increments it by one second."
    //     0x4fb250: add             x16, PP, #0x15, lsl #12  ; [pp+0x15678] "Tapping the compile bar increments it by one second."
    //     0x4fb254: ldr             x16, [x16, #0x678]
    // 0x4fb258: StoreField: r0->field_f = r16
    //     0x4fb258: stur            w16, [x0, #0xf]
    // 0x4fb25c: r16 = "Tapping the compile bar increments it by two seconds."
    //     0x4fb25c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15680] "Tapping the compile bar increments it by two seconds."
    //     0x4fb260: ldr             x16, [x16, #0x680]
    // 0x4fb264: StoreField: r0->field_13 = r16
    //     0x4fb264: stur            w16, [x0, #0x13]
    // 0x4fb268: r1 = <String>
    //     0x4fb268: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fb26c: r0 = AllocateGrowableArray()
    //     0x4fb26c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fb270: mov             x2, x0
    // 0x4fb274: ldur            x0, [fp, #-0x28]
    // 0x4fb278: stur            x2, [fp, #-0x30]
    // 0x4fb27c: StoreField: r2->field_f = r0
    //     0x4fb27c: stur            w0, [x2, #0xf]
    // 0x4fb280: r0 = 4
    //     0x4fb280: movz            x0, #0x4
    // 0x4fb284: StoreField: r2->field_b = r0
    //     0x4fb284: stur            w0, [x2, #0xb]
    // 0x4fb288: r1 = <String>
    //     0x4fb288: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fb28c: r0 = Generator()
    //     0x4fb28c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fb290: mov             x3, x0
    // 0x4fb294: ldur            x0, [fp, #-0x30]
    // 0x4fb298: stur            x3, [fp, #-0x28]
    // 0x4fb29c: StoreField: r3->field_b = r0
    //     0x4fb29c: stur            w0, [x3, #0xb]
    // 0x4fb2a0: r1 = Null
    //     0x4fb2a0: mov             x1, NULL
    // 0x4fb2a4: r2 = 4
    //     0x4fb2a4: movz            x2, #0x4
    // 0x4fb2a8: r0 = AllocateArray()
    //     0x4fb2a8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fb2ac: stur            x0, [fp, #-0x30]
    // 0x4fb2b0: r16 = Instance_Tuple2
    //     0x4fb2b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15688] Obj!Tuple2<Chapter14Stat, CustomNum>@823eb1
    //     0x4fb2b4: ldr             x16, [x16, #0x688]
    // 0x4fb2b8: StoreField: r0->field_f = r16
    //     0x4fb2b8: stur            w16, [x0, #0xf]
    // 0x4fb2bc: r16 = Instance_Tuple2
    //     0x4fb2bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15690] Obj!Tuple2<Chapter14Stat, CustomNum>@823e91
    //     0x4fb2c0: ldr             x16, [x16, #0x690]
    // 0x4fb2c4: StoreField: r0->field_13 = r16
    //     0x4fb2c4: stur            w16, [x0, #0x13]
    // 0x4fb2c8: r1 = <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb2c8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15698] TypeArguments: <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb2cc: ldr             x1, [x1, #0x698]
    // 0x4fb2d0: r0 = AllocateGrowableArray()
    //     0x4fb2d0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fb2d4: mov             x2, x0
    // 0x4fb2d8: ldur            x0, [fp, #-0x30]
    // 0x4fb2dc: stur            x2, [fp, #-0x38]
    // 0x4fb2e0: StoreField: r2->field_f = r0
    //     0x4fb2e0: stur            w0, [x2, #0xf]
    // 0x4fb2e4: r0 = 4
    //     0x4fb2e4: movz            x0, #0x4
    // 0x4fb2e8: StoreField: r2->field_b = r0
    //     0x4fb2e8: stur            w0, [x2, #0xb]
    // 0x4fb2ec: r1 = <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb2ec: add             x1, PP, #0x15, lsl #12  ; [pp+0x15698] TypeArguments: <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb2f0: ldr             x1, [x1, #0x698]
    // 0x4fb2f4: r0 = Generator()
    //     0x4fb2f4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fb2f8: mov             x2, x0
    // 0x4fb2fc: ldur            x0, [fp, #-0x38]
    // 0x4fb300: stur            x2, [fp, #-0x30]
    // 0x4fb304: StoreField: r2->field_b = r0
    //     0x4fb304: stur            w0, [x2, #0xb]
    // 0x4fb308: r1 = <Chapter14Stat>
    //     0x4fb308: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb30c: ldr             x1, [x1, #0xf60]
    // 0x4fb310: r0 = UpgradeData()
    //     0x4fb310: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fb314: mov             x1, x0
    // 0x4fb318: ldur            x0, [fp, #-0x20]
    // 0x4fb31c: StoreField: r1->field_b = r0
    //     0x4fb31c: stur            w0, [x1, #0xb]
    // 0x4fb320: ldur            x0, [fp, #-0x28]
    // 0x4fb324: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fb324: stur            w0, [x1, #0x17]
    // 0x4fb328: r0 = Instance_IconData
    //     0x4fb328: add             x0, PP, #0x15, lsl #12  ; [pp+0x156a0] Obj!IconData@830351
    //     0x4fb32c: ldr             x0, [x0, #0x6a0]
    // 0x4fb330: StoreField: r1->field_13 = r0
    //     0x4fb330: stur            w0, [x1, #0x13]
    // 0x4fb334: ldur            x0, [fp, #-0x30]
    // 0x4fb338: StoreField: r1->field_f = r0
    //     0x4fb338: stur            w0, [x1, #0xf]
    // 0x4fb33c: mov             x0, x1
    // 0x4fb340: ldur            x1, [fp, #-0x18]
    // 0x4fb344: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fb344: add             x25, x1, #0x13
    //     0x4fb348: str             w0, [x25]
    //     0x4fb34c: tbz             w0, #0, #0x4fb368
    //     0x4fb350: ldurb           w16, [x1, #-1]
    //     0x4fb354: ldurb           w17, [x0, #-1]
    //     0x4fb358: and             x16, x17, x16, lsr #2
    //     0x4fb35c: tst             x16, HEAP, lsr #32
    //     0x4fb360: b.eq            #0x4fb368
    //     0x4fb364: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb368: ldur            x0, [fp, #-0x18]
    // 0x4fb36c: r16 = 40
    //     0x4fb36c: movz            x16, #0x28
    // 0x4fb370: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fb370: stur            w16, [x0, #0x17]
    // 0x4fb374: r1 = "Shell Scripts"
    //     0x4fb374: add             x1, PP, #0x15, lsl #12  ; [pp+0x156a8] "Shell Scripts"
    //     0x4fb378: ldr             x1, [x1, #0x6a8]
    // 0x4fb37c: r0 = autoString()
    //     0x4fb37c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fb380: r1 = Null
    //     0x4fb380: mov             x1, NULL
    // 0x4fb384: r2 = 4
    //     0x4fb384: movz            x2, #0x4
    // 0x4fb388: stur            x0, [fp, #-0x20]
    // 0x4fb38c: r0 = AllocateArray()
    //     0x4fb38c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fb390: stur            x0, [fp, #-0x28]
    // 0x4fb394: r16 = "Automate the compile bar."
    //     0x4fb394: add             x16, PP, #0x15, lsl #12  ; [pp+0x156b0] "Automate the compile bar."
    //     0x4fb398: ldr             x16, [x16, #0x6b0]
    // 0x4fb39c: StoreField: r0->field_f = r16
    //     0x4fb39c: stur            w16, [x0, #0xf]
    // 0x4fb3a0: r16 = "Unlocks I/O generators."
    //     0x4fb3a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x156b8] "Unlocks I/O generators."
    //     0x4fb3a4: ldr             x16, [x16, #0x6b8]
    // 0x4fb3a8: StoreField: r0->field_13 = r16
    //     0x4fb3a8: stur            w16, [x0, #0x13]
    // 0x4fb3ac: r1 = <String>
    //     0x4fb3ac: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fb3b0: r0 = AllocateGrowableArray()
    //     0x4fb3b0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fb3b4: mov             x2, x0
    // 0x4fb3b8: ldur            x0, [fp, #-0x28]
    // 0x4fb3bc: stur            x2, [fp, #-0x30]
    // 0x4fb3c0: StoreField: r2->field_f = r0
    //     0x4fb3c0: stur            w0, [x2, #0xf]
    // 0x4fb3c4: r0 = 4
    //     0x4fb3c4: movz            x0, #0x4
    // 0x4fb3c8: StoreField: r2->field_b = r0
    //     0x4fb3c8: stur            w0, [x2, #0xb]
    // 0x4fb3cc: r1 = <String>
    //     0x4fb3cc: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fb3d0: r0 = Generator()
    //     0x4fb3d0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fb3d4: mov             x3, x0
    // 0x4fb3d8: ldur            x0, [fp, #-0x30]
    // 0x4fb3dc: stur            x3, [fp, #-0x28]
    // 0x4fb3e0: StoreField: r3->field_b = r0
    //     0x4fb3e0: stur            w0, [x3, #0xb]
    // 0x4fb3e4: r1 = Null
    //     0x4fb3e4: mov             x1, NULL
    // 0x4fb3e8: r2 = 4
    //     0x4fb3e8: movz            x2, #0x4
    // 0x4fb3ec: r0 = AllocateArray()
    //     0x4fb3ec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fb3f0: stur            x0, [fp, #-0x30]
    // 0x4fb3f4: r16 = Instance_Tuple2
    //     0x4fb3f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x156c0] Obj!Tuple2<Chapter14Stat, CustomNum>@823e71
    //     0x4fb3f8: ldr             x16, [x16, #0x6c0]
    // 0x4fb3fc: StoreField: r0->field_f = r16
    //     0x4fb3fc: stur            w16, [x0, #0xf]
    // 0x4fb400: r16 = Instance_Tuple2
    //     0x4fb400: add             x16, PP, #0x15, lsl #12  ; [pp+0x156c8] Obj!Tuple2<Chapter14Stat, CustomNum>@823e51
    //     0x4fb404: ldr             x16, [x16, #0x6c8]
    // 0x4fb408: StoreField: r0->field_13 = r16
    //     0x4fb408: stur            w16, [x0, #0x13]
    // 0x4fb40c: r1 = <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb40c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15698] TypeArguments: <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb410: ldr             x1, [x1, #0x698]
    // 0x4fb414: r0 = AllocateGrowableArray()
    //     0x4fb414: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fb418: mov             x2, x0
    // 0x4fb41c: ldur            x0, [fp, #-0x30]
    // 0x4fb420: stur            x2, [fp, #-0x38]
    // 0x4fb424: StoreField: r2->field_f = r0
    //     0x4fb424: stur            w0, [x2, #0xf]
    // 0x4fb428: r0 = 4
    //     0x4fb428: movz            x0, #0x4
    // 0x4fb42c: StoreField: r2->field_b = r0
    //     0x4fb42c: stur            w0, [x2, #0xb]
    // 0x4fb430: r1 = <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb430: add             x1, PP, #0x15, lsl #12  ; [pp+0x15698] TypeArguments: <Tuple2<Chapter14Stat, CustomNum>>
    //     0x4fb434: ldr             x1, [x1, #0x698]
    // 0x4fb438: r0 = Generator()
    //     0x4fb438: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fb43c: mov             x2, x0
    // 0x4fb440: ldur            x0, [fp, #-0x38]
    // 0x4fb444: stur            x2, [fp, #-0x30]
    // 0x4fb448: StoreField: r2->field_b = r0
    //     0x4fb448: stur            w0, [x2, #0xb]
    // 0x4fb44c: r1 = <Chapter14Stat>
    //     0x4fb44c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb450: ldr             x1, [x1, #0xf60]
    // 0x4fb454: r0 = UpgradeData()
    //     0x4fb454: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fb458: mov             x3, x0
    // 0x4fb45c: ldur            x0, [fp, #-0x20]
    // 0x4fb460: stur            x3, [fp, #-0x38]
    // 0x4fb464: StoreField: r3->field_b = r0
    //     0x4fb464: stur            w0, [x3, #0xb]
    // 0x4fb468: ldur            x0, [fp, #-0x28]
    // 0x4fb46c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4fb46c: stur            w0, [x3, #0x17]
    // 0x4fb470: r5 = Instance_IconData
    //     0x4fb470: add             x5, PP, #0x13, lsl #12  ; [pp+0x13f68] Obj!IconData@82fbb1
    //     0x4fb474: ldr             x5, [x5, #0xf68]
    // 0x4fb478: StoreField: r3->field_13 = r5
    //     0x4fb478: stur            w5, [x3, #0x13]
    // 0x4fb47c: ldur            x0, [fp, #-0x30]
    // 0x4fb480: StoreField: r3->field_f = r0
    //     0x4fb480: stur            w0, [x3, #0xf]
    // 0x4fb484: ldur            x2, [fp, #-0x10]
    // 0x4fb488: r1 = Function '<anonymous closure>':.
    //     0x4fb488: add             x1, PP, #0x15, lsl #12  ; [pp+0x156d0] AnonymousClosure: (0x4fbf80), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::ensureInitialized (0x4fb030)
    //     0x4fb48c: ldr             x1, [x1, #0x6d0]
    // 0x4fb490: r0 = AllocateClosure()
    //     0x4fb490: bl              #0x826750  ; AllocateClosureStub
    // 0x4fb494: mov             x1, x0
    // 0x4fb498: ldur            x0, [fp, #-0x38]
    // 0x4fb49c: StoreField: r0->field_23 = r1
    //     0x4fb49c: stur            w1, [x0, #0x23]
    // 0x4fb4a0: ldur            x1, [fp, #-0x18]
    // 0x4fb4a4: ArrayStore: r1[3] = r0  ; List_4
    //     0x4fb4a4: add             x25, x1, #0x1b
    //     0x4fb4a8: str             w0, [x25]
    //     0x4fb4ac: tbz             w0, #0, #0x4fb4c8
    //     0x4fb4b0: ldurb           w16, [x1, #-1]
    //     0x4fb4b4: ldurb           w17, [x0, #-1]
    //     0x4fb4b8: and             x16, x17, x16, lsr #2
    //     0x4fb4bc: tst             x16, HEAP, lsr #32
    //     0x4fb4c0: b.eq            #0x4fb4c8
    //     0x4fb4c4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb4c8: ldur            x0, [fp, #-0x18]
    // 0x4fb4cc: r16 = 200
    //     0x4fb4cc: movz            x16, #0xc8
    // 0x4fb4d0: StoreField: r0->field_1f = r16
    //     0x4fb4d0: stur            w16, [x0, #0x1f]
    // 0x4fb4d4: r1 = <Chapter14Stat>
    //     0x4fb4d4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb4d8: ldr             x1, [x1, #0xf60]
    // 0x4fb4dc: r2 = Instance_Tuple2
    //     0x4fb4dc: add             x2, PP, #0x15, lsl #12  ; [pp+0x156d8] Obj!Tuple2<Chapter14Stat, CustomNum>@823e31
    //     0x4fb4e0: ldr             x2, [x2, #0x6d8]
    // 0x4fb4e4: r3 = "Unlocks autobuy for navigation generators."
    //     0x4fb4e4: add             x3, PP, #0x15, lsl #12  ; [pp+0x156e0] "Unlocks autobuy for navigation generators."
    //     0x4fb4e8: ldr             x3, [x3, #0x6e0]
    // 0x4fb4ec: r5 = Instance_IconData
    //     0x4fb4ec: add             x5, PP, #0x14, lsl #12  ; [pp+0x14858] Obj!IconData@82f5b1
    //     0x4fb4f0: ldr             x5, [x5, #0x858]
    // 0x4fb4f4: r6 = "Speed Up"
    //     0x4fb4f4: add             x6, PP, #0x15, lsl #12  ; [pp+0x156e8] "Speed Up"
    //     0x4fb4f8: ldr             x6, [x6, #0x6e8]
    // 0x4fb4fc: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb4fc: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb500: r0 = UpgradeData.single()
    //     0x4fb500: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb504: ldur            x1, [fp, #-0x18]
    // 0x4fb508: ArrayStore: r1[5] = r0  ; List_4
    //     0x4fb508: add             x25, x1, #0x23
    //     0x4fb50c: str             w0, [x25]
    //     0x4fb510: tbz             w0, #0, #0x4fb52c
    //     0x4fb514: ldurb           w16, [x1, #-1]
    //     0x4fb518: ldurb           w17, [x0, #-1]
    //     0x4fb51c: and             x16, x17, x16, lsr #2
    //     0x4fb520: tst             x16, HEAP, lsr #32
    //     0x4fb524: b.eq            #0x4fb52c
    //     0x4fb528: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb52c: ldur            x0, [fp, #-0x18]
    // 0x4fb530: r16 = 210
    //     0x4fb530: movz            x16, #0xd2
    // 0x4fb534: StoreField: r0->field_27 = r16
    //     0x4fb534: stur            w16, [x0, #0x27]
    // 0x4fb538: ldur            x2, [fp, #-0x10]
    // 0x4fb53c: r1 = Function '<anonymous closure>':.
    //     0x4fb53c: add             x1, PP, #0x15, lsl #12  ; [pp+0x156f0] AnonymousClosure: (0x4fbee0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::ensureInitialized (0x4fb030)
    //     0x4fb540: ldr             x1, [x1, #0x6f0]
    // 0x4fb544: r0 = AllocateClosure()
    //     0x4fb544: bl              #0x826750  ; AllocateClosureStub
    // 0x4fb548: str             x0, [SP]
    // 0x4fb54c: r1 = <Chapter14Stat>
    //     0x4fb54c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb550: ldr             x1, [x1, #0xf60]
    // 0x4fb554: r2 = Instance_Tuple2
    //     0x4fb554: add             x2, PP, #0x15, lsl #12  ; [pp+0x156f8] Obj!Tuple2<Chapter14Stat, CustomNum>@823e11
    //     0x4fb558: ldr             x2, [x2, #0x6f8]
    // 0x4fb55c: r3 = "Coffee Break and Shell Scripts are no longer reset upon prestige."
    //     0x4fb55c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15700] "Coffee Break and Shell Scripts are no longer reset upon prestige."
    //     0x4fb560: ldr             x3, [x3, #0x700]
    // 0x4fb564: r5 = Instance_IconData
    //     0x4fb564: add             x5, PP, #0x14, lsl #12  ; [pp+0x14ce8] Obj!IconData@82fa51
    //     0x4fb568: ldr             x5, [x5, #0xce8]
    // 0x4fb56c: r6 = "Automation"
    //     0x4fb56c: add             x6, PP, #0x15, lsl #12  ; [pp+0x15708] "Automation"
    //     0x4fb570: ldr             x6, [x6, #0x708]
    // 0x4fb574: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fb574: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fb578: ldr             x4, [x4, #0xcc0]
    // 0x4fb57c: r0 = UpgradeData.single()
    //     0x4fb57c: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb580: ldur            x1, [fp, #-0x18]
    // 0x4fb584: ArrayStore: r1[7] = r0  ; List_4
    //     0x4fb584: add             x25, x1, #0x2b
    //     0x4fb588: str             w0, [x25]
    //     0x4fb58c: tbz             w0, #0, #0x4fb5a8
    //     0x4fb590: ldurb           w16, [x1, #-1]
    //     0x4fb594: ldurb           w17, [x0, #-1]
    //     0x4fb598: and             x16, x17, x16, lsr #2
    //     0x4fb59c: tst             x16, HEAP, lsr #32
    //     0x4fb5a0: b.eq            #0x4fb5a8
    //     0x4fb5a4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb5a8: ldur            x0, [fp, #-0x18]
    // 0x4fb5ac: r16 = 220
    //     0x4fb5ac: movz            x16, #0xdc
    // 0x4fb5b0: StoreField: r0->field_2f = r16
    //     0x4fb5b0: stur            w16, [x0, #0x2f]
    // 0x4fb5b4: r1 = <Chapter14Stat>
    //     0x4fb5b4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb5b8: ldr             x1, [x1, #0xf60]
    // 0x4fb5bc: r2 = Instance_Tuple2
    //     0x4fb5bc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15710] Obj!Tuple2<Chapter14Stat, CustomNum>@823df1
    //     0x4fb5c0: ldr             x2, [x2, #0x710]
    // 0x4fb5c4: r3 = "Start each prestige with 1000 navigation and I/O instead of removing them completely."
    //     0x4fb5c4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15718] "Start each prestige with 1000 navigation and I/O instead of removing them completely."
    //     0x4fb5c8: ldr             x3, [x3, #0x718]
    // 0x4fb5cc: r5 = Instance_IconData
    //     0x4fb5cc: add             x5, PP, #0x15, lsl #12  ; [pp+0x15720] Obj!IconData@830331
    //     0x4fb5d0: ldr             x5, [x5, #0x720]
    // 0x4fb5d4: r6 = "Boilerplate"
    //     0x4fb5d4: add             x6, PP, #0x15, lsl #12  ; [pp+0x15728] "Boilerplate"
    //     0x4fb5d8: ldr             x6, [x6, #0x728]
    // 0x4fb5dc: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb5dc: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb5e0: r0 = UpgradeData.single()
    //     0x4fb5e0: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb5e4: ldur            x1, [fp, #-0x18]
    // 0x4fb5e8: ArrayStore: r1[9] = r0  ; List_4
    //     0x4fb5e8: add             x25, x1, #0x33
    //     0x4fb5ec: str             w0, [x25]
    //     0x4fb5f0: tbz             w0, #0, #0x4fb60c
    //     0x4fb5f4: ldurb           w16, [x1, #-1]
    //     0x4fb5f8: ldurb           w17, [x0, #-1]
    //     0x4fb5fc: and             x16, x17, x16, lsr #2
    //     0x4fb600: tst             x16, HEAP, lsr #32
    //     0x4fb604: b.eq            #0x4fb60c
    //     0x4fb608: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb60c: ldur            x0, [fp, #-0x18]
    // 0x4fb610: r16 = 240
    //     0x4fb610: movz            x16, #0xf0
    // 0x4fb614: StoreField: r0->field_37 = r16
    //     0x4fb614: stur            w16, [x0, #0x37]
    // 0x4fb618: r1 = <Chapter14Stat>
    //     0x4fb618: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb61c: ldr             x1, [x1, #0xf60]
    // 0x4fb620: r2 = Instance_Tuple2
    //     0x4fb620: add             x2, PP, #0x15, lsl #12  ; [pp+0x15730] Obj!Tuple2<Chapter14Stat, CustomNum>@823dd1
    //     0x4fb624: ldr             x2, [x2, #0x730]
    // 0x4fb628: r3 = "Reduces the cost of I/O generators by 99.9%."
    //     0x4fb628: add             x3, PP, #0x15, lsl #12  ; [pp+0x15738] "Reduces the cost of I/O generators by 99.9%."
    //     0x4fb62c: ldr             x3, [x3, #0x738]
    // 0x4fb630: r5 = Instance_IconData
    //     0x4fb630: add             x5, PP, #0x15, lsl #12  ; [pp+0x15740] Obj!IconData@830311
    //     0x4fb634: ldr             x5, [x5, #0x740]
    // 0x4fb638: r6 = "Panic"
    //     0x4fb638: add             x6, PP, #0x15, lsl #12  ; [pp+0x15748] "Panic"
    //     0x4fb63c: ldr             x6, [x6, #0x748]
    // 0x4fb640: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb640: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb644: r0 = UpgradeData.single()
    //     0x4fb644: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb648: ldur            x1, [fp, #-0x18]
    // 0x4fb64c: ArrayStore: r1[11] = r0  ; List_4
    //     0x4fb64c: add             x25, x1, #0x3b
    //     0x4fb650: str             w0, [x25]
    //     0x4fb654: tbz             w0, #0, #0x4fb670
    //     0x4fb658: ldurb           w16, [x1, #-1]
    //     0x4fb65c: ldurb           w17, [x0, #-1]
    //     0x4fb660: and             x16, x17, x16, lsr #2
    //     0x4fb664: tst             x16, HEAP, lsr #32
    //     0x4fb668: b.eq            #0x4fb670
    //     0x4fb66c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb670: ldur            x0, [fp, #-0x18]
    // 0x4fb674: r16 = 260
    //     0x4fb674: movz            x16, #0x104
    // 0x4fb678: StoreField: r0->field_3f = r16
    //     0x4fb678: stur            w16, [x0, #0x3f]
    // 0x4fb67c: r1 = <Chapter14Stat>
    //     0x4fb67c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb680: ldr             x1, [x1, #0xf60]
    // 0x4fb684: r2 = Instance_Tuple2
    //     0x4fb684: add             x2, PP, #0x15, lsl #12  ; [pp+0x15750] Obj!Tuple2<Chapter14Stat, CustomNum>@823db1
    //     0x4fb688: ldr             x2, [x2, #0x750]
    // 0x4fb68c: r3 = "Unlocks autobuy for I/O generators."
    //     0x4fb68c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15758] "Unlocks autobuy for I/O generators."
    //     0x4fb690: ldr             x3, [x3, #0x758]
    // 0x4fb694: r5 = Instance_IconData
    //     0x4fb694: add             x5, PP, #0x15, lsl #12  ; [pp+0x15760] Obj!IconData@8302f1
    //     0x4fb698: ldr             x5, [x5, #0x760]
    // 0x4fb69c: r6 = "Auto I/O"
    //     0x4fb69c: add             x6, PP, #0x15, lsl #12  ; [pp+0x15768] "Auto I/O"
    //     0x4fb6a0: ldr             x6, [x6, #0x768]
    // 0x4fb6a4: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb6a4: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb6a8: r0 = UpgradeData.single()
    //     0x4fb6a8: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb6ac: ldur            x1, [fp, #-0x18]
    // 0x4fb6b0: ArrayStore: r1[13] = r0  ; List_4
    //     0x4fb6b0: add             x25, x1, #0x43
    //     0x4fb6b4: str             w0, [x25]
    //     0x4fb6b8: tbz             w0, #0, #0x4fb6d4
    //     0x4fb6bc: ldurb           w16, [x1, #-1]
    //     0x4fb6c0: ldurb           w17, [x0, #-1]
    //     0x4fb6c4: and             x16, x17, x16, lsr #2
    //     0x4fb6c8: tst             x16, HEAP, lsr #32
    //     0x4fb6cc: b.eq            #0x4fb6d4
    //     0x4fb6d0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb6d4: ldur            x0, [fp, #-0x18]
    // 0x4fb6d8: r16 = 270
    //     0x4fb6d8: movz            x16, #0x10e
    // 0x4fb6dc: StoreField: r0->field_47 = r16
    //     0x4fb6dc: stur            w16, [x0, #0x47]
    // 0x4fb6e0: r1 = <Chapter14Stat>
    //     0x4fb6e0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb6e4: ldr             x1, [x1, #0xf60]
    // 0x4fb6e8: r2 = Instance_Tuple2
    //     0x4fb6e8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15770] Obj!Tuple2<Chapter14Stat, CustomNum>@823d91
    //     0x4fb6ec: ldr             x2, [x2, #0x770]
    // 0x4fb6f0: r3 = "Start each prestige with 1,000,000 navigation and I/O instead of removing them completely."
    //     0x4fb6f0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15778] "Start each prestige with 1,000,000 navigation and I/O instead of removing them completely."
    //     0x4fb6f4: ldr             x3, [x3, #0x778]
    // 0x4fb6f8: r5 = Instance_IconData
    //     0x4fb6f8: add             x5, PP, #0x15, lsl #12  ; [pp+0x15720] Obj!IconData@830331
    //     0x4fb6fc: ldr             x5, [x5, #0x720]
    // 0x4fb700: r6 = "Boilerplate 2"
    //     0x4fb700: add             x6, PP, #0x15, lsl #12  ; [pp+0x15780] "Boilerplate 2"
    //     0x4fb704: ldr             x6, [x6, #0x780]
    // 0x4fb708: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb708: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb70c: r0 = UpgradeData.single()
    //     0x4fb70c: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb710: ldur            x1, [fp, #-0x18]
    // 0x4fb714: ArrayStore: r1[15] = r0  ; List_4
    //     0x4fb714: add             x25, x1, #0x4b
    //     0x4fb718: str             w0, [x25]
    //     0x4fb71c: tbz             w0, #0, #0x4fb738
    //     0x4fb720: ldurb           w16, [x1, #-1]
    //     0x4fb724: ldurb           w17, [x0, #-1]
    //     0x4fb728: and             x16, x17, x16, lsr #2
    //     0x4fb72c: tst             x16, HEAP, lsr #32
    //     0x4fb730: b.eq            #0x4fb738
    //     0x4fb734: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb738: ldur            x0, [fp, #-0x18]
    // 0x4fb73c: r16 = 280
    //     0x4fb73c: movz            x16, #0x118
    // 0x4fb740: StoreField: r0->field_4f = r16
    //     0x4fb740: stur            w16, [x0, #0x4f]
    // 0x4fb744: ldur            x2, [fp, #-0x10]
    // 0x4fb748: r1 = Function '<anonymous closure>':.
    //     0x4fb748: add             x1, PP, #0x15, lsl #12  ; [pp+0x15788] AnonymousClosure: (0x4fbdfc), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::ensureInitialized (0x4fb030)
    //     0x4fb74c: ldr             x1, [x1, #0x788]
    // 0x4fb750: r0 = AllocateClosure()
    //     0x4fb750: bl              #0x826750  ; AllocateClosureStub
    // 0x4fb754: str             x0, [SP]
    // 0x4fb758: r1 = <Chapter14Stat>
    //     0x4fb758: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb75c: ldr             x1, [x1, #0xf60]
    // 0x4fb760: r2 = Instance_Tuple2
    //     0x4fb760: add             x2, PP, #0x15, lsl #12  ; [pp+0x15790] Obj!Tuple2<Chapter14Stat, CustomNum>@823d71
    //     0x4fb764: ldr             x2, [x2, #0x790]
    // 0x4fb768: r3 = "Adds 50 bonus generators for each navigation generator."
    //     0x4fb768: add             x3, PP, #0x15, lsl #12  ; [pp+0x15798] "Adds 50 bonus generators for each navigation generator."
    //     0x4fb76c: ldr             x3, [x3, #0x798]
    // 0x4fb770: r5 = Instance_IconData
    //     0x4fb770: add             x5, PP, #0x15, lsl #12  ; [pp+0x15720] Obj!IconData@830331
    //     0x4fb774: ldr             x5, [x5, #0x720]
    // 0x4fb778: r6 = "Boosted Navigation"
    //     0x4fb778: add             x6, PP, #0x15, lsl #12  ; [pp+0x157a0] "Boosted Navigation"
    //     0x4fb77c: ldr             x6, [x6, #0x7a0]
    // 0x4fb780: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fb780: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fb784: ldr             x4, [x4, #0xcc0]
    // 0x4fb788: r0 = UpgradeData.single()
    //     0x4fb788: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb78c: ldur            x1, [fp, #-0x18]
    // 0x4fb790: ArrayStore: r1[17] = r0  ; List_4
    //     0x4fb790: add             x25, x1, #0x53
    //     0x4fb794: str             w0, [x25]
    //     0x4fb798: tbz             w0, #0, #0x4fb7b4
    //     0x4fb79c: ldurb           w16, [x1, #-1]
    //     0x4fb7a0: ldurb           w17, [x0, #-1]
    //     0x4fb7a4: and             x16, x17, x16, lsr #2
    //     0x4fb7a8: tst             x16, HEAP, lsr #32
    //     0x4fb7ac: b.eq            #0x4fb7b4
    //     0x4fb7b0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb7b4: ldur            x0, [fp, #-0x18]
    // 0x4fb7b8: r16 = 300
    //     0x4fb7b8: movz            x16, #0x12c
    // 0x4fb7bc: StoreField: r0->field_57 = r16
    //     0x4fb7bc: stur            w16, [x0, #0x57]
    // 0x4fb7c0: ldur            x2, [fp, #-0x10]
    // 0x4fb7c4: r1 = Function '<anonymous closure>':.
    //     0x4fb7c4: add             x1, PP, #0x15, lsl #12  ; [pp+0x157a8] AnonymousClosure: (0x4fbce0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::ensureInitialized (0x4fb030)
    //     0x4fb7c8: ldr             x1, [x1, #0x7a8]
    // 0x4fb7cc: r0 = AllocateClosure()
    //     0x4fb7cc: bl              #0x826750  ; AllocateClosureStub
    // 0x4fb7d0: str             x0, [SP]
    // 0x4fb7d4: r1 = <Chapter14Stat>
    //     0x4fb7d4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb7d8: ldr             x1, [x1, #0xf60]
    // 0x4fb7dc: r2 = Instance_Tuple2
    //     0x4fb7dc: add             x2, PP, #0x15, lsl #12  ; [pp+0x157b0] Obj!Tuple2<Chapter14Stat, CustomNum>@823d51
    //     0x4fb7e0: ldr             x2, [x2, #0x7b0]
    // 0x4fb7e4: r3 = "Adds 50 bonus generators for each I/O generator."
    //     0x4fb7e4: add             x3, PP, #0x15, lsl #12  ; [pp+0x157b8] "Adds 50 bonus generators for each I/O generator."
    //     0x4fb7e8: ldr             x3, [x3, #0x7b8]
    // 0x4fb7ec: r5 = Instance_IconData
    //     0x4fb7ec: add             x5, PP, #0x15, lsl #12  ; [pp+0x157c0] Obj!IconData@8302d1
    //     0x4fb7f0: ldr             x5, [x5, #0x7c0]
    // 0x4fb7f4: r6 = "Boosted I/O"
    //     0x4fb7f4: add             x6, PP, #0x15, lsl #12  ; [pp+0x157c8] "Boosted I/O"
    //     0x4fb7f8: ldr             x6, [x6, #0x7c8]
    // 0x4fb7fc: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fb7fc: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fb800: ldr             x4, [x4, #0xcc0]
    // 0x4fb804: r0 = UpgradeData.single()
    //     0x4fb804: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb808: ldur            x1, [fp, #-0x18]
    // 0x4fb80c: ArrayStore: r1[19] = r0  ; List_4
    //     0x4fb80c: add             x25, x1, #0x5b
    //     0x4fb810: str             w0, [x25]
    //     0x4fb814: tbz             w0, #0, #0x4fb830
    //     0x4fb818: ldurb           w16, [x1, #-1]
    //     0x4fb81c: ldurb           w17, [x0, #-1]
    //     0x4fb820: and             x16, x17, x16, lsr #2
    //     0x4fb824: tst             x16, HEAP, lsr #32
    //     0x4fb828: b.eq            #0x4fb830
    //     0x4fb82c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb830: ldur            x0, [fp, #-0x18]
    // 0x4fb834: r16 = 320
    //     0x4fb834: movz            x16, #0x140
    // 0x4fb838: StoreField: r0->field_5f = r16
    //     0x4fb838: stur            w16, [x0, #0x5f]
    // 0x4fb83c: r1 = <Chapter14Stat>
    //     0x4fb83c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb840: ldr             x1, [x1, #0xf60]
    // 0x4fb844: r2 = Instance_Tuple2
    //     0x4fb844: add             x2, PP, #0x15, lsl #12  ; [pp+0x157d0] Obj!Tuple2<Chapter14Stat, CustomNum>@823d31
    //     0x4fb848: ldr             x2, [x2, #0x7d0]
    // 0x4fb84c: r3 = "10x Throughput on prestige."
    //     0x4fb84c: add             x3, PP, #0x15, lsl #12  ; [pp+0x157d8] "10x Throughput on prestige."
    //     0x4fb850: ldr             x3, [x3, #0x7d8]
    // 0x4fb854: r5 = Instance_IconData
    //     0x4fb854: add             x5, PP, #0x15, lsl #12  ; [pp+0x157e0] Obj!IconData@8302b1
    //     0x4fb858: ldr             x5, [x5, #0x7e0]
    // 0x4fb85c: r6 = "Higher Throughput"
    //     0x4fb85c: add             x6, PP, #0x15, lsl #12  ; [pp+0x157e8] "Higher Throughput"
    //     0x4fb860: ldr             x6, [x6, #0x7e8]
    // 0x4fb864: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb864: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb868: r0 = UpgradeData.single()
    //     0x4fb868: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb86c: ldur            x1, [fp, #-0x18]
    // 0x4fb870: ArrayStore: r1[21] = r0  ; List_4
    //     0x4fb870: add             x25, x1, #0x63
    //     0x4fb874: str             w0, [x25]
    //     0x4fb878: tbz             w0, #0, #0x4fb894
    //     0x4fb87c: ldurb           w16, [x1, #-1]
    //     0x4fb880: ldurb           w17, [x0, #-1]
    //     0x4fb884: and             x16, x17, x16, lsr #2
    //     0x4fb888: tst             x16, HEAP, lsr #32
    //     0x4fb88c: b.eq            #0x4fb894
    //     0x4fb890: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb894: ldur            x0, [fp, #-0x18]
    // 0x4fb898: r16 = 340
    //     0x4fb898: movz            x16, #0x154
    // 0x4fb89c: StoreField: r0->field_67 = r16
    //     0x4fb89c: stur            w16, [x0, #0x67]
    // 0x4fb8a0: r1 = <Chapter14Stat>
    //     0x4fb8a0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb8a4: ldr             x1, [x1, #0xf60]
    // 0x4fb8a8: r2 = Instance_Tuple2
    //     0x4fb8a8: add             x2, PP, #0x15, lsl #12  ; [pp+0x157f0] Obj!Tuple2<Chapter14Stat, CustomNum>@823d11
    //     0x4fb8ac: ldr             x2, [x2, #0x7f0]
    // 0x4fb8b0: r3 = "Reduces all costs by 99.9%."
    //     0x4fb8b0: add             x3, PP, #0x15, lsl #12  ; [pp+0x157f8] "Reduces all costs by 99.9%."
    //     0x4fb8b4: ldr             x3, [x3, #0x7f8]
    // 0x4fb8b8: r5 = Instance_IconData
    //     0x4fb8b8: add             x5, PP, #0x14, lsl #12  ; [pp+0x14858] Obj!IconData@82f5b1
    //     0x4fb8bc: ldr             x5, [x5, #0x858]
    // 0x4fb8c0: r6 = "Faster Running"
    //     0x4fb8c0: add             x6, PP, #0x15, lsl #12  ; [pp+0x15800] "Faster Running"
    //     0x4fb8c4: ldr             x6, [x6, #0x800]
    // 0x4fb8c8: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb8c8: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb8cc: r0 = UpgradeData.single()
    //     0x4fb8cc: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb8d0: ldur            x1, [fp, #-0x18]
    // 0x4fb8d4: ArrayStore: r1[23] = r0  ; List_4
    //     0x4fb8d4: add             x25, x1, #0x6b
    //     0x4fb8d8: str             w0, [x25]
    //     0x4fb8dc: tbz             w0, #0, #0x4fb8f8
    //     0x4fb8e0: ldurb           w16, [x1, #-1]
    //     0x4fb8e4: ldurb           w17, [x0, #-1]
    //     0x4fb8e8: and             x16, x17, x16, lsr #2
    //     0x4fb8ec: tst             x16, HEAP, lsr #32
    //     0x4fb8f0: b.eq            #0x4fb8f8
    //     0x4fb8f4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb8f8: ldur            x0, [fp, #-0x18]
    // 0x4fb8fc: r16 = 360
    //     0x4fb8fc: movz            x16, #0x168
    // 0x4fb900: StoreField: r0->field_6f = r16
    //     0x4fb900: stur            w16, [x0, #0x6f]
    // 0x4fb904: r1 = <Chapter14Stat>
    //     0x4fb904: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb908: ldr             x1, [x1, #0xf60]
    // 0x4fb90c: r2 = Instance_Tuple2
    //     0x4fb90c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15808] Obj!Tuple2<Chapter14Stat, CustomNum>@823cf1
    //     0x4fb910: ldr             x2, [x2, #0x808]
    // 0x4fb914: r3 = "Significantly increases both ops and throughput on prestige."
    //     0x4fb914: add             x3, PP, #0x15, lsl #12  ; [pp+0x15810] "Significantly increases both ops and throughput on prestige."
    //     0x4fb918: ldr             x3, [x3, #0x810]
    // 0x4fb91c: r5 = Instance_IconData
    //     0x4fb91c: add             x5, PP, #0x15, lsl #12  ; [pp+0x15818] Obj!IconData@830291
    //     0x4fb920: ldr             x5, [x5, #0x818]
    // 0x4fb924: r6 = "Tribal Knowledge"
    //     0x4fb924: add             x6, PP, #0x15, lsl #12  ; [pp+0x15820] "Tribal Knowledge"
    //     0x4fb928: ldr             x6, [x6, #0x820]
    // 0x4fb92c: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb92c: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb930: r0 = UpgradeData.single()
    //     0x4fb930: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb934: ldur            x1, [fp, #-0x18]
    // 0x4fb938: ArrayStore: r1[25] = r0  ; List_4
    //     0x4fb938: add             x25, x1, #0x73
    //     0x4fb93c: str             w0, [x25]
    //     0x4fb940: tbz             w0, #0, #0x4fb95c
    //     0x4fb944: ldurb           w16, [x1, #-1]
    //     0x4fb948: ldurb           w17, [x0, #-1]
    //     0x4fb94c: and             x16, x17, x16, lsr #2
    //     0x4fb950: tst             x16, HEAP, lsr #32
    //     0x4fb954: b.eq            #0x4fb95c
    //     0x4fb958: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb95c: ldur            x0, [fp, #-0x18]
    // 0x4fb960: r16 = 380
    //     0x4fb960: movz            x16, #0x17c
    // 0x4fb964: StoreField: r0->field_77 = r16
    //     0x4fb964: stur            w16, [x0, #0x77]
    // 0x4fb968: r1 = <Chapter14Stat>
    //     0x4fb968: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb96c: ldr             x1, [x1, #0xf60]
    // 0x4fb970: r2 = Instance_Tuple2
    //     0x4fb970: add             x2, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!Tuple2<Chapter14Stat, CustomNum>@823cd1
    //     0x4fb974: ldr             x2, [x2, #0x828]
    // 0x4fb978: r3 = "Reduces the cost of all upgrades by 99.9%."
    //     0x4fb978: add             x3, PP, #0x15, lsl #12  ; [pp+0x15830] "Reduces the cost of all upgrades by 99.9%."
    //     0x4fb97c: ldr             x3, [x3, #0x830]
    // 0x4fb980: r5 = Instance_IconData
    //     0x4fb980: add             x5, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!IconData@830271
    //     0x4fb984: ldr             x5, [x5, #0x838]
    // 0x4fb988: r6 = "Cost Reducer"
    //     0x4fb988: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] "Cost Reducer"
    //     0x4fb98c: ldr             x6, [x6, #0x840]
    // 0x4fb990: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb990: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb994: r0 = UpgradeData.single()
    //     0x4fb994: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb998: ldur            x1, [fp, #-0x18]
    // 0x4fb99c: ArrayStore: r1[27] = r0  ; List_4
    //     0x4fb99c: add             x25, x1, #0x7b
    //     0x4fb9a0: str             w0, [x25]
    //     0x4fb9a4: tbz             w0, #0, #0x4fb9c0
    //     0x4fb9a8: ldurb           w16, [x1, #-1]
    //     0x4fb9ac: ldurb           w17, [x0, #-1]
    //     0x4fb9b0: and             x16, x17, x16, lsr #2
    //     0x4fb9b4: tst             x16, HEAP, lsr #32
    //     0x4fb9b8: b.eq            #0x4fb9c0
    //     0x4fb9bc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fb9c0: ldur            x0, [fp, #-0x18]
    // 0x4fb9c4: r16 = 400
    //     0x4fb9c4: movz            x16, #0x190
    // 0x4fb9c8: StoreField: r0->field_7f = r16
    //     0x4fb9c8: stur            w16, [x0, #0x7f]
    // 0x4fb9cc: r1 = <Chapter14Stat>
    //     0x4fb9cc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fb9d0: ldr             x1, [x1, #0xf60]
    // 0x4fb9d4: r2 = Instance_Tuple2
    //     0x4fb9d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15848] Obj!Tuple2<Chapter14Stat, CustomNum>@823cb1
    //     0x4fb9d8: ldr             x2, [x2, #0x848]
    // 0x4fb9dc: r3 = "Increases each of the navigation and I/O generator yields by a small amount for each owned generator."
    //     0x4fb9dc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15850] "Increases each of the navigation and I/O generator yields by a small amount for each owned generator."
    //     0x4fb9e0: ldr             x3, [x3, #0x850]
    // 0x4fb9e4: r5 = Instance_IconData
    //     0x4fb9e4: add             x5, PP, #0x14, lsl #12  ; [pp+0x14ce8] Obj!IconData@82fa51
    //     0x4fb9e8: ldr             x5, [x5, #0xce8]
    // 0x4fb9ec: r6 = "Base Boost"
    //     0x4fb9ec: add             x6, PP, #0x15, lsl #12  ; [pp+0x15858] "Base Boost"
    //     0x4fb9f0: ldr             x6, [x6, #0x858]
    // 0x4fb9f4: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fb9f4: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fb9f8: r0 = UpgradeData.single()
    //     0x4fb9f8: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fb9fc: ldur            x1, [fp, #-0x18]
    // 0x4fba00: ArrayStore: r1[29] = r0  ; List_4
    //     0x4fba00: add             x25, x1, #0x83
    //     0x4fba04: str             w0, [x25]
    //     0x4fba08: tbz             w0, #0, #0x4fba24
    //     0x4fba0c: ldurb           w16, [x1, #-1]
    //     0x4fba10: ldurb           w17, [x0, #-1]
    //     0x4fba14: and             x16, x17, x16, lsr #2
    //     0x4fba18: tst             x16, HEAP, lsr #32
    //     0x4fba1c: b.eq            #0x4fba24
    //     0x4fba20: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fba24: ldur            x0, [fp, #-0x18]
    // 0x4fba28: r16 = 420
    //     0x4fba28: movz            x16, #0x1a4
    // 0x4fba2c: StoreField: r0->field_87 = r16
    //     0x4fba2c: stur            w16, [x0, #0x87]
    // 0x4fba30: r1 = <Chapter14Stat>
    //     0x4fba30: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fba34: ldr             x1, [x1, #0xf60]
    // 0x4fba38: r2 = Instance_Tuple2
    //     0x4fba38: add             x2, PP, #0x15, lsl #12  ; [pp+0x15860] Obj!Tuple2<Chapter14Stat, CustomNum>@823c91
    //     0x4fba3c: ldr             x2, [x2, #0x860]
    // 0x4fba40: r3 = "Grants a small boost of all prestige stats without prestiging per second."
    //     0x4fba40: add             x3, PP, #0x15, lsl #12  ; [pp+0x15868] "Grants a small boost of all prestige stats without prestiging per second."
    //     0x4fba44: ldr             x3, [x3, #0x868]
    // 0x4fba48: r5 = Instance_IconData
    //     0x4fba48: add             x5, PP, #0x15, lsl #12  ; [pp+0x15870] Obj!IconData@830251
    //     0x4fba4c: ldr             x5, [x5, #0x870]
    // 0x4fba50: r6 = "Speed Up"
    //     0x4fba50: add             x6, PP, #0x15, lsl #12  ; [pp+0x156e8] "Speed Up"
    //     0x4fba54: ldr             x6, [x6, #0x6e8]
    // 0x4fba58: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fba58: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fba5c: r0 = UpgradeData.single()
    //     0x4fba5c: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fba60: ldur            x1, [fp, #-0x18]
    // 0x4fba64: ArrayStore: r1[31] = r0  ; List_4
    //     0x4fba64: add             x25, x1, #0x8b
    //     0x4fba68: str             w0, [x25]
    //     0x4fba6c: tbz             w0, #0, #0x4fba88
    //     0x4fba70: ldurb           w16, [x1, #-1]
    //     0x4fba74: ldurb           w17, [x0, #-1]
    //     0x4fba78: and             x16, x17, x16, lsr #2
    //     0x4fba7c: tst             x16, HEAP, lsr #32
    //     0x4fba80: b.eq            #0x4fba88
    //     0x4fba84: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fba88: ldur            x0, [fp, #-0x18]
    // 0x4fba8c: r16 = 2000
    //     0x4fba8c: movz            x16, #0x7d0
    // 0x4fba90: StoreField: r0->field_8f = r16
    //     0x4fba90: stur            w16, [x0, #0x8f]
    // 0x4fba94: r1 = <Chapter14Stat>
    //     0x4fba94: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fba98: ldr             x1, [x1, #0xf60]
    // 0x4fba9c: r2 = Instance_Tuple2
    //     0x4fba9c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15878] Obj!Tuple2<Chapter14Stat, CustomNum>@823c71
    //     0x4fbaa0: ldr             x2, [x2, #0x878]
    // 0x4fbaa4: r3 = "Unlocks navigation and I/O generator generators."
    //     0x4fbaa4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15880] "Unlocks navigation and I/O generator generators."
    //     0x4fbaa8: ldr             x3, [x3, #0x880]
    // 0x4fbaac: r5 = Instance_IconData
    //     0x4fbaac: add             x5, PP, #0x13, lsl #12  ; [pp+0x13f68] Obj!IconData@82fbb1
    //     0x4fbab0: ldr             x5, [x5, #0xf68]
    // 0x4fbab4: r6 = "Auto Automation"
    //     0x4fbab4: add             x6, PP, #0x15, lsl #12  ; [pp+0x15888] "Auto Automation"
    //     0x4fbab8: ldr             x6, [x6, #0x888]
    // 0x4fbabc: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fbabc: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fbac0: r0 = UpgradeData.single()
    //     0x4fbac0: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fbac4: ldur            x1, [fp, #-0x18]
    // 0x4fbac8: ArrayStore: r1[33] = r0  ; List_4
    //     0x4fbac8: add             x25, x1, #0x93
    //     0x4fbacc: str             w0, [x25]
    //     0x4fbad0: tbz             w0, #0, #0x4fbaec
    //     0x4fbad4: ldurb           w16, [x1, #-1]
    //     0x4fbad8: ldurb           w17, [x0, #-1]
    //     0x4fbadc: and             x16, x17, x16, lsr #2
    //     0x4fbae0: tst             x16, HEAP, lsr #32
    //     0x4fbae4: b.eq            #0x4fbaec
    //     0x4fbae8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fbaec: ldur            x0, [fp, #-0x18]
    // 0x4fbaf0: r16 = 2020
    //     0x4fbaf0: movz            x16, #0x7e4
    // 0x4fbaf4: StoreField: r0->field_97 = r16
    //     0x4fbaf4: stur            w16, [x0, #0x97]
    // 0x4fbaf8: r1 = <Chapter14Stat>
    //     0x4fbaf8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fbafc: ldr             x1, [x1, #0xf60]
    // 0x4fbb00: r2 = Instance_Tuple2
    //     0x4fbb00: add             x2, PP, #0x15, lsl #12  ; [pp+0x15890] Obj!Tuple2<Chapter14Stat, CustomNum>@823c51
    //     0x4fbb04: ldr             x2, [x2, #0x890]
    // 0x4fbb08: r3 = "No longer reset upgrades on prestige."
    //     0x4fbb08: add             x3, PP, #0x15, lsl #12  ; [pp+0x15898] "No longer reset upgrades on prestige."
    //     0x4fbb0c: ldr             x3, [x3, #0x898]
    // 0x4fbb10: r5 = Instance_IconData
    //     0x4fbb10: add             x5, PP, #0x15, lsl #12  ; [pp+0x158a0] Obj!IconData@830231
    //     0x4fbb14: ldr             x5, [x5, #0x8a0]
    // 0x4fbb18: r6 = "Persistence"
    //     0x4fbb18: add             x6, PP, #0x15, lsl #12  ; [pp+0x158a8] "Persistence"
    //     0x4fbb1c: ldr             x6, [x6, #0x8a8]
    // 0x4fbb20: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fbb20: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fbb24: r0 = UpgradeData.single()
    //     0x4fbb24: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fbb28: ldur            x1, [fp, #-0x18]
    // 0x4fbb2c: ArrayStore: r1[35] = r0  ; List_4
    //     0x4fbb2c: add             x25, x1, #0x9b
    //     0x4fbb30: str             w0, [x25]
    //     0x4fbb34: tbz             w0, #0, #0x4fbb50
    //     0x4fbb38: ldurb           w16, [x1, #-1]
    //     0x4fbb3c: ldurb           w17, [x0, #-1]
    //     0x4fbb40: and             x16, x17, x16, lsr #2
    //     0x4fbb44: tst             x16, HEAP, lsr #32
    //     0x4fbb48: b.eq            #0x4fbb50
    //     0x4fbb4c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fbb50: ldur            x0, [fp, #-0x18]
    // 0x4fbb54: r16 = 2040
    //     0x4fbb54: movz            x16, #0x7f8
    // 0x4fbb58: StoreField: r0->field_9f = r16
    //     0x4fbb58: stur            w16, [x0, #0x9f]
    // 0x4fbb5c: r1 = <Chapter14Stat>
    //     0x4fbb5c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fbb60: ldr             x1, [x1, #0xf60]
    // 0x4fbb64: r2 = Instance_Tuple2
    //     0x4fbb64: add             x2, PP, #0x15, lsl #12  ; [pp+0x158b0] Obj!Tuple2<Chapter14Stat, CustomNum>@823c31
    //     0x4fbb68: ldr             x2, [x2, #0x8b0]
    // 0x4fbb6c: r3 = "No longer reset quests on prestige."
    //     0x4fbb6c: add             x3, PP, #0x15, lsl #12  ; [pp+0x158b8] "No longer reset quests on prestige."
    //     0x4fbb70: ldr             x3, [x3, #0x8b8]
    // 0x4fbb74: r5 = Instance_IconData
    //     0x4fbb74: add             x5, PP, #0x14, lsl #12  ; [pp+0x14e70] Obj!IconData@82f931
    //     0x4fbb78: ldr             x5, [x5, #0xe70]
    // 0x4fbb7c: r6 = "Quest Persistence"
    //     0x4fbb7c: add             x6, PP, #0x15, lsl #12  ; [pp+0x158c0] "Quest Persistence"
    //     0x4fbb80: ldr             x6, [x6, #0x8c0]
    // 0x4fbb84: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fbb84: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fbb88: r0 = UpgradeData.single()
    //     0x4fbb88: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fbb8c: ldur            x1, [fp, #-0x18]
    // 0x4fbb90: ArrayStore: r1[37] = r0  ; List_4
    //     0x4fbb90: add             x25, x1, #0xa3
    //     0x4fbb94: str             w0, [x25]
    //     0x4fbb98: tbz             w0, #0, #0x4fbbb4
    //     0x4fbb9c: ldurb           w16, [x1, #-1]
    //     0x4fbba0: ldurb           w17, [x0, #-1]
    //     0x4fbba4: and             x16, x17, x16, lsr #2
    //     0x4fbba8: tst             x16, HEAP, lsr #32
    //     0x4fbbac: b.eq            #0x4fbbb4
    //     0x4fbbb0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fbbb4: ldur            x0, [fp, #-0x18]
    // 0x4fbbb8: r16 = 2060
    //     0x4fbbb8: movz            x16, #0x80c
    // 0x4fbbbc: StoreField: r0->field_a7 = r16
    //     0x4fbbbc: stur            w16, [x0, #0xa7]
    // 0x4fbbc0: r1 = <Chapter14Stat>
    //     0x4fbbc0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4fbbc4: ldr             x1, [x1, #0xf60]
    // 0x4fbbc8: r2 = Instance_Tuple2
    //     0x4fbbc8: add             x2, PP, #0x15, lsl #12  ; [pp+0x158c8] Obj!Tuple2<Chapter14Stat, CustomNum>@823c11
    //     0x4fbbcc: ldr             x2, [x2, #0x8c8]
    // 0x4fbbd0: r3 = "Unlocks the final tier of generator."
    //     0x4fbbd0: add             x3, PP, #0x15, lsl #12  ; [pp+0x158d0] "Unlocks the final tier of generator."
    //     0x4fbbd4: ldr             x3, [x3, #0x8d0]
    // 0x4fbbd8: r5 = Instance_IconData
    //     0x4fbbd8: add             x5, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!IconData@830211
    //     0x4fbbdc: ldr             x5, [x5, #0x8d8]
    // 0x4fbbe0: r6 = "Scripting"
    //     0x4fbbe0: add             x6, PP, #0x11, lsl #12  ; [pp+0x117a8] "Scripting"
    //     0x4fbbe4: ldr             x6, [x6, #0x7a8]
    // 0x4fbbe8: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fbbe8: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fbbec: r0 = UpgradeData.single()
    //     0x4fbbec: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fbbf0: ldur            x1, [fp, #-0x18]
    // 0x4fbbf4: ArrayStore: r1[39] = r0  ; List_4
    //     0x4fbbf4: add             x25, x1, #0xab
    //     0x4fbbf8: str             w0, [x25]
    //     0x4fbbfc: tbz             w0, #0, #0x4fbc18
    //     0x4fbc00: ldurb           w16, [x1, #-1]
    //     0x4fbc04: ldurb           w17, [x0, #-1]
    //     0x4fbc08: and             x16, x17, x16, lsr #2
    //     0x4fbc0c: tst             x16, HEAP, lsr #32
    //     0x4fbc10: b.eq            #0x4fbc18
    //     0x4fbc14: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fbc18: r16 = <int, UpgradeData<Chapter14Stat>>
    //     0x4fbc18: add             x16, PP, #0x15, lsl #12  ; [pp+0x158e0] TypeArguments: <int, UpgradeData<Chapter14Stat>>
    //     0x4fbc1c: ldr             x16, [x16, #0x8e0]
    // 0x4fbc20: ldur            lr, [fp, #-0x18]
    // 0x4fbc24: stp             lr, x16, [SP]
    // 0x4fbc28: r0 = Map._fromLiteral()
    //     0x4fbc28: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fbc2c: ldur            x1, [fp, #-8]
    // 0x4fbc30: StoreField: r1->field_8f = r0
    //     0x4fbc30: stur            w0, [x1, #0x8f]
    //     0x4fbc34: ldurb           w16, [x1, #-1]
    //     0x4fbc38: ldurb           w17, [x0, #-1]
    //     0x4fbc3c: and             x16, x17, x16, lsr #2
    //     0x4fbc40: tst             x16, HEAP, lsr #32
    //     0x4fbc44: b.eq            #0x4fbc4c
    //     0x4fbc48: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4fbc4c: r0 = Null
    //     0x4fbc4c: mov             x0, NULL
    // 0x4fbc50: LeaveFrame
    //     0x4fbc50: mov             SP, fp
    //     0x4fbc54: ldp             fp, lr, [SP], #0x10
    // 0x4fbc58: ret
    //     0x4fbc58: ret             
    // 0x4fbc5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fbc5c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fbc60: b               #0x4fb04c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4fbce0, size: 0x11c
    // 0x4fbce0: EnterFrame
    //     0x4fbce0: stp             fp, lr, [SP, #-0x10]!
    //     0x4fbce4: mov             fp, SP
    // 0x4fbce8: AllocStack(0x10)
    //     0x4fbce8: sub             SP, SP, #0x10
    // 0x4fbcec: SetupParameters([dynamic _ /* r0 */])
    //     0x4fbcec: ldr             x0, [fp, #0x10]
    //     0x4fbcf0: ldur            w3, [x0, #0x17]
    //     0x4fbcf4: add             x3, x3, HEAP, lsl #32
    //     0x4fbcf8: stur            x3, [fp, #-0x10]
    // 0x4fbcfc: CheckStackOverflow
    //     0x4fbcfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fbd00: cmp             SP, x16
    //     0x4fbd04: b.ls            #0x4fbdf4
    // 0x4fbd08: LoadField: r0 = r3->field_f
    //     0x4fbd08: ldur            w0, [x3, #0xf]
    // 0x4fbd0c: DecompressPointer r0
    //     0x4fbd0c: add             x0, x0, HEAP, lsl #32
    // 0x4fbd10: LoadField: r4 = r0->field_37
    //     0x4fbd10: ldur            w4, [x0, #0x37]
    // 0x4fbd14: DecompressPointer r4
    //     0x4fbd14: add             x4, x4, HEAP, lsl #32
    // 0x4fbd18: stur            x4, [fp, #-8]
    // 0x4fbd1c: r1 = Null
    //     0x4fbd1c: mov             x1, NULL
    // 0x4fbd20: r2 = 100
    //     0x4fbd20: movz            x2, #0x64
    // 0x4fbd24: r0 = CustomNum()
    //     0x4fbd24: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbd28: ldur            x1, [fp, #-8]
    // 0x4fbd2c: mov             x3, x0
    // 0x4fbd30: r2 = Instance_Chapter14Stat
    //     0x4fbd30: add             x2, PP, #0x11, lsl #12  ; [pp+0x11158] Obj!Chapter14Stat@85f961
    //     0x4fbd34: ldr             x2, [x2, #0x158]
    // 0x4fbd38: r0 = []=()
    //     0x4fbd38: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbd3c: ldur            x0, [fp, #-0x10]
    // 0x4fbd40: LoadField: r1 = r0->field_f
    //     0x4fbd40: ldur            w1, [x0, #0xf]
    // 0x4fbd44: DecompressPointer r1
    //     0x4fbd44: add             x1, x1, HEAP, lsl #32
    // 0x4fbd48: LoadField: r3 = r1->field_37
    //     0x4fbd48: ldur            w3, [x1, #0x37]
    // 0x4fbd4c: DecompressPointer r3
    //     0x4fbd4c: add             x3, x3, HEAP, lsl #32
    // 0x4fbd50: stur            x3, [fp, #-8]
    // 0x4fbd54: r1 = Null
    //     0x4fbd54: mov             x1, NULL
    // 0x4fbd58: r2 = 100
    //     0x4fbd58: movz            x2, #0x64
    // 0x4fbd5c: r0 = CustomNum()
    //     0x4fbd5c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbd60: ldur            x1, [fp, #-8]
    // 0x4fbd64: mov             x3, x0
    // 0x4fbd68: r2 = Instance_Chapter14Stat
    //     0x4fbd68: add             x2, PP, #0x11, lsl #12  ; [pp+0x11160] Obj!Chapter14Stat@85f941
    //     0x4fbd6c: ldr             x2, [x2, #0x160]
    // 0x4fbd70: r0 = []=()
    //     0x4fbd70: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbd74: ldur            x0, [fp, #-0x10]
    // 0x4fbd78: LoadField: r1 = r0->field_f
    //     0x4fbd78: ldur            w1, [x0, #0xf]
    // 0x4fbd7c: DecompressPointer r1
    //     0x4fbd7c: add             x1, x1, HEAP, lsl #32
    // 0x4fbd80: LoadField: r3 = r1->field_37
    //     0x4fbd80: ldur            w3, [x1, #0x37]
    // 0x4fbd84: DecompressPointer r3
    //     0x4fbd84: add             x3, x3, HEAP, lsl #32
    // 0x4fbd88: stur            x3, [fp, #-8]
    // 0x4fbd8c: r1 = Null
    //     0x4fbd8c: mov             x1, NULL
    // 0x4fbd90: r2 = 100
    //     0x4fbd90: movz            x2, #0x64
    // 0x4fbd94: r0 = CustomNum()
    //     0x4fbd94: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbd98: ldur            x1, [fp, #-8]
    // 0x4fbd9c: mov             x3, x0
    // 0x4fbda0: r2 = Instance_Chapter14Stat
    //     0x4fbda0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11168] Obj!Chapter14Stat@85f921
    //     0x4fbda4: ldr             x2, [x2, #0x168]
    // 0x4fbda8: r0 = []=()
    //     0x4fbda8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbdac: ldur            x0, [fp, #-0x10]
    // 0x4fbdb0: LoadField: r1 = r0->field_f
    //     0x4fbdb0: ldur            w1, [x0, #0xf]
    // 0x4fbdb4: DecompressPointer r1
    //     0x4fbdb4: add             x1, x1, HEAP, lsl #32
    // 0x4fbdb8: LoadField: r0 = r1->field_37
    //     0x4fbdb8: ldur            w0, [x1, #0x37]
    // 0x4fbdbc: DecompressPointer r0
    //     0x4fbdbc: add             x0, x0, HEAP, lsl #32
    // 0x4fbdc0: stur            x0, [fp, #-8]
    // 0x4fbdc4: r1 = Null
    //     0x4fbdc4: mov             x1, NULL
    // 0x4fbdc8: r2 = 100
    //     0x4fbdc8: movz            x2, #0x64
    // 0x4fbdcc: r0 = CustomNum()
    //     0x4fbdcc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbdd0: ldur            x1, [fp, #-8]
    // 0x4fbdd4: mov             x3, x0
    // 0x4fbdd8: r2 = Instance_Chapter14Stat
    //     0x4fbdd8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11170] Obj!Chapter14Stat@85f901
    //     0x4fbddc: ldr             x2, [x2, #0x170]
    // 0x4fbde0: r0 = []=()
    //     0x4fbde0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbde4: r0 = Null
    //     0x4fbde4: mov             x0, NULL
    // 0x4fbde8: LeaveFrame
    //     0x4fbde8: mov             SP, fp
    //     0x4fbdec: ldp             fp, lr, [SP], #0x10
    // 0x4fbdf0: ret
    //     0x4fbdf0: ret             
    // 0x4fbdf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fbdf4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fbdf8: b               #0x4fbd08
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4fbdfc, size: 0xe4
    // 0x4fbdfc: EnterFrame
    //     0x4fbdfc: stp             fp, lr, [SP, #-0x10]!
    //     0x4fbe00: mov             fp, SP
    // 0x4fbe04: AllocStack(0x10)
    //     0x4fbe04: sub             SP, SP, #0x10
    // 0x4fbe08: SetupParameters([dynamic _ /* r0 */])
    //     0x4fbe08: ldr             x0, [fp, #0x10]
    //     0x4fbe0c: ldur            w3, [x0, #0x17]
    //     0x4fbe10: add             x3, x3, HEAP, lsl #32
    //     0x4fbe14: stur            x3, [fp, #-0x10]
    // 0x4fbe18: CheckStackOverflow
    //     0x4fbe18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fbe1c: cmp             SP, x16
    //     0x4fbe20: b.ls            #0x4fbed8
    // 0x4fbe24: LoadField: r0 = r3->field_f
    //     0x4fbe24: ldur            w0, [x3, #0xf]
    // 0x4fbe28: DecompressPointer r0
    //     0x4fbe28: add             x0, x0, HEAP, lsl #32
    // 0x4fbe2c: LoadField: r4 = r0->field_37
    //     0x4fbe2c: ldur            w4, [x0, #0x37]
    // 0x4fbe30: DecompressPointer r4
    //     0x4fbe30: add             x4, x4, HEAP, lsl #32
    // 0x4fbe34: stur            x4, [fp, #-8]
    // 0x4fbe38: r1 = Null
    //     0x4fbe38: mov             x1, NULL
    // 0x4fbe3c: r2 = 100
    //     0x4fbe3c: movz            x2, #0x64
    // 0x4fbe40: r0 = CustomNum()
    //     0x4fbe40: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbe44: ldur            x1, [fp, #-8]
    // 0x4fbe48: mov             x3, x0
    // 0x4fbe4c: r2 = Instance_Chapter14Stat
    //     0x4fbe4c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11140] Obj!Chapter14Stat@85f9c1
    //     0x4fbe50: ldr             x2, [x2, #0x140]
    // 0x4fbe54: r0 = []=()
    //     0x4fbe54: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbe58: ldur            x0, [fp, #-0x10]
    // 0x4fbe5c: LoadField: r1 = r0->field_f
    //     0x4fbe5c: ldur            w1, [x0, #0xf]
    // 0x4fbe60: DecompressPointer r1
    //     0x4fbe60: add             x1, x1, HEAP, lsl #32
    // 0x4fbe64: LoadField: r3 = r1->field_37
    //     0x4fbe64: ldur            w3, [x1, #0x37]
    // 0x4fbe68: DecompressPointer r3
    //     0x4fbe68: add             x3, x3, HEAP, lsl #32
    // 0x4fbe6c: stur            x3, [fp, #-8]
    // 0x4fbe70: r1 = Null
    //     0x4fbe70: mov             x1, NULL
    // 0x4fbe74: r2 = 100
    //     0x4fbe74: movz            x2, #0x64
    // 0x4fbe78: r0 = CustomNum()
    //     0x4fbe78: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbe7c: ldur            x1, [fp, #-8]
    // 0x4fbe80: mov             x3, x0
    // 0x4fbe84: r2 = Instance_Chapter14Stat
    //     0x4fbe84: add             x2, PP, #0x11, lsl #12  ; [pp+0x11148] Obj!Chapter14Stat@85f9a1
    //     0x4fbe88: ldr             x2, [x2, #0x148]
    // 0x4fbe8c: r0 = []=()
    //     0x4fbe8c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbe90: ldur            x0, [fp, #-0x10]
    // 0x4fbe94: LoadField: r1 = r0->field_f
    //     0x4fbe94: ldur            w1, [x0, #0xf]
    // 0x4fbe98: DecompressPointer r1
    //     0x4fbe98: add             x1, x1, HEAP, lsl #32
    // 0x4fbe9c: LoadField: r0 = r1->field_37
    //     0x4fbe9c: ldur            w0, [x1, #0x37]
    // 0x4fbea0: DecompressPointer r0
    //     0x4fbea0: add             x0, x0, HEAP, lsl #32
    // 0x4fbea4: stur            x0, [fp, #-8]
    // 0x4fbea8: r1 = Null
    //     0x4fbea8: mov             x1, NULL
    // 0x4fbeac: r2 = 100
    //     0x4fbeac: movz            x2, #0x64
    // 0x4fbeb0: r0 = CustomNum()
    //     0x4fbeb0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4fbeb4: ldur            x1, [fp, #-8]
    // 0x4fbeb8: mov             x3, x0
    // 0x4fbebc: r2 = Instance_Chapter14Stat
    //     0x4fbebc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11150] Obj!Chapter14Stat@85f981
    //     0x4fbec0: ldr             x2, [x2, #0x150]
    // 0x4fbec4: r0 = []=()
    //     0x4fbec4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbec8: r0 = Null
    //     0x4fbec8: mov             x0, NULL
    // 0x4fbecc: LeaveFrame
    //     0x4fbecc: mov             SP, fp
    //     0x4fbed0: ldp             fp, lr, [SP], #0x10
    // 0x4fbed4: ret
    //     0x4fbed4: ret             
    // 0x4fbed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fbed8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fbedc: b               #0x4fbe24
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4fbee0, size: 0xa0
    // 0x4fbee0: EnterFrame
    //     0x4fbee0: stp             fp, lr, [SP, #-0x10]!
    //     0x4fbee4: mov             fp, SP
    // 0x4fbee8: AllocStack(0x8)
    //     0x4fbee8: sub             SP, SP, #8
    // 0x4fbeec: SetupParameters([dynamic _ /* r0 */])
    //     0x4fbeec: ldr             x0, [fp, #0x10]
    //     0x4fbef0: ldur            w4, [x0, #0x17]
    //     0x4fbef4: add             x4, x4, HEAP, lsl #32
    //     0x4fbef8: stur            x4, [fp, #-8]
    // 0x4fbefc: CheckStackOverflow
    //     0x4fbefc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fbf00: cmp             SP, x16
    //     0x4fbf04: b.ls            #0x4fbf78
    // 0x4fbf08: LoadField: r0 = r4->field_f
    //     0x4fbf08: ldur            w0, [x4, #0xf]
    // 0x4fbf0c: DecompressPointer r0
    //     0x4fbf0c: add             x0, x0, HEAP, lsl #32
    // 0x4fbf10: LoadField: r1 = r0->field_43
    //     0x4fbf10: ldur            w1, [x0, #0x43]
    // 0x4fbf14: DecompressPointer r1
    //     0x4fbf14: add             x1, x1, HEAP, lsl #32
    // 0x4fbf18: r2 = 20
    //     0x4fbf18: movz            x2, #0x14
    // 0x4fbf1c: r3 = 2
    //     0x4fbf1c: movz            x3, #0x2
    // 0x4fbf20: r0 = []=()
    //     0x4fbf20: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbf24: ldur            x0, [fp, #-8]
    // 0x4fbf28: LoadField: r1 = r0->field_f
    //     0x4fbf28: ldur            w1, [x0, #0xf]
    // 0x4fbf2c: DecompressPointer r1
    //     0x4fbf2c: add             x1, x1, HEAP, lsl #32
    // 0x4fbf30: LoadField: r2 = r1->field_43
    //     0x4fbf30: ldur            w2, [x1, #0x43]
    // 0x4fbf34: DecompressPointer r2
    //     0x4fbf34: add             x2, x2, HEAP, lsl #32
    // 0x4fbf38: mov             x1, x2
    // 0x4fbf3c: r2 = 40
    //     0x4fbf3c: movz            x2, #0x28
    // 0x4fbf40: r3 = 4
    //     0x4fbf40: movz            x3, #0x4
    // 0x4fbf44: r0 = []=()
    //     0x4fbf44: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4fbf48: ldur            x0, [fp, #-8]
    // 0x4fbf4c: LoadField: r1 = r0->field_f
    //     0x4fbf4c: ldur            w1, [x0, #0xf]
    // 0x4fbf50: DecompressPointer r1
    //     0x4fbf50: add             x1, x1, HEAP, lsl #32
    // 0x4fbf54: LoadField: r0 = r1->field_53
    //     0x4fbf54: ldur            w0, [x1, #0x53]
    // 0x4fbf58: DecompressPointer r0
    //     0x4fbf58: add             x0, x0, HEAP, lsl #32
    // 0x4fbf5c: mov             x1, x0
    // 0x4fbf60: r2 = 0
    //     0x4fbf60: movz            x2, #0
    // 0x4fbf64: r0 = add()
    //     0x4fbf64: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4fbf68: r0 = Null
    //     0x4fbf68: mov             x0, NULL
    // 0x4fbf6c: LeaveFrame
    //     0x4fbf6c: mov             SP, fp
    //     0x4fbf70: ldp             fp, lr, [SP], #0x10
    // 0x4fbf74: ret
    //     0x4fbf74: ret             
    // 0x4fbf78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fbf78: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fbf7c: b               #0x4fbf08
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x4fbf80, size: 0x50
    // 0x4fbf80: EnterFrame
    //     0x4fbf80: stp             fp, lr, [SP, #-0x10]!
    //     0x4fbf84: mov             fp, SP
    // 0x4fbf88: ldr             x0, [fp, #0x18]
    // 0x4fbf8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x4fbf8c: ldur            w1, [x0, #0x17]
    // 0x4fbf90: DecompressPointer r1
    //     0x4fbf90: add             x1, x1, HEAP, lsl #32
    // 0x4fbf94: CheckStackOverflow
    //     0x4fbf94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fbf98: cmp             SP, x16
    //     0x4fbf9c: b.ls            #0x4fbfc8
    // 0x4fbfa0: LoadField: r0 = r1->field_f
    //     0x4fbfa0: ldur            w0, [x1, #0xf]
    // 0x4fbfa4: DecompressPointer r0
    //     0x4fbfa4: add             x0, x0, HEAP, lsl #32
    // 0x4fbfa8: LoadField: r1 = r0->field_53
    //     0x4fbfa8: ldur            w1, [x0, #0x53]
    // 0x4fbfac: DecompressPointer r1
    //     0x4fbfac: add             x1, x1, HEAP, lsl #32
    // 0x4fbfb0: r2 = 0
    //     0x4fbfb0: movz            x2, #0
    // 0x4fbfb4: r0 = add()
    //     0x4fbfb4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4fbfb8: r0 = Null
    //     0x4fbfb8: mov             x0, NULL
    // 0x4fbfbc: LeaveFrame
    //     0x4fbfbc: mov             SP, fp
    //     0x4fbfc0: ldp             fp, lr, [SP], #0x10
    // 0x4fbfc4: ret
    //     0x4fbfc4: ret             
    // 0x4fbfc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fbfc8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fbfcc: b               #0x4fbfa0
  }
  _ getNonGeneratorStatsPerSecond(/* No info */) {
    // ** addr: 0x54e65c, size: 0x178
    // 0x54e65c: EnterFrame
    //     0x54e65c: stp             fp, lr, [SP, #-0x10]!
    //     0x54e660: mov             fp, SP
    // 0x54e664: AllocStack(0x20)
    //     0x54e664: sub             SP, SP, #0x20
    // 0x54e668: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */)
    //     0x54e668: mov             x0, x1
    //     0x54e66c: stur            x1, [fp, #-8]
    // 0x54e670: CheckStackOverflow
    //     0x54e670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e674: cmp             SP, x16
    //     0x54e678: b.ls            #0x54e7cc
    // 0x54e67c: LoadField: r1 = r0->field_43
    //     0x54e67c: ldur            w1, [x0, #0x43]
    // 0x54e680: DecompressPointer r1
    //     0x54e680: add             x1, x1, HEAP, lsl #32
    // 0x54e684: r2 = 420
    //     0x54e684: movz            x2, #0x1a4
    // 0x54e688: r0 = containsKey()
    //     0x54e688: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54e68c: tbnz            w0, #4, #0x54e7ac
    // 0x54e690: r1 = Null
    //     0x54e690: mov             x1, NULL
    // 0x54e694: r2 = 12
    //     0x54e694: movz            x2, #0xc
    // 0x54e698: r0 = AllocateArray()
    //     0x54e698: bl              #0x82746c  ; AllocateArrayStub
    // 0x54e69c: stur            x0, [fp, #-0x10]
    // 0x54e6a0: r16 = Instance_Chapter14Stat
    //     0x54e6a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x54e6a4: ldr             x16, [x16, #0x1c8]
    // 0x54e6a8: StoreField: r0->field_f = r16
    //     0x54e6a8: stur            w16, [x0, #0xf]
    // 0x54e6ac: ldur            x1, [fp, #-8]
    // 0x54e6b0: r0 = getRewriteInRustPoints()
    //     0x54e6b0: bl              #0x54e9cc  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getRewriteInRustPoints
    // 0x54e6b4: mov             x2, x0
    // 0x54e6b8: r1 = Instance_CustomNum
    //     0x54e6b8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a680] Obj!CustomNum@82b3f1
    //     0x54e6bc: ldr             x1, [x1, #0x680]
    // 0x54e6c0: r0 = mult2()
    //     0x54e6c0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54e6c4: ldur            x1, [fp, #-0x10]
    // 0x54e6c8: ArrayStore: r1[1] = r0  ; List_4
    //     0x54e6c8: add             x25, x1, #0x13
    //     0x54e6cc: str             w0, [x25]
    //     0x54e6d0: tbz             w0, #0, #0x54e6ec
    //     0x54e6d4: ldurb           w16, [x1, #-1]
    //     0x54e6d8: ldurb           w17, [x0, #-1]
    //     0x54e6dc: and             x16, x17, x16, lsr #2
    //     0x54e6e0: tst             x16, HEAP, lsr #32
    //     0x54e6e4: b.eq            #0x54e6ec
    //     0x54e6e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x54e6ec: ldur            x0, [fp, #-0x10]
    // 0x54e6f0: r16 = Instance_Chapter14Stat
    //     0x54e6f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x54e6f4: ldr             x16, [x16, #0x1e8]
    // 0x54e6f8: ArrayStore: r0[0] = r16  ; List_4
    //     0x54e6f8: stur            w16, [x0, #0x17]
    // 0x54e6fc: ldur            x1, [fp, #-8]
    // 0x54e700: r0 = getOptimizePoints()
    //     0x54e700: bl              #0x54e89c  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getOptimizePoints
    // 0x54e704: mov             x2, x0
    // 0x54e708: r1 = Instance_CustomNum
    //     0x54e708: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a680] Obj!CustomNum@82b3f1
    //     0x54e70c: ldr             x1, [x1, #0x680]
    // 0x54e710: r0 = mult2()
    //     0x54e710: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54e714: ldur            x1, [fp, #-0x10]
    // 0x54e718: ArrayStore: r1[3] = r0  ; List_4
    //     0x54e718: add             x25, x1, #0x1b
    //     0x54e71c: str             w0, [x25]
    //     0x54e720: tbz             w0, #0, #0x54e73c
    //     0x54e724: ldurb           w16, [x1, #-1]
    //     0x54e728: ldurb           w17, [x0, #-1]
    //     0x54e72c: and             x16, x17, x16, lsr #2
    //     0x54e730: tst             x16, HEAP, lsr #32
    //     0x54e734: b.eq            #0x54e73c
    //     0x54e738: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x54e73c: ldur            x0, [fp, #-0x10]
    // 0x54e740: r16 = Instance_Chapter14Stat
    //     0x54e740: add             x16, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x54e744: ldr             x16, [x16, #0x230]
    // 0x54e748: StoreField: r0->field_1f = r16
    //     0x54e748: stur            w16, [x0, #0x1f]
    // 0x54e74c: ldur            x1, [fp, #-8]
    // 0x54e750: r0 = getStabilityPoints()
    //     0x54e750: bl              #0x54e7d4  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getStabilityPoints
    // 0x54e754: mov             x2, x0
    // 0x54e758: r1 = Instance_CustomNum
    //     0x54e758: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a688] Obj!CustomNum@82b3e1
    //     0x54e75c: ldr             x1, [x1, #0x688]
    // 0x54e760: r0 = mult2()
    //     0x54e760: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54e764: ldur            x1, [fp, #-0x10]
    // 0x54e768: ArrayStore: r1[5] = r0  ; List_4
    //     0x54e768: add             x25, x1, #0x23
    //     0x54e76c: str             w0, [x25]
    //     0x54e770: tbz             w0, #0, #0x54e78c
    //     0x54e774: ldurb           w16, [x1, #-1]
    //     0x54e778: ldurb           w17, [x0, #-1]
    //     0x54e77c: and             x16, x17, x16, lsr #2
    //     0x54e780: tst             x16, HEAP, lsr #32
    //     0x54e784: b.eq            #0x54e78c
    //     0x54e788: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x54e78c: r16 = <Chapter14Stat, CustomNum>
    //     0x54e78c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a668] TypeArguments: <Chapter14Stat, CustomNum>
    //     0x54e790: ldr             x16, [x16, #0x668]
    // 0x54e794: ldur            lr, [fp, #-0x10]
    // 0x54e798: stp             lr, x16, [SP]
    // 0x54e79c: r0 = Map._fromLiteral()
    //     0x54e79c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54e7a0: LeaveFrame
    //     0x54e7a0: mov             SP, fp
    //     0x54e7a4: ldp             fp, lr, [SP], #0x10
    // 0x54e7a8: ret
    //     0x54e7a8: ret             
    // 0x54e7ac: r16 = <Chapter14Stat, CustomNum>
    //     0x54e7ac: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a668] TypeArguments: <Chapter14Stat, CustomNum>
    //     0x54e7b0: ldr             x16, [x16, #0x668]
    // 0x54e7b4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x54e7b8: stp             lr, x16, [SP]
    // 0x54e7bc: r0 = Map._fromLiteral()
    //     0x54e7bc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54e7c0: LeaveFrame
    //     0x54e7c0: mov             SP, fp
    //     0x54e7c4: ldp             fp, lr, [SP], #0x10
    // 0x54e7c8: ret
    //     0x54e7c8: ret             
    // 0x54e7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e7cc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e7d0: b               #0x54e67c
  }
  _ getStabilityPoints(/* No info */) {
    // ** addr: 0x54e7d4, size: 0x90
    // 0x54e7d4: EnterFrame
    //     0x54e7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x54e7d8: mov             fp, SP
    // 0x54e7dc: AllocStack(0x8)
    //     0x54e7dc: sub             SP, SP, #8
    // 0x54e7e0: CheckStackOverflow
    //     0x54e7e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e7e4: cmp             SP, x16
    //     0x54e7e8: b.ls            #0x54e85c
    // 0x54e7ec: LoadField: r0 = r1->field_3b
    //     0x54e7ec: ldur            w0, [x1, #0x3b]
    // 0x54e7f0: DecompressPointer r0
    //     0x54e7f0: add             x0, x0, HEAP, lsl #32
    // 0x54e7f4: mov             x1, x0
    // 0x54e7f8: stur            x0, [fp, #-8]
    // 0x54e7fc: r2 = Instance_Chapter14Stat
    //     0x54e7fc: add             x2, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x54e800: ldr             x2, [x2, #0x1a8]
    // 0x54e804: r0 = _getValueOrData()
    //     0x54e804: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e808: mov             x1, x0
    // 0x54e80c: ldur            x0, [fp, #-8]
    // 0x54e810: LoadField: r2 = r0->field_f
    //     0x54e810: ldur            w2, [x0, #0xf]
    // 0x54e814: DecompressPointer r2
    //     0x54e814: add             x2, x2, HEAP, lsl #32
    // 0x54e818: cmp             w2, w1
    // 0x54e81c: b.ne            #0x54e828
    // 0x54e820: r0 = Null
    //     0x54e820: mov             x0, NULL
    // 0x54e824: b               #0x54e82c
    // 0x54e828: mov             x0, x1
    // 0x54e82c: cmp             w0, NULL
    // 0x54e830: b.ne            #0x54e840
    // 0x54e834: r1 = Instance_CustomNum
    //     0x54e834: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e838: ldr             x1, [x1, #0xaf8]
    // 0x54e83c: b               #0x54e844
    // 0x54e840: mov             x1, x0
    // 0x54e844: r2 = Instance_CustomNum
    //     0x54e844: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a690] Obj!CustomNum@82b391
    //     0x54e848: ldr             x2, [x2, #0x690]
    // 0x54e84c: r0 = mult2()
    //     0x54e84c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54e850: LeaveFrame
    //     0x54e850: mov             SP, fp
    //     0x54e854: ldp             fp, lr, [SP], #0x10
    // 0x54e858: ret
    //     0x54e858: ret             
    // 0x54e85c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e85c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e860: b               #0x54e7ec
  }
  [closure] CustomNum getStabilityPoints(dynamic) {
    // ** addr: 0x54e864, size: 0x38
    // 0x54e864: EnterFrame
    //     0x54e864: stp             fp, lr, [SP, #-0x10]!
    //     0x54e868: mov             fp, SP
    // 0x54e86c: ldr             x0, [fp, #0x10]
    // 0x54e870: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x54e870: ldur            w1, [x0, #0x17]
    // 0x54e874: DecompressPointer r1
    //     0x54e874: add             x1, x1, HEAP, lsl #32
    // 0x54e878: CheckStackOverflow
    //     0x54e878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e87c: cmp             SP, x16
    //     0x54e880: b.ls            #0x54e894
    // 0x54e884: r0 = getStabilityPoints()
    //     0x54e884: bl              #0x54e7d4  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getStabilityPoints
    // 0x54e888: LeaveFrame
    //     0x54e888: mov             SP, fp
    //     0x54e88c: ldp             fp, lr, [SP], #0x10
    // 0x54e890: ret
    //     0x54e890: ret             
    // 0x54e894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e894: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e898: b               #0x54e884
  }
  _ getOptimizePoints(/* No info */) {
    // ** addr: 0x54e89c, size: 0xf8
    // 0x54e89c: EnterFrame
    //     0x54e89c: stp             fp, lr, [SP, #-0x10]!
    //     0x54e8a0: mov             fp, SP
    // 0x54e8a4: AllocStack(0x18)
    //     0x54e8a4: sub             SP, SP, #0x18
    // 0x54e8a8: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x10 */)
    //     0x54e8a8: mov             x0, x1
    //     0x54e8ac: stur            x1, [fp, #-0x10]
    // 0x54e8b0: CheckStackOverflow
    //     0x54e8b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e8b4: cmp             SP, x16
    //     0x54e8b8: b.ls            #0x54e98c
    // 0x54e8bc: LoadField: r3 = r0->field_3b
    //     0x54e8bc: ldur            w3, [x0, #0x3b]
    // 0x54e8c0: DecompressPointer r3
    //     0x54e8c0: add             x3, x3, HEAP, lsl #32
    // 0x54e8c4: mov             x1, x3
    // 0x54e8c8: stur            x3, [fp, #-8]
    // 0x54e8cc: r2 = Instance_Chapter14Stat
    //     0x54e8cc: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x54e8d0: ldr             x2, [x2, #0x1d8]
    // 0x54e8d4: r0 = _getValueOrData()
    //     0x54e8d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e8d8: mov             x1, x0
    // 0x54e8dc: ldur            x0, [fp, #-8]
    // 0x54e8e0: LoadField: r2 = r0->field_f
    //     0x54e8e0: ldur            w2, [x0, #0xf]
    // 0x54e8e4: DecompressPointer r2
    //     0x54e8e4: add             x2, x2, HEAP, lsl #32
    // 0x54e8e8: cmp             w2, w1
    // 0x54e8ec: b.ne            #0x54e8f8
    // 0x54e8f0: r0 = Null
    //     0x54e8f0: mov             x0, NULL
    // 0x54e8f4: b               #0x54e8fc
    // 0x54e8f8: mov             x0, x1
    // 0x54e8fc: cmp             w0, NULL
    // 0x54e900: b.ne            #0x54e910
    // 0x54e904: r3 = Instance_CustomNum
    //     0x54e904: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e908: ldr             x3, [x3, #0xaf8]
    // 0x54e90c: b               #0x54e914
    // 0x54e910: mov             x3, x0
    // 0x54e914: ldur            x0, [fp, #-0x10]
    // 0x54e918: stur            x3, [fp, #-8]
    // 0x54e91c: LoadField: r1 = r0->field_43
    //     0x54e91c: ldur            w1, [x0, #0x43]
    // 0x54e920: DecompressPointer r1
    //     0x54e920: add             x1, x1, HEAP, lsl #32
    // 0x54e924: r2 = 360
    //     0x54e924: movz            x2, #0x168
    // 0x54e928: r0 = containsKey()
    //     0x54e928: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54e92c: tbnz            w0, #4, #0x54e93c
    // 0x54e930: r3 = Instance_CustomNum
    //     0x54e930: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a698] Obj!CustomNum@82b3b1
    //     0x54e934: ldr             x3, [x3, #0x698]
    // 0x54e938: b               #0x54e944
    // 0x54e93c: r3 = Instance_CustomNum
    //     0x54e93c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a6a0] Obj!CustomNum@82b3a1
    //     0x54e940: ldr             x3, [x3, #0x6a0]
    // 0x54e944: ldur            x0, [fp, #-0x10]
    // 0x54e948: stur            x3, [fp, #-0x18]
    // 0x54e94c: LoadField: r1 = r0->field_43
    //     0x54e94c: ldur            w1, [x0, #0x43]
    // 0x54e950: DecompressPointer r1
    //     0x54e950: add             x1, x1, HEAP, lsl #32
    // 0x54e954: r2 = 320
    //     0x54e954: movz            x2, #0x140
    // 0x54e958: r0 = containsKey()
    //     0x54e958: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54e95c: tbnz            w0, #4, #0x54e96c
    // 0x54e960: r3 = Instance_CustomNum
    //     0x54e960: add             x3, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x54e964: ldr             x3, [x3, #0x448]
    // 0x54e968: b               #0x54e974
    // 0x54e96c: r3 = Instance_CustomNum
    //     0x54e96c: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e970: ldr             x3, [x3, #0xa70]
    // 0x54e974: ldur            x1, [fp, #-8]
    // 0x54e978: ldur            x2, [fp, #-0x18]
    // 0x54e97c: r0 = mult3()
    //     0x54e97c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x54e980: LeaveFrame
    //     0x54e980: mov             SP, fp
    //     0x54e984: ldp             fp, lr, [SP], #0x10
    // 0x54e988: ret
    //     0x54e988: ret             
    // 0x54e98c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e98c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e990: b               #0x54e8bc
  }
  [closure] CustomNum getOptimizePoints(dynamic) {
    // ** addr: 0x54e994, size: 0x38
    // 0x54e994: EnterFrame
    //     0x54e994: stp             fp, lr, [SP, #-0x10]!
    //     0x54e998: mov             fp, SP
    // 0x54e99c: ldr             x0, [fp, #0x10]
    // 0x54e9a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x54e9a0: ldur            w1, [x0, #0x17]
    // 0x54e9a4: DecompressPointer r1
    //     0x54e9a4: add             x1, x1, HEAP, lsl #32
    // 0x54e9a8: CheckStackOverflow
    //     0x54e9a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e9ac: cmp             SP, x16
    //     0x54e9b0: b.ls            #0x54e9c4
    // 0x54e9b4: r0 = getOptimizePoints()
    //     0x54e9b4: bl              #0x54e89c  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getOptimizePoints
    // 0x54e9b8: LeaveFrame
    //     0x54e9b8: mov             SP, fp
    //     0x54e9bc: ldp             fp, lr, [SP], #0x10
    // 0x54e9c0: ret
    //     0x54e9c0: ret             
    // 0x54e9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e9c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e9c8: b               #0x54e9b4
  }
  _ getRewriteInRustPoints(/* No info */) {
    // ** addr: 0x54e9cc, size: 0xc4
    // 0x54e9cc: EnterFrame
    //     0x54e9cc: stp             fp, lr, [SP, #-0x10]!
    //     0x54e9d0: mov             fp, SP
    // 0x54e9d4: AllocStack(0x10)
    //     0x54e9d4: sub             SP, SP, #0x10
    // 0x54e9d8: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x10 */)
    //     0x54e9d8: mov             x0, x1
    //     0x54e9dc: stur            x1, [fp, #-0x10]
    // 0x54e9e0: CheckStackOverflow
    //     0x54e9e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e9e4: cmp             SP, x16
    //     0x54e9e8: b.ls            #0x54ea88
    // 0x54e9ec: LoadField: r3 = r0->field_3b
    //     0x54e9ec: ldur            w3, [x0, #0x3b]
    // 0x54e9f0: DecompressPointer r3
    //     0x54e9f0: add             x3, x3, HEAP, lsl #32
    // 0x54e9f4: mov             x1, x3
    // 0x54e9f8: stur            x3, [fp, #-8]
    // 0x54e9fc: r2 = Instance_Chapter14Stat
    //     0x54e9fc: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x54ea00: ldr             x2, [x2, #0x1b8]
    // 0x54ea04: r0 = _getValueOrData()
    //     0x54ea04: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54ea08: mov             x1, x0
    // 0x54ea0c: ldur            x0, [fp, #-8]
    // 0x54ea10: LoadField: r2 = r0->field_f
    //     0x54ea10: ldur            w2, [x0, #0xf]
    // 0x54ea14: DecompressPointer r2
    //     0x54ea14: add             x2, x2, HEAP, lsl #32
    // 0x54ea18: cmp             w2, w1
    // 0x54ea1c: b.ne            #0x54ea28
    // 0x54ea20: r0 = Null
    //     0x54ea20: mov             x0, NULL
    // 0x54ea24: b               #0x54ea2c
    // 0x54ea28: mov             x0, x1
    // 0x54ea2c: cmp             w0, NULL
    // 0x54ea30: b.ne            #0x54ea40
    // 0x54ea34: r3 = Instance_CustomNum
    //     0x54ea34: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54ea38: ldr             x3, [x3, #0xaf8]
    // 0x54ea3c: b               #0x54ea44
    // 0x54ea40: mov             x3, x0
    // 0x54ea44: ldur            x0, [fp, #-0x10]
    // 0x54ea48: stur            x3, [fp, #-8]
    // 0x54ea4c: LoadField: r1 = r0->field_43
    //     0x54ea4c: ldur            w1, [x0, #0x43]
    // 0x54ea50: DecompressPointer r1
    //     0x54ea50: add             x1, x1, HEAP, lsl #32
    // 0x54ea54: r2 = 360
    //     0x54ea54: movz            x2, #0x168
    // 0x54ea58: r0 = containsKey()
    //     0x54ea58: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54ea5c: tbnz            w0, #4, #0x54ea6c
    // 0x54ea60: r2 = Instance_CustomNum
    //     0x54ea60: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a6a8] Obj!CustomNum@82b3d1
    //     0x54ea64: ldr             x2, [x2, #0x6a8]
    // 0x54ea68: b               #0x54ea74
    // 0x54ea6c: r2 = Instance_CustomNum
    //     0x54ea6c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a6b0] Obj!CustomNum@82b3c1
    //     0x54ea70: ldr             x2, [x2, #0x6b0]
    // 0x54ea74: ldur            x1, [fp, #-8]
    // 0x54ea78: r0 = mult2()
    //     0x54ea78: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54ea7c: LeaveFrame
    //     0x54ea7c: mov             SP, fp
    //     0x54ea80: ldp             fp, lr, [SP], #0x10
    // 0x54ea84: ret
    //     0x54ea84: ret             
    // 0x54ea88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54ea88: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54ea8c: b               #0x54e9ec
  }
  [closure] CustomNum getRewriteInRustPoints(dynamic) {
    // ** addr: 0x54ea90, size: 0x38
    // 0x54ea90: EnterFrame
    //     0x54ea90: stp             fp, lr, [SP, #-0x10]!
    //     0x54ea94: mov             fp, SP
    // 0x54ea98: ldr             x0, [fp, #0x10]
    // 0x54ea9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x54ea9c: ldur            w1, [x0, #0x17]
    // 0x54eaa0: DecompressPointer r1
    //     0x54eaa0: add             x1, x1, HEAP, lsl #32
    // 0x54eaa4: CheckStackOverflow
    //     0x54eaa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54eaa8: cmp             SP, x16
    //     0x54eaac: b.ls            #0x54eac0
    // 0x54eab0: r0 = getRewriteInRustPoints()
    //     0x54eab0: bl              #0x54e9cc  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getRewriteInRustPoints
    // 0x54eab4: LeaveFrame
    //     0x54eab4: mov             SP, fp
    //     0x54eab8: ldp             fp, lr, [SP], #0x10
    // 0x54eabc: ret
    //     0x54eabc: ret             
    // 0x54eac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54eac0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54eac4: b               #0x54eab0
  }
  _ getGeneratorSingleYieldsRawPreMetaBoosts(/* No info */) {
    // ** addr: 0x556b74, size: 0xcc
    // 0x556b74: EnterFrame
    //     0x556b74: stp             fp, lr, [SP, #-0x10]!
    //     0x556b78: mov             fp, SP
    // 0x556b7c: AllocStack(0x38)
    //     0x556b7c: sub             SP, SP, #0x38
    // 0x556b80: SetupParameters(Chapter14GameState this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x556b80: mov             x5, x1
    //     0x556b84: mov             x4, x2
    //     0x556b88: mov             x0, x3
    //     0x556b8c: stur            x1, [fp, #-8]
    //     0x556b90: stur            x2, [fp, #-0x10]
    //     0x556b94: stur            x3, [fp, #-0x18]
    // 0x556b98: CheckStackOverflow
    //     0x556b98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x556b9c: cmp             SP, x16
    //     0x556ba0: b.ls            #0x556c38
    // 0x556ba4: mov             x1, x5
    // 0x556ba8: mov             x2, x4
    // 0x556bac: mov             x3, x0
    // 0x556bb0: r0 = getGeneratorSingleYieldsRawPreMetaBoosts()
    //     0x556bb0: bl              #0x55b23c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsRawPreMetaBoosts
    // 0x556bb4: mov             x3, x0
    // 0x556bb8: ldur            x0, [fp, #-8]
    // 0x556bbc: stur            x3, [fp, #-0x20]
    // 0x556bc0: LoadField: r1 = r0->field_43
    //     0x556bc0: ldur            w1, [x0, #0x43]
    // 0x556bc4: DecompressPointer r1
    //     0x556bc4: add             x1, x1, HEAP, lsl #32
    // 0x556bc8: r2 = 400
    //     0x556bc8: movz            x2, #0x190
    // 0x556bcc: r0 = containsKey()
    //     0x556bcc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x556bd0: tbnz            w0, #4, #0x556c28
    // 0x556bd4: ldur            x0, [fp, #-0x10]
    // 0x556bd8: cmp             x0, #0x3e8
    // 0x556bdc: b.ge            #0x556c28
    // 0x556be0: ldur            x2, [fp, #-0x18]
    // 0x556be4: r1 = Instance_CustomNum
    //     0x556be4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x556be8: ldr             x1, [x1, #0xce0]
    // 0x556bec: r0 = mult2()
    //     0x556bec: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x556bf0: mov             x2, x0
    // 0x556bf4: r1 = Instance_CustomNum
    //     0x556bf4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x556bf8: ldr             x1, [x1, #0xa70]
    // 0x556bfc: r0 = add()
    //     0x556bfc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x556c00: r16 = <Chapter14Stat>
    //     0x556c00: add             x16, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x556c04: ldr             x16, [x16, #0xf60]
    // 0x556c08: ldur            lr, [fp, #-0x20]
    // 0x556c0c: stp             lr, x16, [SP, #8]
    // 0x556c10: str             x0, [SP]
    // 0x556c14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x556c14: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x556c18: r0 = MapOperations.multiplyScaler()
    //     0x556c18: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x556c1c: LeaveFrame
    //     0x556c1c: mov             SP, fp
    //     0x556c20: ldp             fp, lr, [SP], #0x10
    // 0x556c24: ret
    //     0x556c24: ret             
    // 0x556c28: ldur            x0, [fp, #-0x20]
    // 0x556c2c: LeaveFrame
    //     0x556c2c: mov             SP, fp
    //     0x556c30: ldp             fp, lr, [SP], #0x10
    // 0x556c34: ret
    //     0x556c34: ret             
    // 0x556c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556c38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556c3c: b               #0x556ba4
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55c854, size: 0x5ec
    // 0x55c854: EnterFrame
    //     0x55c854: stp             fp, lr, [SP, #-0x10]!
    //     0x55c858: mov             fp, SP
    // 0x55c85c: AllocStack(0x40)
    //     0x55c85c: sub             SP, SP, #0x40
    // 0x55c860: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x10 */)
    //     0x55c860: mov             x0, x1
    //     0x55c864: stur            x1, [fp, #-0x10]
    // 0x55c868: CheckStackOverflow
    //     0x55c868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55c86c: cmp             SP, x16
    //     0x55c870: b.ls            #0x55ce38
    // 0x55c874: LoadField: r1 = r0->field_3f
    //     0x55c874: ldur            w1, [x0, #0x3f]
    // 0x55c878: DecompressPointer r1
    //     0x55c878: add             x1, x1, HEAP, lsl #32
    // 0x55c87c: LoadField: r3 = r1->field_b
    //     0x55c87c: ldur            w3, [x1, #0xb]
    // 0x55c880: DecompressPointer r3
    //     0x55c880: add             x3, x3, HEAP, lsl #32
    // 0x55c884: mov             x1, x3
    // 0x55c888: stur            x3, [fp, #-8]
    // 0x55c88c: r2 = 2
    //     0x55c88c: movz            x2, #0x2
    // 0x55c890: r0 = _getValueOrData()
    //     0x55c890: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c894: mov             x1, x0
    // 0x55c898: ldur            x0, [fp, #-8]
    // 0x55c89c: LoadField: r2 = r0->field_f
    //     0x55c89c: ldur            w2, [x0, #0xf]
    // 0x55c8a0: DecompressPointer r2
    //     0x55c8a0: add             x2, x2, HEAP, lsl #32
    // 0x55c8a4: cmp             w2, w1
    // 0x55c8a8: b.ne            #0x55c8b4
    // 0x55c8ac: r0 = Null
    //     0x55c8ac: mov             x0, NULL
    // 0x55c8b0: b               #0x55c8b8
    // 0x55c8b4: mov             x0, x1
    // 0x55c8b8: cmp             w0, NULL
    // 0x55c8bc: b.ne            #0x55c8c8
    // 0x55c8c0: r0 = 0
    //     0x55c8c0: movz            x0, #0
    // 0x55c8c4: b               #0x55c8d8
    // 0x55c8c8: r1 = LoadInt32Instr(r0)
    //     0x55c8c8: sbfx            x1, x0, #1, #0x1f
    //     0x55c8cc: tbz             w0, #0, #0x55c8d4
    //     0x55c8d0: ldur            x1, [x0, #7]
    // 0x55c8d4: mov             x0, x1
    // 0x55c8d8: cmp             x0, #1
    // 0x55c8dc: b.le            #0x55c9cc
    // 0x55c8e0: ldur            x0, [fp, #-0x10]
    // 0x55c8e4: LoadField: r3 = r0->field_37
    //     0x55c8e4: ldur            w3, [x0, #0x37]
    // 0x55c8e8: DecompressPointer r3
    //     0x55c8e8: add             x3, x3, HEAP, lsl #32
    // 0x55c8ec: mov             x1, x3
    // 0x55c8f0: stur            x3, [fp, #-8]
    // 0x55c8f4: r2 = Instance_Chapter14Stat
    //     0x55c8f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x55c8f8: ldr             x2, [x2, #0x1c8]
    // 0x55c8fc: r0 = _getValueOrData()
    //     0x55c8fc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c900: mov             x1, x0
    // 0x55c904: ldur            x0, [fp, #-8]
    // 0x55c908: LoadField: r2 = r0->field_f
    //     0x55c908: ldur            w2, [x0, #0xf]
    // 0x55c90c: DecompressPointer r2
    //     0x55c90c: add             x2, x2, HEAP, lsl #32
    // 0x55c910: cmp             w2, w1
    // 0x55c914: b.ne            #0x55c920
    // 0x55c918: r0 = Null
    //     0x55c918: mov             x0, NULL
    // 0x55c91c: b               #0x55c924
    // 0x55c920: mov             x0, x1
    // 0x55c924: cmp             w0, NULL
    // 0x55c928: b.ne            #0x55c938
    // 0x55c92c: r3 = Instance_CustomNum
    //     0x55c92c: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55c930: ldr             x3, [x3, #0xaf8]
    // 0x55c934: b               #0x55c93c
    // 0x55c938: mov             x3, x0
    // 0x55c93c: ldur            x0, [fp, #-0x10]
    // 0x55c940: stur            x3, [fp, #-0x18]
    // 0x55c944: LoadField: r4 = r0->field_37
    //     0x55c944: ldur            w4, [x0, #0x37]
    // 0x55c948: DecompressPointer r4
    //     0x55c948: add             x4, x4, HEAP, lsl #32
    // 0x55c94c: mov             x1, x4
    // 0x55c950: stur            x4, [fp, #-8]
    // 0x55c954: r2 = Instance_Chapter14Stat
    //     0x55c954: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x55c958: ldr             x2, [x2, #0x1d8]
    // 0x55c95c: r0 = _getValueOrData()
    //     0x55c95c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c960: mov             x1, x0
    // 0x55c964: ldur            x0, [fp, #-8]
    // 0x55c968: LoadField: r2 = r0->field_f
    //     0x55c968: ldur            w2, [x0, #0xf]
    // 0x55c96c: DecompressPointer r2
    //     0x55c96c: add             x2, x2, HEAP, lsl #32
    // 0x55c970: cmp             w2, w1
    // 0x55c974: b.ne            #0x55c980
    // 0x55c978: r0 = Null
    //     0x55c978: mov             x0, NULL
    // 0x55c97c: b               #0x55c984
    // 0x55c980: mov             x0, x1
    // 0x55c984: cmp             w0, NULL
    // 0x55c988: b.ne            #0x55c998
    // 0x55c98c: r2 = Instance_CustomNum
    //     0x55c98c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55c990: ldr             x2, [x2, #0xaf8]
    // 0x55c994: b               #0x55c99c
    // 0x55c998: mov             x2, x0
    // 0x55c99c: ldur            x1, [fp, #-0x18]
    // 0x55c9a0: r0 = min()
    //     0x55c9a0: bl              #0x55ce40  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::min
    // 0x55c9a4: mov             x2, x0
    // 0x55c9a8: r1 = Instance_CustomNum
    //     0x55c9a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55c9ac: ldr             x1, [x1, #0xa70]
    // 0x55c9b0: r0 = add()
    //     0x55c9b0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55c9b4: mov             x1, x0
    // 0x55c9b8: r2 = 0.100000
    //     0x55c9b8: add             x2, PP, #0x15, lsl #12  ; [pp+0x151e0] 0.1
    //     0x55c9bc: ldr             x2, [x2, #0x1e0]
    // 0x55c9c0: r0 = pow()
    //     0x55c9c0: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x55c9c4: mov             x3, x0
    // 0x55c9c8: b               #0x55c9d4
    // 0x55c9cc: r3 = Instance_CustomNum
    //     0x55c9cc: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55c9d0: ldr             x3, [x3, #0xa70]
    // 0x55c9d4: ldur            x0, [fp, #-0x10]
    // 0x55c9d8: stur            x3, [fp, #-0x18]
    // 0x55c9dc: LoadField: r4 = r0->field_37
    //     0x55c9dc: ldur            w4, [x0, #0x37]
    // 0x55c9e0: DecompressPointer r4
    //     0x55c9e0: add             x4, x4, HEAP, lsl #32
    // 0x55c9e4: mov             x1, x4
    // 0x55c9e8: stur            x4, [fp, #-8]
    // 0x55c9ec: r2 = Instance_Chapter14Stat
    //     0x55c9ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x55c9f0: ldr             x2, [x2, #0x230]
    // 0x55c9f4: r0 = _getValueOrData()
    //     0x55c9f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c9f8: mov             x1, x0
    // 0x55c9fc: ldur            x0, [fp, #-8]
    // 0x55ca00: LoadField: r2 = r0->field_f
    //     0x55ca00: ldur            w2, [x0, #0xf]
    // 0x55ca04: DecompressPointer r2
    //     0x55ca04: add             x2, x2, HEAP, lsl #32
    // 0x55ca08: cmp             w2, w1
    // 0x55ca0c: b.ne            #0x55ca18
    // 0x55ca10: r0 = Null
    //     0x55ca10: mov             x0, NULL
    // 0x55ca14: b               #0x55ca1c
    // 0x55ca18: mov             x0, x1
    // 0x55ca1c: cmp             w0, NULL
    // 0x55ca20: b.ne            #0x55ca30
    // 0x55ca24: r1 = Instance_CustomNum
    //     0x55ca24: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55ca28: ldr             x1, [x1, #0xaf8]
    // 0x55ca2c: b               #0x55ca34
    // 0x55ca30: mov             x1, x0
    // 0x55ca34: ldur            x0, [fp, #-0x10]
    // 0x55ca38: r2 = 0.300000
    //     0x55ca38: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a660] 0.3
    //     0x55ca3c: ldr             x2, [x2, #0x660]
    // 0x55ca40: r0 = pow()
    //     0x55ca40: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x55ca44: mov             x2, x0
    // 0x55ca48: r1 = Instance_CustomNum
    //     0x55ca48: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55ca4c: ldr             x1, [x1, #0xce0]
    // 0x55ca50: r0 = mult2()
    //     0x55ca50: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55ca54: mov             x2, x0
    // 0x55ca58: r1 = Instance_CustomNum
    //     0x55ca58: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55ca5c: ldr             x1, [x1, #0xa70]
    // 0x55ca60: r0 = add()
    //     0x55ca60: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55ca64: r1 = Null
    //     0x55ca64: mov             x1, NULL
    // 0x55ca68: r2 = 12
    //     0x55ca68: movz            x2, #0xc
    // 0x55ca6c: stur            x0, [fp, #-8]
    // 0x55ca70: r0 = AllocateArray()
    //     0x55ca70: bl              #0x82746c  ; AllocateArrayStub
    // 0x55ca74: stur            x0, [fp, #-0x28]
    // 0x55ca78: r16 = Instance_Chapter14Stat
    //     0x55ca78: add             x16, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x55ca7c: ldr             x16, [x16, #0x1a8]
    // 0x55ca80: StoreField: r0->field_f = r16
    //     0x55ca80: stur            w16, [x0, #0xf]
    // 0x55ca84: ldur            x3, [fp, #-0x10]
    // 0x55ca88: LoadField: r1 = r3->field_3f
    //     0x55ca88: ldur            w1, [x3, #0x3f]
    // 0x55ca8c: DecompressPointer r1
    //     0x55ca8c: add             x1, x1, HEAP, lsl #32
    // 0x55ca90: LoadField: r2 = r1->field_7
    //     0x55ca90: ldur            w2, [x1, #7]
    // 0x55ca94: DecompressPointer r2
    //     0x55ca94: add             x2, x2, HEAP, lsl #32
    // 0x55ca98: cmp             w2, #2
    // 0x55ca9c: b.eq            #0x55cb88
    // 0x55caa0: LoadField: r4 = r3->field_37
    //     0x55caa0: ldur            w4, [x3, #0x37]
    // 0x55caa4: DecompressPointer r4
    //     0x55caa4: add             x4, x4, HEAP, lsl #32
    // 0x55caa8: mov             x1, x4
    // 0x55caac: stur            x4, [fp, #-0x20]
    // 0x55cab0: r2 = Instance_Chapter14Stat
    //     0x55cab0: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x55cab4: ldr             x2, [x2, #0x1b8]
    // 0x55cab8: r0 = _getValueOrData()
    //     0x55cab8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55cabc: mov             x1, x0
    // 0x55cac0: ldur            x0, [fp, #-0x20]
    // 0x55cac4: LoadField: r2 = r0->field_f
    //     0x55cac4: ldur            w2, [x0, #0xf]
    // 0x55cac8: DecompressPointer r2
    //     0x55cac8: add             x2, x2, HEAP, lsl #32
    // 0x55cacc: cmp             w2, w1
    // 0x55cad0: b.ne            #0x55cadc
    // 0x55cad4: r0 = Null
    //     0x55cad4: mov             x0, NULL
    // 0x55cad8: b               #0x55cae0
    // 0x55cadc: mov             x0, x1
    // 0x55cae0: cmp             w0, NULL
    // 0x55cae4: b.ne            #0x55caf4
    // 0x55cae8: r3 = Instance_CustomNum
    //     0x55cae8: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55caec: ldr             x3, [x3, #0xaf8]
    // 0x55caf0: b               #0x55caf8
    // 0x55caf4: mov             x3, x0
    // 0x55caf8: ldur            x0, [fp, #-0x10]
    // 0x55cafc: stur            x3, [fp, #-0x30]
    // 0x55cb00: LoadField: r4 = r0->field_37
    //     0x55cb00: ldur            w4, [x0, #0x37]
    // 0x55cb04: DecompressPointer r4
    //     0x55cb04: add             x4, x4, HEAP, lsl #32
    // 0x55cb08: mov             x1, x4
    // 0x55cb0c: stur            x4, [fp, #-0x20]
    // 0x55cb10: r2 = Instance_Chapter14Stat
    //     0x55cb10: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x55cb14: ldr             x2, [x2, #0x1d8]
    // 0x55cb18: r0 = _getValueOrData()
    //     0x55cb18: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55cb1c: mov             x1, x0
    // 0x55cb20: ldur            x0, [fp, #-0x20]
    // 0x55cb24: LoadField: r2 = r0->field_f
    //     0x55cb24: ldur            w2, [x0, #0xf]
    // 0x55cb28: DecompressPointer r2
    //     0x55cb28: add             x2, x2, HEAP, lsl #32
    // 0x55cb2c: cmp             w2, w1
    // 0x55cb30: b.ne            #0x55cb3c
    // 0x55cb34: r0 = Null
    //     0x55cb34: mov             x0, NULL
    // 0x55cb38: b               #0x55cb40
    // 0x55cb3c: mov             x0, x1
    // 0x55cb40: cmp             w0, NULL
    // 0x55cb44: b.ne            #0x55cb54
    // 0x55cb48: r2 = Instance_CustomNum
    //     0x55cb48: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55cb4c: ldr             x2, [x2, #0xaf8]
    // 0x55cb50: b               #0x55cb58
    // 0x55cb54: mov             x2, x0
    // 0x55cb58: ldur            x1, [fp, #-0x30]
    // 0x55cb5c: r0 = add()
    //     0x55cb5c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55cb60: mov             x2, x0
    // 0x55cb64: ldur            x3, [fp, #-0x18]
    // 0x55cb68: r1 = Instance_CustomNum
    //     0x55cb68: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55cb6c: ldr             x1, [x1, #0xce0]
    // 0x55cb70: r0 = mult3()
    //     0x55cb70: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x55cb74: mov             x2, x0
    // 0x55cb78: r1 = Instance_CustomNum
    //     0x55cb78: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55cb7c: ldr             x1, [x1, #0xa70]
    // 0x55cb80: r0 = add()
    //     0x55cb80: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55cb84: b               #0x55cc70
    // 0x55cb88: mov             x0, x3
    // 0x55cb8c: LoadField: r3 = r0->field_37
    //     0x55cb8c: ldur            w3, [x0, #0x37]
    // 0x55cb90: DecompressPointer r3
    //     0x55cb90: add             x3, x3, HEAP, lsl #32
    // 0x55cb94: mov             x1, x3
    // 0x55cb98: stur            x3, [fp, #-0x20]
    // 0x55cb9c: r2 = Instance_Chapter14Stat
    //     0x55cb9c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x55cba0: ldr             x2, [x2, #0x1b8]
    // 0x55cba4: r0 = _getValueOrData()
    //     0x55cba4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55cba8: mov             x1, x0
    // 0x55cbac: ldur            x0, [fp, #-0x20]
    // 0x55cbb0: LoadField: r2 = r0->field_f
    //     0x55cbb0: ldur            w2, [x0, #0xf]
    // 0x55cbb4: DecompressPointer r2
    //     0x55cbb4: add             x2, x2, HEAP, lsl #32
    // 0x55cbb8: cmp             w2, w1
    // 0x55cbbc: b.ne            #0x55cbc8
    // 0x55cbc0: r0 = Null
    //     0x55cbc0: mov             x0, NULL
    // 0x55cbc4: b               #0x55cbcc
    // 0x55cbc8: mov             x0, x1
    // 0x55cbcc: cmp             w0, NULL
    // 0x55cbd0: b.ne            #0x55cbe0
    // 0x55cbd4: r3 = Instance_CustomNum
    //     0x55cbd4: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55cbd8: ldr             x3, [x3, #0xaf8]
    // 0x55cbdc: b               #0x55cbe4
    // 0x55cbe0: mov             x3, x0
    // 0x55cbe4: ldur            x0, [fp, #-0x10]
    // 0x55cbe8: stur            x3, [fp, #-0x30]
    // 0x55cbec: LoadField: r4 = r0->field_37
    //     0x55cbec: ldur            w4, [x0, #0x37]
    // 0x55cbf0: DecompressPointer r4
    //     0x55cbf0: add             x4, x4, HEAP, lsl #32
    // 0x55cbf4: mov             x1, x4
    // 0x55cbf8: stur            x4, [fp, #-0x20]
    // 0x55cbfc: r2 = Instance_Chapter14Stat
    //     0x55cbfc: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x55cc00: ldr             x2, [x2, #0x1d8]
    // 0x55cc04: r0 = _getValueOrData()
    //     0x55cc04: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55cc08: mov             x1, x0
    // 0x55cc0c: ldur            x0, [fp, #-0x20]
    // 0x55cc10: LoadField: r2 = r0->field_f
    //     0x55cc10: ldur            w2, [x0, #0xf]
    // 0x55cc14: DecompressPointer r2
    //     0x55cc14: add             x2, x2, HEAP, lsl #32
    // 0x55cc18: cmp             w2, w1
    // 0x55cc1c: b.ne            #0x55cc28
    // 0x55cc20: r0 = Null
    //     0x55cc20: mov             x0, NULL
    // 0x55cc24: b               #0x55cc2c
    // 0x55cc28: mov             x0, x1
    // 0x55cc2c: cmp             w0, NULL
    // 0x55cc30: b.ne            #0x55cc40
    // 0x55cc34: r2 = Instance_CustomNum
    //     0x55cc34: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55cc38: ldr             x2, [x2, #0xaf8]
    // 0x55cc3c: b               #0x55cc44
    // 0x55cc40: mov             x2, x0
    // 0x55cc44: ldur            x1, [fp, #-0x30]
    // 0x55cc48: r0 = min()
    //     0x55cc48: bl              #0x55ce40  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::min
    // 0x55cc4c: mov             x2, x0
    // 0x55cc50: ldur            x3, [fp, #-0x18]
    // 0x55cc54: r1 = Instance_CustomNum
    //     0x55cc54: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55cc58: ldr             x1, [x1, #0xce0]
    // 0x55cc5c: r0 = mult3()
    //     0x55cc5c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x55cc60: mov             x2, x0
    // 0x55cc64: r1 = Instance_CustomNum
    //     0x55cc64: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55cc68: ldr             x1, [x1, #0xa70]
    // 0x55cc6c: r0 = add()
    //     0x55cc6c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55cc70: ldur            x3, [fp, #-0x10]
    // 0x55cc74: ldur            x4, [fp, #-0x28]
    // 0x55cc78: mov             x1, x4
    // 0x55cc7c: ArrayStore: r1[1] = r0  ; List_4
    //     0x55cc7c: add             x25, x1, #0x13
    //     0x55cc80: str             w0, [x25]
    //     0x55cc84: tbz             w0, #0, #0x55cca0
    //     0x55cc88: ldurb           w16, [x1, #-1]
    //     0x55cc8c: ldurb           w17, [x0, #-1]
    //     0x55cc90: and             x16, x17, x16, lsr #2
    //     0x55cc94: tst             x16, HEAP, lsr #32
    //     0x55cc98: b.eq            #0x55cca0
    //     0x55cc9c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x55cca0: r16 = Instance_Chapter14Stat
    //     0x55cca0: add             x16, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x55cca4: ldr             x16, [x16, #0x1b8]
    // 0x55cca8: ArrayStore: r4[0] = r16  ; List_4
    //     0x55cca8: stur            w16, [x4, #0x17]
    // 0x55ccac: LoadField: r0 = r3->field_37
    //     0x55ccac: ldur            w0, [x3, #0x37]
    // 0x55ccb0: DecompressPointer r0
    //     0x55ccb0: add             x0, x0, HEAP, lsl #32
    // 0x55ccb4: mov             x1, x0
    // 0x55ccb8: stur            x0, [fp, #-0x18]
    // 0x55ccbc: r2 = Instance_Chapter14Stat
    //     0x55ccbc: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x55ccc0: ldr             x2, [x2, #0x1c8]
    // 0x55ccc4: r0 = _getValueOrData()
    //     0x55ccc4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55ccc8: mov             x1, x0
    // 0x55cccc: ldur            x0, [fp, #-0x18]
    // 0x55ccd0: LoadField: r2 = r0->field_f
    //     0x55ccd0: ldur            w2, [x0, #0xf]
    // 0x55ccd4: DecompressPointer r2
    //     0x55ccd4: add             x2, x2, HEAP, lsl #32
    // 0x55ccd8: cmp             w2, w1
    // 0x55ccdc: b.ne            #0x55cce8
    // 0x55cce0: r0 = Null
    //     0x55cce0: mov             x0, NULL
    // 0x55cce4: b               #0x55ccec
    // 0x55cce8: mov             x0, x1
    // 0x55ccec: cmp             w0, NULL
    // 0x55ccf0: b.ne            #0x55cd00
    // 0x55ccf4: r2 = Instance_CustomNum
    //     0x55ccf4: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55ccf8: ldr             x2, [x2, #0xaf8]
    // 0x55ccfc: b               #0x55cd04
    // 0x55cd00: mov             x2, x0
    // 0x55cd04: ldur            x0, [fp, #-0x10]
    // 0x55cd08: ldur            x3, [fp, #-0x28]
    // 0x55cd0c: r1 = Instance_CustomNum
    //     0x55cd0c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55cd10: ldr             x1, [x1, #0xce0]
    // 0x55cd14: r0 = mult2()
    //     0x55cd14: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55cd18: mov             x2, x0
    // 0x55cd1c: r1 = Instance_CustomNum
    //     0x55cd1c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55cd20: ldr             x1, [x1, #0xa70]
    // 0x55cd24: r0 = add()
    //     0x55cd24: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55cd28: mov             x1, x0
    // 0x55cd2c: ldur            x2, [fp, #-8]
    // 0x55cd30: r0 = mult2()
    //     0x55cd30: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55cd34: ldur            x1, [fp, #-0x28]
    // 0x55cd38: ArrayStore: r1[3] = r0  ; List_4
    //     0x55cd38: add             x25, x1, #0x1b
    //     0x55cd3c: str             w0, [x25]
    //     0x55cd40: tbz             w0, #0, #0x55cd5c
    //     0x55cd44: ldurb           w16, [x1, #-1]
    //     0x55cd48: ldurb           w17, [x0, #-1]
    //     0x55cd4c: and             x16, x17, x16, lsr #2
    //     0x55cd50: tst             x16, HEAP, lsr #32
    //     0x55cd54: b.eq            #0x55cd5c
    //     0x55cd58: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x55cd5c: ldur            x0, [fp, #-0x28]
    // 0x55cd60: r16 = Instance_Chapter14Stat
    //     0x55cd60: add             x16, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x55cd64: ldr             x16, [x16, #0x1d8]
    // 0x55cd68: StoreField: r0->field_1f = r16
    //     0x55cd68: stur            w16, [x0, #0x1f]
    // 0x55cd6c: ldur            x1, [fp, #-0x10]
    // 0x55cd70: LoadField: r3 = r1->field_37
    //     0x55cd70: ldur            w3, [x1, #0x37]
    // 0x55cd74: DecompressPointer r3
    //     0x55cd74: add             x3, x3, HEAP, lsl #32
    // 0x55cd78: mov             x1, x3
    // 0x55cd7c: stur            x3, [fp, #-0x18]
    // 0x55cd80: r2 = Instance_Chapter14Stat
    //     0x55cd80: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x55cd84: ldr             x2, [x2, #0x1e8]
    // 0x55cd88: r0 = _getValueOrData()
    //     0x55cd88: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55cd8c: mov             x1, x0
    // 0x55cd90: ldur            x0, [fp, #-0x18]
    // 0x55cd94: LoadField: r2 = r0->field_f
    //     0x55cd94: ldur            w2, [x0, #0xf]
    // 0x55cd98: DecompressPointer r2
    //     0x55cd98: add             x2, x2, HEAP, lsl #32
    // 0x55cd9c: cmp             w2, w1
    // 0x55cda0: b.ne            #0x55cdac
    // 0x55cda4: r0 = Null
    //     0x55cda4: mov             x0, NULL
    // 0x55cda8: b               #0x55cdb0
    // 0x55cdac: mov             x0, x1
    // 0x55cdb0: cmp             w0, NULL
    // 0x55cdb4: b.ne            #0x55cdc4
    // 0x55cdb8: r2 = Instance_CustomNum
    //     0x55cdb8: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55cdbc: ldr             x2, [x2, #0xaf8]
    // 0x55cdc0: b               #0x55cdc8
    // 0x55cdc4: mov             x2, x0
    // 0x55cdc8: r1 = Instance_CustomNum
    //     0x55cdc8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55cdcc: ldr             x1, [x1, #0xce0]
    // 0x55cdd0: r0 = mult2()
    //     0x55cdd0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55cdd4: mov             x2, x0
    // 0x55cdd8: r1 = Instance_CustomNum
    //     0x55cdd8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55cddc: ldr             x1, [x1, #0xa70]
    // 0x55cde0: r0 = add()
    //     0x55cde0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55cde4: mov             x1, x0
    // 0x55cde8: ldur            x2, [fp, #-8]
    // 0x55cdec: r0 = mult2()
    //     0x55cdec: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55cdf0: ldur            x1, [fp, #-0x28]
    // 0x55cdf4: ArrayStore: r1[5] = r0  ; List_4
    //     0x55cdf4: add             x25, x1, #0x23
    //     0x55cdf8: str             w0, [x25]
    //     0x55cdfc: tbz             w0, #0, #0x55ce18
    //     0x55ce00: ldurb           w16, [x1, #-1]
    //     0x55ce04: ldurb           w17, [x0, #-1]
    //     0x55ce08: and             x16, x17, x16, lsr #2
    //     0x55ce0c: tst             x16, HEAP, lsr #32
    //     0x55ce10: b.eq            #0x55ce18
    //     0x55ce14: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x55ce18: r16 = <Chapter14Stat, CustomNum>
    //     0x55ce18: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a668] TypeArguments: <Chapter14Stat, CustomNum>
    //     0x55ce1c: ldr             x16, [x16, #0x668]
    // 0x55ce20: ldur            lr, [fp, #-0x28]
    // 0x55ce24: stp             lr, x16, [SP]
    // 0x55ce28: r0 = Map._fromLiteral()
    //     0x55ce28: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55ce2c: LeaveFrame
    //     0x55ce2c: mov             SP, fp
    //     0x55ce30: ldp             fp, lr, [SP], #0x10
    // 0x55ce34: ret
    //     0x55ce34: ret             
    // 0x55ce38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55ce38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55ce3c: b               #0x55c874
  }
  _ preUpdateCallback(/* No info */) {
    // ** addr: 0x651154, size: 0x430
    // 0x651154: EnterFrame
    //     0x651154: stp             fp, lr, [SP, #-0x10]!
    //     0x651158: mov             fp, SP
    // 0x65115c: AllocStack(0x38)
    //     0x65115c: sub             SP, SP, #0x38
    // 0x651160: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */)
    //     0x651160: mov             x0, x1
    //     0x651164: stur            x1, [fp, #-8]
    // 0x651168: CheckStackOverflow
    //     0x651168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x65116c: cmp             SP, x16
    //     0x651170: b.ls            #0x651568
    // 0x651174: LoadField: r1 = r0->field_3f
    //     0x651174: ldur            w1, [x0, #0x3f]
    // 0x651178: DecompressPointer r1
    //     0x651178: add             x1, x1, HEAP, lsl #32
    // 0x65117c: LoadField: r2 = r1->field_7
    //     0x65117c: ldur            w2, [x1, #7]
    // 0x651180: DecompressPointer r2
    //     0x651180: add             x2, x2, HEAP, lsl #32
    // 0x651184: cmp             w2, #4
    // 0x651188: b.eq            #0x6512a8
    // 0x65118c: LoadField: r1 = r0->field_43
    //     0x65118c: ldur            w1, [x0, #0x43]
    // 0x651190: DecompressPointer r1
    //     0x651190: add             x1, x1, HEAP, lsl #32
    // 0x651194: r2 = 200
    //     0x651194: movz            x2, #0xc8
    // 0x651198: r0 = containsKey()
    //     0x651198: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x65119c: tbnz            w0, #4, #0x651214
    // 0x6511a0: r1 = "ch14_autobuy_navigation"
    //     0x6511a0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a670] "ch14_autobuy_navigation"
    //     0x6511a4: ldr             x1, [x1, #0x670]
    // 0x6511a8: r0 = prefsGetBool()
    //     0x6511a8: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x6511ac: cmp             w0, NULL
    // 0x6511b0: b.eq            #0x651214
    // 0x6511b4: tbnz            w0, #4, #0x651214
    // 0x6511b8: r0 = 6
    //     0x6511b8: movz            x0, #0x6
    // 0x6511bc: mov             x2, x0
    // 0x6511c0: r1 = Null
    //     0x6511c0: mov             x1, NULL
    // 0x6511c4: r0 = AllocateArray()
    //     0x6511c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x6511c8: stur            x0, [fp, #-0x10]
    // 0x6511cc: r16 = 2
    //     0x6511cc: movz            x16, #0x2
    // 0x6511d0: StoreField: r0->field_f = r16
    //     0x6511d0: stur            w16, [x0, #0xf]
    // 0x6511d4: r16 = 4
    //     0x6511d4: movz            x16, #0x4
    // 0x6511d8: StoreField: r0->field_13 = r16
    //     0x6511d8: stur            w16, [x0, #0x13]
    // 0x6511dc: r16 = 6
    //     0x6511dc: movz            x16, #0x6
    // 0x6511e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x6511e0: stur            w16, [x0, #0x17]
    // 0x6511e4: r1 = <int>
    //     0x6511e4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x6511e8: r0 = AllocateGrowableArray()
    //     0x6511e8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6511ec: mov             x1, x0
    // 0x6511f0: ldur            x0, [fp, #-0x10]
    // 0x6511f4: StoreField: r1->field_f = r0
    //     0x6511f4: stur            w0, [x1, #0xf]
    // 0x6511f8: r0 = 6
    //     0x6511f8: movz            x0, #0x6
    // 0x6511fc: StoreField: r1->field_b = r0
    //     0x6511fc: stur            w0, [x1, #0xb]
    // 0x651200: mov             x2, x1
    // 0x651204: ldur            x1, [fp, #-8]
    // 0x651208: r3 = false
    //     0x651208: add             x3, NULL, #0x30  ; false
    // 0x65120c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x65120c: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x651210: r0 = buyAll()
    //     0x651210: bl              #0x544a08  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll
    // 0x651214: ldur            x0, [fp, #-8]
    // 0x651218: LoadField: r1 = r0->field_43
    //     0x651218: ldur            w1, [x0, #0x43]
    // 0x65121c: DecompressPointer r1
    //     0x65121c: add             x1, x1, HEAP, lsl #32
    // 0x651220: r2 = 260
    //     0x651220: movz            x2, #0x104
    // 0x651224: r0 = containsKey()
    //     0x651224: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x651228: tbnz            w0, #4, #0x6512a8
    // 0x65122c: r1 = "ch14_autobuy_io"
    //     0x65122c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a678] "ch14_autobuy_io"
    //     0x651230: ldr             x1, [x1, #0x678]
    // 0x651234: r0 = prefsGetBool()
    //     0x651234: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x651238: cmp             w0, NULL
    // 0x65123c: b.eq            #0x6512a8
    // 0x651240: tbnz            w0, #4, #0x6512a8
    // 0x651244: r0 = 8
    //     0x651244: movz            x0, #0x8
    // 0x651248: mov             x2, x0
    // 0x65124c: r1 = Null
    //     0x65124c: mov             x1, NULL
    // 0x651250: r0 = AllocateArray()
    //     0x651250: bl              #0x82746c  ; AllocateArrayStub
    // 0x651254: stur            x0, [fp, #-0x10]
    // 0x651258: r16 = 8
    //     0x651258: movz            x16, #0x8
    // 0x65125c: StoreField: r0->field_f = r16
    //     0x65125c: stur            w16, [x0, #0xf]
    // 0x651260: r16 = 10
    //     0x651260: movz            x16, #0xa
    // 0x651264: StoreField: r0->field_13 = r16
    //     0x651264: stur            w16, [x0, #0x13]
    // 0x651268: r16 = 12
    //     0x651268: movz            x16, #0xc
    // 0x65126c: ArrayStore: r0[0] = r16  ; List_4
    //     0x65126c: stur            w16, [x0, #0x17]
    // 0x651270: r16 = 14
    //     0x651270: movz            x16, #0xe
    // 0x651274: StoreField: r0->field_1b = r16
    //     0x651274: stur            w16, [x0, #0x1b]
    // 0x651278: r1 = <int>
    //     0x651278: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x65127c: r0 = AllocateGrowableArray()
    //     0x65127c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x651280: mov             x1, x0
    // 0x651284: ldur            x0, [fp, #-0x10]
    // 0x651288: StoreField: r1->field_f = r0
    //     0x651288: stur            w0, [x1, #0xf]
    // 0x65128c: r0 = 8
    //     0x65128c: movz            x0, #0x8
    // 0x651290: StoreField: r1->field_b = r0
    //     0x651290: stur            w0, [x1, #0xb]
    // 0x651294: mov             x2, x1
    // 0x651298: ldur            x1, [fp, #-8]
    // 0x65129c: r3 = false
    //     0x65129c: add             x3, NULL, #0x30  ; false
    // 0x6512a0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6512a0: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6512a4: r0 = buyAll()
    //     0x6512a4: bl              #0x544a08  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll
    // 0x6512a8: ldur            x0, [fp, #-8]
    // 0x6512ac: LoadField: r3 = r0->field_33
    //     0x6512ac: ldur            w3, [x0, #0x33]
    // 0x6512b0: DecompressPointer r3
    //     0x6512b0: add             x3, x3, HEAP, lsl #32
    // 0x6512b4: stur            x3, [fp, #-0x18]
    // 0x6512b8: LoadField: r4 = r0->field_37
    //     0x6512b8: ldur            w4, [x0, #0x37]
    // 0x6512bc: DecompressPointer r4
    //     0x6512bc: add             x4, x4, HEAP, lsl #32
    // 0x6512c0: mov             x1, x4
    // 0x6512c4: stur            x4, [fp, #-0x10]
    // 0x6512c8: r2 = Instance_Chapter14Stat
    //     0x6512c8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6512cc: ldr             x2, [x2, #0x1d8]
    // 0x6512d0: r0 = _getValueOrData()
    //     0x6512d0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6512d4: mov             x1, x0
    // 0x6512d8: ldur            x0, [fp, #-0x10]
    // 0x6512dc: LoadField: r2 = r0->field_f
    //     0x6512dc: ldur            w2, [x0, #0xf]
    // 0x6512e0: DecompressPointer r2
    //     0x6512e0: add             x2, x2, HEAP, lsl #32
    // 0x6512e4: cmp             w2, w1
    // 0x6512e8: b.ne            #0x6512f4
    // 0x6512ec: r0 = Null
    //     0x6512ec: mov             x0, NULL
    // 0x6512f0: b               #0x6512f8
    // 0x6512f4: mov             x0, x1
    // 0x6512f8: cmp             w0, NULL
    // 0x6512fc: b.ne            #0x65130c
    // 0x651300: r3 = Instance_CustomNum
    //     0x651300: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x651304: ldr             x3, [x3, #0xaf8]
    // 0x651308: b               #0x651310
    // 0x65130c: mov             x3, x0
    // 0x651310: ldur            x0, [fp, #-8]
    // 0x651314: stur            x3, [fp, #-0x20]
    // 0x651318: LoadField: r1 = r0->field_3f
    //     0x651318: ldur            w1, [x0, #0x3f]
    // 0x65131c: DecompressPointer r1
    //     0x65131c: add             x1, x1, HEAP, lsl #32
    // 0x651320: LoadField: r4 = r1->field_b
    //     0x651320: ldur            w4, [x1, #0xb]
    // 0x651324: DecompressPointer r4
    //     0x651324: add             x4, x4, HEAP, lsl #32
    // 0x651328: mov             x1, x4
    // 0x65132c: stur            x4, [fp, #-0x10]
    // 0x651330: r2 = 4
    //     0x651330: movz            x2, #0x4
    // 0x651334: r0 = _getValueOrData()
    //     0x651334: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x651338: mov             x1, x0
    // 0x65133c: ldur            x0, [fp, #-0x10]
    // 0x651340: LoadField: r2 = r0->field_f
    //     0x651340: ldur            w2, [x0, #0xf]
    // 0x651344: DecompressPointer r2
    //     0x651344: add             x2, x2, HEAP, lsl #32
    // 0x651348: cmp             w2, w1
    // 0x65134c: b.ne            #0x651358
    // 0x651350: r0 = Null
    //     0x651350: mov             x0, NULL
    // 0x651354: b               #0x65135c
    // 0x651358: mov             x0, x1
    // 0x65135c: cmp             w0, NULL
    // 0x651360: b.ne            #0x65136c
    // 0x651364: r3 = 0
    //     0x651364: movz            x3, #0
    // 0x651368: b               #0x65137c
    // 0x65136c: r1 = LoadInt32Instr(r0)
    //     0x65136c: sbfx            x1, x0, #1, #0x1f
    //     0x651370: tbz             w0, #0, #0x651378
    //     0x651374: ldur            x1, [x0, #7]
    // 0x651378: mov             x3, x1
    // 0x65137c: ldur            x2, [fp, #-8]
    // 0x651380: r0 = BoxInt64Instr(r3)
    //     0x651380: sbfiz           x0, x3, #1, #0x1f
    //     0x651384: cmp             x3, x0, asr #1
    //     0x651388: b.eq            #0x651394
    //     0x65138c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x651390: stur            x3, [x0, #7]
    // 0x651394: stp             x0, NULL, [SP]
    // 0x651398: r0 = _Double.fromInteger()
    //     0x651398: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x65139c: mov             x2, x0
    // 0x6513a0: r1 = Instance_CustomNum
    //     0x6513a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6513a4: ldr             x1, [x1, #0xdd0]
    // 0x6513a8: r0 = pow()
    //     0x6513a8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6513ac: mov             x3, x0
    // 0x6513b0: ldur            x0, [fp, #-8]
    // 0x6513b4: stur            x3, [fp, #-0x28]
    // 0x6513b8: LoadField: r1 = r0->field_3f
    //     0x6513b8: ldur            w1, [x0, #0x3f]
    // 0x6513bc: DecompressPointer r1
    //     0x6513bc: add             x1, x1, HEAP, lsl #32
    // 0x6513c0: LoadField: r4 = r1->field_b
    //     0x6513c0: ldur            w4, [x1, #0xb]
    // 0x6513c4: DecompressPointer r4
    //     0x6513c4: add             x4, x4, HEAP, lsl #32
    // 0x6513c8: mov             x1, x4
    // 0x6513cc: stur            x4, [fp, #-0x10]
    // 0x6513d0: r2 = 2
    //     0x6513d0: movz            x2, #0x2
    // 0x6513d4: r0 = _getValueOrData()
    //     0x6513d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6513d8: mov             x1, x0
    // 0x6513dc: ldur            x0, [fp, #-0x10]
    // 0x6513e0: LoadField: r2 = r0->field_f
    //     0x6513e0: ldur            w2, [x0, #0xf]
    // 0x6513e4: DecompressPointer r2
    //     0x6513e4: add             x2, x2, HEAP, lsl #32
    // 0x6513e8: cmp             w2, w1
    // 0x6513ec: b.ne            #0x6513f8
    // 0x6513f0: r0 = Null
    //     0x6513f0: mov             x0, NULL
    // 0x6513f4: b               #0x6513fc
    // 0x6513f8: mov             x0, x1
    // 0x6513fc: cmp             w0, NULL
    // 0x651400: b.ne            #0x65140c
    // 0x651404: r0 = 0
    //     0x651404: movz            x0, #0
    // 0x651408: b               #0x65141c
    // 0x65140c: r1 = LoadInt32Instr(r0)
    //     0x65140c: sbfx            x1, x0, #1, #0x1f
    //     0x651410: tbz             w0, #0, #0x651418
    //     0x651414: ldur            x1, [x0, #7]
    // 0x651418: mov             x0, x1
    // 0x65141c: cmp             x0, #3
    // 0x651420: b.le            #0x6514f4
    // 0x651424: ldur            x0, [fp, #-8]
    // 0x651428: LoadField: r1 = r0->field_3f
    //     0x651428: ldur            w1, [x0, #0x3f]
    // 0x65142c: DecompressPointer r1
    //     0x65142c: add             x1, x1, HEAP, lsl #32
    // 0x651430: LoadField: r0 = r1->field_b
    //     0x651430: ldur            w0, [x1, #0xb]
    // 0x651434: DecompressPointer r0
    //     0x651434: add             x0, x0, HEAP, lsl #32
    // 0x651438: mov             x1, x0
    // 0x65143c: stur            x0, [fp, #-8]
    // 0x651440: r2 = 2
    //     0x651440: movz            x2, #0x2
    // 0x651444: r0 = _getValueOrData()
    //     0x651444: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x651448: mov             x1, x0
    // 0x65144c: ldur            x0, [fp, #-8]
    // 0x651450: LoadField: r2 = r0->field_f
    //     0x651450: ldur            w2, [x0, #0xf]
    // 0x651454: DecompressPointer r2
    //     0x651454: add             x2, x2, HEAP, lsl #32
    // 0x651458: cmp             w2, w1
    // 0x65145c: b.ne            #0x651468
    // 0x651460: r0 = Null
    //     0x651460: mov             x0, NULL
    // 0x651464: b               #0x65146c
    // 0x651468: mov             x0, x1
    // 0x65146c: cmp             w0, NULL
    // 0x651470: b.ne            #0x65147c
    // 0x651474: r2 = 0
    //     0x651474: movz            x2, #0
    // 0x651478: b               #0x65148c
    // 0x65147c: r1 = LoadInt32Instr(r0)
    //     0x65147c: sbfx            x1, x0, #1, #0x1f
    //     0x651480: tbz             w0, #0, #0x651488
    //     0x651484: ldur            x1, [x0, #7]
    // 0x651488: mov             x2, x1
    // 0x65148c: r0 = BoxInt64Instr(r2)
    //     0x65148c: sbfiz           x0, x2, #1, #0x1f
    //     0x651490: cmp             x2, x0, asr #1
    //     0x651494: b.eq            #0x6514a0
    //     0x651498: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x65149c: stur            x2, [x0, #7]
    // 0x6514a0: stp             x0, NULL, [SP]
    // 0x6514a4: r0 = _Double.fromInteger()
    //     0x6514a4: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x6514a8: LoadField: d0 = r0->field_7
    //     0x6514a8: ldur            d0, [x0, #7]
    // 0x6514ac: d1 = 3.000000
    //     0x6514ac: fmov            d1, #3.00000000
    // 0x6514b0: fsub            d2, d0, d1
    // 0x6514b4: r2 = inline_Allocate_Double()
    //     0x6514b4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x6514b8: add             x2, x2, #0x10
    //     0x6514bc: cmp             x0, x2
    //     0x6514c0: b.ls            #0x651570
    //     0x6514c4: str             x2, [THR, #0x60]  ; THR::top
    //     0x6514c8: sub             x2, x2, #0xf
    //     0x6514cc: movz            x0, #0xe19c
    //     0x6514d0: movk            x0, #0x3, lsl #16
    //     0x6514d4: stur            x0, [x2, #-1]
    // 0x6514d8: dmb             ishst
    // 0x6514dc: StoreField: r2->field_7 = d2
    //     0x6514dc: stur            d2, [x2, #7]
    // 0x6514e0: r1 = Instance_CustomNum
    //     0x6514e0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6514e4: ldr             x1, [x1, #0xdd0]
    // 0x6514e8: r0 = pow()
    //     0x6514e8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6514ec: mov             x5, x0
    // 0x6514f0: b               #0x6514fc
    // 0x6514f4: r5 = Instance_CustomNum
    //     0x6514f4: add             x5, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6514f8: ldr             x5, [x5, #0xa70]
    // 0x6514fc: ldur            x2, [fp, #-0x20]
    // 0x651500: ldur            x3, [fp, #-0x28]
    // 0x651504: r1 = Instance_CustomNum
    //     0x651504: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x651508: ldr             x1, [x1, #0xce0]
    // 0x65150c: r0 = mult4()
    //     0x65150c: bl              #0x3dda04  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult4
    // 0x651510: mov             x2, x0
    // 0x651514: r1 = Instance_CustomNum
    //     0x651514: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x651518: ldr             x1, [x1, #0xa70]
    // 0x65151c: r0 = add()
    //     0x65151c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x651520: stur            x0, [fp, #-8]
    // 0x651524: r0 = Boost()
    //     0x651524: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x651528: mov             x1, x0
    // 0x65152c: ldur            x0, [fp, #-8]
    // 0x651530: StoreField: r1->field_7 = r0
    //     0x651530: stur            w0, [x1, #7]
    // 0x651534: r0 = Instance_CustomNum
    //     0x651534: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x651538: ldr             x0, [x0, #0xa70]
    // 0x65153c: StoreField: r1->field_b = r0
    //     0x65153c: stur            w0, [x1, #0xb]
    // 0x651540: StoreField: r1->field_f = r0
    //     0x651540: stur            w0, [x1, #0xf]
    // 0x651544: StoreField: r1->field_13 = r0
    //     0x651544: stur            w0, [x1, #0x13]
    // 0x651548: mov             x3, x1
    // 0x65154c: ldur            x1, [fp, #-0x18]
    // 0x651550: r2 = 0
    //     0x651550: movz            x2, #0
    // 0x651554: r0 = []=()
    //     0x651554: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x651558: r0 = Null
    //     0x651558: mov             x0, NULL
    // 0x65155c: LeaveFrame
    //     0x65155c: mov             SP, fp
    //     0x651560: ldp             fp, lr, [SP], #0x10
    // 0x651564: ret
    //     0x651564: ret             
    // 0x651568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x651568: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65156c: b               #0x651174
    // 0x651570: SaveReg d2
    //     0x651570: str             q2, [SP, #-0x10]!
    // 0x651574: r0 = AllocateDouble()
    //     0x651574: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x651578: mov             x2, x0
    // 0x65157c: RestoreReg d2
    //     0x65157c: ldr             q2, [SP], #0x10
    // 0x651580: b               #0x6514dc
  }
  _ build(/* No info */) {
    // ** addr: 0x69f870, size: 0x1a0c
    // 0x69f870: EnterFrame
    //     0x69f870: stp             fp, lr, [SP, #-0x10]!
    //     0x69f874: mov             fp, SP
    // 0x69f878: AllocStack(0xc0)
    //     0x69f878: sub             SP, SP, #0xc0
    // 0x69f87c: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x69f87c: mov             x0, x1
    //     0x69f880: stur            x1, [fp, #-8]
    //     0x69f884: stur            x2, [fp, #-0x10]
    // 0x69f888: CheckStackOverflow
    //     0x69f888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f88c: cmp             SP, x16
    //     0x69f890: b.ls            #0x6a1268
    // 0x69f894: r1 = 2
    //     0x69f894: movz            x1, #0x2
    // 0x69f898: r0 = AllocateContext()
    //     0x69f898: bl              #0x82637c  ; AllocateContextStub
    // 0x69f89c: ldur            x2, [fp, #-8]
    // 0x69f8a0: stur            x0, [fp, #-0x58]
    // 0x69f8a4: StoreField: r0->field_f = r2
    //     0x69f8a4: stur            w2, [x0, #0xf]
    // 0x69f8a8: ldur            x1, [fp, #-0x10]
    // 0x69f8ac: StoreField: r0->field_13 = r1
    //     0x69f8ac: stur            w1, [x0, #0x13]
    // 0x69f8b0: LoadField: r3 = r2->field_2b
    //     0x69f8b0: ldur            w3, [x2, #0x2b]
    // 0x69f8b4: DecompressPointer r3
    //     0x69f8b4: add             x3, x3, HEAP, lsl #32
    // 0x69f8b8: stur            x3, [fp, #-0x50]
    // 0x69f8bc: LoadField: r4 = r2->field_37
    //     0x69f8bc: ldur            w4, [x2, #0x37]
    // 0x69f8c0: DecompressPointer r4
    //     0x69f8c0: add             x4, x4, HEAP, lsl #32
    // 0x69f8c4: stur            x4, [fp, #-0x48]
    // 0x69f8c8: LoadField: r5 = r2->field_7
    //     0x69f8c8: ldur            w5, [x2, #7]
    // 0x69f8cc: DecompressPointer r5
    //     0x69f8cc: add             x5, x5, HEAP, lsl #32
    // 0x69f8d0: stur            x5, [fp, #-0x40]
    // 0x69f8d4: LoadField: r6 = r2->field_4b
    //     0x69f8d4: ldur            w6, [x2, #0x4b]
    // 0x69f8d8: DecompressPointer r6
    //     0x69f8d8: add             x6, x6, HEAP, lsl #32
    // 0x69f8dc: stur            x6, [fp, #-0x38]
    // 0x69f8e0: LoadField: r7 = r2->field_47
    //     0x69f8e0: ldur            w7, [x2, #0x47]
    // 0x69f8e4: DecompressPointer r7
    //     0x69f8e4: add             x7, x7, HEAP, lsl #32
    // 0x69f8e8: stur            x7, [fp, #-0x30]
    // 0x69f8ec: LoadField: r8 = r2->field_53
    //     0x69f8ec: ldur            w8, [x2, #0x53]
    // 0x69f8f0: DecompressPointer r8
    //     0x69f8f0: add             x8, x8, HEAP, lsl #32
    // 0x69f8f4: stur            x8, [fp, #-0x28]
    // 0x69f8f8: LoadField: r9 = r2->field_33
    //     0x69f8f8: ldur            w9, [x2, #0x33]
    // 0x69f8fc: DecompressPointer r9
    //     0x69f8fc: add             x9, x9, HEAP, lsl #32
    // 0x69f900: stur            x9, [fp, #-0x20]
    // 0x69f904: LoadField: r10 = r2->field_2f
    //     0x69f904: ldur            w10, [x2, #0x2f]
    // 0x69f908: DecompressPointer r10
    //     0x69f908: add             x10, x10, HEAP, lsl #32
    // 0x69f90c: stur            x10, [fp, #-0x18]
    // 0x69f910: LoadField: r11 = r2->field_93
    //     0x69f910: ldur            w11, [x2, #0x93]
    // 0x69f914: DecompressPointer r11
    //     0x69f914: add             x11, x11, HEAP, lsl #32
    // 0x69f918: stur            x11, [fp, #-0x10]
    // 0x69f91c: r1 = <Chapter14Stat>
    //     0x69f91c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x69f920: ldr             x1, [x1, #0xf60]
    // 0x69f924: r0 = GeneratorGroup()
    //     0x69f924: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69f928: mov             x3, x0
    // 0x69f92c: ldur            x0, [fp, #-0x48]
    // 0x69f930: stur            x3, [fp, #-0x60]
    // 0x69f934: StoreField: r3->field_1f = r0
    //     0x69f934: stur            w0, [x3, #0x1f]
    // 0x69f938: ldur            x2, [fp, #-8]
    // 0x69f93c: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x69f93c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1caf8] AnonymousClosure: (0x3db0dc), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getCostToBuyOneMoreGenerator (0x3daf58)
    //     0x69f940: ldr             x1, [x1, #0xaf8]
    // 0x69f944: r0 = AllocateClosure()
    //     0x69f944: bl              #0x826750  ; AllocateClosureStub
    // 0x69f948: mov             x3, x0
    // 0x69f94c: ldur            x0, [fp, #-0x60]
    // 0x69f950: stur            x3, [fp, #-0x48]
    // 0x69f954: StoreField: r0->field_23 = r3
    //     0x69f954: stur            w3, [x0, #0x23]
    // 0x69f958: ldur            x2, [fp, #-8]
    // 0x69f95c: r1 = Function 'getGeneratorInfo':.
    //     0x69f95c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28620] AnonymousClosure: (0x6a2d58), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getGeneratorInfo (0x80d308)
    //     0x69f960: ldr             x1, [x1, #0x620]
    // 0x69f964: r0 = AllocateClosure()
    //     0x69f964: bl              #0x826750  ; AllocateClosureStub
    // 0x69f968: mov             x3, x0
    // 0x69f96c: ldur            x0, [fp, #-0x60]
    // 0x69f970: stur            x3, [fp, #-0x68]
    // 0x69f974: StoreField: r0->field_27 = r3
    //     0x69f974: stur            w3, [x0, #0x27]
    // 0x69f978: ldur            x1, [fp, #-0x38]
    // 0x69f97c: StoreField: r0->field_2b = r1
    //     0x69f97c: stur            w1, [x0, #0x2b]
    // 0x69f980: ldur            x1, [fp, #-0x30]
    // 0x69f984: StoreField: r0->field_2f = r1
    //     0x69f984: stur            w1, [x0, #0x2f]
    // 0x69f988: ldur            x1, [fp, #-0x28]
    // 0x69f98c: StoreField: r0->field_33 = r1
    //     0x69f98c: stur            w1, [x0, #0x33]
    // 0x69f990: r1 = Function '<anonymous closure>':.
    //     0x69f990: add             x1, PP, #0x28, lsl #12  ; [pp+0x28628] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69f994: ldr             x1, [x1, #0x628]
    // 0x69f998: r2 = Null
    //     0x69f998: mov             x2, NULL
    // 0x69f99c: r0 = AllocateClosure()
    //     0x69f99c: bl              #0x826750  ; AllocateClosureStub
    // 0x69f9a0: mov             x1, x0
    // 0x69f9a4: ldur            x0, [fp, #-0x60]
    // 0x69f9a8: StoreField: r0->field_3b = r1
    //     0x69f9a8: stur            w1, [x0, #0x3b]
    // 0x69f9ac: ldur            x3, [fp, #-0x20]
    // 0x69f9b0: StoreField: r0->field_43 = r3
    //     0x69f9b0: stur            w3, [x0, #0x43]
    // 0x69f9b4: ldur            x4, [fp, #-0x18]
    // 0x69f9b8: StoreField: r0->field_47 = r4
    //     0x69f9b8: stur            w4, [x0, #0x47]
    // 0x69f9bc: ldur            x2, [fp, #-0x58]
    // 0x69f9c0: r1 = Function '<anonymous closure>':.
    //     0x69f9c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28630] AnonymousClosure: (0x6a2c70), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69f9c4: ldr             x1, [x1, #0x630]
    // 0x69f9c8: r0 = AllocateClosure()
    //     0x69f9c8: bl              #0x826750  ; AllocateClosureStub
    // 0x69f9cc: mov             x1, x0
    // 0x69f9d0: ldur            x0, [fp, #-0x60]
    // 0x69f9d4: StoreField: r0->field_4f = r1
    //     0x69f9d4: stur            w1, [x0, #0x4f]
    // 0x69f9d8: ldur            x2, [fp, #-8]
    // 0x69f9dc: r1 = Function 'buyGenerator':.
    //     0x69f9dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x69f9e0: ldr             x1, [x1, #0x108]
    // 0x69f9e4: r0 = AllocateClosure()
    //     0x69f9e4: bl              #0x826750  ; AllocateClosureStub
    // 0x69f9e8: mov             x3, x0
    // 0x69f9ec: ldur            x0, [fp, #-0x60]
    // 0x69f9f0: stur            x3, [fp, #-0x28]
    // 0x69f9f4: StoreField: r0->field_5b = r3
    //     0x69f9f4: stur            w3, [x0, #0x5b]
    // 0x69f9f8: r1 = Function '<anonymous closure>':.
    //     0x69f9f8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28638] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69f9fc: ldr             x1, [x1, #0x638]
    // 0x69fa00: r2 = Null
    //     0x69fa00: mov             x2, NULL
    // 0x69fa04: r0 = AllocateClosure()
    //     0x69fa04: bl              #0x826750  ; AllocateClosureStub
    // 0x69fa08: mov             x1, x0
    // 0x69fa0c: ldur            x0, [fp, #-0x60]
    // 0x69fa10: ArrayStore: r0[0] = r1  ; List_4
    //     0x69fa10: stur            w1, [x0, #0x17]
    // 0x69fa14: r1 = Function '<anonymous closure>':.
    //     0x69fa14: add             x1, PP, #0x28, lsl #12  ; [pp+0x28640] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69fa18: ldr             x1, [x1, #0x640]
    // 0x69fa1c: r2 = Null
    //     0x69fa1c: mov             x2, NULL
    // 0x69fa20: r0 = AllocateClosure()
    //     0x69fa20: bl              #0x826750  ; AllocateClosureStub
    // 0x69fa24: mov             x1, x0
    // 0x69fa28: ldur            x0, [fp, #-0x60]
    // 0x69fa2c: StoreField: r0->field_1b = r1
    //     0x69fa2c: stur            w1, [x0, #0x1b]
    // 0x69fa30: ldur            x2, [fp, #-8]
    // 0x69fa34: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x69fa34: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x69fa38: ldr             x1, [x1, #0x120]
    // 0x69fa3c: r0 = AllocateClosure()
    //     0x69fa3c: bl              #0x826750  ; AllocateClosureStub
    // 0x69fa40: mov             x4, x0
    // 0x69fa44: ldur            x0, [fp, #-0x60]
    // 0x69fa48: stur            x4, [fp, #-0x30]
    // 0x69fa4c: StoreField: r0->field_57 = r4
    //     0x69fa4c: stur            w4, [x0, #0x57]
    // 0x69fa50: r1 = const [0]
    //     0x69fa50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28648] List<int>(1)
    //     0x69fa54: ldr             x1, [x1, #0x648]
    // 0x69fa58: StoreField: r0->field_53 = r1
    //     0x69fa58: stur            w1, [x0, #0x53]
    // 0x69fa5c: ldur            x2, [fp, #-8]
    // 0x69fa60: ldur            x3, [fp, #-0x40]
    // 0x69fa64: r1 = Function 'getGeneratorSingleYieldsBoosted':.
    //     0x69fa64: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0x54a720), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted (0x54a520)
    //     0x69fa68: ldr             x1, [x1, #0x130]
    // 0x69fa6c: r0 = AllocateClosureTA()
    //     0x69fa6c: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x69fa70: mov             x4, x0
    // 0x69fa74: ldur            x0, [fp, #-0x60]
    // 0x69fa78: stur            x4, [fp, #-0x38]
    // 0x69fa7c: StoreField: r0->field_6b = r4
    //     0x69fa7c: stur            w4, [x0, #0x6b]
    // 0x69fa80: ldur            x1, [fp, #-0x50]
    // 0x69fa84: StoreField: r0->field_4b = r1
    //     0x69fa84: stur            w1, [x0, #0x4b]
    // 0x69fa88: ldur            x1, [fp, #-0x10]
    // 0x69fa8c: StoreField: r0->field_67 = r1
    //     0x69fa8c: stur            w1, [x0, #0x67]
    // 0x69fa90: ldur            x2, [fp, #-8]
    // 0x69fa94: ldur            x3, [fp, #-0x40]
    // 0x69fa98: r1 = Function 'getGeneratorBaseCost':.
    //     0x69fa98: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x69fa9c: ldr             x1, [x1, #0x138]
    // 0x69faa0: r0 = AllocateClosureTA()
    //     0x69faa0: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x69faa4: mov             x3, x0
    // 0x69faa8: ldur            x0, [fp, #-0x60]
    // 0x69faac: stur            x3, [fp, #-0x10]
    // 0x69fab0: StoreField: r0->field_77 = r3
    //     0x69fab0: stur            w3, [x0, #0x77]
    // 0x69fab4: ldur            x2, [fp, #-8]
    // 0x69fab8: r1 = Function 'getGeneratorMultiplier':.
    //     0x69fab8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x69fabc: ldr             x1, [x1, #0x140]
    // 0x69fac0: r0 = AllocateClosure()
    //     0x69fac0: bl              #0x826750  ; AllocateClosureStub
    // 0x69fac4: mov             x3, x0
    // 0x69fac8: ldur            x0, [fp, #-0x60]
    // 0x69facc: stur            x3, [fp, #-0x40]
    // 0x69fad0: StoreField: r0->field_7b = r3
    //     0x69fad0: stur            w3, [x0, #0x7b]
    // 0x69fad4: r4 = "Chapter 14 Main Generator"
    //     0x69fad4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28650] "Chapter 14 Main Generator"
    //     0x69fad8: ldr             x4, [x4, #0x650]
    // 0x69fadc: StoreField: r0->field_73 = r4
    //     0x69fadc: stur            w4, [x0, #0x73]
    // 0x69fae0: r1 = Function '<anonymous closure>':.
    //     0x69fae0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28658] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x69fae4: ldr             x1, [x1, #0x658]
    // 0x69fae8: r2 = Null
    //     0x69fae8: mov             x2, NULL
    // 0x69faec: r0 = AllocateClosure()
    //     0x69faec: bl              #0x826750  ; AllocateClosureStub
    // 0x69faf0: ldur            x2, [fp, #-0x60]
    // 0x69faf4: mov             x5, x0
    // 0x69faf8: r1 = Null
    //     0x69faf8: mov             x1, NULL
    // 0x69fafc: r3 = "Chapter 14 Main Generator"
    //     0x69fafc: add             x3, PP, #0x28, lsl #12  ; [pp+0x28650] "Chapter 14 Main Generator"
    //     0x69fb00: ldr             x3, [x3, #0x650]
    // 0x69fb04: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69fb04: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69fb08: r0 = IdleFragment()
    //     0x69fb08: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69fb0c: r1 = <Widget>
    //     0x69fb0c: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69fb10: r2 = 32
    //     0x69fb10: movz            x2, #0x20
    // 0x69fb14: stur            x0, [fp, #-0x50]
    // 0x69fb18: r0 = AllocateArray()
    //     0x69fb18: bl              #0x82746c  ; AllocateArrayStub
    // 0x69fb1c: mov             x2, x0
    // 0x69fb20: ldur            x0, [fp, #-0x50]
    // 0x69fb24: stur            x2, [fp, #-0x78]
    // 0x69fb28: StoreField: r2->field_f = r0
    //     0x69fb28: stur            w0, [x2, #0xf]
    // 0x69fb2c: ldur            x0, [fp, #-8]
    // 0x69fb30: LoadField: r3 = r0->field_37
    //     0x69fb30: ldur            w3, [x0, #0x37]
    // 0x69fb34: DecompressPointer r3
    //     0x69fb34: add             x3, x3, HEAP, lsl #32
    // 0x69fb38: stur            x3, [fp, #-0x70]
    // 0x69fb3c: LoadField: r4 = r0->field_43
    //     0x69fb3c: ldur            w4, [x0, #0x43]
    // 0x69fb40: DecompressPointer r4
    //     0x69fb40: add             x4, x4, HEAP, lsl #32
    // 0x69fb44: stur            x4, [fp, #-0x60]
    // 0x69fb48: LoadField: r5 = r0->field_8f
    //     0x69fb48: ldur            w5, [x0, #0x8f]
    // 0x69fb4c: DecompressPointer r5
    //     0x69fb4c: add             x5, x5, HEAP, lsl #32
    // 0x69fb50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69fb54: cmp             w5, w16
    // 0x69fb58: b.eq            #0x6a1270
    // 0x69fb5c: stur            x5, [fp, #-0x50]
    // 0x69fb60: r1 = <Chapter14Stat>
    //     0x69fb60: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x69fb64: ldr             x1, [x1, #0xf60]
    // 0x69fb68: r0 = UpgradeGroup()
    //     0x69fb68: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x69fb6c: mov             x3, x0
    // 0x69fb70: r0 = 1
    //     0x69fb70: movz            x0, #0x1
    // 0x69fb74: stur            x3, [fp, #-0x80]
    // 0x69fb78: StoreField: r3->field_13 = r0
    //     0x69fb78: stur            x0, [x3, #0x13]
    // 0x69fb7c: ldur            x1, [fp, #-0x50]
    // 0x69fb80: StoreField: r3->field_1b = r1
    //     0x69fb80: stur            w1, [x3, #0x1b]
    // 0x69fb84: ldur            x1, [fp, #-0x70]
    // 0x69fb88: StoreField: r3->field_1f = r1
    //     0x69fb88: stur            w1, [x3, #0x1f]
    // 0x69fb8c: ldur            x1, [fp, #-0x60]
    // 0x69fb90: StoreField: r3->field_23 = r1
    //     0x69fb90: stur            w1, [x3, #0x23]
    // 0x69fb94: r1 = Function '<anonymous closure>':.
    //     0x69fb94: add             x1, PP, #0x28, lsl #12  ; [pp+0x28660] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69fb98: ldr             x1, [x1, #0x660]
    // 0x69fb9c: r2 = Null
    //     0x69fb9c: mov             x2, NULL
    // 0x69fba0: r0 = AllocateClosure()
    //     0x69fba0: bl              #0x826750  ; AllocateClosureStub
    // 0x69fba4: mov             x1, x0
    // 0x69fba8: ldur            x0, [fp, #-0x80]
    // 0x69fbac: StoreField: r0->field_2b = r1
    //     0x69fbac: stur            w1, [x0, #0x2b]
    // 0x69fbb0: r1 = const [0xa, 0x14]
    //     0x69fbb0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28668] List<int>(2)
    //     0x69fbb4: ldr             x1, [x1, #0x668]
    // 0x69fbb8: StoreField: r0->field_f = r1
    //     0x69fbb8: stur            w1, [x0, #0xf]
    // 0x69fbbc: r3 = true
    //     0x69fbbc: add             x3, NULL, #0x20  ; true
    // 0x69fbc0: StoreField: r0->field_27 = r3
    //     0x69fbc0: stur            w3, [x0, #0x27]
    // 0x69fbc4: r4 = Instance_UpgradeDisplayMode
    //     0x69fbc4: add             x4, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x69fbc8: ldr             x4, [x4, #0x608]
    // 0x69fbcc: StoreField: r0->field_2f = r4
    //     0x69fbcc: stur            w4, [x0, #0x2f]
    // 0x69fbd0: r5 = false
    //     0x69fbd0: add             x5, NULL, #0x30  ; false
    // 0x69fbd4: StoreField: r0->field_33 = r5
    //     0x69fbd4: stur            w5, [x0, #0x33]
    // 0x69fbd8: r1 = Function '<anonymous closure>':.
    //     0x69fbd8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28670] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x69fbdc: ldr             x1, [x1, #0x670]
    // 0x69fbe0: r2 = Null
    //     0x69fbe0: mov             x2, NULL
    // 0x69fbe4: r0 = AllocateClosure()
    //     0x69fbe4: bl              #0x826750  ; AllocateClosureStub
    // 0x69fbe8: r16 = false
    //     0x69fbe8: add             x16, NULL, #0x30  ; false
    // 0x69fbec: str             x16, [SP]
    // 0x69fbf0: ldur            x2, [fp, #-0x80]
    // 0x69fbf4: mov             x5, x0
    // 0x69fbf8: r1 = Null
    //     0x69fbf8: mov             x1, NULL
    // 0x69fbfc: r3 = "Chapter 14 Upgrades 1"
    //     0x69fbfc: add             x3, PP, #0x28, lsl #12  ; [pp+0x28678] "Chapter 14 Upgrades 1"
    //     0x69fc00: ldr             x3, [x3, #0x678]
    // 0x69fc04: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x69fc04: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x69fc08: ldr             x4, [x4, #0xf0]
    // 0x69fc0c: r0 = IdleFragment()
    //     0x69fc0c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69fc10: ldur            x1, [fp, #-0x78]
    // 0x69fc14: ArrayStore: r1[1] = r0  ; List_4
    //     0x69fc14: add             x25, x1, #0x13
    //     0x69fc18: str             w0, [x25]
    //     0x69fc1c: tbz             w0, #0, #0x69fc38
    //     0x69fc20: ldurb           w16, [x1, #-1]
    //     0x69fc24: ldurb           w17, [x0, #-1]
    //     0x69fc28: and             x16, x17, x16, lsr #2
    //     0x69fc2c: tst             x16, HEAP, lsr #32
    //     0x69fc30: b.eq            #0x69fc38
    //     0x69fc34: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69fc38: r0 = AutoBuyChip()
    //     0x69fc38: bl              #0x637a20  ; AllocateAutoBuyChipStub -> AutoBuyChip (size=0x18)
    // 0x69fc3c: mov             x3, x0
    // 0x69fc40: r0 = "Auto"
    //     0x69fc40: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b8] "Auto"
    //     0x69fc44: ldr             x0, [x0, #0x6b8]
    // 0x69fc48: stur            x3, [fp, #-0x50]
    // 0x69fc4c: StoreField: r3->field_b = r0
    //     0x69fc4c: stur            w0, [x3, #0xb]
    // 0x69fc50: r1 = Function '<anonymous closure>':.
    //     0x69fc50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28680] AnonymousClosure: (0x6a2c30), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69fc54: ldr             x1, [x1, #0x680]
    // 0x69fc58: r2 = Null
    //     0x69fc58: mov             x2, NULL
    // 0x69fc5c: r0 = AllocateClosure()
    //     0x69fc5c: bl              #0x826750  ; AllocateClosureStub
    // 0x69fc60: mov             x1, x0
    // 0x69fc64: ldur            x0, [fp, #-0x50]
    // 0x69fc68: StoreField: r0->field_f = r1
    //     0x69fc68: stur            w1, [x0, #0xf]
    // 0x69fc6c: r1 = Function '<anonymous closure>':.
    //     0x69fc6c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28688] AnonymousClosure: (0x6a2be0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69fc70: ldr             x1, [x1, #0x688]
    // 0x69fc74: r2 = Null
    //     0x69fc74: mov             x2, NULL
    // 0x69fc78: r0 = AllocateClosure()
    //     0x69fc78: bl              #0x826750  ; AllocateClosureStub
    // 0x69fc7c: mov             x1, x0
    // 0x69fc80: ldur            x0, [fp, #-0x50]
    // 0x69fc84: StoreField: r0->field_13 = r1
    //     0x69fc84: stur            w1, [x0, #0x13]
    // 0x69fc88: r0 = Padding()
    //     0x69fc88: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x69fc8c: mov             x3, x0
    // 0x69fc90: r0 = Instance_EdgeInsets
    //     0x69fc90: add             x0, PP, #0x28, lsl #12  ; [pp+0x28690] Obj!EdgeInsets@8324f1
    //     0x69fc94: ldr             x0, [x0, #0x690]
    // 0x69fc98: stur            x3, [fp, #-0x60]
    // 0x69fc9c: StoreField: r3->field_f = r0
    //     0x69fc9c: stur            w0, [x3, #0xf]
    // 0x69fca0: ldur            x1, [fp, #-0x50]
    // 0x69fca4: StoreField: r3->field_b = r1
    //     0x69fca4: stur            w1, [x3, #0xb]
    // 0x69fca8: ldur            x2, [fp, #-0x58]
    // 0x69fcac: r1 = Function '<anonymous closure>':.
    //     0x69fcac: add             x1, PP, #0x28, lsl #12  ; [pp+0x28698] AnonymousClosure: (0x6a2b94), in [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::build (0x6b6238)
    //     0x69fcb0: ldr             x1, [x1, #0x698]
    // 0x69fcb4: r0 = AllocateClosure()
    //     0x69fcb4: bl              #0x826750  ; AllocateClosureStub
    // 0x69fcb8: r16 = false
    //     0x69fcb8: add             x16, NULL, #0x30  ; false
    // 0x69fcbc: r30 = false
    //     0x69fcbc: add             lr, NULL, #0x30  ; false
    // 0x69fcc0: stp             lr, x16, [SP, #8]
    // 0x69fcc4: r16 = false
    //     0x69fcc4: add             x16, NULL, #0x30  ; false
    // 0x69fcc8: str             x16, [SP]
    // 0x69fccc: ldur            x2, [fp, #-0x60]
    // 0x69fcd0: mov             x5, x0
    // 0x69fcd4: r1 = Null
    //     0x69fcd4: mov             x1, NULL
    // 0x69fcd8: r3 = "auto buy navigation"
    //     0x69fcd8: add             x3, PP, #0x28, lsl #12  ; [pp+0x286a0] "auto buy navigation"
    //     0x69fcdc: ldr             x3, [x3, #0x6a0]
    // 0x69fce0: r4 = const [0, 0x7, 0x3, 0x4, drawBackground, 0x4, padding, 0x5, scrollToBottomOnUnlock, 0x6, null]
    //     0x69fce0: add             x4, PP, #0x28, lsl #12  ; [pp+0x286a8] List(11) [0, 0x7, 0x3, 0x4, "drawBackground", 0x4, "padding", 0x5, "scrollToBottomOnUnlock", 0x6, Null]
    //     0x69fce4: ldr             x4, [x4, #0x6a8]
    // 0x69fce8: r0 = IdleFragment()
    //     0x69fce8: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69fcec: stur            x0, [fp, #-0x50]
    // 0x69fcf0: r0 = CurrencyCounter()
    //     0x69fcf0: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69fcf4: mov             x3, x0
    // 0x69fcf8: r0 = "Navigation"
    //     0x69fcf8: add             x0, PP, #0x11, lsl #12  ; [pp+0x111c0] "Navigation"
    //     0x69fcfc: ldr             x0, [x0, #0x1c0]
    // 0x69fd00: stur            x3, [fp, #-0x60]
    // 0x69fd04: StoreField: r3->field_b = r0
    //     0x69fd04: stur            w0, [x3, #0xb]
    // 0x69fd08: ldur            x2, [fp, #-0x58]
    // 0x69fd0c: r1 = Function '<anonymous closure>':.
    //     0x69fd0c: add             x1, PP, #0x28, lsl #12  ; [pp+0x286b0] AnonymousClosure: (0x6a2aec), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69fd10: ldr             x1, [x1, #0x6b0]
    // 0x69fd14: r0 = AllocateClosure()
    //     0x69fd14: bl              #0x826750  ; AllocateClosureStub
    // 0x69fd18: mov             x1, x0
    // 0x69fd1c: ldur            x0, [fp, #-0x60]
    // 0x69fd20: StoreField: r0->field_f = r1
    //     0x69fd20: stur            w1, [x0, #0xf]
    // 0x69fd24: ldur            x2, [fp, #-0x58]
    // 0x69fd28: r1 = Function '<anonymous closure>':.
    //     0x69fd28: add             x1, PP, #0x28, lsl #12  ; [pp+0x286b8] AnonymousClosure: (0x6a2a44), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69fd2c: ldr             x1, [x1, #0x6b8]
    // 0x69fd30: r0 = AllocateClosure()
    //     0x69fd30: bl              #0x826750  ; AllocateClosureStub
    // 0x69fd34: mov             x1, x0
    // 0x69fd38: ldur            x0, [fp, #-0x60]
    // 0x69fd3c: StoreField: r0->field_13 = r1
    //     0x69fd3c: stur            w1, [x0, #0x13]
    // 0x69fd40: r1 = Function '<anonymous closure>':.
    //     0x69fd40: add             x1, PP, #0x28, lsl #12  ; [pp+0x286c0] AnonymousClosure: (0x6a2a38), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69fd44: ldr             x1, [x1, #0x6c0]
    // 0x69fd48: r2 = Null
    //     0x69fd48: mov             x2, NULL
    // 0x69fd4c: r0 = AllocateClosure()
    //     0x69fd4c: bl              #0x826750  ; AllocateClosureStub
    // 0x69fd50: mov             x1, x0
    // 0x69fd54: ldur            x0, [fp, #-0x60]
    // 0x69fd58: ArrayStore: r0[0] = r1  ; List_4
    //     0x69fd58: stur            w1, [x0, #0x17]
    // 0x69fd5c: ldur            x1, [fp, #-0x50]
    // 0x69fd60: StoreField: r0->field_1b = r1
    //     0x69fd60: stur            w1, [x0, #0x1b]
    // 0x69fd64: r2 = false
    //     0x69fd64: add             x2, NULL, #0x30  ; false
    // 0x69fd68: StoreField: r0->field_1f = r2
    //     0x69fd68: stur            w2, [x0, #0x1f]
    // 0x69fd6c: ldur            x3, [fp, #-8]
    // 0x69fd70: LoadField: r4 = r3->field_2b
    //     0x69fd70: ldur            w4, [x3, #0x2b]
    // 0x69fd74: DecompressPointer r4
    //     0x69fd74: add             x4, x4, HEAP, lsl #32
    // 0x69fd78: stur            x4, [fp, #-0x98]
    // 0x69fd7c: LoadField: r5 = r3->field_37
    //     0x69fd7c: ldur            w5, [x3, #0x37]
    // 0x69fd80: DecompressPointer r5
    //     0x69fd80: add             x5, x5, HEAP, lsl #32
    // 0x69fd84: stur            x5, [fp, #-0x90]
    // 0x69fd88: LoadField: r6 = r3->field_4b
    //     0x69fd88: ldur            w6, [x3, #0x4b]
    // 0x69fd8c: DecompressPointer r6
    //     0x69fd8c: add             x6, x6, HEAP, lsl #32
    // 0x69fd90: stur            x6, [fp, #-0x88]
    // 0x69fd94: LoadField: r7 = r3->field_47
    //     0x69fd94: ldur            w7, [x3, #0x47]
    // 0x69fd98: DecompressPointer r7
    //     0x69fd98: add             x7, x7, HEAP, lsl #32
    // 0x69fd9c: stur            x7, [fp, #-0x80]
    // 0x69fda0: LoadField: r8 = r3->field_53
    //     0x69fda0: ldur            w8, [x3, #0x53]
    // 0x69fda4: DecompressPointer r8
    //     0x69fda4: add             x8, x8, HEAP, lsl #32
    // 0x69fda8: stur            x8, [fp, #-0x70]
    // 0x69fdac: LoadField: r9 = r3->field_93
    //     0x69fdac: ldur            w9, [x3, #0x93]
    // 0x69fdb0: DecompressPointer r9
    //     0x69fdb0: add             x9, x9, HEAP, lsl #32
    // 0x69fdb4: stur            x9, [fp, #-0x50]
    // 0x69fdb8: r1 = <Chapter14Stat>
    //     0x69fdb8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x69fdbc: ldr             x1, [x1, #0xf60]
    // 0x69fdc0: r0 = GeneratorGroup()
    //     0x69fdc0: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69fdc4: mov             x3, x0
    // 0x69fdc8: ldur            x0, [fp, #-0x90]
    // 0x69fdcc: stur            x3, [fp, #-0xa0]
    // 0x69fdd0: StoreField: r3->field_1f = r0
    //     0x69fdd0: stur            w0, [x3, #0x1f]
    // 0x69fdd4: ldur            x0, [fp, #-0x48]
    // 0x69fdd8: StoreField: r3->field_23 = r0
    //     0x69fdd8: stur            w0, [x3, #0x23]
    // 0x69fddc: ldur            x4, [fp, #-0x68]
    // 0x69fde0: StoreField: r3->field_27 = r4
    //     0x69fde0: stur            w4, [x3, #0x27]
    // 0x69fde4: ldur            x1, [fp, #-0x88]
    // 0x69fde8: StoreField: r3->field_2b = r1
    //     0x69fde8: stur            w1, [x3, #0x2b]
    // 0x69fdec: ldur            x1, [fp, #-0x80]
    // 0x69fdf0: StoreField: r3->field_2f = r1
    //     0x69fdf0: stur            w1, [x3, #0x2f]
    // 0x69fdf4: ldur            x1, [fp, #-0x70]
    // 0x69fdf8: StoreField: r3->field_33 = r1
    //     0x69fdf8: stur            w1, [x3, #0x33]
    // 0x69fdfc: r1 = Function '<anonymous closure>':.
    //     0x69fdfc: add             x1, PP, #0x28, lsl #12  ; [pp+0x286c8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69fe00: ldr             x1, [x1, #0x6c8]
    // 0x69fe04: r2 = Null
    //     0x69fe04: mov             x2, NULL
    // 0x69fe08: r0 = AllocateClosure()
    //     0x69fe08: bl              #0x826750  ; AllocateClosureStub
    // 0x69fe0c: mov             x1, x0
    // 0x69fe10: ldur            x0, [fp, #-0xa0]
    // 0x69fe14: StoreField: r0->field_3b = r1
    //     0x69fe14: stur            w1, [x0, #0x3b]
    // 0x69fe18: ldur            x3, [fp, #-0x20]
    // 0x69fe1c: StoreField: r0->field_43 = r3
    //     0x69fe1c: stur            w3, [x0, #0x43]
    // 0x69fe20: ldur            x4, [fp, #-0x18]
    // 0x69fe24: StoreField: r0->field_47 = r4
    //     0x69fe24: stur            w4, [x0, #0x47]
    // 0x69fe28: ldur            x5, [fp, #-0x28]
    // 0x69fe2c: StoreField: r0->field_5b = r5
    //     0x69fe2c: stur            w5, [x0, #0x5b]
    // 0x69fe30: r1 = Function '<anonymous closure>':.
    //     0x69fe30: add             x1, PP, #0x28, lsl #12  ; [pp+0x286d0] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69fe34: ldr             x1, [x1, #0x6d0]
    // 0x69fe38: r2 = Null
    //     0x69fe38: mov             x2, NULL
    // 0x69fe3c: r0 = AllocateClosure()
    //     0x69fe3c: bl              #0x826750  ; AllocateClosureStub
    // 0x69fe40: mov             x1, x0
    // 0x69fe44: ldur            x0, [fp, #-0xa0]
    // 0x69fe48: ArrayStore: r0[0] = r1  ; List_4
    //     0x69fe48: stur            w1, [x0, #0x17]
    // 0x69fe4c: r1 = Function '<anonymous closure>':.
    //     0x69fe4c: add             x1, PP, #0x28, lsl #12  ; [pp+0x286d8] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69fe50: ldr             x1, [x1, #0x6d8]
    // 0x69fe54: r2 = Null
    //     0x69fe54: mov             x2, NULL
    // 0x69fe58: r0 = AllocateClosure()
    //     0x69fe58: bl              #0x826750  ; AllocateClosureStub
    // 0x69fe5c: mov             x1, x0
    // 0x69fe60: ldur            x0, [fp, #-0xa0]
    // 0x69fe64: StoreField: r0->field_1b = r1
    //     0x69fe64: stur            w1, [x0, #0x1b]
    // 0x69fe68: ldur            x3, [fp, #-0x30]
    // 0x69fe6c: StoreField: r0->field_57 = r3
    //     0x69fe6c: stur            w3, [x0, #0x57]
    // 0x69fe70: r1 = const [0x1, 0x2, 0x3]
    //     0x69fe70: add             x1, PP, #0x26, lsl #12  ; [pp+0x268e0] List<int>(3)
    //     0x69fe74: ldr             x1, [x1, #0x8e0]
    // 0x69fe78: StoreField: r0->field_53 = r1
    //     0x69fe78: stur            w1, [x0, #0x53]
    // 0x69fe7c: ldur            x4, [fp, #-0x38]
    // 0x69fe80: StoreField: r0->field_6b = r4
    //     0x69fe80: stur            w4, [x0, #0x6b]
    // 0x69fe84: ldur            x1, [fp, #-0x98]
    // 0x69fe88: StoreField: r0->field_4b = r1
    //     0x69fe88: stur            w1, [x0, #0x4b]
    // 0x69fe8c: ldur            x1, [fp, #-0x60]
    // 0x69fe90: StoreField: r0->field_f = r1
    //     0x69fe90: stur            w1, [x0, #0xf]
    // 0x69fe94: ldur            x1, [fp, #-0x50]
    // 0x69fe98: StoreField: r0->field_67 = r1
    //     0x69fe98: stur            w1, [x0, #0x67]
    // 0x69fe9c: ldur            x5, [fp, #-0x10]
    // 0x69fea0: StoreField: r0->field_77 = r5
    //     0x69fea0: stur            w5, [x0, #0x77]
    // 0x69fea4: ldur            x6, [fp, #-0x40]
    // 0x69fea8: StoreField: r0->field_7b = r6
    //     0x69fea8: stur            w6, [x0, #0x7b]
    // 0x69feac: r7 = "Chapter 14 Generators 1"
    //     0x69feac: add             x7, PP, #0x28, lsl #12  ; [pp+0x286e0] "Chapter 14 Generators 1"
    //     0x69feb0: ldr             x7, [x7, #0x6e0]
    // 0x69feb4: StoreField: r0->field_73 = r7
    //     0x69feb4: stur            w7, [x0, #0x73]
    // 0x69feb8: ldur            x2, [fp, #-0x58]
    // 0x69febc: r1 = Function '<anonymous closure>':.
    //     0x69febc: add             x1, PP, #0x28, lsl #12  ; [pp+0x286e8] AnonymousClosure: (0x6a29f4), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x69fec0: ldr             x1, [x1, #0x6e8]
    // 0x69fec4: r0 = AllocateClosure()
    //     0x69fec4: bl              #0x826750  ; AllocateClosureStub
    // 0x69fec8: ldur            x2, [fp, #-0xa0]
    // 0x69fecc: mov             x5, x0
    // 0x69fed0: r1 = Null
    //     0x69fed0: mov             x1, NULL
    // 0x69fed4: r3 = "Chapter 14 Generators 1"
    //     0x69fed4: add             x3, PP, #0x28, lsl #12  ; [pp+0x286e0] "Chapter 14 Generators 1"
    //     0x69fed8: ldr             x3, [x3, #0x6e0]
    // 0x69fedc: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69fedc: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69fee0: r0 = IdleFragment()
    //     0x69fee0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69fee4: ldur            x1, [fp, #-0x78]
    // 0x69fee8: ArrayStore: r1[2] = r0  ; List_4
    //     0x69fee8: add             x25, x1, #0x17
    //     0x69feec: str             w0, [x25]
    //     0x69fef0: tbz             w0, #0, #0x69ff0c
    //     0x69fef4: ldurb           w16, [x1, #-1]
    //     0x69fef8: ldurb           w17, [x0, #-1]
    //     0x69fefc: and             x16, x17, x16, lsr #2
    //     0x69ff00: tst             x16, HEAP, lsr #32
    //     0x69ff04: b.eq            #0x69ff0c
    //     0x69ff08: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69ff0c: ldur            x2, [fp, #-8]
    // 0x69ff10: LoadField: r0 = r2->field_2b
    //     0x69ff10: ldur            w0, [x2, #0x2b]
    // 0x69ff14: DecompressPointer r0
    //     0x69ff14: add             x0, x0, HEAP, lsl #32
    // 0x69ff18: stur            x0, [fp, #-0x90]
    // 0x69ff1c: LoadField: r3 = r2->field_37
    //     0x69ff1c: ldur            w3, [x2, #0x37]
    // 0x69ff20: DecompressPointer r3
    //     0x69ff20: add             x3, x3, HEAP, lsl #32
    // 0x69ff24: stur            x3, [fp, #-0x88]
    // 0x69ff28: LoadField: r4 = r2->field_4b
    //     0x69ff28: ldur            w4, [x2, #0x4b]
    // 0x69ff2c: DecompressPointer r4
    //     0x69ff2c: add             x4, x4, HEAP, lsl #32
    // 0x69ff30: stur            x4, [fp, #-0x80]
    // 0x69ff34: LoadField: r5 = r2->field_47
    //     0x69ff34: ldur            w5, [x2, #0x47]
    // 0x69ff38: DecompressPointer r5
    //     0x69ff38: add             x5, x5, HEAP, lsl #32
    // 0x69ff3c: stur            x5, [fp, #-0x70]
    // 0x69ff40: LoadField: r6 = r2->field_53
    //     0x69ff40: ldur            w6, [x2, #0x53]
    // 0x69ff44: DecompressPointer r6
    //     0x69ff44: add             x6, x6, HEAP, lsl #32
    // 0x69ff48: stur            x6, [fp, #-0x60]
    // 0x69ff4c: LoadField: r7 = r2->field_93
    //     0x69ff4c: ldur            w7, [x2, #0x93]
    // 0x69ff50: DecompressPointer r7
    //     0x69ff50: add             x7, x7, HEAP, lsl #32
    // 0x69ff54: stur            x7, [fp, #-0x50]
    // 0x69ff58: r1 = <Chapter14Stat>
    //     0x69ff58: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x69ff5c: ldr             x1, [x1, #0xf60]
    // 0x69ff60: r0 = GeneratorGroup()
    //     0x69ff60: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69ff64: mov             x3, x0
    // 0x69ff68: ldur            x0, [fp, #-0x88]
    // 0x69ff6c: stur            x3, [fp, #-0x98]
    // 0x69ff70: StoreField: r3->field_1f = r0
    //     0x69ff70: stur            w0, [x3, #0x1f]
    // 0x69ff74: ldur            x0, [fp, #-0x48]
    // 0x69ff78: StoreField: r3->field_23 = r0
    //     0x69ff78: stur            w0, [x3, #0x23]
    // 0x69ff7c: ldur            x4, [fp, #-0x68]
    // 0x69ff80: StoreField: r3->field_27 = r4
    //     0x69ff80: stur            w4, [x3, #0x27]
    // 0x69ff84: ldur            x1, [fp, #-0x80]
    // 0x69ff88: StoreField: r3->field_2b = r1
    //     0x69ff88: stur            w1, [x3, #0x2b]
    // 0x69ff8c: ldur            x1, [fp, #-0x70]
    // 0x69ff90: StoreField: r3->field_2f = r1
    //     0x69ff90: stur            w1, [x3, #0x2f]
    // 0x69ff94: ldur            x1, [fp, #-0x60]
    // 0x69ff98: StoreField: r3->field_33 = r1
    //     0x69ff98: stur            w1, [x3, #0x33]
    // 0x69ff9c: r1 = Function '<anonymous closure>':.
    //     0x69ff9c: add             x1, PP, #0x28, lsl #12  ; [pp+0x286f0] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x69ffa0: ldr             x1, [x1, #0x6f0]
    // 0x69ffa4: r2 = Null
    //     0x69ffa4: mov             x2, NULL
    // 0x69ffa8: r0 = AllocateClosure()
    //     0x69ffa8: bl              #0x826750  ; AllocateClosureStub
    // 0x69ffac: mov             x1, x0
    // 0x69ffb0: ldur            x0, [fp, #-0x98]
    // 0x69ffb4: StoreField: r0->field_3b = r1
    //     0x69ffb4: stur            w1, [x0, #0x3b]
    // 0x69ffb8: ldur            x3, [fp, #-0x20]
    // 0x69ffbc: StoreField: r0->field_43 = r3
    //     0x69ffbc: stur            w3, [x0, #0x43]
    // 0x69ffc0: ldur            x4, [fp, #-0x18]
    // 0x69ffc4: StoreField: r0->field_47 = r4
    //     0x69ffc4: stur            w4, [x0, #0x47]
    // 0x69ffc8: ldur            x5, [fp, #-0x28]
    // 0x69ffcc: StoreField: r0->field_5b = r5
    //     0x69ffcc: stur            w5, [x0, #0x5b]
    // 0x69ffd0: r1 = Function '<anonymous closure>':.
    //     0x69ffd0: add             x1, PP, #0x28, lsl #12  ; [pp+0x286f8] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69ffd4: ldr             x1, [x1, #0x6f8]
    // 0x69ffd8: r2 = Null
    //     0x69ffd8: mov             x2, NULL
    // 0x69ffdc: r0 = AllocateClosure()
    //     0x69ffdc: bl              #0x826750  ; AllocateClosureStub
    // 0x69ffe0: mov             x1, x0
    // 0x69ffe4: ldur            x0, [fp, #-0x98]
    // 0x69ffe8: ArrayStore: r0[0] = r1  ; List_4
    //     0x69ffe8: stur            w1, [x0, #0x17]
    // 0x69ffec: r1 = Function '<anonymous closure>':.
    //     0x69ffec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28700] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x69fff0: ldr             x1, [x1, #0x700]
    // 0x69fff4: r2 = Null
    //     0x69fff4: mov             x2, NULL
    // 0x69fff8: r0 = AllocateClosure()
    //     0x69fff8: bl              #0x826750  ; AllocateClosureStub
    // 0x69fffc: mov             x1, x0
    // 0x6a0000: ldur            x0, [fp, #-0x98]
    // 0x6a0004: StoreField: r0->field_1b = r1
    //     0x6a0004: stur            w1, [x0, #0x1b]
    // 0x6a0008: ldur            x3, [fp, #-0x30]
    // 0x6a000c: StoreField: r0->field_57 = r3
    //     0x6a000c: stur            w3, [x0, #0x57]
    // 0x6a0010: r1 = const [0x65, 0x66, 0x67]
    //     0x6a0010: add             x1, PP, #0x28, lsl #12  ; [pp+0x28708] List<int>(3)
    //     0x6a0014: ldr             x1, [x1, #0x708]
    // 0x6a0018: StoreField: r0->field_53 = r1
    //     0x6a0018: stur            w1, [x0, #0x53]
    // 0x6a001c: ldur            x4, [fp, #-0x38]
    // 0x6a0020: StoreField: r0->field_6b = r4
    //     0x6a0020: stur            w4, [x0, #0x6b]
    // 0x6a0024: ldur            x1, [fp, #-0x90]
    // 0x6a0028: StoreField: r0->field_4b = r1
    //     0x6a0028: stur            w1, [x0, #0x4b]
    // 0x6a002c: ldur            x1, [fp, #-0x50]
    // 0x6a0030: StoreField: r0->field_67 = r1
    //     0x6a0030: stur            w1, [x0, #0x67]
    // 0x6a0034: ldur            x5, [fp, #-0x10]
    // 0x6a0038: StoreField: r0->field_77 = r5
    //     0x6a0038: stur            w5, [x0, #0x77]
    // 0x6a003c: ldur            x6, [fp, #-0x40]
    // 0x6a0040: StoreField: r0->field_7b = r6
    //     0x6a0040: stur            w6, [x0, #0x7b]
    // 0x6a0044: r7 = "Chapter 14 Generator Generators 1"
    //     0x6a0044: add             x7, PP, #0x28, lsl #12  ; [pp+0x28710] "Chapter 14 Generator Generators 1"
    //     0x6a0048: ldr             x7, [x7, #0x710]
    // 0x6a004c: StoreField: r0->field_73 = r7
    //     0x6a004c: stur            w7, [x0, #0x73]
    // 0x6a0050: ldur            x2, [fp, #-0x58]
    // 0x6a0054: r1 = Function '<anonymous closure>':.
    //     0x6a0054: add             x1, PP, #0x28, lsl #12  ; [pp+0x28718] AnonymousClosure: (0x6a2274), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0058: ldr             x1, [x1, #0x718]
    // 0x6a005c: r0 = AllocateClosure()
    //     0x6a005c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0060: r16 = false
    //     0x6a0060: add             x16, NULL, #0x30  ; false
    // 0x6a0064: str             x16, [SP]
    // 0x6a0068: ldur            x2, [fp, #-0x98]
    // 0x6a006c: mov             x5, x0
    // 0x6a0070: r1 = Null
    //     0x6a0070: mov             x1, NULL
    // 0x6a0074: r3 = "Chapter 14 Generator Generators 1"
    //     0x6a0074: add             x3, PP, #0x28, lsl #12  ; [pp+0x28710] "Chapter 14 Generator Generators 1"
    //     0x6a0078: ldr             x3, [x3, #0x710]
    // 0x6a007c: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6a007c: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6a0080: ldr             x4, [x4, #0xf0]
    // 0x6a0084: r0 = IdleFragment()
    //     0x6a0084: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0088: ldur            x1, [fp, #-0x78]
    // 0x6a008c: ArrayStore: r1[3] = r0  ; List_4
    //     0x6a008c: add             x25, x1, #0x1b
    //     0x6a0090: str             w0, [x25]
    //     0x6a0094: tbz             w0, #0, #0x6a00b0
    //     0x6a0098: ldurb           w16, [x1, #-1]
    //     0x6a009c: ldurb           w17, [x0, #-1]
    //     0x6a00a0: and             x16, x17, x16, lsr #2
    //     0x6a00a4: tst             x16, HEAP, lsr #32
    //     0x6a00a8: b.eq            #0x6a00b0
    //     0x6a00ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a00b0: ldur            x2, [fp, #-8]
    // 0x6a00b4: LoadField: r0 = r2->field_37
    //     0x6a00b4: ldur            w0, [x2, #0x37]
    // 0x6a00b8: DecompressPointer r0
    //     0x6a00b8: add             x0, x0, HEAP, lsl #32
    // 0x6a00bc: stur            x0, [fp, #-0x50]
    // 0x6a00c0: r1 = <Chapter14Stat>
    //     0x6a00c0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a00c4: ldr             x1, [x1, #0xf60]
    // 0x6a00c8: r0 = IntermissionButton()
    //     0x6a00c8: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x6a00cc: mov             x3, x0
    // 0x6a00d0: ldur            x0, [fp, #-0x50]
    // 0x6a00d4: stur            x3, [fp, #-0x60]
    // 0x6a00d8: StoreField: r3->field_1b = r0
    //     0x6a00d8: stur            w0, [x3, #0x1b]
    // 0x6a00dc: r0 = Instance_Tuple2
    //     0x6a00dc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28720] Obj!Tuple2<Chapter14Stat, CustomNum>@826b91
    //     0x6a00e0: ldr             x0, [x0, #0x720]
    // 0x6a00e4: StoreField: r3->field_1f = r0
    //     0x6a00e4: stur            w0, [x3, #0x1f]
    // 0x6a00e8: ldur            x2, [fp, #-0x58]
    // 0x6a00ec: r1 = Function '<anonymous closure>':.
    //     0x6a00ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28728] AnonymousClosure: (0x6a2904), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a00f0: ldr             x1, [x1, #0x728]
    // 0x6a00f4: r0 = AllocateClosure()
    //     0x6a00f4: bl              #0x826750  ; AllocateClosureStub
    // 0x6a00f8: mov             x1, x0
    // 0x6a00fc: ldur            x0, [fp, #-0x60]
    // 0x6a0100: StoreField: r0->field_23 = r1
    //     0x6a0100: stur            w1, [x0, #0x23]
    // 0x6a0104: r1 = Function '<anonymous closure>':.
    //     0x6a0104: add             x1, PP, #0x28, lsl #12  ; [pp+0x28730] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x6a0108: ldr             x1, [x1, #0x730]
    // 0x6a010c: r2 = Null
    //     0x6a010c: mov             x2, NULL
    // 0x6a0110: r0 = AllocateClosure()
    //     0x6a0110: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0114: mov             x1, x0
    // 0x6a0118: ldur            x0, [fp, #-0x60]
    // 0x6a011c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a011c: stur            w1, [x0, #0x17]
    // 0x6a0120: r1 = Function '<anonymous closure>':.
    //     0x6a0120: add             x1, PP, #0x28, lsl #12  ; [pp+0x28738] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a0124: ldr             x1, [x1, #0x738]
    // 0x6a0128: r2 = Null
    //     0x6a0128: mov             x2, NULL
    // 0x6a012c: r0 = AllocateClosure()
    //     0x6a012c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0130: mov             x1, x0
    // 0x6a0134: ldur            x0, [fp, #-0x60]
    // 0x6a0138: StoreField: r0->field_f = r1
    //     0x6a0138: stur            w1, [x0, #0xf]
    // 0x6a013c: ldur            x2, [fp, #-0x58]
    // 0x6a0140: r1 = Function '<anonymous closure>':.
    //     0x6a0140: add             x1, PP, #0x28, lsl #12  ; [pp+0x28740] AnonymousClosure: (0x6a2858), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0144: ldr             x1, [x1, #0x740]
    // 0x6a0148: r0 = AllocateClosure()
    //     0x6a0148: bl              #0x826750  ; AllocateClosureStub
    // 0x6a014c: ldur            x2, [fp, #-0x58]
    // 0x6a0150: r1 = Function '<anonymous closure>':.
    //     0x6a0150: add             x1, PP, #0x28, lsl #12  ; [pp+0x28748] AnonymousClosure: (0x6a280c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0154: ldr             x1, [x1, #0x748]
    // 0x6a0158: stur            x0, [fp, #-0x50]
    // 0x6a015c: r0 = AllocateClosure()
    //     0x6a015c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0160: ldur            x16, [fp, #-0x50]
    // 0x6a0164: str             x16, [SP]
    // 0x6a0168: ldur            x2, [fp, #-0x60]
    // 0x6a016c: mov             x5, x0
    // 0x6a0170: r1 = Null
    //     0x6a0170: mov             x1, NULL
    // 0x6a0174: r3 = "Chapter 14 Intermission"
    //     0x6a0174: add             x3, PP, #0x28, lsl #12  ; [pp+0x28750] "Chapter 14 Intermission"
    //     0x6a0178: ldr             x3, [x3, #0x750]
    // 0x6a017c: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6a017c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6a0180: ldr             x4, [x4, #0x160]
    // 0x6a0184: r0 = IdleFragment()
    //     0x6a0184: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0188: ldur            x1, [fp, #-0x78]
    // 0x6a018c: ArrayStore: r1[4] = r0  ; List_4
    //     0x6a018c: add             x25, x1, #0x1f
    //     0x6a0190: str             w0, [x25]
    //     0x6a0194: tbz             w0, #0, #0x6a01b0
    //     0x6a0198: ldurb           w16, [x1, #-1]
    //     0x6a019c: ldurb           w17, [x0, #-1]
    //     0x6a01a0: and             x16, x17, x16, lsr #2
    //     0x6a01a4: tst             x16, HEAP, lsr #32
    //     0x6a01a8: b.eq            #0x6a01b0
    //     0x6a01ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a01b0: ldur            x0, [fp, #-8]
    // 0x6a01b4: LoadField: r3 = r0->field_37
    //     0x6a01b4: ldur            w3, [x0, #0x37]
    // 0x6a01b8: DecompressPointer r3
    //     0x6a01b8: add             x3, x3, HEAP, lsl #32
    // 0x6a01bc: stur            x3, [fp, #-0x50]
    // 0x6a01c0: r1 = Function '<anonymous closure>':.
    //     0x6a01c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28758] AnonymousClosure: (0x6a2800), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a01c4: ldr             x1, [x1, #0x758]
    // 0x6a01c8: r2 = Null
    //     0x6a01c8: mov             x2, NULL
    // 0x6a01cc: r0 = AllocateClosure()
    //     0x6a01cc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a01d0: r1 = <Chapter14Stat>
    //     0x6a01d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a01d4: ldr             x1, [x1, #0xf60]
    // 0x6a01d8: stur            x0, [fp, #-0x60]
    // 0x6a01dc: r0 = PrestigeButton()
    //     0x6a01dc: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6a01e0: mov             x3, x0
    // 0x6a01e4: ldur            x0, [fp, #-0x60]
    // 0x6a01e8: stur            x3, [fp, #-0x70]
    // 0x6a01ec: StoreField: r3->field_1f = r0
    //     0x6a01ec: stur            w0, [x3, #0x1f]
    // 0x6a01f0: r0 = Instance_Chapter14Stat
    //     0x6a01f0: add             x0, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a01f4: ldr             x0, [x0, #0x1c8]
    // 0x6a01f8: StoreField: r3->field_1b = r0
    //     0x6a01f8: stur            w0, [x3, #0x1b]
    // 0x6a01fc: ldur            x2, [fp, #-8]
    // 0x6a0200: r1 = Function 'getRewriteInRustPoints':.
    //     0x6a0200: add             x1, PP, #0x28, lsl #12  ; [pp+0x28760] AnonymousClosure: (0x54ea90), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getRewriteInRustPoints (0x54e9cc)
    //     0x6a0204: ldr             x1, [x1, #0x760]
    // 0x6a0208: r0 = AllocateClosure()
    //     0x6a0208: bl              #0x826750  ; AllocateClosureStub
    // 0x6a020c: mov             x1, x0
    // 0x6a0210: ldur            x0, [fp, #-0x70]
    // 0x6a0214: StoreField: r0->field_2f = r1
    //     0x6a0214: stur            w1, [x0, #0x2f]
    // 0x6a0218: ldur            x2, [fp, #-8]
    // 0x6a021c: r1 = Function 'applyRewriteInRust':.
    //     0x6a021c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28768] AnonymousClosure: (0x6a2690), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyRewriteInRust (0x6a26c8)
    //     0x6a0220: ldr             x1, [x1, #0x768]
    // 0x6a0224: r0 = AllocateClosure()
    //     0x6a0224: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0228: mov             x3, x0
    // 0x6a022c: ldur            x0, [fp, #-0x70]
    // 0x6a0230: stur            x3, [fp, #-0x60]
    // 0x6a0234: StoreField: r0->field_33 = r3
    //     0x6a0234: stur            w3, [x0, #0x33]
    // 0x6a0238: ldur            x1, [fp, #-0x50]
    // 0x6a023c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a023c: stur            w1, [x0, #0x17]
    // 0x6a0240: r4 = Closure: (Chapter14Stat?) => String from Function 'humanName': static.
    //     0x6a0240: add             x4, PP, #0x28, lsl #12  ; [pp+0x28770] Closure: (Chapter14Stat?) => String from Function 'humanName': static. (0x248ed99c520)
    //     0x6a0244: ldr             x4, [x4, #0x770]
    // 0x6a0248: StoreField: r0->field_43 = r4
    //     0x6a0248: stur            w4, [x0, #0x43]
    // 0x6a024c: r1 = Function '<anonymous closure>':.
    //     0x6a024c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28778] AnonymousClosure: (0x6a2684), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0250: ldr             x1, [x1, #0x778]
    // 0x6a0254: r2 = Null
    //     0x6a0254: mov             x2, NULL
    // 0x6a0258: r0 = AllocateClosure()
    //     0x6a0258: bl              #0x826750  ; AllocateClosureStub
    // 0x6a025c: mov             x1, x0
    // 0x6a0260: ldur            x0, [fp, #-0x70]
    // 0x6a0264: StoreField: r0->field_23 = r1
    //     0x6a0264: stur            w1, [x0, #0x23]
    // 0x6a0268: r3 = "everything above"
    //     0x6a0268: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x6a026c: ldr             x3, [x3, #0x1b0]
    // 0x6a0270: StoreField: r0->field_3f = r3
    //     0x6a0270: stur            w3, [x0, #0x3f]
    // 0x6a0274: r4 = false
    //     0x6a0274: add             x4, NULL, #0x30  ; false
    // 0x6a0278: StoreField: r0->field_f = r4
    //     0x6a0278: stur            w4, [x0, #0xf]
    // 0x6a027c: StoreField: r0->field_4f = r4
    //     0x6a027c: stur            w4, [x0, #0x4f]
    // 0x6a0280: r5 = true
    //     0x6a0280: add             x5, NULL, #0x20  ; true
    // 0x6a0284: StoreField: r0->field_2b = r5
    //     0x6a0284: stur            w5, [x0, #0x2b]
    // 0x6a0288: StoreField: r0->field_53 = r4
    //     0x6a0288: stur            w4, [x0, #0x53]
    // 0x6a028c: StoreField: r0->field_5b = r5
    //     0x6a028c: stur            w5, [x0, #0x5b]
    // 0x6a0290: r6 = "Gain"
    //     0x6a0290: add             x6, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6a0294: ldr             x6, [x6, #0x1b8]
    // 0x6a0298: StoreField: r0->field_5f = r6
    //     0x6a0298: stur            w6, [x0, #0x5f]
    // 0x6a029c: ldur            x2, [fp, #-0x58]
    // 0x6a02a0: r1 = Function '<anonymous closure>':.
    //     0x6a02a0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28780] AnonymousClosure: (0x6a25ec), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a02a4: ldr             x1, [x1, #0x780]
    // 0x6a02a8: r0 = AllocateClosure()
    //     0x6a02a8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a02ac: ldur            x2, [fp, #-0x70]
    // 0x6a02b0: mov             x5, x0
    // 0x6a02b4: r1 = Null
    //     0x6a02b4: mov             x1, NULL
    // 0x6a02b8: r3 = "Chapter 14 Prestige 1"
    //     0x6a02b8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28788] "Chapter 14 Prestige 1"
    //     0x6a02bc: ldr             x3, [x3, #0x788]
    // 0x6a02c0: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a02c0: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a02c4: r0 = IdleFragment()
    //     0x6a02c4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a02c8: ldur            x1, [fp, #-0x78]
    // 0x6a02cc: ArrayStore: r1[5] = r0  ; List_4
    //     0x6a02cc: add             x25, x1, #0x23
    //     0x6a02d0: str             w0, [x25]
    //     0x6a02d4: tbz             w0, #0, #0x6a02f0
    //     0x6a02d8: ldurb           w16, [x1, #-1]
    //     0x6a02dc: ldurb           w17, [x0, #-1]
    //     0x6a02e0: and             x16, x17, x16, lsr #2
    //     0x6a02e4: tst             x16, HEAP, lsr #32
    //     0x6a02e8: b.eq            #0x6a02f0
    //     0x6a02ec: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a02f0: r1 = Null
    //     0x6a02f0: mov             x1, NULL
    // 0x6a02f4: r2 = 4
    //     0x6a02f4: movz            x2, #0x4
    // 0x6a02f8: r0 = AllocateArray()
    //     0x6a02f8: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a02fc: r16 = "Chapter 14 Upgrades 2 "
    //     0x6a02fc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28790] "Chapter 14 Upgrades 2 "
    //     0x6a0300: ldr             x16, [x16, #0x790]
    // 0x6a0304: StoreField: r0->field_f = r16
    //     0x6a0304: stur            w16, [x0, #0xf]
    // 0x6a0308: ldur            x2, [fp, #-8]
    // 0x6a030c: LoadField: r1 = r2->field_43
    //     0x6a030c: ldur            w1, [x2, #0x43]
    // 0x6a0310: DecompressPointer r1
    //     0x6a0310: add             x1, x1, HEAP, lsl #32
    // 0x6a0314: LoadField: r3 = r1->field_13
    //     0x6a0314: ldur            w3, [x1, #0x13]
    // 0x6a0318: r4 = LoadInt32Instr(r3)
    //     0x6a0318: sbfx            x4, x3, #1, #0x1f
    // 0x6a031c: asr             x3, x4, #1
    // 0x6a0320: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x6a0320: ldur            w4, [x1, #0x17]
    // 0x6a0324: r1 = LoadInt32Instr(r4)
    //     0x6a0324: sbfx            x1, x4, #1, #0x1f
    // 0x6a0328: sub             x4, x3, x1
    // 0x6a032c: lsl             x1, x4, #1
    // 0x6a0330: StoreField: r0->field_13 = r1
    //     0x6a0330: stur            w1, [x0, #0x13]
    // 0x6a0334: str             x0, [SP]
    // 0x6a0338: r0 = _interpolate()
    //     0x6a0338: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6a033c: ldur            x2, [fp, #-8]
    // 0x6a0340: stur            x0, [fp, #-0x88]
    // 0x6a0344: LoadField: r3 = r2->field_37
    //     0x6a0344: ldur            w3, [x2, #0x37]
    // 0x6a0348: DecompressPointer r3
    //     0x6a0348: add             x3, x3, HEAP, lsl #32
    // 0x6a034c: stur            x3, [fp, #-0x80]
    // 0x6a0350: LoadField: r4 = r2->field_43
    //     0x6a0350: ldur            w4, [x2, #0x43]
    // 0x6a0354: DecompressPointer r4
    //     0x6a0354: add             x4, x4, HEAP, lsl #32
    // 0x6a0358: stur            x4, [fp, #-0x70]
    // 0x6a035c: LoadField: r5 = r2->field_8f
    //     0x6a035c: ldur            w5, [x2, #0x8f]
    // 0x6a0360: DecompressPointer r5
    //     0x6a0360: add             x5, x5, HEAP, lsl #32
    // 0x6a0364: stur            x5, [fp, #-0x50]
    // 0x6a0368: r1 = <Chapter14Stat>
    //     0x6a0368: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a036c: ldr             x1, [x1, #0xf60]
    // 0x6a0370: r0 = UpgradeGroup()
    //     0x6a0370: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6a0374: mov             x3, x0
    // 0x6a0378: r0 = 1
    //     0x6a0378: movz            x0, #0x1
    // 0x6a037c: stur            x3, [fp, #-0x90]
    // 0x6a0380: StoreField: r3->field_13 = r0
    //     0x6a0380: stur            x0, [x3, #0x13]
    // 0x6a0384: ldur            x1, [fp, #-0x50]
    // 0x6a0388: StoreField: r3->field_1b = r1
    //     0x6a0388: stur            w1, [x3, #0x1b]
    // 0x6a038c: ldur            x1, [fp, #-0x80]
    // 0x6a0390: StoreField: r3->field_1f = r1
    //     0x6a0390: stur            w1, [x3, #0x1f]
    // 0x6a0394: ldur            x1, [fp, #-0x70]
    // 0x6a0398: StoreField: r3->field_23 = r1
    //     0x6a0398: stur            w1, [x3, #0x23]
    // 0x6a039c: r1 = Function '<anonymous closure>':.
    //     0x6a039c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28798] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a03a0: ldr             x1, [x1, #0x798]
    // 0x6a03a4: r2 = Null
    //     0x6a03a4: mov             x2, NULL
    // 0x6a03a8: r0 = AllocateClosure()
    //     0x6a03a8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a03ac: mov             x1, x0
    // 0x6a03b0: ldur            x0, [fp, #-0x90]
    // 0x6a03b4: StoreField: r0->field_2b = r1
    //     0x6a03b4: stur            w1, [x0, #0x2b]
    // 0x6a03b8: r1 = const [0x64, 0x69, 0x6e, 0x78, 0x82, 0x87, 0x8c, 0x96, 0xa0, 0xaa, 0xb4, 0xc8, 0xbe, 0xd2]
    //     0x6a03b8: add             x1, PP, #0x28, lsl #12  ; [pp+0x287a0] List<int>(14)
    //     0x6a03bc: ldr             x1, [x1, #0x7a0]
    // 0x6a03c0: StoreField: r0->field_f = r1
    //     0x6a03c0: stur            w1, [x0, #0xf]
    // 0x6a03c4: r3 = false
    //     0x6a03c4: add             x3, NULL, #0x30  ; false
    // 0x6a03c8: StoreField: r0->field_27 = r3
    //     0x6a03c8: stur            w3, [x0, #0x27]
    // 0x6a03cc: r1 = Instance_UpgradeDisplayMode
    //     0x6a03cc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26300] Obj!UpgradeDisplayMode@85e861
    //     0x6a03d0: ldr             x1, [x1, #0x300]
    // 0x6a03d4: StoreField: r0->field_2f = r1
    //     0x6a03d4: stur            w1, [x0, #0x2f]
    // 0x6a03d8: StoreField: r0->field_33 = r3
    //     0x6a03d8: stur            w3, [x0, #0x33]
    // 0x6a03dc: ldur            x2, [fp, #-0x58]
    // 0x6a03e0: r1 = Function '<anonymous closure>':.
    //     0x6a03e0: add             x1, PP, #0x28, lsl #12  ; [pp+0x287a8] AnonymousClosure: (0x6a25a0), in [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::build (0x6c2c88)
    //     0x6a03e4: ldr             x1, [x1, #0x7a8]
    // 0x6a03e8: r0 = AllocateClosure()
    //     0x6a03e8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a03ec: ldur            x2, [fp, #-0x90]
    // 0x6a03f0: ldur            x3, [fp, #-0x88]
    // 0x6a03f4: mov             x5, x0
    // 0x6a03f8: r1 = Null
    //     0x6a03f8: mov             x1, NULL
    // 0x6a03fc: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a03fc: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a0400: r0 = IdleFragment()
    //     0x6a0400: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0404: ldur            x1, [fp, #-0x78]
    // 0x6a0408: ArrayStore: r1[6] = r0  ; List_4
    //     0x6a0408: add             x25, x1, #0x27
    //     0x6a040c: str             w0, [x25]
    //     0x6a0410: tbz             w0, #0, #0x6a042c
    //     0x6a0414: ldurb           w16, [x1, #-1]
    //     0x6a0418: ldurb           w17, [x0, #-1]
    //     0x6a041c: and             x16, x17, x16, lsr #2
    //     0x6a0420: tst             x16, HEAP, lsr #32
    //     0x6a0424: b.eq            #0x6a042c
    //     0x6a0428: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a042c: r0 = AutoBuyChip()
    //     0x6a042c: bl              #0x637a20  ; AllocateAutoBuyChipStub -> AutoBuyChip (size=0x18)
    // 0x6a0430: mov             x3, x0
    // 0x6a0434: r0 = "Auto"
    //     0x6a0434: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b8] "Auto"
    //     0x6a0438: ldr             x0, [x0, #0x6b8]
    // 0x6a043c: stur            x3, [fp, #-0x50]
    // 0x6a0440: StoreField: r3->field_b = r0
    //     0x6a0440: stur            w0, [x3, #0xb]
    // 0x6a0444: r1 = Function '<anonymous closure>':.
    //     0x6a0444: add             x1, PP, #0x28, lsl #12  ; [pp+0x287b0] AnonymousClosure: (0x6a2560), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0448: ldr             x1, [x1, #0x7b0]
    // 0x6a044c: r2 = Null
    //     0x6a044c: mov             x2, NULL
    // 0x6a0450: r0 = AllocateClosure()
    //     0x6a0450: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0454: mov             x1, x0
    // 0x6a0458: ldur            x0, [fp, #-0x50]
    // 0x6a045c: StoreField: r0->field_f = r1
    //     0x6a045c: stur            w1, [x0, #0xf]
    // 0x6a0460: r1 = Function '<anonymous closure>':.
    //     0x6a0460: add             x1, PP, #0x28, lsl #12  ; [pp+0x287b8] AnonymousClosure: (0x6a2510), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0464: ldr             x1, [x1, #0x7b8]
    // 0x6a0468: r2 = Null
    //     0x6a0468: mov             x2, NULL
    // 0x6a046c: r0 = AllocateClosure()
    //     0x6a046c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0470: mov             x1, x0
    // 0x6a0474: ldur            x0, [fp, #-0x50]
    // 0x6a0478: StoreField: r0->field_13 = r1
    //     0x6a0478: stur            w1, [x0, #0x13]
    // 0x6a047c: r0 = Padding()
    //     0x6a047c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6a0480: mov             x3, x0
    // 0x6a0484: r0 = Instance_EdgeInsets
    //     0x6a0484: add             x0, PP, #0x28, lsl #12  ; [pp+0x28690] Obj!EdgeInsets@8324f1
    //     0x6a0488: ldr             x0, [x0, #0x690]
    // 0x6a048c: stur            x3, [fp, #-0x70]
    // 0x6a0490: StoreField: r3->field_f = r0
    //     0x6a0490: stur            w0, [x3, #0xf]
    // 0x6a0494: ldur            x0, [fp, #-0x50]
    // 0x6a0498: StoreField: r3->field_b = r0
    //     0x6a0498: stur            w0, [x3, #0xb]
    // 0x6a049c: ldur            x2, [fp, #-0x58]
    // 0x6a04a0: r1 = Function '<anonymous closure>':.
    //     0x6a04a0: add             x1, PP, #0x28, lsl #12  ; [pp+0x287c0] AnonymousClosure: (0x6a24c4), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a04a4: ldr             x1, [x1, #0x7c0]
    // 0x6a04a8: r0 = AllocateClosure()
    //     0x6a04a8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a04ac: r16 = false
    //     0x6a04ac: add             x16, NULL, #0x30  ; false
    // 0x6a04b0: r30 = false
    //     0x6a04b0: add             lr, NULL, #0x30  ; false
    // 0x6a04b4: stp             lr, x16, [SP, #8]
    // 0x6a04b8: r16 = false
    //     0x6a04b8: add             x16, NULL, #0x30  ; false
    // 0x6a04bc: str             x16, [SP]
    // 0x6a04c0: ldur            x2, [fp, #-0x70]
    // 0x6a04c4: mov             x5, x0
    // 0x6a04c8: r1 = Null
    //     0x6a04c8: mov             x1, NULL
    // 0x6a04cc: r3 = "auto buy io"
    //     0x6a04cc: add             x3, PP, #0x28, lsl #12  ; [pp+0x287c8] "auto buy io"
    //     0x6a04d0: ldr             x3, [x3, #0x7c8]
    // 0x6a04d4: r4 = const [0, 0x7, 0x3, 0x4, drawBackground, 0x4, padding, 0x5, scrollToBottomOnUnlock, 0x6, null]
    //     0x6a04d4: add             x4, PP, #0x28, lsl #12  ; [pp+0x286a8] List(11) [0, 0x7, 0x3, 0x4, "drawBackground", 0x4, "padding", 0x5, "scrollToBottomOnUnlock", 0x6, Null]
    //     0x6a04d8: ldr             x4, [x4, #0x6a8]
    // 0x6a04dc: r0 = IdleFragment()
    //     0x6a04dc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a04e0: stur            x0, [fp, #-0x50]
    // 0x6a04e4: r0 = CurrencyCounter()
    //     0x6a04e4: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x6a04e8: mov             x3, x0
    // 0x6a04ec: r0 = "I/O"
    //     0x6a04ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x111e0] "I/O"
    //     0x6a04f0: ldr             x0, [x0, #0x1e0]
    // 0x6a04f4: stur            x3, [fp, #-0x70]
    // 0x6a04f8: StoreField: r3->field_b = r0
    //     0x6a04f8: stur            w0, [x3, #0xb]
    // 0x6a04fc: ldur            x2, [fp, #-0x58]
    // 0x6a0500: r1 = Function '<anonymous closure>':.
    //     0x6a0500: add             x1, PP, #0x28, lsl #12  ; [pp+0x287d0] AnonymousClosure: (0x6a241c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0504: ldr             x1, [x1, #0x7d0]
    // 0x6a0508: r0 = AllocateClosure()
    //     0x6a0508: bl              #0x826750  ; AllocateClosureStub
    // 0x6a050c: mov             x1, x0
    // 0x6a0510: ldur            x0, [fp, #-0x70]
    // 0x6a0514: StoreField: r0->field_f = r1
    //     0x6a0514: stur            w1, [x0, #0xf]
    // 0x6a0518: ldur            x2, [fp, #-0x58]
    // 0x6a051c: r1 = Function '<anonymous closure>':.
    //     0x6a051c: add             x1, PP, #0x28, lsl #12  ; [pp+0x287d8] AnonymousClosure: (0x6a2374), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0520: ldr             x1, [x1, #0x7d8]
    // 0x6a0524: r0 = AllocateClosure()
    //     0x6a0524: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0528: mov             x1, x0
    // 0x6a052c: ldur            x0, [fp, #-0x70]
    // 0x6a0530: StoreField: r0->field_13 = r1
    //     0x6a0530: stur            w1, [x0, #0x13]
    // 0x6a0534: r1 = Function '<anonymous closure>':.
    //     0x6a0534: add             x1, PP, #0x28, lsl #12  ; [pp+0x287e0] AnonymousClosure: (0x6a2368), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0538: ldr             x1, [x1, #0x7e0]
    // 0x6a053c: r2 = Null
    //     0x6a053c: mov             x2, NULL
    // 0x6a0540: r0 = AllocateClosure()
    //     0x6a0540: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0544: mov             x1, x0
    // 0x6a0548: ldur            x0, [fp, #-0x70]
    // 0x6a054c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a054c: stur            w1, [x0, #0x17]
    // 0x6a0550: ldur            x1, [fp, #-0x50]
    // 0x6a0554: StoreField: r0->field_1b = r1
    //     0x6a0554: stur            w1, [x0, #0x1b]
    // 0x6a0558: r2 = false
    //     0x6a0558: add             x2, NULL, #0x30  ; false
    // 0x6a055c: StoreField: r0->field_1f = r2
    //     0x6a055c: stur            w2, [x0, #0x1f]
    // 0x6a0560: ldur            x3, [fp, #-8]
    // 0x6a0564: LoadField: r4 = r3->field_2b
    //     0x6a0564: ldur            w4, [x3, #0x2b]
    // 0x6a0568: DecompressPointer r4
    //     0x6a0568: add             x4, x4, HEAP, lsl #32
    // 0x6a056c: stur            x4, [fp, #-0xa0]
    // 0x6a0570: LoadField: r5 = r3->field_37
    //     0x6a0570: ldur            w5, [x3, #0x37]
    // 0x6a0574: DecompressPointer r5
    //     0x6a0574: add             x5, x5, HEAP, lsl #32
    // 0x6a0578: stur            x5, [fp, #-0x98]
    // 0x6a057c: LoadField: r6 = r3->field_4b
    //     0x6a057c: ldur            w6, [x3, #0x4b]
    // 0x6a0580: DecompressPointer r6
    //     0x6a0580: add             x6, x6, HEAP, lsl #32
    // 0x6a0584: stur            x6, [fp, #-0x90]
    // 0x6a0588: LoadField: r7 = r3->field_47
    //     0x6a0588: ldur            w7, [x3, #0x47]
    // 0x6a058c: DecompressPointer r7
    //     0x6a058c: add             x7, x7, HEAP, lsl #32
    // 0x6a0590: stur            x7, [fp, #-0x88]
    // 0x6a0594: LoadField: r8 = r3->field_53
    //     0x6a0594: ldur            w8, [x3, #0x53]
    // 0x6a0598: DecompressPointer r8
    //     0x6a0598: add             x8, x8, HEAP, lsl #32
    // 0x6a059c: stur            x8, [fp, #-0x80]
    // 0x6a05a0: LoadField: r9 = r3->field_93
    //     0x6a05a0: ldur            w9, [x3, #0x93]
    // 0x6a05a4: DecompressPointer r9
    //     0x6a05a4: add             x9, x9, HEAP, lsl #32
    // 0x6a05a8: stur            x9, [fp, #-0x50]
    // 0x6a05ac: r1 = <Chapter14Stat>
    //     0x6a05ac: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a05b0: ldr             x1, [x1, #0xf60]
    // 0x6a05b4: r0 = GeneratorGroup()
    //     0x6a05b4: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6a05b8: mov             x3, x0
    // 0x6a05bc: ldur            x0, [fp, #-0x98]
    // 0x6a05c0: stur            x3, [fp, #-0xa8]
    // 0x6a05c4: StoreField: r3->field_1f = r0
    //     0x6a05c4: stur            w0, [x3, #0x1f]
    // 0x6a05c8: ldur            x0, [fp, #-0x48]
    // 0x6a05cc: StoreField: r3->field_23 = r0
    //     0x6a05cc: stur            w0, [x3, #0x23]
    // 0x6a05d0: ldur            x4, [fp, #-0x68]
    // 0x6a05d4: StoreField: r3->field_27 = r4
    //     0x6a05d4: stur            w4, [x3, #0x27]
    // 0x6a05d8: ldur            x1, [fp, #-0x90]
    // 0x6a05dc: StoreField: r3->field_2b = r1
    //     0x6a05dc: stur            w1, [x3, #0x2b]
    // 0x6a05e0: ldur            x1, [fp, #-0x88]
    // 0x6a05e4: StoreField: r3->field_2f = r1
    //     0x6a05e4: stur            w1, [x3, #0x2f]
    // 0x6a05e8: ldur            x1, [fp, #-0x80]
    // 0x6a05ec: StoreField: r3->field_33 = r1
    //     0x6a05ec: stur            w1, [x3, #0x33]
    // 0x6a05f0: r1 = Function '<anonymous closure>':.
    //     0x6a05f0: add             x1, PP, #0x28, lsl #12  ; [pp+0x287e8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x6a05f4: ldr             x1, [x1, #0x7e8]
    // 0x6a05f8: r2 = Null
    //     0x6a05f8: mov             x2, NULL
    // 0x6a05fc: r0 = AllocateClosure()
    //     0x6a05fc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0600: mov             x1, x0
    // 0x6a0604: ldur            x0, [fp, #-0xa8]
    // 0x6a0608: StoreField: r0->field_3b = r1
    //     0x6a0608: stur            w1, [x0, #0x3b]
    // 0x6a060c: ldur            x3, [fp, #-0x20]
    // 0x6a0610: StoreField: r0->field_43 = r3
    //     0x6a0610: stur            w3, [x0, #0x43]
    // 0x6a0614: ldur            x4, [fp, #-0x18]
    // 0x6a0618: StoreField: r0->field_47 = r4
    //     0x6a0618: stur            w4, [x0, #0x47]
    // 0x6a061c: ldur            x5, [fp, #-0x28]
    // 0x6a0620: StoreField: r0->field_5b = r5
    //     0x6a0620: stur            w5, [x0, #0x5b]
    // 0x6a0624: r1 = Function '<anonymous closure>':.
    //     0x6a0624: add             x1, PP, #0x28, lsl #12  ; [pp+0x287f0] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a0628: ldr             x1, [x1, #0x7f0]
    // 0x6a062c: r2 = Null
    //     0x6a062c: mov             x2, NULL
    // 0x6a0630: r0 = AllocateClosure()
    //     0x6a0630: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0634: mov             x1, x0
    // 0x6a0638: ldur            x0, [fp, #-0xa8]
    // 0x6a063c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a063c: stur            w1, [x0, #0x17]
    // 0x6a0640: r1 = Function '<anonymous closure>':.
    //     0x6a0640: add             x1, PP, #0x28, lsl #12  ; [pp+0x287f8] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a0644: ldr             x1, [x1, #0x7f8]
    // 0x6a0648: r2 = Null
    //     0x6a0648: mov             x2, NULL
    // 0x6a064c: r0 = AllocateClosure()
    //     0x6a064c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0650: mov             x1, x0
    // 0x6a0654: ldur            x0, [fp, #-0xa8]
    // 0x6a0658: StoreField: r0->field_1b = r1
    //     0x6a0658: stur            w1, [x0, #0x1b]
    // 0x6a065c: ldur            x3, [fp, #-0x30]
    // 0x6a0660: StoreField: r0->field_57 = r3
    //     0x6a0660: stur            w3, [x0, #0x57]
    // 0x6a0664: r1 = const [0x4, 0x5, 0x6, 0x7]
    //     0x6a0664: add             x1, PP, #0x28, lsl #12  ; [pp+0x28800] List<int>(4)
    //     0x6a0668: ldr             x1, [x1, #0x800]
    // 0x6a066c: StoreField: r0->field_53 = r1
    //     0x6a066c: stur            w1, [x0, #0x53]
    // 0x6a0670: ldur            x4, [fp, #-0x38]
    // 0x6a0674: StoreField: r0->field_6b = r4
    //     0x6a0674: stur            w4, [x0, #0x6b]
    // 0x6a0678: ldur            x1, [fp, #-0xa0]
    // 0x6a067c: StoreField: r0->field_4b = r1
    //     0x6a067c: stur            w1, [x0, #0x4b]
    // 0x6a0680: ldur            x1, [fp, #-0x70]
    // 0x6a0684: StoreField: r0->field_f = r1
    //     0x6a0684: stur            w1, [x0, #0xf]
    // 0x6a0688: ldur            x1, [fp, #-0x50]
    // 0x6a068c: StoreField: r0->field_67 = r1
    //     0x6a068c: stur            w1, [x0, #0x67]
    // 0x6a0690: ldur            x5, [fp, #-0x10]
    // 0x6a0694: StoreField: r0->field_77 = r5
    //     0x6a0694: stur            w5, [x0, #0x77]
    // 0x6a0698: ldur            x6, [fp, #-0x40]
    // 0x6a069c: StoreField: r0->field_7b = r6
    //     0x6a069c: stur            w6, [x0, #0x7b]
    // 0x6a06a0: r7 = "Chapter 14 Generators 2"
    //     0x6a06a0: add             x7, PP, #0x28, lsl #12  ; [pp+0x28808] "Chapter 14 Generators 2"
    //     0x6a06a4: ldr             x7, [x7, #0x808]
    // 0x6a06a8: StoreField: r0->field_73 = r7
    //     0x6a06a8: stur            w7, [x0, #0x73]
    // 0x6a06ac: ldur            x2, [fp, #-0x58]
    // 0x6a06b0: r1 = Function '<anonymous closure>':.
    //     0x6a06b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28810] AnonymousClosure: (0x6a22c0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a06b4: ldr             x1, [x1, #0x810]
    // 0x6a06b8: r0 = AllocateClosure()
    //     0x6a06b8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a06bc: r16 = false
    //     0x6a06bc: add             x16, NULL, #0x30  ; false
    // 0x6a06c0: str             x16, [SP]
    // 0x6a06c4: ldur            x2, [fp, #-0xa8]
    // 0x6a06c8: mov             x5, x0
    // 0x6a06cc: r1 = Null
    //     0x6a06cc: mov             x1, NULL
    // 0x6a06d0: r3 = "Chapter 14 Generators 2"
    //     0x6a06d0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28808] "Chapter 14 Generators 2"
    //     0x6a06d4: ldr             x3, [x3, #0x808]
    // 0x6a06d8: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6a06d8: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6a06dc: ldr             x4, [x4, #0xf0]
    // 0x6a06e0: r0 = IdleFragment()
    //     0x6a06e0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a06e4: ldur            x1, [fp, #-0x78]
    // 0x6a06e8: ArrayStore: r1[7] = r0  ; List_4
    //     0x6a06e8: add             x25, x1, #0x2b
    //     0x6a06ec: str             w0, [x25]
    //     0x6a06f0: tbz             w0, #0, #0x6a070c
    //     0x6a06f4: ldurb           w16, [x1, #-1]
    //     0x6a06f8: ldurb           w17, [x0, #-1]
    //     0x6a06fc: and             x16, x17, x16, lsr #2
    //     0x6a0700: tst             x16, HEAP, lsr #32
    //     0x6a0704: b.eq            #0x6a070c
    //     0x6a0708: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a070c: ldur            x2, [fp, #-8]
    // 0x6a0710: LoadField: r0 = r2->field_2b
    //     0x6a0710: ldur            w0, [x2, #0x2b]
    // 0x6a0714: DecompressPointer r0
    //     0x6a0714: add             x0, x0, HEAP, lsl #32
    // 0x6a0718: stur            x0, [fp, #-0x98]
    // 0x6a071c: LoadField: r3 = r2->field_37
    //     0x6a071c: ldur            w3, [x2, #0x37]
    // 0x6a0720: DecompressPointer r3
    //     0x6a0720: add             x3, x3, HEAP, lsl #32
    // 0x6a0724: stur            x3, [fp, #-0x90]
    // 0x6a0728: LoadField: r4 = r2->field_4b
    //     0x6a0728: ldur            w4, [x2, #0x4b]
    // 0x6a072c: DecompressPointer r4
    //     0x6a072c: add             x4, x4, HEAP, lsl #32
    // 0x6a0730: stur            x4, [fp, #-0x88]
    // 0x6a0734: LoadField: r5 = r2->field_47
    //     0x6a0734: ldur            w5, [x2, #0x47]
    // 0x6a0738: DecompressPointer r5
    //     0x6a0738: add             x5, x5, HEAP, lsl #32
    // 0x6a073c: stur            x5, [fp, #-0x80]
    // 0x6a0740: LoadField: r6 = r2->field_53
    //     0x6a0740: ldur            w6, [x2, #0x53]
    // 0x6a0744: DecompressPointer r6
    //     0x6a0744: add             x6, x6, HEAP, lsl #32
    // 0x6a0748: stur            x6, [fp, #-0x70]
    // 0x6a074c: LoadField: r7 = r2->field_93
    //     0x6a074c: ldur            w7, [x2, #0x93]
    // 0x6a0750: DecompressPointer r7
    //     0x6a0750: add             x7, x7, HEAP, lsl #32
    // 0x6a0754: stur            x7, [fp, #-0x50]
    // 0x6a0758: r1 = <Chapter14Stat>
    //     0x6a0758: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a075c: ldr             x1, [x1, #0xf60]
    // 0x6a0760: r0 = GeneratorGroup()
    //     0x6a0760: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6a0764: mov             x3, x0
    // 0x6a0768: ldur            x0, [fp, #-0x90]
    // 0x6a076c: stur            x3, [fp, #-0xa0]
    // 0x6a0770: StoreField: r3->field_1f = r0
    //     0x6a0770: stur            w0, [x3, #0x1f]
    // 0x6a0774: ldur            x0, [fp, #-0x48]
    // 0x6a0778: StoreField: r3->field_23 = r0
    //     0x6a0778: stur            w0, [x3, #0x23]
    // 0x6a077c: ldur            x4, [fp, #-0x68]
    // 0x6a0780: StoreField: r3->field_27 = r4
    //     0x6a0780: stur            w4, [x3, #0x27]
    // 0x6a0784: ldur            x1, [fp, #-0x88]
    // 0x6a0788: StoreField: r3->field_2b = r1
    //     0x6a0788: stur            w1, [x3, #0x2b]
    // 0x6a078c: ldur            x1, [fp, #-0x80]
    // 0x6a0790: StoreField: r3->field_2f = r1
    //     0x6a0790: stur            w1, [x3, #0x2f]
    // 0x6a0794: ldur            x1, [fp, #-0x70]
    // 0x6a0798: StoreField: r3->field_33 = r1
    //     0x6a0798: stur            w1, [x3, #0x33]
    // 0x6a079c: r1 = Function '<anonymous closure>':.
    //     0x6a079c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28818] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6a07a0: ldr             x1, [x1, #0x818]
    // 0x6a07a4: r2 = Null
    //     0x6a07a4: mov             x2, NULL
    // 0x6a07a8: r0 = AllocateClosure()
    //     0x6a07a8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a07ac: mov             x1, x0
    // 0x6a07b0: ldur            x0, [fp, #-0xa0]
    // 0x6a07b4: StoreField: r0->field_3b = r1
    //     0x6a07b4: stur            w1, [x0, #0x3b]
    // 0x6a07b8: ldur            x3, [fp, #-0x20]
    // 0x6a07bc: StoreField: r0->field_43 = r3
    //     0x6a07bc: stur            w3, [x0, #0x43]
    // 0x6a07c0: ldur            x4, [fp, #-0x18]
    // 0x6a07c4: StoreField: r0->field_47 = r4
    //     0x6a07c4: stur            w4, [x0, #0x47]
    // 0x6a07c8: ldur            x5, [fp, #-0x28]
    // 0x6a07cc: StoreField: r0->field_5b = r5
    //     0x6a07cc: stur            w5, [x0, #0x5b]
    // 0x6a07d0: r1 = Function '<anonymous closure>':.
    //     0x6a07d0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28820] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a07d4: ldr             x1, [x1, #0x820]
    // 0x6a07d8: r2 = Null
    //     0x6a07d8: mov             x2, NULL
    // 0x6a07dc: r0 = AllocateClosure()
    //     0x6a07dc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a07e0: mov             x1, x0
    // 0x6a07e4: ldur            x0, [fp, #-0xa0]
    // 0x6a07e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a07e8: stur            w1, [x0, #0x17]
    // 0x6a07ec: r1 = Function '<anonymous closure>':.
    //     0x6a07ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28828] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a07f0: ldr             x1, [x1, #0x828]
    // 0x6a07f4: r2 = Null
    //     0x6a07f4: mov             x2, NULL
    // 0x6a07f8: r0 = AllocateClosure()
    //     0x6a07f8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a07fc: mov             x1, x0
    // 0x6a0800: ldur            x0, [fp, #-0xa0]
    // 0x6a0804: StoreField: r0->field_1b = r1
    //     0x6a0804: stur            w1, [x0, #0x1b]
    // 0x6a0808: ldur            x3, [fp, #-0x30]
    // 0x6a080c: StoreField: r0->field_57 = r3
    //     0x6a080c: stur            w3, [x0, #0x57]
    // 0x6a0810: r1 = const [0x68, 0x69, 0x6a, 0x6b]
    //     0x6a0810: add             x1, PP, #0x28, lsl #12  ; [pp+0x28830] List<int>(4)
    //     0x6a0814: ldr             x1, [x1, #0x830]
    // 0x6a0818: StoreField: r0->field_53 = r1
    //     0x6a0818: stur            w1, [x0, #0x53]
    // 0x6a081c: ldur            x4, [fp, #-0x38]
    // 0x6a0820: StoreField: r0->field_6b = r4
    //     0x6a0820: stur            w4, [x0, #0x6b]
    // 0x6a0824: ldur            x1, [fp, #-0x98]
    // 0x6a0828: StoreField: r0->field_4b = r1
    //     0x6a0828: stur            w1, [x0, #0x4b]
    // 0x6a082c: ldur            x1, [fp, #-0x50]
    // 0x6a0830: StoreField: r0->field_67 = r1
    //     0x6a0830: stur            w1, [x0, #0x67]
    // 0x6a0834: ldur            x5, [fp, #-0x10]
    // 0x6a0838: StoreField: r0->field_77 = r5
    //     0x6a0838: stur            w5, [x0, #0x77]
    // 0x6a083c: ldur            x6, [fp, #-0x40]
    // 0x6a0840: StoreField: r0->field_7b = r6
    //     0x6a0840: stur            w6, [x0, #0x7b]
    // 0x6a0844: r7 = "Chapter 14 Generator Generators 2"
    //     0x6a0844: add             x7, PP, #0x28, lsl #12  ; [pp+0x28838] "Chapter 14 Generator Generators 2"
    //     0x6a0848: ldr             x7, [x7, #0x838]
    // 0x6a084c: StoreField: r0->field_73 = r7
    //     0x6a084c: stur            w7, [x0, #0x73]
    // 0x6a0850: ldur            x2, [fp, #-0x58]
    // 0x6a0854: r1 = Function '<anonymous closure>':.
    //     0x6a0854: add             x1, PP, #0x28, lsl #12  ; [pp+0x28840] AnonymousClosure: (0x6a2274), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0858: ldr             x1, [x1, #0x840]
    // 0x6a085c: r0 = AllocateClosure()
    //     0x6a085c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0860: r16 = false
    //     0x6a0860: add             x16, NULL, #0x30  ; false
    // 0x6a0864: str             x16, [SP]
    // 0x6a0868: ldur            x2, [fp, #-0xa0]
    // 0x6a086c: mov             x5, x0
    // 0x6a0870: r1 = Null
    //     0x6a0870: mov             x1, NULL
    // 0x6a0874: r3 = "Chapter 14 Generator Generators 2"
    //     0x6a0874: add             x3, PP, #0x28, lsl #12  ; [pp+0x28838] "Chapter 14 Generator Generators 2"
    //     0x6a0878: ldr             x3, [x3, #0x838]
    // 0x6a087c: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6a087c: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6a0880: ldr             x4, [x4, #0xf0]
    // 0x6a0884: r0 = IdleFragment()
    //     0x6a0884: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0888: ldur            x1, [fp, #-0x78]
    // 0x6a088c: ArrayStore: r1[8] = r0  ; List_4
    //     0x6a088c: add             x25, x1, #0x2f
    //     0x6a0890: str             w0, [x25]
    //     0x6a0894: tbz             w0, #0, #0x6a08b0
    //     0x6a0898: ldurb           w16, [x1, #-1]
    //     0x6a089c: ldurb           w17, [x0, #-1]
    //     0x6a08a0: and             x16, x17, x16, lsr #2
    //     0x6a08a4: tst             x16, HEAP, lsr #32
    //     0x6a08a8: b.eq            #0x6a08b0
    //     0x6a08ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a08b0: ldur            x2, [fp, #-8]
    // 0x6a08b4: LoadField: r0 = r2->field_37
    //     0x6a08b4: ldur            w0, [x2, #0x37]
    // 0x6a08b8: DecompressPointer r0
    //     0x6a08b8: add             x0, x0, HEAP, lsl #32
    // 0x6a08bc: stur            x0, [fp, #-0x70]
    // 0x6a08c0: LoadField: r3 = r2->field_3f
    //     0x6a08c0: ldur            w3, [x2, #0x3f]
    // 0x6a08c4: DecompressPointer r3
    //     0x6a08c4: add             x3, x3, HEAP, lsl #32
    // 0x6a08c8: stur            x3, [fp, #-0x50]
    // 0x6a08cc: r1 = <Chapter14Stat>
    //     0x6a08cc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a08d0: ldr             x1, [x1, #0xf60]
    // 0x6a08d4: r0 = QuestButton()
    //     0x6a08d4: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x6a08d8: mov             x2, x0
    // 0x6a08dc: ldur            x0, [fp, #-0x60]
    // 0x6a08e0: stur            x2, [fp, #-0x80]
    // 0x6a08e4: StoreField: r2->field_2f = r0
    //     0x6a08e4: stur            w0, [x2, #0x2f]
    // 0x6a08e8: ldur            x3, [fp, #-0x70]
    // 0x6a08ec: StoreField: r2->field_1b = r3
    //     0x6a08ec: stur            w3, [x2, #0x1b]
    // 0x6a08f0: r1 = Instance_IconData
    //     0x6a08f0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28848] Obj!IconData@830931
    //     0x6a08f4: ldr             x1, [x1, #0x848]
    // 0x6a08f8: StoreField: r2->field_1f = r1
    //     0x6a08f8: stur            w1, [x2, #0x1f]
    // 0x6a08fc: ldur            x4, [fp, #-0x50]
    // 0x6a0900: StoreField: r2->field_2b = r4
    //     0x6a0900: stur            w4, [x2, #0x2b]
    // 0x6a0904: r1 = 1
    //     0x6a0904: movz            x1, #0x1
    // 0x6a0908: StoreField: r2->field_23 = r1
    //     0x6a0908: stur            x1, [x2, #0x23]
    // 0x6a090c: r5 = Closure: (Chapter14Stat?) => String from Function 'humanName': static.
    //     0x6a090c: add             x5, PP, #0x28, lsl #12  ; [pp+0x28770] Closure: (Chapter14Stat?) => String from Function 'humanName': static. (0x248ed99c520)
    //     0x6a0910: ldr             x5, [x5, #0x770]
    // 0x6a0914: StoreField: r2->field_f = r5
    //     0x6a0914: stur            w5, [x2, #0xf]
    // 0x6a0918: r1 = const [Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>']
    //     0x6a0918: add             x1, PP, #0x28, lsl #12  ; [pp+0x28850] List<QuestLevel<Chapter14Stat>>(5)
    //     0x6a091c: ldr             x1, [x1, #0x850]
    // 0x6a0920: StoreField: r2->field_37 = r1
    //     0x6a0920: stur            w1, [x2, #0x37]
    // 0x6a0924: r6 = true
    //     0x6a0924: add             x6, NULL, #0x20  ; true
    // 0x6a0928: StoreField: r2->field_13 = r6
    //     0x6a0928: stur            w6, [x2, #0x13]
    // 0x6a092c: r1 = <Chapter14Stat>
    //     0x6a092c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a0930: ldr             x1, [x1, #0xf60]
    // 0x6a0934: r0 = QuestButton()
    //     0x6a0934: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x6a0938: mov             x3, x0
    // 0x6a093c: ldur            x0, [fp, #-0x60]
    // 0x6a0940: stur            x3, [fp, #-0x88]
    // 0x6a0944: StoreField: r3->field_2f = r0
    //     0x6a0944: stur            w0, [x3, #0x2f]
    // 0x6a0948: ldur            x0, [fp, #-0x70]
    // 0x6a094c: StoreField: r3->field_1b = r0
    //     0x6a094c: stur            w0, [x3, #0x1b]
    // 0x6a0950: r0 = Instance_IconData
    //     0x6a0950: add             x0, PP, #0x28, lsl #12  ; [pp+0x28858] Obj!IconData@830911
    //     0x6a0954: ldr             x0, [x0, #0x858]
    // 0x6a0958: StoreField: r3->field_1f = r0
    //     0x6a0958: stur            w0, [x3, #0x1f]
    // 0x6a095c: ldur            x0, [fp, #-0x50]
    // 0x6a0960: StoreField: r3->field_2b = r0
    //     0x6a0960: stur            w0, [x3, #0x2b]
    // 0x6a0964: r0 = 2
    //     0x6a0964: movz            x0, #0x2
    // 0x6a0968: StoreField: r3->field_23 = r0
    //     0x6a0968: stur            x0, [x3, #0x23]
    // 0x6a096c: r4 = Closure: (Chapter14Stat?) => String from Function 'humanName': static.
    //     0x6a096c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28770] Closure: (Chapter14Stat?) => String from Function 'humanName': static. (0x248ed99c520)
    //     0x6a0970: ldr             x4, [x4, #0x770]
    // 0x6a0974: StoreField: r3->field_f = r4
    //     0x6a0974: stur            w4, [x3, #0xf]
    // 0x6a0978: r1 = const [Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>', Instance of 'QuestLevel<Chapter14Stat>']
    //     0x6a0978: add             x1, PP, #0x28, lsl #12  ; [pp+0x28860] List<QuestLevel<Chapter14Stat>>(4)
    //     0x6a097c: ldr             x1, [x1, #0x860]
    // 0x6a0980: StoreField: r3->field_37 = r1
    //     0x6a0980: stur            w1, [x3, #0x37]
    // 0x6a0984: r5 = true
    //     0x6a0984: add             x5, NULL, #0x20  ; true
    // 0x6a0988: StoreField: r3->field_13 = r5
    //     0x6a0988: stur            w5, [x3, #0x13]
    // 0x6a098c: r1 = Null
    //     0x6a098c: mov             x1, NULL
    // 0x6a0990: r2 = 4
    //     0x6a0990: movz            x2, #0x4
    // 0x6a0994: r0 = AllocateArray()
    //     0x6a0994: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a0998: mov             x2, x0
    // 0x6a099c: ldur            x0, [fp, #-0x80]
    // 0x6a09a0: stur            x2, [fp, #-0x50]
    // 0x6a09a4: StoreField: r2->field_f = r0
    //     0x6a09a4: stur            w0, [x2, #0xf]
    // 0x6a09a8: ldur            x0, [fp, #-0x88]
    // 0x6a09ac: StoreField: r2->field_13 = r0
    //     0x6a09ac: stur            w0, [x2, #0x13]
    // 0x6a09b0: r1 = <Widget>
    //     0x6a09b0: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a09b4: r0 = AllocateGrowableArray()
    //     0x6a09b4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a09b8: mov             x1, x0
    // 0x6a09bc: ldur            x0, [fp, #-0x50]
    // 0x6a09c0: stur            x1, [fp, #-0x60]
    // 0x6a09c4: StoreField: r1->field_f = r0
    //     0x6a09c4: stur            w0, [x1, #0xf]
    // 0x6a09c8: r0 = 4
    //     0x6a09c8: movz            x0, #0x4
    // 0x6a09cc: StoreField: r1->field_b = r0
    //     0x6a09cc: stur            w0, [x1, #0xb]
    // 0x6a09d0: r0 = Column()
    //     0x6a09d0: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6a09d4: mov             x1, x0
    // 0x6a09d8: r0 = Instance_Axis
    //     0x6a09d8: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6a09dc: stur            x1, [fp, #-0x50]
    // 0x6a09e0: StoreField: r1->field_f = r0
    //     0x6a09e0: stur            w0, [x1, #0xf]
    // 0x6a09e4: r2 = Instance_MainAxisAlignment
    //     0x6a09e4: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6a09e8: ldr             x2, [x2, #0x200]
    // 0x6a09ec: StoreField: r1->field_13 = r2
    //     0x6a09ec: stur            w2, [x1, #0x13]
    // 0x6a09f0: r3 = Instance_MainAxisSize
    //     0x6a09f0: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6a09f4: ldr             x3, [x3, #0x70]
    // 0x6a09f8: ArrayStore: r1[0] = r3  ; List_4
    //     0x6a09f8: stur            w3, [x1, #0x17]
    // 0x6a09fc: r4 = Instance_CrossAxisAlignment
    //     0x6a09fc: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6a0a00: ldr             x4, [x4, #0x78]
    // 0x6a0a04: StoreField: r1->field_1b = r4
    //     0x6a0a04: stur            w4, [x1, #0x1b]
    // 0x6a0a08: r5 = Instance_VerticalDirection
    //     0x6a0a08: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6a0a0c: ldr             x5, [x5, #0x1e8]
    // 0x6a0a10: StoreField: r1->field_23 = r5
    //     0x6a0a10: stur            w5, [x1, #0x23]
    // 0x6a0a14: r6 = Instance_Clip
    //     0x6a0a14: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6a0a18: ldr             x6, [x6, #0x1b0]
    // 0x6a0a1c: StoreField: r1->field_2b = r6
    //     0x6a0a1c: stur            w6, [x1, #0x2b]
    // 0x6a0a20: StoreField: r1->field_2f = rZR
    //     0x6a0a20: stur            xzr, [x1, #0x2f]
    // 0x6a0a24: ldur            x7, [fp, #-0x60]
    // 0x6a0a28: StoreField: r1->field_b = r7
    //     0x6a0a28: stur            w7, [x1, #0xb]
    // 0x6a0a2c: r0 = Padding()
    //     0x6a0a2c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6a0a30: mov             x3, x0
    // 0x6a0a34: r0 = Instance_EdgeInsets
    //     0x6a0a34: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a08] Obj!EdgeInsets@831da1
    //     0x6a0a38: ldr             x0, [x0, #0xa08]
    // 0x6a0a3c: stur            x3, [fp, #-0x60]
    // 0x6a0a40: StoreField: r3->field_f = r0
    //     0x6a0a40: stur            w0, [x3, #0xf]
    // 0x6a0a44: ldur            x0, [fp, #-0x50]
    // 0x6a0a48: StoreField: r3->field_b = r0
    //     0x6a0a48: stur            w0, [x3, #0xb]
    // 0x6a0a4c: ldur            x2, [fp, #-0x58]
    // 0x6a0a50: r1 = Function '<anonymous closure>':.
    //     0x6a0a50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28868] AnonymousClosure: (0x6a2228), in [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::build (0x6c2c88)
    //     0x6a0a54: ldr             x1, [x1, #0x868]
    // 0x6a0a58: r0 = AllocateClosure()
    //     0x6a0a58: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0a5c: ldur            x2, [fp, #-0x60]
    // 0x6a0a60: mov             x5, x0
    // 0x6a0a64: r1 = Null
    //     0x6a0a64: mov             x1, NULL
    // 0x6a0a68: r3 = "Chapter 14 Quests 1"
    //     0x6a0a68: add             x3, PP, #0x28, lsl #12  ; [pp+0x28870] "Chapter 14 Quests 1"
    //     0x6a0a6c: ldr             x3, [x3, #0x870]
    // 0x6a0a70: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a0a70: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a0a74: r0 = IdleFragment()
    //     0x6a0a74: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0a78: ldur            x1, [fp, #-0x78]
    // 0x6a0a7c: ArrayStore: r1[9] = r0  ; List_4
    //     0x6a0a7c: add             x25, x1, #0x33
    //     0x6a0a80: str             w0, [x25]
    //     0x6a0a84: tbz             w0, #0, #0x6a0aa0
    //     0x6a0a88: ldurb           w16, [x1, #-1]
    //     0x6a0a8c: ldurb           w17, [x0, #-1]
    //     0x6a0a90: and             x16, x17, x16, lsr #2
    //     0x6a0a94: tst             x16, HEAP, lsr #32
    //     0x6a0a98: b.eq            #0x6a0aa0
    //     0x6a0a9c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a0aa0: ldur            x0, [fp, #-8]
    // 0x6a0aa4: LoadField: r3 = r0->field_37
    //     0x6a0aa4: ldur            w3, [x0, #0x37]
    // 0x6a0aa8: DecompressPointer r3
    //     0x6a0aa8: add             x3, x3, HEAP, lsl #32
    // 0x6a0aac: stur            x3, [fp, #-0x50]
    // 0x6a0ab0: r1 = Function '<anonymous closure>':.
    //     0x6a0ab0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28878] AnonymousClosure: (0x6a221c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0ab4: ldr             x1, [x1, #0x878]
    // 0x6a0ab8: r2 = Null
    //     0x6a0ab8: mov             x2, NULL
    // 0x6a0abc: r0 = AllocateClosure()
    //     0x6a0abc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0ac0: r1 = <Chapter14Stat>
    //     0x6a0ac0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a0ac4: ldr             x1, [x1, #0xf60]
    // 0x6a0ac8: stur            x0, [fp, #-0x60]
    // 0x6a0acc: r0 = PrestigeButton()
    //     0x6a0acc: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6a0ad0: mov             x3, x0
    // 0x6a0ad4: ldur            x0, [fp, #-0x60]
    // 0x6a0ad8: stur            x3, [fp, #-0x70]
    // 0x6a0adc: StoreField: r3->field_1f = r0
    //     0x6a0adc: stur            w0, [x3, #0x1f]
    // 0x6a0ae0: r0 = Instance_Chapter14Stat
    //     0x6a0ae0: add             x0, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a0ae4: ldr             x0, [x0, #0x1e8]
    // 0x6a0ae8: StoreField: r3->field_1b = r0
    //     0x6a0ae8: stur            w0, [x3, #0x1b]
    // 0x6a0aec: ldur            x2, [fp, #-8]
    // 0x6a0af0: r1 = Function 'getOptimizePoints':.
    //     0x6a0af0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28880] AnonymousClosure: (0x54e994), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getOptimizePoints (0x54e89c)
    //     0x6a0af4: ldr             x1, [x1, #0x880]
    // 0x6a0af8: r0 = AllocateClosure()
    //     0x6a0af8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0afc: mov             x1, x0
    // 0x6a0b00: ldur            x0, [fp, #-0x70]
    // 0x6a0b04: StoreField: r0->field_2f = r1
    //     0x6a0b04: stur            w1, [x0, #0x2f]
    // 0x6a0b08: ldur            x2, [fp, #-8]
    // 0x6a0b0c: r1 = Function 'applyOptimize':.
    //     0x6a0b0c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28888] AnonymousClosure: (0x6a20ac), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyOptimize (0x6a20e4)
    //     0x6a0b10: ldr             x1, [x1, #0x888]
    // 0x6a0b14: r0 = AllocateClosure()
    //     0x6a0b14: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0b18: mov             x1, x0
    // 0x6a0b1c: ldur            x0, [fp, #-0x70]
    // 0x6a0b20: StoreField: r0->field_33 = r1
    //     0x6a0b20: stur            w1, [x0, #0x33]
    // 0x6a0b24: ldur            x1, [fp, #-0x50]
    // 0x6a0b28: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a0b28: stur            w1, [x0, #0x17]
    // 0x6a0b2c: r3 = Closure: (Chapter14Stat?) => String from Function 'humanName': static.
    //     0x6a0b2c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28770] Closure: (Chapter14Stat?) => String from Function 'humanName': static. (0x248ed99c520)
    //     0x6a0b30: ldr             x3, [x3, #0x770]
    // 0x6a0b34: StoreField: r0->field_43 = r3
    //     0x6a0b34: stur            w3, [x0, #0x43]
    // 0x6a0b38: r1 = Function '<anonymous closure>':.
    //     0x6a0b38: add             x1, PP, #0x28, lsl #12  ; [pp+0x28890] AnonymousClosure: (0x6a20a0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0b3c: ldr             x1, [x1, #0x890]
    // 0x6a0b40: r2 = Null
    //     0x6a0b40: mov             x2, NULL
    // 0x6a0b44: r0 = AllocateClosure()
    //     0x6a0b44: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0b48: mov             x1, x0
    // 0x6a0b4c: ldur            x0, [fp, #-0x70]
    // 0x6a0b50: StoreField: r0->field_23 = r1
    //     0x6a0b50: stur            w1, [x0, #0x23]
    // 0x6a0b54: r3 = "everything above"
    //     0x6a0b54: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x6a0b58: ldr             x3, [x3, #0x1b0]
    // 0x6a0b5c: StoreField: r0->field_3f = r3
    //     0x6a0b5c: stur            w3, [x0, #0x3f]
    // 0x6a0b60: r4 = false
    //     0x6a0b60: add             x4, NULL, #0x30  ; false
    // 0x6a0b64: StoreField: r0->field_f = r4
    //     0x6a0b64: stur            w4, [x0, #0xf]
    // 0x6a0b68: StoreField: r0->field_4f = r4
    //     0x6a0b68: stur            w4, [x0, #0x4f]
    // 0x6a0b6c: r5 = true
    //     0x6a0b6c: add             x5, NULL, #0x20  ; true
    // 0x6a0b70: StoreField: r0->field_2b = r5
    //     0x6a0b70: stur            w5, [x0, #0x2b]
    // 0x6a0b74: StoreField: r0->field_53 = r4
    //     0x6a0b74: stur            w4, [x0, #0x53]
    // 0x6a0b78: StoreField: r0->field_5b = r5
    //     0x6a0b78: stur            w5, [x0, #0x5b]
    // 0x6a0b7c: r6 = "Gain"
    //     0x6a0b7c: add             x6, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6a0b80: ldr             x6, [x6, #0x1b8]
    // 0x6a0b84: StoreField: r0->field_5f = r6
    //     0x6a0b84: stur            w6, [x0, #0x5f]
    // 0x6a0b88: ldur            x2, [fp, #-0x58]
    // 0x6a0b8c: r1 = Function '<anonymous closure>':.
    //     0x6a0b8c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28898] AnonymousClosure: (0x6a2048), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0b90: ldr             x1, [x1, #0x898]
    // 0x6a0b94: r0 = AllocateClosure()
    //     0x6a0b94: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0b98: ldur            x2, [fp, #-0x70]
    // 0x6a0b9c: mov             x5, x0
    // 0x6a0ba0: r1 = Null
    //     0x6a0ba0: mov             x1, NULL
    // 0x6a0ba4: r3 = "Chapter 14 Prestige 2"
    //     0x6a0ba4: add             x3, PP, #0x28, lsl #12  ; [pp+0x288a0] "Chapter 14 Prestige 2"
    //     0x6a0ba8: ldr             x3, [x3, #0x8a0]
    // 0x6a0bac: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a0bac: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a0bb0: r0 = IdleFragment()
    //     0x6a0bb0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0bb4: ldur            x1, [fp, #-0x78]
    // 0x6a0bb8: ArrayStore: r1[10] = r0  ; List_4
    //     0x6a0bb8: add             x25, x1, #0x37
    //     0x6a0bbc: str             w0, [x25]
    //     0x6a0bc0: tbz             w0, #0, #0x6a0bdc
    //     0x6a0bc4: ldurb           w16, [x1, #-1]
    //     0x6a0bc8: ldurb           w17, [x0, #-1]
    //     0x6a0bcc: and             x16, x17, x16, lsr #2
    //     0x6a0bd0: tst             x16, HEAP, lsr #32
    //     0x6a0bd4: b.eq            #0x6a0bdc
    //     0x6a0bd8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a0bdc: ldur            x2, [fp, #-8]
    // 0x6a0be0: LoadField: r0 = r2->field_37
    //     0x6a0be0: ldur            w0, [x2, #0x37]
    // 0x6a0be4: DecompressPointer r0
    //     0x6a0be4: add             x0, x0, HEAP, lsl #32
    // 0x6a0be8: stur            x0, [fp, #-0x50]
    // 0x6a0bec: r1 = <Chapter14Stat>
    //     0x6a0bec: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a0bf0: ldr             x1, [x1, #0xf60]
    // 0x6a0bf4: r0 = IntermissionButton()
    //     0x6a0bf4: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x6a0bf8: mov             x3, x0
    // 0x6a0bfc: ldur            x0, [fp, #-0x50]
    // 0x6a0c00: stur            x3, [fp, #-0x60]
    // 0x6a0c04: StoreField: r3->field_1b = r0
    //     0x6a0c04: stur            w0, [x3, #0x1b]
    // 0x6a0c08: r0 = Instance_Tuple2
    //     0x6a0c08: add             x0, PP, #0x28, lsl #12  ; [pp+0x288a8] Obj!Tuple2<Chapter14Stat, CustomNum>@826a51
    //     0x6a0c0c: ldr             x0, [x0, #0x8a8]
    // 0x6a0c10: StoreField: r3->field_1f = r0
    //     0x6a0c10: stur            w0, [x3, #0x1f]
    // 0x6a0c14: ldur            x2, [fp, #-0x58]
    // 0x6a0c18: r1 = Function '<anonymous closure>':.
    //     0x6a0c18: add             x1, PP, #0x28, lsl #12  ; [pp+0x288b0] AnonymousClosure: (0x6a1f58), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0c1c: ldr             x1, [x1, #0x8b0]
    // 0x6a0c20: r0 = AllocateClosure()
    //     0x6a0c20: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0c24: mov             x1, x0
    // 0x6a0c28: ldur            x0, [fp, #-0x60]
    // 0x6a0c2c: StoreField: r0->field_23 = r1
    //     0x6a0c2c: stur            w1, [x0, #0x23]
    // 0x6a0c30: r1 = Function '<anonymous closure>':.
    //     0x6a0c30: add             x1, PP, #0x28, lsl #12  ; [pp+0x288b8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x6a0c34: ldr             x1, [x1, #0x8b8]
    // 0x6a0c38: r2 = Null
    //     0x6a0c38: mov             x2, NULL
    // 0x6a0c3c: r0 = AllocateClosure()
    //     0x6a0c3c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0c40: mov             x1, x0
    // 0x6a0c44: ldur            x0, [fp, #-0x60]
    // 0x6a0c48: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a0c48: stur            w1, [x0, #0x17]
    // 0x6a0c4c: r1 = Function '<anonymous closure>':.
    //     0x6a0c4c: add             x1, PP, #0x28, lsl #12  ; [pp+0x288c0] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a0c50: ldr             x1, [x1, #0x8c0]
    // 0x6a0c54: r2 = Null
    //     0x6a0c54: mov             x2, NULL
    // 0x6a0c58: r0 = AllocateClosure()
    //     0x6a0c58: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0c5c: mov             x1, x0
    // 0x6a0c60: ldur            x0, [fp, #-0x60]
    // 0x6a0c64: StoreField: r0->field_f = r1
    //     0x6a0c64: stur            w1, [x0, #0xf]
    // 0x6a0c68: ldur            x2, [fp, #-0x58]
    // 0x6a0c6c: r1 = Function '<anonymous closure>':.
    //     0x6a0c6c: add             x1, PP, #0x28, lsl #12  ; [pp+0x288c8] AnonymousClosure: (0x6a1eac), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0c70: ldr             x1, [x1, #0x8c8]
    // 0x6a0c74: r0 = AllocateClosure()
    //     0x6a0c74: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0c78: ldur            x2, [fp, #-0x58]
    // 0x6a0c7c: r1 = Function '<anonymous closure>':.
    //     0x6a0c7c: add             x1, PP, #0x28, lsl #12  ; [pp+0x288d0] AnonymousClosure: (0x6a1dfc), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0c80: ldr             x1, [x1, #0x8d0]
    // 0x6a0c84: stur            x0, [fp, #-0x50]
    // 0x6a0c88: r0 = AllocateClosure()
    //     0x6a0c88: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0c8c: r16 = false
    //     0x6a0c8c: add             x16, NULL, #0x30  ; false
    // 0x6a0c90: ldur            lr, [fp, #-0x50]
    // 0x6a0c94: stp             lr, x16, [SP]
    // 0x6a0c98: ldur            x2, [fp, #-0x60]
    // 0x6a0c9c: mov             x5, x0
    // 0x6a0ca0: r1 = Null
    //     0x6a0ca0: mov             x1, NULL
    // 0x6a0ca4: r3 = "Chapter 14 Intermission 2"
    //     0x6a0ca4: add             x3, PP, #0x28, lsl #12  ; [pp+0x288d8] "Chapter 14 Intermission 2"
    //     0x6a0ca8: ldr             x3, [x3, #0x8d8]
    // 0x6a0cac: r4 = const [0, 0x6, 0x2, 0x4, generateMinimizedName, 0x5, scrollToBottomOnUnlock, 0x4, null]
    //     0x6a0cac: add             x4, PP, #0x26, lsl #12  ; [pp+0x260c0] List(9) [0, 0x6, 0x2, 0x4, "generateMinimizedName", 0x5, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6a0cb0: ldr             x4, [x4, #0xc0]
    // 0x6a0cb4: r0 = IdleFragment()
    //     0x6a0cb4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0cb8: ldur            x1, [fp, #-0x78]
    // 0x6a0cbc: ArrayStore: r1[11] = r0  ; List_4
    //     0x6a0cbc: add             x25, x1, #0x3b
    //     0x6a0cc0: str             w0, [x25]
    //     0x6a0cc4: tbz             w0, #0, #0x6a0ce0
    //     0x6a0cc8: ldurb           w16, [x1, #-1]
    //     0x6a0ccc: ldurb           w17, [x0, #-1]
    //     0x6a0cd0: and             x16, x17, x16, lsr #2
    //     0x6a0cd4: tst             x16, HEAP, lsr #32
    //     0x6a0cd8: b.eq            #0x6a0ce0
    //     0x6a0cdc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a0ce0: ldur            x0, [fp, #-8]
    // 0x6a0ce4: LoadField: r3 = r0->field_37
    //     0x6a0ce4: ldur            w3, [x0, #0x37]
    // 0x6a0ce8: DecompressPointer r3
    //     0x6a0ce8: add             x3, x3, HEAP, lsl #32
    // 0x6a0cec: stur            x3, [fp, #-0x50]
    // 0x6a0cf0: r1 = Function '<anonymous closure>':.
    //     0x6a0cf0: add             x1, PP, #0x28, lsl #12  ; [pp+0x288e0] AnonymousClosure: (0x6a1df0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0cf4: ldr             x1, [x1, #0x8e0]
    // 0x6a0cf8: r2 = Null
    //     0x6a0cf8: mov             x2, NULL
    // 0x6a0cfc: r0 = AllocateClosure()
    //     0x6a0cfc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0d00: r1 = <Chapter14Stat>
    //     0x6a0d00: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a0d04: ldr             x1, [x1, #0xf60]
    // 0x6a0d08: stur            x0, [fp, #-0x60]
    // 0x6a0d0c: r0 = PrestigeButton()
    //     0x6a0d0c: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6a0d10: mov             x3, x0
    // 0x6a0d14: ldur            x0, [fp, #-0x60]
    // 0x6a0d18: stur            x3, [fp, #-0x70]
    // 0x6a0d1c: StoreField: r3->field_1f = r0
    //     0x6a0d1c: stur            w0, [x3, #0x1f]
    // 0x6a0d20: r0 = Instance_Chapter14Stat
    //     0x6a0d20: add             x0, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x6a0d24: ldr             x0, [x0, #0x230]
    // 0x6a0d28: StoreField: r3->field_1b = r0
    //     0x6a0d28: stur            w0, [x3, #0x1b]
    // 0x6a0d2c: ldur            x2, [fp, #-8]
    // 0x6a0d30: r1 = Function 'getStabilityPoints':.
    //     0x6a0d30: add             x1, PP, #0x28, lsl #12  ; [pp+0x288e8] AnonymousClosure: (0x54e864), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getStabilityPoints (0x54e7d4)
    //     0x6a0d34: ldr             x1, [x1, #0x8e8]
    // 0x6a0d38: r0 = AllocateClosure()
    //     0x6a0d38: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0d3c: mov             x1, x0
    // 0x6a0d40: ldur            x0, [fp, #-0x70]
    // 0x6a0d44: StoreField: r0->field_2f = r1
    //     0x6a0d44: stur            w1, [x0, #0x2f]
    // 0x6a0d48: ldur            x2, [fp, #-8]
    // 0x6a0d4c: r1 = Function 'applyStability':.
    //     0x6a0d4c: add             x1, PP, #0x28, lsl #12  ; [pp+0x288f0] AnonymousClosure: (0x6a1598), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyStability (0x6a15d0)
    //     0x6a0d50: ldr             x1, [x1, #0x8f0]
    // 0x6a0d54: r0 = AllocateClosure()
    //     0x6a0d54: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0d58: mov             x1, x0
    // 0x6a0d5c: ldur            x0, [fp, #-0x70]
    // 0x6a0d60: StoreField: r0->field_33 = r1
    //     0x6a0d60: stur            w1, [x0, #0x33]
    // 0x6a0d64: ldur            x1, [fp, #-0x50]
    // 0x6a0d68: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a0d68: stur            w1, [x0, #0x17]
    // 0x6a0d6c: r3 = Closure: (Chapter14Stat?) => String from Function 'humanName': static.
    //     0x6a0d6c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28770] Closure: (Chapter14Stat?) => String from Function 'humanName': static. (0x248ed99c520)
    //     0x6a0d70: ldr             x3, [x3, #0x770]
    // 0x6a0d74: StoreField: r0->field_43 = r3
    //     0x6a0d74: stur            w3, [x0, #0x43]
    // 0x6a0d78: r1 = Function '<anonymous closure>':.
    //     0x6a0d78: add             x1, PP, #0x28, lsl #12  ; [pp+0x288f8] AnonymousClosure: (0x6a158c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0d7c: ldr             x1, [x1, #0x8f8]
    // 0x6a0d80: r2 = Null
    //     0x6a0d80: mov             x2, NULL
    // 0x6a0d84: r0 = AllocateClosure()
    //     0x6a0d84: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0d88: mov             x1, x0
    // 0x6a0d8c: ldur            x0, [fp, #-0x70]
    // 0x6a0d90: StoreField: r0->field_23 = r1
    //     0x6a0d90: stur            w1, [x0, #0x23]
    // 0x6a0d94: r1 = Function '<anonymous closure>':.
    //     0x6a0d94: add             x1, PP, #0x28, lsl #12  ; [pp+0x28900] AnonymousClosure: (0x6a1580), in [package:pretentious/data/Chapters/Chapter5GameState.dart] Chapter5GameState::build (0x6b8d34)
    //     0x6a0d98: ldr             x1, [x1, #0x900]
    // 0x6a0d9c: r2 = Null
    //     0x6a0d9c: mov             x2, NULL
    // 0x6a0da0: r0 = AllocateClosure()
    //     0x6a0da0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0da4: mov             x1, x0
    // 0x6a0da8: ldur            x0, [fp, #-0x70]
    // 0x6a0dac: StoreField: r0->field_3b = r1
    //     0x6a0dac: stur            w1, [x0, #0x3b]
    // 0x6a0db0: r1 = "everything above"
    //     0x6a0db0: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x6a0db4: ldr             x1, [x1, #0x1b0]
    // 0x6a0db8: StoreField: r0->field_3f = r1
    //     0x6a0db8: stur            w1, [x0, #0x3f]
    // 0x6a0dbc: r3 = false
    //     0x6a0dbc: add             x3, NULL, #0x30  ; false
    // 0x6a0dc0: StoreField: r0->field_f = r3
    //     0x6a0dc0: stur            w3, [x0, #0xf]
    // 0x6a0dc4: StoreField: r0->field_4f = r3
    //     0x6a0dc4: stur            w3, [x0, #0x4f]
    // 0x6a0dc8: r4 = true
    //     0x6a0dc8: add             x4, NULL, #0x20  ; true
    // 0x6a0dcc: StoreField: r0->field_2b = r4
    //     0x6a0dcc: stur            w4, [x0, #0x2b]
    // 0x6a0dd0: StoreField: r0->field_53 = r3
    //     0x6a0dd0: stur            w3, [x0, #0x53]
    // 0x6a0dd4: StoreField: r0->field_5b = r4
    //     0x6a0dd4: stur            w4, [x0, #0x5b]
    // 0x6a0dd8: r1 = "Gain"
    //     0x6a0dd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6a0ddc: ldr             x1, [x1, #0x1b8]
    // 0x6a0de0: StoreField: r0->field_5f = r1
    //     0x6a0de0: stur            w1, [x0, #0x5f]
    // 0x6a0de4: ldur            x2, [fp, #-0x58]
    // 0x6a0de8: r1 = Function '<anonymous closure>':.
    //     0x6a0de8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28908] AnonymousClosure: (0x6a1488), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0dec: ldr             x1, [x1, #0x908]
    // 0x6a0df0: r0 = AllocateClosure()
    //     0x6a0df0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0df4: r16 = false
    //     0x6a0df4: add             x16, NULL, #0x30  ; false
    // 0x6a0df8: str             x16, [SP]
    // 0x6a0dfc: ldur            x2, [fp, #-0x70]
    // 0x6a0e00: mov             x5, x0
    // 0x6a0e04: r1 = Null
    //     0x6a0e04: mov             x1, NULL
    // 0x6a0e08: r3 = "Chapter 14 Prestige 3"
    //     0x6a0e08: add             x3, PP, #0x28, lsl #12  ; [pp+0x28910] "Chapter 14 Prestige 3"
    //     0x6a0e0c: ldr             x3, [x3, #0x910]
    // 0x6a0e10: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x6a0e10: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x6a0e14: ldr             x4, [x4, #0xf0]
    // 0x6a0e18: r0 = IdleFragment()
    //     0x6a0e18: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0e1c: ldur            x1, [fp, #-0x78]
    // 0x6a0e20: ArrayStore: r1[12] = r0  ; List_4
    //     0x6a0e20: add             x25, x1, #0x3f
    //     0x6a0e24: str             w0, [x25]
    //     0x6a0e28: tbz             w0, #0, #0x6a0e44
    //     0x6a0e2c: ldurb           w16, [x1, #-1]
    //     0x6a0e30: ldurb           w17, [x0, #-1]
    //     0x6a0e34: and             x16, x17, x16, lsr #2
    //     0x6a0e38: tst             x16, HEAP, lsr #32
    //     0x6a0e3c: b.eq            #0x6a0e44
    //     0x6a0e40: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a0e44: ldur            x0, [fp, #-8]
    // 0x6a0e48: LoadField: r2 = r0->field_37
    //     0x6a0e48: ldur            w2, [x0, #0x37]
    // 0x6a0e4c: DecompressPointer r2
    //     0x6a0e4c: add             x2, x2, HEAP, lsl #32
    // 0x6a0e50: stur            x2, [fp, #-0x70]
    // 0x6a0e54: LoadField: r3 = r0->field_43
    //     0x6a0e54: ldur            w3, [x0, #0x43]
    // 0x6a0e58: DecompressPointer r3
    //     0x6a0e58: add             x3, x3, HEAP, lsl #32
    // 0x6a0e5c: stur            x3, [fp, #-0x60]
    // 0x6a0e60: LoadField: r4 = r0->field_8f
    //     0x6a0e60: ldur            w4, [x0, #0x8f]
    // 0x6a0e64: DecompressPointer r4
    //     0x6a0e64: add             x4, x4, HEAP, lsl #32
    // 0x6a0e68: stur            x4, [fp, #-0x50]
    // 0x6a0e6c: r1 = <Chapter14Stat>
    //     0x6a0e6c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a0e70: ldr             x1, [x1, #0xf60]
    // 0x6a0e74: r0 = UpgradeGroup()
    //     0x6a0e74: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6a0e78: mov             x3, x0
    // 0x6a0e7c: r0 = 2
    //     0x6a0e7c: movz            x0, #0x2
    // 0x6a0e80: stur            x3, [fp, #-0x80]
    // 0x6a0e84: StoreField: r3->field_13 = r0
    //     0x6a0e84: stur            x0, [x3, #0x13]
    // 0x6a0e88: ldur            x0, [fp, #-0x50]
    // 0x6a0e8c: StoreField: r3->field_1b = r0
    //     0x6a0e8c: stur            w0, [x3, #0x1b]
    // 0x6a0e90: ldur            x0, [fp, #-0x70]
    // 0x6a0e94: StoreField: r3->field_1f = r0
    //     0x6a0e94: stur            w0, [x3, #0x1f]
    // 0x6a0e98: ldur            x0, [fp, #-0x60]
    // 0x6a0e9c: StoreField: r3->field_23 = r0
    //     0x6a0e9c: stur            w0, [x3, #0x23]
    // 0x6a0ea0: r1 = Function '<anonymous closure>':.
    //     0x6a0ea0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28918] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a0ea4: ldr             x1, [x1, #0x918]
    // 0x6a0ea8: r2 = Null
    //     0x6a0ea8: mov             x2, NULL
    // 0x6a0eac: r0 = AllocateClosure()
    //     0x6a0eac: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0eb0: mov             x1, x0
    // 0x6a0eb4: ldur            x0, [fp, #-0x80]
    // 0x6a0eb8: StoreField: r0->field_2b = r1
    //     0x6a0eb8: stur            w1, [x0, #0x2b]
    // 0x6a0ebc: r1 = const [0x3e8, 0x3f2, 0x3fc, 0x406]
    //     0x6a0ebc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28920] List<int>(4)
    //     0x6a0ec0: ldr             x1, [x1, #0x920]
    // 0x6a0ec4: StoreField: r0->field_f = r1
    //     0x6a0ec4: stur            w1, [x0, #0xf]
    // 0x6a0ec8: r1 = true
    //     0x6a0ec8: add             x1, NULL, #0x20  ; true
    // 0x6a0ecc: StoreField: r0->field_27 = r1
    //     0x6a0ecc: stur            w1, [x0, #0x27]
    // 0x6a0ed0: r1 = Instance_UpgradeDisplayMode
    //     0x6a0ed0: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x6a0ed4: ldr             x1, [x1, #0x608]
    // 0x6a0ed8: StoreField: r0->field_2f = r1
    //     0x6a0ed8: stur            w1, [x0, #0x2f]
    // 0x6a0edc: r1 = false
    //     0x6a0edc: add             x1, NULL, #0x30  ; false
    // 0x6a0ee0: StoreField: r0->field_33 = r1
    //     0x6a0ee0: stur            w1, [x0, #0x33]
    // 0x6a0ee4: ldur            x2, [fp, #-0x58]
    // 0x6a0ee8: r1 = Function '<anonymous closure>':.
    //     0x6a0ee8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28928] AnonymousClosure: (0x6a143c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0eec: ldr             x1, [x1, #0x928]
    // 0x6a0ef0: r0 = AllocateClosure()
    //     0x6a0ef0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0ef4: ldur            x2, [fp, #-0x58]
    // 0x6a0ef8: r1 = Function '<anonymous closure>':.
    //     0x6a0ef8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28930] AnonymousClosure: (0x6a1368), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a0efc: ldr             x1, [x1, #0x930]
    // 0x6a0f00: stur            x0, [fp, #-0x50]
    // 0x6a0f04: r0 = AllocateClosure()
    //     0x6a0f04: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0f08: str             x0, [SP]
    // 0x6a0f0c: ldur            x2, [fp, #-0x80]
    // 0x6a0f10: ldur            x5, [fp, #-0x50]
    // 0x6a0f14: r1 = Null
    //     0x6a0f14: mov             x1, NULL
    // 0x6a0f18: r3 = "Chapter 14 Upgrades 3"
    //     0x6a0f18: add             x3, PP, #0x28, lsl #12  ; [pp+0x28938] "Chapter 14 Upgrades 3"
    //     0x6a0f1c: ldr             x3, [x3, #0x938]
    // 0x6a0f20: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6a0f20: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6a0f24: ldr             x4, [x4, #0x160]
    // 0x6a0f28: r0 = IdleFragment()
    //     0x6a0f28: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a0f2c: ldur            x1, [fp, #-0x78]
    // 0x6a0f30: ArrayStore: r1[13] = r0  ; List_4
    //     0x6a0f30: add             x25, x1, #0x43
    //     0x6a0f34: str             w0, [x25]
    //     0x6a0f38: tbz             w0, #0, #0x6a0f54
    //     0x6a0f3c: ldurb           w16, [x1, #-1]
    //     0x6a0f40: ldurb           w17, [x0, #-1]
    //     0x6a0f44: and             x16, x17, x16, lsr #2
    //     0x6a0f48: tst             x16, HEAP, lsr #32
    //     0x6a0f4c: b.eq            #0x6a0f54
    //     0x6a0f50: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a0f54: ldur            x0, [fp, #-8]
    // 0x6a0f58: LoadField: r2 = r0->field_2b
    //     0x6a0f58: ldur            w2, [x0, #0x2b]
    // 0x6a0f5c: DecompressPointer r2
    //     0x6a0f5c: add             x2, x2, HEAP, lsl #32
    // 0x6a0f60: stur            x2, [fp, #-0x90]
    // 0x6a0f64: LoadField: r3 = r0->field_37
    //     0x6a0f64: ldur            w3, [x0, #0x37]
    // 0x6a0f68: DecompressPointer r3
    //     0x6a0f68: add             x3, x3, HEAP, lsl #32
    // 0x6a0f6c: stur            x3, [fp, #-0x88]
    // 0x6a0f70: LoadField: r4 = r0->field_4b
    //     0x6a0f70: ldur            w4, [x0, #0x4b]
    // 0x6a0f74: DecompressPointer r4
    //     0x6a0f74: add             x4, x4, HEAP, lsl #32
    // 0x6a0f78: stur            x4, [fp, #-0x80]
    // 0x6a0f7c: LoadField: r5 = r0->field_47
    //     0x6a0f7c: ldur            w5, [x0, #0x47]
    // 0x6a0f80: DecompressPointer r5
    //     0x6a0f80: add             x5, x5, HEAP, lsl #32
    // 0x6a0f84: stur            x5, [fp, #-0x70]
    // 0x6a0f88: LoadField: r6 = r0->field_53
    //     0x6a0f88: ldur            w6, [x0, #0x53]
    // 0x6a0f8c: DecompressPointer r6
    //     0x6a0f8c: add             x6, x6, HEAP, lsl #32
    // 0x6a0f90: stur            x6, [fp, #-0x60]
    // 0x6a0f94: LoadField: r7 = r0->field_93
    //     0x6a0f94: ldur            w7, [x0, #0x93]
    // 0x6a0f98: DecompressPointer r7
    //     0x6a0f98: add             x7, x7, HEAP, lsl #32
    // 0x6a0f9c: stur            x7, [fp, #-0x50]
    // 0x6a0fa0: r1 = <Chapter14Stat>
    //     0x6a0fa0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a0fa4: ldr             x1, [x1, #0xf60]
    // 0x6a0fa8: r0 = GeneratorGroup()
    //     0x6a0fa8: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6a0fac: mov             x3, x0
    // 0x6a0fb0: ldur            x0, [fp, #-0x88]
    // 0x6a0fb4: stur            x3, [fp, #-0x98]
    // 0x6a0fb8: StoreField: r3->field_1f = r0
    //     0x6a0fb8: stur            w0, [x3, #0x1f]
    // 0x6a0fbc: ldur            x0, [fp, #-0x48]
    // 0x6a0fc0: StoreField: r3->field_23 = r0
    //     0x6a0fc0: stur            w0, [x3, #0x23]
    // 0x6a0fc4: ldur            x0, [fp, #-0x68]
    // 0x6a0fc8: StoreField: r3->field_27 = r0
    //     0x6a0fc8: stur            w0, [x3, #0x27]
    // 0x6a0fcc: ldur            x0, [fp, #-0x80]
    // 0x6a0fd0: StoreField: r3->field_2b = r0
    //     0x6a0fd0: stur            w0, [x3, #0x2b]
    // 0x6a0fd4: ldur            x0, [fp, #-0x70]
    // 0x6a0fd8: StoreField: r3->field_2f = r0
    //     0x6a0fd8: stur            w0, [x3, #0x2f]
    // 0x6a0fdc: ldur            x0, [fp, #-0x60]
    // 0x6a0fe0: StoreField: r3->field_33 = r0
    //     0x6a0fe0: stur            w0, [x3, #0x33]
    // 0x6a0fe4: r1 = Function '<anonymous closure>':.
    //     0x6a0fe4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28940] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x6a0fe8: ldr             x1, [x1, #0x940]
    // 0x6a0fec: r2 = Null
    //     0x6a0fec: mov             x2, NULL
    // 0x6a0ff0: r0 = AllocateClosure()
    //     0x6a0ff0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a0ff4: mov             x1, x0
    // 0x6a0ff8: ldur            x0, [fp, #-0x98]
    // 0x6a0ffc: StoreField: r0->field_3b = r1
    //     0x6a0ffc: stur            w1, [x0, #0x3b]
    // 0x6a1000: ldur            x1, [fp, #-0x20]
    // 0x6a1004: StoreField: r0->field_43 = r1
    //     0x6a1004: stur            w1, [x0, #0x43]
    // 0x6a1008: ldur            x1, [fp, #-0x18]
    // 0x6a100c: StoreField: r0->field_47 = r1
    //     0x6a100c: stur            w1, [x0, #0x47]
    // 0x6a1010: ldur            x1, [fp, #-0x28]
    // 0x6a1014: StoreField: r0->field_5b = r1
    //     0x6a1014: stur            w1, [x0, #0x5b]
    // 0x6a1018: r1 = Function '<anonymous closure>':.
    //     0x6a1018: add             x1, PP, #0x28, lsl #12  ; [pp+0x28948] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a101c: ldr             x1, [x1, #0x948]
    // 0x6a1020: r2 = Null
    //     0x6a1020: mov             x2, NULL
    // 0x6a1024: r0 = AllocateClosure()
    //     0x6a1024: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1028: mov             x1, x0
    // 0x6a102c: ldur            x0, [fp, #-0x98]
    // 0x6a1030: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a1030: stur            w1, [x0, #0x17]
    // 0x6a1034: r1 = Function '<anonymous closure>':.
    //     0x6a1034: add             x1, PP, #0x28, lsl #12  ; [pp+0x28950] AnonymousClosure: (0x46c520), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState (0x46c318)
    //     0x6a1038: ldr             x1, [x1, #0x950]
    // 0x6a103c: r2 = Null
    //     0x6a103c: mov             x2, NULL
    // 0x6a1040: r0 = AllocateClosure()
    //     0x6a1040: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1044: mov             x1, x0
    // 0x6a1048: ldur            x0, [fp, #-0x98]
    // 0x6a104c: StoreField: r0->field_1b = r1
    //     0x6a104c: stur            w1, [x0, #0x1b]
    // 0x6a1050: ldur            x1, [fp, #-0x30]
    // 0x6a1054: StoreField: r0->field_57 = r1
    //     0x6a1054: stur            w1, [x0, #0x57]
    // 0x6a1058: r1 = const [0xc9, 0xca, 0xcb, 0xcc]
    //     0x6a1058: add             x1, PP, #0x28, lsl #12  ; [pp+0x28958] List<int>(4)
    //     0x6a105c: ldr             x1, [x1, #0x958]
    // 0x6a1060: StoreField: r0->field_53 = r1
    //     0x6a1060: stur            w1, [x0, #0x53]
    // 0x6a1064: ldur            x1, [fp, #-0x38]
    // 0x6a1068: StoreField: r0->field_6b = r1
    //     0x6a1068: stur            w1, [x0, #0x6b]
    // 0x6a106c: ldur            x1, [fp, #-0x90]
    // 0x6a1070: StoreField: r0->field_4b = r1
    //     0x6a1070: stur            w1, [x0, #0x4b]
    // 0x6a1074: ldur            x1, [fp, #-0x50]
    // 0x6a1078: StoreField: r0->field_67 = r1
    //     0x6a1078: stur            w1, [x0, #0x67]
    // 0x6a107c: ldur            x1, [fp, #-0x10]
    // 0x6a1080: StoreField: r0->field_77 = r1
    //     0x6a1080: stur            w1, [x0, #0x77]
    // 0x6a1084: ldur            x1, [fp, #-0x40]
    // 0x6a1088: StoreField: r0->field_7b = r1
    //     0x6a1088: stur            w1, [x0, #0x7b]
    // 0x6a108c: r3 = "Chapter 14 Generators 3"
    //     0x6a108c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28960] "Chapter 14 Generators 3"
    //     0x6a1090: ldr             x3, [x3, #0x960]
    // 0x6a1094: StoreField: r0->field_73 = r3
    //     0x6a1094: stur            w3, [x0, #0x73]
    // 0x6a1098: ldur            x2, [fp, #-0x58]
    // 0x6a109c: r1 = Function '<anonymous closure>':.
    //     0x6a109c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28968] AnonymousClosure: (0x6a131c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a10a0: ldr             x1, [x1, #0x968]
    // 0x6a10a4: r0 = AllocateClosure()
    //     0x6a10a4: bl              #0x826750  ; AllocateClosureStub
    // 0x6a10a8: ldur            x2, [fp, #-0x98]
    // 0x6a10ac: mov             x5, x0
    // 0x6a10b0: r1 = Null
    //     0x6a10b0: mov             x1, NULL
    // 0x6a10b4: r3 = "Chapter 14 Generators 3"
    //     0x6a10b4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28960] "Chapter 14 Generators 3"
    //     0x6a10b8: ldr             x3, [x3, #0x960]
    // 0x6a10bc: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a10bc: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a10c0: r0 = IdleFragment()
    //     0x6a10c0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a10c4: ldur            x1, [fp, #-0x78]
    // 0x6a10c8: ArrayStore: r1[14] = r0  ; List_4
    //     0x6a10c8: add             x25, x1, #0x47
    //     0x6a10cc: str             w0, [x25]
    //     0x6a10d0: tbz             w0, #0, #0x6a10ec
    //     0x6a10d4: ldurb           w16, [x1, #-1]
    //     0x6a10d8: ldurb           w17, [x0, #-1]
    //     0x6a10dc: and             x16, x17, x16, lsr #2
    //     0x6a10e0: tst             x16, HEAP, lsr #32
    //     0x6a10e4: b.eq            #0x6a10ec
    //     0x6a10e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a10ec: ldur            x0, [fp, #-8]
    // 0x6a10f0: LoadField: r2 = r0->field_37
    //     0x6a10f0: ldur            w2, [x0, #0x37]
    // 0x6a10f4: DecompressPointer r2
    //     0x6a10f4: add             x2, x2, HEAP, lsl #32
    // 0x6a10f8: stur            x2, [fp, #-0x10]
    // 0x6a10fc: r1 = <Chapter14Stat>
    //     0x6a10fc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x6a1100: ldr             x1, [x1, #0xf60]
    // 0x6a1104: r0 = CompleteChapterButtons()
    //     0x6a1104: bl              #0x697edc  ; AllocateCompleteChapterButtonsStub -> CompleteChapterButtons<X0> (size=0x24)
    // 0x6a1108: mov             x3, x0
    // 0x6a110c: ldur            x0, [fp, #-0x10]
    // 0x6a1110: stur            x3, [fp, #-8]
    // 0x6a1114: StoreField: r3->field_f = r0
    //     0x6a1114: stur            w0, [x3, #0xf]
    // 0x6a1118: r0 = Instance_Tuple2
    //     0x6a1118: add             x0, PP, #0x28, lsl #12  ; [pp+0x28970] Obj!Tuple2<Chapter14Stat, CustomNum>@826a31
    //     0x6a111c: ldr             x0, [x0, #0x970]
    // 0x6a1120: StoreField: r3->field_13 = r0
    //     0x6a1120: stur            w0, [x3, #0x13]
    // 0x6a1124: ldur            x2, [fp, #-0x58]
    // 0x6a1128: r1 = Function '<anonymous closure>':.
    //     0x6a1128: add             x1, PP, #0x28, lsl #12  ; [pp+0x28978] AnonymousClosure: (0x6a12c8), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a112c: ldr             x1, [x1, #0x978]
    // 0x6a1130: r0 = AllocateClosure()
    //     0x6a1130: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1134: mov             x1, x0
    // 0x6a1138: ldur            x0, [fp, #-8]
    // 0x6a113c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a113c: stur            w1, [x0, #0x17]
    // 0x6a1140: r1 = Closure: (Chapter14Stat?) => String from Function 'humanName': static.
    //     0x6a1140: add             x1, PP, #0x28, lsl #12  ; [pp+0x28770] Closure: (Chapter14Stat?) => String from Function 'humanName': static. (0x248ed99c520)
    //     0x6a1144: ldr             x1, [x1, #0x770]
    // 0x6a1148: StoreField: r0->field_1f = r1
    //     0x6a1148: stur            w1, [x0, #0x1f]
    // 0x6a114c: r1 = Instance_ChapterCompleteButtonType
    //     0x6a114c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!ChapterCompleteButtonType@85ea61
    //     0x6a1150: ldr             x1, [x1, #0x330]
    // 0x6a1154: StoreField: r0->field_1b = r1
    //     0x6a1154: stur            w1, [x0, #0x1b]
    // 0x6a1158: r1 = Null
    //     0x6a1158: mov             x1, NULL
    // 0x6a115c: r2 = 2
    //     0x6a115c: movz            x2, #0x2
    // 0x6a1160: r0 = AllocateArray()
    //     0x6a1160: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a1164: mov             x2, x0
    // 0x6a1168: ldur            x0, [fp, #-8]
    // 0x6a116c: stur            x2, [fp, #-0x10]
    // 0x6a1170: StoreField: r2->field_f = r0
    //     0x6a1170: stur            w0, [x2, #0xf]
    // 0x6a1174: r1 = <Widget>
    //     0x6a1174: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a1178: r0 = AllocateGrowableArray()
    //     0x6a1178: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a117c: mov             x1, x0
    // 0x6a1180: ldur            x0, [fp, #-0x10]
    // 0x6a1184: stur            x1, [fp, #-8]
    // 0x6a1188: StoreField: r1->field_f = r0
    //     0x6a1188: stur            w0, [x1, #0xf]
    // 0x6a118c: r0 = 2
    //     0x6a118c: movz            x0, #0x2
    // 0x6a1190: StoreField: r1->field_b = r0
    //     0x6a1190: stur            w0, [x1, #0xb]
    // 0x6a1194: r0 = Column()
    //     0x6a1194: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6a1198: mov             x3, x0
    // 0x6a119c: r0 = Instance_Axis
    //     0x6a119c: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6a11a0: stur            x3, [fp, #-0x10]
    // 0x6a11a4: StoreField: r3->field_f = r0
    //     0x6a11a4: stur            w0, [x3, #0xf]
    // 0x6a11a8: r0 = Instance_MainAxisAlignment
    //     0x6a11a8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6a11ac: ldr             x0, [x0, #0x200]
    // 0x6a11b0: StoreField: r3->field_13 = r0
    //     0x6a11b0: stur            w0, [x3, #0x13]
    // 0x6a11b4: r0 = Instance_MainAxisSize
    //     0x6a11b4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6a11b8: ldr             x0, [x0, #0x70]
    // 0x6a11bc: ArrayStore: r3[0] = r0  ; List_4
    //     0x6a11bc: stur            w0, [x3, #0x17]
    // 0x6a11c0: r0 = Instance_CrossAxisAlignment
    //     0x6a11c0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6a11c4: ldr             x0, [x0, #0x78]
    // 0x6a11c8: StoreField: r3->field_1b = r0
    //     0x6a11c8: stur            w0, [x3, #0x1b]
    // 0x6a11cc: r0 = Instance_VerticalDirection
    //     0x6a11cc: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6a11d0: ldr             x0, [x0, #0x1e8]
    // 0x6a11d4: StoreField: r3->field_23 = r0
    //     0x6a11d4: stur            w0, [x3, #0x23]
    // 0x6a11d8: r0 = Instance_Clip
    //     0x6a11d8: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6a11dc: ldr             x0, [x0, #0x1b0]
    // 0x6a11e0: StoreField: r3->field_2b = r0
    //     0x6a11e0: stur            w0, [x3, #0x2b]
    // 0x6a11e4: StoreField: r3->field_2f = rZR
    //     0x6a11e4: stur            xzr, [x3, #0x2f]
    // 0x6a11e8: ldur            x0, [fp, #-8]
    // 0x6a11ec: StoreField: r3->field_b = r0
    //     0x6a11ec: stur            w0, [x3, #0xb]
    // 0x6a11f0: ldur            x2, [fp, #-0x58]
    // 0x6a11f4: r1 = Function '<anonymous closure>':.
    //     0x6a11f4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28980] AnonymousClosure: (0x6a127c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a11f8: ldr             x1, [x1, #0x980]
    // 0x6a11fc: r0 = AllocateClosure()
    //     0x6a11fc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1200: ldur            x2, [fp, #-0x10]
    // 0x6a1204: mov             x5, x0
    // 0x6a1208: r1 = Null
    //     0x6a1208: mov             x1, NULL
    // 0x6a120c: r3 = "Chapter 14 Complete Chapter"
    //     0x6a120c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28988] "Chapter 14 Complete Chapter"
    //     0x6a1210: ldr             x3, [x3, #0x988]
    // 0x6a1214: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a1214: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a1218: r0 = IdleFragment()
    //     0x6a1218: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a121c: ldur            x1, [fp, #-0x78]
    // 0x6a1220: ArrayStore: r1[15] = r0  ; List_4
    //     0x6a1220: add             x25, x1, #0x4b
    //     0x6a1224: str             w0, [x25]
    //     0x6a1228: tbz             w0, #0, #0x6a1244
    //     0x6a122c: ldurb           w16, [x1, #-1]
    //     0x6a1230: ldurb           w17, [x0, #-1]
    //     0x6a1234: and             x16, x17, x16, lsr #2
    //     0x6a1238: tst             x16, HEAP, lsr #32
    //     0x6a123c: b.eq            #0x6a1244
    //     0x6a1240: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a1244: r1 = <Widget>
    //     0x6a1244: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a1248: r0 = AllocateGrowableArray()
    //     0x6a1248: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a124c: ldur            x1, [fp, #-0x78]
    // 0x6a1250: StoreField: r0->field_f = r1
    //     0x6a1250: stur            w1, [x0, #0xf]
    // 0x6a1254: r1 = 32
    //     0x6a1254: movz            x1, #0x20
    // 0x6a1258: StoreField: r0->field_b = r1
    //     0x6a1258: stur            w1, [x0, #0xb]
    // 0x6a125c: LeaveFrame
    //     0x6a125c: mov             SP, fp
    //     0x6a1260: ldp             fp, lr, [SP], #0x10
    // 0x6a1264: ret
    //     0x6a1264: ret             
    // 0x6a1268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1268: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a126c: b               #0x69f894
    // 0x6a1270: r9 = allUpgradeData
    //     0x6a1270: add             x9, PP, #0x28, lsl #12  ; [pp+0x28990] Field <Chapter14GameState.allUpgradeData>: late (offset: 0x90)
    //     0x6a1274: ldr             x9, [x9, #0x990]
    // 0x6a1278: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a1278: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a127c, size: 0x4c
    // 0x6a127c: EnterFrame
    //     0x6a127c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1280: mov             fp, SP
    // 0x6a1284: ldr             x0, [fp, #0x10]
    // 0x6a1288: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a1288: ldur            w1, [x0, #0x17]
    // 0x6a128c: DecompressPointer r1
    //     0x6a128c: add             x1, x1, HEAP, lsl #32
    // 0x6a1290: CheckStackOverflow
    //     0x6a1290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1294: cmp             SP, x16
    //     0x6a1298: b.ls            #0x6a12c0
    // 0x6a129c: LoadField: r0 = r1->field_f
    //     0x6a129c: ldur            w0, [x1, #0xf]
    // 0x6a12a0: DecompressPointer r0
    //     0x6a12a0: add             x0, x0, HEAP, lsl #32
    // 0x6a12a4: LoadField: r1 = r0->field_13
    //     0x6a12a4: ldur            w1, [x0, #0x13]
    // 0x6a12a8: DecompressPointer r1
    //     0x6a12a8: add             x1, x1, HEAP, lsl #32
    // 0x6a12ac: r2 = 26
    //     0x6a12ac: movz            x2, #0x1a
    // 0x6a12b0: r0 = contains()
    //     0x6a12b0: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a12b4: LeaveFrame
    //     0x6a12b4: mov             SP, fp
    //     0x6a12b8: ldp             fp, lr, [SP], #0x10
    // 0x6a12bc: ret
    //     0x6a12bc: ret             
    // 0x6a12c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a12c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a12c4: b               #0x6a129c
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a12c8, size: 0x54
    // 0x6a12c8: EnterFrame
    //     0x6a12c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a12cc: mov             fp, SP
    // 0x6a12d0: ldr             x0, [fp, #0x18]
    // 0x6a12d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a12d4: ldur            w1, [x0, #0x17]
    // 0x6a12d8: DecompressPointer r1
    //     0x6a12d8: add             x1, x1, HEAP, lsl #32
    // 0x6a12dc: CheckStackOverflow
    //     0x6a12dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a12e0: cmp             SP, x16
    //     0x6a12e4: b.ls            #0x6a1314
    // 0x6a12e8: LoadField: r0 = r1->field_f
    //     0x6a12e8: ldur            w0, [x1, #0xf]
    // 0x6a12ec: DecompressPointer r0
    //     0x6a12ec: add             x0, x0, HEAP, lsl #32
    // 0x6a12f0: LoadField: r2 = r1->field_13
    //     0x6a12f0: ldur            w2, [x1, #0x13]
    // 0x6a12f4: DecompressPointer r2
    //     0x6a12f4: add             x2, x2, HEAP, lsl #32
    // 0x6a12f8: mov             x1, x0
    // 0x6a12fc: r3 = Instance_Tuple2
    //     0x6a12fc: add             x3, PP, #0x28, lsl #12  ; [pp+0x28998] Obj!Tuple2<int, String>@826a11
    //     0x6a1300: ldr             x3, [x3, #0x998]
    // 0x6a1304: r0 = completeChapter()
    //     0x6a1304: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x6a1308: LeaveFrame
    //     0x6a1308: mov             SP, fp
    //     0x6a130c: ldp             fp, lr, [SP], #0x10
    // 0x6a1310: ret
    //     0x6a1310: ret             
    // 0x6a1314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1314: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1318: b               #0x6a12e8
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a131c, size: 0x4c
    // 0x6a131c: EnterFrame
    //     0x6a131c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1320: mov             fp, SP
    // 0x6a1324: ldr             x0, [fp, #0x10]
    // 0x6a1328: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a1328: ldur            w1, [x0, #0x17]
    // 0x6a132c: DecompressPointer r1
    //     0x6a132c: add             x1, x1, HEAP, lsl #32
    // 0x6a1330: CheckStackOverflow
    //     0x6a1330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1334: cmp             SP, x16
    //     0x6a1338: b.ls            #0x6a1360
    // 0x6a133c: LoadField: r0 = r1->field_f
    //     0x6a133c: ldur            w0, [x1, #0xf]
    // 0x6a1340: DecompressPointer r0
    //     0x6a1340: add             x0, x0, HEAP, lsl #32
    // 0x6a1344: LoadField: r1 = r0->field_43
    //     0x6a1344: ldur            w1, [x0, #0x43]
    // 0x6a1348: DecompressPointer r1
    //     0x6a1348: add             x1, x1, HEAP, lsl #32
    // 0x6a134c: r2 = 2060
    //     0x6a134c: movz            x2, #0x80c
    // 0x6a1350: r0 = containsKey()
    //     0x6a1350: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1354: LeaveFrame
    //     0x6a1354: mov             SP, fp
    //     0x6a1358: ldp             fp, lr, [SP], #0x10
    // 0x6a135c: ret
    //     0x6a135c: ret             
    // 0x6a1360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1360: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1364: b               #0x6a133c
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6a1368, size: 0xd4
    // 0x6a1368: EnterFrame
    //     0x6a1368: stp             fp, lr, [SP, #-0x10]!
    //     0x6a136c: mov             fp, SP
    // 0x6a1370: AllocStack(0x8)
    //     0x6a1370: sub             SP, SP, #8
    // 0x6a1374: SetupParameters([dynamic _ /* r0 */])
    //     0x6a1374: ldr             x0, [fp, #0x10]
    //     0x6a1378: ldur            w3, [x0, #0x17]
    //     0x6a137c: add             x3, x3, HEAP, lsl #32
    //     0x6a1380: stur            x3, [fp, #-8]
    // 0x6a1384: CheckStackOverflow
    //     0x6a1384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1388: cmp             SP, x16
    //     0x6a138c: b.ls            #0x6a1434
    // 0x6a1390: LoadField: r0 = r3->field_f
    //     0x6a1390: ldur            w0, [x3, #0xf]
    // 0x6a1394: DecompressPointer r0
    //     0x6a1394: add             x0, x0, HEAP, lsl #32
    // 0x6a1398: LoadField: r1 = r0->field_43
    //     0x6a1398: ldur            w1, [x0, #0x43]
    // 0x6a139c: DecompressPointer r1
    //     0x6a139c: add             x1, x1, HEAP, lsl #32
    // 0x6a13a0: r2 = 2000
    //     0x6a13a0: movz            x2, #0x7d0
    // 0x6a13a4: r0 = containsKey()
    //     0x6a13a4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a13a8: tbnz            w0, #4, #0x6a1424
    // 0x6a13ac: ldur            x0, [fp, #-8]
    // 0x6a13b0: LoadField: r1 = r0->field_f
    //     0x6a13b0: ldur            w1, [x0, #0xf]
    // 0x6a13b4: DecompressPointer r1
    //     0x6a13b4: add             x1, x1, HEAP, lsl #32
    // 0x6a13b8: LoadField: r2 = r1->field_43
    //     0x6a13b8: ldur            w2, [x1, #0x43]
    // 0x6a13bc: DecompressPointer r2
    //     0x6a13bc: add             x2, x2, HEAP, lsl #32
    // 0x6a13c0: mov             x1, x2
    // 0x6a13c4: r2 = 2020
    //     0x6a13c4: movz            x2, #0x7e4
    // 0x6a13c8: r0 = containsKey()
    //     0x6a13c8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a13cc: tbnz            w0, #4, #0x6a1424
    // 0x6a13d0: ldur            x0, [fp, #-8]
    // 0x6a13d4: LoadField: r1 = r0->field_f
    //     0x6a13d4: ldur            w1, [x0, #0xf]
    // 0x6a13d8: DecompressPointer r1
    //     0x6a13d8: add             x1, x1, HEAP, lsl #32
    // 0x6a13dc: LoadField: r2 = r1->field_43
    //     0x6a13dc: ldur            w2, [x1, #0x43]
    // 0x6a13e0: DecompressPointer r2
    //     0x6a13e0: add             x2, x2, HEAP, lsl #32
    // 0x6a13e4: mov             x1, x2
    // 0x6a13e8: r2 = 2040
    //     0x6a13e8: movz            x2, #0x7f8
    // 0x6a13ec: r0 = containsKey()
    //     0x6a13ec: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a13f0: tbnz            w0, #4, #0x6a1424
    // 0x6a13f4: ldur            x0, [fp, #-8]
    // 0x6a13f8: LoadField: r1 = r0->field_f
    //     0x6a13f8: ldur            w1, [x0, #0xf]
    // 0x6a13fc: DecompressPointer r1
    //     0x6a13fc: add             x1, x1, HEAP, lsl #32
    // 0x6a1400: LoadField: r0 = r1->field_43
    //     0x6a1400: ldur            w0, [x1, #0x43]
    // 0x6a1404: DecompressPointer r0
    //     0x6a1404: add             x0, x0, HEAP, lsl #32
    // 0x6a1408: mov             x1, x0
    // 0x6a140c: r2 = 2060
    //     0x6a140c: movz            x2, #0x80c
    // 0x6a1410: r0 = containsKey()
    //     0x6a1410: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1414: tbnz            w0, #4, #0x6a1424
    // 0x6a1418: r0 = "Upgrades"
    //     0x6a1418: add             x0, PP, #0x26, lsl #12  ; [pp+0x26508] "Upgrades"
    //     0x6a141c: ldr             x0, [x0, #0x508]
    // 0x6a1420: b               #0x6a1428
    // 0x6a1424: r0 = Null
    //     0x6a1424: mov             x0, NULL
    // 0x6a1428: LeaveFrame
    //     0x6a1428: mov             SP, fp
    //     0x6a142c: ldp             fp, lr, [SP], #0x10
    // 0x6a1430: ret
    //     0x6a1430: ret             
    // 0x6a1434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1434: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1438: b               #0x6a1390
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a143c, size: 0x4c
    // 0x6a143c: EnterFrame
    //     0x6a143c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1440: mov             fp, SP
    // 0x6a1444: ldr             x0, [fp, #0x10]
    // 0x6a1448: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a1448: ldur            w1, [x0, #0x17]
    // 0x6a144c: DecompressPointer r1
    //     0x6a144c: add             x1, x1, HEAP, lsl #32
    // 0x6a1450: CheckStackOverflow
    //     0x6a1450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1454: cmp             SP, x16
    //     0x6a1458: b.ls            #0x6a1480
    // 0x6a145c: LoadField: r0 = r1->field_f
    //     0x6a145c: ldur            w0, [x1, #0xf]
    // 0x6a1460: DecompressPointer r0
    //     0x6a1460: add             x0, x0, HEAP, lsl #32
    // 0x6a1464: LoadField: r1 = r0->field_13
    //     0x6a1464: ldur            w1, [x0, #0x13]
    // 0x6a1468: DecompressPointer r1
    //     0x6a1468: add             x1, x1, HEAP, lsl #32
    // 0x6a146c: r2 = 24
    //     0x6a146c: movz            x2, #0x18
    // 0x6a1470: r0 = contains()
    //     0x6a1470: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a1474: LeaveFrame
    //     0x6a1474: mov             SP, fp
    //     0x6a1478: ldp             fp, lr, [SP], #0x10
    // 0x6a147c: ret
    //     0x6a147c: ret             
    // 0x6a1480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1480: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1484: b               #0x6a145c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a1488, size: 0xf8
    // 0x6a1488: EnterFrame
    //     0x6a1488: stp             fp, lr, [SP, #-0x10]!
    //     0x6a148c: mov             fp, SP
    // 0x6a1490: AllocStack(0x8)
    //     0x6a1490: sub             SP, SP, #8
    // 0x6a1494: SetupParameters([dynamic _ /* r0 */])
    //     0x6a1494: ldr             x0, [fp, #0x10]
    //     0x6a1498: ldur            w3, [x0, #0x17]
    //     0x6a149c: add             x3, x3, HEAP, lsl #32
    //     0x6a14a0: stur            x3, [fp, #-8]
    // 0x6a14a4: CheckStackOverflow
    //     0x6a14a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a14a8: cmp             SP, x16
    //     0x6a14ac: b.ls            #0x6a156c
    // 0x6a14b0: r0 = LoadStaticField(0xf7c)
    //     0x6a14b0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a14b4: ldr             x0, [x0, #0x1ef8]
    // 0x6a14b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a14bc: cmp             w0, w16
    // 0x6a14c0: b.eq            #0x6a1574
    // 0x6a14c4: LoadField: r1 = r0->field_13
    //     0x6a14c4: ldur            w1, [x0, #0x13]
    // 0x6a14c8: DecompressPointer r1
    //     0x6a14c8: add             x1, x1, HEAP, lsl #32
    // 0x6a14cc: r2 = 62
    //     0x6a14cc: movz            x2, #0x3e
    // 0x6a14d0: r0 = containsKey()
    //     0x6a14d0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a14d4: tbnz            w0, #4, #0x6a155c
    // 0x6a14d8: ldur            x0, [fp, #-8]
    // 0x6a14dc: LoadField: r1 = r0->field_f
    //     0x6a14dc: ldur            w1, [x0, #0xf]
    // 0x6a14e0: DecompressPointer r1
    //     0x6a14e0: add             x1, x1, HEAP, lsl #32
    // 0x6a14e4: LoadField: r0 = r1->field_3f
    //     0x6a14e4: ldur            w0, [x1, #0x3f]
    // 0x6a14e8: DecompressPointer r0
    //     0x6a14e8: add             x0, x0, HEAP, lsl #32
    // 0x6a14ec: LoadField: r3 = r0->field_b
    //     0x6a14ec: ldur            w3, [x0, #0xb]
    // 0x6a14f0: DecompressPointer r3
    //     0x6a14f0: add             x3, x3, HEAP, lsl #32
    // 0x6a14f4: mov             x1, x3
    // 0x6a14f8: stur            x3, [fp, #-8]
    // 0x6a14fc: r2 = 2
    //     0x6a14fc: movz            x2, #0x2
    // 0x6a1500: r0 = _getValueOrData()
    //     0x6a1500: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a1504: ldur            x1, [fp, #-8]
    // 0x6a1508: LoadField: r2 = r1->field_f
    //     0x6a1508: ldur            w2, [x1, #0xf]
    // 0x6a150c: DecompressPointer r2
    //     0x6a150c: add             x2, x2, HEAP, lsl #32
    // 0x6a1510: cmp             w2, w0
    // 0x6a1514: b.ne            #0x6a1520
    // 0x6a1518: r1 = Null
    //     0x6a1518: mov             x1, NULL
    // 0x6a151c: b               #0x6a1524
    // 0x6a1520: mov             x1, x0
    // 0x6a1524: cmp             w1, NULL
    // 0x6a1528: b.ne            #0x6a1534
    // 0x6a152c: r1 = 0
    //     0x6a152c: movz            x1, #0
    // 0x6a1530: b               #0x6a1544
    // 0x6a1534: r2 = LoadInt32Instr(r1)
    //     0x6a1534: sbfx            x2, x1, #1, #0x1f
    //     0x6a1538: tbz             w1, #0, #0x6a1540
    //     0x6a153c: ldur            x2, [x1, #7]
    // 0x6a1540: mov             x1, x2
    // 0x6a1544: cmp             x1, #2
    // 0x6a1548: r16 = true
    //     0x6a1548: add             x16, NULL, #0x20  ; true
    // 0x6a154c: r17 = false
    //     0x6a154c: add             x17, NULL, #0x30  ; false
    // 0x6a1550: csel            x2, x16, x17, gt
    // 0x6a1554: mov             x0, x2
    // 0x6a1558: b               #0x6a1560
    // 0x6a155c: r0 = false
    //     0x6a155c: add             x0, NULL, #0x30  ; false
    // 0x6a1560: LeaveFrame
    //     0x6a1560: mov             SP, fp
    //     0x6a1564: ldp             fp, lr, [SP], #0x10
    // 0x6a1568: ret
    //     0x6a1568: ret             
    // 0x6a156c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a156c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1570: b               #0x6a14b0
    // 0x6a1574: r9 = coreData
    //     0x6a1574: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6a1578: ldr             x9, [x9, #0x530]
    // 0x6a157c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a157c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a158c, size: 0xc
    // 0x6a158c: r0 = "Each stability point increases both I/O and navigation per second by 1%"
    //     0x6a158c: add             x0, PP, #0x28, lsl #12  ; [pp+0x289a0] "Each stability point increases both I/O and navigation per second by 1%"
    //     0x6a1590: ldr             x0, [x0, #0x9a0]
    // 0x6a1594: ret
    //     0x6a1594: ret             
  }
  [closure] void applyStability(dynamic) {
    // ** addr: 0x6a1598, size: 0x38
    // 0x6a1598: EnterFrame
    //     0x6a1598: stp             fp, lr, [SP, #-0x10]!
    //     0x6a159c: mov             fp, SP
    // 0x6a15a0: ldr             x0, [fp, #0x10]
    // 0x6a15a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a15a4: ldur            w1, [x0, #0x17]
    // 0x6a15a8: DecompressPointer r1
    //     0x6a15a8: add             x1, x1, HEAP, lsl #32
    // 0x6a15ac: CheckStackOverflow
    //     0x6a15ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a15b0: cmp             SP, x16
    //     0x6a15b4: b.ls            #0x6a15c8
    // 0x6a15b8: r0 = applyStability()
    //     0x6a15b8: bl              #0x6a15d0  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyStability
    // 0x6a15bc: LeaveFrame
    //     0x6a15bc: mov             SP, fp
    //     0x6a15c0: ldp             fp, lr, [SP], #0x10
    // 0x6a15c4: ret
    //     0x6a15c4: ret             
    // 0x6a15c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a15c8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a15cc: b               #0x6a15b8
  }
  _ applyStability(/* No info */) {
    // ** addr: 0x6a15d0, size: 0x49c
    // 0x6a15d0: EnterFrame
    //     0x6a15d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a15d4: mov             fp, SP
    // 0x6a15d8: AllocStack(0x18)
    //     0x6a15d8: sub             SP, SP, #0x18
    // 0x6a15dc: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */)
    //     0x6a15dc: mov             x0, x1
    //     0x6a15e0: stur            x1, [fp, #-8]
    // 0x6a15e4: CheckStackOverflow
    //     0x6a15e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a15e8: cmp             SP, x16
    //     0x6a15ec: b.ls            #0x6a1a64
    // 0x6a15f0: LoadField: r1 = r0->field_4b
    //     0x6a15f0: ldur            w1, [x0, #0x4b]
    // 0x6a15f4: DecompressPointer r1
    //     0x6a15f4: add             x1, x1, HEAP, lsl #32
    // 0x6a15f8: r0 = clear()
    //     0x6a15f8: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x6a15fc: ldur            x1, [fp, #-8]
    // 0x6a1600: r0 = getStabilityPoints()
    //     0x6a1600: bl              #0x54e7d4  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getStabilityPoints
    // 0x6a1604: mov             x3, x0
    // 0x6a1608: ldur            x0, [fp, #-8]
    // 0x6a160c: stur            x3, [fp, #-0x10]
    // 0x6a1610: LoadField: r1 = r0->field_13
    //     0x6a1610: ldur            w1, [x0, #0x13]
    // 0x6a1614: DecompressPointer r1
    //     0x6a1614: add             x1, x1, HEAP, lsl #32
    // 0x6a1618: r2 = 24
    //     0x6a1618: movz            x2, #0x18
    // 0x6a161c: r0 = add()
    //     0x6a161c: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6a1620: ldur            x0, [fp, #-8]
    // 0x6a1624: LoadField: r3 = r0->field_37
    //     0x6a1624: ldur            w3, [x0, #0x37]
    // 0x6a1628: DecompressPointer r3
    //     0x6a1628: add             x3, x3, HEAP, lsl #32
    // 0x6a162c: mov             x1, x3
    // 0x6a1630: stur            x3, [fp, #-0x18]
    // 0x6a1634: r2 = Instance_Chapter14Stat
    //     0x6a1634: add             x2, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x6a1638: ldr             x2, [x2, #0x230]
    // 0x6a163c: r0 = _getValueOrData()
    //     0x6a163c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a1640: mov             x1, x0
    // 0x6a1644: ldur            x0, [fp, #-0x18]
    // 0x6a1648: LoadField: r2 = r0->field_f
    //     0x6a1648: ldur            w2, [x0, #0xf]
    // 0x6a164c: DecompressPointer r2
    //     0x6a164c: add             x2, x2, HEAP, lsl #32
    // 0x6a1650: cmp             w2, w1
    // 0x6a1654: b.ne            #0x6a165c
    // 0x6a1658: r1 = Null
    //     0x6a1658: mov             x1, NULL
    // 0x6a165c: cmp             w1, NULL
    // 0x6a1660: b.ne            #0x6a166c
    // 0x6a1664: r1 = Instance_CustomNum
    //     0x6a1664: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1668: ldr             x1, [x1, #0xaf8]
    // 0x6a166c: ldur            x3, [fp, #-8]
    // 0x6a1670: ldur            x2, [fp, #-0x10]
    // 0x6a1674: r0 = add()
    //     0x6a1674: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a1678: ldur            x1, [fp, #-0x18]
    // 0x6a167c: mov             x3, x0
    // 0x6a1680: r2 = Instance_Chapter14Stat
    //     0x6a1680: add             x2, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x6a1684: ldr             x2, [x2, #0x230]
    // 0x6a1688: r0 = []=()
    //     0x6a1688: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a168c: ldur            x0, [fp, #-8]
    // 0x6a1690: LoadField: r3 = r0->field_3b
    //     0x6a1690: ldur            w3, [x0, #0x3b]
    // 0x6a1694: DecompressPointer r3
    //     0x6a1694: add             x3, x3, HEAP, lsl #32
    // 0x6a1698: mov             x1, x3
    // 0x6a169c: stur            x3, [fp, #-0x18]
    // 0x6a16a0: r2 = Instance_Chapter14Stat
    //     0x6a16a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x6a16a4: ldr             x2, [x2, #0x230]
    // 0x6a16a8: r0 = _getValueOrData()
    //     0x6a16a8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a16ac: mov             x1, x0
    // 0x6a16b0: ldur            x0, [fp, #-0x18]
    // 0x6a16b4: LoadField: r2 = r0->field_f
    //     0x6a16b4: ldur            w2, [x0, #0xf]
    // 0x6a16b8: DecompressPointer r2
    //     0x6a16b8: add             x2, x2, HEAP, lsl #32
    // 0x6a16bc: cmp             w2, w1
    // 0x6a16c0: b.ne            #0x6a16c8
    // 0x6a16c4: r1 = Null
    //     0x6a16c4: mov             x1, NULL
    // 0x6a16c8: cmp             w1, NULL
    // 0x6a16cc: b.ne            #0x6a16d8
    // 0x6a16d0: r1 = Instance_CustomNum
    //     0x6a16d0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a16d4: ldr             x1, [x1, #0xaf8]
    // 0x6a16d8: ldur            x3, [fp, #-8]
    // 0x6a16dc: ldur            x2, [fp, #-0x10]
    // 0x6a16e0: r0 = add()
    //     0x6a16e0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a16e4: ldur            x1, [fp, #-0x18]
    // 0x6a16e8: mov             x3, x0
    // 0x6a16ec: r2 = Instance_Chapter14Stat
    //     0x6a16ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11230] Obj!Chapter14Stat@85f841
    //     0x6a16f0: ldr             x2, [x2, #0x230]
    // 0x6a16f4: r0 = []=()
    //     0x6a16f4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a16f8: ldur            x0, [fp, #-8]
    // 0x6a16fc: LoadField: r1 = r0->field_37
    //     0x6a16fc: ldur            w1, [x0, #0x37]
    // 0x6a1700: DecompressPointer r1
    //     0x6a1700: add             x1, x1, HEAP, lsl #32
    // 0x6a1704: r2 = Instance_Chapter14Stat
    //     0x6a1704: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a1708: ldr             x2, [x2, #0x1c8]
    // 0x6a170c: r0 = remove()
    //     0x6a170c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1710: ldur            x0, [fp, #-8]
    // 0x6a1714: LoadField: r1 = r0->field_3b
    //     0x6a1714: ldur            w1, [x0, #0x3b]
    // 0x6a1718: DecompressPointer r1
    //     0x6a1718: add             x1, x1, HEAP, lsl #32
    // 0x6a171c: r2 = Instance_Chapter14Stat
    //     0x6a171c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a1720: ldr             x2, [x2, #0x1c8]
    // 0x6a1724: r0 = remove()
    //     0x6a1724: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1728: ldur            x0, [fp, #-8]
    // 0x6a172c: LoadField: r1 = r0->field_37
    //     0x6a172c: ldur            w1, [x0, #0x37]
    // 0x6a1730: DecompressPointer r1
    //     0x6a1730: add             x1, x1, HEAP, lsl #32
    // 0x6a1734: r2 = Instance_Chapter14Stat
    //     0x6a1734: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a1738: ldr             x2, [x2, #0x1e8]
    // 0x6a173c: r0 = remove()
    //     0x6a173c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1740: ldur            x0, [fp, #-8]
    // 0x6a1744: LoadField: r1 = r0->field_3b
    //     0x6a1744: ldur            w1, [x0, #0x3b]
    // 0x6a1748: DecompressPointer r1
    //     0x6a1748: add             x1, x1, HEAP, lsl #32
    // 0x6a174c: r2 = Instance_Chapter14Stat
    //     0x6a174c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a1750: ldr             x2, [x2, #0x1e8]
    // 0x6a1754: r0 = remove()
    //     0x6a1754: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1758: ldur            x0, [fp, #-8]
    // 0x6a175c: LoadField: r1 = r0->field_37
    //     0x6a175c: ldur            w1, [x0, #0x37]
    // 0x6a1760: DecompressPointer r1
    //     0x6a1760: add             x1, x1, HEAP, lsl #32
    // 0x6a1764: r2 = Instance_Chapter14Stat
    //     0x6a1764: add             x2, PP, #0x11, lsl #12  ; [pp+0x11140] Obj!Chapter14Stat@85f9c1
    //     0x6a1768: ldr             x2, [x2, #0x140]
    // 0x6a176c: r0 = remove()
    //     0x6a176c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1770: ldur            x0, [fp, #-8]
    // 0x6a1774: LoadField: r1 = r0->field_37
    //     0x6a1774: ldur            w1, [x0, #0x37]
    // 0x6a1778: DecompressPointer r1
    //     0x6a1778: add             x1, x1, HEAP, lsl #32
    // 0x6a177c: r2 = Instance_Chapter14Stat
    //     0x6a177c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11148] Obj!Chapter14Stat@85f9a1
    //     0x6a1780: ldr             x2, [x2, #0x148]
    // 0x6a1784: r0 = remove()
    //     0x6a1784: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1788: ldur            x0, [fp, #-8]
    // 0x6a178c: LoadField: r1 = r0->field_37
    //     0x6a178c: ldur            w1, [x0, #0x37]
    // 0x6a1790: DecompressPointer r1
    //     0x6a1790: add             x1, x1, HEAP, lsl #32
    // 0x6a1794: r2 = Instance_Chapter14Stat
    //     0x6a1794: add             x2, PP, #0x11, lsl #12  ; [pp+0x11150] Obj!Chapter14Stat@85f981
    //     0x6a1798: ldr             x2, [x2, #0x150]
    // 0x6a179c: r0 = remove()
    //     0x6a179c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a17a0: ldur            x0, [fp, #-8]
    // 0x6a17a4: LoadField: r1 = r0->field_37
    //     0x6a17a4: ldur            w1, [x0, #0x37]
    // 0x6a17a8: DecompressPointer r1
    //     0x6a17a8: add             x1, x1, HEAP, lsl #32
    // 0x6a17ac: r2 = Instance_Chapter14Stat
    //     0x6a17ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11158] Obj!Chapter14Stat@85f961
    //     0x6a17b0: ldr             x2, [x2, #0x158]
    // 0x6a17b4: r0 = remove()
    //     0x6a17b4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a17b8: ldur            x0, [fp, #-8]
    // 0x6a17bc: LoadField: r1 = r0->field_37
    //     0x6a17bc: ldur            w1, [x0, #0x37]
    // 0x6a17c0: DecompressPointer r1
    //     0x6a17c0: add             x1, x1, HEAP, lsl #32
    // 0x6a17c4: r2 = Instance_Chapter14Stat
    //     0x6a17c4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11160] Obj!Chapter14Stat@85f941
    //     0x6a17c8: ldr             x2, [x2, #0x160]
    // 0x6a17cc: r0 = remove()
    //     0x6a17cc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a17d0: ldur            x0, [fp, #-8]
    // 0x6a17d4: LoadField: r1 = r0->field_37
    //     0x6a17d4: ldur            w1, [x0, #0x37]
    // 0x6a17d8: DecompressPointer r1
    //     0x6a17d8: add             x1, x1, HEAP, lsl #32
    // 0x6a17dc: r2 = Instance_Chapter14Stat
    //     0x6a17dc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11168] Obj!Chapter14Stat@85f921
    //     0x6a17e0: ldr             x2, [x2, #0x168]
    // 0x6a17e4: r0 = remove()
    //     0x6a17e4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a17e8: ldur            x0, [fp, #-8]
    // 0x6a17ec: LoadField: r1 = r0->field_37
    //     0x6a17ec: ldur            w1, [x0, #0x37]
    // 0x6a17f0: DecompressPointer r1
    //     0x6a17f0: add             x1, x1, HEAP, lsl #32
    // 0x6a17f4: r2 = Instance_Chapter14Stat
    //     0x6a17f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11170] Obj!Chapter14Stat@85f901
    //     0x6a17f8: ldr             x2, [x2, #0x170]
    // 0x6a17fc: r0 = remove()
    //     0x6a17fc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1800: ldur            x0, [fp, #-8]
    // 0x6a1804: LoadField: r3 = r0->field_47
    //     0x6a1804: ldur            w3, [x0, #0x47]
    // 0x6a1808: DecompressPointer r3
    //     0x6a1808: add             x3, x3, HEAP, lsl #32
    // 0x6a180c: stur            x3, [fp, #-0x10]
    // 0x6a1810: r1 = Function '<anonymous closure>':.
    //     0x6a1810: add             x1, PP, #0x28, lsl #12  ; [pp+0x289a8] AnonymousClosure: (0x6a1db8), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyStability (0x6a15d0)
    //     0x6a1814: ldr             x1, [x1, #0x9a8]
    // 0x6a1818: r2 = Null
    //     0x6a1818: mov             x2, NULL
    // 0x6a181c: r0 = AllocateClosure()
    //     0x6a181c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1820: ldur            x1, [fp, #-0x10]
    // 0x6a1824: mov             x2, x0
    // 0x6a1828: r0 = removeWhere()
    //     0x6a1828: bl              #0x427f40  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::removeWhere
    // 0x6a182c: ldur            x0, [fp, #-8]
    // 0x6a1830: LoadField: r1 = r0->field_43
    //     0x6a1830: ldur            w1, [x0, #0x43]
    // 0x6a1834: DecompressPointer r1
    //     0x6a1834: add             x1, x1, HEAP, lsl #32
    // 0x6a1838: r2 = 2020
    //     0x6a1838: movz            x2, #0x7e4
    // 0x6a183c: r0 = containsKey()
    //     0x6a183c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1840: tbz             w0, #4, #0x6a1874
    // 0x6a1844: ldur            x0, [fp, #-8]
    // 0x6a1848: LoadField: r3 = r0->field_43
    //     0x6a1848: ldur            w3, [x0, #0x43]
    // 0x6a184c: DecompressPointer r3
    //     0x6a184c: add             x3, x3, HEAP, lsl #32
    // 0x6a1850: stur            x3, [fp, #-0x10]
    // 0x6a1854: r1 = Function '<anonymous closure>':.
    //     0x6a1854: add             x1, PP, #0x28, lsl #12  ; [pp+0x289b0] AnonymousClosure: (0x6a1d94), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyStability (0x6a15d0)
    //     0x6a1858: ldr             x1, [x1, #0x9b0]
    // 0x6a185c: r2 = Null
    //     0x6a185c: mov             x2, NULL
    // 0x6a1860: r0 = AllocateClosure()
    //     0x6a1860: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1864: ldur            x1, [fp, #-0x10]
    // 0x6a1868: mov             x2, x0
    // 0x6a186c: r0 = removeWhere()
    //     0x6a186c: bl              #0x427f40  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::removeWhere
    // 0x6a1870: b               #0x6a19f4
    // 0x6a1874: ldur            x0, [fp, #-8]
    // 0x6a1878: LoadField: r1 = r0->field_43
    //     0x6a1878: ldur            w1, [x0, #0x43]
    // 0x6a187c: DecompressPointer r1
    //     0x6a187c: add             x1, x1, HEAP, lsl #32
    // 0x6a1880: r2 = 300
    //     0x6a1880: movz            x2, #0x12c
    // 0x6a1884: r0 = containsKey()
    //     0x6a1884: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1888: tbnz            w0, #4, #0x6a194c
    // 0x6a188c: ldur            x0, [fp, #-8]
    // 0x6a1890: LoadField: r3 = r0->field_37
    //     0x6a1890: ldur            w3, [x0, #0x37]
    // 0x6a1894: DecompressPointer r3
    //     0x6a1894: add             x3, x3, HEAP, lsl #32
    // 0x6a1898: stur            x3, [fp, #-0x10]
    // 0x6a189c: r1 = Null
    //     0x6a189c: mov             x1, NULL
    // 0x6a18a0: r2 = 100
    //     0x6a18a0: movz            x2, #0x64
    // 0x6a18a4: r0 = CustomNum()
    //     0x6a18a4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a18a8: ldur            x1, [fp, #-0x10]
    // 0x6a18ac: mov             x3, x0
    // 0x6a18b0: r2 = Instance_Chapter14Stat
    //     0x6a18b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11158] Obj!Chapter14Stat@85f961
    //     0x6a18b4: ldr             x2, [x2, #0x158]
    // 0x6a18b8: r0 = []=()
    //     0x6a18b8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a18bc: ldur            x0, [fp, #-8]
    // 0x6a18c0: LoadField: r3 = r0->field_37
    //     0x6a18c0: ldur            w3, [x0, #0x37]
    // 0x6a18c4: DecompressPointer r3
    //     0x6a18c4: add             x3, x3, HEAP, lsl #32
    // 0x6a18c8: stur            x3, [fp, #-0x10]
    // 0x6a18cc: r1 = Null
    //     0x6a18cc: mov             x1, NULL
    // 0x6a18d0: r2 = 100
    //     0x6a18d0: movz            x2, #0x64
    // 0x6a18d4: r0 = CustomNum()
    //     0x6a18d4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a18d8: ldur            x1, [fp, #-0x10]
    // 0x6a18dc: mov             x3, x0
    // 0x6a18e0: r2 = Instance_Chapter14Stat
    //     0x6a18e0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11160] Obj!Chapter14Stat@85f941
    //     0x6a18e4: ldr             x2, [x2, #0x160]
    // 0x6a18e8: r0 = []=()
    //     0x6a18e8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a18ec: ldur            x0, [fp, #-8]
    // 0x6a18f0: LoadField: r3 = r0->field_37
    //     0x6a18f0: ldur            w3, [x0, #0x37]
    // 0x6a18f4: DecompressPointer r3
    //     0x6a18f4: add             x3, x3, HEAP, lsl #32
    // 0x6a18f8: stur            x3, [fp, #-0x10]
    // 0x6a18fc: r1 = Null
    //     0x6a18fc: mov             x1, NULL
    // 0x6a1900: r2 = 100
    //     0x6a1900: movz            x2, #0x64
    // 0x6a1904: r0 = CustomNum()
    //     0x6a1904: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1908: ldur            x1, [fp, #-0x10]
    // 0x6a190c: mov             x3, x0
    // 0x6a1910: r2 = Instance_Chapter14Stat
    //     0x6a1910: add             x2, PP, #0x11, lsl #12  ; [pp+0x11168] Obj!Chapter14Stat@85f921
    //     0x6a1914: ldr             x2, [x2, #0x168]
    // 0x6a1918: r0 = []=()
    //     0x6a1918: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a191c: ldur            x0, [fp, #-8]
    // 0x6a1920: LoadField: r3 = r0->field_37
    //     0x6a1920: ldur            w3, [x0, #0x37]
    // 0x6a1924: DecompressPointer r3
    //     0x6a1924: add             x3, x3, HEAP, lsl #32
    // 0x6a1928: stur            x3, [fp, #-0x10]
    // 0x6a192c: r1 = Null
    //     0x6a192c: mov             x1, NULL
    // 0x6a1930: r2 = 100
    //     0x6a1930: movz            x2, #0x64
    // 0x6a1934: r0 = CustomNum()
    //     0x6a1934: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1938: ldur            x1, [fp, #-0x10]
    // 0x6a193c: mov             x3, x0
    // 0x6a1940: r2 = Instance_Chapter14Stat
    //     0x6a1940: add             x2, PP, #0x11, lsl #12  ; [pp+0x11170] Obj!Chapter14Stat@85f901
    //     0x6a1944: ldr             x2, [x2, #0x170]
    // 0x6a1948: r0 = []=()
    //     0x6a1948: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a194c: ldur            x0, [fp, #-8]
    // 0x6a1950: LoadField: r1 = r0->field_43
    //     0x6a1950: ldur            w1, [x0, #0x43]
    // 0x6a1954: DecompressPointer r1
    //     0x6a1954: add             x1, x1, HEAP, lsl #32
    // 0x6a1958: r2 = 280
    //     0x6a1958: movz            x2, #0x118
    // 0x6a195c: r0 = containsKey()
    //     0x6a195c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1960: tbnz            w0, #4, #0x6a19f4
    // 0x6a1964: ldur            x0, [fp, #-8]
    // 0x6a1968: LoadField: r3 = r0->field_37
    //     0x6a1968: ldur            w3, [x0, #0x37]
    // 0x6a196c: DecompressPointer r3
    //     0x6a196c: add             x3, x3, HEAP, lsl #32
    // 0x6a1970: stur            x3, [fp, #-0x10]
    // 0x6a1974: r1 = Null
    //     0x6a1974: mov             x1, NULL
    // 0x6a1978: r2 = 100
    //     0x6a1978: movz            x2, #0x64
    // 0x6a197c: r0 = CustomNum()
    //     0x6a197c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1980: ldur            x1, [fp, #-0x10]
    // 0x6a1984: mov             x3, x0
    // 0x6a1988: r2 = Instance_Chapter14Stat
    //     0x6a1988: add             x2, PP, #0x11, lsl #12  ; [pp+0x11140] Obj!Chapter14Stat@85f9c1
    //     0x6a198c: ldr             x2, [x2, #0x140]
    // 0x6a1990: r0 = []=()
    //     0x6a1990: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1994: ldur            x0, [fp, #-8]
    // 0x6a1998: LoadField: r3 = r0->field_37
    //     0x6a1998: ldur            w3, [x0, #0x37]
    // 0x6a199c: DecompressPointer r3
    //     0x6a199c: add             x3, x3, HEAP, lsl #32
    // 0x6a19a0: stur            x3, [fp, #-0x10]
    // 0x6a19a4: r1 = Null
    //     0x6a19a4: mov             x1, NULL
    // 0x6a19a8: r2 = 100
    //     0x6a19a8: movz            x2, #0x64
    // 0x6a19ac: r0 = CustomNum()
    //     0x6a19ac: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a19b0: ldur            x1, [fp, #-0x10]
    // 0x6a19b4: mov             x3, x0
    // 0x6a19b8: r2 = Instance_Chapter14Stat
    //     0x6a19b8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11148] Obj!Chapter14Stat@85f9a1
    //     0x6a19bc: ldr             x2, [x2, #0x148]
    // 0x6a19c0: r0 = []=()
    //     0x6a19c0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a19c4: ldur            x0, [fp, #-8]
    // 0x6a19c8: LoadField: r3 = r0->field_37
    //     0x6a19c8: ldur            w3, [x0, #0x37]
    // 0x6a19cc: DecompressPointer r3
    //     0x6a19cc: add             x3, x3, HEAP, lsl #32
    // 0x6a19d0: stur            x3, [fp, #-0x10]
    // 0x6a19d4: r1 = Null
    //     0x6a19d4: mov             x1, NULL
    // 0x6a19d8: r2 = 100
    //     0x6a19d8: movz            x2, #0x64
    // 0x6a19dc: r0 = CustomNum()
    //     0x6a19dc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a19e0: ldur            x1, [fp, #-0x10]
    // 0x6a19e4: mov             x3, x0
    // 0x6a19e8: r2 = Instance_Chapter14Stat
    //     0x6a19e8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11150] Obj!Chapter14Stat@85f981
    //     0x6a19ec: ldr             x2, [x2, #0x150]
    // 0x6a19f0: r0 = []=()
    //     0x6a19f0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a19f4: ldur            x0, [fp, #-8]
    // 0x6a19f8: LoadField: r1 = r0->field_43
    //     0x6a19f8: ldur            w1, [x0, #0x43]
    // 0x6a19fc: DecompressPointer r1
    //     0x6a19fc: add             x1, x1, HEAP, lsl #32
    // 0x6a1a00: r2 = 2040
    //     0x6a1a00: movz            x2, #0x7f8
    // 0x6a1a04: r0 = containsKey()
    //     0x6a1a04: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1a08: tbz             w0, #4, #0x6a1a40
    // 0x6a1a0c: ldur            x0, [fp, #-8]
    // 0x6a1a10: LoadField: r1 = r0->field_3f
    //     0x6a1a10: ldur            w1, [x0, #0x3f]
    // 0x6a1a14: DecompressPointer r1
    //     0x6a1a14: add             x1, x1, HEAP, lsl #32
    // 0x6a1a18: LoadField: r3 = r1->field_b
    //     0x6a1a18: ldur            w3, [x1, #0xb]
    // 0x6a1a1c: DecompressPointer r3
    //     0x6a1a1c: add             x3, x3, HEAP, lsl #32
    // 0x6a1a20: stur            x3, [fp, #-0x10]
    // 0x6a1a24: r1 = Function '<anonymous closure>':.
    //     0x6a1a24: add             x1, PP, #0x28, lsl #12  ; [pp+0x289b8] AnonymousClosure: (0x6a1d70), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyStability (0x6a15d0)
    //     0x6a1a28: ldr             x1, [x1, #0x9b8]
    // 0x6a1a2c: r2 = Null
    //     0x6a1a2c: mov             x2, NULL
    // 0x6a1a30: r0 = AllocateClosure()
    //     0x6a1a30: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1a34: ldur            x1, [fp, #-0x10]
    // 0x6a1a38: mov             x2, x0
    // 0x6a1a3c: r0 = removeWhere()
    //     0x6a1a3c: bl              #0x427f40  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::removeWhere
    // 0x6a1a40: ldur            x1, [fp, #-8]
    // 0x6a1a44: r0 = applySharedPrestige()
    //     0x6a1a44: bl              #0x6a1a6c  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applySharedPrestige
    // 0x6a1a48: r1 = "prestige"
    //     0x6a1a48: add             x1, PP, #0x28, lsl #12  ; [pp+0x289c0] "prestige"
    //     0x6a1a4c: ldr             x1, [x1, #0x9c0]
    // 0x6a1a50: r0 = broadcastToListeners()
    //     0x6a1a50: bl              #0x4513b8  ; [package:state_groups/src/sync_state.dart] ::broadcastToListeners
    // 0x6a1a54: r0 = Null
    //     0x6a1a54: mov             x0, NULL
    // 0x6a1a58: LeaveFrame
    //     0x6a1a58: mov             SP, fp
    //     0x6a1a5c: ldp             fp, lr, [SP], #0x10
    // 0x6a1a60: ret
    //     0x6a1a60: ret             
    // 0x6a1a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1a64: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1a68: b               #0x6a15f0
  }
  _ applySharedPrestige(/* No info */) {
    // ** addr: 0x6a1a6c, size: 0x304
    // 0x6a1a6c: EnterFrame
    //     0x6a1a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1a70: mov             fp, SP
    // 0x6a1a74: AllocStack(0x10)
    //     0x6a1a74: sub             SP, SP, #0x10
    // 0x6a1a78: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */)
    //     0x6a1a78: mov             x0, x1
    //     0x6a1a7c: stur            x1, [fp, #-8]
    // 0x6a1a80: CheckStackOverflow
    //     0x6a1a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1a84: cmp             SP, x16
    //     0x6a1a88: b.ls            #0x6a1d68
    // 0x6a1a8c: LoadField: r1 = r0->field_4b
    //     0x6a1a8c: ldur            w1, [x0, #0x4b]
    // 0x6a1a90: DecompressPointer r1
    //     0x6a1a90: add             x1, x1, HEAP, lsl #32
    // 0x6a1a94: r2 = 0
    //     0x6a1a94: movz            x2, #0
    // 0x6a1a98: r0 = remove()
    //     0x6a1a98: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1a9c: ldur            x0, [fp, #-8]
    // 0x6a1aa0: LoadField: r1 = r0->field_37
    //     0x6a1aa0: ldur            w1, [x0, #0x37]
    // 0x6a1aa4: DecompressPointer r1
    //     0x6a1aa4: add             x1, x1, HEAP, lsl #32
    // 0x6a1aa8: r2 = Instance_Chapter14Stat
    //     0x6a1aa8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x6a1aac: ldr             x2, [x2, #0x1a8]
    // 0x6a1ab0: r3 = Instance_CustomNum
    //     0x6a1ab0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1ab4: ldr             x3, [x3, #0xaf8]
    // 0x6a1ab8: r0 = []=()
    //     0x6a1ab8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1abc: ldur            x0, [fp, #-8]
    // 0x6a1ac0: LoadField: r1 = r0->field_3b
    //     0x6a1ac0: ldur            w1, [x0, #0x3b]
    // 0x6a1ac4: DecompressPointer r1
    //     0x6a1ac4: add             x1, x1, HEAP, lsl #32
    // 0x6a1ac8: r2 = Instance_Chapter14Stat
    //     0x6a1ac8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111a8] Obj!Chapter14Stat@85f8c1
    //     0x6a1acc: ldr             x2, [x2, #0x1a8]
    // 0x6a1ad0: r3 = Instance_CustomNum
    //     0x6a1ad0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1ad4: ldr             x3, [x3, #0xaf8]
    // 0x6a1ad8: r0 = []=()
    //     0x6a1ad8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1adc: ldur            x0, [fp, #-8]
    // 0x6a1ae0: LoadField: r1 = r0->field_3b
    //     0x6a1ae0: ldur            w1, [x0, #0x3b]
    // 0x6a1ae4: DecompressPointer r1
    //     0x6a1ae4: add             x1, x1, HEAP, lsl #32
    // 0x6a1ae8: r2 = Instance_Chapter14Stat
    //     0x6a1ae8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x6a1aec: ldr             x2, [x2, #0x1b8]
    // 0x6a1af0: r3 = Instance_CustomNum
    //     0x6a1af0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1af4: ldr             x3, [x3, #0xaf8]
    // 0x6a1af8: r0 = []=()
    //     0x6a1af8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1afc: ldur            x0, [fp, #-8]
    // 0x6a1b00: LoadField: r1 = r0->field_3b
    //     0x6a1b00: ldur            w1, [x0, #0x3b]
    // 0x6a1b04: DecompressPointer r1
    //     0x6a1b04: add             x1, x1, HEAP, lsl #32
    // 0x6a1b08: r2 = Instance_Chapter14Stat
    //     0x6a1b08: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6a1b0c: ldr             x2, [x2, #0x1d8]
    // 0x6a1b10: r3 = Instance_CustomNum
    //     0x6a1b10: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1b14: ldr             x3, [x3, #0xaf8]
    // 0x6a1b18: r0 = []=()
    //     0x6a1b18: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1b1c: ldur            x0, [fp, #-8]
    // 0x6a1b20: LoadField: r1 = r0->field_43
    //     0x6a1b20: ldur            w1, [x0, #0x43]
    // 0x6a1b24: DecompressPointer r1
    //     0x6a1b24: add             x1, x1, HEAP, lsl #32
    // 0x6a1b28: r2 = 270
    //     0x6a1b28: movz            x2, #0x10e
    // 0x6a1b2c: r0 = containsKey()
    //     0x6a1b2c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1b30: tbnz            w0, #4, #0x6a1ba0
    // 0x6a1b34: ldur            x0, [fp, #-8]
    // 0x6a1b38: LoadField: r3 = r0->field_37
    //     0x6a1b38: ldur            w3, [x0, #0x37]
    // 0x6a1b3c: DecompressPointer r3
    //     0x6a1b3c: add             x3, x3, HEAP, lsl #32
    // 0x6a1b40: stur            x3, [fp, #-0x10]
    // 0x6a1b44: r1 = Null
    //     0x6a1b44: mov             x1, NULL
    // 0x6a1b48: r2 = 2000000
    //     0x6a1b48: movz            x2, #0x8480
    //     0x6a1b4c: movk            x2, #0x1e, lsl #16
    // 0x6a1b50: r0 = CustomNum()
    //     0x6a1b50: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1b54: ldur            x1, [fp, #-0x10]
    // 0x6a1b58: mov             x3, x0
    // 0x6a1b5c: r2 = Instance_Chapter14Stat
    //     0x6a1b5c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6a1b60: ldr             x2, [x2, #0x1d8]
    // 0x6a1b64: r0 = []=()
    //     0x6a1b64: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1b68: ldur            x0, [fp, #-8]
    // 0x6a1b6c: LoadField: r3 = r0->field_37
    //     0x6a1b6c: ldur            w3, [x0, #0x37]
    // 0x6a1b70: DecompressPointer r3
    //     0x6a1b70: add             x3, x3, HEAP, lsl #32
    // 0x6a1b74: stur            x3, [fp, #-0x10]
    // 0x6a1b78: r1 = Null
    //     0x6a1b78: mov             x1, NULL
    // 0x6a1b7c: r2 = 2000000
    //     0x6a1b7c: movz            x2, #0x8480
    //     0x6a1b80: movk            x2, #0x1e, lsl #16
    // 0x6a1b84: r0 = CustomNum()
    //     0x6a1b84: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1b88: ldur            x1, [fp, #-0x10]
    // 0x6a1b8c: mov             x3, x0
    // 0x6a1b90: r2 = Instance_Chapter14Stat
    //     0x6a1b90: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x6a1b94: ldr             x2, [x2, #0x1b8]
    // 0x6a1b98: r0 = []=()
    //     0x6a1b98: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1b9c: b               #0x6a1c5c
    // 0x6a1ba0: ldur            x0, [fp, #-8]
    // 0x6a1ba4: LoadField: r1 = r0->field_43
    //     0x6a1ba4: ldur            w1, [x0, #0x43]
    // 0x6a1ba8: DecompressPointer r1
    //     0x6a1ba8: add             x1, x1, HEAP, lsl #32
    // 0x6a1bac: r2 = 220
    //     0x6a1bac: movz            x2, #0xdc
    // 0x6a1bb0: r0 = containsKey()
    //     0x6a1bb0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1bb4: tbnz            w0, #4, #0x6a1c1c
    // 0x6a1bb8: ldur            x0, [fp, #-8]
    // 0x6a1bbc: LoadField: r3 = r0->field_37
    //     0x6a1bbc: ldur            w3, [x0, #0x37]
    // 0x6a1bc0: DecompressPointer r3
    //     0x6a1bc0: add             x3, x3, HEAP, lsl #32
    // 0x6a1bc4: stur            x3, [fp, #-0x10]
    // 0x6a1bc8: r1 = Null
    //     0x6a1bc8: mov             x1, NULL
    // 0x6a1bcc: r2 = 2000
    //     0x6a1bcc: movz            x2, #0x7d0
    // 0x6a1bd0: r0 = CustomNum()
    //     0x6a1bd0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1bd4: ldur            x1, [fp, #-0x10]
    // 0x6a1bd8: mov             x3, x0
    // 0x6a1bdc: r2 = Instance_Chapter14Stat
    //     0x6a1bdc: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6a1be0: ldr             x2, [x2, #0x1d8]
    // 0x6a1be4: r0 = []=()
    //     0x6a1be4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1be8: ldur            x0, [fp, #-8]
    // 0x6a1bec: LoadField: r3 = r0->field_37
    //     0x6a1bec: ldur            w3, [x0, #0x37]
    // 0x6a1bf0: DecompressPointer r3
    //     0x6a1bf0: add             x3, x3, HEAP, lsl #32
    // 0x6a1bf4: stur            x3, [fp, #-0x10]
    // 0x6a1bf8: r1 = Null
    //     0x6a1bf8: mov             x1, NULL
    // 0x6a1bfc: r2 = 2000
    //     0x6a1bfc: movz            x2, #0x7d0
    // 0x6a1c00: r0 = CustomNum()
    //     0x6a1c00: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a1c04: ldur            x1, [fp, #-0x10]
    // 0x6a1c08: mov             x3, x0
    // 0x6a1c0c: r2 = Instance_Chapter14Stat
    //     0x6a1c0c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x6a1c10: ldr             x2, [x2, #0x1b8]
    // 0x6a1c14: r0 = []=()
    //     0x6a1c14: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1c18: b               #0x6a1c5c
    // 0x6a1c1c: ldur            x0, [fp, #-8]
    // 0x6a1c20: LoadField: r1 = r0->field_37
    //     0x6a1c20: ldur            w1, [x0, #0x37]
    // 0x6a1c24: DecompressPointer r1
    //     0x6a1c24: add             x1, x1, HEAP, lsl #32
    // 0x6a1c28: r2 = Instance_Chapter14Stat
    //     0x6a1c28: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x6a1c2c: ldr             x2, [x2, #0x1b8]
    // 0x6a1c30: r3 = Instance_CustomNum
    //     0x6a1c30: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1c34: ldr             x3, [x3, #0xaf8]
    // 0x6a1c38: r0 = []=()
    //     0x6a1c38: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1c3c: ldur            x0, [fp, #-8]
    // 0x6a1c40: LoadField: r1 = r0->field_37
    //     0x6a1c40: ldur            w1, [x0, #0x37]
    // 0x6a1c44: DecompressPointer r1
    //     0x6a1c44: add             x1, x1, HEAP, lsl #32
    // 0x6a1c48: r2 = Instance_Chapter14Stat
    //     0x6a1c48: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6a1c4c: ldr             x2, [x2, #0x1d8]
    // 0x6a1c50: r3 = Instance_CustomNum
    //     0x6a1c50: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a1c54: ldr             x3, [x3, #0xaf8]
    // 0x6a1c58: r0 = []=()
    //     0x6a1c58: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1c5c: ldur            x0, [fp, #-8]
    // 0x6a1c60: LoadField: r1 = r0->field_47
    //     0x6a1c60: ldur            w1, [x0, #0x47]
    // 0x6a1c64: DecompressPointer r1
    //     0x6a1c64: add             x1, x1, HEAP, lsl #32
    // 0x6a1c68: r2 = 2
    //     0x6a1c68: movz            x2, #0x2
    // 0x6a1c6c: r3 = 0.000000
    //     0x6a1c6c: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1c70: r0 = []=()
    //     0x6a1c70: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1c74: ldur            x0, [fp, #-8]
    // 0x6a1c78: LoadField: r1 = r0->field_47
    //     0x6a1c78: ldur            w1, [x0, #0x47]
    // 0x6a1c7c: DecompressPointer r1
    //     0x6a1c7c: add             x1, x1, HEAP, lsl #32
    // 0x6a1c80: r2 = 4
    //     0x6a1c80: movz            x2, #0x4
    // 0x6a1c84: r3 = 0.000000
    //     0x6a1c84: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1c88: r0 = []=()
    //     0x6a1c88: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1c8c: ldur            x0, [fp, #-8]
    // 0x6a1c90: LoadField: r1 = r0->field_47
    //     0x6a1c90: ldur            w1, [x0, #0x47]
    // 0x6a1c94: DecompressPointer r1
    //     0x6a1c94: add             x1, x1, HEAP, lsl #32
    // 0x6a1c98: r2 = 6
    //     0x6a1c98: movz            x2, #0x6
    // 0x6a1c9c: r3 = 0.000000
    //     0x6a1c9c: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1ca0: r0 = []=()
    //     0x6a1ca0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1ca4: ldur            x0, [fp, #-8]
    // 0x6a1ca8: LoadField: r1 = r0->field_47
    //     0x6a1ca8: ldur            w1, [x0, #0x47]
    // 0x6a1cac: DecompressPointer r1
    //     0x6a1cac: add             x1, x1, HEAP, lsl #32
    // 0x6a1cb0: r2 = 8
    //     0x6a1cb0: movz            x2, #0x8
    // 0x6a1cb4: r3 = 0.000000
    //     0x6a1cb4: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1cb8: r0 = []=()
    //     0x6a1cb8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1cbc: ldur            x0, [fp, #-8]
    // 0x6a1cc0: LoadField: r1 = r0->field_47
    //     0x6a1cc0: ldur            w1, [x0, #0x47]
    // 0x6a1cc4: DecompressPointer r1
    //     0x6a1cc4: add             x1, x1, HEAP, lsl #32
    // 0x6a1cc8: r2 = 10
    //     0x6a1cc8: movz            x2, #0xa
    // 0x6a1ccc: r3 = 0.000000
    //     0x6a1ccc: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1cd0: r0 = []=()
    //     0x6a1cd0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1cd4: ldur            x0, [fp, #-8]
    // 0x6a1cd8: LoadField: r1 = r0->field_47
    //     0x6a1cd8: ldur            w1, [x0, #0x47]
    // 0x6a1cdc: DecompressPointer r1
    //     0x6a1cdc: add             x1, x1, HEAP, lsl #32
    // 0x6a1ce0: r2 = 12
    //     0x6a1ce0: movz            x2, #0xc
    // 0x6a1ce4: r3 = 0.000000
    //     0x6a1ce4: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1ce8: r0 = []=()
    //     0x6a1ce8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1cec: ldur            x0, [fp, #-8]
    // 0x6a1cf0: LoadField: r1 = r0->field_47
    //     0x6a1cf0: ldur            w1, [x0, #0x47]
    // 0x6a1cf4: DecompressPointer r1
    //     0x6a1cf4: add             x1, x1, HEAP, lsl #32
    // 0x6a1cf8: r2 = 14
    //     0x6a1cf8: movz            x2, #0xe
    // 0x6a1cfc: r3 = 0.000000
    //     0x6a1cfc: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a1d00: r0 = []=()
    //     0x6a1d00: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a1d04: ldur            x0, [fp, #-8]
    // 0x6a1d08: LoadField: r1 = r0->field_43
    //     0x6a1d08: ldur            w1, [x0, #0x43]
    // 0x6a1d0c: DecompressPointer r1
    //     0x6a1d0c: add             x1, x1, HEAP, lsl #32
    // 0x6a1d10: r2 = 210
    //     0x6a1d10: movz            x2, #0xd2
    // 0x6a1d14: r0 = containsKey()
    //     0x6a1d14: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1d18: tbz             w0, #4, #0x6a1d58
    // 0x6a1d1c: ldur            x0, [fp, #-8]
    // 0x6a1d20: LoadField: r1 = r0->field_53
    //     0x6a1d20: ldur            w1, [x0, #0x53]
    // 0x6a1d24: DecompressPointer r1
    //     0x6a1d24: add             x1, x1, HEAP, lsl #32
    // 0x6a1d28: r2 = 0
    //     0x6a1d28: movz            x2, #0
    // 0x6a1d2c: r0 = remove()
    //     0x6a1d2c: bl              #0x7e8a40  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x6a1d30: ldur            x0, [fp, #-8]
    // 0x6a1d34: LoadField: r1 = r0->field_43
    //     0x6a1d34: ldur            w1, [x0, #0x43]
    // 0x6a1d38: DecompressPointer r1
    //     0x6a1d38: add             x1, x1, HEAP, lsl #32
    // 0x6a1d3c: r2 = 20
    //     0x6a1d3c: movz            x2, #0x14
    // 0x6a1d40: r0 = remove()
    //     0x6a1d40: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1d44: ldur            x0, [fp, #-8]
    // 0x6a1d48: LoadField: r1 = r0->field_43
    //     0x6a1d48: ldur            w1, [x0, #0x43]
    // 0x6a1d4c: DecompressPointer r1
    //     0x6a1d4c: add             x1, x1, HEAP, lsl #32
    // 0x6a1d50: r2 = 40
    //     0x6a1d50: movz            x2, #0x28
    // 0x6a1d54: r0 = remove()
    //     0x6a1d54: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a1d58: r0 = Null
    //     0x6a1d58: mov             x0, NULL
    // 0x6a1d5c: LeaveFrame
    //     0x6a1d5c: mov             SP, fp
    //     0x6a1d60: ldp             fp, lr, [SP], #0x10
    // 0x6a1d64: ret
    //     0x6a1d64: ret             
    // 0x6a1d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1d68: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1d6c: b               #0x6a1a8c
  }
  [closure] bool <anonymous closure>(dynamic, int, int) {
    // ** addr: 0x6a1d70, size: 0x24
    // 0x6a1d70: ldr             x1, [SP, #8]
    // 0x6a1d74: r2 = LoadInt32Instr(r1)
    //     0x6a1d74: sbfx            x2, x1, #1, #0x1f
    //     0x6a1d78: tbz             w1, #0, #0x6a1d80
    //     0x6a1d7c: ldur            x2, [x1, #7]
    // 0x6a1d80: cmp             x2, #0xa
    // 0x6a1d84: r16 = true
    //     0x6a1d84: add             x16, NULL, #0x20  ; true
    // 0x6a1d88: r17 = false
    //     0x6a1d88: add             x17, NULL, #0x30  ; false
    // 0x6a1d8c: csel            x0, x16, x17, lt
    // 0x6a1d90: ret
    //     0x6a1d90: ret             
  }
  [closure] bool <anonymous closure>(dynamic, int, int) {
    // ** addr: 0x6a1d94, size: 0x24
    // 0x6a1d94: ldr             x1, [SP, #8]
    // 0x6a1d98: r2 = LoadInt32Instr(r1)
    //     0x6a1d98: sbfx            x2, x1, #1, #0x1f
    //     0x6a1d9c: tbz             w1, #0, #0x6a1da4
    //     0x6a1da0: ldur            x2, [x1, #7]
    // 0x6a1da4: cmp             x2, #0x3e8
    // 0x6a1da8: r16 = true
    //     0x6a1da8: add             x16, NULL, #0x20  ; true
    // 0x6a1dac: r17 = false
    //     0x6a1dac: add             x17, NULL, #0x30  ; false
    // 0x6a1db0: csel            x0, x16, x17, lt
    // 0x6a1db4: ret
    //     0x6a1db4: ret             
  }
  [closure] bool <anonymous closure>(dynamic, int, double) {
    // ** addr: 0x6a1db8, size: 0x38
    // 0x6a1db8: ldr             x1, [SP, #8]
    // 0x6a1dbc: r2 = LoadInt32Instr(r1)
    //     0x6a1dbc: sbfx            x2, x1, #1, #0x1f
    //     0x6a1dc0: tbz             w1, #0, #0x6a1dc8
    //     0x6a1dc4: ldur            x2, [x1, #7]
    // 0x6a1dc8: cmp             x2, #0xc8
    // 0x6a1dcc: b.ge            #0x6a1de8
    // 0x6a1dd0: cmp             x2, #0
    // 0x6a1dd4: r16 = true
    //     0x6a1dd4: add             x16, NULL, #0x20  ; true
    // 0x6a1dd8: r17 = false
    //     0x6a1dd8: add             x17, NULL, #0x30  ; false
    // 0x6a1ddc: csel            x1, x16, x17, gt
    // 0x6a1de0: mov             x0, x1
    // 0x6a1de4: b               #0x6a1dec
    // 0x6a1de8: r0 = false
    //     0x6a1de8: add             x0, NULL, #0x30  ; false
    // 0x6a1dec: ret
    //     0x6a1dec: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a1df0, size: 0xc
    // 0x6a1df0: r0 = "Write Shim"
    //     0x6a1df0: add             x0, PP, #0x28, lsl #12  ; [pp+0x289c8] "Write Shim"
    //     0x6a1df4: ldr             x0, [x0, #0x9c8]
    // 0x6a1df8: ret
    //     0x6a1df8: ret             
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a1dfc, size: 0xb0
    // 0x6a1dfc: EnterFrame
    //     0x6a1dfc: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1e00: mov             fp, SP
    // 0x6a1e04: AllocStack(0x8)
    //     0x6a1e04: sub             SP, SP, #8
    // 0x6a1e08: SetupParameters([dynamic _ /* r0 */])
    //     0x6a1e08: ldr             x0, [fp, #0x10]
    //     0x6a1e0c: ldur            w1, [x0, #0x17]
    //     0x6a1e10: add             x1, x1, HEAP, lsl #32
    // 0x6a1e14: CheckStackOverflow
    //     0x6a1e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1e18: cmp             SP, x16
    //     0x6a1e1c: b.ls            #0x6a1ea4
    // 0x6a1e20: LoadField: r0 = r1->field_f
    //     0x6a1e20: ldur            w0, [x1, #0xf]
    // 0x6a1e24: DecompressPointer r0
    //     0x6a1e24: add             x0, x0, HEAP, lsl #32
    // 0x6a1e28: LoadField: r1 = r0->field_3f
    //     0x6a1e28: ldur            w1, [x0, #0x3f]
    // 0x6a1e2c: DecompressPointer r1
    //     0x6a1e2c: add             x1, x1, HEAP, lsl #32
    // 0x6a1e30: LoadField: r0 = r1->field_b
    //     0x6a1e30: ldur            w0, [x1, #0xb]
    // 0x6a1e34: DecompressPointer r0
    //     0x6a1e34: add             x0, x0, HEAP, lsl #32
    // 0x6a1e38: mov             x1, x0
    // 0x6a1e3c: stur            x0, [fp, #-8]
    // 0x6a1e40: r2 = 2
    //     0x6a1e40: movz            x2, #0x2
    // 0x6a1e44: r0 = _getValueOrData()
    //     0x6a1e44: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a1e48: ldur            x1, [fp, #-8]
    // 0x6a1e4c: LoadField: r2 = r1->field_f
    //     0x6a1e4c: ldur            w2, [x1, #0xf]
    // 0x6a1e50: DecompressPointer r2
    //     0x6a1e50: add             x2, x2, HEAP, lsl #32
    // 0x6a1e54: cmp             w2, w0
    // 0x6a1e58: b.ne            #0x6a1e64
    // 0x6a1e5c: r1 = Null
    //     0x6a1e5c: mov             x1, NULL
    // 0x6a1e60: b               #0x6a1e68
    // 0x6a1e64: mov             x1, x0
    // 0x6a1e68: cmp             w1, NULL
    // 0x6a1e6c: b.ne            #0x6a1e78
    // 0x6a1e70: r1 = 0
    //     0x6a1e70: movz            x1, #0
    // 0x6a1e74: b               #0x6a1e88
    // 0x6a1e78: r2 = LoadInt32Instr(r1)
    //     0x6a1e78: sbfx            x2, x1, #1, #0x1f
    //     0x6a1e7c: tbz             w1, #0, #0x6a1e84
    //     0x6a1e80: ldur            x2, [x1, #7]
    // 0x6a1e84: mov             x1, x2
    // 0x6a1e88: cmp             x1, #2
    // 0x6a1e8c: r16 = true
    //     0x6a1e8c: add             x16, NULL, #0x20  ; true
    // 0x6a1e90: r17 = false
    //     0x6a1e90: add             x17, NULL, #0x30  ; false
    // 0x6a1e94: csel            x0, x16, x17, gt
    // 0x6a1e98: LeaveFrame
    //     0x6a1e98: mov             SP, fp
    //     0x6a1e9c: ldp             fp, lr, [SP], #0x10
    // 0x6a1ea0: ret
    //     0x6a1ea0: ret             
    // 0x6a1ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1ea4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1ea8: b               #0x6a1e20
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6a1eac, size: 0xac
    // 0x6a1eac: EnterFrame
    //     0x6a1eac: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1eb0: mov             fp, SP
    // 0x6a1eb4: AllocStack(0x10)
    //     0x6a1eb4: sub             SP, SP, #0x10
    // 0x6a1eb8: SetupParameters([dynamic _ /* r0 */])
    //     0x6a1eb8: ldr             x0, [fp, #0x10]
    //     0x6a1ebc: ldur            w3, [x0, #0x17]
    //     0x6a1ec0: add             x3, x3, HEAP, lsl #32
    //     0x6a1ec4: stur            x3, [fp, #-8]
    // 0x6a1ec8: CheckStackOverflow
    //     0x6a1ec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1ecc: cmp             SP, x16
    //     0x6a1ed0: b.ls            #0x6a1f44
    // 0x6a1ed4: r0 = LoadStaticField(0xf7c)
    //     0x6a1ed4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a1ed8: ldr             x0, [x0, #0x1ef8]
    // 0x6a1edc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a1ee0: cmp             w0, w16
    // 0x6a1ee4: b.eq            #0x6a1f4c
    // 0x6a1ee8: LoadField: r1 = r0->field_13
    //     0x6a1ee8: ldur            w1, [x0, #0x13]
    // 0x6a1eec: DecompressPointer r1
    //     0x6a1eec: add             x1, x1, HEAP, lsl #32
    // 0x6a1ef0: r2 = 62
    //     0x6a1ef0: movz            x2, #0x3e
    // 0x6a1ef4: r0 = containsKey()
    //     0x6a1ef4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a1ef8: tbnz            w0, #4, #0x6a1f34
    // 0x6a1efc: ldur            x0, [fp, #-8]
    // 0x6a1f00: LoadField: r1 = r0->field_f
    //     0x6a1f00: ldur            w1, [x0, #0xf]
    // 0x6a1f04: DecompressPointer r1
    //     0x6a1f04: add             x1, x1, HEAP, lsl #32
    // 0x6a1f08: r16 = false
    //     0x6a1f08: add             x16, NULL, #0x30  ; false
    // 0x6a1f0c: str             x16, [SP]
    // 0x6a1f10: r2 = 31
    //     0x6a1f10: movz            x2, #0x1f
    // 0x6a1f14: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x6a1f14: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x6a1f18: ldr             x4, [x4, #0x5c0]
    // 0x6a1f1c: r0 = notifyDialoguePoint()
    //     0x6a1f1c: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6a1f20: r0 = "Intermission"
    //     0x6a1f20: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x6a1f24: ldr             x0, [x0, #0x5c8]
    // 0x6a1f28: LeaveFrame
    //     0x6a1f28: mov             SP, fp
    //     0x6a1f2c: ldp             fp, lr, [SP], #0x10
    // 0x6a1f30: ret
    //     0x6a1f30: ret             
    // 0x6a1f34: r0 = Null
    //     0x6a1f34: mov             x0, NULL
    // 0x6a1f38: LeaveFrame
    //     0x6a1f38: mov             SP, fp
    //     0x6a1f3c: ldp             fp, lr, [SP], #0x10
    // 0x6a1f40: ret
    //     0x6a1f40: ret             
    // 0x6a1f44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1f44: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1f48: b               #0x6a1ed4
    // 0x6a1f4c: r9 = coreData
    //     0x6a1f4c: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6a1f50: ldr             x9, [x9, #0x530]
    // 0x6a1f54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a1f54: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6a1f58, size: 0x78
    // 0x6a1f58: EnterFrame
    //     0x6a1f58: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1f5c: mov             fp, SP
    // 0x6a1f60: AllocStack(0x18)
    //     0x6a1f60: sub             SP, SP, #0x18
    // 0x6a1f64: SetupParameters(Chapter14GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x6a1f64: stur            NULL, [fp, #-8]
    //     0x6a1f68: movz            x0, #0
    //     0x6a1f6c: add             x1, fp, w0, sxtw #2
    //     0x6a1f70: ldr             x1, [x1, #0x18]
    //     0x6a1f74: add             x2, fp, w0, sxtw #2
    //     0x6a1f78: ldr             x2, [x2, #0x10]
    //     0x6a1f7c: stur            x2, [fp, #-0x18]
    //     0x6a1f80: ldur            w3, [x1, #0x17]
    //     0x6a1f84: add             x3, x3, HEAP, lsl #32
    //     0x6a1f88: stur            x3, [fp, #-0x10]
    // 0x6a1f8c: CheckStackOverflow
    //     0x6a1f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1f90: cmp             SP, x16
    //     0x6a1f94: b.ls            #0x6a1fc8
    // 0x6a1f98: InitAsync() -> Future<void?>
    //     0x6a1f98: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6a1f9c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x6a1fa0: ldur            x2, [fp, #-0x10]
    // 0x6a1fa4: r1 = Function '<anonymous closure>':.
    //     0x6a1fa4: add             x1, PP, #0x28, lsl #12  ; [pp+0x289d0] AnonymousClosure: (0x6a1fd0), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a1fa8: ldr             x1, [x1, #0x9d0]
    // 0x6a1fac: r0 = AllocateClosure()
    //     0x6a1fac: bl              #0x826750  ; AllocateClosureStub
    // 0x6a1fb0: ldur            x1, [fp, #-0x18]
    // 0x6a1fb4: mov             x3, x0
    // 0x6a1fb8: r2 = 31
    //     0x6a1fb8: movz            x2, #0x1f
    // 0x6a1fbc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6a1fbc: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6a1fc0: r0 = displaySlackPage()
    //     0x6a1fc0: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x6a1fc4: r0 = ReturnAsync()
    //     0x6a1fc4: b               #0x353380  ; ReturnAsyncStub
    // 0x6a1fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a1fc8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a1fcc: b               #0x6a1f98
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6a1fd0, size: 0x78
    // 0x6a1fd0: EnterFrame
    //     0x6a1fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a1fd4: mov             fp, SP
    // 0x6a1fd8: AllocStack(0x8)
    //     0x6a1fd8: sub             SP, SP, #8
    // 0x6a1fdc: SetupParameters([dynamic _ /* r0 */])
    //     0x6a1fdc: ldr             x0, [fp, #0x20]
    //     0x6a1fe0: ldur            w3, [x0, #0x17]
    //     0x6a1fe4: add             x3, x3, HEAP, lsl #32
    //     0x6a1fe8: stur            x3, [fp, #-8]
    // 0x6a1fec: CheckStackOverflow
    //     0x6a1fec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a1ff0: cmp             SP, x16
    //     0x6a1ff4: b.ls            #0x6a2040
    // 0x6a1ff8: LoadField: r1 = r3->field_f
    //     0x6a1ff8: ldur            w1, [x3, #0xf]
    // 0x6a1ffc: DecompressPointer r1
    //     0x6a1ffc: add             x1, x1, HEAP, lsl #32
    // 0x6a2000: r2 = 31
    //     0x6a2000: movz            x2, #0x1f
    // 0x6a2004: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a2004: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a2008: r0 = notifyDialoguePoint()
    //     0x6a2008: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6a200c: ldr             x0, [fp, #0x10]
    // 0x6a2010: r1 = LoadInt32Instr(r0)
    //     0x6a2010: sbfx            x1, x0, #1, #0x1f
    //     0x6a2014: tbz             w0, #0, #0x6a201c
    //     0x6a2018: ldur            x1, [x0, #7]
    // 0x6a201c: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x6a201c: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x6a2020: ldur            x0, [fp, #-8]
    // 0x6a2024: LoadField: r1 = r0->field_f
    //     0x6a2024: ldur            w1, [x0, #0xf]
    // 0x6a2028: DecompressPointer r1
    //     0x6a2028: add             x1, x1, HEAP, lsl #32
    // 0x6a202c: r0 = saveDeferred()
    //     0x6a202c: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x6a2030: r0 = Null
    //     0x6a2030: mov             x0, NULL
    // 0x6a2034: LeaveFrame
    //     0x6a2034: mov             SP, fp
    //     0x6a2038: ldp             fp, lr, [SP], #0x10
    // 0x6a203c: ret
    //     0x6a203c: ret             
    // 0x6a2040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2040: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2044: b               #0x6a1ff8
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a2048, size: 0x58
    // 0x6a2048: EnterFrame
    //     0x6a2048: stp             fp, lr, [SP, #-0x10]!
    //     0x6a204c: mov             fp, SP
    // 0x6a2050: ldr             x0, [fp, #0x10]
    // 0x6a2054: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a2054: ldur            w1, [x0, #0x17]
    // 0x6a2058: DecompressPointer r1
    //     0x6a2058: add             x1, x1, HEAP, lsl #32
    // 0x6a205c: CheckStackOverflow
    //     0x6a205c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2060: cmp             SP, x16
    //     0x6a2064: b.ls            #0x6a2098
    // 0x6a2068: LoadField: r0 = r1->field_f
    //     0x6a2068: ldur            w0, [x1, #0xf]
    // 0x6a206c: DecompressPointer r0
    //     0x6a206c: add             x0, x0, HEAP, lsl #32
    // 0x6a2070: LoadField: r1 = r0->field_3f
    //     0x6a2070: ldur            w1, [x0, #0x3f]
    // 0x6a2074: DecompressPointer r1
    //     0x6a2074: add             x1, x1, HEAP, lsl #32
    // 0x6a2078: LoadField: r0 = r1->field_b
    //     0x6a2078: ldur            w0, [x1, #0xb]
    // 0x6a207c: DecompressPointer r0
    //     0x6a207c: add             x0, x0, HEAP, lsl #32
    // 0x6a2080: mov             x1, x0
    // 0x6a2084: r2 = 2
    //     0x6a2084: movz            x2, #0x2
    // 0x6a2088: r0 = containsKey()
    //     0x6a2088: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a208c: LeaveFrame
    //     0x6a208c: mov             SP, fp
    //     0x6a2090: ldp             fp, lr, [SP], #0x10
    // 0x6a2094: ret
    //     0x6a2094: ret             
    // 0x6a2098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2098: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a209c: b               #0x6a2068
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a20a0, size: 0xc
    // 0x6a20a0: r0 = "Each throughput increases I/O per second by 1%"
    //     0x6a20a0: add             x0, PP, #0x28, lsl #12  ; [pp+0x289d8] "Each throughput increases I/O per second by 1%"
    //     0x6a20a4: ldr             x0, [x0, #0x9d8]
    // 0x6a20a8: ret
    //     0x6a20a8: ret             
  }
  [closure] void applyOptimize(dynamic) {
    // ** addr: 0x6a20ac, size: 0x38
    // 0x6a20ac: EnterFrame
    //     0x6a20ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6a20b0: mov             fp, SP
    // 0x6a20b4: ldr             x0, [fp, #0x10]
    // 0x6a20b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a20b8: ldur            w1, [x0, #0x17]
    // 0x6a20bc: DecompressPointer r1
    //     0x6a20bc: add             x1, x1, HEAP, lsl #32
    // 0x6a20c0: CheckStackOverflow
    //     0x6a20c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a20c4: cmp             SP, x16
    //     0x6a20c8: b.ls            #0x6a20dc
    // 0x6a20cc: r0 = applyOptimize()
    //     0x6a20cc: bl              #0x6a20e4  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyOptimize
    // 0x6a20d0: LeaveFrame
    //     0x6a20d0: mov             SP, fp
    //     0x6a20d4: ldp             fp, lr, [SP], #0x10
    // 0x6a20d8: ret
    //     0x6a20d8: ret             
    // 0x6a20dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a20dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a20e0: b               #0x6a20cc
  }
  _ applyOptimize(/* No info */) {
    // ** addr: 0x6a20e4, size: 0x138
    // 0x6a20e4: EnterFrame
    //     0x6a20e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a20e8: mov             fp, SP
    // 0x6a20ec: AllocStack(0x18)
    //     0x6a20ec: sub             SP, SP, #0x18
    // 0x6a20f0: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */)
    //     0x6a20f0: mov             x0, x1
    //     0x6a20f4: stur            x1, [fp, #-8]
    // 0x6a20f8: CheckStackOverflow
    //     0x6a20f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a20fc: cmp             SP, x16
    //     0x6a2100: b.ls            #0x6a2214
    // 0x6a2104: mov             x1, x0
    // 0x6a2108: r0 = getOptimizePoints()
    //     0x6a2108: bl              #0x54e89c  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getOptimizePoints
    // 0x6a210c: mov             x3, x0
    // 0x6a2110: ldur            x0, [fp, #-8]
    // 0x6a2114: stur            x3, [fp, #-0x10]
    // 0x6a2118: LoadField: r1 = r0->field_13
    //     0x6a2118: ldur            w1, [x0, #0x13]
    // 0x6a211c: DecompressPointer r1
    //     0x6a211c: add             x1, x1, HEAP, lsl #32
    // 0x6a2120: r2 = 8
    //     0x6a2120: movz            x2, #0x8
    // 0x6a2124: r0 = add()
    //     0x6a2124: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6a2128: ldur            x0, [fp, #-8]
    // 0x6a212c: LoadField: r3 = r0->field_37
    //     0x6a212c: ldur            w3, [x0, #0x37]
    // 0x6a2130: DecompressPointer r3
    //     0x6a2130: add             x3, x3, HEAP, lsl #32
    // 0x6a2134: mov             x1, x3
    // 0x6a2138: stur            x3, [fp, #-0x18]
    // 0x6a213c: r2 = Instance_Chapter14Stat
    //     0x6a213c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a2140: ldr             x2, [x2, #0x1e8]
    // 0x6a2144: r0 = _getValueOrData()
    //     0x6a2144: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2148: mov             x1, x0
    // 0x6a214c: ldur            x0, [fp, #-0x18]
    // 0x6a2150: LoadField: r2 = r0->field_f
    //     0x6a2150: ldur            w2, [x0, #0xf]
    // 0x6a2154: DecompressPointer r2
    //     0x6a2154: add             x2, x2, HEAP, lsl #32
    // 0x6a2158: cmp             w2, w1
    // 0x6a215c: b.ne            #0x6a2164
    // 0x6a2160: r1 = Null
    //     0x6a2160: mov             x1, NULL
    // 0x6a2164: cmp             w1, NULL
    // 0x6a2168: b.ne            #0x6a2174
    // 0x6a216c: r1 = Instance_CustomNum
    //     0x6a216c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a2170: ldr             x1, [x1, #0xaf8]
    // 0x6a2174: ldur            x3, [fp, #-8]
    // 0x6a2178: ldur            x2, [fp, #-0x10]
    // 0x6a217c: r0 = add()
    //     0x6a217c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a2180: ldur            x1, [fp, #-0x18]
    // 0x6a2184: mov             x3, x0
    // 0x6a2188: r2 = Instance_Chapter14Stat
    //     0x6a2188: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a218c: ldr             x2, [x2, #0x1e8]
    // 0x6a2190: r0 = []=()
    //     0x6a2190: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a2194: ldur            x0, [fp, #-8]
    // 0x6a2198: LoadField: r3 = r0->field_3b
    //     0x6a2198: ldur            w3, [x0, #0x3b]
    // 0x6a219c: DecompressPointer r3
    //     0x6a219c: add             x3, x3, HEAP, lsl #32
    // 0x6a21a0: mov             x1, x3
    // 0x6a21a4: stur            x3, [fp, #-0x18]
    // 0x6a21a8: r2 = Instance_Chapter14Stat
    //     0x6a21a8: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a21ac: ldr             x2, [x2, #0x1e8]
    // 0x6a21b0: r0 = _getValueOrData()
    //     0x6a21b0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a21b4: mov             x1, x0
    // 0x6a21b8: ldur            x0, [fp, #-0x18]
    // 0x6a21bc: LoadField: r2 = r0->field_f
    //     0x6a21bc: ldur            w2, [x0, #0xf]
    // 0x6a21c0: DecompressPointer r2
    //     0x6a21c0: add             x2, x2, HEAP, lsl #32
    // 0x6a21c4: cmp             w2, w1
    // 0x6a21c8: b.ne            #0x6a21d0
    // 0x6a21cc: r1 = Null
    //     0x6a21cc: mov             x1, NULL
    // 0x6a21d0: cmp             w1, NULL
    // 0x6a21d4: b.ne            #0x6a21e0
    // 0x6a21d8: r1 = Instance_CustomNum
    //     0x6a21d8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a21dc: ldr             x1, [x1, #0xaf8]
    // 0x6a21e0: ldur            x2, [fp, #-0x10]
    // 0x6a21e4: r0 = add()
    //     0x6a21e4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a21e8: ldur            x1, [fp, #-0x18]
    // 0x6a21ec: mov             x3, x0
    // 0x6a21f0: r2 = Instance_Chapter14Stat
    //     0x6a21f0: add             x2, PP, #0x11, lsl #12  ; [pp+0x111e8] Obj!Chapter14Stat@85f861
    //     0x6a21f4: ldr             x2, [x2, #0x1e8]
    // 0x6a21f8: r0 = []=()
    //     0x6a21f8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a21fc: ldur            x1, [fp, #-8]
    // 0x6a2200: r0 = applySharedPrestige()
    //     0x6a2200: bl              #0x6a1a6c  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applySharedPrestige
    // 0x6a2204: r0 = Null
    //     0x6a2204: mov             x0, NULL
    // 0x6a2208: LeaveFrame
    //     0x6a2208: mov             SP, fp
    //     0x6a220c: ldp             fp, lr, [SP], #0x10
    // 0x6a2210: ret
    //     0x6a2210: ret             
    // 0x6a2214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2214: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2218: b               #0x6a2104
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a221c, size: 0xc
    // 0x6a221c: r0 = "Optimize"
    //     0x6a221c: add             x0, PP, #0x28, lsl #12  ; [pp+0x289e0] "Optimize"
    //     0x6a2220: ldr             x0, [x0, #0x9e0]
    // 0x6a2224: ret
    //     0x6a2224: ret             
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a2274, size: 0x4c
    // 0x6a2274: EnterFrame
    //     0x6a2274: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2278: mov             fp, SP
    // 0x6a227c: ldr             x0, [fp, #0x10]
    // 0x6a2280: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a2280: ldur            w1, [x0, #0x17]
    // 0x6a2284: DecompressPointer r1
    //     0x6a2284: add             x1, x1, HEAP, lsl #32
    // 0x6a2288: CheckStackOverflow
    //     0x6a2288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a228c: cmp             SP, x16
    //     0x6a2290: b.ls            #0x6a22b8
    // 0x6a2294: LoadField: r0 = r1->field_f
    //     0x6a2294: ldur            w0, [x1, #0xf]
    // 0x6a2298: DecompressPointer r0
    //     0x6a2298: add             x0, x0, HEAP, lsl #32
    // 0x6a229c: LoadField: r1 = r0->field_43
    //     0x6a229c: ldur            w1, [x0, #0x43]
    // 0x6a22a0: DecompressPointer r1
    //     0x6a22a0: add             x1, x1, HEAP, lsl #32
    // 0x6a22a4: r2 = 2000
    //     0x6a22a4: movz            x2, #0x7d0
    // 0x6a22a8: r0 = containsKey()
    //     0x6a22a8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a22ac: LeaveFrame
    //     0x6a22ac: mov             SP, fp
    //     0x6a22b0: ldp             fp, lr, [SP], #0x10
    // 0x6a22b4: ret
    //     0x6a22b4: ret             
    // 0x6a22b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a22b8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a22bc: b               #0x6a2294
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a22c0, size: 0xa8
    // 0x6a22c0: EnterFrame
    //     0x6a22c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a22c4: mov             fp, SP
    // 0x6a22c8: AllocStack(0x8)
    //     0x6a22c8: sub             SP, SP, #8
    // 0x6a22cc: SetupParameters([dynamic _ /* r0 */])
    //     0x6a22cc: ldr             x0, [fp, #0x10]
    //     0x6a22d0: ldur            w1, [x0, #0x17]
    //     0x6a22d4: add             x1, x1, HEAP, lsl #32
    // 0x6a22d8: CheckStackOverflow
    //     0x6a22d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a22dc: cmp             SP, x16
    //     0x6a22e0: b.ls            #0x6a2360
    // 0x6a22e4: LoadField: r0 = r1->field_f
    //     0x6a22e4: ldur            w0, [x1, #0xf]
    // 0x6a22e8: DecompressPointer r0
    //     0x6a22e8: add             x0, x0, HEAP, lsl #32
    // 0x6a22ec: LoadField: r3 = r0->field_43
    //     0x6a22ec: ldur            w3, [x0, #0x43]
    // 0x6a22f0: DecompressPointer r3
    //     0x6a22f0: add             x3, x3, HEAP, lsl #32
    // 0x6a22f4: mov             x1, x3
    // 0x6a22f8: stur            x3, [fp, #-8]
    // 0x6a22fc: r2 = 40
    //     0x6a22fc: movz            x2, #0x28
    // 0x6a2300: r0 = _getValueOrData()
    //     0x6a2300: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2304: ldur            x1, [fp, #-8]
    // 0x6a2308: LoadField: r2 = r1->field_f
    //     0x6a2308: ldur            w2, [x1, #0xf]
    // 0x6a230c: DecompressPointer r2
    //     0x6a230c: add             x2, x2, HEAP, lsl #32
    // 0x6a2310: cmp             w2, w0
    // 0x6a2314: b.ne            #0x6a2320
    // 0x6a2318: r1 = Null
    //     0x6a2318: mov             x1, NULL
    // 0x6a231c: b               #0x6a2324
    // 0x6a2320: mov             x1, x0
    // 0x6a2324: cmp             w1, NULL
    // 0x6a2328: b.ne            #0x6a2334
    // 0x6a232c: r1 = 0
    //     0x6a232c: movz            x1, #0
    // 0x6a2330: b               #0x6a2344
    // 0x6a2334: r2 = LoadInt32Instr(r1)
    //     0x6a2334: sbfx            x2, x1, #1, #0x1f
    //     0x6a2338: tbz             w1, #0, #0x6a2340
    //     0x6a233c: ldur            x2, [x1, #7]
    // 0x6a2340: mov             x1, x2
    // 0x6a2344: cmp             x1, #1
    // 0x6a2348: r16 = true
    //     0x6a2348: add             x16, NULL, #0x20  ; true
    // 0x6a234c: r17 = false
    //     0x6a234c: add             x17, NULL, #0x30  ; false
    // 0x6a2350: csel            x0, x16, x17, gt
    // 0x6a2354: LeaveFrame
    //     0x6a2354: mov             SP, fp
    //     0x6a2358: ldp             fp, lr, [SP], #0x10
    // 0x6a235c: ret
    //     0x6a235c: ret             
    // 0x6a2360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2360: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2364: b               #0x6a22e4
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2368, size: 0xc
    // 0x6a2368: r0 = "Each I/O increases main bar speed by 1%"
    //     0x6a2368: add             x0, PP, #0x28, lsl #12  ; [pp+0x289e8] "Each I/O increases main bar speed by 1%"
    //     0x6a236c: ldr             x0, [x0, #0x9e8]
    // 0x6a2370: ret
    //     0x6a2370: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2374, size: 0xa8
    // 0x6a2374: EnterFrame
    //     0x6a2374: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2378: mov             fp, SP
    // 0x6a237c: AllocStack(0x8)
    //     0x6a237c: sub             SP, SP, #8
    // 0x6a2380: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2380: ldr             x0, [fp, #0x10]
    //     0x6a2384: ldur            w1, [x0, #0x17]
    //     0x6a2388: add             x1, x1, HEAP, lsl #32
    // 0x6a238c: CheckStackOverflow
    //     0x6a238c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2390: cmp             SP, x16
    //     0x6a2394: b.ls            #0x6a2414
    // 0x6a2398: LoadField: r0 = r1->field_f
    //     0x6a2398: ldur            w0, [x1, #0xf]
    // 0x6a239c: DecompressPointer r0
    //     0x6a239c: add             x0, x0, HEAP, lsl #32
    // 0x6a23a0: LoadField: r3 = r0->field_57
    //     0x6a23a0: ldur            w3, [x0, #0x57]
    // 0x6a23a4: DecompressPointer r3
    //     0x6a23a4: add             x3, x3, HEAP, lsl #32
    // 0x6a23a8: mov             x1, x3
    // 0x6a23ac: stur            x3, [fp, #-8]
    // 0x6a23b0: r2 = Instance_Chapter14Stat
    //     0x6a23b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6a23b4: ldr             x2, [x2, #0x1d8]
    // 0x6a23b8: r0 = _getValueOrData()
    //     0x6a23b8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a23bc: mov             x1, x0
    // 0x6a23c0: ldur            x0, [fp, #-8]
    // 0x6a23c4: LoadField: r2 = r0->field_f
    //     0x6a23c4: ldur            w2, [x0, #0xf]
    // 0x6a23c8: DecompressPointer r2
    //     0x6a23c8: add             x2, x2, HEAP, lsl #32
    // 0x6a23cc: cmp             w2, w1
    // 0x6a23d0: b.ne            #0x6a23d8
    // 0x6a23d4: r1 = Null
    //     0x6a23d4: mov             x1, NULL
    // 0x6a23d8: cmp             w1, NULL
    // 0x6a23dc: b.ne            #0x6a23e8
    // 0x6a23e0: r1 = Null
    //     0x6a23e0: mov             x1, NULL
    // 0x6a23e4: b               #0x6a23f4
    // 0x6a23e8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6a23e8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6a23ec: r0 = toStringConsistentDecimalPlaces()
    //     0x6a23ec: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6a23f0: mov             x1, x0
    // 0x6a23f4: cmp             w1, NULL
    // 0x6a23f8: b.ne            #0x6a2404
    // 0x6a23fc: r0 = "0"
    //     0x6a23fc: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6a2400: b               #0x6a2408
    // 0x6a2404: mov             x0, x1
    // 0x6a2408: LeaveFrame
    //     0x6a2408: mov             SP, fp
    //     0x6a240c: ldp             fp, lr, [SP], #0x10
    // 0x6a2410: ret
    //     0x6a2410: ret             
    // 0x6a2414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2414: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2418: b               #0x6a2398
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a241c, size: 0xa8
    // 0x6a241c: EnterFrame
    //     0x6a241c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2420: mov             fp, SP
    // 0x6a2424: AllocStack(0x8)
    //     0x6a2424: sub             SP, SP, #8
    // 0x6a2428: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2428: ldr             x0, [fp, #0x10]
    //     0x6a242c: ldur            w1, [x0, #0x17]
    //     0x6a2430: add             x1, x1, HEAP, lsl #32
    // 0x6a2434: CheckStackOverflow
    //     0x6a2434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2438: cmp             SP, x16
    //     0x6a243c: b.ls            #0x6a24bc
    // 0x6a2440: LoadField: r0 = r1->field_f
    //     0x6a2440: ldur            w0, [x1, #0xf]
    // 0x6a2444: DecompressPointer r0
    //     0x6a2444: add             x0, x0, HEAP, lsl #32
    // 0x6a2448: LoadField: r3 = r0->field_37
    //     0x6a2448: ldur            w3, [x0, #0x37]
    // 0x6a244c: DecompressPointer r3
    //     0x6a244c: add             x3, x3, HEAP, lsl #32
    // 0x6a2450: mov             x1, x3
    // 0x6a2454: stur            x3, [fp, #-8]
    // 0x6a2458: r2 = Instance_Chapter14Stat
    //     0x6a2458: add             x2, PP, #0x11, lsl #12  ; [pp+0x111d8] Obj!Chapter14Stat@85f821
    //     0x6a245c: ldr             x2, [x2, #0x1d8]
    // 0x6a2460: r0 = _getValueOrData()
    //     0x6a2460: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2464: mov             x1, x0
    // 0x6a2468: ldur            x0, [fp, #-8]
    // 0x6a246c: LoadField: r2 = r0->field_f
    //     0x6a246c: ldur            w2, [x0, #0xf]
    // 0x6a2470: DecompressPointer r2
    //     0x6a2470: add             x2, x2, HEAP, lsl #32
    // 0x6a2474: cmp             w2, w1
    // 0x6a2478: b.ne            #0x6a2480
    // 0x6a247c: r1 = Null
    //     0x6a247c: mov             x1, NULL
    // 0x6a2480: cmp             w1, NULL
    // 0x6a2484: b.ne            #0x6a2490
    // 0x6a2488: r1 = Null
    //     0x6a2488: mov             x1, NULL
    // 0x6a248c: b               #0x6a249c
    // 0x6a2490: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6a2490: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6a2494: r0 = toStringConsistentDecimalPlaces()
    //     0x6a2494: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6a2498: mov             x1, x0
    // 0x6a249c: cmp             w1, NULL
    // 0x6a24a0: b.ne            #0x6a24ac
    // 0x6a24a4: r0 = "0"
    //     0x6a24a4: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6a24a8: b               #0x6a24b0
    // 0x6a24ac: mov             x0, x1
    // 0x6a24b0: LeaveFrame
    //     0x6a24b0: mov             SP, fp
    //     0x6a24b4: ldp             fp, lr, [SP], #0x10
    // 0x6a24b8: ret
    //     0x6a24b8: ret             
    // 0x6a24bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a24bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a24c0: b               #0x6a2440
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a24c4, size: 0x4c
    // 0x6a24c4: EnterFrame
    //     0x6a24c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a24c8: mov             fp, SP
    // 0x6a24cc: ldr             x0, [fp, #0x10]
    // 0x6a24d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a24d0: ldur            w1, [x0, #0x17]
    // 0x6a24d4: DecompressPointer r1
    //     0x6a24d4: add             x1, x1, HEAP, lsl #32
    // 0x6a24d8: CheckStackOverflow
    //     0x6a24d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a24dc: cmp             SP, x16
    //     0x6a24e0: b.ls            #0x6a2508
    // 0x6a24e4: LoadField: r0 = r1->field_f
    //     0x6a24e4: ldur            w0, [x1, #0xf]
    // 0x6a24e8: DecompressPointer r0
    //     0x6a24e8: add             x0, x0, HEAP, lsl #32
    // 0x6a24ec: LoadField: r1 = r0->field_43
    //     0x6a24ec: ldur            w1, [x0, #0x43]
    // 0x6a24f0: DecompressPointer r1
    //     0x6a24f0: add             x1, x1, HEAP, lsl #32
    // 0x6a24f4: r2 = 260
    //     0x6a24f4: movz            x2, #0x104
    // 0x6a24f8: r0 = containsKey()
    //     0x6a24f8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a24fc: LeaveFrame
    //     0x6a24fc: mov             SP, fp
    //     0x6a2500: ldp             fp, lr, [SP], #0x10
    // 0x6a2504: ret
    //     0x6a2504: ret             
    // 0x6a2508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2508: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a250c: b               #0x6a24e4
  }
  [closure] void <anonymous closure>(dynamic, bool?) {
    // ** addr: 0x6a2510, size: 0x50
    // 0x6a2510: EnterFrame
    //     0x6a2510: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2514: mov             fp, SP
    // 0x6a2518: CheckStackOverflow
    //     0x6a2518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a251c: cmp             SP, x16
    //     0x6a2520: b.ls            #0x6a2558
    // 0x6a2524: ldr             x0, [fp, #0x10]
    // 0x6a2528: cmp             w0, NULL
    // 0x6a252c: b.ne            #0x6a2538
    // 0x6a2530: r2 = false
    //     0x6a2530: add             x2, NULL, #0x30  ; false
    // 0x6a2534: b               #0x6a253c
    // 0x6a2538: mov             x2, x0
    // 0x6a253c: r1 = "ch14_autobuy_io"
    //     0x6a253c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a678] "ch14_autobuy_io"
    //     0x6a2540: ldr             x1, [x1, #0x678]
    // 0x6a2544: r0 = prefsSetBool()
    //     0x6a2544: bl              #0x4820f0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetBool
    // 0x6a2548: r0 = Null
    //     0x6a2548: mov             x0, NULL
    // 0x6a254c: LeaveFrame
    //     0x6a254c: mov             SP, fp
    //     0x6a2550: ldp             fp, lr, [SP], #0x10
    // 0x6a2554: ret
    //     0x6a2554: ret             
    // 0x6a2558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2558: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a255c: b               #0x6a2524
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a2560, size: 0x40
    // 0x6a2560: EnterFrame
    //     0x6a2560: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2564: mov             fp, SP
    // 0x6a2568: CheckStackOverflow
    //     0x6a2568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a256c: cmp             SP, x16
    //     0x6a2570: b.ls            #0x6a2598
    // 0x6a2574: r1 = "ch14_autobuy_io"
    //     0x6a2574: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a678] "ch14_autobuy_io"
    //     0x6a2578: ldr             x1, [x1, #0x678]
    // 0x6a257c: r0 = prefsGetBool()
    //     0x6a257c: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x6a2580: cmp             w0, NULL
    // 0x6a2584: b.ne            #0x6a258c
    // 0x6a2588: r0 = false
    //     0x6a2588: add             x0, NULL, #0x30  ; false
    // 0x6a258c: LeaveFrame
    //     0x6a258c: mov             SP, fp
    //     0x6a2590: ldp             fp, lr, [SP], #0x10
    // 0x6a2594: ret
    //     0x6a2594: ret             
    // 0x6a2598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2598: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a259c: b               #0x6a2574
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a25ec, size: 0x98
    // 0x6a25ec: EnterFrame
    //     0x6a25ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6a25f0: mov             fp, SP
    // 0x6a25f4: AllocStack(0x8)
    //     0x6a25f4: sub             SP, SP, #8
    // 0x6a25f8: SetupParameters([dynamic _ /* r0 */])
    //     0x6a25f8: ldr             x0, [fp, #0x10]
    //     0x6a25fc: ldur            w3, [x0, #0x17]
    //     0x6a2600: add             x3, x3, HEAP, lsl #32
    //     0x6a2604: stur            x3, [fp, #-8]
    // 0x6a2608: CheckStackOverflow
    //     0x6a2608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a260c: cmp             SP, x16
    //     0x6a2610: b.ls            #0x6a2670
    // 0x6a2614: r0 = LoadStaticField(0xf7c)
    //     0x6a2614: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a2618: ldr             x0, [x0, #0x1ef8]
    // 0x6a261c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a2620: cmp             w0, w16
    // 0x6a2624: b.eq            #0x6a2678
    // 0x6a2628: LoadField: r1 = r0->field_13
    //     0x6a2628: ldur            w1, [x0, #0x13]
    // 0x6a262c: DecompressPointer r1
    //     0x6a262c: add             x1, x1, HEAP, lsl #32
    // 0x6a2630: r2 = 60
    //     0x6a2630: movz            x2, #0x3c
    // 0x6a2634: r0 = containsKey()
    //     0x6a2634: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a2638: tbnz            w0, #4, #0x6a2660
    // 0x6a263c: ldur            x0, [fp, #-8]
    // 0x6a2640: LoadField: r1 = r0->field_f
    //     0x6a2640: ldur            w1, [x0, #0xf]
    // 0x6a2644: DecompressPointer r1
    //     0x6a2644: add             x1, x1, HEAP, lsl #32
    // 0x6a2648: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x6a2648: ldur            w0, [x1, #0x17]
    // 0x6a264c: DecompressPointer r0
    //     0x6a264c: add             x0, x0, HEAP, lsl #32
    // 0x6a2650: mov             x1, x0
    // 0x6a2654: r2 = 6
    //     0x6a2654: movz            x2, #0x6
    // 0x6a2658: r0 = contains()
    //     0x6a2658: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a265c: b               #0x6a2664
    // 0x6a2660: r0 = false
    //     0x6a2660: add             x0, NULL, #0x30  ; false
    // 0x6a2664: LeaveFrame
    //     0x6a2664: mov             SP, fp
    //     0x6a2668: ldp             fp, lr, [SP], #0x10
    // 0x6a266c: ret
    //     0x6a266c: ret             
    // 0x6a2670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2670: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2674: b               #0x6a2614
    // 0x6a2678: r9 = coreData
    //     0x6a2678: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6a267c: ldr             x9, [x9, #0x530]
    // 0x6a2680: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a2680: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2684, size: 0xc
    // 0x6a2684: r0 = "Each op increases navigation per second by 1%"
    //     0x6a2684: add             x0, PP, #0x28, lsl #12  ; [pp+0x289f0] "Each op increases navigation per second by 1%"
    //     0x6a2688: ldr             x0, [x0, #0x9f0]
    // 0x6a268c: ret
    //     0x6a268c: ret             
  }
  [closure] void applyRewriteInRust(dynamic) {
    // ** addr: 0x6a2690, size: 0x38
    // 0x6a2690: EnterFrame
    //     0x6a2690: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2694: mov             fp, SP
    // 0x6a2698: ldr             x0, [fp, #0x10]
    // 0x6a269c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a269c: ldur            w1, [x0, #0x17]
    // 0x6a26a0: DecompressPointer r1
    //     0x6a26a0: add             x1, x1, HEAP, lsl #32
    // 0x6a26a4: CheckStackOverflow
    //     0x6a26a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a26a8: cmp             SP, x16
    //     0x6a26ac: b.ls            #0x6a26c0
    // 0x6a26b0: r0 = applyRewriteInRust()
    //     0x6a26b0: bl              #0x6a26c8  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applyRewriteInRust
    // 0x6a26b4: LeaveFrame
    //     0x6a26b4: mov             SP, fp
    //     0x6a26b8: ldp             fp, lr, [SP], #0x10
    // 0x6a26bc: ret
    //     0x6a26bc: ret             
    // 0x6a26c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a26c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a26c4: b               #0x6a26b0
  }
  _ applyRewriteInRust(/* No info */) {
    // ** addr: 0x6a26c8, size: 0x138
    // 0x6a26c8: EnterFrame
    //     0x6a26c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a26cc: mov             fp, SP
    // 0x6a26d0: AllocStack(0x18)
    //     0x6a26d0: sub             SP, SP, #0x18
    // 0x6a26d4: SetupParameters(Chapter14GameState this /* r1 => r0, fp-0x8 */)
    //     0x6a26d4: mov             x0, x1
    //     0x6a26d8: stur            x1, [fp, #-8]
    // 0x6a26dc: CheckStackOverflow
    //     0x6a26dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a26e0: cmp             SP, x16
    //     0x6a26e4: b.ls            #0x6a27f8
    // 0x6a26e8: mov             x1, x0
    // 0x6a26ec: r0 = getRewriteInRustPoints()
    //     0x6a26ec: bl              #0x54e9cc  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getRewriteInRustPoints
    // 0x6a26f0: mov             x3, x0
    // 0x6a26f4: ldur            x0, [fp, #-8]
    // 0x6a26f8: stur            x3, [fp, #-0x10]
    // 0x6a26fc: LoadField: r1 = r0->field_13
    //     0x6a26fc: ldur            w1, [x0, #0x13]
    // 0x6a2700: DecompressPointer r1
    //     0x6a2700: add             x1, x1, HEAP, lsl #32
    // 0x6a2704: r2 = 4
    //     0x6a2704: movz            x2, #0x4
    // 0x6a2708: r0 = add()
    //     0x6a2708: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6a270c: ldur            x0, [fp, #-8]
    // 0x6a2710: LoadField: r3 = r0->field_37
    //     0x6a2710: ldur            w3, [x0, #0x37]
    // 0x6a2714: DecompressPointer r3
    //     0x6a2714: add             x3, x3, HEAP, lsl #32
    // 0x6a2718: mov             x1, x3
    // 0x6a271c: stur            x3, [fp, #-0x18]
    // 0x6a2720: r2 = Instance_Chapter14Stat
    //     0x6a2720: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a2724: ldr             x2, [x2, #0x1c8]
    // 0x6a2728: r0 = _getValueOrData()
    //     0x6a2728: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a272c: mov             x1, x0
    // 0x6a2730: ldur            x0, [fp, #-0x18]
    // 0x6a2734: LoadField: r2 = r0->field_f
    //     0x6a2734: ldur            w2, [x0, #0xf]
    // 0x6a2738: DecompressPointer r2
    //     0x6a2738: add             x2, x2, HEAP, lsl #32
    // 0x6a273c: cmp             w2, w1
    // 0x6a2740: b.ne            #0x6a2748
    // 0x6a2744: r1 = Null
    //     0x6a2744: mov             x1, NULL
    // 0x6a2748: cmp             w1, NULL
    // 0x6a274c: b.ne            #0x6a2758
    // 0x6a2750: r1 = Instance_CustomNum
    //     0x6a2750: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a2754: ldr             x1, [x1, #0xaf8]
    // 0x6a2758: ldur            x3, [fp, #-8]
    // 0x6a275c: ldur            x2, [fp, #-0x10]
    // 0x6a2760: r0 = add()
    //     0x6a2760: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a2764: ldur            x1, [fp, #-0x18]
    // 0x6a2768: mov             x3, x0
    // 0x6a276c: r2 = Instance_Chapter14Stat
    //     0x6a276c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a2770: ldr             x2, [x2, #0x1c8]
    // 0x6a2774: r0 = []=()
    //     0x6a2774: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a2778: ldur            x0, [fp, #-8]
    // 0x6a277c: LoadField: r3 = r0->field_3b
    //     0x6a277c: ldur            w3, [x0, #0x3b]
    // 0x6a2780: DecompressPointer r3
    //     0x6a2780: add             x3, x3, HEAP, lsl #32
    // 0x6a2784: mov             x1, x3
    // 0x6a2788: stur            x3, [fp, #-0x18]
    // 0x6a278c: r2 = Instance_Chapter14Stat
    //     0x6a278c: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a2790: ldr             x2, [x2, #0x1c8]
    // 0x6a2794: r0 = _getValueOrData()
    //     0x6a2794: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2798: mov             x1, x0
    // 0x6a279c: ldur            x0, [fp, #-0x18]
    // 0x6a27a0: LoadField: r2 = r0->field_f
    //     0x6a27a0: ldur            w2, [x0, #0xf]
    // 0x6a27a4: DecompressPointer r2
    //     0x6a27a4: add             x2, x2, HEAP, lsl #32
    // 0x6a27a8: cmp             w2, w1
    // 0x6a27ac: b.ne            #0x6a27b4
    // 0x6a27b0: r1 = Null
    //     0x6a27b0: mov             x1, NULL
    // 0x6a27b4: cmp             w1, NULL
    // 0x6a27b8: b.ne            #0x6a27c4
    // 0x6a27bc: r1 = Instance_CustomNum
    //     0x6a27bc: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a27c0: ldr             x1, [x1, #0xaf8]
    // 0x6a27c4: ldur            x2, [fp, #-0x10]
    // 0x6a27c8: r0 = add()
    //     0x6a27c8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a27cc: ldur            x1, [fp, #-0x18]
    // 0x6a27d0: mov             x3, x0
    // 0x6a27d4: r2 = Instance_Chapter14Stat
    //     0x6a27d4: add             x2, PP, #0x11, lsl #12  ; [pp+0x111c8] Obj!Chapter14Stat@85f881
    //     0x6a27d8: ldr             x2, [x2, #0x1c8]
    // 0x6a27dc: r0 = []=()
    //     0x6a27dc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a27e0: ldur            x1, [fp, #-8]
    // 0x6a27e4: r0 = applySharedPrestige()
    //     0x6a27e4: bl              #0x6a1a6c  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::applySharedPrestige
    // 0x6a27e8: r0 = Null
    //     0x6a27e8: mov             x0, NULL
    // 0x6a27ec: LeaveFrame
    //     0x6a27ec: mov             SP, fp
    //     0x6a27f0: ldp             fp, lr, [SP], #0x10
    // 0x6a27f4: ret
    //     0x6a27f4: ret             
    // 0x6a27f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a27f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a27fc: b               #0x6a26e8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2800, size: 0xc
    // 0x6a2800: r0 = "Rewrite In Rust"
    //     0x6a2800: add             x0, PP, #0x28, lsl #12  ; [pp+0x289f8] "Rewrite In Rust"
    //     0x6a2804: ldr             x0, [x0, #0x9f8]
    // 0x6a2808: ret
    //     0x6a2808: ret             
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a280c, size: 0x4c
    // 0x6a280c: EnterFrame
    //     0x6a280c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2810: mov             fp, SP
    // 0x6a2814: ldr             x0, [fp, #0x10]
    // 0x6a2818: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a2818: ldur            w1, [x0, #0x17]
    // 0x6a281c: DecompressPointer r1
    //     0x6a281c: add             x1, x1, HEAP, lsl #32
    // 0x6a2820: CheckStackOverflow
    //     0x6a2820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2824: cmp             SP, x16
    //     0x6a2828: b.ls            #0x6a2850
    // 0x6a282c: LoadField: r0 = r1->field_f
    //     0x6a282c: ldur            w0, [x1, #0xf]
    // 0x6a2830: DecompressPointer r0
    //     0x6a2830: add             x0, x0, HEAP, lsl #32
    // 0x6a2834: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a2834: ldur            w1, [x0, #0x17]
    // 0x6a2838: DecompressPointer r1
    //     0x6a2838: add             x1, x1, HEAP, lsl #32
    // 0x6a283c: r2 = 6
    //     0x6a283c: movz            x2, #0x6
    // 0x6a2840: r0 = contains()
    //     0x6a2840: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a2844: LeaveFrame
    //     0x6a2844: mov             SP, fp
    //     0x6a2848: ldp             fp, lr, [SP], #0x10
    // 0x6a284c: ret
    //     0x6a284c: ret             
    // 0x6a2850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2850: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2854: b               #0x6a282c
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6a2858, size: 0xac
    // 0x6a2858: EnterFrame
    //     0x6a2858: stp             fp, lr, [SP, #-0x10]!
    //     0x6a285c: mov             fp, SP
    // 0x6a2860: AllocStack(0x10)
    //     0x6a2860: sub             SP, SP, #0x10
    // 0x6a2864: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2864: ldr             x0, [fp, #0x10]
    //     0x6a2868: ldur            w3, [x0, #0x17]
    //     0x6a286c: add             x3, x3, HEAP, lsl #32
    //     0x6a2870: stur            x3, [fp, #-8]
    // 0x6a2874: CheckStackOverflow
    //     0x6a2874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2878: cmp             SP, x16
    //     0x6a287c: b.ls            #0x6a28f0
    // 0x6a2880: r0 = LoadStaticField(0xf7c)
    //     0x6a2880: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a2884: ldr             x0, [x0, #0x1ef8]
    // 0x6a2888: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a288c: cmp             w0, w16
    // 0x6a2890: b.eq            #0x6a28f8
    // 0x6a2894: LoadField: r1 = r0->field_13
    //     0x6a2894: ldur            w1, [x0, #0x13]
    // 0x6a2898: DecompressPointer r1
    //     0x6a2898: add             x1, x1, HEAP, lsl #32
    // 0x6a289c: r2 = 60
    //     0x6a289c: movz            x2, #0x3c
    // 0x6a28a0: r0 = containsKey()
    //     0x6a28a0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a28a4: tbnz            w0, #4, #0x6a28e0
    // 0x6a28a8: ldur            x0, [fp, #-8]
    // 0x6a28ac: LoadField: r1 = r0->field_f
    //     0x6a28ac: ldur            w1, [x0, #0xf]
    // 0x6a28b0: DecompressPointer r1
    //     0x6a28b0: add             x1, x1, HEAP, lsl #32
    // 0x6a28b4: r16 = false
    //     0x6a28b4: add             x16, NULL, #0x30  ; false
    // 0x6a28b8: str             x16, [SP]
    // 0x6a28bc: r2 = 30
    //     0x6a28bc: movz            x2, #0x1e
    // 0x6a28c0: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x6a28c0: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x6a28c4: ldr             x4, [x4, #0x5c0]
    // 0x6a28c8: r0 = notifyDialoguePoint()
    //     0x6a28c8: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6a28cc: r0 = "Intermission"
    //     0x6a28cc: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x6a28d0: ldr             x0, [x0, #0x5c8]
    // 0x6a28d4: LeaveFrame
    //     0x6a28d4: mov             SP, fp
    //     0x6a28d8: ldp             fp, lr, [SP], #0x10
    // 0x6a28dc: ret
    //     0x6a28dc: ret             
    // 0x6a28e0: r0 = Null
    //     0x6a28e0: mov             x0, NULL
    // 0x6a28e4: LeaveFrame
    //     0x6a28e4: mov             SP, fp
    //     0x6a28e8: ldp             fp, lr, [SP], #0x10
    // 0x6a28ec: ret
    //     0x6a28ec: ret             
    // 0x6a28f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a28f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a28f4: b               #0x6a2880
    // 0x6a28f8: r9 = coreData
    //     0x6a28f8: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6a28fc: ldr             x9, [x9, #0x530]
    // 0x6a2900: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a2900: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6a2904, size: 0x78
    // 0x6a2904: EnterFrame
    //     0x6a2904: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2908: mov             fp, SP
    // 0x6a290c: AllocStack(0x18)
    //     0x6a290c: sub             SP, SP, #0x18
    // 0x6a2910: SetupParameters(Chapter14GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x6a2910: stur            NULL, [fp, #-8]
    //     0x6a2914: movz            x0, #0
    //     0x6a2918: add             x1, fp, w0, sxtw #2
    //     0x6a291c: ldr             x1, [x1, #0x18]
    //     0x6a2920: add             x2, fp, w0, sxtw #2
    //     0x6a2924: ldr             x2, [x2, #0x10]
    //     0x6a2928: stur            x2, [fp, #-0x18]
    //     0x6a292c: ldur            w3, [x1, #0x17]
    //     0x6a2930: add             x3, x3, HEAP, lsl #32
    //     0x6a2934: stur            x3, [fp, #-0x10]
    // 0x6a2938: CheckStackOverflow
    //     0x6a2938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a293c: cmp             SP, x16
    //     0x6a2940: b.ls            #0x6a2974
    // 0x6a2944: InitAsync() -> Future<void?>
    //     0x6a2944: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6a2948: bl              #0x34b9a0  ; InitAsyncStub
    // 0x6a294c: ldur            x2, [fp, #-0x10]
    // 0x6a2950: r1 = Function '<anonymous closure>':.
    //     0x6a2950: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a00] AnonymousClosure: (0x6a297c), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::build (0x69f870)
    //     0x6a2954: ldr             x1, [x1, #0xa00]
    // 0x6a2958: r0 = AllocateClosure()
    //     0x6a2958: bl              #0x826750  ; AllocateClosureStub
    // 0x6a295c: ldur            x1, [fp, #-0x18]
    // 0x6a2960: mov             x3, x0
    // 0x6a2964: r2 = 30
    //     0x6a2964: movz            x2, #0x1e
    // 0x6a2968: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6a2968: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6a296c: r0 = displaySlackPage()
    //     0x6a296c: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x6a2970: r0 = ReturnAsync()
    //     0x6a2970: b               #0x353380  ; ReturnAsyncStub
    // 0x6a2974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2974: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2978: b               #0x6a2944
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6a297c, size: 0x78
    // 0x6a297c: EnterFrame
    //     0x6a297c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2980: mov             fp, SP
    // 0x6a2984: AllocStack(0x8)
    //     0x6a2984: sub             SP, SP, #8
    // 0x6a2988: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2988: ldr             x0, [fp, #0x20]
    //     0x6a298c: ldur            w3, [x0, #0x17]
    //     0x6a2990: add             x3, x3, HEAP, lsl #32
    //     0x6a2994: stur            x3, [fp, #-8]
    // 0x6a2998: CheckStackOverflow
    //     0x6a2998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a299c: cmp             SP, x16
    //     0x6a29a0: b.ls            #0x6a29ec
    // 0x6a29a4: LoadField: r1 = r3->field_f
    //     0x6a29a4: ldur            w1, [x3, #0xf]
    // 0x6a29a8: DecompressPointer r1
    //     0x6a29a8: add             x1, x1, HEAP, lsl #32
    // 0x6a29ac: r2 = 30
    //     0x6a29ac: movz            x2, #0x1e
    // 0x6a29b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a29b0: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a29b4: r0 = notifyDialoguePoint()
    //     0x6a29b4: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6a29b8: ldr             x0, [fp, #0x10]
    // 0x6a29bc: r1 = LoadInt32Instr(r0)
    //     0x6a29bc: sbfx            x1, x0, #1, #0x1f
    //     0x6a29c0: tbz             w0, #0, #0x6a29c8
    //     0x6a29c4: ldur            x1, [x0, #7]
    // 0x6a29c8: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x6a29c8: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x6a29cc: ldur            x0, [fp, #-8]
    // 0x6a29d0: LoadField: r1 = r0->field_f
    //     0x6a29d0: ldur            w1, [x0, #0xf]
    // 0x6a29d4: DecompressPointer r1
    //     0x6a29d4: add             x1, x1, HEAP, lsl #32
    // 0x6a29d8: r0 = saveDeferred()
    //     0x6a29d8: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x6a29dc: r0 = Null
    //     0x6a29dc: mov             x0, NULL
    // 0x6a29e0: LeaveFrame
    //     0x6a29e0: mov             SP, fp
    //     0x6a29e4: ldp             fp, lr, [SP], #0x10
    // 0x6a29e8: ret
    //     0x6a29e8: ret             
    // 0x6a29ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a29ec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a29f0: b               #0x6a29a4
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a29f4, size: 0x44
    // 0x6a29f4: ldr             x1, [SP]
    // 0x6a29f8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6a29f8: ldur            w2, [x1, #0x17]
    // 0x6a29fc: DecompressPointer r2
    //     0x6a29fc: add             x2, x2, HEAP, lsl #32
    // 0x6a2a00: LoadField: r1 = r2->field_f
    //     0x6a2a00: ldur            w1, [x2, #0xf]
    // 0x6a2a04: DecompressPointer r1
    //     0x6a2a04: add             x1, x1, HEAP, lsl #32
    // 0x6a2a08: LoadField: r2 = r1->field_1b
    //     0x6a2a08: ldur            w2, [x1, #0x1b]
    // 0x6a2a0c: DecompressPointer r2
    //     0x6a2a0c: add             x2, x2, HEAP, lsl #32
    // 0x6a2a10: LoadField: r1 = r2->field_13
    //     0x6a2a10: ldur            w1, [x2, #0x13]
    // 0x6a2a14: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x6a2a14: ldur            w3, [x2, #0x17]
    // 0x6a2a18: r2 = LoadInt32Instr(r1)
    //     0x6a2a18: sbfx            x2, x1, #1, #0x1f
    // 0x6a2a1c: r1 = LoadInt32Instr(r3)
    //     0x6a2a1c: sbfx            x1, x3, #1, #0x1f
    // 0x6a2a20: sub             x3, x2, x1
    // 0x6a2a24: cbnz            x3, #0x6a2a30
    // 0x6a2a28: r0 = false
    //     0x6a2a28: add             x0, NULL, #0x30  ; false
    // 0x6a2a2c: b               #0x6a2a34
    // 0x6a2a30: r0 = true
    //     0x6a2a30: add             x0, NULL, #0x20  ; true
    // 0x6a2a34: ret
    //     0x6a2a34: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2a38, size: 0xc
    // 0x6a2a38: r0 = "Each navigation increases segfaults per second by 1%"
    //     0x6a2a38: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a08] "Each navigation increases segfaults per second by 1%"
    //     0x6a2a3c: ldr             x0, [x0, #0xa08]
    // 0x6a2a40: ret
    //     0x6a2a40: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2a44, size: 0xa8
    // 0x6a2a44: EnterFrame
    //     0x6a2a44: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2a48: mov             fp, SP
    // 0x6a2a4c: AllocStack(0x8)
    //     0x6a2a4c: sub             SP, SP, #8
    // 0x6a2a50: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2a50: ldr             x0, [fp, #0x10]
    //     0x6a2a54: ldur            w1, [x0, #0x17]
    //     0x6a2a58: add             x1, x1, HEAP, lsl #32
    // 0x6a2a5c: CheckStackOverflow
    //     0x6a2a5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2a60: cmp             SP, x16
    //     0x6a2a64: b.ls            #0x6a2ae4
    // 0x6a2a68: LoadField: r0 = r1->field_f
    //     0x6a2a68: ldur            w0, [x1, #0xf]
    // 0x6a2a6c: DecompressPointer r0
    //     0x6a2a6c: add             x0, x0, HEAP, lsl #32
    // 0x6a2a70: LoadField: r3 = r0->field_57
    //     0x6a2a70: ldur            w3, [x0, #0x57]
    // 0x6a2a74: DecompressPointer r3
    //     0x6a2a74: add             x3, x3, HEAP, lsl #32
    // 0x6a2a78: mov             x1, x3
    // 0x6a2a7c: stur            x3, [fp, #-8]
    // 0x6a2a80: r2 = Instance_Chapter14Stat
    //     0x6a2a80: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x6a2a84: ldr             x2, [x2, #0x1b8]
    // 0x6a2a88: r0 = _getValueOrData()
    //     0x6a2a88: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2a8c: mov             x1, x0
    // 0x6a2a90: ldur            x0, [fp, #-8]
    // 0x6a2a94: LoadField: r2 = r0->field_f
    //     0x6a2a94: ldur            w2, [x0, #0xf]
    // 0x6a2a98: DecompressPointer r2
    //     0x6a2a98: add             x2, x2, HEAP, lsl #32
    // 0x6a2a9c: cmp             w2, w1
    // 0x6a2aa0: b.ne            #0x6a2aa8
    // 0x6a2aa4: r1 = Null
    //     0x6a2aa4: mov             x1, NULL
    // 0x6a2aa8: cmp             w1, NULL
    // 0x6a2aac: b.ne            #0x6a2ab8
    // 0x6a2ab0: r1 = Null
    //     0x6a2ab0: mov             x1, NULL
    // 0x6a2ab4: b               #0x6a2ac4
    // 0x6a2ab8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6a2ab8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6a2abc: r0 = toStringConsistentDecimalPlaces()
    //     0x6a2abc: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6a2ac0: mov             x1, x0
    // 0x6a2ac4: cmp             w1, NULL
    // 0x6a2ac8: b.ne            #0x6a2ad4
    // 0x6a2acc: r0 = "0"
    //     0x6a2acc: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6a2ad0: b               #0x6a2ad8
    // 0x6a2ad4: mov             x0, x1
    // 0x6a2ad8: LeaveFrame
    //     0x6a2ad8: mov             SP, fp
    //     0x6a2adc: ldp             fp, lr, [SP], #0x10
    // 0x6a2ae0: ret
    //     0x6a2ae0: ret             
    // 0x6a2ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2ae4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2ae8: b               #0x6a2a68
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a2aec, size: 0xa8
    // 0x6a2aec: EnterFrame
    //     0x6a2aec: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2af0: mov             fp, SP
    // 0x6a2af4: AllocStack(0x8)
    //     0x6a2af4: sub             SP, SP, #8
    // 0x6a2af8: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2af8: ldr             x0, [fp, #0x10]
    //     0x6a2afc: ldur            w1, [x0, #0x17]
    //     0x6a2b00: add             x1, x1, HEAP, lsl #32
    // 0x6a2b04: CheckStackOverflow
    //     0x6a2b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2b08: cmp             SP, x16
    //     0x6a2b0c: b.ls            #0x6a2b8c
    // 0x6a2b10: LoadField: r0 = r1->field_f
    //     0x6a2b10: ldur            w0, [x1, #0xf]
    // 0x6a2b14: DecompressPointer r0
    //     0x6a2b14: add             x0, x0, HEAP, lsl #32
    // 0x6a2b18: LoadField: r3 = r0->field_37
    //     0x6a2b18: ldur            w3, [x0, #0x37]
    // 0x6a2b1c: DecompressPointer r3
    //     0x6a2b1c: add             x3, x3, HEAP, lsl #32
    // 0x6a2b20: mov             x1, x3
    // 0x6a2b24: stur            x3, [fp, #-8]
    // 0x6a2b28: r2 = Instance_Chapter14Stat
    //     0x6a2b28: add             x2, PP, #0x11, lsl #12  ; [pp+0x111b8] Obj!Chapter14Stat@85f8a1
    //     0x6a2b2c: ldr             x2, [x2, #0x1b8]
    // 0x6a2b30: r0 = _getValueOrData()
    //     0x6a2b30: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2b34: mov             x1, x0
    // 0x6a2b38: ldur            x0, [fp, #-8]
    // 0x6a2b3c: LoadField: r2 = r0->field_f
    //     0x6a2b3c: ldur            w2, [x0, #0xf]
    // 0x6a2b40: DecompressPointer r2
    //     0x6a2b40: add             x2, x2, HEAP, lsl #32
    // 0x6a2b44: cmp             w2, w1
    // 0x6a2b48: b.ne            #0x6a2b50
    // 0x6a2b4c: r1 = Null
    //     0x6a2b4c: mov             x1, NULL
    // 0x6a2b50: cmp             w1, NULL
    // 0x6a2b54: b.ne            #0x6a2b60
    // 0x6a2b58: r1 = Null
    //     0x6a2b58: mov             x1, NULL
    // 0x6a2b5c: b               #0x6a2b6c
    // 0x6a2b60: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6a2b60: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6a2b64: r0 = toStringConsistentDecimalPlaces()
    //     0x6a2b64: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6a2b68: mov             x1, x0
    // 0x6a2b6c: cmp             w1, NULL
    // 0x6a2b70: b.ne            #0x6a2b7c
    // 0x6a2b74: r0 = "0"
    //     0x6a2b74: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6a2b78: b               #0x6a2b80
    // 0x6a2b7c: mov             x0, x1
    // 0x6a2b80: LeaveFrame
    //     0x6a2b80: mov             SP, fp
    //     0x6a2b84: ldp             fp, lr, [SP], #0x10
    // 0x6a2b88: ret
    //     0x6a2b88: ret             
    // 0x6a2b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2b8c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2b90: b               #0x6a2b10
  }
  [closure] void <anonymous closure>(dynamic, bool?) {
    // ** addr: 0x6a2be0, size: 0x50
    // 0x6a2be0: EnterFrame
    //     0x6a2be0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2be4: mov             fp, SP
    // 0x6a2be8: CheckStackOverflow
    //     0x6a2be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2bec: cmp             SP, x16
    //     0x6a2bf0: b.ls            #0x6a2c28
    // 0x6a2bf4: ldr             x0, [fp, #0x10]
    // 0x6a2bf8: cmp             w0, NULL
    // 0x6a2bfc: b.ne            #0x6a2c08
    // 0x6a2c00: r2 = false
    //     0x6a2c00: add             x2, NULL, #0x30  ; false
    // 0x6a2c04: b               #0x6a2c0c
    // 0x6a2c08: mov             x2, x0
    // 0x6a2c0c: r1 = "ch14_autobuy_navigation"
    //     0x6a2c0c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a670] "ch14_autobuy_navigation"
    //     0x6a2c10: ldr             x1, [x1, #0x670]
    // 0x6a2c14: r0 = prefsSetBool()
    //     0x6a2c14: bl              #0x4820f0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetBool
    // 0x6a2c18: r0 = Null
    //     0x6a2c18: mov             x0, NULL
    // 0x6a2c1c: LeaveFrame
    //     0x6a2c1c: mov             SP, fp
    //     0x6a2c20: ldp             fp, lr, [SP], #0x10
    // 0x6a2c24: ret
    //     0x6a2c24: ret             
    // 0x6a2c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2c28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2c2c: b               #0x6a2bf4
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a2c30, size: 0x40
    // 0x6a2c30: EnterFrame
    //     0x6a2c30: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2c34: mov             fp, SP
    // 0x6a2c38: CheckStackOverflow
    //     0x6a2c38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2c3c: cmp             SP, x16
    //     0x6a2c40: b.ls            #0x6a2c68
    // 0x6a2c44: r1 = "ch14_autobuy_navigation"
    //     0x6a2c44: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a670] "ch14_autobuy_navigation"
    //     0x6a2c48: ldr             x1, [x1, #0x670]
    // 0x6a2c4c: r0 = prefsGetBool()
    //     0x6a2c4c: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x6a2c50: cmp             w0, NULL
    // 0x6a2c54: b.ne            #0x6a2c5c
    // 0x6a2c58: r0 = false
    //     0x6a2c58: add             x0, NULL, #0x30  ; false
    // 0x6a2c5c: LeaveFrame
    //     0x6a2c5c: mov             SP, fp
    //     0x6a2c60: ldp             fp, lr, [SP], #0x10
    // 0x6a2c64: ret
    //     0x6a2c64: ret             
    // 0x6a2c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2c68: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2c6c: b               #0x6a2c44
  }
  [closure] double <anonymous closure>(dynamic, int) {
    // ** addr: 0x6a2c70, size: 0xe8
    // 0x6a2c70: EnterFrame
    //     0x6a2c70: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2c74: mov             fp, SP
    // 0x6a2c78: AllocStack(0x18)
    //     0x6a2c78: sub             SP, SP, #0x18
    // 0x6a2c7c: SetupParameters([dynamic _ /* r0 */])
    //     0x6a2c7c: ldr             x0, [fp, #0x18]
    //     0x6a2c80: ldur            w1, [x0, #0x17]
    //     0x6a2c84: add             x1, x1, HEAP, lsl #32
    // 0x6a2c88: CheckStackOverflow
    //     0x6a2c88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2c8c: cmp             SP, x16
    //     0x6a2c90: b.ls            #0x6a2d40
    // 0x6a2c94: LoadField: r0 = r1->field_f
    //     0x6a2c94: ldur            w0, [x1, #0xf]
    // 0x6a2c98: DecompressPointer r0
    //     0x6a2c98: add             x0, x0, HEAP, lsl #32
    // 0x6a2c9c: LoadField: r3 = r0->field_43
    //     0x6a2c9c: ldur            w3, [x0, #0x43]
    // 0x6a2ca0: DecompressPointer r3
    //     0x6a2ca0: add             x3, x3, HEAP, lsl #32
    // 0x6a2ca4: mov             x1, x3
    // 0x6a2ca8: stur            x3, [fp, #-8]
    // 0x6a2cac: r2 = 20
    //     0x6a2cac: movz            x2, #0x14
    // 0x6a2cb0: r0 = _getValueOrData()
    //     0x6a2cb0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a2cb4: mov             x1, x0
    // 0x6a2cb8: ldur            x0, [fp, #-8]
    // 0x6a2cbc: LoadField: r2 = r0->field_f
    //     0x6a2cbc: ldur            w2, [x0, #0xf]
    // 0x6a2cc0: DecompressPointer r2
    //     0x6a2cc0: add             x2, x2, HEAP, lsl #32
    // 0x6a2cc4: cmp             w2, w1
    // 0x6a2cc8: b.ne            #0x6a2cd4
    // 0x6a2ccc: r0 = Null
    //     0x6a2ccc: mov             x0, NULL
    // 0x6a2cd0: b               #0x6a2cd8
    // 0x6a2cd4: mov             x0, x1
    // 0x6a2cd8: cmp             w0, NULL
    // 0x6a2cdc: b.ne            #0x6a2ce8
    // 0x6a2ce0: r1 = Null
    //     0x6a2ce0: mov             x1, NULL
    // 0x6a2ce4: b               #0x6a2cf4
    // 0x6a2ce8: stp             x0, NULL, [SP]
    // 0x6a2cec: r0 = _Double.fromInteger()
    //     0x6a2cec: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x6a2cf0: mov             x1, x0
    // 0x6a2cf4: cmp             w1, NULL
    // 0x6a2cf8: b.ne            #0x6a2d04
    // 0x6a2cfc: d0 = 0.000000
    //     0x6a2cfc: eor             v0.16b, v0.16b, v0.16b
    // 0x6a2d00: b               #0x6a2d08
    // 0x6a2d04: LoadField: d0 = r1->field_7
    //     0x6a2d04: ldur            d0, [x1, #7]
    // 0x6a2d08: r0 = inline_Allocate_Double()
    //     0x6a2d08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6a2d0c: add             x0, x0, #0x10
    //     0x6a2d10: cmp             x1, x0
    //     0x6a2d14: b.ls            #0x6a2d48
    //     0x6a2d18: str             x0, [THR, #0x60]  ; THR::top
    //     0x6a2d1c: sub             x0, x0, #0xf
    //     0x6a2d20: movz            x1, #0xe19c
    //     0x6a2d24: movk            x1, #0x3, lsl #16
    //     0x6a2d28: stur            x1, [x0, #-1]
    // 0x6a2d2c: dmb             ishst
    // 0x6a2d30: StoreField: r0->field_7 = d0
    //     0x6a2d30: stur            d0, [x0, #7]
    // 0x6a2d34: LeaveFrame
    //     0x6a2d34: mov             SP, fp
    //     0x6a2d38: ldp             fp, lr, [SP], #0x10
    // 0x6a2d3c: ret
    //     0x6a2d3c: ret             
    // 0x6a2d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2d40: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2d44: b               #0x6a2c94
    // 0x6a2d48: SaveReg d0
    //     0x6a2d48: str             q0, [SP, #-0x10]!
    // 0x6a2d4c: r0 = AllocateDouble()
    //     0x6a2d4c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x6a2d50: RestoreReg d0
    //     0x6a2d50: ldr             q0, [SP], #0x10
    // 0x6a2d54: b               #0x6a2d30
  }
  [closure] GeneratorInfo<Chapter14Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x6a2d58, size: 0x3c
    // 0x6a2d58: EnterFrame
    //     0x6a2d58: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2d5c: mov             fp, SP
    // 0x6a2d60: ldr             x0, [fp, #0x18]
    // 0x6a2d64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a2d64: ldur            w1, [x0, #0x17]
    // 0x6a2d68: DecompressPointer r1
    //     0x6a2d68: add             x1, x1, HEAP, lsl #32
    // 0x6a2d6c: CheckStackOverflow
    //     0x6a2d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2d70: cmp             SP, x16
    //     0x6a2d74: b.ls            #0x6a2d8c
    // 0x6a2d78: ldr             x2, [fp, #0x10]
    // 0x6a2d7c: r0 = getGeneratorInfo()
    //     0x6a2d7c: bl              #0x80d308  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getGeneratorInfo
    // 0x6a2d80: LeaveFrame
    //     0x6a2d80: mov             SP, fp
    //     0x6a2d84: ldp             fp, lr, [SP], #0x10
    // 0x6a2d88: ret
    //     0x6a2d88: ret             
    // 0x6a2d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a2d8c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a2d90: b               #0x6a2d78
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d308, size: 0x7c
    // 0x80d308: EnterFrame
    //     0x80d308: stp             fp, lr, [SP, #-0x10]!
    //     0x80d30c: mov             fp, SP
    // 0x80d310: AllocStack(0x8)
    //     0x80d310: sub             SP, SP, #8
    // 0x80d314: CheckStackOverflow
    //     0x80d314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d318: cmp             SP, x16
    //     0x80d31c: b.ls            #0x80d36c
    // 0x80d320: LoadField: r0 = r1->field_8b
    //     0x80d320: ldur            w0, [x1, #0x8b]
    // 0x80d324: DecompressPointer r0
    //     0x80d324: add             x0, x0, HEAP, lsl #32
    // 0x80d328: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d32c: cmp             w0, w16
    // 0x80d330: b.eq            #0x80d374
    // 0x80d334: mov             x1, x0
    // 0x80d338: stur            x0, [fp, #-8]
    // 0x80d33c: r0 = _getValueOrData()
    //     0x80d33c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d340: ldur            x1, [fp, #-8]
    // 0x80d344: LoadField: r2 = r1->field_f
    //     0x80d344: ldur            w2, [x1, #0xf]
    // 0x80d348: DecompressPointer r2
    //     0x80d348: add             x2, x2, HEAP, lsl #32
    // 0x80d34c: cmp             w2, w0
    // 0x80d350: b.ne            #0x80d358
    // 0x80d354: r0 = Null
    //     0x80d354: mov             x0, NULL
    // 0x80d358: cmp             w0, NULL
    // 0x80d35c: b.eq            #0x80d380
    // 0x80d360: LeaveFrame
    //     0x80d360: mov             SP, fp
    //     0x80d364: ldp             fp, lr, [SP], #0x10
    // 0x80d368: ret
    //     0x80d368: ret             
    // 0x80d36c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d36c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d370: b               #0x80d320
    // 0x80d374: r9 = generators
    //     0x80d374: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a6b8] Field <Chapter14GameState.generators>: late (offset: 0x8c)
    //     0x80d378: ldr             x9, [x9, #0x6b8]
    // 0x80d37c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d37c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d380: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d138, size: 0xc
    // 0x81d138: r0 = "14"
    //     0x81d138: add             x0, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x81d13c: ldr             x0, [x0, #0x340]
    // 0x81d140: ret
    //     0x81d140: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f6cc, size: 0x24
    // 0x81f6cc: EnterFrame
    //     0x81f6cc: stp             fp, lr, [SP, #-0x10]!
    //     0x81f6d0: mov             fp, SP
    // 0x81f6d4: ldr             x2, [fp, #0x10]
    // 0x81f6d8: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f6d8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1caf8] AnonymousClosure: (0x3db0dc), in [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::getCostToBuyOneMoreGenerator (0x3daf58)
    //     0x81f6dc: ldr             x1, [x1, #0xaf8]
    // 0x81f6e0: r0 = AllocateClosure()
    //     0x81f6e0: bl              #0x826750  ; AllocateClosureStub
    // 0x81f6e4: LeaveFrame
    //     0x81f6e4: mov             SP, fp
    //     0x81f6e8: ldp             fp, lr, [SP], #0x10
    // 0x81f6ec: ret
    //     0x81f6ec: ret             
  }
}

// class id: 4184, size: 0x14, field offset: 0x14
enum Chapter14Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724948, size: 0x64
    // 0x724948: EnterFrame
    //     0x724948: stp             fp, lr, [SP, #-0x10]!
    //     0x72494c: mov             fp, SP
    // 0x724950: AllocStack(0x10)
    //     0x724950: sub             SP, SP, #0x10
    // 0x724954: SetupParameters(Chapter14Stat this /* r1 => r0, fp-0x8 */)
    //     0x724954: mov             x0, x1
    //     0x724958: stur            x1, [fp, #-8]
    // 0x72495c: CheckStackOverflow
    //     0x72495c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724960: cmp             SP, x16
    //     0x724964: b.ls            #0x7249a4
    // 0x724968: r1 = Null
    //     0x724968: mov             x1, NULL
    // 0x72496c: r2 = 4
    //     0x72496c: movz            x2, #0x4
    // 0x724970: r0 = AllocateArray()
    //     0x724970: bl              #0x82746c  ; AllocateArrayStub
    // 0x724974: r16 = "Chapter14Stat."
    //     0x724974: add             x16, PP, #0x15, lsl #12  ; [pp+0x158e8] "Chapter14Stat."
    //     0x724978: ldr             x16, [x16, #0x8e8]
    // 0x72497c: StoreField: r0->field_f = r16
    //     0x72497c: stur            w16, [x0, #0xf]
    // 0x724980: ldur            x1, [fp, #-8]
    // 0x724984: LoadField: r2 = r1->field_f
    //     0x724984: ldur            w2, [x1, #0xf]
    // 0x724988: DecompressPointer r2
    //     0x724988: add             x2, x2, HEAP, lsl #32
    // 0x72498c: StoreField: r0->field_13 = r2
    //     0x72498c: stur            w2, [x0, #0x13]
    // 0x724990: str             x0, [SP]
    // 0x724994: r0 = _interpolate()
    //     0x724994: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724998: LeaveFrame
    //     0x724998: mov             SP, fp
    //     0x72499c: ldp             fp, lr, [SP], #0x10
    // 0x7249a0: ret
    //     0x7249a0: ret             
    // 0x7249a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7249a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7249a8: b               #0x724968
  }
}
