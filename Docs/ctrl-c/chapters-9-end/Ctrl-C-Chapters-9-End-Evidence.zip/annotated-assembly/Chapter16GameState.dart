// lib: , url: package:pretentious/data/Chapters/Chapter16GameState.dart

// class id: 1049453, size: 0x8
class :: {
}

// class id: 279, size: 0x90, field offset: 0x8c
class Chapter16GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter16Stat>> generators; // offset: 0x8c

  _ Chapter16GameState(/* No info */) {
    // ** addr: 0x46ae7c, size: 0xb0
    // 0x46ae7c: EnterFrame
    //     0x46ae7c: stp             fp, lr, [SP, #-0x10]!
    //     0x46ae80: mov             fp, SP
    // 0x46ae84: AllocStack(0x28)
    //     0x46ae84: sub             SP, SP, #0x28
    // 0x46ae88: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46ae8c: mov             x4, x1
    // 0x46ae90: mov             x3, x2
    // 0x46ae94: stur            x1, [fp, #-8]
    // 0x46ae98: stur            x2, [fp, #-0x10]
    // 0x46ae9c: CheckStackOverflow
    //     0x46ae9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46aea0: cmp             SP, x16
    //     0x46aea4: b.ls            #0x46af24
    // 0x46aea8: StoreField: r4->field_8b = r0
    //     0x46aea8: stur            w0, [x4, #0x8b]
    // 0x46aeac: r1 = Function '<anonymous closure>':.
    //     0x46aeac: add             x1, PP, #0x10, lsl #12  ; [pp+0x10fa8] AnonymousClosure: (0x46afc0), in [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::Chapter16GameState (0x46ae7c)
    //     0x46aeb0: ldr             x1, [x1, #0xfa8]
    // 0x46aeb4: r2 = Null
    //     0x46aeb4: mov             x2, NULL
    // 0x46aeb8: r0 = AllocateClosure()
    //     0x46aeb8: bl              #0x826750  ; AllocateClosureStub
    // 0x46aebc: r1 = Function '<anonymous closure>':.
    //     0x46aebc: add             x1, PP, #0x10, lsl #12  ; [pp+0x10fb0] AnonymousClosure: (0x46af98), in [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::Chapter16GameState (0x46ae7c)
    //     0x46aec0: ldr             x1, [x1, #0xfb0]
    // 0x46aec4: r2 = Null
    //     0x46aec4: mov             x2, NULL
    // 0x46aec8: stur            x0, [fp, #-0x18]
    // 0x46aecc: r0 = AllocateClosure()
    //     0x46aecc: bl              #0x826750  ; AllocateClosureStub
    // 0x46aed0: r1 = Function '<anonymous closure>':.
    //     0x46aed0: add             x1, PP, #0x10, lsl #12  ; [pp+0x10fb8] AnonymousClosure: (0x46af70), in [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::Chapter16GameState (0x46ae7c)
    //     0x46aed4: ldr             x1, [x1, #0xfb8]
    // 0x46aed8: r2 = Null
    //     0x46aed8: mov             x2, NULL
    // 0x46aedc: stur            x0, [fp, #-0x20]
    // 0x46aee0: r0 = AllocateClosure()
    //     0x46aee0: bl              #0x826750  ; AllocateClosureStub
    // 0x46aee4: r1 = Function '<anonymous closure>':.
    //     0x46aee4: add             x1, PP, #0x10, lsl #12  ; [pp+0x10fc0] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46aee8: ldr             x1, [x1, #0xfc0]
    // 0x46aeec: r2 = Null
    //     0x46aeec: mov             x2, NULL
    // 0x46aef0: stur            x0, [fp, #-0x28]
    // 0x46aef4: r0 = AllocateClosure()
    //     0x46aef4: bl              #0x826750  ; AllocateClosureStub
    // 0x46aef8: ldur            x1, [fp, #-8]
    // 0x46aefc: ldur            x2, [fp, #-0x10]
    // 0x46af00: ldur            x3, [fp, #-0x18]
    // 0x46af04: ldur            x5, [fp, #-0x20]
    // 0x46af08: ldur            x6, [fp, #-0x28]
    // 0x46af0c: mov             x7, x0
    // 0x46af10: r0 = IPlayableGameState()
    //     0x46af10: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46af14: r0 = Null
    //     0x46af14: mov             x0, NULL
    // 0x46af18: LeaveFrame
    //     0x46af18: mov             SP, fp
    //     0x46af1c: ldp             fp, lr, [SP], #0x10
    // 0x46af20: ret
    //     0x46af20: ret             
    // 0x46af24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46af24: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46af28: b               #0x46aea8
  }
  [closure] String <anonymous closure>(dynamic, Chapter16Stat) {
    // ** addr: 0x46af70, size: 0x28
    // 0x46af70: ldr             x1, [SP]
    // 0x46af74: r16 = Instance_Chapter16Stat
    //     0x46af74: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fc8] Obj!Chapter16Stat@85f6c1
    //     0x46af78: ldr             x16, [x16, #0xfc8]
    // 0x46af7c: cmp             w1, w16
    // 0x46af80: b.ne            #0x46af90
    // 0x46af84: r0 = "Contributions"
    //     0x46af84: add             x0, PP, #0x10, lsl #12  ; [pp+0x10f90] "Contributions"
    //     0x46af88: ldr             x0, [x0, #0xf90]
    // 0x46af8c: b               #0x46af94
    // 0x46af90: r0 = Null
    //     0x46af90: mov             x0, NULL
    // 0x46af94: ret
    //     0x46af94: ret             
  }
  [closure] String <anonymous closure>(dynamic, Chapter16Stat) {
    // ** addr: 0x46af98, size: 0x28
    // 0x46af98: ldr             x1, [SP]
    // 0x46af9c: r16 = Instance_Chapter16Stat
    //     0x46af9c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fc8] Obj!Chapter16Stat@85f6c1
    //     0x46afa0: ldr             x16, [x16, #0xfc8]
    // 0x46afa4: cmp             w1, w16
    // 0x46afa8: b.ne            #0x46afb8
    // 0x46afac: r0 = "Contr"
    //     0x46afac: add             x0, PP, #0x10, lsl #12  ; [pp+0x10f98] "Contr"
    //     0x46afb0: ldr             x0, [x0, #0xf98]
    // 0x46afb4: b               #0x46afbc
    // 0x46afb8: r0 = Null
    //     0x46afb8: mov             x0, NULL
    // 0x46afbc: ret
    //     0x46afbc: ret             
  }
  [closure] Chapter16Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46afc0, size: 0x44
    // 0x46afc0: r2 = const [Instance of 'Chapter16Stat']
    //     0x46afc0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fd0] List<Chapter16Stat>(1)
    //     0x46afc4: ldr             x2, [x2, #0xfd0]
    // 0x46afc8: ldr             x3, [SP]
    // 0x46afcc: r4 = LoadInt32Instr(r3)
    //     0x46afcc: sbfx            x4, x3, #1, #0x1f
    //     0x46afd0: tbz             w3, #0, #0x46afd8
    //     0x46afd4: ldur            x4, [x3, #7]
    // 0x46afd8: mov             x1, x4
    // 0x46afdc: r0 = 1
    //     0x46afdc: movz            x0, #0x1
    // 0x46afe0: cmp             x1, x0
    // 0x46afe4: b.hs            #0x46aff8
    // 0x46afe8: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46afe8: add             x16, x2, x4, lsl #2
    //     0x46afec: ldur            w0, [x16, #0xf]
    // 0x46aff0: DecompressPointer r0
    //     0x46aff0: add             x0, x0, HEAP, lsl #32
    // 0x46aff4: ret
    //     0x46aff4: ret             
    // 0x46aff8: EnterFrame
    //     0x46aff8: stp             fp, lr, [SP, #-0x10]!
    //     0x46affc: mov             fp, SP
    // 0x46b000: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46b000: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e73c8, size: 0x74
    // 0x4e73c8: EnterFrame
    //     0x4e73c8: stp             fp, lr, [SP, #-0x10]!
    //     0x4e73cc: mov             fp, SP
    // 0x4e73d0: AllocStack(0x10)
    //     0x4e73d0: sub             SP, SP, #0x10
    // 0x4e73d4: SetupParameters(Chapter16GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e73d4: stur            x1, [fp, #-8]
    // 0x4e73d8: r1 = 1
    //     0x4e73d8: movz            x1, #0x1
    // 0x4e73dc: r0 = AllocateContext()
    //     0x4e73dc: bl              #0x82637c  ; AllocateContextStub
    // 0x4e73e0: mov             x1, x0
    // 0x4e73e4: ldur            x0, [fp, #-8]
    // 0x4e73e8: StoreField: r1->field_f = r0
    //     0x4e73e8: stur            w0, [x1, #0xf]
    // 0x4e73ec: mov             x2, x1
    // 0x4e73f0: r1 = Function '<anonymous closure>':.
    //     0x4e73f0: add             x1, PP, #0x25, lsl #12  ; [pp+0x25710] AnonymousClosure: (0x4e743c), in [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::makeHeader (0x4e73c8)
    //     0x4e73f4: ldr             x1, [x1, #0x710]
    // 0x4e73f8: r0 = AllocateClosure()
    //     0x4e73f8: bl              #0x826750  ; AllocateClosureStub
    // 0x4e73fc: stur            x0, [fp, #-8]
    // 0x4e7400: r0 = MainStatDisplay()
    //     0x4e7400: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e7404: mov             x3, x0
    // 0x4e7408: ldur            x0, [fp, #-8]
    // 0x4e740c: stur            x3, [fp, #-0x10]
    // 0x4e7410: StoreField: r3->field_b = r0
    //     0x4e7410: stur            w0, [x3, #0xb]
    // 0x4e7414: r1 = Function '<anonymous closure>':.
    //     0x4e7414: add             x1, PP, #0x25, lsl #12  ; [pp+0x25718] AnonymousClosure: (0x7b6794), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::makeHeader (0x4e78b8)
    //     0x4e7418: ldr             x1, [x1, #0x718]
    // 0x4e741c: r2 = Null
    //     0x4e741c: mov             x2, NULL
    // 0x4e7420: r0 = AllocateClosure()
    //     0x4e7420: bl              #0x826750  ; AllocateClosureStub
    // 0x4e7424: mov             x1, x0
    // 0x4e7428: ldur            x0, [fp, #-0x10]
    // 0x4e742c: StoreField: r0->field_f = r1
    //     0x4e742c: stur            w1, [x0, #0xf]
    // 0x4e7430: LeaveFrame
    //     0x4e7430: mov             SP, fp
    //     0x4e7434: ldp             fp, lr, [SP], #0x10
    // 0x4e7438: ret
    //     0x4e7438: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e743c, size: 0xf4
    // 0x4e743c: EnterFrame
    //     0x4e743c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e7440: mov             fp, SP
    // 0x4e7444: AllocStack(0x18)
    //     0x4e7444: sub             SP, SP, #0x18
    // 0x4e7448: SetupParameters([dynamic _ /* r0 */])
    //     0x4e7448: ldr             x0, [fp, #0x10]
    //     0x4e744c: ldur            w3, [x0, #0x17]
    //     0x4e7450: add             x3, x3, HEAP, lsl #32
    //     0x4e7454: stur            x3, [fp, #-8]
    // 0x4e7458: CheckStackOverflow
    //     0x4e7458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e745c: cmp             SP, x16
    //     0x4e7460: b.ls            #0x4e7528
    // 0x4e7464: r1 = Null
    //     0x4e7464: mov             x1, NULL
    // 0x4e7468: r2 = 4
    //     0x4e7468: movz            x2, #0x4
    // 0x4e746c: r0 = AllocateArray()
    //     0x4e746c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e7470: stur            x0, [fp, #-0x10]
    // 0x4e7474: r16 = "Contributions: "
    //     0x4e7474: add             x16, PP, #0x25, lsl #12  ; [pp+0x25708] "Contributions: "
    //     0x4e7478: ldr             x16, [x16, #0x708]
    // 0x4e747c: StoreField: r0->field_f = r16
    //     0x4e747c: stur            w16, [x0, #0xf]
    // 0x4e7480: ldur            x1, [fp, #-8]
    // 0x4e7484: LoadField: r2 = r1->field_f
    //     0x4e7484: ldur            w2, [x1, #0xf]
    // 0x4e7488: DecompressPointer r2
    //     0x4e7488: add             x2, x2, HEAP, lsl #32
    // 0x4e748c: LoadField: r3 = r2->field_37
    //     0x4e748c: ldur            w3, [x2, #0x37]
    // 0x4e7490: DecompressPointer r3
    //     0x4e7490: add             x3, x3, HEAP, lsl #32
    // 0x4e7494: mov             x1, x3
    // 0x4e7498: stur            x3, [fp, #-8]
    // 0x4e749c: r2 = Instance_Chapter16Stat
    //     0x4e749c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fc8] Obj!Chapter16Stat@85f6c1
    //     0x4e74a0: ldr             x2, [x2, #0xfc8]
    // 0x4e74a4: r0 = _getValueOrData()
    //     0x4e74a4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e74a8: mov             x1, x0
    // 0x4e74ac: ldur            x0, [fp, #-8]
    // 0x4e74b0: LoadField: r2 = r0->field_f
    //     0x4e74b0: ldur            w2, [x0, #0xf]
    // 0x4e74b4: DecompressPointer r2
    //     0x4e74b4: add             x2, x2, HEAP, lsl #32
    // 0x4e74b8: cmp             w2, w1
    // 0x4e74bc: b.ne            #0x4e74c4
    // 0x4e74c0: r1 = Null
    //     0x4e74c0: mov             x1, NULL
    // 0x4e74c4: cmp             w1, NULL
    // 0x4e74c8: b.ne            #0x4e74d4
    // 0x4e74cc: r0 = Null
    //     0x4e74cc: mov             x0, NULL
    // 0x4e74d0: b               #0x4e74dc
    // 0x4e74d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e74d4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e74d8: r0 = toStringConsistentDecimalPlaces()
    //     0x4e74d8: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e74dc: cmp             w0, NULL
    // 0x4e74e0: b.ne            #0x4e74e8
    // 0x4e74e4: r0 = 0
    //     0x4e74e4: movz            x0, #0
    // 0x4e74e8: ldur            x1, [fp, #-0x10]
    // 0x4e74ec: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e74ec: add             x25, x1, #0x13
    //     0x4e74f0: str             w0, [x25]
    //     0x4e74f4: tbz             w0, #0, #0x4e7510
    //     0x4e74f8: ldurb           w16, [x1, #-1]
    //     0x4e74fc: ldurb           w17, [x0, #-1]
    //     0x4e7500: and             x16, x17, x16, lsr #2
    //     0x4e7504: tst             x16, HEAP, lsr #32
    //     0x4e7508: b.eq            #0x4e7510
    //     0x4e750c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e7510: ldur            x16, [fp, #-0x10]
    // 0x4e7514: str             x16, [SP]
    // 0x4e7518: r0 = _interpolate()
    //     0x4e7518: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e751c: LeaveFrame
    //     0x4e751c: mov             SP, fp
    //     0x4e7520: ldp             fp, lr, [SP], #0x10
    // 0x4e7524: ret
    //     0x4e7524: ret             
    // 0x4e7528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e7528: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e752c: b               #0x4e7464
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4fe9c4, size: 0x7c
    // 0x4fe9c4: EnterFrame
    //     0x4fe9c4: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe9c8: mov             fp, SP
    // 0x4fe9cc: AllocStack(0x18)
    //     0x4fe9cc: sub             SP, SP, #0x18
    // 0x4fe9d0: SetupParameters(Chapter16GameState this /* r1 => r1, fp-0x8 */)
    //     0x4fe9d0: stur            x1, [fp, #-8]
    // 0x4fe9d4: CheckStackOverflow
    //     0x4fe9d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fe9d8: cmp             SP, x16
    //     0x4fe9dc: b.ls            #0x4fea38
    // 0x4fe9e0: r16 = <int, GeneratorInfo<Chapter16Stat>>
    //     0x4fe9e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15238] TypeArguments: <int, GeneratorInfo<Chapter16Stat>>
    //     0x4fe9e4: ldr             x16, [x16, #0x238]
    // 0x4fe9e8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4fe9ec: stp             lr, x16, [SP]
    // 0x4fe9f0: r0 = Map._fromLiteral()
    //     0x4fe9f0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fe9f4: ldur            x1, [fp, #-8]
    // 0x4fe9f8: StoreField: r1->field_8b = r0
    //     0x4fe9f8: stur            w0, [x1, #0x8b]
    //     0x4fe9fc: ldurb           w16, [x1, #-1]
    //     0x4fea00: ldurb           w17, [x0, #-1]
    //     0x4fea04: and             x16, x17, x16, lsr #2
    //     0x4fea08: tst             x16, HEAP, lsr #32
    //     0x4fea0c: b.eq            #0x4fea14
    //     0x4fea10: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4fea14: r16 = <int, UpgradeData<Chapter16Stat>>
    //     0x4fea14: add             x16, PP, #0x15, lsl #12  ; [pp+0x15240] TypeArguments: <int, UpgradeData<Chapter16Stat>>
    //     0x4fea18: ldr             x16, [x16, #0x240]
    // 0x4fea1c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4fea20: stp             lr, x16, [SP]
    // 0x4fea24: r0 = Map._fromLiteral()
    //     0x4fea24: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fea28: r0 = Null
    //     0x4fea28: mov             x0, NULL
    // 0x4fea2c: LeaveFrame
    //     0x4fea2c: mov             SP, fp
    //     0x4fea30: ldp             fp, lr, [SP], #0x10
    // 0x4fea34: ret
    //     0x4fea34: ret             
    // 0x4fea38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fea38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fea3c: b               #0x4fe9e0
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55cf64, size: 0x40
    // 0x55cf64: EnterFrame
    //     0x55cf64: stp             fp, lr, [SP, #-0x10]!
    //     0x55cf68: mov             fp, SP
    // 0x55cf6c: AllocStack(0x10)
    //     0x55cf6c: sub             SP, SP, #0x10
    // 0x55cf70: CheckStackOverflow
    //     0x55cf70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55cf74: cmp             SP, x16
    //     0x55cf78: b.ls            #0x55cf9c
    // 0x55cf7c: r16 = <Chapter16Stat, CustomNum>
    //     0x55cf7c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a638] TypeArguments: <Chapter16Stat, CustomNum>
    //     0x55cf80: ldr             x16, [x16, #0x638]
    // 0x55cf84: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x55cf88: stp             lr, x16, [SP]
    // 0x55cf8c: r0 = Map._fromLiteral()
    //     0x55cf8c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55cf90: LeaveFrame
    //     0x55cf90: mov             SP, fp
    //     0x55cf94: ldp             fp, lr, [SP], #0x10
    // 0x55cf98: ret
    //     0x55cf98: ret             
    // 0x55cf9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55cf9c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55cfa0: b               #0x55cf7c
  }
  _ build(/* No info */) {
    // ** addr: 0x6a57b8, size: 0x94
    // 0x6a57b8: EnterFrame
    //     0x6a57b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a57bc: mov             fp, SP
    // 0x6a57c0: AllocStack(0x10)
    //     0x6a57c0: sub             SP, SP, #0x10
    // 0x6a57c4: CheckStackOverflow
    //     0x6a57c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a57c8: cmp             SP, x16
    //     0x6a57cc: b.ls            #0x6a5844
    // 0x6a57d0: r1 = Function '<anonymous closure>':.
    //     0x6a57d0: add             x1, PP, #0x28, lsl #12  ; [pp+0x283e0] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6a57d4: ldr             x1, [x1, #0x3e0]
    // 0x6a57d8: r2 = Null
    //     0x6a57d8: mov             x2, NULL
    // 0x6a57dc: r0 = AllocateClosure()
    //     0x6a57dc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a57e0: mov             x5, x0
    // 0x6a57e4: r1 = Null
    //     0x6a57e4: mov             x1, NULL
    // 0x6a57e8: r2 = Instance_WarningWidget
    //     0x6a57e8: add             x2, PP, #0x28, lsl #12  ; [pp+0x283d0] Obj!WarningWidget@84e941
    //     0x6a57ec: ldr             x2, [x2, #0x3d0]
    // 0x6a57f0: r3 = "Ch16 Under Development"
    //     0x6a57f0: add             x3, PP, #0x28, lsl #12  ; [pp+0x283e8] "Ch16 Under Development"
    //     0x6a57f4: ldr             x3, [x3, #0x3e8]
    // 0x6a57f8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a57f8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a57fc: r0 = IdleFragment()
    //     0x6a57fc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a5800: r1 = Null
    //     0x6a5800: mov             x1, NULL
    // 0x6a5804: r2 = 2
    //     0x6a5804: movz            x2, #0x2
    // 0x6a5808: stur            x0, [fp, #-8]
    // 0x6a580c: r0 = AllocateArray()
    //     0x6a580c: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a5810: mov             x2, x0
    // 0x6a5814: ldur            x0, [fp, #-8]
    // 0x6a5818: stur            x2, [fp, #-0x10]
    // 0x6a581c: StoreField: r2->field_f = r0
    //     0x6a581c: stur            w0, [x2, #0xf]
    // 0x6a5820: r1 = <Widget>
    //     0x6a5820: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a5824: r0 = AllocateGrowableArray()
    //     0x6a5824: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a5828: ldur            x1, [fp, #-0x10]
    // 0x6a582c: StoreField: r0->field_f = r1
    //     0x6a582c: stur            w1, [x0, #0xf]
    // 0x6a5830: r1 = 2
    //     0x6a5830: movz            x1, #0x2
    // 0x6a5834: StoreField: r0->field_b = r1
    //     0x6a5834: stur            w1, [x0, #0xb]
    // 0x6a5838: LeaveFrame
    //     0x6a5838: mov             SP, fp
    //     0x6a583c: ldp             fp, lr, [SP], #0x10
    // 0x6a5840: ret
    //     0x6a5840: ret             
    // 0x6a5844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5844: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5848: b               #0x6a57d0
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d400, size: 0x7c
    // 0x80d400: EnterFrame
    //     0x80d400: stp             fp, lr, [SP, #-0x10]!
    //     0x80d404: mov             fp, SP
    // 0x80d408: AllocStack(0x8)
    //     0x80d408: sub             SP, SP, #8
    // 0x80d40c: CheckStackOverflow
    //     0x80d40c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d410: cmp             SP, x16
    //     0x80d414: b.ls            #0x80d464
    // 0x80d418: LoadField: r0 = r1->field_8b
    //     0x80d418: ldur            w0, [x1, #0x8b]
    // 0x80d41c: DecompressPointer r0
    //     0x80d41c: add             x0, x0, HEAP, lsl #32
    // 0x80d420: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d424: cmp             w0, w16
    // 0x80d428: b.eq            #0x80d46c
    // 0x80d42c: mov             x1, x0
    // 0x80d430: stur            x0, [fp, #-8]
    // 0x80d434: r0 = _getValueOrData()
    //     0x80d434: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d438: ldur            x1, [fp, #-8]
    // 0x80d43c: LoadField: r2 = r1->field_f
    //     0x80d43c: ldur            w2, [x1, #0xf]
    // 0x80d440: DecompressPointer r2
    //     0x80d440: add             x2, x2, HEAP, lsl #32
    // 0x80d444: cmp             w2, w0
    // 0x80d448: b.ne            #0x80d450
    // 0x80d44c: r0 = Null
    //     0x80d44c: mov             x0, NULL
    // 0x80d450: cmp             w0, NULL
    // 0x80d454: b.eq            #0x80d478
    // 0x80d458: LeaveFrame
    //     0x80d458: mov             SP, fp
    //     0x80d45c: ldp             fp, lr, [SP], #0x10
    // 0x80d460: ret
    //     0x80d460: ret             
    // 0x80d464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d464: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d468: b               #0x80d418
    // 0x80d46c: r9 = generators
    //     0x80d46c: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a640] Field <Chapter16GameState.generators>: late (offset: 0x8c)
    //     0x80d470: ldr             x9, [x9, #0x640]
    // 0x80d474: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d474: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d478: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d478: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d150, size: 0xc
    // 0x81d150: r0 = "16"
    //     0x81d150: add             x0, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x81d154: ldr             x0, [x0, #0x350]
    // 0x81d158: ret
    //     0x81d158: ret             
  }
}

// class id: 4182, size: 0x14, field offset: 0x14
enum Chapter16Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724a10, size: 0x64
    // 0x724a10: EnterFrame
    //     0x724a10: stp             fp, lr, [SP, #-0x10]!
    //     0x724a14: mov             fp, SP
    // 0x724a18: AllocStack(0x10)
    //     0x724a18: sub             SP, SP, #0x10
    // 0x724a1c: SetupParameters(Chapter16Stat this /* r1 => r0, fp-0x8 */)
    //     0x724a1c: mov             x0, x1
    //     0x724a20: stur            x1, [fp, #-8]
    // 0x724a24: CheckStackOverflow
    //     0x724a24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724a28: cmp             SP, x16
    //     0x724a2c: b.ls            #0x724a6c
    // 0x724a30: r1 = Null
    //     0x724a30: mov             x1, NULL
    // 0x724a34: r2 = 4
    //     0x724a34: movz            x2, #0x4
    // 0x724a38: r0 = AllocateArray()
    //     0x724a38: bl              #0x82746c  ; AllocateArrayStub
    // 0x724a3c: r16 = "Chapter16Stat."
    //     0x724a3c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15248] "Chapter16Stat."
    //     0x724a40: ldr             x16, [x16, #0x248]
    // 0x724a44: StoreField: r0->field_f = r16
    //     0x724a44: stur            w16, [x0, #0xf]
    // 0x724a48: ldur            x1, [fp, #-8]
    // 0x724a4c: LoadField: r2 = r1->field_f
    //     0x724a4c: ldur            w2, [x1, #0xf]
    // 0x724a50: DecompressPointer r2
    //     0x724a50: add             x2, x2, HEAP, lsl #32
    // 0x724a54: StoreField: r0->field_13 = r2
    //     0x724a54: stur            w2, [x0, #0x13]
    // 0x724a58: str             x0, [SP]
    // 0x724a5c: r0 = _interpolate()
    //     0x724a5c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724a60: LeaveFrame
    //     0x724a60: mov             SP, fp
    //     0x724a64: ldp             fp, lr, [SP], #0x10
    // 0x724a68: ret
    //     0x724a68: ret             
    // 0x724a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724a6c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724a70: b               #0x724a30
  }
}
