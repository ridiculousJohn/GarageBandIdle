// lib: , url: package:pretentious/data/Chapters/Chapter10GameState.dart

// class id: 1049447, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46e19c, size: 0xf8
    // 0x46e19c: cmp             w1, NULL
    // 0x46e1a0: b.ne            #0x46e1ac
    // 0x46e1a4: r0 = ""
    //     0x46e1a4: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46e1a8: ret
    //     0x46e1a8: ret             
    // 0x46e1ac: r16 = Instance_Chapter10Stat
    //     0x46e1ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x46e1b0: ldr             x16, [x16, #0x798]
    // 0x46e1b4: cmp             w1, w16
    // 0x46e1b8: b.ne            #0x46e1c8
    // 0x46e1bc: r0 = "Utility"
    //     0x46e1bc: add             x0, PP, #0x11, lsl #12  ; [pp+0x117a0] "Utility"
    //     0x46e1c0: ldr             x0, [x0, #0x7a0]
    // 0x46e1c4: ret
    //     0x46e1c4: ret             
    // 0x46e1c8: r16 = Instance_Chapter10Stat
    //     0x46e1c8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11720] Obj!Chapter10Stat@85fee1
    //     0x46e1cc: ldr             x16, [x16, #0x720]
    // 0x46e1d0: cmp             w1, w16
    // 0x46e1d4: b.ne            #0x46e1e4
    // 0x46e1d8: r0 = "Scripting"
    //     0x46e1d8: add             x0, PP, #0x11, lsl #12  ; [pp+0x117a8] "Scripting"
    //     0x46e1dc: ldr             x0, [x0, #0x7a8]
    // 0x46e1e0: ret
    //     0x46e1e0: ret             
    // 0x46e1e4: r16 = Instance_Chapter10Stat
    //     0x46e1e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11728] Obj!Chapter10Stat@85fec1
    //     0x46e1e8: ldr             x16, [x16, #0x728]
    // 0x46e1ec: cmp             w1, w16
    // 0x46e1f0: b.ne            #0x46e200
    // 0x46e1f4: r0 = "Synchronization"
    //     0x46e1f4: add             x0, PP, #0x11, lsl #12  ; [pp+0x117b0] "Synchronization"
    //     0x46e1f8: ldr             x0, [x0, #0x7b0]
    // 0x46e1fc: ret
    //     0x46e1fc: ret             
    // 0x46e200: r16 = Instance_Chapter10Stat
    //     0x46e200: add             x16, PP, #0x11, lsl #12  ; [pp+0x11730] Obj!Chapter10Stat@85fea1
    //     0x46e204: ldr             x16, [x16, #0x730]
    // 0x46e208: cmp             w1, w16
    // 0x46e20c: b.ne            #0x46e21c
    // 0x46e210: r0 = "Search"
    //     0x46e210: add             x0, PP, #0x11, lsl #12  ; [pp+0x117b8] "Search"
    //     0x46e214: ldr             x0, [x0, #0x7b8]
    // 0x46e218: ret
    //     0x46e218: ret             
    // 0x46e21c: r16 = Instance_Chapter10Stat
    //     0x46e21c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] Obj!Chapter10Stat@85fe81
    //     0x46e220: ldr             x16, [x16, #0x738]
    // 0x46e224: cmp             w1, w16
    // 0x46e228: b.ne            #0x46e238
    // 0x46e22c: r0 = "Boot"
    //     0x46e22c: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Boot"
    //     0x46e230: ldr             x0, [x0, #0x7c0]
    // 0x46e234: ret
    //     0x46e234: ret             
    // 0x46e238: r16 = Instance_Chapter10Stat
    //     0x46e238: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] Obj!Chapter10Stat@85fe61
    //     0x46e23c: ldr             x16, [x16, #0x740]
    // 0x46e240: cmp             w1, w16
    // 0x46e244: b.ne            #0x46e254
    // 0x46e248: r0 = "IO"
    //     0x46e248: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] "IO"
    //     0x46e24c: ldr             x0, [x0, #0x7c8]
    // 0x46e250: ret
    //     0x46e250: ret             
    // 0x46e254: r16 = Instance_Chapter10Stat
    //     0x46e254: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] Obj!Chapter10Stat@85fe41
    //     0x46e258: ldr             x16, [x16, #0x748]
    // 0x46e25c: cmp             w1, w16
    // 0x46e260: b.ne            #0x46e270
    // 0x46e264: r0 = "Compression"
    //     0x46e264: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d0] "Compression"
    //     0x46e268: ldr             x0, [x0, #0x7d0]
    // 0x46e26c: ret
    //     0x46e26c: ret             
    // 0x46e270: r16 = Instance_Chapter10Stat
    //     0x46e270: add             x16, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x46e274: ldr             x16, [x16, #0x7d8]
    // 0x46e278: cmp             w1, w16
    // 0x46e27c: b.ne            #0x46e28c
    // 0x46e280: r0 = "Efficiency"
    //     0x46e280: add             x0, PP, #0x11, lsl #12  ; [pp+0x117e0] "Efficiency"
    //     0x46e284: ldr             x0, [x0, #0x7e0]
    // 0x46e288: ret
    //     0x46e288: ret             
    // 0x46e28c: r0 = Null
    //     0x46e28c: mov             x0, NULL
    // 0x46e290: ret
    //     0x46e290: ret             
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46e2c4, size: 0xe8
    // 0x46e2c4: r16 = Instance_Chapter10Stat
    //     0x46e2c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x46e2c8: ldr             x16, [x16, #0x798]
    // 0x46e2cc: cmp             w1, w16
    // 0x46e2d0: b.ne            #0x46e2e0
    // 0x46e2d4: r0 = "Utlty"
    //     0x46e2d4: add             x0, PP, #0x11, lsl #12  ; [pp+0x117e8] "Utlty"
    //     0x46e2d8: ldr             x0, [x0, #0x7e8]
    // 0x46e2dc: ret
    //     0x46e2dc: ret             
    // 0x46e2e0: r16 = Instance_Chapter10Stat
    //     0x46e2e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11720] Obj!Chapter10Stat@85fee1
    //     0x46e2e4: ldr             x16, [x16, #0x720]
    // 0x46e2e8: cmp             w1, w16
    // 0x46e2ec: b.ne            #0x46e2fc
    // 0x46e2f0: r0 = "Scrptng"
    //     0x46e2f0: add             x0, PP, #0x11, lsl #12  ; [pp+0x117f0] "Scrptng"
    //     0x46e2f4: ldr             x0, [x0, #0x7f0]
    // 0x46e2f8: ret
    //     0x46e2f8: ret             
    // 0x46e2fc: r16 = Instance_Chapter10Stat
    //     0x46e2fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11728] Obj!Chapter10Stat@85fec1
    //     0x46e300: ldr             x16, [x16, #0x728]
    // 0x46e304: cmp             w1, w16
    // 0x46e308: b.ne            #0x46e318
    // 0x46e30c: r0 = "Sync"
    //     0x46e30c: add             x0, PP, #0x11, lsl #12  ; [pp+0x117f8] "Sync"
    //     0x46e310: ldr             x0, [x0, #0x7f8]
    // 0x46e314: ret
    //     0x46e314: ret             
    // 0x46e318: r16 = Instance_Chapter10Stat
    //     0x46e318: add             x16, PP, #0x11, lsl #12  ; [pp+0x11730] Obj!Chapter10Stat@85fea1
    //     0x46e31c: ldr             x16, [x16, #0x730]
    // 0x46e320: cmp             w1, w16
    // 0x46e324: b.ne            #0x46e334
    // 0x46e328: r0 = "Srch"
    //     0x46e328: add             x0, PP, #0x11, lsl #12  ; [pp+0x11800] "Srch"
    //     0x46e32c: ldr             x0, [x0, #0x800]
    // 0x46e330: ret
    //     0x46e330: ret             
    // 0x46e334: r16 = Instance_Chapter10Stat
    //     0x46e334: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] Obj!Chapter10Stat@85fe81
    //     0x46e338: ldr             x16, [x16, #0x738]
    // 0x46e33c: cmp             w1, w16
    // 0x46e340: b.ne            #0x46e350
    // 0x46e344: r0 = "Boot"
    //     0x46e344: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Boot"
    //     0x46e348: ldr             x0, [x0, #0x7c0]
    // 0x46e34c: ret
    //     0x46e34c: ret             
    // 0x46e350: r16 = Instance_Chapter10Stat
    //     0x46e350: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] Obj!Chapter10Stat@85fe61
    //     0x46e354: ldr             x16, [x16, #0x740]
    // 0x46e358: cmp             w1, w16
    // 0x46e35c: b.ne            #0x46e36c
    // 0x46e360: r0 = "IO"
    //     0x46e360: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] "IO"
    //     0x46e364: ldr             x0, [x0, #0x7c8]
    // 0x46e368: ret
    //     0x46e368: ret             
    // 0x46e36c: r16 = Instance_Chapter10Stat
    //     0x46e36c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] Obj!Chapter10Stat@85fe41
    //     0x46e370: ldr             x16, [x16, #0x748]
    // 0x46e374: cmp             w1, w16
    // 0x46e378: b.ne            #0x46e388
    // 0x46e37c: r0 = "Cmprssn"
    //     0x46e37c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11808] "Cmprssn"
    //     0x46e380: ldr             x0, [x0, #0x808]
    // 0x46e384: ret
    //     0x46e384: ret             
    // 0x46e388: r16 = Instance_Chapter10Stat
    //     0x46e388: add             x16, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x46e38c: ldr             x16, [x16, #0x7d8]
    // 0x46e390: cmp             w1, w16
    // 0x46e394: b.ne            #0x46e3a4
    // 0x46e398: r0 = "Effncy"
    //     0x46e398: add             x0, PP, #0x11, lsl #12  ; [pp+0x11810] "Effncy"
    //     0x46e39c: ldr             x0, [x0, #0x810]
    // 0x46e3a0: ret
    //     0x46e3a0: ret             
    // 0x46e3a4: r0 = Null
    //     0x46e3a4: mov             x0, NULL
    // 0x46e3a8: ret
    //     0x46e3a8: ret             
  }
}

// class id: 285, size: 0xa4, field offset: 0x8c
class Chapter10GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter10Stat>> generators; // offset: 0x94
  late Map<int, UpgradeData<Chapter10Stat>> allUpgradeData; // offset: 0x98

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3d9ab0, size: 0x3c0
    // 0x3d9ab0: EnterFrame
    //     0x3d9ab0: stp             fp, lr, [SP, #-0x10]!
    //     0x3d9ab4: mov             fp, SP
    // 0x3d9ab8: AllocStack(0x48)
    //     0x3d9ab8: sub             SP, SP, #0x48
    // 0x3d9abc: SetupParameters(Chapter10GameState this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0x3d9abc: mov             x5, x1
    //     0x3d9ac0: mov             x4, x2
    //     0x3d9ac4: mov             x0, x3
    //     0x3d9ac8: stur            x1, [fp, #-0x10]
    //     0x3d9acc: stur            x2, [fp, #-0x18]
    //     0x3d9ad0: stur            x3, [fp, #-0x20]
    // 0x3d9ad4: CheckStackOverflow
    //     0x3d9ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3d9ad8: cmp             SP, x16
    //     0x3d9adc: b.ls            #0x3d9e5c
    // 0x3d9ae0: LoadField: r1 = r5->field_3f
    //     0x3d9ae0: ldur            w1, [x5, #0x3f]
    // 0x3d9ae4: DecompressPointer r1
    //     0x3d9ae4: add             x1, x1, HEAP, lsl #32
    // 0x3d9ae8: LoadField: r2 = r1->field_7
    //     0x3d9ae8: ldur            w2, [x1, #7]
    // 0x3d9aec: DecompressPointer r2
    //     0x3d9aec: add             x2, x2, HEAP, lsl #32
    // 0x3d9af0: cmp             w2, #2
    // 0x3d9af4: b.ne            #0x3d9be0
    // 0x3d9af8: LoadField: r6 = r5->field_47
    //     0x3d9af8: ldur            w6, [x5, #0x47]
    // 0x3d9afc: DecompressPointer r6
    //     0x3d9afc: add             x6, x6, HEAP, lsl #32
    // 0x3d9b00: stur            x6, [fp, #-8]
    // 0x3d9b04: LoadField: r2 = r6->field_7
    //     0x3d9b04: ldur            w2, [x6, #7]
    // 0x3d9b08: DecompressPointer r2
    //     0x3d9b08: add             x2, x2, HEAP, lsl #32
    // 0x3d9b0c: r1 = Null
    //     0x3d9b0c: mov             x1, NULL
    // 0x3d9b10: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x3d9b10: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x3d9b14: r30 = InstantiateTypeArgumentsStub
    //     0x3d9b14: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x3d9b18: LoadField: r30 = r30->field_7
    //     0x3d9b18: ldur            lr, [lr, #7]
    // 0x3d9b1c: blr             lr
    // 0x3d9b20: mov             x1, x0
    // 0x3d9b24: r0 = _CompactEntriesIterable()
    //     0x3d9b24: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x3d9b28: mov             x1, x0
    // 0x3d9b2c: ldur            x0, [fp, #-8]
    // 0x3d9b30: StoreField: r1->field_b = r0
    //     0x3d9b30: stur            w0, [x1, #0xb]
    // 0x3d9b34: r0 = iterator()
    //     0x3d9b34: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x3d9b38: stur            x0, [fp, #-0x28]
    // 0x3d9b3c: ldur            x2, [fp, #-0x20]
    // 0x3d9b40: stur            x2, [fp, #-8]
    // 0x3d9b44: CheckStackOverflow
    //     0x3d9b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3d9b48: cmp             SP, x16
    //     0x3d9b4c: b.ls            #0x3d9e64
    // 0x3d9b50: mov             x1, x0
    // 0x3d9b54: r0 = moveNext()
    //     0x3d9b54: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x3d9b58: tbnz            w0, #4, #0x3d9bd4
    // 0x3d9b5c: ldur            x0, [fp, #-0x28]
    // 0x3d9b60: LoadField: r1 = r0->field_2b
    //     0x3d9b60: ldur            w1, [x0, #0x2b]
    // 0x3d9b64: DecompressPointer r1
    //     0x3d9b64: add             x1, x1, HEAP, lsl #32
    // 0x3d9b68: stur            x1, [fp, #-0x30]
    // 0x3d9b6c: cmp             w1, NULL
    // 0x3d9b70: b.eq            #0x3d9e50
    // 0x3d9b74: LoadField: r2 = r1->field_b
    //     0x3d9b74: ldur            w2, [x1, #0xb]
    // 0x3d9b78: DecompressPointer r2
    //     0x3d9b78: add             x2, x2, HEAP, lsl #32
    // 0x3d9b7c: ldur            x16, [fp, #-0x18]
    // 0x3d9b80: stp             x2, x16, [SP]
    // 0x3d9b84: r0 = ==()
    //     0x3d9b84: bl              #0x7c926c  ; [dart:core] _IntegerImplementation::==
    // 0x3d9b88: tbz             w0, #4, #0x3d9bc4
    // 0x3d9b8c: ldur            x1, [fp, #-8]
    // 0x3d9b90: ldur            x0, [fp, #-0x30]
    // 0x3d9b94: LoadField: r2 = r0->field_f
    //     0x3d9b94: ldur            w2, [x0, #0xf]
    // 0x3d9b98: DecompressPointer r2
    //     0x3d9b98: add             x2, x2, HEAP, lsl #32
    // 0x3d9b9c: r0 = 60
    //     0x3d9b9c: movz            x0, #0x3c
    // 0x3d9ba0: branchIfSmi(r1, 0x3d9bac)
    //     0x3d9ba0: tbz             w1, #0, #0x3d9bac
    // 0x3d9ba4: r0 = LoadClassIdInstr(r1)
    //     0x3d9ba4: ldur            x0, [x1, #-1]
    //     0x3d9ba8: ubfx            x0, x0, #0xc, #0x14
    // 0x3d9bac: stp             x2, x1, [SP]
    // 0x3d9bb0: r0 = GDT[cid_x0 + -0xff2]()
    //     0x3d9bb0: sub             lr, x0, #0xff2
    //     0x3d9bb4: ldr             lr, [x21, lr, lsl #3]
    //     0x3d9bb8: blr             lr
    // 0x3d9bbc: mov             x2, x0
    // 0x3d9bc0: b               #0x3d9bcc
    // 0x3d9bc4: ldur            x1, [fp, #-8]
    // 0x3d9bc8: mov             x2, x1
    // 0x3d9bcc: ldur            x0, [fp, #-0x28]
    // 0x3d9bd0: b               #0x3d9b40
    // 0x3d9bd4: ldur            x1, [fp, #-8]
    // 0x3d9bd8: mov             x3, x1
    // 0x3d9bdc: b               #0x3d9d3c
    // 0x3d9be0: cmp             w2, #4
    // 0x3d9be4: b.ne            #0x3d9d34
    // 0x3d9be8: ldur            x3, [fp, #-0x18]
    // 0x3d9bec: r0 = LoadInt32Instr(r3)
    //     0x3d9bec: sbfx            x0, x3, #1, #0x1f
    //     0x3d9bf0: tbz             w3, #0, #0x3d9bf8
    //     0x3d9bf4: ldur            x0, [x3, #7]
    // 0x3d9bf8: cmp             x0, #1
    // 0x3d9bfc: b.le            #0x3d9d2c
    // 0x3d9c00: ldur            x4, [fp, #-0x10]
    // 0x3d9c04: LoadField: r5 = r4->field_47
    //     0x3d9c04: ldur            w5, [x4, #0x47]
    // 0x3d9c08: DecompressPointer r5
    //     0x3d9c08: add             x5, x5, HEAP, lsl #32
    // 0x3d9c0c: stur            x5, [fp, #-8]
    // 0x3d9c10: sub             x2, x0, #1
    // 0x3d9c14: r0 = BoxInt64Instr(r2)
    //     0x3d9c14: sbfiz           x0, x2, #1, #0x1f
    //     0x3d9c18: cmp             x2, x0, asr #1
    //     0x3d9c1c: b.eq            #0x3d9c28
    //     0x3d9c20: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x3d9c24: stur            x2, [x0, #7]
    // 0x3d9c28: mov             x1, x5
    // 0x3d9c2c: mov             x2, x0
    // 0x3d9c30: r0 = _getValueOrData()
    //     0x3d9c30: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3d9c34: mov             x1, x0
    // 0x3d9c38: ldur            x0, [fp, #-8]
    // 0x3d9c3c: LoadField: r2 = r0->field_f
    //     0x3d9c3c: ldur            w2, [x0, #0xf]
    // 0x3d9c40: DecompressPointer r2
    //     0x3d9c40: add             x2, x2, HEAP, lsl #32
    // 0x3d9c44: cmp             w2, w1
    // 0x3d9c48: b.ne            #0x3d9c54
    // 0x3d9c4c: r0 = Null
    //     0x3d9c4c: mov             x0, NULL
    // 0x3d9c50: b               #0x3d9c58
    // 0x3d9c54: mov             x0, x1
    // 0x3d9c58: cmp             w0, NULL
    // 0x3d9c5c: b.ne            #0x3d9c68
    // 0x3d9c60: d0 = 0.000000
    //     0x3d9c60: eor             v0.16b, v0.16b, v0.16b
    // 0x3d9c64: b               #0x3d9c6c
    // 0x3d9c68: LoadField: d0 = r0->field_7
    //     0x3d9c68: ldur            d0, [x0, #7]
    // 0x3d9c6c: ldur            x0, [fp, #-0x10]
    // 0x3d9c70: stur            d0, [fp, #-0x38]
    // 0x3d9c74: LoadField: r1 = r0->field_3f
    //     0x3d9c74: ldur            w1, [x0, #0x3f]
    // 0x3d9c78: DecompressPointer r1
    //     0x3d9c78: add             x1, x1, HEAP, lsl #32
    // 0x3d9c7c: LoadField: r3 = r1->field_b
    //     0x3d9c7c: ldur            w3, [x1, #0xb]
    // 0x3d9c80: DecompressPointer r3
    //     0x3d9c80: add             x3, x3, HEAP, lsl #32
    // 0x3d9c84: mov             x1, x3
    // 0x3d9c88: stur            x3, [fp, #-8]
    // 0x3d9c8c: r2 = 4
    //     0x3d9c8c: movz            x2, #0x4
    // 0x3d9c90: r0 = _getValueOrData()
    //     0x3d9c90: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3d9c94: mov             x1, x0
    // 0x3d9c98: ldur            x0, [fp, #-8]
    // 0x3d9c9c: LoadField: r2 = r0->field_f
    //     0x3d9c9c: ldur            w2, [x0, #0xf]
    // 0x3d9ca0: DecompressPointer r2
    //     0x3d9ca0: add             x2, x2, HEAP, lsl #32
    // 0x3d9ca4: cmp             w2, w1
    // 0x3d9ca8: b.ne            #0x3d9cb4
    // 0x3d9cac: r0 = Null
    //     0x3d9cac: mov             x0, NULL
    // 0x3d9cb0: b               #0x3d9cb8
    // 0x3d9cb4: mov             x0, x1
    // 0x3d9cb8: cmp             w0, NULL
    // 0x3d9cbc: b.ne            #0x3d9cc8
    // 0x3d9cc0: r0 = 0
    //     0x3d9cc0: movz            x0, #0
    // 0x3d9cc4: b               #0x3d9cd8
    // 0x3d9cc8: r1 = LoadInt32Instr(r0)
    //     0x3d9cc8: sbfx            x1, x0, #1, #0x1f
    //     0x3d9ccc: tbz             w0, #0, #0x3d9cd4
    //     0x3d9cd0: ldur            x1, [x0, #7]
    // 0x3d9cd4: mov             x0, x1
    // 0x3d9cd8: ldur            d0, [fp, #-0x38]
    // 0x3d9cdc: r16 = 10
    //     0x3d9cdc: movz            x16, #0xa
    // 0x3d9ce0: mul             x1, x0, x16
    // 0x3d9ce4: add             x0, x1, #0x46
    // 0x3d9ce8: scvtf           d1, x0
    // 0x3d9cec: fcmp            d1, d0
    // 0x3d9cf0: b.le            #0x3d9d24
    // 0x3d9cf4: ldur            x0, [fp, #-0x20]
    // 0x3d9cf8: r1 = 60
    //     0x3d9cf8: movz            x1, #0x3c
    // 0x3d9cfc: branchIfSmi(r0, 0x3d9d08)
    //     0x3d9cfc: tbz             w0, #0, #0x3d9d08
    // 0x3d9d00: r1 = LoadClassIdInstr(r0)
    //     0x3d9d00: ldur            x1, [x0, #-1]
    //     0x3d9d04: ubfx            x1, x1, #0xc, #0x14
    // 0x3d9d08: r16 = 20000
    //     0x3d9d08: movz            x16, #0x4e20
    // 0x3d9d0c: stp             x16, x0, [SP]
    // 0x3d9d10: mov             x0, x1
    // 0x3d9d14: r0 = GDT[cid_x0 + -0xff2]()
    //     0x3d9d14: sub             lr, x0, #0xff2
    //     0x3d9d18: ldr             lr, [x21, lr, lsl #3]
    //     0x3d9d1c: blr             lr
    // 0x3d9d20: b               #0x3d9d38
    // 0x3d9d24: ldur            x0, [fp, #-0x20]
    // 0x3d9d28: b               #0x3d9d38
    // 0x3d9d2c: ldur            x0, [fp, #-0x20]
    // 0x3d9d30: b               #0x3d9d38
    // 0x3d9d34: ldur            x0, [fp, #-0x20]
    // 0x3d9d38: mov             x3, x0
    // 0x3d9d3c: ldur            x0, [fp, #-0x10]
    // 0x3d9d40: mov             x1, x0
    // 0x3d9d44: ldur            x2, [fp, #-0x18]
    // 0x3d9d48: stur            x3, [fp, #-8]
    // 0x3d9d4c: r0 = getGeneratorInfo()
    //     0x3d9d4c: bl              #0x80d118  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getGeneratorInfo
    // 0x3d9d50: LoadField: r3 = r0->field_27
    //     0x3d9d50: ldur            w3, [x0, #0x27]
    // 0x3d9d54: DecompressPointer r3
    //     0x3d9d54: add             x3, x3, HEAP, lsl #32
    // 0x3d9d58: stur            x3, [fp, #-0x30]
    // 0x3d9d5c: cmp             w3, NULL
    // 0x3d9d60: b.eq            #0x3d9e6c
    // 0x3d9d64: LoadField: r0 = r3->field_b
    //     0x3d9d64: ldur            w0, [x3, #0xb]
    // 0x3d9d68: DecompressPointer r0
    //     0x3d9d68: add             x0, x0, HEAP, lsl #32
    // 0x3d9d6c: ldur            x1, [fp, #-0x10]
    // 0x3d9d70: stur            x0, [fp, #-0x28]
    // 0x3d9d74: LoadField: r4 = r1->field_33
    //     0x3d9d74: ldur            w4, [x1, #0x33]
    // 0x3d9d78: DecompressPointer r4
    //     0x3d9d78: add             x4, x4, HEAP, lsl #32
    // 0x3d9d7c: mov             x1, x4
    // 0x3d9d80: ldur            x2, [fp, #-0x18]
    // 0x3d9d84: stur            x4, [fp, #-0x20]
    // 0x3d9d88: r0 = _getValueOrData()
    //     0x3d9d88: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3d9d8c: mov             x1, x0
    // 0x3d9d90: ldur            x0, [fp, #-0x20]
    // 0x3d9d94: LoadField: r2 = r0->field_f
    //     0x3d9d94: ldur            w2, [x0, #0xf]
    // 0x3d9d98: DecompressPointer r2
    //     0x3d9d98: add             x2, x2, HEAP, lsl #32
    // 0x3d9d9c: cmp             w2, w1
    // 0x3d9da0: b.ne            #0x3d9dac
    // 0x3d9da4: r0 = Null
    //     0x3d9da4: mov             x0, NULL
    // 0x3d9da8: b               #0x3d9db0
    // 0x3d9dac: mov             x0, x1
    // 0x3d9db0: cmp             w0, NULL
    // 0x3d9db4: b.ne            #0x3d9dc0
    // 0x3d9db8: r0 = Null
    //     0x3d9db8: mov             x0, NULL
    // 0x3d9dbc: b               #0x3d9dcc
    // 0x3d9dc0: LoadField: r1 = r0->field_b
    //     0x3d9dc0: ldur            w1, [x0, #0xb]
    // 0x3d9dc4: DecompressPointer r1
    //     0x3d9dc4: add             x1, x1, HEAP, lsl #32
    // 0x3d9dc8: mov             x0, x1
    // 0x3d9dcc: cmp             w0, NULL
    // 0x3d9dd0: b.ne            #0x3d9de0
    // 0x3d9dd4: r4 = Instance_CustomNum
    //     0x3d9dd4: add             x4, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3d9dd8: ldr             x4, [x4, #0xa70]
    // 0x3d9ddc: b               #0x3d9de4
    // 0x3d9de0: mov             x4, x0
    // 0x3d9de4: ldur            x0, [fp, #-0x30]
    // 0x3d9de8: ldur            x3, [fp, #-0x28]
    // 0x3d9dec: ldur            x2, [fp, #-8]
    // 0x3d9df0: stur            x4, [fp, #-0x10]
    // 0x3d9df4: r1 = Instance_CustomNum
    //     0x3d9df4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3d9df8: ldr             x1, [x1, #0x2f0]
    // 0x3d9dfc: r0 = pow()
    //     0x3d9dfc: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3d9e00: mov             x1, x0
    // 0x3d9e04: ldur            x0, [fp, #-0x30]
    // 0x3d9e08: LoadField: r3 = r0->field_f
    //     0x3d9e08: ldur            w3, [x0, #0xf]
    // 0x3d9e0c: DecompressPointer r3
    //     0x3d9e0c: add             x3, x3, HEAP, lsl #32
    // 0x3d9e10: mov             x2, x1
    // 0x3d9e14: ldur            x1, [fp, #-0x10]
    // 0x3d9e18: r0 = mult3()
    //     0x3d9e18: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x3d9e1c: r1 = <Chapter10Stat, CustomNum>
    //     0x3d9e1c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16720] TypeArguments: <Chapter10Stat, CustomNum>
    //     0x3d9e20: ldr             x1, [x1, #0x720]
    // 0x3d9e24: stur            x0, [fp, #-8]
    // 0x3d9e28: r0 = Tuple2()
    //     0x3d9e28: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3d9e2c: mov             x1, x0
    // 0x3d9e30: ldur            x0, [fp, #-0x28]
    // 0x3d9e34: StoreField: r1->field_b = r0
    //     0x3d9e34: stur            w0, [x1, #0xb]
    // 0x3d9e38: ldur            x0, [fp, #-8]
    // 0x3d9e3c: StoreField: r1->field_f = r0
    //     0x3d9e3c: stur            w0, [x1, #0xf]
    // 0x3d9e40: mov             x0, x1
    // 0x3d9e44: LeaveFrame
    //     0x3d9e44: mov             SP, fp
    //     0x3d9e48: ldp             fp, lr, [SP], #0x10
    // 0x3d9e4c: ret
    //     0x3d9e4c: ret             
    // 0x3d9e50: r0 = noElement()
    //     0x3d9e50: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x3d9e54: r0 = Throw()
    //     0x3d9e54: bl              #0x825670  ; ThrowStub
    // 0x3d9e58: brk             #0
    // 0x3d9e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3d9e5c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3d9e60: b               #0x3d9ae0
    // 0x3d9e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3d9e64: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3d9e68: b               #0x3d9b50
    // 0x3d9e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3d9e6c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter10Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3d9e70, size: 0x40
    // 0x3d9e70: EnterFrame
    //     0x3d9e70: stp             fp, lr, [SP, #-0x10]!
    //     0x3d9e74: mov             fp, SP
    // 0x3d9e78: ldr             x0, [fp, #0x20]
    // 0x3d9e7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3d9e7c: ldur            w1, [x0, #0x17]
    // 0x3d9e80: DecompressPointer r1
    //     0x3d9e80: add             x1, x1, HEAP, lsl #32
    // 0x3d9e84: CheckStackOverflow
    //     0x3d9e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3d9e88: cmp             SP, x16
    //     0x3d9e8c: b.ls            #0x3d9ea8
    // 0x3d9e90: ldr             x2, [fp, #0x18]
    // 0x3d9e94: ldr             x3, [fp, #0x10]
    // 0x3d9e98: r0 = getCostToBuyOneMoreGenerator()
    //     0x3d9e98: bl              #0x3d9ab0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getCostToBuyOneMoreGenerator
    // 0x3d9e9c: LeaveFrame
    //     0x3d9e9c: mov             SP, fp
    //     0x3d9ea0: ldp             fp, lr, [SP], #0x10
    // 0x3d9ea4: ret
    //     0x3d9ea4: ret             
    // 0x3d9ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3d9ea8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3d9eac: b               #0x3d9e90
  }
  _ Chapter10GameState(/* No info */) {
    // ** addr: 0x46db78, size: 0x5c8
    // 0x46db78: EnterFrame
    //     0x46db78: stp             fp, lr, [SP, #-0x10]!
    //     0x46db7c: mov             fp, SP
    // 0x46db80: AllocStack(0x38)
    //     0x46db80: sub             SP, SP, #0x38
    // 0x46db84: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x46db88: r3 = 26
    //     0x46db88: movz            x3, #0x1a
    // 0x46db8c: r0 = 1
    //     0x46db8c: movz            x0, #0x1
    // 0x46db90: mov             x6, x1
    // 0x46db94: mov             x5, x2
    // 0x46db98: stur            x1, [fp, #-8]
    // 0x46db9c: stur            x2, [fp, #-0x10]
    // 0x46dba0: CheckStackOverflow
    //     0x46dba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46dba4: cmp             SP, x16
    //     0x46dba8: b.ls            #0x46e138
    // 0x46dbac: StoreField: r6->field_8b = r0
    //     0x46dbac: stur            x0, [x6, #0x8b]
    // 0x46dbb0: StoreField: r6->field_93 = r4
    //     0x46dbb0: stur            w4, [x6, #0x93]
    // 0x46dbb4: StoreField: r6->field_97 = r4
    //     0x46dbb4: stur            w4, [x6, #0x97]
    // 0x46dbb8: mov             x2, x3
    // 0x46dbbc: r1 = <(String, CustomNum)>
    //     0x46dbbc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11660] TypeArguments: <(String, CustomNum)>
    //     0x46dbc0: ldr             x1, [x1, #0x660]
    // 0x46dbc4: r0 = AllocateArray()
    //     0x46dbc4: bl              #0x82746c  ; AllocateArrayStub
    // 0x46dbc8: r2 = "0.00"
    //     0x46dbc8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11668] "0.00"
    //     0x46dbcc: ldr             x2, [x2, #0x668]
    // 0x46dbd0: r3 = Instance_CustomNum
    //     0x46dbd0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x46dbd4: ldr             x3, [x3, #0xaf8]
    // 0x46dbd8: stur            x0, [fp, #-0x18]
    // 0x46dbdc: r0 = AllocateRecord2()
    //     0x46dbdc: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dbe0: ldur            x1, [fp, #-0x18]
    // 0x46dbe4: ArrayStore: r1[0] = r0  ; List_4
    //     0x46dbe4: add             x25, x1, #0xf
    //     0x46dbe8: str             w0, [x25]
    //     0x46dbec: tbz             w0, #0, #0x46dc08
    //     0x46dbf0: ldurb           w16, [x1, #-1]
    //     0x46dbf4: ldurb           w17, [x0, #-1]
    //     0x46dbf8: and             x16, x17, x16, lsr #2
    //     0x46dbfc: tst             x16, HEAP, lsr #32
    //     0x46dc00: b.eq            #0x46dc08
    //     0x46dc04: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dc08: r1 = Null
    //     0x46dc08: mov             x1, NULL
    // 0x46dc0c: r2 = 20000
    //     0x46dc0c: movz            x2, #0x4e20
    // 0x46dc10: r0 = CustomNum()
    //     0x46dc10: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46dc14: mov             x3, x0
    // 0x46dc18: r2 = "0.01"
    //     0x46dc18: add             x2, PP, #0x11, lsl #12  ; [pp+0x11670] "0.01"
    //     0x46dc1c: ldr             x2, [x2, #0x670]
    // 0x46dc20: r0 = AllocateRecord2()
    //     0x46dc20: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dc24: ldur            x1, [fp, #-0x18]
    // 0x46dc28: ArrayStore: r1[1] = r0  ; List_4
    //     0x46dc28: add             x25, x1, #0x13
    //     0x46dc2c: str             w0, [x25]
    //     0x46dc30: tbz             w0, #0, #0x46dc4c
    //     0x46dc34: ldurb           w16, [x1, #-1]
    //     0x46dc38: ldurb           w17, [x0, #-1]
    //     0x46dc3c: and             x16, x17, x16, lsr #2
    //     0x46dc40: tst             x16, HEAP, lsr #32
    //     0x46dc44: b.eq            #0x46dc4c
    //     0x46dc48: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dc4c: r2 = "0.02"
    //     0x46dc4c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11678] "0.02"
    //     0x46dc50: ldr             x2, [x2, #0x678]
    // 0x46dc54: r3 = Instance_CustomNum
    //     0x46dc54: add             x3, PP, #0x11, lsl #12  ; [pp+0x11680] Obj!CustomNum@828d11
    //     0x46dc58: ldr             x3, [x3, #0x680]
    // 0x46dc5c: r0 = AllocateRecord2()
    //     0x46dc5c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dc60: ldur            x1, [fp, #-0x18]
    // 0x46dc64: ArrayStore: r1[2] = r0  ; List_4
    //     0x46dc64: add             x25, x1, #0x17
    //     0x46dc68: str             w0, [x25]
    //     0x46dc6c: tbz             w0, #0, #0x46dc88
    //     0x46dc70: ldurb           w16, [x1, #-1]
    //     0x46dc74: ldurb           w17, [x0, #-1]
    //     0x46dc78: and             x16, x17, x16, lsr #2
    //     0x46dc7c: tst             x16, HEAP, lsr #32
    //     0x46dc80: b.eq            #0x46dc88
    //     0x46dc84: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dc88: r2 = "0.03"
    //     0x46dc88: add             x2, PP, #0x11, lsl #12  ; [pp+0x11688] "0.03"
    //     0x46dc8c: ldr             x2, [x2, #0x688]
    // 0x46dc90: r3 = Instance_CustomNum
    //     0x46dc90: add             x3, PP, #0x11, lsl #12  ; [pp+0x11690] Obj!CustomNum@828d01
    //     0x46dc94: ldr             x3, [x3, #0x690]
    // 0x46dc98: r0 = AllocateRecord2()
    //     0x46dc98: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dc9c: ldur            x1, [fp, #-0x18]
    // 0x46dca0: ArrayStore: r1[3] = r0  ; List_4
    //     0x46dca0: add             x25, x1, #0x1b
    //     0x46dca4: str             w0, [x25]
    //     0x46dca8: tbz             w0, #0, #0x46dcc4
    //     0x46dcac: ldurb           w16, [x1, #-1]
    //     0x46dcb0: ldurb           w17, [x0, #-1]
    //     0x46dcb4: and             x16, x17, x16, lsr #2
    //     0x46dcb8: tst             x16, HEAP, lsr #32
    //     0x46dcbc: b.eq            #0x46dcc4
    //     0x46dcc0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dcc4: r2 = "0.10"
    //     0x46dcc4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11698] "0.10"
    //     0x46dcc8: ldr             x2, [x2, #0x698]
    // 0x46dccc: r3 = Instance_CustomNum
    //     0x46dccc: add             x3, PP, #0x11, lsl #12  ; [pp+0x116a0] Obj!CustomNum@828cf1
    //     0x46dcd0: ldr             x3, [x3, #0x6a0]
    // 0x46dcd4: r0 = AllocateRecord2()
    //     0x46dcd4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dcd8: ldur            x1, [fp, #-0x18]
    // 0x46dcdc: ArrayStore: r1[4] = r0  ; List_4
    //     0x46dcdc: add             x25, x1, #0x1f
    //     0x46dce0: str             w0, [x25]
    //     0x46dce4: tbz             w0, #0, #0x46dd00
    //     0x46dce8: ldurb           w16, [x1, #-1]
    //     0x46dcec: ldurb           w17, [x0, #-1]
    //     0x46dcf0: and             x16, x17, x16, lsr #2
    //     0x46dcf4: tst             x16, HEAP, lsr #32
    //     0x46dcf8: b.eq            #0x46dd00
    //     0x46dcfc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dd00: r2 = "0.11"
    //     0x46dd00: add             x2, PP, #0x11, lsl #12  ; [pp+0x116a8] "0.11"
    //     0x46dd04: ldr             x2, [x2, #0x6a8]
    // 0x46dd08: r3 = Instance_CustomNum
    //     0x46dd08: add             x3, PP, #0x11, lsl #12  ; [pp+0x116b0] Obj!CustomNum@828ce1
    //     0x46dd0c: ldr             x3, [x3, #0x6b0]
    // 0x46dd10: r0 = AllocateRecord2()
    //     0x46dd10: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dd14: ldur            x1, [fp, #-0x18]
    // 0x46dd18: ArrayStore: r1[5] = r0  ; List_4
    //     0x46dd18: add             x25, x1, #0x23
    //     0x46dd1c: str             w0, [x25]
    //     0x46dd20: tbz             w0, #0, #0x46dd3c
    //     0x46dd24: ldurb           w16, [x1, #-1]
    //     0x46dd28: ldurb           w17, [x0, #-1]
    //     0x46dd2c: and             x16, x17, x16, lsr #2
    //     0x46dd30: tst             x16, HEAP, lsr #32
    //     0x46dd34: b.eq            #0x46dd3c
    //     0x46dd38: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dd3c: r2 = "0.12"
    //     0x46dd3c: add             x2, PP, #0x11, lsl #12  ; [pp+0x116b8] "0.12"
    //     0x46dd40: ldr             x2, [x2, #0x6b8]
    // 0x46dd44: r3 = Instance_CustomNum
    //     0x46dd44: add             x3, PP, #0x11, lsl #12  ; [pp+0x116c0] Obj!CustomNum@828cd1
    //     0x46dd48: ldr             x3, [x3, #0x6c0]
    // 0x46dd4c: r0 = AllocateRecord2()
    //     0x46dd4c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dd50: ldur            x1, [fp, #-0x18]
    // 0x46dd54: ArrayStore: r1[6] = r0  ; List_4
    //     0x46dd54: add             x25, x1, #0x27
    //     0x46dd58: str             w0, [x25]
    //     0x46dd5c: tbz             w0, #0, #0x46dd78
    //     0x46dd60: ldurb           w16, [x1, #-1]
    //     0x46dd64: ldurb           w17, [x0, #-1]
    //     0x46dd68: and             x16, x17, x16, lsr #2
    //     0x46dd6c: tst             x16, HEAP, lsr #32
    //     0x46dd70: b.eq            #0x46dd78
    //     0x46dd74: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dd78: r2 = "0.95"
    //     0x46dd78: add             x2, PP, #0x11, lsl #12  ; [pp+0x116c8] "0.95"
    //     0x46dd7c: ldr             x2, [x2, #0x6c8]
    // 0x46dd80: r3 = Instance_CustomNum
    //     0x46dd80: add             x3, PP, #0x11, lsl #12  ; [pp+0x116d0] Obj!CustomNum@828cc1
    //     0x46dd84: ldr             x3, [x3, #0x6d0]
    // 0x46dd88: r0 = AllocateRecord2()
    //     0x46dd88: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46dd8c: ldur            x1, [fp, #-0x18]
    // 0x46dd90: ArrayStore: r1[7] = r0  ; List_4
    //     0x46dd90: add             x25, x1, #0x2b
    //     0x46dd94: str             w0, [x25]
    //     0x46dd98: tbz             w0, #0, #0x46ddb4
    //     0x46dd9c: ldurb           w16, [x1, #-1]
    //     0x46dda0: ldurb           w17, [x0, #-1]
    //     0x46dda4: and             x16, x17, x16, lsr #2
    //     0x46dda8: tst             x16, HEAP, lsr #32
    //     0x46ddac: b.eq            #0x46ddb4
    //     0x46ddb0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46ddb4: r2 = "0.96"
    //     0x46ddb4: add             x2, PP, #0x11, lsl #12  ; [pp+0x116d8] "0.96"
    //     0x46ddb8: ldr             x2, [x2, #0x6d8]
    // 0x46ddbc: r3 = Instance_CustomNum
    //     0x46ddbc: add             x3, PP, #0x11, lsl #12  ; [pp+0x116e0] Obj!CustomNum@828cb1
    //     0x46ddc0: ldr             x3, [x3, #0x6e0]
    // 0x46ddc4: r0 = AllocateRecord2()
    //     0x46ddc4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46ddc8: ldur            x1, [fp, #-0x18]
    // 0x46ddcc: ArrayStore: r1[8] = r0  ; List_4
    //     0x46ddcc: add             x25, x1, #0x2f
    //     0x46ddd0: str             w0, [x25]
    //     0x46ddd4: tbz             w0, #0, #0x46ddf0
    //     0x46ddd8: ldurb           w16, [x1, #-1]
    //     0x46dddc: ldurb           w17, [x0, #-1]
    //     0x46dde0: and             x16, x17, x16, lsr #2
    //     0x46dde4: tst             x16, HEAP, lsr #32
    //     0x46dde8: b.eq            #0x46ddf0
    //     0x46ddec: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46ddf0: r2 = "0.97"
    //     0x46ddf0: add             x2, PP, #0x11, lsl #12  ; [pp+0x116e8] "0.97"
    //     0x46ddf4: ldr             x2, [x2, #0x6e8]
    // 0x46ddf8: r3 = Instance_CustomNum
    //     0x46ddf8: add             x3, PP, #0x11, lsl #12  ; [pp+0x116f0] Obj!CustomNum@828ca1
    //     0x46ddfc: ldr             x3, [x3, #0x6f0]
    // 0x46de00: r0 = AllocateRecord2()
    //     0x46de00: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46de04: ldur            x1, [fp, #-0x18]
    // 0x46de08: ArrayStore: r1[9] = r0  ; List_4
    //     0x46de08: add             x25, x1, #0x33
    //     0x46de0c: str             w0, [x25]
    //     0x46de10: tbz             w0, #0, #0x46de2c
    //     0x46de14: ldurb           w16, [x1, #-1]
    //     0x46de18: ldurb           w17, [x0, #-1]
    //     0x46de1c: and             x16, x17, x16, lsr #2
    //     0x46de20: tst             x16, HEAP, lsr #32
    //     0x46de24: b.eq            #0x46de2c
    //     0x46de28: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46de2c: r2 = "0.98"
    //     0x46de2c: add             x2, PP, #0x11, lsl #12  ; [pp+0x116f8] "0.98"
    //     0x46de30: ldr             x2, [x2, #0x6f8]
    // 0x46de34: r3 = Instance_CustomNum
    //     0x46de34: add             x3, PP, #0x11, lsl #12  ; [pp+0x11700] Obj!CustomNum@828c91
    //     0x46de38: ldr             x3, [x3, #0x700]
    // 0x46de3c: r0 = AllocateRecord2()
    //     0x46de3c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46de40: ldur            x1, [fp, #-0x18]
    // 0x46de44: ArrayStore: r1[10] = r0  ; List_4
    //     0x46de44: add             x25, x1, #0x37
    //     0x46de48: str             w0, [x25]
    //     0x46de4c: tbz             w0, #0, #0x46de68
    //     0x46de50: ldurb           w16, [x1, #-1]
    //     0x46de54: ldurb           w17, [x0, #-1]
    //     0x46de58: and             x16, x17, x16, lsr #2
    //     0x46de5c: tst             x16, HEAP, lsr #32
    //     0x46de60: b.eq            #0x46de68
    //     0x46de64: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46de68: r2 = "0.99"
    //     0x46de68: add             x2, PP, #0x11, lsl #12  ; [pp+0x11708] "0.99"
    //     0x46de6c: ldr             x2, [x2, #0x708]
    // 0x46de70: r3 = Instance_CustomNum
    //     0x46de70: add             x3, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!CustomNum@828c81
    //     0x46de74: ldr             x3, [x3, #0x710]
    // 0x46de78: r0 = AllocateRecord2()
    //     0x46de78: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46de7c: ldur            x1, [fp, #-0x18]
    // 0x46de80: ArrayStore: r1[11] = r0  ; List_4
    //     0x46de80: add             x25, x1, #0x3b
    //     0x46de84: str             w0, [x25]
    //     0x46de88: tbz             w0, #0, #0x46dea4
    //     0x46de8c: ldurb           w16, [x1, #-1]
    //     0x46de90: ldurb           w17, [x0, #-1]
    //     0x46de94: and             x16, x17, x16, lsr #2
    //     0x46de98: tst             x16, HEAP, lsr #32
    //     0x46de9c: b.eq            #0x46dea4
    //     0x46dea0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dea4: r2 = "1.00"
    //     0x46dea4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11718] "1.00"
    //     0x46dea8: ldr             x2, [x2, #0x718]
    // 0x46deac: r3 = Instance_CustomNum
    //     0x46deac: add             x3, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!CustomNum@828c81
    //     0x46deb0: ldr             x3, [x3, #0x710]
    // 0x46deb4: r0 = AllocateRecord2()
    //     0x46deb4: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x46deb8: ldur            x1, [fp, #-0x18]
    // 0x46debc: ArrayStore: r1[12] = r0  ; List_4
    //     0x46debc: add             x25, x1, #0x3f
    //     0x46dec0: str             w0, [x25]
    //     0x46dec4: tbz             w0, #0, #0x46dee0
    //     0x46dec8: ldurb           w16, [x1, #-1]
    //     0x46decc: ldurb           w17, [x0, #-1]
    //     0x46ded0: and             x16, x17, x16, lsr #2
    //     0x46ded4: tst             x16, HEAP, lsr #32
    //     0x46ded8: b.eq            #0x46dee0
    //     0x46dedc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46dee0: r1 = <(String, CustomNum)>
    //     0x46dee0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11660] TypeArguments: <(String, CustomNum)>
    //     0x46dee4: ldr             x1, [x1, #0x660]
    // 0x46dee8: r0 = AllocateGrowableArray()
    //     0x46dee8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46deec: mov             x1, x0
    // 0x46def0: ldur            x0, [fp, #-0x18]
    // 0x46def4: StoreField: r1->field_f = r0
    //     0x46def4: stur            w0, [x1, #0xf]
    // 0x46def8: r0 = 26
    //     0x46def8: movz            x0, #0x1a
    // 0x46defc: StoreField: r1->field_b = r0
    //     0x46defc: stur            w0, [x1, #0xb]
    // 0x46df00: mov             x0, x1
    // 0x46df04: ldur            x3, [fp, #-8]
    // 0x46df08: StoreField: r3->field_9b = r0
    //     0x46df08: stur            w0, [x3, #0x9b]
    //     0x46df0c: ldurb           w16, [x3, #-1]
    //     0x46df10: ldurb           w17, [x0, #-1]
    //     0x46df14: and             x16, x17, x16, lsr #2
    //     0x46df18: tst             x16, HEAP, lsr #32
    //     0x46df1c: b.eq            #0x46df24
    //     0x46df20: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46df24: r1 = Null
    //     0x46df24: mov             x1, NULL
    // 0x46df28: r2 = 24
    //     0x46df28: movz            x2, #0x18
    // 0x46df2c: r0 = AllocateArray()
    //     0x46df2c: bl              #0x82746c  ; AllocateArrayStub
    // 0x46df30: r16 = 2
    //     0x46df30: movz            x16, #0x2
    // 0x46df34: StoreField: r0->field_f = r16
    //     0x46df34: stur            w16, [x0, #0xf]
    // 0x46df38: r16 = Instance_Chapter10Stat
    //     0x46df38: add             x16, PP, #0x11, lsl #12  ; [pp+0x11720] Obj!Chapter10Stat@85fee1
    //     0x46df3c: ldr             x16, [x16, #0x720]
    // 0x46df40: StoreField: r0->field_13 = r16
    //     0x46df40: stur            w16, [x0, #0x13]
    // 0x46df44: r16 = 4
    //     0x46df44: movz            x16, #0x4
    // 0x46df48: ArrayStore: r0[0] = r16  ; List_4
    //     0x46df48: stur            w16, [x0, #0x17]
    // 0x46df4c: r16 = Instance_Chapter10Stat
    //     0x46df4c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11728] Obj!Chapter10Stat@85fec1
    //     0x46df50: ldr             x16, [x16, #0x728]
    // 0x46df54: StoreField: r0->field_1b = r16
    //     0x46df54: stur            w16, [x0, #0x1b]
    // 0x46df58: r16 = 6
    //     0x46df58: movz            x16, #0x6
    // 0x46df5c: StoreField: r0->field_1f = r16
    //     0x46df5c: stur            w16, [x0, #0x1f]
    // 0x46df60: r16 = Instance_Chapter10Stat
    //     0x46df60: add             x16, PP, #0x11, lsl #12  ; [pp+0x11730] Obj!Chapter10Stat@85fea1
    //     0x46df64: ldr             x16, [x16, #0x730]
    // 0x46df68: StoreField: r0->field_23 = r16
    //     0x46df68: stur            w16, [x0, #0x23]
    // 0x46df6c: r16 = 8
    //     0x46df6c: movz            x16, #0x8
    // 0x46df70: StoreField: r0->field_27 = r16
    //     0x46df70: stur            w16, [x0, #0x27]
    // 0x46df74: r16 = Instance_Chapter10Stat
    //     0x46df74: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] Obj!Chapter10Stat@85fe81
    //     0x46df78: ldr             x16, [x16, #0x738]
    // 0x46df7c: StoreField: r0->field_2b = r16
    //     0x46df7c: stur            w16, [x0, #0x2b]
    // 0x46df80: r16 = 10
    //     0x46df80: movz            x16, #0xa
    // 0x46df84: StoreField: r0->field_2f = r16
    //     0x46df84: stur            w16, [x0, #0x2f]
    // 0x46df88: r16 = Instance_Chapter10Stat
    //     0x46df88: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] Obj!Chapter10Stat@85fe61
    //     0x46df8c: ldr             x16, [x16, #0x740]
    // 0x46df90: StoreField: r0->field_33 = r16
    //     0x46df90: stur            w16, [x0, #0x33]
    // 0x46df94: r16 = 12
    //     0x46df94: movz            x16, #0xc
    // 0x46df98: StoreField: r0->field_37 = r16
    //     0x46df98: stur            w16, [x0, #0x37]
    // 0x46df9c: r16 = Instance_Chapter10Stat
    //     0x46df9c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] Obj!Chapter10Stat@85fe41
    //     0x46dfa0: ldr             x16, [x16, #0x748]
    // 0x46dfa4: StoreField: r0->field_3b = r16
    //     0x46dfa4: stur            w16, [x0, #0x3b]
    // 0x46dfa8: r16 = <int, Chapter10Stat>
    //     0x46dfa8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11750] TypeArguments: <int, Chapter10Stat>
    //     0x46dfac: ldr             x16, [x16, #0x750]
    // 0x46dfb0: stp             x0, x16, [SP]
    // 0x46dfb4: r0 = Map._fromLiteral()
    //     0x46dfb4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46dfb8: ldur            x3, [fp, #-8]
    // 0x46dfbc: StoreField: r3->field_9f = r0
    //     0x46dfbc: stur            w0, [x3, #0x9f]
    //     0x46dfc0: ldurb           w16, [x3, #-1]
    //     0x46dfc4: ldurb           w17, [x0, #-1]
    //     0x46dfc8: and             x16, x17, x16, lsr #2
    //     0x46dfcc: tst             x16, HEAP, lsr #32
    //     0x46dfd0: b.eq            #0x46dfd8
    //     0x46dfd4: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46dfd8: r1 = Function '<anonymous closure>':.
    //     0x46dfd8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11758] AnonymousClosure: (0x46e3ac), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x46dfdc: ldr             x1, [x1, #0x758]
    // 0x46dfe0: r2 = Null
    //     0x46dfe0: mov             x2, NULL
    // 0x46dfe4: r0 = AllocateClosure()
    //     0x46dfe4: bl              #0x826750  ; AllocateClosureStub
    // 0x46dfe8: r1 = Function '<anonymous closure>':.
    //     0x46dfe8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11760] AnonymousClosure: (0x46e294), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x46dfec: ldr             x1, [x1, #0x760]
    // 0x46dff0: r2 = Null
    //     0x46dff0: mov             x2, NULL
    // 0x46dff4: stur            x0, [fp, #-0x18]
    // 0x46dff8: r0 = AllocateClosure()
    //     0x46dff8: bl              #0x826750  ; AllocateClosureStub
    // 0x46dffc: r1 = Function '<anonymous closure>':.
    //     0x46dffc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11768] AnonymousClosure: (0x46e16c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x46e000: ldr             x1, [x1, #0x768]
    // 0x46e004: r2 = Null
    //     0x46e004: mov             x2, NULL
    // 0x46e008: stur            x0, [fp, #-0x20]
    // 0x46e00c: r0 = AllocateClosure()
    //     0x46e00c: bl              #0x826750  ; AllocateClosureStub
    // 0x46e010: r1 = Function '<anonymous closure>':.
    //     0x46e010: add             x1, PP, #0x11, lsl #12  ; [pp+0x11770] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46e014: ldr             x1, [x1, #0x770]
    // 0x46e018: r2 = Null
    //     0x46e018: mov             x2, NULL
    // 0x46e01c: stur            x0, [fp, #-0x28]
    // 0x46e020: r0 = AllocateClosure()
    //     0x46e020: bl              #0x826750  ; AllocateClosureStub
    // 0x46e024: ldur            x1, [fp, #-8]
    // 0x46e028: ldur            x2, [fp, #-0x10]
    // 0x46e02c: ldur            x3, [fp, #-0x18]
    // 0x46e030: ldur            x5, [fp, #-0x20]
    // 0x46e034: ldur            x6, [fp, #-0x28]
    // 0x46e038: mov             x7, x0
    // 0x46e03c: r0 = IPlayableGameState()
    //     0x46e03c: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46e040: ldur            x1, [fp, #-0x10]
    // 0x46e044: cmp             w1, NULL
    // 0x46e048: b.ne            #0x46e054
    // 0x46e04c: r3 = Null
    //     0x46e04c: mov             x3, NULL
    // 0x46e050: b               #0x46e070
    // 0x46e054: r0 = LoadClassIdInstr(r1)
    //     0x46e054: ldur            x0, [x1, #-1]
    //     0x46e058: ubfx            x0, x0, #0xc, #0x14
    // 0x46e05c: r2 = 38
    //     0x46e05c: movz            x2, #0x26
    // 0x46e060: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46e060: sub             lr, x0, #1, lsl #12
    //     0x46e064: ldr             lr, [x21, lr, lsl #3]
    //     0x46e068: blr             lr
    // 0x46e06c: mov             x3, x0
    // 0x46e070: mov             x0, x3
    // 0x46e074: stur            x3, [fp, #-0x10]
    // 0x46e078: r2 = Null
    //     0x46e078: mov             x2, NULL
    // 0x46e07c: r1 = Null
    //     0x46e07c: mov             x1, NULL
    // 0x46e080: r8 = Map?
    //     0x46e080: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x46e084: ldr             x8, [x8, #0x38]
    // 0x46e088: r3 = Null
    //     0x46e088: add             x3, PP, #0x11, lsl #12  ; [pp+0x11778] Null
    //     0x46e08c: ldr             x3, [x3, #0x778]
    // 0x46e090: r0 = Map?()
    //     0x46e090: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x46e094: ldur            x1, [fp, #-0x10]
    // 0x46e098: cmp             w1, NULL
    // 0x46e09c: b.ne            #0x46e0a8
    // 0x46e0a0: r0 = Null
    //     0x46e0a0: mov             x0, NULL
    // 0x46e0a4: b               #0x46e0c0
    // 0x46e0a8: r0 = LoadClassIdInstr(r1)
    //     0x46e0a8: ldur            x0, [x1, #-1]
    //     0x46e0ac: ubfx            x0, x0, #0xc, #0x14
    // 0x46e0b0: r2 = 0
    //     0x46e0b0: movz            x2, #0
    // 0x46e0b4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46e0b4: sub             lr, x0, #1, lsl #12
    //     0x46e0b8: ldr             lr, [x21, lr, lsl #3]
    //     0x46e0bc: blr             lr
    // 0x46e0c0: cmp             w0, NULL
    // 0x46e0c4: b.ne            #0x46e0d0
    // 0x46e0c8: r4 = 2
    //     0x46e0c8: movz            x4, #0x2
    // 0x46e0cc: b               #0x46e0d4
    // 0x46e0d0: mov             x4, x0
    // 0x46e0d4: ldur            x3, [fp, #-8]
    // 0x46e0d8: mov             x0, x4
    // 0x46e0dc: stur            x4, [fp, #-0x10]
    // 0x46e0e0: r2 = Null
    //     0x46e0e0: mov             x2, NULL
    // 0x46e0e4: r1 = Null
    //     0x46e0e4: mov             x1, NULL
    // 0x46e0e8: branchIfSmi(r0, 0x46e110)
    //     0x46e0e8: tbz             w0, #0, #0x46e110
    // 0x46e0ec: r4 = LoadClassIdInstr(r0)
    //     0x46e0ec: ldur            x4, [x0, #-1]
    //     0x46e0f0: ubfx            x4, x4, #0xc, #0x14
    // 0x46e0f4: sub             x4, x4, #0x3c
    // 0x46e0f8: cmp             x4, #1
    // 0x46e0fc: b.ls            #0x46e110
    // 0x46e100: r8 = int
    //     0x46e100: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x46e104: r3 = Null
    //     0x46e104: add             x3, PP, #0x11, lsl #12  ; [pp+0x11788] Null
    //     0x46e108: ldr             x3, [x3, #0x788]
    // 0x46e10c: r0 = int()
    //     0x46e10c: bl              #0x82bb04  ; IsType_int_Stub
    // 0x46e110: ldur            x1, [fp, #-0x10]
    // 0x46e114: r2 = LoadInt32Instr(r1)
    //     0x46e114: sbfx            x2, x1, #1, #0x1f
    //     0x46e118: tbz             w1, #0, #0x46e120
    //     0x46e11c: ldur            x2, [x1, #7]
    // 0x46e120: ldur            x1, [fp, #-8]
    // 0x46e124: StoreField: r1->field_8b = r2
    //     0x46e124: stur            x2, [x1, #0x8b]
    // 0x46e128: r0 = Null
    //     0x46e128: mov             x0, NULL
    // 0x46e12c: LeaveFrame
    //     0x46e12c: mov             SP, fp
    //     0x46e130: ldp             fp, lr, [SP], #0x10
    // 0x46e134: ret
    //     0x46e134: ret             
    // 0x46e138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46e138: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46e13c: b               #0x46dbac
  }
  [closure] String <anonymous closure>(dynamic, Chapter10Stat) {
    // ** addr: 0x46e16c, size: 0x30
    // 0x46e16c: EnterFrame
    //     0x46e16c: stp             fp, lr, [SP, #-0x10]!
    //     0x46e170: mov             fp, SP
    // 0x46e174: CheckStackOverflow
    //     0x46e174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46e178: cmp             SP, x16
    //     0x46e17c: b.ls            #0x46e194
    // 0x46e180: ldr             x1, [fp, #0x10]
    // 0x46e184: r0 = humanName()
    //     0x46e184: bl              #0x46e19c  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] ::humanName
    // 0x46e188: LeaveFrame
    //     0x46e188: mov             SP, fp
    //     0x46e18c: ldp             fp, lr, [SP], #0x10
    // 0x46e190: ret
    //     0x46e190: ret             
    // 0x46e194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46e194: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46e198: b               #0x46e180
  }
  [closure] String <anonymous closure>(dynamic, Chapter10Stat) {
    // ** addr: 0x46e294, size: 0x30
    // 0x46e294: EnterFrame
    //     0x46e294: stp             fp, lr, [SP, #-0x10]!
    //     0x46e298: mov             fp, SP
    // 0x46e29c: CheckStackOverflow
    //     0x46e29c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46e2a0: cmp             SP, x16
    //     0x46e2a4: b.ls            #0x46e2bc
    // 0x46e2a8: ldr             x1, [fp, #0x10]
    // 0x46e2ac: r0 = shortenedName()
    //     0x46e2ac: bl              #0x46e2c4  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] ::shortenedName
    // 0x46e2b0: LeaveFrame
    //     0x46e2b0: mov             SP, fp
    //     0x46e2b4: ldp             fp, lr, [SP], #0x10
    // 0x46e2b8: ret
    //     0x46e2b8: ret             
    // 0x46e2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46e2bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46e2c0: b               #0x46e2a8
  }
  [closure] Chapter10Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46e3ac, size: 0x44
    // 0x46e3ac: r2 = const [Instance of 'Chapter10Stat', Instance of 'Chapter10Stat', Instance of 'Chapter10Stat', Instance of 'Chapter10Stat', Instance of 'Chapter10Stat', Instance of 'Chapter10Stat', Instance of 'Chapter10Stat', Instance of 'Chapter10Stat']
    //     0x46e3ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11818] List<Chapter10Stat>(8)
    //     0x46e3b0: ldr             x2, [x2, #0x818]
    // 0x46e3b4: ldr             x3, [SP]
    // 0x46e3b8: r4 = LoadInt32Instr(r3)
    //     0x46e3b8: sbfx            x4, x3, #1, #0x1f
    //     0x46e3bc: tbz             w3, #0, #0x46e3c4
    //     0x46e3c0: ldur            x4, [x3, #7]
    // 0x46e3c4: mov             x1, x4
    // 0x46e3c8: r0 = 8
    //     0x46e3c8: movz            x0, #0x8
    // 0x46e3cc: cmp             x1, x0
    // 0x46e3d0: b.hs            #0x46e3e4
    // 0x46e3d4: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46e3d4: add             x16, x2, x4, lsl #2
    //     0x46e3d8: ldur            w0, [x16, #0xf]
    // 0x46e3dc: DecompressPointer r0
    //     0x46e3dc: add             x0, x0, HEAP, lsl #32
    // 0x46e3e0: ret
    //     0x46e3e0: ret             
    // 0x46e3e4: EnterFrame
    //     0x46e3e4: stp             fp, lr, [SP, #-0x10]!
    //     0x46e3e8: mov             fp, SP
    // 0x46e3ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46e3ec: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toMapFile(/* No info */) {
    // ** addr: 0x4e2e2c, size: 0xdc
    // 0x4e2e2c: EnterFrame
    //     0x4e2e2c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e2e30: mov             fp, SP
    // 0x4e2e34: AllocStack(0x20)
    //     0x4e2e34: sub             SP, SP, #0x20
    // 0x4e2e38: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */, {dynamic zeroOutIdleTime = false /* r1 */})
    //     0x4e2e38: mov             x0, x1
    //     0x4e2e3c: stur            x1, [fp, #-8]
    //     0x4e2e40: ldur            w1, [x4, #0x13]
    //     0x4e2e44: ldur            w2, [x4, #0x1f]
    //     0x4e2e48: add             x2, x2, HEAP, lsl #32
    //     0x4e2e4c: add             x16, PP, #0x14, lsl #12  ; [pp+0x143e8] "zeroOutIdleTime"
    //     0x4e2e50: ldr             x16, [x16, #0x3e8]
    //     0x4e2e54: cmp             w2, w16
    //     0x4e2e58: b.ne            #0x4e2e74
    //     0x4e2e5c: ldur            w2, [x4, #0x23]
    //     0x4e2e60: add             x2, x2, HEAP, lsl #32
    //     0x4e2e64: sub             w3, w1, w2
    //     0x4e2e68: add             x1, fp, w3, sxtw #2
    //     0x4e2e6c: ldr             x1, [x1, #8]
    //     0x4e2e70: b               #0x4e2e78
    //     0x4e2e74: add             x1, NULL, #0x30  ; false
    // 0x4e2e78: CheckStackOverflow
    //     0x4e2e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e2e7c: cmp             SP, x16
    //     0x4e2e80: b.ls            #0x4e2f00
    // 0x4e2e84: str             x1, [SP]
    // 0x4e2e88: mov             x1, x0
    // 0x4e2e8c: r4 = const [0, 0x2, 0x1, 0x1, zeroOutIdleTime, 0x1, null]
    //     0x4e2e8c: add             x4, PP, #0xe, lsl #12  ; [pp+0xeb78] List(7) [0, 0x2, 0x1, 0x1, "zeroOutIdleTime", 0x1, Null]
    //     0x4e2e90: ldr             x4, [x4, #0xb78]
    // 0x4e2e94: r0 = toMapFile()
    //     0x4e2e94: bl              #0x4e365c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::toMapFile
    // 0x4e2e98: r1 = Null
    //     0x4e2e98: mov             x1, NULL
    // 0x4e2e9c: r2 = 4
    //     0x4e2e9c: movz            x2, #0x4
    // 0x4e2ea0: stur            x0, [fp, #-0x10]
    // 0x4e2ea4: r0 = AllocateArray()
    //     0x4e2ea4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e2ea8: mov             x2, x0
    // 0x4e2eac: StoreField: r2->field_f = rZR
    //     0x4e2eac: stur            wzr, [x2, #0xf]
    // 0x4e2eb0: ldur            x0, [fp, #-8]
    // 0x4e2eb4: LoadField: r3 = r0->field_8b
    //     0x4e2eb4: ldur            x3, [x0, #0x8b]
    // 0x4e2eb8: r0 = BoxInt64Instr(r3)
    //     0x4e2eb8: sbfiz           x0, x3, #1, #0x1f
    //     0x4e2ebc: cmp             x3, x0, asr #1
    //     0x4e2ec0: b.eq            #0x4e2ecc
    //     0x4e2ec4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e2ec8: stur            x3, [x0, #7]
    // 0x4e2ecc: StoreField: r2->field_13 = r0
    //     0x4e2ecc: stur            w0, [x2, #0x13]
    // 0x4e2ed0: r16 = <int, dynamic>
    //     0x4e2ed0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x4e2ed4: ldr             x16, [x16, #0x4f0]
    // 0x4e2ed8: stp             x2, x16, [SP]
    // 0x4e2edc: r0 = Map._fromLiteral()
    //     0x4e2edc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e2ee0: ldur            x1, [fp, #-0x10]
    // 0x4e2ee4: mov             x3, x0
    // 0x4e2ee8: r2 = 38
    //     0x4e2ee8: movz            x2, #0x26
    // 0x4e2eec: r0 = []=()
    //     0x4e2eec: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4e2ef0: ldur            x0, [fp, #-0x10]
    // 0x4e2ef4: LeaveFrame
    //     0x4e2ef4: mov             SP, fp
    //     0x4e2ef8: ldp             fp, lr, [SP], #0x10
    // 0x4e2efc: ret
    //     0x4e2efc: ret             
    // 0x4e2f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e2f00: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e2f04: b               #0x4e2e84
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e5d8c, size: 0x78
    // 0x4e5d8c: EnterFrame
    //     0x4e5d8c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e5d90: mov             fp, SP
    // 0x4e5d94: AllocStack(0x18)
    //     0x4e5d94: sub             SP, SP, #0x18
    // 0x4e5d98: SetupParameters(Chapter10GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e5d98: stur            x1, [fp, #-8]
    // 0x4e5d9c: r1 = 1
    //     0x4e5d9c: movz            x1, #0x1
    // 0x4e5da0: r0 = AllocateContext()
    //     0x4e5da0: bl              #0x82637c  ; AllocateContextStub
    // 0x4e5da4: mov             x3, x0
    // 0x4e5da8: ldur            x0, [fp, #-8]
    // 0x4e5dac: stur            x3, [fp, #-0x10]
    // 0x4e5db0: StoreField: r3->field_f = r0
    //     0x4e5db0: stur            w0, [x3, #0xf]
    // 0x4e5db4: mov             x2, x3
    // 0x4e5db8: r1 = Function '<anonymous closure>':.
    //     0x4e5db8: add             x1, PP, #0x25, lsl #12  ; [pp+0x25798] AnonymousClosure: (0x4e68c0), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::makeHeader (0x4e5d8c)
    //     0x4e5dbc: ldr             x1, [x1, #0x798]
    // 0x4e5dc0: r0 = AllocateClosure()
    //     0x4e5dc0: bl              #0x826750  ; AllocateClosureStub
    // 0x4e5dc4: stur            x0, [fp, #-8]
    // 0x4e5dc8: r0 = MainStatDisplay()
    //     0x4e5dc8: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e5dcc: mov             x3, x0
    // 0x4e5dd0: ldur            x0, [fp, #-8]
    // 0x4e5dd4: stur            x3, [fp, #-0x18]
    // 0x4e5dd8: StoreField: r3->field_b = r0
    //     0x4e5dd8: stur            w0, [x3, #0xb]
    // 0x4e5ddc: ldur            x2, [fp, #-0x10]
    // 0x4e5de0: r1 = Function '<anonymous closure>':.
    //     0x4e5de0: add             x1, PP, #0x25, lsl #12  ; [pp+0x257a0] AnonymousClosure: (0x4e5e30), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::makeHeader (0x4e5d8c)
    //     0x4e5de4: ldr             x1, [x1, #0x7a0]
    // 0x4e5de8: r0 = AllocateClosure()
    //     0x4e5de8: bl              #0x826750  ; AllocateClosureStub
    // 0x4e5dec: mov             x1, x0
    // 0x4e5df0: ldur            x0, [fp, #-0x18]
    // 0x4e5df4: StoreField: r0->field_f = r1
    //     0x4e5df4: stur            w1, [x0, #0xf]
    // 0x4e5df8: LeaveFrame
    //     0x4e5df8: mov             SP, fp
    //     0x4e5dfc: ldp             fp, lr, [SP], #0x10
    // 0x4e5e00: ret
    //     0x4e5e00: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e5e30, size: 0x100
    // 0x4e5e30: EnterFrame
    //     0x4e5e30: stp             fp, lr, [SP, #-0x10]!
    //     0x4e5e34: mov             fp, SP
    // 0x4e5e38: AllocStack(0x18)
    //     0x4e5e38: sub             SP, SP, #0x18
    // 0x4e5e3c: SetupParameters([dynamic _ /* r0 */])
    //     0x4e5e3c: ldr             x0, [fp, #0x10]
    //     0x4e5e40: ldur            w1, [x0, #0x17]
    //     0x4e5e44: add             x1, x1, HEAP, lsl #32
    // 0x4e5e48: CheckStackOverflow
    //     0x4e5e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e5e4c: cmp             SP, x16
    //     0x4e5e50: b.ls            #0x4e5f28
    // 0x4e5e54: LoadField: r0 = r1->field_f
    //     0x4e5e54: ldur            w0, [x1, #0xf]
    // 0x4e5e58: DecompressPointer r0
    //     0x4e5e58: add             x0, x0, HEAP, lsl #32
    // 0x4e5e5c: LoadField: r3 = r0->field_57
    //     0x4e5e5c: ldur            w3, [x0, #0x57]
    // 0x4e5e60: DecompressPointer r3
    //     0x4e5e60: add             x3, x3, HEAP, lsl #32
    // 0x4e5e64: mov             x1, x3
    // 0x4e5e68: stur            x3, [fp, #-8]
    // 0x4e5e6c: r2 = Instance_Chapter10Stat
    //     0x4e5e6c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x4e5e70: ldr             x2, [x2, #0x798]
    // 0x4e5e74: r0 = _getValueOrData()
    //     0x4e5e74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e5e78: mov             x1, x0
    // 0x4e5e7c: ldur            x0, [fp, #-8]
    // 0x4e5e80: LoadField: r2 = r0->field_f
    //     0x4e5e80: ldur            w2, [x0, #0xf]
    // 0x4e5e84: DecompressPointer r2
    //     0x4e5e84: add             x2, x2, HEAP, lsl #32
    // 0x4e5e88: cmp             w2, w1
    // 0x4e5e8c: b.ne            #0x4e5e98
    // 0x4e5e90: r0 = Null
    //     0x4e5e90: mov             x0, NULL
    // 0x4e5e94: b               #0x4e5e9c
    // 0x4e5e98: mov             x0, x1
    // 0x4e5e9c: stur            x0, [fp, #-8]
    // 0x4e5ea0: cmp             w0, NULL
    // 0x4e5ea4: b.eq            #0x4e5f18
    // 0x4e5ea8: r1 = Null
    //     0x4e5ea8: mov             x1, NULL
    // 0x4e5eac: r2 = 6
    //     0x4e5eac: movz            x2, #0x6
    // 0x4e5eb0: r0 = AllocateArray()
    //     0x4e5eb0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e5eb4: stur            x0, [fp, #-0x10]
    // 0x4e5eb8: r16 = "("
    //     0x4e5eb8: ldr             x16, [PP, #0x2218]  ; [pp+0x2218] "("
    // 0x4e5ebc: StoreField: r0->field_f = r16
    //     0x4e5ebc: stur            w16, [x0, #0xf]
    // 0x4e5ec0: ldur            x1, [fp, #-8]
    // 0x4e5ec4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e5ec4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e5ec8: r0 = toStringConsistentDecimalPlaces()
    //     0x4e5ec8: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e5ecc: ldur            x1, [fp, #-0x10]
    // 0x4e5ed0: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e5ed0: add             x25, x1, #0x13
    //     0x4e5ed4: str             w0, [x25]
    //     0x4e5ed8: tbz             w0, #0, #0x4e5ef4
    //     0x4e5edc: ldurb           w16, [x1, #-1]
    //     0x4e5ee0: ldurb           w17, [x0, #-1]
    //     0x4e5ee4: and             x16, x17, x16, lsr #2
    //     0x4e5ee8: tst             x16, HEAP, lsr #32
    //     0x4e5eec: b.eq            #0x4e5ef4
    //     0x4e5ef0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e5ef4: ldur            x0, [fp, #-0x10]
    // 0x4e5ef8: r16 = "/s)"
    //     0x4e5ef8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a568] "/s)"
    //     0x4e5efc: ldr             x16, [x16, #0x568]
    // 0x4e5f00: ArrayStore: r0[0] = r16  ; List_4
    //     0x4e5f00: stur            w16, [x0, #0x17]
    // 0x4e5f04: str             x0, [SP]
    // 0x4e5f08: r0 = _interpolate()
    //     0x4e5f08: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e5f0c: LeaveFrame
    //     0x4e5f0c: mov             SP, fp
    //     0x4e5f10: ldp             fp, lr, [SP], #0x10
    // 0x4e5f14: ret
    //     0x4e5f14: ret             
    // 0x4e5f18: r0 = ""
    //     0x4e5f18: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x4e5f1c: LeaveFrame
    //     0x4e5f1c: mov             SP, fp
    //     0x4e5f20: ldp             fp, lr, [SP], #0x10
    // 0x4e5f24: ret
    //     0x4e5f24: ret             
    // 0x4e5f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e5f28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e5f2c: b               #0x4e5e54
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e68c0, size: 0xf4
    // 0x4e68c0: EnterFrame
    //     0x4e68c0: stp             fp, lr, [SP, #-0x10]!
    //     0x4e68c4: mov             fp, SP
    // 0x4e68c8: AllocStack(0x18)
    //     0x4e68c8: sub             SP, SP, #0x18
    // 0x4e68cc: SetupParameters([dynamic _ /* r0 */])
    //     0x4e68cc: ldr             x0, [fp, #0x10]
    //     0x4e68d0: ldur            w3, [x0, #0x17]
    //     0x4e68d4: add             x3, x3, HEAP, lsl #32
    //     0x4e68d8: stur            x3, [fp, #-8]
    // 0x4e68dc: CheckStackOverflow
    //     0x4e68dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e68e0: cmp             SP, x16
    //     0x4e68e4: b.ls            #0x4e69ac
    // 0x4e68e8: r1 = Null
    //     0x4e68e8: mov             x1, NULL
    // 0x4e68ec: r2 = 4
    //     0x4e68ec: movz            x2, #0x4
    // 0x4e68f0: r0 = AllocateArray()
    //     0x4e68f0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e68f4: stur            x0, [fp, #-0x10]
    // 0x4e68f8: r16 = "Utility: "
    //     0x4e68f8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257a8] "Utility: "
    //     0x4e68fc: ldr             x16, [x16, #0x7a8]
    // 0x4e6900: StoreField: r0->field_f = r16
    //     0x4e6900: stur            w16, [x0, #0xf]
    // 0x4e6904: ldur            x1, [fp, #-8]
    // 0x4e6908: LoadField: r2 = r1->field_f
    //     0x4e6908: ldur            w2, [x1, #0xf]
    // 0x4e690c: DecompressPointer r2
    //     0x4e690c: add             x2, x2, HEAP, lsl #32
    // 0x4e6910: LoadField: r3 = r2->field_37
    //     0x4e6910: ldur            w3, [x2, #0x37]
    // 0x4e6914: DecompressPointer r3
    //     0x4e6914: add             x3, x3, HEAP, lsl #32
    // 0x4e6918: mov             x1, x3
    // 0x4e691c: stur            x3, [fp, #-8]
    // 0x4e6920: r2 = Instance_Chapter10Stat
    //     0x4e6920: add             x2, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x4e6924: ldr             x2, [x2, #0x798]
    // 0x4e6928: r0 = _getValueOrData()
    //     0x4e6928: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e692c: mov             x1, x0
    // 0x4e6930: ldur            x0, [fp, #-8]
    // 0x4e6934: LoadField: r2 = r0->field_f
    //     0x4e6934: ldur            w2, [x0, #0xf]
    // 0x4e6938: DecompressPointer r2
    //     0x4e6938: add             x2, x2, HEAP, lsl #32
    // 0x4e693c: cmp             w2, w1
    // 0x4e6940: b.ne            #0x4e6948
    // 0x4e6944: r1 = Null
    //     0x4e6944: mov             x1, NULL
    // 0x4e6948: cmp             w1, NULL
    // 0x4e694c: b.ne            #0x4e6958
    // 0x4e6950: r0 = Null
    //     0x4e6950: mov             x0, NULL
    // 0x4e6954: b               #0x4e6960
    // 0x4e6958: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e6958: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e695c: r0 = toStringConsistentDecimalPlaces()
    //     0x4e695c: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e6960: cmp             w0, NULL
    // 0x4e6964: b.ne            #0x4e696c
    // 0x4e6968: r0 = 0
    //     0x4e6968: movz            x0, #0
    // 0x4e696c: ldur            x1, [fp, #-0x10]
    // 0x4e6970: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e6970: add             x25, x1, #0x13
    //     0x4e6974: str             w0, [x25]
    //     0x4e6978: tbz             w0, #0, #0x4e6994
    //     0x4e697c: ldurb           w16, [x1, #-1]
    //     0x4e6980: ldurb           w17, [x0, #-1]
    //     0x4e6984: and             x16, x17, x16, lsr #2
    //     0x4e6988: tst             x16, HEAP, lsr #32
    //     0x4e698c: b.eq            #0x4e6994
    //     0x4e6990: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6994: ldur            x16, [fp, #-0x10]
    // 0x4e6998: str             x16, [SP]
    // 0x4e699c: r0 = _interpolate()
    //     0x4e699c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e69a0: LeaveFrame
    //     0x4e69a0: mov             SP, fp
    //     0x4e69a4: ldp             fp, lr, [SP], #0x10
    // 0x4e69a8: ret
    //     0x4e69a8: ret             
    // 0x4e69ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e69ac: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e69b0: b               #0x4e68e8
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4f40c0, size: 0xc80
    // 0x4f40c0: EnterFrame
    //     0x4f40c0: stp             fp, lr, [SP, #-0x10]!
    //     0x4f40c4: mov             fp, SP
    // 0x4f40c8: AllocStack(0x50)
    //     0x4f40c8: sub             SP, SP, #0x50
    // 0x4f40cc: SetupParameters(Chapter10GameState this /* r1 => r1, fp-0x8 */)
    //     0x4f40cc: stur            x1, [fp, #-8]
    // 0x4f40d0: CheckStackOverflow
    //     0x4f40d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f40d4: cmp             SP, x16
    //     0x4f40d8: b.ls            #0x4f4d38
    // 0x4f40dc: r1 = 1
    //     0x4f40dc: movz            x1, #0x1
    // 0x4f40e0: r0 = AllocateContext()
    //     0x4f40e0: bl              #0x82637c  ; AllocateContextStub
    // 0x4f40e4: mov             x3, x0
    // 0x4f40e8: ldur            x0, [fp, #-8]
    // 0x4f40ec: stur            x3, [fp, #-0x10]
    // 0x4f40f0: StoreField: r3->field_f = r0
    //     0x4f40f0: stur            w0, [x3, #0xf]
    // 0x4f40f4: r1 = Null
    //     0x4f40f4: mov             x1, NULL
    // 0x4f40f8: r2 = 56
    //     0x4f40f8: movz            x2, #0x38
    // 0x4f40fc: r0 = AllocateArray()
    //     0x4f40fc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4100: r16 = 2
    //     0x4f4100: movz            x16, #0x2
    // 0x4f4104: StoreField: r0->field_f = r16
    //     0x4f4104: stur            w16, [x0, #0xf]
    // 0x4f4108: r16 = Instance_GeneratorInfo
    //     0x4f4108: add             x16, PP, #0x16, lsl #12  ; [pp+0x165d8] Obj!GeneratorInfo<Chapter10Stat>@82cad1
    //     0x4f410c: ldr             x16, [x16, #0x5d8]
    // 0x4f4110: StoreField: r0->field_13 = r16
    //     0x4f4110: stur            w16, [x0, #0x13]
    // 0x4f4114: r16 = 4
    //     0x4f4114: movz            x16, #0x4
    // 0x4f4118: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4118: stur            w16, [x0, #0x17]
    // 0x4f411c: r16 = Instance_GeneratorInfo
    //     0x4f411c: add             x16, PP, #0x16, lsl #12  ; [pp+0x165e0] Obj!GeneratorInfo<Chapter10Stat>@82ca91
    //     0x4f4120: ldr             x16, [x16, #0x5e0]
    // 0x4f4124: StoreField: r0->field_1b = r16
    //     0x4f4124: stur            w16, [x0, #0x1b]
    // 0x4f4128: r16 = 6
    //     0x4f4128: movz            x16, #0x6
    // 0x4f412c: StoreField: r0->field_1f = r16
    //     0x4f412c: stur            w16, [x0, #0x1f]
    // 0x4f4130: r16 = Instance_GeneratorInfo
    //     0x4f4130: add             x16, PP, #0x16, lsl #12  ; [pp+0x165e8] Obj!GeneratorInfo<Chapter10Stat>@82ca51
    //     0x4f4134: ldr             x16, [x16, #0x5e8]
    // 0x4f4138: StoreField: r0->field_23 = r16
    //     0x4f4138: stur            w16, [x0, #0x23]
    // 0x4f413c: r16 = 8
    //     0x4f413c: movz            x16, #0x8
    // 0x4f4140: StoreField: r0->field_27 = r16
    //     0x4f4140: stur            w16, [x0, #0x27]
    // 0x4f4144: r16 = Instance_GeneratorInfo
    //     0x4f4144: add             x16, PP, #0x16, lsl #12  ; [pp+0x165f0] Obj!GeneratorInfo<Chapter10Stat>@82ca11
    //     0x4f4148: ldr             x16, [x16, #0x5f0]
    // 0x4f414c: StoreField: r0->field_2b = r16
    //     0x4f414c: stur            w16, [x0, #0x2b]
    // 0x4f4150: r16 = 10
    //     0x4f4150: movz            x16, #0xa
    // 0x4f4154: StoreField: r0->field_2f = r16
    //     0x4f4154: stur            w16, [x0, #0x2f]
    // 0x4f4158: r16 = Instance_GeneratorInfo
    //     0x4f4158: add             x16, PP, #0x16, lsl #12  ; [pp+0x165f8] Obj!GeneratorInfo<Chapter10Stat>@82c9d1
    //     0x4f415c: ldr             x16, [x16, #0x5f8]
    // 0x4f4160: StoreField: r0->field_33 = r16
    //     0x4f4160: stur            w16, [x0, #0x33]
    // 0x4f4164: r16 = 12
    //     0x4f4164: movz            x16, #0xc
    // 0x4f4168: StoreField: r0->field_37 = r16
    //     0x4f4168: stur            w16, [x0, #0x37]
    // 0x4f416c: r16 = Instance_GeneratorInfo
    //     0x4f416c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16600] Obj!GeneratorInfo<Chapter10Stat>@82c991
    //     0x4f4170: ldr             x16, [x16, #0x600]
    // 0x4f4174: StoreField: r0->field_3b = r16
    //     0x4f4174: stur            w16, [x0, #0x3b]
    // 0x4f4178: r16 = 14
    //     0x4f4178: movz            x16, #0xe
    // 0x4f417c: StoreField: r0->field_3f = r16
    //     0x4f417c: stur            w16, [x0, #0x3f]
    // 0x4f4180: r16 = Instance_GeneratorInfo
    //     0x4f4180: add             x16, PP, #0x16, lsl #12  ; [pp+0x16608] Obj!GeneratorInfo<Chapter10Stat>@82c951
    //     0x4f4184: ldr             x16, [x16, #0x608]
    // 0x4f4188: StoreField: r0->field_43 = r16
    //     0x4f4188: stur            w16, [x0, #0x43]
    // 0x4f418c: r16 = 16
    //     0x4f418c: movz            x16, #0x10
    // 0x4f4190: StoreField: r0->field_47 = r16
    //     0x4f4190: stur            w16, [x0, #0x47]
    // 0x4f4194: r16 = Instance_GeneratorInfo
    //     0x4f4194: add             x16, PP, #0x16, lsl #12  ; [pp+0x16610] Obj!GeneratorInfo<Chapter10Stat>@82c911
    //     0x4f4198: ldr             x16, [x16, #0x610]
    // 0x4f419c: StoreField: r0->field_4b = r16
    //     0x4f419c: stur            w16, [x0, #0x4b]
    // 0x4f41a0: r16 = 200
    //     0x4f41a0: movz            x16, #0xc8
    // 0x4f41a4: StoreField: r0->field_4f = r16
    //     0x4f41a4: stur            w16, [x0, #0x4f]
    // 0x4f41a8: r16 = Instance_GeneratorInfo
    //     0x4f41a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16618] Obj!GeneratorInfo<Chapter10Stat>@82c8d1
    //     0x4f41ac: ldr             x16, [x16, #0x618]
    // 0x4f41b0: StoreField: r0->field_53 = r16
    //     0x4f41b0: stur            w16, [x0, #0x53]
    // 0x4f41b4: r16 = 202
    //     0x4f41b4: movz            x16, #0xca
    // 0x4f41b8: StoreField: r0->field_57 = r16
    //     0x4f41b8: stur            w16, [x0, #0x57]
    // 0x4f41bc: r16 = Instance_GeneratorInfo
    //     0x4f41bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16620] Obj!GeneratorInfo<Chapter10Stat>@82c891
    //     0x4f41c0: ldr             x16, [x16, #0x620]
    // 0x4f41c4: StoreField: r0->field_5b = r16
    //     0x4f41c4: stur            w16, [x0, #0x5b]
    // 0x4f41c8: r16 = 204
    //     0x4f41c8: movz            x16, #0xcc
    // 0x4f41cc: StoreField: r0->field_5f = r16
    //     0x4f41cc: stur            w16, [x0, #0x5f]
    // 0x4f41d0: r16 = Instance_GeneratorInfo
    //     0x4f41d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16628] Obj!GeneratorInfo<Chapter10Stat>@82c851
    //     0x4f41d4: ldr             x16, [x16, #0x628]
    // 0x4f41d8: StoreField: r0->field_63 = r16
    //     0x4f41d8: stur            w16, [x0, #0x63]
    // 0x4f41dc: r16 = 206
    //     0x4f41dc: movz            x16, #0xce
    // 0x4f41e0: StoreField: r0->field_67 = r16
    //     0x4f41e0: stur            w16, [x0, #0x67]
    // 0x4f41e4: r16 = Instance_GeneratorInfo
    //     0x4f41e4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16630] Obj!GeneratorInfo<Chapter10Stat>@82c811
    //     0x4f41e8: ldr             x16, [x16, #0x630]
    // 0x4f41ec: StoreField: r0->field_6b = r16
    //     0x4f41ec: stur            w16, [x0, #0x6b]
    // 0x4f41f0: r16 = 208
    //     0x4f41f0: movz            x16, #0xd0
    // 0x4f41f4: StoreField: r0->field_6f = r16
    //     0x4f41f4: stur            w16, [x0, #0x6f]
    // 0x4f41f8: r16 = Instance_GeneratorInfo
    //     0x4f41f8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16638] Obj!GeneratorInfo<Chapter10Stat>@82c7d1
    //     0x4f41fc: ldr             x16, [x16, #0x638]
    // 0x4f4200: StoreField: r0->field_73 = r16
    //     0x4f4200: stur            w16, [x0, #0x73]
    // 0x4f4204: r16 = 210
    //     0x4f4204: movz            x16, #0xd2
    // 0x4f4208: StoreField: r0->field_77 = r16
    //     0x4f4208: stur            w16, [x0, #0x77]
    // 0x4f420c: r16 = Instance_GeneratorInfo
    //     0x4f420c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16640] Obj!GeneratorInfo<Chapter10Stat>@82c791
    //     0x4f4210: ldr             x16, [x16, #0x640]
    // 0x4f4214: StoreField: r0->field_7b = r16
    //     0x4f4214: stur            w16, [x0, #0x7b]
    // 0x4f4218: r16 = <int, GeneratorInfo<Chapter10Stat>>
    //     0x4f4218: add             x16, PP, #0x16, lsl #12  ; [pp+0x16648] TypeArguments: <int, GeneratorInfo<Chapter10Stat>>
    //     0x4f421c: ldr             x16, [x16, #0x648]
    // 0x4f4220: stp             x0, x16, [SP]
    // 0x4f4224: r0 = Map._fromLiteral()
    //     0x4f4224: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4f4228: ldur            x3, [fp, #-8]
    // 0x4f422c: StoreField: r3->field_93 = r0
    //     0x4f422c: stur            w0, [x3, #0x93]
    //     0x4f4230: ldurb           w16, [x3, #-1]
    //     0x4f4234: ldurb           w17, [x0, #-1]
    //     0x4f4238: and             x16, x17, x16, lsr #2
    //     0x4f423c: tst             x16, HEAP, lsr #32
    //     0x4f4240: b.eq            #0x4f4248
    //     0x4f4244: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4f4248: r1 = Null
    //     0x4f4248: mov             x1, NULL
    // 0x4f424c: r2 = 28
    //     0x4f424c: movz            x2, #0x1c
    // 0x4f4250: r0 = AllocateArray()
    //     0x4f4250: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4254: stur            x0, [fp, #-0x18]
    // 0x4f4258: r16 = 2
    //     0x4f4258: movz            x16, #0x2
    // 0x4f425c: StoreField: r0->field_f = r16
    //     0x4f425c: stur            w16, [x0, #0xf]
    // 0x4f4260: r1 = "Pipes"
    //     0x4f4260: add             x1, PP, #0x16, lsl #12  ; [pp+0x16650] "Pipes"
    //     0x4f4264: ldr             x1, [x1, #0x650]
    // 0x4f4268: r0 = autoString()
    //     0x4f4268: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f426c: r1 = Function '<anonymous closure>':.
    //     0x4f426c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16658] AnonymousClosure: (0x4f4ffc), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::ensureInitialized (0x4f40c0)
    //     0x4f4270: ldr             x1, [x1, #0x658]
    // 0x4f4274: r2 = Null
    //     0x4f4274: mov             x2, NULL
    // 0x4f4278: stur            x0, [fp, #-0x20]
    // 0x4f427c: r0 = AllocateClosure()
    //     0x4f427c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4280: r1 = <String>
    //     0x4f4280: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4284: stur            x0, [fp, #-0x28]
    // 0x4f4288: r0 = Generator()
    //     0x4f4288: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f428c: ldur            x2, [fp, #-0x28]
    // 0x4f4290: r3 = Null
    //     0x4f4290: mov             x3, NULL
    // 0x4f4294: stur            x0, [fp, #-0x28]
    // 0x4f4298: r0 = AllocateRecord2()
    //     0x4f4298: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f429c: mov             x1, x0
    // 0x4f42a0: ldur            x0, [fp, #-0x28]
    // 0x4f42a4: StoreField: r0->field_f = r1
    //     0x4f42a4: stur            w1, [x0, #0xf]
    // 0x4f42a8: r1 = Null
    //     0x4f42a8: mov             x1, NULL
    // 0x4f42ac: r2 = 12
    //     0x4f42ac: movz            x2, #0xc
    // 0x4f42b0: r0 = AllocateArray()
    //     0x4f42b0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f42b4: stur            x0, [fp, #-0x30]
    // 0x4f42b8: r16 = Instance_Tuple2
    //     0x4f42b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16660] Obj!Tuple2<Chapter10Stat, CustomNum>@8228f1
    //     0x4f42bc: ldr             x16, [x16, #0x660]
    // 0x4f42c0: StoreField: r0->field_f = r16
    //     0x4f42c0: stur            w16, [x0, #0xf]
    // 0x4f42c4: r16 = Instance_Tuple2
    //     0x4f42c4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16668] Obj!Tuple2<Chapter10Stat, CustomNum>@8228d1
    //     0x4f42c8: ldr             x16, [x16, #0x668]
    // 0x4f42cc: StoreField: r0->field_13 = r16
    //     0x4f42cc: stur            w16, [x0, #0x13]
    // 0x4f42d0: r16 = Instance_Tuple2
    //     0x4f42d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16670] Obj!Tuple2<Chapter10Stat, CustomNum>@8228b1
    //     0x4f42d4: ldr             x16, [x16, #0x670]
    // 0x4f42d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f42d8: stur            w16, [x0, #0x17]
    // 0x4f42dc: r16 = Instance_Tuple2
    //     0x4f42dc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16678] Obj!Tuple2<Chapter10Stat, CustomNum>@822891
    //     0x4f42e0: ldr             x16, [x16, #0x678]
    // 0x4f42e4: StoreField: r0->field_1b = r16
    //     0x4f42e4: stur            w16, [x0, #0x1b]
    // 0x4f42e8: r16 = Instance_Tuple2
    //     0x4f42e8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16680] Obj!Tuple2<Chapter10Stat, CustomNum>@822871
    //     0x4f42ec: ldr             x16, [x16, #0x680]
    // 0x4f42f0: StoreField: r0->field_1f = r16
    //     0x4f42f0: stur            w16, [x0, #0x1f]
    // 0x4f42f4: r16 = Instance_Tuple2
    //     0x4f42f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16688] Obj!Tuple2<Chapter10Stat, CustomNum>@822851
    //     0x4f42f8: ldr             x16, [x16, #0x688]
    // 0x4f42fc: StoreField: r0->field_23 = r16
    //     0x4f42fc: stur            w16, [x0, #0x23]
    // 0x4f4300: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4300: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4304: ldr             x1, [x1, #0x690]
    // 0x4f4308: r0 = AllocateGrowableArray()
    //     0x4f4308: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f430c: mov             x2, x0
    // 0x4f4310: ldur            x0, [fp, #-0x30]
    // 0x4f4314: stur            x2, [fp, #-0x38]
    // 0x4f4318: StoreField: r2->field_f = r0
    //     0x4f4318: stur            w0, [x2, #0xf]
    // 0x4f431c: r0 = 12
    //     0x4f431c: movz            x0, #0xc
    // 0x4f4320: StoreField: r2->field_b = r0
    //     0x4f4320: stur            w0, [x2, #0xb]
    // 0x4f4324: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4324: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4328: ldr             x1, [x1, #0x690]
    // 0x4f432c: r0 = Generator()
    //     0x4f432c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4330: mov             x2, x0
    // 0x4f4334: ldur            x0, [fp, #-0x38]
    // 0x4f4338: stur            x2, [fp, #-0x30]
    // 0x4f433c: StoreField: r2->field_b = r0
    //     0x4f433c: stur            w0, [x2, #0xb]
    // 0x4f4340: r1 = <Chapter10Stat>
    //     0x4f4340: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f4344: ldr             x1, [x1, #0xe80]
    // 0x4f4348: r0 = UpgradeData()
    //     0x4f4348: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f434c: mov             x3, x0
    // 0x4f4350: ldur            x0, [fp, #-0x20]
    // 0x4f4354: stur            x3, [fp, #-0x38]
    // 0x4f4358: StoreField: r3->field_b = r0
    //     0x4f4358: stur            w0, [x3, #0xb]
    // 0x4f435c: ldur            x0, [fp, #-0x28]
    // 0x4f4360: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f4360: stur            w0, [x3, #0x17]
    // 0x4f4364: r0 = Instance_IconData
    //     0x4f4364: add             x0, PP, #0x16, lsl #12  ; [pp+0x16088] Obj!IconData@82f3d1
    //     0x4f4368: ldr             x0, [x0, #0x88]
    // 0x4f436c: StoreField: r3->field_13 = r0
    //     0x4f436c: stur            w0, [x3, #0x13]
    // 0x4f4370: ldur            x0, [fp, #-0x30]
    // 0x4f4374: StoreField: r3->field_f = r0
    //     0x4f4374: stur            w0, [x3, #0xf]
    // 0x4f4378: ldur            x2, [fp, #-0x10]
    // 0x4f437c: r1 = Function '<anonymous closure>':.
    //     0x4f437c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16698] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f4380: ldr             x1, [x1, #0x698]
    // 0x4f4384: r0 = AllocateClosure()
    //     0x4f4384: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4388: mov             x1, x0
    // 0x4f438c: ldur            x0, [fp, #-0x38]
    // 0x4f4390: StoreField: r0->field_23 = r1
    //     0x4f4390: stur            w1, [x0, #0x23]
    // 0x4f4394: ldur            x1, [fp, #-0x18]
    // 0x4f4398: ArrayStore: r1[1] = r0  ; List_4
    //     0x4f4398: add             x25, x1, #0x13
    //     0x4f439c: str             w0, [x25]
    //     0x4f43a0: tbz             w0, #0, #0x4f43bc
    //     0x4f43a4: ldurb           w16, [x1, #-1]
    //     0x4f43a8: ldurb           w17, [x0, #-1]
    //     0x4f43ac: and             x16, x17, x16, lsr #2
    //     0x4f43b0: tst             x16, HEAP, lsr #32
    //     0x4f43b4: b.eq            #0x4f43bc
    //     0x4f43b8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f43bc: ldur            x0, [fp, #-0x18]
    // 0x4f43c0: r16 = 4
    //     0x4f43c0: movz            x16, #0x4
    // 0x4f43c4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f43c4: stur            w16, [x0, #0x17]
    // 0x4f43c8: r1 = "Refactoring"
    //     0x4f43c8: add             x1, PP, #0x16, lsl #12  ; [pp+0x166a0] "Refactoring"
    //     0x4f43cc: ldr             x1, [x1, #0x6a0]
    // 0x4f43d0: r0 = autoString()
    //     0x4f43d0: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f43d4: r1 = Null
    //     0x4f43d4: mov             x1, NULL
    // 0x4f43d8: r2 = 14
    //     0x4f43d8: movz            x2, #0xe
    // 0x4f43dc: stur            x0, [fp, #-0x20]
    // 0x4f43e0: r0 = AllocateArray()
    //     0x4f43e0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f43e4: stur            x0, [fp, #-0x28]
    // 0x4f43e8: r16 = "Allows repeating kernel upgrades to gain efficiency. Each efficiency increases speed by 100%."
    //     0x4f43e8: add             x16, PP, #0x16, lsl #12  ; [pp+0x166a8] "Allows repeating kernel upgrades to gain efficiency. Each efficiency increases speed by 100%."
    //     0x4f43ec: ldr             x16, [x16, #0x6a8]
    // 0x4f43f0: StoreField: r0->field_f = r16
    //     0x4f43f0: stur            w16, [x0, #0xf]
    // 0x4f43f4: r16 = "Allows gaining more than 1 efficiency from each refactor."
    //     0x4f43f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x166b0] "Allows gaining more than 1 efficiency from each refactor."
    //     0x4f43f8: ldr             x16, [x16, #0x6b0]
    // 0x4f43fc: StoreField: r0->field_13 = r16
    //     0x4f43fc: stur            w16, [x0, #0x13]
    // 0x4f4400: r16 = "Increases the efficiency gained from refactor."
    //     0x4f4400: add             x16, PP, #0x16, lsl #12  ; [pp+0x166b8] "Increases the efficiency gained from refactor."
    //     0x4f4404: ldr             x16, [x16, #0x6b8]
    // 0x4f4408: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4408: stur            w16, [x0, #0x17]
    // 0x4f440c: r16 = "Increases the efficiency gained from refactor."
    //     0x4f440c: add             x16, PP, #0x16, lsl #12  ; [pp+0x166b8] "Increases the efficiency gained from refactor."
    //     0x4f4410: ldr             x16, [x16, #0x6b8]
    // 0x4f4414: StoreField: r0->field_1b = r16
    //     0x4f4414: stur            w16, [x0, #0x1b]
    // 0x4f4418: r16 = "Increases the efficiency gained from refactor."
    //     0x4f4418: add             x16, PP, #0x16, lsl #12  ; [pp+0x166b8] "Increases the efficiency gained from refactor."
    //     0x4f441c: ldr             x16, [x16, #0x6b8]
    // 0x4f4420: StoreField: r0->field_1f = r16
    //     0x4f4420: stur            w16, [x0, #0x1f]
    // 0x4f4424: r16 = "Increases the efficiency gained from refactor."
    //     0x4f4424: add             x16, PP, #0x16, lsl #12  ; [pp+0x166b8] "Increases the efficiency gained from refactor."
    //     0x4f4428: ldr             x16, [x16, #0x6b8]
    // 0x4f442c: StoreField: r0->field_23 = r16
    //     0x4f442c: stur            w16, [x0, #0x23]
    // 0x4f4430: r16 = "Increases the efficiency gained from refactor."
    //     0x4f4430: add             x16, PP, #0x16, lsl #12  ; [pp+0x166b8] "Increases the efficiency gained from refactor."
    //     0x4f4434: ldr             x16, [x16, #0x6b8]
    // 0x4f4438: StoreField: r0->field_27 = r16
    //     0x4f4438: stur            w16, [x0, #0x27]
    // 0x4f443c: r1 = <String>
    //     0x4f443c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4440: r0 = AllocateGrowableArray()
    //     0x4f4440: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f4444: mov             x2, x0
    // 0x4f4448: ldur            x0, [fp, #-0x28]
    // 0x4f444c: stur            x2, [fp, #-0x30]
    // 0x4f4450: StoreField: r2->field_f = r0
    //     0x4f4450: stur            w0, [x2, #0xf]
    // 0x4f4454: r0 = 14
    //     0x4f4454: movz            x0, #0xe
    // 0x4f4458: StoreField: r2->field_b = r0
    //     0x4f4458: stur            w0, [x2, #0xb]
    // 0x4f445c: r1 = <String>
    //     0x4f445c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4460: r0 = Generator()
    //     0x4f4460: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4464: mov             x3, x0
    // 0x4f4468: ldur            x0, [fp, #-0x30]
    // 0x4f446c: stur            x3, [fp, #-0x28]
    // 0x4f4470: StoreField: r3->field_b = r0
    //     0x4f4470: stur            w0, [x3, #0xb]
    // 0x4f4474: r1 = Null
    //     0x4f4474: mov             x1, NULL
    // 0x4f4478: r2 = 14
    //     0x4f4478: movz            x2, #0xe
    // 0x4f447c: r0 = AllocateArray()
    //     0x4f447c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4480: stur            x0, [fp, #-0x30]
    // 0x4f4484: r16 = Instance_Tuple2
    //     0x4f4484: add             x16, PP, #0x16, lsl #12  ; [pp+0x166c0] Obj!Tuple2<Chapter10Stat, CustomNum>@822831
    //     0x4f4488: ldr             x16, [x16, #0x6c0]
    // 0x4f448c: StoreField: r0->field_f = r16
    //     0x4f448c: stur            w16, [x0, #0xf]
    // 0x4f4490: r16 = Instance_Tuple2
    //     0x4f4490: add             x16, PP, #0x16, lsl #12  ; [pp+0x166c8] Obj!Tuple2<Chapter10Stat, CustomNum>@822811
    //     0x4f4494: ldr             x16, [x16, #0x6c8]
    // 0x4f4498: StoreField: r0->field_13 = r16
    //     0x4f4498: stur            w16, [x0, #0x13]
    // 0x4f449c: r16 = Instance_Tuple2
    //     0x4f449c: add             x16, PP, #0x16, lsl #12  ; [pp+0x166d0] Obj!Tuple2<Chapter10Stat, CustomNum>@8227f1
    //     0x4f44a0: ldr             x16, [x16, #0x6d0]
    // 0x4f44a4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f44a4: stur            w16, [x0, #0x17]
    // 0x4f44a8: r16 = Instance_Tuple2
    //     0x4f44a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x166d8] Obj!Tuple2<Chapter10Stat, CustomNum>@8227d1
    //     0x4f44ac: ldr             x16, [x16, #0x6d8]
    // 0x4f44b0: StoreField: r0->field_1b = r16
    //     0x4f44b0: stur            w16, [x0, #0x1b]
    // 0x4f44b4: r16 = Instance_Tuple2
    //     0x4f44b4: add             x16, PP, #0x16, lsl #12  ; [pp+0x166e0] Obj!Tuple2<Chapter10Stat, CustomNum>@8227b1
    //     0x4f44b8: ldr             x16, [x16, #0x6e0]
    // 0x4f44bc: StoreField: r0->field_1f = r16
    //     0x4f44bc: stur            w16, [x0, #0x1f]
    // 0x4f44c0: r16 = Instance_Tuple2
    //     0x4f44c0: add             x16, PP, #0x16, lsl #12  ; [pp+0x166e8] Obj!Tuple2<Chapter10Stat, CustomNum>@822791
    //     0x4f44c4: ldr             x16, [x16, #0x6e8]
    // 0x4f44c8: StoreField: r0->field_23 = r16
    //     0x4f44c8: stur            w16, [x0, #0x23]
    // 0x4f44cc: r16 = Instance_Tuple2
    //     0x4f44cc: add             x16, PP, #0x16, lsl #12  ; [pp+0x166f0] Obj!Tuple2<Chapter10Stat, CustomNum>@822771
    //     0x4f44d0: ldr             x16, [x16, #0x6f0]
    // 0x4f44d4: StoreField: r0->field_27 = r16
    //     0x4f44d4: stur            w16, [x0, #0x27]
    // 0x4f44d8: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f44d8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f44dc: ldr             x1, [x1, #0x690]
    // 0x4f44e0: r0 = AllocateGrowableArray()
    //     0x4f44e0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f44e4: mov             x2, x0
    // 0x4f44e8: ldur            x0, [fp, #-0x30]
    // 0x4f44ec: stur            x2, [fp, #-0x38]
    // 0x4f44f0: StoreField: r2->field_f = r0
    //     0x4f44f0: stur            w0, [x2, #0xf]
    // 0x4f44f4: r0 = 14
    //     0x4f44f4: movz            x0, #0xe
    // 0x4f44f8: StoreField: r2->field_b = r0
    //     0x4f44f8: stur            w0, [x2, #0xb]
    // 0x4f44fc: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f44fc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4500: ldr             x1, [x1, #0x690]
    // 0x4f4504: r0 = Generator()
    //     0x4f4504: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4508: mov             x1, x0
    // 0x4f450c: ldur            x0, [fp, #-0x38]
    // 0x4f4510: stur            x1, [fp, #-0x30]
    // 0x4f4514: StoreField: r1->field_b = r0
    //     0x4f4514: stur            w0, [x1, #0xb]
    // 0x4f4518: r0 = LoadStaticField(0x1040)
    //     0x4f4518: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4f451c: ldr             x0, [x0, #0x2080]
    // 0x4f4520: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4f4524: cmp             w0, w16
    // 0x4f4528: b.ne            #0x4f4538
    // 0x4f452c: r2 = fragments
    //     0x4f452c: add             x2, PP, #0x10, lsl #12  ; [pp+0x100b8] Field <::.fragments>: static late (offset: 0x1040)
    //     0x4f4530: ldr             x2, [x2, #0xb8]
    // 0x4f4534: r0 = InitLateStaticField()
    //     0x4f4534: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x4f4538: r1 = <Chapter10Stat>
    //     0x4f4538: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f453c: ldr             x1, [x1, #0xe80]
    // 0x4f4540: stur            x0, [fp, #-0x38]
    // 0x4f4544: r0 = UpgradeData()
    //     0x4f4544: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f4548: mov             x3, x0
    // 0x4f454c: ldur            x0, [fp, #-0x20]
    // 0x4f4550: stur            x3, [fp, #-0x40]
    // 0x4f4554: StoreField: r3->field_b = r0
    //     0x4f4554: stur            w0, [x3, #0xb]
    // 0x4f4558: ldur            x0, [fp, #-0x28]
    // 0x4f455c: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f455c: stur            w0, [x3, #0x17]
    // 0x4f4560: r0 = Instance_IconData
    //     0x4f4560: add             x0, PP, #0x15, lsl #12  ; [pp+0x153f0] Obj!IconData@82f3b1
    //     0x4f4564: ldr             x0, [x0, #0x3f0]
    // 0x4f4568: StoreField: r3->field_13 = r0
    //     0x4f4568: stur            w0, [x3, #0x13]
    // 0x4f456c: ldur            x0, [fp, #-0x30]
    // 0x4f4570: StoreField: r3->field_f = r0
    //     0x4f4570: stur            w0, [x3, #0xf]
    // 0x4f4574: ldur            x2, [fp, #-0x38]
    // 0x4f4578: r1 = Function 'notifyAll':.
    //     0x4f4578: add             x1, PP, #0x16, lsl #12  ; [pp+0x166f8] AnonymousClosure: (0x371f58), in [package:state_groups/src/sync_state.dart] StateGroup::notifyAll (0x371e0c)
    //     0x4f457c: ldr             x1, [x1, #0x6f8]
    // 0x4f4580: r0 = AllocateClosure()
    //     0x4f4580: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4584: mov             x1, x0
    // 0x4f4588: ldur            x0, [fp, #-0x40]
    // 0x4f458c: StoreField: r0->field_1b = r1
    //     0x4f458c: stur            w1, [x0, #0x1b]
    // 0x4f4590: ldur            x2, [fp, #-0x10]
    // 0x4f4594: r1 = Function '<anonymous closure>':.
    //     0x4f4594: add             x1, PP, #0x16, lsl #12  ; [pp+0x16700] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f4598: ldr             x1, [x1, #0x700]
    // 0x4f459c: r0 = AllocateClosure()
    //     0x4f459c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f45a0: mov             x1, x0
    // 0x4f45a4: ldur            x0, [fp, #-0x40]
    // 0x4f45a8: StoreField: r0->field_23 = r1
    //     0x4f45a8: stur            w1, [x0, #0x23]
    // 0x4f45ac: ldur            x1, [fp, #-0x18]
    // 0x4f45b0: ArrayStore: r1[3] = r0  ; List_4
    //     0x4f45b0: add             x25, x1, #0x1b
    //     0x4f45b4: str             w0, [x25]
    //     0x4f45b8: tbz             w0, #0, #0x4f45d4
    //     0x4f45bc: ldurb           w16, [x1, #-1]
    //     0x4f45c0: ldurb           w17, [x0, #-1]
    //     0x4f45c4: and             x16, x17, x16, lsr #2
    //     0x4f45c8: tst             x16, HEAP, lsr #32
    //     0x4f45cc: b.eq            #0x4f45d4
    //     0x4f45d0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f45d4: ldur            x0, [fp, #-0x18]
    // 0x4f45d8: r16 = 6
    //     0x4f45d8: movz            x16, #0x6
    // 0x4f45dc: StoreField: r0->field_1f = r16
    //     0x4f45dc: stur            w16, [x0, #0x1f]
    // 0x4f45e0: r1 = "Kernel Modules"
    //     0x4f45e0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16708] "Kernel Modules"
    //     0x4f45e4: ldr             x1, [x1, #0x708]
    // 0x4f45e8: r0 = autoString()
    //     0x4f45e8: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f45ec: r1 = Function '<anonymous closure>':.
    //     0x4f45ec: add             x1, PP, #0x16, lsl #12  ; [pp+0x16710] AnonymousClosure: (0x4f4ff0), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::ensureInitialized (0x4f40c0)
    //     0x4f45f0: ldr             x1, [x1, #0x710]
    // 0x4f45f4: r2 = Null
    //     0x4f45f4: mov             x2, NULL
    // 0x4f45f8: stur            x0, [fp, #-0x20]
    // 0x4f45fc: r0 = AllocateClosure()
    //     0x4f45fc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4600: r1 = <String>
    //     0x4f4600: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4604: stur            x0, [fp, #-0x28]
    // 0x4f4608: r0 = Generator()
    //     0x4f4608: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f460c: ldur            x2, [fp, #-0x28]
    // 0x4f4610: r3 = Null
    //     0x4f4610: mov             x3, NULL
    // 0x4f4614: stur            x0, [fp, #-0x28]
    // 0x4f4618: r0 = AllocateRecord2()
    //     0x4f4618: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f461c: mov             x1, x0
    // 0x4f4620: ldur            x0, [fp, #-0x28]
    // 0x4f4624: StoreField: r0->field_f = r1
    //     0x4f4624: stur            w1, [x0, #0xf]
    // 0x4f4628: r1 = Null
    //     0x4f4628: mov             x1, NULL
    // 0x4f462c: r2 = 3.200000
    //     0x4f462c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16718] 3.2
    //     0x4f4630: ldr             x2, [x2, #0x718]
    // 0x4f4634: r0 = CustomNum()
    //     0x4f4634: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4f4638: r1 = <Chapter10Stat, CustomNum>
    //     0x4f4638: add             x1, PP, #0x16, lsl #12  ; [pp+0x16720] TypeArguments: <Chapter10Stat, CustomNum>
    //     0x4f463c: ldr             x1, [x1, #0x720]
    // 0x4f4640: stur            x0, [fp, #-0x30]
    // 0x4f4644: r0 = Tuple2()
    //     0x4f4644: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4f4648: mov             x3, x0
    // 0x4f464c: r0 = Instance_Chapter10Stat
    //     0x4f464c: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x4f4650: ldr             x0, [x0, #0x7d8]
    // 0x4f4654: stur            x3, [fp, #-0x38]
    // 0x4f4658: StoreField: r3->field_b = r0
    //     0x4f4658: stur            w0, [x3, #0xb]
    // 0x4f465c: ldur            x0, [fp, #-0x30]
    // 0x4f4660: StoreField: r3->field_f = r0
    //     0x4f4660: stur            w0, [x3, #0xf]
    // 0x4f4664: r1 = Null
    //     0x4f4664: mov             x1, NULL
    // 0x4f4668: r2 = 2
    //     0x4f4668: movz            x2, #0x2
    // 0x4f466c: r0 = AllocateArray()
    //     0x4f466c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4670: mov             x2, x0
    // 0x4f4674: ldur            x0, [fp, #-0x38]
    // 0x4f4678: stur            x2, [fp, #-0x30]
    // 0x4f467c: StoreField: r2->field_f = r0
    //     0x4f467c: stur            w0, [x2, #0xf]
    // 0x4f4680: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4680: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4684: ldr             x1, [x1, #0x690]
    // 0x4f4688: r0 = AllocateGrowableArray()
    //     0x4f4688: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f468c: mov             x2, x0
    // 0x4f4690: ldur            x0, [fp, #-0x30]
    // 0x4f4694: stur            x2, [fp, #-0x38]
    // 0x4f4698: StoreField: r2->field_f = r0
    //     0x4f4698: stur            w0, [x2, #0xf]
    // 0x4f469c: r0 = 2
    //     0x4f469c: movz            x0, #0x2
    // 0x4f46a0: StoreField: r2->field_b = r0
    //     0x4f46a0: stur            w0, [x2, #0xb]
    // 0x4f46a4: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f46a4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f46a8: ldr             x1, [x1, #0x690]
    // 0x4f46ac: r0 = Generator()
    //     0x4f46ac: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f46b0: mov             x2, x0
    // 0x4f46b4: ldur            x0, [fp, #-0x38]
    // 0x4f46b8: stur            x2, [fp, #-0x30]
    // 0x4f46bc: StoreField: r2->field_b = r0
    //     0x4f46bc: stur            w0, [x2, #0xb]
    // 0x4f46c0: r1 = <Chapter10Stat>
    //     0x4f46c0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f46c4: ldr             x1, [x1, #0xe80]
    // 0x4f46c8: r0 = UpgradeData()
    //     0x4f46c8: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f46cc: mov             x3, x0
    // 0x4f46d0: ldur            x0, [fp, #-0x20]
    // 0x4f46d4: stur            x3, [fp, #-0x38]
    // 0x4f46d8: StoreField: r3->field_b = r0
    //     0x4f46d8: stur            w0, [x3, #0xb]
    // 0x4f46dc: ldur            x0, [fp, #-0x28]
    // 0x4f46e0: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f46e0: stur            w0, [x3, #0x17]
    // 0x4f46e4: r0 = Instance_IconData
    //     0x4f46e4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16728] Obj!IconData@82f391
    //     0x4f46e8: ldr             x0, [x0, #0x728]
    // 0x4f46ec: StoreField: r3->field_13 = r0
    //     0x4f46ec: stur            w0, [x3, #0x13]
    // 0x4f46f0: ldur            x0, [fp, #-0x30]
    // 0x4f46f4: StoreField: r3->field_f = r0
    //     0x4f46f4: stur            w0, [x3, #0xf]
    // 0x4f46f8: ldur            x2, [fp, #-0x10]
    // 0x4f46fc: r1 = Function '<anonymous closure>':.
    //     0x4f46fc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16730] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f4700: ldr             x1, [x1, #0x730]
    // 0x4f4704: r0 = AllocateClosure()
    //     0x4f4704: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4708: mov             x1, x0
    // 0x4f470c: ldur            x0, [fp, #-0x38]
    // 0x4f4710: StoreField: r0->field_23 = r1
    //     0x4f4710: stur            w1, [x0, #0x23]
    // 0x4f4714: ldur            x1, [fp, #-0x18]
    // 0x4f4718: ArrayStore: r1[5] = r0  ; List_4
    //     0x4f4718: add             x25, x1, #0x23
    //     0x4f471c: str             w0, [x25]
    //     0x4f4720: tbz             w0, #0, #0x4f473c
    //     0x4f4724: ldurb           w16, [x1, #-1]
    //     0x4f4728: ldurb           w17, [x0, #-1]
    //     0x4f472c: and             x16, x17, x16, lsr #2
    //     0x4f4730: tst             x16, HEAP, lsr #32
    //     0x4f4734: b.eq            #0x4f473c
    //     0x4f4738: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f473c: ldur            x0, [fp, #-0x18]
    // 0x4f4740: r16 = 20
    //     0x4f4740: movz            x16, #0x14
    // 0x4f4744: StoreField: r0->field_27 = r16
    //     0x4f4744: stur            w16, [x0, #0x27]
    // 0x4f4748: r1 = "More productivity"
    //     0x4f4748: add             x1, PP, #0x16, lsl #12  ; [pp+0x16738] "More productivity"
    //     0x4f474c: ldr             x1, [x1, #0x738]
    // 0x4f4750: r0 = autoString()
    //     0x4f4750: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f4754: r1 = Function '<anonymous closure>':.
    //     0x4f4754: add             x1, PP, #0x16, lsl #12  ; [pp+0x16740] AnonymousClosure: (0x4f4f64), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::ensureInitialized (0x4f40c0)
    //     0x4f4758: ldr             x1, [x1, #0x740]
    // 0x4f475c: r2 = Null
    //     0x4f475c: mov             x2, NULL
    // 0x4f4760: stur            x0, [fp, #-0x20]
    // 0x4f4764: r0 = AllocateClosure()
    //     0x4f4764: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4768: r1 = <String>
    //     0x4f4768: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f476c: stur            x0, [fp, #-0x28]
    // 0x4f4770: r0 = Generator()
    //     0x4f4770: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4774: ldur            x2, [fp, #-0x28]
    // 0x4f4778: r3 = Null
    //     0x4f4778: mov             x3, NULL
    // 0x4f477c: stur            x0, [fp, #-0x28]
    // 0x4f4780: r0 = AllocateRecord2()
    //     0x4f4780: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f4784: mov             x1, x0
    // 0x4f4788: ldur            x0, [fp, #-0x28]
    // 0x4f478c: StoreField: r0->field_f = r1
    //     0x4f478c: stur            w1, [x0, #0xf]
    // 0x4f4790: r1 = Null
    //     0x4f4790: mov             x1, NULL
    // 0x4f4794: r2 = 8
    //     0x4f4794: movz            x2, #0x8
    // 0x4f4798: r0 = AllocateArray()
    //     0x4f4798: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f479c: stur            x0, [fp, #-0x30]
    // 0x4f47a0: r16 = Instance_Tuple2
    //     0x4f47a0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16748] Obj!Tuple2<Chapter10Stat, CustomNum>@822751
    //     0x4f47a4: ldr             x16, [x16, #0x748]
    // 0x4f47a8: StoreField: r0->field_f = r16
    //     0x4f47a8: stur            w16, [x0, #0xf]
    // 0x4f47ac: r16 = Instance_Tuple2
    //     0x4f47ac: add             x16, PP, #0x16, lsl #12  ; [pp+0x16750] Obj!Tuple2<Chapter10Stat, CustomNum>@822731
    //     0x4f47b0: ldr             x16, [x16, #0x750]
    // 0x4f47b4: StoreField: r0->field_13 = r16
    //     0x4f47b4: stur            w16, [x0, #0x13]
    // 0x4f47b8: r16 = Instance_Tuple2
    //     0x4f47b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16758] Obj!Tuple2<Chapter10Stat, CustomNum>@822711
    //     0x4f47bc: ldr             x16, [x16, #0x758]
    // 0x4f47c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f47c0: stur            w16, [x0, #0x17]
    // 0x4f47c4: r16 = Instance_Tuple2
    //     0x4f47c4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16760] Obj!Tuple2<Chapter10Stat, CustomNum>@8226f1
    //     0x4f47c8: ldr             x16, [x16, #0x760]
    // 0x4f47cc: StoreField: r0->field_1b = r16
    //     0x4f47cc: stur            w16, [x0, #0x1b]
    // 0x4f47d0: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f47d0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f47d4: ldr             x1, [x1, #0x690]
    // 0x4f47d8: r0 = AllocateGrowableArray()
    //     0x4f47d8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f47dc: mov             x2, x0
    // 0x4f47e0: ldur            x0, [fp, #-0x30]
    // 0x4f47e4: stur            x2, [fp, #-0x38]
    // 0x4f47e8: StoreField: r2->field_f = r0
    //     0x4f47e8: stur            w0, [x2, #0xf]
    // 0x4f47ec: r0 = 8
    //     0x4f47ec: movz            x0, #0x8
    // 0x4f47f0: StoreField: r2->field_b = r0
    //     0x4f47f0: stur            w0, [x2, #0xb]
    // 0x4f47f4: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f47f4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f47f8: ldr             x1, [x1, #0x690]
    // 0x4f47fc: r0 = Generator()
    //     0x4f47fc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4800: mov             x2, x0
    // 0x4f4804: ldur            x0, [fp, #-0x38]
    // 0x4f4808: stur            x2, [fp, #-0x30]
    // 0x4f480c: StoreField: r2->field_b = r0
    //     0x4f480c: stur            w0, [x2, #0xb]
    // 0x4f4810: r1 = <Chapter10Stat>
    //     0x4f4810: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f4814: ldr             x1, [x1, #0xe80]
    // 0x4f4818: r0 = UpgradeData()
    //     0x4f4818: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f481c: mov             x3, x0
    // 0x4f4820: ldur            x0, [fp, #-0x20]
    // 0x4f4824: stur            x3, [fp, #-0x38]
    // 0x4f4828: StoreField: r3->field_b = r0
    //     0x4f4828: stur            w0, [x3, #0xb]
    // 0x4f482c: ldur            x0, [fp, #-0x28]
    // 0x4f4830: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f4830: stur            w0, [x3, #0x17]
    // 0x4f4834: r0 = Instance_IconData
    //     0x4f4834: add             x0, PP, #0x16, lsl #12  ; [pp+0x16768] Obj!IconData@82f371
    //     0x4f4838: ldr             x0, [x0, #0x768]
    // 0x4f483c: StoreField: r3->field_13 = r0
    //     0x4f483c: stur            w0, [x3, #0x13]
    // 0x4f4840: ldur            x0, [fp, #-0x30]
    // 0x4f4844: StoreField: r3->field_f = r0
    //     0x4f4844: stur            w0, [x3, #0xf]
    // 0x4f4848: ldur            x2, [fp, #-0x10]
    // 0x4f484c: r1 = Function '<anonymous closure>':.
    //     0x4f484c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16770] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f4850: ldr             x1, [x1, #0x770]
    // 0x4f4854: r0 = AllocateClosure()
    //     0x4f4854: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4858: mov             x1, x0
    // 0x4f485c: ldur            x0, [fp, #-0x38]
    // 0x4f4860: StoreField: r0->field_23 = r1
    //     0x4f4860: stur            w1, [x0, #0x23]
    // 0x4f4864: ldur            x1, [fp, #-0x18]
    // 0x4f4868: ArrayStore: r1[7] = r0  ; List_4
    //     0x4f4868: add             x25, x1, #0x2b
    //     0x4f486c: str             w0, [x25]
    //     0x4f4870: tbz             w0, #0, #0x4f488c
    //     0x4f4874: ldurb           w16, [x1, #-1]
    //     0x4f4878: ldurb           w17, [x0, #-1]
    //     0x4f487c: and             x16, x17, x16, lsr #2
    //     0x4f4880: tst             x16, HEAP, lsr #32
    //     0x4f4884: b.eq            #0x4f488c
    //     0x4f4888: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f488c: ldur            x0, [fp, #-0x18]
    // 0x4f4890: r16 = 40
    //     0x4f4890: movz            x16, #0x28
    // 0x4f4894: StoreField: r0->field_2f = r16
    //     0x4f4894: stur            w16, [x0, #0x2f]
    // 0x4f4898: r1 = "Upgrade 1"
    //     0x4f4898: add             x1, PP, #0x16, lsl #12  ; [pp+0x16778] "Upgrade 1"
    //     0x4f489c: ldr             x1, [x1, #0x778]
    // 0x4f48a0: r0 = autoString()
    //     0x4f48a0: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f48a4: r1 = Null
    //     0x4f48a4: mov             x1, NULL
    // 0x4f48a8: r2 = 6
    //     0x4f48a8: movz            x2, #0x6
    // 0x4f48ac: stur            x0, [fp, #-0x20]
    // 0x4f48b0: r0 = AllocateArray()
    //     0x4f48b0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f48b4: stur            x0, [fp, #-0x28]
    // 0x4f48b8: r16 = "Reduces Grep prices."
    //     0x4f48b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16780] "Reduces Grep prices."
    //     0x4f48bc: ldr             x16, [x16, #0x780]
    // 0x4f48c0: StoreField: r0->field_f = r16
    //     0x4f48c0: stur            w16, [x0, #0xf]
    // 0x4f48c4: r16 = "Increases Time yields."
    //     0x4f48c4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16788] "Increases Time yields."
    //     0x4f48c8: ldr             x16, [x16, #0x788]
    // 0x4f48cc: StoreField: r0->field_13 = r16
    //     0x4f48cc: stur            w16, [x0, #0x13]
    // 0x4f48d0: r16 = "Increases Readline yields."
    //     0x4f48d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16790] "Increases Readline yields."
    //     0x4f48d4: ldr             x16, [x16, #0x790]
    // 0x4f48d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f48d8: stur            w16, [x0, #0x17]
    // 0x4f48dc: r1 = <String>
    //     0x4f48dc: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f48e0: r0 = AllocateGrowableArray()
    //     0x4f48e0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f48e4: mov             x2, x0
    // 0x4f48e8: ldur            x0, [fp, #-0x28]
    // 0x4f48ec: stur            x2, [fp, #-0x30]
    // 0x4f48f0: StoreField: r2->field_f = r0
    //     0x4f48f0: stur            w0, [x2, #0xf]
    // 0x4f48f4: r0 = 6
    //     0x4f48f4: movz            x0, #0x6
    // 0x4f48f8: StoreField: r2->field_b = r0
    //     0x4f48f8: stur            w0, [x2, #0xb]
    // 0x4f48fc: r1 = <String>
    //     0x4f48fc: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4900: r0 = Generator()
    //     0x4f4900: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4904: mov             x3, x0
    // 0x4f4908: ldur            x0, [fp, #-0x30]
    // 0x4f490c: stur            x3, [fp, #-0x28]
    // 0x4f4910: StoreField: r3->field_b = r0
    //     0x4f4910: stur            w0, [x3, #0xb]
    // 0x4f4914: r1 = Null
    //     0x4f4914: mov             x1, NULL
    // 0x4f4918: r2 = 6
    //     0x4f4918: movz            x2, #0x6
    // 0x4f491c: r0 = AllocateArray()
    //     0x4f491c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4920: stur            x0, [fp, #-0x30]
    // 0x4f4924: r16 = Instance_Tuple2
    //     0x4f4924: add             x16, PP, #0x16, lsl #12  ; [pp+0x16798] Obj!Tuple2<Chapter10Stat, CustomNum>@8226d1
    //     0x4f4928: ldr             x16, [x16, #0x798]
    // 0x4f492c: StoreField: r0->field_f = r16
    //     0x4f492c: stur            w16, [x0, #0xf]
    // 0x4f4930: r16 = Instance_Tuple2
    //     0x4f4930: add             x16, PP, #0x16, lsl #12  ; [pp+0x167a0] Obj!Tuple2<Chapter10Stat, CustomNum>@8226b1
    //     0x4f4934: ldr             x16, [x16, #0x7a0]
    // 0x4f4938: StoreField: r0->field_13 = r16
    //     0x4f4938: stur            w16, [x0, #0x13]
    // 0x4f493c: r16 = Instance_Tuple2
    //     0x4f493c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167a8] Obj!Tuple2<Chapter10Stat, CustomNum>@822691
    //     0x4f4940: ldr             x16, [x16, #0x7a8]
    // 0x4f4944: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4944: stur            w16, [x0, #0x17]
    // 0x4f4948: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4948: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f494c: ldr             x1, [x1, #0x690]
    // 0x4f4950: r0 = AllocateGrowableArray()
    //     0x4f4950: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f4954: mov             x2, x0
    // 0x4f4958: ldur            x0, [fp, #-0x30]
    // 0x4f495c: stur            x2, [fp, #-0x38]
    // 0x4f4960: StoreField: r2->field_f = r0
    //     0x4f4960: stur            w0, [x2, #0xf]
    // 0x4f4964: r0 = 6
    //     0x4f4964: movz            x0, #0x6
    // 0x4f4968: StoreField: r2->field_b = r0
    //     0x4f4968: stur            w0, [x2, #0xb]
    // 0x4f496c: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f496c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4970: ldr             x1, [x1, #0x690]
    // 0x4f4974: r0 = Generator()
    //     0x4f4974: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4978: mov             x2, x0
    // 0x4f497c: ldur            x0, [fp, #-0x38]
    // 0x4f4980: stur            x2, [fp, #-0x30]
    // 0x4f4984: StoreField: r2->field_b = r0
    //     0x4f4984: stur            w0, [x2, #0xb]
    // 0x4f4988: r1 = <Chapter10Stat>
    //     0x4f4988: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f498c: ldr             x1, [x1, #0xe80]
    // 0x4f4990: r0 = UpgradeData()
    //     0x4f4990: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f4994: mov             x3, x0
    // 0x4f4998: ldur            x0, [fp, #-0x20]
    // 0x4f499c: stur            x3, [fp, #-0x38]
    // 0x4f49a0: StoreField: r3->field_b = r0
    //     0x4f49a0: stur            w0, [x3, #0xb]
    // 0x4f49a4: ldur            x0, [fp, #-0x28]
    // 0x4f49a8: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f49a8: stur            w0, [x3, #0x17]
    // 0x4f49ac: r0 = Instance_IconData
    //     0x4f49ac: add             x0, PP, #0x16, lsl #12  ; [pp+0x167b0] Obj!IconData@82f351
    //     0x4f49b0: ldr             x0, [x0, #0x7b0]
    // 0x4f49b4: StoreField: r3->field_13 = r0
    //     0x4f49b4: stur            w0, [x3, #0x13]
    // 0x4f49b8: ldur            x0, [fp, #-0x30]
    // 0x4f49bc: StoreField: r3->field_f = r0
    //     0x4f49bc: stur            w0, [x3, #0xf]
    // 0x4f49c0: ldur            x2, [fp, #-0x10]
    // 0x4f49c4: r1 = Function '<anonymous closure>':.
    //     0x4f49c4: add             x1, PP, #0x16, lsl #12  ; [pp+0x167b8] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f49c8: ldr             x1, [x1, #0x7b8]
    // 0x4f49cc: r0 = AllocateClosure()
    //     0x4f49cc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f49d0: mov             x1, x0
    // 0x4f49d4: ldur            x0, [fp, #-0x38]
    // 0x4f49d8: StoreField: r0->field_23 = r1
    //     0x4f49d8: stur            w1, [x0, #0x23]
    // 0x4f49dc: ldur            x1, [fp, #-0x18]
    // 0x4f49e0: ArrayStore: r1[9] = r0  ; List_4
    //     0x4f49e0: add             x25, x1, #0x33
    //     0x4f49e4: str             w0, [x25]
    //     0x4f49e8: tbz             w0, #0, #0x4f4a04
    //     0x4f49ec: ldurb           w16, [x1, #-1]
    //     0x4f49f0: ldurb           w17, [x0, #-1]
    //     0x4f49f4: and             x16, x17, x16, lsr #2
    //     0x4f49f8: tst             x16, HEAP, lsr #32
    //     0x4f49fc: b.eq            #0x4f4a04
    //     0x4f4a00: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f4a04: ldur            x0, [fp, #-0x18]
    // 0x4f4a08: r16 = 42
    //     0x4f4a08: movz            x16, #0x2a
    // 0x4f4a0c: StoreField: r0->field_37 = r16
    //     0x4f4a0c: stur            w16, [x0, #0x37]
    // 0x4f4a10: r1 = "Upgrade 2"
    //     0x4f4a10: add             x1, PP, #0x16, lsl #12  ; [pp+0x167c0] "Upgrade 2"
    //     0x4f4a14: ldr             x1, [x1, #0x7c0]
    // 0x4f4a18: r0 = autoString()
    //     0x4f4a18: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f4a1c: r1 = Null
    //     0x4f4a1c: mov             x1, NULL
    // 0x4f4a20: r2 = 6
    //     0x4f4a20: movz            x2, #0x6
    // 0x4f4a24: stur            x0, [fp, #-0x20]
    // 0x4f4a28: r0 = AllocateArray()
    //     0x4f4a28: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4a2c: stur            x0, [fp, #-0x28]
    // 0x4f4a30: r16 = "Reduces Gzip prices."
    //     0x4f4a30: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "Reduces Gzip prices."
    //     0x4f4a34: ldr             x16, [x16, #0x7c8]
    // 0x4f4a38: StoreField: r0->field_f = r16
    //     0x4f4a38: stur            w16, [x0, #0xf]
    // 0x4f4a3c: r16 = "Increases GCC yields."
    //     0x4f4a3c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167d0] "Increases GCC yields."
    //     0x4f4a40: ldr             x16, [x16, #0x7d0]
    // 0x4f4a44: StoreField: r0->field_13 = r16
    //     0x4f4a44: stur            w16, [x0, #0x13]
    // 0x4f4a48: r16 = "Increases GRUB yields."
    //     0x4f4a48: add             x16, PP, #0x16, lsl #12  ; [pp+0x167d8] "Increases GRUB yields."
    //     0x4f4a4c: ldr             x16, [x16, #0x7d8]
    // 0x4f4a50: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4a50: stur            w16, [x0, #0x17]
    // 0x4f4a54: r1 = <String>
    //     0x4f4a54: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4a58: r0 = AllocateGrowableArray()
    //     0x4f4a58: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f4a5c: mov             x2, x0
    // 0x4f4a60: ldur            x0, [fp, #-0x28]
    // 0x4f4a64: stur            x2, [fp, #-0x30]
    // 0x4f4a68: StoreField: r2->field_f = r0
    //     0x4f4a68: stur            w0, [x2, #0xf]
    // 0x4f4a6c: r0 = 6
    //     0x4f4a6c: movz            x0, #0x6
    // 0x4f4a70: StoreField: r2->field_b = r0
    //     0x4f4a70: stur            w0, [x2, #0xb]
    // 0x4f4a74: r1 = <String>
    //     0x4f4a74: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4a78: r0 = Generator()
    //     0x4f4a78: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4a7c: mov             x3, x0
    // 0x4f4a80: ldur            x0, [fp, #-0x30]
    // 0x4f4a84: stur            x3, [fp, #-0x28]
    // 0x4f4a88: StoreField: r3->field_b = r0
    //     0x4f4a88: stur            w0, [x3, #0xb]
    // 0x4f4a8c: r1 = Null
    //     0x4f4a8c: mov             x1, NULL
    // 0x4f4a90: r2 = 6
    //     0x4f4a90: movz            x2, #0x6
    // 0x4f4a94: r0 = AllocateArray()
    //     0x4f4a94: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4a98: stur            x0, [fp, #-0x30]
    // 0x4f4a9c: r16 = Instance_Tuple2
    //     0x4f4a9c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167e0] Obj!Tuple2<Chapter10Stat, CustomNum>@822671
    //     0x4f4aa0: ldr             x16, [x16, #0x7e0]
    // 0x4f4aa4: StoreField: r0->field_f = r16
    //     0x4f4aa4: stur            w16, [x0, #0xf]
    // 0x4f4aa8: r16 = Instance_Tuple2
    //     0x4f4aa8: add             x16, PP, #0x16, lsl #12  ; [pp+0x167e8] Obj!Tuple2<Chapter10Stat, CustomNum>@822651
    //     0x4f4aac: ldr             x16, [x16, #0x7e8]
    // 0x4f4ab0: StoreField: r0->field_13 = r16
    //     0x4f4ab0: stur            w16, [x0, #0x13]
    // 0x4f4ab4: r16 = Instance_Tuple2
    //     0x4f4ab4: add             x16, PP, #0x16, lsl #12  ; [pp+0x167f0] Obj!Tuple2<Chapter10Stat, CustomNum>@822631
    //     0x4f4ab8: ldr             x16, [x16, #0x7f0]
    // 0x4f4abc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4abc: stur            w16, [x0, #0x17]
    // 0x4f4ac0: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4ac0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4ac4: ldr             x1, [x1, #0x690]
    // 0x4f4ac8: r0 = AllocateGrowableArray()
    //     0x4f4ac8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f4acc: mov             x2, x0
    // 0x4f4ad0: ldur            x0, [fp, #-0x30]
    // 0x4f4ad4: stur            x2, [fp, #-0x38]
    // 0x4f4ad8: StoreField: r2->field_f = r0
    //     0x4f4ad8: stur            w0, [x2, #0xf]
    // 0x4f4adc: r0 = 6
    //     0x4f4adc: movz            x0, #0x6
    // 0x4f4ae0: StoreField: r2->field_b = r0
    //     0x4f4ae0: stur            w0, [x2, #0xb]
    // 0x4f4ae4: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4ae4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4ae8: ldr             x1, [x1, #0x690]
    // 0x4f4aec: r0 = Generator()
    //     0x4f4aec: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4af0: mov             x2, x0
    // 0x4f4af4: ldur            x0, [fp, #-0x38]
    // 0x4f4af8: stur            x2, [fp, #-0x30]
    // 0x4f4afc: StoreField: r2->field_b = r0
    //     0x4f4afc: stur            w0, [x2, #0xb]
    // 0x4f4b00: r1 = <Chapter10Stat>
    //     0x4f4b00: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f4b04: ldr             x1, [x1, #0xe80]
    // 0x4f4b08: r0 = UpgradeData()
    //     0x4f4b08: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f4b0c: mov             x3, x0
    // 0x4f4b10: ldur            x0, [fp, #-0x20]
    // 0x4f4b14: stur            x3, [fp, #-0x38]
    // 0x4f4b18: StoreField: r3->field_b = r0
    //     0x4f4b18: stur            w0, [x3, #0xb]
    // 0x4f4b1c: ldur            x0, [fp, #-0x28]
    // 0x4f4b20: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f4b20: stur            w0, [x3, #0x17]
    // 0x4f4b24: r0 = Instance_IconData
    //     0x4f4b24: add             x0, PP, #0x16, lsl #12  ; [pp+0x167f8] Obj!IconData@82f331
    //     0x4f4b28: ldr             x0, [x0, #0x7f8]
    // 0x4f4b2c: StoreField: r3->field_13 = r0
    //     0x4f4b2c: stur            w0, [x3, #0x13]
    // 0x4f4b30: ldur            x0, [fp, #-0x30]
    // 0x4f4b34: StoreField: r3->field_f = r0
    //     0x4f4b34: stur            w0, [x3, #0xf]
    // 0x4f4b38: ldur            x2, [fp, #-0x10]
    // 0x4f4b3c: r1 = Function '<anonymous closure>':.
    //     0x4f4b3c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16800] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f4b40: ldr             x1, [x1, #0x800]
    // 0x4f4b44: r0 = AllocateClosure()
    //     0x4f4b44: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4b48: mov             x1, x0
    // 0x4f4b4c: ldur            x0, [fp, #-0x38]
    // 0x4f4b50: StoreField: r0->field_23 = r1
    //     0x4f4b50: stur            w1, [x0, #0x23]
    // 0x4f4b54: ldur            x1, [fp, #-0x18]
    // 0x4f4b58: ArrayStore: r1[11] = r0  ; List_4
    //     0x4f4b58: add             x25, x1, #0x3b
    //     0x4f4b5c: str             w0, [x25]
    //     0x4f4b60: tbz             w0, #0, #0x4f4b7c
    //     0x4f4b64: ldurb           w16, [x1, #-1]
    //     0x4f4b68: ldurb           w17, [x0, #-1]
    //     0x4f4b6c: and             x16, x17, x16, lsr #2
    //     0x4f4b70: tst             x16, HEAP, lsr #32
    //     0x4f4b74: b.eq            #0x4f4b7c
    //     0x4f4b78: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f4b7c: ldur            x0, [fp, #-0x18]
    // 0x4f4b80: r16 = 44
    //     0x4f4b80: movz            x16, #0x2c
    // 0x4f4b84: StoreField: r0->field_3f = r16
    //     0x4f4b84: stur            w16, [x0, #0x3f]
    // 0x4f4b88: r1 = "Upgrade 3"
    //     0x4f4b88: add             x1, PP, #0x16, lsl #12  ; [pp+0x16808] "Upgrade 3"
    //     0x4f4b8c: ldr             x1, [x1, #0x808]
    // 0x4f4b90: r0 = autoString()
    //     0x4f4b90: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f4b94: r1 = Null
    //     0x4f4b94: mov             x1, NULL
    // 0x4f4b98: r2 = 6
    //     0x4f4b98: movz            x2, #0x6
    // 0x4f4b9c: stur            x0, [fp, #-0x20]
    // 0x4f4ba0: r0 = AllocateArray()
    //     0x4f4ba0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4ba4: stur            x0, [fp, #-0x28]
    // 0x4f4ba8: r16 = "Reduces GRUB prices."
    //     0x4f4ba8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16810] "Reduces GRUB prices."
    //     0x4f4bac: ldr             x16, [x16, #0x810]
    // 0x4f4bb0: StoreField: r0->field_f = r16
    //     0x4f4bb0: stur            w16, [x0, #0xf]
    // 0x4f4bb4: r16 = "Increases Readline yields."
    //     0x4f4bb4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16790] "Increases Readline yields."
    //     0x4f4bb8: ldr             x16, [x16, #0x790]
    // 0x4f4bbc: StoreField: r0->field_13 = r16
    //     0x4f4bbc: stur            w16, [x0, #0x13]
    // 0x4f4bc0: r16 = "Increases time yields."
    //     0x4f4bc0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16818] "Increases time yields."
    //     0x4f4bc4: ldr             x16, [x16, #0x818]
    // 0x4f4bc8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4bc8: stur            w16, [x0, #0x17]
    // 0x4f4bcc: r1 = <String>
    //     0x4f4bcc: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4bd0: r0 = AllocateGrowableArray()
    //     0x4f4bd0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f4bd4: mov             x2, x0
    // 0x4f4bd8: ldur            x0, [fp, #-0x28]
    // 0x4f4bdc: stur            x2, [fp, #-0x30]
    // 0x4f4be0: StoreField: r2->field_f = r0
    //     0x4f4be0: stur            w0, [x2, #0xf]
    // 0x4f4be4: r0 = 6
    //     0x4f4be4: movz            x0, #0x6
    // 0x4f4be8: StoreField: r2->field_b = r0
    //     0x4f4be8: stur            w0, [x2, #0xb]
    // 0x4f4bec: r1 = <String>
    //     0x4f4bec: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f4bf0: r0 = Generator()
    //     0x4f4bf0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4bf4: mov             x3, x0
    // 0x4f4bf8: ldur            x0, [fp, #-0x30]
    // 0x4f4bfc: stur            x3, [fp, #-0x28]
    // 0x4f4c00: StoreField: r3->field_b = r0
    //     0x4f4c00: stur            w0, [x3, #0xb]
    // 0x4f4c04: r1 = Null
    //     0x4f4c04: mov             x1, NULL
    // 0x4f4c08: r2 = 6
    //     0x4f4c08: movz            x2, #0x6
    // 0x4f4c0c: r0 = AllocateArray()
    //     0x4f4c0c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4c10: stur            x0, [fp, #-0x30]
    // 0x4f4c14: r16 = Instance_Tuple2
    //     0x4f4c14: add             x16, PP, #0x16, lsl #12  ; [pp+0x16820] Obj!Tuple2<Chapter10Stat, CustomNum>@822611
    //     0x4f4c18: ldr             x16, [x16, #0x820]
    // 0x4f4c1c: StoreField: r0->field_f = r16
    //     0x4f4c1c: stur            w16, [x0, #0xf]
    // 0x4f4c20: r16 = Instance_Tuple2
    //     0x4f4c20: add             x16, PP, #0x16, lsl #12  ; [pp+0x16828] Obj!Tuple2<Chapter10Stat, CustomNum>@8225f1
    //     0x4f4c24: ldr             x16, [x16, #0x828]
    // 0x4f4c28: StoreField: r0->field_13 = r16
    //     0x4f4c28: stur            w16, [x0, #0x13]
    // 0x4f4c2c: r16 = Instance_Tuple2
    //     0x4f4c2c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16830] Obj!Tuple2<Chapter10Stat, CustomNum>@8225d1
    //     0x4f4c30: ldr             x16, [x16, #0x830]
    // 0x4f4c34: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f4c34: stur            w16, [x0, #0x17]
    // 0x4f4c38: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4c38: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4c3c: ldr             x1, [x1, #0x690]
    // 0x4f4c40: r0 = AllocateGrowableArray()
    //     0x4f4c40: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f4c44: mov             x2, x0
    // 0x4f4c48: ldur            x0, [fp, #-0x30]
    // 0x4f4c4c: stur            x2, [fp, #-0x38]
    // 0x4f4c50: StoreField: r2->field_f = r0
    //     0x4f4c50: stur            w0, [x2, #0xf]
    // 0x4f4c54: r0 = 6
    //     0x4f4c54: movz            x0, #0x6
    // 0x4f4c58: StoreField: r2->field_b = r0
    //     0x4f4c58: stur            w0, [x2, #0xb]
    // 0x4f4c5c: r1 = <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4c5c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16690] TypeArguments: <Tuple2<Chapter10Stat, CustomNum>>
    //     0x4f4c60: ldr             x1, [x1, #0x690]
    // 0x4f4c64: r0 = Generator()
    //     0x4f4c64: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f4c68: mov             x2, x0
    // 0x4f4c6c: ldur            x0, [fp, #-0x38]
    // 0x4f4c70: stur            x2, [fp, #-0x30]
    // 0x4f4c74: StoreField: r2->field_b = r0
    //     0x4f4c74: stur            w0, [x2, #0xb]
    // 0x4f4c78: r1 = <Chapter10Stat>
    //     0x4f4c78: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4f4c7c: ldr             x1, [x1, #0xe80]
    // 0x4f4c80: r0 = UpgradeData()
    //     0x4f4c80: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f4c84: mov             x3, x0
    // 0x4f4c88: ldur            x0, [fp, #-0x20]
    // 0x4f4c8c: stur            x3, [fp, #-0x38]
    // 0x4f4c90: StoreField: r3->field_b = r0
    //     0x4f4c90: stur            w0, [x3, #0xb]
    // 0x4f4c94: ldur            x0, [fp, #-0x28]
    // 0x4f4c98: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f4c98: stur            w0, [x3, #0x17]
    // 0x4f4c9c: r0 = Instance_IconData
    //     0x4f4c9c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16838] Obj!IconData@82f311
    //     0x4f4ca0: ldr             x0, [x0, #0x838]
    // 0x4f4ca4: StoreField: r3->field_13 = r0
    //     0x4f4ca4: stur            w0, [x3, #0x13]
    // 0x4f4ca8: ldur            x0, [fp, #-0x30]
    // 0x4f4cac: StoreField: r3->field_f = r0
    //     0x4f4cac: stur            w0, [x3, #0xf]
    // 0x4f4cb0: ldur            x2, [fp, #-0x10]
    // 0x4f4cb4: r1 = Function '<anonymous closure>':.
    //     0x4f4cb4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16840] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f4cb8: ldr             x1, [x1, #0x840]
    // 0x4f4cbc: r0 = AllocateClosure()
    //     0x4f4cbc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f4cc0: mov             x1, x0
    // 0x4f4cc4: ldur            x0, [fp, #-0x38]
    // 0x4f4cc8: StoreField: r0->field_23 = r1
    //     0x4f4cc8: stur            w1, [x0, #0x23]
    // 0x4f4ccc: ldur            x1, [fp, #-0x18]
    // 0x4f4cd0: ArrayStore: r1[13] = r0  ; List_4
    //     0x4f4cd0: add             x25, x1, #0x43
    //     0x4f4cd4: str             w0, [x25]
    //     0x4f4cd8: tbz             w0, #0, #0x4f4cf4
    //     0x4f4cdc: ldurb           w16, [x1, #-1]
    //     0x4f4ce0: ldurb           w17, [x0, #-1]
    //     0x4f4ce4: and             x16, x17, x16, lsr #2
    //     0x4f4ce8: tst             x16, HEAP, lsr #32
    //     0x4f4cec: b.eq            #0x4f4cf4
    //     0x4f4cf0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f4cf4: r16 = <int, UpgradeData<Chapter10Stat>>
    //     0x4f4cf4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16848] TypeArguments: <int, UpgradeData<Chapter10Stat>>
    //     0x4f4cf8: ldr             x16, [x16, #0x848]
    // 0x4f4cfc: ldur            lr, [fp, #-0x18]
    // 0x4f4d00: stp             lr, x16, [SP]
    // 0x4f4d04: r0 = Map._fromLiteral()
    //     0x4f4d04: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4f4d08: ldur            x1, [fp, #-8]
    // 0x4f4d0c: StoreField: r1->field_97 = r0
    //     0x4f4d0c: stur            w0, [x1, #0x97]
    //     0x4f4d10: ldurb           w16, [x1, #-1]
    //     0x4f4d14: ldurb           w17, [x0, #-1]
    //     0x4f4d18: and             x16, x17, x16, lsr #2
    //     0x4f4d1c: tst             x16, HEAP, lsr #32
    //     0x4f4d20: b.eq            #0x4f4d28
    //     0x4f4d24: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4f4d28: r0 = Null
    //     0x4f4d28: mov             x0, NULL
    // 0x4f4d2c: LeaveFrame
    //     0x4f4d2c: mov             SP, fp
    //     0x4f4d30: ldp             fp, lr, [SP], #0x10
    // 0x4f4d34: ret
    //     0x4f4d34: ret             
    // 0x4f4d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f4d38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f4d3c: b               #0x4f40dc
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f4f64, size: 0x8c
    // 0x4f4f64: EnterFrame
    //     0x4f4f64: stp             fp, lr, [SP, #-0x10]!
    //     0x4f4f68: mov             fp, SP
    // 0x4f4f6c: AllocStack(0x8)
    //     0x4f4f6c: sub             SP, SP, #8
    // 0x4f4f70: CheckStackOverflow
    //     0x4f4f70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f4f74: cmp             SP, x16
    //     0x4f4f78: b.ls            #0x4f4fe8
    // 0x4f4f7c: r1 = Null
    //     0x4f4f7c: mov             x1, NULL
    // 0x4f4f80: r2 = 6
    //     0x4f4f80: movz            x2, #0x6
    // 0x4f4f84: r0 = AllocateArray()
    //     0x4f4f84: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f4f88: mov             x2, x0
    // 0x4f4f8c: r16 = "Decreases the minimum utility to refactor by a factor of 1e"
    //     0x4f4f8c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16850] "Decreases the minimum utility to refactor by a factor of 1e"
    //     0x4f4f90: ldr             x16, [x16, #0x850]
    // 0x4f4f94: StoreField: r2->field_f = r16
    //     0x4f4f94: stur            w16, [x2, #0xf]
    // 0x4f4f98: ldr             x0, [fp, #0x10]
    // 0x4f4f9c: r1 = LoadInt32Instr(r0)
    //     0x4f4f9c: sbfx            x1, x0, #1, #0x1f
    //     0x4f4fa0: tbz             w0, #0, #0x4f4fa8
    //     0x4f4fa4: ldur            x1, [x0, #7]
    // 0x4f4fa8: add             x0, x1, #1
    // 0x4f4fac: r16 = 10
    //     0x4f4fac: movz            x16, #0xa
    // 0x4f4fb0: mul             x3, x0, x16
    // 0x4f4fb4: r0 = BoxInt64Instr(r3)
    //     0x4f4fb4: sbfiz           x0, x3, #1, #0x1f
    //     0x4f4fb8: cmp             x3, x0, asr #1
    //     0x4f4fbc: b.eq            #0x4f4fc8
    //     0x4f4fc0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4f4fc4: stur            x3, [x0, #7]
    // 0x4f4fc8: StoreField: r2->field_13 = r0
    //     0x4f4fc8: stur            w0, [x2, #0x13]
    // 0x4f4fcc: r16 = "."
    //     0x4f4fcc: ldr             x16, [PP, #0x108]  ; [pp+0x108] "."
    // 0x4f4fd0: ArrayStore: r2[0] = r16  ; List_4
    //     0x4f4fd0: stur            w16, [x2, #0x17]
    // 0x4f4fd4: str             x2, [SP]
    // 0x4f4fd8: r0 = _interpolate()
    //     0x4f4fd8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4f4fdc: LeaveFrame
    //     0x4f4fdc: mov             SP, fp
    //     0x4f4fe0: ldp             fp, lr, [SP], #0x10
    // 0x4f4fe4: ret
    //     0x4f4fe4: ret             
    // 0x4f4fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f4fe8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f4fec: b               #0x4f4f7c
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f4ff0, size: 0xc
    // 0x4f4ff0: r0 = "Refacter/kernel prestiges no longer reset upgrades."
    //     0x4f4ff0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16858] "Refacter/kernel prestiges no longer reset upgrades."
    //     0x4f4ff4: ldr             x0, [x0, #0x858]
    // 0x4f4ff8: ret
    //     0x4f4ff8: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f4ffc, size: 0x260
    // 0x4f4ffc: EnterFrame
    //     0x4f4ffc: stp             fp, lr, [SP, #-0x10]!
    //     0x4f5000: mov             fp, SP
    // 0x4f5004: AllocStack(0x20)
    //     0x4f5004: sub             SP, SP, #0x20
    // 0x4f5008: CheckStackOverflow
    //     0x4f5008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f500c: cmp             SP, x16
    //     0x4f5010: b.ls            #0x4f523c
    // 0x4f5014: r1 = Null
    //     0x4f5014: mov             x1, NULL
    // 0x4f5018: r2 = 6
    //     0x4f5018: movz            x2, #0x6
    // 0x4f501c: r0 = AllocateArray()
    //     0x4f501c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5020: mov             x2, x0
    // 0x4f5024: stur            x2, [fp, #-8]
    // 0x4f5028: r16 = "Increase rate of all generators by "
    //     0x4f5028: add             x16, PP, #0x14, lsl #12  ; [pp+0x14010] "Increase rate of all generators by "
    //     0x4f502c: ldr             x16, [x16, #0x10]
    // 0x4f5030: StoreField: r2->field_f = r16
    //     0x4f5030: stur            w16, [x2, #0xf]
    // 0x4f5034: ldr             x0, [fp, #0x10]
    // 0x4f5038: r1 = LoadInt32Instr(r0)
    //     0x4f5038: sbfx            x1, x0, #1, #0x1f
    //     0x4f503c: tbz             w0, #0, #0x4f5044
    //     0x4f5040: ldur            x1, [x0, #7]
    // 0x4f5044: tbnz            x1, #0x3f, #0x4f50a0
    // 0x4f5048: mov             x0, x1
    // 0x4f504c: r1 = 2
    //     0x4f504c: movz            x1, #0x2
    // 0x4f5050: r3 = 1
    //     0x4f5050: movz            x3, #0x1
    // 0x4f5054: CheckStackOverflow
    //     0x4f5054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f5058: cmp             SP, x16
    //     0x4f505c: b.ls            #0x4f5244
    // 0x4f5060: cbz             x0, #0x4f5088
    // 0x4f5064: branchIfSmi(r0, 0x4f5070)
    //     0x4f5064: tbz             w0, #0, #0x4f5070
    // 0x4f5068: mul             x4, x3, x1
    // 0x4f506c: mov             x3, x4
    // 0x4f5070: asr             x4, x0, #1
    // 0x4f5074: cbz             x4, #0x4f5080
    // 0x4f5078: mul             x5, x1, x1
    // 0x4f507c: mov             x1, x5
    // 0x4f5080: mov             x0, x4
    // 0x4f5084: b               #0x4f5054
    // 0x4f5088: r0 = BoxInt64Instr(r3)
    //     0x4f5088: sbfiz           x0, x3, #1, #0x1f
    //     0x4f508c: cmp             x3, x0, asr #1
    //     0x4f5090: b.eq            #0x4f509c
    //     0x4f5094: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4f5098: stur            x3, [x0, #7]
    // 0x4f509c: b               #0x4f51f4
    // 0x4f50a0: r16 = 4
    //     0x4f50a0: movz            x16, #0x4
    // 0x4f50a4: stp             x16, NULL, [SP]
    // 0x4f50a8: r0 = _Double.fromInteger()
    //     0x4f50a8: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x4f50ac: mov             x1, x0
    // 0x4f50b0: ldr             x0, [fp, #0x10]
    // 0x4f50b4: stur            x1, [fp, #-0x10]
    // 0x4f50b8: r2 = 60
    //     0x4f50b8: movz            x2, #0x3c
    // 0x4f50bc: branchIfSmi(r0, 0x4f50c8)
    //     0x4f50bc: tbz             w0, #0, #0x4f50c8
    // 0x4f50c0: r2 = LoadClassIdInstr(r0)
    //     0x4f50c0: ldur            x2, [x0, #-1]
    //     0x4f50c4: ubfx            x2, x2, #0xc, #0x14
    // 0x4f50c8: str             x0, [SP]
    // 0x4f50cc: mov             x0, x2
    // 0x4f50d0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4f50d0: sub             lr, x0, #1, lsl #12
    //     0x4f50d4: ldr             lr, [x21, lr, lsl #3]
    //     0x4f50d8: blr             lr
    // 0x4f50dc: mov             x1, x0
    // 0x4f50e0: ldur            x0, [fp, #-0x10]
    // 0x4f50e4: LoadField: d0 = r0->field_7
    //     0x4f50e4: ldur            d0, [x0, #7]
    // 0x4f50e8: LoadField: d1 = r1->field_7
    //     0x4f50e8: ldur            d1, [x1, #7]
    // 0x4f50ec: d30 = 0.000000
    //     0x4f50ec: fmov            d30, d0
    // 0x4f50f0: d0 = 1.000000
    //     0x4f50f0: fmov            d0, #1.00000000
    // 0x4f50f4: fcmp            d1, #0.0
    // 0x4f50f8: b.vs            #0x4f513c
    // 0x4f50fc: b.eq            #0x4f51c4
    // 0x4f5100: fcmp            d1, d0
    // 0x4f5104: b.eq            #0x4f512c
    // 0x4f5108: d31 = 2.000000
    //     0x4f5108: fmov            d31, #2.00000000
    // 0x4f510c: fcmp            d1, d31
    // 0x4f5110: b.eq            #0x4f5134
    // 0x4f5114: d31 = 3.000000
    //     0x4f5114: fmov            d31, #3.00000000
    // 0x4f5118: fcmp            d1, d31
    // 0x4f511c: b.ne            #0x4f513c
    // 0x4f5120: fmul            d0, d30, d30
    // 0x4f5124: fmul            d0, d0, d30
    // 0x4f5128: b               #0x4f51c4
    // 0x4f512c: d0 = 0.000000
    //     0x4f512c: fmov            d0, d30
    // 0x4f5130: b               #0x4f51c4
    // 0x4f5134: fmul            d0, d30, d30
    // 0x4f5138: b               #0x4f51c4
    // 0x4f513c: fcmp            d30, d0
    // 0x4f5140: b.vs            #0x4f5150
    // 0x4f5144: b.eq            #0x4f51c4
    // 0x4f5148: fcmp            d30, d1
    // 0x4f514c: b.vc            #0x4f515c
    // 0x4f5150: d0 = nan
    //     0x4f5150: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x4f5154: ldr             d0, [x17, #0xe48]
    // 0x4f5158: b               #0x4f51c4
    // 0x4f515c: d0 = -inf
    //     0x4f515c: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x4f5160: fcmp            d30, d0
    // 0x4f5164: b.eq            #0x4f518c
    // 0x4f5168: d0 = 0.500000
    //     0x4f5168: fmov            d0, #0.50000000
    // 0x4f516c: fcmp            d1, d0
    // 0x4f5170: b.ne            #0x4f518c
    // 0x4f5174: fcmp            d30, #0.0
    // 0x4f5178: b.eq            #0x4f5184
    // 0x4f517c: fsqrt           d0, d30
    // 0x4f5180: b               #0x4f51c4
    // 0x4f5184: d0 = 0.000000
    //     0x4f5184: eor             v0.16b, v0.16b, v0.16b
    // 0x4f5188: b               #0x4f51c4
    // 0x4f518c: d0 = 0.000000
    //     0x4f518c: fmov            d0, d30
    // 0x4f5190: stp             fp, lr, [SP, #-0x10]!
    // 0x4f5194: mov             fp, SP
    // 0x4f5198: CallRuntime_LibcPow(double, double) -> double
    //     0x4f5198: and             SP, SP, #0xfffffffffffffff0
    //     0x4f519c: mov             sp, SP
    //     0x4f51a0: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x4f51a4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f51a8: blr             x16
    //     0x4f51ac: movz            x16, #0x8
    //     0x4f51b0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f51b4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f51b8: sub             sp, x16, #1, lsl #12
    //     0x4f51bc: mov             SP, fp
    //     0x4f51c0: ldp             fp, lr, [SP], #0x10
    // 0x4f51c4: r0 = inline_Allocate_Double()
    //     0x4f51c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x4f51c8: add             x0, x0, #0x10
    //     0x4f51cc: cmp             x1, x0
    //     0x4f51d0: b.ls            #0x4f524c
    //     0x4f51d4: str             x0, [THR, #0x60]  ; THR::top
    //     0x4f51d8: sub             x0, x0, #0xf
    //     0x4f51dc: movz            x1, #0xe19c
    //     0x4f51e0: movk            x1, #0x3, lsl #16
    //     0x4f51e4: stur            x1, [x0, #-1]
    // 0x4f51e8: dmb             ishst
    // 0x4f51ec: StoreField: r0->field_7 = d0
    //     0x4f51ec: stur            d0, [x0, #7]
    // 0x4f51f0: ldur            x2, [fp, #-8]
    // 0x4f51f4: mov             x1, x2
    // 0x4f51f8: ArrayStore: r1[1] = r0  ; List_4
    //     0x4f51f8: add             x25, x1, #0x13
    //     0x4f51fc: str             w0, [x25]
    //     0x4f5200: tbz             w0, #0, #0x4f521c
    //     0x4f5204: ldurb           w16, [x1, #-1]
    //     0x4f5208: ldurb           w17, [x0, #-1]
    //     0x4f520c: and             x16, x17, x16, lsr #2
    //     0x4f5210: tst             x16, HEAP, lsr #32
    //     0x4f5214: b.eq            #0x4f521c
    //     0x4f5218: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f521c: r16 = "% per non-bonus generator."
    //     0x4f521c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16860] "% per non-bonus generator."
    //     0x4f5220: ldr             x16, [x16, #0x860]
    // 0x4f5224: ArrayStore: r2[0] = r16  ; List_4
    //     0x4f5224: stur            w16, [x2, #0x17]
    // 0x4f5228: str             x2, [SP]
    // 0x4f522c: r0 = _interpolate()
    //     0x4f522c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4f5230: LeaveFrame
    //     0x4f5230: mov             SP, fp
    //     0x4f5234: ldp             fp, lr, [SP], #0x10
    // 0x4f5238: ret
    //     0x4f5238: ret             
    // 0x4f523c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f523c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f5240: b               #0x4f5014
    // 0x4f5244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f5244: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f5248: b               #0x4f5060
    // 0x4f524c: SaveReg d0
    //     0x4f524c: str             q0, [SP, #-0x10]!
    // 0x4f5250: r0 = AllocateDouble()
    //     0x4f5250: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4f5254: RestoreReg d0
    //     0x4f5254: ldr             q0, [SP], #0x10
    // 0x4f5258: b               #0x4f51ec
  }
  _ postUpdateCallback(/* No info */) {
    // ** addr: 0x542e94, size: 0xca0
    // 0x542e94: EnterFrame
    //     0x542e94: stp             fp, lr, [SP, #-0x10]!
    //     0x542e98: mov             fp, SP
    // 0x542e9c: AllocStack(0x68)
    //     0x542e9c: sub             SP, SP, #0x68
    // 0x542ea0: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x10 */)
    //     0x542ea0: mov             x0, x1
    //     0x542ea4: stur            x1, [fp, #-0x10]
    // 0x542ea8: CheckStackOverflow
    //     0x542ea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x542eac: cmp             SP, x16
    //     0x542eb0: b.ls            #0x543af4
    // 0x542eb4: LoadField: r3 = r0->field_37
    //     0x542eb4: ldur            w3, [x0, #0x37]
    // 0x542eb8: DecompressPointer r3
    //     0x542eb8: add             x3, x3, HEAP, lsl #32
    // 0x542ebc: mov             x1, x3
    // 0x542ec0: stur            x3, [fp, #-8]
    // 0x542ec4: r2 = Instance_Chapter10Stat
    //     0x542ec4: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x542ec8: ldr             x2, [x2, #0x7d8]
    // 0x542ecc: r0 = _getValueOrData()
    //     0x542ecc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x542ed0: mov             x1, x0
    // 0x542ed4: ldur            x0, [fp, #-8]
    // 0x542ed8: LoadField: r2 = r0->field_f
    //     0x542ed8: ldur            w2, [x0, #0xf]
    // 0x542edc: DecompressPointer r2
    //     0x542edc: add             x2, x2, HEAP, lsl #32
    // 0x542ee0: cmp             w2, w1
    // 0x542ee4: b.ne            #0x542ef0
    // 0x542ee8: r0 = Null
    //     0x542ee8: mov             x0, NULL
    // 0x542eec: b               #0x542ef4
    // 0x542ef0: mov             x0, x1
    // 0x542ef4: cmp             w0, NULL
    // 0x542ef8: b.ne            #0x542f08
    // 0x542efc: r2 = Instance_CustomNum
    //     0x542efc: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x542f00: ldr             x2, [x2, #0xaf8]
    // 0x542f04: b               #0x542f0c
    // 0x542f08: mov             x2, x0
    // 0x542f0c: ldur            x0, [fp, #-0x10]
    // 0x542f10: r1 = Instance_CustomNum
    //     0x542f10: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x542f14: ldr             x1, [x1, #0xa70]
    // 0x542f18: r0 = add()
    //     0x542f18: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x542f1c: mov             x2, x0
    // 0x542f20: ldur            x0, [fp, #-0x10]
    // 0x542f24: stur            x2, [fp, #-0x18]
    // 0x542f28: LoadField: r3 = r0->field_33
    //     0x542f28: ldur            w3, [x0, #0x33]
    // 0x542f2c: DecompressPointer r3
    //     0x542f2c: add             x3, x3, HEAP, lsl #32
    // 0x542f30: mov             x1, x3
    // 0x542f34: stur            x3, [fp, #-8]
    // 0x542f38: r0 = clear()
    //     0x542f38: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x542f3c: ldur            x0, [fp, #-0x10]
    // 0x542f40: LoadField: r1 = r0->field_3f
    //     0x542f40: ldur            w1, [x0, #0x3f]
    // 0x542f44: DecompressPointer r1
    //     0x542f44: add             x1, x1, HEAP, lsl #32
    // 0x542f48: LoadField: r3 = r1->field_b
    //     0x542f48: ldur            w3, [x1, #0xb]
    // 0x542f4c: DecompressPointer r3
    //     0x542f4c: add             x3, x3, HEAP, lsl #32
    // 0x542f50: mov             x1, x3
    // 0x542f54: stur            x3, [fp, #-0x20]
    // 0x542f58: r2 = 2
    //     0x542f58: movz            x2, #0x2
    // 0x542f5c: r0 = _getValueOrData()
    //     0x542f5c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x542f60: mov             x1, x0
    // 0x542f64: ldur            x0, [fp, #-0x20]
    // 0x542f68: LoadField: r2 = r0->field_f
    //     0x542f68: ldur            w2, [x0, #0xf]
    // 0x542f6c: DecompressPointer r2
    //     0x542f6c: add             x2, x2, HEAP, lsl #32
    // 0x542f70: cmp             w2, w1
    // 0x542f74: b.ne            #0x542f80
    // 0x542f78: r0 = Null
    //     0x542f78: mov             x0, NULL
    // 0x542f7c: b               #0x542f84
    // 0x542f80: mov             x0, x1
    // 0x542f84: cmp             w0, NULL
    // 0x542f88: b.ne            #0x542f94
    // 0x542f8c: r3 = 0
    //     0x542f8c: movz            x3, #0
    // 0x542f90: b               #0x542fa4
    // 0x542f94: r1 = LoadInt32Instr(r0)
    //     0x542f94: sbfx            x1, x0, #1, #0x1f
    //     0x542f98: tbz             w0, #0, #0x542fa0
    //     0x542f9c: ldur            x1, [x0, #7]
    // 0x542fa0: mov             x3, x1
    // 0x542fa4: ldur            x0, [fp, #-0x10]
    // 0x542fa8: stur            x3, [fp, #-0x28]
    // 0x542fac: LoadField: r1 = r0->field_3f
    //     0x542fac: ldur            w1, [x0, #0x3f]
    // 0x542fb0: DecompressPointer r1
    //     0x542fb0: add             x1, x1, HEAP, lsl #32
    // 0x542fb4: LoadField: r4 = r1->field_b
    //     0x542fb4: ldur            w4, [x1, #0xb]
    // 0x542fb8: DecompressPointer r4
    //     0x542fb8: add             x4, x4, HEAP, lsl #32
    // 0x542fbc: mov             x1, x4
    // 0x542fc0: stur            x4, [fp, #-0x20]
    // 0x542fc4: r2 = 4
    //     0x542fc4: movz            x2, #0x4
    // 0x542fc8: r0 = _getValueOrData()
    //     0x542fc8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x542fcc: mov             x1, x0
    // 0x542fd0: ldur            x0, [fp, #-0x20]
    // 0x542fd4: LoadField: r2 = r0->field_f
    //     0x542fd4: ldur            w2, [x0, #0xf]
    // 0x542fd8: DecompressPointer r2
    //     0x542fd8: add             x2, x2, HEAP, lsl #32
    // 0x542fdc: cmp             w2, w1
    // 0x542fe0: b.ne            #0x542fec
    // 0x542fe4: r0 = Null
    //     0x542fe4: mov             x0, NULL
    // 0x542fe8: b               #0x542ff0
    // 0x542fec: mov             x0, x1
    // 0x542ff0: cmp             w0, NULL
    // 0x542ff4: b.ne            #0x543000
    // 0x542ff8: r1 = 0
    //     0x542ff8: movz            x1, #0
    // 0x542ffc: b               #0x54300c
    // 0x543000: r1 = LoadInt32Instr(r0)
    //     0x543000: sbfx            x1, x0, #1, #0x1f
    //     0x543004: tbz             w0, #0, #0x54300c
    //     0x543008: ldur            x1, [x0, #7]
    // 0x54300c: ldur            x3, [fp, #-0x10]
    // 0x543010: ldur            x0, [fp, #-0x28]
    // 0x543014: add             x2, x0, x1
    // 0x543018: r0 = BoxInt64Instr(r2)
    //     0x543018: sbfiz           x0, x2, #1, #0x1f
    //     0x54301c: cmp             x2, x0, asr #1
    //     0x543020: b.eq            #0x54302c
    //     0x543024: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x543028: stur            x2, [x0, #7]
    // 0x54302c: mov             x2, x0
    // 0x543030: r1 = Instance_CustomNum
    //     0x543030: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x543034: ldr             x1, [x1, #0x970]
    // 0x543038: r0 = pow()
    //     0x543038: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x54303c: ldur            x1, [fp, #-0x18]
    // 0x543040: mov             x2, x0
    // 0x543044: r0 = mult2()
    //     0x543044: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x543048: stur            x0, [fp, #-0x18]
    // 0x54304c: r0 = Boost()
    //     0x54304c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543050: mov             x1, x0
    // 0x543054: r0 = Instance_CustomNum
    //     0x543054: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543058: ldr             x0, [x0, #0xa70]
    // 0x54305c: StoreField: r1->field_7 = r0
    //     0x54305c: stur            w0, [x1, #7]
    // 0x543060: StoreField: r1->field_b = r0
    //     0x543060: stur            w0, [x1, #0xb]
    // 0x543064: ldur            x2, [fp, #-0x18]
    // 0x543068: StoreField: r1->field_f = r2
    //     0x543068: stur            w2, [x1, #0xf]
    // 0x54306c: StoreField: r1->field_13 = r0
    //     0x54306c: stur            w0, [x1, #0x13]
    // 0x543070: mov             x3, x1
    // 0x543074: ldur            x1, [fp, #-8]
    // 0x543078: r2 = 2
    //     0x543078: movz            x2, #0x2
    // 0x54307c: r0 = []=()
    //     0x54307c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x543080: ldur            x0, [fp, #-0x10]
    // 0x543084: LoadField: r3 = r0->field_43
    //     0x543084: ldur            w3, [x0, #0x43]
    // 0x543088: DecompressPointer r3
    //     0x543088: add             x3, x3, HEAP, lsl #32
    // 0x54308c: mov             x1, x3
    // 0x543090: stur            x3, [fp, #-0x18]
    // 0x543094: r2 = 40
    //     0x543094: movz            x2, #0x28
    // 0x543098: r0 = _getValueOrData()
    //     0x543098: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54309c: mov             x1, x0
    // 0x5430a0: ldur            x0, [fp, #-0x18]
    // 0x5430a4: LoadField: r2 = r0->field_f
    //     0x5430a4: ldur            w2, [x0, #0xf]
    // 0x5430a8: DecompressPointer r2
    //     0x5430a8: add             x2, x2, HEAP, lsl #32
    // 0x5430ac: cmp             w2, w1
    // 0x5430b0: b.ne            #0x5430bc
    // 0x5430b4: r0 = Null
    //     0x5430b4: mov             x0, NULL
    // 0x5430b8: b               #0x5430c0
    // 0x5430bc: mov             x0, x1
    // 0x5430c0: stur            x0, [fp, #-0x18]
    // 0x5430c4: cmp             w0, NULL
    // 0x5430c8: b.eq            #0x5431a4
    // 0x5430cc: r0 = Boost()
    //     0x5430cc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x5430d0: mov             x1, x0
    // 0x5430d4: r0 = Instance_CustomNum
    //     0x5430d4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x5430d8: ldr             x0, [x0, #0xa70]
    // 0x5430dc: StoreField: r1->field_7 = r0
    //     0x5430dc: stur            w0, [x1, #7]
    // 0x5430e0: r4 = Instance_CustomNum
    //     0x5430e0: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a720] Obj!CustomNum@82b2b1
    //     0x5430e4: ldr             x4, [x4, #0x720]
    // 0x5430e8: StoreField: r1->field_b = r4
    //     0x5430e8: stur            w4, [x1, #0xb]
    // 0x5430ec: StoreField: r1->field_f = r0
    //     0x5430ec: stur            w0, [x1, #0xf]
    // 0x5430f0: StoreField: r1->field_13 = r0
    //     0x5430f0: stur            w0, [x1, #0x13]
    // 0x5430f4: mov             x3, x1
    // 0x5430f8: ldur            x1, [fp, #-8]
    // 0x5430fc: r2 = 8
    //     0x5430fc: movz            x2, #0x8
    // 0x543100: r0 = []=()
    //     0x543100: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x543104: ldur            x0, [fp, #-0x18]
    // 0x543108: r1 = LoadInt32Instr(r0)
    //     0x543108: sbfx            x1, x0, #1, #0x1f
    //     0x54310c: tbz             w0, #0, #0x543114
    //     0x543110: ldur            x1, [x0, #7]
    // 0x543114: stur            x1, [fp, #-0x28]
    // 0x543118: cmp             x1, #1
    // 0x54311c: b.le            #0x5431a4
    // 0x543120: r0 = Boost()
    //     0x543120: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543124: mov             x1, x0
    // 0x543128: r0 = Instance_CustomNum
    //     0x543128: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54312c: ldr             x0, [x0, #0xa70]
    // 0x543130: StoreField: r1->field_7 = r0
    //     0x543130: stur            w0, [x1, #7]
    // 0x543134: StoreField: r1->field_b = r0
    //     0x543134: stur            w0, [x1, #0xb]
    // 0x543138: r2 = Instance_CustomNum
    //     0x543138: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a728] Obj!CustomNum@829041
    //     0x54313c: ldr             x2, [x2, #0x728]
    // 0x543140: StoreField: r1->field_f = r2
    //     0x543140: stur            w2, [x1, #0xf]
    // 0x543144: StoreField: r1->field_13 = r0
    //     0x543144: stur            w0, [x1, #0x13]
    // 0x543148: mov             x3, x1
    // 0x54314c: ldur            x1, [fp, #-8]
    // 0x543150: r2 = 6
    //     0x543150: movz            x2, #0x6
    // 0x543154: r0 = []=()
    //     0x543154: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x543158: ldur            x0, [fp, #-0x28]
    // 0x54315c: cmp             x0, #2
    // 0x543160: b.le            #0x5431a4
    // 0x543164: r0 = Boost()
    //     0x543164: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543168: r1 = Instance_CustomNum
    //     0x543168: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54316c: ldr             x1, [x1, #0xa70]
    // 0x543170: StoreField: r0->field_7 = r1
    //     0x543170: stur            w1, [x0, #7]
    // 0x543174: StoreField: r0->field_b = r1
    //     0x543174: stur            w1, [x0, #0xb]
    // 0x543178: r2 = Instance_CustomNum
    //     0x543178: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a730] Obj!CustomNum@82b2a1
    //     0x54317c: ldr             x2, [x2, #0x730]
    // 0x543180: StoreField: r0->field_f = r2
    //     0x543180: stur            w2, [x0, #0xf]
    // 0x543184: StoreField: r0->field_13 = r1
    //     0x543184: stur            w1, [x0, #0x13]
    // 0x543188: r16 = <int?>
    //     0x543188: ldr             x16, [PP, #0x4188]  ; [pp+0x4188] TypeArguments: <int?>
    // 0x54318c: ldur            lr, [fp, #-8]
    // 0x543190: stp             lr, x16, [SP, #0x10]
    // 0x543194: r3 = 6
    //     0x543194: movz            x3, #0x6
    // 0x543198: stp             x0, x3, [SP]
    // 0x54319c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x54319c: ldr             x4, [PP, #0x460]  ; [pp+0x460] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x5431a0: r0 = AddOrMerge.addOrMerge()
    //     0x5431a0: bl              #0x543c18  ; [package:pretentious/fragment/lib/Data/Boost.dart] ::AddOrMerge.addOrMerge
    // 0x5431a4: ldur            x0, [fp, #-0x10]
    // 0x5431a8: LoadField: r3 = r0->field_43
    //     0x5431a8: ldur            w3, [x0, #0x43]
    // 0x5431ac: DecompressPointer r3
    //     0x5431ac: add             x3, x3, HEAP, lsl #32
    // 0x5431b0: mov             x1, x3
    // 0x5431b4: stur            x3, [fp, #-0x18]
    // 0x5431b8: r2 = 42
    //     0x5431b8: movz            x2, #0x2a
    // 0x5431bc: r0 = _getValueOrData()
    //     0x5431bc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5431c0: mov             x1, x0
    // 0x5431c4: ldur            x0, [fp, #-0x18]
    // 0x5431c8: LoadField: r2 = r0->field_f
    //     0x5431c8: ldur            w2, [x0, #0xf]
    // 0x5431cc: DecompressPointer r2
    //     0x5431cc: add             x2, x2, HEAP, lsl #32
    // 0x5431d0: cmp             w2, w1
    // 0x5431d4: b.ne            #0x5431e0
    // 0x5431d8: r0 = Null
    //     0x5431d8: mov             x0, NULL
    // 0x5431dc: b               #0x5431e4
    // 0x5431e0: mov             x0, x1
    // 0x5431e4: stur            x0, [fp, #-0x18]
    // 0x5431e8: cmp             w0, NULL
    // 0x5431ec: b.eq            #0x5432c8
    // 0x5431f0: r0 = Boost()
    //     0x5431f0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x5431f4: mov             x1, x0
    // 0x5431f8: r0 = Instance_CustomNum
    //     0x5431f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x5431fc: ldr             x0, [x0, #0xa70]
    // 0x543200: StoreField: r1->field_7 = r0
    //     0x543200: stur            w0, [x1, #7]
    // 0x543204: r2 = Instance_CustomNum
    //     0x543204: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a720] Obj!CustomNum@82b2b1
    //     0x543208: ldr             x2, [x2, #0x720]
    // 0x54320c: StoreField: r1->field_b = r2
    //     0x54320c: stur            w2, [x1, #0xb]
    // 0x543210: StoreField: r1->field_f = r0
    //     0x543210: stur            w0, [x1, #0xf]
    // 0x543214: StoreField: r1->field_13 = r0
    //     0x543214: stur            w0, [x1, #0x13]
    // 0x543218: mov             x3, x1
    // 0x54321c: ldur            x1, [fp, #-8]
    // 0x543220: r2 = 14
    //     0x543220: movz            x2, #0xe
    // 0x543224: r0 = []=()
    //     0x543224: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x543228: ldur            x0, [fp, #-0x18]
    // 0x54322c: r1 = LoadInt32Instr(r0)
    //     0x54322c: sbfx            x1, x0, #1, #0x1f
    //     0x543230: tbz             w0, #0, #0x543238
    //     0x543234: ldur            x1, [x0, #7]
    // 0x543238: stur            x1, [fp, #-0x28]
    // 0x54323c: cmp             x1, #1
    // 0x543240: b.le            #0x5432c8
    // 0x543244: r0 = Boost()
    //     0x543244: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543248: mov             x1, x0
    // 0x54324c: r0 = Instance_CustomNum
    //     0x54324c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543250: ldr             x0, [x0, #0xa70]
    // 0x543254: StoreField: r1->field_7 = r0
    //     0x543254: stur            w0, [x1, #7]
    // 0x543258: StoreField: r1->field_b = r0
    //     0x543258: stur            w0, [x1, #0xb]
    // 0x54325c: r4 = Instance_CustomNum
    //     0x54325c: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a738] Obj!CustomNum@82b291
    //     0x543260: ldr             x4, [x4, #0x738]
    // 0x543264: StoreField: r1->field_f = r4
    //     0x543264: stur            w4, [x1, #0xf]
    // 0x543268: StoreField: r1->field_13 = r0
    //     0x543268: stur            w0, [x1, #0x13]
    // 0x54326c: mov             x3, x1
    // 0x543270: ldur            x1, [fp, #-8]
    // 0x543274: r2 = 4
    //     0x543274: movz            x2, #0x4
    // 0x543278: r0 = []=()
    //     0x543278: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x54327c: ldur            x0, [fp, #-0x28]
    // 0x543280: cmp             x0, #2
    // 0x543284: b.le            #0x5432c8
    // 0x543288: r0 = Boost()
    //     0x543288: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x54328c: r1 = Instance_CustomNum
    //     0x54328c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543290: ldr             x1, [x1, #0xa70]
    // 0x543294: StoreField: r0->field_7 = r1
    //     0x543294: stur            w1, [x0, #7]
    // 0x543298: StoreField: r0->field_b = r1
    //     0x543298: stur            w1, [x0, #0xb]
    // 0x54329c: r2 = Instance_CustomNum
    //     0x54329c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a730] Obj!CustomNum@82b2a1
    //     0x5432a0: ldr             x2, [x2, #0x730]
    // 0x5432a4: StoreField: r0->field_f = r2
    //     0x5432a4: stur            w2, [x0, #0xf]
    // 0x5432a8: StoreField: r0->field_13 = r1
    //     0x5432a8: stur            w1, [x0, #0x13]
    // 0x5432ac: r16 = <int?>
    //     0x5432ac: ldr             x16, [PP, #0x4188]  ; [pp+0x4188] TypeArguments: <int?>
    // 0x5432b0: ldur            lr, [fp, #-8]
    // 0x5432b4: stp             lr, x16, [SP, #0x10]
    // 0x5432b8: r3 = 5
    //     0x5432b8: movz            x3, #0x5
    // 0x5432bc: stp             x0, x3, [SP]
    // 0x5432c0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x5432c0: ldr             x4, [PP, #0x460]  ; [pp+0x460] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x5432c4: r0 = AddOrMerge.addOrMerge()
    //     0x5432c4: bl              #0x543c18  ; [package:pretentious/fragment/lib/Data/Boost.dart] ::AddOrMerge.addOrMerge
    // 0x5432c8: ldur            x0, [fp, #-0x10]
    // 0x5432cc: LoadField: r3 = r0->field_43
    //     0x5432cc: ldur            w3, [x0, #0x43]
    // 0x5432d0: DecompressPointer r3
    //     0x5432d0: add             x3, x3, HEAP, lsl #32
    // 0x5432d4: mov             x1, x3
    // 0x5432d8: stur            x3, [fp, #-0x18]
    // 0x5432dc: r2 = 44
    //     0x5432dc: movz            x2, #0x2c
    // 0x5432e0: r0 = _getValueOrData()
    //     0x5432e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5432e4: mov             x1, x0
    // 0x5432e8: ldur            x0, [fp, #-0x18]
    // 0x5432ec: LoadField: r2 = r0->field_f
    //     0x5432ec: ldur            w2, [x0, #0xf]
    // 0x5432f0: DecompressPointer r2
    //     0x5432f0: add             x2, x2, HEAP, lsl #32
    // 0x5432f4: cmp             w2, w1
    // 0x5432f8: b.ne            #0x543304
    // 0x5432fc: r0 = Null
    //     0x5432fc: mov             x0, NULL
    // 0x543300: b               #0x543308
    // 0x543304: mov             x0, x1
    // 0x543308: stur            x0, [fp, #-0x18]
    // 0x54330c: cmp             w0, NULL
    // 0x543310: b.eq            #0x5433ec
    // 0x543314: r0 = Boost()
    //     0x543314: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543318: mov             x1, x0
    // 0x54331c: r0 = Instance_CustomNum
    //     0x54331c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543320: ldr             x0, [x0, #0xa70]
    // 0x543324: StoreField: r1->field_7 = r0
    //     0x543324: stur            w0, [x1, #7]
    // 0x543328: StoreField: r1->field_b = r0
    //     0x543328: stur            w0, [x1, #0xb]
    // 0x54332c: r4 = Instance_CustomNum
    //     0x54332c: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a738] Obj!CustomNum@82b291
    //     0x543330: ldr             x4, [x4, #0x738]
    // 0x543334: StoreField: r1->field_f = r4
    //     0x543334: stur            w4, [x1, #0xf]
    // 0x543338: StoreField: r1->field_13 = r0
    //     0x543338: stur            w0, [x1, #0x13]
    // 0x54333c: mov             x3, x1
    // 0x543340: ldur            x1, [fp, #-8]
    // 0x543344: r2 = 10
    //     0x543344: movz            x2, #0xa
    // 0x543348: r0 = []=()
    //     0x543348: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x54334c: ldur            x0, [fp, #-0x18]
    // 0x543350: r1 = LoadInt32Instr(r0)
    //     0x543350: sbfx            x1, x0, #1, #0x1f
    //     0x543354: tbz             w0, #0, #0x54335c
    //     0x543358: ldur            x1, [x0, #7]
    // 0x54335c: stur            x1, [fp, #-0x28]
    // 0x543360: cmp             x1, #1
    // 0x543364: b.le            #0x5433ec
    // 0x543368: r0 = Boost()
    //     0x543368: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x54336c: mov             x1, x0
    // 0x543370: r0 = Instance_CustomNum
    //     0x543370: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543374: ldr             x0, [x0, #0xa70]
    // 0x543378: StoreField: r1->field_7 = r0
    //     0x543378: stur            w0, [x1, #7]
    // 0x54337c: StoreField: r1->field_b = r0
    //     0x54337c: stur            w0, [x1, #0xb]
    // 0x543380: r2 = Instance_CustomNum
    //     0x543380: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a738] Obj!CustomNum@82b291
    //     0x543384: ldr             x2, [x2, #0x738]
    // 0x543388: StoreField: r1->field_f = r2
    //     0x543388: stur            w2, [x1, #0xf]
    // 0x54338c: StoreField: r1->field_13 = r0
    //     0x54338c: stur            w0, [x1, #0x13]
    // 0x543390: mov             x3, x1
    // 0x543394: ldur            x1, [fp, #-8]
    // 0x543398: r2 = 12
    //     0x543398: movz            x2, #0xc
    // 0x54339c: r0 = []=()
    //     0x54339c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5433a0: ldur            x0, [fp, #-0x28]
    // 0x5433a4: cmp             x0, #2
    // 0x5433a8: b.le            #0x5433ec
    // 0x5433ac: r0 = Boost()
    //     0x5433ac: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x5433b0: r1 = Instance_CustomNum
    //     0x5433b0: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x5433b4: ldr             x1, [x1, #0xa70]
    // 0x5433b8: StoreField: r0->field_7 = r1
    //     0x5433b8: stur            w1, [x0, #7]
    // 0x5433bc: StoreField: r0->field_b = r1
    //     0x5433bc: stur            w1, [x0, #0xb]
    // 0x5433c0: r2 = Instance_CustomNum
    //     0x5433c0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a730] Obj!CustomNum@82b2a1
    //     0x5433c4: ldr             x2, [x2, #0x730]
    // 0x5433c8: StoreField: r0->field_f = r2
    //     0x5433c8: stur            w2, [x0, #0xf]
    // 0x5433cc: StoreField: r0->field_13 = r1
    //     0x5433cc: stur            w1, [x0, #0x13]
    // 0x5433d0: r16 = <int?>
    //     0x5433d0: ldr             x16, [PP, #0x4188]  ; [pp+0x4188] TypeArguments: <int?>
    // 0x5433d4: ldur            lr, [fp, #-8]
    // 0x5433d8: stp             lr, x16, [SP, #0x10]
    // 0x5433dc: r2 = 3
    //     0x5433dc: movz            x2, #0x3
    // 0x5433e0: stp             x0, x2, [SP]
    // 0x5433e4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x5433e4: ldr             x4, [PP, #0x460]  ; [pp+0x460] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x5433e8: r0 = AddOrMerge.addOrMerge()
    //     0x5433e8: bl              #0x543c18  ; [package:pretentious/fragment/lib/Data/Boost.dart] ::AddOrMerge.addOrMerge
    // 0x5433ec: ldur            x0, [fp, #-0x10]
    // 0x5433f0: LoadField: r1 = r0->field_43
    //     0x5433f0: ldur            w1, [x0, #0x43]
    // 0x5433f4: DecompressPointer r1
    //     0x5433f4: add             x1, x1, HEAP, lsl #32
    // 0x5433f8: r2 = 2
    //     0x5433f8: movz            x2, #0x2
    // 0x5433fc: r0 = containsKey()
    //     0x5433fc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x543400: tbnz            w0, #4, #0x543ad8
    // 0x543404: ldur            x0, [fp, #-0x10]
    // 0x543408: LoadField: r4 = r0->field_47
    //     0x543408: ldur            w4, [x0, #0x47]
    // 0x54340c: DecompressPointer r4
    //     0x54340c: add             x4, x4, HEAP, lsl #32
    // 0x543410: stur            x4, [fp, #-0x18]
    // 0x543414: LoadField: r2 = r4->field_7
    //     0x543414: ldur            w2, [x4, #7]
    // 0x543418: DecompressPointer r2
    //     0x543418: add             x2, x2, HEAP, lsl #32
    // 0x54341c: r1 = Null
    //     0x54341c: mov             x1, NULL
    // 0x543420: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x543420: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x543424: r30 = InstantiateTypeArgumentsStub
    //     0x543424: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x543428: LoadField: r30 = r30->field_7
    //     0x543428: ldur            lr, [lr, #7]
    // 0x54342c: blr             lr
    // 0x543430: mov             x1, x0
    // 0x543434: r0 = _CompactEntriesIterable()
    //     0x543434: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x543438: mov             x1, x0
    // 0x54343c: ldur            x0, [fp, #-0x18]
    // 0x543440: StoreField: r1->field_b = r0
    //     0x543440: stur            w0, [x1, #0xb]
    // 0x543444: r0 = iterator()
    //     0x543444: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x543448: stur            x0, [fp, #-0x18]
    // 0x54344c: ldur            x2, [fp, #-0x10]
    // 0x543450: ldur            x3, [fp, #-8]
    // 0x543454: CheckStackOverflow
    //     0x543454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x543458: cmp             SP, x16
    //     0x54345c: b.ls            #0x543afc
    // 0x543460: mov             x1, x0
    // 0x543464: r0 = moveNext()
    //     0x543464: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x543468: tbnz            w0, #4, #0x543ad8
    // 0x54346c: ldur            x0, [fp, #-0x18]
    // 0x543470: LoadField: r3 = r0->field_2b
    //     0x543470: ldur            w3, [x0, #0x2b]
    // 0x543474: DecompressPointer r3
    //     0x543474: add             x3, x3, HEAP, lsl #32
    // 0x543478: stur            x3, [fp, #-0x30]
    // 0x54347c: cmp             w3, NULL
    // 0x543480: b.eq            #0x543ae8
    // 0x543484: ldur            x4, [fp, #-8]
    // 0x543488: LoadField: r5 = r3->field_b
    //     0x543488: ldur            w5, [x3, #0xb]
    // 0x54348c: DecompressPointer r5
    //     0x54348c: add             x5, x5, HEAP, lsl #32
    // 0x543490: mov             x1, x4
    // 0x543494: mov             x2, x5
    // 0x543498: stur            x5, [fp, #-0x20]
    // 0x54349c: r0 = _getValueOrData()
    //     0x54349c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5434a0: mov             x1, x0
    // 0x5434a4: ldur            x0, [fp, #-8]
    // 0x5434a8: LoadField: r2 = r0->field_f
    //     0x5434a8: ldur            w2, [x0, #0xf]
    // 0x5434ac: DecompressPointer r2
    //     0x5434ac: add             x2, x2, HEAP, lsl #32
    // 0x5434b0: cmp             w2, w1
    // 0x5434b4: b.ne            #0x5434c0
    // 0x5434b8: r3 = Null
    //     0x5434b8: mov             x3, NULL
    // 0x5434bc: b               #0x5434c4
    // 0x5434c0: mov             x3, x1
    // 0x5434c4: stur            x3, [fp, #-0x40]
    // 0x5434c8: cmp             w3, NULL
    // 0x5434cc: b.eq            #0x5437d8
    // 0x5434d0: ldur            x4, [fp, #-0x10]
    // 0x5434d4: LoadField: r5 = r4->field_43
    //     0x5434d4: ldur            w5, [x4, #0x43]
    // 0x5434d8: DecompressPointer r5
    //     0x5434d8: add             x5, x5, HEAP, lsl #32
    // 0x5434dc: mov             x1, x5
    // 0x5434e0: stur            x5, [fp, #-0x38]
    // 0x5434e4: r2 = 2
    //     0x5434e4: movz            x2, #0x2
    // 0x5434e8: r0 = _getValueOrData()
    //     0x5434e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5434ec: mov             x1, x0
    // 0x5434f0: ldur            x0, [fp, #-0x38]
    // 0x5434f4: LoadField: r2 = r0->field_f
    //     0x5434f4: ldur            w2, [x0, #0xf]
    // 0x5434f8: DecompressPointer r2
    //     0x5434f8: add             x2, x2, HEAP, lsl #32
    // 0x5434fc: cmp             w2, w1
    // 0x543500: b.ne            #0x54350c
    // 0x543504: r0 = Null
    //     0x543504: mov             x0, NULL
    // 0x543508: b               #0x543510
    // 0x54350c: mov             x0, x1
    // 0x543510: cmp             w0, NULL
    // 0x543514: b.ne            #0x543520
    // 0x543518: r2 = 0
    //     0x543518: movz            x2, #0
    // 0x54351c: b               #0x543530
    // 0x543520: r1 = LoadInt32Instr(r0)
    //     0x543520: sbfx            x1, x0, #1, #0x1f
    //     0x543524: tbz             w0, #0, #0x54352c
    //     0x543528: ldur            x1, [x0, #7]
    // 0x54352c: mov             x2, x1
    // 0x543530: r0 = BoxInt64Instr(r2)
    //     0x543530: sbfiz           x0, x2, #1, #0x1f
    //     0x543534: cmp             x2, x0, asr #1
    //     0x543538: b.eq            #0x543544
    //     0x54353c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x543540: stur            x2, [x0, #7]
    // 0x543544: stur            x0, [fp, #-0x38]
    // 0x543548: tbnz            x2, #0x3f, #0x5435a8
    // 0x54354c: mov             x0, x2
    // 0x543550: r1 = 2
    //     0x543550: movz            x1, #0x2
    // 0x543554: r2 = 1
    //     0x543554: movz            x2, #0x1
    // 0x543558: CheckStackOverflow
    //     0x543558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54355c: cmp             SP, x16
    //     0x543560: b.ls            #0x543b04
    // 0x543564: cbz             x0, #0x54358c
    // 0x543568: branchIfSmi(r0, 0x543574)
    //     0x543568: tbz             w0, #0, #0x543574
    // 0x54356c: mul             x3, x2, x1
    // 0x543570: mov             x2, x3
    // 0x543574: asr             x3, x0, #1
    // 0x543578: cbz             x3, #0x543584
    // 0x54357c: mul             x4, x1, x1
    // 0x543580: mov             x1, x4
    // 0x543584: mov             x0, x3
    // 0x543588: b               #0x543558
    // 0x54358c: r0 = BoxInt64Instr(r2)
    //     0x54358c: sbfiz           x0, x2, #1, #0x1f
    //     0x543590: cmp             x2, x0, asr #1
    //     0x543594: b.eq            #0x5435a0
    //     0x543598: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54359c: stur            x2, [x0, #7]
    // 0x5435a0: mov             x1, x0
    // 0x5435a4: b               #0x5436fc
    // 0x5435a8: r16 = 4
    //     0x5435a8: movz            x16, #0x4
    // 0x5435ac: stp             x16, NULL, [SP]
    // 0x5435b0: r0 = _Double.fromInteger()
    //     0x5435b0: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x5435b4: mov             x1, x0
    // 0x5435b8: ldur            x0, [fp, #-0x38]
    // 0x5435bc: stur            x1, [fp, #-0x48]
    // 0x5435c0: r2 = 60
    //     0x5435c0: movz            x2, #0x3c
    // 0x5435c4: branchIfSmi(r0, 0x5435d0)
    //     0x5435c4: tbz             w0, #0, #0x5435d0
    // 0x5435c8: r2 = LoadClassIdInstr(r0)
    //     0x5435c8: ldur            x2, [x0, #-1]
    //     0x5435cc: ubfx            x2, x2, #0xc, #0x14
    // 0x5435d0: str             x0, [SP]
    // 0x5435d4: mov             x0, x2
    // 0x5435d8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5435d8: sub             lr, x0, #1, lsl #12
    //     0x5435dc: ldr             lr, [x21, lr, lsl #3]
    //     0x5435e0: blr             lr
    // 0x5435e4: mov             x1, x0
    // 0x5435e8: ldur            x0, [fp, #-0x48]
    // 0x5435ec: LoadField: d0 = r0->field_7
    //     0x5435ec: ldur            d0, [x0, #7]
    // 0x5435f0: LoadField: d1 = r1->field_7
    //     0x5435f0: ldur            d1, [x1, #7]
    // 0x5435f4: d30 = 0.000000
    //     0x5435f4: fmov            d30, d0
    // 0x5435f8: d0 = 1.000000
    //     0x5435f8: fmov            d0, #1.00000000
    // 0x5435fc: fcmp            d1, #0.0
    // 0x543600: b.vs            #0x543644
    // 0x543604: b.eq            #0x5436cc
    // 0x543608: fcmp            d1, d0
    // 0x54360c: b.eq            #0x543634
    // 0x543610: d31 = 2.000000
    //     0x543610: fmov            d31, #2.00000000
    // 0x543614: fcmp            d1, d31
    // 0x543618: b.eq            #0x54363c
    // 0x54361c: d31 = 3.000000
    //     0x54361c: fmov            d31, #3.00000000
    // 0x543620: fcmp            d1, d31
    // 0x543624: b.ne            #0x543644
    // 0x543628: fmul            d0, d30, d30
    // 0x54362c: fmul            d0, d0, d30
    // 0x543630: b               #0x5436cc
    // 0x543634: d0 = 0.000000
    //     0x543634: fmov            d0, d30
    // 0x543638: b               #0x5436cc
    // 0x54363c: fmul            d0, d30, d30
    // 0x543640: b               #0x5436cc
    // 0x543644: fcmp            d30, d0
    // 0x543648: b.vs            #0x543658
    // 0x54364c: b.eq            #0x5436cc
    // 0x543650: fcmp            d30, d1
    // 0x543654: b.vc            #0x543664
    // 0x543658: d0 = nan
    //     0x543658: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x54365c: ldr             d0, [x17, #0xe48]
    // 0x543660: b               #0x5436cc
    // 0x543664: d0 = -inf
    //     0x543664: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x543668: fcmp            d30, d0
    // 0x54366c: b.eq            #0x543694
    // 0x543670: d0 = 0.500000
    //     0x543670: fmov            d0, #0.50000000
    // 0x543674: fcmp            d1, d0
    // 0x543678: b.ne            #0x543694
    // 0x54367c: fcmp            d30, #0.0
    // 0x543680: b.eq            #0x54368c
    // 0x543684: fsqrt           d0, d30
    // 0x543688: b               #0x5436cc
    // 0x54368c: d0 = 0.000000
    //     0x54368c: eor             v0.16b, v0.16b, v0.16b
    // 0x543690: b               #0x5436cc
    // 0x543694: d0 = 0.000000
    //     0x543694: fmov            d0, d30
    // 0x543698: stp             fp, lr, [SP, #-0x10]!
    // 0x54369c: mov             fp, SP
    // 0x5436a0: CallRuntime_LibcPow(double, double) -> double
    //     0x5436a0: and             SP, SP, #0xfffffffffffffff0
    //     0x5436a4: mov             sp, SP
    //     0x5436a8: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x5436ac: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5436b0: blr             x16
    //     0x5436b4: movz            x16, #0x8
    //     0x5436b8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5436bc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5436c0: sub             sp, x16, #1, lsl #12
    //     0x5436c4: mov             SP, fp
    //     0x5436c8: ldp             fp, lr, [SP], #0x10
    // 0x5436cc: r0 = inline_Allocate_Double()
    //     0x5436cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5436d0: add             x0, x0, #0x10
    //     0x5436d4: cmp             x1, x0
    //     0x5436d8: b.ls            #0x543b0c
    //     0x5436dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x5436e0: sub             x0, x0, #0xf
    //     0x5436e4: movz            x1, #0xe19c
    //     0x5436e8: movk            x1, #0x3, lsl #16
    //     0x5436ec: stur            x1, [x0, #-1]
    // 0x5436f0: dmb             ishst
    // 0x5436f4: StoreField: r0->field_7 = d0
    //     0x5436f4: stur            d0, [x0, #7]
    // 0x5436f8: mov             x1, x0
    // 0x5436fc: ldur            x0, [fp, #-0x30]
    // 0x543700: r16 = 0.010000
    //     0x543700: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x543704: ldr             x16, [x16, #0xaa0]
    // 0x543708: stp             x1, x16, [SP]
    // 0x54370c: r0 = *()
    //     0x54370c: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x543710: mov             x1, x0
    // 0x543714: ldur            x0, [fp, #-0x30]
    // 0x543718: LoadField: r2 = r0->field_f
    //     0x543718: ldur            w2, [x0, #0xf]
    // 0x54371c: DecompressPointer r2
    //     0x54371c: add             x2, x2, HEAP, lsl #32
    // 0x543720: stp             x2, x1, [SP]
    // 0x543724: r0 = *()
    //     0x543724: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x543728: mov             x2, x0
    // 0x54372c: r1 = Null
    //     0x54372c: mov             x1, NULL
    // 0x543730: r0 = CustomNum()
    //     0x543730: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x543734: mov             x2, x0
    // 0x543738: r1 = Instance_CustomNum
    //     0x543738: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54373c: ldr             x1, [x1, #0xa70]
    // 0x543740: r0 = add()
    //     0x543740: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x543744: stur            x0, [fp, #-0x38]
    // 0x543748: r0 = Boost()
    //     0x543748: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x54374c: mov             x1, x0
    // 0x543750: r0 = Instance_CustomNum
    //     0x543750: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543754: ldr             x0, [x0, #0xa70]
    // 0x543758: StoreField: r1->field_7 = r0
    //     0x543758: stur            w0, [x1, #7]
    // 0x54375c: StoreField: r1->field_b = r0
    //     0x54375c: stur            w0, [x1, #0xb]
    // 0x543760: ldur            x2, [fp, #-0x38]
    // 0x543764: StoreField: r1->field_f = r2
    //     0x543764: stur            w2, [x1, #0xf]
    // 0x543768: StoreField: r1->field_13 = r0
    //     0x543768: stur            w0, [x1, #0x13]
    // 0x54376c: mov             x2, x1
    // 0x543770: ldur            x1, [fp, #-0x40]
    // 0x543774: r0 = *()
    //     0x543774: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x543778: mov             x3, x0
    // 0x54377c: ldur            x0, [fp, #-0x20]
    // 0x543780: r2 = Null
    //     0x543780: mov             x2, NULL
    // 0x543784: r1 = Null
    //     0x543784: mov             x1, NULL
    // 0x543788: stur            x3, [fp, #-0x38]
    // 0x54378c: branchIfSmi(r0, 0x5437b4)
    //     0x54378c: tbz             w0, #0, #0x5437b4
    // 0x543790: r4 = LoadClassIdInstr(r0)
    //     0x543790: ldur            x4, [x0, #-1]
    //     0x543794: ubfx            x4, x4, #0xc, #0x14
    // 0x543798: sub             x4, x4, #0x3c
    // 0x54379c: cmp             x4, #1
    // 0x5437a0: b.ls            #0x5437b4
    // 0x5437a4: r8 = int?
    //     0x5437a4: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x5437a8: r3 = Null
    //     0x5437a8: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a740] Null
    //     0x5437ac: ldr             x3, [x3, #0x740]
    // 0x5437b0: r0 = int?()
    //     0x5437b0: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x5437b4: ldur            x1, [fp, #-8]
    // 0x5437b8: ldur            x2, [fp, #-0x20]
    // 0x5437bc: r0 = _hashCode()
    //     0x5437bc: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x5437c0: ldur            x1, [fp, #-8]
    // 0x5437c4: ldur            x2, [fp, #-0x20]
    // 0x5437c8: ldur            x3, [fp, #-0x38]
    // 0x5437cc: mov             x5, x0
    // 0x5437d0: r0 = _set()
    //     0x5437d0: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x5437d4: b               #0x543ad0
    // 0x5437d8: ldur            x3, [fp, #-0x10]
    // 0x5437dc: ldur            x0, [fp, #-0x30]
    // 0x5437e0: LoadField: r4 = r3->field_43
    //     0x5437e0: ldur            w4, [x3, #0x43]
    // 0x5437e4: DecompressPointer r4
    //     0x5437e4: add             x4, x4, HEAP, lsl #32
    // 0x5437e8: mov             x1, x4
    // 0x5437ec: stur            x4, [fp, #-0x38]
    // 0x5437f0: r2 = 2
    //     0x5437f0: movz            x2, #0x2
    // 0x5437f4: r0 = _getValueOrData()
    //     0x5437f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5437f8: mov             x1, x0
    // 0x5437fc: ldur            x0, [fp, #-0x38]
    // 0x543800: LoadField: r2 = r0->field_f
    //     0x543800: ldur            w2, [x0, #0xf]
    // 0x543804: DecompressPointer r2
    //     0x543804: add             x2, x2, HEAP, lsl #32
    // 0x543808: cmp             w2, w1
    // 0x54380c: b.ne            #0x543818
    // 0x543810: r0 = Null
    //     0x543810: mov             x0, NULL
    // 0x543814: b               #0x54381c
    // 0x543818: mov             x0, x1
    // 0x54381c: cmp             w0, NULL
    // 0x543820: b.ne            #0x54382c
    // 0x543824: r2 = 0
    //     0x543824: movz            x2, #0
    // 0x543828: b               #0x54383c
    // 0x54382c: r1 = LoadInt32Instr(r0)
    //     0x54382c: sbfx            x1, x0, #1, #0x1f
    //     0x543830: tbz             w0, #0, #0x543838
    //     0x543834: ldur            x1, [x0, #7]
    // 0x543838: mov             x2, x1
    // 0x54383c: r0 = BoxInt64Instr(r2)
    //     0x54383c: sbfiz           x0, x2, #1, #0x1f
    //     0x543840: cmp             x2, x0, asr #1
    //     0x543844: b.eq            #0x543850
    //     0x543848: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54384c: stur            x2, [x0, #7]
    // 0x543850: stur            x0, [fp, #-0x38]
    // 0x543854: tbnz            x2, #0x3f, #0x5438b4
    // 0x543858: mov             x0, x2
    // 0x54385c: r1 = 2
    //     0x54385c: movz            x1, #0x2
    // 0x543860: r2 = 1
    //     0x543860: movz            x2, #0x1
    // 0x543864: CheckStackOverflow
    //     0x543864: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x543868: cmp             SP, x16
    //     0x54386c: b.ls            #0x543b1c
    // 0x543870: cbz             x0, #0x543898
    // 0x543874: branchIfSmi(r0, 0x543880)
    //     0x543874: tbz             w0, #0, #0x543880
    // 0x543878: mul             x3, x2, x1
    // 0x54387c: mov             x2, x3
    // 0x543880: asr             x3, x0, #1
    // 0x543884: cbz             x3, #0x543890
    // 0x543888: mul             x4, x1, x1
    // 0x54388c: mov             x1, x4
    // 0x543890: mov             x0, x3
    // 0x543894: b               #0x543864
    // 0x543898: r0 = BoxInt64Instr(r2)
    //     0x543898: sbfiz           x0, x2, #1, #0x1f
    //     0x54389c: cmp             x2, x0, asr #1
    //     0x5438a0: b.eq            #0x5438ac
    //     0x5438a4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x5438a8: stur            x2, [x0, #7]
    // 0x5438ac: mov             x1, x0
    // 0x5438b0: b               #0x543a08
    // 0x5438b4: r16 = 4
    //     0x5438b4: movz            x16, #0x4
    // 0x5438b8: stp             x16, NULL, [SP]
    // 0x5438bc: r0 = _Double.fromInteger()
    //     0x5438bc: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x5438c0: mov             x1, x0
    // 0x5438c4: ldur            x0, [fp, #-0x38]
    // 0x5438c8: stur            x1, [fp, #-0x40]
    // 0x5438cc: r2 = 60
    //     0x5438cc: movz            x2, #0x3c
    // 0x5438d0: branchIfSmi(r0, 0x5438dc)
    //     0x5438d0: tbz             w0, #0, #0x5438dc
    // 0x5438d4: r2 = LoadClassIdInstr(r0)
    //     0x5438d4: ldur            x2, [x0, #-1]
    //     0x5438d8: ubfx            x2, x2, #0xc, #0x14
    // 0x5438dc: str             x0, [SP]
    // 0x5438e0: mov             x0, x2
    // 0x5438e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5438e4: sub             lr, x0, #1, lsl #12
    //     0x5438e8: ldr             lr, [x21, lr, lsl #3]
    //     0x5438ec: blr             lr
    // 0x5438f0: mov             x1, x0
    // 0x5438f4: ldur            x0, [fp, #-0x40]
    // 0x5438f8: LoadField: d0 = r0->field_7
    //     0x5438f8: ldur            d0, [x0, #7]
    // 0x5438fc: LoadField: d1 = r1->field_7
    //     0x5438fc: ldur            d1, [x1, #7]
    // 0x543900: d30 = 0.000000
    //     0x543900: fmov            d30, d0
    // 0x543904: d0 = 1.000000
    //     0x543904: fmov            d0, #1.00000000
    // 0x543908: fcmp            d1, #0.0
    // 0x54390c: b.vs            #0x543950
    // 0x543910: b.eq            #0x5439d8
    // 0x543914: fcmp            d1, d0
    // 0x543918: b.eq            #0x543940
    // 0x54391c: d31 = 2.000000
    //     0x54391c: fmov            d31, #2.00000000
    // 0x543920: fcmp            d1, d31
    // 0x543924: b.eq            #0x543948
    // 0x543928: d31 = 3.000000
    //     0x543928: fmov            d31, #3.00000000
    // 0x54392c: fcmp            d1, d31
    // 0x543930: b.ne            #0x543950
    // 0x543934: fmul            d0, d30, d30
    // 0x543938: fmul            d0, d0, d30
    // 0x54393c: b               #0x5439d8
    // 0x543940: d0 = 0.000000
    //     0x543940: fmov            d0, d30
    // 0x543944: b               #0x5439d8
    // 0x543948: fmul            d0, d30, d30
    // 0x54394c: b               #0x5439d8
    // 0x543950: fcmp            d30, d0
    // 0x543954: b.vs            #0x543964
    // 0x543958: b.eq            #0x5439d8
    // 0x54395c: fcmp            d30, d1
    // 0x543960: b.vc            #0x543970
    // 0x543964: d0 = nan
    //     0x543964: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x543968: ldr             d0, [x17, #0xe48]
    // 0x54396c: b               #0x5439d8
    // 0x543970: d0 = -inf
    //     0x543970: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x543974: fcmp            d30, d0
    // 0x543978: b.eq            #0x5439a0
    // 0x54397c: d0 = 0.500000
    //     0x54397c: fmov            d0, #0.50000000
    // 0x543980: fcmp            d1, d0
    // 0x543984: b.ne            #0x5439a0
    // 0x543988: fcmp            d30, #0.0
    // 0x54398c: b.eq            #0x543998
    // 0x543990: fsqrt           d0, d30
    // 0x543994: b               #0x5439d8
    // 0x543998: d0 = 0.000000
    //     0x543998: eor             v0.16b, v0.16b, v0.16b
    // 0x54399c: b               #0x5439d8
    // 0x5439a0: d0 = 0.000000
    //     0x5439a0: fmov            d0, d30
    // 0x5439a4: stp             fp, lr, [SP, #-0x10]!
    // 0x5439a8: mov             fp, SP
    // 0x5439ac: CallRuntime_LibcPow(double, double) -> double
    //     0x5439ac: and             SP, SP, #0xfffffffffffffff0
    //     0x5439b0: mov             sp, SP
    //     0x5439b4: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x5439b8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5439bc: blr             x16
    //     0x5439c0: movz            x16, #0x8
    //     0x5439c4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5439c8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5439cc: sub             sp, x16, #1, lsl #12
    //     0x5439d0: mov             SP, fp
    //     0x5439d4: ldp             fp, lr, [SP], #0x10
    // 0x5439d8: r0 = inline_Allocate_Double()
    //     0x5439d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5439dc: add             x0, x0, #0x10
    //     0x5439e0: cmp             x1, x0
    //     0x5439e4: b.ls            #0x543b24
    //     0x5439e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x5439ec: sub             x0, x0, #0xf
    //     0x5439f0: movz            x1, #0xe19c
    //     0x5439f4: movk            x1, #0x3, lsl #16
    //     0x5439f8: stur            x1, [x0, #-1]
    // 0x5439fc: dmb             ishst
    // 0x543a00: StoreField: r0->field_7 = d0
    //     0x543a00: stur            d0, [x0, #7]
    // 0x543a04: mov             x1, x0
    // 0x543a08: ldur            x0, [fp, #-0x30]
    // 0x543a0c: r16 = 0.010000
    //     0x543a0c: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x543a10: ldr             x16, [x16, #0xaa0]
    // 0x543a14: stp             x1, x16, [SP]
    // 0x543a18: r0 = *()
    //     0x543a18: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x543a1c: mov             x1, x0
    // 0x543a20: ldur            x0, [fp, #-0x30]
    // 0x543a24: LoadField: r2 = r0->field_f
    //     0x543a24: ldur            w2, [x0, #0xf]
    // 0x543a28: DecompressPointer r2
    //     0x543a28: add             x2, x2, HEAP, lsl #32
    // 0x543a2c: stp             x2, x1, [SP]
    // 0x543a30: r0 = *()
    //     0x543a30: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x543a34: mov             x2, x0
    // 0x543a38: r1 = Null
    //     0x543a38: mov             x1, NULL
    // 0x543a3c: r0 = CustomNum()
    //     0x543a3c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x543a40: mov             x2, x0
    // 0x543a44: r1 = Instance_CustomNum
    //     0x543a44: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543a48: ldr             x1, [x1, #0xa70]
    // 0x543a4c: r0 = add()
    //     0x543a4c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x543a50: stur            x0, [fp, #-0x30]
    // 0x543a54: r0 = Boost()
    //     0x543a54: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x543a58: mov             x4, x0
    // 0x543a5c: r3 = Instance_CustomNum
    //     0x543a5c: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x543a60: ldr             x3, [x3, #0xa70]
    // 0x543a64: stur            x4, [fp, #-0x38]
    // 0x543a68: StoreField: r4->field_7 = r3
    //     0x543a68: stur            w3, [x4, #7]
    // 0x543a6c: StoreField: r4->field_b = r3
    //     0x543a6c: stur            w3, [x4, #0xb]
    // 0x543a70: ldur            x0, [fp, #-0x30]
    // 0x543a74: StoreField: r4->field_f = r0
    //     0x543a74: stur            w0, [x4, #0xf]
    // 0x543a78: StoreField: r4->field_13 = r3
    //     0x543a78: stur            w3, [x4, #0x13]
    // 0x543a7c: ldur            x0, [fp, #-0x20]
    // 0x543a80: r2 = Null
    //     0x543a80: mov             x2, NULL
    // 0x543a84: r1 = Null
    //     0x543a84: mov             x1, NULL
    // 0x543a88: branchIfSmi(r0, 0x543ab0)
    //     0x543a88: tbz             w0, #0, #0x543ab0
    // 0x543a8c: r4 = LoadClassIdInstr(r0)
    //     0x543a8c: ldur            x4, [x0, #-1]
    //     0x543a90: ubfx            x4, x4, #0xc, #0x14
    // 0x543a94: sub             x4, x4, #0x3c
    // 0x543a98: cmp             x4, #1
    // 0x543a9c: b.ls            #0x543ab0
    // 0x543aa0: r8 = int?
    //     0x543aa0: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x543aa4: r3 = Null
    //     0x543aa4: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a750] Null
    //     0x543aa8: ldr             x3, [x3, #0x750]
    // 0x543aac: r0 = int?()
    //     0x543aac: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x543ab0: ldur            x1, [fp, #-8]
    // 0x543ab4: ldur            x2, [fp, #-0x20]
    // 0x543ab8: r0 = _hashCode()
    //     0x543ab8: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x543abc: ldur            x1, [fp, #-8]
    // 0x543ac0: ldur            x2, [fp, #-0x20]
    // 0x543ac4: ldur            x3, [fp, #-0x38]
    // 0x543ac8: mov             x5, x0
    // 0x543acc: r0 = _set()
    //     0x543acc: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x543ad0: ldur            x0, [fp, #-0x18]
    // 0x543ad4: b               #0x54344c
    // 0x543ad8: r0 = Null
    //     0x543ad8: mov             x0, NULL
    // 0x543adc: LeaveFrame
    //     0x543adc: mov             SP, fp
    //     0x543ae0: ldp             fp, lr, [SP], #0x10
    // 0x543ae4: ret
    //     0x543ae4: ret             
    // 0x543ae8: r0 = noElement()
    //     0x543ae8: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x543aec: r0 = Throw()
    //     0x543aec: bl              #0x825670  ; ThrowStub
    // 0x543af0: brk             #0
    // 0x543af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x543af4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x543af8: b               #0x542eb4
    // 0x543afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x543afc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x543b00: b               #0x543460
    // 0x543b04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x543b04: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x543b08: b               #0x543564
    // 0x543b0c: SaveReg d0
    //     0x543b0c: str             q0, [SP, #-0x10]!
    // 0x543b10: r0 = AllocateDouble()
    //     0x543b10: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x543b14: RestoreReg d0
    //     0x543b14: ldr             q0, [SP], #0x10
    // 0x543b18: b               #0x5436f4
    // 0x543b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x543b1c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x543b20: b               #0x543870
    // 0x543b24: SaveReg d0
    //     0x543b24: str             q0, [SP, #-0x10]!
    // 0x543b28: r0 = AllocateDouble()
    //     0x543b28: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x543b2c: RestoreReg d0
    //     0x543b2c: ldr             q0, [SP], #0x10
    // 0x543b30: b               #0x543a00
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55c53c, size: 0x40
    // 0x55c53c: EnterFrame
    //     0x55c53c: stp             fp, lr, [SP, #-0x10]!
    //     0x55c540: mov             fp, SP
    // 0x55c544: AllocStack(0x10)
    //     0x55c544: sub             SP, SP, #0x10
    // 0x55c548: CheckStackOverflow
    //     0x55c548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55c54c: cmp             SP, x16
    //     0x55c550: b.ls            #0x55c574
    // 0x55c554: r16 = <Chapter10Stat, CustomNum>
    //     0x55c554: add             x16, PP, #0x16, lsl #12  ; [pp+0x16720] TypeArguments: <Chapter10Stat, CustomNum>
    //     0x55c558: ldr             x16, [x16, #0x720]
    // 0x55c55c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x55c560: stp             lr, x16, [SP]
    // 0x55c564: r0 = Map._fromLiteral()
    //     0x55c564: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55c568: LeaveFrame
    //     0x55c568: mov             SP, fp
    //     0x55c56c: ldp             fp, lr, [SP], #0x10
    // 0x55c570: ret
    //     0x55c570: ret             
    // 0x55c574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c574: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c578: b               #0x55c554
  }
  _ build(/* No info */) {
    // ** addr: 0x692a30, size: 0x99c
    // 0x692a30: EnterFrame
    //     0x692a30: stp             fp, lr, [SP, #-0x10]!
    //     0x692a34: mov             fp, SP
    // 0x692a38: AllocStack(0x78)
    //     0x692a38: sub             SP, SP, #0x78
    // 0x692a3c: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x692a3c: mov             x0, x1
    //     0x692a40: stur            x1, [fp, #-8]
    //     0x692a44: stur            x2, [fp, #-0x10]
    // 0x692a48: CheckStackOverflow
    //     0x692a48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x692a4c: cmp             SP, x16
    //     0x692a50: b.ls            #0x6933b8
    // 0x692a54: r1 = 2
    //     0x692a54: movz            x1, #0x2
    // 0x692a58: r0 = AllocateContext()
    //     0x692a58: bl              #0x82637c  ; AllocateContextStub
    // 0x692a5c: mov             x3, x0
    // 0x692a60: ldur            x0, [fp, #-8]
    // 0x692a64: stur            x3, [fp, #-0x18]
    // 0x692a68: StoreField: r3->field_f = r0
    //     0x692a68: stur            w0, [x3, #0xf]
    // 0x692a6c: ldur            x1, [fp, #-0x10]
    // 0x692a70: StoreField: r3->field_13 = r1
    //     0x692a70: stur            w1, [x3, #0x13]
    // 0x692a74: LoadField: r4 = r0->field_37
    //     0x692a74: ldur            w4, [x0, #0x37]
    // 0x692a78: DecompressPointer r4
    //     0x692a78: add             x4, x4, HEAP, lsl #32
    // 0x692a7c: stur            x4, [fp, #-0x10]
    // 0x692a80: r1 = Function '<anonymous closure>':.
    //     0x692a80: add             x1, PP, #0x29, lsl #12  ; [pp+0x294d8] AnonymousClosure: (0x696370), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x692a84: ldr             x1, [x1, #0x4d8]
    // 0x692a88: r2 = Null
    //     0x692a88: mov             x2, NULL
    // 0x692a8c: r0 = AllocateClosure()
    //     0x692a8c: bl              #0x826750  ; AllocateClosureStub
    // 0x692a90: r1 = <Chapter10Stat>
    //     0x692a90: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x692a94: ldr             x1, [x1, #0xe80]
    // 0x692a98: stur            x0, [fp, #-0x20]
    // 0x692a9c: r0 = PrestigeButton()
    //     0x692a9c: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x692aa0: mov             x3, x0
    // 0x692aa4: ldur            x0, [fp, #-0x20]
    // 0x692aa8: stur            x3, [fp, #-0x28]
    // 0x692aac: StoreField: r3->field_1f = r0
    //     0x692aac: stur            w0, [x3, #0x1f]
    // 0x692ab0: r0 = Instance_Chapter10Stat
    //     0x692ab0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11748] Obj!Chapter10Stat@85fe41
    //     0x692ab4: ldr             x0, [x0, #0x748]
    // 0x692ab8: StoreField: r3->field_1b = r0
    //     0x692ab8: stur            w0, [x3, #0x1b]
    // 0x692abc: ldur            x2, [fp, #-8]
    // 0x692ac0: r1 = Function 'kernelUpgradePoints':.
    //     0x692ac0: add             x1, PP, #0x29, lsl #12  ; [pp+0x294e0] AnonymousClosure: (0x518ee0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x692ac4: ldr             x1, [x1, #0x4e0]
    // 0x692ac8: r0 = AllocateClosure()
    //     0x692ac8: bl              #0x826750  ; AllocateClosureStub
    // 0x692acc: mov             x1, x0
    // 0x692ad0: ldur            x0, [fp, #-0x28]
    // 0x692ad4: StoreField: r0->field_2f = r1
    //     0x692ad4: stur            w1, [x0, #0x2f]
    // 0x692ad8: ldur            x2, [fp, #-0x18]
    // 0x692adc: r1 = Function '<anonymous closure>':.
    //     0x692adc: add             x1, PP, #0x29, lsl #12  ; [pp+0x294e8] AnonymousClosure: (0x6949d8), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x692ae0: ldr             x1, [x1, #0x4e8]
    // 0x692ae4: r0 = AllocateClosure()
    //     0x692ae4: bl              #0x826750  ; AllocateClosureStub
    // 0x692ae8: mov             x1, x0
    // 0x692aec: ldur            x0, [fp, #-0x28]
    // 0x692af0: StoreField: r0->field_33 = r1
    //     0x692af0: stur            w1, [x0, #0x33]
    // 0x692af4: ldur            x1, [fp, #-0x10]
    // 0x692af8: ArrayStore: r0[0] = r1  ; List_4
    //     0x692af8: stur            w1, [x0, #0x17]
    // 0x692afc: r3 = Closure: (Chapter10Stat?) => String from Function 'humanName': static.
    //     0x692afc: add             x3, PP, #0x29, lsl #12  ; [pp+0x294f0] Closure: (Chapter10Stat?) => String from Function 'humanName': static. (0x248ed99e16c)
    //     0x692b00: ldr             x3, [x3, #0x4f0]
    // 0x692b04: StoreField: r0->field_43 = r3
    //     0x692b04: stur            w3, [x0, #0x43]
    // 0x692b08: ldur            x2, [fp, #-0x18]
    // 0x692b0c: r1 = Function '<anonymous closure>':.
    //     0x692b0c: add             x1, PP, #0x29, lsl #12  ; [pp+0x294f8] AnonymousClosure: (0x69490c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x692b10: ldr             x1, [x1, #0x4f8]
    // 0x692b14: r0 = AllocateClosure()
    //     0x692b14: bl              #0x826750  ; AllocateClosureStub
    // 0x692b18: mov             x1, x0
    // 0x692b1c: ldur            x0, [fp, #-0x28]
    // 0x692b20: StoreField: r0->field_37 = r1
    //     0x692b20: stur            w1, [x0, #0x37]
    // 0x692b24: r3 = "everything above"
    //     0x692b24: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x692b28: ldr             x3, [x3, #0x1b0]
    // 0x692b2c: StoreField: r0->field_3f = r3
    //     0x692b2c: stur            w3, [x0, #0x3f]
    // 0x692b30: r1 = Function '<anonymous closure>':.
    //     0x692b30: add             x1, PP, #0x29, lsl #12  ; [pp+0x29500] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x692b34: ldr             x1, [x1, #0x500]
    // 0x692b38: r2 = Null
    //     0x692b38: mov             x2, NULL
    // 0x692b3c: r0 = AllocateClosure()
    //     0x692b3c: bl              #0x826750  ; AllocateClosureStub
    // 0x692b40: mov             x1, x0
    // 0x692b44: ldur            x0, [fp, #-0x28]
    // 0x692b48: StoreField: r0->field_4b = r1
    //     0x692b48: stur            w1, [x0, #0x4b]
    // 0x692b4c: r3 = false
    //     0x692b4c: add             x3, NULL, #0x30  ; false
    // 0x692b50: StoreField: r0->field_f = r3
    //     0x692b50: stur            w3, [x0, #0xf]
    // 0x692b54: StoreField: r0->field_4f = r3
    //     0x692b54: stur            w3, [x0, #0x4f]
    // 0x692b58: ldur            x2, [fp, #-0x18]
    // 0x692b5c: r1 = Function '<anonymous closure>':.
    //     0x692b5c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29508] AnonymousClosure: (0x6947e0), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x692b60: ldr             x1, [x1, #0x508]
    // 0x692b64: r0 = AllocateClosure()
    //     0x692b64: bl              #0x826750  ; AllocateClosureStub
    // 0x692b68: mov             x1, x0
    // 0x692b6c: ldur            x0, [fp, #-0x28]
    // 0x692b70: StoreField: r0->field_27 = r1
    //     0x692b70: stur            w1, [x0, #0x27]
    // 0x692b74: r3 = false
    //     0x692b74: add             x3, NULL, #0x30  ; false
    // 0x692b78: StoreField: r0->field_2b = r3
    //     0x692b78: stur            w3, [x0, #0x2b]
    // 0x692b7c: StoreField: r0->field_53 = r3
    //     0x692b7c: stur            w3, [x0, #0x53]
    // 0x692b80: r4 = true
    //     0x692b80: add             x4, NULL, #0x20  ; true
    // 0x692b84: StoreField: r0->field_5b = r4
    //     0x692b84: stur            w4, [x0, #0x5b]
    // 0x692b88: r5 = "Gain"
    //     0x692b88: add             x5, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x692b8c: ldr             x5, [x5, #0x1b8]
    // 0x692b90: StoreField: r0->field_5f = r5
    //     0x692b90: stur            w5, [x0, #0x5f]
    // 0x692b94: r1 = Function '<anonymous closure>':.
    //     0x692b94: add             x1, PP, #0x29, lsl #12  ; [pp+0x29510] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x692b98: ldr             x1, [x1, #0x510]
    // 0x692b9c: r2 = Null
    //     0x692b9c: mov             x2, NULL
    // 0x692ba0: r0 = AllocateClosure()
    //     0x692ba0: bl              #0x826750  ; AllocateClosureStub
    // 0x692ba4: ldur            x2, [fp, #-0x28]
    // 0x692ba8: mov             x5, x0
    // 0x692bac: r1 = Null
    //     0x692bac: mov             x1, NULL
    // 0x692bb0: r3 = "Chapter 10 Prestige 1"
    //     0x692bb0: add             x3, PP, #0x29, lsl #12  ; [pp+0x29518] "Chapter 10 Prestige 1"
    //     0x692bb4: ldr             x3, [x3, #0x518]
    // 0x692bb8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x692bb8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x692bbc: r0 = IdleFragment()
    //     0x692bbc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x692bc0: mov             x2, x0
    // 0x692bc4: ldur            x0, [fp, #-8]
    // 0x692bc8: stur            x2, [fp, #-0x58]
    // 0x692bcc: LoadField: r3 = r0->field_2b
    //     0x692bcc: ldur            w3, [x0, #0x2b]
    // 0x692bd0: DecompressPointer r3
    //     0x692bd0: add             x3, x3, HEAP, lsl #32
    // 0x692bd4: stur            x3, [fp, #-0x50]
    // 0x692bd8: LoadField: r4 = r0->field_37
    //     0x692bd8: ldur            w4, [x0, #0x37]
    // 0x692bdc: DecompressPointer r4
    //     0x692bdc: add             x4, x4, HEAP, lsl #32
    // 0x692be0: stur            x4, [fp, #-0x48]
    // 0x692be4: LoadField: r5 = r0->field_7
    //     0x692be4: ldur            w5, [x0, #7]
    // 0x692be8: DecompressPointer r5
    //     0x692be8: add             x5, x5, HEAP, lsl #32
    // 0x692bec: stur            x5, [fp, #-0x40]
    // 0x692bf0: LoadField: r6 = r0->field_4b
    //     0x692bf0: ldur            w6, [x0, #0x4b]
    // 0x692bf4: DecompressPointer r6
    //     0x692bf4: add             x6, x6, HEAP, lsl #32
    // 0x692bf8: stur            x6, [fp, #-0x38]
    // 0x692bfc: LoadField: r7 = r0->field_47
    //     0x692bfc: ldur            w7, [x0, #0x47]
    // 0x692c00: DecompressPointer r7
    //     0x692c00: add             x7, x7, HEAP, lsl #32
    // 0x692c04: stur            x7, [fp, #-0x30]
    // 0x692c08: LoadField: r8 = r0->field_53
    //     0x692c08: ldur            w8, [x0, #0x53]
    // 0x692c0c: DecompressPointer r8
    //     0x692c0c: add             x8, x8, HEAP, lsl #32
    // 0x692c10: stur            x8, [fp, #-0x28]
    // 0x692c14: LoadField: r9 = r0->field_33
    //     0x692c14: ldur            w9, [x0, #0x33]
    // 0x692c18: DecompressPointer r9
    //     0x692c18: add             x9, x9, HEAP, lsl #32
    // 0x692c1c: stur            x9, [fp, #-0x20]
    // 0x692c20: LoadField: r10 = r0->field_2f
    //     0x692c20: ldur            w10, [x0, #0x2f]
    // 0x692c24: DecompressPointer r10
    //     0x692c24: add             x10, x10, HEAP, lsl #32
    // 0x692c28: mov             x1, x0
    // 0x692c2c: stur            x10, [fp, #-0x10]
    // 0x692c30: r0 = generatorsToDisplay()
    //     0x692c30: bl              #0x6937bc  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::generatorsToDisplay
    // 0x692c34: ldur            x2, [fp, #-8]
    // 0x692c38: stur            x0, [fp, #-0x68]
    // 0x692c3c: LoadField: r3 = r2->field_9f
    //     0x692c3c: ldur            w3, [x2, #0x9f]
    // 0x692c40: DecompressPointer r3
    //     0x692c40: add             x3, x3, HEAP, lsl #32
    // 0x692c44: stur            x3, [fp, #-0x60]
    // 0x692c48: r1 = <Chapter10Stat>
    //     0x692c48: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x692c4c: ldr             x1, [x1, #0xe80]
    // 0x692c50: r0 = GeneratorGroup()
    //     0x692c50: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x692c54: mov             x3, x0
    // 0x692c58: ldur            x0, [fp, #-0x48]
    // 0x692c5c: stur            x3, [fp, #-0x70]
    // 0x692c60: StoreField: r3->field_1f = r0
    //     0x692c60: stur            w0, [x3, #0x1f]
    // 0x692c64: ldur            x2, [fp, #-8]
    // 0x692c68: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x692c68: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb50] AnonymousClosure: (0x3d9e70), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getCostToBuyOneMoreGenerator (0x3d9ab0)
    //     0x692c6c: ldr             x1, [x1, #0xb50]
    // 0x692c70: r0 = AllocateClosure()
    //     0x692c70: bl              #0x826750  ; AllocateClosureStub
    // 0x692c74: mov             x1, x0
    // 0x692c78: ldur            x0, [fp, #-0x70]
    // 0x692c7c: StoreField: r0->field_23 = r1
    //     0x692c7c: stur            w1, [x0, #0x23]
    // 0x692c80: ldur            x2, [fp, #-8]
    // 0x692c84: r1 = Function 'getGeneratorInfo':.
    //     0x692c84: add             x1, PP, #0x29, lsl #12  ; [pp+0x29520] AnonymousClosure: (0x6947a4), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getGeneratorInfo (0x80d118)
    //     0x692c88: ldr             x1, [x1, #0x520]
    // 0x692c8c: r0 = AllocateClosure()
    //     0x692c8c: bl              #0x826750  ; AllocateClosureStub
    // 0x692c90: mov             x1, x0
    // 0x692c94: ldur            x0, [fp, #-0x70]
    // 0x692c98: StoreField: r0->field_27 = r1
    //     0x692c98: stur            w1, [x0, #0x27]
    // 0x692c9c: ldur            x1, [fp, #-0x38]
    // 0x692ca0: StoreField: r0->field_2b = r1
    //     0x692ca0: stur            w1, [x0, #0x2b]
    // 0x692ca4: ldur            x1, [fp, #-0x30]
    // 0x692ca8: StoreField: r0->field_2f = r1
    //     0x692ca8: stur            w1, [x0, #0x2f]
    // 0x692cac: ldur            x1, [fp, #-0x28]
    // 0x692cb0: StoreField: r0->field_33 = r1
    //     0x692cb0: stur            w1, [x0, #0x33]
    // 0x692cb4: r1 = Function '<anonymous closure>':.
    //     0x692cb4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29528] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x692cb8: ldr             x1, [x1, #0x528]
    // 0x692cbc: r2 = Null
    //     0x692cbc: mov             x2, NULL
    // 0x692cc0: r0 = AllocateClosure()
    //     0x692cc0: bl              #0x826750  ; AllocateClosureStub
    // 0x692cc4: mov             x1, x0
    // 0x692cc8: ldur            x0, [fp, #-0x70]
    // 0x692ccc: StoreField: r0->field_3b = r1
    //     0x692ccc: stur            w1, [x0, #0x3b]
    // 0x692cd0: ldur            x1, [fp, #-0x20]
    // 0x692cd4: StoreField: r0->field_43 = r1
    //     0x692cd4: stur            w1, [x0, #0x43]
    // 0x692cd8: ldur            x1, [fp, #-0x10]
    // 0x692cdc: StoreField: r0->field_47 = r1
    //     0x692cdc: stur            w1, [x0, #0x47]
    // 0x692ce0: ldur            x2, [fp, #-8]
    // 0x692ce4: r1 = Function 'buyGenerator':.
    //     0x692ce4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x692ce8: ldr             x1, [x1, #0x108]
    // 0x692cec: r0 = AllocateClosure()
    //     0x692cec: bl              #0x826750  ; AllocateClosureStub
    // 0x692cf0: mov             x1, x0
    // 0x692cf4: ldur            x0, [fp, #-0x70]
    // 0x692cf8: StoreField: r0->field_5b = r1
    //     0x692cf8: stur            w1, [x0, #0x5b]
    // 0x692cfc: r1 = Function '<anonymous closure>':.
    //     0x692cfc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29530] AnonymousClosure: (0x46e16c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x692d00: ldr             x1, [x1, #0x530]
    // 0x692d04: r2 = Null
    //     0x692d04: mov             x2, NULL
    // 0x692d08: r0 = AllocateClosure()
    //     0x692d08: bl              #0x826750  ; AllocateClosureStub
    // 0x692d0c: mov             x1, x0
    // 0x692d10: ldur            x0, [fp, #-0x70]
    // 0x692d14: ArrayStore: r0[0] = r1  ; List_4
    //     0x692d14: stur            w1, [x0, #0x17]
    // 0x692d18: r1 = Function '<anonymous closure>':.
    //     0x692d18: add             x1, PP, #0x29, lsl #12  ; [pp+0x29538] AnonymousClosure: (0x46e16c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x692d1c: ldr             x1, [x1, #0x538]
    // 0x692d20: r2 = Null
    //     0x692d20: mov             x2, NULL
    // 0x692d24: r0 = AllocateClosure()
    //     0x692d24: bl              #0x826750  ; AllocateClosureStub
    // 0x692d28: mov             x1, x0
    // 0x692d2c: ldur            x0, [fp, #-0x70]
    // 0x692d30: StoreField: r0->field_1b = r1
    //     0x692d30: stur            w1, [x0, #0x1b]
    // 0x692d34: ldur            x2, [fp, #-8]
    // 0x692d38: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x692d38: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x692d3c: ldr             x1, [x1, #0x120]
    // 0x692d40: r0 = AllocateClosure()
    //     0x692d40: bl              #0x826750  ; AllocateClosureStub
    // 0x692d44: mov             x1, x0
    // 0x692d48: ldur            x0, [fp, #-0x70]
    // 0x692d4c: StoreField: r0->field_57 = r1
    //     0x692d4c: stur            w1, [x0, #0x57]
    // 0x692d50: ldur            x1, [fp, #-0x68]
    // 0x692d54: StoreField: r0->field_53 = r1
    //     0x692d54: stur            w1, [x0, #0x53]
    // 0x692d58: ldur            x2, [fp, #-8]
    // 0x692d5c: ldur            x3, [fp, #-0x40]
    // 0x692d60: r1 = Function 'getGeneratorSingleYieldsBoosted':.
    //     0x692d60: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0x54a720), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted (0x54a520)
    //     0x692d64: ldr             x1, [x1, #0x130]
    // 0x692d68: r0 = AllocateClosureTA()
    //     0x692d68: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x692d6c: mov             x1, x0
    // 0x692d70: ldur            x0, [fp, #-0x70]
    // 0x692d74: StoreField: r0->field_6b = r1
    //     0x692d74: stur            w1, [x0, #0x6b]
    // 0x692d78: ldur            x1, [fp, #-0x50]
    // 0x692d7c: StoreField: r0->field_4b = r1
    //     0x692d7c: stur            w1, [x0, #0x4b]
    // 0x692d80: ldur            x1, [fp, #-0x60]
    // 0x692d84: StoreField: r0->field_67 = r1
    //     0x692d84: stur            w1, [x0, #0x67]
    // 0x692d88: ldur            x2, [fp, #-8]
    // 0x692d8c: ldur            x3, [fp, #-0x40]
    // 0x692d90: r1 = Function 'getGeneratorBaseCost':.
    //     0x692d90: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x692d94: ldr             x1, [x1, #0x138]
    // 0x692d98: r0 = AllocateClosureTA()
    //     0x692d98: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x692d9c: mov             x1, x0
    // 0x692da0: ldur            x0, [fp, #-0x70]
    // 0x692da4: StoreField: r0->field_77 = r1
    //     0x692da4: stur            w1, [x0, #0x77]
    // 0x692da8: ldur            x2, [fp, #-8]
    // 0x692dac: r1 = Function 'getGeneratorMultiplier':.
    //     0x692dac: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x692db0: ldr             x1, [x1, #0x140]
    // 0x692db4: r0 = AllocateClosure()
    //     0x692db4: bl              #0x826750  ; AllocateClosureStub
    // 0x692db8: mov             x1, x0
    // 0x692dbc: ldur            x0, [fp, #-0x70]
    // 0x692dc0: StoreField: r0->field_7b = r1
    //     0x692dc0: stur            w1, [x0, #0x7b]
    // 0x692dc4: r3 = "Chapter 10 Generators 1"
    //     0x692dc4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29540] "Chapter 10 Generators 1"
    //     0x692dc8: ldr             x3, [x3, #0x540]
    // 0x692dcc: StoreField: r0->field_73 = r3
    //     0x692dcc: stur            w3, [x0, #0x73]
    // 0x692dd0: r1 = Function '<anonymous closure>':.
    //     0x692dd0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29548] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x692dd4: ldr             x1, [x1, #0x548]
    // 0x692dd8: r2 = Null
    //     0x692dd8: mov             x2, NULL
    // 0x692ddc: r0 = AllocateClosure()
    //     0x692ddc: bl              #0x826750  ; AllocateClosureStub
    // 0x692de0: ldur            x2, [fp, #-0x18]
    // 0x692de4: r1 = Function '<anonymous closure>':.
    //     0x692de4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29550] AnonymousClosure: (0x69473c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x692de8: ldr             x1, [x1, #0x550]
    // 0x692dec: stur            x0, [fp, #-0x10]
    // 0x692df0: r0 = AllocateClosure()
    //     0x692df0: bl              #0x826750  ; AllocateClosureStub
    // 0x692df4: str             x0, [SP]
    // 0x692df8: ldur            x2, [fp, #-0x70]
    // 0x692dfc: ldur            x5, [fp, #-0x10]
    // 0x692e00: r1 = Null
    //     0x692e00: mov             x1, NULL
    // 0x692e04: r3 = "Chapter 10 Generators 1"
    //     0x692e04: add             x3, PP, #0x29, lsl #12  ; [pp+0x29540] "Chapter 10 Generators 1"
    //     0x692e08: ldr             x3, [x3, #0x540]
    // 0x692e0c: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x692e0c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x692e10: ldr             x4, [x4, #0x160]
    // 0x692e14: r0 = IdleFragment()
    //     0x692e14: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x692e18: mov             x2, x0
    // 0x692e1c: ldur            x0, [fp, #-8]
    // 0x692e20: stur            x2, [fp, #-0x30]
    // 0x692e24: LoadField: r3 = r0->field_37
    //     0x692e24: ldur            w3, [x0, #0x37]
    // 0x692e28: DecompressPointer r3
    //     0x692e28: add             x3, x3, HEAP, lsl #32
    // 0x692e2c: stur            x3, [fp, #-0x28]
    // 0x692e30: LoadField: r4 = r0->field_43
    //     0x692e30: ldur            w4, [x0, #0x43]
    // 0x692e34: DecompressPointer r4
    //     0x692e34: add             x4, x4, HEAP, lsl #32
    // 0x692e38: stur            x4, [fp, #-0x20]
    // 0x692e3c: LoadField: r5 = r0->field_97
    //     0x692e3c: ldur            w5, [x0, #0x97]
    // 0x692e40: DecompressPointer r5
    //     0x692e40: add             x5, x5, HEAP, lsl #32
    // 0x692e44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x692e48: cmp             w5, w16
    // 0x692e4c: b.eq            #0x6933c0
    // 0x692e50: stur            x5, [fp, #-0x10]
    // 0x692e54: r1 = <Chapter10Stat>
    //     0x692e54: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x692e58: ldr             x1, [x1, #0xe80]
    // 0x692e5c: r0 = UpgradeGroup()
    //     0x692e5c: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x692e60: mov             x3, x0
    // 0x692e64: r0 = 2
    //     0x692e64: movz            x0, #0x2
    // 0x692e68: stur            x3, [fp, #-0x38]
    // 0x692e6c: StoreField: r3->field_13 = r0
    //     0x692e6c: stur            x0, [x3, #0x13]
    // 0x692e70: ldur            x1, [fp, #-0x10]
    // 0x692e74: StoreField: r3->field_1b = r1
    //     0x692e74: stur            w1, [x3, #0x1b]
    // 0x692e78: ldur            x1, [fp, #-0x28]
    // 0x692e7c: StoreField: r3->field_1f = r1
    //     0x692e7c: stur            w1, [x3, #0x1f]
    // 0x692e80: ldur            x1, [fp, #-0x20]
    // 0x692e84: StoreField: r3->field_23 = r1
    //     0x692e84: stur            w1, [x3, #0x23]
    // 0x692e88: r1 = Function '<anonymous closure>':.
    //     0x692e88: add             x1, PP, #0x29, lsl #12  ; [pp+0x29558] AnonymousClosure: (0x46e16c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x692e8c: ldr             x1, [x1, #0x558]
    // 0x692e90: r2 = Null
    //     0x692e90: mov             x2, NULL
    // 0x692e94: r0 = AllocateClosure()
    //     0x692e94: bl              #0x826750  ; AllocateClosureStub
    // 0x692e98: mov             x1, x0
    // 0x692e9c: ldur            x0, [fp, #-0x38]
    // 0x692ea0: StoreField: r0->field_2b = r1
    //     0x692ea0: stur            w1, [x0, #0x2b]
    // 0x692ea4: r1 = const [0x1, 0x2, 0x3, 0xa]
    //     0x692ea4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29560] List<int>(4)
    //     0x692ea8: ldr             x1, [x1, #0x560]
    // 0x692eac: StoreField: r0->field_f = r1
    //     0x692eac: stur            w1, [x0, #0xf]
    // 0x692eb0: r3 = true
    //     0x692eb0: add             x3, NULL, #0x20  ; true
    // 0x692eb4: StoreField: r0->field_27 = r3
    //     0x692eb4: stur            w3, [x0, #0x27]
    // 0x692eb8: r1 = Instance_UpgradeDisplayMode
    //     0x692eb8: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x692ebc: ldr             x1, [x1, #0x608]
    // 0x692ec0: StoreField: r0->field_2f = r1
    //     0x692ec0: stur            w1, [x0, #0x2f]
    // 0x692ec4: r4 = false
    //     0x692ec4: add             x4, NULL, #0x30  ; false
    // 0x692ec8: StoreField: r0->field_33 = r4
    //     0x692ec8: stur            w4, [x0, #0x33]
    // 0x692ecc: ldur            x2, [fp, #-0x18]
    // 0x692ed0: r1 = Function '<anonymous closure>':.
    //     0x692ed0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29568] AnonymousClosure: (0x694710), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::build (0x6aeeb0)
    //     0x692ed4: ldr             x1, [x1, #0x568]
    // 0x692ed8: r0 = AllocateClosure()
    //     0x692ed8: bl              #0x826750  ; AllocateClosureStub
    // 0x692edc: r16 = false
    //     0x692edc: add             x16, NULL, #0x30  ; false
    // 0x692ee0: str             x16, [SP]
    // 0x692ee4: ldur            x2, [fp, #-0x38]
    // 0x692ee8: mov             x5, x0
    // 0x692eec: r1 = Null
    //     0x692eec: mov             x1, NULL
    // 0x692ef0: r3 = "Chapter 10 Upgrades 1"
    //     0x692ef0: add             x3, PP, #0x29, lsl #12  ; [pp+0x29570] "Chapter 10 Upgrades 1"
    //     0x692ef4: ldr             x3, [x3, #0x570]
    // 0x692ef8: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x692ef8: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x692efc: ldr             x4, [x4, #0xf0]
    // 0x692f00: r0 = IdleFragment()
    //     0x692f00: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x692f04: ldur            x1, [fp, #-8]
    // 0x692f08: stur            x0, [fp, #-0x10]
    // 0x692f0c: r0 = makeRefactorLevelChooser()
    //     0x692f0c: bl              #0x6933d8  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::makeRefactorLevelChooser
    // 0x692f10: ldur            x2, [fp, #-0x18]
    // 0x692f14: r1 = Function '<anonymous closure>':.
    //     0x692f14: add             x1, PP, #0x29, lsl #12  ; [pp+0x29578] AnonymousClosure: (0x694504), in [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::build (0x6c2c88)
    //     0x692f18: ldr             x1, [x1, #0x578]
    // 0x692f1c: stur            x0, [fp, #-0x20]
    // 0x692f20: r0 = AllocateClosure()
    //     0x692f20: bl              #0x826750  ; AllocateClosureStub
    // 0x692f24: ldur            x2, [fp, #-0x20]
    // 0x692f28: mov             x5, x0
    // 0x692f2c: r1 = Null
    //     0x692f2c: mov             x1, NULL
    // 0x692f30: r3 = "Chapter 9 Prestige 2 Chooser"
    //     0x692f30: add             x3, PP, #0x29, lsl #12  ; [pp+0x29580] "Chapter 9 Prestige 2 Chooser"
    //     0x692f34: ldr             x3, [x3, #0x580]
    // 0x692f38: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x692f38: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x692f3c: r0 = IdleFragment()
    //     0x692f3c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x692f40: mov             x3, x0
    // 0x692f44: ldur            x0, [fp, #-8]
    // 0x692f48: stur            x3, [fp, #-0x28]
    // 0x692f4c: LoadField: r4 = r0->field_37
    //     0x692f4c: ldur            w4, [x0, #0x37]
    // 0x692f50: DecompressPointer r4
    //     0x692f50: add             x4, x4, HEAP, lsl #32
    // 0x692f54: stur            x4, [fp, #-0x20]
    // 0x692f58: r1 = Function '<anonymous closure>':.
    //     0x692f58: add             x1, PP, #0x29, lsl #12  ; [pp+0x29588] AnonymousClosure: (0x694704), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x692f5c: ldr             x1, [x1, #0x588]
    // 0x692f60: r2 = Null
    //     0x692f60: mov             x2, NULL
    // 0x692f64: r0 = AllocateClosure()
    //     0x692f64: bl              #0x826750  ; AllocateClosureStub
    // 0x692f68: r1 = <Chapter10Stat>
    //     0x692f68: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x692f6c: ldr             x1, [x1, #0xe80]
    // 0x692f70: stur            x0, [fp, #-0x38]
    // 0x692f74: r0 = PrestigeButton()
    //     0x692f74: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x692f78: mov             x3, x0
    // 0x692f7c: ldur            x0, [fp, #-0x38]
    // 0x692f80: stur            x3, [fp, #-0x40]
    // 0x692f84: StoreField: r3->field_1f = r0
    //     0x692f84: stur            w0, [x3, #0x1f]
    // 0x692f88: r0 = Instance_Chapter10Stat
    //     0x692f88: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x692f8c: ldr             x0, [x0, #0x7d8]
    // 0x692f90: StoreField: r3->field_1b = r0
    //     0x692f90: stur            w0, [x3, #0x1b]
    // 0x692f94: ldur            x2, [fp, #-8]
    // 0x692f98: r1 = Function 'presitgePointsFromRefactor':.
    //     0x692f98: add             x1, PP, #0x29, lsl #12  ; [pp+0x29590] AnonymousClosure: (0x6946cc), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::presitgePointsFromRefactor (0x693e20)
    //     0x692f9c: ldr             x1, [x1, #0x590]
    // 0x692fa0: r0 = AllocateClosure()
    //     0x692fa0: bl              #0x826750  ; AllocateClosureStub
    // 0x692fa4: mov             x1, x0
    // 0x692fa8: ldur            x0, [fp, #-0x40]
    // 0x692fac: StoreField: r0->field_2f = r1
    //     0x692fac: stur            w1, [x0, #0x2f]
    // 0x692fb0: ldur            x2, [fp, #-8]
    // 0x692fb4: r1 = Function 'refactorReset':.
    //     0x692fb4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29598] AnonymousClosure: (0x6945c8), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::refactorReset (0x694600)
    //     0x692fb8: ldr             x1, [x1, #0x598]
    // 0x692fbc: r0 = AllocateClosure()
    //     0x692fbc: bl              #0x826750  ; AllocateClosureStub
    // 0x692fc0: mov             x1, x0
    // 0x692fc4: ldur            x0, [fp, #-0x40]
    // 0x692fc8: StoreField: r0->field_33 = r1
    //     0x692fc8: stur            w1, [x0, #0x33]
    // 0x692fcc: ldur            x1, [fp, #-0x20]
    // 0x692fd0: ArrayStore: r0[0] = r1  ; List_4
    //     0x692fd0: stur            w1, [x0, #0x17]
    // 0x692fd4: r3 = Closure: (Chapter10Stat?) => String from Function 'humanName': static.
    //     0x692fd4: add             x3, PP, #0x29, lsl #12  ; [pp+0x294f0] Closure: (Chapter10Stat?) => String from Function 'humanName': static. (0x248ed99e16c)
    //     0x692fd8: ldr             x3, [x3, #0x4f0]
    // 0x692fdc: StoreField: r0->field_43 = r3
    //     0x692fdc: stur            w3, [x0, #0x43]
    // 0x692fe0: r1 = Function '<anonymous closure>':.
    //     0x692fe0: add             x1, PP, #0x29, lsl #12  ; [pp+0x295a0] AnonymousClosure: (0x6945bc), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x692fe4: ldr             x1, [x1, #0x5a0]
    // 0x692fe8: r2 = Null
    //     0x692fe8: mov             x2, NULL
    // 0x692fec: r0 = AllocateClosure()
    //     0x692fec: bl              #0x826750  ; AllocateClosureStub
    // 0x692ff0: mov             x1, x0
    // 0x692ff4: ldur            x0, [fp, #-0x40]
    // 0x692ff8: StoreField: r0->field_23 = r1
    //     0x692ff8: stur            w1, [x0, #0x23]
    // 0x692ffc: ldur            x2, [fp, #-0x18]
    // 0x693000: r1 = Function '<anonymous closure>':.
    //     0x693000: add             x1, PP, #0x29, lsl #12  ; [pp+0x295a8] AnonymousClosure: (0x694550), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::build (0x692a30)
    //     0x693004: ldr             x1, [x1, #0x5a8]
    // 0x693008: r0 = AllocateClosure()
    //     0x693008: bl              #0x826750  ; AllocateClosureStub
    // 0x69300c: mov             x1, x0
    // 0x693010: ldur            x0, [fp, #-0x40]
    // 0x693014: StoreField: r0->field_37 = r1
    //     0x693014: stur            w1, [x0, #0x37]
    // 0x693018: r1 = "everything above"
    //     0x693018: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x69301c: ldr             x1, [x1, #0x1b0]
    // 0x693020: StoreField: r0->field_3f = r1
    //     0x693020: stur            w1, [x0, #0x3f]
    // 0x693024: r3 = false
    //     0x693024: add             x3, NULL, #0x30  ; false
    // 0x693028: StoreField: r0->field_f = r3
    //     0x693028: stur            w3, [x0, #0xf]
    // 0x69302c: StoreField: r0->field_4f = r3
    //     0x69302c: stur            w3, [x0, #0x4f]
    // 0x693030: r4 = true
    //     0x693030: add             x4, NULL, #0x20  ; true
    // 0x693034: StoreField: r0->field_2b = r4
    //     0x693034: stur            w4, [x0, #0x2b]
    // 0x693038: StoreField: r0->field_53 = r3
    //     0x693038: stur            w3, [x0, #0x53]
    // 0x69303c: StoreField: r0->field_5b = r4
    //     0x69303c: stur            w4, [x0, #0x5b]
    // 0x693040: r1 = "Gain"
    //     0x693040: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x693044: ldr             x1, [x1, #0x1b8]
    // 0x693048: StoreField: r0->field_5f = r1
    //     0x693048: stur            w1, [x0, #0x5f]
    // 0x69304c: ldur            x2, [fp, #-0x18]
    // 0x693050: r1 = Function '<anonymous closure>':.
    //     0x693050: add             x1, PP, #0x29, lsl #12  ; [pp+0x295b0] AnonymousClosure: (0x694504), in [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::build (0x6c2c88)
    //     0x693054: ldr             x1, [x1, #0x5b0]
    // 0x693058: r0 = AllocateClosure()
    //     0x693058: bl              #0x826750  ; AllocateClosureStub
    // 0x69305c: ldur            x2, [fp, #-0x40]
    // 0x693060: mov             x5, x0
    // 0x693064: r1 = Null
    //     0x693064: mov             x1, NULL
    // 0x693068: r3 = "Chapter 9 Prestige 2"
    //     0x693068: add             x3, PP, #0x26, lsl #12  ; [pp+0x26260] "Chapter 9 Prestige 2"
    //     0x69306c: ldr             x3, [x3, #0x260]
    // 0x693070: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x693070: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x693074: r0 = IdleFragment()
    //     0x693074: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x693078: mov             x3, x0
    // 0x69307c: ldur            x0, [fp, #-8]
    // 0x693080: stur            x3, [fp, #-0x40]
    // 0x693084: LoadField: r4 = r0->field_37
    //     0x693084: ldur            w4, [x0, #0x37]
    // 0x693088: DecompressPointer r4
    //     0x693088: add             x4, x4, HEAP, lsl #32
    // 0x69308c: stur            x4, [fp, #-0x38]
    // 0x693090: LoadField: r5 = r0->field_3f
    //     0x693090: ldur            w5, [x0, #0x3f]
    // 0x693094: DecompressPointer r5
    //     0x693094: add             x5, x5, HEAP, lsl #32
    // 0x693098: mov             x2, x0
    // 0x69309c: stur            x5, [fp, #-0x20]
    // 0x6930a0: r1 = Function 'questReset':.
    //     0x6930a0: add             x1, PP, #0x29, lsl #12  ; [pp+0x295b8] AnonymousClosure: (0x693cbc), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::questReset (0x693cf4)
    //     0x6930a4: ldr             x1, [x1, #0x5b8]
    // 0x6930a8: r0 = AllocateClosure()
    //     0x6930a8: bl              #0x826750  ; AllocateClosureStub
    // 0x6930ac: r1 = <Chapter10Stat>
    //     0x6930ac: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x6930b0: ldr             x1, [x1, #0xe80]
    // 0x6930b4: stur            x0, [fp, #-0x48]
    // 0x6930b8: r0 = QuestButton()
    //     0x6930b8: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x6930bc: mov             x3, x0
    // 0x6930c0: ldur            x0, [fp, #-0x48]
    // 0x6930c4: stur            x3, [fp, #-0x50]
    // 0x6930c8: StoreField: r3->field_2f = r0
    //     0x6930c8: stur            w0, [x3, #0x2f]
    // 0x6930cc: ldur            x0, [fp, #-0x38]
    // 0x6930d0: StoreField: r3->field_1b = r0
    //     0x6930d0: stur            w0, [x3, #0x1b]
    // 0x6930d4: r1 = Instance_IconData
    //     0x6930d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x269f0] Obj!IconData@82f651
    //     0x6930d8: ldr             x1, [x1, #0x9f0]
    // 0x6930dc: StoreField: r3->field_1f = r1
    //     0x6930dc: stur            w1, [x3, #0x1f]
    // 0x6930e0: ldur            x4, [fp, #-0x20]
    // 0x6930e4: StoreField: r3->field_2b = r4
    //     0x6930e4: stur            w4, [x3, #0x2b]
    // 0x6930e8: r5 = 1
    //     0x6930e8: movz            x5, #0x1
    // 0x6930ec: StoreField: r3->field_23 = r5
    //     0x6930ec: stur            x5, [x3, #0x23]
    // 0x6930f0: r6 = Closure: (Chapter10Stat?) => String from Function 'humanName': static.
    //     0x6930f0: add             x6, PP, #0x29, lsl #12  ; [pp+0x294f0] Closure: (Chapter10Stat?) => String from Function 'humanName': static. (0x248ed99e16c)
    //     0x6930f4: ldr             x6, [x6, #0x4f0]
    // 0x6930f8: StoreField: r3->field_f = r6
    //     0x6930f8: stur            w6, [x3, #0xf]
    // 0x6930fc: r1 = const [Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>']
    //     0x6930fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x295c0] List<QuestLevel<Chapter10Stat>>(5)
    //     0x693100: ldr             x1, [x1, #0x5c0]
    // 0x693104: StoreField: r3->field_37 = r1
    //     0x693104: stur            w1, [x3, #0x37]
    // 0x693108: r7 = true
    //     0x693108: add             x7, NULL, #0x20  ; true
    // 0x69310c: StoreField: r3->field_13 = r7
    //     0x69310c: stur            w7, [x3, #0x13]
    // 0x693110: ldur            x2, [fp, #-8]
    // 0x693114: r1 = Function 'kernelReset':.
    //     0x693114: add             x1, PP, #0x29, lsl #12  ; [pp+0x295c8] AnonymousClosure: (0x693a98), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::kernelReset (0x693ad0)
    //     0x693118: ldr             x1, [x1, #0x5c8]
    // 0x69311c: r0 = AllocateClosure()
    //     0x69311c: bl              #0x826750  ; AllocateClosureStub
    // 0x693120: r1 = <Chapter10Stat>
    //     0x693120: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x693124: ldr             x1, [x1, #0xe80]
    // 0x693128: stur            x0, [fp, #-0x48]
    // 0x69312c: r0 = QuestButton()
    //     0x69312c: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x693130: mov             x3, x0
    // 0x693134: ldur            x0, [fp, #-0x48]
    // 0x693138: stur            x3, [fp, #-0x60]
    // 0x69313c: StoreField: r3->field_2f = r0
    //     0x69313c: stur            w0, [x3, #0x2f]
    // 0x693140: ldur            x0, [fp, #-0x38]
    // 0x693144: StoreField: r3->field_1b = r0
    //     0x693144: stur            w0, [x3, #0x1b]
    // 0x693148: r0 = Instance_IconData
    //     0x693148: add             x0, PP, #0x14, lsl #12  ; [pp+0x14ba0] Obj!IconData@82fb91
    //     0x69314c: ldr             x0, [x0, #0xba0]
    // 0x693150: StoreField: r3->field_1f = r0
    //     0x693150: stur            w0, [x3, #0x1f]
    // 0x693154: ldur            x0, [fp, #-0x20]
    // 0x693158: StoreField: r3->field_2b = r0
    //     0x693158: stur            w0, [x3, #0x2b]
    // 0x69315c: r0 = 2
    //     0x69315c: movz            x0, #0x2
    // 0x693160: StoreField: r3->field_23 = r0
    //     0x693160: stur            x0, [x3, #0x23]
    // 0x693164: r0 = Closure: (Chapter10Stat?) => String from Function 'humanName': static.
    //     0x693164: add             x0, PP, #0x29, lsl #12  ; [pp+0x294f0] Closure: (Chapter10Stat?) => String from Function 'humanName': static. (0x248ed99e16c)
    //     0x693168: ldr             x0, [x0, #0x4f0]
    // 0x69316c: StoreField: r3->field_f = r0
    //     0x69316c: stur            w0, [x3, #0xf]
    // 0x693170: r0 = const [Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>', Instance of 'QuestLevel<Chapter10Stat>']
    //     0x693170: add             x0, PP, #0x29, lsl #12  ; [pp+0x295d0] List<QuestLevel<Chapter10Stat>>(4)
    //     0x693174: ldr             x0, [x0, #0x5d0]
    // 0x693178: StoreField: r3->field_37 = r0
    //     0x693178: stur            w0, [x3, #0x37]
    // 0x69317c: r0 = true
    //     0x69317c: add             x0, NULL, #0x20  ; true
    // 0x693180: StoreField: r3->field_13 = r0
    //     0x693180: stur            w0, [x3, #0x13]
    // 0x693184: r1 = Null
    //     0x693184: mov             x1, NULL
    // 0x693188: r2 = 4
    //     0x693188: movz            x2, #0x4
    // 0x69318c: r0 = AllocateArray()
    //     0x69318c: bl              #0x82746c  ; AllocateArrayStub
    // 0x693190: mov             x2, x0
    // 0x693194: ldur            x0, [fp, #-0x50]
    // 0x693198: stur            x2, [fp, #-0x20]
    // 0x69319c: StoreField: r2->field_f = r0
    //     0x69319c: stur            w0, [x2, #0xf]
    // 0x6931a0: ldur            x0, [fp, #-0x60]
    // 0x6931a4: StoreField: r2->field_13 = r0
    //     0x6931a4: stur            w0, [x2, #0x13]
    // 0x6931a8: r1 = <Widget>
    //     0x6931a8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6931ac: r0 = AllocateGrowableArray()
    //     0x6931ac: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6931b0: mov             x1, x0
    // 0x6931b4: ldur            x0, [fp, #-0x20]
    // 0x6931b8: stur            x1, [fp, #-0x38]
    // 0x6931bc: StoreField: r1->field_f = r0
    //     0x6931bc: stur            w0, [x1, #0xf]
    // 0x6931c0: r0 = 4
    //     0x6931c0: movz            x0, #0x4
    // 0x6931c4: StoreField: r1->field_b = r0
    //     0x6931c4: stur            w0, [x1, #0xb]
    // 0x6931c8: r0 = Column()
    //     0x6931c8: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6931cc: mov             x1, x0
    // 0x6931d0: r0 = Instance_Axis
    //     0x6931d0: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6931d4: stur            x1, [fp, #-0x20]
    // 0x6931d8: StoreField: r1->field_f = r0
    //     0x6931d8: stur            w0, [x1, #0xf]
    // 0x6931dc: r0 = Instance_MainAxisAlignment
    //     0x6931dc: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6931e0: ldr             x0, [x0, #0x200]
    // 0x6931e4: StoreField: r1->field_13 = r0
    //     0x6931e4: stur            w0, [x1, #0x13]
    // 0x6931e8: r0 = Instance_MainAxisSize
    //     0x6931e8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6931ec: ldr             x0, [x0, #0x70]
    // 0x6931f0: ArrayStore: r1[0] = r0  ; List_4
    //     0x6931f0: stur            w0, [x1, #0x17]
    // 0x6931f4: r0 = Instance_CrossAxisAlignment
    //     0x6931f4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6931f8: ldr             x0, [x0, #0x78]
    // 0x6931fc: StoreField: r1->field_1b = r0
    //     0x6931fc: stur            w0, [x1, #0x1b]
    // 0x693200: r0 = Instance_VerticalDirection
    //     0x693200: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x693204: ldr             x0, [x0, #0x1e8]
    // 0x693208: StoreField: r1->field_23 = r0
    //     0x693208: stur            w0, [x1, #0x23]
    // 0x69320c: r0 = Instance_Clip
    //     0x69320c: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x693210: ldr             x0, [x0, #0x1b0]
    // 0x693214: StoreField: r1->field_2b = r0
    //     0x693214: stur            w0, [x1, #0x2b]
    // 0x693218: StoreField: r1->field_2f = rZR
    //     0x693218: stur            xzr, [x1, #0x2f]
    // 0x69321c: ldur            x0, [fp, #-0x38]
    // 0x693220: StoreField: r1->field_b = r0
    //     0x693220: stur            w0, [x1, #0xb]
    // 0x693224: r0 = Padding()
    //     0x693224: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x693228: mov             x3, x0
    // 0x69322c: r0 = Instance_EdgeInsets
    //     0x69322c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a08] Obj!EdgeInsets@831da1
    //     0x693230: ldr             x0, [x0, #0xa08]
    // 0x693234: stur            x3, [fp, #-0x38]
    // 0x693238: StoreField: r3->field_f = r0
    //     0x693238: stur            w0, [x3, #0xf]
    // 0x69323c: ldur            x0, [fp, #-0x20]
    // 0x693240: StoreField: r3->field_b = r0
    //     0x693240: stur            w0, [x3, #0xb]
    // 0x693244: ldur            x2, [fp, #-0x18]
    // 0x693248: r1 = Function '<anonymous closure>':.
    //     0x693248: add             x1, PP, #0x29, lsl #12  ; [pp+0x295d8] AnonymousClosure: (0x693a6c), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::build (0x6aeeb0)
    //     0x69324c: ldr             x1, [x1, #0x5d8]
    // 0x693250: r0 = AllocateClosure()
    //     0x693250: bl              #0x826750  ; AllocateClosureStub
    // 0x693254: ldur            x2, [fp, #-0x38]
    // 0x693258: mov             x5, x0
    // 0x69325c: r1 = Null
    //     0x69325c: mov             x1, NULL
    // 0x693260: r3 = "Chapter 10 Quests 1"
    //     0x693260: add             x3, PP, #0x29, lsl #12  ; [pp+0x295e0] "Chapter 10 Quests 1"
    //     0x693264: ldr             x3, [x3, #0x5e0]
    // 0x693268: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x693268: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69326c: r0 = IdleFragment()
    //     0x69326c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x693270: mov             x2, x0
    // 0x693274: ldur            x0, [fp, #-8]
    // 0x693278: stur            x2, [fp, #-0x50]
    // 0x69327c: LoadField: r3 = r0->field_37
    //     0x69327c: ldur            w3, [x0, #0x37]
    // 0x693280: DecompressPointer r3
    //     0x693280: add             x3, x3, HEAP, lsl #32
    // 0x693284: stur            x3, [fp, #-0x48]
    // 0x693288: LoadField: r4 = r0->field_43
    //     0x693288: ldur            w4, [x0, #0x43]
    // 0x69328c: DecompressPointer r4
    //     0x69328c: add             x4, x4, HEAP, lsl #32
    // 0x693290: stur            x4, [fp, #-0x38]
    // 0x693294: LoadField: r5 = r0->field_97
    //     0x693294: ldur            w5, [x0, #0x97]
    // 0x693298: DecompressPointer r5
    //     0x693298: add             x5, x5, HEAP, lsl #32
    // 0x69329c: stur            x5, [fp, #-0x20]
    // 0x6932a0: r1 = <Chapter10Stat>
    //     0x6932a0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x6932a4: ldr             x1, [x1, #0xe80]
    // 0x6932a8: r0 = UpgradeGroup()
    //     0x6932a8: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6932ac: mov             x3, x0
    // 0x6932b0: r0 = 1
    //     0x6932b0: movz            x0, #0x1
    // 0x6932b4: stur            x3, [fp, #-8]
    // 0x6932b8: StoreField: r3->field_13 = r0
    //     0x6932b8: stur            x0, [x3, #0x13]
    // 0x6932bc: ldur            x0, [fp, #-0x20]
    // 0x6932c0: StoreField: r3->field_1b = r0
    //     0x6932c0: stur            w0, [x3, #0x1b]
    // 0x6932c4: ldur            x0, [fp, #-0x48]
    // 0x6932c8: StoreField: r3->field_1f = r0
    //     0x6932c8: stur            w0, [x3, #0x1f]
    // 0x6932cc: ldur            x0, [fp, #-0x38]
    // 0x6932d0: StoreField: r3->field_23 = r0
    //     0x6932d0: stur            w0, [x3, #0x23]
    // 0x6932d4: r1 = Function '<anonymous closure>':.
    //     0x6932d4: add             x1, PP, #0x29, lsl #12  ; [pp+0x295e8] AnonymousClosure: (0x46e16c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState (0x46db78)
    //     0x6932d8: ldr             x1, [x1, #0x5e8]
    // 0x6932dc: r2 = Null
    //     0x6932dc: mov             x2, NULL
    // 0x6932e0: r0 = AllocateClosure()
    //     0x6932e0: bl              #0x826750  ; AllocateClosureStub
    // 0x6932e4: mov             x1, x0
    // 0x6932e8: ldur            x0, [fp, #-8]
    // 0x6932ec: StoreField: r0->field_2b = r1
    //     0x6932ec: stur            w1, [x0, #0x2b]
    // 0x6932f0: r1 = const [0x14, 0x15, 0x16]
    //     0x6932f0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29340] List<int>(3)
    //     0x6932f4: ldr             x1, [x1, #0x340]
    // 0x6932f8: StoreField: r0->field_f = r1
    //     0x6932f8: stur            w1, [x0, #0xf]
    // 0x6932fc: r1 = true
    //     0x6932fc: add             x1, NULL, #0x20  ; true
    // 0x693300: StoreField: r0->field_27 = r1
    //     0x693300: stur            w1, [x0, #0x27]
    // 0x693304: r1 = Instance_UpgradeDisplayMode
    //     0x693304: add             x1, PP, #0x26, lsl #12  ; [pp+0x26300] Obj!UpgradeDisplayMode@85e861
    //     0x693308: ldr             x1, [x1, #0x300]
    // 0x69330c: StoreField: r0->field_2f = r1
    //     0x69330c: stur            w1, [x0, #0x2f]
    // 0x693310: r1 = false
    //     0x693310: add             x1, NULL, #0x30  ; false
    // 0x693314: StoreField: r0->field_33 = r1
    //     0x693314: stur            w1, [x0, #0x33]
    // 0x693318: ldur            x2, [fp, #-0x18]
    // 0x69331c: r1 = Function '<anonymous closure>':.
    //     0x69331c: add             x1, PP, #0x29, lsl #12  ; [pp+0x295f0] AnonymousClosure: (0x693a40), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::build (0x6aeeb0)
    //     0x693320: ldr             x1, [x1, #0x5f0]
    // 0x693324: r0 = AllocateClosure()
    //     0x693324: bl              #0x826750  ; AllocateClosureStub
    // 0x693328: ldur            x2, [fp, #-8]
    // 0x69332c: mov             x5, x0
    // 0x693330: r1 = Null
    //     0x693330: mov             x1, NULL
    // 0x693334: r3 = "Chapter 10 Upgrades 2"
    //     0x693334: add             x3, PP, #0x29, lsl #12  ; [pp+0x295f8] "Chapter 10 Upgrades 2"
    //     0x693338: ldr             x3, [x3, #0x5f8]
    // 0x69333c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69333c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x693340: r0 = IdleFragment()
    //     0x693340: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x693344: r1 = Null
    //     0x693344: mov             x1, NULL
    // 0x693348: r2 = 14
    //     0x693348: movz            x2, #0xe
    // 0x69334c: stur            x0, [fp, #-8]
    // 0x693350: r0 = AllocateArray()
    //     0x693350: bl              #0x82746c  ; AllocateArrayStub
    // 0x693354: mov             x2, x0
    // 0x693358: ldur            x0, [fp, #-0x58]
    // 0x69335c: stur            x2, [fp, #-0x18]
    // 0x693360: StoreField: r2->field_f = r0
    //     0x693360: stur            w0, [x2, #0xf]
    // 0x693364: ldur            x0, [fp, #-0x30]
    // 0x693368: StoreField: r2->field_13 = r0
    //     0x693368: stur            w0, [x2, #0x13]
    // 0x69336c: ldur            x0, [fp, #-0x10]
    // 0x693370: ArrayStore: r2[0] = r0  ; List_4
    //     0x693370: stur            w0, [x2, #0x17]
    // 0x693374: ldur            x0, [fp, #-0x28]
    // 0x693378: StoreField: r2->field_1b = r0
    //     0x693378: stur            w0, [x2, #0x1b]
    // 0x69337c: ldur            x0, [fp, #-0x40]
    // 0x693380: StoreField: r2->field_1f = r0
    //     0x693380: stur            w0, [x2, #0x1f]
    // 0x693384: ldur            x0, [fp, #-0x50]
    // 0x693388: StoreField: r2->field_23 = r0
    //     0x693388: stur            w0, [x2, #0x23]
    // 0x69338c: ldur            x0, [fp, #-8]
    // 0x693390: StoreField: r2->field_27 = r0
    //     0x693390: stur            w0, [x2, #0x27]
    // 0x693394: r1 = <Widget>
    //     0x693394: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x693398: r0 = AllocateGrowableArray()
    //     0x693398: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69339c: ldur            x1, [fp, #-0x18]
    // 0x6933a0: StoreField: r0->field_f = r1
    //     0x6933a0: stur            w1, [x0, #0xf]
    // 0x6933a4: r1 = 14
    //     0x6933a4: movz            x1, #0xe
    // 0x6933a8: StoreField: r0->field_b = r1
    //     0x6933a8: stur            w1, [x0, #0xb]
    // 0x6933ac: LeaveFrame
    //     0x6933ac: mov             SP, fp
    //     0x6933b0: ldp             fp, lr, [SP], #0x10
    // 0x6933b4: ret
    //     0x6933b4: ret             
    // 0x6933b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6933b8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6933bc: b               #0x692a54
    // 0x6933c0: r9 = allUpgradeData
    //     0x6933c0: add             x9, PP, #0x29, lsl #12  ; [pp+0x29600] Field <Chapter10GameState.allUpgradeData>: late (offset: 0x98)
    //     0x6933c4: ldr             x9, [x9, #0x600]
    // 0x6933c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6933c8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ makeRefactorLevelChooser(/* No info */) {
    // ** addr: 0x6933d8, size: 0x2bc
    // 0x6933d8: EnterFrame
    //     0x6933d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6933dc: mov             fp, SP
    // 0x6933e0: AllocStack(0x48)
    //     0x6933e0: sub             SP, SP, #0x48
    // 0x6933e4: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */)
    //     0x6933e4: mov             x0, x1
    //     0x6933e8: stur            x1, [fp, #-8]
    // 0x6933ec: CheckStackOverflow
    //     0x6933ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6933f0: cmp             SP, x16
    //     0x6933f4: b.ls            #0x693680
    // 0x6933f8: r1 = <DropdownMenuItem<int>>
    //     0x6933f8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29640] TypeArguments: <DropdownMenuItem<int>>
    //     0x6933fc: ldr             x1, [x1, #0x640]
    // 0x693400: r2 = 0
    //     0x693400: movz            x2, #0
    // 0x693404: r0 = _GrowableList()
    //     0x693404: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x693408: ldur            x1, [fp, #-8]
    // 0x69340c: stur            x0, [fp, #-0x10]
    // 0x693410: r0 = getRefactorLevel()
    //     0x693410: bl              #0x6936a0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getRefactorLevel
    // 0x693414: mov             x2, x0
    // 0x693418: stur            x2, [fp, #-0x38]
    // 0x69341c: ldur            x3, [fp, #-0x10]
    // 0x693420: r6 = false
    //     0x693420: add             x6, NULL, #0x30  ; false
    // 0x693424: r5 = 2
    //     0x693424: movz            x5, #0x2
    // 0x693428: ldur            x4, [fp, #-8]
    // 0x69342c: stur            x6, [fp, #-0x28]
    // 0x693430: stur            x5, [fp, #-0x30]
    // 0x693434: CheckStackOverflow
    //     0x693434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693438: cmp             SP, x16
    //     0x69343c: b.ls            #0x693688
    // 0x693440: LoadField: r0 = r4->field_8b
    //     0x693440: ldur            x0, [x4, #0x8b]
    // 0x693444: sub             x1, x0, #1
    // 0x693448: LoadField: r7 = r4->field_9b
    //     0x693448: ldur            w7, [x4, #0x9b]
    // 0x69344c: DecompressPointer r7
    //     0x69344c: add             x7, x7, HEAP, lsl #32
    // 0x693450: LoadField: r0 = r7->field_b
    //     0x693450: ldur            w0, [x7, #0xb]
    // 0x693454: r8 = LoadInt32Instr(r0)
    //     0x693454: sbfx            x8, x0, #1, #0x1f
    // 0x693458: cmp             x1, x8
    // 0x69345c: csel            x0, x8, x1, gt
    // 0x693460: cmp             x5, x0
    // 0x693464: b.gt            #0x693590
    // 0x693468: mov             x0, x8
    // 0x69346c: mov             x1, x5
    // 0x693470: cmp             x1, x0
    // 0x693474: b.hs            #0x693690
    // 0x693478: LoadField: r0 = r7->field_f
    //     0x693478: ldur            w0, [x7, #0xf]
    // 0x69347c: DecompressPointer r0
    //     0x69347c: add             x0, x0, HEAP, lsl #32
    // 0x693480: lsl             x1, x5, #1
    // 0x693484: stur            x1, [fp, #-0x20]
    // 0x693488: ArrayLoad: r7 = r0[r5]  ; Unknown_4
    //     0x693488: add             x16, x0, x5, lsl #2
    //     0x69348c: ldur            w7, [x16, #0xf]
    // 0x693490: DecompressPointer r7
    //     0x693490: add             x7, x7, HEAP, lsl #32
    // 0x693494: LoadField: r0 = r7->field_f
    //     0x693494: ldur            w0, [x7, #0xf]
    // 0x693498: DecompressPointer r0
    //     0x693498: add             x0, x0, HEAP, lsl #32
    // 0x69349c: stur            x0, [fp, #-0x18]
    // 0x6934a0: r0 = Text()
    //     0x6934a0: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x6934a4: mov             x2, x0
    // 0x6934a8: ldur            x0, [fp, #-0x18]
    // 0x6934ac: stur            x2, [fp, #-0x40]
    // 0x6934b0: StoreField: r2->field_b = r0
    //     0x6934b0: stur            w0, [x2, #0xb]
    // 0x6934b4: r1 = <int>
    //     0x6934b4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x6934b8: r0 = DropdownMenuItem()
    //     0x6934b8: bl              #0x693694  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x6934bc: mov             x2, x0
    // 0x6934c0: ldur            x0, [fp, #-0x20]
    // 0x6934c4: stur            x2, [fp, #-0x18]
    // 0x6934c8: StoreField: r2->field_1b = r0
    //     0x6934c8: stur            w0, [x2, #0x1b]
    // 0x6934cc: r0 = true
    //     0x6934cc: add             x0, NULL, #0x20  ; true
    // 0x6934d0: StoreField: r2->field_1f = r0
    //     0x6934d0: stur            w0, [x2, #0x1f]
    // 0x6934d4: r3 = Instance_AlignmentDirectional
    //     0x6934d4: add             x3, PP, #0x18, lsl #12  ; [pp+0x18ac0] Obj!AlignmentDirectional@8331d1
    //     0x6934d8: ldr             x3, [x3, #0xac0]
    // 0x6934dc: StoreField: r2->field_f = r3
    //     0x6934dc: stur            w3, [x2, #0xf]
    // 0x6934e0: ldur            x1, [fp, #-0x40]
    // 0x6934e4: StoreField: r2->field_b = r1
    //     0x6934e4: stur            w1, [x2, #0xb]
    // 0x6934e8: ldur            x4, [fp, #-0x10]
    // 0x6934ec: LoadField: r1 = r4->field_b
    //     0x6934ec: ldur            w1, [x4, #0xb]
    // 0x6934f0: LoadField: r5 = r4->field_f
    //     0x6934f0: ldur            w5, [x4, #0xf]
    // 0x6934f4: DecompressPointer r5
    //     0x6934f4: add             x5, x5, HEAP, lsl #32
    // 0x6934f8: LoadField: r6 = r5->field_b
    //     0x6934f8: ldur            w6, [x5, #0xb]
    // 0x6934fc: r5 = LoadInt32Instr(r1)
    //     0x6934fc: sbfx            x5, x1, #1, #0x1f
    // 0x693500: stur            x5, [fp, #-0x48]
    // 0x693504: r1 = LoadInt32Instr(r6)
    //     0x693504: sbfx            x1, x6, #1, #0x1f
    // 0x693508: cmp             x5, x1
    // 0x69350c: b.ne            #0x693518
    // 0x693510: mov             x1, x4
    // 0x693514: r0 = _growToNextCapacity()
    //     0x693514: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x693518: ldur            x2, [fp, #-0x10]
    // 0x69351c: ldur            x4, [fp, #-0x38]
    // 0x693520: ldur            x5, [fp, #-0x30]
    // 0x693524: ldur            x3, [fp, #-0x48]
    // 0x693528: add             x0, x3, #1
    // 0x69352c: lsl             x1, x0, #1
    // 0x693530: StoreField: r2->field_b = r1
    //     0x693530: stur            w1, [x2, #0xb]
    // 0x693534: LoadField: r1 = r2->field_f
    //     0x693534: ldur            w1, [x2, #0xf]
    // 0x693538: DecompressPointer r1
    //     0x693538: add             x1, x1, HEAP, lsl #32
    // 0x69353c: ldur            x0, [fp, #-0x18]
    // 0x693540: ArrayStore: r1[r3] = r0  ; List_4
    //     0x693540: add             x25, x1, x3, lsl #2
    //     0x693544: add             x25, x25, #0xf
    //     0x693548: str             w0, [x25]
    //     0x69354c: tbz             w0, #0, #0x693568
    //     0x693550: ldurb           w16, [x1, #-1]
    //     0x693554: ldurb           w17, [x0, #-1]
    //     0x693558: and             x16, x17, x16, lsr #2
    //     0x69355c: tst             x16, HEAP, lsr #32
    //     0x693560: b.eq            #0x693568
    //     0x693564: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x693568: cmp             x5, x4
    // 0x69356c: b.ne            #0x693578
    // 0x693570: r6 = true
    //     0x693570: add             x6, NULL, #0x20  ; true
    // 0x693574: b               #0x69357c
    // 0x693578: ldur            x6, [fp, #-0x28]
    // 0x69357c: add             x0, x5, #1
    // 0x693580: mov             x5, x0
    // 0x693584: mov             x3, x2
    // 0x693588: mov             x2, x4
    // 0x69358c: b               #0x693428
    // 0x693590: mov             x4, x2
    // 0x693594: mov             x2, x3
    // 0x693598: LoadField: r0 = r2->field_b
    //     0x693598: ldur            w0, [x2, #0xb]
    // 0x69359c: cbnz            w0, #0x6935b4
    // 0x6935a0: r0 = Instance_Text
    //     0x6935a0: add             x0, PP, #0x29, lsl #12  ; [pp+0x29648] Obj!Text@855a31
    //     0x6935a4: ldr             x0, [x0, #0x648]
    // 0x6935a8: LeaveFrame
    //     0x6935a8: mov             SP, fp
    //     0x6935ac: ldp             fp, lr, [SP], #0x10
    // 0x6935b0: ret
    //     0x6935b0: ret             
    // 0x6935b4: ldur            x0, [fp, #-0x28]
    // 0x6935b8: tbz             w0, #4, #0x6935d4
    // 0x6935bc: mov             x1, x2
    // 0x6935c0: r0 = last()
    //     0x6935c0: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x6935c4: LoadField: r1 = r0->field_1b
    //     0x6935c4: ldur            w1, [x0, #0x1b]
    // 0x6935c8: DecompressPointer r1
    //     0x6935c8: add             x1, x1, HEAP, lsl #32
    // 0x6935cc: mov             x5, x1
    // 0x6935d0: b               #0x6935ec
    // 0x6935d4: r0 = BoxInt64Instr(r4)
    //     0x6935d4: sbfiz           x0, x4, #1, #0x1f
    //     0x6935d8: cmp             x4, x0, asr #1
    //     0x6935dc: b.eq            #0x6935e8
    //     0x6935e0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6935e4: stur            x4, [x0, #7]
    // 0x6935e8: mov             x5, x0
    // 0x6935ec: stur            x5, [fp, #-8]
    // 0x6935f0: r1 = Function '<anonymous closure>':.
    //     0x6935f0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29650] AnonymousClosure: (0x69373c), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::makeRefactorLevelChooser (0x6933d8)
    //     0x6935f4: ldr             x1, [x1, #0x650]
    // 0x6935f8: r2 = Null
    //     0x6935f8: mov             x2, NULL
    // 0x6935fc: r0 = AllocateClosure()
    //     0x6935fc: bl              #0x826750  ; AllocateClosureStub
    // 0x693600: r1 = <int>
    //     0x693600: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x693604: stur            x0, [fp, #-0x18]
    // 0x693608: r0 = DropdownButton()
    //     0x693608: bl              #0x5a0fc8  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x69360c: mov             x1, x0
    // 0x693610: ldur            x2, [fp, #-0x10]
    // 0x693614: ldur            x3, [fp, #-0x18]
    // 0x693618: ldur            x5, [fp, #-8]
    // 0x69361c: stur            x0, [fp, #-8]
    // 0x693620: r0 = DropdownButton()
    //     0x693620: bl              #0x5a0ef8  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x693624: r0 = ListTile()
    //     0x693624: bl              #0x5a4e84  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x693628: mov             x1, x0
    // 0x69362c: r0 = Instance_Text
    //     0x69362c: add             x0, PP, #0x29, lsl #12  ; [pp+0x29658] Obj!Text@8559e1
    //     0x693630: ldr             x0, [x0, #0x658]
    // 0x693634: stur            x1, [fp, #-0x10]
    // 0x693638: StoreField: r1->field_f = r0
    //     0x693638: stur            w0, [x1, #0xf]
    // 0x69363c: ldur            x0, [fp, #-8]
    // 0x693640: ArrayStore: r1[0] = r0  ; List_4
    //     0x693640: stur            w0, [x1, #0x17]
    // 0x693644: r0 = true
    //     0x693644: add             x0, NULL, #0x20  ; true
    // 0x693648: StoreField: r1->field_4b = r0
    //     0x693648: stur            w0, [x1, #0x4b]
    // 0x69364c: r2 = false
    //     0x69364c: add             x2, NULL, #0x30  ; false
    // 0x693650: StoreField: r1->field_5f = r2
    //     0x693650: stur            w2, [x1, #0x5f]
    // 0x693654: StoreField: r1->field_73 = r2
    //     0x693654: stur            w2, [x1, #0x73]
    // 0x693658: StoreField: r1->field_97 = r0
    //     0x693658: stur            w0, [x1, #0x97]
    // 0x69365c: r0 = Padding()
    //     0x69365c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x693660: r1 = Instance_EdgeInsets
    //     0x693660: add             x1, PP, #0x29, lsl #12  ; [pp+0x29660] Obj!EdgeInsets@832e21
    //     0x693664: ldr             x1, [x1, #0x660]
    // 0x693668: StoreField: r0->field_f = r1
    //     0x693668: stur            w1, [x0, #0xf]
    // 0x69366c: ldur            x1, [fp, #-0x10]
    // 0x693670: StoreField: r0->field_b = r1
    //     0x693670: stur            w1, [x0, #0xb]
    // 0x693674: LeaveFrame
    //     0x693674: mov             SP, fp
    //     0x693678: ldp             fp, lr, [SP], #0x10
    // 0x69367c: ret
    //     0x69367c: ret             
    // 0x693680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693680: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693684: b               #0x6933f8
    // 0x693688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693688: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69368c: b               #0x693440
    // 0x693690: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x693690: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getRefactorLevel(/* No info */) {
    // ** addr: 0x6936a0, size: 0x9c
    // 0x6936a0: EnterFrame
    //     0x6936a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6936a4: mov             fp, SP
    // 0x6936a8: AllocStack(0x8)
    //     0x6936a8: sub             SP, SP, #8
    // 0x6936ac: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */)
    //     0x6936ac: mov             x0, x1
    //     0x6936b0: stur            x1, [fp, #-8]
    // 0x6936b4: CheckStackOverflow
    //     0x6936b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6936b8: cmp             SP, x16
    //     0x6936bc: b.ls            #0x693734
    // 0x6936c0: r1 = "ch10_refactor_level"
    //     0x6936c0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29608] "ch10_refactor_level"
    //     0x6936c4: ldr             x1, [x1, #0x608]
    // 0x6936c8: r0 = prefsGetInt()
    //     0x6936c8: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x6936cc: cmp             w0, NULL
    // 0x6936d0: b.eq            #0x693710
    // 0x6936d4: r1 = LoadInt32Instr(r0)
    //     0x6936d4: sbfx            x1, x0, #1, #0x1f
    //     0x6936d8: tbz             w0, #0, #0x6936e0
    //     0x6936dc: ldur            x1, [x0, #7]
    // 0x6936e0: cmp             x1, #0
    // 0x6936e4: b.le            #0x693708
    // 0x6936e8: ldur            x2, [fp, #-8]
    // 0x6936ec: LoadField: r3 = r2->field_8b
    //     0x6936ec: ldur            x3, [x2, #0x8b]
    // 0x6936f0: cmp             x1, x3
    // 0x6936f4: b.gt            #0x693714
    // 0x6936f8: mov             x0, x1
    // 0x6936fc: LeaveFrame
    //     0x6936fc: mov             SP, fp
    //     0x693700: ldp             fp, lr, [SP], #0x10
    // 0x693704: ret
    //     0x693704: ret             
    // 0x693708: ldur            x2, [fp, #-8]
    // 0x69370c: b               #0x693714
    // 0x693710: ldur            x2, [fp, #-8]
    // 0x693714: r1 = 0
    //     0x693714: movz            x1, #0
    // 0x693718: LoadField: r3 = r2->field_8b
    //     0x693718: ldur            x3, [x2, #0x8b]
    // 0x69371c: sub             x2, x3, #1
    // 0x693720: cmp             x2, x1
    // 0x693724: csel            x0, x1, x2, lt
    // 0x693728: LeaveFrame
    //     0x693728: mov             SP, fp
    //     0x69372c: ldp             fp, lr, [SP], #0x10
    // 0x693730: ret
    //     0x693730: ret             
    // 0x693734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693734: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693738: b               #0x6936c0
  }
  [closure] void <anonymous closure>(dynamic, int?) {
    // ** addr: 0x69373c, size: 0x68
    // 0x69373c: EnterFrame
    //     0x69373c: stp             fp, lr, [SP, #-0x10]!
    //     0x693740: mov             fp, SP
    // 0x693744: AllocStack(0x8)
    //     0x693744: sub             SP, SP, #8
    // 0x693748: CheckStackOverflow
    //     0x693748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69374c: cmp             SP, x16
    //     0x693750: b.ls            #0x69379c
    // 0x693754: ldr             x0, [fp, #0x10]
    // 0x693758: cmp             w0, NULL
    // 0x69375c: b.eq            #0x69378c
    // 0x693760: r2 = LoadInt32Instr(r0)
    //     0x693760: sbfx            x2, x0, #1, #0x1f
    //     0x693764: tbz             w0, #0, #0x69376c
    //     0x693768: ldur            x2, [x0, #7]
    // 0x69376c: r1 = "ch10_refactor_level"
    //     0x69376c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29608] "ch10_refactor_level"
    //     0x693770: ldr             x1, [x1, #0x608]
    // 0x693774: r0 = prefsSetInt()
    //     0x693774: bl              #0x35e50c  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetInt
    // 0x693778: r16 = <ChapterViewportState>
    //     0x693778: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9e0] TypeArguments: <ChapterViewportState>
    //     0x69377c: ldr             x16, [x16, #0x9e0]
    // 0x693780: str             x16, [SP]
    // 0x693784: r4 = const [0x1, 0, 0, 0, null]
    //     0x693784: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x693788: r0 = updateAll()
    //     0x693788: bl              #0x4589c0  ; [package:state_groups/src/sync_state.dart] ::updateAll
    // 0x69378c: r0 = Null
    //     0x69378c: mov             x0, NULL
    // 0x693790: LeaveFrame
    //     0x693790: mov             SP, fp
    //     0x693794: ldp             fp, lr, [SP], #0x10
    // 0x693798: ret
    //     0x693798: ret             
    // 0x69379c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69379c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6937a0: b               #0x693754
  }
  _ generatorsToDisplay(/* No info */) {
    // ** addr: 0x6937bc, size: 0x278
    // 0x6937bc: EnterFrame
    //     0x6937bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6937c0: mov             fp, SP
    // 0x6937c4: AllocStack(0x20)
    //     0x6937c4: sub             SP, SP, #0x20
    // 0x6937c8: r0 = 4
    //     0x6937c8: movz            x0, #0x4
    // 0x6937cc: mov             x3, x1
    // 0x6937d0: stur            x1, [fp, #-8]
    // 0x6937d4: CheckStackOverflow
    //     0x6937d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6937d8: cmp             SP, x16
    //     0x6937dc: b.ls            #0x693a1c
    // 0x6937e0: mov             x2, x0
    // 0x6937e4: r1 = Null
    //     0x6937e4: mov             x1, NULL
    // 0x6937e8: r0 = AllocateArray()
    //     0x6937e8: bl              #0x82746c  ; AllocateArrayStub
    // 0x6937ec: stur            x0, [fp, #-0x10]
    // 0x6937f0: r16 = 2
    //     0x6937f0: movz            x16, #0x2
    // 0x6937f4: StoreField: r0->field_f = r16
    //     0x6937f4: stur            w16, [x0, #0xf]
    // 0x6937f8: r16 = 4
    //     0x6937f8: movz            x16, #0x4
    // 0x6937fc: StoreField: r0->field_13 = r16
    //     0x6937fc: stur            w16, [x0, #0x13]
    // 0x693800: r1 = <int>
    //     0x693800: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x693804: r0 = AllocateGrowableArray()
    //     0x693804: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x693808: mov             x2, x0
    // 0x69380c: ldur            x0, [fp, #-0x10]
    // 0x693810: stur            x2, [fp, #-0x18]
    // 0x693814: StoreField: r2->field_f = r0
    //     0x693814: stur            w0, [x2, #0xf]
    // 0x693818: r1 = 4
    //     0x693818: movz            x1, #0x4
    // 0x69381c: StoreField: r2->field_b = r1
    //     0x69381c: stur            w1, [x2, #0xb]
    // 0x693820: ldur            x3, [fp, #-8]
    // 0x693824: LoadField: r1 = r3->field_8b
    //     0x693824: ldur            x1, [x3, #0x8b]
    // 0x693828: cmp             x1, #1
    // 0x69382c: b.le            #0x693860
    // 0x693830: mov             x1, x2
    // 0x693834: r0 = _growToNextCapacity()
    //     0x693834: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x693838: ldur            x2, [fp, #-0x18]
    // 0x69383c: r0 = 6
    //     0x69383c: movz            x0, #0x6
    // 0x693840: StoreField: r2->field_b = r0
    //     0x693840: stur            w0, [x2, #0xb]
    // 0x693844: LoadField: r0 = r2->field_f
    //     0x693844: ldur            w0, [x2, #0xf]
    // 0x693848: DecompressPointer r0
    //     0x693848: add             x0, x0, HEAP, lsl #32
    // 0x69384c: r16 = 6
    //     0x69384c: movz            x16, #0x6
    // 0x693850: ArrayStore: r0[0] = r16  ; List_4
    //     0x693850: stur            w16, [x0, #0x17]
    // 0x693854: mov             x1, x0
    // 0x693858: r3 = 3
    //     0x693858: movz            x3, #0x3
    // 0x69385c: b               #0x693868
    // 0x693860: mov             x1, x0
    // 0x693864: r3 = 2
    //     0x693864: movz            x3, #0x2
    // 0x693868: ldur            x0, [fp, #-8]
    // 0x69386c: stur            x3, [fp, #-0x20]
    // 0x693870: LoadField: r4 = r0->field_8b
    //     0x693870: ldur            x4, [x0, #0x8b]
    // 0x693874: cmp             x4, #2
    // 0x693878: b.le            #0x6938d4
    // 0x69387c: LoadField: r4 = r1->field_b
    //     0x69387c: ldur            w4, [x1, #0xb]
    // 0x693880: r1 = LoadInt32Instr(r4)
    //     0x693880: sbfx            x1, x4, #1, #0x1f
    // 0x693884: cmp             x3, x1
    // 0x693888: b.ne            #0x693894
    // 0x69388c: mov             x1, x2
    // 0x693890: r0 = _growToNextCapacity()
    //     0x693890: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x693894: ldur            x2, [fp, #-0x18]
    // 0x693898: ldur            x3, [fp, #-0x20]
    // 0x69389c: add             x4, x3, #1
    // 0x6938a0: lsl             x0, x4, #1
    // 0x6938a4: StoreField: r2->field_b = r0
    //     0x6938a4: stur            w0, [x2, #0xb]
    // 0x6938a8: mov             x0, x4
    // 0x6938ac: mov             x1, x3
    // 0x6938b0: cmp             x1, x0
    // 0x6938b4: b.hs            #0x693a24
    // 0x6938b8: LoadField: r0 = r2->field_f
    //     0x6938b8: ldur            w0, [x2, #0xf]
    // 0x6938bc: DecompressPointer r0
    //     0x6938bc: add             x0, x0, HEAP, lsl #32
    // 0x6938c0: add             x1, x0, x3, lsl #2
    // 0x6938c4: r16 = 8
    //     0x6938c4: movz            x16, #0x8
    // 0x6938c8: StoreField: r1->field_f = r16
    //     0x6938c8: stur            w16, [x1, #0xf]
    // 0x6938cc: mov             x1, x0
    // 0x6938d0: mov             x3, x4
    // 0x6938d4: ldur            x0, [fp, #-8]
    // 0x6938d8: stur            x3, [fp, #-0x20]
    // 0x6938dc: LoadField: r4 = r0->field_8b
    //     0x6938dc: ldur            x4, [x0, #0x8b]
    // 0x6938e0: cmp             x4, #4
    // 0x6938e4: b.le            #0x693940
    // 0x6938e8: LoadField: r4 = r1->field_b
    //     0x6938e8: ldur            w4, [x1, #0xb]
    // 0x6938ec: r1 = LoadInt32Instr(r4)
    //     0x6938ec: sbfx            x1, x4, #1, #0x1f
    // 0x6938f0: cmp             x3, x1
    // 0x6938f4: b.ne            #0x693900
    // 0x6938f8: mov             x1, x2
    // 0x6938fc: r0 = _growToNextCapacity()
    //     0x6938fc: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x693900: ldur            x2, [fp, #-0x18]
    // 0x693904: ldur            x3, [fp, #-0x20]
    // 0x693908: add             x4, x3, #1
    // 0x69390c: lsl             x0, x4, #1
    // 0x693910: StoreField: r2->field_b = r0
    //     0x693910: stur            w0, [x2, #0xb]
    // 0x693914: mov             x0, x4
    // 0x693918: mov             x1, x3
    // 0x69391c: cmp             x1, x0
    // 0x693920: b.hs            #0x693a28
    // 0x693924: LoadField: r0 = r2->field_f
    //     0x693924: ldur            w0, [x2, #0xf]
    // 0x693928: DecompressPointer r0
    //     0x693928: add             x0, x0, HEAP, lsl #32
    // 0x69392c: add             x1, x0, x3, lsl #2
    // 0x693930: r16 = 10
    //     0x693930: movz            x16, #0xa
    // 0x693934: StoreField: r1->field_f = r16
    //     0x693934: stur            w16, [x1, #0xf]
    // 0x693938: mov             x1, x0
    // 0x69393c: mov             x3, x4
    // 0x693940: ldur            x0, [fp, #-8]
    // 0x693944: stur            x3, [fp, #-0x20]
    // 0x693948: LoadField: r4 = r0->field_8b
    //     0x693948: ldur            x4, [x0, #0x8b]
    // 0x69394c: cmp             x4, #5
    // 0x693950: b.le            #0x6939ac
    // 0x693954: LoadField: r4 = r1->field_b
    //     0x693954: ldur            w4, [x1, #0xb]
    // 0x693958: r1 = LoadInt32Instr(r4)
    //     0x693958: sbfx            x1, x4, #1, #0x1f
    // 0x69395c: cmp             x3, x1
    // 0x693960: b.ne            #0x69396c
    // 0x693964: mov             x1, x2
    // 0x693968: r0 = _growToNextCapacity()
    //     0x693968: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69396c: ldur            x2, [fp, #-0x18]
    // 0x693970: ldur            x3, [fp, #-0x20]
    // 0x693974: add             x4, x3, #1
    // 0x693978: lsl             x0, x4, #1
    // 0x69397c: StoreField: r2->field_b = r0
    //     0x69397c: stur            w0, [x2, #0xb]
    // 0x693980: mov             x0, x4
    // 0x693984: mov             x1, x3
    // 0x693988: cmp             x1, x0
    // 0x69398c: b.hs            #0x693a2c
    // 0x693990: LoadField: r0 = r2->field_f
    //     0x693990: ldur            w0, [x2, #0xf]
    // 0x693994: DecompressPointer r0
    //     0x693994: add             x0, x0, HEAP, lsl #32
    // 0x693998: add             x1, x0, x3, lsl #2
    // 0x69399c: r16 = 12
    //     0x69399c: movz            x16, #0xc
    // 0x6939a0: StoreField: r1->field_f = r16
    //     0x6939a0: stur            w16, [x1, #0xf]
    // 0x6939a4: mov             x1, x0
    // 0x6939a8: mov             x3, x4
    // 0x6939ac: ldur            x0, [fp, #-8]
    // 0x6939b0: stur            x3, [fp, #-0x20]
    // 0x6939b4: LoadField: r4 = r0->field_8b
    //     0x6939b4: ldur            x4, [x0, #0x8b]
    // 0x6939b8: cmp             x4, #6
    // 0x6939bc: b.le            #0x693a0c
    // 0x6939c0: LoadField: r0 = r1->field_b
    //     0x6939c0: ldur            w0, [x1, #0xb]
    // 0x6939c4: r1 = LoadInt32Instr(r0)
    //     0x6939c4: sbfx            x1, x0, #1, #0x1f
    // 0x6939c8: cmp             x3, x1
    // 0x6939cc: b.ne            #0x6939d8
    // 0x6939d0: mov             x1, x2
    // 0x6939d4: r0 = _growToNextCapacity()
    //     0x6939d4: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6939d8: ldur            x2, [fp, #-0x18]
    // 0x6939dc: ldur            x3, [fp, #-0x20]
    // 0x6939e0: add             x0, x3, #1
    // 0x6939e4: lsl             x4, x0, #1
    // 0x6939e8: StoreField: r2->field_b = r4
    //     0x6939e8: stur            w4, [x2, #0xb]
    // 0x6939ec: mov             x1, x3
    // 0x6939f0: cmp             x1, x0
    // 0x6939f4: b.hs            #0x693a30
    // 0x6939f8: LoadField: r1 = r2->field_f
    //     0x6939f8: ldur            w1, [x2, #0xf]
    // 0x6939fc: DecompressPointer r1
    //     0x6939fc: add             x1, x1, HEAP, lsl #32
    // 0x693a00: add             x4, x1, x3, lsl #2
    // 0x693a04: r16 = 14
    //     0x693a04: movz            x16, #0xe
    // 0x693a08: StoreField: r4->field_f = r16
    //     0x693a08: stur            w16, [x4, #0xf]
    // 0x693a0c: mov             x0, x2
    // 0x693a10: LeaveFrame
    //     0x693a10: mov             SP, fp
    //     0x693a14: ldp             fp, lr, [SP], #0x10
    // 0x693a18: ret
    //     0x693a18: ret             
    // 0x693a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693a1c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693a20: b               #0x6937e0
    // 0x693a24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x693a24: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x693a28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x693a28: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x693a2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x693a2c: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x693a30: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x693a30: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void kernelReset(dynamic) {
    // ** addr: 0x693a98, size: 0x38
    // 0x693a98: EnterFrame
    //     0x693a98: stp             fp, lr, [SP, #-0x10]!
    //     0x693a9c: mov             fp, SP
    // 0x693aa0: ldr             x0, [fp, #0x10]
    // 0x693aa4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x693aa4: ldur            w1, [x0, #0x17]
    // 0x693aa8: DecompressPointer r1
    //     0x693aa8: add             x1, x1, HEAP, lsl #32
    // 0x693aac: CheckStackOverflow
    //     0x693aac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693ab0: cmp             SP, x16
    //     0x693ab4: b.ls            #0x693ac8
    // 0x693ab8: r0 = kernelReset()
    //     0x693ab8: bl              #0x693ad0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::kernelReset
    // 0x693abc: LeaveFrame
    //     0x693abc: mov             SP, fp
    //     0x693ac0: ldp             fp, lr, [SP], #0x10
    // 0x693ac4: ret
    //     0x693ac4: ret             
    // 0x693ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693ac8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693acc: b               #0x693ab8
  }
  _ kernelReset(/* No info */) {
    // ** addr: 0x693ad0, size: 0x1ec
    // 0x693ad0: EnterFrame
    //     0x693ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x693ad4: mov             fp, SP
    // 0x693ad8: AllocStack(0x8)
    //     0x693ad8: sub             SP, SP, #8
    // 0x693adc: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */)
    //     0x693adc: mov             x0, x1
    //     0x693ae0: stur            x1, [fp, #-8]
    // 0x693ae4: CheckStackOverflow
    //     0x693ae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693ae8: cmp             SP, x16
    //     0x693aec: b.ls            #0x693cb4
    // 0x693af0: LoadField: r1 = r0->field_8b
    //     0x693af0: ldur            x1, [x0, #0x8b]
    // 0x693af4: r16 = 100
    //     0x693af4: movz            x16, #0x64
    // 0x693af8: mul             x2, x1, x16
    // 0x693afc: mov             x1, x0
    // 0x693b00: r0 = _setCurrentDisplayProgress()
    //     0x693b00: bl              #0x4561dc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::_setCurrentDisplayProgress
    // 0x693b04: ldur            x0, [fp, #-8]
    // 0x693b08: LoadField: r1 = r0->field_37
    //     0x693b08: ldur            w1, [x0, #0x37]
    // 0x693b0c: DecompressPointer r1
    //     0x693b0c: add             x1, x1, HEAP, lsl #32
    // 0x693b10: r2 = Instance_Chapter10Stat
    //     0x693b10: add             x2, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x693b14: ldr             x2, [x2, #0x798]
    // 0x693b18: r0 = remove()
    //     0x693b18: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693b1c: ldur            x0, [fp, #-8]
    // 0x693b20: LoadField: r1 = r0->field_3b
    //     0x693b20: ldur            w1, [x0, #0x3b]
    // 0x693b24: DecompressPointer r1
    //     0x693b24: add             x1, x1, HEAP, lsl #32
    // 0x693b28: r2 = Instance_Chapter10Stat
    //     0x693b28: add             x2, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x693b2c: ldr             x2, [x2, #0x798]
    // 0x693b30: r0 = remove()
    //     0x693b30: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693b34: ldur            x0, [fp, #-8]
    // 0x693b38: LoadField: r1 = r0->field_37
    //     0x693b38: ldur            w1, [x0, #0x37]
    // 0x693b3c: DecompressPointer r1
    //     0x693b3c: add             x1, x1, HEAP, lsl #32
    // 0x693b40: r2 = Instance_Chapter10Stat
    //     0x693b40: add             x2, PP, #0x11, lsl #12  ; [pp+0x11720] Obj!Chapter10Stat@85fee1
    //     0x693b44: ldr             x2, [x2, #0x720]
    // 0x693b48: r0 = remove()
    //     0x693b48: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693b4c: ldur            x0, [fp, #-8]
    // 0x693b50: LoadField: r1 = r0->field_37
    //     0x693b50: ldur            w1, [x0, #0x37]
    // 0x693b54: DecompressPointer r1
    //     0x693b54: add             x1, x1, HEAP, lsl #32
    // 0x693b58: r2 = Instance_Chapter10Stat
    //     0x693b58: add             x2, PP, #0x11, lsl #12  ; [pp+0x11748] Obj!Chapter10Stat@85fe41
    //     0x693b5c: ldr             x2, [x2, #0x748]
    // 0x693b60: r0 = remove()
    //     0x693b60: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693b64: ldur            x0, [fp, #-8]
    // 0x693b68: LoadField: r1 = r0->field_37
    //     0x693b68: ldur            w1, [x0, #0x37]
    // 0x693b6c: DecompressPointer r1
    //     0x693b6c: add             x1, x1, HEAP, lsl #32
    // 0x693b70: r2 = Instance_Chapter10Stat
    //     0x693b70: add             x2, PP, #0x11, lsl #12  ; [pp+0x11740] Obj!Chapter10Stat@85fe61
    //     0x693b74: ldr             x2, [x2, #0x740]
    // 0x693b78: r0 = remove()
    //     0x693b78: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693b7c: ldur            x0, [fp, #-8]
    // 0x693b80: LoadField: r1 = r0->field_37
    //     0x693b80: ldur            w1, [x0, #0x37]
    // 0x693b84: DecompressPointer r1
    //     0x693b84: add             x1, x1, HEAP, lsl #32
    // 0x693b88: r2 = Instance_Chapter10Stat
    //     0x693b88: add             x2, PP, #0x11, lsl #12  ; [pp+0x11738] Obj!Chapter10Stat@85fe81
    //     0x693b8c: ldr             x2, [x2, #0x738]
    // 0x693b90: r0 = remove()
    //     0x693b90: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693b94: ldur            x0, [fp, #-8]
    // 0x693b98: LoadField: r1 = r0->field_37
    //     0x693b98: ldur            w1, [x0, #0x37]
    // 0x693b9c: DecompressPointer r1
    //     0x693b9c: add             x1, x1, HEAP, lsl #32
    // 0x693ba0: r2 = Instance_Chapter10Stat
    //     0x693ba0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11730] Obj!Chapter10Stat@85fea1
    //     0x693ba4: ldr             x2, [x2, #0x730]
    // 0x693ba8: r0 = remove()
    //     0x693ba8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693bac: ldur            x0, [fp, #-8]
    // 0x693bb0: LoadField: r1 = r0->field_37
    //     0x693bb0: ldur            w1, [x0, #0x37]
    // 0x693bb4: DecompressPointer r1
    //     0x693bb4: add             x1, x1, HEAP, lsl #32
    // 0x693bb8: r2 = Instance_Chapter10Stat
    //     0x693bb8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11728] Obj!Chapter10Stat@85fec1
    //     0x693bbc: ldr             x2, [x2, #0x728]
    // 0x693bc0: r0 = remove()
    //     0x693bc0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693bc4: ldur            x0, [fp, #-8]
    // 0x693bc8: LoadField: r1 = r0->field_47
    //     0x693bc8: ldur            w1, [x0, #0x47]
    // 0x693bcc: DecompressPointer r1
    //     0x693bcc: add             x1, x1, HEAP, lsl #32
    // 0x693bd0: r2 = 2
    //     0x693bd0: movz            x2, #0x2
    // 0x693bd4: r0 = remove()
    //     0x693bd4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693bd8: ldur            x0, [fp, #-8]
    // 0x693bdc: LoadField: r1 = r0->field_47
    //     0x693bdc: ldur            w1, [x0, #0x47]
    // 0x693be0: DecompressPointer r1
    //     0x693be0: add             x1, x1, HEAP, lsl #32
    // 0x693be4: r2 = 4
    //     0x693be4: movz            x2, #0x4
    // 0x693be8: r0 = remove()
    //     0x693be8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693bec: ldur            x0, [fp, #-8]
    // 0x693bf0: LoadField: r1 = r0->field_47
    //     0x693bf0: ldur            w1, [x0, #0x47]
    // 0x693bf4: DecompressPointer r1
    //     0x693bf4: add             x1, x1, HEAP, lsl #32
    // 0x693bf8: r2 = 6
    //     0x693bf8: movz            x2, #0x6
    // 0x693bfc: r0 = remove()
    //     0x693bfc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c00: ldur            x0, [fp, #-8]
    // 0x693c04: LoadField: r1 = r0->field_47
    //     0x693c04: ldur            w1, [x0, #0x47]
    // 0x693c08: DecompressPointer r1
    //     0x693c08: add             x1, x1, HEAP, lsl #32
    // 0x693c0c: r2 = 8
    //     0x693c0c: movz            x2, #0x8
    // 0x693c10: r0 = remove()
    //     0x693c10: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c14: ldur            x0, [fp, #-8]
    // 0x693c18: LoadField: r1 = r0->field_47
    //     0x693c18: ldur            w1, [x0, #0x47]
    // 0x693c1c: DecompressPointer r1
    //     0x693c1c: add             x1, x1, HEAP, lsl #32
    // 0x693c20: r2 = 10
    //     0x693c20: movz            x2, #0xa
    // 0x693c24: r0 = remove()
    //     0x693c24: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c28: ldur            x0, [fp, #-8]
    // 0x693c2c: LoadField: r1 = r0->field_47
    //     0x693c2c: ldur            w1, [x0, #0x47]
    // 0x693c30: DecompressPointer r1
    //     0x693c30: add             x1, x1, HEAP, lsl #32
    // 0x693c34: r2 = 12
    //     0x693c34: movz            x2, #0xc
    // 0x693c38: r0 = remove()
    //     0x693c38: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c3c: ldur            x0, [fp, #-8]
    // 0x693c40: LoadField: r1 = r0->field_47
    //     0x693c40: ldur            w1, [x0, #0x47]
    // 0x693c44: DecompressPointer r1
    //     0x693c44: add             x1, x1, HEAP, lsl #32
    // 0x693c48: r2 = 14
    //     0x693c48: movz            x2, #0xe
    // 0x693c4c: r0 = remove()
    //     0x693c4c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c50: ldur            x0, [fp, #-8]
    // 0x693c54: LoadField: r1 = r0->field_47
    //     0x693c54: ldur            w1, [x0, #0x47]
    // 0x693c58: DecompressPointer r1
    //     0x693c58: add             x1, x1, HEAP, lsl #32
    // 0x693c5c: r2 = 16
    //     0x693c5c: movz            x2, #0x10
    // 0x693c60: r0 = remove()
    //     0x693c60: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c64: ldur            x0, [fp, #-8]
    // 0x693c68: LoadField: r1 = r0->field_43
    //     0x693c68: ldur            w1, [x0, #0x43]
    // 0x693c6c: DecompressPointer r1
    //     0x693c6c: add             x1, x1, HEAP, lsl #32
    // 0x693c70: r2 = 6
    //     0x693c70: movz            x2, #0x6
    // 0x693c74: r0 = containsKey()
    //     0x693c74: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x693c78: tbz             w0, #4, #0x693ca4
    // 0x693c7c: ldur            x0, [fp, #-8]
    // 0x693c80: LoadField: r1 = r0->field_43
    //     0x693c80: ldur            w1, [x0, #0x43]
    // 0x693c84: DecompressPointer r1
    //     0x693c84: add             x1, x1, HEAP, lsl #32
    // 0x693c88: r2 = 2
    //     0x693c88: movz            x2, #0x2
    // 0x693c8c: r0 = remove()
    //     0x693c8c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693c90: ldur            x0, [fp, #-8]
    // 0x693c94: LoadField: r1 = r0->field_43
    //     0x693c94: ldur            w1, [x0, #0x43]
    // 0x693c98: DecompressPointer r1
    //     0x693c98: add             x1, x1, HEAP, lsl #32
    // 0x693c9c: r2 = 4
    //     0x693c9c: movz            x2, #0x4
    // 0x693ca0: r0 = remove()
    //     0x693ca0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x693ca4: r0 = Null
    //     0x693ca4: mov             x0, NULL
    // 0x693ca8: LeaveFrame
    //     0x693ca8: mov             SP, fp
    //     0x693cac: ldp             fp, lr, [SP], #0x10
    // 0x693cb0: ret
    //     0x693cb0: ret             
    // 0x693cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693cb4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693cb8: b               #0x693af0
  }
  [closure] void questReset(dynamic) {
    // ** addr: 0x693cbc, size: 0x38
    // 0x693cbc: EnterFrame
    //     0x693cbc: stp             fp, lr, [SP, #-0x10]!
    //     0x693cc0: mov             fp, SP
    // 0x693cc4: ldr             x0, [fp, #0x10]
    // 0x693cc8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x693cc8: ldur            w1, [x0, #0x17]
    // 0x693ccc: DecompressPointer r1
    //     0x693ccc: add             x1, x1, HEAP, lsl #32
    // 0x693cd0: CheckStackOverflow
    //     0x693cd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693cd4: cmp             SP, x16
    //     0x693cd8: b.ls            #0x693cec
    // 0x693cdc: r0 = questReset()
    //     0x693cdc: bl              #0x693cf4  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::questReset
    // 0x693ce0: LeaveFrame
    //     0x693ce0: mov             SP, fp
    //     0x693ce4: ldp             fp, lr, [SP], #0x10
    // 0x693ce8: ret
    //     0x693ce8: ret             
    // 0x693cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693cec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693cf0: b               #0x693cdc
  }
  _ questReset(/* No info */) {
    // ** addr: 0x693cf4, size: 0x12c
    // 0x693cf4: EnterFrame
    //     0x693cf4: stp             fp, lr, [SP, #-0x10]!
    //     0x693cf8: mov             fp, SP
    // 0x693cfc: AllocStack(0x30)
    //     0x693cfc: sub             SP, SP, #0x30
    // 0x693d00: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x10 */)
    //     0x693d00: mov             x0, x1
    //     0x693d04: stur            x1, [fp, #-0x10]
    // 0x693d08: CheckStackOverflow
    //     0x693d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693d0c: cmp             SP, x16
    //     0x693d10: b.ls            #0x693e18
    // 0x693d14: LoadField: r2 = r0->field_37
    //     0x693d14: ldur            w2, [x0, #0x37]
    // 0x693d18: DecompressPointer r2
    //     0x693d18: add             x2, x2, HEAP, lsl #32
    // 0x693d1c: mov             x1, x0
    // 0x693d20: stur            x2, [fp, #-8]
    // 0x693d24: r0 = minUtilityToPrestige()
    //     0x693d24: bl              #0x69441c  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::minUtilityToPrestige
    // 0x693d28: r1 = <Chapter10Stat, CustomNum>
    //     0x693d28: add             x1, PP, #0x16, lsl #12  ; [pp+0x16720] TypeArguments: <Chapter10Stat, CustomNum>
    //     0x693d2c: ldr             x1, [x1, #0x720]
    // 0x693d30: stur            x0, [fp, #-0x18]
    // 0x693d34: r0 = Tuple2()
    //     0x693d34: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x693d38: mov             x1, x0
    // 0x693d3c: r0 = Instance_Chapter10Stat
    //     0x693d3c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x693d40: ldr             x0, [x0, #0x798]
    // 0x693d44: StoreField: r1->field_b = r0
    //     0x693d44: stur            w0, [x1, #0xb]
    // 0x693d48: ldur            x0, [fp, #-0x18]
    // 0x693d4c: StoreField: r1->field_f = r0
    //     0x693d4c: stur            w0, [x1, #0xf]
    // 0x693d50: r16 = <Chapter10Stat>
    //     0x693d50: add             x16, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x693d54: ldr             x16, [x16, #0xe80]
    // 0x693d58: ldur            lr, [fp, #-8]
    // 0x693d5c: stp             lr, x16, [SP, #8]
    // 0x693d60: str             x1, [SP]
    // 0x693d64: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x693d64: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x693d68: r0 = MapOperations.isSupersetOfTuple()
    //     0x693d68: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x693d6c: tbnz            w0, #4, #0x693e00
    // 0x693d70: ldur            x0, [fp, #-0x10]
    // 0x693d74: LoadField: r3 = r0->field_37
    //     0x693d74: ldur            w3, [x0, #0x37]
    // 0x693d78: DecompressPointer r3
    //     0x693d78: add             x3, x3, HEAP, lsl #32
    // 0x693d7c: mov             x1, x3
    // 0x693d80: stur            x3, [fp, #-8]
    // 0x693d84: r2 = Instance_Chapter10Stat
    //     0x693d84: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x693d88: ldr             x2, [x2, #0x7d8]
    // 0x693d8c: r0 = _getValueOrData()
    //     0x693d8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x693d90: mov             x1, x0
    // 0x693d94: ldur            x0, [fp, #-8]
    // 0x693d98: LoadField: r2 = r0->field_f
    //     0x693d98: ldur            w2, [x0, #0xf]
    // 0x693d9c: DecompressPointer r2
    //     0x693d9c: add             x2, x2, HEAP, lsl #32
    // 0x693da0: cmp             w2, w1
    // 0x693da4: b.ne            #0x693dac
    // 0x693da8: r1 = Null
    //     0x693da8: mov             x1, NULL
    // 0x693dac: cmp             w1, NULL
    // 0x693db0: b.ne            #0x693dc0
    // 0x693db4: r2 = Instance_CustomNum
    //     0x693db4: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x693db8: ldr             x2, [x2, #0xaf8]
    // 0x693dbc: b               #0x693dc4
    // 0x693dc0: mov             x2, x1
    // 0x693dc4: ldur            x1, [fp, #-0x10]
    // 0x693dc8: stur            x2, [fp, #-0x18]
    // 0x693dcc: r0 = presitgePointsFromRefactor()
    //     0x693dcc: bl              #0x693e20  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::presitgePointsFromRefactor
    // 0x693dd0: ldur            x1, [fp, #-0x18]
    // 0x693dd4: mov             x2, x0
    // 0x693dd8: r0 = add()
    //     0x693dd8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x693ddc: ldur            x1, [fp, #-8]
    // 0x693de0: mov             x3, x0
    // 0x693de4: r2 = Instance_Chapter10Stat
    //     0x693de4: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x693de8: ldr             x2, [x2, #0x7d8]
    // 0x693dec: r0 = []=()
    //     0x693dec: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x693df0: ldur            x1, [fp, #-0x10]
    // 0x693df4: r2 = Instance_Chapter10Stat
    //     0x693df4: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x693df8: ldr             x2, [x2, #0x7d8]
    // 0x693dfc: r0 = notifyStatGained()
    //     0x693dfc: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x693e00: ldur            x1, [fp, #-0x10]
    // 0x693e04: r0 = kernelReset()
    //     0x693e04: bl              #0x693ad0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::kernelReset
    // 0x693e08: r0 = Null
    //     0x693e08: mov             x0, NULL
    // 0x693e0c: LeaveFrame
    //     0x693e0c: mov             SP, fp
    //     0x693e10: ldp             fp, lr, [SP], #0x10
    // 0x693e14: ret
    //     0x693e14: ret             
    // 0x693e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693e18: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693e1c: b               #0x693d14
  }
  _ presitgePointsFromRefactor(/* No info */) {
    // ** addr: 0x693e20, size: 0x574
    // 0x693e20: EnterFrame
    //     0x693e20: stp             fp, lr, [SP, #-0x10]!
    //     0x693e24: mov             fp, SP
    // 0x693e28: AllocStack(0x50)
    //     0x693e28: sub             SP, SP, #0x50
    // 0x693e2c: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */)
    //     0x693e2c: mov             x0, x1
    //     0x693e30: stur            x1, [fp, #-8]
    // 0x693e34: CheckStackOverflow
    //     0x693e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693e38: cmp             SP, x16
    //     0x693e3c: b.ls            #0x694358
    // 0x693e40: mov             x1, x0
    // 0x693e44: r0 = getRefactorLevel()
    //     0x693e44: bl              #0x6936a0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getRefactorLevel
    // 0x693e48: mov             x3, x0
    // 0x693e4c: ldur            x0, [fp, #-8]
    // 0x693e50: stur            x3, [fp, #-0x18]
    // 0x693e54: LoadField: r1 = r0->field_8b
    //     0x693e54: ldur            x1, [x0, #0x8b]
    // 0x693e58: sub             x2, x1, #1
    // 0x693e5c: r1 = 0
    //     0x693e5c: movz            x1, #0
    // 0x693e60: cmp             x2, x1
    // 0x693e64: csel            x4, x1, x2, lt
    // 0x693e68: sub             x5, x3, x4
    // 0x693e6c: mov             x1, x0
    // 0x693e70: mov             x2, x3
    // 0x693e74: stur            x5, [fp, #-0x10]
    // 0x693e78: r0 = getRequiredUtility()
    //     0x693e78: bl              #0x694394  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getRequiredUtility
    // 0x693e7c: mov             x3, x0
    // 0x693e80: ldur            x0, [fp, #-8]
    // 0x693e84: stur            x3, [fp, #-0x28]
    // 0x693e88: LoadField: r4 = r0->field_3b
    //     0x693e88: ldur            w4, [x0, #0x3b]
    // 0x693e8c: DecompressPointer r4
    //     0x693e8c: add             x4, x4, HEAP, lsl #32
    // 0x693e90: mov             x1, x4
    // 0x693e94: stur            x4, [fp, #-0x20]
    // 0x693e98: r2 = Instance_Chapter10Stat
    //     0x693e98: add             x2, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x693e9c: ldr             x2, [x2, #0x798]
    // 0x693ea0: r0 = _getValueOrData()
    //     0x693ea0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x693ea4: mov             x1, x0
    // 0x693ea8: ldur            x0, [fp, #-0x20]
    // 0x693eac: LoadField: r2 = r0->field_f
    //     0x693eac: ldur            w2, [x0, #0xf]
    // 0x693eb0: DecompressPointer r2
    //     0x693eb0: add             x2, x2, HEAP, lsl #32
    // 0x693eb4: cmp             w2, w1
    // 0x693eb8: b.ne            #0x693ec4
    // 0x693ebc: r0 = Null
    //     0x693ebc: mov             x0, NULL
    // 0x693ec0: b               #0x693ec8
    // 0x693ec4: mov             x0, x1
    // 0x693ec8: cmp             w0, NULL
    // 0x693ecc: b.ne            #0x693edc
    // 0x693ed0: r2 = Instance_CustomNum
    //     0x693ed0: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x693ed4: ldr             x2, [x2, #0xaf8]
    // 0x693ed8: b               #0x693ee0
    // 0x693edc: mov             x2, x0
    // 0x693ee0: ldur            x0, [fp, #-8]
    // 0x693ee4: ldur            x1, [fp, #-0x28]
    // 0x693ee8: stur            x2, [fp, #-0x20]
    // 0x693eec: r0 = invert()
    //     0x693eec: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x693ef0: ldur            x1, [fp, #-0x20]
    // 0x693ef4: mov             x2, x0
    // 0x693ef8: r0 = mult2()
    //     0x693ef8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x693efc: mov             x3, x0
    // 0x693f00: ldur            x0, [fp, #-8]
    // 0x693f04: stur            x3, [fp, #-0x28]
    // 0x693f08: LoadField: r4 = r0->field_43
    //     0x693f08: ldur            w4, [x0, #0x43]
    // 0x693f0c: DecompressPointer r4
    //     0x693f0c: add             x4, x4, HEAP, lsl #32
    // 0x693f10: mov             x1, x4
    // 0x693f14: stur            x4, [fp, #-0x20]
    // 0x693f18: r2 = 4
    //     0x693f18: movz            x2, #0x4
    // 0x693f1c: r0 = _getValueOrData()
    //     0x693f1c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x693f20: mov             x1, x0
    // 0x693f24: ldur            x0, [fp, #-0x20]
    // 0x693f28: LoadField: r2 = r0->field_f
    //     0x693f28: ldur            w2, [x0, #0xf]
    // 0x693f2c: DecompressPointer r2
    //     0x693f2c: add             x2, x2, HEAP, lsl #32
    // 0x693f30: cmp             w2, w1
    // 0x693f34: b.ne            #0x693f40
    // 0x693f38: r0 = Null
    //     0x693f38: mov             x0, NULL
    // 0x693f3c: b               #0x693f44
    // 0x693f40: mov             x0, x1
    // 0x693f44: cmp             w0, NULL
    // 0x693f48: b.eq            #0x693f64
    // 0x693f4c: r3 = LoadInt32Instr(r0)
    //     0x693f4c: sbfx            x3, x0, #1, #0x1f
    //     0x693f50: tbz             w0, #0, #0x693f58
    //     0x693f54: ldur            x3, [x0, #7]
    // 0x693f58: stur            x3, [fp, #-0x30]
    // 0x693f5c: cmp             x3, #2
    // 0x693f60: b.ge            #0x693fa4
    // 0x693f64: ldur            x4, [fp, #-0x10]
    // 0x693f68: r0 = BoxInt64Instr(r4)
    //     0x693f68: sbfiz           x0, x4, #1, #0x1f
    //     0x693f6c: cmp             x4, x0, asr #1
    //     0x693f70: b.eq            #0x693f7c
    //     0x693f74: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x693f78: stur            x4, [x0, #7]
    // 0x693f7c: mov             x2, x0
    // 0x693f80: r1 = Instance_CustomNum
    //     0x693f80: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x693f84: ldr             x1, [x1, #0x970]
    // 0x693f88: r0 = pow()
    //     0x693f88: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x693f8c: ldur            x1, [fp, #-0x28]
    // 0x693f90: mov             x2, x0
    // 0x693f94: r0 = min()
    //     0x693f94: bl              #0x55ce40  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::min
    // 0x693f98: LeaveFrame
    //     0x693f98: mov             SP, fp
    //     0x693f9c: ldp             fp, lr, [SP], #0x10
    // 0x693fa0: ret
    //     0x693fa0: ret             
    // 0x693fa4: ldur            x4, [fp, #-0x10]
    // 0x693fa8: ldur            x1, [fp, #-0x28]
    // 0x693fac: r2 = Instance_CustomNum
    //     0x693fac: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x693fb0: ldr             x2, [x2, #0xa70]
    // 0x693fb4: r0 = min()
    //     0x693fb4: bl              #0x55ce40  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::min
    // 0x693fb8: mov             x2, x0
    // 0x693fbc: ldur            x0, [fp, #-0x30]
    // 0x693fc0: stur            x2, [fp, #-0x20]
    // 0x693fc4: sub             x1, x0, #2
    // 0x693fc8: stur            x1, [fp, #-0x38]
    // 0x693fcc: tbnz            x1, #0x3f, #0x69402c
    // 0x693fd0: mov             x0, x1
    // 0x693fd4: r1 = 2
    //     0x693fd4: movz            x1, #0x2
    // 0x693fd8: r3 = 1
    //     0x693fd8: movz            x3, #0x1
    // 0x693fdc: CheckStackOverflow
    //     0x693fdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x693fe0: cmp             SP, x16
    //     0x693fe4: b.ls            #0x694360
    // 0x693fe8: cbz             x0, #0x694010
    // 0x693fec: branchIfSmi(r0, 0x693ff8)
    //     0x693fec: tbz             w0, #0, #0x693ff8
    // 0x693ff0: mul             x4, x3, x1
    // 0x693ff4: mov             x3, x4
    // 0x693ff8: asr             x4, x0, #1
    // 0x693ffc: cbz             x4, #0x694008
    // 0x694000: mul             x5, x1, x1
    // 0x694004: mov             x1, x5
    // 0x694008: mov             x0, x4
    // 0x69400c: b               #0x693fdc
    // 0x694010: r0 = BoxInt64Instr(r3)
    //     0x694010: sbfiz           x0, x3, #1, #0x1f
    //     0x694014: cmp             x3, x0, asr #1
    //     0x694018: b.eq            #0x694024
    //     0x69401c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694020: stur            x3, [x0, #7]
    // 0x694024: mov             x4, x0
    // 0x694028: b               #0x694194
    // 0x69402c: r16 = 4
    //     0x69402c: movz            x16, #0x4
    // 0x694030: stp             x16, NULL, [SP]
    // 0x694034: r0 = _Double.fromInteger()
    //     0x694034: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x694038: mov             x3, x0
    // 0x69403c: ldur            x2, [fp, #-0x38]
    // 0x694040: stur            x3, [fp, #-0x28]
    // 0x694044: r0 = BoxInt64Instr(r2)
    //     0x694044: sbfiz           x0, x2, #1, #0x1f
    //     0x694048: cmp             x2, x0, asr #1
    //     0x69404c: b.eq            #0x694058
    //     0x694050: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694054: stur            x2, [x0, #7]
    // 0x694058: r1 = 60
    //     0x694058: movz            x1, #0x3c
    // 0x69405c: branchIfSmi(r0, 0x694068)
    //     0x69405c: tbz             w0, #0, #0x694068
    // 0x694060: r1 = LoadClassIdInstr(r0)
    //     0x694060: ldur            x1, [x0, #-1]
    //     0x694064: ubfx            x1, x1, #0xc, #0x14
    // 0x694068: str             x0, [SP]
    // 0x69406c: mov             x0, x1
    // 0x694070: r0 = GDT[cid_x0 + -0x1000]()
    //     0x694070: sub             lr, x0, #1, lsl #12
    //     0x694074: ldr             lr, [x21, lr, lsl #3]
    //     0x694078: blr             lr
    // 0x69407c: mov             x1, x0
    // 0x694080: ldur            x0, [fp, #-0x28]
    // 0x694084: LoadField: d0 = r0->field_7
    //     0x694084: ldur            d0, [x0, #7]
    // 0x694088: LoadField: d1 = r1->field_7
    //     0x694088: ldur            d1, [x1, #7]
    // 0x69408c: d30 = 0.000000
    //     0x69408c: fmov            d30, d0
    // 0x694090: d0 = 1.000000
    //     0x694090: fmov            d0, #1.00000000
    // 0x694094: fcmp            d1, #0.0
    // 0x694098: b.vs            #0x6940dc
    // 0x69409c: b.eq            #0x694164
    // 0x6940a0: fcmp            d1, d0
    // 0x6940a4: b.eq            #0x6940cc
    // 0x6940a8: d31 = 2.000000
    //     0x6940a8: fmov            d31, #2.00000000
    // 0x6940ac: fcmp            d1, d31
    // 0x6940b0: b.eq            #0x6940d4
    // 0x6940b4: d31 = 3.000000
    //     0x6940b4: fmov            d31, #3.00000000
    // 0x6940b8: fcmp            d1, d31
    // 0x6940bc: b.ne            #0x6940dc
    // 0x6940c0: fmul            d0, d30, d30
    // 0x6940c4: fmul            d0, d0, d30
    // 0x6940c8: b               #0x694164
    // 0x6940cc: d0 = 0.000000
    //     0x6940cc: fmov            d0, d30
    // 0x6940d0: b               #0x694164
    // 0x6940d4: fmul            d0, d30, d30
    // 0x6940d8: b               #0x694164
    // 0x6940dc: fcmp            d30, d0
    // 0x6940e0: b.vs            #0x6940f0
    // 0x6940e4: b.eq            #0x694164
    // 0x6940e8: fcmp            d30, d1
    // 0x6940ec: b.vc            #0x6940fc
    // 0x6940f0: d0 = nan
    //     0x6940f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x6940f4: ldr             d0, [x17, #0xe48]
    // 0x6940f8: b               #0x694164
    // 0x6940fc: d0 = -inf
    //     0x6940fc: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x694100: fcmp            d30, d0
    // 0x694104: b.eq            #0x69412c
    // 0x694108: d0 = 0.500000
    //     0x694108: fmov            d0, #0.50000000
    // 0x69410c: fcmp            d1, d0
    // 0x694110: b.ne            #0x69412c
    // 0x694114: fcmp            d30, #0.0
    // 0x694118: b.eq            #0x694124
    // 0x69411c: fsqrt           d0, d30
    // 0x694120: b               #0x694164
    // 0x694124: d0 = 0.000000
    //     0x694124: eor             v0.16b, v0.16b, v0.16b
    // 0x694128: b               #0x694164
    // 0x69412c: d0 = 0.000000
    //     0x69412c: fmov            d0, d30
    // 0x694130: stp             fp, lr, [SP, #-0x10]!
    // 0x694134: mov             fp, SP
    // 0x694138: CallRuntime_LibcPow(double, double) -> double
    //     0x694138: and             SP, SP, #0xfffffffffffffff0
    //     0x69413c: mov             sp, SP
    //     0x694140: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x694144: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x694148: blr             x16
    //     0x69414c: movz            x16, #0x8
    //     0x694150: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x694154: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x694158: sub             sp, x16, #1, lsl #12
    //     0x69415c: mov             SP, fp
    //     0x694160: ldp             fp, lr, [SP], #0x10
    // 0x694164: r0 = inline_Allocate_Double()
    //     0x694164: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x694168: add             x0, x0, #0x10
    //     0x69416c: cmp             x1, x0
    //     0x694170: b.ls            #0x694368
    //     0x694174: str             x0, [THR, #0x60]  ; THR::top
    //     0x694178: sub             x0, x0, #0xf
    //     0x69417c: movz            x1, #0xe19c
    //     0x694180: movk            x1, #0x3, lsl #16
    //     0x694184: stur            x1, [x0, #-1]
    // 0x694188: dmb             ishst
    // 0x69418c: StoreField: r0->field_7 = d0
    //     0x69418c: stur            d0, [x0, #7]
    // 0x694190: mov             x4, x0
    // 0x694194: ldur            x2, [fp, #-8]
    // 0x694198: ldur            x3, [fp, #-0x18]
    // 0x69419c: r0 = BoxInt64Instr(r3)
    //     0x69419c: sbfiz           x0, x3, #1, #0x1f
    //     0x6941a0: cmp             x3, x0, asr #1
    //     0x6941a4: b.eq            #0x6941b0
    //     0x6941a8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6941ac: stur            x3, [x0, #7]
    // 0x6941b0: r1 = 60
    //     0x6941b0: movz            x1, #0x3c
    // 0x6941b4: branchIfSmi(r4, 0x6941c0)
    //     0x6941b4: tbz             w4, #0, #0x6941c0
    // 0x6941b8: r1 = LoadClassIdInstr(r4)
    //     0x6941b8: ldur            x1, [x4, #-1]
    //     0x6941bc: ubfx            x1, x1, #0xc, #0x14
    // 0x6941c0: stp             x0, x4, [SP]
    // 0x6941c4: mov             x0, x1
    // 0x6941c8: r0 = GDT[cid_x0 + -0xffd]()
    //     0x6941c8: sub             lr, x0, #0xffd
    //     0x6941cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6941d0: blr             lr
    // 0x6941d4: mov             x3, x0
    // 0x6941d8: ldur            x0, [fp, #-8]
    // 0x6941dc: stur            x3, [fp, #-0x40]
    // 0x6941e0: LoadField: r4 = r0->field_3b
    //     0x6941e0: ldur            w4, [x0, #0x3b]
    // 0x6941e4: DecompressPointer r4
    //     0x6941e4: add             x4, x4, HEAP, lsl #32
    // 0x6941e8: mov             x1, x4
    // 0x6941ec: stur            x4, [fp, #-0x28]
    // 0x6941f0: r2 = Instance_Chapter10Stat
    //     0x6941f0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x6941f4: ldr             x2, [x2, #0x798]
    // 0x6941f8: r0 = _getValueOrData()
    //     0x6941f8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6941fc: mov             x1, x0
    // 0x694200: ldur            x0, [fp, #-0x28]
    // 0x694204: LoadField: r2 = r0->field_f
    //     0x694204: ldur            w2, [x0, #0xf]
    // 0x694208: DecompressPointer r2
    //     0x694208: add             x2, x2, HEAP, lsl #32
    // 0x69420c: cmp             w2, w1
    // 0x694210: b.ne            #0x69421c
    // 0x694214: r0 = Null
    //     0x694214: mov             x0, NULL
    // 0x694218: b               #0x694220
    // 0x69421c: mov             x0, x1
    // 0x694220: cmp             w0, NULL
    // 0x694224: b.ne            #0x694234
    // 0x694228: r1 = Instance_CustomNum
    //     0x694228: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69422c: ldr             x1, [x1, #0xaf8]
    // 0x694230: b               #0x694238
    // 0x694234: mov             x1, x0
    // 0x694238: ldur            x0, [fp, #-0x40]
    // 0x69423c: LoadField: d0 = r1->field_7
    //     0x69423c: ldur            d0, [x1, #7]
    // 0x694240: r1 = inline_Allocate_Double()
    //     0x694240: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x694244: add             x1, x1, #0x10
    //     0x694248: cmp             x2, x1
    //     0x69424c: b.ls            #0x694378
    //     0x694250: str             x1, [THR, #0x60]  ; THR::top
    //     0x694254: sub             x1, x1, #0xf
    //     0x694258: movz            x2, #0xe19c
    //     0x69425c: movk            x2, #0x3, lsl #16
    //     0x694260: stur            x2, [x1, #-1]
    // 0x694264: dmb             ishst
    // 0x694268: StoreField: r1->field_7 = d0
    //     0x694268: stur            d0, [x1, #7]
    // 0x69426c: r2 = 60
    //     0x69426c: movz            x2, #0x3c
    // 0x694270: branchIfSmi(r0, 0x69427c)
    //     0x694270: tbz             w0, #0, #0x69427c
    // 0x694274: r2 = LoadClassIdInstr(r0)
    //     0x694274: ldur            x2, [x0, #-1]
    //     0x694278: ubfx            x2, x2, #0xc, #0x14
    // 0x69427c: stp             x1, x0, [SP]
    // 0x694280: mov             x0, x2
    // 0x694284: r0 = GDT[cid_x0 + -0xffd]()
    //     0x694284: sub             lr, x0, #0xffd
    //     0x694288: ldr             lr, [x21, lr, lsl #3]
    //     0x69428c: blr             lr
    // 0x694290: LoadField: d0 = r0->field_7
    //     0x694290: ldur            d0, [x0, #7]
    // 0x694294: d1 = 0.000000
    //     0x694294: eor             v1.16b, v1.16b, v1.16b
    // 0x694298: fcmp            d0, d1
    // 0x69429c: b.gt            #0x6942cc
    // 0x6942a0: fcmp            d1, d0
    // 0x6942a4: b.le            #0x6942b0
    // 0x6942a8: r0 = 0
    //     0x6942a8: movz            x0, #0
    // 0x6942ac: b               #0x6942cc
    // 0x6942b0: fcmp            d0, #0.0
    // 0x6942b4: b.vs            #0x6942cc
    // 0x6942b8: b.ne            #0x6942c4
    // 0x6942bc: r1 = 0.000000
    //     0x6942bc: fmov            x1, d0
    // 0x6942c0: cmp             x1, #0
    // 0x6942c4: b.ge            #0x6942cc
    // 0x6942c8: r0 = 0
    //     0x6942c8: movz            x0, #0
    // 0x6942cc: ldur            x1, [fp, #-0x10]
    // 0x6942d0: r2 = 60
    //     0x6942d0: movz            x2, #0x3c
    // 0x6942d4: branchIfSmi(r0, 0x6942e0)
    //     0x6942d4: tbz             w0, #0, #0x6942e0
    // 0x6942d8: r2 = LoadClassIdInstr(r0)
    //     0x6942d8: ldur            x2, [x0, #-1]
    //     0x6942dc: ubfx            x2, x2, #0xc, #0x14
    // 0x6942e0: r16 = 6
    //     0x6942e0: movz            x16, #0x6
    // 0x6942e4: stp             x16, x0, [SP]
    // 0x6942e8: mov             x0, x2
    // 0x6942ec: r0 = GDT[cid_x0 + -0xd64]()
    //     0x6942ec: sub             lr, x0, #0xd64
    //     0x6942f0: ldr             lr, [x21, lr, lsl #3]
    //     0x6942f4: blr             lr
    // 0x6942f8: mov             x2, x0
    // 0x6942fc: r1 = Null
    //     0x6942fc: mov             x1, NULL
    // 0x694300: r0 = CustomNum()
    //     0x694300: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x694304: ldur            x1, [fp, #-0x20]
    // 0x694308: mov             x2, x0
    // 0x69430c: r0 = add()
    //     0x69430c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x694310: mov             x3, x0
    // 0x694314: ldur            x2, [fp, #-0x10]
    // 0x694318: stur            x3, [fp, #-8]
    // 0x69431c: r0 = BoxInt64Instr(r2)
    //     0x69431c: sbfiz           x0, x2, #1, #0x1f
    //     0x694320: cmp             x2, x0, asr #1
    //     0x694324: b.eq            #0x694330
    //     0x694328: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x69432c: stur            x2, [x0, #7]
    // 0x694330: mov             x2, x0
    // 0x694334: r1 = Instance_CustomNum
    //     0x694334: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x694338: ldr             x1, [x1, #0x970]
    // 0x69433c: r0 = pow()
    //     0x69433c: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x694340: ldur            x1, [fp, #-8]
    // 0x694344: mov             x2, x0
    // 0x694348: r0 = mult2()
    //     0x694348: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x69434c: LeaveFrame
    //     0x69434c: mov             SP, fp
    //     0x694350: ldp             fp, lr, [SP], #0x10
    // 0x694354: ret
    //     0x694354: ret             
    // 0x694358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694358: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69435c: b               #0x693e40
    // 0x694360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694360: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694364: b               #0x693fe8
    // 0x694368: SaveReg d0
    //     0x694368: str             q0, [SP, #-0x10]!
    // 0x69436c: r0 = AllocateDouble()
    //     0x69436c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x694370: RestoreReg d0
    //     0x694370: ldr             q0, [SP], #0x10
    // 0x694374: b               #0x69418c
    // 0x694378: SaveReg d0
    //     0x694378: str             q0, [SP, #-0x10]!
    // 0x69437c: SaveReg r0
    //     0x69437c: str             x0, [SP, #-8]!
    // 0x694380: r0 = AllocateDouble()
    //     0x694380: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x694384: mov             x1, x0
    // 0x694388: RestoreReg r0
    //     0x694388: ldr             x0, [SP], #8
    // 0x69438c: RestoreReg d0
    //     0x69438c: ldr             q0, [SP], #0x10
    // 0x694390: b               #0x694268
  }
  _ getRequiredUtility(/* No info */) {
    // ** addr: 0x694394, size: 0x88
    // 0x694394: EnterFrame
    //     0x694394: stp             fp, lr, [SP, #-0x10]!
    //     0x694398: mov             fp, SP
    // 0x69439c: CheckStackOverflow
    //     0x69439c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6943a0: cmp             SP, x16
    //     0x6943a4: b.ls            #0x694410
    // 0x6943a8: LoadField: r3 = r1->field_9b
    //     0x6943a8: ldur            w3, [x1, #0x9b]
    // 0x6943ac: DecompressPointer r3
    //     0x6943ac: add             x3, x3, HEAP, lsl #32
    // 0x6943b0: LoadField: r0 = r3->field_b
    //     0x6943b0: ldur            w0, [x3, #0xb]
    // 0x6943b4: r1 = LoadInt32Instr(r0)
    //     0x6943b4: sbfx            x1, x0, #1, #0x1f
    // 0x6943b8: cmp             x1, x2
    // 0x6943bc: b.le            #0x6943f0
    // 0x6943c0: mov             x0, x1
    // 0x6943c4: mov             x1, x2
    // 0x6943c8: cmp             x1, x0
    // 0x6943cc: b.hs            #0x694418
    // 0x6943d0: LoadField: r0 = r3->field_f
    //     0x6943d0: ldur            w0, [x3, #0xf]
    // 0x6943d4: DecompressPointer r0
    //     0x6943d4: add             x0, x0, HEAP, lsl #32
    // 0x6943d8: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x6943d8: add             x16, x0, x2, lsl #2
    //     0x6943dc: ldur            w1, [x16, #0xf]
    // 0x6943e0: DecompressPointer r1
    //     0x6943e0: add             x1, x1, HEAP, lsl #32
    // 0x6943e4: LoadField: r0 = r1->field_13
    //     0x6943e4: ldur            w0, [x1, #0x13]
    // 0x6943e8: DecompressPointer r0
    //     0x6943e8: add             x0, x0, HEAP, lsl #32
    // 0x6943ec: b               #0x694404
    // 0x6943f0: mov             x1, x3
    // 0x6943f4: r0 = last()
    //     0x6943f4: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x6943f8: LoadField: r1 = r0->field_13
    //     0x6943f8: ldur            w1, [x0, #0x13]
    // 0x6943fc: DecompressPointer r1
    //     0x6943fc: add             x1, x1, HEAP, lsl #32
    // 0x694400: mov             x0, x1
    // 0x694404: LeaveFrame
    //     0x694404: mov             SP, fp
    //     0x694408: ldp             fp, lr, [SP], #0x10
    // 0x69440c: ret
    //     0x69440c: ret             
    // 0x694410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694410: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694414: b               #0x6943a8
    // 0x694418: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x694418: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ minUtilityToPrestige(/* No info */) {
    // ** addr: 0x69441c, size: 0xe8
    // 0x69441c: EnterFrame
    //     0x69441c: stp             fp, lr, [SP, #-0x10]!
    //     0x694420: mov             fp, SP
    // 0x694424: AllocStack(0x18)
    //     0x694424: sub             SP, SP, #0x18
    // 0x694428: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */)
    //     0x694428: mov             x0, x1
    //     0x69442c: stur            x1, [fp, #-8]
    // 0x694430: CheckStackOverflow
    //     0x694430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694434: cmp             SP, x16
    //     0x694438: b.ls            #0x6944fc
    // 0x69443c: mov             x1, x0
    // 0x694440: r0 = getRefactorLevel()
    //     0x694440: bl              #0x6936a0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getRefactorLevel
    // 0x694444: ldur            x1, [fp, #-8]
    // 0x694448: mov             x2, x0
    // 0x69444c: r0 = getRequiredUtility()
    //     0x69444c: bl              #0x694394  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getRequiredUtility
    // 0x694450: mov             x3, x0
    // 0x694454: ldur            x0, [fp, #-8]
    // 0x694458: stur            x3, [fp, #-0x18]
    // 0x69445c: LoadField: r4 = r0->field_43
    //     0x69445c: ldur            w4, [x0, #0x43]
    // 0x694460: DecompressPointer r4
    //     0x694460: add             x4, x4, HEAP, lsl #32
    // 0x694464: mov             x1, x4
    // 0x694468: stur            x4, [fp, #-0x10]
    // 0x69446c: r2 = 20
    //     0x69446c: movz            x2, #0x14
    // 0x694470: r0 = _getValueOrData()
    //     0x694470: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x694474: mov             x1, x0
    // 0x694478: ldur            x0, [fp, #-0x10]
    // 0x69447c: LoadField: r2 = r0->field_f
    //     0x69447c: ldur            w2, [x0, #0xf]
    // 0x694480: DecompressPointer r2
    //     0x694480: add             x2, x2, HEAP, lsl #32
    // 0x694484: cmp             w2, w1
    // 0x694488: b.ne            #0x694494
    // 0x69448c: r0 = Null
    //     0x69448c: mov             x0, NULL
    // 0x694490: b               #0x694498
    // 0x694494: mov             x0, x1
    // 0x694498: cmp             w0, NULL
    // 0x69449c: b.ne            #0x6944a8
    // 0x6944a0: r0 = 0
    //     0x6944a0: movz            x0, #0
    // 0x6944a4: b               #0x6944b8
    // 0x6944a8: r1 = LoadInt32Instr(r0)
    //     0x6944a8: sbfx            x1, x0, #1, #0x1f
    //     0x6944ac: tbz             w0, #0, #0x6944b4
    //     0x6944b0: ldur            x1, [x0, #7]
    // 0x6944b4: mov             x0, x1
    // 0x6944b8: r16 = 10
    //     0x6944b8: movz            x16, #0xa
    // 0x6944bc: mul             x2, x0, x16
    // 0x6944c0: r0 = BoxInt64Instr(r2)
    //     0x6944c0: sbfiz           x0, x2, #1, #0x1f
    //     0x6944c4: cmp             x2, x0, asr #1
    //     0x6944c8: b.eq            #0x6944d4
    //     0x6944cc: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6944d0: stur            x2, [x0, #7]
    // 0x6944d4: mov             x2, x0
    // 0x6944d8: r1 = Instance_CustomNum
    //     0x6944d8: add             x1, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x6944dc: ldr             x1, [x1, #0x6f0]
    // 0x6944e0: r0 = pow()
    //     0x6944e0: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6944e4: ldur            x1, [fp, #-0x18]
    // 0x6944e8: mov             x2, x0
    // 0x6944ec: r0 = mult2()
    //     0x6944ec: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6944f0: LeaveFrame
    //     0x6944f0: mov             SP, fp
    //     0x6944f4: ldp             fp, lr, [SP], #0x10
    // 0x6944f8: ret
    //     0x6944f8: ret             
    // 0x6944fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6944fc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694500: b               #0x69443c
  }
  [closure] Tuple2<Chapter10Stat, CustomNum> <anonymous closure>(dynamic) {
    // ** addr: 0x694550, size: 0x6c
    // 0x694550: EnterFrame
    //     0x694550: stp             fp, lr, [SP, #-0x10]!
    //     0x694554: mov             fp, SP
    // 0x694558: AllocStack(0x8)
    //     0x694558: sub             SP, SP, #8
    // 0x69455c: SetupParameters([dynamic _ /* r0 */])
    //     0x69455c: ldr             x0, [fp, #0x10]
    //     0x694560: ldur            w1, [x0, #0x17]
    //     0x694564: add             x1, x1, HEAP, lsl #32
    // 0x694568: CheckStackOverflow
    //     0x694568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69456c: cmp             SP, x16
    //     0x694570: b.ls            #0x6945b4
    // 0x694574: LoadField: r0 = r1->field_f
    //     0x694574: ldur            w0, [x1, #0xf]
    // 0x694578: DecompressPointer r0
    //     0x694578: add             x0, x0, HEAP, lsl #32
    // 0x69457c: mov             x1, x0
    // 0x694580: r0 = minUtilityToPrestige()
    //     0x694580: bl              #0x69441c  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::minUtilityToPrestige
    // 0x694584: r1 = <Chapter10Stat, CustomNum>
    //     0x694584: add             x1, PP, #0x16, lsl #12  ; [pp+0x16720] TypeArguments: <Chapter10Stat, CustomNum>
    //     0x694588: ldr             x1, [x1, #0x720]
    // 0x69458c: stur            x0, [fp, #-8]
    // 0x694590: r0 = Tuple2()
    //     0x694590: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x694594: r1 = Instance_Chapter10Stat
    //     0x694594: add             x1, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x694598: ldr             x1, [x1, #0x798]
    // 0x69459c: StoreField: r0->field_b = r1
    //     0x69459c: stur            w1, [x0, #0xb]
    // 0x6945a0: ldur            x1, [fp, #-8]
    // 0x6945a4: StoreField: r0->field_f = r1
    //     0x6945a4: stur            w1, [x0, #0xf]
    // 0x6945a8: LeaveFrame
    //     0x6945a8: mov             SP, fp
    //     0x6945ac: ldp             fp, lr, [SP], #0x10
    // 0x6945b0: ret
    //     0x6945b0: ret             
    // 0x6945b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6945b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6945b8: b               #0x694574
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6945bc, size: 0xc
    // 0x6945bc: r0 = "Increases the rate of utility gain by 100% for each efficiency."
    //     0x6945bc: add             x0, PP, #0x29, lsl #12  ; [pp+0x29610] "Increases the rate of utility gain by 100% for each efficiency."
    //     0x6945c0: ldr             x0, [x0, #0x610]
    // 0x6945c4: ret
    //     0x6945c4: ret             
  }
  [closure] void refactorReset(dynamic) {
    // ** addr: 0x6945c8, size: 0x38
    // 0x6945c8: EnterFrame
    //     0x6945c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6945cc: mov             fp, SP
    // 0x6945d0: ldr             x0, [fp, #0x10]
    // 0x6945d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6945d4: ldur            w1, [x0, #0x17]
    // 0x6945d8: DecompressPointer r1
    //     0x6945d8: add             x1, x1, HEAP, lsl #32
    // 0x6945dc: CheckStackOverflow
    //     0x6945dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6945e0: cmp             SP, x16
    //     0x6945e4: b.ls            #0x6945f8
    // 0x6945e8: r0 = refactorReset()
    //     0x6945e8: bl              #0x694600  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::refactorReset
    // 0x6945ec: LeaveFrame
    //     0x6945ec: mov             SP, fp
    //     0x6945f0: ldp             fp, lr, [SP], #0x10
    // 0x6945f4: ret
    //     0x6945f4: ret             
    // 0x6945f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6945f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6945fc: b               #0x6945e8
  }
  _ refactorReset(/* No info */) {
    // ** addr: 0x694600, size: 0xcc
    // 0x694600: EnterFrame
    //     0x694600: stp             fp, lr, [SP, #-0x10]!
    //     0x694604: mov             fp, SP
    // 0x694608: AllocStack(0x18)
    //     0x694608: sub             SP, SP, #0x18
    // 0x69460c: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x10 */)
    //     0x69460c: mov             x0, x1
    //     0x694610: stur            x1, [fp, #-0x10]
    // 0x694614: CheckStackOverflow
    //     0x694614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694618: cmp             SP, x16
    //     0x69461c: b.ls            #0x6946c4
    // 0x694620: LoadField: r3 = r0->field_37
    //     0x694620: ldur            w3, [x0, #0x37]
    // 0x694624: DecompressPointer r3
    //     0x694624: add             x3, x3, HEAP, lsl #32
    // 0x694628: mov             x1, x3
    // 0x69462c: stur            x3, [fp, #-8]
    // 0x694630: r2 = Instance_Chapter10Stat
    //     0x694630: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x694634: ldr             x2, [x2, #0x7d8]
    // 0x694638: r0 = _getValueOrData()
    //     0x694638: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69463c: mov             x1, x0
    // 0x694640: ldur            x0, [fp, #-8]
    // 0x694644: LoadField: r2 = r0->field_f
    //     0x694644: ldur            w2, [x0, #0xf]
    // 0x694648: DecompressPointer r2
    //     0x694648: add             x2, x2, HEAP, lsl #32
    // 0x69464c: cmp             w2, w1
    // 0x694650: b.ne            #0x694658
    // 0x694654: r1 = Null
    //     0x694654: mov             x1, NULL
    // 0x694658: cmp             w1, NULL
    // 0x69465c: b.ne            #0x69466c
    // 0x694660: r2 = Instance_CustomNum
    //     0x694660: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x694664: ldr             x2, [x2, #0xaf8]
    // 0x694668: b               #0x694670
    // 0x69466c: mov             x2, x1
    // 0x694670: ldur            x1, [fp, #-0x10]
    // 0x694674: stur            x2, [fp, #-0x18]
    // 0x694678: r0 = presitgePointsFromRefactor()
    //     0x694678: bl              #0x693e20  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::presitgePointsFromRefactor
    // 0x69467c: ldur            x1, [fp, #-0x18]
    // 0x694680: mov             x2, x0
    // 0x694684: r0 = add()
    //     0x694684: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x694688: ldur            x1, [fp, #-8]
    // 0x69468c: mov             x3, x0
    // 0x694690: r2 = Instance_Chapter10Stat
    //     0x694690: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x694694: ldr             x2, [x2, #0x7d8]
    // 0x694698: r0 = []=()
    //     0x694698: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69469c: ldur            x1, [fp, #-0x10]
    // 0x6946a0: r2 = Instance_Chapter10Stat
    //     0x6946a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!Chapter10Stat@85fe01
    //     0x6946a4: ldr             x2, [x2, #0x7d8]
    // 0x6946a8: r0 = notifyStatGained()
    //     0x6946a8: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6946ac: ldur            x1, [fp, #-0x10]
    // 0x6946b0: r0 = kernelReset()
    //     0x6946b0: bl              #0x693ad0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::kernelReset
    // 0x6946b4: r0 = Null
    //     0x6946b4: mov             x0, NULL
    // 0x6946b8: LeaveFrame
    //     0x6946b8: mov             SP, fp
    //     0x6946bc: ldp             fp, lr, [SP], #0x10
    // 0x6946c0: ret
    //     0x6946c0: ret             
    // 0x6946c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6946c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6946c8: b               #0x694620
  }
  [closure] CustomNum presitgePointsFromRefactor(dynamic) {
    // ** addr: 0x6946cc, size: 0x38
    // 0x6946cc: EnterFrame
    //     0x6946cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6946d0: mov             fp, SP
    // 0x6946d4: ldr             x0, [fp, #0x10]
    // 0x6946d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6946d8: ldur            w1, [x0, #0x17]
    // 0x6946dc: DecompressPointer r1
    //     0x6946dc: add             x1, x1, HEAP, lsl #32
    // 0x6946e0: CheckStackOverflow
    //     0x6946e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6946e4: cmp             SP, x16
    //     0x6946e8: b.ls            #0x6946fc
    // 0x6946ec: r0 = presitgePointsFromRefactor()
    //     0x6946ec: bl              #0x693e20  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::presitgePointsFromRefactor
    // 0x6946f0: LeaveFrame
    //     0x6946f0: mov             SP, fp
    //     0x6946f4: ldp             fp, lr, [SP], #0x10
    // 0x6946f8: ret
    //     0x6946f8: ret             
    // 0x6946fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6946fc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694700: b               #0x6946ec
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x694704, size: 0xc
    // 0x694704: r0 = "Refactor"
    //     0x694704: add             x0, PP, #0x29, lsl #12  ; [pp+0x29618] "Refactor"
    //     0x694708: ldr             x0, [x0, #0x618]
    // 0x69470c: ret
    //     0x69470c: ret             
  }
  [closure] GeneratorInfo<Chapter10Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x6947a4, size: 0x3c
    // 0x6947a4: EnterFrame
    //     0x6947a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6947a8: mov             fp, SP
    // 0x6947ac: ldr             x0, [fp, #0x18]
    // 0x6947b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6947b0: ldur            w1, [x0, #0x17]
    // 0x6947b4: DecompressPointer r1
    //     0x6947b4: add             x1, x1, HEAP, lsl #32
    // 0x6947b8: CheckStackOverflow
    //     0x6947b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6947bc: cmp             SP, x16
    //     0x6947c0: b.ls            #0x6947d8
    // 0x6947c4: ldr             x2, [fp, #0x10]
    // 0x6947c8: r0 = getGeneratorInfo()
    //     0x6947c8: bl              #0x80d118  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getGeneratorInfo
    // 0x6947cc: LeaveFrame
    //     0x6947cc: mov             SP, fp
    //     0x6947d0: ldp             fp, lr, [SP], #0x10
    // 0x6947d4: ret
    //     0x6947d4: ret             
    // 0x6947d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6947d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6947dc: b               #0x6947c4
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6947e0, size: 0x12c
    // 0x6947e0: EnterFrame
    //     0x6947e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6947e4: mov             fp, SP
    // 0x6947e8: AllocStack(0x20)
    //     0x6947e8: sub             SP, SP, #0x20
    // 0x6947ec: SetupParameters([dynamic _ /* r0 */])
    //     0x6947ec: ldr             x0, [fp, #0x10]
    //     0x6947f0: ldur            w1, [x0, #0x17]
    //     0x6947f4: add             x1, x1, HEAP, lsl #32
    // 0x6947f8: CheckStackOverflow
    //     0x6947f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6947fc: cmp             SP, x16
    //     0x694800: b.ls            #0x6948fc
    // 0x694804: LoadField: r0 = r1->field_f
    //     0x694804: ldur            w0, [x1, #0xf]
    // 0x694808: DecompressPointer r0
    //     0x694808: add             x0, x0, HEAP, lsl #32
    // 0x69480c: LoadField: r3 = r0->field_8b
    //     0x69480c: ldur            x3, [x0, #0x8b]
    // 0x694810: stur            x3, [fp, #-0x18]
    // 0x694814: LoadField: r4 = r0->field_9b
    //     0x694814: ldur            w4, [x0, #0x9b]
    // 0x694818: DecompressPointer r4
    //     0x694818: add             x4, x4, HEAP, lsl #32
    // 0x69481c: stur            x4, [fp, #-0x10]
    // 0x694820: LoadField: r0 = r4->field_b
    //     0x694820: ldur            w0, [x4, #0xb]
    // 0x694824: stur            x0, [fp, #-8]
    // 0x694828: r1 = LoadInt32Instr(r0)
    //     0x694828: sbfx            x1, x0, #1, #0x1f
    // 0x69482c: sub             x2, x1, #1
    // 0x694830: cmp             x3, x2
    // 0x694834: b.lt            #0x69484c
    // 0x694838: r0 = "Current version 1.0.0"
    //     0x694838: add             x0, PP, #0x29, lsl #12  ; [pp+0x29620] "Current version 1.0.0"
    //     0x69483c: ldr             x0, [x0, #0x620]
    // 0x694840: LeaveFrame
    //     0x694840: mov             SP, fp
    //     0x694844: ldp             fp, lr, [SP], #0x10
    // 0x694848: ret
    //     0x694848: ret             
    // 0x69484c: r1 = Null
    //     0x69484c: mov             x1, NULL
    // 0x694850: r2 = 10
    //     0x694850: movz            x2, #0xa
    // 0x694854: r0 = AllocateArray()
    //     0x694854: bl              #0x82746c  ; AllocateArrayStub
    // 0x694858: mov             x2, x0
    // 0x69485c: r16 = "Upgrade Kernel ("
    //     0x69485c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29628] "Upgrade Kernel ("
    //     0x694860: ldr             x16, [x16, #0x628]
    // 0x694864: StoreField: r2->field_f = r16
    //     0x694864: stur            w16, [x2, #0xf]
    // 0x694868: ldur            x0, [fp, #-8]
    // 0x69486c: r3 = LoadInt32Instr(r0)
    //     0x69486c: sbfx            x3, x0, #1, #0x1f
    // 0x694870: mov             x0, x3
    // 0x694874: ldur            x1, [fp, #-0x18]
    // 0x694878: cmp             x1, x0
    // 0x69487c: b.hs            #0x694904
    // 0x694880: ldur            x0, [fp, #-0x10]
    // 0x694884: LoadField: r4 = r0->field_f
    //     0x694884: ldur            w4, [x0, #0xf]
    // 0x694888: DecompressPointer r4
    //     0x694888: add             x4, x4, HEAP, lsl #32
    // 0x69488c: ldur            x0, [fp, #-0x18]
    // 0x694890: ArrayLoad: r1 = r4[r0]  ; Unknown_4
    //     0x694890: add             x16, x4, x0, lsl #2
    //     0x694894: ldur            w1, [x16, #0xf]
    // 0x694898: DecompressPointer r1
    //     0x694898: add             x1, x1, HEAP, lsl #32
    // 0x69489c: LoadField: r5 = r1->field_f
    //     0x69489c: ldur            w5, [x1, #0xf]
    // 0x6948a0: DecompressPointer r5
    //     0x6948a0: add             x5, x5, HEAP, lsl #32
    // 0x6948a4: StoreField: r2->field_13 = r5
    //     0x6948a4: stur            w5, [x2, #0x13]
    // 0x6948a8: r16 = " -> "
    //     0x6948a8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13cd8] " -> "
    //     0x6948ac: ldr             x16, [x16, #0xcd8]
    // 0x6948b0: ArrayStore: r2[0] = r16  ; List_4
    //     0x6948b0: stur            w16, [x2, #0x17]
    // 0x6948b4: add             x5, x0, #1
    // 0x6948b8: mov             x0, x3
    // 0x6948bc: mov             x1, x5
    // 0x6948c0: cmp             x1, x0
    // 0x6948c4: b.hs            #0x694908
    // 0x6948c8: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x6948c8: add             x16, x4, x5, lsl #2
    //     0x6948cc: ldur            w0, [x16, #0xf]
    // 0x6948d0: DecompressPointer r0
    //     0x6948d0: add             x0, x0, HEAP, lsl #32
    // 0x6948d4: LoadField: r1 = r0->field_f
    //     0x6948d4: ldur            w1, [x0, #0xf]
    // 0x6948d8: DecompressPointer r1
    //     0x6948d8: add             x1, x1, HEAP, lsl #32
    // 0x6948dc: StoreField: r2->field_1b = r1
    //     0x6948dc: stur            w1, [x2, #0x1b]
    // 0x6948e0: r16 = ")"
    //     0x6948e0: ldr             x16, [PP, #0x2228]  ; [pp+0x2228] ")"
    // 0x6948e4: StoreField: r2->field_1f = r16
    //     0x6948e4: stur            w16, [x2, #0x1f]
    // 0x6948e8: str             x2, [SP]
    // 0x6948ec: r0 = _interpolate()
    //     0x6948ec: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6948f0: LeaveFrame
    //     0x6948f0: mov             SP, fp
    //     0x6948f4: ldp             fp, lr, [SP], #0x10
    // 0x6948f8: ret
    //     0x6948f8: ret             
    // 0x6948fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6948fc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694900: b               #0x694804
    // 0x694904: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x694904: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x694908: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x694908: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter10Stat, CustomNum> <anonymous closure>(dynamic) {
    // ** addr: 0x69490c, size: 0xcc
    // 0x69490c: EnterFrame
    //     0x69490c: stp             fp, lr, [SP, #-0x10]!
    //     0x694910: mov             fp, SP
    // 0x694914: AllocStack(0x8)
    //     0x694914: sub             SP, SP, #8
    // 0x694918: SetupParameters([dynamic _ /* r0 */])
    //     0x694918: ldr             x0, [fp, #0x10]
    //     0x69491c: ldur            w1, [x0, #0x17]
    //     0x694920: add             x1, x1, HEAP, lsl #32
    // 0x694924: CheckStackOverflow
    //     0x694924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694928: cmp             SP, x16
    //     0x69492c: b.ls            #0x6949cc
    // 0x694930: LoadField: r0 = r1->field_f
    //     0x694930: ldur            w0, [x1, #0xf]
    // 0x694934: DecompressPointer r0
    //     0x694934: add             x0, x0, HEAP, lsl #32
    // 0x694938: LoadField: r2 = r0->field_8b
    //     0x694938: ldur            x2, [x0, #0x8b]
    // 0x69493c: LoadField: r3 = r0->field_9b
    //     0x69493c: ldur            w3, [x0, #0x9b]
    // 0x694940: DecompressPointer r3
    //     0x694940: add             x3, x3, HEAP, lsl #32
    // 0x694944: LoadField: r0 = r3->field_b
    //     0x694944: ldur            w0, [x3, #0xb]
    // 0x694948: r1 = LoadInt32Instr(r0)
    //     0x694948: sbfx            x1, x0, #1, #0x1f
    // 0x69494c: cmp             x2, x1
    // 0x694950: b.ge            #0x694988
    // 0x694954: r1 = LoadInt32Instr(r0)
    //     0x694954: sbfx            x1, x0, #1, #0x1f
    // 0x694958: mov             x0, x1
    // 0x69495c: mov             x1, x2
    // 0x694960: cmp             x1, x0
    // 0x694964: b.hs            #0x6949d4
    // 0x694968: LoadField: r0 = r3->field_f
    //     0x694968: ldur            w0, [x3, #0xf]
    // 0x69496c: DecompressPointer r0
    //     0x69496c: add             x0, x0, HEAP, lsl #32
    // 0x694970: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x694970: add             x16, x0, x2, lsl #2
    //     0x694974: ldur            w1, [x16, #0xf]
    // 0x694978: DecompressPointer r1
    //     0x694978: add             x1, x1, HEAP, lsl #32
    // 0x69497c: LoadField: r0 = r1->field_13
    //     0x69497c: ldur            w0, [x1, #0x13]
    // 0x694980: DecompressPointer r0
    //     0x694980: add             x0, x0, HEAP, lsl #32
    // 0x694984: b               #0x69499c
    // 0x694988: mov             x1, x3
    // 0x69498c: r0 = last()
    //     0x69498c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x694990: LoadField: r1 = r0->field_13
    //     0x694990: ldur            w1, [x0, #0x13]
    // 0x694994: DecompressPointer r1
    //     0x694994: add             x1, x1, HEAP, lsl #32
    // 0x694998: mov             x0, x1
    // 0x69499c: stur            x0, [fp, #-8]
    // 0x6949a0: r1 = <Chapter10Stat, CustomNum>
    //     0x6949a0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16720] TypeArguments: <Chapter10Stat, CustomNum>
    //     0x6949a4: ldr             x1, [x1, #0x720]
    // 0x6949a8: r0 = Tuple2()
    //     0x6949a8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x6949ac: r1 = Instance_Chapter10Stat
    //     0x6949ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11798] Obj!Chapter10Stat@85fe21
    //     0x6949b0: ldr             x1, [x1, #0x798]
    // 0x6949b4: StoreField: r0->field_b = r1
    //     0x6949b4: stur            w1, [x0, #0xb]
    // 0x6949b8: ldur            x1, [fp, #-8]
    // 0x6949bc: StoreField: r0->field_f = r1
    //     0x6949bc: stur            w1, [x0, #0xf]
    // 0x6949c0: LeaveFrame
    //     0x6949c0: mov             SP, fp
    //     0x6949c4: ldp             fp, lr, [SP], #0x10
    // 0x6949c8: ret
    //     0x6949c8: ret             
    // 0x6949cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6949cc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6949d0: b               #0x694930
    // 0x6949d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6949d4: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6949d8, size: 0x50
    // 0x6949d8: EnterFrame
    //     0x6949d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6949dc: mov             fp, SP
    // 0x6949e0: ldr             x0, [fp, #0x10]
    // 0x6949e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6949e4: ldur            w1, [x0, #0x17]
    // 0x6949e8: DecompressPointer r1
    //     0x6949e8: add             x1, x1, HEAP, lsl #32
    // 0x6949ec: CheckStackOverflow
    //     0x6949ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6949f0: cmp             SP, x16
    //     0x6949f4: b.ls            #0x694a20
    // 0x6949f8: LoadField: r0 = r1->field_f
    //     0x6949f8: ldur            w0, [x1, #0xf]
    // 0x6949fc: DecompressPointer r0
    //     0x6949fc: add             x0, x0, HEAP, lsl #32
    // 0x694a00: LoadField: r2 = r1->field_13
    //     0x694a00: ldur            w2, [x1, #0x13]
    // 0x694a04: DecompressPointer r2
    //     0x694a04: add             x2, x2, HEAP, lsl #32
    // 0x694a08: mov             x1, x0
    // 0x694a0c: r0 = upgradeKernel()
    //     0x694a0c: bl              #0x694a28  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::upgradeKernel
    // 0x694a10: r0 = Null
    //     0x694a10: mov             x0, NULL
    // 0x694a14: LeaveFrame
    //     0x694a14: mov             SP, fp
    //     0x694a18: ldp             fp, lr, [SP], #0x10
    // 0x694a1c: ret
    //     0x694a1c: ret             
    // 0x694a20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694a20: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694a24: b               #0x6949f8
  }
  _ upgradeKernel(/* No info */) {
    // ** addr: 0x694a28, size: 0xa0
    // 0x694a28: EnterFrame
    //     0x694a28: stp             fp, lr, [SP, #-0x10]!
    //     0x694a2c: mov             fp, SP
    // 0x694a30: AllocStack(0x10)
    //     0x694a30: sub             SP, SP, #0x10
    // 0x694a34: SetupParameters(Chapter10GameState this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x694a34: mov             x5, x1
    //     0x694a38: mov             x3, x2
    //     0x694a3c: stur            x1, [fp, #-8]
    //     0x694a40: stur            x2, [fp, #-0x10]
    // 0x694a44: CheckStackOverflow
    //     0x694a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694a48: cmp             SP, x16
    //     0x694a4c: b.ls            #0x694ab4
    // 0x694a50: r0 = LoadStaticField(0xa6c)
    //     0x694a50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x694a54: ldr             x0, [x0, #0x14d8]
    // 0x694a58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x694a5c: cmp             w0, w16
    // 0x694a60: b.eq            #0x694abc
    // 0x694a64: mov             x1, x0
    // 0x694a68: r2 = "ch10_refactor_level"
    //     0x694a68: add             x2, PP, #0x29, lsl #12  ; [pp+0x29608] "ch10_refactor_level"
    //     0x694a6c: ldr             x2, [x2, #0x608]
    // 0x694a70: r0 = remove()
    //     0x694a70: bl              #0x46f904  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::remove
    // 0x694a74: ldur            x1, [fp, #-8]
    // 0x694a78: LoadField: r0 = r1->field_8b
    //     0x694a78: ldur            x0, [x1, #0x8b]
    // 0x694a7c: cmp             x0, #0xb
    // 0x694a80: b.lt            #0x694a98
    // 0x694a84: ldur            x2, [fp, #-0x10]
    // 0x694a88: r3 = Instance_Tuple2
    //     0x694a88: add             x3, PP, #0x29, lsl #12  ; [pp+0x29630] Obj!Tuple2<int, String>@826471
    //     0x694a8c: ldr             x3, [x3, #0x630]
    // 0x694a90: r0 = completeChapter()
    //     0x694a90: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x694a94: b               #0x694aa4
    // 0x694a98: add             x2, x0, #1
    // 0x694a9c: StoreField: r1->field_8b = r2
    //     0x694a9c: stur            x2, [x1, #0x8b]
    // 0x694aa0: r0 = kernelReset()
    //     0x694aa0: bl              #0x693ad0  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::kernelReset
    // 0x694aa4: r0 = Null
    //     0x694aa4: mov             x0, NULL
    // 0x694aa8: LeaveFrame
    //     0x694aa8: mov             SP, fp
    //     0x694aac: ldp             fp, lr, [SP], #0x10
    // 0x694ab0: ret
    //     0x694ab0: ret             
    // 0x694ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694ab4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694ab8: b               #0x694a50
    // 0x694abc: r9 = prefs
    //     0x694abc: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x694ac0: ldr             x9, [x9, #0xc00]
    // 0x694ac4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x694ac4: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x696370, size: 0xc
    // 0x696370: r0 = "Upgrade Kernel"
    //     0x696370: add             x0, PP, #0x29, lsl #12  ; [pp+0x29638] "Upgrade Kernel"
    //     0x696374: ldr             x0, [x0, #0x638]
    // 0x696378: ret
    //     0x696378: ret             
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d118, size: 0x7c
    // 0x80d118: EnterFrame
    //     0x80d118: stp             fp, lr, [SP, #-0x10]!
    //     0x80d11c: mov             fp, SP
    // 0x80d120: AllocStack(0x8)
    //     0x80d120: sub             SP, SP, #8
    // 0x80d124: CheckStackOverflow
    //     0x80d124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d128: cmp             SP, x16
    //     0x80d12c: b.ls            #0x80d17c
    // 0x80d130: LoadField: r0 = r1->field_93
    //     0x80d130: ldur            w0, [x1, #0x93]
    // 0x80d134: DecompressPointer r0
    //     0x80d134: add             x0, x0, HEAP, lsl #32
    // 0x80d138: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d13c: cmp             w0, w16
    // 0x80d140: b.eq            #0x80d184
    // 0x80d144: mov             x1, x0
    // 0x80d148: stur            x0, [fp, #-8]
    // 0x80d14c: r0 = _getValueOrData()
    //     0x80d14c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d150: ldur            x1, [fp, #-8]
    // 0x80d154: LoadField: r2 = r1->field_f
    //     0x80d154: ldur            w2, [x1, #0xf]
    // 0x80d158: DecompressPointer r2
    //     0x80d158: add             x2, x2, HEAP, lsl #32
    // 0x80d15c: cmp             w2, w0
    // 0x80d160: b.ne            #0x80d168
    // 0x80d164: r0 = Null
    //     0x80d164: mov             x0, NULL
    // 0x80d168: cmp             w0, NULL
    // 0x80d16c: b.eq            #0x80d190
    // 0x80d170: LeaveFrame
    //     0x80d170: mov             SP, fp
    //     0x80d174: ldp             fp, lr, [SP], #0x10
    // 0x80d178: ret
    //     0x80d178: ret             
    // 0x80d17c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d17c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d180: b               #0x80d130
    // 0x80d184: r9 = generators
    //     0x80d184: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a760] Field <Chapter10GameState.generators>: late (offset: 0x94)
    //     0x80d188: ldr             x9, [x9, #0x760]
    // 0x80d18c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d18c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d190: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ reset(/* No info */) {
    // ** addr: 0x81b030, size: 0x70
    // 0x81b030: EnterFrame
    //     0x81b030: stp             fp, lr, [SP, #-0x10]!
    //     0x81b034: mov             fp, SP
    // 0x81b038: AllocStack(0x10)
    //     0x81b038: sub             SP, SP, #0x10
    // 0x81b03c: SetupParameters(Chapter10GameState this /* r1 => r0, fp-0x8 */)
    //     0x81b03c: mov             x0, x1
    //     0x81b040: stur            x1, [fp, #-8]
    // 0x81b044: CheckStackOverflow
    //     0x81b044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x81b048: cmp             SP, x16
    //     0x81b04c: b.ls            #0x81b098
    // 0x81b050: r16 = false
    //     0x81b050: add             x16, NULL, #0x30  ; false
    // 0x81b054: str             x16, [SP]
    // 0x81b058: mov             x1, x0
    // 0x81b05c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x81b05c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x81b060: ldr             x4, [x4, #0x2b8]
    // 0x81b064: r0 = reset()
    //     0x81b064: bl              #0x81b0a0  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::reset
    // 0x81b068: ldur            x1, [fp, #-8]
    // 0x81b06c: r0 = 1
    //     0x81b06c: movz            x0, #0x1
    // 0x81b070: StoreField: r1->field_8b = r0
    //     0x81b070: stur            x0, [x1, #0x8b]
    // 0x81b074: r16 = <ChapterViewportState>
    //     0x81b074: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9e0] TypeArguments: <ChapterViewportState>
    //     0x81b078: ldr             x16, [x16, #0x9e0]
    // 0x81b07c: str             x16, [SP]
    // 0x81b080: r4 = const [0x1, 0, 0, 0, null]
    //     0x81b080: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x81b084: r0 = updateAll()
    //     0x81b084: bl              #0x4589c0  ; [package:state_groups/src/sync_state.dart] ::updateAll
    // 0x81b088: r0 = Null
    //     0x81b088: mov             x0, NULL
    // 0x81b08c: LeaveFrame
    //     0x81b08c: mov             SP, fp
    //     0x81b090: ldp             fp, lr, [SP], #0x10
    // 0x81b094: ret
    //     0x81b094: ret             
    // 0x81b098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81b098: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81b09c: b               #0x81b050
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d108, size: 0xc
    // 0x81d108: r0 = "10"
    //     0x81d108: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x81d10c: ldr             x0, [x0, #0x9d0]
    // 0x81d110: ret
    //     0x81d110: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f63c, size: 0x24
    // 0x81f63c: EnterFrame
    //     0x81f63c: stp             fp, lr, [SP, #-0x10]!
    //     0x81f640: mov             fp, SP
    // 0x81f644: ldr             x2, [fp, #0x10]
    // 0x81f648: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f648: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb50] AnonymousClosure: (0x3d9e70), in [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::getCostToBuyOneMoreGenerator (0x3d9ab0)
    //     0x81f64c: ldr             x1, [x1, #0xb50]
    // 0x81f650: r0 = AllocateClosure()
    //     0x81f650: bl              #0x826750  ; AllocateClosureStub
    // 0x81f654: LeaveFrame
    //     0x81f654: mov             SP, fp
    //     0x81f658: ldp             fp, lr, [SP], #0x10
    // 0x81f65c: ret
    //     0x81f65c: ret             
  }
}

// class id: 4188, size: 0x14, field offset: 0x14
enum Chapter10Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x7247b8, size: 0x64
    // 0x7247b8: EnterFrame
    //     0x7247b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7247bc: mov             fp, SP
    // 0x7247c0: AllocStack(0x10)
    //     0x7247c0: sub             SP, SP, #0x10
    // 0x7247c4: SetupParameters(Chapter10Stat this /* r1 => r0, fp-0x8 */)
    //     0x7247c4: mov             x0, x1
    //     0x7247c8: stur            x1, [fp, #-8]
    // 0x7247cc: CheckStackOverflow
    //     0x7247cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7247d0: cmp             SP, x16
    //     0x7247d4: b.ls            #0x724814
    // 0x7247d8: r1 = Null
    //     0x7247d8: mov             x1, NULL
    // 0x7247dc: r2 = 4
    //     0x7247dc: movz            x2, #0x4
    // 0x7247e0: r0 = AllocateArray()
    //     0x7247e0: bl              #0x82746c  ; AllocateArrayStub
    // 0x7247e4: r16 = "Chapter10Stat."
    //     0x7247e4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16868] "Chapter10Stat."
    //     0x7247e8: ldr             x16, [x16, #0x868]
    // 0x7247ec: StoreField: r0->field_f = r16
    //     0x7247ec: stur            w16, [x0, #0xf]
    // 0x7247f0: ldur            x1, [fp, #-8]
    // 0x7247f4: LoadField: r2 = r1->field_f
    //     0x7247f4: ldur            w2, [x1, #0xf]
    // 0x7247f8: DecompressPointer r2
    //     0x7247f8: add             x2, x2, HEAP, lsl #32
    // 0x7247fc: StoreField: r0->field_13 = r2
    //     0x7247fc: stur            w2, [x0, #0x13]
    // 0x724800: str             x0, [SP]
    // 0x724804: r0 = _interpolate()
    //     0x724804: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724808: LeaveFrame
    //     0x724808: mov             SP, fp
    //     0x72480c: ldp             fp, lr, [SP], #0x10
    // 0x724810: ret
    //     0x724810: ret             
    // 0x724814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724814: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724818: b               #0x7247d8
  }
}
