// lib: , url: package:pretentious/data/Chapters/Chapter13GameState.dart

// class id: 1049450, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46cc8c, size: 0x224
    // 0x46cc8c: EnterFrame
    //     0x46cc8c: stp             fp, lr, [SP, #-0x10]!
    //     0x46cc90: mov             fp, SP
    // 0x46cc94: CheckStackOverflow
    //     0x46cc94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46cc98: cmp             SP, x16
    //     0x46cc9c: b.ls            #0x46cea8
    // 0x46cca0: cmp             w1, NULL
    // 0x46cca4: b.ne            #0x46ccb8
    // 0x46cca8: r0 = ""
    //     0x46cca8: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46ccac: LeaveFrame
    //     0x46ccac: mov             SP, fp
    //     0x46ccb0: ldp             fp, lr, [SP], #0x10
    // 0x46ccb4: ret
    //     0x46ccb4: ret             
    // 0x46ccb8: r16 = Instance_Chapter13Stat
    //     0x46ccb8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x46ccbc: ldr             x16, [x16, #0x298]
    // 0x46ccc0: cmp             w1, w16
    // 0x46ccc4: b.ne            #0x46cce0
    // 0x46ccc8: r1 = "power"
    //     0x46ccc8: add             x1, PP, #0x11, lsl #12  ; [pp+0x112d8] "power"
    //     0x46cccc: ldr             x1, [x1, #0x2d8]
    // 0x46ccd0: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46ccd0: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46ccd4: LeaveFrame
    //     0x46ccd4: mov             SP, fp
    //     0x46ccd8: ldp             fp, lr, [SP], #0x10
    // 0x46ccdc: ret
    //     0x46ccdc: ret             
    // 0x46cce0: r16 = Instance_Chapter13Stat
    //     0x46cce0: add             x16, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x46cce4: ldr             x16, [x16, #0x2e0]
    // 0x46cce8: cmp             w1, w16
    // 0x46ccec: b.ne            #0x46cd08
    // 0x46ccf0: r1 = "compute"
    //     0x46ccf0: add             x1, PP, #0x11, lsl #12  ; [pp+0x112e8] "compute"
    //     0x46ccf4: ldr             x1, [x1, #0x2e8]
    // 0x46ccf8: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46ccf8: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46ccfc: LeaveFrame
    //     0x46ccfc: mov             SP, fp
    //     0x46cd00: ldp             fp, lr, [SP], #0x10
    // 0x46cd04: ret
    //     0x46cd04: ret             
    // 0x46cd08: r16 = Instance_Chapter13Stat
    //     0x46cd08: add             x16, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x46cd0c: ldr             x16, [x16, #0x2f0]
    // 0x46cd10: cmp             w1, w16
    // 0x46cd14: b.ne            #0x46cd30
    // 0x46cd18: r1 = "storage"
    //     0x46cd18: add             x1, PP, #0x11, lsl #12  ; [pp+0x112f8] "storage"
    //     0x46cd1c: ldr             x1, [x1, #0x2f8]
    // 0x46cd20: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46cd20: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46cd24: LeaveFrame
    //     0x46cd24: mov             SP, fp
    //     0x46cd28: ldp             fp, lr, [SP], #0x10
    // 0x46cd2c: ret
    //     0x46cd2c: ret             
    // 0x46cd30: r16 = Instance_Chapter13Stat
    //     0x46cd30: add             x16, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x46cd34: ldr             x16, [x16, #0x300]
    // 0x46cd38: cmp             w1, w16
    // 0x46cd3c: b.ne            #0x46cd58
    // 0x46cd40: r1 = "networking"
    //     0x46cd40: add             x1, PP, #0x11, lsl #12  ; [pp+0x11308] "networking"
    //     0x46cd44: ldr             x1, [x1, #0x308]
    // 0x46cd48: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46cd48: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46cd4c: LeaveFrame
    //     0x46cd4c: mov             SP, fp
    //     0x46cd50: ldp             fp, lr, [SP], #0x10
    // 0x46cd54: ret
    //     0x46cd54: ret             
    // 0x46cd58: r16 = Instance_Chapter13Stat
    //     0x46cd58: add             x16, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x46cd5c: ldr             x16, [x16, #0x310]
    // 0x46cd60: cmp             w1, w16
    // 0x46cd64: b.ne            #0x46cd80
    // 0x46cd68: r1 = "databases"
    //     0x46cd68: add             x1, PP, #0x11, lsl #12  ; [pp+0x11318] "databases"
    //     0x46cd6c: ldr             x1, [x1, #0x318]
    // 0x46cd70: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46cd70: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46cd74: LeaveFrame
    //     0x46cd74: mov             SP, fp
    //     0x46cd78: ldp             fp, lr, [SP], #0x10
    // 0x46cd7c: ret
    //     0x46cd7c: ret             
    // 0x46cd80: r16 = Instance_Chapter13Stat
    //     0x46cd80: add             x16, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x46cd84: ldr             x16, [x16, #0x320]
    // 0x46cd88: cmp             w1, w16
    // 0x46cd8c: b.ne            #0x46cda8
    // 0x46cd90: r1 = "security"
    //     0x46cd90: add             x1, PP, #0x11, lsl #12  ; [pp+0x11328] "security"
    //     0x46cd94: ldr             x1, [x1, #0x328]
    // 0x46cd98: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46cd98: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46cd9c: LeaveFrame
    //     0x46cd9c: mov             SP, fp
    //     0x46cda0: ldp             fp, lr, [SP], #0x10
    // 0x46cda4: ret
    //     0x46cda4: ret             
    // 0x46cda8: r16 = Instance_Chapter13Stat
    //     0x46cda8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11330] Obj!Chapter13Stat@85faa1
    //     0x46cdac: ldr             x16, [x16, #0x330]
    // 0x46cdb0: cmp             w1, w16
    // 0x46cdb4: b.ne            #0x46cdd0
    // 0x46cdb8: r1 = "management"
    //     0x46cdb8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11338] "management"
    //     0x46cdbc: ldr             x1, [x1, #0x338]
    // 0x46cdc0: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46cdc0: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46cdc4: LeaveFrame
    //     0x46cdc4: mov             SP, fp
    //     0x46cdc8: ldp             fp, lr, [SP], #0x10
    // 0x46cdcc: ret
    //     0x46cdcc: ret             
    // 0x46cdd0: r16 = Instance_Chapter13Stat
    //     0x46cdd0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11340] Obj!Chapter13Stat@85fa81
    //     0x46cdd4: ldr             x16, [x16, #0x340]
    // 0x46cdd8: cmp             w1, w16
    // 0x46cddc: b.ne            #0x46cdf8
    // 0x46cde0: r1 = "analytics"
    //     0x46cde0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11348] "analytics"
    //     0x46cde4: ldr             x1, [x1, #0x348]
    // 0x46cde8: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46cde8: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46cdec: LeaveFrame
    //     0x46cdec: mov             SP, fp
    //     0x46cdf0: ldp             fp, lr, [SP], #0x10
    // 0x46cdf4: ret
    //     0x46cdf4: ret             
    // 0x46cdf8: r16 = Instance_Chapter13Stat
    //     0x46cdf8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11350] Obj!Chapter13Stat@85fa61
    //     0x46cdfc: ldr             x16, [x16, #0x350]
    // 0x46ce00: cmp             w1, w16
    // 0x46ce04: b.ne            #0x46ce20
    // 0x46ce08: r1 = "ml"
    //     0x46ce08: add             x1, PP, #0x11, lsl #12  ; [pp+0x11358] "ml"
    //     0x46ce0c: ldr             x1, [x1, #0x358]
    // 0x46ce10: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46ce10: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46ce14: LeaveFrame
    //     0x46ce14: mov             SP, fp
    //     0x46ce18: ldp             fp, lr, [SP], #0x10
    // 0x46ce1c: ret
    //     0x46ce1c: ret             
    // 0x46ce20: r16 = Instance_Chapter13Stat
    //     0x46ce20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x46ce24: ldr             x16, [x16, #0x360]
    // 0x46ce28: cmp             w1, w16
    // 0x46ce2c: b.ne            #0x46ce48
    // 0x46ce30: r1 = "dev"
    //     0x46ce30: add             x1, PP, #0x11, lsl #12  ; [pp+0x11368] "dev"
    //     0x46ce34: ldr             x1, [x1, #0x368]
    // 0x46ce38: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46ce38: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46ce3c: LeaveFrame
    //     0x46ce3c: mov             SP, fp
    //     0x46ce40: ldp             fp, lr, [SP], #0x10
    // 0x46ce44: ret
    //     0x46ce44: ret             
    // 0x46ce48: r16 = Instance_Chapter13Stat
    //     0x46ce48: add             x16, PP, #0x11, lsl #12  ; [pp+0x11370] Obj!Chapter13Stat@85fa21
    //     0x46ce4c: ldr             x16, [x16, #0x370]
    // 0x46ce50: cmp             w1, w16
    // 0x46ce54: b.ne            #0x46ce70
    // 0x46ce58: r1 = "integration"
    //     0x46ce58: add             x1, PP, #0x11, lsl #12  ; [pp+0x11378] "integration"
    //     0x46ce5c: ldr             x1, [x1, #0x378]
    // 0x46ce60: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46ce60: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46ce64: LeaveFrame
    //     0x46ce64: mov             SP, fp
    //     0x46ce68: ldp             fp, lr, [SP], #0x10
    // 0x46ce6c: ret
    //     0x46ce6c: ret             
    // 0x46ce70: r16 = Instance_Chapter13Stat
    //     0x46ce70: add             x16, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x46ce74: ldr             x16, [x16, #0x380]
    // 0x46ce78: cmp             w1, w16
    // 0x46ce7c: b.ne            #0x46ce98
    // 0x46ce80: r1 = "experience"
    //     0x46ce80: add             x1, PP, #0x11, lsl #12  ; [pp+0x11388] "experience"
    //     0x46ce84: ldr             x1, [x1, #0x388]
    // 0x46ce88: r0 = Capitalization.capitalizeFirstLetter()
    //     0x46ce88: bl              #0x46ceb0  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.capitalizeFirstLetter
    // 0x46ce8c: LeaveFrame
    //     0x46ce8c: mov             SP, fp
    //     0x46ce90: ldp             fp, lr, [SP], #0x10
    // 0x46ce94: ret
    //     0x46ce94: ret             
    // 0x46ce98: r0 = Null
    //     0x46ce98: mov             x0, NULL
    // 0x46ce9c: LeaveFrame
    //     0x46ce9c: mov             SP, fp
    //     0x46cea0: ldp             fp, lr, [SP], #0x10
    // 0x46cea4: ret
    //     0x46cea4: ret             
    // 0x46cea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46cea8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46ceac: b               #0x46cca0
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46cfc4, size: 0x158
    // 0x46cfc4: r16 = Instance_Chapter13Stat
    //     0x46cfc4: add             x16, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x46cfc8: ldr             x16, [x16, #0x2e0]
    // 0x46cfcc: cmp             w1, w16
    // 0x46cfd0: b.ne            #0x46cfe0
    // 0x46cfd4: r0 = "Cmpt"
    //     0x46cfd4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11390] "Cmpt"
    //     0x46cfd8: ldr             x0, [x0, #0x390]
    // 0x46cfdc: ret
    //     0x46cfdc: ret             
    // 0x46cfe0: r16 = Instance_Chapter13Stat
    //     0x46cfe0: add             x16, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x46cfe4: ldr             x16, [x16, #0x2f0]
    // 0x46cfe8: cmp             w1, w16
    // 0x46cfec: b.ne            #0x46cffc
    // 0x46cff0: r0 = "Stg"
    //     0x46cff0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11398] "Stg"
    //     0x46cff4: ldr             x0, [x0, #0x398]
    // 0x46cff8: ret
    //     0x46cff8: ret             
    // 0x46cffc: r16 = Instance_Chapter13Stat
    //     0x46cffc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x46d000: ldr             x16, [x16, #0x300]
    // 0x46d004: cmp             w1, w16
    // 0x46d008: b.ne            #0x46d018
    // 0x46d00c: r0 = "Ntwrk"
    //     0x46d00c: add             x0, PP, #0x11, lsl #12  ; [pp+0x113a0] "Ntwrk"
    //     0x46d010: ldr             x0, [x0, #0x3a0]
    // 0x46d014: ret
    //     0x46d014: ret             
    // 0x46d018: r16 = Instance_Chapter13Stat
    //     0x46d018: add             x16, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x46d01c: ldr             x16, [x16, #0x310]
    // 0x46d020: cmp             w1, w16
    // 0x46d024: b.ne            #0x46d034
    // 0x46d028: r0 = "Data"
    //     0x46d028: add             x0, PP, #0x11, lsl #12  ; [pp+0x113a8] "Data"
    //     0x46d02c: ldr             x0, [x0, #0x3a8]
    // 0x46d030: ret
    //     0x46d030: ret             
    // 0x46d034: r16 = Instance_Chapter13Stat
    //     0x46d034: add             x16, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x46d038: ldr             x16, [x16, #0x320]
    // 0x46d03c: cmp             w1, w16
    // 0x46d040: b.ne            #0x46d050
    // 0x46d044: r0 = "Scrt"
    //     0x46d044: add             x0, PP, #0x11, lsl #12  ; [pp+0x113b0] "Scrt"
    //     0x46d048: ldr             x0, [x0, #0x3b0]
    // 0x46d04c: ret
    //     0x46d04c: ret             
    // 0x46d050: r16 = Instance_Chapter13Stat
    //     0x46d050: add             x16, PP, #0x11, lsl #12  ; [pp+0x11330] Obj!Chapter13Stat@85faa1
    //     0x46d054: ldr             x16, [x16, #0x330]
    // 0x46d058: cmp             w1, w16
    // 0x46d05c: b.ne            #0x46d06c
    // 0x46d060: r0 = "Mng"
    //     0x46d060: add             x0, PP, #0x11, lsl #12  ; [pp+0x113b8] "Mng"
    //     0x46d064: ldr             x0, [x0, #0x3b8]
    // 0x46d068: ret
    //     0x46d068: ret             
    // 0x46d06c: r16 = Instance_Chapter13Stat
    //     0x46d06c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11340] Obj!Chapter13Stat@85fa81
    //     0x46d070: ldr             x16, [x16, #0x340]
    // 0x46d074: cmp             w1, w16
    // 0x46d078: b.ne            #0x46d088
    // 0x46d07c: r0 = "Anltcs"
    //     0x46d07c: add             x0, PP, #0x11, lsl #12  ; [pp+0x113c0] "Anltcs"
    //     0x46d080: ldr             x0, [x0, #0x3c0]
    // 0x46d084: ret
    //     0x46d084: ret             
    // 0x46d088: r16 = Instance_Chapter13Stat
    //     0x46d088: add             x16, PP, #0x11, lsl #12  ; [pp+0x11350] Obj!Chapter13Stat@85fa61
    //     0x46d08c: ldr             x16, [x16, #0x350]
    // 0x46d090: cmp             w1, w16
    // 0x46d094: b.ne            #0x46d0a4
    // 0x46d098: r0 = "Ml"
    //     0x46d098: add             x0, PP, #0x11, lsl #12  ; [pp+0x113c8] "Ml"
    //     0x46d09c: ldr             x0, [x0, #0x3c8]
    // 0x46d0a0: ret
    //     0x46d0a0: ret             
    // 0x46d0a4: r16 = Instance_Chapter13Stat
    //     0x46d0a4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x46d0a8: ldr             x16, [x16, #0x360]
    // 0x46d0ac: cmp             w1, w16
    // 0x46d0b0: b.ne            #0x46d0c0
    // 0x46d0b4: r0 = "Dev"
    //     0x46d0b4: add             x0, PP, #0x11, lsl #12  ; [pp+0x113d0] "Dev"
    //     0x46d0b8: ldr             x0, [x0, #0x3d0]
    // 0x46d0bc: ret
    //     0x46d0bc: ret             
    // 0x46d0c0: r16 = Instance_Chapter13Stat
    //     0x46d0c0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11370] Obj!Chapter13Stat@85fa21
    //     0x46d0c4: ldr             x16, [x16, #0x370]
    // 0x46d0c8: cmp             w1, w16
    // 0x46d0cc: b.ne            #0x46d0dc
    // 0x46d0d0: r0 = "Int"
    //     0x46d0d0: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] "Int"
    //     0x46d0d4: ldr             x0, [x0, #0xe68]
    // 0x46d0d8: ret
    //     0x46d0d8: ret             
    // 0x46d0dc: r16 = Instance_Chapter13Stat
    //     0x46d0dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x46d0e0: ldr             x16, [x16, #0x298]
    // 0x46d0e4: cmp             w1, w16
    // 0x46d0e8: b.ne            #0x46d0f8
    // 0x46d0ec: r0 = "Pwr"
    //     0x46d0ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x113d8] "Pwr"
    //     0x46d0f0: ldr             x0, [x0, #0x3d8]
    // 0x46d0f4: ret
    //     0x46d0f4: ret             
    // 0x46d0f8: r16 = Instance_Chapter13Stat
    //     0x46d0f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x46d0fc: ldr             x16, [x16, #0x380]
    // 0x46d100: cmp             w1, w16
    // 0x46d104: b.ne            #0x46d114
    // 0x46d108: r0 = "Exp"
    //     0x46d108: add             x0, PP, #0x11, lsl #12  ; [pp+0x113e0] "Exp"
    //     0x46d10c: ldr             x0, [x0, #0x3e0]
    // 0x46d110: ret
    //     0x46d110: ret             
    // 0x46d114: r0 = Null
    //     0x46d114: mov             x0, NULL
    // 0x46d118: ret
    //     0x46d118: ret             
  }
}

// class id: 282, size: 0xa4, field offset: 0x8c
class Chapter13GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter13Stat>> generators; // offset: 0x94
  late List<CustomNum> researchLevels; // offset: 0xa0
  late Map<int, UpgradeData<Chapter13Stat>> allUpgradeData; // offset: 0x98

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3dad94, size: 0x140
    // 0x3dad94: EnterFrame
    //     0x3dad94: stp             fp, lr, [SP, #-0x10]!
    //     0x3dad98: mov             fp, SP
    // 0x3dad9c: AllocStack(0x30)
    //     0x3dad9c: sub             SP, SP, #0x30
    // 0x3dada0: SetupParameters(Chapter13GameState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x3dada0: mov             x4, x1
    //     0x3dada4: mov             x0, x3
    //     0x3dada8: stur            x3, [fp, #-0x18]
    //     0x3dadac: mov             x3, x2
    //     0x3dadb0: stur            x1, [fp, #-8]
    //     0x3dadb4: stur            x2, [fp, #-0x10]
    // 0x3dadb8: CheckStackOverflow
    //     0x3dadb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dadbc: cmp             SP, x16
    //     0x3dadc0: b.ls            #0x3daec8
    // 0x3dadc4: mov             x1, x4
    // 0x3dadc8: mov             x2, x3
    // 0x3dadcc: r0 = getGeneratorInfo()
    //     0x3dadcc: bl              #0x80d28c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorInfo
    // 0x3dadd0: LoadField: r3 = r0->field_27
    //     0x3dadd0: ldur            w3, [x0, #0x27]
    // 0x3dadd4: DecompressPointer r3
    //     0x3dadd4: add             x3, x3, HEAP, lsl #32
    // 0x3dadd8: stur            x3, [fp, #-0x30]
    // 0x3daddc: cmp             w3, NULL
    // 0x3dade0: b.eq            #0x3daed0
    // 0x3dade4: LoadField: r0 = r3->field_b
    //     0x3dade4: ldur            w0, [x3, #0xb]
    // 0x3dade8: DecompressPointer r0
    //     0x3dade8: add             x0, x0, HEAP, lsl #32
    // 0x3dadec: ldur            x1, [fp, #-8]
    // 0x3dadf0: stur            x0, [fp, #-0x28]
    // 0x3dadf4: LoadField: r4 = r1->field_33
    //     0x3dadf4: ldur            w4, [x1, #0x33]
    // 0x3dadf8: DecompressPointer r4
    //     0x3dadf8: add             x4, x4, HEAP, lsl #32
    // 0x3dadfc: mov             x1, x4
    // 0x3dae00: ldur            x2, [fp, #-0x10]
    // 0x3dae04: stur            x4, [fp, #-0x20]
    // 0x3dae08: r0 = _getValueOrData()
    //     0x3dae08: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3dae0c: mov             x1, x0
    // 0x3dae10: ldur            x0, [fp, #-0x20]
    // 0x3dae14: LoadField: r2 = r0->field_f
    //     0x3dae14: ldur            w2, [x0, #0xf]
    // 0x3dae18: DecompressPointer r2
    //     0x3dae18: add             x2, x2, HEAP, lsl #32
    // 0x3dae1c: cmp             w2, w1
    // 0x3dae20: b.ne            #0x3dae2c
    // 0x3dae24: r0 = Null
    //     0x3dae24: mov             x0, NULL
    // 0x3dae28: b               #0x3dae30
    // 0x3dae2c: mov             x0, x1
    // 0x3dae30: cmp             w0, NULL
    // 0x3dae34: b.ne            #0x3dae40
    // 0x3dae38: r0 = Null
    //     0x3dae38: mov             x0, NULL
    // 0x3dae3c: b               #0x3dae4c
    // 0x3dae40: LoadField: r1 = r0->field_b
    //     0x3dae40: ldur            w1, [x0, #0xb]
    // 0x3dae44: DecompressPointer r1
    //     0x3dae44: add             x1, x1, HEAP, lsl #32
    // 0x3dae48: mov             x0, x1
    // 0x3dae4c: cmp             w0, NULL
    // 0x3dae50: b.ne            #0x3dae60
    // 0x3dae54: r4 = Instance_CustomNum
    //     0x3dae54: add             x4, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3dae58: ldr             x4, [x4, #0xa70]
    // 0x3dae5c: b               #0x3dae64
    // 0x3dae60: mov             x4, x0
    // 0x3dae64: ldur            x0, [fp, #-0x30]
    // 0x3dae68: ldur            x3, [fp, #-0x28]
    // 0x3dae6c: ldur            x2, [fp, #-0x18]
    // 0x3dae70: stur            x4, [fp, #-8]
    // 0x3dae74: r1 = Instance_CustomNum
    //     0x3dae74: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3dae78: ldr             x1, [x1, #0x2f0]
    // 0x3dae7c: r0 = pow()
    //     0x3dae7c: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3dae80: mov             x1, x0
    // 0x3dae84: ldur            x0, [fp, #-0x30]
    // 0x3dae88: LoadField: r3 = r0->field_f
    //     0x3dae88: ldur            w3, [x0, #0xf]
    // 0x3dae8c: DecompressPointer r3
    //     0x3dae8c: add             x3, x3, HEAP, lsl #32
    // 0x3dae90: mov             x2, x1
    // 0x3dae94: ldur            x1, [fp, #-8]
    // 0x3dae98: r0 = mult3()
    //     0x3dae98: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x3dae9c: r1 = <Chapter13Stat, CustomNum>
    //     0x3dae9c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6c8] TypeArguments: <Chapter13Stat, CustomNum>
    //     0x3daea0: ldr             x1, [x1, #0x6c8]
    // 0x3daea4: stur            x0, [fp, #-8]
    // 0x3daea8: r0 = Tuple2()
    //     0x3daea8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3daeac: ldur            x1, [fp, #-0x28]
    // 0x3daeb0: StoreField: r0->field_b = r1
    //     0x3daeb0: stur            w1, [x0, #0xb]
    // 0x3daeb4: ldur            x1, [fp, #-8]
    // 0x3daeb8: StoreField: r0->field_f = r1
    //     0x3daeb8: stur            w1, [x0, #0xf]
    // 0x3daebc: LeaveFrame
    //     0x3daebc: mov             SP, fp
    //     0x3daec0: ldp             fp, lr, [SP], #0x10
    // 0x3daec4: ret
    //     0x3daec4: ret             
    // 0x3daec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3daec8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3daecc: b               #0x3dadc4
    // 0x3daed0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3daed0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter13Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3daed4, size: 0x40
    // 0x3daed4: EnterFrame
    //     0x3daed4: stp             fp, lr, [SP, #-0x10]!
    //     0x3daed8: mov             fp, SP
    // 0x3daedc: ldr             x0, [fp, #0x20]
    // 0x3daee0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3daee0: ldur            w1, [x0, #0x17]
    // 0x3daee4: DecompressPointer r1
    //     0x3daee4: add             x1, x1, HEAP, lsl #32
    // 0x3daee8: CheckStackOverflow
    //     0x3daee8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3daeec: cmp             SP, x16
    //     0x3daef0: b.ls            #0x3daf0c
    // 0x3daef4: ldr             x2, [fp, #0x18]
    // 0x3daef8: ldr             x3, [fp, #0x10]
    // 0x3daefc: r0 = getCostToBuyOneMoreGenerator()
    //     0x3daefc: bl              #0x3dad94  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getCostToBuyOneMoreGenerator
    // 0x3daf00: LeaveFrame
    //     0x3daf00: mov             SP, fp
    //     0x3daf04: ldp             fp, lr, [SP], #0x10
    // 0x3daf08: ret
    //     0x3daf08: ret             
    // 0x3daf0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3daf0c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3daf10: b               #0x3daef4
  }
  _ Chapter13GameState(/* No info */) {
    // ** addr: 0x46c900, size: 0x35c
    // 0x46c900: EnterFrame
    //     0x46c900: stp             fp, lr, [SP, #-0x10]!
    //     0x46c904: mov             fp, SP
    // 0x46c908: AllocStack(0x28)
    //     0x46c908: sub             SP, SP, #0x28
    // 0x46c90c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46c910: mov             x3, x1
    // 0x46c914: stur            x1, [fp, #-8]
    // 0x46c918: stur            x2, [fp, #-0x10]
    // 0x46c91c: CheckStackOverflow
    //     0x46c91c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46c920: cmp             SP, x16
    //     0x46c924: b.ls            #0x46cc50
    // 0x46c928: StoreField: r3->field_8b = rZR
    //     0x46c928: stur            xzr, [x3, #0x8b]
    // 0x46c92c: StoreField: r3->field_93 = r0
    //     0x46c92c: stur            w0, [x3, #0x93]
    // 0x46c930: StoreField: r3->field_97 = r0
    //     0x46c930: stur            w0, [x3, #0x97]
    // 0x46c934: StoreField: r3->field_9f = r0
    //     0x46c934: stur            w0, [x3, #0x9f]
    // 0x46c938: r1 = <int>
    //     0x46c938: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46c93c: r0 = _Set()
    //     0x46c93c: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x46c940: mov             x1, x0
    // 0x46c944: r0 = _Uint32List
    //     0x46c944: ldr             x0, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x46c948: StoreField: r1->field_1b = r0
    //     0x46c948: stur            w0, [x1, #0x1b]
    // 0x46c94c: StoreField: r1->field_b = rZR
    //     0x46c94c: stur            wzr, [x1, #0xb]
    // 0x46c950: r0 = const []
    //     0x46c950: ldr             x0, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x46c954: StoreField: r1->field_f = r0
    //     0x46c954: stur            w0, [x1, #0xf]
    // 0x46c958: StoreField: r1->field_13 = rZR
    //     0x46c958: stur            wzr, [x1, #0x13]
    // 0x46c95c: ArrayStore: r1[0] = rZR  ; List_4
    //     0x46c95c: stur            wzr, [x1, #0x17]
    // 0x46c960: mov             x0, x1
    // 0x46c964: ldur            x3, [fp, #-8]
    // 0x46c968: StoreField: r3->field_9b = r0
    //     0x46c968: stur            w0, [x3, #0x9b]
    //     0x46c96c: ldurb           w16, [x3, #-1]
    //     0x46c970: ldurb           w17, [x0, #-1]
    //     0x46c974: and             x16, x17, x16, lsr #2
    //     0x46c978: tst             x16, HEAP, lsr #32
    //     0x46c97c: b.eq            #0x46c984
    //     0x46c980: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46c984: r1 = Function '<anonymous closure>':.
    //     0x46c984: add             x1, PP, #0x11, lsl #12  ; [pp+0x11278] AnonymousClosure: (0x46d11c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x46c988: ldr             x1, [x1, #0x278]
    // 0x46c98c: r2 = Null
    //     0x46c98c: mov             x2, NULL
    // 0x46c990: r0 = AllocateClosure()
    //     0x46c990: bl              #0x826750  ; AllocateClosureStub
    // 0x46c994: r1 = Function '<anonymous closure>':.
    //     0x46c994: add             x1, PP, #0x11, lsl #12  ; [pp+0x11280] AnonymousClosure: (0x46cf94), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x46c998: ldr             x1, [x1, #0x280]
    // 0x46c99c: r2 = Null
    //     0x46c99c: mov             x2, NULL
    // 0x46c9a0: stur            x0, [fp, #-0x18]
    // 0x46c9a4: r0 = AllocateClosure()
    //     0x46c9a4: bl              #0x826750  ; AllocateClosureStub
    // 0x46c9a8: r1 = Function '<anonymous closure>':.
    //     0x46c9a8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11288] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x46c9ac: ldr             x1, [x1, #0x288]
    // 0x46c9b0: r2 = Null
    //     0x46c9b0: mov             x2, NULL
    // 0x46c9b4: stur            x0, [fp, #-0x20]
    // 0x46c9b8: r0 = AllocateClosure()
    //     0x46c9b8: bl              #0x826750  ; AllocateClosureStub
    // 0x46c9bc: r1 = Function '<anonymous closure>':.
    //     0x46c9bc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11290] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46c9c0: ldr             x1, [x1, #0x290]
    // 0x46c9c4: r2 = Null
    //     0x46c9c4: mov             x2, NULL
    // 0x46c9c8: stur            x0, [fp, #-0x28]
    // 0x46c9cc: r0 = AllocateClosure()
    //     0x46c9cc: bl              #0x826750  ; AllocateClosureStub
    // 0x46c9d0: ldur            x1, [fp, #-8]
    // 0x46c9d4: ldur            x2, [fp, #-0x10]
    // 0x46c9d8: ldur            x3, [fp, #-0x18]
    // 0x46c9dc: ldur            x5, [fp, #-0x20]
    // 0x46c9e0: ldur            x6, [fp, #-0x28]
    // 0x46c9e4: mov             x7, x0
    // 0x46c9e8: r0 = IPlayableGameState()
    //     0x46c9e8: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46c9ec: ldur            x0, [fp, #-8]
    // 0x46c9f0: LoadField: r3 = r0->field_37
    //     0x46c9f0: ldur            w3, [x0, #0x37]
    // 0x46c9f4: DecompressPointer r3
    //     0x46c9f4: add             x3, x3, HEAP, lsl #32
    // 0x46c9f8: mov             x1, x3
    // 0x46c9fc: stur            x3, [fp, #-0x18]
    // 0x46ca00: r2 = Instance_Chapter13Stat
    //     0x46ca00: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x46ca04: ldr             x2, [x2, #0x298]
    // 0x46ca08: r0 = _getValueOrData()
    //     0x46ca08: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x46ca0c: mov             x1, x0
    // 0x46ca10: ldur            x0, [fp, #-0x18]
    // 0x46ca14: LoadField: r2 = r0->field_f
    //     0x46ca14: ldur            w2, [x0, #0xf]
    // 0x46ca18: DecompressPointer r2
    //     0x46ca18: add             x2, x2, HEAP, lsl #32
    // 0x46ca1c: cmp             w2, w1
    // 0x46ca20: b.eq            #0x46ca2c
    // 0x46ca24: cmp             w1, NULL
    // 0x46ca28: b.ne            #0x46ca38
    // 0x46ca2c: r3 = Instance_CustomNum
    //     0x46ca2c: add             x3, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x46ca30: ldr             x3, [x3, #0x2a0]
    // 0x46ca34: b               #0x46ca9c
    // 0x46ca38: ldur            x0, [fp, #-8]
    // 0x46ca3c: LoadField: r3 = r0->field_37
    //     0x46ca3c: ldur            w3, [x0, #0x37]
    // 0x46ca40: DecompressPointer r3
    //     0x46ca40: add             x3, x3, HEAP, lsl #32
    // 0x46ca44: mov             x1, x3
    // 0x46ca48: stur            x3, [fp, #-0x18]
    // 0x46ca4c: r2 = Instance_Chapter13Stat
    //     0x46ca4c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x46ca50: ldr             x2, [x2, #0x298]
    // 0x46ca54: r0 = _getValueOrData()
    //     0x46ca54: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x46ca58: mov             x1, x0
    // 0x46ca5c: ldur            x0, [fp, #-0x18]
    // 0x46ca60: LoadField: r2 = r0->field_f
    //     0x46ca60: ldur            w2, [x0, #0xf]
    // 0x46ca64: DecompressPointer r2
    //     0x46ca64: add             x2, x2, HEAP, lsl #32
    // 0x46ca68: cmp             w2, w1
    // 0x46ca6c: b.ne            #0x46ca78
    // 0x46ca70: r0 = Null
    //     0x46ca70: mov             x0, NULL
    // 0x46ca74: b               #0x46ca7c
    // 0x46ca78: mov             x0, x1
    // 0x46ca7c: r3 = Instance_CustomNum
    //     0x46ca7c: add             x3, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x46ca80: ldr             x3, [x3, #0x2a0]
    // 0x46ca84: cmp             w0, NULL
    // 0x46ca88: b.eq            #0x46cc58
    // 0x46ca8c: LoadField: d0 = r3->field_7
    //     0x46ca8c: ldur            d0, [x3, #7]
    // 0x46ca90: LoadField: d1 = r0->field_7
    //     0x46ca90: ldur            d1, [x0, #7]
    // 0x46ca94: fcmp            d0, d1
    // 0x46ca98: b.le            #0x46cab4
    // 0x46ca9c: ldur            x0, [fp, #-8]
    // 0x46caa0: LoadField: r1 = r0->field_37
    //     0x46caa0: ldur            w1, [x0, #0x37]
    // 0x46caa4: DecompressPointer r1
    //     0x46caa4: add             x1, x1, HEAP, lsl #32
    // 0x46caa8: r2 = Instance_Chapter13Stat
    //     0x46caa8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x46caac: ldr             x2, [x2, #0x298]
    // 0x46cab0: r0 = []=()
    //     0x46cab0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x46cab4: ldur            x1, [fp, #-0x10]
    // 0x46cab8: cmp             w1, NULL
    // 0x46cabc: b.ne            #0x46cac8
    // 0x46cac0: r3 = Null
    //     0x46cac0: mov             x3, NULL
    // 0x46cac4: b               #0x46cae4
    // 0x46cac8: r0 = LoadClassIdInstr(r1)
    //     0x46cac8: ldur            x0, [x1, #-1]
    //     0x46cacc: ubfx            x0, x0, #0xc, #0x14
    // 0x46cad0: r2 = 38
    //     0x46cad0: movz            x2, #0x26
    // 0x46cad4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46cad4: sub             lr, x0, #1, lsl #12
    //     0x46cad8: ldr             lr, [x21, lr, lsl #3]
    //     0x46cadc: blr             lr
    // 0x46cae0: mov             x3, x0
    // 0x46cae4: mov             x0, x3
    // 0x46cae8: stur            x3, [fp, #-0x10]
    // 0x46caec: r2 = Null
    //     0x46caec: mov             x2, NULL
    // 0x46caf0: r1 = Null
    //     0x46caf0: mov             x1, NULL
    // 0x46caf4: r8 = Map?
    //     0x46caf4: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x46caf8: ldr             x8, [x8, #0x38]
    // 0x46cafc: r3 = Null
    //     0x46cafc: add             x3, PP, #0x11, lsl #12  ; [pp+0x112a8] Null
    //     0x46cb00: ldr             x3, [x3, #0x2a8]
    // 0x46cb04: r0 = Map?()
    //     0x46cb04: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x46cb08: ldur            x3, [fp, #-0x10]
    // 0x46cb0c: cmp             w3, NULL
    // 0x46cb10: b.ne            #0x46cb1c
    // 0x46cb14: r0 = Null
    //     0x46cb14: mov             x0, NULL
    // 0x46cb18: b               #0x46cb38
    // 0x46cb1c: r0 = LoadClassIdInstr(r3)
    //     0x46cb1c: ldur            x0, [x3, #-1]
    //     0x46cb20: ubfx            x0, x0, #0xc, #0x14
    // 0x46cb24: mov             x1, x3
    // 0x46cb28: r2 = 0
    //     0x46cb28: movz            x2, #0
    // 0x46cb2c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46cb2c: sub             lr, x0, #1, lsl #12
    //     0x46cb30: ldr             lr, [x21, lr, lsl #3]
    //     0x46cb34: blr             lr
    // 0x46cb38: cmp             w0, NULL
    // 0x46cb3c: b.ne            #0x46cb48
    // 0x46cb40: r5 = 0
    //     0x46cb40: movz            x5, #0
    // 0x46cb44: b               #0x46cb4c
    // 0x46cb48: mov             x5, x0
    // 0x46cb4c: ldur            x4, [fp, #-8]
    // 0x46cb50: ldur            x3, [fp, #-0x10]
    // 0x46cb54: mov             x0, x5
    // 0x46cb58: stur            x5, [fp, #-0x18]
    // 0x46cb5c: r2 = Null
    //     0x46cb5c: mov             x2, NULL
    // 0x46cb60: r1 = Null
    //     0x46cb60: mov             x1, NULL
    // 0x46cb64: branchIfSmi(r0, 0x46cb8c)
    //     0x46cb64: tbz             w0, #0, #0x46cb8c
    // 0x46cb68: r4 = LoadClassIdInstr(r0)
    //     0x46cb68: ldur            x4, [x0, #-1]
    //     0x46cb6c: ubfx            x4, x4, #0xc, #0x14
    // 0x46cb70: sub             x4, x4, #0x3c
    // 0x46cb74: cmp             x4, #1
    // 0x46cb78: b.ls            #0x46cb8c
    // 0x46cb7c: r8 = int
    //     0x46cb7c: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x46cb80: r3 = Null
    //     0x46cb80: add             x3, PP, #0x11, lsl #12  ; [pp+0x112b8] Null
    //     0x46cb84: ldr             x3, [x3, #0x2b8]
    // 0x46cb88: r0 = int()
    //     0x46cb88: bl              #0x82bb04  ; IsType_int_Stub
    // 0x46cb8c: ldur            x0, [fp, #-0x18]
    // 0x46cb90: r1 = LoadInt32Instr(r0)
    //     0x46cb90: sbfx            x1, x0, #1, #0x1f
    //     0x46cb94: tbz             w0, #0, #0x46cb9c
    //     0x46cb98: ldur            x1, [x0, #7]
    // 0x46cb9c: ldur            x3, [fp, #-8]
    // 0x46cba0: StoreField: r3->field_8b = r1
    //     0x46cba0: stur            x1, [x3, #0x8b]
    // 0x46cba4: ldur            x1, [fp, #-0x10]
    // 0x46cba8: cmp             w1, NULL
    // 0x46cbac: b.ne            #0x46cbb8
    // 0x46cbb0: r0 = Null
    //     0x46cbb0: mov             x0, NULL
    // 0x46cbb4: b               #0x46cbd0
    // 0x46cbb8: r0 = LoadClassIdInstr(r1)
    //     0x46cbb8: ldur            x0, [x1, #-1]
    //     0x46cbbc: ubfx            x0, x0, #0xc, #0x14
    // 0x46cbc0: r2 = 2
    //     0x46cbc0: movz            x2, #0x2
    // 0x46cbc4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46cbc4: sub             lr, x0, #1, lsl #12
    //     0x46cbc8: ldr             lr, [x21, lr, lsl #3]
    //     0x46cbcc: blr             lr
    // 0x46cbd0: cmp             w0, NULL
    // 0x46cbd4: b.ne            #0x46cbec
    // 0x46cbd8: r1 = <int>
    //     0x46cbd8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46cbdc: r2 = 0
    //     0x46cbdc: movz            x2, #0
    // 0x46cbe0: r0 = _GrowableList()
    //     0x46cbe0: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x46cbe4: mov             x4, x0
    // 0x46cbe8: b               #0x46cbf0
    // 0x46cbec: mov             x4, x0
    // 0x46cbf0: ldur            x3, [fp, #-8]
    // 0x46cbf4: mov             x0, x4
    // 0x46cbf8: stur            x4, [fp, #-0x10]
    // 0x46cbfc: r2 = Null
    //     0x46cbfc: mov             x2, NULL
    // 0x46cc00: r1 = Null
    //     0x46cc00: mov             x1, NULL
    // 0x46cc04: r8 = Iterable
    //     0x46cc04: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x46cc08: r3 = Null
    //     0x46cc08: add             x3, PP, #0x11, lsl #12  ; [pp+0x112c8] Null
    //     0x46cc0c: ldr             x3, [x3, #0x2c8]
    // 0x46cc10: r0 = Iterable()
    //     0x46cc10: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x46cc14: ldur            x2, [fp, #-0x10]
    // 0x46cc18: r1 = <int>
    //     0x46cc18: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46cc1c: r0 = LinkedHashSet.from()
    //     0x46cc1c: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x46cc20: ldur            x1, [fp, #-8]
    // 0x46cc24: StoreField: r1->field_9b = r0
    //     0x46cc24: stur            w0, [x1, #0x9b]
    //     0x46cc28: ldurb           w16, [x1, #-1]
    //     0x46cc2c: ldurb           w17, [x0, #-1]
    //     0x46cc30: and             x16, x17, x16, lsr #2
    //     0x46cc34: tst             x16, HEAP, lsr #32
    //     0x46cc38: b.eq            #0x46cc40
    //     0x46cc3c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x46cc40: r0 = Null
    //     0x46cc40: mov             x0, NULL
    // 0x46cc44: LeaveFrame
    //     0x46cc44: mov             SP, fp
    //     0x46cc48: ldp             fp, lr, [SP], #0x10
    // 0x46cc4c: ret
    //     0x46cc4c: ret             
    // 0x46cc50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46cc50: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46cc54: b               #0x46c928
    // 0x46cc58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x46cc58: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic, Chapter13Stat) {
    // ** addr: 0x46cc5c, size: 0x30
    // 0x46cc5c: EnterFrame
    //     0x46cc5c: stp             fp, lr, [SP, #-0x10]!
    //     0x46cc60: mov             fp, SP
    // 0x46cc64: CheckStackOverflow
    //     0x46cc64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46cc68: cmp             SP, x16
    //     0x46cc6c: b.ls            #0x46cc84
    // 0x46cc70: ldr             x1, [fp, #0x10]
    // 0x46cc74: r0 = humanName()
    //     0x46cc74: bl              #0x46cc8c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] ::humanName
    // 0x46cc78: LeaveFrame
    //     0x46cc78: mov             SP, fp
    //     0x46cc7c: ldp             fp, lr, [SP], #0x10
    // 0x46cc80: ret
    //     0x46cc80: ret             
    // 0x46cc84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46cc84: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46cc88: b               #0x46cc70
  }
  [closure] String <anonymous closure>(dynamic, Chapter13Stat) {
    // ** addr: 0x46cf94, size: 0x30
    // 0x46cf94: EnterFrame
    //     0x46cf94: stp             fp, lr, [SP, #-0x10]!
    //     0x46cf98: mov             fp, SP
    // 0x46cf9c: CheckStackOverflow
    //     0x46cf9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46cfa0: cmp             SP, x16
    //     0x46cfa4: b.ls            #0x46cfbc
    // 0x46cfa8: ldr             x1, [fp, #0x10]
    // 0x46cfac: r0 = shortenedName()
    //     0x46cfac: bl              #0x46cfc4  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] ::shortenedName
    // 0x46cfb0: LeaveFrame
    //     0x46cfb0: mov             SP, fp
    //     0x46cfb4: ldp             fp, lr, [SP], #0x10
    // 0x46cfb8: ret
    //     0x46cfb8: ret             
    // 0x46cfbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46cfbc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46cfc0: b               #0x46cfa8
  }
  [closure] Chapter13Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46d11c, size: 0x44
    // 0x46d11c: r2 = const [Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat']
    //     0x46d11c: add             x2, PP, #0x11, lsl #12  ; [pp+0x113e8] List<Chapter13Stat>(12)
    //     0x46d120: ldr             x2, [x2, #0x3e8]
    // 0x46d124: ldr             x3, [SP]
    // 0x46d128: r4 = LoadInt32Instr(r3)
    //     0x46d128: sbfx            x4, x3, #1, #0x1f
    //     0x46d12c: tbz             w3, #0, #0x46d134
    //     0x46d130: ldur            x4, [x3, #7]
    // 0x46d134: mov             x1, x4
    // 0x46d138: r0 = 12
    //     0x46d138: movz            x0, #0xc
    // 0x46d13c: cmp             x1, x0
    // 0x46d140: b.hs            #0x46d154
    // 0x46d144: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46d144: add             x16, x2, x4, lsl #2
    //     0x46d148: ldur            w0, [x16, #0xf]
    // 0x46d14c: DecompressPointer r0
    //     0x46d14c: add             x0, x0, HEAP, lsl #32
    // 0x46d150: ret
    //     0x46d150: ret             
    // 0x46d154: EnterFrame
    //     0x46d154: stp             fp, lr, [SP, #-0x10]!
    //     0x46d158: mov             fp, SP
    // 0x46d15c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46d15c: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toMapFile(/* No info */) {
    // ** addr: 0x4e2fd0, size: 0x128
    // 0x4e2fd0: EnterFrame
    //     0x4e2fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x4e2fd4: mov             fp, SP
    // 0x4e2fd8: AllocStack(0x28)
    //     0x4e2fd8: sub             SP, SP, #0x28
    // 0x4e2fdc: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */, {dynamic zeroOutIdleTime = false /* r1 */})
    //     0x4e2fdc: mov             x0, x1
    //     0x4e2fe0: stur            x1, [fp, #-8]
    //     0x4e2fe4: ldur            w1, [x4, #0x13]
    //     0x4e2fe8: ldur            w2, [x4, #0x1f]
    //     0x4e2fec: add             x2, x2, HEAP, lsl #32
    //     0x4e2ff0: add             x16, PP, #0x14, lsl #12  ; [pp+0x143e8] "zeroOutIdleTime"
    //     0x4e2ff4: ldr             x16, [x16, #0x3e8]
    //     0x4e2ff8: cmp             w2, w16
    //     0x4e2ffc: b.ne            #0x4e3018
    //     0x4e3000: ldur            w2, [x4, #0x23]
    //     0x4e3004: add             x2, x2, HEAP, lsl #32
    //     0x4e3008: sub             w3, w1, w2
    //     0x4e300c: add             x1, fp, w3, sxtw #2
    //     0x4e3010: ldr             x1, [x1, #8]
    //     0x4e3014: b               #0x4e301c
    //     0x4e3018: add             x1, NULL, #0x30  ; false
    // 0x4e301c: CheckStackOverflow
    //     0x4e301c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e3020: cmp             SP, x16
    //     0x4e3024: b.ls            #0x4e30f0
    // 0x4e3028: str             x1, [SP]
    // 0x4e302c: mov             x1, x0
    // 0x4e3030: r4 = const [0, 0x2, 0x1, 0x1, zeroOutIdleTime, 0x1, null]
    //     0x4e3030: add             x4, PP, #0xe, lsl #12  ; [pp+0xeb78] List(7) [0, 0x2, 0x1, 0x1, "zeroOutIdleTime", 0x1, Null]
    //     0x4e3034: ldr             x4, [x4, #0xb78]
    // 0x4e3038: r0 = toMapFile()
    //     0x4e3038: bl              #0x4e365c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::toMapFile
    // 0x4e303c: r1 = Null
    //     0x4e303c: mov             x1, NULL
    // 0x4e3040: r2 = 8
    //     0x4e3040: movz            x2, #0x8
    // 0x4e3044: stur            x0, [fp, #-0x10]
    // 0x4e3048: r0 = AllocateArray()
    //     0x4e3048: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e304c: mov             x3, x0
    // 0x4e3050: stur            x3, [fp, #-0x18]
    // 0x4e3054: StoreField: r3->field_f = rZR
    //     0x4e3054: stur            wzr, [x3, #0xf]
    // 0x4e3058: ldur            x2, [fp, #-8]
    // 0x4e305c: LoadField: r4 = r2->field_8b
    //     0x4e305c: ldur            x4, [x2, #0x8b]
    // 0x4e3060: r0 = BoxInt64Instr(r4)
    //     0x4e3060: sbfiz           x0, x4, #1, #0x1f
    //     0x4e3064: cmp             x4, x0, asr #1
    //     0x4e3068: b.eq            #0x4e3074
    //     0x4e306c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e3070: stur            x4, [x0, #7]
    // 0x4e3074: StoreField: r3->field_13 = r0
    //     0x4e3074: stur            w0, [x3, #0x13]
    // 0x4e3078: r16 = 2
    //     0x4e3078: movz            x16, #0x2
    // 0x4e307c: ArrayStore: r3[0] = r16  ; List_4
    //     0x4e307c: stur            w16, [x3, #0x17]
    // 0x4e3080: LoadField: r0 = r2->field_9b
    //     0x4e3080: ldur            w0, [x2, #0x9b]
    // 0x4e3084: DecompressPointer r0
    //     0x4e3084: add             x0, x0, HEAP, lsl #32
    // 0x4e3088: mov             x2, x0
    // 0x4e308c: r1 = <int>
    //     0x4e308c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3090: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3090: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3094: ldur            x1, [fp, #-0x18]
    // 0x4e3098: ArrayStore: r1[3] = r0  ; List_4
    //     0x4e3098: add             x25, x1, #0x1b
    //     0x4e309c: str             w0, [x25]
    //     0x4e30a0: tbz             w0, #0, #0x4e30bc
    //     0x4e30a4: ldurb           w16, [x1, #-1]
    //     0x4e30a8: ldurb           w17, [x0, #-1]
    //     0x4e30ac: and             x16, x17, x16, lsr #2
    //     0x4e30b0: tst             x16, HEAP, lsr #32
    //     0x4e30b4: b.eq            #0x4e30bc
    //     0x4e30b8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e30bc: r16 = <int, dynamic>
    //     0x4e30bc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x4e30c0: ldr             x16, [x16, #0x4f0]
    // 0x4e30c4: ldur            lr, [fp, #-0x18]
    // 0x4e30c8: stp             lr, x16, [SP]
    // 0x4e30cc: r0 = Map._fromLiteral()
    //     0x4e30cc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e30d0: ldur            x1, [fp, #-0x10]
    // 0x4e30d4: mov             x3, x0
    // 0x4e30d8: r2 = 38
    //     0x4e30d8: movz            x2, #0x26
    // 0x4e30dc: r0 = []=()
    //     0x4e30dc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4e30e0: ldur            x0, [fp, #-0x10]
    // 0x4e30e4: LeaveFrame
    //     0x4e30e4: mov             SP, fp
    //     0x4e30e8: ldp             fp, lr, [SP], #0x10
    // 0x4e30ec: ret
    //     0x4e30ec: ret             
    // 0x4e30f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e30f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e30f4: b               #0x4e3028
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e6d88, size: 0x78
    // 0x4e6d88: EnterFrame
    //     0x4e6d88: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6d8c: mov             fp, SP
    // 0x4e6d90: AllocStack(0x18)
    //     0x4e6d90: sub             SP, SP, #0x18
    // 0x4e6d94: SetupParameters(Chapter13GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e6d94: stur            x1, [fp, #-8]
    // 0x4e6d98: r1 = 1
    //     0x4e6d98: movz            x1, #0x1
    // 0x4e6d9c: r0 = AllocateContext()
    //     0x4e6d9c: bl              #0x82637c  ; AllocateContextStub
    // 0x4e6da0: mov             x3, x0
    // 0x4e6da4: ldur            x0, [fp, #-8]
    // 0x4e6da8: stur            x3, [fp, #-0x10]
    // 0x4e6dac: StoreField: r3->field_f = r0
    //     0x4e6dac: stur            w0, [x3, #0xf]
    // 0x4e6db0: mov             x2, x3
    // 0x4e6db4: r1 = Function '<anonymous closure>':.
    //     0x4e6db4: add             x1, PP, #0x25, lsl #12  ; [pp+0x25750] AnonymousClosure: (0x4e6f00), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::makeHeader (0x4e6d88)
    //     0x4e6db8: ldr             x1, [x1, #0x750]
    // 0x4e6dbc: r0 = AllocateClosure()
    //     0x4e6dbc: bl              #0x826750  ; AllocateClosureStub
    // 0x4e6dc0: stur            x0, [fp, #-8]
    // 0x4e6dc4: r0 = MainStatDisplay()
    //     0x4e6dc4: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e6dc8: mov             x3, x0
    // 0x4e6dcc: ldur            x0, [fp, #-8]
    // 0x4e6dd0: stur            x3, [fp, #-0x18]
    // 0x4e6dd4: StoreField: r3->field_b = r0
    //     0x4e6dd4: stur            w0, [x3, #0xb]
    // 0x4e6dd8: ldur            x2, [fp, #-0x10]
    // 0x4e6ddc: r1 = Function '<anonymous closure>':.
    //     0x4e6ddc: add             x1, PP, #0x25, lsl #12  ; [pp+0x25758] AnonymousClosure: (0x4e6e00), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::makeHeader (0x4e6d88)
    //     0x4e6de0: ldr             x1, [x1, #0x758]
    // 0x4e6de4: r0 = AllocateClosure()
    //     0x4e6de4: bl              #0x826750  ; AllocateClosureStub
    // 0x4e6de8: mov             x1, x0
    // 0x4e6dec: ldur            x0, [fp, #-0x18]
    // 0x4e6df0: StoreField: r0->field_f = r1
    //     0x4e6df0: stur            w1, [x0, #0xf]
    // 0x4e6df4: LeaveFrame
    //     0x4e6df4: mov             SP, fp
    //     0x4e6df8: ldp             fp, lr, [SP], #0x10
    // 0x4e6dfc: ret
    //     0x4e6dfc: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e6e00, size: 0x100
    // 0x4e6e00: EnterFrame
    //     0x4e6e00: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6e04: mov             fp, SP
    // 0x4e6e08: AllocStack(0x18)
    //     0x4e6e08: sub             SP, SP, #0x18
    // 0x4e6e0c: SetupParameters([dynamic _ /* r0 */])
    //     0x4e6e0c: ldr             x0, [fp, #0x10]
    //     0x4e6e10: ldur            w1, [x0, #0x17]
    //     0x4e6e14: add             x1, x1, HEAP, lsl #32
    // 0x4e6e18: CheckStackOverflow
    //     0x4e6e18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e6e1c: cmp             SP, x16
    //     0x4e6e20: b.ls            #0x4e6ef8
    // 0x4e6e24: LoadField: r0 = r1->field_f
    //     0x4e6e24: ldur            w0, [x1, #0xf]
    // 0x4e6e28: DecompressPointer r0
    //     0x4e6e28: add             x0, x0, HEAP, lsl #32
    // 0x4e6e2c: LoadField: r3 = r0->field_57
    //     0x4e6e2c: ldur            w3, [x0, #0x57]
    // 0x4e6e30: DecompressPointer r3
    //     0x4e6e30: add             x3, x3, HEAP, lsl #32
    // 0x4e6e34: mov             x1, x3
    // 0x4e6e38: stur            x3, [fp, #-8]
    // 0x4e6e3c: r2 = Instance_Chapter13Stat
    //     0x4e6e3c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x4e6e40: ldr             x2, [x2, #0x298]
    // 0x4e6e44: r0 = _getValueOrData()
    //     0x4e6e44: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e6e48: mov             x1, x0
    // 0x4e6e4c: ldur            x0, [fp, #-8]
    // 0x4e6e50: LoadField: r2 = r0->field_f
    //     0x4e6e50: ldur            w2, [x0, #0xf]
    // 0x4e6e54: DecompressPointer r2
    //     0x4e6e54: add             x2, x2, HEAP, lsl #32
    // 0x4e6e58: cmp             w2, w1
    // 0x4e6e5c: b.ne            #0x4e6e68
    // 0x4e6e60: r0 = Null
    //     0x4e6e60: mov             x0, NULL
    // 0x4e6e64: b               #0x4e6e6c
    // 0x4e6e68: mov             x0, x1
    // 0x4e6e6c: stur            x0, [fp, #-8]
    // 0x4e6e70: cmp             w0, NULL
    // 0x4e6e74: b.eq            #0x4e6ee8
    // 0x4e6e78: r1 = Null
    //     0x4e6e78: mov             x1, NULL
    // 0x4e6e7c: r2 = 6
    //     0x4e6e7c: movz            x2, #0x6
    // 0x4e6e80: r0 = AllocateArray()
    //     0x4e6e80: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e6e84: stur            x0, [fp, #-0x10]
    // 0x4e6e88: r16 = "("
    //     0x4e6e88: ldr             x16, [PP, #0x2218]  ; [pp+0x2218] "("
    // 0x4e6e8c: StoreField: r0->field_f = r16
    //     0x4e6e8c: stur            w16, [x0, #0xf]
    // 0x4e6e90: ldur            x1, [fp, #-8]
    // 0x4e6e94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e6e94: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e6e98: r0 = toStringConsistentDecimalPlaces()
    //     0x4e6e98: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e6e9c: ldur            x1, [fp, #-0x10]
    // 0x4e6ea0: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e6ea0: add             x25, x1, #0x13
    //     0x4e6ea4: str             w0, [x25]
    //     0x4e6ea8: tbz             w0, #0, #0x4e6ec4
    //     0x4e6eac: ldurb           w16, [x1, #-1]
    //     0x4e6eb0: ldurb           w17, [x0, #-1]
    //     0x4e6eb4: and             x16, x17, x16, lsr #2
    //     0x4e6eb8: tst             x16, HEAP, lsr #32
    //     0x4e6ebc: b.eq            #0x4e6ec4
    //     0x4e6ec0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6ec4: ldur            x0, [fp, #-0x10]
    // 0x4e6ec8: r16 = "/s)"
    //     0x4e6ec8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a568] "/s)"
    //     0x4e6ecc: ldr             x16, [x16, #0x568]
    // 0x4e6ed0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4e6ed0: stur            w16, [x0, #0x17]
    // 0x4e6ed4: str             x0, [SP]
    // 0x4e6ed8: r0 = _interpolate()
    //     0x4e6ed8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e6edc: LeaveFrame
    //     0x4e6edc: mov             SP, fp
    //     0x4e6ee0: ldp             fp, lr, [SP], #0x10
    // 0x4e6ee4: ret
    //     0x4e6ee4: ret             
    // 0x4e6ee8: r0 = ""
    //     0x4e6ee8: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x4e6eec: LeaveFrame
    //     0x4e6eec: mov             SP, fp
    //     0x4e6ef0: ldp             fp, lr, [SP], #0x10
    // 0x4e6ef4: ret
    //     0x4e6ef4: ret             
    // 0x4e6ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6ef8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e6efc: b               #0x4e6e24
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e6f00, size: 0xf4
    // 0x4e6f00: EnterFrame
    //     0x4e6f00: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6f04: mov             fp, SP
    // 0x4e6f08: AllocStack(0x18)
    //     0x4e6f08: sub             SP, SP, #0x18
    // 0x4e6f0c: SetupParameters([dynamic _ /* r0 */])
    //     0x4e6f0c: ldr             x0, [fp, #0x10]
    //     0x4e6f10: ldur            w3, [x0, #0x17]
    //     0x4e6f14: add             x3, x3, HEAP, lsl #32
    //     0x4e6f18: stur            x3, [fp, #-8]
    // 0x4e6f1c: CheckStackOverflow
    //     0x4e6f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e6f20: cmp             SP, x16
    //     0x4e6f24: b.ls            #0x4e6fec
    // 0x4e6f28: r1 = Null
    //     0x4e6f28: mov             x1, NULL
    // 0x4e6f2c: r2 = 4
    //     0x4e6f2c: movz            x2, #0x4
    // 0x4e6f30: r0 = AllocateArray()
    //     0x4e6f30: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e6f34: stur            x0, [fp, #-0x10]
    // 0x4e6f38: r16 = "Power: "
    //     0x4e6f38: add             x16, PP, #0x25, lsl #12  ; [pp+0x25760] "Power: "
    //     0x4e6f3c: ldr             x16, [x16, #0x760]
    // 0x4e6f40: StoreField: r0->field_f = r16
    //     0x4e6f40: stur            w16, [x0, #0xf]
    // 0x4e6f44: ldur            x1, [fp, #-8]
    // 0x4e6f48: LoadField: r2 = r1->field_f
    //     0x4e6f48: ldur            w2, [x1, #0xf]
    // 0x4e6f4c: DecompressPointer r2
    //     0x4e6f4c: add             x2, x2, HEAP, lsl #32
    // 0x4e6f50: LoadField: r3 = r2->field_37
    //     0x4e6f50: ldur            w3, [x2, #0x37]
    // 0x4e6f54: DecompressPointer r3
    //     0x4e6f54: add             x3, x3, HEAP, lsl #32
    // 0x4e6f58: mov             x1, x3
    // 0x4e6f5c: stur            x3, [fp, #-8]
    // 0x4e6f60: r2 = Instance_Chapter13Stat
    //     0x4e6f60: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x4e6f64: ldr             x2, [x2, #0x298]
    // 0x4e6f68: r0 = _getValueOrData()
    //     0x4e6f68: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e6f6c: mov             x1, x0
    // 0x4e6f70: ldur            x0, [fp, #-8]
    // 0x4e6f74: LoadField: r2 = r0->field_f
    //     0x4e6f74: ldur            w2, [x0, #0xf]
    // 0x4e6f78: DecompressPointer r2
    //     0x4e6f78: add             x2, x2, HEAP, lsl #32
    // 0x4e6f7c: cmp             w2, w1
    // 0x4e6f80: b.ne            #0x4e6f88
    // 0x4e6f84: r1 = Null
    //     0x4e6f84: mov             x1, NULL
    // 0x4e6f88: cmp             w1, NULL
    // 0x4e6f8c: b.ne            #0x4e6f98
    // 0x4e6f90: r0 = Null
    //     0x4e6f90: mov             x0, NULL
    // 0x4e6f94: b               #0x4e6fa0
    // 0x4e6f98: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e6f98: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e6f9c: r0 = toStringConsistentDecimalPlaces()
    //     0x4e6f9c: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e6fa0: cmp             w0, NULL
    // 0x4e6fa4: b.ne            #0x4e6fac
    // 0x4e6fa8: r0 = 0
    //     0x4e6fa8: movz            x0, #0
    // 0x4e6fac: ldur            x1, [fp, #-0x10]
    // 0x4e6fb0: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e6fb0: add             x25, x1, #0x13
    //     0x4e6fb4: str             w0, [x25]
    //     0x4e6fb8: tbz             w0, #0, #0x4e6fd4
    //     0x4e6fbc: ldurb           w16, [x1, #-1]
    //     0x4e6fc0: ldurb           w17, [x0, #-1]
    //     0x4e6fc4: and             x16, x17, x16, lsr #2
    //     0x4e6fc8: tst             x16, HEAP, lsr #32
    //     0x4e6fcc: b.eq            #0x4e6fd4
    //     0x4e6fd0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6fd4: ldur            x16, [fp, #-0x10]
    // 0x4e6fd8: str             x16, [SP]
    // 0x4e6fdc: r0 = _interpolate()
    //     0x4e6fdc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e6fe0: LeaveFrame
    //     0x4e6fe0: mov             SP, fp
    //     0x4e6fe4: ldp             fp, lr, [SP], #0x10
    // 0x4e6fe8: ret
    //     0x4e6fe8: ret             
    // 0x4e6fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6fec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e6ff0: b               #0x4e6f28
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4f60e8, size: 0x44
    // 0x4f60e8: EnterFrame
    //     0x4f60e8: stp             fp, lr, [SP, #-0x10]!
    //     0x4f60ec: mov             fp, SP
    // 0x4f60f0: AllocStack(0x8)
    //     0x4f60f0: sub             SP, SP, #8
    // 0x4f60f4: CheckStackOverflow
    //     0x4f60f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f60f8: cmp             SP, x16
    //     0x4f60fc: b.ls            #0x4f6124
    // 0x4f6100: r16 = <ChapterViewportState>
    //     0x4f6100: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9e0] TypeArguments: <ChapterViewportState>
    //     0x4f6104: ldr             x16, [x16, #0x9e0]
    // 0x4f6108: str             x16, [SP]
    // 0x4f610c: r4 = const [0x1, 0, 0, 0, null]
    //     0x4f610c: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x4f6110: r0 = updateAll()
    //     0x4f6110: bl              #0x4589c0  ; [package:state_groups/src/sync_state.dart] ::updateAll
    // 0x4f6114: r0 = Null
    //     0x4f6114: mov             x0, NULL
    // 0x4f6118: LeaveFrame
    //     0x4f6118: mov             SP, fp
    //     0x4f611c: ldp             fp, lr, [SP], #0x10
    // 0x4f6120: ret
    //     0x4f6120: ret             
    // 0x4f6124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f6124: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f6128: b               #0x4f6100
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4f6138, size: 0x48
    // 0x4f6138: EnterFrame
    //     0x4f6138: stp             fp, lr, [SP, #-0x10]!
    //     0x4f613c: mov             fp, SP
    // 0x4f6140: ldr             x0, [fp, #0x10]
    // 0x4f6144: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x4f6144: ldur            w1, [x0, #0x17]
    // 0x4f6148: DecompressPointer r1
    //     0x4f6148: add             x1, x1, HEAP, lsl #32
    // 0x4f614c: CheckStackOverflow
    //     0x4f614c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f6150: cmp             SP, x16
    //     0x4f6154: b.ls            #0x4f6178
    // 0x4f6158: LoadField: r0 = r1->field_f
    //     0x4f6158: ldur            w0, [x1, #0xf]
    // 0x4f615c: DecompressPointer r0
    //     0x4f615c: add             x0, x0, HEAP, lsl #32
    // 0x4f6160: mov             x1, x0
    // 0x4f6164: r0 = resetAndRecomputeBoosts()
    //     0x4f6164: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x4f6168: r0 = Null
    //     0x4f6168: mov             x0, NULL
    // 0x4f616c: LeaveFrame
    //     0x4f616c: mov             SP, fp
    //     0x4f6170: ldp             fp, lr, [SP], #0x10
    // 0x4f6174: ret
    //     0x4f6174: ret             
    // 0x4f6178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f6178: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f617c: b               #0x4f6158
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4fa448, size: 0x874
    // 0x4fa448: EnterFrame
    //     0x4fa448: stp             fp, lr, [SP, #-0x10]!
    //     0x4fa44c: mov             fp, SP
    // 0x4fa450: AllocStack(0x28)
    //     0x4fa450: sub             SP, SP, #0x28
    // 0x4fa454: SetupParameters(Chapter13GameState this /* r1 => r1, fp-0x8 */)
    //     0x4fa454: stur            x1, [fp, #-8]
    // 0x4fa458: CheckStackOverflow
    //     0x4fa458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fa45c: cmp             SP, x16
    //     0x4fa460: b.ls            #0x4facb4
    // 0x4fa464: r1 = 1
    //     0x4fa464: movz            x1, #0x1
    // 0x4fa468: r0 = AllocateContext()
    //     0x4fa468: bl              #0x82637c  ; AllocateContextStub
    // 0x4fa46c: mov             x3, x0
    // 0x4fa470: ldur            x0, [fp, #-8]
    // 0x4fa474: stur            x3, [fp, #-0x10]
    // 0x4fa478: StoreField: r3->field_f = r0
    //     0x4fa478: stur            w0, [x3, #0xf]
    // 0x4fa47c: r1 = <CustomNum>
    //     0x4fa47c: add             x1, PP, #0x15, lsl #12  ; [pp+0x158f8] TypeArguments: <CustomNum>
    //     0x4fa480: ldr             x1, [x1, #0x8f8]
    // 0x4fa484: r2 = 24
    //     0x4fa484: movz            x2, #0x18
    // 0x4fa488: r0 = AllocateArray()
    //     0x4fa488: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fa48c: stur            x0, [fp, #-0x18]
    // 0x4fa490: r16 = Instance_CustomNum
    //     0x4fa490: add             x16, PP, #0x15, lsl #12  ; [pp+0x15900] Obj!CustomNum@829d41
    //     0x4fa494: ldr             x16, [x16, #0x900]
    // 0x4fa498: StoreField: r0->field_f = r16
    //     0x4fa498: stur            w16, [x0, #0xf]
    // 0x4fa49c: r16 = Instance_CustomNum
    //     0x4fa49c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15908] Obj!CustomNum@829d31
    //     0x4fa4a0: ldr             x16, [x16, #0x908]
    // 0x4fa4a4: StoreField: r0->field_13 = r16
    //     0x4fa4a4: stur            w16, [x0, #0x13]
    // 0x4fa4a8: r16 = Instance_CustomNum
    //     0x4fa4a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15910] Obj!CustomNum@829d21
    //     0x4fa4ac: ldr             x16, [x16, #0x910]
    // 0x4fa4b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fa4b0: stur            w16, [x0, #0x17]
    // 0x4fa4b4: r16 = Instance_CustomNum
    //     0x4fa4b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15918] Obj!CustomNum@829d11
    //     0x4fa4b8: ldr             x16, [x16, #0x918]
    // 0x4fa4bc: StoreField: r0->field_1b = r16
    //     0x4fa4bc: stur            w16, [x0, #0x1b]
    // 0x4fa4c0: r16 = Instance_CustomNum
    //     0x4fa4c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15920] Obj!CustomNum@829d01
    //     0x4fa4c4: ldr             x16, [x16, #0x920]
    // 0x4fa4c8: StoreField: r0->field_1f = r16
    //     0x4fa4c8: stur            w16, [x0, #0x1f]
    // 0x4fa4cc: r16 = Instance_CustomNum
    //     0x4fa4cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15928] Obj!CustomNum@829cf1
    //     0x4fa4d0: ldr             x16, [x16, #0x928]
    // 0x4fa4d4: StoreField: r0->field_23 = r16
    //     0x4fa4d4: stur            w16, [x0, #0x23]
    // 0x4fa4d8: r16 = Instance_CustomNum
    //     0x4fa4d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15930] Obj!CustomNum@829ce1
    //     0x4fa4dc: ldr             x16, [x16, #0x930]
    // 0x4fa4e0: StoreField: r0->field_27 = r16
    //     0x4fa4e0: stur            w16, [x0, #0x27]
    // 0x4fa4e4: r16 = Instance_CustomNum
    //     0x4fa4e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15938] Obj!CustomNum@829cd1
    //     0x4fa4e8: ldr             x16, [x16, #0x938]
    // 0x4fa4ec: StoreField: r0->field_2b = r16
    //     0x4fa4ec: stur            w16, [x0, #0x2b]
    // 0x4fa4f0: r16 = Instance_CustomNum
    //     0x4fa4f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15940] Obj!CustomNum@829cc1
    //     0x4fa4f4: ldr             x16, [x16, #0x940]
    // 0x4fa4f8: StoreField: r0->field_2f = r16
    //     0x4fa4f8: stur            w16, [x0, #0x2f]
    // 0x4fa4fc: r16 = Instance_CustomNum
    //     0x4fa4fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15948] Obj!CustomNum@829cb1
    //     0x4fa500: ldr             x16, [x16, #0x948]
    // 0x4fa504: StoreField: r0->field_33 = r16
    //     0x4fa504: stur            w16, [x0, #0x33]
    // 0x4fa508: r16 = Instance_CustomNum
    //     0x4fa508: add             x16, PP, #0x15, lsl #12  ; [pp+0x15950] Obj!CustomNum@829ca1
    //     0x4fa50c: ldr             x16, [x16, #0x950]
    // 0x4fa510: StoreField: r0->field_37 = r16
    //     0x4fa510: stur            w16, [x0, #0x37]
    // 0x4fa514: r16 = Instance_CustomNum
    //     0x4fa514: add             x16, PP, #0x15, lsl #12  ; [pp+0x15958] Obj!CustomNum@829c91
    //     0x4fa518: ldr             x16, [x16, #0x958]
    // 0x4fa51c: StoreField: r0->field_3b = r16
    //     0x4fa51c: stur            w16, [x0, #0x3b]
    // 0x4fa520: r1 = <CustomNum>
    //     0x4fa520: add             x1, PP, #0x15, lsl #12  ; [pp+0x158f8] TypeArguments: <CustomNum>
    //     0x4fa524: ldr             x1, [x1, #0x8f8]
    // 0x4fa528: r0 = AllocateGrowableArray()
    //     0x4fa528: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fa52c: mov             x1, x0
    // 0x4fa530: ldur            x0, [fp, #-0x18]
    // 0x4fa534: StoreField: r1->field_f = r0
    //     0x4fa534: stur            w0, [x1, #0xf]
    // 0x4fa538: r0 = 24
    //     0x4fa538: movz            x0, #0x18
    // 0x4fa53c: StoreField: r1->field_b = r0
    //     0x4fa53c: stur            w0, [x1, #0xb]
    // 0x4fa540: mov             x0, x1
    // 0x4fa544: ldur            x3, [fp, #-8]
    // 0x4fa548: StoreField: r3->field_9f = r0
    //     0x4fa548: stur            w0, [x3, #0x9f]
    //     0x4fa54c: ldurb           w16, [x3, #-1]
    //     0x4fa550: ldurb           w17, [x0, #-1]
    //     0x4fa554: and             x16, x17, x16, lsr #2
    //     0x4fa558: tst             x16, HEAP, lsr #32
    //     0x4fa55c: b.eq            #0x4fa564
    //     0x4fa560: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4fa564: r1 = Null
    //     0x4fa564: mov             x1, NULL
    // 0x4fa568: r2 = 108
    //     0x4fa568: movz            x2, #0x6c
    // 0x4fa56c: r0 = AllocateArray()
    //     0x4fa56c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fa570: r16 = 2
    //     0x4fa570: movz            x16, #0x2
    // 0x4fa574: StoreField: r0->field_f = r16
    //     0x4fa574: stur            w16, [x0, #0xf]
    // 0x4fa578: r16 = Instance_GeneratorInfo
    //     0x4fa578: add             x16, PP, #0x15, lsl #12  ; [pp+0x15960] Obj!GeneratorInfo<Chapter13Stat>@82d711
    //     0x4fa57c: ldr             x16, [x16, #0x960]
    // 0x4fa580: StoreField: r0->field_13 = r16
    //     0x4fa580: stur            w16, [x0, #0x13]
    // 0x4fa584: r16 = 4
    //     0x4fa584: movz            x16, #0x4
    // 0x4fa588: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fa588: stur            w16, [x0, #0x17]
    // 0x4fa58c: r16 = Instance_GeneratorInfo
    //     0x4fa58c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15968] Obj!GeneratorInfo<Chapter13Stat>@82d6d1
    //     0x4fa590: ldr             x16, [x16, #0x968]
    // 0x4fa594: StoreField: r0->field_1b = r16
    //     0x4fa594: stur            w16, [x0, #0x1b]
    // 0x4fa598: r16 = 6
    //     0x4fa598: movz            x16, #0x6
    // 0x4fa59c: StoreField: r0->field_1f = r16
    //     0x4fa59c: stur            w16, [x0, #0x1f]
    // 0x4fa5a0: r16 = Instance_GeneratorInfo
    //     0x4fa5a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15970] Obj!GeneratorInfo<Chapter13Stat>@82d691
    //     0x4fa5a4: ldr             x16, [x16, #0x970]
    // 0x4fa5a8: StoreField: r0->field_23 = r16
    //     0x4fa5a8: stur            w16, [x0, #0x23]
    // 0x4fa5ac: r16 = 22
    //     0x4fa5ac: movz            x16, #0x16
    // 0x4fa5b0: StoreField: r0->field_27 = r16
    //     0x4fa5b0: stur            w16, [x0, #0x27]
    // 0x4fa5b4: r16 = Instance_GeneratorInfo
    //     0x4fa5b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15978] Obj!GeneratorInfo<Chapter13Stat>@82d651
    //     0x4fa5b8: ldr             x16, [x16, #0x978]
    // 0x4fa5bc: StoreField: r0->field_2b = r16
    //     0x4fa5bc: stur            w16, [x0, #0x2b]
    // 0x4fa5c0: r16 = 24
    //     0x4fa5c0: movz            x16, #0x18
    // 0x4fa5c4: StoreField: r0->field_2f = r16
    //     0x4fa5c4: stur            w16, [x0, #0x2f]
    // 0x4fa5c8: r16 = Instance_GeneratorInfo
    //     0x4fa5c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15980] Obj!GeneratorInfo<Chapter13Stat>@82d611
    //     0x4fa5cc: ldr             x16, [x16, #0x980]
    // 0x4fa5d0: StoreField: r0->field_33 = r16
    //     0x4fa5d0: stur            w16, [x0, #0x33]
    // 0x4fa5d4: r16 = 26
    //     0x4fa5d4: movz            x16, #0x1a
    // 0x4fa5d8: StoreField: r0->field_37 = r16
    //     0x4fa5d8: stur            w16, [x0, #0x37]
    // 0x4fa5dc: r16 = Instance_GeneratorInfo
    //     0x4fa5dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15988] Obj!GeneratorInfo<Chapter13Stat>@82d5d1
    //     0x4fa5e0: ldr             x16, [x16, #0x988]
    // 0x4fa5e4: StoreField: r0->field_3b = r16
    //     0x4fa5e4: stur            w16, [x0, #0x3b]
    // 0x4fa5e8: r16 = 42
    //     0x4fa5e8: movz            x16, #0x2a
    // 0x4fa5ec: StoreField: r0->field_3f = r16
    //     0x4fa5ec: stur            w16, [x0, #0x3f]
    // 0x4fa5f0: r16 = Instance_GeneratorInfo
    //     0x4fa5f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15990] Obj!GeneratorInfo<Chapter13Stat>@82d591
    //     0x4fa5f4: ldr             x16, [x16, #0x990]
    // 0x4fa5f8: StoreField: r0->field_43 = r16
    //     0x4fa5f8: stur            w16, [x0, #0x43]
    // 0x4fa5fc: r16 = 44
    //     0x4fa5fc: movz            x16, #0x2c
    // 0x4fa600: StoreField: r0->field_47 = r16
    //     0x4fa600: stur            w16, [x0, #0x47]
    // 0x4fa604: r16 = Instance_GeneratorInfo
    //     0x4fa604: add             x16, PP, #0x15, lsl #12  ; [pp+0x15998] Obj!GeneratorInfo<Chapter13Stat>@82d551
    //     0x4fa608: ldr             x16, [x16, #0x998]
    // 0x4fa60c: StoreField: r0->field_4b = r16
    //     0x4fa60c: stur            w16, [x0, #0x4b]
    // 0x4fa610: r16 = 46
    //     0x4fa610: movz            x16, #0x2e
    // 0x4fa614: StoreField: r0->field_4f = r16
    //     0x4fa614: stur            w16, [x0, #0x4f]
    // 0x4fa618: r16 = Instance_GeneratorInfo
    //     0x4fa618: add             x16, PP, #0x15, lsl #12  ; [pp+0x159a0] Obj!GeneratorInfo<Chapter13Stat>@82d511
    //     0x4fa61c: ldr             x16, [x16, #0x9a0]
    // 0x4fa620: StoreField: r0->field_53 = r16
    //     0x4fa620: stur            w16, [x0, #0x53]
    // 0x4fa624: r16 = 62
    //     0x4fa624: movz            x16, #0x3e
    // 0x4fa628: StoreField: r0->field_57 = r16
    //     0x4fa628: stur            w16, [x0, #0x57]
    // 0x4fa62c: r16 = Instance_GeneratorInfo
    //     0x4fa62c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159a8] Obj!GeneratorInfo<Chapter13Stat>@82d4d1
    //     0x4fa630: ldr             x16, [x16, #0x9a8]
    // 0x4fa634: StoreField: r0->field_5b = r16
    //     0x4fa634: stur            w16, [x0, #0x5b]
    // 0x4fa638: r16 = 64
    //     0x4fa638: movz            x16, #0x40
    // 0x4fa63c: StoreField: r0->field_5f = r16
    //     0x4fa63c: stur            w16, [x0, #0x5f]
    // 0x4fa640: r16 = Instance_GeneratorInfo
    //     0x4fa640: add             x16, PP, #0x15, lsl #12  ; [pp+0x159b0] Obj!GeneratorInfo<Chapter13Stat>@82d491
    //     0x4fa644: ldr             x16, [x16, #0x9b0]
    // 0x4fa648: StoreField: r0->field_63 = r16
    //     0x4fa648: stur            w16, [x0, #0x63]
    // 0x4fa64c: r16 = 66
    //     0x4fa64c: movz            x16, #0x42
    // 0x4fa650: StoreField: r0->field_67 = r16
    //     0x4fa650: stur            w16, [x0, #0x67]
    // 0x4fa654: r16 = Instance_GeneratorInfo
    //     0x4fa654: add             x16, PP, #0x15, lsl #12  ; [pp+0x159b8] Obj!GeneratorInfo<Chapter13Stat>@82d451
    //     0x4fa658: ldr             x16, [x16, #0x9b8]
    // 0x4fa65c: StoreField: r0->field_6b = r16
    //     0x4fa65c: stur            w16, [x0, #0x6b]
    // 0x4fa660: r16 = 82
    //     0x4fa660: movz            x16, #0x52
    // 0x4fa664: StoreField: r0->field_6f = r16
    //     0x4fa664: stur            w16, [x0, #0x6f]
    // 0x4fa668: r16 = Instance_GeneratorInfo
    //     0x4fa668: add             x16, PP, #0x15, lsl #12  ; [pp+0x159c0] Obj!GeneratorInfo<Chapter13Stat>@82d411
    //     0x4fa66c: ldr             x16, [x16, #0x9c0]
    // 0x4fa670: StoreField: r0->field_73 = r16
    //     0x4fa670: stur            w16, [x0, #0x73]
    // 0x4fa674: r16 = 84
    //     0x4fa674: movz            x16, #0x54
    // 0x4fa678: StoreField: r0->field_77 = r16
    //     0x4fa678: stur            w16, [x0, #0x77]
    // 0x4fa67c: r16 = Instance_GeneratorInfo
    //     0x4fa67c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159c8] Obj!GeneratorInfo<Chapter13Stat>@82d3d1
    //     0x4fa680: ldr             x16, [x16, #0x9c8]
    // 0x4fa684: StoreField: r0->field_7b = r16
    //     0x4fa684: stur            w16, [x0, #0x7b]
    // 0x4fa688: r16 = 86
    //     0x4fa688: movz            x16, #0x56
    // 0x4fa68c: StoreField: r0->field_7f = r16
    //     0x4fa68c: stur            w16, [x0, #0x7f]
    // 0x4fa690: r16 = Instance_GeneratorInfo
    //     0x4fa690: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d0] Obj!GeneratorInfo<Chapter13Stat>@82d391
    //     0x4fa694: ldr             x16, [x16, #0x9d0]
    // 0x4fa698: StoreField: r0->field_83 = r16
    //     0x4fa698: stur            w16, [x0, #0x83]
    // 0x4fa69c: r16 = 102
    //     0x4fa69c: movz            x16, #0x66
    // 0x4fa6a0: StoreField: r0->field_87 = r16
    //     0x4fa6a0: stur            w16, [x0, #0x87]
    // 0x4fa6a4: r16 = Instance_GeneratorInfo
    //     0x4fa6a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d8] Obj!GeneratorInfo<Chapter13Stat>@82d351
    //     0x4fa6a8: ldr             x16, [x16, #0x9d8]
    // 0x4fa6ac: StoreField: r0->field_8b = r16
    //     0x4fa6ac: stur            w16, [x0, #0x8b]
    // 0x4fa6b0: r16 = 104
    //     0x4fa6b0: movz            x16, #0x68
    // 0x4fa6b4: StoreField: r0->field_8f = r16
    //     0x4fa6b4: stur            w16, [x0, #0x8f]
    // 0x4fa6b8: r16 = Instance_GeneratorInfo
    //     0x4fa6b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e0] Obj!GeneratorInfo<Chapter13Stat>@82d311
    //     0x4fa6bc: ldr             x16, [x16, #0x9e0]
    // 0x4fa6c0: StoreField: r0->field_93 = r16
    //     0x4fa6c0: stur            w16, [x0, #0x93]
    // 0x4fa6c4: r16 = 106
    //     0x4fa6c4: movz            x16, #0x6a
    // 0x4fa6c8: StoreField: r0->field_97 = r16
    //     0x4fa6c8: stur            w16, [x0, #0x97]
    // 0x4fa6cc: r16 = Instance_GeneratorInfo
    //     0x4fa6cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e8] Obj!GeneratorInfo<Chapter13Stat>@82d2d1
    //     0x4fa6d0: ldr             x16, [x16, #0x9e8]
    // 0x4fa6d4: StoreField: r0->field_9b = r16
    //     0x4fa6d4: stur            w16, [x0, #0x9b]
    // 0x4fa6d8: r16 = 122
    //     0x4fa6d8: movz            x16, #0x7a
    // 0x4fa6dc: StoreField: r0->field_9f = r16
    //     0x4fa6dc: stur            w16, [x0, #0x9f]
    // 0x4fa6e0: r16 = Instance_GeneratorInfo
    //     0x4fa6e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f0] Obj!GeneratorInfo<Chapter13Stat>@82d291
    //     0x4fa6e4: ldr             x16, [x16, #0x9f0]
    // 0x4fa6e8: StoreField: r0->field_a3 = r16
    //     0x4fa6e8: stur            w16, [x0, #0xa3]
    // 0x4fa6ec: r16 = 124
    //     0x4fa6ec: movz            x16, #0x7c
    // 0x4fa6f0: StoreField: r0->field_a7 = r16
    //     0x4fa6f0: stur            w16, [x0, #0xa7]
    // 0x4fa6f4: r16 = Instance_GeneratorInfo
    //     0x4fa6f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f8] Obj!GeneratorInfo<Chapter13Stat>@82d251
    //     0x4fa6f8: ldr             x16, [x16, #0x9f8]
    // 0x4fa6fc: StoreField: r0->field_ab = r16
    //     0x4fa6fc: stur            w16, [x0, #0xab]
    // 0x4fa700: r16 = 126
    //     0x4fa700: movz            x16, #0x7e
    // 0x4fa704: StoreField: r0->field_af = r16
    //     0x4fa704: stur            w16, [x0, #0xaf]
    // 0x4fa708: r16 = Instance_GeneratorInfo
    //     0x4fa708: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a00] Obj!GeneratorInfo<Chapter13Stat>@82d211
    //     0x4fa70c: ldr             x16, [x16, #0xa00]
    // 0x4fa710: StoreField: r0->field_b3 = r16
    //     0x4fa710: stur            w16, [x0, #0xb3]
    // 0x4fa714: r16 = 142
    //     0x4fa714: movz            x16, #0x8e
    // 0x4fa718: StoreField: r0->field_b7 = r16
    //     0x4fa718: stur            w16, [x0, #0xb7]
    // 0x4fa71c: r16 = Instance_GeneratorInfo
    //     0x4fa71c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a08] Obj!GeneratorInfo<Chapter13Stat>@82d1d1
    //     0x4fa720: ldr             x16, [x16, #0xa08]
    // 0x4fa724: StoreField: r0->field_bb = r16
    //     0x4fa724: stur            w16, [x0, #0xbb]
    // 0x4fa728: r16 = 144
    //     0x4fa728: movz            x16, #0x90
    // 0x4fa72c: StoreField: r0->field_bf = r16
    //     0x4fa72c: stur            w16, [x0, #0xbf]
    // 0x4fa730: r16 = Instance_GeneratorInfo
    //     0x4fa730: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a10] Obj!GeneratorInfo<Chapter13Stat>@82d191
    //     0x4fa734: ldr             x16, [x16, #0xa10]
    // 0x4fa738: StoreField: r0->field_c3 = r16
    //     0x4fa738: stur            w16, [x0, #0xc3]
    // 0x4fa73c: r16 = 146
    //     0x4fa73c: movz            x16, #0x92
    // 0x4fa740: StoreField: r0->field_c7 = r16
    //     0x4fa740: stur            w16, [x0, #0xc7]
    // 0x4fa744: r16 = Instance_GeneratorInfo
    //     0x4fa744: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a18] Obj!GeneratorInfo<Chapter13Stat>@82d151
    //     0x4fa748: ldr             x16, [x16, #0xa18]
    // 0x4fa74c: StoreField: r0->field_cb = r16
    //     0x4fa74c: stur            w16, [x0, #0xcb]
    // 0x4fa750: r16 = 162
    //     0x4fa750: movz            x16, #0xa2
    // 0x4fa754: StoreField: r0->field_cf = r16
    //     0x4fa754: stur            w16, [x0, #0xcf]
    // 0x4fa758: r16 = Instance_GeneratorInfo
    //     0x4fa758: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a20] Obj!GeneratorInfo<Chapter13Stat>@82d111
    //     0x4fa75c: ldr             x16, [x16, #0xa20]
    // 0x4fa760: StoreField: r0->field_d3 = r16
    //     0x4fa760: stur            w16, [x0, #0xd3]
    // 0x4fa764: r16 = 164
    //     0x4fa764: movz            x16, #0xa4
    // 0x4fa768: StoreField: r0->field_d7 = r16
    //     0x4fa768: stur            w16, [x0, #0xd7]
    // 0x4fa76c: r16 = Instance_GeneratorInfo
    //     0x4fa76c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] Obj!GeneratorInfo<Chapter13Stat>@82d0d1
    //     0x4fa770: ldr             x16, [x16, #0xa28]
    // 0x4fa774: StoreField: r0->field_db = r16
    //     0x4fa774: stur            w16, [x0, #0xdb]
    // 0x4fa778: r16 = 166
    //     0x4fa778: movz            x16, #0xa6
    // 0x4fa77c: StoreField: r0->field_df = r16
    //     0x4fa77c: stur            w16, [x0, #0xdf]
    // 0x4fa780: r16 = Instance_GeneratorInfo
    //     0x4fa780: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a30] Obj!GeneratorInfo<Chapter13Stat>@82d091
    //     0x4fa784: ldr             x16, [x16, #0xa30]
    // 0x4fa788: StoreField: r0->field_e3 = r16
    //     0x4fa788: stur            w16, [x0, #0xe3]
    // 0x4fa78c: r16 = <int, GeneratorInfo<Chapter13Stat>>
    //     0x4fa78c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a38] TypeArguments: <int, GeneratorInfo<Chapter13Stat>>
    //     0x4fa790: ldr             x16, [x16, #0xa38]
    // 0x4fa794: stp             x0, x16, [SP]
    // 0x4fa798: r0 = Map._fromLiteral()
    //     0x4fa798: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fa79c: ldur            x3, [fp, #-8]
    // 0x4fa7a0: StoreField: r3->field_93 = r0
    //     0x4fa7a0: stur            w0, [x3, #0x93]
    //     0x4fa7a4: ldurb           w16, [x3, #-1]
    //     0x4fa7a8: ldurb           w17, [x0, #-1]
    //     0x4fa7ac: and             x16, x17, x16, lsr #2
    //     0x4fa7b0: tst             x16, HEAP, lsr #32
    //     0x4fa7b4: b.eq            #0x4fa7bc
    //     0x4fa7b8: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4fa7bc: r1 = Null
    //     0x4fa7bc: mov             x1, NULL
    // 0x4fa7c0: r2 = 40
    //     0x4fa7c0: movz            x2, #0x28
    // 0x4fa7c4: r0 = AllocateArray()
    //     0x4fa7c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fa7c8: stur            x0, [fp, #-0x18]
    // 0x4fa7cc: r16 = 20
    //     0x4fa7cc: movz            x16, #0x14
    // 0x4fa7d0: StoreField: r0->field_f = r16
    //     0x4fa7d0: stur            w16, [x0, #0xf]
    // 0x4fa7d4: r1 = Function '<anonymous closure>':.
    //     0x4fa7d4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4fa7d8: ldr             x1, [x1, #0xa40]
    // 0x4fa7dc: r2 = Null
    //     0x4fa7dc: mov             x2, NULL
    // 0x4fa7e0: r0 = AllocateClosure()
    //     0x4fa7e0: bl              #0x826750  ; AllocateClosureStub
    // 0x4fa7e4: str             x0, [SP]
    // 0x4fa7e8: r1 = <Chapter13Stat>
    //     0x4fa7e8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fa7ec: ldr             x1, [x1, #0xf28]
    // 0x4fa7f0: r2 = Instance_Tuple2
    //     0x4fa7f0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!Tuple2<Chapter13Stat, CustomNum>@823891
    //     0x4fa7f4: ldr             x2, [x2, #0xa48]
    // 0x4fa7f8: r3 = "Unlocks Prestige"
    //     0x4fa7f8: add             x3, PP, #0x15, lsl #12  ; [pp+0x15a50] "Unlocks Prestige"
    //     0x4fa7fc: ldr             x3, [x3, #0xa50]
    // 0x4fa800: r5 = Instance_IconData
    //     0x4fa800: add             x5, PP, #0x15, lsl #12  ; [pp+0x15a58] Obj!IconData@82f2f1
    //     0x4fa804: ldr             x5, [x5, #0xa58]
    // 0x4fa808: r6 = "Sprint Planning"
    //     0x4fa808: add             x6, PP, #0x15, lsl #12  ; [pp+0x15a60] "Sprint Planning"
    //     0x4fa80c: ldr             x6, [x6, #0xa60]
    // 0x4fa810: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fa810: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fa814: ldr             x4, [x4, #0xcc0]
    // 0x4fa818: r0 = UpgradeData.single()
    //     0x4fa818: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fa81c: ldur            x1, [fp, #-0x18]
    // 0x4fa820: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fa820: add             x25, x1, #0x13
    //     0x4fa824: str             w0, [x25]
    //     0x4fa828: tbz             w0, #0, #0x4fa844
    //     0x4fa82c: ldurb           w16, [x1, #-1]
    //     0x4fa830: ldurb           w17, [x0, #-1]
    //     0x4fa834: and             x16, x17, x16, lsr #2
    //     0x4fa838: tst             x16, HEAP, lsr #32
    //     0x4fa83c: b.eq            #0x4fa844
    //     0x4fa840: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fa844: ldur            x0, [fp, #-0x18]
    // 0x4fa848: r16 = 40
    //     0x4fa848: movz            x16, #0x28
    // 0x4fa84c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fa84c: stur            w16, [x0, #0x17]
    // 0x4fa850: r1 = Function '<anonymous closure>':.
    //     0x4fa850: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a68] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4fa854: ldr             x1, [x1, #0xa68]
    // 0x4fa858: r2 = Null
    //     0x4fa858: mov             x2, NULL
    // 0x4fa85c: r0 = AllocateClosure()
    //     0x4fa85c: bl              #0x826750  ; AllocateClosureStub
    // 0x4fa860: str             x0, [SP]
    // 0x4fa864: r1 = <Chapter13Stat>
    //     0x4fa864: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fa868: ldr             x1, [x1, #0xf28]
    // 0x4fa86c: r2 = Instance_Tuple2
    //     0x4fa86c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!Tuple2<Chapter13Stat, CustomNum>@823871
    //     0x4fa870: ldr             x2, [x2, #0xa70]
    // 0x4fa874: r3 = "Unlocks autobuyers for first three stats"
    //     0x4fa874: add             x3, PP, #0x15, lsl #12  ; [pp+0x15a78] "Unlocks autobuyers for first three stats"
    //     0x4fa878: ldr             x3, [x3, #0xa78]
    // 0x4fa87c: r5 = Instance_IconData
    //     0x4fa87c: add             x5, PP, #0x15, lsl #12  ; [pp+0x15a80] Obj!IconData@82f2d1
    //     0x4fa880: ldr             x5, [x5, #0xa80]
    // 0x4fa884: r6 = "Core"
    //     0x4fa884: add             x6, PP, #0x15, lsl #12  ; [pp+0x15a88] "Core"
    //     0x4fa888: ldr             x6, [x6, #0xa88]
    // 0x4fa88c: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fa88c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fa890: ldr             x4, [x4, #0xcc0]
    // 0x4fa894: r0 = UpgradeData.single()
    //     0x4fa894: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fa898: ldur            x1, [fp, #-0x18]
    // 0x4fa89c: ArrayStore: r1[3] = r0  ; List_4
    //     0x4fa89c: add             x25, x1, #0x1b
    //     0x4fa8a0: str             w0, [x25]
    //     0x4fa8a4: tbz             w0, #0, #0x4fa8c0
    //     0x4fa8a8: ldurb           w16, [x1, #-1]
    //     0x4fa8ac: ldurb           w17, [x0, #-1]
    //     0x4fa8b0: and             x16, x17, x16, lsr #2
    //     0x4fa8b4: tst             x16, HEAP, lsr #32
    //     0x4fa8b8: b.eq            #0x4fa8c0
    //     0x4fa8bc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fa8c0: ldur            x0, [fp, #-0x18]
    // 0x4fa8c4: r16 = 60
    //     0x4fa8c4: movz            x16, #0x3c
    // 0x4fa8c8: StoreField: r0->field_1f = r16
    //     0x4fa8c8: stur            w16, [x0, #0x1f]
    // 0x4fa8cc: r1 = <Chapter13Stat>
    //     0x4fa8cc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fa8d0: ldr             x1, [x1, #0xf28]
    // 0x4fa8d4: r2 = Instance_Tuple2
    //     0x4fa8d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a90] Obj!Tuple2<Chapter13Stat, CustomNum>@823851
    //     0x4fa8d8: ldr             x2, [x2, #0xa90]
    // 0x4fa8dc: r3 = "Upon completing research get experience as if prestiging"
    //     0x4fa8dc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15a98] "Upon completing research get experience as if prestiging"
    //     0x4fa8e0: ldr             x3, [x3, #0xa98]
    // 0x4fa8e4: r5 = Instance_IconData
    //     0x4fa8e4: add             x5, PP, #0x15, lsl #12  ; [pp+0x15aa0] Obj!IconData@82f2b1
    //     0x4fa8e8: ldr             x5, [x5, #0xaa0]
    // 0x4fa8ec: r6 = "Multitasking"
    //     0x4fa8ec: add             x6, PP, #0x15, lsl #12  ; [pp+0x15aa8] "Multitasking"
    //     0x4fa8f0: ldr             x6, [x6, #0xaa8]
    // 0x4fa8f4: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fa8f4: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fa8f8: r0 = UpgradeData.single()
    //     0x4fa8f8: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fa8fc: ldur            x1, [fp, #-0x18]
    // 0x4fa900: ArrayStore: r1[5] = r0  ; List_4
    //     0x4fa900: add             x25, x1, #0x23
    //     0x4fa904: str             w0, [x25]
    //     0x4fa908: tbz             w0, #0, #0x4fa924
    //     0x4fa90c: ldurb           w16, [x1, #-1]
    //     0x4fa910: ldurb           w17, [x0, #-1]
    //     0x4fa914: and             x16, x17, x16, lsr #2
    //     0x4fa918: tst             x16, HEAP, lsr #32
    //     0x4fa91c: b.eq            #0x4fa924
    //     0x4fa920: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fa924: ldur            x0, [fp, #-0x18]
    // 0x4fa928: r16 = 80
    //     0x4fa928: movz            x16, #0x50
    // 0x4fa92c: StoreField: r0->field_27 = r16
    //     0x4fa92c: stur            w16, [x0, #0x27]
    // 0x4fa930: r1 = <Chapter13Stat>
    //     0x4fa930: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fa934: ldr             x1, [x1, #0xf28]
    // 0x4fa938: r2 = Instance_Tuple2
    //     0x4fa938: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ab0] Obj!Tuple2<Chapter13Stat, CustomNum>@823831
    //     0x4fa93c: ldr             x2, [x2, #0xab0]
    // 0x4fa940: r3 = "After prestiging get 1 of the first 6 stats"
    //     0x4fa940: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ab8] "After prestiging get 1 of the first 6 stats"
    //     0x4fa944: ldr             x3, [x3, #0xab8]
    // 0x4fa948: r5 = Instance_IconData
    //     0x4fa948: add             x5, PP, #0x15, lsl #12  ; [pp+0x15ac0] Obj!IconData@82f291
    //     0x4fa94c: ldr             x5, [x5, #0xac0]
    // 0x4fa950: r6 = "Strong Start"
    //     0x4fa950: add             x6, PP, #0x15, lsl #12  ; [pp+0x15ac8] "Strong Start"
    //     0x4fa954: ldr             x6, [x6, #0xac8]
    // 0x4fa958: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4fa958: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4fa95c: r0 = UpgradeData.single()
    //     0x4fa95c: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fa960: ldur            x1, [fp, #-0x18]
    // 0x4fa964: ArrayStore: r1[7] = r0  ; List_4
    //     0x4fa964: add             x25, x1, #0x2b
    //     0x4fa968: str             w0, [x25]
    //     0x4fa96c: tbz             w0, #0, #0x4fa988
    //     0x4fa970: ldurb           w16, [x1, #-1]
    //     0x4fa974: ldurb           w17, [x0, #-1]
    //     0x4fa978: and             x16, x17, x16, lsr #2
    //     0x4fa97c: tst             x16, HEAP, lsr #32
    //     0x4fa980: b.eq            #0x4fa988
    //     0x4fa984: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fa988: ldur            x0, [fp, #-0x18]
    // 0x4fa98c: r16 = 100
    //     0x4fa98c: movz            x16, #0x64
    // 0x4fa990: StoreField: r0->field_2f = r16
    //     0x4fa990: stur            w16, [x0, #0x2f]
    // 0x4fa994: r1 = Function '<anonymous closure>':.
    //     0x4fa994: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ad0] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4fa998: ldr             x1, [x1, #0xad0]
    // 0x4fa99c: r2 = Null
    //     0x4fa99c: mov             x2, NULL
    // 0x4fa9a0: r0 = AllocateClosure()
    //     0x4fa9a0: bl              #0x826750  ; AllocateClosureStub
    // 0x4fa9a4: str             x0, [SP]
    // 0x4fa9a8: r1 = <Chapter13Stat>
    //     0x4fa9a8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fa9ac: ldr             x1, [x1, #0xf28]
    // 0x4fa9b0: r2 = Instance_Tuple2
    //     0x4fa9b0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ad8] Obj!Tuple2<Chapter13Stat, CustomNum>@823811
    //     0x4fa9b4: ldr             x2, [x2, #0xad8]
    // 0x4fa9b8: r3 = "Unlocks autobuyers for the next three stats"
    //     0x4fa9b8: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ae0] "Unlocks autobuyers for the next three stats"
    //     0x4fa9bc: ldr             x3, [x3, #0xae0]
    // 0x4fa9c0: r5 = Instance_IconData
    //     0x4fa9c0: add             x5, PP, #0x15, lsl #12  ; [pp+0x15ae8] Obj!IconData@8301f1
    //     0x4fa9c4: ldr             x5, [x5, #0xae8]
    // 0x4fa9c8: r6 = "Grow"
    //     0x4fa9c8: add             x6, PP, #0x15, lsl #12  ; [pp+0x15af0] "Grow"
    //     0x4fa9cc: ldr             x6, [x6, #0xaf0]
    // 0x4fa9d0: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fa9d0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fa9d4: ldr             x4, [x4, #0xcc0]
    // 0x4fa9d8: r0 = UpgradeData.single()
    //     0x4fa9d8: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fa9dc: ldur            x1, [fp, #-0x18]
    // 0x4fa9e0: ArrayStore: r1[9] = r0  ; List_4
    //     0x4fa9e0: add             x25, x1, #0x33
    //     0x4fa9e4: str             w0, [x25]
    //     0x4fa9e8: tbz             w0, #0, #0x4faa04
    //     0x4fa9ec: ldurb           w16, [x1, #-1]
    //     0x4fa9f0: ldurb           w17, [x0, #-1]
    //     0x4fa9f4: and             x16, x17, x16, lsr #2
    //     0x4fa9f8: tst             x16, HEAP, lsr #32
    //     0x4fa9fc: b.eq            #0x4faa04
    //     0x4faa00: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4faa04: ldur            x0, [fp, #-0x18]
    // 0x4faa08: r16 = 120
    //     0x4faa08: movz            x16, #0x78
    // 0x4faa0c: StoreField: r0->field_37 = r16
    //     0x4faa0c: stur            w16, [x0, #0x37]
    // 0x4faa10: ldur            x2, [fp, #-0x10]
    // 0x4faa14: r1 = Function '<anonymous closure>':.
    //     0x4faa14: add             x1, PP, #0x15, lsl #12  ; [pp+0x15af8] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4faa18: ldr             x1, [x1, #0xaf8]
    // 0x4faa1c: r0 = AllocateClosure()
    //     0x4faa1c: bl              #0x826750  ; AllocateClosureStub
    // 0x4faa20: str             x0, [SP]
    // 0x4faa24: r1 = <Chapter13Stat>
    //     0x4faa24: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4faa28: ldr             x1, [x1, #0xf28]
    // 0x4faa2c: r2 = Instance_Tuple2
    //     0x4faa2c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b00] Obj!Tuple2<Chapter13Stat, CustomNum>@8237f1
    //     0x4faa30: ldr             x2, [x2, #0xb00]
    // 0x4faa34: r3 = "10x yields to flexible container services, Route 42, and IAM"
    //     0x4faa34: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b08] "10x yields to flexible container services, Route 42, and IAM"
    //     0x4faa38: ldr             x3, [x3, #0xb08]
    // 0x4faa3c: r5 = Instance_IconData
    //     0x4faa3c: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b10] Obj!IconData@82f271
    //     0x4faa40: ldr             x5, [x5, #0xb10]
    // 0x4faa44: r6 = "Back To Basics"
    //     0x4faa44: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b18] "Back To Basics"
    //     0x4faa48: ldr             x6, [x6, #0xb18]
    // 0x4faa4c: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4faa4c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4faa50: ldr             x4, [x4, #0xcc0]
    // 0x4faa54: r0 = UpgradeData.single()
    //     0x4faa54: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4faa58: ldur            x1, [fp, #-0x18]
    // 0x4faa5c: ArrayStore: r1[11] = r0  ; List_4
    //     0x4faa5c: add             x25, x1, #0x3b
    //     0x4faa60: str             w0, [x25]
    //     0x4faa64: tbz             w0, #0, #0x4faa80
    //     0x4faa68: ldurb           w16, [x1, #-1]
    //     0x4faa6c: ldurb           w17, [x0, #-1]
    //     0x4faa70: and             x16, x17, x16, lsr #2
    //     0x4faa74: tst             x16, HEAP, lsr #32
    //     0x4faa78: b.eq            #0x4faa80
    //     0x4faa7c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4faa80: ldur            x0, [fp, #-0x18]
    // 0x4faa84: r16 = 140
    //     0x4faa84: movz            x16, #0x8c
    // 0x4faa88: StoreField: r0->field_3f = r16
    //     0x4faa88: stur            w16, [x0, #0x3f]
    // 0x4faa8c: r1 = Function '<anonymous closure>':.
    //     0x4faa8c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b20] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4faa90: ldr             x1, [x1, #0xb20]
    // 0x4faa94: r2 = Null
    //     0x4faa94: mov             x2, NULL
    // 0x4faa98: r0 = AllocateClosure()
    //     0x4faa98: bl              #0x826750  ; AllocateClosureStub
    // 0x4faa9c: str             x0, [SP]
    // 0x4faaa0: r1 = <Chapter13Stat>
    //     0x4faaa0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4faaa4: ldr             x1, [x1, #0xf28]
    // 0x4faaa8: r2 = Instance_Tuple2
    //     0x4faaa8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b28] Obj!Tuple2<Chapter13Stat, CustomNum>@8237d1
    //     0x4faaac: ldr             x2, [x2, #0xb28]
    // 0x4faab0: r3 = "Unlocks CloudFort (Networking)"
    //     0x4faab0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b30] "Unlocks CloudFort (Networking)"
    //     0x4faab4: ldr             x3, [x3, #0xb30]
    // 0x4faab8: r5 = Instance_IconData
    //     0x4faab8: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b38] Obj!IconData@82f251
    //     0x4faabc: ldr             x5, [x5, #0xb38]
    // 0x4faac0: r6 = "Fortress"
    //     0x4faac0: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b40] "Fortress"
    //     0x4faac4: ldr             x6, [x6, #0xb40]
    // 0x4faac8: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4faac8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4faacc: ldr             x4, [x4, #0xcc0]
    // 0x4faad0: r0 = UpgradeData.single()
    //     0x4faad0: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4faad4: ldur            x1, [fp, #-0x18]
    // 0x4faad8: ArrayStore: r1[13] = r0  ; List_4
    //     0x4faad8: add             x25, x1, #0x43
    //     0x4faadc: str             w0, [x25]
    //     0x4faae0: tbz             w0, #0, #0x4faafc
    //     0x4faae4: ldurb           w16, [x1, #-1]
    //     0x4faae8: ldurb           w17, [x0, #-1]
    //     0x4faaec: and             x16, x17, x16, lsr #2
    //     0x4faaf0: tst             x16, HEAP, lsr #32
    //     0x4faaf4: b.eq            #0x4faafc
    //     0x4faaf8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4faafc: ldur            x0, [fp, #-0x18]
    // 0x4fab00: r16 = 160
    //     0x4fab00: movz            x16, #0xa0
    // 0x4fab04: StoreField: r0->field_47 = r16
    //     0x4fab04: stur            w16, [x0, #0x47]
    // 0x4fab08: r1 = Function '<anonymous closure>':.
    //     0x4fab08: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b48] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4fab0c: ldr             x1, [x1, #0xb48]
    // 0x4fab10: r2 = Null
    //     0x4fab10: mov             x2, NULL
    // 0x4fab14: r0 = AllocateClosure()
    //     0x4fab14: bl              #0x826750  ; AllocateClosureStub
    // 0x4fab18: str             x0, [SP]
    // 0x4fab1c: r1 = <Chapter13Stat>
    //     0x4fab1c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fab20: ldr             x1, [x1, #0xf28]
    // 0x4fab24: r2 = Instance_Tuple2
    //     0x4fab24: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b50] Obj!Tuple2<Chapter13Stat, CustomNum>@8237b1
    //     0x4fab28: ldr             x2, [x2, #0xb50]
    // 0x4fab2c: r3 = "Unlock additional quest levels"
    //     0x4fab2c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b58] "Unlock additional quest levels"
    //     0x4fab30: ldr             x3, [x3, #0xb58]
    // 0x4fab34: r5 = Instance_IconData
    //     0x4fab34: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b60] Obj!IconData@8301d1
    //     0x4fab38: ldr             x5, [x5, #0xb60]
    // 0x4fab3c: r6 = "More Milestones"
    //     0x4fab3c: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b68] "More Milestones"
    //     0x4fab40: ldr             x6, [x6, #0xb68]
    // 0x4fab44: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fab44: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fab48: ldr             x4, [x4, #0xcc0]
    // 0x4fab4c: r0 = UpgradeData.single()
    //     0x4fab4c: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fab50: ldur            x1, [fp, #-0x18]
    // 0x4fab54: ArrayStore: r1[15] = r0  ; List_4
    //     0x4fab54: add             x25, x1, #0x4b
    //     0x4fab58: str             w0, [x25]
    //     0x4fab5c: tbz             w0, #0, #0x4fab78
    //     0x4fab60: ldurb           w16, [x1, #-1]
    //     0x4fab64: ldurb           w17, [x0, #-1]
    //     0x4fab68: and             x16, x17, x16, lsr #2
    //     0x4fab6c: tst             x16, HEAP, lsr #32
    //     0x4fab70: b.eq            #0x4fab78
    //     0x4fab74: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fab78: ldur            x0, [fp, #-0x18]
    // 0x4fab7c: r16 = 180
    //     0x4fab7c: movz            x16, #0xb4
    // 0x4fab80: StoreField: r0->field_4f = r16
    //     0x4fab80: stur            w16, [x0, #0x4f]
    // 0x4fab84: r1 = Function '<anonymous closure>':.
    //     0x4fab84: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b70] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4fab88: ldr             x1, [x1, #0xb70]
    // 0x4fab8c: r2 = Null
    //     0x4fab8c: mov             x2, NULL
    // 0x4fab90: r0 = AllocateClosure()
    //     0x4fab90: bl              #0x826750  ; AllocateClosureStub
    // 0x4fab94: str             x0, [SP]
    // 0x4fab98: r1 = <Chapter13Stat>
    //     0x4fab98: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fab9c: ldr             x1, [x1, #0xf28]
    // 0x4faba0: r2 = Instance_Tuple2
    //     0x4faba0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b78] Obj!Tuple2<Chapter13Stat, CustomNum>@823791
    //     0x4faba4: ldr             x2, [x2, #0xb78]
    // 0x4faba8: r3 = "Unlocks simple message queue."
    //     0x4faba8: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b80] "Unlocks simple message queue."
    //     0x4fabac: ldr             x3, [x3, #0xb80]
    // 0x4fabb0: r5 = Instance_IconData
    //     0x4fabb0: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b88] Obj!IconData@8301b1
    //     0x4fabb4: ldr             x5, [x5, #0xb88]
    // 0x4fabb8: r6 = "Microservices"
    //     0x4fabb8: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b90] "Microservices"
    //     0x4fabbc: ldr             x6, [x6, #0xb90]
    // 0x4fabc0: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fabc0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fabc4: ldr             x4, [x4, #0xcc0]
    // 0x4fabc8: r0 = UpgradeData.single()
    //     0x4fabc8: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fabcc: ldur            x1, [fp, #-0x18]
    // 0x4fabd0: ArrayStore: r1[17] = r0  ; List_4
    //     0x4fabd0: add             x25, x1, #0x53
    //     0x4fabd4: str             w0, [x25]
    //     0x4fabd8: tbz             w0, #0, #0x4fabf4
    //     0x4fabdc: ldurb           w16, [x1, #-1]
    //     0x4fabe0: ldurb           w17, [x0, #-1]
    //     0x4fabe4: and             x16, x17, x16, lsr #2
    //     0x4fabe8: tst             x16, HEAP, lsr #32
    //     0x4fabec: b.eq            #0x4fabf4
    //     0x4fabf0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fabf4: ldur            x0, [fp, #-0x18]
    // 0x4fabf8: r16 = 200
    //     0x4fabf8: movz            x16, #0xc8
    // 0x4fabfc: StoreField: r0->field_57 = r16
    //     0x4fabfc: stur            w16, [x0, #0x57]
    // 0x4fac00: r1 = Function '<anonymous closure>':.
    //     0x4fac00: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b98] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4fac04: ldr             x1, [x1, #0xb98]
    // 0x4fac08: r2 = Null
    //     0x4fac08: mov             x2, NULL
    // 0x4fac0c: r0 = AllocateClosure()
    //     0x4fac0c: bl              #0x826750  ; AllocateClosureStub
    // 0x4fac10: str             x0, [SP]
    // 0x4fac14: r1 = <Chapter13Stat>
    //     0x4fac14: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x4fac18: ldr             x1, [x1, #0xf28]
    // 0x4fac1c: r2 = Instance_Tuple2
    //     0x4fac1c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ba0] Obj!Tuple2<Chapter13Stat, CustomNum>@823771
    //     0x4fac20: ldr             x2, [x2, #0xba0]
    // 0x4fac24: r3 = "Unlocks Kinetics."
    //     0x4fac24: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ba8] "Unlocks Kinetics."
    //     0x4fac28: ldr             x3, [x3, #0xba8]
    // 0x4fac2c: r5 = Instance_IconData
    //     0x4fac2c: add             x5, PP, #0x15, lsl #12  ; [pp+0x15bb0] Obj!IconData@830191
    //     0x4fac30: ldr             x5, [x5, #0xbb0]
    // 0x4fac34: r6 = "Deep Analytics"
    //     0x4fac34: add             x6, PP, #0x15, lsl #12  ; [pp+0x15bb8] "Deep Analytics"
    //     0x4fac38: ldr             x6, [x6, #0xbb8]
    // 0x4fac3c: r4 = const [0, 0x6, 0x1, 0x5, onBuyTap, 0x5, null]
    //     0x4fac3c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14cc0] List(7) [0, 0x6, 0x1, 0x5, "onBuyTap", 0x5, Null]
    //     0x4fac40: ldr             x4, [x4, #0xcc0]
    // 0x4fac44: r0 = UpgradeData.single()
    //     0x4fac44: bl              #0x4facbc  ; [package:pretentious/data/UpgradeData.dart] UpgradeData::UpgradeData.single
    // 0x4fac48: ldur            x1, [fp, #-0x18]
    // 0x4fac4c: ArrayStore: r1[19] = r0  ; List_4
    //     0x4fac4c: add             x25, x1, #0x5b
    //     0x4fac50: str             w0, [x25]
    //     0x4fac54: tbz             w0, #0, #0x4fac70
    //     0x4fac58: ldurb           w16, [x1, #-1]
    //     0x4fac5c: ldurb           w17, [x0, #-1]
    //     0x4fac60: and             x16, x17, x16, lsr #2
    //     0x4fac64: tst             x16, HEAP, lsr #32
    //     0x4fac68: b.eq            #0x4fac70
    //     0x4fac6c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fac70: r16 = <int, UpgradeData<Chapter13Stat>>
    //     0x4fac70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15bc0] TypeArguments: <int, UpgradeData<Chapter13Stat>>
    //     0x4fac74: ldr             x16, [x16, #0xbc0]
    // 0x4fac78: ldur            lr, [fp, #-0x18]
    // 0x4fac7c: stp             lr, x16, [SP]
    // 0x4fac80: r0 = Map._fromLiteral()
    //     0x4fac80: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fac84: ldur            x1, [fp, #-8]
    // 0x4fac88: StoreField: r1->field_97 = r0
    //     0x4fac88: stur            w0, [x1, #0x97]
    //     0x4fac8c: ldurb           w16, [x1, #-1]
    //     0x4fac90: ldurb           w17, [x0, #-1]
    //     0x4fac94: and             x16, x17, x16, lsr #2
    //     0x4fac98: tst             x16, HEAP, lsr #32
    //     0x4fac9c: b.eq            #0x4faca4
    //     0x4faca0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4faca4: r0 = Null
    //     0x4faca4: mov             x0, NULL
    // 0x4faca8: LeaveFrame
    //     0x4faca8: mov             SP, fp
    //     0x4facac: ldp             fp, lr, [SP], #0x10
    // 0x4facb0: ret
    //     0x4facb0: ret             
    // 0x4facb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4facb4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4facb8: b               #0x4fa464
  }
  [closure] CustomNum <anonymous closure>(dynamic) {
    // ** addr: 0x518ee0, size: 0xc
    // 0x518ee0: r0 = Instance_CustomNum
    //     0x518ee0: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x518ee4: ldr             x0, [x0, #0xa70]
    // 0x518ee8: ret
    //     0x518ee8: ret             
  }
  _ postUpdateCallback(/* No info */) {
    // ** addr: 0x544420, size: 0x5e8
    // 0x544420: EnterFrame
    //     0x544420: stp             fp, lr, [SP, #-0x10]!
    //     0x544424: mov             fp, SP
    // 0x544428: AllocStack(0x20)
    //     0x544428: sub             SP, SP, #0x20
    // 0x54442c: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */)
    //     0x54442c: mov             x0, x1
    //     0x544430: stur            x1, [fp, #-8]
    // 0x544434: CheckStackOverflow
    //     0x544434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x544438: cmp             SP, x16
    //     0x54443c: b.ls            #0x544a00
    // 0x544440: r1 = <int>
    //     0x544440: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544444: r2 = 0
    //     0x544444: movz            x2, #0
    // 0x544448: r0 = _GrowableList()
    //     0x544448: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x54444c: mov             x3, x0
    // 0x544450: ldur            x0, [fp, #-8]
    // 0x544454: stur            x3, [fp, #-0x10]
    // 0x544458: LoadField: r1 = r0->field_9b
    //     0x544458: ldur            w1, [x0, #0x9b]
    // 0x54445c: DecompressPointer r1
    //     0x54445c: add             x1, x1, HEAP, lsl #32
    // 0x544460: r2 = 2
    //     0x544460: movz            x2, #0x2
    // 0x544464: r0 = contains()
    //     0x544464: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x544468: tbnz            w0, #4, #0x544520
    // 0x54446c: ldur            x0, [fp, #-8]
    // 0x544470: LoadField: r1 = r0->field_8b
    //     0x544470: ldur            x1, [x0, #0x8b]
    // 0x544474: cmp             x1, #8
    // 0x544478: b.gt            #0x5444cc
    // 0x54447c: r3 = 4
    //     0x54447c: movz            x3, #0x4
    // 0x544480: mov             x2, x3
    // 0x544484: r1 = Null
    //     0x544484: mov             x1, NULL
    // 0x544488: r0 = AllocateArray()
    //     0x544488: bl              #0x82746c  ; AllocateArrayStub
    // 0x54448c: stur            x0, [fp, #-0x18]
    // 0x544490: r16 = 2
    //     0x544490: movz            x16, #0x2
    // 0x544494: StoreField: r0->field_f = r16
    //     0x544494: stur            w16, [x0, #0xf]
    // 0x544498: r16 = 4
    //     0x544498: movz            x16, #0x4
    // 0x54449c: StoreField: r0->field_13 = r16
    //     0x54449c: stur            w16, [x0, #0x13]
    // 0x5444a0: r1 = <int>
    //     0x5444a0: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x5444a4: r0 = AllocateGrowableArray()
    //     0x5444a4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5444a8: mov             x1, x0
    // 0x5444ac: ldur            x0, [fp, #-0x18]
    // 0x5444b0: StoreField: r1->field_f = r0
    //     0x5444b0: stur            w0, [x1, #0xf]
    // 0x5444b4: r0 = 4
    //     0x5444b4: movz            x0, #0x4
    // 0x5444b8: StoreField: r1->field_b = r0
    //     0x5444b8: stur            w0, [x1, #0xb]
    // 0x5444bc: mov             x2, x1
    // 0x5444c0: ldur            x1, [fp, #-0x10]
    // 0x5444c4: r0 = addAll()
    //     0x5444c4: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x5444c8: b               #0x544520
    // 0x5444cc: r0 = 6
    //     0x5444cc: movz            x0, #0x6
    // 0x5444d0: mov             x2, x0
    // 0x5444d4: r1 = Null
    //     0x5444d4: mov             x1, NULL
    // 0x5444d8: r0 = AllocateArray()
    //     0x5444d8: bl              #0x82746c  ; AllocateArrayStub
    // 0x5444dc: stur            x0, [fp, #-0x18]
    // 0x5444e0: r16 = 2
    //     0x5444e0: movz            x16, #0x2
    // 0x5444e4: StoreField: r0->field_f = r16
    //     0x5444e4: stur            w16, [x0, #0xf]
    // 0x5444e8: r16 = 4
    //     0x5444e8: movz            x16, #0x4
    // 0x5444ec: StoreField: r0->field_13 = r16
    //     0x5444ec: stur            w16, [x0, #0x13]
    // 0x5444f0: r16 = 6
    //     0x5444f0: movz            x16, #0x6
    // 0x5444f4: ArrayStore: r0[0] = r16  ; List_4
    //     0x5444f4: stur            w16, [x0, #0x17]
    // 0x5444f8: r1 = <int>
    //     0x5444f8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x5444fc: r0 = AllocateGrowableArray()
    //     0x5444fc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x544500: mov             x1, x0
    // 0x544504: ldur            x0, [fp, #-0x18]
    // 0x544508: StoreField: r1->field_f = r0
    //     0x544508: stur            w0, [x1, #0xf]
    // 0x54450c: r0 = 6
    //     0x54450c: movz            x0, #0x6
    // 0x544510: StoreField: r1->field_b = r0
    //     0x544510: stur            w0, [x1, #0xb]
    // 0x544514: mov             x2, x1
    // 0x544518: ldur            x1, [fp, #-0x10]
    // 0x54451c: r0 = addAll()
    //     0x54451c: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544520: ldur            x0, [fp, #-8]
    // 0x544524: LoadField: r1 = r0->field_9b
    //     0x544524: ldur            w1, [x0, #0x9b]
    // 0x544528: DecompressPointer r1
    //     0x544528: add             x1, x1, HEAP, lsl #32
    // 0x54452c: r2 = 6
    //     0x54452c: movz            x2, #0x6
    // 0x544530: r0 = contains()
    //     0x544530: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x544534: tbnz            w0, #4, #0x544648
    // 0x544538: ldur            x0, [fp, #-8]
    // 0x54453c: LoadField: r1 = r0->field_8b
    //     0x54453c: ldur            x1, [x0, #0x8b]
    // 0x544540: cmp             x1, #7
    // 0x544544: b.lt            #0x544604
    // 0x544548: LoadField: r1 = r0->field_43
    //     0x544548: ldur            w1, [x0, #0x43]
    // 0x54454c: DecompressPointer r1
    //     0x54454c: add             x1, x1, HEAP, lsl #32
    // 0x544550: r2 = 140
    //     0x544550: movz            x2, #0x8c
    // 0x544554: r0 = containsKey()
    //     0x544554: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x544558: tbnz            w0, #4, #0x5445b4
    // 0x54455c: r0 = 6
    //     0x54455c: movz            x0, #0x6
    // 0x544560: mov             x2, x0
    // 0x544564: r1 = Null
    //     0x544564: mov             x1, NULL
    // 0x544568: r0 = AllocateArray()
    //     0x544568: bl              #0x82746c  ; AllocateArrayStub
    // 0x54456c: stur            x0, [fp, #-0x18]
    // 0x544570: r16 = 42
    //     0x544570: movz            x16, #0x2a
    // 0x544574: StoreField: r0->field_f = r16
    //     0x544574: stur            w16, [x0, #0xf]
    // 0x544578: r16 = 44
    //     0x544578: movz            x16, #0x2c
    // 0x54457c: StoreField: r0->field_13 = r16
    //     0x54457c: stur            w16, [x0, #0x13]
    // 0x544580: r16 = 46
    //     0x544580: movz            x16, #0x2e
    // 0x544584: ArrayStore: r0[0] = r16  ; List_4
    //     0x544584: stur            w16, [x0, #0x17]
    // 0x544588: r1 = <int>
    //     0x544588: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x54458c: r0 = AllocateGrowableArray()
    //     0x54458c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x544590: mov             x1, x0
    // 0x544594: ldur            x0, [fp, #-0x18]
    // 0x544598: StoreField: r1->field_f = r0
    //     0x544598: stur            w0, [x1, #0xf]
    // 0x54459c: r0 = 6
    //     0x54459c: movz            x0, #0x6
    // 0x5445a0: StoreField: r1->field_b = r0
    //     0x5445a0: stur            w0, [x1, #0xb]
    // 0x5445a4: mov             x2, x1
    // 0x5445a8: ldur            x1, [fp, #-0x10]
    // 0x5445ac: r0 = addAll()
    //     0x5445ac: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x5445b0: b               #0x544648
    // 0x5445b4: r0 = 4
    //     0x5445b4: movz            x0, #0x4
    // 0x5445b8: mov             x2, x0
    // 0x5445bc: r1 = Null
    //     0x5445bc: mov             x1, NULL
    // 0x5445c0: r0 = AllocateArray()
    //     0x5445c0: bl              #0x82746c  ; AllocateArrayStub
    // 0x5445c4: stur            x0, [fp, #-0x18]
    // 0x5445c8: r16 = 42
    //     0x5445c8: movz            x16, #0x2a
    // 0x5445cc: StoreField: r0->field_f = r16
    //     0x5445cc: stur            w16, [x0, #0xf]
    // 0x5445d0: r16 = 44
    //     0x5445d0: movz            x16, #0x2c
    // 0x5445d4: StoreField: r0->field_13 = r16
    //     0x5445d4: stur            w16, [x0, #0x13]
    // 0x5445d8: r1 = <int>
    //     0x5445d8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x5445dc: r0 = AllocateGrowableArray()
    //     0x5445dc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5445e0: mov             x1, x0
    // 0x5445e4: ldur            x0, [fp, #-0x18]
    // 0x5445e8: StoreField: r1->field_f = r0
    //     0x5445e8: stur            w0, [x1, #0xf]
    // 0x5445ec: r0 = 4
    //     0x5445ec: movz            x0, #0x4
    // 0x5445f0: StoreField: r1->field_b = r0
    //     0x5445f0: stur            w0, [x1, #0xb]
    // 0x5445f4: mov             x2, x1
    // 0x5445f8: ldur            x1, [fp, #-0x10]
    // 0x5445fc: r0 = addAll()
    //     0x5445fc: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544600: b               #0x544648
    // 0x544604: r0 = 2
    //     0x544604: movz            x0, #0x2
    // 0x544608: mov             x2, x0
    // 0x54460c: r1 = Null
    //     0x54460c: mov             x1, NULL
    // 0x544610: r0 = AllocateArray()
    //     0x544610: bl              #0x82746c  ; AllocateArrayStub
    // 0x544614: stur            x0, [fp, #-0x18]
    // 0x544618: r16 = 42
    //     0x544618: movz            x16, #0x2a
    // 0x54461c: StoreField: r0->field_f = r16
    //     0x54461c: stur            w16, [x0, #0xf]
    // 0x544620: r1 = <int>
    //     0x544620: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544624: r0 = AllocateGrowableArray()
    //     0x544624: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x544628: mov             x1, x0
    // 0x54462c: ldur            x0, [fp, #-0x18]
    // 0x544630: StoreField: r1->field_f = r0
    //     0x544630: stur            w0, [x1, #0xf]
    // 0x544634: r0 = 2
    //     0x544634: movz            x0, #0x2
    // 0x544638: StoreField: r1->field_b = r0
    //     0x544638: stur            w0, [x1, #0xb]
    // 0x54463c: mov             x2, x1
    // 0x544640: ldur            x1, [fp, #-0x10]
    // 0x544644: r0 = addAll()
    //     0x544644: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544648: ldur            x0, [fp, #-8]
    // 0x54464c: LoadField: r1 = r0->field_9b
    //     0x54464c: ldur            w1, [x0, #0x9b]
    // 0x544650: DecompressPointer r1
    //     0x544650: add             x1, x1, HEAP, lsl #32
    // 0x544654: r2 = 10
    //     0x544654: movz            x2, #0xa
    // 0x544658: r0 = contains()
    //     0x544658: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x54465c: tbnz            w0, #4, #0x544714
    // 0x544660: ldur            x0, [fp, #-8]
    // 0x544664: LoadField: r1 = r0->field_8b
    //     0x544664: ldur            x1, [x0, #0x8b]
    // 0x544668: cmp             x1, #8
    // 0x54466c: b.gt            #0x5446c0
    // 0x544670: r3 = 4
    //     0x544670: movz            x3, #0x4
    // 0x544674: mov             x2, x3
    // 0x544678: r1 = Null
    //     0x544678: mov             x1, NULL
    // 0x54467c: r0 = AllocateArray()
    //     0x54467c: bl              #0x82746c  ; AllocateArrayStub
    // 0x544680: stur            x0, [fp, #-0x18]
    // 0x544684: r16 = 82
    //     0x544684: movz            x16, #0x52
    // 0x544688: StoreField: r0->field_f = r16
    //     0x544688: stur            w16, [x0, #0xf]
    // 0x54468c: r16 = 84
    //     0x54468c: movz            x16, #0x54
    // 0x544690: StoreField: r0->field_13 = r16
    //     0x544690: stur            w16, [x0, #0x13]
    // 0x544694: r1 = <int>
    //     0x544694: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544698: r0 = AllocateGrowableArray()
    //     0x544698: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x54469c: mov             x1, x0
    // 0x5446a0: ldur            x0, [fp, #-0x18]
    // 0x5446a4: StoreField: r1->field_f = r0
    //     0x5446a4: stur            w0, [x1, #0xf]
    // 0x5446a8: r0 = 4
    //     0x5446a8: movz            x0, #0x4
    // 0x5446ac: StoreField: r1->field_b = r0
    //     0x5446ac: stur            w0, [x1, #0xb]
    // 0x5446b0: mov             x2, x1
    // 0x5446b4: ldur            x1, [fp, #-0x10]
    // 0x5446b8: r0 = addAll()
    //     0x5446b8: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x5446bc: b               #0x544714
    // 0x5446c0: r0 = 6
    //     0x5446c0: movz            x0, #0x6
    // 0x5446c4: mov             x2, x0
    // 0x5446c8: r1 = Null
    //     0x5446c8: mov             x1, NULL
    // 0x5446cc: r0 = AllocateArray()
    //     0x5446cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x5446d0: stur            x0, [fp, #-0x18]
    // 0x5446d4: r16 = 82
    //     0x5446d4: movz            x16, #0x52
    // 0x5446d8: StoreField: r0->field_f = r16
    //     0x5446d8: stur            w16, [x0, #0xf]
    // 0x5446dc: r16 = 84
    //     0x5446dc: movz            x16, #0x54
    // 0x5446e0: StoreField: r0->field_13 = r16
    //     0x5446e0: stur            w16, [x0, #0x13]
    // 0x5446e4: r16 = 86
    //     0x5446e4: movz            x16, #0x56
    // 0x5446e8: ArrayStore: r0[0] = r16  ; List_4
    //     0x5446e8: stur            w16, [x0, #0x17]
    // 0x5446ec: r1 = <int>
    //     0x5446ec: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x5446f0: r0 = AllocateGrowableArray()
    //     0x5446f0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5446f4: mov             x1, x0
    // 0x5446f8: ldur            x0, [fp, #-0x18]
    // 0x5446fc: StoreField: r1->field_f = r0
    //     0x5446fc: stur            w0, [x1, #0xf]
    // 0x544700: r0 = 6
    //     0x544700: movz            x0, #0x6
    // 0x544704: StoreField: r1->field_b = r0
    //     0x544704: stur            w0, [x1, #0xb]
    // 0x544708: mov             x2, x1
    // 0x54470c: ldur            x1, [fp, #-0x10]
    // 0x544710: r0 = addAll()
    //     0x544710: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544714: ldur            x0, [fp, #-8]
    // 0x544718: LoadField: r1 = r0->field_9b
    //     0x544718: ldur            w1, [x0, #0x9b]
    // 0x54471c: DecompressPointer r1
    //     0x54471c: add             x1, x1, HEAP, lsl #32
    // 0x544720: r2 = 4
    //     0x544720: movz            x2, #0x4
    // 0x544724: r0 = contains()
    //     0x544724: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x544728: tbnz            w0, #4, #0x5447e0
    // 0x54472c: ldur            x0, [fp, #-8]
    // 0x544730: LoadField: r1 = r0->field_8b
    //     0x544730: ldur            x1, [x0, #0x8b]
    // 0x544734: cmp             x1, #0xb
    // 0x544738: b.gt            #0x54478c
    // 0x54473c: r3 = 4
    //     0x54473c: movz            x3, #0x4
    // 0x544740: mov             x2, x3
    // 0x544744: r1 = Null
    //     0x544744: mov             x1, NULL
    // 0x544748: r0 = AllocateArray()
    //     0x544748: bl              #0x82746c  ; AllocateArrayStub
    // 0x54474c: stur            x0, [fp, #-0x18]
    // 0x544750: r16 = 22
    //     0x544750: movz            x16, #0x16
    // 0x544754: StoreField: r0->field_f = r16
    //     0x544754: stur            w16, [x0, #0xf]
    // 0x544758: r16 = 24
    //     0x544758: movz            x16, #0x18
    // 0x54475c: StoreField: r0->field_13 = r16
    //     0x54475c: stur            w16, [x0, #0x13]
    // 0x544760: r1 = <int>
    //     0x544760: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544764: r0 = AllocateGrowableArray()
    //     0x544764: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x544768: mov             x1, x0
    // 0x54476c: ldur            x0, [fp, #-0x18]
    // 0x544770: StoreField: r1->field_f = r0
    //     0x544770: stur            w0, [x1, #0xf]
    // 0x544774: r0 = 4
    //     0x544774: movz            x0, #0x4
    // 0x544778: StoreField: r1->field_b = r0
    //     0x544778: stur            w0, [x1, #0xb]
    // 0x54477c: mov             x2, x1
    // 0x544780: ldur            x1, [fp, #-0x10]
    // 0x544784: r0 = addAll()
    //     0x544784: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544788: b               #0x5447e0
    // 0x54478c: r0 = 6
    //     0x54478c: movz            x0, #0x6
    // 0x544790: mov             x2, x0
    // 0x544794: r1 = Null
    //     0x544794: mov             x1, NULL
    // 0x544798: r0 = AllocateArray()
    //     0x544798: bl              #0x82746c  ; AllocateArrayStub
    // 0x54479c: stur            x0, [fp, #-0x18]
    // 0x5447a0: r16 = 22
    //     0x5447a0: movz            x16, #0x16
    // 0x5447a4: StoreField: r0->field_f = r16
    //     0x5447a4: stur            w16, [x0, #0xf]
    // 0x5447a8: r16 = 24
    //     0x5447a8: movz            x16, #0x18
    // 0x5447ac: StoreField: r0->field_13 = r16
    //     0x5447ac: stur            w16, [x0, #0x13]
    // 0x5447b0: r16 = 26
    //     0x5447b0: movz            x16, #0x1a
    // 0x5447b4: ArrayStore: r0[0] = r16  ; List_4
    //     0x5447b4: stur            w16, [x0, #0x17]
    // 0x5447b8: r1 = <int>
    //     0x5447b8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x5447bc: r0 = AllocateGrowableArray()
    //     0x5447bc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5447c0: mov             x1, x0
    // 0x5447c4: ldur            x0, [fp, #-0x18]
    // 0x5447c8: StoreField: r1->field_f = r0
    //     0x5447c8: stur            w0, [x1, #0xf]
    // 0x5447cc: r0 = 6
    //     0x5447cc: movz            x0, #0x6
    // 0x5447d0: StoreField: r1->field_b = r0
    //     0x5447d0: stur            w0, [x1, #0xb]
    // 0x5447d4: mov             x2, x1
    // 0x5447d8: ldur            x1, [fp, #-0x10]
    // 0x5447dc: r0 = addAll()
    //     0x5447dc: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x5447e0: ldur            x0, [fp, #-8]
    // 0x5447e4: LoadField: r1 = r0->field_9b
    //     0x5447e4: ldur            w1, [x0, #0x9b]
    // 0x5447e8: DecompressPointer r1
    //     0x5447e8: add             x1, x1, HEAP, lsl #32
    // 0x5447ec: r2 = 8
    //     0x5447ec: movz            x2, #0x8
    // 0x5447f0: r0 = contains()
    //     0x5447f0: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x5447f4: tbnz            w0, #4, #0x5448ac
    // 0x5447f8: ldur            x0, [fp, #-8]
    // 0x5447fc: LoadField: r1 = r0->field_8b
    //     0x5447fc: ldur            x1, [x0, #0x8b]
    // 0x544800: cmp             x1, #0xa
    // 0x544804: b.lt            #0x544860
    // 0x544808: r3 = 6
    //     0x544808: movz            x3, #0x6
    // 0x54480c: mov             x2, x3
    // 0x544810: r1 = Null
    //     0x544810: mov             x1, NULL
    // 0x544814: r0 = AllocateArray()
    //     0x544814: bl              #0x82746c  ; AllocateArrayStub
    // 0x544818: stur            x0, [fp, #-0x18]
    // 0x54481c: r16 = 62
    //     0x54481c: movz            x16, #0x3e
    // 0x544820: StoreField: r0->field_f = r16
    //     0x544820: stur            w16, [x0, #0xf]
    // 0x544824: r16 = 64
    //     0x544824: movz            x16, #0x40
    // 0x544828: StoreField: r0->field_13 = r16
    //     0x544828: stur            w16, [x0, #0x13]
    // 0x54482c: r16 = 66
    //     0x54482c: movz            x16, #0x42
    // 0x544830: ArrayStore: r0[0] = r16  ; List_4
    //     0x544830: stur            w16, [x0, #0x17]
    // 0x544834: r1 = <int>
    //     0x544834: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544838: r0 = AllocateGrowableArray()
    //     0x544838: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x54483c: mov             x1, x0
    // 0x544840: ldur            x0, [fp, #-0x18]
    // 0x544844: StoreField: r1->field_f = r0
    //     0x544844: stur            w0, [x1, #0xf]
    // 0x544848: r0 = 6
    //     0x544848: movz            x0, #0x6
    // 0x54484c: StoreField: r1->field_b = r0
    //     0x54484c: stur            w0, [x1, #0xb]
    // 0x544850: mov             x2, x1
    // 0x544854: ldur            x1, [fp, #-0x10]
    // 0x544858: r0 = addAll()
    //     0x544858: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x54485c: b               #0x5448ac
    // 0x544860: r0 = 4
    //     0x544860: movz            x0, #0x4
    // 0x544864: mov             x2, x0
    // 0x544868: r1 = Null
    //     0x544868: mov             x1, NULL
    // 0x54486c: r0 = AllocateArray()
    //     0x54486c: bl              #0x82746c  ; AllocateArrayStub
    // 0x544870: stur            x0, [fp, #-0x18]
    // 0x544874: r16 = 62
    //     0x544874: movz            x16, #0x3e
    // 0x544878: StoreField: r0->field_f = r16
    //     0x544878: stur            w16, [x0, #0xf]
    // 0x54487c: r16 = 64
    //     0x54487c: movz            x16, #0x40
    // 0x544880: StoreField: r0->field_13 = r16
    //     0x544880: stur            w16, [x0, #0x13]
    // 0x544884: r1 = <int>
    //     0x544884: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544888: r0 = AllocateGrowableArray()
    //     0x544888: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x54488c: mov             x1, x0
    // 0x544890: ldur            x0, [fp, #-0x18]
    // 0x544894: StoreField: r1->field_f = r0
    //     0x544894: stur            w0, [x1, #0xf]
    // 0x544898: r0 = 4
    //     0x544898: movz            x0, #0x4
    // 0x54489c: StoreField: r1->field_b = r0
    //     0x54489c: stur            w0, [x1, #0xb]
    // 0x5448a0: mov             x2, x1
    // 0x5448a4: ldur            x1, [fp, #-0x10]
    // 0x5448a8: r0 = addAll()
    //     0x5448a8: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x5448ac: ldur            x0, [fp, #-8]
    // 0x5448b0: LoadField: r1 = r0->field_9b
    //     0x5448b0: ldur            w1, [x0, #0x9b]
    // 0x5448b4: DecompressPointer r1
    //     0x5448b4: add             x1, x1, HEAP, lsl #32
    // 0x5448b8: r2 = 18
    //     0x5448b8: movz            x2, #0x12
    // 0x5448bc: r0 = contains()
    //     0x5448bc: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x5448c0: tbnz            w0, #4, #0x5449c8
    // 0x5448c4: ldur            x0, [fp, #-8]
    // 0x5448c8: LoadField: r1 = r0->field_8b
    //     0x5448c8: ldur            x1, [x0, #0x8b]
    // 0x5448cc: cmp             x1, #0xa
    // 0x5448d0: b.lt            #0x54492c
    // 0x5448d4: r3 = 6
    //     0x5448d4: movz            x3, #0x6
    // 0x5448d8: mov             x2, x3
    // 0x5448dc: r1 = Null
    //     0x5448dc: mov             x1, NULL
    // 0x5448e0: r0 = AllocateArray()
    //     0x5448e0: bl              #0x82746c  ; AllocateArrayStub
    // 0x5448e4: stur            x0, [fp, #-0x18]
    // 0x5448e8: r16 = 102
    //     0x5448e8: movz            x16, #0x66
    // 0x5448ec: StoreField: r0->field_f = r16
    //     0x5448ec: stur            w16, [x0, #0xf]
    // 0x5448f0: r16 = 104
    //     0x5448f0: movz            x16, #0x68
    // 0x5448f4: StoreField: r0->field_13 = r16
    //     0x5448f4: stur            w16, [x0, #0x13]
    // 0x5448f8: r16 = 106
    //     0x5448f8: movz            x16, #0x6a
    // 0x5448fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x5448fc: stur            w16, [x0, #0x17]
    // 0x544900: r1 = <int>
    //     0x544900: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x544904: r0 = AllocateGrowableArray()
    //     0x544904: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x544908: mov             x1, x0
    // 0x54490c: ldur            x0, [fp, #-0x18]
    // 0x544910: StoreField: r1->field_f = r0
    //     0x544910: stur            w0, [x1, #0xf]
    // 0x544914: r0 = 6
    //     0x544914: movz            x0, #0x6
    // 0x544918: StoreField: r1->field_b = r0
    //     0x544918: stur            w0, [x1, #0xb]
    // 0x54491c: mov             x2, x1
    // 0x544920: ldur            x1, [fp, #-0x10]
    // 0x544924: r0 = addAll()
    //     0x544924: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544928: b               #0x5449c8
    // 0x54492c: cmp             x1, #0xa
    // 0x544930: b.lt            #0x544984
    // 0x544934: r0 = 4
    //     0x544934: movz            x0, #0x4
    // 0x544938: mov             x2, x0
    // 0x54493c: r1 = Null
    //     0x54493c: mov             x1, NULL
    // 0x544940: r0 = AllocateArray()
    //     0x544940: bl              #0x82746c  ; AllocateArrayStub
    // 0x544944: stur            x0, [fp, #-0x18]
    // 0x544948: r16 = 102
    //     0x544948: movz            x16, #0x66
    // 0x54494c: StoreField: r0->field_f = r16
    //     0x54494c: stur            w16, [x0, #0xf]
    // 0x544950: r16 = 104
    //     0x544950: movz            x16, #0x68
    // 0x544954: StoreField: r0->field_13 = r16
    //     0x544954: stur            w16, [x0, #0x13]
    // 0x544958: r1 = <int>
    //     0x544958: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x54495c: r0 = AllocateGrowableArray()
    //     0x54495c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x544960: mov             x1, x0
    // 0x544964: ldur            x0, [fp, #-0x18]
    // 0x544968: StoreField: r1->field_f = r0
    //     0x544968: stur            w0, [x1, #0xf]
    // 0x54496c: r0 = 4
    //     0x54496c: movz            x0, #0x4
    // 0x544970: StoreField: r1->field_b = r0
    //     0x544970: stur            w0, [x1, #0xb]
    // 0x544974: mov             x2, x1
    // 0x544978: ldur            x1, [fp, #-0x10]
    // 0x54497c: r0 = addAll()
    //     0x54497c: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x544980: b               #0x5449c8
    // 0x544984: r0 = 2
    //     0x544984: movz            x0, #0x2
    // 0x544988: mov             x2, x0
    // 0x54498c: r1 = Null
    //     0x54498c: mov             x1, NULL
    // 0x544990: r0 = AllocateArray()
    //     0x544990: bl              #0x82746c  ; AllocateArrayStub
    // 0x544994: stur            x0, [fp, #-0x18]
    // 0x544998: r16 = 102
    //     0x544998: movz            x16, #0x66
    // 0x54499c: StoreField: r0->field_f = r16
    //     0x54499c: stur            w16, [x0, #0xf]
    // 0x5449a0: r1 = <int>
    //     0x5449a0: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x5449a4: r0 = AllocateGrowableArray()
    //     0x5449a4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5449a8: mov             x1, x0
    // 0x5449ac: ldur            x0, [fp, #-0x18]
    // 0x5449b0: StoreField: r1->field_f = r0
    //     0x5449b0: stur            w0, [x1, #0xf]
    // 0x5449b4: r0 = 2
    //     0x5449b4: movz            x0, #0x2
    // 0x5449b8: StoreField: r1->field_b = r0
    //     0x5449b8: stur            w0, [x1, #0xb]
    // 0x5449bc: mov             x2, x1
    // 0x5449c0: ldur            x1, [fp, #-0x10]
    // 0x5449c4: r0 = addAll()
    //     0x5449c4: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x5449c8: ldur            x2, [fp, #-0x10]
    // 0x5449cc: LoadField: r0 = r2->field_b
    //     0x5449cc: ldur            w0, [x2, #0xb]
    // 0x5449d0: cbz             w0, #0x5449f0
    // 0x5449d4: r16 = 20
    //     0x5449d4: movz            x16, #0x14
    // 0x5449d8: str             x16, [SP]
    // 0x5449dc: ldur            x1, [fp, #-8]
    // 0x5449e0: r3 = false
    //     0x5449e0: add             x3, NULL, #0x30  ; false
    // 0x5449e4: r4 = const [0, 0x4, 0x1, 0x3, maxBuy, 0x3, null]
    //     0x5449e4: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a6c0] List(7) [0, 0x4, 0x1, 0x3, "maxBuy", 0x3, Null]
    //     0x5449e8: ldr             x4, [x4, #0x6c0]
    // 0x5449ec: r0 = buyAll()
    //     0x5449ec: bl              #0x544a08  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll
    // 0x5449f0: r0 = Null
    //     0x5449f0: mov             x0, NULL
    // 0x5449f4: LeaveFrame
    //     0x5449f4: mov             SP, fp
    //     0x5449f8: ldp             fp, lr, [SP], #0x10
    // 0x5449fc: ret
    //     0x5449fc: ret             
    // 0x544a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x544a00: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x544a04: b               #0x544440
  }
  [closure] (Chapter13Stat, CustomNum)? getGeneratorBaseCost(dynamic, int) {
    // ** addr: 0x54519c, size: 0x3c
    // 0x54519c: EnterFrame
    //     0x54519c: stp             fp, lr, [SP, #-0x10]!
    //     0x5451a0: mov             fp, SP
    // 0x5451a4: ldr             x0, [fp, #0x18]
    // 0x5451a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x5451a8: ldur            w1, [x0, #0x17]
    // 0x5451ac: DecompressPointer r1
    //     0x5451ac: add             x1, x1, HEAP, lsl #32
    // 0x5451b0: CheckStackOverflow
    //     0x5451b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5451b4: cmp             SP, x16
    //     0x5451b8: b.ls            #0x5451d0
    // 0x5451bc: ldr             x2, [fp, #0x10]
    // 0x5451c0: r0 = getGeneratorBaseCost()
    //     0x5451c0: bl              #0x5560d0  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorBaseCost
    // 0x5451c4: LeaveFrame
    //     0x5451c4: mov             SP, fp
    //     0x5451c8: ldp             fp, lr, [SP], #0x10
    // 0x5451cc: ret
    //     0x5451cc: ret             
    // 0x5451d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5451d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5451d4: b               #0x5451bc
  }
  _ getNonGeneratorStatsPerSecond(/* No info */) {
    // ** addr: 0x54d9f0, size: 0xb58
    // 0x54d9f0: EnterFrame
    //     0x54d9f0: stp             fp, lr, [SP, #-0x10]!
    //     0x54d9f4: mov             fp, SP
    // 0x54d9f8: AllocStack(0x80)
    //     0x54d9f8: sub             SP, SP, #0x80
    // 0x54d9fc: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */)
    //     0x54d9fc: mov             x0, x1
    //     0x54da00: stur            x1, [fp, #-8]
    // 0x54da04: CheckStackOverflow
    //     0x54da04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54da08: cmp             SP, x16
    //     0x54da0c: b.ls            #0x54e540
    // 0x54da10: LoadField: r1 = r0->field_3f
    //     0x54da10: ldur            w1, [x0, #0x3f]
    // 0x54da14: DecompressPointer r1
    //     0x54da14: add             x1, x1, HEAP, lsl #32
    // 0x54da18: LoadField: r2 = r1->field_7
    //     0x54da18: ldur            w2, [x1, #7]
    // 0x54da1c: DecompressPointer r2
    //     0x54da1c: add             x2, x2, HEAP, lsl #32
    // 0x54da20: cmp             w2, #4
    // 0x54da24: b.ne            #0x54df78
    // 0x54da28: r1 = Null
    //     0x54da28: mov             x1, NULL
    // 0x54da2c: r2 = 4
    //     0x54da2c: movz            x2, #0x4
    // 0x54da30: r0 = AllocateArray()
    //     0x54da30: bl              #0x82746c  ; AllocateArrayStub
    // 0x54da34: stur            x0, [fp, #-0x18]
    // 0x54da38: r16 = Instance_Chapter13Stat
    //     0x54da38: add             x16, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x54da3c: ldr             x16, [x16, #0x298]
    // 0x54da40: StoreField: r0->field_f = r16
    //     0x54da40: stur            w16, [x0, #0xf]
    // 0x54da44: ldur            x3, [fp, #-8]
    // 0x54da48: LoadField: r4 = r3->field_37
    //     0x54da48: ldur            w4, [x3, #0x37]
    // 0x54da4c: DecompressPointer r4
    //     0x54da4c: add             x4, x4, HEAP, lsl #32
    // 0x54da50: mov             x1, x4
    // 0x54da54: stur            x4, [fp, #-0x10]
    // 0x54da58: r2 = Instance_Chapter13Stat
    //     0x54da58: add             x2, PP, #0x11, lsl #12  ; [pp+0x11340] Obj!Chapter13Stat@85fa81
    //     0x54da5c: ldr             x2, [x2, #0x340]
    // 0x54da60: r0 = _getValueOrData()
    //     0x54da60: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54da64: mov             x1, x0
    // 0x54da68: ldur            x0, [fp, #-0x10]
    // 0x54da6c: LoadField: r2 = r0->field_f
    //     0x54da6c: ldur            w2, [x0, #0xf]
    // 0x54da70: DecompressPointer r2
    //     0x54da70: add             x2, x2, HEAP, lsl #32
    // 0x54da74: cmp             w2, w1
    // 0x54da78: b.ne            #0x54da84
    // 0x54da7c: r0 = Null
    //     0x54da7c: mov             x0, NULL
    // 0x54da80: b               #0x54da88
    // 0x54da84: mov             x0, x1
    // 0x54da88: cmp             w0, NULL
    // 0x54da8c: b.ne            #0x54da9c
    // 0x54da90: r2 = Instance_CustomNum
    //     0x54da90: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54da94: ldr             x2, [x2, #0xaf8]
    // 0x54da98: b               #0x54daa0
    // 0x54da9c: mov             x2, x0
    // 0x54daa0: ldur            x0, [fp, #-8]
    // 0x54daa4: r1 = Instance_CustomNum
    //     0x54daa4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54daa8: ldr             x1, [x1, #0xa70]
    // 0x54daac: r0 = add()
    //     0x54daac: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54dab0: mov             x3, x0
    // 0x54dab4: ldur            x0, [fp, #-8]
    // 0x54dab8: stur            x3, [fp, #-0x20]
    // 0x54dabc: LoadField: r4 = r0->field_37
    //     0x54dabc: ldur            w4, [x0, #0x37]
    // 0x54dac0: DecompressPointer r4
    //     0x54dac0: add             x4, x4, HEAP, lsl #32
    // 0x54dac4: mov             x1, x4
    // 0x54dac8: stur            x4, [fp, #-0x10]
    // 0x54dacc: r2 = Instance_Chapter13Stat
    //     0x54dacc: add             x2, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x54dad0: ldr             x2, [x2, #0x2e0]
    // 0x54dad4: r0 = _getValueOrData()
    //     0x54dad4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dad8: mov             x1, x0
    // 0x54dadc: ldur            x0, [fp, #-0x10]
    // 0x54dae0: LoadField: r2 = r0->field_f
    //     0x54dae0: ldur            w2, [x0, #0xf]
    // 0x54dae4: DecompressPointer r2
    //     0x54dae4: add             x2, x2, HEAP, lsl #32
    // 0x54dae8: cmp             w2, w1
    // 0x54daec: b.ne            #0x54daf8
    // 0x54daf0: r0 = Null
    //     0x54daf0: mov             x0, NULL
    // 0x54daf4: b               #0x54dafc
    // 0x54daf8: mov             x0, x1
    // 0x54dafc: cmp             w0, NULL
    // 0x54db00: b.ne            #0x54db10
    // 0x54db04: r2 = Instance_CustomNum
    //     0x54db04: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54db08: ldr             x2, [x2, #0xaf8]
    // 0x54db0c: b               #0x54db14
    // 0x54db10: mov             x2, x0
    // 0x54db14: ldur            x0, [fp, #-8]
    // 0x54db18: r1 = Instance_CustomNum
    //     0x54db18: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54db1c: ldr             x1, [x1, #0xa70]
    // 0x54db20: r0 = add()
    //     0x54db20: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54db24: mov             x3, x0
    // 0x54db28: ldur            x0, [fp, #-8]
    // 0x54db2c: stur            x3, [fp, #-0x28]
    // 0x54db30: LoadField: r4 = r0->field_37
    //     0x54db30: ldur            w4, [x0, #0x37]
    // 0x54db34: DecompressPointer r4
    //     0x54db34: add             x4, x4, HEAP, lsl #32
    // 0x54db38: mov             x1, x4
    // 0x54db3c: stur            x4, [fp, #-0x10]
    // 0x54db40: r2 = Instance_Chapter13Stat
    //     0x54db40: add             x2, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x54db44: ldr             x2, [x2, #0x310]
    // 0x54db48: r0 = _getValueOrData()
    //     0x54db48: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54db4c: mov             x1, x0
    // 0x54db50: ldur            x0, [fp, #-0x10]
    // 0x54db54: LoadField: r2 = r0->field_f
    //     0x54db54: ldur            w2, [x0, #0xf]
    // 0x54db58: DecompressPointer r2
    //     0x54db58: add             x2, x2, HEAP, lsl #32
    // 0x54db5c: cmp             w2, w1
    // 0x54db60: b.ne            #0x54db6c
    // 0x54db64: r0 = Null
    //     0x54db64: mov             x0, NULL
    // 0x54db68: b               #0x54db70
    // 0x54db6c: mov             x0, x1
    // 0x54db70: cmp             w0, NULL
    // 0x54db74: b.ne            #0x54db84
    // 0x54db78: r2 = Instance_CustomNum
    //     0x54db78: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54db7c: ldr             x2, [x2, #0xaf8]
    // 0x54db80: b               #0x54db88
    // 0x54db84: mov             x2, x0
    // 0x54db88: ldur            x0, [fp, #-8]
    // 0x54db8c: r1 = Instance_CustomNum
    //     0x54db8c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54db90: ldr             x1, [x1, #0xa70]
    // 0x54db94: r0 = add()
    //     0x54db94: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54db98: mov             x3, x0
    // 0x54db9c: ldur            x0, [fp, #-8]
    // 0x54dba0: stur            x3, [fp, #-0x30]
    // 0x54dba4: LoadField: r4 = r0->field_37
    //     0x54dba4: ldur            w4, [x0, #0x37]
    // 0x54dba8: DecompressPointer r4
    //     0x54dba8: add             x4, x4, HEAP, lsl #32
    // 0x54dbac: mov             x1, x4
    // 0x54dbb0: stur            x4, [fp, #-0x10]
    // 0x54dbb4: r2 = Instance_Chapter13Stat
    //     0x54dbb4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x54dbb8: ldr             x2, [x2, #0x360]
    // 0x54dbbc: r0 = _getValueOrData()
    //     0x54dbbc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dbc0: mov             x1, x0
    // 0x54dbc4: ldur            x0, [fp, #-0x10]
    // 0x54dbc8: LoadField: r2 = r0->field_f
    //     0x54dbc8: ldur            w2, [x0, #0xf]
    // 0x54dbcc: DecompressPointer r2
    //     0x54dbcc: add             x2, x2, HEAP, lsl #32
    // 0x54dbd0: cmp             w2, w1
    // 0x54dbd4: b.ne            #0x54dbe0
    // 0x54dbd8: r0 = Null
    //     0x54dbd8: mov             x0, NULL
    // 0x54dbdc: b               #0x54dbe4
    // 0x54dbe0: mov             x0, x1
    // 0x54dbe4: cmp             w0, NULL
    // 0x54dbe8: b.ne            #0x54dbf8
    // 0x54dbec: r2 = Instance_CustomNum
    //     0x54dbec: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54dbf0: ldr             x2, [x2, #0xaf8]
    // 0x54dbf4: b               #0x54dbfc
    // 0x54dbf8: mov             x2, x0
    // 0x54dbfc: ldur            x0, [fp, #-8]
    // 0x54dc00: r1 = Instance_CustomNum
    //     0x54dc00: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54dc04: ldr             x1, [x1, #0xa70]
    // 0x54dc08: r0 = add()
    //     0x54dc08: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54dc0c: mov             x3, x0
    // 0x54dc10: ldur            x0, [fp, #-8]
    // 0x54dc14: stur            x3, [fp, #-0x38]
    // 0x54dc18: LoadField: r4 = r0->field_37
    //     0x54dc18: ldur            w4, [x0, #0x37]
    // 0x54dc1c: DecompressPointer r4
    //     0x54dc1c: add             x4, x4, HEAP, lsl #32
    // 0x54dc20: mov             x1, x4
    // 0x54dc24: stur            x4, [fp, #-0x10]
    // 0x54dc28: r2 = Instance_Chapter13Stat
    //     0x54dc28: add             x2, PP, #0x11, lsl #12  ; [pp+0x11370] Obj!Chapter13Stat@85fa21
    //     0x54dc2c: ldr             x2, [x2, #0x370]
    // 0x54dc30: r0 = _getValueOrData()
    //     0x54dc30: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dc34: mov             x1, x0
    // 0x54dc38: ldur            x0, [fp, #-0x10]
    // 0x54dc3c: LoadField: r2 = r0->field_f
    //     0x54dc3c: ldur            w2, [x0, #0xf]
    // 0x54dc40: DecompressPointer r2
    //     0x54dc40: add             x2, x2, HEAP, lsl #32
    // 0x54dc44: cmp             w2, w1
    // 0x54dc48: b.ne            #0x54dc54
    // 0x54dc4c: r0 = Null
    //     0x54dc4c: mov             x0, NULL
    // 0x54dc50: b               #0x54dc58
    // 0x54dc54: mov             x0, x1
    // 0x54dc58: cmp             w0, NULL
    // 0x54dc5c: b.ne            #0x54dc6c
    // 0x54dc60: r2 = Instance_CustomNum
    //     0x54dc60: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54dc64: ldr             x2, [x2, #0xaf8]
    // 0x54dc68: b               #0x54dc70
    // 0x54dc6c: mov             x2, x0
    // 0x54dc70: ldur            x0, [fp, #-8]
    // 0x54dc74: r1 = Instance_CustomNum
    //     0x54dc74: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54dc78: ldr             x1, [x1, #0xa70]
    // 0x54dc7c: r0 = add()
    //     0x54dc7c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54dc80: mov             x3, x0
    // 0x54dc84: ldur            x0, [fp, #-8]
    // 0x54dc88: stur            x3, [fp, #-0x40]
    // 0x54dc8c: LoadField: r4 = r0->field_37
    //     0x54dc8c: ldur            w4, [x0, #0x37]
    // 0x54dc90: DecompressPointer r4
    //     0x54dc90: add             x4, x4, HEAP, lsl #32
    // 0x54dc94: mov             x1, x4
    // 0x54dc98: stur            x4, [fp, #-0x10]
    // 0x54dc9c: r2 = Instance_Chapter13Stat
    //     0x54dc9c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11330] Obj!Chapter13Stat@85faa1
    //     0x54dca0: ldr             x2, [x2, #0x330]
    // 0x54dca4: r0 = _getValueOrData()
    //     0x54dca4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dca8: mov             x1, x0
    // 0x54dcac: ldur            x0, [fp, #-0x10]
    // 0x54dcb0: LoadField: r2 = r0->field_f
    //     0x54dcb0: ldur            w2, [x0, #0xf]
    // 0x54dcb4: DecompressPointer r2
    //     0x54dcb4: add             x2, x2, HEAP, lsl #32
    // 0x54dcb8: cmp             w2, w1
    // 0x54dcbc: b.ne            #0x54dcc8
    // 0x54dcc0: r0 = Null
    //     0x54dcc0: mov             x0, NULL
    // 0x54dcc4: b               #0x54dccc
    // 0x54dcc8: mov             x0, x1
    // 0x54dccc: cmp             w0, NULL
    // 0x54dcd0: b.ne            #0x54dce0
    // 0x54dcd4: r2 = Instance_CustomNum
    //     0x54dcd4: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54dcd8: ldr             x2, [x2, #0xaf8]
    // 0x54dcdc: b               #0x54dce4
    // 0x54dce0: mov             x2, x0
    // 0x54dce4: ldur            x0, [fp, #-8]
    // 0x54dce8: r1 = Instance_CustomNum
    //     0x54dce8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54dcec: ldr             x1, [x1, #0xa70]
    // 0x54dcf0: r0 = add()
    //     0x54dcf0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54dcf4: mov             x3, x0
    // 0x54dcf8: ldur            x0, [fp, #-8]
    // 0x54dcfc: stur            x3, [fp, #-0x48]
    // 0x54dd00: LoadField: r4 = r0->field_37
    //     0x54dd00: ldur            w4, [x0, #0x37]
    // 0x54dd04: DecompressPointer r4
    //     0x54dd04: add             x4, x4, HEAP, lsl #32
    // 0x54dd08: mov             x1, x4
    // 0x54dd0c: stur            x4, [fp, #-0x10]
    // 0x54dd10: r2 = Instance_Chapter13Stat
    //     0x54dd10: add             x2, PP, #0x11, lsl #12  ; [pp+0x11350] Obj!Chapter13Stat@85fa61
    //     0x54dd14: ldr             x2, [x2, #0x350]
    // 0x54dd18: r0 = _getValueOrData()
    //     0x54dd18: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dd1c: mov             x1, x0
    // 0x54dd20: ldur            x0, [fp, #-0x10]
    // 0x54dd24: LoadField: r2 = r0->field_f
    //     0x54dd24: ldur            w2, [x0, #0xf]
    // 0x54dd28: DecompressPointer r2
    //     0x54dd28: add             x2, x2, HEAP, lsl #32
    // 0x54dd2c: cmp             w2, w1
    // 0x54dd30: b.ne            #0x54dd3c
    // 0x54dd34: r0 = Null
    //     0x54dd34: mov             x0, NULL
    // 0x54dd38: b               #0x54dd40
    // 0x54dd3c: mov             x0, x1
    // 0x54dd40: cmp             w0, NULL
    // 0x54dd44: b.ne            #0x54dd54
    // 0x54dd48: r2 = Instance_CustomNum
    //     0x54dd48: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54dd4c: ldr             x2, [x2, #0xaf8]
    // 0x54dd50: b               #0x54dd58
    // 0x54dd54: mov             x2, x0
    // 0x54dd58: ldur            x0, [fp, #-8]
    // 0x54dd5c: r1 = Instance_CustomNum
    //     0x54dd5c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54dd60: ldr             x1, [x1, #0xa70]
    // 0x54dd64: r0 = add()
    //     0x54dd64: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54dd68: mov             x3, x0
    // 0x54dd6c: ldur            x0, [fp, #-8]
    // 0x54dd70: stur            x3, [fp, #-0x50]
    // 0x54dd74: LoadField: r4 = r0->field_37
    //     0x54dd74: ldur            w4, [x0, #0x37]
    // 0x54dd78: DecompressPointer r4
    //     0x54dd78: add             x4, x4, HEAP, lsl #32
    // 0x54dd7c: mov             x1, x4
    // 0x54dd80: stur            x4, [fp, #-0x10]
    // 0x54dd84: r2 = Instance_Chapter13Stat
    //     0x54dd84: add             x2, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x54dd88: ldr             x2, [x2, #0x300]
    // 0x54dd8c: r0 = _getValueOrData()
    //     0x54dd8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dd90: mov             x1, x0
    // 0x54dd94: ldur            x0, [fp, #-0x10]
    // 0x54dd98: LoadField: r2 = r0->field_f
    //     0x54dd98: ldur            w2, [x0, #0xf]
    // 0x54dd9c: DecompressPointer r2
    //     0x54dd9c: add             x2, x2, HEAP, lsl #32
    // 0x54dda0: cmp             w2, w1
    // 0x54dda4: b.ne            #0x54ddb0
    // 0x54dda8: r0 = Null
    //     0x54dda8: mov             x0, NULL
    // 0x54ddac: b               #0x54ddb4
    // 0x54ddb0: mov             x0, x1
    // 0x54ddb4: cmp             w0, NULL
    // 0x54ddb8: b.ne            #0x54ddc8
    // 0x54ddbc: r2 = Instance_CustomNum
    //     0x54ddbc: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54ddc0: ldr             x2, [x2, #0xaf8]
    // 0x54ddc4: b               #0x54ddcc
    // 0x54ddc8: mov             x2, x0
    // 0x54ddcc: ldur            x0, [fp, #-8]
    // 0x54ddd0: r1 = Instance_CustomNum
    //     0x54ddd0: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54ddd4: ldr             x1, [x1, #0xa70]
    // 0x54ddd8: r0 = add()
    //     0x54ddd8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54dddc: mov             x3, x0
    // 0x54dde0: ldur            x0, [fp, #-8]
    // 0x54dde4: stur            x3, [fp, #-0x58]
    // 0x54dde8: LoadField: r4 = r0->field_37
    //     0x54dde8: ldur            w4, [x0, #0x37]
    // 0x54ddec: DecompressPointer r4
    //     0x54ddec: add             x4, x4, HEAP, lsl #32
    // 0x54ddf0: mov             x1, x4
    // 0x54ddf4: stur            x4, [fp, #-0x10]
    // 0x54ddf8: r2 = Instance_Chapter13Stat
    //     0x54ddf8: add             x2, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x54ddfc: ldr             x2, [x2, #0x2f0]
    // 0x54de00: r0 = _getValueOrData()
    //     0x54de00: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54de04: mov             x1, x0
    // 0x54de08: ldur            x0, [fp, #-0x10]
    // 0x54de0c: LoadField: r2 = r0->field_f
    //     0x54de0c: ldur            w2, [x0, #0xf]
    // 0x54de10: DecompressPointer r2
    //     0x54de10: add             x2, x2, HEAP, lsl #32
    // 0x54de14: cmp             w2, w1
    // 0x54de18: b.ne            #0x54de24
    // 0x54de1c: r0 = Null
    //     0x54de1c: mov             x0, NULL
    // 0x54de20: b               #0x54de28
    // 0x54de24: mov             x0, x1
    // 0x54de28: cmp             w0, NULL
    // 0x54de2c: b.ne            #0x54de3c
    // 0x54de30: r2 = Instance_CustomNum
    //     0x54de30: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54de34: ldr             x2, [x2, #0xaf8]
    // 0x54de38: b               #0x54de40
    // 0x54de3c: mov             x2, x0
    // 0x54de40: ldur            x0, [fp, #-8]
    // 0x54de44: r1 = Instance_CustomNum
    //     0x54de44: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54de48: ldr             x1, [x1, #0xa70]
    // 0x54de4c: r0 = add()
    //     0x54de4c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54de50: ldur            x16, [fp, #-0x50]
    // 0x54de54: ldur            lr, [fp, #-0x58]
    // 0x54de58: stp             lr, x16, [SP, #8]
    // 0x54de5c: str             x0, [SP]
    // 0x54de60: ldur            x1, [fp, #-0x20]
    // 0x54de64: ldur            x2, [fp, #-0x28]
    // 0x54de68: ldur            x3, [fp, #-0x30]
    // 0x54de6c: ldur            x5, [fp, #-0x38]
    // 0x54de70: ldur            x6, [fp, #-0x40]
    // 0x54de74: ldur            x7, [fp, #-0x48]
    // 0x54de78: r0 = mult9()
    //     0x54de78: bl              #0x54e5d8  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult9
    // 0x54de7c: mov             x1, x0
    // 0x54de80: r2 = Instance_CustomNum
    //     0x54de80: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54de84: ldr             x2, [x2, #0xa70]
    // 0x54de88: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x54de88: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x54de8c: r0 = subtract()
    //     0x54de8c: bl              #0x539f28  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::subtract
    // 0x54de90: mov             x3, x0
    // 0x54de94: ldur            x0, [fp, #-8]
    // 0x54de98: stur            x3, [fp, #-0x20]
    // 0x54de9c: LoadField: r1 = r0->field_3f
    //     0x54de9c: ldur            w1, [x0, #0x3f]
    // 0x54dea0: DecompressPointer r1
    //     0x54dea0: add             x1, x1, HEAP, lsl #32
    // 0x54dea4: LoadField: r0 = r1->field_b
    //     0x54dea4: ldur            w0, [x1, #0xb]
    // 0x54dea8: DecompressPointer r0
    //     0x54dea8: add             x0, x0, HEAP, lsl #32
    // 0x54deac: mov             x1, x0
    // 0x54deb0: stur            x0, [fp, #-0x10]
    // 0x54deb4: r2 = 2
    //     0x54deb4: movz            x2, #0x2
    // 0x54deb8: r0 = _getValueOrData()
    //     0x54deb8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54debc: mov             x1, x0
    // 0x54dec0: ldur            x0, [fp, #-0x10]
    // 0x54dec4: LoadField: r2 = r0->field_f
    //     0x54dec4: ldur            w2, [x0, #0xf]
    // 0x54dec8: DecompressPointer r2
    //     0x54dec8: add             x2, x2, HEAP, lsl #32
    // 0x54decc: cmp             w2, w1
    // 0x54ded0: b.ne            #0x54dedc
    // 0x54ded4: r0 = Null
    //     0x54ded4: mov             x0, NULL
    // 0x54ded8: b               #0x54dee0
    // 0x54dedc: mov             x0, x1
    // 0x54dee0: cmp             w0, NULL
    // 0x54dee4: b.ne            #0x54def0
    // 0x54dee8: r2 = 0
    //     0x54dee8: movz            x2, #0
    // 0x54deec: b               #0x54df00
    // 0x54def0: r1 = LoadInt32Instr(r0)
    //     0x54def0: sbfx            x1, x0, #1, #0x1f
    //     0x54def4: tbz             w0, #0, #0x54defc
    //     0x54def8: ldur            x1, [x0, #7]
    // 0x54defc: mov             x2, x1
    // 0x54df00: r0 = BoxInt64Instr(r2)
    //     0x54df00: sbfiz           x0, x2, #1, #0x1f
    //     0x54df04: cmp             x2, x0, asr #1
    //     0x54df08: b.eq            #0x54df14
    //     0x54df0c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54df10: stur            x2, [x0, #7]
    // 0x54df14: mov             x2, x0
    // 0x54df18: r1 = Instance_CustomNum
    //     0x54df18: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x54df1c: ldr             x1, [x1, #0x970]
    // 0x54df20: r0 = pow()
    //     0x54df20: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x54df24: ldur            x1, [fp, #-0x20]
    // 0x54df28: mov             x2, x0
    // 0x54df2c: r0 = mult2()
    //     0x54df2c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54df30: ldur            x1, [fp, #-0x18]
    // 0x54df34: ArrayStore: r1[1] = r0  ; List_4
    //     0x54df34: add             x25, x1, #0x13
    //     0x54df38: str             w0, [x25]
    //     0x54df3c: tbz             w0, #0, #0x54df58
    //     0x54df40: ldurb           w16, [x1, #-1]
    //     0x54df44: ldurb           w17, [x0, #-1]
    //     0x54df48: and             x16, x17, x16, lsr #2
    //     0x54df4c: tst             x16, HEAP, lsr #32
    //     0x54df50: b.eq            #0x54df58
    //     0x54df54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x54df58: r16 = <Chapter13Stat, CustomNum>
    //     0x54df58: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6c8] TypeArguments: <Chapter13Stat, CustomNum>
    //     0x54df5c: ldr             x16, [x16, #0x6c8]
    // 0x54df60: ldur            lr, [fp, #-0x18]
    // 0x54df64: stp             lr, x16, [SP]
    // 0x54df68: r0 = Map._fromLiteral()
    //     0x54df68: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54df6c: LeaveFrame
    //     0x54df6c: mov             SP, fp
    //     0x54df70: ldp             fp, lr, [SP], #0x10
    // 0x54df74: ret
    //     0x54df74: ret             
    // 0x54df78: r1 = Null
    //     0x54df78: mov             x1, NULL
    // 0x54df7c: r2 = 4
    //     0x54df7c: movz            x2, #0x4
    // 0x54df80: r0 = AllocateArray()
    //     0x54df80: bl              #0x82746c  ; AllocateArrayStub
    // 0x54df84: stur            x0, [fp, #-0x18]
    // 0x54df88: r16 = Instance_Chapter13Stat
    //     0x54df88: add             x16, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x54df8c: ldr             x16, [x16, #0x298]
    // 0x54df90: StoreField: r0->field_f = r16
    //     0x54df90: stur            w16, [x0, #0xf]
    // 0x54df94: ldur            x3, [fp, #-8]
    // 0x54df98: LoadField: r4 = r3->field_37
    //     0x54df98: ldur            w4, [x3, #0x37]
    // 0x54df9c: DecompressPointer r4
    //     0x54df9c: add             x4, x4, HEAP, lsl #32
    // 0x54dfa0: mov             x1, x4
    // 0x54dfa4: stur            x4, [fp, #-0x10]
    // 0x54dfa8: r2 = Instance_Chapter13Stat
    //     0x54dfa8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11340] Obj!Chapter13Stat@85fa81
    //     0x54dfac: ldr             x2, [x2, #0x340]
    // 0x54dfb0: r0 = _getValueOrData()
    //     0x54dfb0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54dfb4: mov             x1, x0
    // 0x54dfb8: ldur            x0, [fp, #-0x10]
    // 0x54dfbc: LoadField: r2 = r0->field_f
    //     0x54dfbc: ldur            w2, [x0, #0xf]
    // 0x54dfc0: DecompressPointer r2
    //     0x54dfc0: add             x2, x2, HEAP, lsl #32
    // 0x54dfc4: cmp             w2, w1
    // 0x54dfc8: b.ne            #0x54dfd4
    // 0x54dfcc: r0 = Null
    //     0x54dfcc: mov             x0, NULL
    // 0x54dfd0: b               #0x54dfd8
    // 0x54dfd4: mov             x0, x1
    // 0x54dfd8: cmp             w0, NULL
    // 0x54dfdc: b.ne            #0x54dfec
    // 0x54dfe0: r2 = Instance_CustomNum
    //     0x54dfe0: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54dfe4: ldr             x2, [x2, #0xaf8]
    // 0x54dfe8: b               #0x54dff0
    // 0x54dfec: mov             x2, x0
    // 0x54dff0: ldur            x0, [fp, #-8]
    // 0x54dff4: r1 = Instance_CustomNum
    //     0x54dff4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54dff8: ldr             x1, [x1, #0xa70]
    // 0x54dffc: r0 = add()
    //     0x54dffc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e000: mov             x3, x0
    // 0x54e004: ldur            x0, [fp, #-8]
    // 0x54e008: stur            x3, [fp, #-0x20]
    // 0x54e00c: LoadField: r4 = r0->field_37
    //     0x54e00c: ldur            w4, [x0, #0x37]
    // 0x54e010: DecompressPointer r4
    //     0x54e010: add             x4, x4, HEAP, lsl #32
    // 0x54e014: mov             x1, x4
    // 0x54e018: stur            x4, [fp, #-0x10]
    // 0x54e01c: r2 = Instance_Chapter13Stat
    //     0x54e01c: add             x2, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x54e020: ldr             x2, [x2, #0x2e0]
    // 0x54e024: r0 = _getValueOrData()
    //     0x54e024: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e028: mov             x1, x0
    // 0x54e02c: ldur            x0, [fp, #-0x10]
    // 0x54e030: LoadField: r2 = r0->field_f
    //     0x54e030: ldur            w2, [x0, #0xf]
    // 0x54e034: DecompressPointer r2
    //     0x54e034: add             x2, x2, HEAP, lsl #32
    // 0x54e038: cmp             w2, w1
    // 0x54e03c: b.ne            #0x54e048
    // 0x54e040: r0 = Null
    //     0x54e040: mov             x0, NULL
    // 0x54e044: b               #0x54e04c
    // 0x54e048: mov             x0, x1
    // 0x54e04c: cmp             w0, NULL
    // 0x54e050: b.ne            #0x54e060
    // 0x54e054: r2 = Instance_CustomNum
    //     0x54e054: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e058: ldr             x2, [x2, #0xaf8]
    // 0x54e05c: b               #0x54e064
    // 0x54e060: mov             x2, x0
    // 0x54e064: ldur            x0, [fp, #-8]
    // 0x54e068: r1 = Instance_CustomNum
    //     0x54e068: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e06c: ldr             x1, [x1, #0xa70]
    // 0x54e070: r0 = add()
    //     0x54e070: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e074: mov             x3, x0
    // 0x54e078: ldur            x0, [fp, #-8]
    // 0x54e07c: stur            x3, [fp, #-0x28]
    // 0x54e080: LoadField: r4 = r0->field_37
    //     0x54e080: ldur            w4, [x0, #0x37]
    // 0x54e084: DecompressPointer r4
    //     0x54e084: add             x4, x4, HEAP, lsl #32
    // 0x54e088: mov             x1, x4
    // 0x54e08c: stur            x4, [fp, #-0x10]
    // 0x54e090: r2 = Instance_Chapter13Stat
    //     0x54e090: add             x2, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x54e094: ldr             x2, [x2, #0x310]
    // 0x54e098: r0 = _getValueOrData()
    //     0x54e098: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e09c: mov             x1, x0
    // 0x54e0a0: ldur            x0, [fp, #-0x10]
    // 0x54e0a4: LoadField: r2 = r0->field_f
    //     0x54e0a4: ldur            w2, [x0, #0xf]
    // 0x54e0a8: DecompressPointer r2
    //     0x54e0a8: add             x2, x2, HEAP, lsl #32
    // 0x54e0ac: cmp             w2, w1
    // 0x54e0b0: b.ne            #0x54e0bc
    // 0x54e0b4: r0 = Null
    //     0x54e0b4: mov             x0, NULL
    // 0x54e0b8: b               #0x54e0c0
    // 0x54e0bc: mov             x0, x1
    // 0x54e0c0: cmp             w0, NULL
    // 0x54e0c4: b.ne            #0x54e0d4
    // 0x54e0c8: r2 = Instance_CustomNum
    //     0x54e0c8: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e0cc: ldr             x2, [x2, #0xaf8]
    // 0x54e0d0: b               #0x54e0d8
    // 0x54e0d4: mov             x2, x0
    // 0x54e0d8: ldur            x0, [fp, #-8]
    // 0x54e0dc: r1 = Instance_CustomNum
    //     0x54e0dc: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e0e0: ldr             x1, [x1, #0xa70]
    // 0x54e0e4: r0 = add()
    //     0x54e0e4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e0e8: mov             x3, x0
    // 0x54e0ec: ldur            x0, [fp, #-8]
    // 0x54e0f0: stur            x3, [fp, #-0x30]
    // 0x54e0f4: LoadField: r4 = r0->field_37
    //     0x54e0f4: ldur            w4, [x0, #0x37]
    // 0x54e0f8: DecompressPointer r4
    //     0x54e0f8: add             x4, x4, HEAP, lsl #32
    // 0x54e0fc: mov             x1, x4
    // 0x54e100: stur            x4, [fp, #-0x10]
    // 0x54e104: r2 = Instance_Chapter13Stat
    //     0x54e104: add             x2, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x54e108: ldr             x2, [x2, #0x360]
    // 0x54e10c: r0 = _getValueOrData()
    //     0x54e10c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e110: mov             x1, x0
    // 0x54e114: ldur            x0, [fp, #-0x10]
    // 0x54e118: LoadField: r2 = r0->field_f
    //     0x54e118: ldur            w2, [x0, #0xf]
    // 0x54e11c: DecompressPointer r2
    //     0x54e11c: add             x2, x2, HEAP, lsl #32
    // 0x54e120: cmp             w2, w1
    // 0x54e124: b.ne            #0x54e130
    // 0x54e128: r0 = Null
    //     0x54e128: mov             x0, NULL
    // 0x54e12c: b               #0x54e134
    // 0x54e130: mov             x0, x1
    // 0x54e134: cmp             w0, NULL
    // 0x54e138: b.ne            #0x54e148
    // 0x54e13c: r2 = Instance_CustomNum
    //     0x54e13c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e140: ldr             x2, [x2, #0xaf8]
    // 0x54e144: b               #0x54e14c
    // 0x54e148: mov             x2, x0
    // 0x54e14c: ldur            x0, [fp, #-8]
    // 0x54e150: r1 = Instance_CustomNum
    //     0x54e150: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e154: ldr             x1, [x1, #0xa70]
    // 0x54e158: r0 = add()
    //     0x54e158: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e15c: mov             x3, x0
    // 0x54e160: ldur            x0, [fp, #-8]
    // 0x54e164: stur            x3, [fp, #-0x38]
    // 0x54e168: LoadField: r4 = r0->field_37
    //     0x54e168: ldur            w4, [x0, #0x37]
    // 0x54e16c: DecompressPointer r4
    //     0x54e16c: add             x4, x4, HEAP, lsl #32
    // 0x54e170: mov             x1, x4
    // 0x54e174: stur            x4, [fp, #-0x10]
    // 0x54e178: r2 = Instance_Chapter13Stat
    //     0x54e178: add             x2, PP, #0x11, lsl #12  ; [pp+0x11370] Obj!Chapter13Stat@85fa21
    //     0x54e17c: ldr             x2, [x2, #0x370]
    // 0x54e180: r0 = _getValueOrData()
    //     0x54e180: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e184: mov             x1, x0
    // 0x54e188: ldur            x0, [fp, #-0x10]
    // 0x54e18c: LoadField: r2 = r0->field_f
    //     0x54e18c: ldur            w2, [x0, #0xf]
    // 0x54e190: DecompressPointer r2
    //     0x54e190: add             x2, x2, HEAP, lsl #32
    // 0x54e194: cmp             w2, w1
    // 0x54e198: b.ne            #0x54e1a4
    // 0x54e19c: r0 = Null
    //     0x54e19c: mov             x0, NULL
    // 0x54e1a0: b               #0x54e1a8
    // 0x54e1a4: mov             x0, x1
    // 0x54e1a8: cmp             w0, NULL
    // 0x54e1ac: b.ne            #0x54e1bc
    // 0x54e1b0: r2 = Instance_CustomNum
    //     0x54e1b0: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e1b4: ldr             x2, [x2, #0xaf8]
    // 0x54e1b8: b               #0x54e1c0
    // 0x54e1bc: mov             x2, x0
    // 0x54e1c0: ldur            x0, [fp, #-8]
    // 0x54e1c4: r1 = Instance_CustomNum
    //     0x54e1c4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e1c8: ldr             x1, [x1, #0xa70]
    // 0x54e1cc: r0 = add()
    //     0x54e1cc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e1d0: mov             x3, x0
    // 0x54e1d4: ldur            x0, [fp, #-8]
    // 0x54e1d8: stur            x3, [fp, #-0x40]
    // 0x54e1dc: LoadField: r4 = r0->field_37
    //     0x54e1dc: ldur            w4, [x0, #0x37]
    // 0x54e1e0: DecompressPointer r4
    //     0x54e1e0: add             x4, x4, HEAP, lsl #32
    // 0x54e1e4: mov             x1, x4
    // 0x54e1e8: stur            x4, [fp, #-0x10]
    // 0x54e1ec: r2 = Instance_Chapter13Stat
    //     0x54e1ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11330] Obj!Chapter13Stat@85faa1
    //     0x54e1f0: ldr             x2, [x2, #0x330]
    // 0x54e1f4: r0 = _getValueOrData()
    //     0x54e1f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e1f8: mov             x1, x0
    // 0x54e1fc: ldur            x0, [fp, #-0x10]
    // 0x54e200: LoadField: r2 = r0->field_f
    //     0x54e200: ldur            w2, [x0, #0xf]
    // 0x54e204: DecompressPointer r2
    //     0x54e204: add             x2, x2, HEAP, lsl #32
    // 0x54e208: cmp             w2, w1
    // 0x54e20c: b.ne            #0x54e218
    // 0x54e210: r0 = Null
    //     0x54e210: mov             x0, NULL
    // 0x54e214: b               #0x54e21c
    // 0x54e218: mov             x0, x1
    // 0x54e21c: cmp             w0, NULL
    // 0x54e220: b.ne            #0x54e230
    // 0x54e224: r2 = Instance_CustomNum
    //     0x54e224: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e228: ldr             x2, [x2, #0xaf8]
    // 0x54e22c: b               #0x54e234
    // 0x54e230: mov             x2, x0
    // 0x54e234: ldur            x0, [fp, #-8]
    // 0x54e238: r1 = Instance_CustomNum
    //     0x54e238: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e23c: ldr             x1, [x1, #0xa70]
    // 0x54e240: r0 = add()
    //     0x54e240: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e244: mov             x3, x0
    // 0x54e248: ldur            x0, [fp, #-8]
    // 0x54e24c: stur            x3, [fp, #-0x48]
    // 0x54e250: LoadField: r4 = r0->field_37
    //     0x54e250: ldur            w4, [x0, #0x37]
    // 0x54e254: DecompressPointer r4
    //     0x54e254: add             x4, x4, HEAP, lsl #32
    // 0x54e258: mov             x1, x4
    // 0x54e25c: stur            x4, [fp, #-0x10]
    // 0x54e260: r2 = Instance_Chapter13Stat
    //     0x54e260: add             x2, PP, #0x11, lsl #12  ; [pp+0x11350] Obj!Chapter13Stat@85fa61
    //     0x54e264: ldr             x2, [x2, #0x350]
    // 0x54e268: r0 = _getValueOrData()
    //     0x54e268: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e26c: mov             x1, x0
    // 0x54e270: ldur            x0, [fp, #-0x10]
    // 0x54e274: LoadField: r2 = r0->field_f
    //     0x54e274: ldur            w2, [x0, #0xf]
    // 0x54e278: DecompressPointer r2
    //     0x54e278: add             x2, x2, HEAP, lsl #32
    // 0x54e27c: cmp             w2, w1
    // 0x54e280: b.ne            #0x54e28c
    // 0x54e284: r0 = Null
    //     0x54e284: mov             x0, NULL
    // 0x54e288: b               #0x54e290
    // 0x54e28c: mov             x0, x1
    // 0x54e290: cmp             w0, NULL
    // 0x54e294: b.ne            #0x54e2a4
    // 0x54e298: r2 = Instance_CustomNum
    //     0x54e298: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e29c: ldr             x2, [x2, #0xaf8]
    // 0x54e2a0: b               #0x54e2a8
    // 0x54e2a4: mov             x2, x0
    // 0x54e2a8: ldur            x0, [fp, #-8]
    // 0x54e2ac: r1 = Instance_CustomNum
    //     0x54e2ac: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e2b0: ldr             x1, [x1, #0xa70]
    // 0x54e2b4: r0 = add()
    //     0x54e2b4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e2b8: mov             x3, x0
    // 0x54e2bc: ldur            x0, [fp, #-8]
    // 0x54e2c0: stur            x3, [fp, #-0x50]
    // 0x54e2c4: LoadField: r4 = r0->field_37
    //     0x54e2c4: ldur            w4, [x0, #0x37]
    // 0x54e2c8: DecompressPointer r4
    //     0x54e2c8: add             x4, x4, HEAP, lsl #32
    // 0x54e2cc: mov             x1, x4
    // 0x54e2d0: stur            x4, [fp, #-0x10]
    // 0x54e2d4: r2 = Instance_Chapter13Stat
    //     0x54e2d4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x54e2d8: ldr             x2, [x2, #0x300]
    // 0x54e2dc: r0 = _getValueOrData()
    //     0x54e2dc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e2e0: mov             x1, x0
    // 0x54e2e4: ldur            x0, [fp, #-0x10]
    // 0x54e2e8: LoadField: r2 = r0->field_f
    //     0x54e2e8: ldur            w2, [x0, #0xf]
    // 0x54e2ec: DecompressPointer r2
    //     0x54e2ec: add             x2, x2, HEAP, lsl #32
    // 0x54e2f0: cmp             w2, w1
    // 0x54e2f4: b.ne            #0x54e300
    // 0x54e2f8: r0 = Null
    //     0x54e2f8: mov             x0, NULL
    // 0x54e2fc: b               #0x54e304
    // 0x54e300: mov             x0, x1
    // 0x54e304: cmp             w0, NULL
    // 0x54e308: b.ne            #0x54e318
    // 0x54e30c: r2 = Instance_CustomNum
    //     0x54e30c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e310: ldr             x2, [x2, #0xaf8]
    // 0x54e314: b               #0x54e31c
    // 0x54e318: mov             x2, x0
    // 0x54e31c: ldur            x0, [fp, #-8]
    // 0x54e320: r1 = Instance_CustomNum
    //     0x54e320: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e324: ldr             x1, [x1, #0xa70]
    // 0x54e328: r0 = add()
    //     0x54e328: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e32c: mov             x3, x0
    // 0x54e330: ldur            x0, [fp, #-8]
    // 0x54e334: stur            x3, [fp, #-0x58]
    // 0x54e338: LoadField: r4 = r0->field_37
    //     0x54e338: ldur            w4, [x0, #0x37]
    // 0x54e33c: DecompressPointer r4
    //     0x54e33c: add             x4, x4, HEAP, lsl #32
    // 0x54e340: mov             x1, x4
    // 0x54e344: stur            x4, [fp, #-0x10]
    // 0x54e348: r2 = Instance_Chapter13Stat
    //     0x54e348: add             x2, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x54e34c: ldr             x2, [x2, #0x320]
    // 0x54e350: r0 = _getValueOrData()
    //     0x54e350: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e354: mov             x1, x0
    // 0x54e358: ldur            x0, [fp, #-0x10]
    // 0x54e35c: LoadField: r2 = r0->field_f
    //     0x54e35c: ldur            w2, [x0, #0xf]
    // 0x54e360: DecompressPointer r2
    //     0x54e360: add             x2, x2, HEAP, lsl #32
    // 0x54e364: cmp             w2, w1
    // 0x54e368: b.ne            #0x54e374
    // 0x54e36c: r0 = Null
    //     0x54e36c: mov             x0, NULL
    // 0x54e370: b               #0x54e378
    // 0x54e374: mov             x0, x1
    // 0x54e378: cmp             w0, NULL
    // 0x54e37c: b.ne            #0x54e38c
    // 0x54e380: r2 = Instance_CustomNum
    //     0x54e380: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e384: ldr             x2, [x2, #0xaf8]
    // 0x54e388: b               #0x54e390
    // 0x54e38c: mov             x2, x0
    // 0x54e390: ldur            x0, [fp, #-8]
    // 0x54e394: r1 = Instance_CustomNum
    //     0x54e394: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e398: ldr             x1, [x1, #0xa70]
    // 0x54e39c: r0 = add()
    //     0x54e39c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e3a0: mov             x3, x0
    // 0x54e3a4: ldur            x0, [fp, #-8]
    // 0x54e3a8: stur            x3, [fp, #-0x60]
    // 0x54e3ac: LoadField: r4 = r0->field_37
    //     0x54e3ac: ldur            w4, [x0, #0x37]
    // 0x54e3b0: DecompressPointer r4
    //     0x54e3b0: add             x4, x4, HEAP, lsl #32
    // 0x54e3b4: mov             x1, x4
    // 0x54e3b8: stur            x4, [fp, #-0x10]
    // 0x54e3bc: r2 = Instance_Chapter13Stat
    //     0x54e3bc: add             x2, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x54e3c0: ldr             x2, [x2, #0x2f0]
    // 0x54e3c4: r0 = _getValueOrData()
    //     0x54e3c4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e3c8: mov             x1, x0
    // 0x54e3cc: ldur            x0, [fp, #-0x10]
    // 0x54e3d0: LoadField: r2 = r0->field_f
    //     0x54e3d0: ldur            w2, [x0, #0xf]
    // 0x54e3d4: DecompressPointer r2
    //     0x54e3d4: add             x2, x2, HEAP, lsl #32
    // 0x54e3d8: cmp             w2, w1
    // 0x54e3dc: b.ne            #0x54e3e8
    // 0x54e3e0: r0 = Null
    //     0x54e3e0: mov             x0, NULL
    // 0x54e3e4: b               #0x54e3ec
    // 0x54e3e8: mov             x0, x1
    // 0x54e3ec: cmp             w0, NULL
    // 0x54e3f0: b.ne            #0x54e400
    // 0x54e3f4: r2 = Instance_CustomNum
    //     0x54e3f4: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54e3f8: ldr             x2, [x2, #0xaf8]
    // 0x54e3fc: b               #0x54e404
    // 0x54e400: mov             x2, x0
    // 0x54e404: ldur            x0, [fp, #-8]
    // 0x54e408: r1 = Instance_CustomNum
    //     0x54e408: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e40c: ldr             x1, [x1, #0xa70]
    // 0x54e410: r0 = add()
    //     0x54e410: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54e414: ldur            x16, [fp, #-0x50]
    // 0x54e418: ldur            lr, [fp, #-0x58]
    // 0x54e41c: stp             lr, x16, [SP, #0x10]
    // 0x54e420: ldur            x16, [fp, #-0x60]
    // 0x54e424: stp             x0, x16, [SP]
    // 0x54e428: ldur            x1, [fp, #-0x20]
    // 0x54e42c: ldur            x2, [fp, #-0x28]
    // 0x54e430: ldur            x3, [fp, #-0x30]
    // 0x54e434: ldur            x5, [fp, #-0x38]
    // 0x54e438: ldur            x6, [fp, #-0x40]
    // 0x54e43c: ldur            x7, [fp, #-0x48]
    // 0x54e440: r0 = mult10()
    //     0x54e440: bl              #0x54e548  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult10
    // 0x54e444: mov             x1, x0
    // 0x54e448: r2 = Instance_CustomNum
    //     0x54e448: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54e44c: ldr             x2, [x2, #0xa70]
    // 0x54e450: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x54e450: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x54e454: r0 = subtract()
    //     0x54e454: bl              #0x539f28  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::subtract
    // 0x54e458: mov             x3, x0
    // 0x54e45c: ldur            x0, [fp, #-8]
    // 0x54e460: stur            x3, [fp, #-0x10]
    // 0x54e464: LoadField: r1 = r0->field_3f
    //     0x54e464: ldur            w1, [x0, #0x3f]
    // 0x54e468: DecompressPointer r1
    //     0x54e468: add             x1, x1, HEAP, lsl #32
    // 0x54e46c: LoadField: r0 = r1->field_b
    //     0x54e46c: ldur            w0, [x1, #0xb]
    // 0x54e470: DecompressPointer r0
    //     0x54e470: add             x0, x0, HEAP, lsl #32
    // 0x54e474: mov             x1, x0
    // 0x54e478: stur            x0, [fp, #-8]
    // 0x54e47c: r2 = 2
    //     0x54e47c: movz            x2, #0x2
    // 0x54e480: r0 = _getValueOrData()
    //     0x54e480: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54e484: mov             x1, x0
    // 0x54e488: ldur            x0, [fp, #-8]
    // 0x54e48c: LoadField: r2 = r0->field_f
    //     0x54e48c: ldur            w2, [x0, #0xf]
    // 0x54e490: DecompressPointer r2
    //     0x54e490: add             x2, x2, HEAP, lsl #32
    // 0x54e494: cmp             w2, w1
    // 0x54e498: b.ne            #0x54e4a4
    // 0x54e49c: r0 = Null
    //     0x54e49c: mov             x0, NULL
    // 0x54e4a0: b               #0x54e4a8
    // 0x54e4a4: mov             x0, x1
    // 0x54e4a8: cmp             w0, NULL
    // 0x54e4ac: b.ne            #0x54e4b8
    // 0x54e4b0: r2 = 0
    //     0x54e4b0: movz            x2, #0
    // 0x54e4b4: b               #0x54e4c8
    // 0x54e4b8: r1 = LoadInt32Instr(r0)
    //     0x54e4b8: sbfx            x1, x0, #1, #0x1f
    //     0x54e4bc: tbz             w0, #0, #0x54e4c4
    //     0x54e4c0: ldur            x1, [x0, #7]
    // 0x54e4c4: mov             x2, x1
    // 0x54e4c8: r0 = BoxInt64Instr(r2)
    //     0x54e4c8: sbfiz           x0, x2, #1, #0x1f
    //     0x54e4cc: cmp             x2, x0, asr #1
    //     0x54e4d0: b.eq            #0x54e4dc
    //     0x54e4d4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54e4d8: stur            x2, [x0, #7]
    // 0x54e4dc: mov             x2, x0
    // 0x54e4e0: r1 = Instance_CustomNum
    //     0x54e4e0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x54e4e4: ldr             x1, [x1, #0x970]
    // 0x54e4e8: r0 = pow()
    //     0x54e4e8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x54e4ec: ldur            x1, [fp, #-0x10]
    // 0x54e4f0: mov             x2, x0
    // 0x54e4f4: r0 = mult2()
    //     0x54e4f4: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54e4f8: ldur            x1, [fp, #-0x18]
    // 0x54e4fc: ArrayStore: r1[1] = r0  ; List_4
    //     0x54e4fc: add             x25, x1, #0x13
    //     0x54e500: str             w0, [x25]
    //     0x54e504: tbz             w0, #0, #0x54e520
    //     0x54e508: ldurb           w16, [x1, #-1]
    //     0x54e50c: ldurb           w17, [x0, #-1]
    //     0x54e510: and             x16, x17, x16, lsr #2
    //     0x54e514: tst             x16, HEAP, lsr #32
    //     0x54e518: b.eq            #0x54e520
    //     0x54e51c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x54e520: r16 = <Chapter13Stat, CustomNum>
    //     0x54e520: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6c8] TypeArguments: <Chapter13Stat, CustomNum>
    //     0x54e524: ldr             x16, [x16, #0x6c8]
    // 0x54e528: ldur            lr, [fp, #-0x18]
    // 0x54e52c: stp             lr, x16, [SP]
    // 0x54e530: r0 = Map._fromLiteral()
    //     0x54e530: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54e534: LeaveFrame
    //     0x54e534: mov             SP, fp
    //     0x54e538: ldp             fp, lr, [SP], #0x10
    // 0x54e53c: ret
    //     0x54e53c: ret             
    // 0x54e540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e540: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e544: b               #0x54da10
  }
  _ notifyBought(/* No info */) {
    // ** addr: 0x54fdb8, size: 0xc0
    // 0x54fdb8: EnterFrame
    //     0x54fdb8: stp             fp, lr, [SP, #-0x10]!
    //     0x54fdbc: mov             fp, SP
    // 0x54fdc0: AllocStack(0x30)
    //     0x54fdc0: sub             SP, SP, #0x30
    // 0x54fdc4: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x54fdc4: mov             x0, x1
    //     0x54fdc8: stur            x1, [fp, #-8]
    //     0x54fdcc: stur            x3, [fp, #-0x10]
    // 0x54fdd0: CheckStackOverflow
    //     0x54fdd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54fdd4: cmp             SP, x16
    //     0x54fdd8: b.ls            #0x54fe70
    // 0x54fddc: mov             x1, x0
    // 0x54fde0: r0 = getOnBuyStats()
    //     0x54fde0: bl              #0x54fe78  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getOnBuyStats
    // 0x54fde4: mov             x3, x0
    // 0x54fde8: stur            x3, [fp, #-0x18]
    // 0x54fdec: cmp             w3, NULL
    // 0x54fdf0: b.eq            #0x54fe60
    // 0x54fdf4: ldur            x4, [fp, #-8]
    // 0x54fdf8: ldur            x2, [fp, #-0x10]
    // 0x54fdfc: r0 = BoxInt64Instr(r2)
    //     0x54fdfc: sbfiz           x0, x2, #1, #0x1f
    //     0x54fe00: cmp             x2, x0, asr #1
    //     0x54fe04: b.eq            #0x54fe10
    //     0x54fe08: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54fe0c: stur            x2, [x0, #7]
    // 0x54fe10: mov             x2, x0
    // 0x54fe14: r1 = Null
    //     0x54fe14: mov             x1, NULL
    // 0x54fe18: r0 = CustomNum()
    //     0x54fe18: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x54fe1c: r16 = <Chapter13Stat>
    //     0x54fe1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x54fe20: ldr             x16, [x16, #0xf28]
    // 0x54fe24: ldur            lr, [fp, #-0x18]
    // 0x54fe28: stp             lr, x16, [SP, #8]
    // 0x54fe2c: str             x0, [SP]
    // 0x54fe30: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x54fe30: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x54fe34: r0 = MapOperations.multiplyScaler()
    //     0x54fe34: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x54fe38: ldur            x0, [fp, #-8]
    // 0x54fe3c: LoadField: r1 = r0->field_37
    //     0x54fe3c: ldur            w1, [x0, #0x37]
    // 0x54fe40: DecompressPointer r1
    //     0x54fe40: add             x1, x1, HEAP, lsl #32
    // 0x54fe44: r16 = <Chapter13Stat>
    //     0x54fe44: add             x16, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x54fe48: ldr             x16, [x16, #0xf28]
    // 0x54fe4c: stp             x1, x16, [SP, #8]
    // 0x54fe50: ldur            x16, [fp, #-0x18]
    // 0x54fe54: str             x16, [SP]
    // 0x54fe58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x54fe58: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x54fe5c: r0 = MapOperations.merge()
    //     0x54fe5c: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x54fe60: r0 = Null
    //     0x54fe60: mov             x0, NULL
    // 0x54fe64: LeaveFrame
    //     0x54fe64: mov             SP, fp
    //     0x54fe68: ldp             fp, lr, [SP], #0x10
    // 0x54fe6c: ret
    //     0x54fe6c: ret             
    // 0x54fe70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54fe70: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54fe74: b               #0x54fddc
  }
  _ getOnBuyStats(/* No info */) {
    // ** addr: 0x54fe78, size: 0x27c
    // 0x54fe78: EnterFrame
    //     0x54fe78: stp             fp, lr, [SP, #-0x10]!
    //     0x54fe7c: mov             fp, SP
    // 0x54fe80: AllocStack(0x50)
    //     0x54fe80: sub             SP, SP, #0x50
    // 0x54fe84: SetupParameters(Chapter13GameState this /* r1 => r3, fp-0x18 */)
    //     0x54fe84: mov             x3, x1
    //     0x54fe88: stur            x1, [fp, #-0x18]
    // 0x54fe8c: CheckStackOverflow
    //     0x54fe8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54fe90: cmp             SP, x16
    //     0x54fe94: b.ls            #0x5500d8
    // 0x54fe98: LoadField: r4 = r3->field_93
    //     0x54fe98: ldur            w4, [x3, #0x93]
    // 0x54fe9c: DecompressPointer r4
    //     0x54fe9c: add             x4, x4, HEAP, lsl #32
    // 0x54fea0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x54fea4: cmp             w4, w16
    // 0x54fea8: b.eq            #0x5500e0
    // 0x54feac: stur            x4, [fp, #-0x10]
    // 0x54feb0: r0 = BoxInt64Instr(r2)
    //     0x54feb0: sbfiz           x0, x2, #1, #0x1f
    //     0x54feb4: cmp             x2, x0, asr #1
    //     0x54feb8: b.eq            #0x54fec4
    //     0x54febc: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54fec0: stur            x2, [x0, #7]
    // 0x54fec4: mov             x1, x4
    // 0x54fec8: mov             x2, x0
    // 0x54fecc: stur            x0, [fp, #-8]
    // 0x54fed0: r0 = _getValueOrData()
    //     0x54fed0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54fed4: mov             x1, x0
    // 0x54fed8: ldur            x0, [fp, #-0x10]
    // 0x54fedc: LoadField: r2 = r0->field_f
    //     0x54fedc: ldur            w2, [x0, #0xf]
    // 0x54fee0: DecompressPointer r2
    //     0x54fee0: add             x2, x2, HEAP, lsl #32
    // 0x54fee4: cmp             w2, w1
    // 0x54fee8: b.ne            #0x54fef4
    // 0x54feec: r0 = Null
    //     0x54feec: mov             x0, NULL
    // 0x54fef0: b               #0x54fef8
    // 0x54fef4: mov             x0, x1
    // 0x54fef8: cmp             w0, NULL
    // 0x54fefc: b.ne            #0x54ff08
    // 0x54ff00: r0 = Null
    //     0x54ff00: mov             x0, NULL
    // 0x54ff04: b               #0x54ff14
    // 0x54ff08: LoadField: r1 = r0->field_33
    //     0x54ff08: ldur            w1, [x0, #0x33]
    // 0x54ff0c: DecompressPointer r1
    //     0x54ff0c: add             x1, x1, HEAP, lsl #32
    // 0x54ff10: mov             x0, x1
    // 0x54ff14: stur            x0, [fp, #-0x10]
    // 0x54ff18: cmp             w0, NULL
    // 0x54ff1c: b.eq            #0x5500bc
    // 0x54ff20: r16 = <Chapter13Stat, CustomNum>
    //     0x54ff20: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6c8] TypeArguments: <Chapter13Stat, CustomNum>
    //     0x54ff24: ldr             x16, [x16, #0x6c8]
    // 0x54ff28: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x54ff2c: stp             lr, x16, [SP]
    // 0x54ff30: r0 = Map._fromLiteral()
    //     0x54ff30: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54ff34: mov             x4, x0
    // 0x54ff38: ldur            x0, [fp, #-0x10]
    // 0x54ff3c: stur            x4, [fp, #-0x20]
    // 0x54ff40: LoadField: r2 = r0->field_7
    //     0x54ff40: ldur            w2, [x0, #7]
    // 0x54ff44: DecompressPointer r2
    //     0x54ff44: add             x2, x2, HEAP, lsl #32
    // 0x54ff48: r1 = Null
    //     0x54ff48: mov             x1, NULL
    // 0x54ff4c: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x54ff4c: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x54ff50: r30 = InstantiateTypeArgumentsStub
    //     0x54ff50: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x54ff54: LoadField: r30 = r30->field_7
    //     0x54ff54: ldur            lr, [lr, #7]
    // 0x54ff58: blr             lr
    // 0x54ff5c: mov             x1, x0
    // 0x54ff60: r0 = _CompactEntriesIterable()
    //     0x54ff60: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x54ff64: mov             x1, x0
    // 0x54ff68: ldur            x0, [fp, #-0x10]
    // 0x54ff6c: StoreField: r1->field_b = r0
    //     0x54ff6c: stur            w0, [x1, #0xb]
    // 0x54ff70: r0 = iterator()
    //     0x54ff70: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x54ff74: mov             x2, x0
    // 0x54ff78: ldur            x0, [fp, #-0x20]
    // 0x54ff7c: stur            x2, [fp, #-0x28]
    // 0x54ff80: LoadField: r3 = r0->field_7
    //     0x54ff80: ldur            w3, [x0, #7]
    // 0x54ff84: DecompressPointer r3
    //     0x54ff84: add             x3, x3, HEAP, lsl #32
    // 0x54ff88: stur            x3, [fp, #-0x10]
    // 0x54ff8c: CheckStackOverflow
    //     0x54ff8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54ff90: cmp             SP, x16
    //     0x54ff94: b.ls            #0x5500ec
    // 0x54ff98: mov             x1, x2
    // 0x54ff9c: r0 = moveNext()
    //     0x54ff9c: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x54ffa0: tbnz            w0, #4, #0x550088
    // 0x54ffa4: ldur            x0, [fp, #-0x28]
    // 0x54ffa8: LoadField: r1 = r0->field_2b
    //     0x54ffa8: ldur            w1, [x0, #0x2b]
    // 0x54ffac: DecompressPointer r1
    //     0x54ffac: add             x1, x1, HEAP, lsl #32
    // 0x54ffb0: cmp             w1, NULL
    // 0x54ffb4: b.eq            #0x5500cc
    // 0x54ffb8: LoadField: r4 = r1->field_b
    //     0x54ffb8: ldur            w4, [x1, #0xb]
    // 0x54ffbc: DecompressPointer r4
    //     0x54ffbc: add             x4, x4, HEAP, lsl #32
    // 0x54ffc0: stur            x4, [fp, #-0x30]
    // 0x54ffc4: LoadField: r2 = r1->field_f
    //     0x54ffc4: ldur            w2, [x1, #0xf]
    // 0x54ffc8: DecompressPointer r2
    //     0x54ffc8: add             x2, x2, HEAP, lsl #32
    // 0x54ffcc: r16 = 0.166667
    //     0x54ffcc: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cb08] 0.16666666666666666
    //     0x54ffd0: ldr             x16, [x16, #0xb08]
    // 0x54ffd4: str             x16, [SP]
    // 0x54ffd8: ldur            x1, [fp, #-0x18]
    // 0x54ffdc: mov             x3, x4
    // 0x54ffe0: ldur            x5, [fp, #-8]
    // 0x54ffe4: r4 = const [0, 0x5, 0x1, 0x4, metaBoostPow, 0x4, null]
    //     0x54ffe4: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cb10] List(7) [0, 0x5, 0x1, 0x4, "metaBoostPow", 0x4, Null]
    //     0x54ffe8: ldr             x4, [x4, #0xb10]
    // 0x54ffec: r0 = applyAllBoostsToYields()
    //     0x54ffec: bl              #0x54a950  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::applyAllBoostsToYields
    // 0x54fff0: mov             x3, x0
    // 0x54fff4: ldur            x0, [fp, #-0x30]
    // 0x54fff8: ldur            x2, [fp, #-0x10]
    // 0x54fffc: r1 = Null
    //     0x54fffc: mov             x1, NULL
    // 0x550000: stur            x3, [fp, #-0x38]
    // 0x550004: cmp             w2, NULL
    // 0x550008: b.eq            #0x550028
    // 0x55000c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x55000c: ldur            w4, [x2, #0x17]
    // 0x550010: DecompressPointer r4
    //     0x550010: add             x4, x4, HEAP, lsl #32
    // 0x550014: r8 = X0
    //     0x550014: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x550018: LoadField: r9 = r4->field_7
    //     0x550018: ldur            x9, [x4, #7]
    // 0x55001c: r3 = Null
    //     0x55001c: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cb18] Null
    //     0x550020: ldr             x3, [x3, #0xb18]
    // 0x550024: blr             x9
    // 0x550028: ldur            x0, [fp, #-0x38]
    // 0x55002c: ldur            x2, [fp, #-0x10]
    // 0x550030: r1 = Null
    //     0x550030: mov             x1, NULL
    // 0x550034: cmp             w2, NULL
    // 0x550038: b.eq            #0x550058
    // 0x55003c: LoadField: r4 = r2->field_1b
    //     0x55003c: ldur            w4, [x2, #0x1b]
    // 0x550040: DecompressPointer r4
    //     0x550040: add             x4, x4, HEAP, lsl #32
    // 0x550044: r8 = X1
    //     0x550044: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x550048: LoadField: r9 = r4->field_7
    //     0x550048: ldur            x9, [x4, #7]
    // 0x55004c: r3 = Null
    //     0x55004c: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cb28] Null
    //     0x550050: ldr             x3, [x3, #0xb28]
    // 0x550054: blr             x9
    // 0x550058: ldur            x1, [fp, #-0x20]
    // 0x55005c: ldur            x2, [fp, #-0x30]
    // 0x550060: r0 = _hashCode()
    //     0x550060: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x550064: ldur            x1, [fp, #-0x20]
    // 0x550068: ldur            x2, [fp, #-0x30]
    // 0x55006c: ldur            x3, [fp, #-0x38]
    // 0x550070: mov             x5, x0
    // 0x550074: r0 = _set()
    //     0x550074: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x550078: ldur            x0, [fp, #-0x20]
    // 0x55007c: ldur            x2, [fp, #-0x28]
    // 0x550080: ldur            x3, [fp, #-0x10]
    // 0x550084: b               #0x54ff8c
    // 0x550088: ldur            x1, [fp, #-0x18]
    // 0x55008c: r0 = getStatBoosts()
    //     0x55008c: bl              #0x55c750  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getStatBoosts
    // 0x550090: r16 = <Chapter13Stat>
    //     0x550090: add             x16, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x550094: ldr             x16, [x16, #0xf28]
    // 0x550098: ldur            lr, [fp, #-0x20]
    // 0x55009c: stp             lr, x16, [SP, #8]
    // 0x5500a0: str             x0, [SP]
    // 0x5500a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5500a4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5500a8: r0 = MapOperations.multiply()
    //     0x5500a8: bl              #0x54a760  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiply
    // 0x5500ac: ldur            x0, [fp, #-0x20]
    // 0x5500b0: LeaveFrame
    //     0x5500b0: mov             SP, fp
    //     0x5500b4: ldp             fp, lr, [SP], #0x10
    // 0x5500b8: ret
    //     0x5500b8: ret             
    // 0x5500bc: r0 = Null
    //     0x5500bc: mov             x0, NULL
    // 0x5500c0: LeaveFrame
    //     0x5500c0: mov             SP, fp
    //     0x5500c4: ldp             fp, lr, [SP], #0x10
    // 0x5500c8: ret
    //     0x5500c8: ret             
    // 0x5500cc: r0 = noElement()
    //     0x5500cc: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x5500d0: r0 = Throw()
    //     0x5500d0: bl              #0x825670  ; ThrowStub
    // 0x5500d4: brk             #0
    // 0x5500d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5500d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5500dc: b               #0x54fe98
    // 0x5500e0: r9 = generators
    //     0x5500e0: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a6d0] Field <Chapter13GameState.generators>: late (offset: 0x94)
    //     0x5500e4: ldr             x9, [x9, #0x6d0]
    // 0x5500e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5500e8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x5500ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5500ec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5500f0: b               #0x54ff98
  }
  _ getGeneratorBaseCost(/* No info */) {
    // ** addr: 0x5560d0, size: 0xfc
    // 0x5560d0: EnterFrame
    //     0x5560d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5560d4: mov             fp, SP
    // 0x5560d8: AllocStack(0x28)
    //     0x5560d8: sub             SP, SP, #0x28
    // 0x5560dc: SetupParameters(Chapter13GameState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x5560dc: mov             x3, x1
    //     0x5560e0: mov             x0, x2
    //     0x5560e4: stur            x1, [fp, #-8]
    //     0x5560e8: stur            x2, [fp, #-0x10]
    // 0x5560ec: CheckStackOverflow
    //     0x5560ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5560f0: cmp             SP, x16
    //     0x5560f4: b.ls            #0x5561c0
    // 0x5560f8: mov             x1, x3
    // 0x5560fc: mov             x2, x0
    // 0x556100: r0 = getGeneratorInfo()
    //     0x556100: bl              #0x80d28c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorInfo
    // 0x556104: LoadField: r3 = r0->field_27
    //     0x556104: ldur            w3, [x0, #0x27]
    // 0x556108: DecompressPointer r3
    //     0x556108: add             x3, x3, HEAP, lsl #32
    // 0x55610c: stur            x3, [fp, #-0x28]
    // 0x556110: cmp             w3, NULL
    // 0x556114: b.eq            #0x5561c8
    // 0x556118: LoadField: r0 = r3->field_b
    //     0x556118: ldur            w0, [x3, #0xb]
    // 0x55611c: DecompressPointer r0
    //     0x55611c: add             x0, x0, HEAP, lsl #32
    // 0x556120: ldur            x1, [fp, #-8]
    // 0x556124: stur            x0, [fp, #-0x20]
    // 0x556128: LoadField: r4 = r1->field_33
    //     0x556128: ldur            w4, [x1, #0x33]
    // 0x55612c: DecompressPointer r4
    //     0x55612c: add             x4, x4, HEAP, lsl #32
    // 0x556130: mov             x1, x4
    // 0x556134: ldur            x2, [fp, #-0x10]
    // 0x556138: stur            x4, [fp, #-0x18]
    // 0x55613c: r0 = _getValueOrData()
    //     0x55613c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x556140: mov             x1, x0
    // 0x556144: ldur            x0, [fp, #-0x18]
    // 0x556148: LoadField: r2 = r0->field_f
    //     0x556148: ldur            w2, [x0, #0xf]
    // 0x55614c: DecompressPointer r2
    //     0x55614c: add             x2, x2, HEAP, lsl #32
    // 0x556150: cmp             w2, w1
    // 0x556154: b.ne            #0x556160
    // 0x556158: r0 = Null
    //     0x556158: mov             x0, NULL
    // 0x55615c: b               #0x556164
    // 0x556160: mov             x0, x1
    // 0x556164: cmp             w0, NULL
    // 0x556168: b.ne            #0x556174
    // 0x55616c: r0 = Null
    //     0x55616c: mov             x0, NULL
    // 0x556170: b               #0x556180
    // 0x556174: LoadField: r1 = r0->field_b
    //     0x556174: ldur            w1, [x0, #0xb]
    // 0x556178: DecompressPointer r1
    //     0x556178: add             x1, x1, HEAP, lsl #32
    // 0x55617c: mov             x0, x1
    // 0x556180: cmp             w0, NULL
    // 0x556184: b.ne            #0x556194
    // 0x556188: r1 = Instance_CustomNum
    //     0x556188: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55618c: ldr             x1, [x1, #0xa70]
    // 0x556190: b               #0x556198
    // 0x556194: mov             x1, x0
    // 0x556198: ldur            x0, [fp, #-0x28]
    // 0x55619c: LoadField: r2 = r0->field_f
    //     0x55619c: ldur            w2, [x0, #0xf]
    // 0x5561a0: DecompressPointer r2
    //     0x5561a0: add             x2, x2, HEAP, lsl #32
    // 0x5561a4: r0 = mult2()
    //     0x5561a4: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x5561a8: ldur            x2, [fp, #-0x20]
    // 0x5561ac: mov             x3, x0
    // 0x5561b0: r0 = AllocateRecord2()
    //     0x5561b0: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x5561b4: LeaveFrame
    //     0x5561b4: mov             SP, fp
    //     0x5561b8: ldp             fp, lr, [SP], #0x10
    // 0x5561bc: ret
    //     0x5561bc: ret             
    // 0x5561c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5561c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5561c4: b               #0x5560f8
    // 0x5561c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5561c8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55c750, size: 0x104
    // 0x55c750: EnterFrame
    //     0x55c750: stp             fp, lr, [SP, #-0x10]!
    //     0x55c754: mov             fp, SP
    // 0x55c758: AllocStack(0x28)
    //     0x55c758: sub             SP, SP, #0x28
    // 0x55c75c: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */)
    //     0x55c75c: mov             x0, x1
    //     0x55c760: stur            x1, [fp, #-8]
    // 0x55c764: CheckStackOverflow
    //     0x55c764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55c768: cmp             SP, x16
    //     0x55c76c: b.ls            #0x55c84c
    // 0x55c770: r1 = Null
    //     0x55c770: mov             x1, NULL
    // 0x55c774: r2 = 4
    //     0x55c774: movz            x2, #0x4
    // 0x55c778: r0 = AllocateArray()
    //     0x55c778: bl              #0x82746c  ; AllocateArrayStub
    // 0x55c77c: stur            x0, [fp, #-0x18]
    // 0x55c780: r16 = Instance_Chapter13Stat
    //     0x55c780: add             x16, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x55c784: ldr             x16, [x16, #0x298]
    // 0x55c788: StoreField: r0->field_f = r16
    //     0x55c788: stur            w16, [x0, #0xf]
    // 0x55c78c: ldur            x1, [fp, #-8]
    // 0x55c790: LoadField: r3 = r1->field_37
    //     0x55c790: ldur            w3, [x1, #0x37]
    // 0x55c794: DecompressPointer r3
    //     0x55c794: add             x3, x3, HEAP, lsl #32
    // 0x55c798: mov             x1, x3
    // 0x55c79c: stur            x3, [fp, #-0x10]
    // 0x55c7a0: r2 = Instance_Chapter13Stat
    //     0x55c7a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x55c7a4: ldr             x2, [x2, #0x380]
    // 0x55c7a8: r0 = _getValueOrData()
    //     0x55c7a8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c7ac: mov             x1, x0
    // 0x55c7b0: ldur            x0, [fp, #-0x10]
    // 0x55c7b4: LoadField: r2 = r0->field_f
    //     0x55c7b4: ldur            w2, [x0, #0xf]
    // 0x55c7b8: DecompressPointer r2
    //     0x55c7b8: add             x2, x2, HEAP, lsl #32
    // 0x55c7bc: cmp             w2, w1
    // 0x55c7c0: b.ne            #0x55c7cc
    // 0x55c7c4: r0 = Null
    //     0x55c7c4: mov             x0, NULL
    // 0x55c7c8: b               #0x55c7d0
    // 0x55c7cc: mov             x0, x1
    // 0x55c7d0: cmp             w0, NULL
    // 0x55c7d4: b.ne            #0x55c7e4
    // 0x55c7d8: r2 = Instance_CustomNum
    //     0x55c7d8: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55c7dc: ldr             x2, [x2, #0xaf8]
    // 0x55c7e0: b               #0x55c7e8
    // 0x55c7e4: mov             x2, x0
    // 0x55c7e8: r1 = Instance_CustomNum
    //     0x55c7e8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55c7ec: ldr             x1, [x1, #0xce0]
    // 0x55c7f0: r0 = mult2()
    //     0x55c7f0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55c7f4: mov             x2, x0
    // 0x55c7f8: r1 = Instance_CustomNum
    //     0x55c7f8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55c7fc: ldr             x1, [x1, #0xa70]
    // 0x55c800: r0 = add()
    //     0x55c800: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55c804: ldur            x1, [fp, #-0x18]
    // 0x55c808: ArrayStore: r1[1] = r0  ; List_4
    //     0x55c808: add             x25, x1, #0x13
    //     0x55c80c: str             w0, [x25]
    //     0x55c810: tbz             w0, #0, #0x55c82c
    //     0x55c814: ldurb           w16, [x1, #-1]
    //     0x55c818: ldurb           w17, [x0, #-1]
    //     0x55c81c: and             x16, x17, x16, lsr #2
    //     0x55c820: tst             x16, HEAP, lsr #32
    //     0x55c824: b.eq            #0x55c82c
    //     0x55c828: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x55c82c: r16 = <Chapter13Stat, CustomNum>
    //     0x55c82c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6c8] TypeArguments: <Chapter13Stat, CustomNum>
    //     0x55c830: ldr             x16, [x16, #0x6c8]
    // 0x55c834: ldur            lr, [fp, #-0x18]
    // 0x55c838: stp             lr, x16, [SP]
    // 0x55c83c: r0 = Map._fromLiteral()
    //     0x55c83c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55c840: LeaveFrame
    //     0x55c840: mov             SP, fp
    //     0x55c844: ldp             fp, lr, [SP], #0x10
    // 0x55c848: ret
    //     0x55c848: ret             
    // 0x55c84c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c84c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c850: b               #0x55c770
  }
  _ checkAllBoosts(/* No info */) {
    // ** addr: 0x689a80, size: 0xbec
    // 0x689a80: EnterFrame
    //     0x689a80: stp             fp, lr, [SP, #-0x10]!
    //     0x689a84: mov             fp, SP
    // 0x689a88: AllocStack(0x20)
    //     0x689a88: sub             SP, SP, #0x20
    // 0x689a8c: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x10 */)
    //     0x689a8c: mov             x0, x1
    //     0x689a90: stur            x1, [fp, #-0x10]
    // 0x689a94: CheckStackOverflow
    //     0x689a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x689a98: cmp             SP, x16
    //     0x689a9c: b.ls            #0x68a664
    // 0x689aa0: LoadField: r1 = r0->field_3f
    //     0x689aa0: ldur            w1, [x0, #0x3f]
    // 0x689aa4: DecompressPointer r1
    //     0x689aa4: add             x1, x1, HEAP, lsl #32
    // 0x689aa8: LoadField: r3 = r1->field_b
    //     0x689aa8: ldur            w3, [x1, #0xb]
    // 0x689aac: DecompressPointer r3
    //     0x689aac: add             x3, x3, HEAP, lsl #32
    // 0x689ab0: mov             x1, x3
    // 0x689ab4: stur            x3, [fp, #-8]
    // 0x689ab8: r2 = 4
    //     0x689ab8: movz            x2, #0x4
    // 0x689abc: r0 = _getValueOrData()
    //     0x689abc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689ac0: mov             x1, x0
    // 0x689ac4: ldur            x0, [fp, #-8]
    // 0x689ac8: LoadField: r2 = r0->field_f
    //     0x689ac8: ldur            w2, [x0, #0xf]
    // 0x689acc: DecompressPointer r2
    //     0x689acc: add             x2, x2, HEAP, lsl #32
    // 0x689ad0: cmp             w2, w1
    // 0x689ad4: b.ne            #0x689ae0
    // 0x689ad8: r0 = Null
    //     0x689ad8: mov             x0, NULL
    // 0x689adc: b               #0x689ae4
    // 0x689ae0: mov             x0, x1
    // 0x689ae4: cmp             w0, NULL
    // 0x689ae8: b.eq            #0x68a440
    // 0x689aec: r1 = LoadInt32Instr(r0)
    //     0x689aec: sbfx            x1, x0, #1, #0x1f
    //     0x689af0: tbz             w0, #0, #0x689af8
    //     0x689af4: ldur            x1, [x0, #7]
    // 0x689af8: stur            x1, [fp, #-0x18]
    // 0x689afc: cmp             x1, #1
    // 0x689b00: b.lt            #0x689b84
    // 0x689b04: ldur            x0, [fp, #-0x10]
    // 0x689b08: LoadField: r2 = r0->field_33
    //     0x689b08: ldur            w2, [x0, #0x33]
    // 0x689b0c: DecompressPointer r2
    //     0x689b0c: add             x2, x2, HEAP, lsl #32
    // 0x689b10: stur            x2, [fp, #-8]
    // 0x689b14: r0 = Boost()
    //     0x689b14: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689b18: mov             x1, x0
    // 0x689b1c: r0 = Instance_CustomNum
    //     0x689b1c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689b20: ldr             x0, [x0, #0xa70]
    // 0x689b24: StoreField: r1->field_7 = r0
    //     0x689b24: stur            w0, [x1, #7]
    // 0x689b28: StoreField: r1->field_b = r0
    //     0x689b28: stur            w0, [x1, #0xb]
    // 0x689b2c: r4 = Instance_CustomNum
    //     0x689b2c: add             x4, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x689b30: ldr             x4, [x4, #0x448]
    // 0x689b34: StoreField: r1->field_f = r4
    //     0x689b34: stur            w4, [x1, #0xf]
    // 0x689b38: StoreField: r1->field_13 = r0
    //     0x689b38: stur            w0, [x1, #0x13]
    // 0x689b3c: mov             x3, x1
    // 0x689b40: ldur            x1, [fp, #-8]
    // 0x689b44: r2 = 2
    //     0x689b44: movz            x2, #0x2
    // 0x689b48: r0 = []=()
    //     0x689b48: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689b4c: r0 = Boost()
    //     0x689b4c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689b50: mov             x1, x0
    // 0x689b54: r0 = Instance_CustomNum
    //     0x689b54: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689b58: ldr             x0, [x0, #0xa70]
    // 0x689b5c: StoreField: r1->field_7 = r0
    //     0x689b5c: stur            w0, [x1, #7]
    // 0x689b60: StoreField: r1->field_b = r0
    //     0x689b60: stur            w0, [x1, #0xb]
    // 0x689b64: r4 = Instance_CustomNum
    //     0x689b64: add             x4, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x689b68: ldr             x4, [x4, #0x448]
    // 0x689b6c: StoreField: r1->field_f = r4
    //     0x689b6c: stur            w4, [x1, #0xf]
    // 0x689b70: StoreField: r1->field_13 = r0
    //     0x689b70: stur            w0, [x1, #0x13]
    // 0x689b74: mov             x3, x1
    // 0x689b78: ldur            x1, [fp, #-8]
    // 0x689b7c: r2 = 82
    //     0x689b7c: movz            x2, #0x52
    // 0x689b80: r0 = []=()
    //     0x689b80: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689b84: ldur            x0, [fp, #-0x18]
    // 0x689b88: cmp             x0, #2
    // 0x689b8c: b.lt            #0x689c10
    // 0x689b90: ldur            x1, [fp, #-0x10]
    // 0x689b94: LoadField: r2 = r1->field_33
    //     0x689b94: ldur            w2, [x1, #0x33]
    // 0x689b98: DecompressPointer r2
    //     0x689b98: add             x2, x2, HEAP, lsl #32
    // 0x689b9c: stur            x2, [fp, #-8]
    // 0x689ba0: r0 = Boost()
    //     0x689ba0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689ba4: mov             x1, x0
    // 0x689ba8: r0 = Instance_CustomNum
    //     0x689ba8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689bac: ldr             x0, [x0, #0xa70]
    // 0x689bb0: StoreField: r1->field_7 = r0
    //     0x689bb0: stur            w0, [x1, #7]
    // 0x689bb4: r4 = Instance_CustomNum
    //     0x689bb4: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x689bb8: ldr             x4, [x4, #0xce0]
    // 0x689bbc: StoreField: r1->field_b = r4
    //     0x689bbc: stur            w4, [x1, #0xb]
    // 0x689bc0: StoreField: r1->field_f = r0
    //     0x689bc0: stur            w0, [x1, #0xf]
    // 0x689bc4: StoreField: r1->field_13 = r0
    //     0x689bc4: stur            w0, [x1, #0x13]
    // 0x689bc8: mov             x3, x1
    // 0x689bcc: ldur            x1, [fp, #-8]
    // 0x689bd0: r2 = 102
    //     0x689bd0: movz            x2, #0x66
    // 0x689bd4: r0 = []=()
    //     0x689bd4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689bd8: r0 = Boost()
    //     0x689bd8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689bdc: mov             x1, x0
    // 0x689be0: r0 = Instance_CustomNum
    //     0x689be0: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689be4: ldr             x0, [x0, #0xa70]
    // 0x689be8: StoreField: r1->field_7 = r0
    //     0x689be8: stur            w0, [x1, #7]
    // 0x689bec: r2 = Instance_CustomNum
    //     0x689bec: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x689bf0: ldr             x2, [x2, #0xce0]
    // 0x689bf4: StoreField: r1->field_b = r2
    //     0x689bf4: stur            w2, [x1, #0xb]
    // 0x689bf8: StoreField: r1->field_f = r0
    //     0x689bf8: stur            w0, [x1, #0xf]
    // 0x689bfc: StoreField: r1->field_13 = r0
    //     0x689bfc: stur            w0, [x1, #0x13]
    // 0x689c00: mov             x3, x1
    // 0x689c04: ldur            x1, [fp, #-8]
    // 0x689c08: r2 = 24
    //     0x689c08: movz            x2, #0x18
    // 0x689c0c: r0 = []=()
    //     0x689c0c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689c10: ldur            x0, [fp, #-0x18]
    // 0x689c14: cmp             x0, #3
    // 0x689c18: b.lt            #0x689cc8
    // 0x689c1c: ldur            x3, [fp, #-0x10]
    // 0x689c20: LoadField: r4 = r3->field_33
    //     0x689c20: ldur            w4, [x3, #0x33]
    // 0x689c24: DecompressPointer r4
    //     0x689c24: add             x4, x4, HEAP, lsl #32
    // 0x689c28: mov             x1, x4
    // 0x689c2c: stur            x4, [fp, #-8]
    // 0x689c30: r2 = 62
    //     0x689c30: movz            x2, #0x3e
    // 0x689c34: r0 = _getValueOrData()
    //     0x689c34: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689c38: ldur            x1, [fp, #-8]
    // 0x689c3c: LoadField: r2 = r1->field_f
    //     0x689c3c: ldur            w2, [x1, #0xf]
    // 0x689c40: DecompressPointer r2
    //     0x689c40: add             x2, x2, HEAP, lsl #32
    // 0x689c44: cmp             w2, w0
    // 0x689c48: b.ne            #0x689c50
    // 0x689c4c: r0 = Null
    //     0x689c4c: mov             x0, NULL
    // 0x689c50: cmp             w0, NULL
    // 0x689c54: b.ne            #0x689c78
    // 0x689c58: r0 = Boost()
    //     0x689c58: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689c5c: r1 = Instance_CustomNum
    //     0x689c5c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689c60: ldr             x1, [x1, #0xa70]
    // 0x689c64: StoreField: r0->field_7 = r1
    //     0x689c64: stur            w1, [x0, #7]
    // 0x689c68: StoreField: r0->field_b = r1
    //     0x689c68: stur            w1, [x0, #0xb]
    // 0x689c6c: StoreField: r0->field_f = r1
    //     0x689c6c: stur            w1, [x0, #0xf]
    // 0x689c70: StoreField: r0->field_13 = r1
    //     0x689c70: stur            w1, [x0, #0x13]
    // 0x689c74: b               #0x689c80
    // 0x689c78: r1 = Instance_CustomNum
    //     0x689c78: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689c7c: ldr             x1, [x1, #0xa70]
    // 0x689c80: stur            x0, [fp, #-0x20]
    // 0x689c84: r0 = Boost()
    //     0x689c84: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689c88: mov             x1, x0
    // 0x689c8c: r0 = Instance_CustomNum
    //     0x689c8c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689c90: ldr             x0, [x0, #0xa70]
    // 0x689c94: StoreField: r1->field_7 = r0
    //     0x689c94: stur            w0, [x1, #7]
    // 0x689c98: StoreField: r1->field_b = r0
    //     0x689c98: stur            w0, [x1, #0xb]
    // 0x689c9c: r3 = Instance_CustomNum
    //     0x689c9c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x689ca0: ldr             x3, [x3, #0xef8]
    // 0x689ca4: StoreField: r1->field_f = r3
    //     0x689ca4: stur            w3, [x1, #0xf]
    // 0x689ca8: StoreField: r1->field_13 = r0
    //     0x689ca8: stur            w0, [x1, #0x13]
    // 0x689cac: mov             x2, x1
    // 0x689cb0: ldur            x1, [fp, #-0x20]
    // 0x689cb4: r0 = *()
    //     0x689cb4: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x689cb8: ldur            x1, [fp, #-8]
    // 0x689cbc: mov             x3, x0
    // 0x689cc0: r2 = 62
    //     0x689cc0: movz            x2, #0x3e
    // 0x689cc4: r0 = []=()
    //     0x689cc4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689cc8: ldur            x0, [fp, #-0x18]
    // 0x689ccc: cmp             x0, #4
    // 0x689cd0: b.lt            #0x689e28
    // 0x689cd4: ldur            x3, [fp, #-0x10]
    // 0x689cd8: LoadField: r4 = r3->field_33
    //     0x689cd8: ldur            w4, [x3, #0x33]
    // 0x689cdc: DecompressPointer r4
    //     0x689cdc: add             x4, x4, HEAP, lsl #32
    // 0x689ce0: mov             x1, x4
    // 0x689ce4: stur            x4, [fp, #-8]
    // 0x689ce8: r2 = 22
    //     0x689ce8: movz            x2, #0x16
    // 0x689cec: r0 = _getValueOrData()
    //     0x689cec: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689cf0: ldur            x1, [fp, #-8]
    // 0x689cf4: LoadField: r2 = r1->field_f
    //     0x689cf4: ldur            w2, [x1, #0xf]
    // 0x689cf8: DecompressPointer r2
    //     0x689cf8: add             x2, x2, HEAP, lsl #32
    // 0x689cfc: cmp             w2, w0
    // 0x689d00: b.ne            #0x689d08
    // 0x689d04: r0 = Null
    //     0x689d04: mov             x0, NULL
    // 0x689d08: cmp             w0, NULL
    // 0x689d0c: b.ne            #0x689d34
    // 0x689d10: r0 = Boost()
    //     0x689d10: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689d14: r1 = Instance_CustomNum
    //     0x689d14: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689d18: ldr             x1, [x1, #0xa70]
    // 0x689d1c: StoreField: r0->field_7 = r1
    //     0x689d1c: stur            w1, [x0, #7]
    // 0x689d20: StoreField: r0->field_b = r1
    //     0x689d20: stur            w1, [x0, #0xb]
    // 0x689d24: StoreField: r0->field_f = r1
    //     0x689d24: stur            w1, [x0, #0xf]
    // 0x689d28: StoreField: r0->field_13 = r1
    //     0x689d28: stur            w1, [x0, #0x13]
    // 0x689d2c: mov             x2, x0
    // 0x689d30: b               #0x689d40
    // 0x689d34: r1 = Instance_CustomNum
    //     0x689d34: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689d38: ldr             x1, [x1, #0xa70]
    // 0x689d3c: mov             x2, x0
    // 0x689d40: ldur            x0, [fp, #-8]
    // 0x689d44: stur            x2, [fp, #-0x20]
    // 0x689d48: r0 = Boost()
    //     0x689d48: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689d4c: mov             x1, x0
    // 0x689d50: r0 = Instance_CustomNum
    //     0x689d50: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689d54: ldr             x0, [x0, #0xa70]
    // 0x689d58: StoreField: r1->field_7 = r0
    //     0x689d58: stur            w0, [x1, #7]
    // 0x689d5c: StoreField: r1->field_b = r0
    //     0x689d5c: stur            w0, [x1, #0xb]
    // 0x689d60: r3 = Instance_CustomNum
    //     0x689d60: add             x3, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x689d64: ldr             x3, [x3, #0x970]
    // 0x689d68: StoreField: r1->field_f = r3
    //     0x689d68: stur            w3, [x1, #0xf]
    // 0x689d6c: StoreField: r1->field_13 = r0
    //     0x689d6c: stur            w0, [x1, #0x13]
    // 0x689d70: mov             x2, x1
    // 0x689d74: ldur            x1, [fp, #-0x20]
    // 0x689d78: r0 = *()
    //     0x689d78: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x689d7c: ldur            x1, [fp, #-8]
    // 0x689d80: mov             x3, x0
    // 0x689d84: r2 = 22
    //     0x689d84: movz            x2, #0x16
    // 0x689d88: r0 = []=()
    //     0x689d88: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689d8c: ldur            x1, [fp, #-8]
    // 0x689d90: r2 = 102
    //     0x689d90: movz            x2, #0x66
    // 0x689d94: r0 = _getValueOrData()
    //     0x689d94: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689d98: ldur            x1, [fp, #-8]
    // 0x689d9c: LoadField: r2 = r1->field_f
    //     0x689d9c: ldur            w2, [x1, #0xf]
    // 0x689da0: DecompressPointer r2
    //     0x689da0: add             x2, x2, HEAP, lsl #32
    // 0x689da4: cmp             w2, w0
    // 0x689da8: b.ne            #0x689db0
    // 0x689dac: r0 = Null
    //     0x689dac: mov             x0, NULL
    // 0x689db0: cmp             w0, NULL
    // 0x689db4: b.ne            #0x689dd8
    // 0x689db8: r0 = Boost()
    //     0x689db8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689dbc: r1 = Instance_CustomNum
    //     0x689dbc: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689dc0: ldr             x1, [x1, #0xa70]
    // 0x689dc4: StoreField: r0->field_7 = r1
    //     0x689dc4: stur            w1, [x0, #7]
    // 0x689dc8: StoreField: r0->field_b = r1
    //     0x689dc8: stur            w1, [x0, #0xb]
    // 0x689dcc: StoreField: r0->field_f = r1
    //     0x689dcc: stur            w1, [x0, #0xf]
    // 0x689dd0: StoreField: r0->field_13 = r1
    //     0x689dd0: stur            w1, [x0, #0x13]
    // 0x689dd4: b               #0x689de0
    // 0x689dd8: r1 = Instance_CustomNum
    //     0x689dd8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689ddc: ldr             x1, [x1, #0xa70]
    // 0x689de0: stur            x0, [fp, #-0x20]
    // 0x689de4: r0 = Boost()
    //     0x689de4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689de8: mov             x1, x0
    // 0x689dec: r0 = Instance_CustomNum
    //     0x689dec: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689df0: ldr             x0, [x0, #0xa70]
    // 0x689df4: StoreField: r1->field_7 = r0
    //     0x689df4: stur            w0, [x1, #7]
    // 0x689df8: StoreField: r1->field_b = r0
    //     0x689df8: stur            w0, [x1, #0xb]
    // 0x689dfc: r2 = Instance_CustomNum
    //     0x689dfc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x689e00: ldr             x2, [x2, #0x970]
    // 0x689e04: StoreField: r1->field_f = r2
    //     0x689e04: stur            w2, [x1, #0xf]
    // 0x689e08: StoreField: r1->field_13 = r0
    //     0x689e08: stur            w0, [x1, #0x13]
    // 0x689e0c: mov             x2, x1
    // 0x689e10: ldur            x1, [fp, #-0x20]
    // 0x689e14: r0 = *()
    //     0x689e14: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x689e18: ldur            x1, [fp, #-8]
    // 0x689e1c: mov             x3, x0
    // 0x689e20: r2 = 102
    //     0x689e20: movz            x2, #0x66
    // 0x689e24: r0 = []=()
    //     0x689e24: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689e28: ldur            x0, [fp, #-0x18]
    // 0x689e2c: cmp             x0, #5
    // 0x689e30: b.lt            #0x689f88
    // 0x689e34: ldur            x3, [fp, #-0x10]
    // 0x689e38: LoadField: r4 = r3->field_33
    //     0x689e38: ldur            w4, [x3, #0x33]
    // 0x689e3c: DecompressPointer r4
    //     0x689e3c: add             x4, x4, HEAP, lsl #32
    // 0x689e40: mov             x1, x4
    // 0x689e44: stur            x4, [fp, #-8]
    // 0x689e48: r2 = 22
    //     0x689e48: movz            x2, #0x16
    // 0x689e4c: r0 = _getValueOrData()
    //     0x689e4c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689e50: ldur            x1, [fp, #-8]
    // 0x689e54: LoadField: r2 = r1->field_f
    //     0x689e54: ldur            w2, [x1, #0xf]
    // 0x689e58: DecompressPointer r2
    //     0x689e58: add             x2, x2, HEAP, lsl #32
    // 0x689e5c: cmp             w2, w0
    // 0x689e60: b.ne            #0x689e68
    // 0x689e64: r0 = Null
    //     0x689e64: mov             x0, NULL
    // 0x689e68: cmp             w0, NULL
    // 0x689e6c: b.ne            #0x689e94
    // 0x689e70: r0 = Boost()
    //     0x689e70: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689e74: r1 = Instance_CustomNum
    //     0x689e74: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689e78: ldr             x1, [x1, #0xa70]
    // 0x689e7c: StoreField: r0->field_7 = r1
    //     0x689e7c: stur            w1, [x0, #7]
    // 0x689e80: StoreField: r0->field_b = r1
    //     0x689e80: stur            w1, [x0, #0xb]
    // 0x689e84: StoreField: r0->field_f = r1
    //     0x689e84: stur            w1, [x0, #0xf]
    // 0x689e88: StoreField: r0->field_13 = r1
    //     0x689e88: stur            w1, [x0, #0x13]
    // 0x689e8c: mov             x2, x0
    // 0x689e90: b               #0x689ea0
    // 0x689e94: r1 = Instance_CustomNum
    //     0x689e94: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689e98: ldr             x1, [x1, #0xa70]
    // 0x689e9c: mov             x2, x0
    // 0x689ea0: ldur            x0, [fp, #-8]
    // 0x689ea4: stur            x2, [fp, #-0x20]
    // 0x689ea8: r0 = Boost()
    //     0x689ea8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689eac: mov             x1, x0
    // 0x689eb0: r0 = Instance_CustomNum
    //     0x689eb0: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689eb4: ldr             x0, [x0, #0xa70]
    // 0x689eb8: StoreField: r1->field_7 = r0
    //     0x689eb8: stur            w0, [x1, #7]
    // 0x689ebc: StoreField: r1->field_b = r0
    //     0x689ebc: stur            w0, [x1, #0xb]
    // 0x689ec0: r3 = Instance_CustomNum
    //     0x689ec0: add             x3, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x689ec4: ldr             x3, [x3, #0x448]
    // 0x689ec8: StoreField: r1->field_f = r3
    //     0x689ec8: stur            w3, [x1, #0xf]
    // 0x689ecc: StoreField: r1->field_13 = r0
    //     0x689ecc: stur            w0, [x1, #0x13]
    // 0x689ed0: mov             x2, x1
    // 0x689ed4: ldur            x1, [fp, #-0x20]
    // 0x689ed8: r0 = *()
    //     0x689ed8: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x689edc: ldur            x1, [fp, #-8]
    // 0x689ee0: mov             x3, x0
    // 0x689ee4: r2 = 22
    //     0x689ee4: movz            x2, #0x16
    // 0x689ee8: r0 = []=()
    //     0x689ee8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689eec: ldur            x1, [fp, #-8]
    // 0x689ef0: r2 = 62
    //     0x689ef0: movz            x2, #0x3e
    // 0x689ef4: r0 = _getValueOrData()
    //     0x689ef4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689ef8: ldur            x1, [fp, #-8]
    // 0x689efc: LoadField: r2 = r1->field_f
    //     0x689efc: ldur            w2, [x1, #0xf]
    // 0x689f00: DecompressPointer r2
    //     0x689f00: add             x2, x2, HEAP, lsl #32
    // 0x689f04: cmp             w2, w0
    // 0x689f08: b.ne            #0x689f10
    // 0x689f0c: r0 = Null
    //     0x689f0c: mov             x0, NULL
    // 0x689f10: cmp             w0, NULL
    // 0x689f14: b.ne            #0x689f38
    // 0x689f18: r0 = Boost()
    //     0x689f18: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689f1c: r1 = Instance_CustomNum
    //     0x689f1c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689f20: ldr             x1, [x1, #0xa70]
    // 0x689f24: StoreField: r0->field_7 = r1
    //     0x689f24: stur            w1, [x0, #7]
    // 0x689f28: StoreField: r0->field_b = r1
    //     0x689f28: stur            w1, [x0, #0xb]
    // 0x689f2c: StoreField: r0->field_f = r1
    //     0x689f2c: stur            w1, [x0, #0xf]
    // 0x689f30: StoreField: r0->field_13 = r1
    //     0x689f30: stur            w1, [x0, #0x13]
    // 0x689f34: b               #0x689f40
    // 0x689f38: r1 = Instance_CustomNum
    //     0x689f38: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689f3c: ldr             x1, [x1, #0xa70]
    // 0x689f40: stur            x0, [fp, #-0x20]
    // 0x689f44: r0 = Boost()
    //     0x689f44: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689f48: mov             x1, x0
    // 0x689f4c: r0 = Instance_CustomNum
    //     0x689f4c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689f50: ldr             x0, [x0, #0xa70]
    // 0x689f54: StoreField: r1->field_7 = r0
    //     0x689f54: stur            w0, [x1, #7]
    // 0x689f58: StoreField: r1->field_b = r0
    //     0x689f58: stur            w0, [x1, #0xb]
    // 0x689f5c: r3 = Instance_CustomNum
    //     0x689f5c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x689f60: ldr             x3, [x3, #0x448]
    // 0x689f64: StoreField: r1->field_f = r3
    //     0x689f64: stur            w3, [x1, #0xf]
    // 0x689f68: StoreField: r1->field_13 = r0
    //     0x689f68: stur            w0, [x1, #0x13]
    // 0x689f6c: mov             x2, x1
    // 0x689f70: ldur            x1, [fp, #-0x20]
    // 0x689f74: r0 = *()
    //     0x689f74: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x689f78: ldur            x1, [fp, #-8]
    // 0x689f7c: mov             x3, x0
    // 0x689f80: r2 = 62
    //     0x689f80: movz            x2, #0x3e
    // 0x689f84: r0 = []=()
    //     0x689f84: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x689f88: ldur            x0, [fp, #-0x18]
    // 0x689f8c: cmp             x0, #6
    // 0x689f90: b.lt            #0x68a0e8
    // 0x689f94: ldur            x3, [fp, #-0x10]
    // 0x689f98: LoadField: r4 = r3->field_33
    //     0x689f98: ldur            w4, [x3, #0x33]
    // 0x689f9c: DecompressPointer r4
    //     0x689f9c: add             x4, x4, HEAP, lsl #32
    // 0x689fa0: mov             x1, x4
    // 0x689fa4: stur            x4, [fp, #-8]
    // 0x689fa8: r2 = 64
    //     0x689fa8: movz            x2, #0x40
    // 0x689fac: r0 = _getValueOrData()
    //     0x689fac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x689fb0: ldur            x1, [fp, #-8]
    // 0x689fb4: LoadField: r2 = r1->field_f
    //     0x689fb4: ldur            w2, [x1, #0xf]
    // 0x689fb8: DecompressPointer r2
    //     0x689fb8: add             x2, x2, HEAP, lsl #32
    // 0x689fbc: cmp             w2, w0
    // 0x689fc0: b.ne            #0x689fc8
    // 0x689fc4: r0 = Null
    //     0x689fc4: mov             x0, NULL
    // 0x689fc8: cmp             w0, NULL
    // 0x689fcc: b.ne            #0x689ff4
    // 0x689fd0: r0 = Boost()
    //     0x689fd0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x689fd4: r1 = Instance_CustomNum
    //     0x689fd4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689fd8: ldr             x1, [x1, #0xa70]
    // 0x689fdc: StoreField: r0->field_7 = r1
    //     0x689fdc: stur            w1, [x0, #7]
    // 0x689fe0: StoreField: r0->field_b = r1
    //     0x689fe0: stur            w1, [x0, #0xb]
    // 0x689fe4: StoreField: r0->field_f = r1
    //     0x689fe4: stur            w1, [x0, #0xf]
    // 0x689fe8: StoreField: r0->field_13 = r1
    //     0x689fe8: stur            w1, [x0, #0x13]
    // 0x689fec: mov             x2, x0
    // 0x689ff0: b               #0x68a000
    // 0x689ff4: r1 = Instance_CustomNum
    //     0x689ff4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x689ff8: ldr             x1, [x1, #0xa70]
    // 0x689ffc: mov             x2, x0
    // 0x68a000: ldur            x0, [fp, #-8]
    // 0x68a004: stur            x2, [fp, #-0x20]
    // 0x68a008: r0 = Boost()
    //     0x68a008: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a00c: mov             x1, x0
    // 0x68a010: r0 = Instance_CustomNum
    //     0x68a010: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a014: ldr             x0, [x0, #0xa70]
    // 0x68a018: StoreField: r1->field_7 = r0
    //     0x68a018: stur            w0, [x1, #7]
    // 0x68a01c: StoreField: r1->field_b = r0
    //     0x68a01c: stur            w0, [x1, #0xb]
    // 0x68a020: r3 = Instance_CustomNum
    //     0x68a020: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a024: ldr             x3, [x3, #0xef8]
    // 0x68a028: StoreField: r1->field_f = r3
    //     0x68a028: stur            w3, [x1, #0xf]
    // 0x68a02c: StoreField: r1->field_13 = r0
    //     0x68a02c: stur            w0, [x1, #0x13]
    // 0x68a030: mov             x2, x1
    // 0x68a034: ldur            x1, [fp, #-0x20]
    // 0x68a038: r0 = *()
    //     0x68a038: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a03c: ldur            x1, [fp, #-8]
    // 0x68a040: mov             x3, x0
    // 0x68a044: r2 = 62
    //     0x68a044: movz            x2, #0x3e
    // 0x68a048: r0 = []=()
    //     0x68a048: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a04c: ldur            x1, [fp, #-8]
    // 0x68a050: r2 = 102
    //     0x68a050: movz            x2, #0x66
    // 0x68a054: r0 = _getValueOrData()
    //     0x68a054: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a058: ldur            x1, [fp, #-8]
    // 0x68a05c: LoadField: r2 = r1->field_f
    //     0x68a05c: ldur            w2, [x1, #0xf]
    // 0x68a060: DecompressPointer r2
    //     0x68a060: add             x2, x2, HEAP, lsl #32
    // 0x68a064: cmp             w2, w0
    // 0x68a068: b.ne            #0x68a070
    // 0x68a06c: r0 = Null
    //     0x68a06c: mov             x0, NULL
    // 0x68a070: cmp             w0, NULL
    // 0x68a074: b.ne            #0x68a098
    // 0x68a078: r0 = Boost()
    //     0x68a078: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a07c: r1 = Instance_CustomNum
    //     0x68a07c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a080: ldr             x1, [x1, #0xa70]
    // 0x68a084: StoreField: r0->field_7 = r1
    //     0x68a084: stur            w1, [x0, #7]
    // 0x68a088: StoreField: r0->field_b = r1
    //     0x68a088: stur            w1, [x0, #0xb]
    // 0x68a08c: StoreField: r0->field_f = r1
    //     0x68a08c: stur            w1, [x0, #0xf]
    // 0x68a090: StoreField: r0->field_13 = r1
    //     0x68a090: stur            w1, [x0, #0x13]
    // 0x68a094: b               #0x68a0a0
    // 0x68a098: r1 = Instance_CustomNum
    //     0x68a098: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a09c: ldr             x1, [x1, #0xa70]
    // 0x68a0a0: stur            x0, [fp, #-0x20]
    // 0x68a0a4: r0 = Boost()
    //     0x68a0a4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a0a8: mov             x1, x0
    // 0x68a0ac: r0 = Instance_CustomNum
    //     0x68a0ac: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a0b0: ldr             x0, [x0, #0xa70]
    // 0x68a0b4: StoreField: r1->field_7 = r0
    //     0x68a0b4: stur            w0, [x1, #7]
    // 0x68a0b8: StoreField: r1->field_b = r0
    //     0x68a0b8: stur            w0, [x1, #0xb]
    // 0x68a0bc: r3 = Instance_CustomNum
    //     0x68a0bc: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a0c0: ldr             x3, [x3, #0xef8]
    // 0x68a0c4: StoreField: r1->field_f = r3
    //     0x68a0c4: stur            w3, [x1, #0xf]
    // 0x68a0c8: StoreField: r1->field_13 = r0
    //     0x68a0c8: stur            w0, [x1, #0x13]
    // 0x68a0cc: mov             x2, x1
    // 0x68a0d0: ldur            x1, [fp, #-0x20]
    // 0x68a0d4: r0 = *()
    //     0x68a0d4: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a0d8: ldur            x1, [fp, #-8]
    // 0x68a0dc: mov             x3, x0
    // 0x68a0e0: r2 = 102
    //     0x68a0e0: movz            x2, #0x66
    // 0x68a0e4: r0 = []=()
    //     0x68a0e4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a0e8: ldur            x0, [fp, #-0x18]
    // 0x68a0ec: cmp             x0, #7
    // 0x68a0f0: b.lt            #0x68a440
    // 0x68a0f4: ldur            x0, [fp, #-0x10]
    // 0x68a0f8: LoadField: r3 = r0->field_33
    //     0x68a0f8: ldur            w3, [x0, #0x33]
    // 0x68a0fc: DecompressPointer r3
    //     0x68a0fc: add             x3, x3, HEAP, lsl #32
    // 0x68a100: mov             x1, x3
    // 0x68a104: stur            x3, [fp, #-8]
    // 0x68a108: r2 = 4
    //     0x68a108: movz            x2, #0x4
    // 0x68a10c: r0 = _getValueOrData()
    //     0x68a10c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a110: ldur            x1, [fp, #-8]
    // 0x68a114: LoadField: r2 = r1->field_f
    //     0x68a114: ldur            w2, [x1, #0xf]
    // 0x68a118: DecompressPointer r2
    //     0x68a118: add             x2, x2, HEAP, lsl #32
    // 0x68a11c: cmp             w2, w0
    // 0x68a120: b.ne            #0x68a128
    // 0x68a124: r0 = Null
    //     0x68a124: mov             x0, NULL
    // 0x68a128: cmp             w0, NULL
    // 0x68a12c: b.ne            #0x68a154
    // 0x68a130: r0 = Boost()
    //     0x68a130: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a134: r1 = Instance_CustomNum
    //     0x68a134: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a138: ldr             x1, [x1, #0xa70]
    // 0x68a13c: StoreField: r0->field_7 = r1
    //     0x68a13c: stur            w1, [x0, #7]
    // 0x68a140: StoreField: r0->field_b = r1
    //     0x68a140: stur            w1, [x0, #0xb]
    // 0x68a144: StoreField: r0->field_f = r1
    //     0x68a144: stur            w1, [x0, #0xf]
    // 0x68a148: StoreField: r0->field_13 = r1
    //     0x68a148: stur            w1, [x0, #0x13]
    // 0x68a14c: mov             x2, x0
    // 0x68a150: b               #0x68a160
    // 0x68a154: r1 = Instance_CustomNum
    //     0x68a154: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a158: ldr             x1, [x1, #0xa70]
    // 0x68a15c: mov             x2, x0
    // 0x68a160: ldur            x0, [fp, #-8]
    // 0x68a164: stur            x2, [fp, #-0x20]
    // 0x68a168: r0 = Boost()
    //     0x68a168: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a16c: mov             x1, x0
    // 0x68a170: r0 = Instance_CustomNum
    //     0x68a170: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a174: ldr             x0, [x0, #0xa70]
    // 0x68a178: StoreField: r1->field_7 = r0
    //     0x68a178: stur            w0, [x1, #7]
    // 0x68a17c: StoreField: r1->field_b = r0
    //     0x68a17c: stur            w0, [x1, #0xb]
    // 0x68a180: r3 = Instance_CustomNum
    //     0x68a180: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a184: ldr             x3, [x3, #0xef8]
    // 0x68a188: StoreField: r1->field_f = r3
    //     0x68a188: stur            w3, [x1, #0xf]
    // 0x68a18c: StoreField: r1->field_13 = r0
    //     0x68a18c: stur            w0, [x1, #0x13]
    // 0x68a190: mov             x2, x1
    // 0x68a194: ldur            x1, [fp, #-0x20]
    // 0x68a198: r0 = *()
    //     0x68a198: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a19c: ldur            x1, [fp, #-8]
    // 0x68a1a0: mov             x3, x0
    // 0x68a1a4: r2 = 4
    //     0x68a1a4: movz            x2, #0x4
    // 0x68a1a8: r0 = []=()
    //     0x68a1a8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a1ac: ldur            x1, [fp, #-8]
    // 0x68a1b0: r2 = 84
    //     0x68a1b0: movz            x2, #0x54
    // 0x68a1b4: r0 = _getValueOrData()
    //     0x68a1b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a1b8: ldur            x1, [fp, #-8]
    // 0x68a1bc: LoadField: r2 = r1->field_f
    //     0x68a1bc: ldur            w2, [x1, #0xf]
    // 0x68a1c0: DecompressPointer r2
    //     0x68a1c0: add             x2, x2, HEAP, lsl #32
    // 0x68a1c4: cmp             w2, w0
    // 0x68a1c8: b.ne            #0x68a1d0
    // 0x68a1cc: r0 = Null
    //     0x68a1cc: mov             x0, NULL
    // 0x68a1d0: cmp             w0, NULL
    // 0x68a1d4: b.ne            #0x68a1fc
    // 0x68a1d8: r0 = Boost()
    //     0x68a1d8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a1dc: r1 = Instance_CustomNum
    //     0x68a1dc: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a1e0: ldr             x1, [x1, #0xa70]
    // 0x68a1e4: StoreField: r0->field_7 = r1
    //     0x68a1e4: stur            w1, [x0, #7]
    // 0x68a1e8: StoreField: r0->field_b = r1
    //     0x68a1e8: stur            w1, [x0, #0xb]
    // 0x68a1ec: StoreField: r0->field_f = r1
    //     0x68a1ec: stur            w1, [x0, #0xf]
    // 0x68a1f0: StoreField: r0->field_13 = r1
    //     0x68a1f0: stur            w1, [x0, #0x13]
    // 0x68a1f4: mov             x2, x0
    // 0x68a1f8: b               #0x68a208
    // 0x68a1fc: r1 = Instance_CustomNum
    //     0x68a1fc: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a200: ldr             x1, [x1, #0xa70]
    // 0x68a204: mov             x2, x0
    // 0x68a208: ldur            x0, [fp, #-8]
    // 0x68a20c: stur            x2, [fp, #-0x20]
    // 0x68a210: r0 = Boost()
    //     0x68a210: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a214: mov             x1, x0
    // 0x68a218: r0 = Instance_CustomNum
    //     0x68a218: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a21c: ldr             x0, [x0, #0xa70]
    // 0x68a220: StoreField: r1->field_7 = r0
    //     0x68a220: stur            w0, [x1, #7]
    // 0x68a224: StoreField: r1->field_b = r0
    //     0x68a224: stur            w0, [x1, #0xb]
    // 0x68a228: r3 = Instance_CustomNum
    //     0x68a228: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a22c: ldr             x3, [x3, #0xef8]
    // 0x68a230: StoreField: r1->field_f = r3
    //     0x68a230: stur            w3, [x1, #0xf]
    // 0x68a234: StoreField: r1->field_13 = r0
    //     0x68a234: stur            w0, [x1, #0x13]
    // 0x68a238: mov             x2, x1
    // 0x68a23c: ldur            x1, [fp, #-0x20]
    // 0x68a240: r0 = *()
    //     0x68a240: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a244: ldur            x1, [fp, #-8]
    // 0x68a248: mov             x3, x0
    // 0x68a24c: r2 = 84
    //     0x68a24c: movz            x2, #0x54
    // 0x68a250: r0 = []=()
    //     0x68a250: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a254: ldur            x1, [fp, #-8]
    // 0x68a258: r2 = 122
    //     0x68a258: movz            x2, #0x7a
    // 0x68a25c: r0 = _getValueOrData()
    //     0x68a25c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a260: ldur            x1, [fp, #-8]
    // 0x68a264: LoadField: r2 = r1->field_f
    //     0x68a264: ldur            w2, [x1, #0xf]
    // 0x68a268: DecompressPointer r2
    //     0x68a268: add             x2, x2, HEAP, lsl #32
    // 0x68a26c: cmp             w2, w0
    // 0x68a270: b.ne            #0x68a278
    // 0x68a274: r0 = Null
    //     0x68a274: mov             x0, NULL
    // 0x68a278: cmp             w0, NULL
    // 0x68a27c: b.ne            #0x68a2a4
    // 0x68a280: r0 = Boost()
    //     0x68a280: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a284: r1 = Instance_CustomNum
    //     0x68a284: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a288: ldr             x1, [x1, #0xa70]
    // 0x68a28c: StoreField: r0->field_7 = r1
    //     0x68a28c: stur            w1, [x0, #7]
    // 0x68a290: StoreField: r0->field_b = r1
    //     0x68a290: stur            w1, [x0, #0xb]
    // 0x68a294: StoreField: r0->field_f = r1
    //     0x68a294: stur            w1, [x0, #0xf]
    // 0x68a298: StoreField: r0->field_13 = r1
    //     0x68a298: stur            w1, [x0, #0x13]
    // 0x68a29c: mov             x2, x0
    // 0x68a2a0: b               #0x68a2b0
    // 0x68a2a4: r1 = Instance_CustomNum
    //     0x68a2a4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a2a8: ldr             x1, [x1, #0xa70]
    // 0x68a2ac: mov             x2, x0
    // 0x68a2b0: ldur            x0, [fp, #-8]
    // 0x68a2b4: stur            x2, [fp, #-0x20]
    // 0x68a2b8: r0 = Boost()
    //     0x68a2b8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a2bc: mov             x1, x0
    // 0x68a2c0: r0 = Instance_CustomNum
    //     0x68a2c0: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a2c4: ldr             x0, [x0, #0xa70]
    // 0x68a2c8: StoreField: r1->field_7 = r0
    //     0x68a2c8: stur            w0, [x1, #7]
    // 0x68a2cc: StoreField: r1->field_b = r0
    //     0x68a2cc: stur            w0, [x1, #0xb]
    // 0x68a2d0: r3 = Instance_CustomNum
    //     0x68a2d0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a2d4: ldr             x3, [x3, #0xef8]
    // 0x68a2d8: StoreField: r1->field_f = r3
    //     0x68a2d8: stur            w3, [x1, #0xf]
    // 0x68a2dc: StoreField: r1->field_13 = r0
    //     0x68a2dc: stur            w0, [x1, #0x13]
    // 0x68a2e0: mov             x2, x1
    // 0x68a2e4: ldur            x1, [fp, #-0x20]
    // 0x68a2e8: r0 = *()
    //     0x68a2e8: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a2ec: ldur            x1, [fp, #-8]
    // 0x68a2f0: mov             x3, x0
    // 0x68a2f4: r2 = 122
    //     0x68a2f4: movz            x2, #0x7a
    // 0x68a2f8: r0 = []=()
    //     0x68a2f8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a2fc: ldur            x1, [fp, #-8]
    // 0x68a300: r2 = 142
    //     0x68a300: movz            x2, #0x8e
    // 0x68a304: r0 = _getValueOrData()
    //     0x68a304: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a308: ldur            x1, [fp, #-8]
    // 0x68a30c: LoadField: r2 = r1->field_f
    //     0x68a30c: ldur            w2, [x1, #0xf]
    // 0x68a310: DecompressPointer r2
    //     0x68a310: add             x2, x2, HEAP, lsl #32
    // 0x68a314: cmp             w2, w0
    // 0x68a318: b.ne            #0x68a320
    // 0x68a31c: r0 = Null
    //     0x68a31c: mov             x0, NULL
    // 0x68a320: cmp             w0, NULL
    // 0x68a324: b.ne            #0x68a34c
    // 0x68a328: r0 = Boost()
    //     0x68a328: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a32c: r1 = Instance_CustomNum
    //     0x68a32c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a330: ldr             x1, [x1, #0xa70]
    // 0x68a334: StoreField: r0->field_7 = r1
    //     0x68a334: stur            w1, [x0, #7]
    // 0x68a338: StoreField: r0->field_b = r1
    //     0x68a338: stur            w1, [x0, #0xb]
    // 0x68a33c: StoreField: r0->field_f = r1
    //     0x68a33c: stur            w1, [x0, #0xf]
    // 0x68a340: StoreField: r0->field_13 = r1
    //     0x68a340: stur            w1, [x0, #0x13]
    // 0x68a344: mov             x2, x0
    // 0x68a348: b               #0x68a358
    // 0x68a34c: r1 = Instance_CustomNum
    //     0x68a34c: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a350: ldr             x1, [x1, #0xa70]
    // 0x68a354: mov             x2, x0
    // 0x68a358: ldur            x0, [fp, #-8]
    // 0x68a35c: stur            x2, [fp, #-0x20]
    // 0x68a360: r0 = Boost()
    //     0x68a360: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a364: mov             x1, x0
    // 0x68a368: r0 = Instance_CustomNum
    //     0x68a368: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a36c: ldr             x0, [x0, #0xa70]
    // 0x68a370: StoreField: r1->field_7 = r0
    //     0x68a370: stur            w0, [x1, #7]
    // 0x68a374: StoreField: r1->field_b = r0
    //     0x68a374: stur            w0, [x1, #0xb]
    // 0x68a378: r3 = Instance_CustomNum
    //     0x68a378: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a37c: ldr             x3, [x3, #0xef8]
    // 0x68a380: StoreField: r1->field_f = r3
    //     0x68a380: stur            w3, [x1, #0xf]
    // 0x68a384: StoreField: r1->field_13 = r0
    //     0x68a384: stur            w0, [x1, #0x13]
    // 0x68a388: mov             x2, x1
    // 0x68a38c: ldur            x1, [fp, #-0x20]
    // 0x68a390: r0 = *()
    //     0x68a390: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a394: ldur            x1, [fp, #-8]
    // 0x68a398: mov             x3, x0
    // 0x68a39c: r2 = 142
    //     0x68a39c: movz            x2, #0x8e
    // 0x68a3a0: r0 = []=()
    //     0x68a3a0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a3a4: ldur            x1, [fp, #-8]
    // 0x68a3a8: r2 = 162
    //     0x68a3a8: movz            x2, #0xa2
    // 0x68a3ac: r0 = _getValueOrData()
    //     0x68a3ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a3b0: ldur            x1, [fp, #-8]
    // 0x68a3b4: LoadField: r2 = r1->field_f
    //     0x68a3b4: ldur            w2, [x1, #0xf]
    // 0x68a3b8: DecompressPointer r2
    //     0x68a3b8: add             x2, x2, HEAP, lsl #32
    // 0x68a3bc: cmp             w2, w0
    // 0x68a3c0: b.ne            #0x68a3c8
    // 0x68a3c4: r0 = Null
    //     0x68a3c4: mov             x0, NULL
    // 0x68a3c8: cmp             w0, NULL
    // 0x68a3cc: b.ne            #0x68a3f0
    // 0x68a3d0: r0 = Boost()
    //     0x68a3d0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a3d4: r1 = Instance_CustomNum
    //     0x68a3d4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a3d8: ldr             x1, [x1, #0xa70]
    // 0x68a3dc: StoreField: r0->field_7 = r1
    //     0x68a3dc: stur            w1, [x0, #7]
    // 0x68a3e0: StoreField: r0->field_b = r1
    //     0x68a3e0: stur            w1, [x0, #0xb]
    // 0x68a3e4: StoreField: r0->field_f = r1
    //     0x68a3e4: stur            w1, [x0, #0xf]
    // 0x68a3e8: StoreField: r0->field_13 = r1
    //     0x68a3e8: stur            w1, [x0, #0x13]
    // 0x68a3ec: b               #0x68a3f8
    // 0x68a3f0: r1 = Instance_CustomNum
    //     0x68a3f0: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a3f4: ldr             x1, [x1, #0xa70]
    // 0x68a3f8: stur            x0, [fp, #-0x20]
    // 0x68a3fc: r0 = Boost()
    //     0x68a3fc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a400: mov             x1, x0
    // 0x68a404: r0 = Instance_CustomNum
    //     0x68a404: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a408: ldr             x0, [x0, #0xa70]
    // 0x68a40c: StoreField: r1->field_7 = r0
    //     0x68a40c: stur            w0, [x1, #7]
    // 0x68a410: StoreField: r1->field_b = r0
    //     0x68a410: stur            w0, [x1, #0xb]
    // 0x68a414: r2 = Instance_CustomNum
    //     0x68a414: add             x2, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a418: ldr             x2, [x2, #0xef8]
    // 0x68a41c: StoreField: r1->field_f = r2
    //     0x68a41c: stur            w2, [x1, #0xf]
    // 0x68a420: StoreField: r1->field_13 = r0
    //     0x68a420: stur            w0, [x1, #0x13]
    // 0x68a424: mov             x2, x1
    // 0x68a428: ldur            x1, [fp, #-0x20]
    // 0x68a42c: r0 = *()
    //     0x68a42c: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a430: ldur            x1, [fp, #-8]
    // 0x68a434: mov             x3, x0
    // 0x68a438: r2 = 162
    //     0x68a438: movz            x2, #0xa2
    // 0x68a43c: r0 = []=()
    //     0x68a43c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a440: ldur            x0, [fp, #-0x10]
    // 0x68a444: LoadField: r1 = r0->field_43
    //     0x68a444: ldur            w1, [x0, #0x43]
    // 0x68a448: DecompressPointer r1
    //     0x68a448: add             x1, x1, HEAP, lsl #32
    // 0x68a44c: r2 = 100
    //     0x68a44c: movz            x2, #0x64
    // 0x68a450: r0 = containsKey()
    //     0x68a450: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x68a454: tbnz            w0, #4, #0x68a654
    // 0x68a458: ldur            x0, [fp, #-0x10]
    // 0x68a45c: LoadField: r3 = r0->field_33
    //     0x68a45c: ldur            w3, [x0, #0x33]
    // 0x68a460: DecompressPointer r3
    //     0x68a460: add             x3, x3, HEAP, lsl #32
    // 0x68a464: mov             x1, x3
    // 0x68a468: stur            x3, [fp, #-8]
    // 0x68a46c: r2 = 2
    //     0x68a46c: movz            x2, #0x2
    // 0x68a470: r0 = _getValueOrData()
    //     0x68a470: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a474: ldur            x1, [fp, #-8]
    // 0x68a478: LoadField: r2 = r1->field_f
    //     0x68a478: ldur            w2, [x1, #0xf]
    // 0x68a47c: DecompressPointer r2
    //     0x68a47c: add             x2, x2, HEAP, lsl #32
    // 0x68a480: cmp             w2, w0
    // 0x68a484: b.ne            #0x68a48c
    // 0x68a488: r0 = Null
    //     0x68a488: mov             x0, NULL
    // 0x68a48c: cmp             w0, NULL
    // 0x68a490: b.ne            #0x68a4b8
    // 0x68a494: r0 = Boost()
    //     0x68a494: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a498: r1 = Instance_CustomNum
    //     0x68a498: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a49c: ldr             x1, [x1, #0xa70]
    // 0x68a4a0: StoreField: r0->field_7 = r1
    //     0x68a4a0: stur            w1, [x0, #7]
    // 0x68a4a4: StoreField: r0->field_b = r1
    //     0x68a4a4: stur            w1, [x0, #0xb]
    // 0x68a4a8: StoreField: r0->field_f = r1
    //     0x68a4a8: stur            w1, [x0, #0xf]
    // 0x68a4ac: StoreField: r0->field_13 = r1
    //     0x68a4ac: stur            w1, [x0, #0x13]
    // 0x68a4b0: mov             x2, x0
    // 0x68a4b4: b               #0x68a4c4
    // 0x68a4b8: r1 = Instance_CustomNum
    //     0x68a4b8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a4bc: ldr             x1, [x1, #0xa70]
    // 0x68a4c0: mov             x2, x0
    // 0x68a4c4: ldur            x0, [fp, #-8]
    // 0x68a4c8: stur            x2, [fp, #-0x10]
    // 0x68a4cc: r0 = Boost()
    //     0x68a4cc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a4d0: mov             x1, x0
    // 0x68a4d4: r0 = Instance_CustomNum
    //     0x68a4d4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a4d8: ldr             x0, [x0, #0xa70]
    // 0x68a4dc: StoreField: r1->field_7 = r0
    //     0x68a4dc: stur            w0, [x1, #7]
    // 0x68a4e0: StoreField: r1->field_b = r0
    //     0x68a4e0: stur            w0, [x1, #0xb]
    // 0x68a4e4: r3 = Instance_CustomNum
    //     0x68a4e4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x68a4e8: ldr             x3, [x3, #0x448]
    // 0x68a4ec: StoreField: r1->field_f = r3
    //     0x68a4ec: stur            w3, [x1, #0xf]
    // 0x68a4f0: StoreField: r1->field_13 = r0
    //     0x68a4f0: stur            w0, [x1, #0x13]
    // 0x68a4f4: mov             x2, x1
    // 0x68a4f8: ldur            x1, [fp, #-0x10]
    // 0x68a4fc: r0 = *()
    //     0x68a4fc: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a500: ldur            x1, [fp, #-8]
    // 0x68a504: mov             x3, x0
    // 0x68a508: r2 = 2
    //     0x68a508: movz            x2, #0x2
    // 0x68a50c: r0 = []=()
    //     0x68a50c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a510: ldur            x1, [fp, #-8]
    // 0x68a514: r2 = 42
    //     0x68a514: movz            x2, #0x2a
    // 0x68a518: r0 = _getValueOrData()
    //     0x68a518: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a51c: ldur            x1, [fp, #-8]
    // 0x68a520: LoadField: r2 = r1->field_f
    //     0x68a520: ldur            w2, [x1, #0xf]
    // 0x68a524: DecompressPointer r2
    //     0x68a524: add             x2, x2, HEAP, lsl #32
    // 0x68a528: cmp             w2, w0
    // 0x68a52c: b.ne            #0x68a534
    // 0x68a530: r0 = Null
    //     0x68a530: mov             x0, NULL
    // 0x68a534: cmp             w0, NULL
    // 0x68a538: b.ne            #0x68a560
    // 0x68a53c: r0 = Boost()
    //     0x68a53c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a540: r1 = Instance_CustomNum
    //     0x68a540: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a544: ldr             x1, [x1, #0xa70]
    // 0x68a548: StoreField: r0->field_7 = r1
    //     0x68a548: stur            w1, [x0, #7]
    // 0x68a54c: StoreField: r0->field_b = r1
    //     0x68a54c: stur            w1, [x0, #0xb]
    // 0x68a550: StoreField: r0->field_f = r1
    //     0x68a550: stur            w1, [x0, #0xf]
    // 0x68a554: StoreField: r0->field_13 = r1
    //     0x68a554: stur            w1, [x0, #0x13]
    // 0x68a558: mov             x2, x0
    // 0x68a55c: b               #0x68a56c
    // 0x68a560: r1 = Instance_CustomNum
    //     0x68a560: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a564: ldr             x1, [x1, #0xa70]
    // 0x68a568: mov             x2, x0
    // 0x68a56c: ldur            x0, [fp, #-8]
    // 0x68a570: stur            x2, [fp, #-0x10]
    // 0x68a574: r0 = Boost()
    //     0x68a574: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a578: mov             x1, x0
    // 0x68a57c: r0 = Instance_CustomNum
    //     0x68a57c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a580: ldr             x0, [x0, #0xa70]
    // 0x68a584: StoreField: r1->field_7 = r0
    //     0x68a584: stur            w0, [x1, #7]
    // 0x68a588: StoreField: r1->field_b = r0
    //     0x68a588: stur            w0, [x1, #0xb]
    // 0x68a58c: r3 = Instance_CustomNum
    //     0x68a58c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x68a590: ldr             x3, [x3, #0x448]
    // 0x68a594: StoreField: r1->field_f = r3
    //     0x68a594: stur            w3, [x1, #0xf]
    // 0x68a598: StoreField: r1->field_13 = r0
    //     0x68a598: stur            w0, [x1, #0x13]
    // 0x68a59c: mov             x2, x1
    // 0x68a5a0: ldur            x1, [fp, #-0x10]
    // 0x68a5a4: r0 = *()
    //     0x68a5a4: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a5a8: ldur            x1, [fp, #-8]
    // 0x68a5ac: mov             x3, x0
    // 0x68a5b0: r2 = 42
    //     0x68a5b0: movz            x2, #0x2a
    // 0x68a5b4: r0 = []=()
    //     0x68a5b4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a5b8: ldur            x1, [fp, #-8]
    // 0x68a5bc: r2 = 82
    //     0x68a5bc: movz            x2, #0x52
    // 0x68a5c0: r0 = _getValueOrData()
    //     0x68a5c0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a5c4: ldur            x1, [fp, #-8]
    // 0x68a5c8: LoadField: r2 = r1->field_f
    //     0x68a5c8: ldur            w2, [x1, #0xf]
    // 0x68a5cc: DecompressPointer r2
    //     0x68a5cc: add             x2, x2, HEAP, lsl #32
    // 0x68a5d0: cmp             w2, w0
    // 0x68a5d4: b.ne            #0x68a5dc
    // 0x68a5d8: r0 = Null
    //     0x68a5d8: mov             x0, NULL
    // 0x68a5dc: cmp             w0, NULL
    // 0x68a5e0: b.ne            #0x68a604
    // 0x68a5e4: r0 = Boost()
    //     0x68a5e4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a5e8: r1 = Instance_CustomNum
    //     0x68a5e8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a5ec: ldr             x1, [x1, #0xa70]
    // 0x68a5f0: StoreField: r0->field_7 = r1
    //     0x68a5f0: stur            w1, [x0, #7]
    // 0x68a5f4: StoreField: r0->field_b = r1
    //     0x68a5f4: stur            w1, [x0, #0xb]
    // 0x68a5f8: StoreField: r0->field_f = r1
    //     0x68a5f8: stur            w1, [x0, #0xf]
    // 0x68a5fc: StoreField: r0->field_13 = r1
    //     0x68a5fc: stur            w1, [x0, #0x13]
    // 0x68a600: b               #0x68a60c
    // 0x68a604: r1 = Instance_CustomNum
    //     0x68a604: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a608: ldr             x1, [x1, #0xa70]
    // 0x68a60c: stur            x0, [fp, #-0x10]
    // 0x68a610: r0 = Boost()
    //     0x68a610: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a614: mov             x1, x0
    // 0x68a618: r0 = Instance_CustomNum
    //     0x68a618: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a61c: ldr             x0, [x0, #0xa70]
    // 0x68a620: StoreField: r1->field_7 = r0
    //     0x68a620: stur            w0, [x1, #7]
    // 0x68a624: StoreField: r1->field_b = r0
    //     0x68a624: stur            w0, [x1, #0xb]
    // 0x68a628: r2 = Instance_CustomNum
    //     0x68a628: add             x2, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x68a62c: ldr             x2, [x2, #0x448]
    // 0x68a630: StoreField: r1->field_f = r2
    //     0x68a630: stur            w2, [x1, #0xf]
    // 0x68a634: StoreField: r1->field_13 = r0
    //     0x68a634: stur            w0, [x1, #0x13]
    // 0x68a638: mov             x2, x1
    // 0x68a63c: ldur            x1, [fp, #-0x10]
    // 0x68a640: r0 = *()
    //     0x68a640: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68a644: ldur            x1, [fp, #-8]
    // 0x68a648: mov             x3, x0
    // 0x68a64c: r2 = 82
    //     0x68a64c: movz            x2, #0x52
    // 0x68a650: r0 = []=()
    //     0x68a650: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a654: r0 = Null
    //     0x68a654: mov             x0, NULL
    // 0x68a658: LeaveFrame
    //     0x68a658: mov             SP, fp
    //     0x68a65c: ldp             fp, lr, [SP], #0x10
    // 0x68a660: ret
    //     0x68a660: ret             
    // 0x68a664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68a664: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68a668: b               #0x689aa0
  }
  [closure] CustomNum? getGeneratorMultiplier(dynamic, int) {
    // ** addr: 0x6905f8, size: 0xc
    // 0x6905f8: r0 = Instance_CustomNum
    //     0x6905f8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x6905fc: ldr             x0, [x0, #0x2f0]
    // 0x690600: ret
    //     0x690600: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x69b504, size: 0x2e98
    // 0x69b504: EnterFrame
    //     0x69b504: stp             fp, lr, [SP, #-0x10]!
    //     0x69b508: mov             fp, SP
    // 0x69b50c: AllocStack(0xc8)
    //     0x69b50c: sub             SP, SP, #0xc8
    // 0x69b510: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x69b510: mov             x0, x1
    //     0x69b514: stur            x1, [fp, #-8]
    //     0x69b518: stur            x2, [fp, #-0x10]
    // 0x69b51c: CheckStackOverflow
    //     0x69b51c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69b520: cmp             SP, x16
    //     0x69b524: b.ls            #0x69e37c
    // 0x69b528: r1 = 2
    //     0x69b528: movz            x1, #0x2
    // 0x69b52c: r0 = AllocateContext()
    //     0x69b52c: bl              #0x82637c  ; AllocateContextStub
    // 0x69b530: mov             x3, x0
    // 0x69b534: ldur            x0, [fp, #-8]
    // 0x69b538: stur            x3, [fp, #-0x18]
    // 0x69b53c: StoreField: r3->field_f = r0
    //     0x69b53c: stur            w0, [x3, #0xf]
    // 0x69b540: ldur            x1, [fp, #-0x10]
    // 0x69b544: StoreField: r3->field_13 = r1
    //     0x69b544: stur            w1, [x3, #0x13]
    // 0x69b548: r1 = Null
    //     0x69b548: mov             x1, NULL
    // 0x69b54c: r2 = 6
    //     0x69b54c: movz            x2, #0x6
    // 0x69b550: r0 = AllocateArray()
    //     0x69b550: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b554: r16 = "Get "
    //     0x69b554: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b558: ldr             x16, [x16, #0xb68]
    // 0x69b55c: StoreField: r0->field_f = r16
    //     0x69b55c: stur            w16, [x0, #0xf]
    // 0x69b560: r16 = Instance_CustomNum
    //     0x69b560: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a10] Obj!CustomNum@82b871
    //     0x69b564: ldr             x16, [x16, #0xa10]
    // 0x69b568: StoreField: r0->field_13 = r16
    //     0x69b568: stur            w16, [x0, #0x13]
    // 0x69b56c: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b56c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b570: ldr             x16, [x16, #0xa18]
    // 0x69b574: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b574: stur            w16, [x0, #0x17]
    // 0x69b578: str             x0, [SP]
    // 0x69b57c: r0 = _interpolate()
    //     0x69b57c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b580: r1 = <Chapter13Stat>
    //     0x69b580: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b584: ldr             x1, [x1, #0xf28]
    // 0x69b588: stur            x0, [fp, #-0x10]
    // 0x69b58c: r0 = QuestLevel()
    //     0x69b58c: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b590: mov             x3, x0
    // 0x69b594: r0 = Instance_Tuple2
    //     0x69b594: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a20] Obj!Tuple2<Chapter13Stat, CustomNum>@8269f1
    //     0x69b598: ldr             x0, [x0, #0xa20]
    // 0x69b59c: stur            x3, [fp, #-0x20]
    // 0x69b5a0: StoreField: r3->field_f = r0
    //     0x69b5a0: stur            w0, [x3, #0xf]
    // 0x69b5a4: r0 = "Bill Shock 1"
    //     0x69b5a4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a28] "Bill Shock 1"
    //     0x69b5a8: ldr             x0, [x0, #0xa28]
    // 0x69b5ac: StoreField: r3->field_13 = r0
    //     0x69b5ac: stur            w0, [x3, #0x13]
    // 0x69b5b0: ldur            x0, [fp, #-0x10]
    // 0x69b5b4: ArrayStore: r3[0] = r0  ; List_4
    //     0x69b5b4: stur            w0, [x3, #0x17]
    // 0x69b5b8: r0 = "Doubles the yields from power."
    //     0x69b5b8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b5bc: ldr             x0, [x0, #0xa30]
    // 0x69b5c0: StoreField: r3->field_1b = r0
    //     0x69b5c0: stur            w0, [x3, #0x1b]
    // 0x69b5c4: r1 = Null
    //     0x69b5c4: mov             x1, NULL
    // 0x69b5c8: r2 = 6
    //     0x69b5c8: movz            x2, #0x6
    // 0x69b5cc: r0 = AllocateArray()
    //     0x69b5cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b5d0: r16 = "Get "
    //     0x69b5d0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b5d4: ldr             x16, [x16, #0xb68]
    // 0x69b5d8: StoreField: r0->field_f = r16
    //     0x69b5d8: stur            w16, [x0, #0xf]
    // 0x69b5dc: r16 = Instance_CustomNum
    //     0x69b5dc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a38] Obj!CustomNum@82b861
    //     0x69b5e0: ldr             x16, [x16, #0xa38]
    // 0x69b5e4: StoreField: r0->field_13 = r16
    //     0x69b5e4: stur            w16, [x0, #0x13]
    // 0x69b5e8: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b5e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b5ec: ldr             x16, [x16, #0xa18]
    // 0x69b5f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b5f0: stur            w16, [x0, #0x17]
    // 0x69b5f4: str             x0, [SP]
    // 0x69b5f8: r0 = _interpolate()
    //     0x69b5f8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b5fc: r1 = <Chapter13Stat>
    //     0x69b5fc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b600: ldr             x1, [x1, #0xf28]
    // 0x69b604: stur            x0, [fp, #-0x10]
    // 0x69b608: r0 = QuestLevel()
    //     0x69b608: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b60c: mov             x3, x0
    // 0x69b610: r0 = Instance_Tuple2
    //     0x69b610: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a40] Obj!Tuple2<Chapter13Stat, CustomNum>@8269d1
    //     0x69b614: ldr             x0, [x0, #0xa40]
    // 0x69b618: stur            x3, [fp, #-0x28]
    // 0x69b61c: StoreField: r3->field_f = r0
    //     0x69b61c: stur            w0, [x3, #0xf]
    // 0x69b620: r0 = "Bill Shock 2"
    //     0x69b620: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a48] "Bill Shock 2"
    //     0x69b624: ldr             x0, [x0, #0xa48]
    // 0x69b628: StoreField: r3->field_13 = r0
    //     0x69b628: stur            w0, [x3, #0x13]
    // 0x69b62c: ldur            x0, [fp, #-0x10]
    // 0x69b630: ArrayStore: r3[0] = r0  ; List_4
    //     0x69b630: stur            w0, [x3, #0x17]
    // 0x69b634: r0 = "Doubles the yields from power."
    //     0x69b634: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b638: ldr             x0, [x0, #0xa30]
    // 0x69b63c: StoreField: r3->field_1b = r0
    //     0x69b63c: stur            w0, [x3, #0x1b]
    // 0x69b640: r1 = Null
    //     0x69b640: mov             x1, NULL
    // 0x69b644: r2 = 6
    //     0x69b644: movz            x2, #0x6
    // 0x69b648: r0 = AllocateArray()
    //     0x69b648: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b64c: r16 = "Get "
    //     0x69b64c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b650: ldr             x16, [x16, #0xb68]
    // 0x69b654: StoreField: r0->field_f = r16
    //     0x69b654: stur            w16, [x0, #0xf]
    // 0x69b658: r16 = Instance_CustomNum
    //     0x69b658: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a50] Obj!CustomNum@82b851
    //     0x69b65c: ldr             x16, [x16, #0xa50]
    // 0x69b660: StoreField: r0->field_13 = r16
    //     0x69b660: stur            w16, [x0, #0x13]
    // 0x69b664: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b664: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b668: ldr             x16, [x16, #0xa18]
    // 0x69b66c: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b66c: stur            w16, [x0, #0x17]
    // 0x69b670: str             x0, [SP]
    // 0x69b674: r0 = _interpolate()
    //     0x69b674: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b678: r1 = <Chapter13Stat>
    //     0x69b678: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b67c: ldr             x1, [x1, #0xf28]
    // 0x69b680: stur            x0, [fp, #-0x10]
    // 0x69b684: r0 = QuestLevel()
    //     0x69b684: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b688: mov             x3, x0
    // 0x69b68c: r0 = Instance_Tuple2
    //     0x69b68c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a58] Obj!Tuple2<Chapter13Stat, CustomNum>@8269b1
    //     0x69b690: ldr             x0, [x0, #0xa58]
    // 0x69b694: stur            x3, [fp, #-0x30]
    // 0x69b698: StoreField: r3->field_f = r0
    //     0x69b698: stur            w0, [x3, #0xf]
    // 0x69b69c: r0 = "Bill Shock 3"
    //     0x69b69c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a60] "Bill Shock 3"
    //     0x69b6a0: ldr             x0, [x0, #0xa60]
    // 0x69b6a4: StoreField: r3->field_13 = r0
    //     0x69b6a4: stur            w0, [x3, #0x13]
    // 0x69b6a8: ldur            x0, [fp, #-0x10]
    // 0x69b6ac: ArrayStore: r3[0] = r0  ; List_4
    //     0x69b6ac: stur            w0, [x3, #0x17]
    // 0x69b6b0: r0 = "Doubles the yields from power."
    //     0x69b6b0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b6b4: ldr             x0, [x0, #0xa30]
    // 0x69b6b8: StoreField: r3->field_1b = r0
    //     0x69b6b8: stur            w0, [x3, #0x1b]
    // 0x69b6bc: r1 = Null
    //     0x69b6bc: mov             x1, NULL
    // 0x69b6c0: r2 = 6
    //     0x69b6c0: movz            x2, #0x6
    // 0x69b6c4: r0 = AllocateArray()
    //     0x69b6c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b6c8: r16 = "Get "
    //     0x69b6c8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b6cc: ldr             x16, [x16, #0xb68]
    // 0x69b6d0: StoreField: r0->field_f = r16
    //     0x69b6d0: stur            w16, [x0, #0xf]
    // 0x69b6d4: r16 = Instance_CustomNum
    //     0x69b6d4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a68] Obj!CustomNum@82b841
    //     0x69b6d8: ldr             x16, [x16, #0xa68]
    // 0x69b6dc: StoreField: r0->field_13 = r16
    //     0x69b6dc: stur            w16, [x0, #0x13]
    // 0x69b6e0: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b6e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b6e4: ldr             x16, [x16, #0xa18]
    // 0x69b6e8: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b6e8: stur            w16, [x0, #0x17]
    // 0x69b6ec: str             x0, [SP]
    // 0x69b6f0: r0 = _interpolate()
    //     0x69b6f0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b6f4: r1 = <Chapter13Stat>
    //     0x69b6f4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b6f8: ldr             x1, [x1, #0xf28]
    // 0x69b6fc: stur            x0, [fp, #-0x10]
    // 0x69b700: r0 = QuestLevel()
    //     0x69b700: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b704: mov             x3, x0
    // 0x69b708: r0 = Instance_Tuple2
    //     0x69b708: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a70] Obj!Tuple2<Chapter13Stat, CustomNum>@826991
    //     0x69b70c: ldr             x0, [x0, #0xa70]
    // 0x69b710: stur            x3, [fp, #-0x38]
    // 0x69b714: StoreField: r3->field_f = r0
    //     0x69b714: stur            w0, [x3, #0xf]
    // 0x69b718: r0 = "Bill Shock 4"
    //     0x69b718: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a78] "Bill Shock 4"
    //     0x69b71c: ldr             x0, [x0, #0xa78]
    // 0x69b720: StoreField: r3->field_13 = r0
    //     0x69b720: stur            w0, [x3, #0x13]
    // 0x69b724: ldur            x0, [fp, #-0x10]
    // 0x69b728: ArrayStore: r3[0] = r0  ; List_4
    //     0x69b728: stur            w0, [x3, #0x17]
    // 0x69b72c: r0 = "Doubles the yields from power."
    //     0x69b72c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b730: ldr             x0, [x0, #0xa30]
    // 0x69b734: StoreField: r3->field_1b = r0
    //     0x69b734: stur            w0, [x3, #0x1b]
    // 0x69b738: r1 = Null
    //     0x69b738: mov             x1, NULL
    // 0x69b73c: r2 = 6
    //     0x69b73c: movz            x2, #0x6
    // 0x69b740: r0 = AllocateArray()
    //     0x69b740: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b744: r16 = "Get "
    //     0x69b744: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b748: ldr             x16, [x16, #0xb68]
    // 0x69b74c: StoreField: r0->field_f = r16
    //     0x69b74c: stur            w16, [x0, #0xf]
    // 0x69b750: r16 = Instance_CustomNum
    //     0x69b750: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a80] Obj!CustomNum@82b831
    //     0x69b754: ldr             x16, [x16, #0xa80]
    // 0x69b758: StoreField: r0->field_13 = r16
    //     0x69b758: stur            w16, [x0, #0x13]
    // 0x69b75c: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b75c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b760: ldr             x16, [x16, #0xa18]
    // 0x69b764: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b764: stur            w16, [x0, #0x17]
    // 0x69b768: str             x0, [SP]
    // 0x69b76c: r0 = _interpolate()
    //     0x69b76c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b770: r1 = <Chapter13Stat>
    //     0x69b770: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b774: ldr             x1, [x1, #0xf28]
    // 0x69b778: stur            x0, [fp, #-0x10]
    // 0x69b77c: r0 = QuestLevel()
    //     0x69b77c: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b780: mov             x3, x0
    // 0x69b784: r0 = Instance_Tuple2
    //     0x69b784: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a88] Obj!Tuple2<Chapter13Stat, CustomNum>@826971
    //     0x69b788: ldr             x0, [x0, #0xa88]
    // 0x69b78c: stur            x3, [fp, #-0x40]
    // 0x69b790: StoreField: r3->field_f = r0
    //     0x69b790: stur            w0, [x3, #0xf]
    // 0x69b794: r0 = "Bill Shock 5"
    //     0x69b794: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a90] "Bill Shock 5"
    //     0x69b798: ldr             x0, [x0, #0xa90]
    // 0x69b79c: StoreField: r3->field_13 = r0
    //     0x69b79c: stur            w0, [x3, #0x13]
    // 0x69b7a0: ldur            x0, [fp, #-0x10]
    // 0x69b7a4: ArrayStore: r3[0] = r0  ; List_4
    //     0x69b7a4: stur            w0, [x3, #0x17]
    // 0x69b7a8: r0 = "Doubles the yields from power."
    //     0x69b7a8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b7ac: ldr             x0, [x0, #0xa30]
    // 0x69b7b0: StoreField: r3->field_1b = r0
    //     0x69b7b0: stur            w0, [x3, #0x1b]
    // 0x69b7b4: r1 = Null
    //     0x69b7b4: mov             x1, NULL
    // 0x69b7b8: r2 = 10
    //     0x69b7b8: movz            x2, #0xa
    // 0x69b7bc: r0 = AllocateArray()
    //     0x69b7bc: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b7c0: mov             x2, x0
    // 0x69b7c4: ldur            x0, [fp, #-0x20]
    // 0x69b7c8: stur            x2, [fp, #-0x10]
    // 0x69b7cc: StoreField: r2->field_f = r0
    //     0x69b7cc: stur            w0, [x2, #0xf]
    // 0x69b7d0: ldur            x0, [fp, #-0x28]
    // 0x69b7d4: StoreField: r2->field_13 = r0
    //     0x69b7d4: stur            w0, [x2, #0x13]
    // 0x69b7d8: ldur            x0, [fp, #-0x30]
    // 0x69b7dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x69b7dc: stur            w0, [x2, #0x17]
    // 0x69b7e0: ldur            x0, [fp, #-0x38]
    // 0x69b7e4: StoreField: r2->field_1b = r0
    //     0x69b7e4: stur            w0, [x2, #0x1b]
    // 0x69b7e8: ldur            x0, [fp, #-0x40]
    // 0x69b7ec: StoreField: r2->field_1f = r0
    //     0x69b7ec: stur            w0, [x2, #0x1f]
    // 0x69b7f0: r1 = <QuestLevel<Chapter13Stat>>
    //     0x69b7f0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a98] TypeArguments: <QuestLevel<Chapter13Stat>>
    //     0x69b7f4: ldr             x1, [x1, #0xa98]
    // 0x69b7f8: r0 = AllocateGrowableArray()
    //     0x69b7f8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69b7fc: mov             x3, x0
    // 0x69b800: ldur            x0, [fp, #-0x10]
    // 0x69b804: stur            x3, [fp, #-0x20]
    // 0x69b808: StoreField: r3->field_f = r0
    //     0x69b808: stur            w0, [x3, #0xf]
    // 0x69b80c: r0 = 10
    //     0x69b80c: movz            x0, #0xa
    // 0x69b810: StoreField: r3->field_b = r0
    //     0x69b810: stur            w0, [x3, #0xb]
    // 0x69b814: r1 = Null
    //     0x69b814: mov             x1, NULL
    // 0x69b818: r2 = 4
    //     0x69b818: movz            x2, #0x4
    // 0x69b81c: r0 = AllocateArray()
    //     0x69b81c: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b820: stur            x0, [fp, #-0x10]
    // 0x69b824: r16 = Instance_QuestLevel
    //     0x69b824: add             x16, PP, #0x28, lsl #12  ; [pp+0x28aa0] Obj!QuestLevel<Chapter13Stat>@8286f1
    //     0x69b828: ldr             x16, [x16, #0xaa0]
    // 0x69b82c: StoreField: r0->field_f = r16
    //     0x69b82c: stur            w16, [x0, #0xf]
    // 0x69b830: r16 = Instance_QuestLevel
    //     0x69b830: add             x16, PP, #0x28, lsl #12  ; [pp+0x28aa8] Obj!QuestLevel<Chapter13Stat>@8286d1
    //     0x69b834: ldr             x16, [x16, #0xaa8]
    // 0x69b838: StoreField: r0->field_13 = r16
    //     0x69b838: stur            w16, [x0, #0x13]
    // 0x69b83c: r1 = <QuestLevel<Chapter13Stat>>
    //     0x69b83c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a98] TypeArguments: <QuestLevel<Chapter13Stat>>
    //     0x69b840: ldr             x1, [x1, #0xa98]
    // 0x69b844: r0 = AllocateGrowableArray()
    //     0x69b844: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69b848: mov             x3, x0
    // 0x69b84c: ldur            x0, [fp, #-0x10]
    // 0x69b850: stur            x3, [fp, #-0x28]
    // 0x69b854: StoreField: r3->field_f = r0
    //     0x69b854: stur            w0, [x3, #0xf]
    // 0x69b858: r0 = 4
    //     0x69b858: movz            x0, #0x4
    // 0x69b85c: StoreField: r3->field_b = r0
    //     0x69b85c: stur            w0, [x3, #0xb]
    // 0x69b860: ldur            x4, [fp, #-8]
    // 0x69b864: LoadField: r1 = r4->field_43
    //     0x69b864: ldur            w1, [x4, #0x43]
    // 0x69b868: DecompressPointer r1
    //     0x69b868: add             x1, x1, HEAP, lsl #32
    // 0x69b86c: r2 = 160
    //     0x69b86c: movz            x2, #0xa0
    // 0x69b870: r0 = containsKey()
    //     0x69b870: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69b874: tbnz            w0, #4, #0x69c0f0
    // 0x69b878: ldur            x0, [fp, #-0x20]
    // 0x69b87c: r1 = Null
    //     0x69b87c: mov             x1, NULL
    // 0x69b880: r2 = 6
    //     0x69b880: movz            x2, #0x6
    // 0x69b884: r0 = AllocateArray()
    //     0x69b884: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b888: r16 = "Get "
    //     0x69b888: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b88c: ldr             x16, [x16, #0xb68]
    // 0x69b890: StoreField: r0->field_f = r16
    //     0x69b890: stur            w16, [x0, #0xf]
    // 0x69b894: r16 = Instance_CustomNum
    //     0x69b894: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ab0] Obj!CustomNum@82b801
    //     0x69b898: ldr             x16, [x16, #0xab0]
    // 0x69b89c: StoreField: r0->field_13 = r16
    //     0x69b89c: stur            w16, [x0, #0x13]
    // 0x69b8a0: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b8a0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b8a4: ldr             x16, [x16, #0xa18]
    // 0x69b8a8: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b8a8: stur            w16, [x0, #0x17]
    // 0x69b8ac: str             x0, [SP]
    // 0x69b8b0: r0 = _interpolate()
    //     0x69b8b0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b8b4: r1 = <Chapter13Stat>
    //     0x69b8b4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b8b8: ldr             x1, [x1, #0xf28]
    // 0x69b8bc: stur            x0, [fp, #-0x10]
    // 0x69b8c0: r0 = QuestLevel()
    //     0x69b8c0: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b8c4: mov             x2, x0
    // 0x69b8c8: r0 = Instance_Tuple2
    //     0x69b8c8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ab8] Obj!Tuple2<Chapter13Stat, CustomNum>@826911
    //     0x69b8cc: ldr             x0, [x0, #0xab8]
    // 0x69b8d0: stur            x2, [fp, #-0x30]
    // 0x69b8d4: StoreField: r2->field_f = r0
    //     0x69b8d4: stur            w0, [x2, #0xf]
    // 0x69b8d8: r0 = "Bill Shock 6"
    //     0x69b8d8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ac0] "Bill Shock 6"
    //     0x69b8dc: ldr             x0, [x0, #0xac0]
    // 0x69b8e0: StoreField: r2->field_13 = r0
    //     0x69b8e0: stur            w0, [x2, #0x13]
    // 0x69b8e4: ldur            x0, [fp, #-0x10]
    // 0x69b8e8: ArrayStore: r2[0] = r0  ; List_4
    //     0x69b8e8: stur            w0, [x2, #0x17]
    // 0x69b8ec: r0 = "Doubles the yields from power."
    //     0x69b8ec: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b8f0: ldr             x0, [x0, #0xa30]
    // 0x69b8f4: StoreField: r2->field_1b = r0
    //     0x69b8f4: stur            w0, [x2, #0x1b]
    // 0x69b8f8: ldur            x3, [fp, #-0x20]
    // 0x69b8fc: LoadField: r1 = r3->field_b
    //     0x69b8fc: ldur            w1, [x3, #0xb]
    // 0x69b900: LoadField: r4 = r3->field_f
    //     0x69b900: ldur            w4, [x3, #0xf]
    // 0x69b904: DecompressPointer r4
    //     0x69b904: add             x4, x4, HEAP, lsl #32
    // 0x69b908: LoadField: r5 = r4->field_b
    //     0x69b908: ldur            w5, [x4, #0xb]
    // 0x69b90c: r4 = LoadInt32Instr(r1)
    //     0x69b90c: sbfx            x4, x1, #1, #0x1f
    // 0x69b910: stur            x4, [fp, #-0x48]
    // 0x69b914: r1 = LoadInt32Instr(r5)
    //     0x69b914: sbfx            x1, x5, #1, #0x1f
    // 0x69b918: cmp             x4, x1
    // 0x69b91c: b.ne            #0x69b928
    // 0x69b920: mov             x1, x3
    // 0x69b924: r0 = _growToNextCapacity()
    //     0x69b924: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69b928: ldur            x3, [fp, #-0x20]
    // 0x69b92c: ldur            x2, [fp, #-0x48]
    // 0x69b930: add             x0, x2, #1
    // 0x69b934: lsl             x1, x0, #1
    // 0x69b938: StoreField: r3->field_b = r1
    //     0x69b938: stur            w1, [x3, #0xb]
    // 0x69b93c: LoadField: r1 = r3->field_f
    //     0x69b93c: ldur            w1, [x3, #0xf]
    // 0x69b940: DecompressPointer r1
    //     0x69b940: add             x1, x1, HEAP, lsl #32
    // 0x69b944: ldur            x0, [fp, #-0x30]
    // 0x69b948: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69b948: add             x25, x1, x2, lsl #2
    //     0x69b94c: add             x25, x25, #0xf
    //     0x69b950: str             w0, [x25]
    //     0x69b954: tbz             w0, #0, #0x69b970
    //     0x69b958: ldurb           w16, [x1, #-1]
    //     0x69b95c: ldurb           w17, [x0, #-1]
    //     0x69b960: and             x16, x17, x16, lsr #2
    //     0x69b964: tst             x16, HEAP, lsr #32
    //     0x69b968: b.eq            #0x69b970
    //     0x69b96c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69b970: r1 = Null
    //     0x69b970: mov             x1, NULL
    // 0x69b974: r2 = 6
    //     0x69b974: movz            x2, #0x6
    // 0x69b978: r0 = AllocateArray()
    //     0x69b978: bl              #0x82746c  ; AllocateArrayStub
    // 0x69b97c: r16 = "Get "
    //     0x69b97c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69b980: ldr             x16, [x16, #0xb68]
    // 0x69b984: StoreField: r0->field_f = r16
    //     0x69b984: stur            w16, [x0, #0xf]
    // 0x69b988: r16 = Instance_CustomNum
    //     0x69b988: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ac8] Obj!CustomNum@82b7f1
    //     0x69b98c: ldr             x16, [x16, #0xac8]
    // 0x69b990: StoreField: r0->field_13 = r16
    //     0x69b990: stur            w16, [x0, #0x13]
    // 0x69b994: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b994: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69b998: ldr             x16, [x16, #0xa18]
    // 0x69b99c: ArrayStore: r0[0] = r16  ; List_4
    //     0x69b99c: stur            w16, [x0, #0x17]
    // 0x69b9a0: str             x0, [SP]
    // 0x69b9a4: r0 = _interpolate()
    //     0x69b9a4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69b9a8: r1 = <Chapter13Stat>
    //     0x69b9a8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69b9ac: ldr             x1, [x1, #0xf28]
    // 0x69b9b0: stur            x0, [fp, #-0x10]
    // 0x69b9b4: r0 = QuestLevel()
    //     0x69b9b4: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69b9b8: mov             x2, x0
    // 0x69b9bc: r0 = Instance_Tuple2
    //     0x69b9bc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ad0] Obj!Tuple2<Chapter13Stat, CustomNum>@8268f1
    //     0x69b9c0: ldr             x0, [x0, #0xad0]
    // 0x69b9c4: stur            x2, [fp, #-0x30]
    // 0x69b9c8: StoreField: r2->field_f = r0
    //     0x69b9c8: stur            w0, [x2, #0xf]
    // 0x69b9cc: r0 = "Bill Shock 7"
    //     0x69b9cc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ad8] "Bill Shock 7"
    //     0x69b9d0: ldr             x0, [x0, #0xad8]
    // 0x69b9d4: StoreField: r2->field_13 = r0
    //     0x69b9d4: stur            w0, [x2, #0x13]
    // 0x69b9d8: ldur            x0, [fp, #-0x10]
    // 0x69b9dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x69b9dc: stur            w0, [x2, #0x17]
    // 0x69b9e0: r0 = "Doubles the yields from power."
    //     0x69b9e0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69b9e4: ldr             x0, [x0, #0xa30]
    // 0x69b9e8: StoreField: r2->field_1b = r0
    //     0x69b9e8: stur            w0, [x2, #0x1b]
    // 0x69b9ec: ldur            x3, [fp, #-0x20]
    // 0x69b9f0: LoadField: r1 = r3->field_b
    //     0x69b9f0: ldur            w1, [x3, #0xb]
    // 0x69b9f4: LoadField: r4 = r3->field_f
    //     0x69b9f4: ldur            w4, [x3, #0xf]
    // 0x69b9f8: DecompressPointer r4
    //     0x69b9f8: add             x4, x4, HEAP, lsl #32
    // 0x69b9fc: LoadField: r5 = r4->field_b
    //     0x69b9fc: ldur            w5, [x4, #0xb]
    // 0x69ba00: r4 = LoadInt32Instr(r1)
    //     0x69ba00: sbfx            x4, x1, #1, #0x1f
    // 0x69ba04: stur            x4, [fp, #-0x48]
    // 0x69ba08: r1 = LoadInt32Instr(r5)
    //     0x69ba08: sbfx            x1, x5, #1, #0x1f
    // 0x69ba0c: cmp             x4, x1
    // 0x69ba10: b.ne            #0x69ba1c
    // 0x69ba14: mov             x1, x3
    // 0x69ba18: r0 = _growToNextCapacity()
    //     0x69ba18: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69ba1c: ldur            x3, [fp, #-0x20]
    // 0x69ba20: ldur            x2, [fp, #-0x48]
    // 0x69ba24: add             x0, x2, #1
    // 0x69ba28: lsl             x1, x0, #1
    // 0x69ba2c: StoreField: r3->field_b = r1
    //     0x69ba2c: stur            w1, [x3, #0xb]
    // 0x69ba30: LoadField: r1 = r3->field_f
    //     0x69ba30: ldur            w1, [x3, #0xf]
    // 0x69ba34: DecompressPointer r1
    //     0x69ba34: add             x1, x1, HEAP, lsl #32
    // 0x69ba38: ldur            x0, [fp, #-0x30]
    // 0x69ba3c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69ba3c: add             x25, x1, x2, lsl #2
    //     0x69ba40: add             x25, x25, #0xf
    //     0x69ba44: str             w0, [x25]
    //     0x69ba48: tbz             w0, #0, #0x69ba64
    //     0x69ba4c: ldurb           w16, [x1, #-1]
    //     0x69ba50: ldurb           w17, [x0, #-1]
    //     0x69ba54: and             x16, x17, x16, lsr #2
    //     0x69ba58: tst             x16, HEAP, lsr #32
    //     0x69ba5c: b.eq            #0x69ba64
    //     0x69ba60: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69ba64: r1 = Null
    //     0x69ba64: mov             x1, NULL
    // 0x69ba68: r2 = 6
    //     0x69ba68: movz            x2, #0x6
    // 0x69ba6c: r0 = AllocateArray()
    //     0x69ba6c: bl              #0x82746c  ; AllocateArrayStub
    // 0x69ba70: r16 = "Get "
    //     0x69ba70: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69ba74: ldr             x16, [x16, #0xb68]
    // 0x69ba78: StoreField: r0->field_f = r16
    //     0x69ba78: stur            w16, [x0, #0xf]
    // 0x69ba7c: r16 = Instance_CustomNum
    //     0x69ba7c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ae0] Obj!CustomNum@82b7e1
    //     0x69ba80: ldr             x16, [x16, #0xae0]
    // 0x69ba84: StoreField: r0->field_13 = r16
    //     0x69ba84: stur            w16, [x0, #0x13]
    // 0x69ba88: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69ba88: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69ba8c: ldr             x16, [x16, #0xa18]
    // 0x69ba90: ArrayStore: r0[0] = r16  ; List_4
    //     0x69ba90: stur            w16, [x0, #0x17]
    // 0x69ba94: str             x0, [SP]
    // 0x69ba98: r0 = _interpolate()
    //     0x69ba98: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69ba9c: r1 = <Chapter13Stat>
    //     0x69ba9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69baa0: ldr             x1, [x1, #0xf28]
    // 0x69baa4: stur            x0, [fp, #-0x10]
    // 0x69baa8: r0 = QuestLevel()
    //     0x69baa8: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69baac: mov             x2, x0
    // 0x69bab0: r0 = Instance_Tuple2
    //     0x69bab0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ae8] Obj!Tuple2<Chapter13Stat, CustomNum>@8268d1
    //     0x69bab4: ldr             x0, [x0, #0xae8]
    // 0x69bab8: stur            x2, [fp, #-0x30]
    // 0x69babc: StoreField: r2->field_f = r0
    //     0x69babc: stur            w0, [x2, #0xf]
    // 0x69bac0: r0 = "Bill Shock 8"
    //     0x69bac0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28af0] "Bill Shock 8"
    //     0x69bac4: ldr             x0, [x0, #0xaf0]
    // 0x69bac8: StoreField: r2->field_13 = r0
    //     0x69bac8: stur            w0, [x2, #0x13]
    // 0x69bacc: ldur            x0, [fp, #-0x10]
    // 0x69bad0: ArrayStore: r2[0] = r0  ; List_4
    //     0x69bad0: stur            w0, [x2, #0x17]
    // 0x69bad4: r0 = "Doubles the yields from power."
    //     0x69bad4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69bad8: ldr             x0, [x0, #0xa30]
    // 0x69badc: StoreField: r2->field_1b = r0
    //     0x69badc: stur            w0, [x2, #0x1b]
    // 0x69bae0: ldur            x3, [fp, #-0x20]
    // 0x69bae4: LoadField: r1 = r3->field_b
    //     0x69bae4: ldur            w1, [x3, #0xb]
    // 0x69bae8: LoadField: r4 = r3->field_f
    //     0x69bae8: ldur            w4, [x3, #0xf]
    // 0x69baec: DecompressPointer r4
    //     0x69baec: add             x4, x4, HEAP, lsl #32
    // 0x69baf0: LoadField: r5 = r4->field_b
    //     0x69baf0: ldur            w5, [x4, #0xb]
    // 0x69baf4: r4 = LoadInt32Instr(r1)
    //     0x69baf4: sbfx            x4, x1, #1, #0x1f
    // 0x69baf8: stur            x4, [fp, #-0x48]
    // 0x69bafc: r1 = LoadInt32Instr(r5)
    //     0x69bafc: sbfx            x1, x5, #1, #0x1f
    // 0x69bb00: cmp             x4, x1
    // 0x69bb04: b.ne            #0x69bb10
    // 0x69bb08: mov             x1, x3
    // 0x69bb0c: r0 = _growToNextCapacity()
    //     0x69bb0c: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bb10: ldur            x3, [fp, #-0x20]
    // 0x69bb14: ldur            x2, [fp, #-0x48]
    // 0x69bb18: add             x0, x2, #1
    // 0x69bb1c: lsl             x1, x0, #1
    // 0x69bb20: StoreField: r3->field_b = r1
    //     0x69bb20: stur            w1, [x3, #0xb]
    // 0x69bb24: LoadField: r1 = r3->field_f
    //     0x69bb24: ldur            w1, [x3, #0xf]
    // 0x69bb28: DecompressPointer r1
    //     0x69bb28: add             x1, x1, HEAP, lsl #32
    // 0x69bb2c: ldur            x0, [fp, #-0x30]
    // 0x69bb30: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69bb30: add             x25, x1, x2, lsl #2
    //     0x69bb34: add             x25, x25, #0xf
    //     0x69bb38: str             w0, [x25]
    //     0x69bb3c: tbz             w0, #0, #0x69bb58
    //     0x69bb40: ldurb           w16, [x1, #-1]
    //     0x69bb44: ldurb           w17, [x0, #-1]
    //     0x69bb48: and             x16, x17, x16, lsr #2
    //     0x69bb4c: tst             x16, HEAP, lsr #32
    //     0x69bb50: b.eq            #0x69bb58
    //     0x69bb54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69bb58: r1 = Null
    //     0x69bb58: mov             x1, NULL
    // 0x69bb5c: r2 = 6
    //     0x69bb5c: movz            x2, #0x6
    // 0x69bb60: r0 = AllocateArray()
    //     0x69bb60: bl              #0x82746c  ; AllocateArrayStub
    // 0x69bb64: r16 = "Get "
    //     0x69bb64: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69bb68: ldr             x16, [x16, #0xb68]
    // 0x69bb6c: StoreField: r0->field_f = r16
    //     0x69bb6c: stur            w16, [x0, #0xf]
    // 0x69bb70: r16 = Instance_CustomNum
    //     0x69bb70: add             x16, PP, #0x28, lsl #12  ; [pp+0x28af8] Obj!CustomNum@82b7d1
    //     0x69bb74: ldr             x16, [x16, #0xaf8]
    // 0x69bb78: StoreField: r0->field_13 = r16
    //     0x69bb78: stur            w16, [x0, #0x13]
    // 0x69bb7c: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69bb7c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69bb80: ldr             x16, [x16, #0xa18]
    // 0x69bb84: ArrayStore: r0[0] = r16  ; List_4
    //     0x69bb84: stur            w16, [x0, #0x17]
    // 0x69bb88: str             x0, [SP]
    // 0x69bb8c: r0 = _interpolate()
    //     0x69bb8c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69bb90: r1 = <Chapter13Stat>
    //     0x69bb90: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69bb94: ldr             x1, [x1, #0xf28]
    // 0x69bb98: stur            x0, [fp, #-0x10]
    // 0x69bb9c: r0 = QuestLevel()
    //     0x69bb9c: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69bba0: mov             x2, x0
    // 0x69bba4: r0 = Instance_Tuple2
    //     0x69bba4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b00] Obj!Tuple2<Chapter13Stat, CustomNum>@8268b1
    //     0x69bba8: ldr             x0, [x0, #0xb00]
    // 0x69bbac: stur            x2, [fp, #-0x30]
    // 0x69bbb0: StoreField: r2->field_f = r0
    //     0x69bbb0: stur            w0, [x2, #0xf]
    // 0x69bbb4: r0 = "Bill Shock 9"
    //     0x69bbb4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b08] "Bill Shock 9"
    //     0x69bbb8: ldr             x0, [x0, #0xb08]
    // 0x69bbbc: StoreField: r2->field_13 = r0
    //     0x69bbbc: stur            w0, [x2, #0x13]
    // 0x69bbc0: ldur            x0, [fp, #-0x10]
    // 0x69bbc4: ArrayStore: r2[0] = r0  ; List_4
    //     0x69bbc4: stur            w0, [x2, #0x17]
    // 0x69bbc8: r0 = "Doubles the yields from power."
    //     0x69bbc8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69bbcc: ldr             x0, [x0, #0xa30]
    // 0x69bbd0: StoreField: r2->field_1b = r0
    //     0x69bbd0: stur            w0, [x2, #0x1b]
    // 0x69bbd4: ldur            x3, [fp, #-0x20]
    // 0x69bbd8: LoadField: r1 = r3->field_b
    //     0x69bbd8: ldur            w1, [x3, #0xb]
    // 0x69bbdc: LoadField: r4 = r3->field_f
    //     0x69bbdc: ldur            w4, [x3, #0xf]
    // 0x69bbe0: DecompressPointer r4
    //     0x69bbe0: add             x4, x4, HEAP, lsl #32
    // 0x69bbe4: LoadField: r5 = r4->field_b
    //     0x69bbe4: ldur            w5, [x4, #0xb]
    // 0x69bbe8: r4 = LoadInt32Instr(r1)
    //     0x69bbe8: sbfx            x4, x1, #1, #0x1f
    // 0x69bbec: stur            x4, [fp, #-0x48]
    // 0x69bbf0: r1 = LoadInt32Instr(r5)
    //     0x69bbf0: sbfx            x1, x5, #1, #0x1f
    // 0x69bbf4: cmp             x4, x1
    // 0x69bbf8: b.ne            #0x69bc04
    // 0x69bbfc: mov             x1, x3
    // 0x69bc00: r0 = _growToNextCapacity()
    //     0x69bc00: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bc04: ldur            x3, [fp, #-0x20]
    // 0x69bc08: ldur            x2, [fp, #-0x48]
    // 0x69bc0c: add             x0, x2, #1
    // 0x69bc10: lsl             x1, x0, #1
    // 0x69bc14: StoreField: r3->field_b = r1
    //     0x69bc14: stur            w1, [x3, #0xb]
    // 0x69bc18: LoadField: r1 = r3->field_f
    //     0x69bc18: ldur            w1, [x3, #0xf]
    // 0x69bc1c: DecompressPointer r1
    //     0x69bc1c: add             x1, x1, HEAP, lsl #32
    // 0x69bc20: ldur            x0, [fp, #-0x30]
    // 0x69bc24: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69bc24: add             x25, x1, x2, lsl #2
    //     0x69bc28: add             x25, x25, #0xf
    //     0x69bc2c: str             w0, [x25]
    //     0x69bc30: tbz             w0, #0, #0x69bc4c
    //     0x69bc34: ldurb           w16, [x1, #-1]
    //     0x69bc38: ldurb           w17, [x0, #-1]
    //     0x69bc3c: and             x16, x17, x16, lsr #2
    //     0x69bc40: tst             x16, HEAP, lsr #32
    //     0x69bc44: b.eq            #0x69bc4c
    //     0x69bc48: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69bc4c: r1 = Null
    //     0x69bc4c: mov             x1, NULL
    // 0x69bc50: r2 = 6
    //     0x69bc50: movz            x2, #0x6
    // 0x69bc54: r0 = AllocateArray()
    //     0x69bc54: bl              #0x82746c  ; AllocateArrayStub
    // 0x69bc58: r16 = "Get "
    //     0x69bc58: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69bc5c: ldr             x16, [x16, #0xb68]
    // 0x69bc60: StoreField: r0->field_f = r16
    //     0x69bc60: stur            w16, [x0, #0xf]
    // 0x69bc64: r16 = Instance_CustomNum
    //     0x69bc64: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b10] Obj!CustomNum@82b7c1
    //     0x69bc68: ldr             x16, [x16, #0xb10]
    // 0x69bc6c: StoreField: r0->field_13 = r16
    //     0x69bc6c: stur            w16, [x0, #0x13]
    // 0x69bc70: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69bc70: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69bc74: ldr             x16, [x16, #0xa18]
    // 0x69bc78: ArrayStore: r0[0] = r16  ; List_4
    //     0x69bc78: stur            w16, [x0, #0x17]
    // 0x69bc7c: str             x0, [SP]
    // 0x69bc80: r0 = _interpolate()
    //     0x69bc80: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69bc84: r1 = <Chapter13Stat>
    //     0x69bc84: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69bc88: ldr             x1, [x1, #0xf28]
    // 0x69bc8c: stur            x0, [fp, #-0x10]
    // 0x69bc90: r0 = QuestLevel()
    //     0x69bc90: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69bc94: mov             x2, x0
    // 0x69bc98: r0 = Instance_Tuple2
    //     0x69bc98: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b18] Obj!Tuple2<Chapter13Stat, CustomNum>@826891
    //     0x69bc9c: ldr             x0, [x0, #0xb18]
    // 0x69bca0: stur            x2, [fp, #-0x30]
    // 0x69bca4: StoreField: r2->field_f = r0
    //     0x69bca4: stur            w0, [x2, #0xf]
    // 0x69bca8: r0 = "Bill Shock 10"
    //     0x69bca8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b20] "Bill Shock 10"
    //     0x69bcac: ldr             x0, [x0, #0xb20]
    // 0x69bcb0: StoreField: r2->field_13 = r0
    //     0x69bcb0: stur            w0, [x2, #0x13]
    // 0x69bcb4: ldur            x0, [fp, #-0x10]
    // 0x69bcb8: ArrayStore: r2[0] = r0  ; List_4
    //     0x69bcb8: stur            w0, [x2, #0x17]
    // 0x69bcbc: r0 = "Doubles the yields from power."
    //     0x69bcbc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69bcc0: ldr             x0, [x0, #0xa30]
    // 0x69bcc4: StoreField: r2->field_1b = r0
    //     0x69bcc4: stur            w0, [x2, #0x1b]
    // 0x69bcc8: ldur            x3, [fp, #-0x20]
    // 0x69bccc: LoadField: r1 = r3->field_b
    //     0x69bccc: ldur            w1, [x3, #0xb]
    // 0x69bcd0: LoadField: r4 = r3->field_f
    //     0x69bcd0: ldur            w4, [x3, #0xf]
    // 0x69bcd4: DecompressPointer r4
    //     0x69bcd4: add             x4, x4, HEAP, lsl #32
    // 0x69bcd8: LoadField: r5 = r4->field_b
    //     0x69bcd8: ldur            w5, [x4, #0xb]
    // 0x69bcdc: r4 = LoadInt32Instr(r1)
    //     0x69bcdc: sbfx            x4, x1, #1, #0x1f
    // 0x69bce0: stur            x4, [fp, #-0x48]
    // 0x69bce4: r1 = LoadInt32Instr(r5)
    //     0x69bce4: sbfx            x1, x5, #1, #0x1f
    // 0x69bce8: cmp             x4, x1
    // 0x69bcec: b.ne            #0x69bcf8
    // 0x69bcf0: mov             x1, x3
    // 0x69bcf4: r0 = _growToNextCapacity()
    //     0x69bcf4: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bcf8: ldur            x3, [fp, #-0x20]
    // 0x69bcfc: ldur            x2, [fp, #-0x48]
    // 0x69bd00: add             x0, x2, #1
    // 0x69bd04: lsl             x1, x0, #1
    // 0x69bd08: StoreField: r3->field_b = r1
    //     0x69bd08: stur            w1, [x3, #0xb]
    // 0x69bd0c: LoadField: r1 = r3->field_f
    //     0x69bd0c: ldur            w1, [x3, #0xf]
    // 0x69bd10: DecompressPointer r1
    //     0x69bd10: add             x1, x1, HEAP, lsl #32
    // 0x69bd14: ldur            x0, [fp, #-0x30]
    // 0x69bd18: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69bd18: add             x25, x1, x2, lsl #2
    //     0x69bd1c: add             x25, x25, #0xf
    //     0x69bd20: str             w0, [x25]
    //     0x69bd24: tbz             w0, #0, #0x69bd40
    //     0x69bd28: ldurb           w16, [x1, #-1]
    //     0x69bd2c: ldurb           w17, [x0, #-1]
    //     0x69bd30: and             x16, x17, x16, lsr #2
    //     0x69bd34: tst             x16, HEAP, lsr #32
    //     0x69bd38: b.eq            #0x69bd40
    //     0x69bd3c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69bd40: r1 = Null
    //     0x69bd40: mov             x1, NULL
    // 0x69bd44: r2 = 6
    //     0x69bd44: movz            x2, #0x6
    // 0x69bd48: r0 = AllocateArray()
    //     0x69bd48: bl              #0x82746c  ; AllocateArrayStub
    // 0x69bd4c: r16 = "Get "
    //     0x69bd4c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69bd50: ldr             x16, [x16, #0xb68]
    // 0x69bd54: StoreField: r0->field_f = r16
    //     0x69bd54: stur            w16, [x0, #0xf]
    // 0x69bd58: r16 = Instance_CustomNum
    //     0x69bd58: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b28] Obj!CustomNum@82b7b1
    //     0x69bd5c: ldr             x16, [x16, #0xb28]
    // 0x69bd60: StoreField: r0->field_13 = r16
    //     0x69bd60: stur            w16, [x0, #0x13]
    // 0x69bd64: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69bd64: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69bd68: ldr             x16, [x16, #0xa18]
    // 0x69bd6c: ArrayStore: r0[0] = r16  ; List_4
    //     0x69bd6c: stur            w16, [x0, #0x17]
    // 0x69bd70: str             x0, [SP]
    // 0x69bd74: r0 = _interpolate()
    //     0x69bd74: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69bd78: r1 = <Chapter13Stat>
    //     0x69bd78: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69bd7c: ldr             x1, [x1, #0xf28]
    // 0x69bd80: stur            x0, [fp, #-0x10]
    // 0x69bd84: r0 = QuestLevel()
    //     0x69bd84: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69bd88: mov             x2, x0
    // 0x69bd8c: r0 = Instance_Tuple2
    //     0x69bd8c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b30] Obj!Tuple2<Chapter13Stat, CustomNum>@826871
    //     0x69bd90: ldr             x0, [x0, #0xb30]
    // 0x69bd94: stur            x2, [fp, #-0x30]
    // 0x69bd98: StoreField: r2->field_f = r0
    //     0x69bd98: stur            w0, [x2, #0xf]
    // 0x69bd9c: r0 = "Bill Shock 11"
    //     0x69bd9c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b38] "Bill Shock 11"
    //     0x69bda0: ldr             x0, [x0, #0xb38]
    // 0x69bda4: StoreField: r2->field_13 = r0
    //     0x69bda4: stur            w0, [x2, #0x13]
    // 0x69bda8: ldur            x0, [fp, #-0x10]
    // 0x69bdac: ArrayStore: r2[0] = r0  ; List_4
    //     0x69bdac: stur            w0, [x2, #0x17]
    // 0x69bdb0: r0 = "Doubles the yields from power."
    //     0x69bdb0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a30] "Doubles the yields from power."
    //     0x69bdb4: ldr             x0, [x0, #0xa30]
    // 0x69bdb8: StoreField: r2->field_1b = r0
    //     0x69bdb8: stur            w0, [x2, #0x1b]
    // 0x69bdbc: ldur            x0, [fp, #-0x20]
    // 0x69bdc0: LoadField: r1 = r0->field_b
    //     0x69bdc0: ldur            w1, [x0, #0xb]
    // 0x69bdc4: LoadField: r3 = r0->field_f
    //     0x69bdc4: ldur            w3, [x0, #0xf]
    // 0x69bdc8: DecompressPointer r3
    //     0x69bdc8: add             x3, x3, HEAP, lsl #32
    // 0x69bdcc: LoadField: r4 = r3->field_b
    //     0x69bdcc: ldur            w4, [x3, #0xb]
    // 0x69bdd0: r3 = LoadInt32Instr(r1)
    //     0x69bdd0: sbfx            x3, x1, #1, #0x1f
    // 0x69bdd4: stur            x3, [fp, #-0x48]
    // 0x69bdd8: r1 = LoadInt32Instr(r4)
    //     0x69bdd8: sbfx            x1, x4, #1, #0x1f
    // 0x69bddc: cmp             x3, x1
    // 0x69bde0: b.ne            #0x69bdec
    // 0x69bde4: mov             x1, x0
    // 0x69bde8: r0 = _growToNextCapacity()
    //     0x69bde8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bdec: ldur            x3, [fp, #-0x20]
    // 0x69bdf0: ldur            x2, [fp, #-0x48]
    // 0x69bdf4: add             x0, x2, #1
    // 0x69bdf8: lsl             x1, x0, #1
    // 0x69bdfc: StoreField: r3->field_b = r1
    //     0x69bdfc: stur            w1, [x3, #0xb]
    // 0x69be00: LoadField: r1 = r3->field_f
    //     0x69be00: ldur            w1, [x3, #0xf]
    // 0x69be04: DecompressPointer r1
    //     0x69be04: add             x1, x1, HEAP, lsl #32
    // 0x69be08: ldur            x0, [fp, #-0x30]
    // 0x69be0c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69be0c: add             x25, x1, x2, lsl #2
    //     0x69be10: add             x25, x25, #0xf
    //     0x69be14: str             w0, [x25]
    //     0x69be18: tbz             w0, #0, #0x69be34
    //     0x69be1c: ldurb           w16, [x1, #-1]
    //     0x69be20: ldurb           w17, [x0, #-1]
    //     0x69be24: and             x16, x17, x16, lsr #2
    //     0x69be28: tst             x16, HEAP, lsr #32
    //     0x69be2c: b.eq            #0x69be34
    //     0x69be30: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69be34: r1 = Null
    //     0x69be34: mov             x1, NULL
    // 0x69be38: r2 = 6
    //     0x69be38: movz            x2, #0x6
    // 0x69be3c: r0 = AllocateArray()
    //     0x69be3c: bl              #0x82746c  ; AllocateArrayStub
    // 0x69be40: r16 = "Get "
    //     0x69be40: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] "Get "
    //     0x69be44: ldr             x16, [x16, #0xb68]
    // 0x69be48: StoreField: r0->field_f = r16
    //     0x69be48: stur            w16, [x0, #0xf]
    // 0x69be4c: r16 = Instance_CustomNum
    //     0x69be4c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b40] Obj!CustomNum@82b791
    //     0x69be50: ldr             x16, [x16, #0xb40]
    // 0x69be54: StoreField: r0->field_13 = r16
    //     0x69be54: stur            w16, [x0, #0x13]
    // 0x69be58: r16 = " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69be58: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a18] " power in 5 minutes. Quest will automatically cancel if unsuccessful."
    //     0x69be5c: ldr             x16, [x16, #0xa18]
    // 0x69be60: ArrayStore: r0[0] = r16  ; List_4
    //     0x69be60: stur            w16, [x0, #0x17]
    // 0x69be64: str             x0, [SP]
    // 0x69be68: r0 = _interpolate()
    //     0x69be68: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69be6c: r1 = <Chapter13Stat>
    //     0x69be6c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69be70: ldr             x1, [x1, #0xf28]
    // 0x69be74: stur            x0, [fp, #-0x10]
    // 0x69be78: r0 = QuestLevel()
    //     0x69be78: bl              #0x69e3a8  ; AllocateQuestLevelStub -> QuestLevel<X0> (size=0x20)
    // 0x69be7c: mov             x2, x0
    // 0x69be80: r0 = Instance_Tuple2
    //     0x69be80: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b48] Obj!Tuple2<Chapter13Stat, CustomNum>@826851
    //     0x69be84: ldr             x0, [x0, #0xb48]
    // 0x69be88: stur            x2, [fp, #-0x30]
    // 0x69be8c: StoreField: r2->field_f = r0
    //     0x69be8c: stur            w0, [x2, #0xf]
    // 0x69be90: r0 = "Bill Shock 12"
    //     0x69be90: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b50] "Bill Shock 12"
    //     0x69be94: ldr             x0, [x0, #0xb50]
    // 0x69be98: StoreField: r2->field_13 = r0
    //     0x69be98: stur            w0, [x2, #0x13]
    // 0x69be9c: ldur            x0, [fp, #-0x10]
    // 0x69bea0: ArrayStore: r2[0] = r0  ; List_4
    //     0x69bea0: stur            w0, [x2, #0x17]
    // 0x69bea4: r0 = "Doubles the yields from power and unlocks recognition."
    //     0x69bea4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b58] "Doubles the yields from power and unlocks recognition."
    //     0x69bea8: ldr             x0, [x0, #0xb58]
    // 0x69beac: StoreField: r2->field_1b = r0
    //     0x69beac: stur            w0, [x2, #0x1b]
    // 0x69beb0: ldur            x0, [fp, #-0x20]
    // 0x69beb4: LoadField: r1 = r0->field_b
    //     0x69beb4: ldur            w1, [x0, #0xb]
    // 0x69beb8: LoadField: r3 = r0->field_f
    //     0x69beb8: ldur            w3, [x0, #0xf]
    // 0x69bebc: DecompressPointer r3
    //     0x69bebc: add             x3, x3, HEAP, lsl #32
    // 0x69bec0: LoadField: r4 = r3->field_b
    //     0x69bec0: ldur            w4, [x3, #0xb]
    // 0x69bec4: r3 = LoadInt32Instr(r1)
    //     0x69bec4: sbfx            x3, x1, #1, #0x1f
    // 0x69bec8: stur            x3, [fp, #-0x48]
    // 0x69becc: r1 = LoadInt32Instr(r4)
    //     0x69becc: sbfx            x1, x4, #1, #0x1f
    // 0x69bed0: cmp             x3, x1
    // 0x69bed4: b.ne            #0x69bee0
    // 0x69bed8: mov             x1, x0
    // 0x69bedc: r0 = _growToNextCapacity()
    //     0x69bedc: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bee0: ldur            x2, [fp, #-0x20]
    // 0x69bee4: ldur            x4, [fp, #-0x28]
    // 0x69bee8: ldur            x3, [fp, #-0x48]
    // 0x69beec: add             x0, x3, #1
    // 0x69bef0: lsl             x1, x0, #1
    // 0x69bef4: StoreField: r2->field_b = r1
    //     0x69bef4: stur            w1, [x2, #0xb]
    // 0x69bef8: LoadField: r1 = r2->field_f
    //     0x69bef8: ldur            w1, [x2, #0xf]
    // 0x69befc: DecompressPointer r1
    //     0x69befc: add             x1, x1, HEAP, lsl #32
    // 0x69bf00: ldur            x0, [fp, #-0x30]
    // 0x69bf04: ArrayStore: r1[r3] = r0  ; List_4
    //     0x69bf04: add             x25, x1, x3, lsl #2
    //     0x69bf08: add             x25, x25, #0xf
    //     0x69bf0c: str             w0, [x25]
    //     0x69bf10: tbz             w0, #0, #0x69bf2c
    //     0x69bf14: ldurb           w16, [x1, #-1]
    //     0x69bf18: ldurb           w17, [x0, #-1]
    //     0x69bf1c: and             x16, x17, x16, lsr #2
    //     0x69bf20: tst             x16, HEAP, lsr #32
    //     0x69bf24: b.eq            #0x69bf2c
    //     0x69bf28: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69bf2c: LoadField: r0 = r4->field_b
    //     0x69bf2c: ldur            w0, [x4, #0xb]
    // 0x69bf30: LoadField: r1 = r4->field_f
    //     0x69bf30: ldur            w1, [x4, #0xf]
    // 0x69bf34: DecompressPointer r1
    //     0x69bf34: add             x1, x1, HEAP, lsl #32
    // 0x69bf38: LoadField: r3 = r1->field_b
    //     0x69bf38: ldur            w3, [x1, #0xb]
    // 0x69bf3c: r5 = LoadInt32Instr(r0)
    //     0x69bf3c: sbfx            x5, x0, #1, #0x1f
    // 0x69bf40: stur            x5, [fp, #-0x48]
    // 0x69bf44: r0 = LoadInt32Instr(r3)
    //     0x69bf44: sbfx            x0, x3, #1, #0x1f
    // 0x69bf48: cmp             x5, x0
    // 0x69bf4c: b.ne            #0x69bf58
    // 0x69bf50: mov             x1, x4
    // 0x69bf54: r0 = _growToNextCapacity()
    //     0x69bf54: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bf58: ldur            x0, [fp, #-0x28]
    // 0x69bf5c: ldur            x1, [fp, #-0x48]
    // 0x69bf60: add             x2, x1, #1
    // 0x69bf64: stur            x2, [fp, #-0x50]
    // 0x69bf68: lsl             x3, x2, #1
    // 0x69bf6c: StoreField: r0->field_b = r3
    //     0x69bf6c: stur            w3, [x0, #0xb]
    // 0x69bf70: LoadField: r3 = r0->field_f
    //     0x69bf70: ldur            w3, [x0, #0xf]
    // 0x69bf74: DecompressPointer r3
    //     0x69bf74: add             x3, x3, HEAP, lsl #32
    // 0x69bf78: add             x4, x3, x1, lsl #2
    // 0x69bf7c: r16 = Instance_QuestLevel
    //     0x69bf7c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b60] Obj!QuestLevel<Chapter13Stat>@8286b1
    //     0x69bf80: ldr             x16, [x16, #0xb60]
    // 0x69bf84: StoreField: r4->field_f = r16
    //     0x69bf84: stur            w16, [x4, #0xf]
    // 0x69bf88: LoadField: r1 = r3->field_b
    //     0x69bf88: ldur            w1, [x3, #0xb]
    // 0x69bf8c: r3 = LoadInt32Instr(r1)
    //     0x69bf8c: sbfx            x3, x1, #1, #0x1f
    // 0x69bf90: cmp             x2, x3
    // 0x69bf94: b.ne            #0x69bfa0
    // 0x69bf98: mov             x1, x0
    // 0x69bf9c: r0 = _growToNextCapacity()
    //     0x69bf9c: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bfa0: ldur            x1, [fp, #-0x50]
    // 0x69bfa4: ldur            x0, [fp, #-0x28]
    // 0x69bfa8: add             x2, x1, #1
    // 0x69bfac: stur            x2, [fp, #-0x48]
    // 0x69bfb0: lsl             x3, x2, #1
    // 0x69bfb4: StoreField: r0->field_b = r3
    //     0x69bfb4: stur            w3, [x0, #0xb]
    // 0x69bfb8: LoadField: r3 = r0->field_f
    //     0x69bfb8: ldur            w3, [x0, #0xf]
    // 0x69bfbc: DecompressPointer r3
    //     0x69bfbc: add             x3, x3, HEAP, lsl #32
    // 0x69bfc0: add             x4, x3, x1, lsl #2
    // 0x69bfc4: r16 = Instance_QuestLevel
    //     0x69bfc4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b68] Obj!QuestLevel<Chapter13Stat>@828691
    //     0x69bfc8: ldr             x16, [x16, #0xb68]
    // 0x69bfcc: StoreField: r4->field_f = r16
    //     0x69bfcc: stur            w16, [x4, #0xf]
    // 0x69bfd0: LoadField: r1 = r3->field_b
    //     0x69bfd0: ldur            w1, [x3, #0xb]
    // 0x69bfd4: r3 = LoadInt32Instr(r1)
    //     0x69bfd4: sbfx            x3, x1, #1, #0x1f
    // 0x69bfd8: cmp             x2, x3
    // 0x69bfdc: b.ne            #0x69bfe8
    // 0x69bfe0: mov             x1, x0
    // 0x69bfe4: r0 = _growToNextCapacity()
    //     0x69bfe4: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69bfe8: ldur            x1, [fp, #-0x48]
    // 0x69bfec: ldur            x0, [fp, #-0x28]
    // 0x69bff0: add             x2, x1, #1
    // 0x69bff4: stur            x2, [fp, #-0x50]
    // 0x69bff8: lsl             x3, x2, #1
    // 0x69bffc: StoreField: r0->field_b = r3
    //     0x69bffc: stur            w3, [x0, #0xb]
    // 0x69c000: LoadField: r3 = r0->field_f
    //     0x69c000: ldur            w3, [x0, #0xf]
    // 0x69c004: DecompressPointer r3
    //     0x69c004: add             x3, x3, HEAP, lsl #32
    // 0x69c008: add             x4, x3, x1, lsl #2
    // 0x69c00c: r16 = Instance_QuestLevel
    //     0x69c00c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b70] Obj!QuestLevel<Chapter13Stat>@828671
    //     0x69c010: ldr             x16, [x16, #0xb70]
    // 0x69c014: StoreField: r4->field_f = r16
    //     0x69c014: stur            w16, [x4, #0xf]
    // 0x69c018: LoadField: r1 = r3->field_b
    //     0x69c018: ldur            w1, [x3, #0xb]
    // 0x69c01c: r3 = LoadInt32Instr(r1)
    //     0x69c01c: sbfx            x3, x1, #1, #0x1f
    // 0x69c020: cmp             x2, x3
    // 0x69c024: b.ne            #0x69c030
    // 0x69c028: mov             x1, x0
    // 0x69c02c: r0 = _growToNextCapacity()
    //     0x69c02c: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69c030: ldur            x1, [fp, #-0x50]
    // 0x69c034: ldur            x0, [fp, #-0x28]
    // 0x69c038: add             x2, x1, #1
    // 0x69c03c: stur            x2, [fp, #-0x48]
    // 0x69c040: lsl             x3, x2, #1
    // 0x69c044: StoreField: r0->field_b = r3
    //     0x69c044: stur            w3, [x0, #0xb]
    // 0x69c048: LoadField: r3 = r0->field_f
    //     0x69c048: ldur            w3, [x0, #0xf]
    // 0x69c04c: DecompressPointer r3
    //     0x69c04c: add             x3, x3, HEAP, lsl #32
    // 0x69c050: add             x4, x3, x1, lsl #2
    // 0x69c054: r16 = Instance_QuestLevel
    //     0x69c054: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b78] Obj!QuestLevel<Chapter13Stat>@828651
    //     0x69c058: ldr             x16, [x16, #0xb78]
    // 0x69c05c: StoreField: r4->field_f = r16
    //     0x69c05c: stur            w16, [x4, #0xf]
    // 0x69c060: LoadField: r1 = r3->field_b
    //     0x69c060: ldur            w1, [x3, #0xb]
    // 0x69c064: r3 = LoadInt32Instr(r1)
    //     0x69c064: sbfx            x3, x1, #1, #0x1f
    // 0x69c068: cmp             x2, x3
    // 0x69c06c: b.ne            #0x69c078
    // 0x69c070: mov             x1, x0
    // 0x69c074: r0 = _growToNextCapacity()
    //     0x69c074: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69c078: ldur            x1, [fp, #-0x48]
    // 0x69c07c: ldur            x0, [fp, #-0x28]
    // 0x69c080: add             x2, x1, #1
    // 0x69c084: stur            x2, [fp, #-0x50]
    // 0x69c088: lsl             x3, x2, #1
    // 0x69c08c: StoreField: r0->field_b = r3
    //     0x69c08c: stur            w3, [x0, #0xb]
    // 0x69c090: LoadField: r3 = r0->field_f
    //     0x69c090: ldur            w3, [x0, #0xf]
    // 0x69c094: DecompressPointer r3
    //     0x69c094: add             x3, x3, HEAP, lsl #32
    // 0x69c098: add             x4, x3, x1, lsl #2
    // 0x69c09c: r16 = Instance_QuestLevel
    //     0x69c09c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b80] Obj!QuestLevel<Chapter13Stat>@828631
    //     0x69c0a0: ldr             x16, [x16, #0xb80]
    // 0x69c0a4: StoreField: r4->field_f = r16
    //     0x69c0a4: stur            w16, [x4, #0xf]
    // 0x69c0a8: LoadField: r1 = r3->field_b
    //     0x69c0a8: ldur            w1, [x3, #0xb]
    // 0x69c0ac: r3 = LoadInt32Instr(r1)
    //     0x69c0ac: sbfx            x3, x1, #1, #0x1f
    // 0x69c0b0: cmp             x2, x3
    // 0x69c0b4: b.ne            #0x69c0c0
    // 0x69c0b8: mov             x1, x0
    // 0x69c0bc: r0 = _growToNextCapacity()
    //     0x69c0bc: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69c0c0: ldur            x1, [fp, #-0x50]
    // 0x69c0c4: ldur            x0, [fp, #-0x28]
    // 0x69c0c8: add             x2, x1, #1
    // 0x69c0cc: lsl             x3, x2, #1
    // 0x69c0d0: StoreField: r0->field_b = r3
    //     0x69c0d0: stur            w3, [x0, #0xb]
    // 0x69c0d4: LoadField: r2 = r0->field_f
    //     0x69c0d4: ldur            w2, [x0, #0xf]
    // 0x69c0d8: DecompressPointer r2
    //     0x69c0d8: add             x2, x2, HEAP, lsl #32
    // 0x69c0dc: add             x3, x2, x1, lsl #2
    // 0x69c0e0: r16 = Instance_QuestLevel
    //     0x69c0e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b88] Obj!QuestLevel<Chapter13Stat>@828611
    //     0x69c0e4: ldr             x16, [x16, #0xb88]
    // 0x69c0e8: StoreField: r3->field_f = r16
    //     0x69c0e8: stur            w16, [x3, #0xf]
    // 0x69c0ec: b               #0x69c0f4
    // 0x69c0f0: ldur            x0, [fp, #-0x28]
    // 0x69c0f4: ldur            x3, [fp, #-8]
    // 0x69c0f8: LoadField: r4 = r3->field_37
    //     0x69c0f8: ldur            w4, [x3, #0x37]
    // 0x69c0fc: DecompressPointer r4
    //     0x69c0fc: add             x4, x4, HEAP, lsl #32
    // 0x69c100: stur            x4, [fp, #-0x30]
    // 0x69c104: LoadField: r1 = r3->field_8b
    //     0x69c104: ldur            x1, [x3, #0x8b]
    // 0x69c108: LoadField: r2 = r3->field_9f
    //     0x69c108: ldur            w2, [x3, #0x9f]
    // 0x69c10c: DecompressPointer r2
    //     0x69c10c: add             x2, x2, HEAP, lsl #32
    // 0x69c110: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69c114: cmp             w2, w16
    // 0x69c118: b.eq            #0x69e384
    // 0x69c11c: LoadField: r5 = r2->field_b
    //     0x69c11c: ldur            w5, [x2, #0xb]
    // 0x69c120: r2 = LoadInt32Instr(r5)
    //     0x69c120: sbfx            x2, x5, #1, #0x1f
    // 0x69c124: cmp             x1, x2
    // 0x69c128: r16 = true
    //     0x69c128: add             x16, NULL, #0x20  ; true
    // 0x69c12c: r17 = false
    //     0x69c12c: add             x17, NULL, #0x30  ; false
    // 0x69c130: csel            x5, x16, x17, lt
    // 0x69c134: stur            x5, [fp, #-0x10]
    // 0x69c138: r1 = Function '<anonymous closure>':.
    //     0x69c138: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b90] AnonymousClosure: (0x69f7ec), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c13c: ldr             x1, [x1, #0xb90]
    // 0x69c140: r2 = Null
    //     0x69c140: mov             x2, NULL
    // 0x69c144: r0 = AllocateClosure()
    //     0x69c144: bl              #0x826750  ; AllocateClosureStub
    // 0x69c148: r1 = <Chapter13Stat>
    //     0x69c148: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69c14c: ldr             x1, [x1, #0xf28]
    // 0x69c150: stur            x0, [fp, #-0x38]
    // 0x69c154: r0 = PrestigeButton()
    //     0x69c154: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x69c158: mov             x3, x0
    // 0x69c15c: ldur            x0, [fp, #-0x38]
    // 0x69c160: stur            x3, [fp, #-0x40]
    // 0x69c164: StoreField: r3->field_1f = r0
    //     0x69c164: stur            w0, [x3, #0x1f]
    // 0x69c168: r0 = Instance_Chapter13Stat
    //     0x69c168: add             x0, PP, #0x11, lsl #12  ; [pp+0x11340] Obj!Chapter13Stat@85fa81
    //     0x69c16c: ldr             x0, [x0, #0x340]
    // 0x69c170: StoreField: r3->field_1b = r0
    //     0x69c170: stur            w0, [x3, #0x1b]
    // 0x69c174: r1 = Function '<anonymous closure>':.
    //     0x69c174: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b98] AnonymousClosure: (0x518ee0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c178: ldr             x1, [x1, #0xb98]
    // 0x69c17c: r2 = Null
    //     0x69c17c: mov             x2, NULL
    // 0x69c180: r0 = AllocateClosure()
    //     0x69c180: bl              #0x826750  ; AllocateClosureStub
    // 0x69c184: mov             x1, x0
    // 0x69c188: ldur            x0, [fp, #-0x40]
    // 0x69c18c: StoreField: r0->field_2f = r1
    //     0x69c18c: stur            w1, [x0, #0x2f]
    // 0x69c190: ldur            x2, [fp, #-0x18]
    // 0x69c194: r1 = Function '<anonymous closure>':.
    //     0x69c194: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] AnonymousClosure: (0x69f734), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c198: ldr             x1, [x1, #0xba0]
    // 0x69c19c: r0 = AllocateClosure()
    //     0x69c19c: bl              #0x826750  ; AllocateClosureStub
    // 0x69c1a0: mov             x1, x0
    // 0x69c1a4: ldur            x0, [fp, #-0x40]
    // 0x69c1a8: StoreField: r0->field_33 = r1
    //     0x69c1a8: stur            w1, [x0, #0x33]
    // 0x69c1ac: ldur            x1, [fp, #-0x30]
    // 0x69c1b0: ArrayStore: r0[0] = r1  ; List_4
    //     0x69c1b0: stur            w1, [x0, #0x17]
    // 0x69c1b4: r3 = Closure: (Chapter13Stat?) => String from Function 'humanName': static.
    //     0x69c1b4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ba8] Closure: (Chapter13Stat?) => String from Function 'humanName': static. (0x248ed99cc5c)
    //     0x69c1b8: ldr             x3, [x3, #0xba8]
    // 0x69c1bc: StoreField: r0->field_43 = r3
    //     0x69c1bc: stur            w3, [x0, #0x43]
    // 0x69c1c0: ldur            x2, [fp, #-0x18]
    // 0x69c1c4: r1 = Function '<anonymous closure>':.
    //     0x69c1c4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bb0] AnonymousClosure: (0x69f660), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c1c8: ldr             x1, [x1, #0xbb0]
    // 0x69c1cc: r0 = AllocateClosure()
    //     0x69c1cc: bl              #0x826750  ; AllocateClosureStub
    // 0x69c1d0: mov             x1, x0
    // 0x69c1d4: ldur            x0, [fp, #-0x40]
    // 0x69c1d8: StoreField: r0->field_37 = r1
    //     0x69c1d8: stur            w1, [x0, #0x37]
    // 0x69c1dc: r3 = "everything above"
    //     0x69c1dc: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x69c1e0: ldr             x3, [x3, #0x1b0]
    // 0x69c1e4: StoreField: r0->field_3f = r3
    //     0x69c1e4: stur            w3, [x0, #0x3f]
    // 0x69c1e8: r1 = Function '<anonymous closure>':.
    //     0x69c1e8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bb8] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x69c1ec: ldr             x1, [x1, #0xbb8]
    // 0x69c1f0: r2 = Null
    //     0x69c1f0: mov             x2, NULL
    // 0x69c1f4: r0 = AllocateClosure()
    //     0x69c1f4: bl              #0x826750  ; AllocateClosureStub
    // 0x69c1f8: mov             x1, x0
    // 0x69c1fc: ldur            x0, [fp, #-0x40]
    // 0x69c200: StoreField: r0->field_4b = r1
    //     0x69c200: stur            w1, [x0, #0x4b]
    // 0x69c204: r3 = false
    //     0x69c204: add             x3, NULL, #0x30  ; false
    // 0x69c208: StoreField: r0->field_f = r3
    //     0x69c208: stur            w3, [x0, #0xf]
    // 0x69c20c: StoreField: r0->field_4f = r3
    //     0x69c20c: stur            w3, [x0, #0x4f]
    // 0x69c210: ldur            x2, [fp, #-0x18]
    // 0x69c214: r1 = Function '<anonymous closure>':.
    //     0x69c214: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bc0] AnonymousClosure: (0x69f590), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c218: ldr             x1, [x1, #0xbc0]
    // 0x69c21c: r0 = AllocateClosure()
    //     0x69c21c: bl              #0x826750  ; AllocateClosureStub
    // 0x69c220: mov             x1, x0
    // 0x69c224: ldur            x0, [fp, #-0x40]
    // 0x69c228: StoreField: r0->field_27 = r1
    //     0x69c228: stur            w1, [x0, #0x27]
    // 0x69c22c: r3 = false
    //     0x69c22c: add             x3, NULL, #0x30  ; false
    // 0x69c230: StoreField: r0->field_2b = r3
    //     0x69c230: stur            w3, [x0, #0x2b]
    // 0x69c234: StoreField: r0->field_53 = r3
    //     0x69c234: stur            w3, [x0, #0x53]
    // 0x69c238: ldur            x1, [fp, #-0x10]
    // 0x69c23c: StoreField: r0->field_5b = r1
    //     0x69c23c: stur            w1, [x0, #0x5b]
    // 0x69c240: r4 = "Gain"
    //     0x69c240: add             x4, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x69c244: ldr             x4, [x4, #0x1b8]
    // 0x69c248: StoreField: r0->field_5f = r4
    //     0x69c248: stur            w4, [x0, #0x5f]
    // 0x69c24c: ldur            x2, [fp, #-0x18]
    // 0x69c250: r1 = Function '<anonymous closure>':.
    //     0x69c250: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bc8] AnonymousClosure: (0x69f544), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c254: ldr             x1, [x1, #0xbc8]
    // 0x69c258: r0 = AllocateClosure()
    //     0x69c258: bl              #0x826750  ; AllocateClosureStub
    // 0x69c25c: r16 = false
    //     0x69c25c: add             x16, NULL, #0x30  ; false
    // 0x69c260: str             x16, [SP]
    // 0x69c264: ldur            x2, [fp, #-0x40]
    // 0x69c268: mov             x5, x0
    // 0x69c26c: r1 = Null
    //     0x69c26c: mov             x1, NULL
    // 0x69c270: r3 = "Chapter 13 Prestige 1"
    //     0x69c270: add             x3, PP, #0x28, lsl #12  ; [pp+0x28bd0] "Chapter 13 Prestige 1"
    //     0x69c274: ldr             x3, [x3, #0xbd0]
    // 0x69c278: r4 = const [0, 0x5, 0x1, 0x4, scrollToBottomOnUnlock, 0x4, null]
    //     0x69c278: add             x4, PP, #0x26, lsl #12  ; [pp+0x260f0] List(7) [0, 0x5, 0x1, 0x4, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x69c27c: ldr             x4, [x4, #0xf0]
    // 0x69c280: r0 = IdleFragment()
    //     0x69c280: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69c284: r1 = <Widget>
    //     0x69c284: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69c288: r2 = 30
    //     0x69c288: movz            x2, #0x1e
    // 0x69c28c: stur            x0, [fp, #-0x10]
    // 0x69c290: r0 = AllocateArray()
    //     0x69c290: bl              #0x82746c  ; AllocateArrayStub
    // 0x69c294: mov             x3, x0
    // 0x69c298: ldur            x0, [fp, #-0x10]
    // 0x69c29c: stur            x3, [fp, #-0x30]
    // 0x69c2a0: StoreField: r3->field_f = r0
    //     0x69c2a0: stur            w0, [x3, #0xf]
    // 0x69c2a4: ldur            x0, [fp, #-8]
    // 0x69c2a8: LoadField: r1 = r0->field_43
    //     0x69c2a8: ldur            w1, [x0, #0x43]
    // 0x69c2ac: DecompressPointer r1
    //     0x69c2ac: add             x1, x1, HEAP, lsl #32
    // 0x69c2b0: r2 = 40
    //     0x69c2b0: movz            x2, #0x28
    // 0x69c2b4: r0 = containsKey()
    //     0x69c2b4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69c2b8: tbnz            w0, #4, #0x69c2f0
    // 0x69c2bc: ldur            x2, [fp, #-8]
    // 0x69c2c0: LoadField: r0 = r2->field_9b
    //     0x69c2c0: ldur            w0, [x2, #0x9b]
    // 0x69c2c4: DecompressPointer r0
    //     0x69c2c4: add             x0, x0, HEAP, lsl #32
    // 0x69c2c8: stur            x0, [fp, #-0x10]
    // 0x69c2cc: r0 = AutobuySwitchWrapper()
    //     0x69c2cc: bl              #0x69e39c  ; AllocateAutobuySwitchWrapperStub -> AutobuySwitchWrapper (size=0x14)
    // 0x69c2d0: mov             x1, x0
    // 0x69c2d4: r0 = Instance_Chapter13Stat
    //     0x69c2d4: add             x0, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x69c2d8: ldr             x0, [x0, #0x2e0]
    // 0x69c2dc: StoreField: r1->field_b = r0
    //     0x69c2dc: stur            w0, [x1, #0xb]
    // 0x69c2e0: ldur            x0, [fp, #-0x10]
    // 0x69c2e4: StoreField: r1->field_f = r0
    //     0x69c2e4: stur            w0, [x1, #0xf]
    // 0x69c2e8: mov             x0, x1
    // 0x69c2ec: b               #0x69c2f4
    // 0x69c2f0: r0 = Instance_SizedBox
    //     0x69c2f0: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x69c2f4: ldur            x2, [fp, #-8]
    // 0x69c2f8: stur            x0, [fp, #-0x10]
    // 0x69c2fc: r0 = CurrencyCounter()
    //     0x69c2fc: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69c300: mov             x3, x0
    // 0x69c304: r0 = "Compute"
    //     0x69c304: add             x0, PP, #0x28, lsl #12  ; [pp+0x28bd8] "Compute"
    //     0x69c308: ldr             x0, [x0, #0xbd8]
    // 0x69c30c: stur            x3, [fp, #-0x38]
    // 0x69c310: StoreField: r3->field_b = r0
    //     0x69c310: stur            w0, [x3, #0xb]
    // 0x69c314: ldur            x2, [fp, #-0x18]
    // 0x69c318: r1 = Function '<anonymous closure>':.
    //     0x69c318: add             x1, PP, #0x28, lsl #12  ; [pp+0x28be0] AnonymousClosure: (0x69f49c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c31c: ldr             x1, [x1, #0xbe0]
    // 0x69c320: r0 = AllocateClosure()
    //     0x69c320: bl              #0x826750  ; AllocateClosureStub
    // 0x69c324: mov             x1, x0
    // 0x69c328: ldur            x0, [fp, #-0x38]
    // 0x69c32c: StoreField: r0->field_f = r1
    //     0x69c32c: stur            w1, [x0, #0xf]
    // 0x69c330: ldur            x1, [fp, #-0x10]
    // 0x69c334: StoreField: r0->field_1b = r1
    //     0x69c334: stur            w1, [x0, #0x1b]
    // 0x69c338: r2 = false
    //     0x69c338: add             x2, NULL, #0x30  ; false
    // 0x69c33c: StoreField: r0->field_1f = r2
    //     0x69c33c: stur            w2, [x0, #0x1f]
    // 0x69c340: ldur            x3, [fp, #-8]
    // 0x69c344: LoadField: r4 = r3->field_2b
    //     0x69c344: ldur            w4, [x3, #0x2b]
    // 0x69c348: DecompressPointer r4
    //     0x69c348: add             x4, x4, HEAP, lsl #32
    // 0x69c34c: stur            x4, [fp, #-0x88]
    // 0x69c350: LoadField: r5 = r3->field_37
    //     0x69c350: ldur            w5, [x3, #0x37]
    // 0x69c354: DecompressPointer r5
    //     0x69c354: add             x5, x5, HEAP, lsl #32
    // 0x69c358: stur            x5, [fp, #-0x80]
    // 0x69c35c: LoadField: r6 = r3->field_4b
    //     0x69c35c: ldur            w6, [x3, #0x4b]
    // 0x69c360: DecompressPointer r6
    //     0x69c360: add             x6, x6, HEAP, lsl #32
    // 0x69c364: stur            x6, [fp, #-0x78]
    // 0x69c368: LoadField: r7 = r3->field_47
    //     0x69c368: ldur            w7, [x3, #0x47]
    // 0x69c36c: DecompressPointer r7
    //     0x69c36c: add             x7, x7, HEAP, lsl #32
    // 0x69c370: stur            x7, [fp, #-0x70]
    // 0x69c374: LoadField: r8 = r3->field_53
    //     0x69c374: ldur            w8, [x3, #0x53]
    // 0x69c378: DecompressPointer r8
    //     0x69c378: add             x8, x8, HEAP, lsl #32
    // 0x69c37c: stur            x8, [fp, #-0x68]
    // 0x69c380: LoadField: r9 = r3->field_33
    //     0x69c380: ldur            w9, [x3, #0x33]
    // 0x69c384: DecompressPointer r9
    //     0x69c384: add             x9, x9, HEAP, lsl #32
    // 0x69c388: stur            x9, [fp, #-0x60]
    // 0x69c38c: LoadField: r10 = r3->field_2f
    //     0x69c38c: ldur            w10, [x3, #0x2f]
    // 0x69c390: DecompressPointer r10
    //     0x69c390: add             x10, x10, HEAP, lsl #32
    // 0x69c394: stur            x10, [fp, #-0x58]
    // 0x69c398: LoadField: r1 = r3->field_8b
    //     0x69c398: ldur            x1, [x3, #0x8b]
    // 0x69c39c: cmp             x1, #0
    // 0x69c3a0: b.gt            #0x69c3b0
    // 0x69c3a4: r11 = const [0x1]
    //     0x69c3a4: add             x11, PP, #0x28, lsl #12  ; [pp+0x28be8] List<int>(1)
    //     0x69c3a8: ldr             x11, [x11, #0xbe8]
    // 0x69c3ac: b               #0x69c3d0
    // 0x69c3b0: cmp             x1, #8
    // 0x69c3b4: b.gt            #0x69c3c4
    // 0x69c3b8: r1 = const [0x1, 0x2]
    //     0x69c3b8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] List<int>(2)
    //     0x69c3bc: ldr             x1, [x1, #0x170]
    // 0x69c3c0: b               #0x69c3cc
    // 0x69c3c4: r1 = const [0x1, 0x2, 0x3]
    //     0x69c3c4: add             x1, PP, #0x26, lsl #12  ; [pp+0x268e0] List<int>(3)
    //     0x69c3c8: ldr             x1, [x1, #0x8e0]
    // 0x69c3cc: mov             x11, x1
    // 0x69c3d0: stur            x11, [fp, #-0x40]
    // 0x69c3d4: LoadField: r12 = r3->field_7b
    //     0x69c3d4: ldur            w12, [x3, #0x7b]
    // 0x69c3d8: DecompressPointer r12
    //     0x69c3d8: add             x12, x12, HEAP, lsl #32
    // 0x69c3dc: stur            x12, [fp, #-0x10]
    // 0x69c3e0: r1 = <Chapter13Stat>
    //     0x69c3e0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69c3e4: ldr             x1, [x1, #0xf28]
    // 0x69c3e8: r0 = GeneratorGroup()
    //     0x69c3e8: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69c3ec: mov             x3, x0
    // 0x69c3f0: ldur            x0, [fp, #-0x80]
    // 0x69c3f4: stur            x3, [fp, #-0x90]
    // 0x69c3f8: StoreField: r3->field_1f = r0
    //     0x69c3f8: stur            w0, [x3, #0x1f]
    // 0x69c3fc: ldur            x2, [fp, #-8]
    // 0x69c400: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x69c400: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb00] AnonymousClosure: (0x3daed4), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getCostToBuyOneMoreGenerator (0x3dad94)
    //     0x69c404: ldr             x1, [x1, #0xb00]
    // 0x69c408: r0 = AllocateClosure()
    //     0x69c408: bl              #0x826750  ; AllocateClosureStub
    // 0x69c40c: mov             x3, x0
    // 0x69c410: ldur            x0, [fp, #-0x90]
    // 0x69c414: stur            x3, [fp, #-0x80]
    // 0x69c418: StoreField: r0->field_23 = r3
    //     0x69c418: stur            w3, [x0, #0x23]
    // 0x69c41c: ldur            x2, [fp, #-8]
    // 0x69c420: r1 = Function 'getGeneratorInfo':.
    //     0x69c420: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bf0] AnonymousClosure: (0x69f460), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorInfo (0x80d28c)
    //     0x69c424: ldr             x1, [x1, #0xbf0]
    // 0x69c428: r0 = AllocateClosure()
    //     0x69c428: bl              #0x826750  ; AllocateClosureStub
    // 0x69c42c: mov             x3, x0
    // 0x69c430: ldur            x0, [fp, #-0x90]
    // 0x69c434: stur            x3, [fp, #-0x98]
    // 0x69c438: StoreField: r0->field_27 = r3
    //     0x69c438: stur            w3, [x0, #0x27]
    // 0x69c43c: ldur            x1, [fp, #-0x78]
    // 0x69c440: StoreField: r0->field_2b = r1
    //     0x69c440: stur            w1, [x0, #0x2b]
    // 0x69c444: ldur            x1, [fp, #-0x70]
    // 0x69c448: StoreField: r0->field_2f = r1
    //     0x69c448: stur            w1, [x0, #0x2f]
    // 0x69c44c: ldur            x1, [fp, #-0x68]
    // 0x69c450: StoreField: r0->field_33 = r1
    //     0x69c450: stur            w1, [x0, #0x33]
    // 0x69c454: r1 = Function '<anonymous closure>':.
    //     0x69c454: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bf8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69c458: ldr             x1, [x1, #0xbf8]
    // 0x69c45c: r2 = Null
    //     0x69c45c: mov             x2, NULL
    // 0x69c460: r0 = AllocateClosure()
    //     0x69c460: bl              #0x826750  ; AllocateClosureStub
    // 0x69c464: mov             x1, x0
    // 0x69c468: ldur            x0, [fp, #-0x90]
    // 0x69c46c: StoreField: r0->field_3b = r1
    //     0x69c46c: stur            w1, [x0, #0x3b]
    // 0x69c470: ldur            x3, [fp, #-0x60]
    // 0x69c474: StoreField: r0->field_43 = r3
    //     0x69c474: stur            w3, [x0, #0x43]
    // 0x69c478: ldur            x4, [fp, #-0x58]
    // 0x69c47c: StoreField: r0->field_47 = r4
    //     0x69c47c: stur            w4, [x0, #0x47]
    // 0x69c480: ldur            x2, [fp, #-8]
    // 0x69c484: r1 = Function 'buyGenerator':.
    //     0x69c484: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x69c488: ldr             x1, [x1, #0x108]
    // 0x69c48c: r0 = AllocateClosure()
    //     0x69c48c: bl              #0x826750  ; AllocateClosureStub
    // 0x69c490: mov             x3, x0
    // 0x69c494: ldur            x0, [fp, #-0x90]
    // 0x69c498: stur            x3, [fp, #-0x68]
    // 0x69c49c: StoreField: r0->field_5b = r3
    //     0x69c49c: stur            w3, [x0, #0x5b]
    // 0x69c4a0: r1 = Function '<anonymous closure>':.
    //     0x69c4a0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c00] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69c4a4: ldr             x1, [x1, #0xc00]
    // 0x69c4a8: r2 = Null
    //     0x69c4a8: mov             x2, NULL
    // 0x69c4ac: r0 = AllocateClosure()
    //     0x69c4ac: bl              #0x826750  ; AllocateClosureStub
    // 0x69c4b0: mov             x1, x0
    // 0x69c4b4: ldur            x0, [fp, #-0x90]
    // 0x69c4b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x69c4b8: stur            w1, [x0, #0x17]
    // 0x69c4bc: r1 = Function '<anonymous closure>':.
    //     0x69c4bc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c08] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69c4c0: ldr             x1, [x1, #0xc08]
    // 0x69c4c4: r2 = Null
    //     0x69c4c4: mov             x2, NULL
    // 0x69c4c8: r0 = AllocateClosure()
    //     0x69c4c8: bl              #0x826750  ; AllocateClosureStub
    // 0x69c4cc: mov             x1, x0
    // 0x69c4d0: ldur            x0, [fp, #-0x90]
    // 0x69c4d4: StoreField: r0->field_1b = r1
    //     0x69c4d4: stur            w1, [x0, #0x1b]
    // 0x69c4d8: ldur            x2, [fp, #-8]
    // 0x69c4dc: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x69c4dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x69c4e0: ldr             x1, [x1, #0x120]
    // 0x69c4e4: r0 = AllocateClosure()
    //     0x69c4e4: bl              #0x826750  ; AllocateClosureStub
    // 0x69c4e8: mov             x3, x0
    // 0x69c4ec: ldur            x0, [fp, #-0x90]
    // 0x69c4f0: stur            x3, [fp, #-0x70]
    // 0x69c4f4: StoreField: r0->field_57 = r3
    //     0x69c4f4: stur            w3, [x0, #0x57]
    // 0x69c4f8: ldur            x1, [fp, #-0x40]
    // 0x69c4fc: StoreField: r0->field_53 = r1
    //     0x69c4fc: stur            w1, [x0, #0x53]
    // 0x69c500: ldur            x2, [fp, #-0x18]
    // 0x69c504: r1 = Function '<anonymous closure>':.
    //     0x69c504: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c10] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c508: ldr             x1, [x1, #0xc10]
    // 0x69c50c: r0 = AllocateClosure()
    //     0x69c50c: bl              #0x826750  ; AllocateClosureStub
    // 0x69c510: mov             x1, x0
    // 0x69c514: ldur            x0, [fp, #-0x90]
    // 0x69c518: StoreField: r0->field_6b = r1
    //     0x69c518: stur            w1, [x0, #0x6b]
    // 0x69c51c: ldur            x1, [fp, #-0x88]
    // 0x69c520: StoreField: r0->field_4b = r1
    //     0x69c520: stur            w1, [x0, #0x4b]
    // 0x69c524: ldur            x1, [fp, #-0x38]
    // 0x69c528: StoreField: r0->field_f = r1
    //     0x69c528: stur            w1, [x0, #0xf]
    // 0x69c52c: ldur            x1, [fp, #-0x10]
    // 0x69c530: StoreField: r0->field_67 = r1
    //     0x69c530: stur            w1, [x0, #0x67]
    // 0x69c534: ldur            x2, [fp, #-8]
    // 0x69c538: r1 = Function 'getGeneratorBaseCost':.
    //     0x69c538: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c18] AnonymousClosure: (0x54519c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorBaseCost (0x5560d0)
    //     0x69c53c: ldr             x1, [x1, #0xc18]
    // 0x69c540: r0 = AllocateClosure()
    //     0x69c540: bl              #0x826750  ; AllocateClosureStub
    // 0x69c544: mov             x3, x0
    // 0x69c548: ldur            x0, [fp, #-0x90]
    // 0x69c54c: stur            x3, [fp, #-0x10]
    // 0x69c550: StoreField: r0->field_77 = r3
    //     0x69c550: stur            w3, [x0, #0x77]
    // 0x69c554: ldur            x2, [fp, #-8]
    // 0x69c558: r1 = Function 'getGeneratorMultiplier':.
    //     0x69c558: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c20] AnonymousClosure: (0x6905f8), of [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState
    //     0x69c55c: ldr             x1, [x1, #0xc20]
    // 0x69c560: r0 = AllocateClosure()
    //     0x69c560: bl              #0x826750  ; AllocateClosureStub
    // 0x69c564: mov             x3, x0
    // 0x69c568: ldur            x0, [fp, #-0x90]
    // 0x69c56c: stur            x3, [fp, #-0x38]
    // 0x69c570: StoreField: r0->field_7b = r3
    //     0x69c570: stur            w3, [x0, #0x7b]
    // 0x69c574: r4 = "Chapter 13 Compute Generators"
    //     0x69c574: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c28] "Chapter 13 Compute Generators"
    //     0x69c578: ldr             x4, [x4, #0xc28]
    // 0x69c57c: StoreField: r0->field_73 = r4
    //     0x69c57c: stur            w4, [x0, #0x73]
    // 0x69c580: r1 = Function '<anonymous closure>':.
    //     0x69c580: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c30] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x69c584: ldr             x1, [x1, #0xc30]
    // 0x69c588: r2 = Null
    //     0x69c588: mov             x2, NULL
    // 0x69c58c: r0 = AllocateClosure()
    //     0x69c58c: bl              #0x826750  ; AllocateClosureStub
    // 0x69c590: ldur            x2, [fp, #-0x90]
    // 0x69c594: mov             x5, x0
    // 0x69c598: r1 = Null
    //     0x69c598: mov             x1, NULL
    // 0x69c59c: r3 = "Chapter 13 Compute Generators"
    //     0x69c59c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28c28] "Chapter 13 Compute Generators"
    //     0x69c5a0: ldr             x3, [x3, #0xc28]
    // 0x69c5a4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69c5a4: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69c5a8: r0 = IdleFragment()
    //     0x69c5a8: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69c5ac: ldur            x1, [fp, #-0x30]
    // 0x69c5b0: ArrayStore: r1[1] = r0  ; List_4
    //     0x69c5b0: add             x25, x1, #0x13
    //     0x69c5b4: str             w0, [x25]
    //     0x69c5b8: tbz             w0, #0, #0x69c5d4
    //     0x69c5bc: ldurb           w16, [x1, #-1]
    //     0x69c5c0: ldurb           w17, [x0, #-1]
    //     0x69c5c4: and             x16, x17, x16, lsr #2
    //     0x69c5c8: tst             x16, HEAP, lsr #32
    //     0x69c5cc: b.eq            #0x69c5d4
    //     0x69c5d0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69c5d4: ldur            x0, [fp, #-8]
    // 0x69c5d8: LoadField: r1 = r0->field_43
    //     0x69c5d8: ldur            w1, [x0, #0x43]
    // 0x69c5dc: DecompressPointer r1
    //     0x69c5dc: add             x1, x1, HEAP, lsl #32
    // 0x69c5e0: r2 = 40
    //     0x69c5e0: movz            x2, #0x28
    // 0x69c5e4: r0 = containsKey()
    //     0x69c5e4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69c5e8: tbnz            w0, #4, #0x69c620
    // 0x69c5ec: ldur            x2, [fp, #-8]
    // 0x69c5f0: LoadField: r0 = r2->field_9b
    //     0x69c5f0: ldur            w0, [x2, #0x9b]
    // 0x69c5f4: DecompressPointer r0
    //     0x69c5f4: add             x0, x0, HEAP, lsl #32
    // 0x69c5f8: stur            x0, [fp, #-0x40]
    // 0x69c5fc: r0 = AutobuySwitchWrapper()
    //     0x69c5fc: bl              #0x69e39c  ; AllocateAutobuySwitchWrapperStub -> AutobuySwitchWrapper (size=0x14)
    // 0x69c600: mov             x1, x0
    // 0x69c604: r0 = Instance_Chapter13Stat
    //     0x69c604: add             x0, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x69c608: ldr             x0, [x0, #0x300]
    // 0x69c60c: StoreField: r1->field_b = r0
    //     0x69c60c: stur            w0, [x1, #0xb]
    // 0x69c610: ldur            x0, [fp, #-0x40]
    // 0x69c614: StoreField: r1->field_f = r0
    //     0x69c614: stur            w0, [x1, #0xf]
    // 0x69c618: mov             x0, x1
    // 0x69c61c: b               #0x69c624
    // 0x69c620: r0 = Instance_SizedBox
    //     0x69c620: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x69c624: ldur            x2, [fp, #-8]
    // 0x69c628: stur            x0, [fp, #-0x40]
    // 0x69c62c: r0 = CurrencyCounter()
    //     0x69c62c: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69c630: mov             x3, x0
    // 0x69c634: r0 = "Networking"
    //     0x69c634: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c38] "Networking"
    //     0x69c638: ldr             x0, [x0, #0xc38]
    // 0x69c63c: stur            x3, [fp, #-0x78]
    // 0x69c640: StoreField: r3->field_b = r0
    //     0x69c640: stur            w0, [x3, #0xb]
    // 0x69c644: ldur            x2, [fp, #-0x18]
    // 0x69c648: r1 = Function '<anonymous closure>':.
    //     0x69c648: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c40] AnonymousClosure: (0x69f3b8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c64c: ldr             x1, [x1, #0xc40]
    // 0x69c650: r0 = AllocateClosure()
    //     0x69c650: bl              #0x826750  ; AllocateClosureStub
    // 0x69c654: mov             x1, x0
    // 0x69c658: ldur            x0, [fp, #-0x78]
    // 0x69c65c: StoreField: r0->field_f = r1
    //     0x69c65c: stur            w1, [x0, #0xf]
    // 0x69c660: ldur            x1, [fp, #-0x40]
    // 0x69c664: StoreField: r0->field_1b = r1
    //     0x69c664: stur            w1, [x0, #0x1b]
    // 0x69c668: r3 = false
    //     0x69c668: add             x3, NULL, #0x30  ; false
    // 0x69c66c: StoreField: r0->field_1f = r3
    //     0x69c66c: stur            w3, [x0, #0x1f]
    // 0x69c670: ldur            x4, [fp, #-8]
    // 0x69c674: LoadField: r5 = r4->field_2b
    //     0x69c674: ldur            w5, [x4, #0x2b]
    // 0x69c678: DecompressPointer r5
    //     0x69c678: add             x5, x5, HEAP, lsl #32
    // 0x69c67c: stur            x5, [fp, #-0xa8]
    // 0x69c680: LoadField: r6 = r4->field_37
    //     0x69c680: ldur            w6, [x4, #0x37]
    // 0x69c684: DecompressPointer r6
    //     0x69c684: add             x6, x6, HEAP, lsl #32
    // 0x69c688: stur            x6, [fp, #-0xa0]
    // 0x69c68c: LoadField: r7 = r4->field_4b
    //     0x69c68c: ldur            w7, [x4, #0x4b]
    // 0x69c690: DecompressPointer r7
    //     0x69c690: add             x7, x7, HEAP, lsl #32
    // 0x69c694: stur            x7, [fp, #-0x90]
    // 0x69c698: LoadField: r8 = r4->field_47
    //     0x69c698: ldur            w8, [x4, #0x47]
    // 0x69c69c: DecompressPointer r8
    //     0x69c69c: add             x8, x8, HEAP, lsl #32
    // 0x69c6a0: stur            x8, [fp, #-0x88]
    // 0x69c6a4: LoadField: r9 = r4->field_53
    //     0x69c6a4: ldur            w9, [x4, #0x53]
    // 0x69c6a8: DecompressPointer r9
    //     0x69c6a8: add             x9, x9, HEAP, lsl #32
    // 0x69c6ac: stur            x9, [fp, #-0x40]
    // 0x69c6b0: LoadField: r1 = r4->field_8b
    //     0x69c6b0: ldur            x1, [x4, #0x8b]
    // 0x69c6b4: cmp             x1, #6
    // 0x69c6b8: b.gt            #0x69c6e0
    // 0x69c6bc: mov             x2, x4
    // 0x69c6c0: mov             x3, x5
    // 0x69c6c4: mov             x4, x6
    // 0x69c6c8: mov             x5, x7
    // 0x69c6cc: mov             x6, x8
    // 0x69c6d0: mov             x7, x9
    // 0x69c6d4: r20 = const [0x15]
    //     0x69c6d4: add             x20, PP, #0x28, lsl #12  ; [pp+0x28c48] List<int>(1)
    //     0x69c6d8: ldr             x20, [x20, #0xc48]
    // 0x69c6dc: b               #0x69c728
    // 0x69c6e0: LoadField: r1 = r4->field_43
    //     0x69c6e0: ldur            w1, [x4, #0x43]
    // 0x69c6e4: DecompressPointer r1
    //     0x69c6e4: add             x1, x1, HEAP, lsl #32
    // 0x69c6e8: r2 = 140
    //     0x69c6e8: movz            x2, #0x8c
    // 0x69c6ec: r0 = containsKey()
    //     0x69c6ec: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69c6f0: tbnz            w0, #4, #0x69c700
    // 0x69c6f4: r0 = const [0x15, 0x16, 0x17]
    //     0x69c6f4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c50] List<int>(3)
    //     0x69c6f8: ldr             x0, [x0, #0xc50]
    // 0x69c6fc: b               #0x69c708
    // 0x69c700: r0 = const [0x15, 0x16]
    //     0x69c700: add             x0, PP, #0x26, lsl #12  ; [pp+0x262a0] List<int>(2)
    //     0x69c704: ldr             x0, [x0, #0x2a0]
    // 0x69c708: mov             x20, x0
    // 0x69c70c: ldur            x2, [fp, #-8]
    // 0x69c710: ldur            x0, [fp, #-0x78]
    // 0x69c714: ldur            x3, [fp, #-0xa8]
    // 0x69c718: ldur            x4, [fp, #-0xa0]
    // 0x69c71c: ldur            x5, [fp, #-0x90]
    // 0x69c720: ldur            x6, [fp, #-0x88]
    // 0x69c724: ldur            x7, [fp, #-0x40]
    // 0x69c728: ldur            x12, [fp, #-0x60]
    // 0x69c72c: ldur            x13, [fp, #-0x58]
    // 0x69c730: ldur            x10, [fp, #-0x70]
    // 0x69c734: ldur            x9, [fp, #-0x10]
    // 0x69c738: ldur            x8, [fp, #-0x38]
    // 0x69c73c: ldur            x19, [fp, #-0x80]
    // 0x69c740: ldur            x14, [fp, #-0x98]
    // 0x69c744: ldur            x11, [fp, #-0x68]
    // 0x69c748: stur            x20, [fp, #-0xb8]
    // 0x69c74c: LoadField: r23 = r2->field_7b
    //     0x69c74c: ldur            w23, [x2, #0x7b]
    // 0x69c750: DecompressPointer r23
    //     0x69c750: add             x23, x23, HEAP, lsl #32
    // 0x69c754: stur            x23, [fp, #-0xb0]
    // 0x69c758: r1 = <Chapter13Stat>
    //     0x69c758: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69c75c: ldr             x1, [x1, #0xf28]
    // 0x69c760: r0 = GeneratorGroup()
    //     0x69c760: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69c764: mov             x3, x0
    // 0x69c768: ldur            x0, [fp, #-0xa0]
    // 0x69c76c: stur            x3, [fp, #-0xc0]
    // 0x69c770: StoreField: r3->field_1f = r0
    //     0x69c770: stur            w0, [x3, #0x1f]
    // 0x69c774: ldur            x0, [fp, #-0x80]
    // 0x69c778: StoreField: r3->field_23 = r0
    //     0x69c778: stur            w0, [x3, #0x23]
    // 0x69c77c: ldur            x4, [fp, #-0x98]
    // 0x69c780: StoreField: r3->field_27 = r4
    //     0x69c780: stur            w4, [x3, #0x27]
    // 0x69c784: ldur            x1, [fp, #-0x90]
    // 0x69c788: StoreField: r3->field_2b = r1
    //     0x69c788: stur            w1, [x3, #0x2b]
    // 0x69c78c: ldur            x1, [fp, #-0x88]
    // 0x69c790: StoreField: r3->field_2f = r1
    //     0x69c790: stur            w1, [x3, #0x2f]
    // 0x69c794: ldur            x1, [fp, #-0x40]
    // 0x69c798: StoreField: r3->field_33 = r1
    //     0x69c798: stur            w1, [x3, #0x33]
    // 0x69c79c: r1 = Function '<anonymous closure>':.
    //     0x69c79c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c58] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69c7a0: ldr             x1, [x1, #0xc58]
    // 0x69c7a4: r2 = Null
    //     0x69c7a4: mov             x2, NULL
    // 0x69c7a8: r0 = AllocateClosure()
    //     0x69c7a8: bl              #0x826750  ; AllocateClosureStub
    // 0x69c7ac: mov             x1, x0
    // 0x69c7b0: ldur            x0, [fp, #-0xc0]
    // 0x69c7b4: StoreField: r0->field_3b = r1
    //     0x69c7b4: stur            w1, [x0, #0x3b]
    // 0x69c7b8: ldur            x3, [fp, #-0x60]
    // 0x69c7bc: StoreField: r0->field_43 = r3
    //     0x69c7bc: stur            w3, [x0, #0x43]
    // 0x69c7c0: ldur            x4, [fp, #-0x58]
    // 0x69c7c4: StoreField: r0->field_47 = r4
    //     0x69c7c4: stur            w4, [x0, #0x47]
    // 0x69c7c8: ldur            x5, [fp, #-0x68]
    // 0x69c7cc: StoreField: r0->field_5b = r5
    //     0x69c7cc: stur            w5, [x0, #0x5b]
    // 0x69c7d0: r1 = Function '<anonymous closure>':.
    //     0x69c7d0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c60] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69c7d4: ldr             x1, [x1, #0xc60]
    // 0x69c7d8: r2 = Null
    //     0x69c7d8: mov             x2, NULL
    // 0x69c7dc: r0 = AllocateClosure()
    //     0x69c7dc: bl              #0x826750  ; AllocateClosureStub
    // 0x69c7e0: mov             x1, x0
    // 0x69c7e4: ldur            x0, [fp, #-0xc0]
    // 0x69c7e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x69c7e8: stur            w1, [x0, #0x17]
    // 0x69c7ec: r1 = Function '<anonymous closure>':.
    //     0x69c7ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c68] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69c7f0: ldr             x1, [x1, #0xc68]
    // 0x69c7f4: r2 = Null
    //     0x69c7f4: mov             x2, NULL
    // 0x69c7f8: r0 = AllocateClosure()
    //     0x69c7f8: bl              #0x826750  ; AllocateClosureStub
    // 0x69c7fc: mov             x1, x0
    // 0x69c800: ldur            x0, [fp, #-0xc0]
    // 0x69c804: StoreField: r0->field_1b = r1
    //     0x69c804: stur            w1, [x0, #0x1b]
    // 0x69c808: ldur            x3, [fp, #-0x70]
    // 0x69c80c: StoreField: r0->field_57 = r3
    //     0x69c80c: stur            w3, [x0, #0x57]
    // 0x69c810: ldur            x1, [fp, #-0xb8]
    // 0x69c814: StoreField: r0->field_53 = r1
    //     0x69c814: stur            w1, [x0, #0x53]
    // 0x69c818: ldur            x2, [fp, #-0x18]
    // 0x69c81c: r1 = Function '<anonymous closure>':.
    //     0x69c81c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c70] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c820: ldr             x1, [x1, #0xc70]
    // 0x69c824: r0 = AllocateClosure()
    //     0x69c824: bl              #0x826750  ; AllocateClosureStub
    // 0x69c828: mov             x1, x0
    // 0x69c82c: ldur            x0, [fp, #-0xc0]
    // 0x69c830: StoreField: r0->field_6b = r1
    //     0x69c830: stur            w1, [x0, #0x6b]
    // 0x69c834: ldur            x1, [fp, #-0xa8]
    // 0x69c838: StoreField: r0->field_4b = r1
    //     0x69c838: stur            w1, [x0, #0x4b]
    // 0x69c83c: ldur            x1, [fp, #-0x78]
    // 0x69c840: StoreField: r0->field_f = r1
    //     0x69c840: stur            w1, [x0, #0xf]
    // 0x69c844: ldur            x1, [fp, #-0xb0]
    // 0x69c848: StoreField: r0->field_67 = r1
    //     0x69c848: stur            w1, [x0, #0x67]
    // 0x69c84c: ldur            x3, [fp, #-0x10]
    // 0x69c850: StoreField: r0->field_77 = r3
    //     0x69c850: stur            w3, [x0, #0x77]
    // 0x69c854: ldur            x4, [fp, #-0x38]
    // 0x69c858: StoreField: r0->field_7b = r4
    //     0x69c858: stur            w4, [x0, #0x7b]
    // 0x69c85c: r5 = "Chapter 13 Networking Generators"
    //     0x69c85c: add             x5, PP, #0x28, lsl #12  ; [pp+0x28c78] "Chapter 13 Networking Generators"
    //     0x69c860: ldr             x5, [x5, #0xc78]
    // 0x69c864: StoreField: r0->field_73 = r5
    //     0x69c864: stur            w5, [x0, #0x73]
    // 0x69c868: r1 = Function '<anonymous closure>':.
    //     0x69c868: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c80] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x69c86c: ldr             x1, [x1, #0xc80]
    // 0x69c870: r2 = Null
    //     0x69c870: mov             x2, NULL
    // 0x69c874: r0 = AllocateClosure()
    //     0x69c874: bl              #0x826750  ; AllocateClosureStub
    // 0x69c878: ldur            x2, [fp, #-0xc0]
    // 0x69c87c: mov             x5, x0
    // 0x69c880: r1 = Null
    //     0x69c880: mov             x1, NULL
    // 0x69c884: r3 = "Chapter 13 Networking Generators"
    //     0x69c884: add             x3, PP, #0x28, lsl #12  ; [pp+0x28c78] "Chapter 13 Networking Generators"
    //     0x69c888: ldr             x3, [x3, #0xc78]
    // 0x69c88c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69c88c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69c890: r0 = IdleFragment()
    //     0x69c890: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69c894: ldur            x1, [fp, #-0x30]
    // 0x69c898: ArrayStore: r1[2] = r0  ; List_4
    //     0x69c898: add             x25, x1, #0x17
    //     0x69c89c: str             w0, [x25]
    //     0x69c8a0: tbz             w0, #0, #0x69c8bc
    //     0x69c8a4: ldurb           w16, [x1, #-1]
    //     0x69c8a8: ldurb           w17, [x0, #-1]
    //     0x69c8ac: and             x16, x17, x16, lsr #2
    //     0x69c8b0: tst             x16, HEAP, lsr #32
    //     0x69c8b4: b.eq            #0x69c8bc
    //     0x69c8b8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69c8bc: ldur            x0, [fp, #-8]
    // 0x69c8c0: LoadField: r1 = r0->field_43
    //     0x69c8c0: ldur            w1, [x0, #0x43]
    // 0x69c8c4: DecompressPointer r1
    //     0x69c8c4: add             x1, x1, HEAP, lsl #32
    // 0x69c8c8: r2 = 40
    //     0x69c8c8: movz            x2, #0x28
    // 0x69c8cc: r0 = containsKey()
    //     0x69c8cc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69c8d0: tbnz            w0, #4, #0x69c908
    // 0x69c8d4: ldur            x2, [fp, #-8]
    // 0x69c8d8: LoadField: r0 = r2->field_9b
    //     0x69c8d8: ldur            w0, [x2, #0x9b]
    // 0x69c8dc: DecompressPointer r0
    //     0x69c8dc: add             x0, x0, HEAP, lsl #32
    // 0x69c8e0: stur            x0, [fp, #-0x40]
    // 0x69c8e4: r0 = AutobuySwitchWrapper()
    //     0x69c8e4: bl              #0x69e39c  ; AllocateAutobuySwitchWrapperStub -> AutobuySwitchWrapper (size=0x14)
    // 0x69c8e8: mov             x1, x0
    // 0x69c8ec: r0 = Instance_Chapter13Stat
    //     0x69c8ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x69c8f0: ldr             x0, [x0, #0x320]
    // 0x69c8f4: StoreField: r1->field_b = r0
    //     0x69c8f4: stur            w0, [x1, #0xb]
    // 0x69c8f8: ldur            x0, [fp, #-0x40]
    // 0x69c8fc: StoreField: r1->field_f = r0
    //     0x69c8fc: stur            w0, [x1, #0xf]
    // 0x69c900: mov             x0, x1
    // 0x69c904: b               #0x69c90c
    // 0x69c908: r0 = Instance_SizedBox
    //     0x69c908: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x69c90c: ldur            x2, [fp, #-8]
    // 0x69c910: stur            x0, [fp, #-0x40]
    // 0x69c914: r0 = CurrencyCounter()
    //     0x69c914: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69c918: mov             x3, x0
    // 0x69c91c: r0 = "Security"
    //     0x69c91c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c88] "Security"
    //     0x69c920: ldr             x0, [x0, #0xc88]
    // 0x69c924: stur            x3, [fp, #-0x78]
    // 0x69c928: StoreField: r3->field_b = r0
    //     0x69c928: stur            w0, [x3, #0xb]
    // 0x69c92c: ldur            x2, [fp, #-0x18]
    // 0x69c930: r1 = Function '<anonymous closure>':.
    //     0x69c930: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c90] AnonymousClosure: (0x69f310), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69c934: ldr             x1, [x1, #0xc90]
    // 0x69c938: r0 = AllocateClosure()
    //     0x69c938: bl              #0x826750  ; AllocateClosureStub
    // 0x69c93c: mov             x1, x0
    // 0x69c940: ldur            x0, [fp, #-0x78]
    // 0x69c944: StoreField: r0->field_f = r1
    //     0x69c944: stur            w1, [x0, #0xf]
    // 0x69c948: ldur            x1, [fp, #-0x40]
    // 0x69c94c: StoreField: r0->field_1b = r1
    //     0x69c94c: stur            w1, [x0, #0x1b]
    // 0x69c950: r2 = false
    //     0x69c950: add             x2, NULL, #0x30  ; false
    // 0x69c954: StoreField: r0->field_1f = r2
    //     0x69c954: stur            w2, [x0, #0x1f]
    // 0x69c958: ldur            x3, [fp, #-8]
    // 0x69c95c: LoadField: r4 = r3->field_2b
    //     0x69c95c: ldur            w4, [x3, #0x2b]
    // 0x69c960: DecompressPointer r4
    //     0x69c960: add             x4, x4, HEAP, lsl #32
    // 0x69c964: stur            x4, [fp, #-0xb8]
    // 0x69c968: LoadField: r5 = r3->field_37
    //     0x69c968: ldur            w5, [x3, #0x37]
    // 0x69c96c: DecompressPointer r5
    //     0x69c96c: add             x5, x5, HEAP, lsl #32
    // 0x69c970: stur            x5, [fp, #-0xb0]
    // 0x69c974: LoadField: r6 = r3->field_4b
    //     0x69c974: ldur            w6, [x3, #0x4b]
    // 0x69c978: DecompressPointer r6
    //     0x69c978: add             x6, x6, HEAP, lsl #32
    // 0x69c97c: stur            x6, [fp, #-0xa8]
    // 0x69c980: LoadField: r7 = r3->field_47
    //     0x69c980: ldur            w7, [x3, #0x47]
    // 0x69c984: DecompressPointer r7
    //     0x69c984: add             x7, x7, HEAP, lsl #32
    // 0x69c988: stur            x7, [fp, #-0xa0]
    // 0x69c98c: LoadField: r8 = r3->field_53
    //     0x69c98c: ldur            w8, [x3, #0x53]
    // 0x69c990: DecompressPointer r8
    //     0x69c990: add             x8, x8, HEAP, lsl #32
    // 0x69c994: stur            x8, [fp, #-0x90]
    // 0x69c998: LoadField: r1 = r3->field_8b
    //     0x69c998: ldur            x1, [x3, #0x8b]
    // 0x69c99c: cmp             x1, #3
    // 0x69c9a0: b.gt            #0x69c9b0
    // 0x69c9a4: r25 = const [0x29]
    //     0x69c9a4: add             x25, PP, #0x28, lsl #12  ; [pp+0x28c98] List<int>(1)
    //     0x69c9a8: ldr             x25, [x25, #0xc98]
    // 0x69c9ac: b               #0x69c9d0
    // 0x69c9b0: cmp             x1, #8
    // 0x69c9b4: b.gt            #0x69c9c4
    // 0x69c9b8: r1 = const [0x29, 0x2a]
    //     0x69c9b8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ca0] List<int>(2)
    //     0x69c9bc: ldr             x1, [x1, #0xca0]
    // 0x69c9c0: b               #0x69c9cc
    // 0x69c9c4: r1 = const [0x29, 0x2a, 0x2b]
    //     0x69c9c4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ca8] List<int>(3)
    //     0x69c9c8: ldr             x1, [x1, #0xca8]
    // 0x69c9cc: mov             x25, x1
    // 0x69c9d0: ldur            x12, [fp, #-0x60]
    // 0x69c9d4: ldur            x13, [fp, #-0x58]
    // 0x69c9d8: ldur            x11, [fp, #-0x70]
    // 0x69c9dc: ldur            x9, [fp, #-0x10]
    // 0x69c9e0: ldur            x10, [fp, #-0x38]
    // 0x69c9e4: ldur            x19, [fp, #-0x80]
    // 0x69c9e8: ldur            x20, [fp, #-0x98]
    // 0x69c9ec: ldur            x14, [fp, #-0x68]
    // 0x69c9f0: ldur            x24, [fp, #-0x20]
    // 0x69c9f4: ldur            x23, [fp, #-0x28]
    // 0x69c9f8: stur            x25, [fp, #-0x88]
    // 0x69c9fc: LoadField: r1 = r3->field_7b
    //     0x69c9fc: ldur            w1, [x3, #0x7b]
    // 0x69ca00: DecompressPointer r1
    //     0x69ca00: add             x1, x1, HEAP, lsl #32
    // 0x69ca04: stur            x1, [fp, #-0x40]
    // 0x69ca08: r1 = <Chapter13Stat>
    //     0x69ca08: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69ca0c: ldr             x1, [x1, #0xf28]
    // 0x69ca10: r0 = GeneratorGroup()
    //     0x69ca10: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69ca14: mov             x3, x0
    // 0x69ca18: ldur            x0, [fp, #-0xb0]
    // 0x69ca1c: stur            x3, [fp, #-0xc0]
    // 0x69ca20: StoreField: r3->field_1f = r0
    //     0x69ca20: stur            w0, [x3, #0x1f]
    // 0x69ca24: ldur            x0, [fp, #-0x80]
    // 0x69ca28: StoreField: r3->field_23 = r0
    //     0x69ca28: stur            w0, [x3, #0x23]
    // 0x69ca2c: ldur            x4, [fp, #-0x98]
    // 0x69ca30: StoreField: r3->field_27 = r4
    //     0x69ca30: stur            w4, [x3, #0x27]
    // 0x69ca34: ldur            x1, [fp, #-0xa8]
    // 0x69ca38: StoreField: r3->field_2b = r1
    //     0x69ca38: stur            w1, [x3, #0x2b]
    // 0x69ca3c: ldur            x1, [fp, #-0xa0]
    // 0x69ca40: StoreField: r3->field_2f = r1
    //     0x69ca40: stur            w1, [x3, #0x2f]
    // 0x69ca44: ldur            x1, [fp, #-0x90]
    // 0x69ca48: StoreField: r3->field_33 = r1
    //     0x69ca48: stur            w1, [x3, #0x33]
    // 0x69ca4c: r1 = Function '<anonymous closure>':.
    //     0x69ca4c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cb0] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69ca50: ldr             x1, [x1, #0xcb0]
    // 0x69ca54: r2 = Null
    //     0x69ca54: mov             x2, NULL
    // 0x69ca58: r0 = AllocateClosure()
    //     0x69ca58: bl              #0x826750  ; AllocateClosureStub
    // 0x69ca5c: mov             x1, x0
    // 0x69ca60: ldur            x0, [fp, #-0xc0]
    // 0x69ca64: StoreField: r0->field_3b = r1
    //     0x69ca64: stur            w1, [x0, #0x3b]
    // 0x69ca68: ldur            x3, [fp, #-0x60]
    // 0x69ca6c: StoreField: r0->field_43 = r3
    //     0x69ca6c: stur            w3, [x0, #0x43]
    // 0x69ca70: ldur            x4, [fp, #-0x58]
    // 0x69ca74: StoreField: r0->field_47 = r4
    //     0x69ca74: stur            w4, [x0, #0x47]
    // 0x69ca78: ldur            x5, [fp, #-0x68]
    // 0x69ca7c: StoreField: r0->field_5b = r5
    //     0x69ca7c: stur            w5, [x0, #0x5b]
    // 0x69ca80: r1 = Function '<anonymous closure>':.
    //     0x69ca80: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cb8] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69ca84: ldr             x1, [x1, #0xcb8]
    // 0x69ca88: r2 = Null
    //     0x69ca88: mov             x2, NULL
    // 0x69ca8c: r0 = AllocateClosure()
    //     0x69ca8c: bl              #0x826750  ; AllocateClosureStub
    // 0x69ca90: mov             x1, x0
    // 0x69ca94: ldur            x0, [fp, #-0xc0]
    // 0x69ca98: ArrayStore: r0[0] = r1  ; List_4
    //     0x69ca98: stur            w1, [x0, #0x17]
    // 0x69ca9c: r1 = Function '<anonymous closure>':.
    //     0x69ca9c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cc0] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69caa0: ldr             x1, [x1, #0xcc0]
    // 0x69caa4: r2 = Null
    //     0x69caa4: mov             x2, NULL
    // 0x69caa8: r0 = AllocateClosure()
    //     0x69caa8: bl              #0x826750  ; AllocateClosureStub
    // 0x69caac: mov             x1, x0
    // 0x69cab0: ldur            x0, [fp, #-0xc0]
    // 0x69cab4: StoreField: r0->field_1b = r1
    //     0x69cab4: stur            w1, [x0, #0x1b]
    // 0x69cab8: ldur            x3, [fp, #-0x70]
    // 0x69cabc: StoreField: r0->field_57 = r3
    //     0x69cabc: stur            w3, [x0, #0x57]
    // 0x69cac0: ldur            x1, [fp, #-0x88]
    // 0x69cac4: StoreField: r0->field_53 = r1
    //     0x69cac4: stur            w1, [x0, #0x53]
    // 0x69cac8: ldur            x2, [fp, #-0x18]
    // 0x69cacc: r1 = Function '<anonymous closure>':.
    //     0x69cacc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cc8] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69cad0: ldr             x1, [x1, #0xcc8]
    // 0x69cad4: r0 = AllocateClosure()
    //     0x69cad4: bl              #0x826750  ; AllocateClosureStub
    // 0x69cad8: mov             x1, x0
    // 0x69cadc: ldur            x0, [fp, #-0xc0]
    // 0x69cae0: StoreField: r0->field_6b = r1
    //     0x69cae0: stur            w1, [x0, #0x6b]
    // 0x69cae4: ldur            x1, [fp, #-0xb8]
    // 0x69cae8: StoreField: r0->field_4b = r1
    //     0x69cae8: stur            w1, [x0, #0x4b]
    // 0x69caec: ldur            x1, [fp, #-0x78]
    // 0x69caf0: StoreField: r0->field_f = r1
    //     0x69caf0: stur            w1, [x0, #0xf]
    // 0x69caf4: ldur            x1, [fp, #-0x40]
    // 0x69caf8: StoreField: r0->field_67 = r1
    //     0x69caf8: stur            w1, [x0, #0x67]
    // 0x69cafc: ldur            x3, [fp, #-0x10]
    // 0x69cb00: StoreField: r0->field_77 = r3
    //     0x69cb00: stur            w3, [x0, #0x77]
    // 0x69cb04: ldur            x4, [fp, #-0x38]
    // 0x69cb08: StoreField: r0->field_7b = r4
    //     0x69cb08: stur            w4, [x0, #0x7b]
    // 0x69cb0c: r1 = "Chapter 13 Security Generators 1"
    //     0x69cb0c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cd0] "Chapter 13 Security Generators 1"
    //     0x69cb10: ldr             x1, [x1, #0xcd0]
    // 0x69cb14: StoreField: r0->field_73 = r1
    //     0x69cb14: stur            w1, [x0, #0x73]
    // 0x69cb18: r1 = Function '<anonymous closure>':.
    //     0x69cb18: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cd8] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x69cb1c: ldr             x1, [x1, #0xcd8]
    // 0x69cb20: r2 = Null
    //     0x69cb20: mov             x2, NULL
    // 0x69cb24: r0 = AllocateClosure()
    //     0x69cb24: bl              #0x826750  ; AllocateClosureStub
    // 0x69cb28: ldur            x2, [fp, #-0xc0]
    // 0x69cb2c: mov             x5, x0
    // 0x69cb30: r1 = Null
    //     0x69cb30: mov             x1, NULL
    // 0x69cb34: r3 = "Chapter 13 Security Generators"
    //     0x69cb34: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ce0] "Chapter 13 Security Generators"
    //     0x69cb38: ldr             x3, [x3, #0xce0]
    // 0x69cb3c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69cb3c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69cb40: r0 = IdleFragment()
    //     0x69cb40: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69cb44: ldur            x1, [fp, #-0x30]
    // 0x69cb48: ArrayStore: r1[3] = r0  ; List_4
    //     0x69cb48: add             x25, x1, #0x1b
    //     0x69cb4c: str             w0, [x25]
    //     0x69cb50: tbz             w0, #0, #0x69cb6c
    //     0x69cb54: ldurb           w16, [x1, #-1]
    //     0x69cb58: ldurb           w17, [x0, #-1]
    //     0x69cb5c: and             x16, x17, x16, lsr #2
    //     0x69cb60: tst             x16, HEAP, lsr #32
    //     0x69cb64: b.eq            #0x69cb6c
    //     0x69cb68: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69cb6c: ldur            x0, [fp, #-8]
    // 0x69cb70: LoadField: r3 = r0->field_37
    //     0x69cb70: ldur            w3, [x0, #0x37]
    // 0x69cb74: DecompressPointer r3
    //     0x69cb74: add             x3, x3, HEAP, lsl #32
    // 0x69cb78: stur            x3, [fp, #-0x78]
    // 0x69cb7c: LoadField: r4 = r0->field_3f
    //     0x69cb7c: ldur            w4, [x0, #0x3f]
    // 0x69cb80: DecompressPointer r4
    //     0x69cb80: add             x4, x4, HEAP, lsl #32
    // 0x69cb84: mov             x2, x0
    // 0x69cb88: stur            x4, [fp, #-0x40]
    // 0x69cb8c: r1 = Function 'researchReset':.
    //     0x69cb8c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ce8] AnonymousClosure: (0x69f2d8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::researchReset (0x69ec5c)
    //     0x69cb90: ldr             x1, [x1, #0xce8]
    // 0x69cb94: r0 = AllocateClosure()
    //     0x69cb94: bl              #0x826750  ; AllocateClosureStub
    // 0x69cb98: r1 = <Chapter13Stat>
    //     0x69cb98: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69cb9c: ldr             x1, [x1, #0xf28]
    // 0x69cba0: stur            x0, [fp, #-0x88]
    // 0x69cba4: r0 = QuestButton()
    //     0x69cba4: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x69cba8: mov             x3, x0
    // 0x69cbac: ldur            x0, [fp, #-0x88]
    // 0x69cbb0: stur            x3, [fp, #-0x90]
    // 0x69cbb4: StoreField: r3->field_2f = r0
    //     0x69cbb4: stur            w0, [x3, #0x2f]
    // 0x69cbb8: ldur            x4, [fp, #-0x78]
    // 0x69cbbc: StoreField: r3->field_1b = r4
    //     0x69cbbc: stur            w4, [x3, #0x1b]
    // 0x69cbc0: r1 = Instance_IconData
    //     0x69cbc0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e48] Obj!IconData@830071
    //     0x69cbc4: ldr             x1, [x1, #0xe48]
    // 0x69cbc8: StoreField: r3->field_1f = r1
    //     0x69cbc8: stur            w1, [x3, #0x1f]
    // 0x69cbcc: ldur            x5, [fp, #-0x40]
    // 0x69cbd0: StoreField: r3->field_2b = r5
    //     0x69cbd0: stur            w5, [x3, #0x2b]
    // 0x69cbd4: r6 = 1
    //     0x69cbd4: movz            x6, #0x1
    // 0x69cbd8: StoreField: r3->field_23 = r6
    //     0x69cbd8: stur            x6, [x3, #0x23]
    // 0x69cbdc: r1 = Function '<anonymous closure>':.
    //     0x69cbdc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cf0] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69cbe0: ldr             x1, [x1, #0xcf0]
    // 0x69cbe4: r2 = Null
    //     0x69cbe4: mov             x2, NULL
    // 0x69cbe8: r0 = AllocateClosure()
    //     0x69cbe8: bl              #0x826750  ; AllocateClosureStub
    // 0x69cbec: mov             x1, x0
    // 0x69cbf0: ldur            x0, [fp, #-0x90]
    // 0x69cbf4: StoreField: r0->field_f = r1
    //     0x69cbf4: stur            w1, [x0, #0xf]
    // 0x69cbf8: ldur            x1, [fp, #-0x20]
    // 0x69cbfc: StoreField: r0->field_37 = r1
    //     0x69cbfc: stur            w1, [x0, #0x37]
    // 0x69cc00: r1 = Instance_Duration
    //     0x69cc00: add             x1, PP, #0x27, lsl #12  ; [pp+0x27c78] Obj!Duration@866301
    //     0x69cc04: ldr             x1, [x1, #0xc78]
    // 0x69cc08: ArrayStore: r0[0] = r1  ; List_4
    //     0x69cc08: stur            w1, [x0, #0x17]
    // 0x69cc0c: r2 = true
    //     0x69cc0c: add             x2, NULL, #0x20  ; true
    // 0x69cc10: StoreField: r0->field_13 = r2
    //     0x69cc10: stur            w2, [x0, #0x13]
    // 0x69cc14: r1 = <Chapter13Stat>
    //     0x69cc14: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69cc18: ldr             x1, [x1, #0xf28]
    // 0x69cc1c: r0 = QuestButton()
    //     0x69cc1c: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x69cc20: mov             x3, x0
    // 0x69cc24: ldur            x0, [fp, #-0x88]
    // 0x69cc28: stur            x3, [fp, #-0x20]
    // 0x69cc2c: StoreField: r3->field_2f = r0
    //     0x69cc2c: stur            w0, [x3, #0x2f]
    // 0x69cc30: ldur            x0, [fp, #-0x78]
    // 0x69cc34: StoreField: r3->field_1b = r0
    //     0x69cc34: stur            w0, [x3, #0x1b]
    // 0x69cc38: r0 = Instance_IconData
    //     0x69cc38: add             x0, PP, #0x28, lsl #12  ; [pp+0x28cf8] Obj!IconData@8308f1
    //     0x69cc3c: ldr             x0, [x0, #0xcf8]
    // 0x69cc40: StoreField: r3->field_1f = r0
    //     0x69cc40: stur            w0, [x3, #0x1f]
    // 0x69cc44: ldur            x0, [fp, #-0x40]
    // 0x69cc48: StoreField: r3->field_2b = r0
    //     0x69cc48: stur            w0, [x3, #0x2b]
    // 0x69cc4c: r0 = 2
    //     0x69cc4c: movz            x0, #0x2
    // 0x69cc50: StoreField: r3->field_23 = r0
    //     0x69cc50: stur            x0, [x3, #0x23]
    // 0x69cc54: r1 = Function '<anonymous closure>':.
    //     0x69cc54: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d00] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69cc58: ldr             x1, [x1, #0xd00]
    // 0x69cc5c: r2 = Null
    //     0x69cc5c: mov             x2, NULL
    // 0x69cc60: r0 = AllocateClosure()
    //     0x69cc60: bl              #0x826750  ; AllocateClosureStub
    // 0x69cc64: mov             x1, x0
    // 0x69cc68: ldur            x0, [fp, #-0x20]
    // 0x69cc6c: StoreField: r0->field_f = r1
    //     0x69cc6c: stur            w1, [x0, #0xf]
    // 0x69cc70: r1 = Function '<anonymous closure>':.
    //     0x69cc70: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d08] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x69cc74: ldr             x1, [x1, #0xd08]
    // 0x69cc78: r2 = Null
    //     0x69cc78: mov             x2, NULL
    // 0x69cc7c: r0 = AllocateClosure()
    //     0x69cc7c: bl              #0x826750  ; AllocateClosureStub
    // 0x69cc80: mov             x1, x0
    // 0x69cc84: ldur            x0, [fp, #-0x20]
    // 0x69cc88: StoreField: r0->field_33 = r1
    //     0x69cc88: stur            w1, [x0, #0x33]
    // 0x69cc8c: ldur            x1, [fp, #-0x28]
    // 0x69cc90: StoreField: r0->field_37 = r1
    //     0x69cc90: stur            w1, [x0, #0x37]
    // 0x69cc94: r3 = true
    //     0x69cc94: add             x3, NULL, #0x20  ; true
    // 0x69cc98: StoreField: r0->field_13 = r3
    //     0x69cc98: stur            w3, [x0, #0x13]
    // 0x69cc9c: r1 = Null
    //     0x69cc9c: mov             x1, NULL
    // 0x69cca0: r2 = 4
    //     0x69cca0: movz            x2, #0x4
    // 0x69cca4: r0 = AllocateArray()
    //     0x69cca4: bl              #0x82746c  ; AllocateArrayStub
    // 0x69cca8: mov             x2, x0
    // 0x69ccac: ldur            x0, [fp, #-0x90]
    // 0x69ccb0: stur            x2, [fp, #-0x28]
    // 0x69ccb4: StoreField: r2->field_f = r0
    //     0x69ccb4: stur            w0, [x2, #0xf]
    // 0x69ccb8: ldur            x0, [fp, #-0x20]
    // 0x69ccbc: StoreField: r2->field_13 = r0
    //     0x69ccbc: stur            w0, [x2, #0x13]
    // 0x69ccc0: r1 = <Widget>
    //     0x69ccc0: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69ccc4: r0 = AllocateGrowableArray()
    //     0x69ccc4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69ccc8: mov             x1, x0
    // 0x69cccc: ldur            x0, [fp, #-0x28]
    // 0x69ccd0: stur            x1, [fp, #-0x20]
    // 0x69ccd4: StoreField: r1->field_f = r0
    //     0x69ccd4: stur            w0, [x1, #0xf]
    // 0x69ccd8: r2 = 4
    //     0x69ccd8: movz            x2, #0x4
    // 0x69ccdc: StoreField: r1->field_b = r2
    //     0x69ccdc: stur            w2, [x1, #0xb]
    // 0x69cce0: r0 = Column()
    //     0x69cce0: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x69cce4: mov             x1, x0
    // 0x69cce8: r0 = Instance_Axis
    //     0x69cce8: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x69ccec: stur            x1, [fp, #-0x28]
    // 0x69ccf0: StoreField: r1->field_f = r0
    //     0x69ccf0: stur            w0, [x1, #0xf]
    // 0x69ccf4: r2 = Instance_MainAxisAlignment
    //     0x69ccf4: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x69ccf8: ldr             x2, [x2, #0x200]
    // 0x69ccfc: StoreField: r1->field_13 = r2
    //     0x69ccfc: stur            w2, [x1, #0x13]
    // 0x69cd00: r3 = Instance_MainAxisSize
    //     0x69cd00: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x69cd04: ldr             x3, [x3, #0x70]
    // 0x69cd08: ArrayStore: r1[0] = r3  ; List_4
    //     0x69cd08: stur            w3, [x1, #0x17]
    // 0x69cd0c: r4 = Instance_CrossAxisAlignment
    //     0x69cd0c: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x69cd10: ldr             x4, [x4, #0x78]
    // 0x69cd14: StoreField: r1->field_1b = r4
    //     0x69cd14: stur            w4, [x1, #0x1b]
    // 0x69cd18: r5 = Instance_VerticalDirection
    //     0x69cd18: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x69cd1c: ldr             x5, [x5, #0x1e8]
    // 0x69cd20: StoreField: r1->field_23 = r5
    //     0x69cd20: stur            w5, [x1, #0x23]
    // 0x69cd24: r6 = Instance_Clip
    //     0x69cd24: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x69cd28: ldr             x6, [x6, #0x1b0]
    // 0x69cd2c: StoreField: r1->field_2b = r6
    //     0x69cd2c: stur            w6, [x1, #0x2b]
    // 0x69cd30: StoreField: r1->field_2f = rZR
    //     0x69cd30: stur            xzr, [x1, #0x2f]
    // 0x69cd34: ldur            x7, [fp, #-0x20]
    // 0x69cd38: StoreField: r1->field_b = r7
    //     0x69cd38: stur            w7, [x1, #0xb]
    // 0x69cd3c: r0 = Padding()
    //     0x69cd3c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x69cd40: mov             x3, x0
    // 0x69cd44: r0 = Instance_EdgeInsets
    //     0x69cd44: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a08] Obj!EdgeInsets@831da1
    //     0x69cd48: ldr             x0, [x0, #0xa08]
    // 0x69cd4c: stur            x3, [fp, #-0x20]
    // 0x69cd50: StoreField: r3->field_f = r0
    //     0x69cd50: stur            w0, [x3, #0xf]
    // 0x69cd54: ldur            x0, [fp, #-0x28]
    // 0x69cd58: StoreField: r3->field_b = r0
    //     0x69cd58: stur            w0, [x3, #0xb]
    // 0x69cd5c: ldur            x2, [fp, #-0x18]
    // 0x69cd60: r1 = Function '<anonymous closure>':.
    //     0x69cd60: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d10] AnonymousClosure: (0x69f24c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69cd64: ldr             x1, [x1, #0xd10]
    // 0x69cd68: r0 = AllocateClosure()
    //     0x69cd68: bl              #0x826750  ; AllocateClosureStub
    // 0x69cd6c: ldur            x2, [fp, #-0x18]
    // 0x69cd70: r1 = Function '<anonymous closure>':.
    //     0x69cd70: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d18] AnonymousClosure: (0x69b1c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x69cd74: ldr             x1, [x1, #0xd18]
    // 0x69cd78: stur            x0, [fp, #-0x28]
    // 0x69cd7c: r0 = AllocateClosure()
    //     0x69cd7c: bl              #0x826750  ; AllocateClosureStub
    // 0x69cd80: ldur            x16, [fp, #-0x28]
    // 0x69cd84: str             x16, [SP]
    // 0x69cd88: ldur            x2, [fp, #-0x20]
    // 0x69cd8c: mov             x5, x0
    // 0x69cd90: r1 = Null
    //     0x69cd90: mov             x1, NULL
    // 0x69cd94: r3 = "Chapter 13 Quests 1"
    //     0x69cd94: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d20] "Chapter 13 Quests 1"
    //     0x69cd98: ldr             x3, [x3, #0xd20]
    // 0x69cd9c: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x69cd9c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x69cda0: ldr             x4, [x4, #0x160]
    // 0x69cda4: r0 = IdleFragment()
    //     0x69cda4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69cda8: ldur            x1, [fp, #-0x30]
    // 0x69cdac: ArrayStore: r1[4] = r0  ; List_4
    //     0x69cdac: add             x25, x1, #0x1f
    //     0x69cdb0: str             w0, [x25]
    //     0x69cdb4: tbz             w0, #0, #0x69cdd0
    //     0x69cdb8: ldurb           w16, [x1, #-1]
    //     0x69cdbc: ldurb           w17, [x0, #-1]
    //     0x69cdc0: and             x16, x17, x16, lsr #2
    //     0x69cdc4: tst             x16, HEAP, lsr #32
    //     0x69cdc8: b.eq            #0x69cdd0
    //     0x69cdcc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69cdd0: ldur            x0, [fp, #-8]
    // 0x69cdd4: LoadField: r1 = r0->field_43
    //     0x69cdd4: ldur            w1, [x0, #0x43]
    // 0x69cdd8: DecompressPointer r1
    //     0x69cdd8: add             x1, x1, HEAP, lsl #32
    // 0x69cddc: r2 = 100
    //     0x69cddc: movz            x2, #0x64
    // 0x69cde0: r0 = containsKey()
    //     0x69cde0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69cde4: tbnz            w0, #4, #0x69ce1c
    // 0x69cde8: ldur            x2, [fp, #-8]
    // 0x69cdec: LoadField: r0 = r2->field_9b
    //     0x69cdec: ldur            w0, [x2, #0x9b]
    // 0x69cdf0: DecompressPointer r0
    //     0x69cdf0: add             x0, x0, HEAP, lsl #32
    // 0x69cdf4: stur            x0, [fp, #-0x20]
    // 0x69cdf8: r0 = AutobuySwitchWrapper()
    //     0x69cdf8: bl              #0x69e39c  ; AllocateAutobuySwitchWrapperStub -> AutobuySwitchWrapper (size=0x14)
    // 0x69cdfc: mov             x1, x0
    // 0x69ce00: r0 = Instance_Chapter13Stat
    //     0x69ce00: add             x0, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x69ce04: ldr             x0, [x0, #0x2f0]
    // 0x69ce08: StoreField: r1->field_b = r0
    //     0x69ce08: stur            w0, [x1, #0xb]
    // 0x69ce0c: ldur            x0, [fp, #-0x20]
    // 0x69ce10: StoreField: r1->field_f = r0
    //     0x69ce10: stur            w0, [x1, #0xf]
    // 0x69ce14: mov             x0, x1
    // 0x69ce18: b               #0x69ce20
    // 0x69ce1c: r0 = Instance_SizedBox
    //     0x69ce1c: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x69ce20: ldur            x2, [fp, #-8]
    // 0x69ce24: stur            x0, [fp, #-0x20]
    // 0x69ce28: r0 = CurrencyCounter()
    //     0x69ce28: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69ce2c: mov             x3, x0
    // 0x69ce30: r0 = "Storage"
    //     0x69ce30: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d28] "Storage"
    //     0x69ce34: ldr             x0, [x0, #0xd28]
    // 0x69ce38: stur            x3, [fp, #-0x28]
    // 0x69ce3c: StoreField: r3->field_b = r0
    //     0x69ce3c: stur            w0, [x3, #0xb]
    // 0x69ce40: ldur            x2, [fp, #-0x18]
    // 0x69ce44: r1 = Function '<anonymous closure>':.
    //     0x69ce44: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d30] AnonymousClosure: (0x69f1a4), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69ce48: ldr             x1, [x1, #0xd30]
    // 0x69ce4c: r0 = AllocateClosure()
    //     0x69ce4c: bl              #0x826750  ; AllocateClosureStub
    // 0x69ce50: mov             x1, x0
    // 0x69ce54: ldur            x0, [fp, #-0x28]
    // 0x69ce58: StoreField: r0->field_f = r1
    //     0x69ce58: stur            w1, [x0, #0xf]
    // 0x69ce5c: ldur            x1, [fp, #-0x20]
    // 0x69ce60: StoreField: r0->field_1b = r1
    //     0x69ce60: stur            w1, [x0, #0x1b]
    // 0x69ce64: r2 = false
    //     0x69ce64: add             x2, NULL, #0x30  ; false
    // 0x69ce68: StoreField: r0->field_1f = r2
    //     0x69ce68: stur            w2, [x0, #0x1f]
    // 0x69ce6c: ldur            x3, [fp, #-8]
    // 0x69ce70: LoadField: r4 = r3->field_2b
    //     0x69ce70: ldur            w4, [x3, #0x2b]
    // 0x69ce74: DecompressPointer r4
    //     0x69ce74: add             x4, x4, HEAP, lsl #32
    // 0x69ce78: stur            x4, [fp, #-0xa8]
    // 0x69ce7c: LoadField: r5 = r3->field_37
    //     0x69ce7c: ldur            w5, [x3, #0x37]
    // 0x69ce80: DecompressPointer r5
    //     0x69ce80: add             x5, x5, HEAP, lsl #32
    // 0x69ce84: stur            x5, [fp, #-0xa0]
    // 0x69ce88: LoadField: r6 = r3->field_4b
    //     0x69ce88: ldur            w6, [x3, #0x4b]
    // 0x69ce8c: DecompressPointer r6
    //     0x69ce8c: add             x6, x6, HEAP, lsl #32
    // 0x69ce90: stur            x6, [fp, #-0x90]
    // 0x69ce94: LoadField: r7 = r3->field_47
    //     0x69ce94: ldur            w7, [x3, #0x47]
    // 0x69ce98: DecompressPointer r7
    //     0x69ce98: add             x7, x7, HEAP, lsl #32
    // 0x69ce9c: stur            x7, [fp, #-0x88]
    // 0x69cea0: LoadField: r8 = r3->field_53
    //     0x69cea0: ldur            w8, [x3, #0x53]
    // 0x69cea4: DecompressPointer r8
    //     0x69cea4: add             x8, x8, HEAP, lsl #32
    // 0x69cea8: stur            x8, [fp, #-0x78]
    // 0x69ceac: LoadField: r1 = r3->field_8b
    //     0x69ceac: ldur            x1, [x3, #0x8b]
    // 0x69ceb0: cmp             x1, #5
    // 0x69ceb4: b.gt            #0x69cec4
    // 0x69ceb8: r23 = const [0xb]
    //     0x69ceb8: add             x23, PP, #0x28, lsl #12  ; [pp+0x28d38] List<int>(1)
    //     0x69cebc: ldr             x23, [x23, #0xd38]
    // 0x69cec0: b               #0x69cee4
    // 0x69cec4: cmp             x1, #0xb
    // 0x69cec8: b.gt            #0x69ced8
    // 0x69cecc: r1 = const [0xb, 0xc]
    //     0x69cecc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] List<int>(2)
    //     0x69ced0: ldr             x1, [x1, #0x218]
    // 0x69ced4: b               #0x69cee0
    // 0x69ced8: r1 = const [0xb, 0xc, 0xd]
    //     0x69ced8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26da0] List<int>(3)
    //     0x69cedc: ldr             x1, [x1, #0xda0]
    // 0x69cee0: mov             x23, x1
    // 0x69cee4: ldur            x12, [fp, #-0x60]
    // 0x69cee8: ldur            x13, [fp, #-0x58]
    // 0x69ceec: ldur            x11, [fp, #-0x70]
    // 0x69cef0: ldur            x9, [fp, #-0x10]
    // 0x69cef4: ldur            x10, [fp, #-0x38]
    // 0x69cef8: ldur            x19, [fp, #-0x80]
    // 0x69cefc: ldur            x20, [fp, #-0x98]
    // 0x69cf00: ldur            x14, [fp, #-0x68]
    // 0x69cf04: stur            x23, [fp, #-0x40]
    // 0x69cf08: LoadField: r24 = r3->field_7b
    //     0x69cf08: ldur            w24, [x3, #0x7b]
    // 0x69cf0c: DecompressPointer r24
    //     0x69cf0c: add             x24, x24, HEAP, lsl #32
    // 0x69cf10: stur            x24, [fp, #-0x20]
    // 0x69cf14: r1 = <Chapter13Stat>
    //     0x69cf14: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69cf18: ldr             x1, [x1, #0xf28]
    // 0x69cf1c: r0 = GeneratorGroup()
    //     0x69cf1c: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69cf20: mov             x3, x0
    // 0x69cf24: ldur            x0, [fp, #-0xa0]
    // 0x69cf28: stur            x3, [fp, #-0xb0]
    // 0x69cf2c: StoreField: r3->field_1f = r0
    //     0x69cf2c: stur            w0, [x3, #0x1f]
    // 0x69cf30: ldur            x0, [fp, #-0x80]
    // 0x69cf34: StoreField: r3->field_23 = r0
    //     0x69cf34: stur            w0, [x3, #0x23]
    // 0x69cf38: ldur            x4, [fp, #-0x98]
    // 0x69cf3c: StoreField: r3->field_27 = r4
    //     0x69cf3c: stur            w4, [x3, #0x27]
    // 0x69cf40: ldur            x1, [fp, #-0x90]
    // 0x69cf44: StoreField: r3->field_2b = r1
    //     0x69cf44: stur            w1, [x3, #0x2b]
    // 0x69cf48: ldur            x1, [fp, #-0x88]
    // 0x69cf4c: StoreField: r3->field_2f = r1
    //     0x69cf4c: stur            w1, [x3, #0x2f]
    // 0x69cf50: ldur            x1, [fp, #-0x78]
    // 0x69cf54: StoreField: r3->field_33 = r1
    //     0x69cf54: stur            w1, [x3, #0x33]
    // 0x69cf58: r1 = Function '<anonymous closure>':.
    //     0x69cf58: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d40] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69cf5c: ldr             x1, [x1, #0xd40]
    // 0x69cf60: r2 = Null
    //     0x69cf60: mov             x2, NULL
    // 0x69cf64: r0 = AllocateClosure()
    //     0x69cf64: bl              #0x826750  ; AllocateClosureStub
    // 0x69cf68: mov             x1, x0
    // 0x69cf6c: ldur            x0, [fp, #-0xb0]
    // 0x69cf70: StoreField: r0->field_3b = r1
    //     0x69cf70: stur            w1, [x0, #0x3b]
    // 0x69cf74: ldur            x3, [fp, #-0x60]
    // 0x69cf78: StoreField: r0->field_43 = r3
    //     0x69cf78: stur            w3, [x0, #0x43]
    // 0x69cf7c: ldur            x4, [fp, #-0x58]
    // 0x69cf80: StoreField: r0->field_47 = r4
    //     0x69cf80: stur            w4, [x0, #0x47]
    // 0x69cf84: ldur            x5, [fp, #-0x68]
    // 0x69cf88: StoreField: r0->field_5b = r5
    //     0x69cf88: stur            w5, [x0, #0x5b]
    // 0x69cf8c: r1 = Function '<anonymous closure>':.
    //     0x69cf8c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d48] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69cf90: ldr             x1, [x1, #0xd48]
    // 0x69cf94: r2 = Null
    //     0x69cf94: mov             x2, NULL
    // 0x69cf98: r0 = AllocateClosure()
    //     0x69cf98: bl              #0x826750  ; AllocateClosureStub
    // 0x69cf9c: mov             x1, x0
    // 0x69cfa0: ldur            x0, [fp, #-0xb0]
    // 0x69cfa4: ArrayStore: r0[0] = r1  ; List_4
    //     0x69cfa4: stur            w1, [x0, #0x17]
    // 0x69cfa8: r1 = Function '<anonymous closure>':.
    //     0x69cfa8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d50] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69cfac: ldr             x1, [x1, #0xd50]
    // 0x69cfb0: r2 = Null
    //     0x69cfb0: mov             x2, NULL
    // 0x69cfb4: r0 = AllocateClosure()
    //     0x69cfb4: bl              #0x826750  ; AllocateClosureStub
    // 0x69cfb8: mov             x1, x0
    // 0x69cfbc: ldur            x0, [fp, #-0xb0]
    // 0x69cfc0: StoreField: r0->field_1b = r1
    //     0x69cfc0: stur            w1, [x0, #0x1b]
    // 0x69cfc4: ldur            x3, [fp, #-0x70]
    // 0x69cfc8: StoreField: r0->field_57 = r3
    //     0x69cfc8: stur            w3, [x0, #0x57]
    // 0x69cfcc: ldur            x1, [fp, #-0x40]
    // 0x69cfd0: StoreField: r0->field_53 = r1
    //     0x69cfd0: stur            w1, [x0, #0x53]
    // 0x69cfd4: ldur            x2, [fp, #-0x18]
    // 0x69cfd8: r1 = Function '<anonymous closure>':.
    //     0x69cfd8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d58] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69cfdc: ldr             x1, [x1, #0xd58]
    // 0x69cfe0: r0 = AllocateClosure()
    //     0x69cfe0: bl              #0x826750  ; AllocateClosureStub
    // 0x69cfe4: mov             x1, x0
    // 0x69cfe8: ldur            x0, [fp, #-0xb0]
    // 0x69cfec: StoreField: r0->field_6b = r1
    //     0x69cfec: stur            w1, [x0, #0x6b]
    // 0x69cff0: ldur            x1, [fp, #-0xa8]
    // 0x69cff4: StoreField: r0->field_4b = r1
    //     0x69cff4: stur            w1, [x0, #0x4b]
    // 0x69cff8: ldur            x1, [fp, #-0x28]
    // 0x69cffc: StoreField: r0->field_f = r1
    //     0x69cffc: stur            w1, [x0, #0xf]
    // 0x69d000: ldur            x1, [fp, #-0x20]
    // 0x69d004: StoreField: r0->field_67 = r1
    //     0x69d004: stur            w1, [x0, #0x67]
    // 0x69d008: ldur            x3, [fp, #-0x10]
    // 0x69d00c: StoreField: r0->field_77 = r3
    //     0x69d00c: stur            w3, [x0, #0x77]
    // 0x69d010: ldur            x4, [fp, #-0x38]
    // 0x69d014: StoreField: r0->field_7b = r4
    //     0x69d014: stur            w4, [x0, #0x7b]
    // 0x69d018: r1 = "Chapter 13 Storage Generators 1"
    //     0x69d018: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d60] "Chapter 13 Storage Generators 1"
    //     0x69d01c: ldr             x1, [x1, #0xd60]
    // 0x69d020: StoreField: r0->field_73 = r1
    //     0x69d020: stur            w1, [x0, #0x73]
    // 0x69d024: ldur            x2, [fp, #-0x18]
    // 0x69d028: r1 = Function '<anonymous closure>':.
    //     0x69d028: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d68] AnonymousClosure: (0x69f178), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d02c: ldr             x1, [x1, #0xd68]
    // 0x69d030: r0 = AllocateClosure()
    //     0x69d030: bl              #0x826750  ; AllocateClosureStub
    // 0x69d034: ldur            x2, [fp, #-0xb0]
    // 0x69d038: mov             x5, x0
    // 0x69d03c: r1 = Null
    //     0x69d03c: mov             x1, NULL
    // 0x69d040: r3 = "Chapter 13 Storage Generators"
    //     0x69d040: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d70] "Chapter 13 Storage Generators"
    //     0x69d044: ldr             x3, [x3, #0xd70]
    // 0x69d048: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69d048: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69d04c: r0 = IdleFragment()
    //     0x69d04c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69d050: ldur            x1, [fp, #-0x30]
    // 0x69d054: ArrayStore: r1[5] = r0  ; List_4
    //     0x69d054: add             x25, x1, #0x23
    //     0x69d058: str             w0, [x25]
    //     0x69d05c: tbz             w0, #0, #0x69d078
    //     0x69d060: ldurb           w16, [x1, #-1]
    //     0x69d064: ldurb           w17, [x0, #-1]
    //     0x69d068: and             x16, x17, x16, lsr #2
    //     0x69d06c: tst             x16, HEAP, lsr #32
    //     0x69d070: b.eq            #0x69d078
    //     0x69d074: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69d078: ldur            x0, [fp, #-8]
    // 0x69d07c: LoadField: r1 = r0->field_43
    //     0x69d07c: ldur            w1, [x0, #0x43]
    // 0x69d080: DecompressPointer r1
    //     0x69d080: add             x1, x1, HEAP, lsl #32
    // 0x69d084: r2 = 100
    //     0x69d084: movz            x2, #0x64
    // 0x69d088: r0 = containsKey()
    //     0x69d088: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69d08c: tbnz            w0, #4, #0x69d0c4
    // 0x69d090: ldur            x2, [fp, #-8]
    // 0x69d094: LoadField: r0 = r2->field_9b
    //     0x69d094: ldur            w0, [x2, #0x9b]
    // 0x69d098: DecompressPointer r0
    //     0x69d098: add             x0, x0, HEAP, lsl #32
    // 0x69d09c: stur            x0, [fp, #-0x20]
    // 0x69d0a0: r0 = AutobuySwitchWrapper()
    //     0x69d0a0: bl              #0x69e39c  ; AllocateAutobuySwitchWrapperStub -> AutobuySwitchWrapper (size=0x14)
    // 0x69d0a4: mov             x1, x0
    // 0x69d0a8: r0 = Instance_Chapter13Stat
    //     0x69d0a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x69d0ac: ldr             x0, [x0, #0x310]
    // 0x69d0b0: StoreField: r1->field_b = r0
    //     0x69d0b0: stur            w0, [x1, #0xb]
    // 0x69d0b4: ldur            x0, [fp, #-0x20]
    // 0x69d0b8: StoreField: r1->field_f = r0
    //     0x69d0b8: stur            w0, [x1, #0xf]
    // 0x69d0bc: mov             x0, x1
    // 0x69d0c0: b               #0x69d0c8
    // 0x69d0c4: r0 = Instance_SizedBox
    //     0x69d0c4: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x69d0c8: ldur            x2, [fp, #-8]
    // 0x69d0cc: stur            x0, [fp, #-0x20]
    // 0x69d0d0: r0 = CurrencyCounter()
    //     0x69d0d0: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69d0d4: mov             x3, x0
    // 0x69d0d8: r0 = "Database"
    //     0x69d0d8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d78] "Database"
    //     0x69d0dc: ldr             x0, [x0, #0xd78]
    // 0x69d0e0: stur            x3, [fp, #-0x28]
    // 0x69d0e4: StoreField: r3->field_b = r0
    //     0x69d0e4: stur            w0, [x3, #0xb]
    // 0x69d0e8: ldur            x2, [fp, #-0x18]
    // 0x69d0ec: r1 = Function '<anonymous closure>':.
    //     0x69d0ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d80] AnonymousClosure: (0x69f0d0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d0f0: ldr             x1, [x1, #0xd80]
    // 0x69d0f4: r0 = AllocateClosure()
    //     0x69d0f4: bl              #0x826750  ; AllocateClosureStub
    // 0x69d0f8: mov             x1, x0
    // 0x69d0fc: ldur            x0, [fp, #-0x28]
    // 0x69d100: StoreField: r0->field_f = r1
    //     0x69d100: stur            w1, [x0, #0xf]
    // 0x69d104: ldur            x1, [fp, #-0x20]
    // 0x69d108: StoreField: r0->field_1b = r1
    //     0x69d108: stur            w1, [x0, #0x1b]
    // 0x69d10c: r2 = false
    //     0x69d10c: add             x2, NULL, #0x30  ; false
    // 0x69d110: StoreField: r0->field_1f = r2
    //     0x69d110: stur            w2, [x0, #0x1f]
    // 0x69d114: ldur            x3, [fp, #-8]
    // 0x69d118: LoadField: r4 = r3->field_2b
    //     0x69d118: ldur            w4, [x3, #0x2b]
    // 0x69d11c: DecompressPointer r4
    //     0x69d11c: add             x4, x4, HEAP, lsl #32
    // 0x69d120: stur            x4, [fp, #-0xa8]
    // 0x69d124: LoadField: r5 = r3->field_37
    //     0x69d124: ldur            w5, [x3, #0x37]
    // 0x69d128: DecompressPointer r5
    //     0x69d128: add             x5, x5, HEAP, lsl #32
    // 0x69d12c: stur            x5, [fp, #-0xa0]
    // 0x69d130: LoadField: r6 = r3->field_4b
    //     0x69d130: ldur            w6, [x3, #0x4b]
    // 0x69d134: DecompressPointer r6
    //     0x69d134: add             x6, x6, HEAP, lsl #32
    // 0x69d138: stur            x6, [fp, #-0x90]
    // 0x69d13c: LoadField: r7 = r3->field_47
    //     0x69d13c: ldur            w7, [x3, #0x47]
    // 0x69d140: DecompressPointer r7
    //     0x69d140: add             x7, x7, HEAP, lsl #32
    // 0x69d144: stur            x7, [fp, #-0x88]
    // 0x69d148: LoadField: r8 = r3->field_53
    //     0x69d148: ldur            w8, [x3, #0x53]
    // 0x69d14c: DecompressPointer r8
    //     0x69d14c: add             x8, x8, HEAP, lsl #32
    // 0x69d150: stur            x8, [fp, #-0x78]
    // 0x69d154: LoadField: r1 = r3->field_8b
    //     0x69d154: ldur            x1, [x3, #0x8b]
    // 0x69d158: cmp             x1, #8
    // 0x69d15c: b.ge            #0x69d16c
    // 0x69d160: r23 = const [0x1f]
    //     0x69d160: add             x23, PP, #0x28, lsl #12  ; [pp+0x28d88] List<int>(1)
    //     0x69d164: ldr             x23, [x23, #0xd88]
    // 0x69d168: b               #0x69d18c
    // 0x69d16c: cmp             x1, #9
    // 0x69d170: b.gt            #0x69d180
    // 0x69d174: r1 = const [0x1f, 0x20]
    //     0x69d174: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d90] List<int>(2)
    //     0x69d178: ldr             x1, [x1, #0xd90]
    // 0x69d17c: b               #0x69d188
    // 0x69d180: r1 = const [0x1f, 0x20, 0x21]
    //     0x69d180: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d98] List<int>(3)
    //     0x69d184: ldr             x1, [x1, #0xd98]
    // 0x69d188: mov             x23, x1
    // 0x69d18c: ldur            x12, [fp, #-0x60]
    // 0x69d190: ldur            x13, [fp, #-0x58]
    // 0x69d194: ldur            x11, [fp, #-0x70]
    // 0x69d198: ldur            x9, [fp, #-0x10]
    // 0x69d19c: ldur            x10, [fp, #-0x38]
    // 0x69d1a0: ldur            x19, [fp, #-0x80]
    // 0x69d1a4: ldur            x20, [fp, #-0x98]
    // 0x69d1a8: ldur            x14, [fp, #-0x68]
    // 0x69d1ac: stur            x23, [fp, #-0x40]
    // 0x69d1b0: LoadField: r24 = r3->field_7b
    //     0x69d1b0: ldur            w24, [x3, #0x7b]
    // 0x69d1b4: DecompressPointer r24
    //     0x69d1b4: add             x24, x24, HEAP, lsl #32
    // 0x69d1b8: stur            x24, [fp, #-0x20]
    // 0x69d1bc: r1 = <Chapter13Stat>
    //     0x69d1bc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69d1c0: ldr             x1, [x1, #0xf28]
    // 0x69d1c4: r0 = GeneratorGroup()
    //     0x69d1c4: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69d1c8: mov             x3, x0
    // 0x69d1cc: ldur            x0, [fp, #-0xa0]
    // 0x69d1d0: stur            x3, [fp, #-0xb0]
    // 0x69d1d4: StoreField: r3->field_1f = r0
    //     0x69d1d4: stur            w0, [x3, #0x1f]
    // 0x69d1d8: ldur            x0, [fp, #-0x80]
    // 0x69d1dc: StoreField: r3->field_23 = r0
    //     0x69d1dc: stur            w0, [x3, #0x23]
    // 0x69d1e0: ldur            x4, [fp, #-0x98]
    // 0x69d1e4: StoreField: r3->field_27 = r4
    //     0x69d1e4: stur            w4, [x3, #0x27]
    // 0x69d1e8: ldur            x1, [fp, #-0x90]
    // 0x69d1ec: StoreField: r3->field_2b = r1
    //     0x69d1ec: stur            w1, [x3, #0x2b]
    // 0x69d1f0: ldur            x1, [fp, #-0x88]
    // 0x69d1f4: StoreField: r3->field_2f = r1
    //     0x69d1f4: stur            w1, [x3, #0x2f]
    // 0x69d1f8: ldur            x1, [fp, #-0x78]
    // 0x69d1fc: StoreField: r3->field_33 = r1
    //     0x69d1fc: stur            w1, [x3, #0x33]
    // 0x69d200: r1 = Function '<anonymous closure>':.
    //     0x69d200: add             x1, PP, #0x28, lsl #12  ; [pp+0x28da0] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69d204: ldr             x1, [x1, #0xda0]
    // 0x69d208: r2 = Null
    //     0x69d208: mov             x2, NULL
    // 0x69d20c: r0 = AllocateClosure()
    //     0x69d20c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d210: mov             x1, x0
    // 0x69d214: ldur            x0, [fp, #-0xb0]
    // 0x69d218: StoreField: r0->field_3b = r1
    //     0x69d218: stur            w1, [x0, #0x3b]
    // 0x69d21c: ldur            x3, [fp, #-0x60]
    // 0x69d220: StoreField: r0->field_43 = r3
    //     0x69d220: stur            w3, [x0, #0x43]
    // 0x69d224: ldur            x4, [fp, #-0x58]
    // 0x69d228: StoreField: r0->field_47 = r4
    //     0x69d228: stur            w4, [x0, #0x47]
    // 0x69d22c: ldur            x5, [fp, #-0x68]
    // 0x69d230: StoreField: r0->field_5b = r5
    //     0x69d230: stur            w5, [x0, #0x5b]
    // 0x69d234: r1 = Function '<anonymous closure>':.
    //     0x69d234: add             x1, PP, #0x28, lsl #12  ; [pp+0x28da8] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69d238: ldr             x1, [x1, #0xda8]
    // 0x69d23c: r2 = Null
    //     0x69d23c: mov             x2, NULL
    // 0x69d240: r0 = AllocateClosure()
    //     0x69d240: bl              #0x826750  ; AllocateClosureStub
    // 0x69d244: mov             x1, x0
    // 0x69d248: ldur            x0, [fp, #-0xb0]
    // 0x69d24c: ArrayStore: r0[0] = r1  ; List_4
    //     0x69d24c: stur            w1, [x0, #0x17]
    // 0x69d250: r1 = Function '<anonymous closure>':.
    //     0x69d250: add             x1, PP, #0x28, lsl #12  ; [pp+0x28db0] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69d254: ldr             x1, [x1, #0xdb0]
    // 0x69d258: r2 = Null
    //     0x69d258: mov             x2, NULL
    // 0x69d25c: r0 = AllocateClosure()
    //     0x69d25c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d260: mov             x1, x0
    // 0x69d264: ldur            x0, [fp, #-0xb0]
    // 0x69d268: StoreField: r0->field_1b = r1
    //     0x69d268: stur            w1, [x0, #0x1b]
    // 0x69d26c: ldur            x3, [fp, #-0x70]
    // 0x69d270: StoreField: r0->field_57 = r3
    //     0x69d270: stur            w3, [x0, #0x57]
    // 0x69d274: ldur            x1, [fp, #-0x40]
    // 0x69d278: StoreField: r0->field_53 = r1
    //     0x69d278: stur            w1, [x0, #0x53]
    // 0x69d27c: ldur            x2, [fp, #-0x18]
    // 0x69d280: r1 = Function '<anonymous closure>':.
    //     0x69d280: add             x1, PP, #0x28, lsl #12  ; [pp+0x28db8] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d284: ldr             x1, [x1, #0xdb8]
    // 0x69d288: r0 = AllocateClosure()
    //     0x69d288: bl              #0x826750  ; AllocateClosureStub
    // 0x69d28c: mov             x1, x0
    // 0x69d290: ldur            x0, [fp, #-0xb0]
    // 0x69d294: StoreField: r0->field_6b = r1
    //     0x69d294: stur            w1, [x0, #0x6b]
    // 0x69d298: ldur            x1, [fp, #-0xa8]
    // 0x69d29c: StoreField: r0->field_4b = r1
    //     0x69d29c: stur            w1, [x0, #0x4b]
    // 0x69d2a0: ldur            x1, [fp, #-0x28]
    // 0x69d2a4: StoreField: r0->field_f = r1
    //     0x69d2a4: stur            w1, [x0, #0xf]
    // 0x69d2a8: ldur            x1, [fp, #-0x20]
    // 0x69d2ac: StoreField: r0->field_67 = r1
    //     0x69d2ac: stur            w1, [x0, #0x67]
    // 0x69d2b0: ldur            x3, [fp, #-0x10]
    // 0x69d2b4: StoreField: r0->field_77 = r3
    //     0x69d2b4: stur            w3, [x0, #0x77]
    // 0x69d2b8: ldur            x4, [fp, #-0x38]
    // 0x69d2bc: StoreField: r0->field_7b = r4
    //     0x69d2bc: stur            w4, [x0, #0x7b]
    // 0x69d2c0: r1 = "Chapter 13 Database Generators 1"
    //     0x69d2c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28dc0] "Chapter 13 Database Generators 1"
    //     0x69d2c4: ldr             x1, [x1, #0xdc0]
    // 0x69d2c8: StoreField: r0->field_73 = r1
    //     0x69d2c8: stur            w1, [x0, #0x73]
    // 0x69d2cc: ldur            x2, [fp, #-0x18]
    // 0x69d2d0: r1 = Function '<anonymous closure>':.
    //     0x69d2d0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28dc8] AnonymousClosure: (0x69f0a4), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d2d4: ldr             x1, [x1, #0xdc8]
    // 0x69d2d8: r0 = AllocateClosure()
    //     0x69d2d8: bl              #0x826750  ; AllocateClosureStub
    // 0x69d2dc: ldur            x2, [fp, #-0xb0]
    // 0x69d2e0: mov             x5, x0
    // 0x69d2e4: r1 = Null
    //     0x69d2e4: mov             x1, NULL
    // 0x69d2e8: r3 = "Chapter 13 Database Generators"
    //     0x69d2e8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Chapter 13 Database Generators"
    //     0x69d2ec: ldr             x3, [x3, #0xdd0]
    // 0x69d2f0: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69d2f0: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69d2f4: r0 = IdleFragment()
    //     0x69d2f4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69d2f8: ldur            x1, [fp, #-0x30]
    // 0x69d2fc: ArrayStore: r1[6] = r0  ; List_4
    //     0x69d2fc: add             x25, x1, #0x27
    //     0x69d300: str             w0, [x25]
    //     0x69d304: tbz             w0, #0, #0x69d320
    //     0x69d308: ldurb           w16, [x1, #-1]
    //     0x69d30c: ldurb           w17, [x0, #-1]
    //     0x69d310: and             x16, x17, x16, lsr #2
    //     0x69d314: tst             x16, HEAP, lsr #32
    //     0x69d318: b.eq            #0x69d320
    //     0x69d31c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69d320: ldur            x0, [fp, #-8]
    // 0x69d324: LoadField: r1 = r0->field_43
    //     0x69d324: ldur            w1, [x0, #0x43]
    // 0x69d328: DecompressPointer r1
    //     0x69d328: add             x1, x1, HEAP, lsl #32
    // 0x69d32c: r2 = 100
    //     0x69d32c: movz            x2, #0x64
    // 0x69d330: r0 = containsKey()
    //     0x69d330: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69d334: tbnz            w0, #4, #0x69d36c
    // 0x69d338: ldur            x2, [fp, #-8]
    // 0x69d33c: LoadField: r0 = r2->field_9b
    //     0x69d33c: ldur            w0, [x2, #0x9b]
    // 0x69d340: DecompressPointer r0
    //     0x69d340: add             x0, x0, HEAP, lsl #32
    // 0x69d344: stur            x0, [fp, #-0x20]
    // 0x69d348: r0 = AutobuySwitchWrapper()
    //     0x69d348: bl              #0x69e39c  ; AllocateAutobuySwitchWrapperStub -> AutobuySwitchWrapper (size=0x14)
    // 0x69d34c: mov             x1, x0
    // 0x69d350: r0 = Instance_Chapter13Stat
    //     0x69d350: add             x0, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x69d354: ldr             x0, [x0, #0x360]
    // 0x69d358: StoreField: r1->field_b = r0
    //     0x69d358: stur            w0, [x1, #0xb]
    // 0x69d35c: ldur            x0, [fp, #-0x20]
    // 0x69d360: StoreField: r1->field_f = r0
    //     0x69d360: stur            w0, [x1, #0xf]
    // 0x69d364: mov             x0, x1
    // 0x69d368: b               #0x69d370
    // 0x69d36c: r0 = Instance_SizedBox
    //     0x69d36c: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x69d370: ldur            x2, [fp, #-8]
    // 0x69d374: stur            x0, [fp, #-0x20]
    // 0x69d378: r0 = CurrencyCounter()
    //     0x69d378: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69d37c: mov             x3, x0
    // 0x69d380: r0 = "Dev"
    //     0x69d380: add             x0, PP, #0x11, lsl #12  ; [pp+0x113d0] "Dev"
    //     0x69d384: ldr             x0, [x0, #0x3d0]
    // 0x69d388: stur            x3, [fp, #-0x28]
    // 0x69d38c: StoreField: r3->field_b = r0
    //     0x69d38c: stur            w0, [x3, #0xb]
    // 0x69d390: ldur            x2, [fp, #-0x18]
    // 0x69d394: r1 = Function '<anonymous closure>':.
    //     0x69d394: add             x1, PP, #0x28, lsl #12  ; [pp+0x28dd8] AnonymousClosure: (0x69effc), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d398: ldr             x1, [x1, #0xdd8]
    // 0x69d39c: r0 = AllocateClosure()
    //     0x69d39c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d3a0: mov             x1, x0
    // 0x69d3a4: ldur            x0, [fp, #-0x28]
    // 0x69d3a8: StoreField: r0->field_f = r1
    //     0x69d3a8: stur            w1, [x0, #0xf]
    // 0x69d3ac: ldur            x1, [fp, #-0x20]
    // 0x69d3b0: StoreField: r0->field_1b = r1
    //     0x69d3b0: stur            w1, [x0, #0x1b]
    // 0x69d3b4: r2 = false
    //     0x69d3b4: add             x2, NULL, #0x30  ; false
    // 0x69d3b8: StoreField: r0->field_1f = r2
    //     0x69d3b8: stur            w2, [x0, #0x1f]
    // 0x69d3bc: ldur            x3, [fp, #-8]
    // 0x69d3c0: LoadField: r4 = r3->field_2b
    //     0x69d3c0: ldur            w4, [x3, #0x2b]
    // 0x69d3c4: DecompressPointer r4
    //     0x69d3c4: add             x4, x4, HEAP, lsl #32
    // 0x69d3c8: stur            x4, [fp, #-0xa8]
    // 0x69d3cc: LoadField: r5 = r3->field_37
    //     0x69d3cc: ldur            w5, [x3, #0x37]
    // 0x69d3d0: DecompressPointer r5
    //     0x69d3d0: add             x5, x5, HEAP, lsl #32
    // 0x69d3d4: stur            x5, [fp, #-0xa0]
    // 0x69d3d8: LoadField: r6 = r3->field_4b
    //     0x69d3d8: ldur            w6, [x3, #0x4b]
    // 0x69d3dc: DecompressPointer r6
    //     0x69d3dc: add             x6, x6, HEAP, lsl #32
    // 0x69d3e0: stur            x6, [fp, #-0x90]
    // 0x69d3e4: LoadField: r7 = r3->field_47
    //     0x69d3e4: ldur            w7, [x3, #0x47]
    // 0x69d3e8: DecompressPointer r7
    //     0x69d3e8: add             x7, x7, HEAP, lsl #32
    // 0x69d3ec: stur            x7, [fp, #-0x88]
    // 0x69d3f0: LoadField: r8 = r3->field_53
    //     0x69d3f0: ldur            w8, [x3, #0x53]
    // 0x69d3f4: DecompressPointer r8
    //     0x69d3f4: add             x8, x8, HEAP, lsl #32
    // 0x69d3f8: stur            x8, [fp, #-0x78]
    // 0x69d3fc: LoadField: r1 = r3->field_8b
    //     0x69d3fc: ldur            x1, [x3, #0x8b]
    // 0x69d400: cmp             x1, #9
    // 0x69d404: b.gt            #0x69d414
    // 0x69d408: r23 = const [0x33]
    //     0x69d408: add             x23, PP, #0x28, lsl #12  ; [pp+0x28de0] List<int>(1)
    //     0x69d40c: ldr             x23, [x23, #0xde0]
    // 0x69d410: b               #0x69d434
    // 0x69d414: cmp             x1, #0xa
    // 0x69d418: b.gt            #0x69d428
    // 0x69d41c: r1 = const [0x33, 0x34]
    //     0x69d41c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28de8] List<int>(2)
    //     0x69d420: ldr             x1, [x1, #0xde8]
    // 0x69d424: b               #0x69d430
    // 0x69d428: r1 = const [0x33, 0x34, 0x35]
    //     0x69d428: add             x1, PP, #0x28, lsl #12  ; [pp+0x28df0] List<int>(3)
    //     0x69d42c: ldr             x1, [x1, #0xdf0]
    // 0x69d430: mov             x23, x1
    // 0x69d434: ldur            x12, [fp, #-0x60]
    // 0x69d438: ldur            x13, [fp, #-0x58]
    // 0x69d43c: ldur            x11, [fp, #-0x70]
    // 0x69d440: ldur            x9, [fp, #-0x10]
    // 0x69d444: ldur            x10, [fp, #-0x38]
    // 0x69d448: ldur            x19, [fp, #-0x80]
    // 0x69d44c: ldur            x20, [fp, #-0x98]
    // 0x69d450: ldur            x14, [fp, #-0x68]
    // 0x69d454: stur            x23, [fp, #-0x40]
    // 0x69d458: LoadField: r24 = r3->field_7b
    //     0x69d458: ldur            w24, [x3, #0x7b]
    // 0x69d45c: DecompressPointer r24
    //     0x69d45c: add             x24, x24, HEAP, lsl #32
    // 0x69d460: stur            x24, [fp, #-0x20]
    // 0x69d464: r1 = <Chapter13Stat>
    //     0x69d464: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69d468: ldr             x1, [x1, #0xf28]
    // 0x69d46c: r0 = GeneratorGroup()
    //     0x69d46c: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69d470: mov             x3, x0
    // 0x69d474: ldur            x0, [fp, #-0xa0]
    // 0x69d478: stur            x3, [fp, #-0xb0]
    // 0x69d47c: StoreField: r3->field_1f = r0
    //     0x69d47c: stur            w0, [x3, #0x1f]
    // 0x69d480: ldur            x0, [fp, #-0x80]
    // 0x69d484: StoreField: r3->field_23 = r0
    //     0x69d484: stur            w0, [x3, #0x23]
    // 0x69d488: ldur            x4, [fp, #-0x98]
    // 0x69d48c: StoreField: r3->field_27 = r4
    //     0x69d48c: stur            w4, [x3, #0x27]
    // 0x69d490: ldur            x1, [fp, #-0x90]
    // 0x69d494: StoreField: r3->field_2b = r1
    //     0x69d494: stur            w1, [x3, #0x2b]
    // 0x69d498: ldur            x1, [fp, #-0x88]
    // 0x69d49c: StoreField: r3->field_2f = r1
    //     0x69d49c: stur            w1, [x3, #0x2f]
    // 0x69d4a0: ldur            x1, [fp, #-0x78]
    // 0x69d4a4: StoreField: r3->field_33 = r1
    //     0x69d4a4: stur            w1, [x3, #0x33]
    // 0x69d4a8: r1 = Function '<anonymous closure>':.
    //     0x69d4a8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28df8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69d4ac: ldr             x1, [x1, #0xdf8]
    // 0x69d4b0: r2 = Null
    //     0x69d4b0: mov             x2, NULL
    // 0x69d4b4: r0 = AllocateClosure()
    //     0x69d4b4: bl              #0x826750  ; AllocateClosureStub
    // 0x69d4b8: mov             x1, x0
    // 0x69d4bc: ldur            x0, [fp, #-0xb0]
    // 0x69d4c0: StoreField: r0->field_3b = r1
    //     0x69d4c0: stur            w1, [x0, #0x3b]
    // 0x69d4c4: ldur            x3, [fp, #-0x60]
    // 0x69d4c8: StoreField: r0->field_43 = r3
    //     0x69d4c8: stur            w3, [x0, #0x43]
    // 0x69d4cc: ldur            x4, [fp, #-0x58]
    // 0x69d4d0: StoreField: r0->field_47 = r4
    //     0x69d4d0: stur            w4, [x0, #0x47]
    // 0x69d4d4: ldur            x5, [fp, #-0x68]
    // 0x69d4d8: StoreField: r0->field_5b = r5
    //     0x69d4d8: stur            w5, [x0, #0x5b]
    // 0x69d4dc: r1 = Function '<anonymous closure>':.
    //     0x69d4dc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e00] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69d4e0: ldr             x1, [x1, #0xe00]
    // 0x69d4e4: r2 = Null
    //     0x69d4e4: mov             x2, NULL
    // 0x69d4e8: r0 = AllocateClosure()
    //     0x69d4e8: bl              #0x826750  ; AllocateClosureStub
    // 0x69d4ec: mov             x1, x0
    // 0x69d4f0: ldur            x0, [fp, #-0xb0]
    // 0x69d4f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x69d4f4: stur            w1, [x0, #0x17]
    // 0x69d4f8: r1 = Function '<anonymous closure>':.
    //     0x69d4f8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e08] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69d4fc: ldr             x1, [x1, #0xe08]
    // 0x69d500: r2 = Null
    //     0x69d500: mov             x2, NULL
    // 0x69d504: r0 = AllocateClosure()
    //     0x69d504: bl              #0x826750  ; AllocateClosureStub
    // 0x69d508: mov             x1, x0
    // 0x69d50c: ldur            x0, [fp, #-0xb0]
    // 0x69d510: StoreField: r0->field_1b = r1
    //     0x69d510: stur            w1, [x0, #0x1b]
    // 0x69d514: ldur            x3, [fp, #-0x70]
    // 0x69d518: StoreField: r0->field_57 = r3
    //     0x69d518: stur            w3, [x0, #0x57]
    // 0x69d51c: ldur            x1, [fp, #-0x40]
    // 0x69d520: StoreField: r0->field_53 = r1
    //     0x69d520: stur            w1, [x0, #0x53]
    // 0x69d524: ldur            x2, [fp, #-0x18]
    // 0x69d528: r1 = Function '<anonymous closure>':.
    //     0x69d528: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e10] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d52c: ldr             x1, [x1, #0xe10]
    // 0x69d530: r0 = AllocateClosure()
    //     0x69d530: bl              #0x826750  ; AllocateClosureStub
    // 0x69d534: mov             x1, x0
    // 0x69d538: ldur            x0, [fp, #-0xb0]
    // 0x69d53c: StoreField: r0->field_6b = r1
    //     0x69d53c: stur            w1, [x0, #0x6b]
    // 0x69d540: ldur            x1, [fp, #-0xa8]
    // 0x69d544: StoreField: r0->field_4b = r1
    //     0x69d544: stur            w1, [x0, #0x4b]
    // 0x69d548: ldur            x1, [fp, #-0x28]
    // 0x69d54c: StoreField: r0->field_f = r1
    //     0x69d54c: stur            w1, [x0, #0xf]
    // 0x69d550: ldur            x1, [fp, #-0x20]
    // 0x69d554: StoreField: r0->field_67 = r1
    //     0x69d554: stur            w1, [x0, #0x67]
    // 0x69d558: ldur            x3, [fp, #-0x10]
    // 0x69d55c: StoreField: r0->field_77 = r3
    //     0x69d55c: stur            w3, [x0, #0x77]
    // 0x69d560: ldur            x4, [fp, #-0x38]
    // 0x69d564: StoreField: r0->field_7b = r4
    //     0x69d564: stur            w4, [x0, #0x7b]
    // 0x69d568: r1 = "Chapter 13 Dev Generators 1"
    //     0x69d568: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e18] "Chapter 13 Dev Generators 1"
    //     0x69d56c: ldr             x1, [x1, #0xe18]
    // 0x69d570: StoreField: r0->field_73 = r1
    //     0x69d570: stur            w1, [x0, #0x73]
    // 0x69d574: ldur            x2, [fp, #-0x18]
    // 0x69d578: r1 = Function '<anonymous closure>':.
    //     0x69d578: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e20] AnonymousClosure: (0x69efd0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d57c: ldr             x1, [x1, #0xe20]
    // 0x69d580: r0 = AllocateClosure()
    //     0x69d580: bl              #0x826750  ; AllocateClosureStub
    // 0x69d584: ldur            x2, [fp, #-0xb0]
    // 0x69d588: mov             x5, x0
    // 0x69d58c: r1 = Null
    //     0x69d58c: mov             x1, NULL
    // 0x69d590: r3 = "Chapter 13 Dev Generators"
    //     0x69d590: add             x3, PP, #0x28, lsl #12  ; [pp+0x28e28] "Chapter 13 Dev Generators"
    //     0x69d594: ldr             x3, [x3, #0xe28]
    // 0x69d598: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69d598: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69d59c: r0 = IdleFragment()
    //     0x69d59c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69d5a0: ldur            x1, [fp, #-0x30]
    // 0x69d5a4: ArrayStore: r1[7] = r0  ; List_4
    //     0x69d5a4: add             x25, x1, #0x2b
    //     0x69d5a8: str             w0, [x25]
    //     0x69d5ac: tbz             w0, #0, #0x69d5c8
    //     0x69d5b0: ldurb           w16, [x1, #-1]
    //     0x69d5b4: ldurb           w17, [x0, #-1]
    //     0x69d5b8: and             x16, x17, x16, lsr #2
    //     0x69d5bc: tst             x16, HEAP, lsr #32
    //     0x69d5c0: b.eq            #0x69d5c8
    //     0x69d5c4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69d5c8: ldur            x2, [fp, #-8]
    // 0x69d5cc: LoadField: r0 = r2->field_37
    //     0x69d5cc: ldur            w0, [x2, #0x37]
    // 0x69d5d0: DecompressPointer r0
    //     0x69d5d0: add             x0, x0, HEAP, lsl #32
    // 0x69d5d4: stur            x0, [fp, #-0x40]
    // 0x69d5d8: LoadField: r3 = r2->field_43
    //     0x69d5d8: ldur            w3, [x2, #0x43]
    // 0x69d5dc: DecompressPointer r3
    //     0x69d5dc: add             x3, x3, HEAP, lsl #32
    // 0x69d5e0: stur            x3, [fp, #-0x28]
    // 0x69d5e4: LoadField: r4 = r2->field_97
    //     0x69d5e4: ldur            w4, [x2, #0x97]
    // 0x69d5e8: DecompressPointer r4
    //     0x69d5e8: add             x4, x4, HEAP, lsl #32
    // 0x69d5ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69d5f0: cmp             w4, w16
    // 0x69d5f4: b.eq            #0x69e390
    // 0x69d5f8: stur            x4, [fp, #-0x20]
    // 0x69d5fc: r1 = <Chapter13Stat>
    //     0x69d5fc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69d600: ldr             x1, [x1, #0xf28]
    // 0x69d604: r0 = UpgradeGroup()
    //     0x69d604: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x69d608: mov             x3, x0
    // 0x69d60c: r0 = 1
    //     0x69d60c: movz            x0, #0x1
    // 0x69d610: stur            x3, [fp, #-0x78]
    // 0x69d614: StoreField: r3->field_13 = r0
    //     0x69d614: stur            x0, [x3, #0x13]
    // 0x69d618: ldur            x0, [fp, #-0x20]
    // 0x69d61c: StoreField: r3->field_1b = r0
    //     0x69d61c: stur            w0, [x3, #0x1b]
    // 0x69d620: ldur            x0, [fp, #-0x40]
    // 0x69d624: StoreField: r3->field_1f = r0
    //     0x69d624: stur            w0, [x3, #0x1f]
    // 0x69d628: ldur            x0, [fp, #-0x28]
    // 0x69d62c: StoreField: r3->field_23 = r0
    //     0x69d62c: stur            w0, [x3, #0x23]
    // 0x69d630: r1 = Function '<anonymous closure>':.
    //     0x69d630: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e30] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69d634: ldr             x1, [x1, #0xe30]
    // 0x69d638: r2 = Null
    //     0x69d638: mov             x2, NULL
    // 0x69d63c: r0 = AllocateClosure()
    //     0x69d63c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d640: mov             x1, x0
    // 0x69d644: ldur            x0, [fp, #-0x78]
    // 0x69d648: StoreField: r0->field_2b = r1
    //     0x69d648: stur            w1, [x0, #0x2b]
    // 0x69d64c: r1 = const [0xa, 0x14, 0x1e, 0x28, 0x32, 0x3c, 0x46, 0x50, 0x5a, 0x64]
    //     0x69d64c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e38] List<int>(10)
    //     0x69d650: ldr             x1, [x1, #0xe38]
    // 0x69d654: StoreField: r0->field_f = r1
    //     0x69d654: stur            w1, [x0, #0xf]
    // 0x69d658: r3 = false
    //     0x69d658: add             x3, NULL, #0x30  ; false
    // 0x69d65c: StoreField: r0->field_27 = r3
    //     0x69d65c: stur            w3, [x0, #0x27]
    // 0x69d660: r1 = Instance_UpgradeDisplayMode
    //     0x69d660: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x69d664: ldr             x1, [x1, #0x608]
    // 0x69d668: StoreField: r0->field_2f = r1
    //     0x69d668: stur            w1, [x0, #0x2f]
    // 0x69d66c: StoreField: r0->field_33 = r3
    //     0x69d66c: stur            w3, [x0, #0x33]
    // 0x69d670: ldur            x2, [fp, #-0x18]
    // 0x69d674: r1 = Function '<anonymous closure>':.
    //     0x69d674: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e40] AnonymousClosure: (0x69efd0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d678: ldr             x1, [x1, #0xe40]
    // 0x69d67c: r0 = AllocateClosure()
    //     0x69d67c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d680: ldur            x2, [fp, #-0x78]
    // 0x69d684: mov             x5, x0
    // 0x69d688: r1 = Null
    //     0x69d688: mov             x1, NULL
    // 0x69d68c: r3 = "Chapter 13 Main Upgrades"
    //     0x69d68c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28e48] "Chapter 13 Main Upgrades"
    //     0x69d690: ldr             x3, [x3, #0xe48]
    // 0x69d694: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69d694: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69d698: r0 = IdleFragment()
    //     0x69d698: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69d69c: ldur            x1, [fp, #-0x30]
    // 0x69d6a0: ArrayStore: r1[8] = r0  ; List_4
    //     0x69d6a0: add             x25, x1, #0x2f
    //     0x69d6a4: str             w0, [x25]
    //     0x69d6a8: tbz             w0, #0, #0x69d6c4
    //     0x69d6ac: ldurb           w16, [x1, #-1]
    //     0x69d6b0: ldurb           w17, [x0, #-1]
    //     0x69d6b4: and             x16, x17, x16, lsr #2
    //     0x69d6b8: tst             x16, HEAP, lsr #32
    //     0x69d6bc: b.eq            #0x69d6c4
    //     0x69d6c0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69d6c4: ldur            x0, [fp, #-8]
    // 0x69d6c8: LoadField: r3 = r0->field_37
    //     0x69d6c8: ldur            w3, [x0, #0x37]
    // 0x69d6cc: DecompressPointer r3
    //     0x69d6cc: add             x3, x3, HEAP, lsl #32
    // 0x69d6d0: stur            x3, [fp, #-0x20]
    // 0x69d6d4: r1 = Function '<anonymous closure>':.
    //     0x69d6d4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e50] AnonymousClosure: (0x69efc4), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d6d8: ldr             x1, [x1, #0xe50]
    // 0x69d6dc: r2 = Null
    //     0x69d6dc: mov             x2, NULL
    // 0x69d6e0: r0 = AllocateClosure()
    //     0x69d6e0: bl              #0x826750  ; AllocateClosureStub
    // 0x69d6e4: r1 = <Chapter13Stat>
    //     0x69d6e4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69d6e8: ldr             x1, [x1, #0xf28]
    // 0x69d6ec: stur            x0, [fp, #-0x28]
    // 0x69d6f0: r0 = PrestigeButton()
    //     0x69d6f0: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x69d6f4: mov             x3, x0
    // 0x69d6f8: ldur            x0, [fp, #-0x28]
    // 0x69d6fc: stur            x3, [fp, #-0x40]
    // 0x69d700: StoreField: r3->field_1f = r0
    //     0x69d700: stur            w0, [x3, #0x1f]
    // 0x69d704: r0 = Instance_Chapter13Stat
    //     0x69d704: add             x0, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x69d708: ldr             x0, [x0, #0x380]
    // 0x69d70c: StoreField: r3->field_1b = r0
    //     0x69d70c: stur            w0, [x3, #0x1b]
    // 0x69d710: ldur            x2, [fp, #-8]
    // 0x69d714: r1 = Function 'getSprintPoints':.
    //     0x69d714: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e58] AnonymousClosure: (0x69ef8c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getSprintPoints (0x69eefc)
    //     0x69d718: ldr             x1, [x1, #0xe58]
    // 0x69d71c: r0 = AllocateClosure()
    //     0x69d71c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d720: mov             x1, x0
    // 0x69d724: ldur            x0, [fp, #-0x40]
    // 0x69d728: StoreField: r0->field_2f = r1
    //     0x69d728: stur            w1, [x0, #0x2f]
    // 0x69d72c: ldur            x2, [fp, #-8]
    // 0x69d730: r1 = Function 'applyResearchPrestige':.
    //     0x69d730: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e60] AnonymousClosure: (0x69eb00), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::applyResearchPrestige (0x69eb38)
    //     0x69d734: ldr             x1, [x1, #0xe60]
    // 0x69d738: r0 = AllocateClosure()
    //     0x69d738: bl              #0x826750  ; AllocateClosureStub
    // 0x69d73c: mov             x1, x0
    // 0x69d740: ldur            x0, [fp, #-0x40]
    // 0x69d744: StoreField: r0->field_33 = r1
    //     0x69d744: stur            w1, [x0, #0x33]
    // 0x69d748: ldur            x1, [fp, #-0x20]
    // 0x69d74c: ArrayStore: r0[0] = r1  ; List_4
    //     0x69d74c: stur            w1, [x0, #0x17]
    // 0x69d750: r3 = Closure: (Chapter13Stat?) => String from Function 'humanName': static.
    //     0x69d750: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ba8] Closure: (Chapter13Stat?) => String from Function 'humanName': static. (0x248ed99cc5c)
    //     0x69d754: ldr             x3, [x3, #0xba8]
    // 0x69d758: StoreField: r0->field_43 = r3
    //     0x69d758: stur            w3, [x0, #0x43]
    // 0x69d75c: r1 = Function '<anonymous closure>':.
    //     0x69d75c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e68] AnonymousClosure: (0x69eaf4), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d760: ldr             x1, [x1, #0xe68]
    // 0x69d764: r2 = Null
    //     0x69d764: mov             x2, NULL
    // 0x69d768: r0 = AllocateClosure()
    //     0x69d768: bl              #0x826750  ; AllocateClosureStub
    // 0x69d76c: mov             x1, x0
    // 0x69d770: ldur            x0, [fp, #-0x40]
    // 0x69d774: StoreField: r0->field_23 = r1
    //     0x69d774: stur            w1, [x0, #0x23]
    // 0x69d778: r1 = "everything above"
    //     0x69d778: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x69d77c: ldr             x1, [x1, #0x1b0]
    // 0x69d780: StoreField: r0->field_3f = r1
    //     0x69d780: stur            w1, [x0, #0x3f]
    // 0x69d784: r3 = false
    //     0x69d784: add             x3, NULL, #0x30  ; false
    // 0x69d788: StoreField: r0->field_f = r3
    //     0x69d788: stur            w3, [x0, #0xf]
    // 0x69d78c: StoreField: r0->field_4f = r3
    //     0x69d78c: stur            w3, [x0, #0x4f]
    // 0x69d790: r1 = true
    //     0x69d790: add             x1, NULL, #0x20  ; true
    // 0x69d794: StoreField: r0->field_2b = r1
    //     0x69d794: stur            w1, [x0, #0x2b]
    // 0x69d798: StoreField: r0->field_53 = r3
    //     0x69d798: stur            w3, [x0, #0x53]
    // 0x69d79c: StoreField: r0->field_5b = r1
    //     0x69d79c: stur            w1, [x0, #0x5b]
    // 0x69d7a0: r1 = "Gain"
    //     0x69d7a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x69d7a4: ldr             x1, [x1, #0x1b8]
    // 0x69d7a8: StoreField: r0->field_5f = r1
    //     0x69d7a8: stur            w1, [x0, #0x5f]
    // 0x69d7ac: ldur            x2, [fp, #-0x18]
    // 0x69d7b0: r1 = Function '<anonymous closure>':.
    //     0x69d7b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e70] AnonymousClosure: (0x69e94c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d7b4: ldr             x1, [x1, #0xe70]
    // 0x69d7b8: r0 = AllocateClosure()
    //     0x69d7b8: bl              #0x826750  ; AllocateClosureStub
    // 0x69d7bc: ldur            x2, [fp, #-0x40]
    // 0x69d7c0: mov             x5, x0
    // 0x69d7c4: r1 = Null
    //     0x69d7c4: mov             x1, NULL
    // 0x69d7c8: r3 = "Chapter 13 Prestige 1"
    //     0x69d7c8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28bd0] "Chapter 13 Prestige 1"
    //     0x69d7cc: ldr             x3, [x3, #0xbd0]
    // 0x69d7d0: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69d7d0: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69d7d4: r0 = IdleFragment()
    //     0x69d7d4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69d7d8: ldur            x1, [fp, #-0x30]
    // 0x69d7dc: ArrayStore: r1[9] = r0  ; List_4
    //     0x69d7dc: add             x25, x1, #0x33
    //     0x69d7e0: str             w0, [x25]
    //     0x69d7e4: tbz             w0, #0, #0x69d800
    //     0x69d7e8: ldurb           w16, [x1, #-1]
    //     0x69d7ec: ldurb           w17, [x0, #-1]
    //     0x69d7f0: and             x16, x17, x16, lsr #2
    //     0x69d7f4: tst             x16, HEAP, lsr #32
    //     0x69d7f8: b.eq            #0x69d800
    //     0x69d7fc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69d800: ldur            x0, [fp, #-8]
    // 0x69d804: LoadField: r2 = r0->field_37
    //     0x69d804: ldur            w2, [x0, #0x37]
    // 0x69d808: DecompressPointer r2
    //     0x69d808: add             x2, x2, HEAP, lsl #32
    // 0x69d80c: stur            x2, [fp, #-0x20]
    // 0x69d810: r1 = <Chapter13Stat>
    //     0x69d810: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69d814: ldr             x1, [x1, #0xf28]
    // 0x69d818: r0 = IntermissionButton()
    //     0x69d818: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x69d81c: mov             x3, x0
    // 0x69d820: ldur            x0, [fp, #-0x20]
    // 0x69d824: stur            x3, [fp, #-0x28]
    // 0x69d828: StoreField: r3->field_1b = r0
    //     0x69d828: stur            w0, [x3, #0x1b]
    // 0x69d82c: r0 = Instance_Tuple2
    //     0x69d82c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28e78] Obj!Tuple2<Chapter13Stat, CustomNum>@826771
    //     0x69d830: ldr             x0, [x0, #0xe78]
    // 0x69d834: StoreField: r3->field_1f = r0
    //     0x69d834: stur            w0, [x3, #0x1f]
    // 0x69d838: ldur            x2, [fp, #-0x18]
    // 0x69d83c: r1 = Function '<anonymous closure>':.
    //     0x69d83c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e80] AnonymousClosure: (0x69e9f0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d840: ldr             x1, [x1, #0xe80]
    // 0x69d844: r0 = AllocateClosure()
    //     0x69d844: bl              #0x826750  ; AllocateClosureStub
    // 0x69d848: mov             x1, x0
    // 0x69d84c: ldur            x0, [fp, #-0x28]
    // 0x69d850: StoreField: r0->field_23 = r1
    //     0x69d850: stur            w1, [x0, #0x23]
    // 0x69d854: r1 = Function '<anonymous closure>':.
    //     0x69d854: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e88] AnonymousClosure: (0x69e998), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d858: ldr             x1, [x1, #0xe88]
    // 0x69d85c: r2 = Null
    //     0x69d85c: mov             x2, NULL
    // 0x69d860: r0 = AllocateClosure()
    //     0x69d860: bl              #0x826750  ; AllocateClosureStub
    // 0x69d864: mov             x1, x0
    // 0x69d868: ldur            x0, [fp, #-0x28]
    // 0x69d86c: ArrayStore: r0[0] = r1  ; List_4
    //     0x69d86c: stur            w1, [x0, #0x17]
    // 0x69d870: r3 = Closure: (Chapter13Stat?) => String from Function 'humanName': static.
    //     0x69d870: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ba8] Closure: (Chapter13Stat?) => String from Function 'humanName': static. (0x248ed99cc5c)
    //     0x69d874: ldr             x3, [x3, #0xba8]
    // 0x69d878: StoreField: r0->field_f = r3
    //     0x69d878: stur            w3, [x0, #0xf]
    // 0x69d87c: ldur            x2, [fp, #-0x18]
    // 0x69d880: r1 = Function '<anonymous closure>':.
    //     0x69d880: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e90] AnonymousClosure: (0x69e94c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d884: ldr             x1, [x1, #0xe90]
    // 0x69d888: r0 = AllocateClosure()
    //     0x69d888: bl              #0x826750  ; AllocateClosureStub
    // 0x69d88c: ldur            x2, [fp, #-0x18]
    // 0x69d890: r1 = Function '<anonymous closure>':.
    //     0x69d890: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e98] AnonymousClosure: (0x69e8a0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d894: ldr             x1, [x1, #0xe98]
    // 0x69d898: stur            x0, [fp, #-0x20]
    // 0x69d89c: r0 = AllocateClosure()
    //     0x69d89c: bl              #0x826750  ; AllocateClosureStub
    // 0x69d8a0: str             x0, [SP]
    // 0x69d8a4: ldur            x2, [fp, #-0x28]
    // 0x69d8a8: ldur            x5, [fp, #-0x20]
    // 0x69d8ac: r1 = Null
    //     0x69d8ac: mov             x1, NULL
    // 0x69d8b0: r3 = "Chapter 13 Intermission 1"
    //     0x69d8b0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ea0] "Chapter 13 Intermission 1"
    //     0x69d8b4: ldr             x3, [x3, #0xea0]
    // 0x69d8b8: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x69d8b8: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x69d8bc: ldr             x4, [x4, #0x160]
    // 0x69d8c0: r0 = IdleFragment()
    //     0x69d8c0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69d8c4: ldur            x1, [fp, #-0x30]
    // 0x69d8c8: ArrayStore: r1[10] = r0  ; List_4
    //     0x69d8c8: add             x25, x1, #0x37
    //     0x69d8cc: str             w0, [x25]
    //     0x69d8d0: tbz             w0, #0, #0x69d8ec
    //     0x69d8d4: ldurb           w16, [x1, #-1]
    //     0x69d8d8: ldurb           w17, [x0, #-1]
    //     0x69d8dc: and             x16, x17, x16, lsr #2
    //     0x69d8e0: tst             x16, HEAP, lsr #32
    //     0x69d8e4: b.eq            #0x69d8ec
    //     0x69d8e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69d8ec: r0 = CurrencyCounter()
    //     0x69d8ec: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69d8f0: mov             x3, x0
    // 0x69d8f4: r0 = "Analytics"
    //     0x69d8f4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ea8] "Analytics"
    //     0x69d8f8: ldr             x0, [x0, #0xea8]
    // 0x69d8fc: stur            x3, [fp, #-0x20]
    // 0x69d900: StoreField: r3->field_b = r0
    //     0x69d900: stur            w0, [x3, #0xb]
    // 0x69d904: ldur            x2, [fp, #-0x18]
    // 0x69d908: r1 = Function '<anonymous closure>':.
    //     0x69d908: add             x1, PP, #0x28, lsl #12  ; [pp+0x28eb0] AnonymousClosure: (0x69e7f8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69d90c: ldr             x1, [x1, #0xeb0]
    // 0x69d910: r0 = AllocateClosure()
    //     0x69d910: bl              #0x826750  ; AllocateClosureStub
    // 0x69d914: mov             x1, x0
    // 0x69d918: ldur            x0, [fp, #-0x20]
    // 0x69d91c: StoreField: r0->field_f = r1
    //     0x69d91c: stur            w1, [x0, #0xf]
    // 0x69d920: r3 = false
    //     0x69d920: add             x3, NULL, #0x30  ; false
    // 0x69d924: StoreField: r0->field_1f = r3
    //     0x69d924: stur            w3, [x0, #0x1f]
    // 0x69d928: ldur            x4, [fp, #-8]
    // 0x69d92c: LoadField: r5 = r4->field_2b
    //     0x69d92c: ldur            w5, [x4, #0x2b]
    // 0x69d930: DecompressPointer r5
    //     0x69d930: add             x5, x5, HEAP, lsl #32
    // 0x69d934: stur            x5, [fp, #-0x90]
    // 0x69d938: LoadField: r6 = r4->field_37
    //     0x69d938: ldur            w6, [x4, #0x37]
    // 0x69d93c: DecompressPointer r6
    //     0x69d93c: add             x6, x6, HEAP, lsl #32
    // 0x69d940: stur            x6, [fp, #-0x88]
    // 0x69d944: LoadField: r7 = r4->field_4b
    //     0x69d944: ldur            w7, [x4, #0x4b]
    // 0x69d948: DecompressPointer r7
    //     0x69d948: add             x7, x7, HEAP, lsl #32
    // 0x69d94c: stur            x7, [fp, #-0x78]
    // 0x69d950: LoadField: r8 = r4->field_47
    //     0x69d950: ldur            w8, [x4, #0x47]
    // 0x69d954: DecompressPointer r8
    //     0x69d954: add             x8, x8, HEAP, lsl #32
    // 0x69d958: stur            x8, [fp, #-0x40]
    // 0x69d95c: LoadField: r9 = r4->field_53
    //     0x69d95c: ldur            w9, [x4, #0x53]
    // 0x69d960: DecompressPointer r9
    //     0x69d960: add             x9, x9, HEAP, lsl #32
    // 0x69d964: stur            x9, [fp, #-0x28]
    // 0x69d968: LoadField: r1 = r4->field_8b
    //     0x69d968: ldur            x1, [x4, #0x8b]
    // 0x69d96c: cmp             x1, #0xb
    // 0x69d970: b.gt            #0x69d9b8
    // 0x69d974: r10 = 2
    //     0x69d974: movz            x10, #0x2
    // 0x69d978: mov             x2, x10
    // 0x69d97c: r1 = Null
    //     0x69d97c: mov             x1, NULL
    // 0x69d980: r0 = AllocateArray()
    //     0x69d980: bl              #0x82746c  ; AllocateArrayStub
    // 0x69d984: stur            x0, [fp, #-0xa0]
    // 0x69d988: r16 = 122
    //     0x69d988: movz            x16, #0x7a
    // 0x69d98c: StoreField: r0->field_f = r16
    //     0x69d98c: stur            w16, [x0, #0xf]
    // 0x69d990: r1 = <int>
    //     0x69d990: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x69d994: r0 = AllocateGrowableArray()
    //     0x69d994: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69d998: mov             x1, x0
    // 0x69d99c: ldur            x0, [fp, #-0xa0]
    // 0x69d9a0: StoreField: r1->field_f = r0
    //     0x69d9a0: stur            w0, [x1, #0xf]
    // 0x69d9a4: r0 = 2
    //     0x69d9a4: movz            x0, #0x2
    // 0x69d9a8: StoreField: r1->field_b = r0
    //     0x69d9a8: stur            w0, [x1, #0xb]
    // 0x69d9ac: mov             x23, x1
    // 0x69d9b0: r2 = 4
    //     0x69d9b0: movz            x2, #0x4
    // 0x69d9b4: b               #0x69da70
    // 0x69d9b8: mov             x3, x4
    // 0x69d9bc: r0 = 2
    //     0x69d9bc: movz            x0, #0x2
    // 0x69d9c0: LoadField: r1 = r3->field_43
    //     0x69d9c0: ldur            w1, [x3, #0x43]
    // 0x69d9c4: DecompressPointer r1
    //     0x69d9c4: add             x1, x1, HEAP, lsl #32
    // 0x69d9c8: r2 = 200
    //     0x69d9c8: movz            x2, #0xc8
    // 0x69d9cc: r0 = containsKey()
    //     0x69d9cc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69d9d0: tbnz            w0, #4, #0x69da28
    // 0x69d9d4: r0 = 6
    //     0x69d9d4: movz            x0, #0x6
    // 0x69d9d8: mov             x2, x0
    // 0x69d9dc: r1 = Null
    //     0x69d9dc: mov             x1, NULL
    // 0x69d9e0: r0 = AllocateArray()
    //     0x69d9e0: bl              #0x82746c  ; AllocateArrayStub
    // 0x69d9e4: stur            x0, [fp, #-0xa0]
    // 0x69d9e8: r16 = 122
    //     0x69d9e8: movz            x16, #0x7a
    // 0x69d9ec: StoreField: r0->field_f = r16
    //     0x69d9ec: stur            w16, [x0, #0xf]
    // 0x69d9f0: r16 = 124
    //     0x69d9f0: movz            x16, #0x7c
    // 0x69d9f4: StoreField: r0->field_13 = r16
    //     0x69d9f4: stur            w16, [x0, #0x13]
    // 0x69d9f8: r16 = 126
    //     0x69d9f8: movz            x16, #0x7e
    // 0x69d9fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x69d9fc: stur            w16, [x0, #0x17]
    // 0x69da00: r1 = <int>
    //     0x69da00: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x69da04: r0 = AllocateGrowableArray()
    //     0x69da04: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69da08: mov             x1, x0
    // 0x69da0c: ldur            x0, [fp, #-0xa0]
    // 0x69da10: StoreField: r1->field_f = r0
    //     0x69da10: stur            w0, [x1, #0xf]
    // 0x69da14: r0 = 6
    //     0x69da14: movz            x0, #0x6
    // 0x69da18: StoreField: r1->field_b = r0
    //     0x69da18: stur            w0, [x1, #0xb]
    // 0x69da1c: mov             x0, x1
    // 0x69da20: r2 = 4
    //     0x69da20: movz            x2, #0x4
    // 0x69da24: b               #0x69da6c
    // 0x69da28: r0 = 4
    //     0x69da28: movz            x0, #0x4
    // 0x69da2c: mov             x2, x0
    // 0x69da30: r1 = Null
    //     0x69da30: mov             x1, NULL
    // 0x69da34: r0 = AllocateArray()
    //     0x69da34: bl              #0x82746c  ; AllocateArrayStub
    // 0x69da38: stur            x0, [fp, #-0xa0]
    // 0x69da3c: r16 = 122
    //     0x69da3c: movz            x16, #0x7a
    // 0x69da40: StoreField: r0->field_f = r16
    //     0x69da40: stur            w16, [x0, #0xf]
    // 0x69da44: r16 = 124
    //     0x69da44: movz            x16, #0x7c
    // 0x69da48: StoreField: r0->field_13 = r16
    //     0x69da48: stur            w16, [x0, #0x13]
    // 0x69da4c: r1 = <int>
    //     0x69da4c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x69da50: r0 = AllocateGrowableArray()
    //     0x69da50: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69da54: mov             x1, x0
    // 0x69da58: ldur            x0, [fp, #-0xa0]
    // 0x69da5c: StoreField: r1->field_f = r0
    //     0x69da5c: stur            w0, [x1, #0xf]
    // 0x69da60: r2 = 4
    //     0x69da60: movz            x2, #0x4
    // 0x69da64: StoreField: r1->field_b = r2
    //     0x69da64: stur            w2, [x1, #0xb]
    // 0x69da68: mov             x0, x1
    // 0x69da6c: mov             x23, x0
    // 0x69da70: ldur            x0, [fp, #-8]
    // 0x69da74: ldur            x12, [fp, #-0x60]
    // 0x69da78: ldur            x13, [fp, #-0x58]
    // 0x69da7c: ldur            x3, [fp, #-0x20]
    // 0x69da80: ldur            x4, [fp, #-0x90]
    // 0x69da84: ldur            x5, [fp, #-0x88]
    // 0x69da88: ldur            x6, [fp, #-0x78]
    // 0x69da8c: ldur            x7, [fp, #-0x40]
    // 0x69da90: ldur            x8, [fp, #-0x28]
    // 0x69da94: ldur            x11, [fp, #-0x70]
    // 0x69da98: ldur            x9, [fp, #-0x10]
    // 0x69da9c: ldur            x10, [fp, #-0x38]
    // 0x69daa0: ldur            x19, [fp, #-0x80]
    // 0x69daa4: ldur            x20, [fp, #-0x98]
    // 0x69daa8: ldur            x14, [fp, #-0x68]
    // 0x69daac: stur            x23, [fp, #-0xa8]
    // 0x69dab0: LoadField: r24 = r0->field_7b
    //     0x69dab0: ldur            w24, [x0, #0x7b]
    // 0x69dab4: DecompressPointer r24
    //     0x69dab4: add             x24, x24, HEAP, lsl #32
    // 0x69dab8: stur            x24, [fp, #-0xa0]
    // 0x69dabc: r1 = <Chapter13Stat>
    //     0x69dabc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69dac0: ldr             x1, [x1, #0xf28]
    // 0x69dac4: r0 = GeneratorGroup()
    //     0x69dac4: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69dac8: mov             x3, x0
    // 0x69dacc: ldur            x0, [fp, #-0x88]
    // 0x69dad0: stur            x3, [fp, #-0xb0]
    // 0x69dad4: StoreField: r3->field_1f = r0
    //     0x69dad4: stur            w0, [x3, #0x1f]
    // 0x69dad8: ldur            x0, [fp, #-0x80]
    // 0x69dadc: StoreField: r3->field_23 = r0
    //     0x69dadc: stur            w0, [x3, #0x23]
    // 0x69dae0: ldur            x4, [fp, #-0x98]
    // 0x69dae4: StoreField: r3->field_27 = r4
    //     0x69dae4: stur            w4, [x3, #0x27]
    // 0x69dae8: ldur            x1, [fp, #-0x78]
    // 0x69daec: StoreField: r3->field_2b = r1
    //     0x69daec: stur            w1, [x3, #0x2b]
    // 0x69daf0: ldur            x1, [fp, #-0x40]
    // 0x69daf4: StoreField: r3->field_2f = r1
    //     0x69daf4: stur            w1, [x3, #0x2f]
    // 0x69daf8: ldur            x1, [fp, #-0x28]
    // 0x69dafc: StoreField: r3->field_33 = r1
    //     0x69dafc: stur            w1, [x3, #0x33]
    // 0x69db00: r1 = Function '<anonymous closure>':.
    //     0x69db00: add             x1, PP, #0x28, lsl #12  ; [pp+0x28eb8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69db04: ldr             x1, [x1, #0xeb8]
    // 0x69db08: r2 = Null
    //     0x69db08: mov             x2, NULL
    // 0x69db0c: r0 = AllocateClosure()
    //     0x69db0c: bl              #0x826750  ; AllocateClosureStub
    // 0x69db10: mov             x1, x0
    // 0x69db14: ldur            x0, [fp, #-0xb0]
    // 0x69db18: StoreField: r0->field_3b = r1
    //     0x69db18: stur            w1, [x0, #0x3b]
    // 0x69db1c: ldur            x3, [fp, #-0x60]
    // 0x69db20: StoreField: r0->field_43 = r3
    //     0x69db20: stur            w3, [x0, #0x43]
    // 0x69db24: ldur            x4, [fp, #-0x58]
    // 0x69db28: StoreField: r0->field_47 = r4
    //     0x69db28: stur            w4, [x0, #0x47]
    // 0x69db2c: ldur            x5, [fp, #-0x68]
    // 0x69db30: StoreField: r0->field_5b = r5
    //     0x69db30: stur            w5, [x0, #0x5b]
    // 0x69db34: r1 = Function '<anonymous closure>':.
    //     0x69db34: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ec0] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69db38: ldr             x1, [x1, #0xec0]
    // 0x69db3c: r2 = Null
    //     0x69db3c: mov             x2, NULL
    // 0x69db40: r0 = AllocateClosure()
    //     0x69db40: bl              #0x826750  ; AllocateClosureStub
    // 0x69db44: mov             x1, x0
    // 0x69db48: ldur            x0, [fp, #-0xb0]
    // 0x69db4c: ArrayStore: r0[0] = r1  ; List_4
    //     0x69db4c: stur            w1, [x0, #0x17]
    // 0x69db50: r1 = Function '<anonymous closure>':.
    //     0x69db50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ec8] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69db54: ldr             x1, [x1, #0xec8]
    // 0x69db58: r2 = Null
    //     0x69db58: mov             x2, NULL
    // 0x69db5c: r0 = AllocateClosure()
    //     0x69db5c: bl              #0x826750  ; AllocateClosureStub
    // 0x69db60: mov             x1, x0
    // 0x69db64: ldur            x0, [fp, #-0xb0]
    // 0x69db68: StoreField: r0->field_1b = r1
    //     0x69db68: stur            w1, [x0, #0x1b]
    // 0x69db6c: ldur            x3, [fp, #-0x70]
    // 0x69db70: StoreField: r0->field_57 = r3
    //     0x69db70: stur            w3, [x0, #0x57]
    // 0x69db74: ldur            x1, [fp, #-0xa8]
    // 0x69db78: StoreField: r0->field_53 = r1
    //     0x69db78: stur            w1, [x0, #0x53]
    // 0x69db7c: ldur            x2, [fp, #-0x18]
    // 0x69db80: r1 = Function '<anonymous closure>':.
    //     0x69db80: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ed0] AnonymousClosure: (0x69e6d0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69db84: ldr             x1, [x1, #0xed0]
    // 0x69db88: r0 = AllocateClosure()
    //     0x69db88: bl              #0x826750  ; AllocateClosureStub
    // 0x69db8c: mov             x1, x0
    // 0x69db90: ldur            x0, [fp, #-0xb0]
    // 0x69db94: StoreField: r0->field_5f = r1
    //     0x69db94: stur            w1, [x0, #0x5f]
    // 0x69db98: ldur            x2, [fp, #-0x18]
    // 0x69db9c: r1 = Function '<anonymous closure>':.
    //     0x69db9c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ed8] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69dba0: ldr             x1, [x1, #0xed8]
    // 0x69dba4: r0 = AllocateClosure()
    //     0x69dba4: bl              #0x826750  ; AllocateClosureStub
    // 0x69dba8: mov             x1, x0
    // 0x69dbac: ldur            x0, [fp, #-0xb0]
    // 0x69dbb0: StoreField: r0->field_6b = r1
    //     0x69dbb0: stur            w1, [x0, #0x6b]
    // 0x69dbb4: ldur            x1, [fp, #-0x90]
    // 0x69dbb8: StoreField: r0->field_4b = r1
    //     0x69dbb8: stur            w1, [x0, #0x4b]
    // 0x69dbbc: ldur            x1, [fp, #-0x20]
    // 0x69dbc0: StoreField: r0->field_f = r1
    //     0x69dbc0: stur            w1, [x0, #0xf]
    // 0x69dbc4: ldur            x1, [fp, #-0xa0]
    // 0x69dbc8: StoreField: r0->field_67 = r1
    //     0x69dbc8: stur            w1, [x0, #0x67]
    // 0x69dbcc: ldur            x3, [fp, #-0x10]
    // 0x69dbd0: StoreField: r0->field_77 = r3
    //     0x69dbd0: stur            w3, [x0, #0x77]
    // 0x69dbd4: ldur            x4, [fp, #-0x38]
    // 0x69dbd8: StoreField: r0->field_7b = r4
    //     0x69dbd8: stur            w4, [x0, #0x7b]
    // 0x69dbdc: r1 = "Chapter 13 Dev Analytics 1"
    //     0x69dbdc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ee0] "Chapter 13 Dev Analytics 1"
    //     0x69dbe0: ldr             x1, [x1, #0xee0]
    // 0x69dbe4: StoreField: r0->field_73 = r1
    //     0x69dbe4: stur            w1, [x0, #0x73]
    // 0x69dbe8: ldur            x2, [fp, #-0x18]
    // 0x69dbec: r1 = Function '<anonymous closure>':.
    //     0x69dbec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ee8] AnonymousClosure: (0x69e648), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69dbf0: ldr             x1, [x1, #0xee8]
    // 0x69dbf4: r0 = AllocateClosure()
    //     0x69dbf4: bl              #0x826750  ; AllocateClosureStub
    // 0x69dbf8: ldur            x2, [fp, #-0xb0]
    // 0x69dbfc: mov             x5, x0
    // 0x69dc00: r1 = Null
    //     0x69dc00: mov             x1, NULL
    // 0x69dc04: r3 = "Chapter 13 Analytics Generators"
    //     0x69dc04: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ef0] "Chapter 13 Analytics Generators"
    //     0x69dc08: ldr             x3, [x3, #0xef0]
    // 0x69dc0c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69dc0c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69dc10: r0 = IdleFragment()
    //     0x69dc10: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69dc14: ldur            x1, [fp, #-0x30]
    // 0x69dc18: ArrayStore: r1[11] = r0  ; List_4
    //     0x69dc18: add             x25, x1, #0x3b
    //     0x69dc1c: str             w0, [x25]
    //     0x69dc20: tbz             w0, #0, #0x69dc3c
    //     0x69dc24: ldurb           w16, [x1, #-1]
    //     0x69dc28: ldurb           w17, [x0, #-1]
    //     0x69dc2c: and             x16, x17, x16, lsr #2
    //     0x69dc30: tst             x16, HEAP, lsr #32
    //     0x69dc34: b.eq            #0x69dc3c
    //     0x69dc38: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69dc3c: r0 = CurrencyCounter()
    //     0x69dc3c: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69dc40: mov             x3, x0
    // 0x69dc44: r0 = "ML"
    //     0x69dc44: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ef8] "ML"
    //     0x69dc48: ldr             x0, [x0, #0xef8]
    // 0x69dc4c: stur            x3, [fp, #-0x20]
    // 0x69dc50: StoreField: r3->field_b = r0
    //     0x69dc50: stur            w0, [x3, #0xb]
    // 0x69dc54: ldur            x2, [fp, #-0x18]
    // 0x69dc58: r1 = Function '<anonymous closure>':.
    //     0x69dc58: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f00] AnonymousClosure: (0x69e5a0), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69dc5c: ldr             x1, [x1, #0xf00]
    // 0x69dc60: r0 = AllocateClosure()
    //     0x69dc60: bl              #0x826750  ; AllocateClosureStub
    // 0x69dc64: mov             x1, x0
    // 0x69dc68: ldur            x0, [fp, #-0x20]
    // 0x69dc6c: StoreField: r0->field_f = r1
    //     0x69dc6c: stur            w1, [x0, #0xf]
    // 0x69dc70: r3 = false
    //     0x69dc70: add             x3, NULL, #0x30  ; false
    // 0x69dc74: StoreField: r0->field_1f = r3
    //     0x69dc74: stur            w3, [x0, #0x1f]
    // 0x69dc78: ldur            x4, [fp, #-8]
    // 0x69dc7c: LoadField: r5 = r4->field_2b
    //     0x69dc7c: ldur            w5, [x4, #0x2b]
    // 0x69dc80: DecompressPointer r5
    //     0x69dc80: add             x5, x5, HEAP, lsl #32
    // 0x69dc84: stur            x5, [fp, #-0xa0]
    // 0x69dc88: LoadField: r6 = r4->field_37
    //     0x69dc88: ldur            w6, [x4, #0x37]
    // 0x69dc8c: DecompressPointer r6
    //     0x69dc8c: add             x6, x6, HEAP, lsl #32
    // 0x69dc90: stur            x6, [fp, #-0x90]
    // 0x69dc94: LoadField: r7 = r4->field_4b
    //     0x69dc94: ldur            w7, [x4, #0x4b]
    // 0x69dc98: DecompressPointer r7
    //     0x69dc98: add             x7, x7, HEAP, lsl #32
    // 0x69dc9c: stur            x7, [fp, #-0x88]
    // 0x69dca0: LoadField: r8 = r4->field_47
    //     0x69dca0: ldur            w8, [x4, #0x47]
    // 0x69dca4: DecompressPointer r8
    //     0x69dca4: add             x8, x8, HEAP, lsl #32
    // 0x69dca8: stur            x8, [fp, #-0x78]
    // 0x69dcac: LoadField: r9 = r4->field_53
    //     0x69dcac: ldur            w9, [x4, #0x53]
    // 0x69dcb0: DecompressPointer r9
    //     0x69dcb0: add             x9, x9, HEAP, lsl #32
    // 0x69dcb4: stur            x9, [fp, #-0x40]
    // 0x69dcb8: LoadField: r1 = r4->field_8b
    //     0x69dcb8: ldur            x1, [x4, #0x8b]
    // 0x69dcbc: cmp             x1, #0xa
    // 0x69dcc0: b.gt            #0x69dce8
    // 0x69dcc4: mov             x2, x4
    // 0x69dcc8: mov             x3, x5
    // 0x69dccc: mov             x4, x6
    // 0x69dcd0: mov             x5, x7
    // 0x69dcd4: mov             x6, x8
    // 0x69dcd8: mov             x7, x9
    // 0x69dcdc: r20 = const [0x47]
    //     0x69dcdc: add             x20, PP, #0x28, lsl #12  ; [pp+0x28f08] List<int>(1)
    //     0x69dce0: ldr             x20, [x20, #0xf08]
    // 0x69dce4: b               #0x69dd88
    // 0x69dce8: LoadField: r1 = r4->field_3f
    //     0x69dce8: ldur            w1, [x4, #0x3f]
    // 0x69dcec: DecompressPointer r1
    //     0x69dcec: add             x1, x1, HEAP, lsl #32
    // 0x69dcf0: LoadField: r10 = r1->field_b
    //     0x69dcf0: ldur            w10, [x1, #0xb]
    // 0x69dcf4: DecompressPointer r10
    //     0x69dcf4: add             x10, x10, HEAP, lsl #32
    // 0x69dcf8: mov             x1, x10
    // 0x69dcfc: stur            x10, [fp, #-0x28]
    // 0x69dd00: r2 = 2
    //     0x69dd00: movz            x2, #0x2
    // 0x69dd04: r0 = _getValueOrData()
    //     0x69dd04: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69dd08: mov             x1, x0
    // 0x69dd0c: ldur            x0, [fp, #-0x28]
    // 0x69dd10: LoadField: r2 = r0->field_f
    //     0x69dd10: ldur            w2, [x0, #0xf]
    // 0x69dd14: DecompressPointer r2
    //     0x69dd14: add             x2, x2, HEAP, lsl #32
    // 0x69dd18: cmp             w2, w1
    // 0x69dd1c: b.ne            #0x69dd28
    // 0x69dd20: r0 = Null
    //     0x69dd20: mov             x0, NULL
    // 0x69dd24: b               #0x69dd2c
    // 0x69dd28: mov             x0, x1
    // 0x69dd2c: cmp             w0, NULL
    // 0x69dd30: b.ne            #0x69dd3c
    // 0x69dd34: r0 = 0
    //     0x69dd34: movz            x0, #0
    // 0x69dd38: b               #0x69dd4c
    // 0x69dd3c: r1 = LoadInt32Instr(r0)
    //     0x69dd3c: sbfx            x1, x0, #1, #0x1f
    //     0x69dd40: tbz             w0, #0, #0x69dd48
    //     0x69dd44: ldur            x1, [x0, #7]
    // 0x69dd48: mov             x0, x1
    // 0x69dd4c: cmp             x0, #0xb
    // 0x69dd50: b.le            #0x69dd60
    // 0x69dd54: r0 = const [0x47, 0x48, 0x49]
    //     0x69dd54: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f10] List<int>(3)
    //     0x69dd58: ldr             x0, [x0, #0xf10]
    // 0x69dd5c: b               #0x69dd68
    // 0x69dd60: r0 = const [0x47, 0x48]
    //     0x69dd60: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f18] List<int>(2)
    //     0x69dd64: ldr             x0, [x0, #0xf18]
    // 0x69dd68: mov             x20, x0
    // 0x69dd6c: ldur            x2, [fp, #-8]
    // 0x69dd70: ldur            x0, [fp, #-0x20]
    // 0x69dd74: ldur            x3, [fp, #-0xa0]
    // 0x69dd78: ldur            x4, [fp, #-0x90]
    // 0x69dd7c: ldur            x5, [fp, #-0x88]
    // 0x69dd80: ldur            x6, [fp, #-0x78]
    // 0x69dd84: ldur            x7, [fp, #-0x40]
    // 0x69dd88: ldur            x11, [fp, #-0x60]
    // 0x69dd8c: ldur            x12, [fp, #-0x58]
    // 0x69dd90: ldur            x10, [fp, #-0x70]
    // 0x69dd94: ldur            x8, [fp, #-0x10]
    // 0x69dd98: ldur            x9, [fp, #-0x38]
    // 0x69dd9c: ldur            x14, [fp, #-0x80]
    // 0x69dda0: ldur            x19, [fp, #-0x98]
    // 0x69dda4: ldur            x13, [fp, #-0x68]
    // 0x69dda8: stur            x20, [fp, #-0xa8]
    // 0x69ddac: LoadField: r23 = r2->field_7b
    //     0x69ddac: ldur            w23, [x2, #0x7b]
    // 0x69ddb0: DecompressPointer r23
    //     0x69ddb0: add             x23, x23, HEAP, lsl #32
    // 0x69ddb4: stur            x23, [fp, #-0x28]
    // 0x69ddb8: r1 = <Chapter13Stat>
    //     0x69ddb8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69ddbc: ldr             x1, [x1, #0xf28]
    // 0x69ddc0: r0 = GeneratorGroup()
    //     0x69ddc0: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69ddc4: mov             x3, x0
    // 0x69ddc8: ldur            x0, [fp, #-0x90]
    // 0x69ddcc: stur            x3, [fp, #-0xb0]
    // 0x69ddd0: StoreField: r3->field_1f = r0
    //     0x69ddd0: stur            w0, [x3, #0x1f]
    // 0x69ddd4: ldur            x0, [fp, #-0x80]
    // 0x69ddd8: StoreField: r3->field_23 = r0
    //     0x69ddd8: stur            w0, [x3, #0x23]
    // 0x69dddc: ldur            x4, [fp, #-0x98]
    // 0x69dde0: StoreField: r3->field_27 = r4
    //     0x69dde0: stur            w4, [x3, #0x27]
    // 0x69dde4: ldur            x1, [fp, #-0x88]
    // 0x69dde8: StoreField: r3->field_2b = r1
    //     0x69dde8: stur            w1, [x3, #0x2b]
    // 0x69ddec: ldur            x1, [fp, #-0x78]
    // 0x69ddf0: StoreField: r3->field_2f = r1
    //     0x69ddf0: stur            w1, [x3, #0x2f]
    // 0x69ddf4: ldur            x1, [fp, #-0x40]
    // 0x69ddf8: StoreField: r3->field_33 = r1
    //     0x69ddf8: stur            w1, [x3, #0x33]
    // 0x69ddfc: r1 = Function '<anonymous closure>':.
    //     0x69ddfc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f20] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69de00: ldr             x1, [x1, #0xf20]
    // 0x69de04: r2 = Null
    //     0x69de04: mov             x2, NULL
    // 0x69de08: r0 = AllocateClosure()
    //     0x69de08: bl              #0x826750  ; AllocateClosureStub
    // 0x69de0c: mov             x1, x0
    // 0x69de10: ldur            x0, [fp, #-0xb0]
    // 0x69de14: StoreField: r0->field_3b = r1
    //     0x69de14: stur            w1, [x0, #0x3b]
    // 0x69de18: ldur            x3, [fp, #-0x60]
    // 0x69de1c: StoreField: r0->field_43 = r3
    //     0x69de1c: stur            w3, [x0, #0x43]
    // 0x69de20: ldur            x4, [fp, #-0x58]
    // 0x69de24: StoreField: r0->field_47 = r4
    //     0x69de24: stur            w4, [x0, #0x47]
    // 0x69de28: ldur            x5, [fp, #-0x68]
    // 0x69de2c: StoreField: r0->field_5b = r5
    //     0x69de2c: stur            w5, [x0, #0x5b]
    // 0x69de30: r1 = Function '<anonymous closure>':.
    //     0x69de30: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f28] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69de34: ldr             x1, [x1, #0xf28]
    // 0x69de38: r2 = Null
    //     0x69de38: mov             x2, NULL
    // 0x69de3c: r0 = AllocateClosure()
    //     0x69de3c: bl              #0x826750  ; AllocateClosureStub
    // 0x69de40: mov             x1, x0
    // 0x69de44: ldur            x0, [fp, #-0xb0]
    // 0x69de48: ArrayStore: r0[0] = r1  ; List_4
    //     0x69de48: stur            w1, [x0, #0x17]
    // 0x69de4c: r1 = Function '<anonymous closure>':.
    //     0x69de4c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f30] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69de50: ldr             x1, [x1, #0xf30]
    // 0x69de54: r2 = Null
    //     0x69de54: mov             x2, NULL
    // 0x69de58: r0 = AllocateClosure()
    //     0x69de58: bl              #0x826750  ; AllocateClosureStub
    // 0x69de5c: mov             x1, x0
    // 0x69de60: ldur            x0, [fp, #-0xb0]
    // 0x69de64: StoreField: r0->field_1b = r1
    //     0x69de64: stur            w1, [x0, #0x1b]
    // 0x69de68: ldur            x3, [fp, #-0x70]
    // 0x69de6c: StoreField: r0->field_57 = r3
    //     0x69de6c: stur            w3, [x0, #0x57]
    // 0x69de70: ldur            x1, [fp, #-0xa8]
    // 0x69de74: StoreField: r0->field_53 = r1
    //     0x69de74: stur            w1, [x0, #0x53]
    // 0x69de78: ldur            x2, [fp, #-0x18]
    // 0x69de7c: r1 = Function '<anonymous closure>':.
    //     0x69de7c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f38] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69de80: ldr             x1, [x1, #0xf38]
    // 0x69de84: r0 = AllocateClosure()
    //     0x69de84: bl              #0x826750  ; AllocateClosureStub
    // 0x69de88: mov             x1, x0
    // 0x69de8c: ldur            x0, [fp, #-0xb0]
    // 0x69de90: StoreField: r0->field_6b = r1
    //     0x69de90: stur            w1, [x0, #0x6b]
    // 0x69de94: ldur            x1, [fp, #-0xa0]
    // 0x69de98: StoreField: r0->field_4b = r1
    //     0x69de98: stur            w1, [x0, #0x4b]
    // 0x69de9c: ldur            x1, [fp, #-0x20]
    // 0x69dea0: StoreField: r0->field_f = r1
    //     0x69dea0: stur            w1, [x0, #0xf]
    // 0x69dea4: ldur            x1, [fp, #-0x28]
    // 0x69dea8: StoreField: r0->field_67 = r1
    //     0x69dea8: stur            w1, [x0, #0x67]
    // 0x69deac: ldur            x3, [fp, #-0x10]
    // 0x69deb0: StoreField: r0->field_77 = r3
    //     0x69deb0: stur            w3, [x0, #0x77]
    // 0x69deb4: ldur            x4, [fp, #-0x38]
    // 0x69deb8: StoreField: r0->field_7b = r4
    //     0x69deb8: stur            w4, [x0, #0x7b]
    // 0x69debc: r5 = "Chapter 13 ML"
    //     0x69debc: add             x5, PP, #0x28, lsl #12  ; [pp+0x28f40] "Chapter 13 ML"
    //     0x69dec0: ldr             x5, [x5, #0xf40]
    // 0x69dec4: StoreField: r0->field_73 = r5
    //     0x69dec4: stur            w5, [x0, #0x73]
    // 0x69dec8: ldur            x2, [fp, #-0x18]
    // 0x69decc: r1 = Function '<anonymous closure>':.
    //     0x69decc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f48] AnonymousClosure: (0x69e574), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69ded0: ldr             x1, [x1, #0xf48]
    // 0x69ded4: r0 = AllocateClosure()
    //     0x69ded4: bl              #0x826750  ; AllocateClosureStub
    // 0x69ded8: ldur            x2, [fp, #-0xb0]
    // 0x69dedc: mov             x5, x0
    // 0x69dee0: r1 = Null
    //     0x69dee0: mov             x1, NULL
    // 0x69dee4: r3 = "Chapter 13 ML"
    //     0x69dee4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28f40] "Chapter 13 ML"
    //     0x69dee8: ldr             x3, [x3, #0xf40]
    // 0x69deec: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69deec: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69def0: r0 = IdleFragment()
    //     0x69def0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69def4: ldur            x1, [fp, #-0x30]
    // 0x69def8: ArrayStore: r1[12] = r0  ; List_4
    //     0x69def8: add             x25, x1, #0x3f
    //     0x69defc: str             w0, [x25]
    //     0x69df00: tbz             w0, #0, #0x69df1c
    //     0x69df04: ldurb           w16, [x1, #-1]
    //     0x69df08: ldurb           w17, [x0, #-1]
    //     0x69df0c: and             x16, x17, x16, lsr #2
    //     0x69df10: tst             x16, HEAP, lsr #32
    //     0x69df14: b.eq            #0x69df1c
    //     0x69df18: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69df1c: r0 = CurrencyCounter()
    //     0x69df1c: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69df20: mov             x3, x0
    // 0x69df24: r0 = "Integration"
    //     0x69df24: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b50] "Integration"
    //     0x69df28: ldr             x0, [x0, #0xb50]
    // 0x69df2c: stur            x3, [fp, #-0x20]
    // 0x69df30: StoreField: r3->field_b = r0
    //     0x69df30: stur            w0, [x3, #0xb]
    // 0x69df34: ldur            x2, [fp, #-0x18]
    // 0x69df38: r1 = Function '<anonymous closure>':.
    //     0x69df38: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f50] AnonymousClosure: (0x69e4cc), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69df3c: ldr             x1, [x1, #0xf50]
    // 0x69df40: r0 = AllocateClosure()
    //     0x69df40: bl              #0x826750  ; AllocateClosureStub
    // 0x69df44: mov             x1, x0
    // 0x69df48: ldur            x0, [fp, #-0x20]
    // 0x69df4c: StoreField: r0->field_f = r1
    //     0x69df4c: stur            w1, [x0, #0xf]
    // 0x69df50: r1 = false
    //     0x69df50: add             x1, NULL, #0x30  ; false
    // 0x69df54: StoreField: r0->field_1f = r1
    //     0x69df54: stur            w1, [x0, #0x1f]
    // 0x69df58: ldur            x3, [fp, #-8]
    // 0x69df5c: LoadField: r4 = r3->field_2b
    //     0x69df5c: ldur            w4, [x3, #0x2b]
    // 0x69df60: DecompressPointer r4
    //     0x69df60: add             x4, x4, HEAP, lsl #32
    // 0x69df64: stur            x4, [fp, #-0xa0]
    // 0x69df68: LoadField: r5 = r3->field_37
    //     0x69df68: ldur            w5, [x3, #0x37]
    // 0x69df6c: DecompressPointer r5
    //     0x69df6c: add             x5, x5, HEAP, lsl #32
    // 0x69df70: stur            x5, [fp, #-0x90]
    // 0x69df74: LoadField: r6 = r3->field_4b
    //     0x69df74: ldur            w6, [x3, #0x4b]
    // 0x69df78: DecompressPointer r6
    //     0x69df78: add             x6, x6, HEAP, lsl #32
    // 0x69df7c: stur            x6, [fp, #-0x88]
    // 0x69df80: LoadField: r7 = r3->field_47
    //     0x69df80: ldur            w7, [x3, #0x47]
    // 0x69df84: DecompressPointer r7
    //     0x69df84: add             x7, x7, HEAP, lsl #32
    // 0x69df88: stur            x7, [fp, #-0x78]
    // 0x69df8c: LoadField: r8 = r3->field_53
    //     0x69df8c: ldur            w8, [x3, #0x53]
    // 0x69df90: DecompressPointer r8
    //     0x69df90: add             x8, x8, HEAP, lsl #32
    // 0x69df94: stur            x8, [fp, #-0x40]
    // 0x69df98: LoadField: r1 = r3->field_8b
    //     0x69df98: ldur            x1, [x3, #0x8b]
    // 0x69df9c: cmp             x1, #0xb
    // 0x69dfa0: b.gt            #0x69dfc8
    // 0x69dfa4: mov             x2, x3
    // 0x69dfa8: mov             x3, x4
    // 0x69dfac: mov             x4, x5
    // 0x69dfb0: mov             x5, x6
    // 0x69dfb4: mov             x6, x7
    // 0x69dfb8: mov             x7, x8
    // 0x69dfbc: r23 = const [0x51]
    //     0x69dfbc: add             x23, PP, #0x28, lsl #12  ; [pp+0x28f58] List<int>(1)
    //     0x69dfc0: ldr             x23, [x23, #0xf58]
    // 0x69dfc4: b               #0x69e068
    // 0x69dfc8: LoadField: r1 = r3->field_3f
    //     0x69dfc8: ldur            w1, [x3, #0x3f]
    // 0x69dfcc: DecompressPointer r1
    //     0x69dfcc: add             x1, x1, HEAP, lsl #32
    // 0x69dfd0: LoadField: r9 = r1->field_b
    //     0x69dfd0: ldur            w9, [x1, #0xb]
    // 0x69dfd4: DecompressPointer r9
    //     0x69dfd4: add             x9, x9, HEAP, lsl #32
    // 0x69dfd8: mov             x1, x9
    // 0x69dfdc: stur            x9, [fp, #-0x28]
    // 0x69dfe0: r2 = 4
    //     0x69dfe0: movz            x2, #0x4
    // 0x69dfe4: r0 = _getValueOrData()
    //     0x69dfe4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69dfe8: mov             x1, x0
    // 0x69dfec: ldur            x0, [fp, #-0x28]
    // 0x69dff0: LoadField: r2 = r0->field_f
    //     0x69dff0: ldur            w2, [x0, #0xf]
    // 0x69dff4: DecompressPointer r2
    //     0x69dff4: add             x2, x2, HEAP, lsl #32
    // 0x69dff8: cmp             w2, w1
    // 0x69dffc: b.ne            #0x69e008
    // 0x69e000: r0 = Null
    //     0x69e000: mov             x0, NULL
    // 0x69e004: b               #0x69e00c
    // 0x69e008: mov             x0, x1
    // 0x69e00c: cmp             w0, NULL
    // 0x69e010: b.ne            #0x69e01c
    // 0x69e014: r0 = 0
    //     0x69e014: movz            x0, #0
    // 0x69e018: b               #0x69e02c
    // 0x69e01c: r1 = LoadInt32Instr(r0)
    //     0x69e01c: sbfx            x1, x0, #1, #0x1f
    //     0x69e020: tbz             w0, #0, #0x69e028
    //     0x69e024: ldur            x1, [x0, #7]
    // 0x69e028: mov             x0, x1
    // 0x69e02c: cmp             x0, #7
    // 0x69e030: b.le            #0x69e040
    // 0x69e034: r0 = const [0x51, 0x52, 0x53]
    //     0x69e034: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f60] List<int>(3)
    //     0x69e038: ldr             x0, [x0, #0xf60]
    // 0x69e03c: b               #0x69e048
    // 0x69e040: r0 = const [0x51, 0x52]
    //     0x69e040: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f68] List<int>(2)
    //     0x69e044: ldr             x0, [x0, #0xf68]
    // 0x69e048: mov             x23, x0
    // 0x69e04c: ldur            x2, [fp, #-8]
    // 0x69e050: ldur            x0, [fp, #-0x20]
    // 0x69e054: ldur            x3, [fp, #-0xa0]
    // 0x69e058: ldur            x4, [fp, #-0x90]
    // 0x69e05c: ldur            x5, [fp, #-0x88]
    // 0x69e060: ldur            x6, [fp, #-0x78]
    // 0x69e064: ldur            x7, [fp, #-0x40]
    // 0x69e068: ldur            x20, [fp, #-0x30]
    // 0x69e06c: ldur            x11, [fp, #-0x60]
    // 0x69e070: ldur            x12, [fp, #-0x58]
    // 0x69e074: ldur            x10, [fp, #-0x70]
    // 0x69e078: ldur            x8, [fp, #-0x10]
    // 0x69e07c: ldur            x9, [fp, #-0x38]
    // 0x69e080: ldur            x14, [fp, #-0x80]
    // 0x69e084: ldur            x19, [fp, #-0x98]
    // 0x69e088: ldur            x13, [fp, #-0x68]
    // 0x69e08c: stur            x23, [fp, #-0xa8]
    // 0x69e090: LoadField: r24 = r2->field_7b
    //     0x69e090: ldur            w24, [x2, #0x7b]
    // 0x69e094: DecompressPointer r24
    //     0x69e094: add             x24, x24, HEAP, lsl #32
    // 0x69e098: stur            x24, [fp, #-0x28]
    // 0x69e09c: r1 = <Chapter13Stat>
    //     0x69e09c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69e0a0: ldr             x1, [x1, #0xf28]
    // 0x69e0a4: r0 = GeneratorGroup()
    //     0x69e0a4: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69e0a8: mov             x3, x0
    // 0x69e0ac: ldur            x0, [fp, #-0x90]
    // 0x69e0b0: stur            x3, [fp, #-0xb0]
    // 0x69e0b4: StoreField: r3->field_1f = r0
    //     0x69e0b4: stur            w0, [x3, #0x1f]
    // 0x69e0b8: ldur            x0, [fp, #-0x80]
    // 0x69e0bc: StoreField: r3->field_23 = r0
    //     0x69e0bc: stur            w0, [x3, #0x23]
    // 0x69e0c0: ldur            x0, [fp, #-0x98]
    // 0x69e0c4: StoreField: r3->field_27 = r0
    //     0x69e0c4: stur            w0, [x3, #0x27]
    // 0x69e0c8: ldur            x0, [fp, #-0x88]
    // 0x69e0cc: StoreField: r3->field_2b = r0
    //     0x69e0cc: stur            w0, [x3, #0x2b]
    // 0x69e0d0: ldur            x0, [fp, #-0x78]
    // 0x69e0d4: StoreField: r3->field_2f = r0
    //     0x69e0d4: stur            w0, [x3, #0x2f]
    // 0x69e0d8: ldur            x0, [fp, #-0x40]
    // 0x69e0dc: StoreField: r3->field_33 = r0
    //     0x69e0dc: stur            w0, [x3, #0x33]
    // 0x69e0e0: r1 = Function '<anonymous closure>':.
    //     0x69e0e0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f70] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x69e0e4: ldr             x1, [x1, #0xf70]
    // 0x69e0e8: r2 = Null
    //     0x69e0e8: mov             x2, NULL
    // 0x69e0ec: r0 = AllocateClosure()
    //     0x69e0ec: bl              #0x826750  ; AllocateClosureStub
    // 0x69e0f0: mov             x1, x0
    // 0x69e0f4: ldur            x0, [fp, #-0xb0]
    // 0x69e0f8: StoreField: r0->field_3b = r1
    //     0x69e0f8: stur            w1, [x0, #0x3b]
    // 0x69e0fc: ldur            x1, [fp, #-0x60]
    // 0x69e100: StoreField: r0->field_43 = r1
    //     0x69e100: stur            w1, [x0, #0x43]
    // 0x69e104: ldur            x1, [fp, #-0x58]
    // 0x69e108: StoreField: r0->field_47 = r1
    //     0x69e108: stur            w1, [x0, #0x47]
    // 0x69e10c: ldur            x1, [fp, #-0x68]
    // 0x69e110: StoreField: r0->field_5b = r1
    //     0x69e110: stur            w1, [x0, #0x5b]
    // 0x69e114: r1 = Function '<anonymous closure>':.
    //     0x69e114: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f78] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69e118: ldr             x1, [x1, #0xf78]
    // 0x69e11c: r2 = Null
    //     0x69e11c: mov             x2, NULL
    // 0x69e120: r0 = AllocateClosure()
    //     0x69e120: bl              #0x826750  ; AllocateClosureStub
    // 0x69e124: mov             x1, x0
    // 0x69e128: ldur            x0, [fp, #-0xb0]
    // 0x69e12c: ArrayStore: r0[0] = r1  ; List_4
    //     0x69e12c: stur            w1, [x0, #0x17]
    // 0x69e130: r1 = Function '<anonymous closure>':.
    //     0x69e130: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f80] AnonymousClosure: (0x46cc5c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState (0x46c900)
    //     0x69e134: ldr             x1, [x1, #0xf80]
    // 0x69e138: r2 = Null
    //     0x69e138: mov             x2, NULL
    // 0x69e13c: r0 = AllocateClosure()
    //     0x69e13c: bl              #0x826750  ; AllocateClosureStub
    // 0x69e140: mov             x1, x0
    // 0x69e144: ldur            x0, [fp, #-0xb0]
    // 0x69e148: StoreField: r0->field_1b = r1
    //     0x69e148: stur            w1, [x0, #0x1b]
    // 0x69e14c: ldur            x1, [fp, #-0x70]
    // 0x69e150: StoreField: r0->field_57 = r1
    //     0x69e150: stur            w1, [x0, #0x57]
    // 0x69e154: ldur            x1, [fp, #-0xa8]
    // 0x69e158: StoreField: r0->field_53 = r1
    //     0x69e158: stur            w1, [x0, #0x53]
    // 0x69e15c: ldur            x2, [fp, #-0x18]
    // 0x69e160: r1 = Function '<anonymous closure>':.
    //     0x69e160: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f88] AnonymousClosure: (0x69e454), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69e164: ldr             x1, [x1, #0xf88]
    // 0x69e168: r0 = AllocateClosure()
    //     0x69e168: bl              #0x826750  ; AllocateClosureStub
    // 0x69e16c: mov             x1, x0
    // 0x69e170: ldur            x0, [fp, #-0xb0]
    // 0x69e174: StoreField: r0->field_6b = r1
    //     0x69e174: stur            w1, [x0, #0x6b]
    // 0x69e178: ldur            x1, [fp, #-0xa0]
    // 0x69e17c: StoreField: r0->field_4b = r1
    //     0x69e17c: stur            w1, [x0, #0x4b]
    // 0x69e180: ldur            x1, [fp, #-0x20]
    // 0x69e184: StoreField: r0->field_f = r1
    //     0x69e184: stur            w1, [x0, #0xf]
    // 0x69e188: ldur            x1, [fp, #-0x28]
    // 0x69e18c: StoreField: r0->field_67 = r1
    //     0x69e18c: stur            w1, [x0, #0x67]
    // 0x69e190: ldur            x1, [fp, #-0x10]
    // 0x69e194: StoreField: r0->field_77 = r1
    //     0x69e194: stur            w1, [x0, #0x77]
    // 0x69e198: ldur            x1, [fp, #-0x38]
    // 0x69e19c: StoreField: r0->field_7b = r1
    //     0x69e19c: stur            w1, [x0, #0x7b]
    // 0x69e1a0: r3 = "Chapter 13 Integration"
    //     0x69e1a0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28f90] "Chapter 13 Integration"
    //     0x69e1a4: ldr             x3, [x3, #0xf90]
    // 0x69e1a8: StoreField: r0->field_73 = r3
    //     0x69e1a8: stur            w3, [x0, #0x73]
    // 0x69e1ac: ldur            x2, [fp, #-0x18]
    // 0x69e1b0: r1 = Function '<anonymous closure>':.
    //     0x69e1b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f98] AnonymousClosure: (0x69e3b4), in [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::build (0x6b6238)
    //     0x69e1b4: ldr             x1, [x1, #0xf98]
    // 0x69e1b8: r0 = AllocateClosure()
    //     0x69e1b8: bl              #0x826750  ; AllocateClosureStub
    // 0x69e1bc: ldur            x2, [fp, #-0xb0]
    // 0x69e1c0: mov             x5, x0
    // 0x69e1c4: r1 = Null
    //     0x69e1c4: mov             x1, NULL
    // 0x69e1c8: r3 = "Chapter 13 Integration"
    //     0x69e1c8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28f90] "Chapter 13 Integration"
    //     0x69e1cc: ldr             x3, [x3, #0xf90]
    // 0x69e1d0: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69e1d0: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69e1d4: r0 = IdleFragment()
    //     0x69e1d4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69e1d8: ldur            x1, [fp, #-0x30]
    // 0x69e1dc: ArrayStore: r1[13] = r0  ; List_4
    //     0x69e1dc: add             x25, x1, #0x43
    //     0x69e1e0: str             w0, [x25]
    //     0x69e1e4: tbz             w0, #0, #0x69e200
    //     0x69e1e8: ldurb           w16, [x1, #-1]
    //     0x69e1ec: ldurb           w17, [x0, #-1]
    //     0x69e1f0: and             x16, x17, x16, lsr #2
    //     0x69e1f4: tst             x16, HEAP, lsr #32
    //     0x69e1f8: b.eq            #0x69e200
    //     0x69e1fc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69e200: ldur            x0, [fp, #-8]
    // 0x69e204: LoadField: r2 = r0->field_37
    //     0x69e204: ldur            w2, [x0, #0x37]
    // 0x69e208: DecompressPointer r2
    //     0x69e208: add             x2, x2, HEAP, lsl #32
    // 0x69e20c: stur            x2, [fp, #-0x10]
    // 0x69e210: r1 = <Chapter13Stat>
    //     0x69e210: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x69e214: ldr             x1, [x1, #0xf28]
    // 0x69e218: r0 = CompleteChapterButtons()
    //     0x69e218: bl              #0x697edc  ; AllocateCompleteChapterButtonsStub -> CompleteChapterButtons<X0> (size=0x24)
    // 0x69e21c: mov             x3, x0
    // 0x69e220: ldur            x0, [fp, #-0x10]
    // 0x69e224: stur            x3, [fp, #-8]
    // 0x69e228: StoreField: r3->field_f = r0
    //     0x69e228: stur            w0, [x3, #0xf]
    // 0x69e22c: r0 = Instance_Tuple2
    //     0x69e22c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28fa0] Obj!Tuple2<Chapter13Stat, CustomNum>@826751
    //     0x69e230: ldr             x0, [x0, #0xfa0]
    // 0x69e234: StoreField: r3->field_13 = r0
    //     0x69e234: stur            w0, [x3, #0x13]
    // 0x69e238: ldur            x2, [fp, #-0x18]
    // 0x69e23c: r1 = Function '<anonymous closure>':.
    //     0x69e23c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28fa8] AnonymousClosure: (0x69e400), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69e240: ldr             x1, [x1, #0xfa8]
    // 0x69e244: r0 = AllocateClosure()
    //     0x69e244: bl              #0x826750  ; AllocateClosureStub
    // 0x69e248: mov             x1, x0
    // 0x69e24c: ldur            x0, [fp, #-8]
    // 0x69e250: ArrayStore: r0[0] = r1  ; List_4
    //     0x69e250: stur            w1, [x0, #0x17]
    // 0x69e254: r1 = Closure: (Chapter13Stat?) => String from Function 'humanName': static.
    //     0x69e254: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba8] Closure: (Chapter13Stat?) => String from Function 'humanName': static. (0x248ed99cc5c)
    //     0x69e258: ldr             x1, [x1, #0xba8]
    // 0x69e25c: StoreField: r0->field_1f = r1
    //     0x69e25c: stur            w1, [x0, #0x1f]
    // 0x69e260: r1 = Instance_ChapterCompleteButtonType
    //     0x69e260: add             x1, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!ChapterCompleteButtonType@85ea61
    //     0x69e264: ldr             x1, [x1, #0x330]
    // 0x69e268: StoreField: r0->field_1b = r1
    //     0x69e268: stur            w1, [x0, #0x1b]
    // 0x69e26c: r1 = Null
    //     0x69e26c: mov             x1, NULL
    // 0x69e270: r2 = 2
    //     0x69e270: movz            x2, #0x2
    // 0x69e274: r0 = AllocateArray()
    //     0x69e274: bl              #0x82746c  ; AllocateArrayStub
    // 0x69e278: mov             x2, x0
    // 0x69e27c: ldur            x0, [fp, #-8]
    // 0x69e280: stur            x2, [fp, #-0x10]
    // 0x69e284: StoreField: r2->field_f = r0
    //     0x69e284: stur            w0, [x2, #0xf]
    // 0x69e288: r1 = <Widget>
    //     0x69e288: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69e28c: r0 = AllocateGrowableArray()
    //     0x69e28c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69e290: mov             x1, x0
    // 0x69e294: ldur            x0, [fp, #-0x10]
    // 0x69e298: stur            x1, [fp, #-8]
    // 0x69e29c: StoreField: r1->field_f = r0
    //     0x69e29c: stur            w0, [x1, #0xf]
    // 0x69e2a0: r0 = 2
    //     0x69e2a0: movz            x0, #0x2
    // 0x69e2a4: StoreField: r1->field_b = r0
    //     0x69e2a4: stur            w0, [x1, #0xb]
    // 0x69e2a8: r0 = Column()
    //     0x69e2a8: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x69e2ac: mov             x3, x0
    // 0x69e2b0: r0 = Instance_Axis
    //     0x69e2b0: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x69e2b4: stur            x3, [fp, #-0x10]
    // 0x69e2b8: StoreField: r3->field_f = r0
    //     0x69e2b8: stur            w0, [x3, #0xf]
    // 0x69e2bc: r0 = Instance_MainAxisAlignment
    //     0x69e2bc: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x69e2c0: ldr             x0, [x0, #0x200]
    // 0x69e2c4: StoreField: r3->field_13 = r0
    //     0x69e2c4: stur            w0, [x3, #0x13]
    // 0x69e2c8: r0 = Instance_MainAxisSize
    //     0x69e2c8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x69e2cc: ldr             x0, [x0, #0x70]
    // 0x69e2d0: ArrayStore: r3[0] = r0  ; List_4
    //     0x69e2d0: stur            w0, [x3, #0x17]
    // 0x69e2d4: r0 = Instance_CrossAxisAlignment
    //     0x69e2d4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x69e2d8: ldr             x0, [x0, #0x78]
    // 0x69e2dc: StoreField: r3->field_1b = r0
    //     0x69e2dc: stur            w0, [x3, #0x1b]
    // 0x69e2e0: r0 = Instance_VerticalDirection
    //     0x69e2e0: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x69e2e4: ldr             x0, [x0, #0x1e8]
    // 0x69e2e8: StoreField: r3->field_23 = r0
    //     0x69e2e8: stur            w0, [x3, #0x23]
    // 0x69e2ec: r0 = Instance_Clip
    //     0x69e2ec: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x69e2f0: ldr             x0, [x0, #0x1b0]
    // 0x69e2f4: StoreField: r3->field_2b = r0
    //     0x69e2f4: stur            w0, [x3, #0x2b]
    // 0x69e2f8: StoreField: r3->field_2f = rZR
    //     0x69e2f8: stur            xzr, [x3, #0x2f]
    // 0x69e2fc: ldur            x0, [fp, #-8]
    // 0x69e300: StoreField: r3->field_b = r0
    //     0x69e300: stur            w0, [x3, #0xb]
    // 0x69e304: ldur            x2, [fp, #-0x18]
    // 0x69e308: r1 = Function '<anonymous closure>':.
    //     0x69e308: add             x1, PP, #0x28, lsl #12  ; [pp+0x28fb0] AnonymousClosure: (0x69e3b4), in [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::build (0x6b6238)
    //     0x69e30c: ldr             x1, [x1, #0xfb0]
    // 0x69e310: r0 = AllocateClosure()
    //     0x69e310: bl              #0x826750  ; AllocateClosureStub
    // 0x69e314: ldur            x2, [fp, #-0x10]
    // 0x69e318: mov             x5, x0
    // 0x69e31c: r1 = Null
    //     0x69e31c: mov             x1, NULL
    // 0x69e320: r3 = "Chapter 13 Complete Chapter"
    //     0x69e320: add             x3, PP, #0x28, lsl #12  ; [pp+0x28fb8] "Chapter 13 Complete Chapter"
    //     0x69e324: ldr             x3, [x3, #0xfb8]
    // 0x69e328: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x69e328: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x69e32c: r0 = IdleFragment()
    //     0x69e32c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69e330: ldur            x1, [fp, #-0x30]
    // 0x69e334: ArrayStore: r1[14] = r0  ; List_4
    //     0x69e334: add             x25, x1, #0x47
    //     0x69e338: str             w0, [x25]
    //     0x69e33c: tbz             w0, #0, #0x69e358
    //     0x69e340: ldurb           w16, [x1, #-1]
    //     0x69e344: ldurb           w17, [x0, #-1]
    //     0x69e348: and             x16, x17, x16, lsr #2
    //     0x69e34c: tst             x16, HEAP, lsr #32
    //     0x69e350: b.eq            #0x69e358
    //     0x69e354: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69e358: r1 = <Widget>
    //     0x69e358: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x69e35c: r0 = AllocateGrowableArray()
    //     0x69e35c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x69e360: ldur            x1, [fp, #-0x30]
    // 0x69e364: StoreField: r0->field_f = r1
    //     0x69e364: stur            w1, [x0, #0xf]
    // 0x69e368: r1 = 30
    //     0x69e368: movz            x1, #0x1e
    // 0x69e36c: StoreField: r0->field_b = r1
    //     0x69e36c: stur            w1, [x0, #0xb]
    // 0x69e370: LeaveFrame
    //     0x69e370: mov             SP, fp
    //     0x69e374: ldp             fp, lr, [SP], #0x10
    // 0x69e378: ret
    //     0x69e378: ret             
    // 0x69e37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e37c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e380: b               #0x69b528
    // 0x69e384: r9 = researchLevels
    //     0x69e384: add             x9, PP, #0x28, lsl #12  ; [pp+0x28fc0] Field <Chapter13GameState.researchLevels>: late (offset: 0xa0)
    //     0x69e388: ldr             x9, [x9, #0xfc0]
    // 0x69e38c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69e38c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x69e390: r9 = allUpgradeData
    //     0x69e390: add             x9, PP, #0x28, lsl #12  ; [pp+0x28fc8] Field <Chapter13GameState.allUpgradeData>: late (offset: 0x98)
    //     0x69e394: ldr             x9, [x9, #0xfc8]
    // 0x69e398: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69e398: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x69e400, size: 0x54
    // 0x69e400: EnterFrame
    //     0x69e400: stp             fp, lr, [SP, #-0x10]!
    //     0x69e404: mov             fp, SP
    // 0x69e408: ldr             x0, [fp, #0x18]
    // 0x69e40c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69e40c: ldur            w1, [x0, #0x17]
    // 0x69e410: DecompressPointer r1
    //     0x69e410: add             x1, x1, HEAP, lsl #32
    // 0x69e414: CheckStackOverflow
    //     0x69e414: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e418: cmp             SP, x16
    //     0x69e41c: b.ls            #0x69e44c
    // 0x69e420: LoadField: r0 = r1->field_f
    //     0x69e420: ldur            w0, [x1, #0xf]
    // 0x69e424: DecompressPointer r0
    //     0x69e424: add             x0, x0, HEAP, lsl #32
    // 0x69e428: LoadField: r2 = r1->field_13
    //     0x69e428: ldur            w2, [x1, #0x13]
    // 0x69e42c: DecompressPointer r2
    //     0x69e42c: add             x2, x2, HEAP, lsl #32
    // 0x69e430: mov             x1, x0
    // 0x69e434: r3 = Instance_Tuple2
    //     0x69e434: add             x3, PP, #0x28, lsl #12  ; [pp+0x28fd0] Obj!Tuple2<int, String>@826731
    //     0x69e438: ldr             x3, [x3, #0xfd0]
    // 0x69e43c: r0 = completeChapter()
    //     0x69e43c: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x69e440: LeaveFrame
    //     0x69e440: mov             SP, fp
    //     0x69e444: ldp             fp, lr, [SP], #0x10
    // 0x69e448: ret
    //     0x69e448: ret             
    // 0x69e44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e44c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e450: b               #0x69e420
  }
  [closure] Map<Chapter13Stat, CustomNum> <anonymous closure>(dynamic, int, num) {
    // ** addr: 0x69e454, size: 0x78
    // 0x69e454: EnterFrame
    //     0x69e454: stp             fp, lr, [SP, #-0x10]!
    //     0x69e458: mov             fp, SP
    // 0x69e45c: AllocStack(0x8)
    //     0x69e45c: sub             SP, SP, #8
    // 0x69e460: SetupParameters([dynamic _ /* r0 */])
    //     0x69e460: ldr             x0, [fp, #0x20]
    //     0x69e464: ldur            w3, [x0, #0x17]
    //     0x69e468: add             x3, x3, HEAP, lsl #32
    //     0x69e46c: stur            x3, [fp, #-8]
    // 0x69e470: CheckStackOverflow
    //     0x69e470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e474: cmp             SP, x16
    //     0x69e478: b.ls            #0x69e4c4
    // 0x69e47c: LoadField: r1 = r3->field_f
    //     0x69e47c: ldur            w1, [x3, #0xf]
    // 0x69e480: DecompressPointer r1
    //     0x69e480: add             x1, x1, HEAP, lsl #32
    // 0x69e484: ldr             x0, [fp, #0x18]
    // 0x69e488: r2 = LoadInt32Instr(r0)
    //     0x69e488: sbfx            x2, x0, #1, #0x1f
    //     0x69e48c: tbz             w0, #0, #0x69e494
    //     0x69e490: ldur            x2, [x0, #7]
    // 0x69e494: r0 = getOnBuyStats()
    //     0x69e494: bl              #0x54fe78  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getOnBuyStats
    // 0x69e498: cmp             w0, NULL
    // 0x69e49c: b.ne            #0x69e4b8
    // 0x69e4a0: ldur            x0, [fp, #-8]
    // 0x69e4a4: LoadField: r1 = r0->field_f
    //     0x69e4a4: ldur            w1, [x0, #0xf]
    // 0x69e4a8: DecompressPointer r1
    //     0x69e4a8: add             x1, x1, HEAP, lsl #32
    // 0x69e4ac: ldr             x2, [fp, #0x18]
    // 0x69e4b0: ldr             x3, [fp, #0x10]
    // 0x69e4b4: r0 = getGeneratorSingleYieldsBoosted()
    //     0x69e4b4: bl              #0x54a520  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted
    // 0x69e4b8: LeaveFrame
    //     0x69e4b8: mov             SP, fp
    //     0x69e4bc: ldp             fp, lr, [SP], #0x10
    // 0x69e4c0: ret
    //     0x69e4c0: ret             
    // 0x69e4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e4c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e4c8: b               #0x69e47c
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69e4cc, size: 0xa8
    // 0x69e4cc: EnterFrame
    //     0x69e4cc: stp             fp, lr, [SP, #-0x10]!
    //     0x69e4d0: mov             fp, SP
    // 0x69e4d4: AllocStack(0x8)
    //     0x69e4d4: sub             SP, SP, #8
    // 0x69e4d8: SetupParameters([dynamic _ /* r0 */])
    //     0x69e4d8: ldr             x0, [fp, #0x10]
    //     0x69e4dc: ldur            w1, [x0, #0x17]
    //     0x69e4e0: add             x1, x1, HEAP, lsl #32
    // 0x69e4e4: CheckStackOverflow
    //     0x69e4e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e4e8: cmp             SP, x16
    //     0x69e4ec: b.ls            #0x69e56c
    // 0x69e4f0: LoadField: r0 = r1->field_f
    //     0x69e4f0: ldur            w0, [x1, #0xf]
    // 0x69e4f4: DecompressPointer r0
    //     0x69e4f4: add             x0, x0, HEAP, lsl #32
    // 0x69e4f8: LoadField: r3 = r0->field_37
    //     0x69e4f8: ldur            w3, [x0, #0x37]
    // 0x69e4fc: DecompressPointer r3
    //     0x69e4fc: add             x3, x3, HEAP, lsl #32
    // 0x69e500: mov             x1, x3
    // 0x69e504: stur            x3, [fp, #-8]
    // 0x69e508: r2 = Instance_Chapter13Stat
    //     0x69e508: add             x2, PP, #0x11, lsl #12  ; [pp+0x11370] Obj!Chapter13Stat@85fa21
    //     0x69e50c: ldr             x2, [x2, #0x370]
    // 0x69e510: r0 = _getValueOrData()
    //     0x69e510: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69e514: mov             x1, x0
    // 0x69e518: ldur            x0, [fp, #-8]
    // 0x69e51c: LoadField: r2 = r0->field_f
    //     0x69e51c: ldur            w2, [x0, #0xf]
    // 0x69e520: DecompressPointer r2
    //     0x69e520: add             x2, x2, HEAP, lsl #32
    // 0x69e524: cmp             w2, w1
    // 0x69e528: b.ne            #0x69e530
    // 0x69e52c: r1 = Null
    //     0x69e52c: mov             x1, NULL
    // 0x69e530: cmp             w1, NULL
    // 0x69e534: b.ne            #0x69e540
    // 0x69e538: r1 = Null
    //     0x69e538: mov             x1, NULL
    // 0x69e53c: b               #0x69e54c
    // 0x69e540: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69e540: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69e544: r0 = toStringConsistentDecimalPlaces()
    //     0x69e544: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69e548: mov             x1, x0
    // 0x69e54c: cmp             w1, NULL
    // 0x69e550: b.ne            #0x69e55c
    // 0x69e554: r0 = "0"
    //     0x69e554: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69e558: b               #0x69e560
    // 0x69e55c: mov             x0, x1
    // 0x69e560: LeaveFrame
    //     0x69e560: mov             SP, fp
    //     0x69e564: ldp             fp, lr, [SP], #0x10
    // 0x69e568: ret
    //     0x69e568: ret             
    // 0x69e56c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e56c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e570: b               #0x69e4f0
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69e574, size: 0x2c
    // 0x69e574: ldr             x1, [SP]
    // 0x69e578: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69e578: ldur            w2, [x1, #0x17]
    // 0x69e57c: DecompressPointer r2
    //     0x69e57c: add             x2, x2, HEAP, lsl #32
    // 0x69e580: LoadField: r1 = r2->field_f
    //     0x69e580: ldur            w1, [x2, #0xf]
    // 0x69e584: DecompressPointer r1
    //     0x69e584: add             x1, x1, HEAP, lsl #32
    // 0x69e588: LoadField: r2 = r1->field_8b
    //     0x69e588: ldur            x2, [x1, #0x8b]
    // 0x69e58c: cmp             x2, #0xa
    // 0x69e590: r16 = true
    //     0x69e590: add             x16, NULL, #0x20  ; true
    // 0x69e594: r17 = false
    //     0x69e594: add             x17, NULL, #0x30  ; false
    // 0x69e598: csel            x0, x16, x17, ge
    // 0x69e59c: ret
    //     0x69e59c: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69e5a0, size: 0xa8
    // 0x69e5a0: EnterFrame
    //     0x69e5a0: stp             fp, lr, [SP, #-0x10]!
    //     0x69e5a4: mov             fp, SP
    // 0x69e5a8: AllocStack(0x8)
    //     0x69e5a8: sub             SP, SP, #8
    // 0x69e5ac: SetupParameters([dynamic _ /* r0 */])
    //     0x69e5ac: ldr             x0, [fp, #0x10]
    //     0x69e5b0: ldur            w1, [x0, #0x17]
    //     0x69e5b4: add             x1, x1, HEAP, lsl #32
    // 0x69e5b8: CheckStackOverflow
    //     0x69e5b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e5bc: cmp             SP, x16
    //     0x69e5c0: b.ls            #0x69e640
    // 0x69e5c4: LoadField: r0 = r1->field_f
    //     0x69e5c4: ldur            w0, [x1, #0xf]
    // 0x69e5c8: DecompressPointer r0
    //     0x69e5c8: add             x0, x0, HEAP, lsl #32
    // 0x69e5cc: LoadField: r3 = r0->field_37
    //     0x69e5cc: ldur            w3, [x0, #0x37]
    // 0x69e5d0: DecompressPointer r3
    //     0x69e5d0: add             x3, x3, HEAP, lsl #32
    // 0x69e5d4: mov             x1, x3
    // 0x69e5d8: stur            x3, [fp, #-8]
    // 0x69e5dc: r2 = Instance_Chapter13Stat
    //     0x69e5dc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11350] Obj!Chapter13Stat@85fa61
    //     0x69e5e0: ldr             x2, [x2, #0x350]
    // 0x69e5e4: r0 = _getValueOrData()
    //     0x69e5e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69e5e8: mov             x1, x0
    // 0x69e5ec: ldur            x0, [fp, #-8]
    // 0x69e5f0: LoadField: r2 = r0->field_f
    //     0x69e5f0: ldur            w2, [x0, #0xf]
    // 0x69e5f4: DecompressPointer r2
    //     0x69e5f4: add             x2, x2, HEAP, lsl #32
    // 0x69e5f8: cmp             w2, w1
    // 0x69e5fc: b.ne            #0x69e604
    // 0x69e600: r1 = Null
    //     0x69e600: mov             x1, NULL
    // 0x69e604: cmp             w1, NULL
    // 0x69e608: b.ne            #0x69e614
    // 0x69e60c: r1 = Null
    //     0x69e60c: mov             x1, NULL
    // 0x69e610: b               #0x69e620
    // 0x69e614: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69e614: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69e618: r0 = toStringConsistentDecimalPlaces()
    //     0x69e618: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69e61c: mov             x1, x0
    // 0x69e620: cmp             w1, NULL
    // 0x69e624: b.ne            #0x69e630
    // 0x69e628: r0 = "0"
    //     0x69e628: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69e62c: b               #0x69e634
    // 0x69e630: mov             x0, x1
    // 0x69e634: LeaveFrame
    //     0x69e634: mov             SP, fp
    //     0x69e638: ldp             fp, lr, [SP], #0x10
    // 0x69e63c: ret
    //     0x69e63c: ret             
    // 0x69e640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e640: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e644: b               #0x69e5c4
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69e648, size: 0x88
    // 0x69e648: EnterFrame
    //     0x69e648: stp             fp, lr, [SP, #-0x10]!
    //     0x69e64c: mov             fp, SP
    // 0x69e650: ldr             x0, [fp, #0x10]
    // 0x69e654: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69e654: ldur            w1, [x0, #0x17]
    // 0x69e658: DecompressPointer r1
    //     0x69e658: add             x1, x1, HEAP, lsl #32
    // 0x69e65c: CheckStackOverflow
    //     0x69e65c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e660: cmp             SP, x16
    //     0x69e664: b.ls            #0x69e6bc
    // 0x69e668: LoadField: r0 = r1->field_f
    //     0x69e668: ldur            w0, [x1, #0xf]
    // 0x69e66c: DecompressPointer r0
    //     0x69e66c: add             x0, x0, HEAP, lsl #32
    // 0x69e670: LoadField: r1 = r0->field_43
    //     0x69e670: ldur            w1, [x0, #0x43]
    // 0x69e674: DecompressPointer r1
    //     0x69e674: add             x1, x1, HEAP, lsl #32
    // 0x69e678: r2 = 20
    //     0x69e678: movz            x2, #0x14
    // 0x69e67c: r0 = containsKey()
    //     0x69e67c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69e680: tbnz            w0, #4, #0x69e6ac
    // 0x69e684: r0 = LoadStaticField(0xf7c)
    //     0x69e684: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69e688: ldr             x0, [x0, #0x1ef8]
    // 0x69e68c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69e690: cmp             w0, w16
    // 0x69e694: b.eq            #0x69e6c4
    // 0x69e698: LoadField: r1 = r0->field_13
    //     0x69e698: ldur            w1, [x0, #0x13]
    // 0x69e69c: DecompressPointer r1
    //     0x69e69c: add             x1, x1, HEAP, lsl #32
    // 0x69e6a0: r2 = 54
    //     0x69e6a0: movz            x2, #0x36
    // 0x69e6a4: r0 = containsKey()
    //     0x69e6a4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69e6a8: b               #0x69e6b0
    // 0x69e6ac: r0 = false
    //     0x69e6ac: add             x0, NULL, #0x30  ; false
    // 0x69e6b0: LeaveFrame
    //     0x69e6b0: mov             SP, fp
    //     0x69e6b4: ldp             fp, lr, [SP], #0x10
    // 0x69e6b8: ret
    //     0x69e6b8: ret             
    // 0x69e6bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e6bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e6c0: b               #0x69e668
    // 0x69e6c4: r9 = coreData
    //     0x69e6c4: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69e6c8: ldr             x9, [x9, #0x530]
    // 0x69e6cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69e6cc: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x69e6d0, size: 0xb0
    // 0x69e6d0: EnterFrame
    //     0x69e6d0: stp             fp, lr, [SP, #-0x10]!
    //     0x69e6d4: mov             fp, SP
    // 0x69e6d8: AllocStack(0x10)
    //     0x69e6d8: sub             SP, SP, #0x10
    // 0x69e6dc: SetupParameters([dynamic _ /* r0 */])
    //     0x69e6dc: ldr             x0, [fp, #0x18]
    //     0x69e6e0: ldur            w3, [x0, #0x17]
    //     0x69e6e4: add             x3, x3, HEAP, lsl #32
    //     0x69e6e8: stur            x3, [fp, #-8]
    // 0x69e6ec: CheckStackOverflow
    //     0x69e6ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e6f0: cmp             SP, x16
    //     0x69e6f4: b.ls            #0x69e76c
    // 0x69e6f8: ldr             x0, [fp, #0x10]
    // 0x69e6fc: cmp             w0, #0x7c
    // 0x69e700: b.ne            #0x69e75c
    // 0x69e704: r0 = LoadStaticField(0xf7c)
    //     0x69e704: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69e708: ldr             x0, [x0, #0x1ef8]
    // 0x69e70c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69e710: cmp             w0, w16
    // 0x69e714: b.eq            #0x69e774
    // 0x69e718: LoadField: r1 = r0->field_13
    //     0x69e718: ldur            w1, [x0, #0x13]
    // 0x69e71c: DecompressPointer r1
    //     0x69e71c: add             x1, x1, HEAP, lsl #32
    // 0x69e720: r2 = 56
    //     0x69e720: movz            x2, #0x38
    // 0x69e724: r0 = containsKey()
    //     0x69e724: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69e728: tbz             w0, #4, #0x69e75c
    // 0x69e72c: ldur            x2, [fp, #-8]
    // 0x69e730: LoadField: r0 = r2->field_13
    //     0x69e730: ldur            w0, [x2, #0x13]
    // 0x69e734: DecompressPointer r0
    //     0x69e734: add             x0, x0, HEAP, lsl #32
    // 0x69e738: stur            x0, [fp, #-0x10]
    // 0x69e73c: r1 = Function '<anonymous closure>':.
    //     0x69e73c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28fd8] AnonymousClosure: (0x69e780), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69e740: ldr             x1, [x1, #0xfd8]
    // 0x69e744: r0 = AllocateClosure()
    //     0x69e744: bl              #0x826750  ; AllocateClosureStub
    // 0x69e748: ldur            x1, [fp, #-0x10]
    // 0x69e74c: mov             x3, x0
    // 0x69e750: r2 = 28
    //     0x69e750: movz            x2, #0x1c
    // 0x69e754: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x69e754: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x69e758: r0 = displaySlackPage()
    //     0x69e758: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x69e75c: r0 = Null
    //     0x69e75c: mov             x0, NULL
    // 0x69e760: LeaveFrame
    //     0x69e760: mov             SP, fp
    //     0x69e764: ldp             fp, lr, [SP], #0x10
    // 0x69e768: ret
    //     0x69e768: ret             
    // 0x69e76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e76c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e770: b               #0x69e6f8
    // 0x69e774: r9 = coreData
    //     0x69e774: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69e778: ldr             x9, [x9, #0x530]
    // 0x69e77c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69e77c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x69e780, size: 0x78
    // 0x69e780: EnterFrame
    //     0x69e780: stp             fp, lr, [SP, #-0x10]!
    //     0x69e784: mov             fp, SP
    // 0x69e788: AllocStack(0x8)
    //     0x69e788: sub             SP, SP, #8
    // 0x69e78c: SetupParameters([dynamic _ /* r0 */])
    //     0x69e78c: ldr             x0, [fp, #0x20]
    //     0x69e790: ldur            w3, [x0, #0x17]
    //     0x69e794: add             x3, x3, HEAP, lsl #32
    //     0x69e798: stur            x3, [fp, #-8]
    // 0x69e79c: CheckStackOverflow
    //     0x69e79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e7a0: cmp             SP, x16
    //     0x69e7a4: b.ls            #0x69e7f0
    // 0x69e7a8: LoadField: r1 = r3->field_f
    //     0x69e7a8: ldur            w1, [x3, #0xf]
    // 0x69e7ac: DecompressPointer r1
    //     0x69e7ac: add             x1, x1, HEAP, lsl #32
    // 0x69e7b0: r2 = 28
    //     0x69e7b0: movz            x2, #0x1c
    // 0x69e7b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x69e7b4: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x69e7b8: r0 = notifyDialoguePoint()
    //     0x69e7b8: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x69e7bc: ldr             x0, [fp, #0x10]
    // 0x69e7c0: r1 = LoadInt32Instr(r0)
    //     0x69e7c0: sbfx            x1, x0, #1, #0x1f
    //     0x69e7c4: tbz             w0, #0, #0x69e7cc
    //     0x69e7c8: ldur            x1, [x0, #7]
    // 0x69e7cc: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x69e7cc: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x69e7d0: ldur            x0, [fp, #-8]
    // 0x69e7d4: LoadField: r1 = r0->field_f
    //     0x69e7d4: ldur            w1, [x0, #0xf]
    // 0x69e7d8: DecompressPointer r1
    //     0x69e7d8: add             x1, x1, HEAP, lsl #32
    // 0x69e7dc: r0 = saveDeferred()
    //     0x69e7dc: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x69e7e0: r0 = Null
    //     0x69e7e0: mov             x0, NULL
    // 0x69e7e4: LeaveFrame
    //     0x69e7e4: mov             SP, fp
    //     0x69e7e8: ldp             fp, lr, [SP], #0x10
    // 0x69e7ec: ret
    //     0x69e7ec: ret             
    // 0x69e7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e7f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e7f4: b               #0x69e7a8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69e7f8, size: 0xa8
    // 0x69e7f8: EnterFrame
    //     0x69e7f8: stp             fp, lr, [SP, #-0x10]!
    //     0x69e7fc: mov             fp, SP
    // 0x69e800: AllocStack(0x8)
    //     0x69e800: sub             SP, SP, #8
    // 0x69e804: SetupParameters([dynamic _ /* r0 */])
    //     0x69e804: ldr             x0, [fp, #0x10]
    //     0x69e808: ldur            w1, [x0, #0x17]
    //     0x69e80c: add             x1, x1, HEAP, lsl #32
    // 0x69e810: CheckStackOverflow
    //     0x69e810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e814: cmp             SP, x16
    //     0x69e818: b.ls            #0x69e898
    // 0x69e81c: LoadField: r0 = r1->field_f
    //     0x69e81c: ldur            w0, [x1, #0xf]
    // 0x69e820: DecompressPointer r0
    //     0x69e820: add             x0, x0, HEAP, lsl #32
    // 0x69e824: LoadField: r3 = r0->field_37
    //     0x69e824: ldur            w3, [x0, #0x37]
    // 0x69e828: DecompressPointer r3
    //     0x69e828: add             x3, x3, HEAP, lsl #32
    // 0x69e82c: mov             x1, x3
    // 0x69e830: stur            x3, [fp, #-8]
    // 0x69e834: r2 = Instance_Chapter13Stat
    //     0x69e834: add             x2, PP, #0x11, lsl #12  ; [pp+0x11340] Obj!Chapter13Stat@85fa81
    //     0x69e838: ldr             x2, [x2, #0x340]
    // 0x69e83c: r0 = _getValueOrData()
    //     0x69e83c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69e840: mov             x1, x0
    // 0x69e844: ldur            x0, [fp, #-8]
    // 0x69e848: LoadField: r2 = r0->field_f
    //     0x69e848: ldur            w2, [x0, #0xf]
    // 0x69e84c: DecompressPointer r2
    //     0x69e84c: add             x2, x2, HEAP, lsl #32
    // 0x69e850: cmp             w2, w1
    // 0x69e854: b.ne            #0x69e85c
    // 0x69e858: r1 = Null
    //     0x69e858: mov             x1, NULL
    // 0x69e85c: cmp             w1, NULL
    // 0x69e860: b.ne            #0x69e86c
    // 0x69e864: r1 = Null
    //     0x69e864: mov             x1, NULL
    // 0x69e868: b               #0x69e878
    // 0x69e86c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69e86c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69e870: r0 = toStringConsistentDecimalPlaces()
    //     0x69e870: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69e874: mov             x1, x0
    // 0x69e878: cmp             w1, NULL
    // 0x69e87c: b.ne            #0x69e888
    // 0x69e880: r0 = "0"
    //     0x69e880: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69e884: b               #0x69e88c
    // 0x69e888: mov             x0, x1
    // 0x69e88c: LeaveFrame
    //     0x69e88c: mov             SP, fp
    //     0x69e890: ldp             fp, lr, [SP], #0x10
    // 0x69e894: ret
    //     0x69e894: ret             
    // 0x69e898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e898: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e89c: b               #0x69e81c
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x69e8a0, size: 0xac
    // 0x69e8a0: EnterFrame
    //     0x69e8a0: stp             fp, lr, [SP, #-0x10]!
    //     0x69e8a4: mov             fp, SP
    // 0x69e8a8: AllocStack(0x10)
    //     0x69e8a8: sub             SP, SP, #0x10
    // 0x69e8ac: SetupParameters([dynamic _ /* r0 */])
    //     0x69e8ac: ldr             x0, [fp, #0x10]
    //     0x69e8b0: ldur            w3, [x0, #0x17]
    //     0x69e8b4: add             x3, x3, HEAP, lsl #32
    //     0x69e8b8: stur            x3, [fp, #-8]
    // 0x69e8bc: CheckStackOverflow
    //     0x69e8bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e8c0: cmp             SP, x16
    //     0x69e8c4: b.ls            #0x69e938
    // 0x69e8c8: r0 = LoadStaticField(0xf7c)
    //     0x69e8c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69e8cc: ldr             x0, [x0, #0x1ef8]
    // 0x69e8d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69e8d4: cmp             w0, w16
    // 0x69e8d8: b.eq            #0x69e940
    // 0x69e8dc: LoadField: r1 = r0->field_13
    //     0x69e8dc: ldur            w1, [x0, #0x13]
    // 0x69e8e0: DecompressPointer r1
    //     0x69e8e0: add             x1, x1, HEAP, lsl #32
    // 0x69e8e4: r2 = 54
    //     0x69e8e4: movz            x2, #0x36
    // 0x69e8e8: r0 = containsKey()
    //     0x69e8e8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69e8ec: tbnz            w0, #4, #0x69e928
    // 0x69e8f0: ldur            x0, [fp, #-8]
    // 0x69e8f4: LoadField: r1 = r0->field_f
    //     0x69e8f4: ldur            w1, [x0, #0xf]
    // 0x69e8f8: DecompressPointer r1
    //     0x69e8f8: add             x1, x1, HEAP, lsl #32
    // 0x69e8fc: r16 = false
    //     0x69e8fc: add             x16, NULL, #0x30  ; false
    // 0x69e900: str             x16, [SP]
    // 0x69e904: r2 = 27
    //     0x69e904: movz            x2, #0x1b
    // 0x69e908: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x69e908: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x69e90c: ldr             x4, [x4, #0x5c0]
    // 0x69e910: r0 = notifyDialoguePoint()
    //     0x69e910: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x69e914: r0 = "Intermission"
    //     0x69e914: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x69e918: ldr             x0, [x0, #0x5c8]
    // 0x69e91c: LeaveFrame
    //     0x69e91c: mov             SP, fp
    //     0x69e920: ldp             fp, lr, [SP], #0x10
    // 0x69e924: ret
    //     0x69e924: ret             
    // 0x69e928: r0 = Null
    //     0x69e928: mov             x0, NULL
    // 0x69e92c: LeaveFrame
    //     0x69e92c: mov             SP, fp
    //     0x69e930: ldp             fp, lr, [SP], #0x10
    // 0x69e934: ret
    //     0x69e934: ret             
    // 0x69e938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e938: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e93c: b               #0x69e8c8
    // 0x69e940: r9 = coreData
    //     0x69e940: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69e944: ldr             x9, [x9, #0x530]
    // 0x69e948: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69e948: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69e94c, size: 0x4c
    // 0x69e94c: EnterFrame
    //     0x69e94c: stp             fp, lr, [SP, #-0x10]!
    //     0x69e950: mov             fp, SP
    // 0x69e954: ldr             x0, [fp, #0x10]
    // 0x69e958: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69e958: ldur            w1, [x0, #0x17]
    // 0x69e95c: DecompressPointer r1
    //     0x69e95c: add             x1, x1, HEAP, lsl #32
    // 0x69e960: CheckStackOverflow
    //     0x69e960: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e964: cmp             SP, x16
    //     0x69e968: b.ls            #0x69e990
    // 0x69e96c: LoadField: r0 = r1->field_f
    //     0x69e96c: ldur            w0, [x1, #0xf]
    // 0x69e970: DecompressPointer r0
    //     0x69e970: add             x0, x0, HEAP, lsl #32
    // 0x69e974: LoadField: r1 = r0->field_43
    //     0x69e974: ldur            w1, [x0, #0x43]
    // 0x69e978: DecompressPointer r1
    //     0x69e978: add             x1, x1, HEAP, lsl #32
    // 0x69e97c: r2 = 20
    //     0x69e97c: movz            x2, #0x14
    // 0x69e980: r0 = containsKey()
    //     0x69e980: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69e984: LeaveFrame
    //     0x69e984: mov             SP, fp
    //     0x69e988: ldp             fp, lr, [SP], #0x10
    // 0x69e98c: ret
    //     0x69e98c: ret             
    // 0x69e990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e990: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e994: b               #0x69e96c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69e998, size: 0x58
    // 0x69e998: EnterFrame
    //     0x69e998: stp             fp, lr, [SP, #-0x10]!
    //     0x69e99c: mov             fp, SP
    // 0x69e9a0: CheckStackOverflow
    //     0x69e9a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69e9a4: cmp             SP, x16
    //     0x69e9a8: b.ls            #0x69e9dc
    // 0x69e9ac: r0 = LoadStaticField(0xf7c)
    //     0x69e9ac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69e9b0: ldr             x0, [x0, #0x1ef8]
    // 0x69e9b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69e9b8: cmp             w0, w16
    // 0x69e9bc: b.eq            #0x69e9e4
    // 0x69e9c0: LoadField: r1 = r0->field_13
    //     0x69e9c0: ldur            w1, [x0, #0x13]
    // 0x69e9c4: DecompressPointer r1
    //     0x69e9c4: add             x1, x1, HEAP, lsl #32
    // 0x69e9c8: r2 = 54
    //     0x69e9c8: movz            x2, #0x36
    // 0x69e9cc: r0 = containsKey()
    //     0x69e9cc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69e9d0: LeaveFrame
    //     0x69e9d0: mov             SP, fp
    //     0x69e9d4: ldp             fp, lr, [SP], #0x10
    // 0x69e9d8: ret
    //     0x69e9d8: ret             
    // 0x69e9dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e9dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e9e0: b               #0x69e9ac
    // 0x69e9e4: r9 = coreData
    //     0x69e9e4: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x69e9e8: ldr             x9, [x9, #0x530]
    // 0x69e9ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69e9ec: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x69e9f0, size: 0x78
    // 0x69e9f0: EnterFrame
    //     0x69e9f0: stp             fp, lr, [SP, #-0x10]!
    //     0x69e9f4: mov             fp, SP
    // 0x69e9f8: AllocStack(0x18)
    //     0x69e9f8: sub             SP, SP, #0x18
    // 0x69e9fc: SetupParameters(Chapter13GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x69e9fc: stur            NULL, [fp, #-8]
    //     0x69ea00: movz            x0, #0
    //     0x69ea04: add             x1, fp, w0, sxtw #2
    //     0x69ea08: ldr             x1, [x1, #0x18]
    //     0x69ea0c: add             x2, fp, w0, sxtw #2
    //     0x69ea10: ldr             x2, [x2, #0x10]
    //     0x69ea14: stur            x2, [fp, #-0x18]
    //     0x69ea18: ldur            w3, [x1, #0x17]
    //     0x69ea1c: add             x3, x3, HEAP, lsl #32
    //     0x69ea20: stur            x3, [fp, #-0x10]
    // 0x69ea24: CheckStackOverflow
    //     0x69ea24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ea28: cmp             SP, x16
    //     0x69ea2c: b.ls            #0x69ea60
    // 0x69ea30: InitAsync() -> Future<void?>
    //     0x69ea30: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x69ea34: bl              #0x34b9a0  ; InitAsyncStub
    // 0x69ea38: ldur            x2, [fp, #-0x10]
    // 0x69ea3c: r1 = Function '<anonymous closure>':.
    //     0x69ea3c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28fe0] AnonymousClosure: (0x69ea68), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::build (0x69b504)
    //     0x69ea40: ldr             x1, [x1, #0xfe0]
    // 0x69ea44: r0 = AllocateClosure()
    //     0x69ea44: bl              #0x826750  ; AllocateClosureStub
    // 0x69ea48: ldur            x1, [fp, #-0x18]
    // 0x69ea4c: mov             x3, x0
    // 0x69ea50: r2 = 27
    //     0x69ea50: movz            x2, #0x1b
    // 0x69ea54: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x69ea54: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x69ea58: r0 = displaySlackPage()
    //     0x69ea58: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x69ea5c: r0 = ReturnAsync()
    //     0x69ea5c: b               #0x353380  ; ReturnAsyncStub
    // 0x69ea60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69ea60: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ea64: b               #0x69ea30
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x69ea68, size: 0x8c
    // 0x69ea68: EnterFrame
    //     0x69ea68: stp             fp, lr, [SP, #-0x10]!
    //     0x69ea6c: mov             fp, SP
    // 0x69ea70: AllocStack(0x10)
    //     0x69ea70: sub             SP, SP, #0x10
    // 0x69ea74: SetupParameters([dynamic _ /* r0 */])
    //     0x69ea74: ldr             x0, [fp, #0x20]
    //     0x69ea78: ldur            w3, [x0, #0x17]
    //     0x69ea7c: add             x3, x3, HEAP, lsl #32
    //     0x69ea80: stur            x3, [fp, #-8]
    // 0x69ea84: CheckStackOverflow
    //     0x69ea84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ea88: cmp             SP, x16
    //     0x69ea8c: b.ls            #0x69eaec
    // 0x69ea90: LoadField: r1 = r3->field_f
    //     0x69ea90: ldur            w1, [x3, #0xf]
    // 0x69ea94: DecompressPointer r1
    //     0x69ea94: add             x1, x1, HEAP, lsl #32
    // 0x69ea98: r2 = 27
    //     0x69ea98: movz            x2, #0x1b
    // 0x69ea9c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x69ea9c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x69eaa0: r0 = notifyDialoguePoint()
    //     0x69eaa0: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x69eaa4: ldr             x0, [fp, #0x10]
    // 0x69eaa8: r1 = LoadInt32Instr(r0)
    //     0x69eaa8: sbfx            x1, x0, #1, #0x1f
    //     0x69eaac: tbz             w0, #0, #0x69eab4
    //     0x69eab0: ldur            x1, [x0, #7]
    // 0x69eab4: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x69eab4: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x69eab8: ldur            x0, [fp, #-8]
    // 0x69eabc: LoadField: r1 = r0->field_f
    //     0x69eabc: ldur            w1, [x0, #0xf]
    // 0x69eac0: DecompressPointer r1
    //     0x69eac0: add             x1, x1, HEAP, lsl #32
    // 0x69eac4: r0 = saveDeferred()
    //     0x69eac4: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x69eac8: r16 = <ChapterViewportState>
    //     0x69eac8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9e0] TypeArguments: <ChapterViewportState>
    //     0x69eacc: ldr             x16, [x16, #0x9e0]
    // 0x69ead0: str             x16, [SP]
    // 0x69ead4: r4 = const [0x1, 0, 0, 0, null]
    //     0x69ead4: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x69ead8: r0 = updateAll()
    //     0x69ead8: bl              #0x4589c0  ; [package:state_groups/src/sync_state.dart] ::updateAll
    // 0x69eadc: r0 = Null
    //     0x69eadc: mov             x0, NULL
    // 0x69eae0: LeaveFrame
    //     0x69eae0: mov             SP, fp
    //     0x69eae4: ldp             fp, lr, [SP], #0x10
    // 0x69eae8: ret
    //     0x69eae8: ret             
    // 0x69eaec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69eaec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69eaf0: b               #0x69ea90
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69eaf4, size: 0xc
    // 0x69eaf4: r0 = "Each experience increases power gained by 1%"
    //     0x69eaf4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28fe8] "Each experience increases power gained by 1%"
    //     0x69eaf8: ldr             x0, [x0, #0xfe8]
    // 0x69eafc: ret
    //     0x69eafc: ret             
  }
  [closure] void applyResearchPrestige(dynamic) {
    // ** addr: 0x69eb00, size: 0x38
    // 0x69eb00: EnterFrame
    //     0x69eb00: stp             fp, lr, [SP, #-0x10]!
    //     0x69eb04: mov             fp, SP
    // 0x69eb08: ldr             x0, [fp, #0x10]
    // 0x69eb0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69eb0c: ldur            w1, [x0, #0x17]
    // 0x69eb10: DecompressPointer r1
    //     0x69eb10: add             x1, x1, HEAP, lsl #32
    // 0x69eb14: CheckStackOverflow
    //     0x69eb14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69eb18: cmp             SP, x16
    //     0x69eb1c: b.ls            #0x69eb30
    // 0x69eb20: r0 = applyResearchPrestige()
    //     0x69eb20: bl              #0x69eb38  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::applyResearchPrestige
    // 0x69eb24: LeaveFrame
    //     0x69eb24: mov             SP, fp
    //     0x69eb28: ldp             fp, lr, [SP], #0x10
    // 0x69eb2c: ret
    //     0x69eb2c: ret             
    // 0x69eb30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69eb30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69eb34: b               #0x69eb20
  }
  _ applyResearchPrestige(/* No info */) {
    // ** addr: 0x69eb38, size: 0x124
    // 0x69eb38: EnterFrame
    //     0x69eb38: stp             fp, lr, [SP, #-0x10]!
    //     0x69eb3c: mov             fp, SP
    // 0x69eb40: AllocStack(0x18)
    //     0x69eb40: sub             SP, SP, #0x18
    // 0x69eb44: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */)
    //     0x69eb44: mov             x0, x1
    //     0x69eb48: stur            x1, [fp, #-8]
    // 0x69eb4c: CheckStackOverflow
    //     0x69eb4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69eb50: cmp             SP, x16
    //     0x69eb54: b.ls            #0x69ec54
    // 0x69eb58: mov             x1, x0
    // 0x69eb5c: r0 = getSprintPoints()
    //     0x69eb5c: bl              #0x69eefc  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getSprintPoints
    // 0x69eb60: mov             x3, x0
    // 0x69eb64: ldur            x0, [fp, #-8]
    // 0x69eb68: stur            x3, [fp, #-0x18]
    // 0x69eb6c: LoadField: r4 = r0->field_37
    //     0x69eb6c: ldur            w4, [x0, #0x37]
    // 0x69eb70: DecompressPointer r4
    //     0x69eb70: add             x4, x4, HEAP, lsl #32
    // 0x69eb74: mov             x1, x4
    // 0x69eb78: stur            x4, [fp, #-0x10]
    // 0x69eb7c: r2 = Instance_Chapter13Stat
    //     0x69eb7c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x69eb80: ldr             x2, [x2, #0x380]
    // 0x69eb84: r0 = _getValueOrData()
    //     0x69eb84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69eb88: mov             x1, x0
    // 0x69eb8c: ldur            x0, [fp, #-0x10]
    // 0x69eb90: LoadField: r2 = r0->field_f
    //     0x69eb90: ldur            w2, [x0, #0xf]
    // 0x69eb94: DecompressPointer r2
    //     0x69eb94: add             x2, x2, HEAP, lsl #32
    // 0x69eb98: cmp             w2, w1
    // 0x69eb9c: b.ne            #0x69eba4
    // 0x69eba0: r1 = Null
    //     0x69eba0: mov             x1, NULL
    // 0x69eba4: cmp             w1, NULL
    // 0x69eba8: b.ne            #0x69ebb4
    // 0x69ebac: r1 = Instance_CustomNum
    //     0x69ebac: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69ebb0: ldr             x1, [x1, #0xaf8]
    // 0x69ebb4: ldur            x3, [fp, #-8]
    // 0x69ebb8: ldur            x2, [fp, #-0x18]
    // 0x69ebbc: r0 = add()
    //     0x69ebbc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x69ebc0: ldur            x1, [fp, #-0x10]
    // 0x69ebc4: mov             x3, x0
    // 0x69ebc8: r2 = Instance_Chapter13Stat
    //     0x69ebc8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x69ebcc: ldr             x2, [x2, #0x380]
    // 0x69ebd0: r0 = []=()
    //     0x69ebd0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ebd4: ldur            x0, [fp, #-8]
    // 0x69ebd8: LoadField: r3 = r0->field_3b
    //     0x69ebd8: ldur            w3, [x0, #0x3b]
    // 0x69ebdc: DecompressPointer r3
    //     0x69ebdc: add             x3, x3, HEAP, lsl #32
    // 0x69ebe0: mov             x1, x3
    // 0x69ebe4: stur            x3, [fp, #-0x10]
    // 0x69ebe8: r2 = Instance_Chapter13Stat
    //     0x69ebe8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x69ebec: ldr             x2, [x2, #0x380]
    // 0x69ebf0: r0 = _getValueOrData()
    //     0x69ebf0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69ebf4: mov             x1, x0
    // 0x69ebf8: ldur            x0, [fp, #-0x10]
    // 0x69ebfc: LoadField: r2 = r0->field_f
    //     0x69ebfc: ldur            w2, [x0, #0xf]
    // 0x69ec00: DecompressPointer r2
    //     0x69ec00: add             x2, x2, HEAP, lsl #32
    // 0x69ec04: cmp             w2, w1
    // 0x69ec08: b.ne            #0x69ec10
    // 0x69ec0c: r1 = Null
    //     0x69ec0c: mov             x1, NULL
    // 0x69ec10: cmp             w1, NULL
    // 0x69ec14: b.ne            #0x69ec20
    // 0x69ec18: r1 = Instance_CustomNum
    //     0x69ec18: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69ec1c: ldr             x1, [x1, #0xaf8]
    // 0x69ec20: ldur            x2, [fp, #-0x18]
    // 0x69ec24: r0 = add()
    //     0x69ec24: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x69ec28: ldur            x1, [fp, #-0x10]
    // 0x69ec2c: mov             x3, x0
    // 0x69ec30: r2 = Instance_Chapter13Stat
    //     0x69ec30: add             x2, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x69ec34: ldr             x2, [x2, #0x380]
    // 0x69ec38: r0 = []=()
    //     0x69ec38: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ec3c: ldur            x1, [fp, #-8]
    // 0x69ec40: r0 = researchReset()
    //     0x69ec40: bl              #0x69ec5c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::researchReset
    // 0x69ec44: r0 = Null
    //     0x69ec44: mov             x0, NULL
    // 0x69ec48: LeaveFrame
    //     0x69ec48: mov             SP, fp
    //     0x69ec4c: ldp             fp, lr, [SP], #0x10
    // 0x69ec50: ret
    //     0x69ec50: ret             
    // 0x69ec54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69ec54: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ec58: b               #0x69eb58
  }
  _ researchReset(/* No info */) {
    // ** addr: 0x69ec5c, size: 0x2a0
    // 0x69ec5c: EnterFrame
    //     0x69ec5c: stp             fp, lr, [SP, #-0x10]!
    //     0x69ec60: mov             fp, SP
    // 0x69ec64: AllocStack(0x18)
    //     0x69ec64: sub             SP, SP, #0x18
    // 0x69ec68: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */)
    //     0x69ec68: mov             x0, x1
    //     0x69ec6c: stur            x1, [fp, #-8]
    // 0x69ec70: CheckStackOverflow
    //     0x69ec70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ec74: cmp             SP, x16
    //     0x69ec78: b.ls            #0x69eeec
    // 0x69ec7c: LoadField: r1 = r0->field_47
    //     0x69ec7c: ldur            w1, [x0, #0x47]
    // 0x69ec80: DecompressPointer r1
    //     0x69ec80: add             x1, x1, HEAP, lsl #32
    // 0x69ec84: r0 = clear()
    //     0x69ec84: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x69ec88: r1 = 0
    //     0x69ec88: movz            x1, #0
    // 0x69ec8c: ldur            x0, [fp, #-8]
    // 0x69ec90: r3 = const [Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat', Instance of 'Chapter13Stat']
    //     0x69ec90: add             x3, PP, #0x11, lsl #12  ; [pp+0x113e8] List<Chapter13Stat>(12)
    //     0x69ec94: ldr             x3, [x3, #0x3e8]
    // 0x69ec98: CheckStackOverflow
    //     0x69ec98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ec9c: cmp             SP, x16
    //     0x69eca0: b.ls            #0x69eef4
    // 0x69eca4: cmp             x1, #0xc
    // 0x69eca8: b.ge            #0x69ed00
    // 0x69ecac: ArrayLoad: r4 = r3[r1]  ; Unknown_4
    //     0x69ecac: add             x16, x3, x1, lsl #2
    //     0x69ecb0: ldur            w4, [x16, #0xf]
    // 0x69ecb4: DecompressPointer r4
    //     0x69ecb4: add             x4, x4, HEAP, lsl #32
    // 0x69ecb8: stur            x4, [fp, #-0x18]
    // 0x69ecbc: add             x5, x1, #1
    // 0x69ecc0: stur            x5, [fp, #-0x10]
    // 0x69ecc4: r16 = Instance_Chapter13Stat
    //     0x69ecc4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11380] Obj!Chapter13Stat@85fa01
    //     0x69ecc8: ldr             x16, [x16, #0x380]
    // 0x69eccc: cmp             w4, w16
    // 0x69ecd0: b.eq            #0x69ecf8
    // 0x69ecd4: LoadField: r1 = r0->field_37
    //     0x69ecd4: ldur            w1, [x0, #0x37]
    // 0x69ecd8: DecompressPointer r1
    //     0x69ecd8: add             x1, x1, HEAP, lsl #32
    // 0x69ecdc: mov             x2, x4
    // 0x69ece0: r0 = remove()
    //     0x69ece0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69ece4: ldur            x0, [fp, #-8]
    // 0x69ece8: LoadField: r1 = r0->field_3b
    //     0x69ece8: ldur            w1, [x0, #0x3b]
    // 0x69ecec: DecompressPointer r1
    //     0x69ecec: add             x1, x1, HEAP, lsl #32
    // 0x69ecf0: ldur            x2, [fp, #-0x18]
    // 0x69ecf4: r0 = remove()
    //     0x69ecf4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69ecf8: ldur            x1, [fp, #-0x10]
    // 0x69ecfc: b               #0x69ec8c
    // 0x69ed00: LoadField: r1 = r0->field_43
    //     0x69ed00: ldur            w1, [x0, #0x43]
    // 0x69ed04: DecompressPointer r1
    //     0x69ed04: add             x1, x1, HEAP, lsl #32
    // 0x69ed08: r2 = 80
    //     0x69ed08: movz            x2, #0x50
    // 0x69ed0c: r0 = containsKey()
    //     0x69ed0c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69ed10: tbnz            w0, #4, #0x69ee94
    // 0x69ed14: ldur            x0, [fp, #-8]
    // 0x69ed18: LoadField: r1 = r0->field_37
    //     0x69ed18: ldur            w1, [x0, #0x37]
    // 0x69ed1c: DecompressPointer r1
    //     0x69ed1c: add             x1, x1, HEAP, lsl #32
    // 0x69ed20: r2 = Instance_Chapter13Stat
    //     0x69ed20: add             x2, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x69ed24: ldr             x2, [x2, #0x2e0]
    // 0x69ed28: r3 = Instance_CustomNum
    //     0x69ed28: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ed2c: ldr             x3, [x3, #0xa70]
    // 0x69ed30: r0 = []=()
    //     0x69ed30: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ed34: ldur            x0, [fp, #-8]
    // 0x69ed38: LoadField: r1 = r0->field_3b
    //     0x69ed38: ldur            w1, [x0, #0x3b]
    // 0x69ed3c: DecompressPointer r1
    //     0x69ed3c: add             x1, x1, HEAP, lsl #32
    // 0x69ed40: r2 = Instance_Chapter13Stat
    //     0x69ed40: add             x2, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x69ed44: ldr             x2, [x2, #0x2e0]
    // 0x69ed48: r3 = Instance_CustomNum
    //     0x69ed48: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ed4c: ldr             x3, [x3, #0xa70]
    // 0x69ed50: r0 = []=()
    //     0x69ed50: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ed54: ldur            x0, [fp, #-8]
    // 0x69ed58: LoadField: r1 = r0->field_37
    //     0x69ed58: ldur            w1, [x0, #0x37]
    // 0x69ed5c: DecompressPointer r1
    //     0x69ed5c: add             x1, x1, HEAP, lsl #32
    // 0x69ed60: r2 = Instance_Chapter13Stat
    //     0x69ed60: add             x2, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x69ed64: ldr             x2, [x2, #0x300]
    // 0x69ed68: r3 = Instance_CustomNum
    //     0x69ed68: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ed6c: ldr             x3, [x3, #0xa70]
    // 0x69ed70: r0 = []=()
    //     0x69ed70: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ed74: ldur            x0, [fp, #-8]
    // 0x69ed78: LoadField: r1 = r0->field_3b
    //     0x69ed78: ldur            w1, [x0, #0x3b]
    // 0x69ed7c: DecompressPointer r1
    //     0x69ed7c: add             x1, x1, HEAP, lsl #32
    // 0x69ed80: r2 = Instance_Chapter13Stat
    //     0x69ed80: add             x2, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x69ed84: ldr             x2, [x2, #0x300]
    // 0x69ed88: r3 = Instance_CustomNum
    //     0x69ed88: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ed8c: ldr             x3, [x3, #0xa70]
    // 0x69ed90: r0 = []=()
    //     0x69ed90: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ed94: ldur            x0, [fp, #-8]
    // 0x69ed98: LoadField: r1 = r0->field_37
    //     0x69ed98: ldur            w1, [x0, #0x37]
    // 0x69ed9c: DecompressPointer r1
    //     0x69ed9c: add             x1, x1, HEAP, lsl #32
    // 0x69eda0: r2 = Instance_Chapter13Stat
    //     0x69eda0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x69eda4: ldr             x2, [x2, #0x320]
    // 0x69eda8: r3 = Instance_CustomNum
    //     0x69eda8: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69edac: ldr             x3, [x3, #0xa70]
    // 0x69edb0: r0 = []=()
    //     0x69edb0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69edb4: ldur            x0, [fp, #-8]
    // 0x69edb8: LoadField: r1 = r0->field_3b
    //     0x69edb8: ldur            w1, [x0, #0x3b]
    // 0x69edbc: DecompressPointer r1
    //     0x69edbc: add             x1, x1, HEAP, lsl #32
    // 0x69edc0: r2 = Instance_Chapter13Stat
    //     0x69edc0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x69edc4: ldr             x2, [x2, #0x320]
    // 0x69edc8: r3 = Instance_CustomNum
    //     0x69edc8: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69edcc: ldr             x3, [x3, #0xa70]
    // 0x69edd0: r0 = []=()
    //     0x69edd0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69edd4: ldur            x0, [fp, #-8]
    // 0x69edd8: LoadField: r1 = r0->field_37
    //     0x69edd8: ldur            w1, [x0, #0x37]
    // 0x69eddc: DecompressPointer r1
    //     0x69eddc: add             x1, x1, HEAP, lsl #32
    // 0x69ede0: r2 = Instance_Chapter13Stat
    //     0x69ede0: add             x2, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x69ede4: ldr             x2, [x2, #0x2f0]
    // 0x69ede8: r3 = Instance_CustomNum
    //     0x69ede8: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69edec: ldr             x3, [x3, #0xa70]
    // 0x69edf0: r0 = []=()
    //     0x69edf0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69edf4: ldur            x0, [fp, #-8]
    // 0x69edf8: LoadField: r1 = r0->field_3b
    //     0x69edf8: ldur            w1, [x0, #0x3b]
    // 0x69edfc: DecompressPointer r1
    //     0x69edfc: add             x1, x1, HEAP, lsl #32
    // 0x69ee00: r2 = Instance_Chapter13Stat
    //     0x69ee00: add             x2, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x69ee04: ldr             x2, [x2, #0x2f0]
    // 0x69ee08: r3 = Instance_CustomNum
    //     0x69ee08: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ee0c: ldr             x3, [x3, #0xa70]
    // 0x69ee10: r0 = []=()
    //     0x69ee10: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ee14: ldur            x0, [fp, #-8]
    // 0x69ee18: LoadField: r1 = r0->field_37
    //     0x69ee18: ldur            w1, [x0, #0x37]
    // 0x69ee1c: DecompressPointer r1
    //     0x69ee1c: add             x1, x1, HEAP, lsl #32
    // 0x69ee20: r2 = Instance_Chapter13Stat
    //     0x69ee20: add             x2, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x69ee24: ldr             x2, [x2, #0x310]
    // 0x69ee28: r3 = Instance_CustomNum
    //     0x69ee28: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ee2c: ldr             x3, [x3, #0xa70]
    // 0x69ee30: r0 = []=()
    //     0x69ee30: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ee34: ldur            x0, [fp, #-8]
    // 0x69ee38: LoadField: r1 = r0->field_3b
    //     0x69ee38: ldur            w1, [x0, #0x3b]
    // 0x69ee3c: DecompressPointer r1
    //     0x69ee3c: add             x1, x1, HEAP, lsl #32
    // 0x69ee40: r2 = Instance_Chapter13Stat
    //     0x69ee40: add             x2, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x69ee44: ldr             x2, [x2, #0x310]
    // 0x69ee48: r3 = Instance_CustomNum
    //     0x69ee48: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ee4c: ldr             x3, [x3, #0xa70]
    // 0x69ee50: r0 = []=()
    //     0x69ee50: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ee54: ldur            x0, [fp, #-8]
    // 0x69ee58: LoadField: r1 = r0->field_37
    //     0x69ee58: ldur            w1, [x0, #0x37]
    // 0x69ee5c: DecompressPointer r1
    //     0x69ee5c: add             x1, x1, HEAP, lsl #32
    // 0x69ee60: r2 = Instance_Chapter13Stat
    //     0x69ee60: add             x2, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x69ee64: ldr             x2, [x2, #0x360]
    // 0x69ee68: r3 = Instance_CustomNum
    //     0x69ee68: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ee6c: ldr             x3, [x3, #0xa70]
    // 0x69ee70: r0 = []=()
    //     0x69ee70: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ee74: ldur            x0, [fp, #-8]
    // 0x69ee78: LoadField: r1 = r0->field_3b
    //     0x69ee78: ldur            w1, [x0, #0x3b]
    // 0x69ee7c: DecompressPointer r1
    //     0x69ee7c: add             x1, x1, HEAP, lsl #32
    // 0x69ee80: r2 = Instance_Chapter13Stat
    //     0x69ee80: add             x2, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x69ee84: ldr             x2, [x2, #0x360]
    // 0x69ee88: r3 = Instance_CustomNum
    //     0x69ee88: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x69ee8c: ldr             x3, [x3, #0xa70]
    // 0x69ee90: r0 = []=()
    //     0x69ee90: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69ee94: ldur            x0, [fp, #-8]
    // 0x69ee98: LoadField: r1 = r0->field_37
    //     0x69ee98: ldur            w1, [x0, #0x37]
    // 0x69ee9c: DecompressPointer r1
    //     0x69ee9c: add             x1, x1, HEAP, lsl #32
    // 0x69eea0: r2 = Instance_Chapter13Stat
    //     0x69eea0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x69eea4: ldr             x2, [x2, #0x298]
    // 0x69eea8: r3 = Instance_CustomNum
    //     0x69eea8: add             x3, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x69eeac: ldr             x3, [x3, #0x2a0]
    // 0x69eeb0: r0 = []=()
    //     0x69eeb0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69eeb4: ldur            x0, [fp, #-8]
    // 0x69eeb8: LoadField: r1 = r0->field_3b
    //     0x69eeb8: ldur            w1, [x0, #0x3b]
    // 0x69eebc: DecompressPointer r1
    //     0x69eebc: add             x1, x1, HEAP, lsl #32
    // 0x69eec0: r2 = Instance_Chapter13Stat
    //     0x69eec0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x69eec4: ldr             x2, [x2, #0x298]
    // 0x69eec8: r3 = Instance_CustomNum
    //     0x69eec8: add             x3, PP, #0x11, lsl #12  ; [pp+0x112a0] Obj!CustomNum@828c71
    //     0x69eecc: ldr             x3, [x3, #0x2a0]
    // 0x69eed0: r0 = []=()
    //     0x69eed0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69eed4: ldur            x1, [fp, #-8]
    // 0x69eed8: r0 = resetAndRecomputeBoosts()
    //     0x69eed8: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x69eedc: r0 = Null
    //     0x69eedc: mov             x0, NULL
    // 0x69eee0: LeaveFrame
    //     0x69eee0: mov             SP, fp
    //     0x69eee4: ldp             fp, lr, [SP], #0x10
    // 0x69eee8: ret
    //     0x69eee8: ret             
    // 0x69eeec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69eeec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69eef0: b               #0x69ec7c
    // 0x69eef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69eef4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69eef8: b               #0x69eca4
  }
  _ getSprintPoints(/* No info */) {
    // ** addr: 0x69eefc, size: 0x90
    // 0x69eefc: EnterFrame
    //     0x69eefc: stp             fp, lr, [SP, #-0x10]!
    //     0x69ef00: mov             fp, SP
    // 0x69ef04: AllocStack(0x8)
    //     0x69ef04: sub             SP, SP, #8
    // 0x69ef08: CheckStackOverflow
    //     0x69ef08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69ef0c: cmp             SP, x16
    //     0x69ef10: b.ls            #0x69ef84
    // 0x69ef14: LoadField: r0 = r1->field_3b
    //     0x69ef14: ldur            w0, [x1, #0x3b]
    // 0x69ef18: DecompressPointer r0
    //     0x69ef18: add             x0, x0, HEAP, lsl #32
    // 0x69ef1c: mov             x1, x0
    // 0x69ef20: stur            x0, [fp, #-8]
    // 0x69ef24: r2 = Instance_Chapter13Stat
    //     0x69ef24: add             x2, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x69ef28: ldr             x2, [x2, #0x298]
    // 0x69ef2c: r0 = _getValueOrData()
    //     0x69ef2c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69ef30: mov             x1, x0
    // 0x69ef34: ldur            x0, [fp, #-8]
    // 0x69ef38: LoadField: r2 = r0->field_f
    //     0x69ef38: ldur            w2, [x0, #0xf]
    // 0x69ef3c: DecompressPointer r2
    //     0x69ef3c: add             x2, x2, HEAP, lsl #32
    // 0x69ef40: cmp             w2, w1
    // 0x69ef44: b.ne            #0x69ef50
    // 0x69ef48: r0 = Null
    //     0x69ef48: mov             x0, NULL
    // 0x69ef4c: b               #0x69ef54
    // 0x69ef50: mov             x0, x1
    // 0x69ef54: cmp             w0, NULL
    // 0x69ef58: b.ne            #0x69ef68
    // 0x69ef5c: r2 = Instance_CustomNum
    //     0x69ef5c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69ef60: ldr             x2, [x2, #0xaf8]
    // 0x69ef64: b               #0x69ef6c
    // 0x69ef68: mov             x2, x0
    // 0x69ef6c: r1 = Instance_CustomNum
    //     0x69ef6c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ff0] Obj!CustomNum@82b721
    //     0x69ef70: ldr             x1, [x1, #0xff0]
    // 0x69ef74: r0 = mult2()
    //     0x69ef74: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x69ef78: LeaveFrame
    //     0x69ef78: mov             SP, fp
    //     0x69ef7c: ldp             fp, lr, [SP], #0x10
    // 0x69ef80: ret
    //     0x69ef80: ret             
    // 0x69ef84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69ef84: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ef88: b               #0x69ef14
  }
  [closure] CustomNum getSprintPoints(dynamic) {
    // ** addr: 0x69ef8c, size: 0x38
    // 0x69ef8c: EnterFrame
    //     0x69ef8c: stp             fp, lr, [SP, #-0x10]!
    //     0x69ef90: mov             fp, SP
    // 0x69ef94: ldr             x0, [fp, #0x10]
    // 0x69ef98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69ef98: ldur            w1, [x0, #0x17]
    // 0x69ef9c: DecompressPointer r1
    //     0x69ef9c: add             x1, x1, HEAP, lsl #32
    // 0x69efa0: CheckStackOverflow
    //     0x69efa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69efa4: cmp             SP, x16
    //     0x69efa8: b.ls            #0x69efbc
    // 0x69efac: r0 = getSprintPoints()
    //     0x69efac: bl              #0x69eefc  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getSprintPoints
    // 0x69efb0: LeaveFrame
    //     0x69efb0: mov             SP, fp
    //     0x69efb4: ldp             fp, lr, [SP], #0x10
    // 0x69efb8: ret
    //     0x69efb8: ret             
    // 0x69efbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69efbc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69efc0: b               #0x69efac
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69efc4, size: 0xc
    // 0x69efc4: r0 = "Sprint Meeting"
    //     0x69efc4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ff8] "Sprint Meeting"
    //     0x69efc8: ldr             x0, [x0, #0xff8]
    // 0x69efcc: ret
    //     0x69efcc: ret             
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69efd0, size: 0x2c
    // 0x69efd0: ldr             x1, [SP]
    // 0x69efd4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69efd4: ldur            w2, [x1, #0x17]
    // 0x69efd8: DecompressPointer r2
    //     0x69efd8: add             x2, x2, HEAP, lsl #32
    // 0x69efdc: LoadField: r1 = r2->field_f
    //     0x69efdc: ldur            w1, [x2, #0xf]
    // 0x69efe0: DecompressPointer r1
    //     0x69efe0: add             x1, x1, HEAP, lsl #32
    // 0x69efe4: LoadField: r2 = r1->field_8b
    //     0x69efe4: ldur            x2, [x1, #0x8b]
    // 0x69efe8: cmp             x2, #5
    // 0x69efec: r16 = true
    //     0x69efec: add             x16, NULL, #0x20  ; true
    // 0x69eff0: r17 = false
    //     0x69eff0: add             x17, NULL, #0x30  ; false
    // 0x69eff4: csel            x0, x16, x17, ge
    // 0x69eff8: ret
    //     0x69eff8: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69effc, size: 0xa8
    // 0x69effc: EnterFrame
    //     0x69effc: stp             fp, lr, [SP, #-0x10]!
    //     0x69f000: mov             fp, SP
    // 0x69f004: AllocStack(0x8)
    //     0x69f004: sub             SP, SP, #8
    // 0x69f008: SetupParameters([dynamic _ /* r0 */])
    //     0x69f008: ldr             x0, [fp, #0x10]
    //     0x69f00c: ldur            w1, [x0, #0x17]
    //     0x69f010: add             x1, x1, HEAP, lsl #32
    // 0x69f014: CheckStackOverflow
    //     0x69f014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f018: cmp             SP, x16
    //     0x69f01c: b.ls            #0x69f09c
    // 0x69f020: LoadField: r0 = r1->field_f
    //     0x69f020: ldur            w0, [x1, #0xf]
    // 0x69f024: DecompressPointer r0
    //     0x69f024: add             x0, x0, HEAP, lsl #32
    // 0x69f028: LoadField: r3 = r0->field_37
    //     0x69f028: ldur            w3, [x0, #0x37]
    // 0x69f02c: DecompressPointer r3
    //     0x69f02c: add             x3, x3, HEAP, lsl #32
    // 0x69f030: mov             x1, x3
    // 0x69f034: stur            x3, [fp, #-8]
    // 0x69f038: r2 = Instance_Chapter13Stat
    //     0x69f038: add             x2, PP, #0x11, lsl #12  ; [pp+0x11360] Obj!Chapter13Stat@85fa41
    //     0x69f03c: ldr             x2, [x2, #0x360]
    // 0x69f040: r0 = _getValueOrData()
    //     0x69f040: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f044: mov             x1, x0
    // 0x69f048: ldur            x0, [fp, #-8]
    // 0x69f04c: LoadField: r2 = r0->field_f
    //     0x69f04c: ldur            w2, [x0, #0xf]
    // 0x69f050: DecompressPointer r2
    //     0x69f050: add             x2, x2, HEAP, lsl #32
    // 0x69f054: cmp             w2, w1
    // 0x69f058: b.ne            #0x69f060
    // 0x69f05c: r1 = Null
    //     0x69f05c: mov             x1, NULL
    // 0x69f060: cmp             w1, NULL
    // 0x69f064: b.ne            #0x69f070
    // 0x69f068: r1 = Null
    //     0x69f068: mov             x1, NULL
    // 0x69f06c: b               #0x69f07c
    // 0x69f070: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69f070: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69f074: r0 = toStringConsistentDecimalPlaces()
    //     0x69f074: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69f078: mov             x1, x0
    // 0x69f07c: cmp             w1, NULL
    // 0x69f080: b.ne            #0x69f08c
    // 0x69f084: r0 = "0"
    //     0x69f084: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69f088: b               #0x69f090
    // 0x69f08c: mov             x0, x1
    // 0x69f090: LeaveFrame
    //     0x69f090: mov             SP, fp
    //     0x69f094: ldp             fp, lr, [SP], #0x10
    // 0x69f098: ret
    //     0x69f098: ret             
    // 0x69f09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f09c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f0a0: b               #0x69f020
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69f0a4, size: 0x2c
    // 0x69f0a4: ldr             x1, [SP]
    // 0x69f0a8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69f0a8: ldur            w2, [x1, #0x17]
    // 0x69f0ac: DecompressPointer r2
    //     0x69f0ac: add             x2, x2, HEAP, lsl #32
    // 0x69f0b0: LoadField: r1 = r2->field_f
    //     0x69f0b0: ldur            w1, [x2, #0xf]
    // 0x69f0b4: DecompressPointer r1
    //     0x69f0b4: add             x1, x1, HEAP, lsl #32
    // 0x69f0b8: LoadField: r2 = r1->field_8b
    //     0x69f0b8: ldur            x2, [x1, #0x8b]
    // 0x69f0bc: cmp             x2, #3
    // 0x69f0c0: r16 = true
    //     0x69f0c0: add             x16, NULL, #0x20  ; true
    // 0x69f0c4: r17 = false
    //     0x69f0c4: add             x17, NULL, #0x30  ; false
    // 0x69f0c8: csel            x0, x16, x17, ge
    // 0x69f0cc: ret
    //     0x69f0cc: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f0d0, size: 0xa8
    // 0x69f0d0: EnterFrame
    //     0x69f0d0: stp             fp, lr, [SP, #-0x10]!
    //     0x69f0d4: mov             fp, SP
    // 0x69f0d8: AllocStack(0x8)
    //     0x69f0d8: sub             SP, SP, #8
    // 0x69f0dc: SetupParameters([dynamic _ /* r0 */])
    //     0x69f0dc: ldr             x0, [fp, #0x10]
    //     0x69f0e0: ldur            w1, [x0, #0x17]
    //     0x69f0e4: add             x1, x1, HEAP, lsl #32
    // 0x69f0e8: CheckStackOverflow
    //     0x69f0e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f0ec: cmp             SP, x16
    //     0x69f0f0: b.ls            #0x69f170
    // 0x69f0f4: LoadField: r0 = r1->field_f
    //     0x69f0f4: ldur            w0, [x1, #0xf]
    // 0x69f0f8: DecompressPointer r0
    //     0x69f0f8: add             x0, x0, HEAP, lsl #32
    // 0x69f0fc: LoadField: r3 = r0->field_37
    //     0x69f0fc: ldur            w3, [x0, #0x37]
    // 0x69f100: DecompressPointer r3
    //     0x69f100: add             x3, x3, HEAP, lsl #32
    // 0x69f104: mov             x1, x3
    // 0x69f108: stur            x3, [fp, #-8]
    // 0x69f10c: r2 = Instance_Chapter13Stat
    //     0x69f10c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11310] Obj!Chapter13Stat@85fae1
    //     0x69f110: ldr             x2, [x2, #0x310]
    // 0x69f114: r0 = _getValueOrData()
    //     0x69f114: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f118: mov             x1, x0
    // 0x69f11c: ldur            x0, [fp, #-8]
    // 0x69f120: LoadField: r2 = r0->field_f
    //     0x69f120: ldur            w2, [x0, #0xf]
    // 0x69f124: DecompressPointer r2
    //     0x69f124: add             x2, x2, HEAP, lsl #32
    // 0x69f128: cmp             w2, w1
    // 0x69f12c: b.ne            #0x69f134
    // 0x69f130: r1 = Null
    //     0x69f130: mov             x1, NULL
    // 0x69f134: cmp             w1, NULL
    // 0x69f138: b.ne            #0x69f144
    // 0x69f13c: r1 = Null
    //     0x69f13c: mov             x1, NULL
    // 0x69f140: b               #0x69f150
    // 0x69f144: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69f144: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69f148: r0 = toStringConsistentDecimalPlaces()
    //     0x69f148: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69f14c: mov             x1, x0
    // 0x69f150: cmp             w1, NULL
    // 0x69f154: b.ne            #0x69f160
    // 0x69f158: r0 = "0"
    //     0x69f158: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69f15c: b               #0x69f164
    // 0x69f160: mov             x0, x1
    // 0x69f164: LeaveFrame
    //     0x69f164: mov             SP, fp
    //     0x69f168: ldp             fp, lr, [SP], #0x10
    // 0x69f16c: ret
    //     0x69f16c: ret             
    // 0x69f170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f170: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f174: b               #0x69f0f4
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69f178, size: 0x2c
    // 0x69f178: ldr             x1, [SP]
    // 0x69f17c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x69f17c: ldur            w2, [x1, #0x17]
    // 0x69f180: DecompressPointer r2
    //     0x69f180: add             x2, x2, HEAP, lsl #32
    // 0x69f184: LoadField: r1 = r2->field_f
    //     0x69f184: ldur            w1, [x2, #0xf]
    // 0x69f188: DecompressPointer r1
    //     0x69f188: add             x1, x1, HEAP, lsl #32
    // 0x69f18c: LoadField: r2 = r1->field_8b
    //     0x69f18c: ldur            x2, [x1, #0x8b]
    // 0x69f190: cmp             x2, #2
    // 0x69f194: r16 = true
    //     0x69f194: add             x16, NULL, #0x20  ; true
    // 0x69f198: r17 = false
    //     0x69f198: add             x17, NULL, #0x30  ; false
    // 0x69f19c: csel            x0, x16, x17, ge
    // 0x69f1a0: ret
    //     0x69f1a0: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f1a4, size: 0xa8
    // 0x69f1a4: EnterFrame
    //     0x69f1a4: stp             fp, lr, [SP, #-0x10]!
    //     0x69f1a8: mov             fp, SP
    // 0x69f1ac: AllocStack(0x8)
    //     0x69f1ac: sub             SP, SP, #8
    // 0x69f1b0: SetupParameters([dynamic _ /* r0 */])
    //     0x69f1b0: ldr             x0, [fp, #0x10]
    //     0x69f1b4: ldur            w1, [x0, #0x17]
    //     0x69f1b8: add             x1, x1, HEAP, lsl #32
    // 0x69f1bc: CheckStackOverflow
    //     0x69f1bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f1c0: cmp             SP, x16
    //     0x69f1c4: b.ls            #0x69f244
    // 0x69f1c8: LoadField: r0 = r1->field_f
    //     0x69f1c8: ldur            w0, [x1, #0xf]
    // 0x69f1cc: DecompressPointer r0
    //     0x69f1cc: add             x0, x0, HEAP, lsl #32
    // 0x69f1d0: LoadField: r3 = r0->field_37
    //     0x69f1d0: ldur            w3, [x0, #0x37]
    // 0x69f1d4: DecompressPointer r3
    //     0x69f1d4: add             x3, x3, HEAP, lsl #32
    // 0x69f1d8: mov             x1, x3
    // 0x69f1dc: stur            x3, [fp, #-8]
    // 0x69f1e0: r2 = Instance_Chapter13Stat
    //     0x69f1e0: add             x2, PP, #0x11, lsl #12  ; [pp+0x112f0] Obj!Chapter13Stat@85fb21
    //     0x69f1e4: ldr             x2, [x2, #0x2f0]
    // 0x69f1e8: r0 = _getValueOrData()
    //     0x69f1e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f1ec: mov             x1, x0
    // 0x69f1f0: ldur            x0, [fp, #-8]
    // 0x69f1f4: LoadField: r2 = r0->field_f
    //     0x69f1f4: ldur            w2, [x0, #0xf]
    // 0x69f1f8: DecompressPointer r2
    //     0x69f1f8: add             x2, x2, HEAP, lsl #32
    // 0x69f1fc: cmp             w2, w1
    // 0x69f200: b.ne            #0x69f208
    // 0x69f204: r1 = Null
    //     0x69f204: mov             x1, NULL
    // 0x69f208: cmp             w1, NULL
    // 0x69f20c: b.ne            #0x69f218
    // 0x69f210: r1 = Null
    //     0x69f210: mov             x1, NULL
    // 0x69f214: b               #0x69f224
    // 0x69f218: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69f218: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69f21c: r0 = toStringConsistentDecimalPlaces()
    //     0x69f21c: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69f220: mov             x1, x0
    // 0x69f224: cmp             w1, NULL
    // 0x69f228: b.ne            #0x69f234
    // 0x69f22c: r0 = "0"
    //     0x69f22c: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69f230: b               #0x69f238
    // 0x69f234: mov             x0, x1
    // 0x69f238: LeaveFrame
    //     0x69f238: mov             SP, fp
    //     0x69f23c: ldp             fp, lr, [SP], #0x10
    // 0x69f240: ret
    //     0x69f240: ret             
    // 0x69f244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f244: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f248: b               #0x69f1c8
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x69f24c, size: 0x8c
    // 0x69f24c: EnterFrame
    //     0x69f24c: stp             fp, lr, [SP, #-0x10]!
    //     0x69f250: mov             fp, SP
    // 0x69f254: AllocStack(0x8)
    //     0x69f254: sub             SP, SP, #8
    // 0x69f258: SetupParameters([dynamic _ /* r0 */])
    //     0x69f258: ldr             x0, [fp, #0x10]
    //     0x69f25c: ldur            w1, [x0, #0x17]
    //     0x69f260: add             x1, x1, HEAP, lsl #32
    // 0x69f264: CheckStackOverflow
    //     0x69f264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f268: cmp             SP, x16
    //     0x69f26c: b.ls            #0x69f2d0
    // 0x69f270: LoadField: r0 = r1->field_f
    //     0x69f270: ldur            w0, [x1, #0xf]
    // 0x69f274: DecompressPointer r0
    //     0x69f274: add             x0, x0, HEAP, lsl #32
    // 0x69f278: LoadField: r1 = r0->field_3f
    //     0x69f278: ldur            w1, [x0, #0x3f]
    // 0x69f27c: DecompressPointer r1
    //     0x69f27c: add             x1, x1, HEAP, lsl #32
    // 0x69f280: LoadField: r0 = r1->field_b
    //     0x69f280: ldur            w0, [x1, #0xb]
    // 0x69f284: DecompressPointer r0
    //     0x69f284: add             x0, x0, HEAP, lsl #32
    // 0x69f288: mov             x1, x0
    // 0x69f28c: stur            x0, [fp, #-8]
    // 0x69f290: r2 = 2
    //     0x69f290: movz            x2, #0x2
    // 0x69f294: r0 = _getValueOrData()
    //     0x69f294: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f298: ldur            x1, [fp, #-8]
    // 0x69f29c: LoadField: r2 = r1->field_f
    //     0x69f29c: ldur            w2, [x1, #0xf]
    // 0x69f2a0: DecompressPointer r2
    //     0x69f2a0: add             x2, x2, HEAP, lsl #32
    // 0x69f2a4: cmp             w2, w0
    // 0x69f2a8: b.eq            #0x69f2c0
    // 0x69f2ac: cmp             w0, #0x7ce
    // 0x69f2b0: b.ne            #0x69f2c0
    // 0x69f2b4: r0 = "Bill Shock"
    //     0x69f2b4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29000] "Bill Shock"
    //     0x69f2b8: ldr             x0, [x0]
    // 0x69f2bc: b               #0x69f2c4
    // 0x69f2c0: r0 = Null
    //     0x69f2c0: mov             x0, NULL
    // 0x69f2c4: LeaveFrame
    //     0x69f2c4: mov             SP, fp
    //     0x69f2c8: ldp             fp, lr, [SP], #0x10
    // 0x69f2cc: ret
    //     0x69f2cc: ret             
    // 0x69f2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f2d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f2d4: b               #0x69f270
  }
  [closure] void researchReset(dynamic) {
    // ** addr: 0x69f2d8, size: 0x38
    // 0x69f2d8: EnterFrame
    //     0x69f2d8: stp             fp, lr, [SP, #-0x10]!
    //     0x69f2dc: mov             fp, SP
    // 0x69f2e0: ldr             x0, [fp, #0x10]
    // 0x69f2e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69f2e4: ldur            w1, [x0, #0x17]
    // 0x69f2e8: DecompressPointer r1
    //     0x69f2e8: add             x1, x1, HEAP, lsl #32
    // 0x69f2ec: CheckStackOverflow
    //     0x69f2ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f2f0: cmp             SP, x16
    //     0x69f2f4: b.ls            #0x69f308
    // 0x69f2f8: r0 = researchReset()
    //     0x69f2f8: bl              #0x69ec5c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::researchReset
    // 0x69f2fc: LeaveFrame
    //     0x69f2fc: mov             SP, fp
    //     0x69f300: ldp             fp, lr, [SP], #0x10
    // 0x69f304: ret
    //     0x69f304: ret             
    // 0x69f308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f308: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f30c: b               #0x69f2f8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f310, size: 0xa8
    // 0x69f310: EnterFrame
    //     0x69f310: stp             fp, lr, [SP, #-0x10]!
    //     0x69f314: mov             fp, SP
    // 0x69f318: AllocStack(0x8)
    //     0x69f318: sub             SP, SP, #8
    // 0x69f31c: SetupParameters([dynamic _ /* r0 */])
    //     0x69f31c: ldr             x0, [fp, #0x10]
    //     0x69f320: ldur            w1, [x0, #0x17]
    //     0x69f324: add             x1, x1, HEAP, lsl #32
    // 0x69f328: CheckStackOverflow
    //     0x69f328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f32c: cmp             SP, x16
    //     0x69f330: b.ls            #0x69f3b0
    // 0x69f334: LoadField: r0 = r1->field_f
    //     0x69f334: ldur            w0, [x1, #0xf]
    // 0x69f338: DecompressPointer r0
    //     0x69f338: add             x0, x0, HEAP, lsl #32
    // 0x69f33c: LoadField: r3 = r0->field_37
    //     0x69f33c: ldur            w3, [x0, #0x37]
    // 0x69f340: DecompressPointer r3
    //     0x69f340: add             x3, x3, HEAP, lsl #32
    // 0x69f344: mov             x1, x3
    // 0x69f348: stur            x3, [fp, #-8]
    // 0x69f34c: r2 = Instance_Chapter13Stat
    //     0x69f34c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11320] Obj!Chapter13Stat@85fac1
    //     0x69f350: ldr             x2, [x2, #0x320]
    // 0x69f354: r0 = _getValueOrData()
    //     0x69f354: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f358: mov             x1, x0
    // 0x69f35c: ldur            x0, [fp, #-8]
    // 0x69f360: LoadField: r2 = r0->field_f
    //     0x69f360: ldur            w2, [x0, #0xf]
    // 0x69f364: DecompressPointer r2
    //     0x69f364: add             x2, x2, HEAP, lsl #32
    // 0x69f368: cmp             w2, w1
    // 0x69f36c: b.ne            #0x69f374
    // 0x69f370: r1 = Null
    //     0x69f370: mov             x1, NULL
    // 0x69f374: cmp             w1, NULL
    // 0x69f378: b.ne            #0x69f384
    // 0x69f37c: r1 = Null
    //     0x69f37c: mov             x1, NULL
    // 0x69f380: b               #0x69f390
    // 0x69f384: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69f384: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69f388: r0 = toStringConsistentDecimalPlaces()
    //     0x69f388: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69f38c: mov             x1, x0
    // 0x69f390: cmp             w1, NULL
    // 0x69f394: b.ne            #0x69f3a0
    // 0x69f398: r0 = "0"
    //     0x69f398: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69f39c: b               #0x69f3a4
    // 0x69f3a0: mov             x0, x1
    // 0x69f3a4: LeaveFrame
    //     0x69f3a4: mov             SP, fp
    //     0x69f3a8: ldp             fp, lr, [SP], #0x10
    // 0x69f3ac: ret
    //     0x69f3ac: ret             
    // 0x69f3b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f3b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f3b4: b               #0x69f334
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f3b8, size: 0xa8
    // 0x69f3b8: EnterFrame
    //     0x69f3b8: stp             fp, lr, [SP, #-0x10]!
    //     0x69f3bc: mov             fp, SP
    // 0x69f3c0: AllocStack(0x8)
    //     0x69f3c0: sub             SP, SP, #8
    // 0x69f3c4: SetupParameters([dynamic _ /* r0 */])
    //     0x69f3c4: ldr             x0, [fp, #0x10]
    //     0x69f3c8: ldur            w1, [x0, #0x17]
    //     0x69f3cc: add             x1, x1, HEAP, lsl #32
    // 0x69f3d0: CheckStackOverflow
    //     0x69f3d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f3d4: cmp             SP, x16
    //     0x69f3d8: b.ls            #0x69f458
    // 0x69f3dc: LoadField: r0 = r1->field_f
    //     0x69f3dc: ldur            w0, [x1, #0xf]
    // 0x69f3e0: DecompressPointer r0
    //     0x69f3e0: add             x0, x0, HEAP, lsl #32
    // 0x69f3e4: LoadField: r3 = r0->field_37
    //     0x69f3e4: ldur            w3, [x0, #0x37]
    // 0x69f3e8: DecompressPointer r3
    //     0x69f3e8: add             x3, x3, HEAP, lsl #32
    // 0x69f3ec: mov             x1, x3
    // 0x69f3f0: stur            x3, [fp, #-8]
    // 0x69f3f4: r2 = Instance_Chapter13Stat
    //     0x69f3f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11300] Obj!Chapter13Stat@85fb01
    //     0x69f3f8: ldr             x2, [x2, #0x300]
    // 0x69f3fc: r0 = _getValueOrData()
    //     0x69f3fc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f400: mov             x1, x0
    // 0x69f404: ldur            x0, [fp, #-8]
    // 0x69f408: LoadField: r2 = r0->field_f
    //     0x69f408: ldur            w2, [x0, #0xf]
    // 0x69f40c: DecompressPointer r2
    //     0x69f40c: add             x2, x2, HEAP, lsl #32
    // 0x69f410: cmp             w2, w1
    // 0x69f414: b.ne            #0x69f41c
    // 0x69f418: r1 = Null
    //     0x69f418: mov             x1, NULL
    // 0x69f41c: cmp             w1, NULL
    // 0x69f420: b.ne            #0x69f42c
    // 0x69f424: r1 = Null
    //     0x69f424: mov             x1, NULL
    // 0x69f428: b               #0x69f438
    // 0x69f42c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69f42c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69f430: r0 = toStringConsistentDecimalPlaces()
    //     0x69f430: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69f434: mov             x1, x0
    // 0x69f438: cmp             w1, NULL
    // 0x69f43c: b.ne            #0x69f448
    // 0x69f440: r0 = "0"
    //     0x69f440: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69f444: b               #0x69f44c
    // 0x69f448: mov             x0, x1
    // 0x69f44c: LeaveFrame
    //     0x69f44c: mov             SP, fp
    //     0x69f450: ldp             fp, lr, [SP], #0x10
    // 0x69f454: ret
    //     0x69f454: ret             
    // 0x69f458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f458: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f45c: b               #0x69f3dc
  }
  [closure] GeneratorInfo<Chapter13Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x69f460, size: 0x3c
    // 0x69f460: EnterFrame
    //     0x69f460: stp             fp, lr, [SP, #-0x10]!
    //     0x69f464: mov             fp, SP
    // 0x69f468: ldr             x0, [fp, #0x18]
    // 0x69f46c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69f46c: ldur            w1, [x0, #0x17]
    // 0x69f470: DecompressPointer r1
    //     0x69f470: add             x1, x1, HEAP, lsl #32
    // 0x69f474: CheckStackOverflow
    //     0x69f474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f478: cmp             SP, x16
    //     0x69f47c: b.ls            #0x69f494
    // 0x69f480: ldr             x2, [fp, #0x10]
    // 0x69f484: r0 = getGeneratorInfo()
    //     0x69f484: bl              #0x80d28c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorInfo
    // 0x69f488: LeaveFrame
    //     0x69f488: mov             SP, fp
    //     0x69f48c: ldp             fp, lr, [SP], #0x10
    // 0x69f490: ret
    //     0x69f490: ret             
    // 0x69f494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f494: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f498: b               #0x69f480
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f49c, size: 0xa8
    // 0x69f49c: EnterFrame
    //     0x69f49c: stp             fp, lr, [SP, #-0x10]!
    //     0x69f4a0: mov             fp, SP
    // 0x69f4a4: AllocStack(0x8)
    //     0x69f4a4: sub             SP, SP, #8
    // 0x69f4a8: SetupParameters([dynamic _ /* r0 */])
    //     0x69f4a8: ldr             x0, [fp, #0x10]
    //     0x69f4ac: ldur            w1, [x0, #0x17]
    //     0x69f4b0: add             x1, x1, HEAP, lsl #32
    // 0x69f4b4: CheckStackOverflow
    //     0x69f4b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f4b8: cmp             SP, x16
    //     0x69f4bc: b.ls            #0x69f53c
    // 0x69f4c0: LoadField: r0 = r1->field_f
    //     0x69f4c0: ldur            w0, [x1, #0xf]
    // 0x69f4c4: DecompressPointer r0
    //     0x69f4c4: add             x0, x0, HEAP, lsl #32
    // 0x69f4c8: LoadField: r3 = r0->field_37
    //     0x69f4c8: ldur            w3, [x0, #0x37]
    // 0x69f4cc: DecompressPointer r3
    //     0x69f4cc: add             x3, x3, HEAP, lsl #32
    // 0x69f4d0: mov             x1, x3
    // 0x69f4d4: stur            x3, [fp, #-8]
    // 0x69f4d8: r2 = Instance_Chapter13Stat
    //     0x69f4d8: add             x2, PP, #0x11, lsl #12  ; [pp+0x112e0] Obj!Chapter13Stat@85fb41
    //     0x69f4dc: ldr             x2, [x2, #0x2e0]
    // 0x69f4e0: r0 = _getValueOrData()
    //     0x69f4e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69f4e4: mov             x1, x0
    // 0x69f4e8: ldur            x0, [fp, #-8]
    // 0x69f4ec: LoadField: r2 = r0->field_f
    //     0x69f4ec: ldur            w2, [x0, #0xf]
    // 0x69f4f0: DecompressPointer r2
    //     0x69f4f0: add             x2, x2, HEAP, lsl #32
    // 0x69f4f4: cmp             w2, w1
    // 0x69f4f8: b.ne            #0x69f500
    // 0x69f4fc: r1 = Null
    //     0x69f4fc: mov             x1, NULL
    // 0x69f500: cmp             w1, NULL
    // 0x69f504: b.ne            #0x69f510
    // 0x69f508: r1 = Null
    //     0x69f508: mov             x1, NULL
    // 0x69f50c: b               #0x69f51c
    // 0x69f510: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x69f510: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x69f514: r0 = toStringConsistentDecimalPlaces()
    //     0x69f514: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x69f518: mov             x1, x0
    // 0x69f51c: cmp             w1, NULL
    // 0x69f520: b.ne            #0x69f52c
    // 0x69f524: r0 = "0"
    //     0x69f524: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x69f528: b               #0x69f530
    // 0x69f52c: mov             x0, x1
    // 0x69f530: LeaveFrame
    //     0x69f530: mov             SP, fp
    //     0x69f534: ldp             fp, lr, [SP], #0x10
    // 0x69f538: ret
    //     0x69f538: ret             
    // 0x69f53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f53c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f540: b               #0x69f4c0
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69f544, size: 0x4c
    // 0x69f544: EnterFrame
    //     0x69f544: stp             fp, lr, [SP, #-0x10]!
    //     0x69f548: mov             fp, SP
    // 0x69f54c: ldr             x0, [fp, #0x10]
    // 0x69f550: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69f550: ldur            w1, [x0, #0x17]
    // 0x69f554: DecompressPointer r1
    //     0x69f554: add             x1, x1, HEAP, lsl #32
    // 0x69f558: CheckStackOverflow
    //     0x69f558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f55c: cmp             SP, x16
    //     0x69f560: b.ls            #0x69f588
    // 0x69f564: LoadField: r0 = r1->field_f
    //     0x69f564: ldur            w0, [x1, #0xf]
    // 0x69f568: DecompressPointer r0
    //     0x69f568: add             x0, x0, HEAP, lsl #32
    // 0x69f56c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69f56c: ldur            w1, [x0, #0x17]
    // 0x69f570: DecompressPointer r1
    //     0x69f570: add             x1, x1, HEAP, lsl #32
    // 0x69f574: r2 = 82
    //     0x69f574: movz            x2, #0x52
    // 0x69f578: r0 = contains()
    //     0x69f578: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x69f57c: LeaveFrame
    //     0x69f57c: mov             SP, fp
    //     0x69f580: ldp             fp, lr, [SP], #0x10
    // 0x69f584: ret
    //     0x69f584: ret             
    // 0x69f588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f588: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f58c: b               #0x69f564
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f590, size: 0xd0
    // 0x69f590: EnterFrame
    //     0x69f590: stp             fp, lr, [SP, #-0x10]!
    //     0x69f594: mov             fp, SP
    // 0x69f598: AllocStack(0x10)
    //     0x69f598: sub             SP, SP, #0x10
    // 0x69f59c: SetupParameters([dynamic _ /* r0 */])
    //     0x69f59c: ldr             x0, [fp, #0x10]
    //     0x69f5a0: ldur            w1, [x0, #0x17]
    //     0x69f5a4: add             x1, x1, HEAP, lsl #32
    // 0x69f5a8: CheckStackOverflow
    //     0x69f5a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f5ac: cmp             SP, x16
    //     0x69f5b0: b.ls            #0x69f64c
    // 0x69f5b4: LoadField: r0 = r1->field_f
    //     0x69f5b4: ldur            w0, [x1, #0xf]
    // 0x69f5b8: DecompressPointer r0
    //     0x69f5b8: add             x0, x0, HEAP, lsl #32
    // 0x69f5bc: LoadField: r3 = r0->field_8b
    //     0x69f5bc: ldur            x3, [x0, #0x8b]
    // 0x69f5c0: stur            x3, [fp, #-8]
    // 0x69f5c4: LoadField: r1 = r0->field_9f
    //     0x69f5c4: ldur            w1, [x0, #0x9f]
    // 0x69f5c8: DecompressPointer r1
    //     0x69f5c8: add             x1, x1, HEAP, lsl #32
    // 0x69f5cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69f5d0: cmp             w1, w16
    // 0x69f5d4: b.eq            #0x69f654
    // 0x69f5d8: LoadField: r0 = r1->field_b
    //     0x69f5d8: ldur            w0, [x1, #0xb]
    // 0x69f5dc: r1 = LoadInt32Instr(r0)
    //     0x69f5dc: sbfx            x1, x0, #1, #0x1f
    // 0x69f5e0: cmp             x3, x1
    // 0x69f5e4: b.lt            #0x69f5fc
    // 0x69f5e8: r0 = "Max Level"
    //     0x69f5e8: add             x0, PP, #0x29, lsl #12  ; [pp+0x29008] "Max Level"
    //     0x69f5ec: ldr             x0, [x0, #8]
    // 0x69f5f0: LeaveFrame
    //     0x69f5f0: mov             SP, fp
    //     0x69f5f4: ldp             fp, lr, [SP], #0x10
    // 0x69f5f8: ret
    //     0x69f5f8: ret             
    // 0x69f5fc: r1 = Null
    //     0x69f5fc: mov             x1, NULL
    // 0x69f600: r2 = 4
    //     0x69f600: movz            x2, #0x4
    // 0x69f604: r0 = AllocateArray()
    //     0x69f604: bl              #0x82746c  ; AllocateArrayStub
    // 0x69f608: mov             x2, x0
    // 0x69f60c: r16 = "Upgrade Research "
    //     0x69f60c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29010] "Upgrade Research "
    //     0x69f610: ldr             x16, [x16, #0x10]
    // 0x69f614: StoreField: r2->field_f = r16
    //     0x69f614: stur            w16, [x2, #0xf]
    // 0x69f618: ldur            x0, [fp, #-8]
    // 0x69f61c: add             x3, x0, #1
    // 0x69f620: r0 = BoxInt64Instr(r3)
    //     0x69f620: sbfiz           x0, x3, #1, #0x1f
    //     0x69f624: cmp             x3, x0, asr #1
    //     0x69f628: b.eq            #0x69f634
    //     0x69f62c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x69f630: stur            x3, [x0, #7]
    // 0x69f634: StoreField: r2->field_13 = r0
    //     0x69f634: stur            w0, [x2, #0x13]
    // 0x69f638: str             x2, [SP]
    // 0x69f63c: r0 = _interpolate()
    //     0x69f63c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69f640: LeaveFrame
    //     0x69f640: mov             SP, fp
    //     0x69f644: ldp             fp, lr, [SP], #0x10
    // 0x69f648: ret
    //     0x69f648: ret             
    // 0x69f64c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f64c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f650: b               #0x69f5b4
    // 0x69f654: r9 = researchLevels
    //     0x69f654: add             x9, PP, #0x28, lsl #12  ; [pp+0x28fc0] Field <Chapter13GameState.researchLevels>: late (offset: 0xa0)
    //     0x69f658: ldr             x9, [x9, #0xfc0]
    // 0x69f65c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69f65c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter13Stat, CustomNum> <anonymous closure>(dynamic) {
    // ** addr: 0x69f660, size: 0xd4
    // 0x69f660: EnterFrame
    //     0x69f660: stp             fp, lr, [SP, #-0x10]!
    //     0x69f664: mov             fp, SP
    // 0x69f668: AllocStack(0x8)
    //     0x69f668: sub             SP, SP, #8
    // 0x69f66c: SetupParameters([dynamic _ /* r0 */])
    //     0x69f66c: ldr             x0, [fp, #0x10]
    //     0x69f670: ldur            w1, [x0, #0x17]
    //     0x69f674: add             x1, x1, HEAP, lsl #32
    // 0x69f678: CheckStackOverflow
    //     0x69f678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f67c: cmp             SP, x16
    //     0x69f680: b.ls            #0x69f71c
    // 0x69f684: LoadField: r0 = r1->field_f
    //     0x69f684: ldur            w0, [x1, #0xf]
    // 0x69f688: DecompressPointer r0
    //     0x69f688: add             x0, x0, HEAP, lsl #32
    // 0x69f68c: LoadField: r2 = r0->field_8b
    //     0x69f68c: ldur            x2, [x0, #0x8b]
    // 0x69f690: LoadField: r3 = r0->field_9f
    //     0x69f690: ldur            w3, [x0, #0x9f]
    // 0x69f694: DecompressPointer r3
    //     0x69f694: add             x3, x3, HEAP, lsl #32
    // 0x69f698: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x69f69c: cmp             w3, w16
    // 0x69f6a0: b.eq            #0x69f724
    // 0x69f6a4: LoadField: r0 = r3->field_b
    //     0x69f6a4: ldur            w0, [x3, #0xb]
    // 0x69f6a8: r1 = LoadInt32Instr(r0)
    //     0x69f6a8: sbfx            x1, x0, #1, #0x1f
    // 0x69f6ac: cmp             x2, x1
    // 0x69f6b0: b.ge            #0x69f6e4
    // 0x69f6b4: r1 = LoadInt32Instr(r0)
    //     0x69f6b4: sbfx            x1, x0, #1, #0x1f
    // 0x69f6b8: mov             x0, x1
    // 0x69f6bc: mov             x1, x2
    // 0x69f6c0: cmp             x1, x0
    // 0x69f6c4: b.hs            #0x69f730
    // 0x69f6c8: LoadField: r0 = r3->field_f
    //     0x69f6c8: ldur            w0, [x3, #0xf]
    // 0x69f6cc: DecompressPointer r0
    //     0x69f6cc: add             x0, x0, HEAP, lsl #32
    // 0x69f6d0: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x69f6d0: add             x16, x0, x2, lsl #2
    //     0x69f6d4: ldur            w1, [x16, #0xf]
    // 0x69f6d8: DecompressPointer r1
    //     0x69f6d8: add             x1, x1, HEAP, lsl #32
    // 0x69f6dc: mov             x0, x1
    // 0x69f6e0: b               #0x69f6ec
    // 0x69f6e4: mov             x1, x3
    // 0x69f6e8: r0 = last()
    //     0x69f6e8: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x69f6ec: stur            x0, [fp, #-8]
    // 0x69f6f0: r1 = <Chapter13Stat, CustomNum>
    //     0x69f6f0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6c8] TypeArguments: <Chapter13Stat, CustomNum>
    //     0x69f6f4: ldr             x1, [x1, #0x6c8]
    // 0x69f6f8: r0 = Tuple2()
    //     0x69f6f8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x69f6fc: r1 = Instance_Chapter13Stat
    //     0x69f6fc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11298] Obj!Chapter13Stat@85f9e1
    //     0x69f700: ldr             x1, [x1, #0x298]
    // 0x69f704: StoreField: r0->field_b = r1
    //     0x69f704: stur            w1, [x0, #0xb]
    // 0x69f708: ldur            x1, [fp, #-8]
    // 0x69f70c: StoreField: r0->field_f = r1
    //     0x69f70c: stur            w1, [x0, #0xf]
    // 0x69f710: LeaveFrame
    //     0x69f710: mov             SP, fp
    //     0x69f714: ldp             fp, lr, [SP], #0x10
    // 0x69f718: ret
    //     0x69f718: ret             
    // 0x69f71c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f71c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f720: b               #0x69f684
    // 0x69f724: r9 = researchLevels
    //     0x69f724: add             x9, PP, #0x28, lsl #12  ; [pp+0x28fc0] Field <Chapter13GameState.researchLevels>: late (offset: 0xa0)
    //     0x69f728: ldr             x9, [x9, #0xfc0]
    // 0x69f72c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69f72c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x69f730: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69f730: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x69f734, size: 0x48
    // 0x69f734: EnterFrame
    //     0x69f734: stp             fp, lr, [SP, #-0x10]!
    //     0x69f738: mov             fp, SP
    // 0x69f73c: ldr             x0, [fp, #0x10]
    // 0x69f740: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69f740: ldur            w1, [x0, #0x17]
    // 0x69f744: DecompressPointer r1
    //     0x69f744: add             x1, x1, HEAP, lsl #32
    // 0x69f748: CheckStackOverflow
    //     0x69f748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f74c: cmp             SP, x16
    //     0x69f750: b.ls            #0x69f774
    // 0x69f754: LoadField: r0 = r1->field_f
    //     0x69f754: ldur            w0, [x1, #0xf]
    // 0x69f758: DecompressPointer r0
    //     0x69f758: add             x0, x0, HEAP, lsl #32
    // 0x69f75c: mov             x1, x0
    // 0x69f760: r0 = upgradeResearch()
    //     0x69f760: bl              #0x69f77c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::upgradeResearch
    // 0x69f764: r0 = Null
    //     0x69f764: mov             x0, NULL
    // 0x69f768: LeaveFrame
    //     0x69f768: mov             SP, fp
    //     0x69f76c: ldp             fp, lr, [SP], #0x10
    // 0x69f770: ret
    //     0x69f770: ret             
    // 0x69f774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f774: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f778: b               #0x69f754
  }
  _ upgradeResearch(/* No info */) {
    // ** addr: 0x69f77c, size: 0x70
    // 0x69f77c: EnterFrame
    //     0x69f77c: stp             fp, lr, [SP, #-0x10]!
    //     0x69f780: mov             fp, SP
    // 0x69f784: AllocStack(0x8)
    //     0x69f784: sub             SP, SP, #8
    // 0x69f788: SetupParameters(Chapter13GameState this /* r1 => r0, fp-0x8 */)
    //     0x69f788: mov             x0, x1
    //     0x69f78c: stur            x1, [fp, #-8]
    // 0x69f790: CheckStackOverflow
    //     0x69f790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69f794: cmp             SP, x16
    //     0x69f798: b.ls            #0x69f7e4
    // 0x69f79c: LoadField: r1 = r0->field_43
    //     0x69f79c: ldur            w1, [x0, #0x43]
    // 0x69f7a0: DecompressPointer r1
    //     0x69f7a0: add             x1, x1, HEAP, lsl #32
    // 0x69f7a4: r2 = 60
    //     0x69f7a4: movz            x2, #0x3c
    // 0x69f7a8: r0 = containsKey()
    //     0x69f7a8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69f7ac: tbnz            w0, #4, #0x69f7bc
    // 0x69f7b0: ldur            x1, [fp, #-8]
    // 0x69f7b4: r0 = applyResearchPrestige()
    //     0x69f7b4: bl              #0x69eb38  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::applyResearchPrestige
    // 0x69f7b8: b               #0x69f7c4
    // 0x69f7bc: ldur            x1, [fp, #-8]
    // 0x69f7c0: r0 = researchReset()
    //     0x69f7c0: bl              #0x69ec5c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::researchReset
    // 0x69f7c4: ldur            x1, [fp, #-8]
    // 0x69f7c8: LoadField: r2 = r1->field_8b
    //     0x69f7c8: ldur            x2, [x1, #0x8b]
    // 0x69f7cc: add             x3, x2, #1
    // 0x69f7d0: StoreField: r1->field_8b = r3
    //     0x69f7d0: stur            x3, [x1, #0x8b]
    // 0x69f7d4: r0 = Null
    //     0x69f7d4: mov             x0, NULL
    // 0x69f7d8: LeaveFrame
    //     0x69f7d8: mov             SP, fp
    //     0x69f7dc: ldp             fp, lr, [SP], #0x10
    // 0x69f7e0: ret
    //     0x69f7e0: ret             
    // 0x69f7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69f7e4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69f7e8: b               #0x69f79c
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69f7ec, size: 0xc
    // 0x69f7ec: r0 = "Upgrade Research"
    //     0x69f7ec: add             x0, PP, #0x29, lsl #12  ; [pp+0x29018] "Upgrade Research"
    //     0x69f7f0: ldr             x0, [x0, #0x18]
    // 0x69f7f4: ret
    //     0x69f7f4: ret             
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d28c, size: 0x7c
    // 0x80d28c: EnterFrame
    //     0x80d28c: stp             fp, lr, [SP, #-0x10]!
    //     0x80d290: mov             fp, SP
    // 0x80d294: AllocStack(0x8)
    //     0x80d294: sub             SP, SP, #8
    // 0x80d298: CheckStackOverflow
    //     0x80d298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d29c: cmp             SP, x16
    //     0x80d2a0: b.ls            #0x80d2f0
    // 0x80d2a4: LoadField: r0 = r1->field_93
    //     0x80d2a4: ldur            w0, [x1, #0x93]
    // 0x80d2a8: DecompressPointer r0
    //     0x80d2a8: add             x0, x0, HEAP, lsl #32
    // 0x80d2ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d2b0: cmp             w0, w16
    // 0x80d2b4: b.eq            #0x80d2f8
    // 0x80d2b8: mov             x1, x0
    // 0x80d2bc: stur            x0, [fp, #-8]
    // 0x80d2c0: r0 = _getValueOrData()
    //     0x80d2c0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d2c4: ldur            x1, [fp, #-8]
    // 0x80d2c8: LoadField: r2 = r1->field_f
    //     0x80d2c8: ldur            w2, [x1, #0xf]
    // 0x80d2cc: DecompressPointer r2
    //     0x80d2cc: add             x2, x2, HEAP, lsl #32
    // 0x80d2d0: cmp             w2, w0
    // 0x80d2d4: b.ne            #0x80d2dc
    // 0x80d2d8: r0 = Null
    //     0x80d2d8: mov             x0, NULL
    // 0x80d2dc: cmp             w0, NULL
    // 0x80d2e0: b.eq            #0x80d304
    // 0x80d2e4: LeaveFrame
    //     0x80d2e4: mov             SP, fp
    //     0x80d2e8: ldp             fp, lr, [SP], #0x10
    // 0x80d2ec: ret
    //     0x80d2ec: ret             
    // 0x80d2f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d2f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d2f4: b               #0x80d2a4
    // 0x80d2f8: r9 = generators
    //     0x80d2f8: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a6d0] Field <Chapter13GameState.generators>: late (offset: 0x94)
    //     0x80d2fc: ldr             x9, [x9, #0x6d0]
    // 0x80d300: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d300: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d304: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d12c, size: 0xc
    // 0x81d12c: r0 = "13"
    //     0x81d12c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x81d130: ldr             x0, [x0, #0x338]
    // 0x81d134: ret
    //     0x81d134: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f6a8, size: 0x24
    // 0x81f6a8: EnterFrame
    //     0x81f6a8: stp             fp, lr, [SP, #-0x10]!
    //     0x81f6ac: mov             fp, SP
    // 0x81f6b0: ldr             x2, [fp, #0x10]
    // 0x81f6b4: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f6b4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb00] AnonymousClosure: (0x3daed4), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getCostToBuyOneMoreGenerator (0x3dad94)
    //     0x81f6b8: ldr             x1, [x1, #0xb00]
    // 0x81f6bc: r0 = AllocateClosure()
    //     0x81f6bc: bl              #0x826750  ; AllocateClosureStub
    // 0x81f6c0: LeaveFrame
    //     0x81f6c0: mov             SP, fp
    //     0x81f6c4: ldp             fp, lr, [SP], #0x10
    // 0x81f6c8: ret
    //     0x81f6c8: ret             
  }
}

// class id: 2848, size: 0x14, field offset: 0xc
//   const constructor, 
class AutobuySwitchWrapper extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72c540, size: 0x24
    // 0x72c540: EnterFrame
    //     0x72c540: stp             fp, lr, [SP, #-0x10]!
    //     0x72c544: mov             fp, SP
    // 0x72c548: mov             x0, x1
    // 0x72c54c: r1 = <AutobuySwitchWrapper>
    //     0x72c54c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2a350] TypeArguments: <AutobuySwitchWrapper>
    //     0x72c550: ldr             x1, [x1, #0x350]
    // 0x72c554: r0 = _AutobuySwitchWrapperState()
    //     0x72c554: bl              #0x72c564  ; Allocate_AutobuySwitchWrapperStateStub -> _AutobuySwitchWrapperState (size=0x14)
    // 0x72c558: LeaveFrame
    //     0x72c558: mov             SP, fp
    //     0x72c55c: ldp             fp, lr, [SP], #0x10
    // 0x72c560: ret
    //     0x72c560: ret             
  }
}

// class id: 3268, size: 0x14, field offset: 0x14
class _AutobuySwitchWrapperState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x637964, size: 0x9c
    // 0x637964: EnterFrame
    //     0x637964: stp             fp, lr, [SP, #-0x10]!
    //     0x637968: mov             fp, SP
    // 0x63796c: AllocStack(0x10)
    //     0x63796c: sub             SP, SP, #0x10
    // 0x637970: SetupParameters(_AutobuySwitchWrapperState this /* r1 => r1, fp-0x8 */)
    //     0x637970: stur            x1, [fp, #-8]
    // 0x637974: r1 = 1
    //     0x637974: movz            x1, #0x1
    // 0x637978: r0 = AllocateContext()
    //     0x637978: bl              #0x82637c  ; AllocateContextStub
    // 0x63797c: mov             x1, x0
    // 0x637980: ldur            x0, [fp, #-8]
    // 0x637984: stur            x1, [fp, #-0x10]
    // 0x637988: StoreField: r1->field_f = r0
    //     0x637988: stur            w0, [x1, #0xf]
    // 0x63798c: r0 = AutoBuyChip()
    //     0x63798c: bl              #0x637a20  ; AllocateAutoBuyChipStub -> AutoBuyChip (size=0x18)
    // 0x637990: mov             x3, x0
    // 0x637994: r0 = "Auto"
    //     0x637994: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b8] "Auto"
    //     0x637998: ldr             x0, [x0, #0x6b8]
    // 0x63799c: stur            x3, [fp, #-8]
    // 0x6379a0: StoreField: r3->field_b = r0
    //     0x6379a0: stur            w0, [x3, #0xb]
    // 0x6379a4: ldur            x2, [fp, #-0x10]
    // 0x6379a8: r1 = Function '<anonymous closure>':.
    //     0x6379a8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c430] AnonymousClosure: (0x637b38), in [package:pretentious/data/Chapters/Chapter13GameState.dart] _AutobuySwitchWrapperState::build (0x637964)
    //     0x6379ac: ldr             x1, [x1, #0x430]
    // 0x6379b0: r0 = AllocateClosure()
    //     0x6379b0: bl              #0x826750  ; AllocateClosureStub
    // 0x6379b4: mov             x1, x0
    // 0x6379b8: ldur            x0, [fp, #-8]
    // 0x6379bc: StoreField: r0->field_f = r1
    //     0x6379bc: stur            w1, [x0, #0xf]
    // 0x6379c0: ldur            x2, [fp, #-0x10]
    // 0x6379c4: r1 = Function '<anonymous closure>':.
    //     0x6379c4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c438] AnonymousClosure: (0x637a4c), in [package:pretentious/data/Chapters/Chapter13GameState.dart] _AutobuySwitchWrapperState::build (0x637964)
    //     0x6379c8: ldr             x1, [x1, #0x438]
    // 0x6379cc: r0 = AllocateClosure()
    //     0x6379cc: bl              #0x826750  ; AllocateClosureStub
    // 0x6379d0: mov             x1, x0
    // 0x6379d4: ldur            x0, [fp, #-8]
    // 0x6379d8: StoreField: r0->field_13 = r1
    //     0x6379d8: stur            w1, [x0, #0x13]
    // 0x6379dc: r0 = Padding()
    //     0x6379dc: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6379e0: r1 = Instance_EdgeInsets
    //     0x6379e0: add             x1, PP, #0x25, lsl #12  ; [pp+0x25a90] Obj!EdgeInsets@832911
    //     0x6379e4: ldr             x1, [x1, #0xa90]
    // 0x6379e8: StoreField: r0->field_f = r1
    //     0x6379e8: stur            w1, [x0, #0xf]
    // 0x6379ec: ldur            x1, [fp, #-8]
    // 0x6379f0: StoreField: r0->field_b = r1
    //     0x6379f0: stur            w1, [x0, #0xb]
    // 0x6379f4: LeaveFrame
    //     0x6379f4: mov             SP, fp
    //     0x6379f8: ldp             fp, lr, [SP], #0x10
    // 0x6379fc: ret
    //     0x6379fc: ret             
  }
  [closure] void <anonymous closure>(dynamic, bool?) {
    // ** addr: 0x637a4c, size: 0xec
    // 0x637a4c: EnterFrame
    //     0x637a4c: stp             fp, lr, [SP, #-0x10]!
    //     0x637a50: mov             fp, SP
    // 0x637a54: ldr             x0, [fp, #0x18]
    // 0x637a58: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x637a58: ldur            w1, [x0, #0x17]
    // 0x637a5c: DecompressPointer r1
    //     0x637a5c: add             x1, x1, HEAP, lsl #32
    // 0x637a60: CheckStackOverflow
    //     0x637a60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x637a64: cmp             SP, x16
    //     0x637a68: b.ls            #0x637b28
    // 0x637a6c: ldr             x0, [fp, #0x10]
    // 0x637a70: cmp             w0, NULL
    // 0x637a74: b.eq            #0x637acc
    // 0x637a78: tbnz            w0, #4, #0x637acc
    // 0x637a7c: LoadField: r0 = r1->field_f
    //     0x637a7c: ldur            w0, [x1, #0xf]
    // 0x637a80: DecompressPointer r0
    //     0x637a80: add             x0, x0, HEAP, lsl #32
    // 0x637a84: LoadField: r1 = r0->field_b
    //     0x637a84: ldur            w1, [x0, #0xb]
    // 0x637a88: DecompressPointer r1
    //     0x637a88: add             x1, x1, HEAP, lsl #32
    // 0x637a8c: cmp             w1, NULL
    // 0x637a90: b.eq            #0x637b30
    // 0x637a94: LoadField: r2 = r1->field_f
    //     0x637a94: ldur            w2, [x1, #0xf]
    // 0x637a98: DecompressPointer r2
    //     0x637a98: add             x2, x2, HEAP, lsl #32
    // 0x637a9c: LoadField: r0 = r1->field_b
    //     0x637a9c: ldur            w0, [x1, #0xb]
    // 0x637aa0: DecompressPointer r0
    //     0x637aa0: add             x0, x0, HEAP, lsl #32
    // 0x637aa4: LoadField: r3 = r0->field_7
    //     0x637aa4: ldur            x3, [x0, #7]
    // 0x637aa8: r0 = BoxInt64Instr(r3)
    //     0x637aa8: sbfiz           x0, x3, #1, #0x1f
    //     0x637aac: cmp             x3, x0, asr #1
    //     0x637ab0: b.eq            #0x637abc
    //     0x637ab4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x637ab8: stur            x3, [x0, #7]
    // 0x637abc: mov             x1, x2
    // 0x637ac0: mov             x2, x0
    // 0x637ac4: r0 = add()
    //     0x637ac4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x637ac8: b               #0x637b18
    // 0x637acc: LoadField: r0 = r1->field_f
    //     0x637acc: ldur            w0, [x1, #0xf]
    // 0x637ad0: DecompressPointer r0
    //     0x637ad0: add             x0, x0, HEAP, lsl #32
    // 0x637ad4: LoadField: r1 = r0->field_b
    //     0x637ad4: ldur            w1, [x0, #0xb]
    // 0x637ad8: DecompressPointer r1
    //     0x637ad8: add             x1, x1, HEAP, lsl #32
    // 0x637adc: cmp             w1, NULL
    // 0x637ae0: b.eq            #0x637b34
    // 0x637ae4: LoadField: r2 = r1->field_f
    //     0x637ae4: ldur            w2, [x1, #0xf]
    // 0x637ae8: DecompressPointer r2
    //     0x637ae8: add             x2, x2, HEAP, lsl #32
    // 0x637aec: LoadField: r0 = r1->field_b
    //     0x637aec: ldur            w0, [x1, #0xb]
    // 0x637af0: DecompressPointer r0
    //     0x637af0: add             x0, x0, HEAP, lsl #32
    // 0x637af4: LoadField: r3 = r0->field_7
    //     0x637af4: ldur            x3, [x0, #7]
    // 0x637af8: r0 = BoxInt64Instr(r3)
    //     0x637af8: sbfiz           x0, x3, #1, #0x1f
    //     0x637afc: cmp             x3, x0, asr #1
    //     0x637b00: b.eq            #0x637b0c
    //     0x637b04: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x637b08: stur            x3, [x0, #7]
    // 0x637b0c: mov             x1, x2
    // 0x637b10: mov             x2, x0
    // 0x637b14: r0 = remove()
    //     0x637b14: bl              #0x7e8a40  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x637b18: r0 = Null
    //     0x637b18: mov             x0, NULL
    // 0x637b1c: LeaveFrame
    //     0x637b1c: mov             SP, fp
    //     0x637b20: ldp             fp, lr, [SP], #0x10
    // 0x637b24: ret
    //     0x637b24: ret             
    // 0x637b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x637b28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x637b2c: b               #0x637a6c
    // 0x637b30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x637b30: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x637b34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x637b34: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x637b38, size: 0x84
    // 0x637b38: EnterFrame
    //     0x637b38: stp             fp, lr, [SP, #-0x10]!
    //     0x637b3c: mov             fp, SP
    // 0x637b40: ldr             x0, [fp, #0x10]
    // 0x637b44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x637b44: ldur            w1, [x0, #0x17]
    // 0x637b48: DecompressPointer r1
    //     0x637b48: add             x1, x1, HEAP, lsl #32
    // 0x637b4c: CheckStackOverflow
    //     0x637b4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x637b50: cmp             SP, x16
    //     0x637b54: b.ls            #0x637bb0
    // 0x637b58: LoadField: r0 = r1->field_f
    //     0x637b58: ldur            w0, [x1, #0xf]
    // 0x637b5c: DecompressPointer r0
    //     0x637b5c: add             x0, x0, HEAP, lsl #32
    // 0x637b60: LoadField: r1 = r0->field_b
    //     0x637b60: ldur            w1, [x0, #0xb]
    // 0x637b64: DecompressPointer r1
    //     0x637b64: add             x1, x1, HEAP, lsl #32
    // 0x637b68: cmp             w1, NULL
    // 0x637b6c: b.eq            #0x637bb8
    // 0x637b70: LoadField: r2 = r1->field_f
    //     0x637b70: ldur            w2, [x1, #0xf]
    // 0x637b74: DecompressPointer r2
    //     0x637b74: add             x2, x2, HEAP, lsl #32
    // 0x637b78: LoadField: r0 = r1->field_b
    //     0x637b78: ldur            w0, [x1, #0xb]
    // 0x637b7c: DecompressPointer r0
    //     0x637b7c: add             x0, x0, HEAP, lsl #32
    // 0x637b80: LoadField: r3 = r0->field_7
    //     0x637b80: ldur            x3, [x0, #7]
    // 0x637b84: r0 = BoxInt64Instr(r3)
    //     0x637b84: sbfiz           x0, x3, #1, #0x1f
    //     0x637b88: cmp             x3, x0, asr #1
    //     0x637b8c: b.eq            #0x637b98
    //     0x637b90: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x637b94: stur            x3, [x0, #7]
    // 0x637b98: mov             x1, x2
    // 0x637b9c: mov             x2, x0
    // 0x637ba0: r0 = contains()
    //     0x637ba0: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x637ba4: LeaveFrame
    //     0x637ba4: mov             SP, fp
    //     0x637ba8: ldp             fp, lr, [SP], #0x10
    // 0x637bac: ret
    //     0x637bac: ret             
    // 0x637bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x637bb0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x637bb4: b               #0x637b58
    // 0x637bb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x637bb8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4185, size: 0x14, field offset: 0x14
enum Chapter13Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x7248e4, size: 0x64
    // 0x7248e4: EnterFrame
    //     0x7248e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7248e8: mov             fp, SP
    // 0x7248ec: AllocStack(0x10)
    //     0x7248ec: sub             SP, SP, #0x10
    // 0x7248f0: SetupParameters(Chapter13Stat this /* r1 => r0, fp-0x8 */)
    //     0x7248f0: mov             x0, x1
    //     0x7248f4: stur            x1, [fp, #-8]
    // 0x7248f8: CheckStackOverflow
    //     0x7248f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7248fc: cmp             SP, x16
    //     0x724900: b.ls            #0x724940
    // 0x724904: r1 = Null
    //     0x724904: mov             x1, NULL
    // 0x724908: r2 = 4
    //     0x724908: movz            x2, #0x4
    // 0x72490c: r0 = AllocateArray()
    //     0x72490c: bl              #0x82746c  ; AllocateArrayStub
    // 0x724910: r16 = "Chapter13Stat."
    //     0x724910: add             x16, PP, #0x15, lsl #12  ; [pp+0x158f0] "Chapter13Stat."
    //     0x724914: ldr             x16, [x16, #0x8f0]
    // 0x724918: StoreField: r0->field_f = r16
    //     0x724918: stur            w16, [x0, #0xf]
    // 0x72491c: ldur            x1, [fp, #-8]
    // 0x724920: LoadField: r2 = r1->field_f
    //     0x724920: ldur            w2, [x1, #0xf]
    // 0x724924: DecompressPointer r2
    //     0x724924: add             x2, x2, HEAP, lsl #32
    // 0x724928: StoreField: r0->field_13 = r2
    //     0x724928: stur            w2, [x0, #0x13]
    // 0x72492c: str             x0, [SP]
    // 0x724930: r0 = _interpolate()
    //     0x724930: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724934: LeaveFrame
    //     0x724934: mov             SP, fp
    //     0x724938: ldp             fp, lr, [SP], #0x10
    // 0x72493c: ret
    //     0x72493c: ret             
    // 0x724940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724940: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724944: b               #0x724904
  }
}
