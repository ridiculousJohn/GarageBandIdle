// lib: , url: package:pretentious/data/Chapters/Chapter11GameState.dart

// class id: 1049448, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46d8e0, size: 0x114
    // 0x46d8e0: cmp             w1, NULL
    // 0x46d8e4: b.ne            #0x46d8f0
    // 0x46d8e8: r0 = ""
    //     0x46d8e8: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46d8ec: ret
    //     0x46d8ec: ret             
    // 0x46d8f0: r16 = Instance_Chapter11Stat
    //     0x46d8f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x46d8f4: ldr             x16, [x16, #0x5a0]
    // 0x46d8f8: cmp             w1, w16
    // 0x46d8fc: b.ne            #0x46d90c
    // 0x46d900: r0 = "Associates"
    //     0x46d900: add             x0, PP, #0x11, lsl #12  ; [pp+0x115a8] "Associates"
    //     0x46d904: ldr             x0, [x0, #0x5a8]
    // 0x46d908: ret
    //     0x46d908: ret             
    // 0x46d90c: r16 = Instance_Chapter11Stat
    //     0x46d90c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x46d910: ldr             x16, [x16, #0x5b0]
    // 0x46d914: cmp             w1, w16
    // 0x46d918: b.ne            #0x46d928
    // 0x46d91c: r0 = "Engagement"
    //     0x46d91c: add             x0, PP, #0x11, lsl #12  ; [pp+0x115b8] "Engagement"
    //     0x46d920: ldr             x0, [x0, #0x5b8]
    // 0x46d924: ret
    //     0x46d924: ret             
    // 0x46d928: r16 = Instance_Chapter11Stat
    //     0x46d928: add             x16, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x46d92c: ldr             x16, [x16, #0x5c0]
    // 0x46d930: cmp             w1, w16
    // 0x46d934: b.ne            #0x46d944
    // 0x46d938: r0 = "Silver Members"
    //     0x46d938: add             x0, PP, #0x11, lsl #12  ; [pp+0x115c8] "Silver Members"
    //     0x46d93c: ldr             x0, [x0, #0x5c8]
    // 0x46d940: ret
    //     0x46d940: ret             
    // 0x46d944: r16 = Instance_Chapter11Stat
    //     0x46d944: add             x16, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x46d948: ldr             x16, [x16, #0x5d0]
    // 0x46d94c: cmp             w1, w16
    // 0x46d950: b.ne            #0x46d960
    // 0x46d954: r0 = "Velocity"
    //     0x46d954: add             x0, PP, #0x11, lsl #12  ; [pp+0x115d8] "Velocity"
    //     0x46d958: ldr             x0, [x0, #0x5d8]
    // 0x46d95c: ret
    //     0x46d95c: ret             
    // 0x46d960: r16 = Instance_Chapter11Stat
    //     0x46d960: add             x16, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x46d964: ldr             x16, [x16, #0x5e0]
    // 0x46d968: cmp             w1, w16
    // 0x46d96c: b.ne            #0x46d97c
    // 0x46d970: r0 = "Gold Members"
    //     0x46d970: add             x0, PP, #0x11, lsl #12  ; [pp+0x115e8] "Gold Members"
    //     0x46d974: ldr             x0, [x0, #0x5e8]
    // 0x46d978: ret
    //     0x46d978: ret             
    // 0x46d97c: r16 = Instance_Chapter11Stat
    //     0x46d97c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11560] Obj!Chapter11Stat@85fde1
    //     0x46d980: ldr             x16, [x16, #0x560]
    // 0x46d984: cmp             w1, w16
    // 0x46d988: b.ne            #0x46d998
    // 0x46d98c: r0 = "Accelerator"
    //     0x46d98c: add             x0, PP, #0x11, lsl #12  ; [pp+0x115f0] "Accelerator"
    //     0x46d990: ldr             x0, [x0, #0x5f0]
    // 0x46d994: ret
    //     0x46d994: ret             
    // 0x46d998: r16 = Instance_Chapter11Stat
    //     0x46d998: add             x16, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Chapter11Stat@85fdc1
    //     0x46d99c: ldr             x16, [x16, #0x568]
    // 0x46d9a0: cmp             w1, w16
    // 0x46d9a4: b.ne            #0x46d9b4
    // 0x46d9a8: r0 = "Certification"
    //     0x46d9a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x115f8] "Certification"
    //     0x46d9ac: ldr             x0, [x0, #0x5f8]
    // 0x46d9b0: ret
    //     0x46d9b0: ret             
    // 0x46d9b4: r16 = Instance_Chapter11Stat
    //     0x46d9b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11570] Obj!Chapter11Stat@85fda1
    //     0x46d9b8: ldr             x16, [x16, #0x570]
    // 0x46d9bc: cmp             w1, w16
    // 0x46d9c0: b.ne            #0x46d9d0
    // 0x46d9c4: r0 = "Onboarding"
    //     0x46d9c4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11600] "Onboarding"
    //     0x46d9c8: ldr             x0, [x0, #0x600]
    // 0x46d9cc: ret
    //     0x46d9cc: ret             
    // 0x46d9d0: r16 = Instance_Chapter11Stat
    //     0x46d9d0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x46d9d4: ldr             x16, [x16, #0x608]
    // 0x46d9d8: cmp             w1, w16
    // 0x46d9dc: b.ne            #0x46d9ec
    // 0x46d9e0: r0 = "Titanium Members"
    //     0x46d9e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11610] "Titanium Members"
    //     0x46d9e4: ldr             x0, [x0, #0x610]
    // 0x46d9e8: ret
    //     0x46d9e8: ret             
    // 0x46d9ec: r0 = Null
    //     0x46d9ec: mov             x0, NULL
    // 0x46d9f0: ret
    //     0x46d9f0: ret             
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46da24, size: 0x104
    // 0x46da24: r16 = Instance_Chapter11Stat
    //     0x46da24: add             x16, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x46da28: ldr             x16, [x16, #0x5a0]
    // 0x46da2c: cmp             w1, w16
    // 0x46da30: b.ne            #0x46da40
    // 0x46da34: r0 = "Associate"
    //     0x46da34: add             x0, PP, #0x11, lsl #12  ; [pp+0x11618] "Associate"
    //     0x46da38: ldr             x0, [x0, #0x618]
    // 0x46da3c: ret
    //     0x46da3c: ret             
    // 0x46da40: r16 = Instance_Chapter11Stat
    //     0x46da40: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x46da44: ldr             x16, [x16, #0x5b0]
    // 0x46da48: cmp             w1, w16
    // 0x46da4c: b.ne            #0x46da5c
    // 0x46da50: r0 = "Engmt"
    //     0x46da50: add             x0, PP, #0x11, lsl #12  ; [pp+0x11620] "Engmt"
    //     0x46da54: ldr             x0, [x0, #0x620]
    // 0x46da58: ret
    //     0x46da58: ret             
    // 0x46da5c: r16 = Instance_Chapter11Stat
    //     0x46da5c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x46da60: ldr             x16, [x16, #0x5c0]
    // 0x46da64: cmp             w1, w16
    // 0x46da68: b.ne            #0x46da78
    // 0x46da6c: r0 = "Silver"
    //     0x46da6c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11628] "Silver"
    //     0x46da70: ldr             x0, [x0, #0x628]
    // 0x46da74: ret
    //     0x46da74: ret             
    // 0x46da78: r16 = Instance_Chapter11Stat
    //     0x46da78: add             x16, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x46da7c: ldr             x16, [x16, #0x5d0]
    // 0x46da80: cmp             w1, w16
    // 0x46da84: b.ne            #0x46da94
    // 0x46da88: r0 = "Velocity"
    //     0x46da88: add             x0, PP, #0x11, lsl #12  ; [pp+0x115d8] "Velocity"
    //     0x46da8c: ldr             x0, [x0, #0x5d8]
    // 0x46da90: ret
    //     0x46da90: ret             
    // 0x46da94: r16 = Instance_Chapter11Stat
    //     0x46da94: add             x16, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x46da98: ldr             x16, [x16, #0x5e0]
    // 0x46da9c: cmp             w1, w16
    // 0x46daa0: b.ne            #0x46dab0
    // 0x46daa4: r0 = "Gold"
    //     0x46daa4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11630] "Gold"
    //     0x46daa8: ldr             x0, [x0, #0x630]
    // 0x46daac: ret
    //     0x46daac: ret             
    // 0x46dab0: r16 = Instance_Chapter11Stat
    //     0x46dab0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11560] Obj!Chapter11Stat@85fde1
    //     0x46dab4: ldr             x16, [x16, #0x560]
    // 0x46dab8: cmp             w1, w16
    // 0x46dabc: b.ne            #0x46dacc
    // 0x46dac0: r0 = "Acc"
    //     0x46dac0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11638] "Acc"
    //     0x46dac4: ldr             x0, [x0, #0x638]
    // 0x46dac8: ret
    //     0x46dac8: ret             
    // 0x46dacc: r16 = Instance_Chapter11Stat
    //     0x46dacc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Chapter11Stat@85fdc1
    //     0x46dad0: ldr             x16, [x16, #0x568]
    // 0x46dad4: cmp             w1, w16
    // 0x46dad8: b.ne            #0x46dae8
    // 0x46dadc: r0 = "Cert"
    //     0x46dadc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11640] "Cert"
    //     0x46dae0: ldr             x0, [x0, #0x640]
    // 0x46dae4: ret
    //     0x46dae4: ret             
    // 0x46dae8: r16 = Instance_Chapter11Stat
    //     0x46dae8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11570] Obj!Chapter11Stat@85fda1
    //     0x46daec: ldr             x16, [x16, #0x570]
    // 0x46daf0: cmp             w1, w16
    // 0x46daf4: b.ne            #0x46db04
    // 0x46daf8: r0 = "Onbrdng"
    //     0x46daf8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11648] "Onbrdng"
    //     0x46dafc: ldr             x0, [x0, #0x648]
    // 0x46db00: ret
    //     0x46db00: ret             
    // 0x46db04: r16 = Instance_Chapter11Stat
    //     0x46db04: add             x16, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x46db08: ldr             x16, [x16, #0x608]
    // 0x46db0c: cmp             w1, w16
    // 0x46db10: b.ne            #0x46db20
    // 0x46db14: r0 = "Titanium"
    //     0x46db14: add             x0, PP, #0x11, lsl #12  ; [pp+0x11650] "Titanium"
    //     0x46db18: ldr             x0, [x0, #0x650]
    // 0x46db1c: ret
    //     0x46db1c: ret             
    // 0x46db20: r0 = Null
    //     0x46db20: mov             x0, NULL
    // 0x46db24: ret
    //     0x46db24: ret             
  }
}

// class id: 284, size: 0x98, field offset: 0x8c
class Chapter11GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter11Stat>> generators; // offset: 0x8c
  late Map<int, UpgradeData<Chapter11Stat>> allUpgradeData; // offset: 0x90

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3da3d8, size: 0x28c
    // 0x3da3d8: EnterFrame
    //     0x3da3d8: stp             fp, lr, [SP, #-0x10]!
    //     0x3da3dc: mov             fp, SP
    // 0x3da3e0: AllocStack(0x40)
    //     0x3da3e0: sub             SP, SP, #0x40
    // 0x3da3e4: SetupParameters(Chapter11GameState this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0x3da3e4: mov             x5, x1
    //     0x3da3e8: mov             x4, x2
    //     0x3da3ec: mov             x0, x3
    //     0x3da3f0: stur            x1, [fp, #-0x10]
    //     0x3da3f4: stur            x2, [fp, #-0x18]
    //     0x3da3f8: stur            x3, [fp, #-0x20]
    // 0x3da3fc: CheckStackOverflow
    //     0x3da3fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da400: cmp             SP, x16
    //     0x3da404: b.ls            #0x3da650
    // 0x3da408: LoadField: r1 = r5->field_3f
    //     0x3da408: ldur            w1, [x5, #0x3f]
    // 0x3da40c: DecompressPointer r1
    //     0x3da40c: add             x1, x1, HEAP, lsl #32
    // 0x3da410: LoadField: r2 = r1->field_7
    //     0x3da410: ldur            w2, [x1, #7]
    // 0x3da414: DecompressPointer r2
    //     0x3da414: add             x2, x2, HEAP, lsl #32
    // 0x3da418: cmp             w2, #4
    // 0x3da41c: b.ne            #0x3da508
    // 0x3da420: LoadField: r6 = r5->field_47
    //     0x3da420: ldur            w6, [x5, #0x47]
    // 0x3da424: DecompressPointer r6
    //     0x3da424: add             x6, x6, HEAP, lsl #32
    // 0x3da428: stur            x6, [fp, #-8]
    // 0x3da42c: LoadField: r2 = r6->field_7
    //     0x3da42c: ldur            w2, [x6, #7]
    // 0x3da430: DecompressPointer r2
    //     0x3da430: add             x2, x2, HEAP, lsl #32
    // 0x3da434: r1 = Null
    //     0x3da434: mov             x1, NULL
    // 0x3da438: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x3da438: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x3da43c: r30 = InstantiateTypeArgumentsStub
    //     0x3da43c: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x3da440: LoadField: r30 = r30->field_7
    //     0x3da440: ldur            lr, [lr, #7]
    // 0x3da444: blr             lr
    // 0x3da448: mov             x1, x0
    // 0x3da44c: r0 = _CompactEntriesIterable()
    //     0x3da44c: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x3da450: mov             x1, x0
    // 0x3da454: ldur            x0, [fp, #-8]
    // 0x3da458: StoreField: r1->field_b = r0
    //     0x3da458: stur            w0, [x1, #0xb]
    // 0x3da45c: r0 = iterator()
    //     0x3da45c: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x3da460: stur            x0, [fp, #-0x28]
    // 0x3da464: ldur            x2, [fp, #-0x20]
    // 0x3da468: stur            x2, [fp, #-8]
    // 0x3da46c: CheckStackOverflow
    //     0x3da46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da470: cmp             SP, x16
    //     0x3da474: b.ls            #0x3da658
    // 0x3da478: mov             x1, x0
    // 0x3da47c: r0 = moveNext()
    //     0x3da47c: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x3da480: tbnz            w0, #4, #0x3da4fc
    // 0x3da484: ldur            x0, [fp, #-0x28]
    // 0x3da488: LoadField: r1 = r0->field_2b
    //     0x3da488: ldur            w1, [x0, #0x2b]
    // 0x3da48c: DecompressPointer r1
    //     0x3da48c: add             x1, x1, HEAP, lsl #32
    // 0x3da490: stur            x1, [fp, #-0x30]
    // 0x3da494: cmp             w1, NULL
    // 0x3da498: b.eq            #0x3da644
    // 0x3da49c: LoadField: r2 = r1->field_b
    //     0x3da49c: ldur            w2, [x1, #0xb]
    // 0x3da4a0: DecompressPointer r2
    //     0x3da4a0: add             x2, x2, HEAP, lsl #32
    // 0x3da4a4: ldur            x16, [fp, #-0x18]
    // 0x3da4a8: stp             x2, x16, [SP]
    // 0x3da4ac: r0 = ==()
    //     0x3da4ac: bl              #0x7c926c  ; [dart:core] _IntegerImplementation::==
    // 0x3da4b0: tbz             w0, #4, #0x3da4ec
    // 0x3da4b4: ldur            x1, [fp, #-8]
    // 0x3da4b8: ldur            x0, [fp, #-0x30]
    // 0x3da4bc: LoadField: r2 = r0->field_f
    //     0x3da4bc: ldur            w2, [x0, #0xf]
    // 0x3da4c0: DecompressPointer r2
    //     0x3da4c0: add             x2, x2, HEAP, lsl #32
    // 0x3da4c4: r0 = 60
    //     0x3da4c4: movz            x0, #0x3c
    // 0x3da4c8: branchIfSmi(r1, 0x3da4d4)
    //     0x3da4c8: tbz             w1, #0, #0x3da4d4
    // 0x3da4cc: r0 = LoadClassIdInstr(r1)
    //     0x3da4cc: ldur            x0, [x1, #-1]
    //     0x3da4d0: ubfx            x0, x0, #0xc, #0x14
    // 0x3da4d4: stp             x2, x1, [SP]
    // 0x3da4d8: r0 = GDT[cid_x0 + -0xff2]()
    //     0x3da4d8: sub             lr, x0, #0xff2
    //     0x3da4dc: ldr             lr, [x21, lr, lsl #3]
    //     0x3da4e0: blr             lr
    // 0x3da4e4: mov             x2, x0
    // 0x3da4e8: b               #0x3da4f4
    // 0x3da4ec: ldur            x1, [fp, #-8]
    // 0x3da4f0: mov             x2, x1
    // 0x3da4f4: ldur            x0, [fp, #-0x28]
    // 0x3da4f8: b               #0x3da468
    // 0x3da4fc: ldur            x1, [fp, #-8]
    // 0x3da500: mov             x3, x1
    // 0x3da504: b               #0x3da50c
    // 0x3da508: ldur            x3, [fp, #-0x20]
    // 0x3da50c: ldur            x0, [fp, #-0x10]
    // 0x3da510: mov             x1, x0
    // 0x3da514: ldur            x2, [fp, #-0x18]
    // 0x3da518: stur            x3, [fp, #-8]
    // 0x3da51c: r0 = getGeneratorInfo()
    //     0x3da51c: bl              #0x80d194  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::getGeneratorInfo
    // 0x3da520: LoadField: r2 = r0->field_27
    //     0x3da520: ldur            w2, [x0, #0x27]
    // 0x3da524: DecompressPointer r2
    //     0x3da524: add             x2, x2, HEAP, lsl #32
    // 0x3da528: stur            x2, [fp, #-0x28]
    // 0x3da52c: cmp             w2, NULL
    // 0x3da530: b.eq            #0x3da660
    // 0x3da534: LoadField: r3 = r2->field_b
    //     0x3da534: ldur            w3, [x2, #0xb]
    // 0x3da538: DecompressPointer r3
    //     0x3da538: add             x3, x3, HEAP, lsl #32
    // 0x3da53c: ldur            x1, [fp, #-0x10]
    // 0x3da540: stur            x3, [fp, #-0x20]
    // 0x3da544: LoadField: r4 = r1->field_2f
    //     0x3da544: ldur            w4, [x1, #0x2f]
    // 0x3da548: DecompressPointer r4
    //     0x3da548: add             x4, x4, HEAP, lsl #32
    // 0x3da54c: stur            x4, [fp, #-0x18]
    // 0x3da550: LoadField: r1 = r0->field_23
    //     0x3da550: ldur            w1, [x0, #0x23]
    // 0x3da554: DecompressPointer r1
    //     0x3da554: add             x1, x1, HEAP, lsl #32
    // 0x3da558: r0 = LoadClassIdInstr(r1)
    //     0x3da558: ldur            x0, [x1, #-1]
    //     0x3da55c: ubfx            x0, x0, #0xc, #0x14
    // 0x3da560: r0 = GDT[cid_x0 + -0xcb]()
    //     0x3da560: sub             lr, x0, #0xcb
    //     0x3da564: ldr             lr, [x21, lr, lsl #3]
    //     0x3da568: blr             lr
    // 0x3da56c: mov             x1, x0
    // 0x3da570: r0 = first()
    //     0x3da570: bl              #0x4de97c  ; [dart:core] Iterable::first
    // 0x3da574: ldur            x1, [fp, #-0x18]
    // 0x3da578: mov             x2, x0
    // 0x3da57c: r0 = _getValueOrData()
    //     0x3da57c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3da580: mov             x1, x0
    // 0x3da584: ldur            x0, [fp, #-0x18]
    // 0x3da588: LoadField: r2 = r0->field_f
    //     0x3da588: ldur            w2, [x0, #0xf]
    // 0x3da58c: DecompressPointer r2
    //     0x3da58c: add             x2, x2, HEAP, lsl #32
    // 0x3da590: cmp             w2, w1
    // 0x3da594: b.ne            #0x3da5a0
    // 0x3da598: r0 = Null
    //     0x3da598: mov             x0, NULL
    // 0x3da59c: b               #0x3da5a4
    // 0x3da5a0: mov             x0, x1
    // 0x3da5a4: cmp             w0, NULL
    // 0x3da5a8: b.ne            #0x3da5b4
    // 0x3da5ac: r0 = Null
    //     0x3da5ac: mov             x0, NULL
    // 0x3da5b0: b               #0x3da5c0
    // 0x3da5b4: LoadField: r1 = r0->field_b
    //     0x3da5b4: ldur            w1, [x0, #0xb]
    // 0x3da5b8: DecompressPointer r1
    //     0x3da5b8: add             x1, x1, HEAP, lsl #32
    // 0x3da5bc: mov             x0, x1
    // 0x3da5c0: cmp             w0, NULL
    // 0x3da5c4: b.ne            #0x3da5d4
    // 0x3da5c8: r4 = Instance_CustomNum
    //     0x3da5c8: add             x4, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x3da5cc: ldr             x4, [x4, #0xa70]
    // 0x3da5d0: b               #0x3da5d8
    // 0x3da5d4: mov             x4, x0
    // 0x3da5d8: ldur            x0, [fp, #-0x28]
    // 0x3da5dc: ldur            x3, [fp, #-0x20]
    // 0x3da5e0: ldur            x2, [fp, #-8]
    // 0x3da5e4: stur            x4, [fp, #-0x10]
    // 0x3da5e8: r1 = Instance_CustomNum
    //     0x3da5e8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3da5ec: ldr             x1, [x1, #0x2f0]
    // 0x3da5f0: r0 = pow()
    //     0x3da5f0: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3da5f4: mov             x1, x0
    // 0x3da5f8: ldur            x0, [fp, #-0x28]
    // 0x3da5fc: LoadField: r3 = r0->field_f
    //     0x3da5fc: ldur            w3, [x0, #0xf]
    // 0x3da600: DecompressPointer r3
    //     0x3da600: add             x3, x3, HEAP, lsl #32
    // 0x3da604: mov             x2, x1
    // 0x3da608: ldur            x1, [fp, #-0x10]
    // 0x3da60c: r0 = mult3()
    //     0x3da60c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x3da610: r1 = <Chapter11Stat, CustomNum>
    //     0x3da610: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6e0] TypeArguments: <Chapter11Stat, CustomNum>
    //     0x3da614: ldr             x1, [x1, #0x6e0]
    // 0x3da618: stur            x0, [fp, #-8]
    // 0x3da61c: r0 = Tuple2()
    //     0x3da61c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3da620: mov             x1, x0
    // 0x3da624: ldur            x0, [fp, #-0x20]
    // 0x3da628: StoreField: r1->field_b = r0
    //     0x3da628: stur            w0, [x1, #0xb]
    // 0x3da62c: ldur            x0, [fp, #-8]
    // 0x3da630: StoreField: r1->field_f = r0
    //     0x3da630: stur            w0, [x1, #0xf]
    // 0x3da634: mov             x0, x1
    // 0x3da638: LeaveFrame
    //     0x3da638: mov             SP, fp
    //     0x3da63c: ldp             fp, lr, [SP], #0x10
    // 0x3da640: ret
    //     0x3da640: ret             
    // 0x3da644: r0 = noElement()
    //     0x3da644: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x3da648: r0 = Throw()
    //     0x3da648: bl              #0x825670  ; ThrowStub
    // 0x3da64c: brk             #0
    // 0x3da650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3da650: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3da654: b               #0x3da408
    // 0x3da658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3da658: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3da65c: b               #0x3da478
    // 0x3da660: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3da660: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter11Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3da664, size: 0x40
    // 0x3da664: EnterFrame
    //     0x3da664: stp             fp, lr, [SP, #-0x10]!
    //     0x3da668: mov             fp, SP
    // 0x3da66c: ldr             x0, [fp, #0x20]
    // 0x3da670: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3da670: ldur            w1, [x0, #0x17]
    // 0x3da674: DecompressPointer r1
    //     0x3da674: add             x1, x1, HEAP, lsl #32
    // 0x3da678: CheckStackOverflow
    //     0x3da678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da67c: cmp             SP, x16
    //     0x3da680: b.ls            #0x3da69c
    // 0x3da684: ldr             x2, [fp, #0x18]
    // 0x3da688: ldr             x3, [fp, #0x10]
    // 0x3da68c: r0 = getCostToBuyOneMoreGenerator()
    //     0x3da68c: bl              #0x3da3d8  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::getCostToBuyOneMoreGenerator
    // 0x3da690: LeaveFrame
    //     0x3da690: mov             SP, fp
    //     0x3da694: ldp             fp, lr, [SP], #0x10
    // 0x3da698: ret
    //     0x3da698: ret             
    // 0x3da69c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3da69c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3da6a0: b               #0x3da684
  }
  _ Chapter11GameState(/* No info */) {
    // ** addr: 0x46d784, size: 0x12c
    // 0x46d784: EnterFrame
    //     0x46d784: stp             fp, lr, [SP, #-0x10]!
    //     0x46d788: mov             fp, SP
    // 0x46d78c: AllocStack(0x38)
    //     0x46d78c: sub             SP, SP, #0x38
    // 0x46d790: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46d794: mov             x4, x1
    // 0x46d798: mov             x3, x2
    // 0x46d79c: stur            x1, [fp, #-8]
    // 0x46d7a0: stur            x2, [fp, #-0x10]
    // 0x46d7a4: CheckStackOverflow
    //     0x46d7a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46d7a8: cmp             SP, x16
    //     0x46d7ac: b.ls            #0x46d8a8
    // 0x46d7b0: StoreField: r4->field_8b = r0
    //     0x46d7b0: stur            w0, [x4, #0x8b]
    // 0x46d7b4: StoreField: r4->field_8f = r0
    //     0x46d7b4: stur            w0, [x4, #0x8f]
    // 0x46d7b8: r1 = Null
    //     0x46d7b8: mov             x1, NULL
    // 0x46d7bc: r2 = 12
    //     0x46d7bc: movz            x2, #0xc
    // 0x46d7c0: r0 = AllocateArray()
    //     0x46d7c0: bl              #0x82746c  ; AllocateArrayStub
    // 0x46d7c4: r16 = 40
    //     0x46d7c4: movz            x16, #0x28
    // 0x46d7c8: StoreField: r0->field_f = r16
    //     0x46d7c8: stur            w16, [x0, #0xf]
    // 0x46d7cc: r16 = Instance_Chapter11Stat
    //     0x46d7cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11560] Obj!Chapter11Stat@85fde1
    //     0x46d7d0: ldr             x16, [x16, #0x560]
    // 0x46d7d4: StoreField: r0->field_13 = r16
    //     0x46d7d4: stur            w16, [x0, #0x13]
    // 0x46d7d8: r16 = 42
    //     0x46d7d8: movz            x16, #0x2a
    // 0x46d7dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x46d7dc: stur            w16, [x0, #0x17]
    // 0x46d7e0: r16 = Instance_Chapter11Stat
    //     0x46d7e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Chapter11Stat@85fdc1
    //     0x46d7e4: ldr             x16, [x16, #0x568]
    // 0x46d7e8: StoreField: r0->field_1b = r16
    //     0x46d7e8: stur            w16, [x0, #0x1b]
    // 0x46d7ec: r16 = 44
    //     0x46d7ec: movz            x16, #0x2c
    // 0x46d7f0: StoreField: r0->field_1f = r16
    //     0x46d7f0: stur            w16, [x0, #0x1f]
    // 0x46d7f4: r16 = Instance_Chapter11Stat
    //     0x46d7f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11570] Obj!Chapter11Stat@85fda1
    //     0x46d7f8: ldr             x16, [x16, #0x570]
    // 0x46d7fc: StoreField: r0->field_23 = r16
    //     0x46d7fc: stur            w16, [x0, #0x23]
    // 0x46d800: r16 = <int, Chapter11Stat>
    //     0x46d800: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] TypeArguments: <int, Chapter11Stat>
    //     0x46d804: ldr             x16, [x16, #0x578]
    // 0x46d808: stp             x0, x16, [SP]
    // 0x46d80c: r0 = Map._fromLiteral()
    //     0x46d80c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46d810: ldur            x3, [fp, #-8]
    // 0x46d814: StoreField: r3->field_93 = r0
    //     0x46d814: stur            w0, [x3, #0x93]
    //     0x46d818: ldurb           w16, [x3, #-1]
    //     0x46d81c: ldurb           w17, [x0, #-1]
    //     0x46d820: and             x16, x17, x16, lsr #2
    //     0x46d824: tst             x16, HEAP, lsr #32
    //     0x46d828: b.eq            #0x46d830
    //     0x46d82c: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46d830: r1 = Function '<anonymous closure>':.
    //     0x46d830: add             x1, PP, #0x11, lsl #12  ; [pp+0x11580] AnonymousClosure: (0x46db28), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x46d834: ldr             x1, [x1, #0x580]
    // 0x46d838: r2 = Null
    //     0x46d838: mov             x2, NULL
    // 0x46d83c: r0 = AllocateClosure()
    //     0x46d83c: bl              #0x826750  ; AllocateClosureStub
    // 0x46d840: r1 = Function '<anonymous closure>':.
    //     0x46d840: add             x1, PP, #0x11, lsl #12  ; [pp+0x11588] AnonymousClosure: (0x46d9f4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x46d844: ldr             x1, [x1, #0x588]
    // 0x46d848: r2 = Null
    //     0x46d848: mov             x2, NULL
    // 0x46d84c: stur            x0, [fp, #-0x18]
    // 0x46d850: r0 = AllocateClosure()
    //     0x46d850: bl              #0x826750  ; AllocateClosureStub
    // 0x46d854: r1 = Function '<anonymous closure>':.
    //     0x46d854: add             x1, PP, #0x11, lsl #12  ; [pp+0x11590] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x46d858: ldr             x1, [x1, #0x590]
    // 0x46d85c: r2 = Null
    //     0x46d85c: mov             x2, NULL
    // 0x46d860: stur            x0, [fp, #-0x20]
    // 0x46d864: r0 = AllocateClosure()
    //     0x46d864: bl              #0x826750  ; AllocateClosureStub
    // 0x46d868: r1 = Function '<anonymous closure>':.
    //     0x46d868: add             x1, PP, #0x11, lsl #12  ; [pp+0x11598] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46d86c: ldr             x1, [x1, #0x598]
    // 0x46d870: r2 = Null
    //     0x46d870: mov             x2, NULL
    // 0x46d874: stur            x0, [fp, #-0x28]
    // 0x46d878: r0 = AllocateClosure()
    //     0x46d878: bl              #0x826750  ; AllocateClosureStub
    // 0x46d87c: ldur            x1, [fp, #-8]
    // 0x46d880: ldur            x2, [fp, #-0x10]
    // 0x46d884: ldur            x3, [fp, #-0x18]
    // 0x46d888: ldur            x5, [fp, #-0x20]
    // 0x46d88c: ldur            x6, [fp, #-0x28]
    // 0x46d890: mov             x7, x0
    // 0x46d894: r0 = IPlayableGameState()
    //     0x46d894: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46d898: r0 = Null
    //     0x46d898: mov             x0, NULL
    // 0x46d89c: LeaveFrame
    //     0x46d89c: mov             SP, fp
    //     0x46d8a0: ldp             fp, lr, [SP], #0x10
    // 0x46d8a4: ret
    //     0x46d8a4: ret             
    // 0x46d8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46d8a8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46d8ac: b               #0x46d7b0
  }
  [closure] String <anonymous closure>(dynamic, Chapter11Stat) {
    // ** addr: 0x46d8b0, size: 0x30
    // 0x46d8b0: EnterFrame
    //     0x46d8b0: stp             fp, lr, [SP, #-0x10]!
    //     0x46d8b4: mov             fp, SP
    // 0x46d8b8: CheckStackOverflow
    //     0x46d8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46d8bc: cmp             SP, x16
    //     0x46d8c0: b.ls            #0x46d8d8
    // 0x46d8c4: ldr             x1, [fp, #0x10]
    // 0x46d8c8: r0 = humanName()
    //     0x46d8c8: bl              #0x46d8e0  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] ::humanName
    // 0x46d8cc: LeaveFrame
    //     0x46d8cc: mov             SP, fp
    //     0x46d8d0: ldp             fp, lr, [SP], #0x10
    // 0x46d8d4: ret
    //     0x46d8d4: ret             
    // 0x46d8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46d8d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46d8dc: b               #0x46d8c4
  }
  [closure] String <anonymous closure>(dynamic, Chapter11Stat) {
    // ** addr: 0x46d9f4, size: 0x30
    // 0x46d9f4: EnterFrame
    //     0x46d9f4: stp             fp, lr, [SP, #-0x10]!
    //     0x46d9f8: mov             fp, SP
    // 0x46d9fc: CheckStackOverflow
    //     0x46d9fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46da00: cmp             SP, x16
    //     0x46da04: b.ls            #0x46da1c
    // 0x46da08: ldr             x1, [fp, #0x10]
    // 0x46da0c: r0 = shortenedName()
    //     0x46da0c: bl              #0x46da24  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] ::shortenedName
    // 0x46da10: LeaveFrame
    //     0x46da10: mov             SP, fp
    //     0x46da14: ldp             fp, lr, [SP], #0x10
    // 0x46da18: ret
    //     0x46da18: ret             
    // 0x46da1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46da1c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46da20: b               #0x46da08
  }
  [closure] Chapter11Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46db28, size: 0x44
    // 0x46db28: r2 = const [Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat', Instance of 'Chapter11Stat']
    //     0x46db28: add             x2, PP, #0x11, lsl #12  ; [pp+0x11658] List<Chapter11Stat>(9)
    //     0x46db2c: ldr             x2, [x2, #0x658]
    // 0x46db30: ldr             x3, [SP]
    // 0x46db34: r4 = LoadInt32Instr(r3)
    //     0x46db34: sbfx            x4, x3, #1, #0x1f
    //     0x46db38: tbz             w3, #0, #0x46db40
    //     0x46db3c: ldur            x4, [x3, #7]
    // 0x46db40: mov             x1, x4
    // 0x46db44: r0 = 9
    //     0x46db44: movz            x0, #0x9
    // 0x46db48: cmp             x1, x0
    // 0x46db4c: b.hs            #0x46db60
    // 0x46db50: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46db50: add             x16, x2, x4, lsl #2
    //     0x46db54: ldur            w0, [x16, #0xf]
    // 0x46db58: DecompressPointer r0
    //     0x46db58: add             x0, x0, HEAP, lsl #32
    // 0x46db5c: ret
    //     0x46db5c: ret             
    // 0x46db60: EnterFrame
    //     0x46db60: stp             fp, lr, [SP, #-0x10]!
    //     0x46db64: mov             fp, SP
    // 0x46db68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46db68: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e69b4, size: 0x74
    // 0x4e69b4: EnterFrame
    //     0x4e69b4: stp             fp, lr, [SP, #-0x10]!
    //     0x4e69b8: mov             fp, SP
    // 0x4e69bc: AllocStack(0x10)
    //     0x4e69bc: sub             SP, SP, #0x10
    // 0x4e69c0: SetupParameters(Chapter11GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e69c0: stur            x1, [fp, #-8]
    // 0x4e69c4: r1 = 1
    //     0x4e69c4: movz            x1, #0x1
    // 0x4e69c8: r0 = AllocateContext()
    //     0x4e69c8: bl              #0x82637c  ; AllocateContextStub
    // 0x4e69cc: mov             x1, x0
    // 0x4e69d0: ldur            x0, [fp, #-8]
    // 0x4e69d4: StoreField: r1->field_f = r0
    //     0x4e69d4: stur            w0, [x1, #0xf]
    // 0x4e69d8: mov             x2, x1
    // 0x4e69dc: r1 = Function '<anonymous closure>':.
    //     0x4e69dc: add             x1, PP, #0x25, lsl #12  ; [pp+0x25780] AnonymousClosure: (0x4e6a28), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::makeHeader (0x4e69b4)
    //     0x4e69e0: ldr             x1, [x1, #0x780]
    // 0x4e69e4: r0 = AllocateClosure()
    //     0x4e69e4: bl              #0x826750  ; AllocateClosureStub
    // 0x4e69e8: stur            x0, [fp, #-8]
    // 0x4e69ec: r0 = MainStatDisplay()
    //     0x4e69ec: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e69f0: mov             x3, x0
    // 0x4e69f4: ldur            x0, [fp, #-8]
    // 0x4e69f8: stur            x3, [fp, #-0x10]
    // 0x4e69fc: StoreField: r3->field_b = r0
    //     0x4e69fc: stur            w0, [x3, #0xb]
    // 0x4e6a00: r1 = Function '<anonymous closure>':.
    //     0x4e6a00: add             x1, PP, #0x25, lsl #12  ; [pp+0x25788] AnonymousClosure: (0x7b6794), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::makeHeader (0x4e78b8)
    //     0x4e6a04: ldr             x1, [x1, #0x788]
    // 0x4e6a08: r2 = Null
    //     0x4e6a08: mov             x2, NULL
    // 0x4e6a0c: r0 = AllocateClosure()
    //     0x4e6a0c: bl              #0x826750  ; AllocateClosureStub
    // 0x4e6a10: mov             x1, x0
    // 0x4e6a14: ldur            x0, [fp, #-0x10]
    // 0x4e6a18: StoreField: r0->field_f = r1
    //     0x4e6a18: stur            w1, [x0, #0xf]
    // 0x4e6a1c: LeaveFrame
    //     0x4e6a1c: mov             SP, fp
    //     0x4e6a20: ldp             fp, lr, [SP], #0x10
    // 0x4e6a24: ret
    //     0x4e6a24: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e6a28, size: 0xf4
    // 0x4e6a28: EnterFrame
    //     0x4e6a28: stp             fp, lr, [SP, #-0x10]!
    //     0x4e6a2c: mov             fp, SP
    // 0x4e6a30: AllocStack(0x18)
    //     0x4e6a30: sub             SP, SP, #0x18
    // 0x4e6a34: SetupParameters([dynamic _ /* r0 */])
    //     0x4e6a34: ldr             x0, [fp, #0x10]
    //     0x4e6a38: ldur            w3, [x0, #0x17]
    //     0x4e6a3c: add             x3, x3, HEAP, lsl #32
    //     0x4e6a40: stur            x3, [fp, #-8]
    // 0x4e6a44: CheckStackOverflow
    //     0x4e6a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e6a48: cmp             SP, x16
    //     0x4e6a4c: b.ls            #0x4e6b14
    // 0x4e6a50: r1 = Null
    //     0x4e6a50: mov             x1, NULL
    // 0x4e6a54: r2 = 4
    //     0x4e6a54: movz            x2, #0x4
    // 0x4e6a58: r0 = AllocateArray()
    //     0x4e6a58: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e6a5c: stur            x0, [fp, #-0x10]
    // 0x4e6a60: r16 = "Associates: "
    //     0x4e6a60: add             x16, PP, #0x25, lsl #12  ; [pp+0x25790] "Associates: "
    //     0x4e6a64: ldr             x16, [x16, #0x790]
    // 0x4e6a68: StoreField: r0->field_f = r16
    //     0x4e6a68: stur            w16, [x0, #0xf]
    // 0x4e6a6c: ldur            x1, [fp, #-8]
    // 0x4e6a70: LoadField: r2 = r1->field_f
    //     0x4e6a70: ldur            w2, [x1, #0xf]
    // 0x4e6a74: DecompressPointer r2
    //     0x4e6a74: add             x2, x2, HEAP, lsl #32
    // 0x4e6a78: LoadField: r3 = r2->field_37
    //     0x4e6a78: ldur            w3, [x2, #0x37]
    // 0x4e6a7c: DecompressPointer r3
    //     0x4e6a7c: add             x3, x3, HEAP, lsl #32
    // 0x4e6a80: mov             x1, x3
    // 0x4e6a84: stur            x3, [fp, #-8]
    // 0x4e6a88: r2 = Instance_Chapter11Stat
    //     0x4e6a88: add             x2, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x4e6a8c: ldr             x2, [x2, #0x5a0]
    // 0x4e6a90: r0 = _getValueOrData()
    //     0x4e6a90: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e6a94: mov             x1, x0
    // 0x4e6a98: ldur            x0, [fp, #-8]
    // 0x4e6a9c: LoadField: r2 = r0->field_f
    //     0x4e6a9c: ldur            w2, [x0, #0xf]
    // 0x4e6aa0: DecompressPointer r2
    //     0x4e6aa0: add             x2, x2, HEAP, lsl #32
    // 0x4e6aa4: cmp             w2, w1
    // 0x4e6aa8: b.ne            #0x4e6ab0
    // 0x4e6aac: r1 = Null
    //     0x4e6aac: mov             x1, NULL
    // 0x4e6ab0: cmp             w1, NULL
    // 0x4e6ab4: b.ne            #0x4e6ac0
    // 0x4e6ab8: r0 = Null
    //     0x4e6ab8: mov             x0, NULL
    // 0x4e6abc: b               #0x4e6ac8
    // 0x4e6ac0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e6ac0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e6ac4: r0 = toStringConsistentDecimalPlaces()
    //     0x4e6ac4: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e6ac8: cmp             w0, NULL
    // 0x4e6acc: b.ne            #0x4e6ad4
    // 0x4e6ad0: r0 = 0
    //     0x4e6ad0: movz            x0, #0
    // 0x4e6ad4: ldur            x1, [fp, #-0x10]
    // 0x4e6ad8: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e6ad8: add             x25, x1, #0x13
    //     0x4e6adc: str             w0, [x25]
    //     0x4e6ae0: tbz             w0, #0, #0x4e6afc
    //     0x4e6ae4: ldurb           w16, [x1, #-1]
    //     0x4e6ae8: ldurb           w17, [x0, #-1]
    //     0x4e6aec: and             x16, x17, x16, lsr #2
    //     0x4e6af0: tst             x16, HEAP, lsr #32
    //     0x4e6af4: b.eq            #0x4e6afc
    //     0x4e6af8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6afc: ldur            x16, [fp, #-0x10]
    // 0x4e6b00: str             x16, [SP]
    // 0x4e6b04: r0 = _interpolate()
    //     0x4e6b04: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e6b08: LeaveFrame
    //     0x4e6b08: mov             SP, fp
    //     0x4e6b0c: ldp             fp, lr, [SP], #0x10
    // 0x4e6b10: ret
    //     0x4e6b10: ret             
    // 0x4e6b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6b14: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e6b18: b               #0x4e6a50
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4f52d4, size: 0xd98
    // 0x4f52d4: EnterFrame
    //     0x4f52d4: stp             fp, lr, [SP, #-0x10]!
    //     0x4f52d8: mov             fp, SP
    // 0x4f52dc: AllocStack(0x48)
    //     0x4f52dc: sub             SP, SP, #0x48
    // 0x4f52e0: SetupParameters(Chapter11GameState this /* r1 => r1, fp-0x8 */)
    //     0x4f52e0: stur            x1, [fp, #-8]
    // 0x4f52e4: CheckStackOverflow
    //     0x4f52e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f52e8: cmp             SP, x16
    //     0x4f52ec: b.ls            #0x4f6064
    // 0x4f52f0: r1 = 1
    //     0x4f52f0: movz            x1, #0x1
    // 0x4f52f4: r0 = AllocateContext()
    //     0x4f52f4: bl              #0x82637c  ; AllocateContextStub
    // 0x4f52f8: mov             x3, x0
    // 0x4f52fc: ldur            x0, [fp, #-8]
    // 0x4f5300: stur            x3, [fp, #-0x10]
    // 0x4f5304: StoreField: r3->field_f = r0
    //     0x4f5304: stur            w0, [x3, #0xf]
    // 0x4f5308: r1 = Null
    //     0x4f5308: mov             x1, NULL
    // 0x4f530c: r2 = 48
    //     0x4f530c: movz            x2, #0x30
    // 0x4f5310: r0 = AllocateArray()
    //     0x4f5310: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5314: r16 = 2
    //     0x4f5314: movz            x16, #0x2
    // 0x4f5318: StoreField: r0->field_f = r16
    //     0x4f5318: stur            w16, [x0, #0xf]
    // 0x4f531c: r16 = Instance_GeneratorInfo
    //     0x4f531c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16328] Obj!GeneratorInfo<Chapter11Stat>@82cdd1
    //     0x4f5320: ldr             x16, [x16, #0x328]
    // 0x4f5324: StoreField: r0->field_13 = r16
    //     0x4f5324: stur            w16, [x0, #0x13]
    // 0x4f5328: r16 = 20
    //     0x4f5328: movz            x16, #0x14
    // 0x4f532c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f532c: stur            w16, [x0, #0x17]
    // 0x4f5330: r16 = Instance_GeneratorInfo
    //     0x4f5330: add             x16, PP, #0x16, lsl #12  ; [pp+0x16330] Obj!GeneratorInfo<Chapter11Stat>@82cd91
    //     0x4f5334: ldr             x16, [x16, #0x330]
    // 0x4f5338: StoreField: r0->field_1b = r16
    //     0x4f5338: stur            w16, [x0, #0x1b]
    // 0x4f533c: r16 = 22
    //     0x4f533c: movz            x16, #0x16
    // 0x4f5340: StoreField: r0->field_1f = r16
    //     0x4f5340: stur            w16, [x0, #0x1f]
    // 0x4f5344: r16 = Instance_GeneratorInfo
    //     0x4f5344: add             x16, PP, #0x16, lsl #12  ; [pp+0x16338] Obj!GeneratorInfo<Chapter11Stat>@82cd51
    //     0x4f5348: ldr             x16, [x16, #0x338]
    // 0x4f534c: StoreField: r0->field_23 = r16
    //     0x4f534c: stur            w16, [x0, #0x23]
    // 0x4f5350: r16 = 24
    //     0x4f5350: movz            x16, #0x18
    // 0x4f5354: StoreField: r0->field_27 = r16
    //     0x4f5354: stur            w16, [x0, #0x27]
    // 0x4f5358: r16 = Instance_GeneratorInfo
    //     0x4f5358: add             x16, PP, #0x16, lsl #12  ; [pp+0x16340] Obj!GeneratorInfo<Chapter11Stat>@82cd11
    //     0x4f535c: ldr             x16, [x16, #0x340]
    // 0x4f5360: StoreField: r0->field_2b = r16
    //     0x4f5360: stur            w16, [x0, #0x2b]
    // 0x4f5364: r16 = 26
    //     0x4f5364: movz            x16, #0x1a
    // 0x4f5368: StoreField: r0->field_2f = r16
    //     0x4f5368: stur            w16, [x0, #0x2f]
    // 0x4f536c: r16 = Instance_GeneratorInfo
    //     0x4f536c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16348] Obj!GeneratorInfo<Chapter11Stat>@82ccd1
    //     0x4f5370: ldr             x16, [x16, #0x348]
    // 0x4f5374: StoreField: r0->field_33 = r16
    //     0x4f5374: stur            w16, [x0, #0x33]
    // 0x4f5378: r16 = 28
    //     0x4f5378: movz            x16, #0x1c
    // 0x4f537c: StoreField: r0->field_37 = r16
    //     0x4f537c: stur            w16, [x0, #0x37]
    // 0x4f5380: r16 = Instance_GeneratorInfo
    //     0x4f5380: add             x16, PP, #0x16, lsl #12  ; [pp+0x16350] Obj!GeneratorInfo<Chapter11Stat>@82cc91
    //     0x4f5384: ldr             x16, [x16, #0x350]
    // 0x4f5388: StoreField: r0->field_3b = r16
    //     0x4f5388: stur            w16, [x0, #0x3b]
    // 0x4f538c: r16 = 40
    //     0x4f538c: movz            x16, #0x28
    // 0x4f5390: StoreField: r0->field_3f = r16
    //     0x4f5390: stur            w16, [x0, #0x3f]
    // 0x4f5394: r16 = Instance_GeneratorInfo
    //     0x4f5394: add             x16, PP, #0x16, lsl #12  ; [pp+0x16358] Obj!GeneratorInfo<Chapter11Stat>@82cc51
    //     0x4f5398: ldr             x16, [x16, #0x358]
    // 0x4f539c: StoreField: r0->field_43 = r16
    //     0x4f539c: stur            w16, [x0, #0x43]
    // 0x4f53a0: r16 = 42
    //     0x4f53a0: movz            x16, #0x2a
    // 0x4f53a4: StoreField: r0->field_47 = r16
    //     0x4f53a4: stur            w16, [x0, #0x47]
    // 0x4f53a8: r16 = Instance_GeneratorInfo
    //     0x4f53a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16360] Obj!GeneratorInfo<Chapter11Stat>@82cc11
    //     0x4f53ac: ldr             x16, [x16, #0x360]
    // 0x4f53b0: StoreField: r0->field_4b = r16
    //     0x4f53b0: stur            w16, [x0, #0x4b]
    // 0x4f53b4: r16 = 44
    //     0x4f53b4: movz            x16, #0x2c
    // 0x4f53b8: StoreField: r0->field_4f = r16
    //     0x4f53b8: stur            w16, [x0, #0x4f]
    // 0x4f53bc: r16 = Instance_GeneratorInfo
    //     0x4f53bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16368] Obj!GeneratorInfo<Chapter11Stat>@82cbd1
    //     0x4f53c0: ldr             x16, [x16, #0x368]
    // 0x4f53c4: StoreField: r0->field_53 = r16
    //     0x4f53c4: stur            w16, [x0, #0x53]
    // 0x4f53c8: r16 = 62
    //     0x4f53c8: movz            x16, #0x3e
    // 0x4f53cc: StoreField: r0->field_57 = r16
    //     0x4f53cc: stur            w16, [x0, #0x57]
    // 0x4f53d0: r16 = Instance_GeneratorInfo
    //     0x4f53d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16370] Obj!GeneratorInfo<Chapter11Stat>@82cb91
    //     0x4f53d4: ldr             x16, [x16, #0x370]
    // 0x4f53d8: StoreField: r0->field_5b = r16
    //     0x4f53d8: stur            w16, [x0, #0x5b]
    // 0x4f53dc: r16 = 64
    //     0x4f53dc: movz            x16, #0x40
    // 0x4f53e0: StoreField: r0->field_5f = r16
    //     0x4f53e0: stur            w16, [x0, #0x5f]
    // 0x4f53e4: r16 = Instance_GeneratorInfo
    //     0x4f53e4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16378] Obj!GeneratorInfo<Chapter11Stat>@82cb51
    //     0x4f53e8: ldr             x16, [x16, #0x378]
    // 0x4f53ec: StoreField: r0->field_63 = r16
    //     0x4f53ec: stur            w16, [x0, #0x63]
    // 0x4f53f0: r16 = 66
    //     0x4f53f0: movz            x16, #0x42
    // 0x4f53f4: StoreField: r0->field_67 = r16
    //     0x4f53f4: stur            w16, [x0, #0x67]
    // 0x4f53f8: r16 = Instance_GeneratorInfo
    //     0x4f53f8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16380] Obj!GeneratorInfo<Chapter11Stat>@82cb11
    //     0x4f53fc: ldr             x16, [x16, #0x380]
    // 0x4f5400: StoreField: r0->field_6b = r16
    //     0x4f5400: stur            w16, [x0, #0x6b]
    // 0x4f5404: r16 = <int, GeneratorInfo<Chapter11Stat>>
    //     0x4f5404: add             x16, PP, #0x16, lsl #12  ; [pp+0x16388] TypeArguments: <int, GeneratorInfo<Chapter11Stat>>
    //     0x4f5408: ldr             x16, [x16, #0x388]
    // 0x4f540c: stp             x0, x16, [SP]
    // 0x4f5410: r0 = Map._fromLiteral()
    //     0x4f5410: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4f5414: ldur            x3, [fp, #-8]
    // 0x4f5418: StoreField: r3->field_8b = r0
    //     0x4f5418: stur            w0, [x3, #0x8b]
    //     0x4f541c: ldurb           w16, [x3, #-1]
    //     0x4f5420: ldurb           w17, [x0, #-1]
    //     0x4f5424: and             x16, x17, x16, lsr #2
    //     0x4f5428: tst             x16, HEAP, lsr #32
    //     0x4f542c: b.eq            #0x4f5434
    //     0x4f5430: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4f5434: r1 = Null
    //     0x4f5434: mov             x1, NULL
    // 0x4f5438: r2 = 36
    //     0x4f5438: movz            x2, #0x24
    // 0x4f543c: r0 = AllocateArray()
    //     0x4f543c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5440: stur            x0, [fp, #-0x18]
    // 0x4f5444: r16 = 2
    //     0x4f5444: movz            x16, #0x2
    // 0x4f5448: StoreField: r0->field_f = r16
    //     0x4f5448: stur            w16, [x0, #0xf]
    // 0x4f544c: r1 = "Turbocharge"
    //     0x4f544c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16390] "Turbocharge"
    //     0x4f5450: ldr             x1, [x1, #0x390]
    // 0x4f5454: r0 = autoString()
    //     0x4f5454: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f5458: r1 = Function '<anonymous closure>':.
    //     0x4f5458: add             x1, PP, #0x16, lsl #12  ; [pp+0x16398] AnonymousClosure: (0x4f692c), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::ensureInitialized (0x4f52d4)
    //     0x4f545c: ldr             x1, [x1, #0x398]
    // 0x4f5460: r2 = Null
    //     0x4f5460: mov             x2, NULL
    // 0x4f5464: stur            x0, [fp, #-0x20]
    // 0x4f5468: r0 = AllocateClosure()
    //     0x4f5468: bl              #0x826750  ; AllocateClosureStub
    // 0x4f546c: r1 = <String>
    //     0x4f546c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5470: stur            x0, [fp, #-0x28]
    // 0x4f5474: r0 = Generator()
    //     0x4f5474: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5478: ldur            x2, [fp, #-0x28]
    // 0x4f547c: r3 = Null
    //     0x4f547c: mov             x3, NULL
    // 0x4f5480: stur            x0, [fp, #-0x28]
    // 0x4f5484: r0 = AllocateRecord2()
    //     0x4f5484: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f5488: mov             x1, x0
    // 0x4f548c: ldur            x0, [fp, #-0x28]
    // 0x4f5490: StoreField: r0->field_f = r1
    //     0x4f5490: stur            w1, [x0, #0xf]
    // 0x4f5494: r1 = Null
    //     0x4f5494: mov             x1, NULL
    // 0x4f5498: r2 = 6
    //     0x4f5498: movz            x2, #0x6
    // 0x4f549c: r0 = AllocateArray()
    //     0x4f549c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f54a0: stur            x0, [fp, #-0x30]
    // 0x4f54a4: r16 = Instance_Tuple2
    //     0x4f54a4: add             x16, PP, #0x16, lsl #12  ; [pp+0x163a0] Obj!Tuple2<Chapter11Stat, CustomNum>@822cf1
    //     0x4f54a8: ldr             x16, [x16, #0x3a0]
    // 0x4f54ac: StoreField: r0->field_f = r16
    //     0x4f54ac: stur            w16, [x0, #0xf]
    // 0x4f54b0: r16 = Instance_Tuple2
    //     0x4f54b0: add             x16, PP, #0x16, lsl #12  ; [pp+0x163a8] Obj!Tuple2<Chapter11Stat, CustomNum>@822cd1
    //     0x4f54b4: ldr             x16, [x16, #0x3a8]
    // 0x4f54b8: StoreField: r0->field_13 = r16
    //     0x4f54b8: stur            w16, [x0, #0x13]
    // 0x4f54bc: r16 = Instance_Tuple2
    //     0x4f54bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x163b0] Obj!Tuple2<Chapter11Stat, CustomNum>@822cb1
    //     0x4f54c0: ldr             x16, [x16, #0x3b0]
    // 0x4f54c4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f54c4: stur            w16, [x0, #0x17]
    // 0x4f54c8: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f54c8: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f54cc: ldr             x1, [x1, #0x3b8]
    // 0x4f54d0: r0 = AllocateGrowableArray()
    //     0x4f54d0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f54d4: mov             x2, x0
    // 0x4f54d8: ldur            x0, [fp, #-0x30]
    // 0x4f54dc: stur            x2, [fp, #-0x38]
    // 0x4f54e0: StoreField: r2->field_f = r0
    //     0x4f54e0: stur            w0, [x2, #0xf]
    // 0x4f54e4: r0 = 6
    //     0x4f54e4: movz            x0, #0x6
    // 0x4f54e8: StoreField: r2->field_b = r0
    //     0x4f54e8: stur            w0, [x2, #0xb]
    // 0x4f54ec: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f54ec: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f54f0: ldr             x1, [x1, #0x3b8]
    // 0x4f54f4: r0 = Generator()
    //     0x4f54f4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f54f8: mov             x2, x0
    // 0x4f54fc: ldur            x0, [fp, #-0x38]
    // 0x4f5500: stur            x2, [fp, #-0x30]
    // 0x4f5504: StoreField: r2->field_b = r0
    //     0x4f5504: stur            w0, [x2, #0xb]
    // 0x4f5508: r1 = <Chapter11Stat>
    //     0x4f5508: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f550c: ldr             x1, [x1, #0xeb8]
    // 0x4f5510: r0 = UpgradeData()
    //     0x4f5510: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5514: mov             x3, x0
    // 0x4f5518: ldur            x0, [fp, #-0x20]
    // 0x4f551c: stur            x3, [fp, #-0x38]
    // 0x4f5520: StoreField: r3->field_b = r0
    //     0x4f5520: stur            w0, [x3, #0xb]
    // 0x4f5524: ldur            x0, [fp, #-0x28]
    // 0x4f5528: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f5528: stur            w0, [x3, #0x17]
    // 0x4f552c: r0 = Instance_IconData
    //     0x4f552c: add             x0, PP, #0x16, lsl #12  ; [pp+0x163c0] Obj!IconData@82fe31
    //     0x4f5530: ldr             x0, [x0, #0x3c0]
    // 0x4f5534: StoreField: r3->field_13 = r0
    //     0x4f5534: stur            w0, [x3, #0x13]
    // 0x4f5538: ldur            x0, [fp, #-0x30]
    // 0x4f553c: StoreField: r3->field_f = r0
    //     0x4f553c: stur            w0, [x3, #0xf]
    // 0x4f5540: ldur            x2, [fp, #-0x10]
    // 0x4f5544: r1 = Function '<anonymous closure>':.
    //     0x4f5544: add             x1, PP, #0x16, lsl #12  ; [pp+0x163c8] AnonymousClosure: (0x4f4f1c), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::ensureInitialized (0x50a2f8)
    //     0x4f5548: ldr             x1, [x1, #0x3c8]
    // 0x4f554c: r0 = AllocateClosure()
    //     0x4f554c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f5550: mov             x1, x0
    // 0x4f5554: ldur            x0, [fp, #-0x38]
    // 0x4f5558: StoreField: r0->field_23 = r1
    //     0x4f5558: stur            w1, [x0, #0x23]
    // 0x4f555c: ldur            x1, [fp, #-0x18]
    // 0x4f5560: ArrayStore: r1[1] = r0  ; List_4
    //     0x4f5560: add             x25, x1, #0x13
    //     0x4f5564: str             w0, [x25]
    //     0x4f5568: tbz             w0, #0, #0x4f5584
    //     0x4f556c: ldurb           w16, [x1, #-1]
    //     0x4f5570: ldurb           w17, [x0, #-1]
    //     0x4f5574: and             x16, x17, x16, lsr #2
    //     0x4f5578: tst             x16, HEAP, lsr #32
    //     0x4f557c: b.eq            #0x4f5584
    //     0x4f5580: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f5584: ldur            x0, [fp, #-0x18]
    // 0x4f5588: r16 = 4
    //     0x4f5588: movz            x16, #0x4
    // 0x4f558c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f558c: stur            w16, [x0, #0x17]
    // 0x4f5590: r1 = "Flywheel"
    //     0x4f5590: add             x1, PP, #0x16, lsl #12  ; [pp+0x163d0] "Flywheel"
    //     0x4f5594: ldr             x1, [x1, #0x3d0]
    // 0x4f5598: r0 = autoString()
    //     0x4f5598: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f559c: r1 = Null
    //     0x4f559c: mov             x1, NULL
    // 0x4f55a0: r2 = 8
    //     0x4f55a0: movz            x2, #0x8
    // 0x4f55a4: stur            x0, [fp, #-0x20]
    // 0x4f55a8: r0 = AllocateArray()
    //     0x4f55a8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f55ac: stur            x0, [fp, #-0x28]
    // 0x4f55b0: r16 = "Automates recruiting associates"
    //     0x4f55b0: add             x16, PP, #0x16, lsl #12  ; [pp+0x163d8] "Automates recruiting associates"
    //     0x4f55b4: ldr             x16, [x16, #0x3d8]
    // 0x4f55b8: StoreField: r0->field_f = r16
    //     0x4f55b8: stur            w16, [x0, #0xf]
    // 0x4f55bc: r16 = "Doubles outreach and marketing campaign yields."
    //     0x4f55bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x163e0] "Doubles outreach and marketing campaign yields."
    //     0x4f55c0: ldr             x16, [x16, #0x3e0]
    // 0x4f55c4: StoreField: r0->field_13 = r16
    //     0x4f55c4: stur            w16, [x0, #0x13]
    // 0x4f55c8: r16 = "Doubles outreach and marketing campaign, and workshop yields."
    //     0x4f55c8: add             x16, PP, #0x16, lsl #12  ; [pp+0x163e8] "Doubles outreach and marketing campaign, and workshop yields."
    //     0x4f55cc: ldr             x16, [x16, #0x3e8]
    // 0x4f55d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f55d0: stur            w16, [x0, #0x17]
    // 0x4f55d4: r16 = "Doubles outreach and marketing campaign, and workshop yields again."
    //     0x4f55d4: add             x16, PP, #0x16, lsl #12  ; [pp+0x163f0] "Doubles outreach and marketing campaign, and workshop yields again."
    //     0x4f55d8: ldr             x16, [x16, #0x3f0]
    // 0x4f55dc: StoreField: r0->field_1b = r16
    //     0x4f55dc: stur            w16, [x0, #0x1b]
    // 0x4f55e0: r1 = <String>
    //     0x4f55e0: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f55e4: r0 = AllocateGrowableArray()
    //     0x4f55e4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f55e8: mov             x2, x0
    // 0x4f55ec: ldur            x0, [fp, #-0x28]
    // 0x4f55f0: stur            x2, [fp, #-0x30]
    // 0x4f55f4: StoreField: r2->field_f = r0
    //     0x4f55f4: stur            w0, [x2, #0xf]
    // 0x4f55f8: r0 = 8
    //     0x4f55f8: movz            x0, #0x8
    // 0x4f55fc: StoreField: r2->field_b = r0
    //     0x4f55fc: stur            w0, [x2, #0xb]
    // 0x4f5600: r1 = <String>
    //     0x4f5600: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5604: r0 = Generator()
    //     0x4f5604: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5608: mov             x3, x0
    // 0x4f560c: ldur            x0, [fp, #-0x30]
    // 0x4f5610: stur            x3, [fp, #-0x28]
    // 0x4f5614: StoreField: r3->field_b = r0
    //     0x4f5614: stur            w0, [x3, #0xb]
    // 0x4f5618: r1 = Null
    //     0x4f5618: mov             x1, NULL
    // 0x4f561c: r2 = 8
    //     0x4f561c: movz            x2, #0x8
    // 0x4f5620: r0 = AllocateArray()
    //     0x4f5620: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5624: stur            x0, [fp, #-0x30]
    // 0x4f5628: r16 = Instance_Tuple2
    //     0x4f5628: add             x16, PP, #0x16, lsl #12  ; [pp+0x163f8] Obj!Tuple2<Chapter11Stat, CustomNum>@822c91
    //     0x4f562c: ldr             x16, [x16, #0x3f8]
    // 0x4f5630: StoreField: r0->field_f = r16
    //     0x4f5630: stur            w16, [x0, #0xf]
    // 0x4f5634: r16 = Instance_Tuple2
    //     0x4f5634: add             x16, PP, #0x16, lsl #12  ; [pp+0x16400] Obj!Tuple2<Chapter11Stat, CustomNum>@822c71
    //     0x4f5638: ldr             x16, [x16, #0x400]
    // 0x4f563c: StoreField: r0->field_13 = r16
    //     0x4f563c: stur            w16, [x0, #0x13]
    // 0x4f5640: r16 = Instance_Tuple2
    //     0x4f5640: add             x16, PP, #0x16, lsl #12  ; [pp+0x16408] Obj!Tuple2<Chapter11Stat, CustomNum>@822c51
    //     0x4f5644: ldr             x16, [x16, #0x408]
    // 0x4f5648: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5648: stur            w16, [x0, #0x17]
    // 0x4f564c: r16 = Instance_Tuple2
    //     0x4f564c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16410] Obj!Tuple2<Chapter11Stat, CustomNum>@822c31
    //     0x4f5650: ldr             x16, [x16, #0x410]
    // 0x4f5654: StoreField: r0->field_1b = r16
    //     0x4f5654: stur            w16, [x0, #0x1b]
    // 0x4f5658: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5658: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f565c: ldr             x1, [x1, #0x3b8]
    // 0x4f5660: r0 = AllocateGrowableArray()
    //     0x4f5660: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5664: mov             x2, x0
    // 0x4f5668: ldur            x0, [fp, #-0x30]
    // 0x4f566c: stur            x2, [fp, #-0x38]
    // 0x4f5670: StoreField: r2->field_f = r0
    //     0x4f5670: stur            w0, [x2, #0xf]
    // 0x4f5674: r0 = 8
    //     0x4f5674: movz            x0, #0x8
    // 0x4f5678: StoreField: r2->field_b = r0
    //     0x4f5678: stur            w0, [x2, #0xb]
    // 0x4f567c: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f567c: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5680: ldr             x1, [x1, #0x3b8]
    // 0x4f5684: r0 = Generator()
    //     0x4f5684: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5688: mov             x2, x0
    // 0x4f568c: ldur            x0, [fp, #-0x38]
    // 0x4f5690: stur            x2, [fp, #-0x30]
    // 0x4f5694: StoreField: r2->field_b = r0
    //     0x4f5694: stur            w0, [x2, #0xb]
    // 0x4f5698: r1 = <Chapter11Stat>
    //     0x4f5698: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f569c: ldr             x1, [x1, #0xeb8]
    // 0x4f56a0: r0 = UpgradeData()
    //     0x4f56a0: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f56a4: mov             x3, x0
    // 0x4f56a8: ldur            x0, [fp, #-0x20]
    // 0x4f56ac: stur            x3, [fp, #-0x38]
    // 0x4f56b0: StoreField: r3->field_b = r0
    //     0x4f56b0: stur            w0, [x3, #0xb]
    // 0x4f56b4: ldur            x0, [fp, #-0x28]
    // 0x4f56b8: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f56b8: stur            w0, [x3, #0x17]
    // 0x4f56bc: r0 = Instance_IconData
    //     0x4f56bc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16418] Obj!IconData@82fe11
    //     0x4f56c0: ldr             x0, [x0, #0x418]
    // 0x4f56c4: StoreField: r3->field_13 = r0
    //     0x4f56c4: stur            w0, [x3, #0x13]
    // 0x4f56c8: ldur            x0, [fp, #-0x30]
    // 0x4f56cc: StoreField: r3->field_f = r0
    //     0x4f56cc: stur            w0, [x3, #0xf]
    // 0x4f56d0: ldur            x2, [fp, #-0x10]
    // 0x4f56d4: r1 = Function '<anonymous closure>':.
    //     0x4f56d4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16420] AnonymousClosure: (0x4f68c0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::ensureInitialized (0x4f52d4)
    //     0x4f56d8: ldr             x1, [x1, #0x420]
    // 0x4f56dc: r0 = AllocateClosure()
    //     0x4f56dc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f56e0: mov             x1, x0
    // 0x4f56e4: ldur            x0, [fp, #-0x38]
    // 0x4f56e8: StoreField: r0->field_1b = r1
    //     0x4f56e8: stur            w1, [x0, #0x1b]
    // 0x4f56ec: ldur            x1, [fp, #-0x18]
    // 0x4f56f0: ArrayStore: r1[3] = r0  ; List_4
    //     0x4f56f0: add             x25, x1, #0x1b
    //     0x4f56f4: str             w0, [x25]
    //     0x4f56f8: tbz             w0, #0, #0x4f5714
    //     0x4f56fc: ldurb           w16, [x1, #-1]
    //     0x4f5700: ldurb           w17, [x0, #-1]
    //     0x4f5704: and             x16, x17, x16, lsr #2
    //     0x4f5708: tst             x16, HEAP, lsr #32
    //     0x4f570c: b.eq            #0x4f5714
    //     0x4f5710: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f5714: ldur            x0, [fp, #-0x18]
    // 0x4f5718: r16 = 6
    //     0x4f5718: movz            x16, #0x6
    // 0x4f571c: StoreField: r0->field_1f = r16
    //     0x4f571c: stur            w16, [x0, #0x1f]
    // 0x4f5720: r1 = "Boost"
    //     0x4f5720: add             x1, PP, #0x16, lsl #12  ; [pp+0x16428] "Boost"
    //     0x4f5724: ldr             x1, [x1, #0x428]
    // 0x4f5728: r0 = autoString()
    //     0x4f5728: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f572c: r1 = Function '<anonymous closure>':.
    //     0x4f572c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16430] AnonymousClosure: (0x4f66c0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::ensureInitialized (0x4f52d4)
    //     0x4f5730: ldr             x1, [x1, #0x430]
    // 0x4f5734: r2 = Null
    //     0x4f5734: mov             x2, NULL
    // 0x4f5738: stur            x0, [fp, #-0x20]
    // 0x4f573c: r0 = AllocateClosure()
    //     0x4f573c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f5740: r1 = <String>
    //     0x4f5740: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5744: stur            x0, [fp, #-0x28]
    // 0x4f5748: r0 = Generator()
    //     0x4f5748: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f574c: ldur            x2, [fp, #-0x28]
    // 0x4f5750: r3 = Null
    //     0x4f5750: mov             x3, NULL
    // 0x4f5754: stur            x0, [fp, #-0x28]
    // 0x4f5758: r0 = AllocateRecord2()
    //     0x4f5758: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f575c: mov             x1, x0
    // 0x4f5760: ldur            x0, [fp, #-0x28]
    // 0x4f5764: StoreField: r0->field_f = r1
    //     0x4f5764: stur            w1, [x0, #0xf]
    // 0x4f5768: r1 = Null
    //     0x4f5768: mov             x1, NULL
    // 0x4f576c: r2 = 6
    //     0x4f576c: movz            x2, #0x6
    // 0x4f5770: r0 = AllocateArray()
    //     0x4f5770: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5774: stur            x0, [fp, #-0x30]
    // 0x4f5778: r16 = Instance_Tuple2
    //     0x4f5778: add             x16, PP, #0x16, lsl #12  ; [pp+0x16438] Obj!Tuple2<Chapter11Stat, CustomNum>@822c11
    //     0x4f577c: ldr             x16, [x16, #0x438]
    // 0x4f5780: StoreField: r0->field_f = r16
    //     0x4f5780: stur            w16, [x0, #0xf]
    // 0x4f5784: r16 = Instance_Tuple2
    //     0x4f5784: add             x16, PP, #0x16, lsl #12  ; [pp+0x16440] Obj!Tuple2<Chapter11Stat, CustomNum>@822bf1
    //     0x4f5788: ldr             x16, [x16, #0x440]
    // 0x4f578c: StoreField: r0->field_13 = r16
    //     0x4f578c: stur            w16, [x0, #0x13]
    // 0x4f5790: r16 = Instance_Tuple2
    //     0x4f5790: add             x16, PP, #0x16, lsl #12  ; [pp+0x16448] Obj!Tuple2<Chapter11Stat, CustomNum>@822bd1
    //     0x4f5794: ldr             x16, [x16, #0x448]
    // 0x4f5798: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5798: stur            w16, [x0, #0x17]
    // 0x4f579c: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f579c: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f57a0: ldr             x1, [x1, #0x3b8]
    // 0x4f57a4: r0 = AllocateGrowableArray()
    //     0x4f57a4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f57a8: mov             x2, x0
    // 0x4f57ac: ldur            x0, [fp, #-0x30]
    // 0x4f57b0: stur            x2, [fp, #-0x38]
    // 0x4f57b4: StoreField: r2->field_f = r0
    //     0x4f57b4: stur            w0, [x2, #0xf]
    // 0x4f57b8: r0 = 6
    //     0x4f57b8: movz            x0, #0x6
    // 0x4f57bc: StoreField: r2->field_b = r0
    //     0x4f57bc: stur            w0, [x2, #0xb]
    // 0x4f57c0: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f57c0: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f57c4: ldr             x1, [x1, #0x3b8]
    // 0x4f57c8: r0 = Generator()
    //     0x4f57c8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f57cc: mov             x2, x0
    // 0x4f57d0: ldur            x0, [fp, #-0x38]
    // 0x4f57d4: stur            x2, [fp, #-0x30]
    // 0x4f57d8: StoreField: r2->field_b = r0
    //     0x4f57d8: stur            w0, [x2, #0xb]
    // 0x4f57dc: r1 = <Chapter11Stat>
    //     0x4f57dc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f57e0: ldr             x1, [x1, #0xeb8]
    // 0x4f57e4: r0 = UpgradeData()
    //     0x4f57e4: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f57e8: mov             x1, x0
    // 0x4f57ec: ldur            x0, [fp, #-0x20]
    // 0x4f57f0: StoreField: r1->field_b = r0
    //     0x4f57f0: stur            w0, [x1, #0xb]
    // 0x4f57f4: ldur            x0, [fp, #-0x28]
    // 0x4f57f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x4f57f8: stur            w0, [x1, #0x17]
    // 0x4f57fc: r0 = Instance_IconData
    //     0x4f57fc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14858] Obj!IconData@82f5b1
    //     0x4f5800: ldr             x0, [x0, #0x858]
    // 0x4f5804: StoreField: r1->field_13 = r0
    //     0x4f5804: stur            w0, [x1, #0x13]
    // 0x4f5808: ldur            x0, [fp, #-0x30]
    // 0x4f580c: StoreField: r1->field_f = r0
    //     0x4f580c: stur            w0, [x1, #0xf]
    // 0x4f5810: mov             x0, x1
    // 0x4f5814: ldur            x1, [fp, #-0x18]
    // 0x4f5818: ArrayStore: r1[5] = r0  ; List_4
    //     0x4f5818: add             x25, x1, #0x23
    //     0x4f581c: str             w0, [x25]
    //     0x4f5820: tbz             w0, #0, #0x4f583c
    //     0x4f5824: ldurb           w16, [x1, #-1]
    //     0x4f5828: ldurb           w17, [x0, #-1]
    //     0x4f582c: and             x16, x17, x16, lsr #2
    //     0x4f5830: tst             x16, HEAP, lsr #32
    //     0x4f5834: b.eq            #0x4f583c
    //     0x4f5838: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f583c: ldur            x0, [fp, #-0x18]
    // 0x4f5840: r16 = 22
    //     0x4f5840: movz            x16, #0x16
    // 0x4f5844: StoreField: r0->field_27 = r16
    //     0x4f5844: stur            w16, [x0, #0x27]
    // 0x4f5848: r1 = "Community"
    //     0x4f5848: add             x1, PP, #0x16, lsl #12  ; [pp+0x16450] "Community"
    //     0x4f584c: ldr             x1, [x1, #0x450]
    // 0x4f5850: r0 = autoString()
    //     0x4f5850: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f5854: r1 = Null
    //     0x4f5854: mov             x1, NULL
    // 0x4f5858: r2 = 6
    //     0x4f5858: movz            x2, #0x6
    // 0x4f585c: stur            x0, [fp, #-0x20]
    // 0x4f5860: r0 = AllocateArray()
    //     0x4f5860: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5864: stur            x0, [fp, #-0x28]
    // 0x4f5868: r16 = "Allows autobuying engagement and velocity upgrades and doubles engagement and velocity gain"
    //     0x4f5868: add             x16, PP, #0x16, lsl #12  ; [pp+0x16458] "Allows autobuying engagement and velocity upgrades and doubles engagement and velocity gain"
    //     0x4f586c: ldr             x16, [x16, #0x458]
    // 0x4f5870: StoreField: r0->field_f = r16
    //     0x4f5870: stur            w16, [x0, #0xf]
    // 0x4f5874: r16 = "Allows autobuying engagement upgrades and 3× engagement and velocity gain"
    //     0x4f5874: add             x16, PP, #0x16, lsl #12  ; [pp+0x16460] "Allows autobuying engagement upgrades and 3× engagement and velocity gain"
    //     0x4f5878: ldr             x16, [x16, #0x460]
    // 0x4f587c: StoreField: r0->field_13 = r16
    //     0x4f587c: stur            w16, [x0, #0x13]
    // 0x4f5880: r16 = "Allows autobuying engagement upgrades and 4× engagement and velocity gain"
    //     0x4f5880: add             x16, PP, #0x16, lsl #12  ; [pp+0x16468] "Allows autobuying engagement upgrades and 4× engagement and velocity gain"
    //     0x4f5884: ldr             x16, [x16, #0x468]
    // 0x4f5888: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5888: stur            w16, [x0, #0x17]
    // 0x4f588c: r1 = <String>
    //     0x4f588c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5890: r0 = AllocateGrowableArray()
    //     0x4f5890: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5894: mov             x2, x0
    // 0x4f5898: ldur            x0, [fp, #-0x28]
    // 0x4f589c: stur            x2, [fp, #-0x30]
    // 0x4f58a0: StoreField: r2->field_f = r0
    //     0x4f58a0: stur            w0, [x2, #0xf]
    // 0x4f58a4: r0 = 6
    //     0x4f58a4: movz            x0, #0x6
    // 0x4f58a8: StoreField: r2->field_b = r0
    //     0x4f58a8: stur            w0, [x2, #0xb]
    // 0x4f58ac: r1 = <String>
    //     0x4f58ac: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f58b0: r0 = Generator()
    //     0x4f58b0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f58b4: mov             x3, x0
    // 0x4f58b8: ldur            x0, [fp, #-0x30]
    // 0x4f58bc: stur            x3, [fp, #-0x28]
    // 0x4f58c0: StoreField: r3->field_b = r0
    //     0x4f58c0: stur            w0, [x3, #0xb]
    // 0x4f58c4: r1 = Null
    //     0x4f58c4: mov             x1, NULL
    // 0x4f58c8: r2 = 6
    //     0x4f58c8: movz            x2, #0x6
    // 0x4f58cc: r0 = AllocateArray()
    //     0x4f58cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f58d0: stur            x0, [fp, #-0x30]
    // 0x4f58d4: r16 = Instance_Tuple2
    //     0x4f58d4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16470] Obj!Tuple2<Chapter11Stat, CustomNum>@822bb1
    //     0x4f58d8: ldr             x16, [x16, #0x470]
    // 0x4f58dc: StoreField: r0->field_f = r16
    //     0x4f58dc: stur            w16, [x0, #0xf]
    // 0x4f58e0: r16 = Instance_Tuple2
    //     0x4f58e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16478] Obj!Tuple2<Chapter11Stat, CustomNum>@822b91
    //     0x4f58e4: ldr             x16, [x16, #0x478]
    // 0x4f58e8: StoreField: r0->field_13 = r16
    //     0x4f58e8: stur            w16, [x0, #0x13]
    // 0x4f58ec: r16 = Instance_Tuple2
    //     0x4f58ec: add             x16, PP, #0x16, lsl #12  ; [pp+0x16480] Obj!Tuple2<Chapter11Stat, CustomNum>@822b71
    //     0x4f58f0: ldr             x16, [x16, #0x480]
    // 0x4f58f4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f58f4: stur            w16, [x0, #0x17]
    // 0x4f58f8: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f58f8: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f58fc: ldr             x1, [x1, #0x3b8]
    // 0x4f5900: r0 = AllocateGrowableArray()
    //     0x4f5900: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5904: mov             x2, x0
    // 0x4f5908: ldur            x0, [fp, #-0x30]
    // 0x4f590c: stur            x2, [fp, #-0x38]
    // 0x4f5910: StoreField: r2->field_f = r0
    //     0x4f5910: stur            w0, [x2, #0xf]
    // 0x4f5914: r0 = 6
    //     0x4f5914: movz            x0, #0x6
    // 0x4f5918: StoreField: r2->field_b = r0
    //     0x4f5918: stur            w0, [x2, #0xb]
    // 0x4f591c: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f591c: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5920: ldr             x1, [x1, #0x3b8]
    // 0x4f5924: r0 = Generator()
    //     0x4f5924: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5928: mov             x2, x0
    // 0x4f592c: ldur            x0, [fp, #-0x38]
    // 0x4f5930: stur            x2, [fp, #-0x30]
    // 0x4f5934: StoreField: r2->field_b = r0
    //     0x4f5934: stur            w0, [x2, #0xb]
    // 0x4f5938: r1 = <Chapter11Stat>
    //     0x4f5938: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f593c: ldr             x1, [x1, #0xeb8]
    // 0x4f5940: r0 = UpgradeData()
    //     0x4f5940: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5944: mov             x3, x0
    // 0x4f5948: ldur            x0, [fp, #-0x20]
    // 0x4f594c: stur            x3, [fp, #-0x38]
    // 0x4f5950: StoreField: r3->field_b = r0
    //     0x4f5950: stur            w0, [x3, #0xb]
    // 0x4f5954: ldur            x0, [fp, #-0x28]
    // 0x4f5958: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f5958: stur            w0, [x3, #0x17]
    // 0x4f595c: r0 = Instance_IconData
    //     0x4f595c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16488] Obj!IconData@82fdf1
    //     0x4f5960: ldr             x0, [x0, #0x488]
    // 0x4f5964: StoreField: r3->field_13 = r0
    //     0x4f5964: stur            w0, [x3, #0x13]
    // 0x4f5968: ldur            x0, [fp, #-0x30]
    // 0x4f596c: StoreField: r3->field_f = r0
    //     0x4f596c: stur            w0, [x3, #0xf]
    // 0x4f5970: ldur            x2, [fp, #-0x10]
    // 0x4f5974: r1 = Function '<anonymous closure>':.
    //     0x4f5974: add             x1, PP, #0x16, lsl #12  ; [pp+0x16490] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f5978: ldr             x1, [x1, #0x490]
    // 0x4f597c: r0 = AllocateClosure()
    //     0x4f597c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f5980: mov             x1, x0
    // 0x4f5984: ldur            x0, [fp, #-0x38]
    // 0x4f5988: StoreField: r0->field_1b = r1
    //     0x4f5988: stur            w1, [x0, #0x1b]
    // 0x4f598c: ldur            x1, [fp, #-0x18]
    // 0x4f5990: ArrayStore: r1[7] = r0  ; List_4
    //     0x4f5990: add             x25, x1, #0x2b
    //     0x4f5994: str             w0, [x25]
    //     0x4f5998: tbz             w0, #0, #0x4f59b4
    //     0x4f599c: ldurb           w16, [x1, #-1]
    //     0x4f59a0: ldurb           w17, [x0, #-1]
    //     0x4f59a4: and             x16, x17, x16, lsr #2
    //     0x4f59a8: tst             x16, HEAP, lsr #32
    //     0x4f59ac: b.eq            #0x4f59b4
    //     0x4f59b0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f59b4: ldur            x0, [fp, #-0x18]
    // 0x4f59b8: r16 = 24
    //     0x4f59b8: movz            x16, #0x18
    // 0x4f59bc: StoreField: r0->field_2f = r16
    //     0x4f59bc: stur            w16, [x0, #0x2f]
    // 0x4f59c0: r1 = "CRM"
    //     0x4f59c0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16498] "CRM"
    //     0x4f59c4: ldr             x1, [x1, #0x498]
    // 0x4f59c8: r0 = autoString()
    //     0x4f59c8: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f59cc: r1 = Function '<anonymous closure>':.
    //     0x4f59cc: add             x1, PP, #0x16, lsl #12  ; [pp+0x164a0] AnonymousClosure: (0x4f6180), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::ensureInitialized (0x4f52d4)
    //     0x4f59d0: ldr             x1, [x1, #0x4a0]
    // 0x4f59d4: r2 = Null
    //     0x4f59d4: mov             x2, NULL
    // 0x4f59d8: stur            x0, [fp, #-0x20]
    // 0x4f59dc: r0 = AllocateClosure()
    //     0x4f59dc: bl              #0x826750  ; AllocateClosureStub
    // 0x4f59e0: r1 = <String>
    //     0x4f59e0: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f59e4: stur            x0, [fp, #-0x28]
    // 0x4f59e8: r0 = Generator()
    //     0x4f59e8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f59ec: ldur            x2, [fp, #-0x28]
    // 0x4f59f0: r3 = Null
    //     0x4f59f0: mov             x3, NULL
    // 0x4f59f4: stur            x0, [fp, #-0x28]
    // 0x4f59f8: r0 = AllocateRecord2()
    //     0x4f59f8: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f59fc: mov             x1, x0
    // 0x4f5a00: ldur            x0, [fp, #-0x28]
    // 0x4f5a04: StoreField: r0->field_f = r1
    //     0x4f5a04: stur            w1, [x0, #0xf]
    // 0x4f5a08: r1 = Null
    //     0x4f5a08: mov             x1, NULL
    // 0x4f5a0c: r2 = 6
    //     0x4f5a0c: movz            x2, #0x6
    // 0x4f5a10: r0 = AllocateArray()
    //     0x4f5a10: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5a14: stur            x0, [fp, #-0x30]
    // 0x4f5a18: r16 = Instance_Tuple2
    //     0x4f5a18: add             x16, PP, #0x16, lsl #12  ; [pp+0x164a8] Obj!Tuple2<Chapter11Stat, CustomNum>@822b51
    //     0x4f5a1c: ldr             x16, [x16, #0x4a8]
    // 0x4f5a20: StoreField: r0->field_f = r16
    //     0x4f5a20: stur            w16, [x0, #0xf]
    // 0x4f5a24: r16 = Instance_Tuple2
    //     0x4f5a24: add             x16, PP, #0x16, lsl #12  ; [pp+0x164b0] Obj!Tuple2<Chapter11Stat, CustomNum>@822b31
    //     0x4f5a28: ldr             x16, [x16, #0x4b0]
    // 0x4f5a2c: StoreField: r0->field_13 = r16
    //     0x4f5a2c: stur            w16, [x0, #0x13]
    // 0x4f5a30: r16 = Instance_Tuple2
    //     0x4f5a30: add             x16, PP, #0x16, lsl #12  ; [pp+0x164b8] Obj!Tuple2<Chapter11Stat, CustomNum>@822b11
    //     0x4f5a34: ldr             x16, [x16, #0x4b8]
    // 0x4f5a38: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5a38: stur            w16, [x0, #0x17]
    // 0x4f5a3c: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5a3c: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5a40: ldr             x1, [x1, #0x3b8]
    // 0x4f5a44: r0 = AllocateGrowableArray()
    //     0x4f5a44: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5a48: mov             x2, x0
    // 0x4f5a4c: ldur            x0, [fp, #-0x30]
    // 0x4f5a50: stur            x2, [fp, #-0x38]
    // 0x4f5a54: StoreField: r2->field_f = r0
    //     0x4f5a54: stur            w0, [x2, #0xf]
    // 0x4f5a58: r0 = 6
    //     0x4f5a58: movz            x0, #0x6
    // 0x4f5a5c: StoreField: r2->field_b = r0
    //     0x4f5a5c: stur            w0, [x2, #0xb]
    // 0x4f5a60: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5a60: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5a64: ldr             x1, [x1, #0x3b8]
    // 0x4f5a68: r0 = Generator()
    //     0x4f5a68: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5a6c: mov             x2, x0
    // 0x4f5a70: ldur            x0, [fp, #-0x38]
    // 0x4f5a74: stur            x2, [fp, #-0x30]
    // 0x4f5a78: StoreField: r2->field_b = r0
    //     0x4f5a78: stur            w0, [x2, #0xb]
    // 0x4f5a7c: r1 = <Chapter11Stat>
    //     0x4f5a7c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f5a80: ldr             x1, [x1, #0xeb8]
    // 0x4f5a84: r0 = UpgradeData()
    //     0x4f5a84: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5a88: mov             x1, x0
    // 0x4f5a8c: ldur            x0, [fp, #-0x20]
    // 0x4f5a90: StoreField: r1->field_b = r0
    //     0x4f5a90: stur            w0, [x1, #0xb]
    // 0x4f5a94: ldur            x0, [fp, #-0x28]
    // 0x4f5a98: ArrayStore: r1[0] = r0  ; List_4
    //     0x4f5a98: stur            w0, [x1, #0x17]
    // 0x4f5a9c: r0 = Instance_IconData
    //     0x4f5a9c: add             x0, PP, #0x16, lsl #12  ; [pp+0x164c0] Obj!IconData@82fdd1
    //     0x4f5aa0: ldr             x0, [x0, #0x4c0]
    // 0x4f5aa4: StoreField: r1->field_13 = r0
    //     0x4f5aa4: stur            w0, [x1, #0x13]
    // 0x4f5aa8: ldur            x0, [fp, #-0x30]
    // 0x4f5aac: StoreField: r1->field_f = r0
    //     0x4f5aac: stur            w0, [x1, #0xf]
    // 0x4f5ab0: mov             x0, x1
    // 0x4f5ab4: ldur            x1, [fp, #-0x18]
    // 0x4f5ab8: ArrayStore: r1[9] = r0  ; List_4
    //     0x4f5ab8: add             x25, x1, #0x33
    //     0x4f5abc: str             w0, [x25]
    //     0x4f5ac0: tbz             w0, #0, #0x4f5adc
    //     0x4f5ac4: ldurb           w16, [x1, #-1]
    //     0x4f5ac8: ldurb           w17, [x0, #-1]
    //     0x4f5acc: and             x16, x17, x16, lsr #2
    //     0x4f5ad0: tst             x16, HEAP, lsr #32
    //     0x4f5ad4: b.eq            #0x4f5adc
    //     0x4f5ad8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f5adc: ldur            x0, [fp, #-0x18]
    // 0x4f5ae0: r16 = 26
    //     0x4f5ae0: movz            x16, #0x1a
    // 0x4f5ae4: StoreField: r0->field_37 = r16
    //     0x4f5ae4: stur            w16, [x0, #0x37]
    // 0x4f5ae8: r1 = "Cost Cutting"
    //     0x4f5ae8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14cd0] "Cost Cutting"
    //     0x4f5aec: ldr             x1, [x1, #0xcd0]
    // 0x4f5af0: r0 = autoString()
    //     0x4f5af0: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f5af4: r1 = Null
    //     0x4f5af4: mov             x1, NULL
    // 0x4f5af8: r2 = 6
    //     0x4f5af8: movz            x2, #0x6
    // 0x4f5afc: stur            x0, [fp, #-0x20]
    // 0x4f5b00: r0 = AllocateArray()
    //     0x4f5b00: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5b04: stur            x0, [fp, #-0x28]
    // 0x4f5b08: r16 = "Decreases the cost of all generators by 50%"
    //     0x4f5b08: add             x16, PP, #0x16, lsl #12  ; [pp+0x164c8] "Decreases the cost of all generators by 50%"
    //     0x4f5b0c: ldr             x16, [x16, #0x4c8]
    // 0x4f5b10: StoreField: r0->field_f = r16
    //     0x4f5b10: stur            w16, [x0, #0xf]
    // 0x4f5b14: r16 = "Decreases the cost of all generators by 90%"
    //     0x4f5b14: add             x16, PP, #0x16, lsl #12  ; [pp+0x164d0] "Decreases the cost of all generators by 90%"
    //     0x4f5b18: ldr             x16, [x16, #0x4d0]
    // 0x4f5b1c: StoreField: r0->field_13 = r16
    //     0x4f5b1c: stur            w16, [x0, #0x13]
    // 0x4f5b20: r16 = "Decreases the cost of all generators by 99%"
    //     0x4f5b20: add             x16, PP, #0x16, lsl #12  ; [pp+0x164d8] "Decreases the cost of all generators by 99%"
    //     0x4f5b24: ldr             x16, [x16, #0x4d8]
    // 0x4f5b28: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5b28: stur            w16, [x0, #0x17]
    // 0x4f5b2c: r1 = <String>
    //     0x4f5b2c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5b30: r0 = AllocateGrowableArray()
    //     0x4f5b30: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5b34: mov             x2, x0
    // 0x4f5b38: ldur            x0, [fp, #-0x28]
    // 0x4f5b3c: stur            x2, [fp, #-0x30]
    // 0x4f5b40: StoreField: r2->field_f = r0
    //     0x4f5b40: stur            w0, [x2, #0xf]
    // 0x4f5b44: r0 = 6
    //     0x4f5b44: movz            x0, #0x6
    // 0x4f5b48: StoreField: r2->field_b = r0
    //     0x4f5b48: stur            w0, [x2, #0xb]
    // 0x4f5b4c: r1 = <String>
    //     0x4f5b4c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5b50: r0 = Generator()
    //     0x4f5b50: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5b54: mov             x3, x0
    // 0x4f5b58: ldur            x0, [fp, #-0x30]
    // 0x4f5b5c: stur            x3, [fp, #-0x28]
    // 0x4f5b60: StoreField: r3->field_b = r0
    //     0x4f5b60: stur            w0, [x3, #0xb]
    // 0x4f5b64: r1 = Null
    //     0x4f5b64: mov             x1, NULL
    // 0x4f5b68: r2 = 6
    //     0x4f5b68: movz            x2, #0x6
    // 0x4f5b6c: r0 = AllocateArray()
    //     0x4f5b6c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5b70: stur            x0, [fp, #-0x30]
    // 0x4f5b74: r16 = Instance_Tuple2
    //     0x4f5b74: add             x16, PP, #0x16, lsl #12  ; [pp+0x164e0] Obj!Tuple2<Chapter11Stat, CustomNum>@822af1
    //     0x4f5b78: ldr             x16, [x16, #0x4e0]
    // 0x4f5b7c: StoreField: r0->field_f = r16
    //     0x4f5b7c: stur            w16, [x0, #0xf]
    // 0x4f5b80: r16 = Instance_Tuple2
    //     0x4f5b80: add             x16, PP, #0x16, lsl #12  ; [pp+0x164e8] Obj!Tuple2<Chapter11Stat, CustomNum>@822ad1
    //     0x4f5b84: ldr             x16, [x16, #0x4e8]
    // 0x4f5b88: StoreField: r0->field_13 = r16
    //     0x4f5b88: stur            w16, [x0, #0x13]
    // 0x4f5b8c: r16 = Instance_Tuple2
    //     0x4f5b8c: add             x16, PP, #0x16, lsl #12  ; [pp+0x164f0] Obj!Tuple2<Chapter11Stat, CustomNum>@822ab1
    //     0x4f5b90: ldr             x16, [x16, #0x4f0]
    // 0x4f5b94: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5b94: stur            w16, [x0, #0x17]
    // 0x4f5b98: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5b98: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5b9c: ldr             x1, [x1, #0x3b8]
    // 0x4f5ba0: r0 = AllocateGrowableArray()
    //     0x4f5ba0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5ba4: mov             x2, x0
    // 0x4f5ba8: ldur            x0, [fp, #-0x30]
    // 0x4f5bac: stur            x2, [fp, #-0x38]
    // 0x4f5bb0: StoreField: r2->field_f = r0
    //     0x4f5bb0: stur            w0, [x2, #0xf]
    // 0x4f5bb4: r0 = 6
    //     0x4f5bb4: movz            x0, #0x6
    // 0x4f5bb8: StoreField: r2->field_b = r0
    //     0x4f5bb8: stur            w0, [x2, #0xb]
    // 0x4f5bbc: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5bbc: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5bc0: ldr             x1, [x1, #0x3b8]
    // 0x4f5bc4: r0 = Generator()
    //     0x4f5bc4: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5bc8: mov             x2, x0
    // 0x4f5bcc: ldur            x0, [fp, #-0x38]
    // 0x4f5bd0: stur            x2, [fp, #-0x30]
    // 0x4f5bd4: StoreField: r2->field_b = r0
    //     0x4f5bd4: stur            w0, [x2, #0xb]
    // 0x4f5bd8: r1 = <Chapter11Stat>
    //     0x4f5bd8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f5bdc: ldr             x1, [x1, #0xeb8]
    // 0x4f5be0: r0 = UpgradeData()
    //     0x4f5be0: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5be4: mov             x3, x0
    // 0x4f5be8: ldur            x0, [fp, #-0x20]
    // 0x4f5bec: stur            x3, [fp, #-0x38]
    // 0x4f5bf0: StoreField: r3->field_b = r0
    //     0x4f5bf0: stur            w0, [x3, #0xb]
    // 0x4f5bf4: ldur            x0, [fp, #-0x28]
    // 0x4f5bf8: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f5bf8: stur            w0, [x3, #0x17]
    // 0x4f5bfc: r0 = Instance_IconData
    //     0x4f5bfc: add             x0, PP, #0x16, lsl #12  ; [pp+0x164f8] Obj!IconData@82fdb1
    //     0x4f5c00: ldr             x0, [x0, #0x4f8]
    // 0x4f5c04: StoreField: r3->field_13 = r0
    //     0x4f5c04: stur            w0, [x3, #0x13]
    // 0x4f5c08: ldur            x0, [fp, #-0x30]
    // 0x4f5c0c: StoreField: r3->field_f = r0
    //     0x4f5c0c: stur            w0, [x3, #0xf]
    // 0x4f5c10: ldur            x2, [fp, #-0x10]
    // 0x4f5c14: r1 = Function '<anonymous closure>':.
    //     0x4f5c14: add             x1, PP, #0x16, lsl #12  ; [pp+0x16500] AnonymousClosure: (0x4f6138), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f5c18: ldr             x1, [x1, #0x500]
    // 0x4f5c1c: r0 = AllocateClosure()
    //     0x4f5c1c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f5c20: mov             x1, x0
    // 0x4f5c24: ldur            x0, [fp, #-0x38]
    // 0x4f5c28: StoreField: r0->field_1b = r1
    //     0x4f5c28: stur            w1, [x0, #0x1b]
    // 0x4f5c2c: ldur            x1, [fp, #-0x18]
    // 0x4f5c30: ArrayStore: r1[11] = r0  ; List_4
    //     0x4f5c30: add             x25, x1, #0x3b
    //     0x4f5c34: str             w0, [x25]
    //     0x4f5c38: tbz             w0, #0, #0x4f5c54
    //     0x4f5c3c: ldurb           w16, [x1, #-1]
    //     0x4f5c40: ldurb           w17, [x0, #-1]
    //     0x4f5c44: and             x16, x17, x16, lsr #2
    //     0x4f5c48: tst             x16, HEAP, lsr #32
    //     0x4f5c4c: b.eq            #0x4f5c54
    //     0x4f5c50: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f5c54: ldur            x0, [fp, #-0x18]
    // 0x4f5c58: r16 = 28
    //     0x4f5c58: movz            x16, #0x1c
    // 0x4f5c5c: StoreField: r0->field_3f = r16
    //     0x4f5c5c: stur            w16, [x0, #0x3f]
    // 0x4f5c60: r1 = "Positions"
    //     0x4f5c60: add             x1, PP, #0x16, lsl #12  ; [pp+0x16508] "Positions"
    //     0x4f5c64: ldr             x1, [x1, #0x508]
    // 0x4f5c68: r0 = autoString()
    //     0x4f5c68: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f5c6c: r1 = Null
    //     0x4f5c6c: mov             x1, NULL
    // 0x4f5c70: r2 = 6
    //     0x4f5c70: movz            x2, #0x6
    // 0x4f5c74: stur            x0, [fp, #-0x10]
    // 0x4f5c78: r0 = AllocateArray()
    //     0x4f5c78: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5c7c: stur            x0, [fp, #-0x20]
    // 0x4f5c80: r16 = "Tier 1 upgrades are not reset between prestiges."
    //     0x4f5c80: add             x16, PP, #0x16, lsl #12  ; [pp+0x16510] "Tier 1 upgrades are not reset between prestiges."
    //     0x4f5c84: ldr             x16, [x16, #0x510]
    // 0x4f5c88: StoreField: r0->field_f = r16
    //     0x4f5c88: stur            w16, [x0, #0xf]
    // 0x4f5c8c: r16 = "Tier 2 upgrades are not reset between prestiges."
    //     0x4f5c8c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16518] "Tier 2 upgrades are not reset between prestiges."
    //     0x4f5c90: ldr             x16, [x16, #0x518]
    // 0x4f5c94: StoreField: r0->field_13 = r16
    //     0x4f5c94: stur            w16, [x0, #0x13]
    // 0x4f5c98: r16 = "Tier 2 quests are not reset between prestiges."
    //     0x4f5c98: add             x16, PP, #0x16, lsl #12  ; [pp+0x16520] "Tier 2 quests are not reset between prestiges."
    //     0x4f5c9c: ldr             x16, [x16, #0x520]
    // 0x4f5ca0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5ca0: stur            w16, [x0, #0x17]
    // 0x4f5ca4: r1 = <String>
    //     0x4f5ca4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5ca8: r0 = AllocateGrowableArray()
    //     0x4f5ca8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5cac: mov             x2, x0
    // 0x4f5cb0: ldur            x0, [fp, #-0x20]
    // 0x4f5cb4: stur            x2, [fp, #-0x28]
    // 0x4f5cb8: StoreField: r2->field_f = r0
    //     0x4f5cb8: stur            w0, [x2, #0xf]
    // 0x4f5cbc: r0 = 6
    //     0x4f5cbc: movz            x0, #0x6
    // 0x4f5cc0: StoreField: r2->field_b = r0
    //     0x4f5cc0: stur            w0, [x2, #0xb]
    // 0x4f5cc4: r1 = <String>
    //     0x4f5cc4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5cc8: r0 = Generator()
    //     0x4f5cc8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5ccc: mov             x3, x0
    // 0x4f5cd0: ldur            x0, [fp, #-0x28]
    // 0x4f5cd4: stur            x3, [fp, #-0x20]
    // 0x4f5cd8: StoreField: r3->field_b = r0
    //     0x4f5cd8: stur            w0, [x3, #0xb]
    // 0x4f5cdc: r1 = Null
    //     0x4f5cdc: mov             x1, NULL
    // 0x4f5ce0: r2 = 6
    //     0x4f5ce0: movz            x2, #0x6
    // 0x4f5ce4: r0 = AllocateArray()
    //     0x4f5ce4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5ce8: stur            x0, [fp, #-0x28]
    // 0x4f5cec: r16 = Instance_Tuple2
    //     0x4f5cec: add             x16, PP, #0x16, lsl #12  ; [pp+0x16528] Obj!Tuple2<Chapter11Stat, CustomNum>@822a91
    //     0x4f5cf0: ldr             x16, [x16, #0x528]
    // 0x4f5cf4: StoreField: r0->field_f = r16
    //     0x4f5cf4: stur            w16, [x0, #0xf]
    // 0x4f5cf8: r16 = Instance_Tuple2
    //     0x4f5cf8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16530] Obj!Tuple2<Chapter11Stat, CustomNum>@822a71
    //     0x4f5cfc: ldr             x16, [x16, #0x530]
    // 0x4f5d00: StoreField: r0->field_13 = r16
    //     0x4f5d00: stur            w16, [x0, #0x13]
    // 0x4f5d04: r16 = Instance_Tuple2
    //     0x4f5d04: add             x16, PP, #0x16, lsl #12  ; [pp+0x16538] Obj!Tuple2<Chapter11Stat, CustomNum>@822a51
    //     0x4f5d08: ldr             x16, [x16, #0x538]
    // 0x4f5d0c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f5d0c: stur            w16, [x0, #0x17]
    // 0x4f5d10: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5d10: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5d14: ldr             x1, [x1, #0x3b8]
    // 0x4f5d18: r0 = AllocateGrowableArray()
    //     0x4f5d18: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5d1c: mov             x2, x0
    // 0x4f5d20: ldur            x0, [fp, #-0x28]
    // 0x4f5d24: stur            x2, [fp, #-0x30]
    // 0x4f5d28: StoreField: r2->field_f = r0
    //     0x4f5d28: stur            w0, [x2, #0xf]
    // 0x4f5d2c: r0 = 6
    //     0x4f5d2c: movz            x0, #0x6
    // 0x4f5d30: StoreField: r2->field_b = r0
    //     0x4f5d30: stur            w0, [x2, #0xb]
    // 0x4f5d34: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5d34: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5d38: ldr             x1, [x1, #0x3b8]
    // 0x4f5d3c: r0 = Generator()
    //     0x4f5d3c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5d40: mov             x2, x0
    // 0x4f5d44: ldur            x0, [fp, #-0x30]
    // 0x4f5d48: stur            x2, [fp, #-0x28]
    // 0x4f5d4c: StoreField: r2->field_b = r0
    //     0x4f5d4c: stur            w0, [x2, #0xb]
    // 0x4f5d50: r1 = <Chapter11Stat>
    //     0x4f5d50: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f5d54: ldr             x1, [x1, #0xeb8]
    // 0x4f5d58: r0 = UpgradeData()
    //     0x4f5d58: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5d5c: mov             x1, x0
    // 0x4f5d60: ldur            x0, [fp, #-0x10]
    // 0x4f5d64: StoreField: r1->field_b = r0
    //     0x4f5d64: stur            w0, [x1, #0xb]
    // 0x4f5d68: ldur            x0, [fp, #-0x20]
    // 0x4f5d6c: ArrayStore: r1[0] = r0  ; List_4
    //     0x4f5d6c: stur            w0, [x1, #0x17]
    // 0x4f5d70: r0 = Instance_IconData
    //     0x4f5d70: add             x0, PP, #0x16, lsl #12  ; [pp+0x16540] Obj!IconData@82fd91
    //     0x4f5d74: ldr             x0, [x0, #0x540]
    // 0x4f5d78: StoreField: r1->field_13 = r0
    //     0x4f5d78: stur            w0, [x1, #0x13]
    // 0x4f5d7c: ldur            x0, [fp, #-0x28]
    // 0x4f5d80: StoreField: r1->field_f = r0
    //     0x4f5d80: stur            w0, [x1, #0xf]
    // 0x4f5d84: mov             x0, x1
    // 0x4f5d88: ldur            x1, [fp, #-0x18]
    // 0x4f5d8c: ArrayStore: r1[13] = r0  ; List_4
    //     0x4f5d8c: add             x25, x1, #0x43
    //     0x4f5d90: str             w0, [x25]
    //     0x4f5d94: tbz             w0, #0, #0x4f5db0
    //     0x4f5d98: ldurb           w16, [x1, #-1]
    //     0x4f5d9c: ldurb           w17, [x0, #-1]
    //     0x4f5da0: and             x16, x17, x16, lsr #2
    //     0x4f5da4: tst             x16, HEAP, lsr #32
    //     0x4f5da8: b.eq            #0x4f5db0
    //     0x4f5dac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f5db0: ldur            x0, [fp, #-0x18]
    // 0x4f5db4: r16 = 42
    //     0x4f5db4: movz            x16, #0x2a
    // 0x4f5db8: StoreField: r0->field_47 = r16
    //     0x4f5db8: stur            w16, [x0, #0x47]
    // 0x4f5dbc: r1 = "Auto Promote"
    //     0x4f5dbc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16548] "Auto Promote"
    //     0x4f5dc0: ldr             x1, [x1, #0x548]
    // 0x4f5dc4: r0 = autoString()
    //     0x4f5dc4: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f5dc8: r1 = Null
    //     0x4f5dc8: mov             x1, NULL
    // 0x4f5dcc: r2 = 4
    //     0x4f5dcc: movz            x2, #0x4
    // 0x4f5dd0: stur            x0, [fp, #-0x10]
    // 0x4f5dd4: r0 = AllocateArray()
    //     0x4f5dd4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5dd8: stur            x0, [fp, #-0x20]
    // 0x4f5ddc: r16 = "Auto generate silver members at the rate of 1% per second."
    //     0x4f5ddc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] "Auto generate silver members at the rate of 1% per second."
    //     0x4f5de0: ldr             x16, [x16, #0x550]
    // 0x4f5de4: StoreField: r0->field_f = r16
    //     0x4f5de4: stur            w16, [x0, #0xf]
    // 0x4f5de8: r16 = "Auto generate silver members at the rate of 1% per second and gold at a much lower rate."
    //     0x4f5de8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16558] "Auto generate silver members at the rate of 1% per second and gold at a much lower rate."
    //     0x4f5dec: ldr             x16, [x16, #0x558]
    // 0x4f5df0: StoreField: r0->field_13 = r16
    //     0x4f5df0: stur            w16, [x0, #0x13]
    // 0x4f5df4: r1 = <String>
    //     0x4f5df4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5df8: r0 = AllocateGrowableArray()
    //     0x4f5df8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5dfc: mov             x2, x0
    // 0x4f5e00: ldur            x0, [fp, #-0x20]
    // 0x4f5e04: stur            x2, [fp, #-0x28]
    // 0x4f5e08: StoreField: r2->field_f = r0
    //     0x4f5e08: stur            w0, [x2, #0xf]
    // 0x4f5e0c: r0 = 4
    //     0x4f5e0c: movz            x0, #0x4
    // 0x4f5e10: StoreField: r2->field_b = r0
    //     0x4f5e10: stur            w0, [x2, #0xb]
    // 0x4f5e14: r1 = <String>
    //     0x4f5e14: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5e18: r0 = Generator()
    //     0x4f5e18: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5e1c: mov             x3, x0
    // 0x4f5e20: ldur            x0, [fp, #-0x28]
    // 0x4f5e24: stur            x3, [fp, #-0x20]
    // 0x4f5e28: StoreField: r3->field_b = r0
    //     0x4f5e28: stur            w0, [x3, #0xb]
    // 0x4f5e2c: r1 = Null
    //     0x4f5e2c: mov             x1, NULL
    // 0x4f5e30: r2 = 4
    //     0x4f5e30: movz            x2, #0x4
    // 0x4f5e34: r0 = AllocateArray()
    //     0x4f5e34: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5e38: stur            x0, [fp, #-0x28]
    // 0x4f5e3c: r16 = Instance_Tuple2
    //     0x4f5e3c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16530] Obj!Tuple2<Chapter11Stat, CustomNum>@822a71
    //     0x4f5e40: ldr             x16, [x16, #0x530]
    // 0x4f5e44: StoreField: r0->field_f = r16
    //     0x4f5e44: stur            w16, [x0, #0xf]
    // 0x4f5e48: r16 = Instance_Tuple2
    //     0x4f5e48: add             x16, PP, #0x16, lsl #12  ; [pp+0x16560] Obj!Tuple2<Chapter11Stat, CustomNum>@822a31
    //     0x4f5e4c: ldr             x16, [x16, #0x560]
    // 0x4f5e50: StoreField: r0->field_13 = r16
    //     0x4f5e50: stur            w16, [x0, #0x13]
    // 0x4f5e54: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5e54: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5e58: ldr             x1, [x1, #0x3b8]
    // 0x4f5e5c: r0 = AllocateGrowableArray()
    //     0x4f5e5c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5e60: mov             x2, x0
    // 0x4f5e64: ldur            x0, [fp, #-0x28]
    // 0x4f5e68: stur            x2, [fp, #-0x30]
    // 0x4f5e6c: StoreField: r2->field_f = r0
    //     0x4f5e6c: stur            w0, [x2, #0xf]
    // 0x4f5e70: r0 = 4
    //     0x4f5e70: movz            x0, #0x4
    // 0x4f5e74: StoreField: r2->field_b = r0
    //     0x4f5e74: stur            w0, [x2, #0xb]
    // 0x4f5e78: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5e78: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5e7c: ldr             x1, [x1, #0x3b8]
    // 0x4f5e80: r0 = Generator()
    //     0x4f5e80: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5e84: mov             x2, x0
    // 0x4f5e88: ldur            x0, [fp, #-0x30]
    // 0x4f5e8c: stur            x2, [fp, #-0x28]
    // 0x4f5e90: StoreField: r2->field_b = r0
    //     0x4f5e90: stur            w0, [x2, #0xb]
    // 0x4f5e94: r1 = <Chapter11Stat>
    //     0x4f5e94: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f5e98: ldr             x1, [x1, #0xeb8]
    // 0x4f5e9c: r0 = UpgradeData()
    //     0x4f5e9c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5ea0: mov             x1, x0
    // 0x4f5ea4: ldur            x0, [fp, #-0x10]
    // 0x4f5ea8: StoreField: r1->field_b = r0
    //     0x4f5ea8: stur            w0, [x1, #0xb]
    // 0x4f5eac: ldur            x0, [fp, #-0x20]
    // 0x4f5eb0: ArrayStore: r1[0] = r0  ; List_4
    //     0x4f5eb0: stur            w0, [x1, #0x17]
    // 0x4f5eb4: r0 = Instance_IconData
    //     0x4f5eb4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16568] Obj!IconData@82fd71
    //     0x4f5eb8: ldr             x0, [x0, #0x568]
    // 0x4f5ebc: StoreField: r1->field_13 = r0
    //     0x4f5ebc: stur            w0, [x1, #0x13]
    // 0x4f5ec0: ldur            x0, [fp, #-0x28]
    // 0x4f5ec4: StoreField: r1->field_f = r0
    //     0x4f5ec4: stur            w0, [x1, #0xf]
    // 0x4f5ec8: mov             x0, x1
    // 0x4f5ecc: ldur            x1, [fp, #-0x18]
    // 0x4f5ed0: ArrayStore: r1[15] = r0  ; List_4
    //     0x4f5ed0: add             x25, x1, #0x4b
    //     0x4f5ed4: str             w0, [x25]
    //     0x4f5ed8: tbz             w0, #0, #0x4f5ef4
    //     0x4f5edc: ldurb           w16, [x1, #-1]
    //     0x4f5ee0: ldurb           w17, [x0, #-1]
    //     0x4f5ee4: and             x16, x17, x16, lsr #2
    //     0x4f5ee8: tst             x16, HEAP, lsr #32
    //     0x4f5eec: b.eq            #0x4f5ef4
    //     0x4f5ef0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f5ef4: ldur            x0, [fp, #-0x18]
    // 0x4f5ef8: r16 = 44
    //     0x4f5ef8: movz            x16, #0x2c
    // 0x4f5efc: StoreField: r0->field_4f = r16
    //     0x4f5efc: stur            w16, [x0, #0x4f]
    // 0x4f5f00: r1 = "Expansion"
    //     0x4f5f00: add             x1, PP, #0x16, lsl #12  ; [pp+0x16570] "Expansion"
    //     0x4f5f04: ldr             x1, [x1, #0x570]
    // 0x4f5f08: r0 = autoString()
    //     0x4f5f08: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4f5f0c: r1 = Function '<anonymous closure>':.
    //     0x4f5f0c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16578] AnonymousClosure: (0x4f612c), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::ensureInitialized (0x4f52d4)
    //     0x4f5f10: ldr             x1, [x1, #0x578]
    // 0x4f5f14: r2 = Null
    //     0x4f5f14: mov             x2, NULL
    // 0x4f5f18: stur            x0, [fp, #-0x10]
    // 0x4f5f1c: r0 = AllocateClosure()
    //     0x4f5f1c: bl              #0x826750  ; AllocateClosureStub
    // 0x4f5f20: r1 = <String>
    //     0x4f5f20: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4f5f24: stur            x0, [fp, #-0x20]
    // 0x4f5f28: r0 = Generator()
    //     0x4f5f28: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5f2c: ldur            x2, [fp, #-0x20]
    // 0x4f5f30: r3 = Null
    //     0x4f5f30: mov             x3, NULL
    // 0x4f5f34: stur            x0, [fp, #-0x20]
    // 0x4f5f38: r0 = AllocateRecord2()
    //     0x4f5f38: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x4f5f3c: mov             x1, x0
    // 0x4f5f40: ldur            x0, [fp, #-0x20]
    // 0x4f5f44: StoreField: r0->field_f = r1
    //     0x4f5f44: stur            w1, [x0, #0xf]
    // 0x4f5f48: r1 = Null
    //     0x4f5f48: mov             x1, NULL
    // 0x4f5f4c: r2 = 2
    //     0x4f5f4c: movz            x2, #0x2
    // 0x4f5f50: r0 = AllocateArray()
    //     0x4f5f50: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f5f54: stur            x0, [fp, #-0x28]
    // 0x4f5f58: r16 = Instance_Tuple2
    //     0x4f5f58: add             x16, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Tuple2<Chapter11Stat, CustomNum>@822a11
    //     0x4f5f5c: ldr             x16, [x16, #0x580]
    // 0x4f5f60: StoreField: r0->field_f = r16
    //     0x4f5f60: stur            w16, [x0, #0xf]
    // 0x4f5f64: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5f64: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5f68: ldr             x1, [x1, #0x3b8]
    // 0x4f5f6c: r0 = AllocateGrowableArray()
    //     0x4f5f6c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4f5f70: mov             x2, x0
    // 0x4f5f74: ldur            x0, [fp, #-0x28]
    // 0x4f5f78: stur            x2, [fp, #-0x30]
    // 0x4f5f7c: StoreField: r2->field_f = r0
    //     0x4f5f7c: stur            w0, [x2, #0xf]
    // 0x4f5f80: r0 = 2
    //     0x4f5f80: movz            x0, #0x2
    // 0x4f5f84: StoreField: r2->field_b = r0
    //     0x4f5f84: stur            w0, [x2, #0xb]
    // 0x4f5f88: r1 = <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5f88: add             x1, PP, #0x16, lsl #12  ; [pp+0x163b8] TypeArguments: <Tuple2<Chapter11Stat, CustomNum>>
    //     0x4f5f8c: ldr             x1, [x1, #0x3b8]
    // 0x4f5f90: r0 = Generator()
    //     0x4f5f90: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4f5f94: mov             x2, x0
    // 0x4f5f98: ldur            x0, [fp, #-0x30]
    // 0x4f5f9c: stur            x2, [fp, #-0x28]
    // 0x4f5fa0: StoreField: r2->field_b = r0
    //     0x4f5fa0: stur            w0, [x2, #0xb]
    // 0x4f5fa4: r1 = <Chapter11Stat>
    //     0x4f5fa4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4f5fa8: ldr             x1, [x1, #0xeb8]
    // 0x4f5fac: r0 = UpgradeData()
    //     0x4f5fac: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4f5fb0: mov             x3, x0
    // 0x4f5fb4: ldur            x0, [fp, #-0x10]
    // 0x4f5fb8: stur            x3, [fp, #-0x30]
    // 0x4f5fbc: StoreField: r3->field_b = r0
    //     0x4f5fbc: stur            w0, [x3, #0xb]
    // 0x4f5fc0: ldur            x0, [fp, #-0x20]
    // 0x4f5fc4: ArrayStore: r3[0] = r0  ; List_4
    //     0x4f5fc4: stur            w0, [x3, #0x17]
    // 0x4f5fc8: r0 = Instance_IconData
    //     0x4f5fc8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16588] Obj!IconData@82fd51
    //     0x4f5fcc: ldr             x0, [x0, #0x588]
    // 0x4f5fd0: StoreField: r3->field_13 = r0
    //     0x4f5fd0: stur            w0, [x3, #0x13]
    // 0x4f5fd4: ldur            x0, [fp, #-0x28]
    // 0x4f5fd8: StoreField: r3->field_f = r0
    //     0x4f5fd8: stur            w0, [x3, #0xf]
    // 0x4f5fdc: r1 = Function '<anonymous closure>':.
    //     0x4f5fdc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16590] AnonymousClosure: (0x4f60e8), in [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::ensureInitialized (0x4fa448)
    //     0x4f5fe0: ldr             x1, [x1, #0x590]
    // 0x4f5fe4: r2 = Null
    //     0x4f5fe4: mov             x2, NULL
    // 0x4f5fe8: r0 = AllocateClosure()
    //     0x4f5fe8: bl              #0x826750  ; AllocateClosureStub
    // 0x4f5fec: mov             x1, x0
    // 0x4f5ff0: ldur            x0, [fp, #-0x30]
    // 0x4f5ff4: StoreField: r0->field_1b = r1
    //     0x4f5ff4: stur            w1, [x0, #0x1b]
    // 0x4f5ff8: ldur            x1, [fp, #-0x18]
    // 0x4f5ffc: ArrayStore: r1[17] = r0  ; List_4
    //     0x4f5ffc: add             x25, x1, #0x53
    //     0x4f6000: str             w0, [x25]
    //     0x4f6004: tbz             w0, #0, #0x4f6020
    //     0x4f6008: ldurb           w16, [x1, #-1]
    //     0x4f600c: ldurb           w17, [x0, #-1]
    //     0x4f6010: and             x16, x17, x16, lsr #2
    //     0x4f6014: tst             x16, HEAP, lsr #32
    //     0x4f6018: b.eq            #0x4f6020
    //     0x4f601c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f6020: r16 = <int, UpgradeData<Chapter11Stat>>
    //     0x4f6020: add             x16, PP, #0x16, lsl #12  ; [pp+0x16598] TypeArguments: <int, UpgradeData<Chapter11Stat>>
    //     0x4f6024: ldr             x16, [x16, #0x598]
    // 0x4f6028: ldur            lr, [fp, #-0x18]
    // 0x4f602c: stp             lr, x16, [SP]
    // 0x4f6030: r0 = Map._fromLiteral()
    //     0x4f6030: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4f6034: ldur            x1, [fp, #-8]
    // 0x4f6038: StoreField: r1->field_8f = r0
    //     0x4f6038: stur            w0, [x1, #0x8f]
    //     0x4f603c: ldurb           w16, [x1, #-1]
    //     0x4f6040: ldurb           w17, [x0, #-1]
    //     0x4f6044: and             x16, x17, x16, lsr #2
    //     0x4f6048: tst             x16, HEAP, lsr #32
    //     0x4f604c: b.eq            #0x4f6054
    //     0x4f6050: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4f6054: r0 = Null
    //     0x4f6054: mov             x0, NULL
    // 0x4f6058: LeaveFrame
    //     0x4f6058: mov             SP, fp
    //     0x4f605c: ldp             fp, lr, [SP], #0x10
    // 0x4f6060: ret
    //     0x4f6060: ret             
    // 0x4f6064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f6064: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f6068: b               #0x4f52f0
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f612c, size: 0xc
    // 0x4f612c: r0 = "Adds buy options to tier 3 generators and doubles all prestige yields"
    //     0x4f612c: add             x0, PP, #0x16, lsl #12  ; [pp+0x165a0] "Adds buy options to tier 3 generators and doubles all prestige yields"
    //     0x4f6130: ldr             x0, [x0, #0x5a0]
    // 0x4f6134: ret
    //     0x4f6134: ret             
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f6180, size: 0x274
    // 0x4f6180: EnterFrame
    //     0x4f6180: stp             fp, lr, [SP, #-0x10]!
    //     0x4f6184: mov             fp, SP
    // 0x4f6188: AllocStack(0x20)
    //     0x4f6188: sub             SP, SP, #0x20
    // 0x4f618c: CheckStackOverflow
    //     0x4f618c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f6190: cmp             SP, x16
    //     0x4f6194: b.ls            #0x4f63d4
    // 0x4f6198: r1 = Null
    //     0x4f6198: mov             x1, NULL
    // 0x4f619c: r2 = 6
    //     0x4f619c: movz            x2, #0x6
    // 0x4f61a0: r0 = AllocateArray()
    //     0x4f61a0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f61a4: mov             x2, x0
    // 0x4f61a8: stur            x2, [fp, #-8]
    // 0x4f61ac: r16 = "Keep "
    //     0x4f61ac: add             x16, PP, #0x16, lsl #12  ; [pp+0x165a8] "Keep "
    //     0x4f61b0: ldr             x16, [x16, #0x5a8]
    // 0x4f61b4: StoreField: r2->field_f = r16
    //     0x4f61b4: stur            w16, [x2, #0xf]
    // 0x4f61b8: ldr             x0, [fp, #0x10]
    // 0x4f61bc: r1 = LoadInt32Instr(r0)
    //     0x4f61bc: sbfx            x1, x0, #1, #0x1f
    //     0x4f61c0: tbz             w0, #0, #0x4f61c8
    //     0x4f61c4: ldur            x1, [x0, #7]
    // 0x4f61c8: tbnz            x1, #0x3f, #0x4f622c
    // 0x4f61cc: mov             x0, x1
    // 0x4f61d0: r1 = 2
    //     0x4f61d0: movz            x1, #0x2
    // 0x4f61d4: r3 = 1
    //     0x4f61d4: movz            x3, #0x1
    // 0x4f61d8: CheckStackOverflow
    //     0x4f61d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f61dc: cmp             SP, x16
    //     0x4f61e0: b.ls            #0x4f63dc
    // 0x4f61e4: cbz             x0, #0x4f620c
    // 0x4f61e8: branchIfSmi(r0, 0x4f61f4)
    //     0x4f61e8: tbz             w0, #0, #0x4f61f4
    // 0x4f61ec: mul             x4, x3, x1
    // 0x4f61f0: mov             x3, x4
    // 0x4f61f4: asr             x4, x0, #1
    // 0x4f61f8: cbz             x4, #0x4f6204
    // 0x4f61fc: mul             x5, x1, x1
    // 0x4f6200: mov             x1, x5
    // 0x4f6204: mov             x0, x4
    // 0x4f6208: b               #0x4f61d8
    // 0x4f620c: r0 = BoxInt64Instr(r3)
    //     0x4f620c: sbfiz           x0, x3, #1, #0x1f
    //     0x4f6210: cmp             x3, x0, asr #1
    //     0x4f6214: b.eq            #0x4f6220
    //     0x4f6218: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4f621c: stur            x3, [x0, #7]
    // 0x4f6220: mov             x1, x0
    // 0x4f6224: mov             x0, x2
    // 0x4f6228: b               #0x4f6384
    // 0x4f622c: r16 = 4
    //     0x4f622c: movz            x16, #0x4
    // 0x4f6230: stp             x16, NULL, [SP]
    // 0x4f6234: r0 = _Double.fromInteger()
    //     0x4f6234: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x4f6238: mov             x1, x0
    // 0x4f623c: ldr             x0, [fp, #0x10]
    // 0x4f6240: stur            x1, [fp, #-0x10]
    // 0x4f6244: r2 = 60
    //     0x4f6244: movz            x2, #0x3c
    // 0x4f6248: branchIfSmi(r0, 0x4f6254)
    //     0x4f6248: tbz             w0, #0, #0x4f6254
    // 0x4f624c: r2 = LoadClassIdInstr(r0)
    //     0x4f624c: ldur            x2, [x0, #-1]
    //     0x4f6250: ubfx            x2, x2, #0xc, #0x14
    // 0x4f6254: str             x0, [SP]
    // 0x4f6258: mov             x0, x2
    // 0x4f625c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4f625c: sub             lr, x0, #1, lsl #12
    //     0x4f6260: ldr             lr, [x21, lr, lsl #3]
    //     0x4f6264: blr             lr
    // 0x4f6268: mov             x1, x0
    // 0x4f626c: ldur            x0, [fp, #-0x10]
    // 0x4f6270: LoadField: d0 = r0->field_7
    //     0x4f6270: ldur            d0, [x0, #7]
    // 0x4f6274: LoadField: d1 = r1->field_7
    //     0x4f6274: ldur            d1, [x1, #7]
    // 0x4f6278: d30 = 0.000000
    //     0x4f6278: fmov            d30, d0
    // 0x4f627c: d0 = 1.000000
    //     0x4f627c: fmov            d0, #1.00000000
    // 0x4f6280: fcmp            d1, #0.0
    // 0x4f6284: b.vs            #0x4f62c8
    // 0x4f6288: b.eq            #0x4f6350
    // 0x4f628c: fcmp            d1, d0
    // 0x4f6290: b.eq            #0x4f62b8
    // 0x4f6294: d31 = 2.000000
    //     0x4f6294: fmov            d31, #2.00000000
    // 0x4f6298: fcmp            d1, d31
    // 0x4f629c: b.eq            #0x4f62c0
    // 0x4f62a0: d31 = 3.000000
    //     0x4f62a0: fmov            d31, #3.00000000
    // 0x4f62a4: fcmp            d1, d31
    // 0x4f62a8: b.ne            #0x4f62c8
    // 0x4f62ac: fmul            d0, d30, d30
    // 0x4f62b0: fmul            d0, d0, d30
    // 0x4f62b4: b               #0x4f6350
    // 0x4f62b8: d0 = 0.000000
    //     0x4f62b8: fmov            d0, d30
    // 0x4f62bc: b               #0x4f6350
    // 0x4f62c0: fmul            d0, d30, d30
    // 0x4f62c4: b               #0x4f6350
    // 0x4f62c8: fcmp            d30, d0
    // 0x4f62cc: b.vs            #0x4f62dc
    // 0x4f62d0: b.eq            #0x4f6350
    // 0x4f62d4: fcmp            d30, d1
    // 0x4f62d8: b.vc            #0x4f62e8
    // 0x4f62dc: d0 = nan
    //     0x4f62dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x4f62e0: ldr             d0, [x17, #0xe48]
    // 0x4f62e4: b               #0x4f6350
    // 0x4f62e8: d0 = -inf
    //     0x4f62e8: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x4f62ec: fcmp            d30, d0
    // 0x4f62f0: b.eq            #0x4f6318
    // 0x4f62f4: d0 = 0.500000
    //     0x4f62f4: fmov            d0, #0.50000000
    // 0x4f62f8: fcmp            d1, d0
    // 0x4f62fc: b.ne            #0x4f6318
    // 0x4f6300: fcmp            d30, #0.0
    // 0x4f6304: b.eq            #0x4f6310
    // 0x4f6308: fsqrt           d0, d30
    // 0x4f630c: b               #0x4f6350
    // 0x4f6310: d0 = 0.000000
    //     0x4f6310: eor             v0.16b, v0.16b, v0.16b
    // 0x4f6314: b               #0x4f6350
    // 0x4f6318: d0 = 0.000000
    //     0x4f6318: fmov            d0, d30
    // 0x4f631c: stp             fp, lr, [SP, #-0x10]!
    // 0x4f6320: mov             fp, SP
    // 0x4f6324: CallRuntime_LibcPow(double, double) -> double
    //     0x4f6324: and             SP, SP, #0xfffffffffffffff0
    //     0x4f6328: mov             sp, SP
    //     0x4f632c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x4f6330: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f6334: blr             x16
    //     0x4f6338: movz            x16, #0x8
    //     0x4f633c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f6340: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f6344: sub             sp, x16, #1, lsl #12
    //     0x4f6348: mov             SP, fp
    //     0x4f634c: ldp             fp, lr, [SP], #0x10
    // 0x4f6350: r0 = inline_Allocate_Double()
    //     0x4f6350: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x4f6354: add             x0, x0, #0x10
    //     0x4f6358: cmp             x1, x0
    //     0x4f635c: b.ls            #0x4f63e4
    //     0x4f6360: str             x0, [THR, #0x60]  ; THR::top
    //     0x4f6364: sub             x0, x0, #0xf
    //     0x4f6368: movz            x1, #0xe19c
    //     0x4f636c: movk            x1, #0x3, lsl #16
    //     0x4f6370: stur            x1, [x0, #-1]
    // 0x4f6374: dmb             ishst
    // 0x4f6378: StoreField: r0->field_7 = d0
    //     0x4f6378: stur            d0, [x0, #7]
    // 0x4f637c: mov             x1, x0
    // 0x4f6380: ldur            x0, [fp, #-8]
    // 0x4f6384: r0 = DecimalManagement.max2DecimalPlaces()
    //     0x4f6384: bl              #0x4f63f4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlaces
    // 0x4f6388: ldur            x1, [fp, #-8]
    // 0x4f638c: ArrayStore: r1[1] = r0  ; List_4
    //     0x4f638c: add             x25, x1, #0x13
    //     0x4f6390: str             w0, [x25]
    //     0x4f6394: tbz             w0, #0, #0x4f63b0
    //     0x4f6398: ldurb           w16, [x1, #-1]
    //     0x4f639c: ldurb           w17, [x0, #-1]
    //     0x4f63a0: and             x16, x17, x16, lsr #2
    //     0x4f63a4: tst             x16, HEAP, lsr #32
    //     0x4f63a8: b.eq            #0x4f63b0
    //     0x4f63ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f63b0: ldur            x0, [fp, #-8]
    // 0x4f63b4: r16 = "% of your engagement, and velocity between prestiges."
    //     0x4f63b4: add             x16, PP, #0x16, lsl #12  ; [pp+0x165b0] "% of your engagement, and velocity between prestiges."
    //     0x4f63b8: ldr             x16, [x16, #0x5b0]
    // 0x4f63bc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f63bc: stur            w16, [x0, #0x17]
    // 0x4f63c0: str             x0, [SP]
    // 0x4f63c4: r0 = _interpolate()
    //     0x4f63c4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4f63c8: LeaveFrame
    //     0x4f63c8: mov             SP, fp
    //     0x4f63cc: ldp             fp, lr, [SP], #0x10
    // 0x4f63d0: ret
    //     0x4f63d0: ret             
    // 0x4f63d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f63d4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f63d8: b               #0x4f6198
    // 0x4f63dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f63dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f63e0: b               #0x4f61e4
    // 0x4f63e4: SaveReg d0
    //     0x4f63e4: str             q0, [SP, #-0x10]!
    // 0x4f63e8: r0 = AllocateDouble()
    //     0x4f63e8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4f63ec: RestoreReg d0
    //     0x4f63ec: ldr             q0, [SP], #0x10
    // 0x4f63f0: b               #0x4f6378
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f66c0, size: 0x200
    // 0x4f66c0: EnterFrame
    //     0x4f66c0: stp             fp, lr, [SP, #-0x10]!
    //     0x4f66c4: mov             fp, SP
    // 0x4f66c8: AllocStack(0x10)
    //     0x4f66c8: sub             SP, SP, #0x10
    // 0x4f66cc: CheckStackOverflow
    //     0x4f66cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f66d0: cmp             SP, x16
    //     0x4f66d4: b.ls            #0x4f68a4
    // 0x4f66d8: r1 = Null
    //     0x4f66d8: mov             x1, NULL
    // 0x4f66dc: r2 = 6
    //     0x4f66dc: movz            x2, #0x6
    // 0x4f66e0: r0 = AllocateArray()
    //     0x4f66e0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4f66e4: mov             x2, x0
    // 0x4f66e8: stur            x2, [fp, #-8]
    // 0x4f66ec: r16 = "Each tap of the recruit associates bar adds an additional "
    //     0x4f66ec: add             x16, PP, #0x16, lsl #12  ; [pp+0x165b8] "Each tap of the recruit associates bar adds an additional "
    //     0x4f66f0: ldr             x16, [x16, #0x5b8]
    // 0x4f66f4: StoreField: r2->field_f = r16
    //     0x4f66f4: stur            w16, [x2, #0xf]
    // 0x4f66f8: ldr             x0, [fp, #0x10]
    // 0x4f66fc: r1 = LoadInt32Instr(r0)
    //     0x4f66fc: sbfx            x1, x0, #1, #0x1f
    //     0x4f6700: tbz             w0, #0, #0x4f6708
    //     0x4f6704: ldur            x1, [x0, #7]
    // 0x4f6708: add             x3, x1, #1
    // 0x4f670c: r0 = BoxInt64Instr(r3)
    //     0x4f670c: sbfiz           x0, x3, #1, #0x1f
    //     0x4f6710: cmp             x3, x0, asr #1
    //     0x4f6714: b.eq            #0x4f6720
    //     0x4f6718: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4f671c: stur            x3, [x0, #7]
    // 0x4f6720: r1 = 60
    //     0x4f6720: movz            x1, #0x3c
    // 0x4f6724: branchIfSmi(r0, 0x4f6730)
    //     0x4f6724: tbz             w0, #0, #0x4f6730
    // 0x4f6728: r1 = LoadClassIdInstr(r0)
    //     0x4f6728: ldur            x1, [x0, #-1]
    //     0x4f672c: ubfx            x1, x1, #0xc, #0x14
    // 0x4f6730: str             x0, [SP]
    // 0x4f6734: mov             x0, x1
    // 0x4f6738: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4f6738: sub             lr, x0, #1, lsl #12
    //     0x4f673c: ldr             lr, [x21, lr, lsl #3]
    //     0x4f6740: blr             lr
    // 0x4f6744: LoadField: d1 = r0->field_7
    //     0x4f6744: ldur            d1, [x0, #7]
    // 0x4f6748: d0 = 2.218282
    //     0x4f6748: add             x17, PP, #0x16, lsl #12  ; [pp+0x165c0] IMM: double(2.218281828459045) from 0x4001bf0a8b145769
    //     0x4f674c: ldr             d0, [x17, #0x5c0]
    // 0x4f6750: d30 = 0.000000
    //     0x4f6750: fmov            d30, d0
    // 0x4f6754: d0 = 1.000000
    //     0x4f6754: fmov            d0, #1.00000000
    // 0x4f6758: fcmp            d1, #0.0
    // 0x4f675c: b.vs            #0x4f67a0
    // 0x4f6760: b.eq            #0x4f6828
    // 0x4f6764: fcmp            d1, d0
    // 0x4f6768: b.eq            #0x4f6790
    // 0x4f676c: d31 = 2.000000
    //     0x4f676c: fmov            d31, #2.00000000
    // 0x4f6770: fcmp            d1, d31
    // 0x4f6774: b.eq            #0x4f6798
    // 0x4f6778: d31 = 3.000000
    //     0x4f6778: fmov            d31, #3.00000000
    // 0x4f677c: fcmp            d1, d31
    // 0x4f6780: b.ne            #0x4f67a0
    // 0x4f6784: fmul            d0, d30, d30
    // 0x4f6788: fmul            d0, d0, d30
    // 0x4f678c: b               #0x4f6828
    // 0x4f6790: d0 = 0.000000
    //     0x4f6790: fmov            d0, d30
    // 0x4f6794: b               #0x4f6828
    // 0x4f6798: fmul            d0, d30, d30
    // 0x4f679c: b               #0x4f6828
    // 0x4f67a0: fcmp            d30, d0
    // 0x4f67a4: b.vs            #0x4f67b4
    // 0x4f67a8: b.eq            #0x4f6828
    // 0x4f67ac: fcmp            d30, d1
    // 0x4f67b0: b.vc            #0x4f67c0
    // 0x4f67b4: d0 = nan
    //     0x4f67b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x4f67b8: ldr             d0, [x17, #0xe48]
    // 0x4f67bc: b               #0x4f6828
    // 0x4f67c0: d0 = -inf
    //     0x4f67c0: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x4f67c4: fcmp            d30, d0
    // 0x4f67c8: b.eq            #0x4f67f0
    // 0x4f67cc: d0 = 0.500000
    //     0x4f67cc: fmov            d0, #0.50000000
    // 0x4f67d0: fcmp            d1, d0
    // 0x4f67d4: b.ne            #0x4f67f0
    // 0x4f67d8: fcmp            d30, #0.0
    // 0x4f67dc: b.eq            #0x4f67e8
    // 0x4f67e0: fsqrt           d0, d30
    // 0x4f67e4: b               #0x4f6828
    // 0x4f67e8: d0 = 0.000000
    //     0x4f67e8: eor             v0.16b, v0.16b, v0.16b
    // 0x4f67ec: b               #0x4f6828
    // 0x4f67f0: d0 = 0.000000
    //     0x4f67f0: fmov            d0, d30
    // 0x4f67f4: stp             fp, lr, [SP, #-0x10]!
    // 0x4f67f8: mov             fp, SP
    // 0x4f67fc: CallRuntime_LibcPow(double, double) -> double
    //     0x4f67fc: and             SP, SP, #0xfffffffffffffff0
    //     0x4f6800: mov             sp, SP
    //     0x4f6804: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x4f6808: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f680c: blr             x16
    //     0x4f6810: movz            x16, #0x8
    //     0x4f6814: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f6818: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f681c: sub             sp, x16, #1, lsl #12
    //     0x4f6820: mov             SP, fp
    //     0x4f6824: ldp             fp, lr, [SP], #0x10
    // 0x4f6828: r1 = inline_Allocate_Double()
    //     0x4f6828: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x4f682c: add             x1, x1, #0x10
    //     0x4f6830: cmp             x0, x1
    //     0x4f6834: b.ls            #0x4f68ac
    //     0x4f6838: str             x1, [THR, #0x60]  ; THR::top
    //     0x4f683c: sub             x1, x1, #0xf
    //     0x4f6840: movz            x0, #0xe19c
    //     0x4f6844: movk            x0, #0x3, lsl #16
    //     0x4f6848: stur            x0, [x1, #-1]
    // 0x4f684c: dmb             ishst
    // 0x4f6850: StoreField: r1->field_7 = d0
    //     0x4f6850: stur            d0, [x1, #7]
    // 0x4f6854: r0 = DecimalManagement.max2DecimalPlaces()
    //     0x4f6854: bl              #0x4f63f4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlaces
    // 0x4f6858: ldur            x1, [fp, #-8]
    // 0x4f685c: ArrayStore: r1[1] = r0  ; List_4
    //     0x4f685c: add             x25, x1, #0x13
    //     0x4f6860: str             w0, [x25]
    //     0x4f6864: tbz             w0, #0, #0x4f6880
    //     0x4f6868: ldurb           w16, [x1, #-1]
    //     0x4f686c: ldurb           w17, [x0, #-1]
    //     0x4f6870: and             x16, x17, x16, lsr #2
    //     0x4f6874: tst             x16, HEAP, lsr #32
    //     0x4f6878: b.eq            #0x4f6880
    //     0x4f687c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4f6880: ldur            x0, [fp, #-8]
    // 0x4f6884: r16 = " seconds of time."
    //     0x4f6884: add             x16, PP, #0x16, lsl #12  ; [pp+0x165c8] " seconds of time."
    //     0x4f6888: ldr             x16, [x16, #0x5c8]
    // 0x4f688c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4f688c: stur            w16, [x0, #0x17]
    // 0x4f6890: str             x0, [SP]
    // 0x4f6894: r0 = _interpolate()
    //     0x4f6894: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4f6898: LeaveFrame
    //     0x4f6898: mov             SP, fp
    //     0x4f689c: ldp             fp, lr, [SP], #0x10
    // 0x4f68a0: ret
    //     0x4f68a0: ret             
    // 0x4f68a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f68a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f68a8: b               #0x4f66d8
    // 0x4f68ac: SaveReg d0
    //     0x4f68ac: str             q0, [SP, #-0x10]!
    // 0x4f68b0: r0 = AllocateDouble()
    //     0x4f68b0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4f68b4: mov             x1, x0
    // 0x4f68b8: RestoreReg d0
    //     0x4f68b8: ldr             q0, [SP], #0x10
    // 0x4f68bc: b               #0x4f6850
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4f68c0, size: 0x6c
    // 0x4f68c0: EnterFrame
    //     0x4f68c0: stp             fp, lr, [SP, #-0x10]!
    //     0x4f68c4: mov             fp, SP
    // 0x4f68c8: AllocStack(0x8)
    //     0x4f68c8: sub             SP, SP, #8
    // 0x4f68cc: SetupParameters([dynamic _ /* r0 */])
    //     0x4f68cc: ldr             x0, [fp, #0x10]
    //     0x4f68d0: ldur            w2, [x0, #0x17]
    //     0x4f68d4: add             x2, x2, HEAP, lsl #32
    //     0x4f68d8: stur            x2, [fp, #-8]
    // 0x4f68dc: CheckStackOverflow
    //     0x4f68dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f68e0: cmp             SP, x16
    //     0x4f68e4: b.ls            #0x4f6924
    // 0x4f68e8: LoadField: r1 = r2->field_f
    //     0x4f68e8: ldur            w1, [x2, #0xf]
    // 0x4f68ec: DecompressPointer r1
    //     0x4f68ec: add             x1, x1, HEAP, lsl #32
    // 0x4f68f0: r0 = resetAndRecomputeBoosts()
    //     0x4f68f0: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x4f68f4: ldur            x0, [fp, #-8]
    // 0x4f68f8: LoadField: r1 = r0->field_f
    //     0x4f68f8: ldur            w1, [x0, #0xf]
    // 0x4f68fc: DecompressPointer r1
    //     0x4f68fc: add             x1, x1, HEAP, lsl #32
    // 0x4f6900: LoadField: r0 = r1->field_53
    //     0x4f6900: ldur            w0, [x1, #0x53]
    // 0x4f6904: DecompressPointer r0
    //     0x4f6904: add             x0, x0, HEAP, lsl #32
    // 0x4f6908: mov             x1, x0
    // 0x4f690c: r2 = 2
    //     0x4f690c: movz            x2, #0x2
    // 0x4f6910: r0 = add()
    //     0x4f6910: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4f6914: r0 = Null
    //     0x4f6914: mov             x0, NULL
    // 0x4f6918: LeaveFrame
    //     0x4f6918: mov             SP, fp
    //     0x4f691c: ldp             fp, lr, [SP], #0x10
    // 0x4f6920: ret
    //     0x4f6920: ret             
    // 0x4f6924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f6924: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f6928: b               #0x4f68e8
  }
  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x4f692c, size: 0xc
    // 0x4f692c: r0 = "Doubles the rate of associate gain."
    //     0x4f692c: add             x0, PP, #0x16, lsl #12  ; [pp+0x165d0] "Doubles the rate of associate gain."
    //     0x4f6930: ldr             x0, [x0, #0x5d0]
    // 0x4f6934: ret
    //     0x4f6934: ret             
  }
  _ getNonGeneratorStatsPerSecond(/* No info */) {
    // ** addr: 0x54d5ec, size: 0x12c
    // 0x54d5ec: EnterFrame
    //     0x54d5ec: stp             fp, lr, [SP, #-0x10]!
    //     0x54d5f0: mov             fp, SP
    // 0x54d5f4: AllocStack(0x28)
    //     0x54d5f4: sub             SP, SP, #0x28
    // 0x54d5f8: SetupParameters(Chapter11GameState this /* r1 => r1, fp-0x8 */)
    //     0x54d5f8: stur            x1, [fp, #-8]
    // 0x54d5fc: CheckStackOverflow
    //     0x54d5fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54d600: cmp             SP, x16
    //     0x54d604: b.ls            #0x54d710
    // 0x54d608: r16 = <Chapter11Stat, CustomNum>
    //     0x54d608: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6e0] TypeArguments: <Chapter11Stat, CustomNum>
    //     0x54d60c: ldr             x16, [x16, #0x6e0]
    // 0x54d610: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x54d614: stp             lr, x16, [SP]
    // 0x54d618: r0 = Map._fromLiteral()
    //     0x54d618: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54d61c: mov             x3, x0
    // 0x54d620: ldur            x0, [fp, #-8]
    // 0x54d624: stur            x3, [fp, #-0x10]
    // 0x54d628: LoadField: r1 = r0->field_43
    //     0x54d628: ldur            w1, [x0, #0x43]
    // 0x54d62c: DecompressPointer r1
    //     0x54d62c: add             x1, x1, HEAP, lsl #32
    // 0x54d630: r2 = 42
    //     0x54d630: movz            x2, #0x2a
    // 0x54d634: r0 = containsKey()
    //     0x54d634: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54d638: tbnz            w0, #4, #0x54d700
    // 0x54d63c: ldur            x0, [fp, #-8]
    // 0x54d640: mov             x1, x0
    // 0x54d644: r0 = silverPrestigePoints()
    //     0x54d644: bl              #0x54d7fc  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestigePoints
    // 0x54d648: mov             x1, x0
    // 0x54d64c: r2 = Instance_CustomNum
    //     0x54d64c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x54d650: ldr             x2, [x2, #0xce0]
    // 0x54d654: r0 = mult2()
    //     0x54d654: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54d658: ldur            x1, [fp, #-0x10]
    // 0x54d65c: mov             x3, x0
    // 0x54d660: r2 = Instance_Chapter11Stat
    //     0x54d660: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x54d664: ldr             x2, [x2, #0x5c0]
    // 0x54d668: r0 = []=()
    //     0x54d668: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x54d66c: ldur            x0, [fp, #-8]
    // 0x54d670: LoadField: r3 = r0->field_43
    //     0x54d670: ldur            w3, [x0, #0x43]
    // 0x54d674: DecompressPointer r3
    //     0x54d674: add             x3, x3, HEAP, lsl #32
    // 0x54d678: mov             x1, x3
    // 0x54d67c: stur            x3, [fp, #-0x18]
    // 0x54d680: r2 = 42
    //     0x54d680: movz            x2, #0x2a
    // 0x54d684: r0 = _getValueOrData()
    //     0x54d684: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54d688: mov             x1, x0
    // 0x54d68c: ldur            x0, [fp, #-0x18]
    // 0x54d690: LoadField: r2 = r0->field_f
    //     0x54d690: ldur            w2, [x0, #0xf]
    // 0x54d694: DecompressPointer r2
    //     0x54d694: add             x2, x2, HEAP, lsl #32
    // 0x54d698: cmp             w2, w1
    // 0x54d69c: b.ne            #0x54d6a8
    // 0x54d6a0: r0 = Null
    //     0x54d6a0: mov             x0, NULL
    // 0x54d6a4: b               #0x54d6ac
    // 0x54d6a8: mov             x0, x1
    // 0x54d6ac: cmp             w0, NULL
    // 0x54d6b0: b.ne            #0x54d6bc
    // 0x54d6b4: r0 = 0
    //     0x54d6b4: movz            x0, #0
    // 0x54d6b8: b               #0x54d6cc
    // 0x54d6bc: r1 = LoadInt32Instr(r0)
    //     0x54d6bc: sbfx            x1, x0, #1, #0x1f
    //     0x54d6c0: tbz             w0, #0, #0x54d6c8
    //     0x54d6c4: ldur            x1, [x0, #7]
    // 0x54d6c8: mov             x0, x1
    // 0x54d6cc: cmp             x0, #2
    // 0x54d6d0: b.lt            #0x54d700
    // 0x54d6d4: ldur            x1, [fp, #-8]
    // 0x54d6d8: r0 = goldPrestigePoints()
    //     0x54d6d8: bl              #0x54d718  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestigePoints
    // 0x54d6dc: mov             x1, x0
    // 0x54d6e0: r2 = Instance_CustomNum
    //     0x54d6e0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a6f8] Obj!CustomNum@82b381
    //     0x54d6e4: ldr             x2, [x2, #0x6f8]
    // 0x54d6e8: r0 = mult2()
    //     0x54d6e8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54d6ec: ldur            x1, [fp, #-0x10]
    // 0x54d6f0: mov             x3, x0
    // 0x54d6f4: r2 = Instance_Chapter11Stat
    //     0x54d6f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x54d6f8: ldr             x2, [x2, #0x5e0]
    // 0x54d6fc: r0 = []=()
    //     0x54d6fc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x54d700: ldur            x0, [fp, #-0x10]
    // 0x54d704: LeaveFrame
    //     0x54d704: mov             SP, fp
    //     0x54d708: ldp             fp, lr, [SP], #0x10
    // 0x54d70c: ret
    //     0x54d70c: ret             
    // 0x54d710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d710: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d714: b               #0x54d608
  }
  _ goldPrestigePoints(/* No info */) {
    // ** addr: 0x54d718, size: 0xac
    // 0x54d718: EnterFrame
    //     0x54d718: stp             fp, lr, [SP, #-0x10]!
    //     0x54d71c: mov             fp, SP
    // 0x54d720: AllocStack(0x10)
    //     0x54d720: sub             SP, SP, #0x10
    // 0x54d724: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x10 */)
    //     0x54d724: mov             x0, x1
    //     0x54d728: stur            x1, [fp, #-0x10]
    // 0x54d72c: CheckStackOverflow
    //     0x54d72c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54d730: cmp             SP, x16
    //     0x54d734: b.ls            #0x54d7bc
    // 0x54d738: LoadField: r3 = r0->field_3b
    //     0x54d738: ldur            w3, [x0, #0x3b]
    // 0x54d73c: DecompressPointer r3
    //     0x54d73c: add             x3, x3, HEAP, lsl #32
    // 0x54d740: mov             x1, x3
    // 0x54d744: stur            x3, [fp, #-8]
    // 0x54d748: r2 = Instance_Chapter11Stat
    //     0x54d748: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x54d74c: ldr             x2, [x2, #0x5c0]
    // 0x54d750: r0 = _getValueOrData()
    //     0x54d750: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54d754: mov             x1, x0
    // 0x54d758: ldur            x0, [fp, #-8]
    // 0x54d75c: LoadField: r2 = r0->field_f
    //     0x54d75c: ldur            w2, [x0, #0xf]
    // 0x54d760: DecompressPointer r2
    //     0x54d760: add             x2, x2, HEAP, lsl #32
    // 0x54d764: cmp             w2, w1
    // 0x54d768: b.ne            #0x54d774
    // 0x54d76c: r0 = Null
    //     0x54d76c: mov             x0, NULL
    // 0x54d770: b               #0x54d778
    // 0x54d774: mov             x0, x1
    // 0x54d778: cmp             w0, NULL
    // 0x54d77c: b.ne            #0x54d788
    // 0x54d780: r0 = Instance_CustomNum
    //     0x54d780: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54d784: ldr             x0, [x0, #0xaf8]
    // 0x54d788: ldur            x1, [fp, #-0x10]
    // 0x54d78c: stur            x0, [fp, #-8]
    // 0x54d790: r0 = silverPrestigePoints()
    //     0x54d790: bl              #0x54d7fc  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestigePoints
    // 0x54d794: ldur            x1, [fp, #-8]
    // 0x54d798: mov             x2, x0
    // 0x54d79c: r0 = add()
    //     0x54d79c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x54d7a0: mov             x1, x0
    // 0x54d7a4: r2 = Instance_CustomNum
    //     0x54d7a4: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a700] Obj!CustomNum@82b361
    //     0x54d7a8: ldr             x2, [x2, #0x700]
    // 0x54d7ac: r0 = mult2()
    //     0x54d7ac: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54d7b0: LeaveFrame
    //     0x54d7b0: mov             SP, fp
    //     0x54d7b4: ldp             fp, lr, [SP], #0x10
    // 0x54d7b8: ret
    //     0x54d7b8: ret             
    // 0x54d7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d7bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d7c0: b               #0x54d738
  }
  [closure] CustomNum goldPrestigePoints(dynamic) {
    // ** addr: 0x54d7c4, size: 0x38
    // 0x54d7c4: EnterFrame
    //     0x54d7c4: stp             fp, lr, [SP, #-0x10]!
    //     0x54d7c8: mov             fp, SP
    // 0x54d7cc: ldr             x0, [fp, #0x10]
    // 0x54d7d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x54d7d0: ldur            w1, [x0, #0x17]
    // 0x54d7d4: DecompressPointer r1
    //     0x54d7d4: add             x1, x1, HEAP, lsl #32
    // 0x54d7d8: CheckStackOverflow
    //     0x54d7d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54d7dc: cmp             SP, x16
    //     0x54d7e0: b.ls            #0x54d7f4
    // 0x54d7e4: r0 = goldPrestigePoints()
    //     0x54d7e4: bl              #0x54d718  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestigePoints
    // 0x54d7e8: LeaveFrame
    //     0x54d7e8: mov             SP, fp
    //     0x54d7ec: ldp             fp, lr, [SP], #0x10
    // 0x54d7f0: ret
    //     0x54d7f0: ret             
    // 0x54d7f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d7f4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d7f8: b               #0x54d7e4
  }
  _ silverPrestigePoints(/* No info */) {
    // ** addr: 0x54d7fc, size: 0x1bc
    // 0x54d7fc: EnterFrame
    //     0x54d7fc: stp             fp, lr, [SP, #-0x10]!
    //     0x54d800: mov             fp, SP
    // 0x54d804: AllocStack(0x20)
    //     0x54d804: sub             SP, SP, #0x20
    // 0x54d808: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x10 */)
    //     0x54d808: mov             x0, x1
    //     0x54d80c: stur            x1, [fp, #-0x10]
    // 0x54d810: CheckStackOverflow
    //     0x54d810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54d814: cmp             SP, x16
    //     0x54d818: b.ls            #0x54d9b0
    // 0x54d81c: LoadField: r3 = r0->field_3b
    //     0x54d81c: ldur            w3, [x0, #0x3b]
    // 0x54d820: DecompressPointer r3
    //     0x54d820: add             x3, x3, HEAP, lsl #32
    // 0x54d824: mov             x1, x3
    // 0x54d828: stur            x3, [fp, #-8]
    // 0x54d82c: r2 = Instance_Chapter11Stat
    //     0x54d82c: add             x2, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x54d830: ldr             x2, [x2, #0x5a0]
    // 0x54d834: r0 = _getValueOrData()
    //     0x54d834: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54d838: mov             x1, x0
    // 0x54d83c: ldur            x0, [fp, #-8]
    // 0x54d840: LoadField: r2 = r0->field_f
    //     0x54d840: ldur            w2, [x0, #0xf]
    // 0x54d844: DecompressPointer r2
    //     0x54d844: add             x2, x2, HEAP, lsl #32
    // 0x54d848: cmp             w2, w1
    // 0x54d84c: b.ne            #0x54d858
    // 0x54d850: r0 = Null
    //     0x54d850: mov             x0, NULL
    // 0x54d854: b               #0x54d85c
    // 0x54d858: mov             x0, x1
    // 0x54d85c: cmp             w0, NULL
    // 0x54d860: b.ne            #0x54d870
    // 0x54d864: r1 = Instance_CustomNum
    //     0x54d864: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x54d868: ldr             x1, [x1, #0xaf8]
    // 0x54d86c: b               #0x54d874
    // 0x54d870: mov             x1, x0
    // 0x54d874: ldur            x0, [fp, #-0x10]
    // 0x54d878: r2 = Instance_CustomNum
    //     0x54d878: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a708] Obj!CustomNum@82b371
    //     0x54d87c: ldr             x2, [x2, #0x708]
    // 0x54d880: r0 = mult2()
    //     0x54d880: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54d884: mov             x1, x0
    // 0x54d888: r2 = 0.250000
    //     0x54d888: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a710] 0.25
    //     0x54d88c: ldr             x2, [x2, #0x710]
    // 0x54d890: r0 = pow()
    //     0x54d890: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x54d894: mov             x3, x0
    // 0x54d898: ldur            x0, [fp, #-0x10]
    // 0x54d89c: stur            x3, [fp, #-0x18]
    // 0x54d8a0: LoadField: r1 = r0->field_3f
    //     0x54d8a0: ldur            w1, [x0, #0x3f]
    // 0x54d8a4: DecompressPointer r1
    //     0x54d8a4: add             x1, x1, HEAP, lsl #32
    // 0x54d8a8: LoadField: r4 = r1->field_b
    //     0x54d8a8: ldur            w4, [x1, #0xb]
    // 0x54d8ac: DecompressPointer r4
    //     0x54d8ac: add             x4, x4, HEAP, lsl #32
    // 0x54d8b0: mov             x1, x4
    // 0x54d8b4: stur            x4, [fp, #-8]
    // 0x54d8b8: r2 = 2
    //     0x54d8b8: movz            x2, #0x2
    // 0x54d8bc: r0 = _getValueOrData()
    //     0x54d8bc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54d8c0: mov             x1, x0
    // 0x54d8c4: ldur            x0, [fp, #-8]
    // 0x54d8c8: LoadField: r2 = r0->field_f
    //     0x54d8c8: ldur            w2, [x0, #0xf]
    // 0x54d8cc: DecompressPointer r2
    //     0x54d8cc: add             x2, x2, HEAP, lsl #32
    // 0x54d8d0: cmp             w2, w1
    // 0x54d8d4: b.ne            #0x54d8e0
    // 0x54d8d8: r0 = Null
    //     0x54d8d8: mov             x0, NULL
    // 0x54d8dc: b               #0x54d8e4
    // 0x54d8e0: mov             x0, x1
    // 0x54d8e4: cmp             w0, NULL
    // 0x54d8e8: b.ne            #0x54d8f4
    // 0x54d8ec: r3 = 0
    //     0x54d8ec: movz            x3, #0
    // 0x54d8f0: b               #0x54d904
    // 0x54d8f4: r1 = LoadInt32Instr(r0)
    //     0x54d8f4: sbfx            x1, x0, #1, #0x1f
    //     0x54d8f8: tbz             w0, #0, #0x54d900
    //     0x54d8fc: ldur            x1, [x0, #7]
    // 0x54d900: mov             x3, x1
    // 0x54d904: ldur            x0, [fp, #-0x10]
    // 0x54d908: stur            x3, [fp, #-0x20]
    // 0x54d90c: LoadField: r1 = r0->field_3f
    //     0x54d90c: ldur            w1, [x0, #0x3f]
    // 0x54d910: DecompressPointer r1
    //     0x54d910: add             x1, x1, HEAP, lsl #32
    // 0x54d914: LoadField: r0 = r1->field_b
    //     0x54d914: ldur            w0, [x1, #0xb]
    // 0x54d918: DecompressPointer r0
    //     0x54d918: add             x0, x0, HEAP, lsl #32
    // 0x54d91c: mov             x1, x0
    // 0x54d920: stur            x0, [fp, #-8]
    // 0x54d924: r2 = 4
    //     0x54d924: movz            x2, #0x4
    // 0x54d928: r0 = _getValueOrData()
    //     0x54d928: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54d92c: mov             x1, x0
    // 0x54d930: ldur            x0, [fp, #-8]
    // 0x54d934: LoadField: r2 = r0->field_f
    //     0x54d934: ldur            w2, [x0, #0xf]
    // 0x54d938: DecompressPointer r2
    //     0x54d938: add             x2, x2, HEAP, lsl #32
    // 0x54d93c: cmp             w2, w1
    // 0x54d940: b.ne            #0x54d94c
    // 0x54d944: r0 = Null
    //     0x54d944: mov             x0, NULL
    // 0x54d948: b               #0x54d950
    // 0x54d94c: mov             x0, x1
    // 0x54d950: cmp             w0, NULL
    // 0x54d954: b.ne            #0x54d960
    // 0x54d958: r1 = 0
    //     0x54d958: movz            x1, #0
    // 0x54d95c: b               #0x54d96c
    // 0x54d960: r1 = LoadInt32Instr(r0)
    //     0x54d960: sbfx            x1, x0, #1, #0x1f
    //     0x54d964: tbz             w0, #0, #0x54d96c
    //     0x54d968: ldur            x1, [x0, #7]
    // 0x54d96c: ldur            x0, [fp, #-0x20]
    // 0x54d970: add             x2, x0, x1
    // 0x54d974: r0 = BoxInt64Instr(r2)
    //     0x54d974: sbfiz           x0, x2, #1, #0x1f
    //     0x54d978: cmp             x2, x0, asr #1
    //     0x54d97c: b.eq            #0x54d988
    //     0x54d980: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54d984: stur            x2, [x0, #7]
    // 0x54d988: mov             x2, x0
    // 0x54d98c: r1 = Instance_CustomNum
    //     0x54d98c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x54d990: ldr             x1, [x1, #0x970]
    // 0x54d994: r0 = pow()
    //     0x54d994: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x54d998: ldur            x1, [fp, #-0x18]
    // 0x54d99c: mov             x2, x0
    // 0x54d9a0: r0 = mult2()
    //     0x54d9a0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x54d9a4: LeaveFrame
    //     0x54d9a4: mov             SP, fp
    //     0x54d9a8: ldp             fp, lr, [SP], #0x10
    // 0x54d9ac: ret
    //     0x54d9ac: ret             
    // 0x54d9b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d9b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d9b4: b               #0x54d81c
  }
  [closure] CustomNum silverPrestigePoints(dynamic) {
    // ** addr: 0x54d9b8, size: 0x38
    // 0x54d9b8: EnterFrame
    //     0x54d9b8: stp             fp, lr, [SP, #-0x10]!
    //     0x54d9bc: mov             fp, SP
    // 0x54d9c0: ldr             x0, [fp, #0x10]
    // 0x54d9c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x54d9c4: ldur            w1, [x0, #0x17]
    // 0x54d9c8: DecompressPointer r1
    //     0x54d9c8: add             x1, x1, HEAP, lsl #32
    // 0x54d9cc: CheckStackOverflow
    //     0x54d9cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54d9d0: cmp             SP, x16
    //     0x54d9d4: b.ls            #0x54d9e8
    // 0x54d9d8: r0 = silverPrestigePoints()
    //     0x54d9d8: bl              #0x54d7fc  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestigePoints
    // 0x54d9dc: LeaveFrame
    //     0x54d9dc: mov             SP, fp
    //     0x54d9e0: ldp             fp, lr, [SP], #0x10
    // 0x54d9e4: ret
    //     0x54d9e4: ret             
    // 0x54d9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54d9e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54d9ec: b               #0x54d9d8
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55c57c, size: 0x194
    // 0x55c57c: EnterFrame
    //     0x55c57c: stp             fp, lr, [SP, #-0x10]!
    //     0x55c580: mov             fp, SP
    // 0x55c584: AllocStack(0x30)
    //     0x55c584: sub             SP, SP, #0x30
    // 0x55c588: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x8 */)
    //     0x55c588: mov             x0, x1
    //     0x55c58c: stur            x1, [fp, #-8]
    // 0x55c590: CheckStackOverflow
    //     0x55c590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55c594: cmp             SP, x16
    //     0x55c598: b.ls            #0x55c708
    // 0x55c59c: r1 = Null
    //     0x55c59c: mov             x1, NULL
    // 0x55c5a0: r2 = 4
    //     0x55c5a0: movz            x2, #0x4
    // 0x55c5a4: r0 = AllocateArray()
    //     0x55c5a4: bl              #0x82746c  ; AllocateArrayStub
    // 0x55c5a8: stur            x0, [fp, #-0x18]
    // 0x55c5ac: r16 = Instance_Chapter11Stat
    //     0x55c5ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x55c5b0: ldr             x16, [x16, #0x5a0]
    // 0x55c5b4: StoreField: r0->field_f = r16
    //     0x55c5b4: stur            w16, [x0, #0xf]
    // 0x55c5b8: ldur            x3, [fp, #-8]
    // 0x55c5bc: LoadField: r4 = r3->field_37
    //     0x55c5bc: ldur            w4, [x3, #0x37]
    // 0x55c5c0: DecompressPointer r4
    //     0x55c5c0: add             x4, x4, HEAP, lsl #32
    // 0x55c5c4: mov             x1, x4
    // 0x55c5c8: stur            x4, [fp, #-0x10]
    // 0x55c5cc: r2 = Instance_Chapter11Stat
    //     0x55c5cc: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x55c5d0: ldr             x2, [x2, #0x5c0]
    // 0x55c5d4: r0 = _getValueOrData()
    //     0x55c5d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c5d8: mov             x1, x0
    // 0x55c5dc: ldur            x0, [fp, #-0x10]
    // 0x55c5e0: LoadField: r2 = r0->field_f
    //     0x55c5e0: ldur            w2, [x0, #0xf]
    // 0x55c5e4: DecompressPointer r2
    //     0x55c5e4: add             x2, x2, HEAP, lsl #32
    // 0x55c5e8: cmp             w2, w1
    // 0x55c5ec: b.ne            #0x55c5f8
    // 0x55c5f0: r0 = Null
    //     0x55c5f0: mov             x0, NULL
    // 0x55c5f4: b               #0x55c5fc
    // 0x55c5f8: mov             x0, x1
    // 0x55c5fc: cmp             w0, NULL
    // 0x55c600: b.ne            #0x55c610
    // 0x55c604: r2 = Instance_CustomNum
    //     0x55c604: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55c608: ldr             x2, [x2, #0xaf8]
    // 0x55c60c: b               #0x55c614
    // 0x55c610: mov             x2, x0
    // 0x55c614: ldur            x0, [fp, #-8]
    // 0x55c618: r1 = Instance_CustomNum
    //     0x55c618: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55c61c: ldr             x1, [x1, #0xce0]
    // 0x55c620: r0 = mult2()
    //     0x55c620: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55c624: mov             x2, x0
    // 0x55c628: r1 = Instance_CustomNum
    //     0x55c628: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55c62c: ldr             x1, [x1, #0xa70]
    // 0x55c630: r0 = add()
    //     0x55c630: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55c634: mov             x3, x0
    // 0x55c638: ldur            x0, [fp, #-8]
    // 0x55c63c: stur            x3, [fp, #-0x20]
    // 0x55c640: LoadField: r4 = r0->field_37
    //     0x55c640: ldur            w4, [x0, #0x37]
    // 0x55c644: DecompressPointer r4
    //     0x55c644: add             x4, x4, HEAP, lsl #32
    // 0x55c648: mov             x1, x4
    // 0x55c64c: stur            x4, [fp, #-0x10]
    // 0x55c650: r2 = Instance_Chapter11Stat
    //     0x55c650: add             x2, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x55c654: ldr             x2, [x2, #0x608]
    // 0x55c658: r0 = _getValueOrData()
    //     0x55c658: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55c65c: mov             x1, x0
    // 0x55c660: ldur            x0, [fp, #-0x10]
    // 0x55c664: LoadField: r2 = r0->field_f
    //     0x55c664: ldur            w2, [x0, #0xf]
    // 0x55c668: DecompressPointer r2
    //     0x55c668: add             x2, x2, HEAP, lsl #32
    // 0x55c66c: cmp             w2, w1
    // 0x55c670: b.ne            #0x55c67c
    // 0x55c674: r0 = Null
    //     0x55c674: mov             x0, NULL
    // 0x55c678: b               #0x55c680
    // 0x55c67c: mov             x0, x1
    // 0x55c680: cmp             w0, NULL
    // 0x55c684: b.ne            #0x55c694
    // 0x55c688: r2 = Instance_CustomNum
    //     0x55c688: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55c68c: ldr             x2, [x2, #0xaf8]
    // 0x55c690: b               #0x55c698
    // 0x55c694: mov             x2, x0
    // 0x55c698: r1 = Instance_CustomNum
    //     0x55c698: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55c69c: ldr             x1, [x1, #0xce0]
    // 0x55c6a0: r0 = mult2()
    //     0x55c6a0: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55c6a4: mov             x2, x0
    // 0x55c6a8: r1 = Instance_CustomNum
    //     0x55c6a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55c6ac: ldr             x1, [x1, #0xa70]
    // 0x55c6b0: r0 = add()
    //     0x55c6b0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55c6b4: ldur            x1, [fp, #-0x20]
    // 0x55c6b8: mov             x2, x0
    // 0x55c6bc: r0 = mult2()
    //     0x55c6bc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55c6c0: ldur            x1, [fp, #-0x18]
    // 0x55c6c4: ArrayStore: r1[1] = r0  ; List_4
    //     0x55c6c4: add             x25, x1, #0x13
    //     0x55c6c8: str             w0, [x25]
    //     0x55c6cc: tbz             w0, #0, #0x55c6e8
    //     0x55c6d0: ldurb           w16, [x1, #-1]
    //     0x55c6d4: ldurb           w17, [x0, #-1]
    //     0x55c6d8: and             x16, x17, x16, lsr #2
    //     0x55c6dc: tst             x16, HEAP, lsr #32
    //     0x55c6e0: b.eq            #0x55c6e8
    //     0x55c6e4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x55c6e8: r16 = <Chapter11Stat, CustomNum>
    //     0x55c6e8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6e0] TypeArguments: <Chapter11Stat, CustomNum>
    //     0x55c6ec: ldr             x16, [x16, #0x6e0]
    // 0x55c6f0: ldur            lr, [fp, #-0x18]
    // 0x55c6f4: stp             lr, x16, [SP]
    // 0x55c6f8: r0 = Map._fromLiteral()
    //     0x55c6f8: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55c6fc: LeaveFrame
    //     0x55c6fc: mov             SP, fp
    //     0x55c700: ldp             fp, lr, [SP], #0x10
    // 0x55c704: ret
    //     0x55c704: ret             
    // 0x55c708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c708: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c70c: b               #0x55c59c
  }
  _ preUpdateCallback(/* No info */) {
    // ** addr: 0x650d58, size: 0x3fc
    // 0x650d58: EnterFrame
    //     0x650d58: stp             fp, lr, [SP, #-0x10]!
    //     0x650d5c: mov             fp, SP
    // 0x650d60: AllocStack(0x28)
    //     0x650d60: sub             SP, SP, #0x28
    // 0x650d64: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x18 */)
    //     0x650d64: mov             x0, x1
    //     0x650d68: stur            x1, [fp, #-0x18]
    // 0x650d6c: CheckStackOverflow
    //     0x650d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x650d70: cmp             SP, x16
    //     0x650d74: b.ls            #0x65114c
    // 0x650d78: LoadField: r3 = r0->field_33
    //     0x650d78: ldur            w3, [x0, #0x33]
    // 0x650d7c: DecompressPointer r3
    //     0x650d7c: add             x3, x3, HEAP, lsl #32
    // 0x650d80: stur            x3, [fp, #-0x10]
    // 0x650d84: LoadField: r4 = r0->field_43
    //     0x650d84: ldur            w4, [x0, #0x43]
    // 0x650d88: DecompressPointer r4
    //     0x650d88: add             x4, x4, HEAP, lsl #32
    // 0x650d8c: mov             x1, x4
    // 0x650d90: stur            x4, [fp, #-8]
    // 0x650d94: r2 = 2
    //     0x650d94: movz            x2, #0x2
    // 0x650d98: r0 = _getValueOrData()
    //     0x650d98: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x650d9c: mov             x1, x0
    // 0x650da0: ldur            x0, [fp, #-8]
    // 0x650da4: LoadField: r2 = r0->field_f
    //     0x650da4: ldur            w2, [x0, #0xf]
    // 0x650da8: DecompressPointer r2
    //     0x650da8: add             x2, x2, HEAP, lsl #32
    // 0x650dac: cmp             w2, w1
    // 0x650db0: b.ne            #0x650dbc
    // 0x650db4: r0 = Null
    //     0x650db4: mov             x0, NULL
    // 0x650db8: b               #0x650dc0
    // 0x650dbc: mov             x0, x1
    // 0x650dc0: cmp             w0, NULL
    // 0x650dc4: b.ne            #0x650dd0
    // 0x650dc8: r2 = 0
    //     0x650dc8: movz            x2, #0
    // 0x650dcc: b               #0x650de0
    // 0x650dd0: r1 = LoadInt32Instr(r0)
    //     0x650dd0: sbfx            x1, x0, #1, #0x1f
    //     0x650dd4: tbz             w0, #0, #0x650ddc
    //     0x650dd8: ldur            x1, [x0, #7]
    // 0x650ddc: mov             x2, x1
    // 0x650de0: ldur            x3, [fp, #-0x18]
    // 0x650de4: r0 = BoxInt64Instr(r2)
    //     0x650de4: sbfiz           x0, x2, #1, #0x1f
    //     0x650de8: cmp             x2, x0, asr #1
    //     0x650dec: b.eq            #0x650df8
    //     0x650df0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x650df4: stur            x2, [x0, #7]
    // 0x650df8: mov             x2, x0
    // 0x650dfc: r1 = Instance_CustomNum
    //     0x650dfc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x650e00: ldr             x1, [x1, #0x970]
    // 0x650e04: r0 = pow()
    //     0x650e04: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x650e08: mov             x3, x0
    // 0x650e0c: ldur            x0, [fp, #-0x18]
    // 0x650e10: stur            x3, [fp, #-0x20]
    // 0x650e14: LoadField: r4 = r0->field_37
    //     0x650e14: ldur            w4, [x0, #0x37]
    // 0x650e18: DecompressPointer r4
    //     0x650e18: add             x4, x4, HEAP, lsl #32
    // 0x650e1c: mov             x1, x4
    // 0x650e20: stur            x4, [fp, #-8]
    // 0x650e24: r2 = Instance_Chapter11Stat
    //     0x650e24: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x650e28: ldr             x2, [x2, #0x5d0]
    // 0x650e2c: r0 = _getValueOrData()
    //     0x650e2c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x650e30: mov             x1, x0
    // 0x650e34: ldur            x0, [fp, #-8]
    // 0x650e38: LoadField: r2 = r0->field_f
    //     0x650e38: ldur            w2, [x0, #0xf]
    // 0x650e3c: DecompressPointer r2
    //     0x650e3c: add             x2, x2, HEAP, lsl #32
    // 0x650e40: cmp             w2, w1
    // 0x650e44: b.ne            #0x650e50
    // 0x650e48: r0 = Null
    //     0x650e48: mov             x0, NULL
    // 0x650e4c: b               #0x650e54
    // 0x650e50: mov             x0, x1
    // 0x650e54: cmp             w0, NULL
    // 0x650e58: b.ne            #0x650e68
    // 0x650e5c: r2 = Instance_CustomNum
    //     0x650e5c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x650e60: ldr             x2, [x2, #0xaf8]
    // 0x650e64: b               #0x650e6c
    // 0x650e68: mov             x2, x0
    // 0x650e6c: ldur            x0, [fp, #-0x18]
    // 0x650e70: r1 = Instance_CustomNum
    //     0x650e70: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x650e74: ldr             x1, [x1, #0xce0]
    // 0x650e78: r0 = mult2()
    //     0x650e78: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x650e7c: mov             x2, x0
    // 0x650e80: r1 = Instance_CustomNum
    //     0x650e80: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x650e84: ldr             x1, [x1, #0xa70]
    // 0x650e88: r0 = add()
    //     0x650e88: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x650e8c: mov             x3, x0
    // 0x650e90: ldur            x0, [fp, #-0x18]
    // 0x650e94: stur            x3, [fp, #-0x28]
    // 0x650e98: LoadField: r4 = r0->field_37
    //     0x650e98: ldur            w4, [x0, #0x37]
    // 0x650e9c: DecompressPointer r4
    //     0x650e9c: add             x4, x4, HEAP, lsl #32
    // 0x650ea0: mov             x1, x4
    // 0x650ea4: stur            x4, [fp, #-8]
    // 0x650ea8: r2 = Instance_Chapter11Stat
    //     0x650ea8: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x650eac: ldr             x2, [x2, #0x5e0]
    // 0x650eb0: r0 = _getValueOrData()
    //     0x650eb0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x650eb4: mov             x1, x0
    // 0x650eb8: ldur            x0, [fp, #-8]
    // 0x650ebc: LoadField: r2 = r0->field_f
    //     0x650ebc: ldur            w2, [x0, #0xf]
    // 0x650ec0: DecompressPointer r2
    //     0x650ec0: add             x2, x2, HEAP, lsl #32
    // 0x650ec4: cmp             w2, w1
    // 0x650ec8: b.ne            #0x650ed4
    // 0x650ecc: r0 = Null
    //     0x650ecc: mov             x0, NULL
    // 0x650ed0: b               #0x650ed8
    // 0x650ed4: mov             x0, x1
    // 0x650ed8: cmp             w0, NULL
    // 0x650edc: b.ne            #0x650eec
    // 0x650ee0: r2 = Instance_CustomNum
    //     0x650ee0: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x650ee4: ldr             x2, [x2, #0xaf8]
    // 0x650ee8: b               #0x650ef0
    // 0x650eec: mov             x2, x0
    // 0x650ef0: ldur            x0, [fp, #-0x18]
    // 0x650ef4: r1 = Instance_CustomNum
    //     0x650ef4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x650ef8: ldr             x1, [x1, #0xce0]
    // 0x650efc: r0 = mult2()
    //     0x650efc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x650f00: mov             x2, x0
    // 0x650f04: r1 = Instance_CustomNum
    //     0x650f04: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x650f08: ldr             x1, [x1, #0xa70]
    // 0x650f0c: r0 = add()
    //     0x650f0c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x650f10: ldur            x1, [fp, #-0x20]
    // 0x650f14: ldur            x2, [fp, #-0x28]
    // 0x650f18: mov             x3, x0
    // 0x650f1c: r0 = mult3()
    //     0x650f1c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x650f20: mov             x3, x0
    // 0x650f24: ldur            x0, [fp, #-0x18]
    // 0x650f28: stur            x3, [fp, #-0x20]
    // 0x650f2c: LoadField: r1 = r0->field_3f
    //     0x650f2c: ldur            w1, [x0, #0x3f]
    // 0x650f30: DecompressPointer r1
    //     0x650f30: add             x1, x1, HEAP, lsl #32
    // 0x650f34: LoadField: r2 = r1->field_7
    //     0x650f34: ldur            w2, [x1, #7]
    // 0x650f38: DecompressPointer r2
    //     0x650f38: add             x2, x2, HEAP, lsl #32
    // 0x650f3c: cmp             w2, #2
    // 0x650f40: b.ne            #0x650f58
    // 0x650f44: mov             x1, x0
    // 0x650f48: mov             x0, x3
    // 0x650f4c: r2 = Instance_CustomNum
    //     0x650f4c: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x650f50: ldr             x2, [x2, #0xa70]
    // 0x650f54: b               #0x650fd8
    // 0x650f58: LoadField: r4 = r0->field_37
    //     0x650f58: ldur            w4, [x0, #0x37]
    // 0x650f5c: DecompressPointer r4
    //     0x650f5c: add             x4, x4, HEAP, lsl #32
    // 0x650f60: mov             x1, x4
    // 0x650f64: stur            x4, [fp, #-8]
    // 0x650f68: r2 = Instance_Chapter11Stat
    //     0x650f68: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x650f6c: ldr             x2, [x2, #0x5b0]
    // 0x650f70: r0 = _getValueOrData()
    //     0x650f70: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x650f74: mov             x1, x0
    // 0x650f78: ldur            x0, [fp, #-8]
    // 0x650f7c: LoadField: r2 = r0->field_f
    //     0x650f7c: ldur            w2, [x0, #0xf]
    // 0x650f80: DecompressPointer r2
    //     0x650f80: add             x2, x2, HEAP, lsl #32
    // 0x650f84: cmp             w2, w1
    // 0x650f88: b.ne            #0x650f94
    // 0x650f8c: r0 = Null
    //     0x650f8c: mov             x0, NULL
    // 0x650f90: b               #0x650f98
    // 0x650f94: mov             x0, x1
    // 0x650f98: cmp             w0, NULL
    // 0x650f9c: b.ne            #0x650fac
    // 0x650fa0: r2 = Instance_CustomNum
    //     0x650fa0: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x650fa4: ldr             x2, [x2, #0xaf8]
    // 0x650fa8: b               #0x650fb0
    // 0x650fac: mov             x2, x0
    // 0x650fb0: r1 = Instance_CustomNum
    //     0x650fb0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x650fb4: ldr             x1, [x1, #0xce0]
    // 0x650fb8: r0 = mult2()
    //     0x650fb8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x650fbc: mov             x2, x0
    // 0x650fc0: r1 = Instance_CustomNum
    //     0x650fc0: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x650fc4: ldr             x1, [x1, #0xa70]
    // 0x650fc8: r0 = add()
    //     0x650fc8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x650fcc: mov             x2, x0
    // 0x650fd0: ldur            x1, [fp, #-0x18]
    // 0x650fd4: ldur            x0, [fp, #-0x20]
    // 0x650fd8: stur            x2, [fp, #-8]
    // 0x650fdc: r0 = Boost()
    //     0x650fdc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x650fe0: mov             x1, x0
    // 0x650fe4: ldur            x0, [fp, #-0x20]
    // 0x650fe8: StoreField: r1->field_7 = r0
    //     0x650fe8: stur            w0, [x1, #7]
    // 0x650fec: r0 = Instance_CustomNum
    //     0x650fec: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x650ff0: ldr             x0, [x0, #0xa70]
    // 0x650ff4: StoreField: r1->field_b = r0
    //     0x650ff4: stur            w0, [x1, #0xb]
    // 0x650ff8: ldur            x2, [fp, #-8]
    // 0x650ffc: StoreField: r1->field_f = r2
    //     0x650ffc: stur            w2, [x1, #0xf]
    // 0x651000: StoreField: r1->field_13 = r0
    //     0x651000: stur            w0, [x1, #0x13]
    // 0x651004: mov             x3, x1
    // 0x651008: ldur            x1, [fp, #-0x10]
    // 0x65100c: r2 = 2
    //     0x65100c: movz            x2, #0x2
    // 0x651010: r0 = []=()
    //     0x651010: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x651014: ldur            x0, [fp, #-0x18]
    // 0x651018: LoadField: r1 = r0->field_43
    //     0x651018: ldur            w1, [x0, #0x43]
    // 0x65101c: DecompressPointer r1
    //     0x65101c: add             x1, x1, HEAP, lsl #32
    // 0x651020: r2 = 22
    //     0x651020: movz            x2, #0x16
    // 0x651024: r0 = containsKey()
    //     0x651024: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x651028: tbnz            w0, #4, #0x6510b0
    // 0x65102c: r1 = "ch11_autobuy_engagement"
    //     0x65102c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6e8] "ch11_autobuy_engagement"
    //     0x651030: ldr             x1, [x1, #0x6e8]
    // 0x651034: r0 = prefsGetBool()
    //     0x651034: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x651038: cmp             w0, NULL
    // 0x65103c: b.eq            #0x6510b0
    // 0x651040: tbnz            w0, #4, #0x6510b0
    // 0x651044: r0 = 10
    //     0x651044: movz            x0, #0xa
    // 0x651048: mov             x2, x0
    // 0x65104c: r1 = Null
    //     0x65104c: mov             x1, NULL
    // 0x651050: r0 = AllocateArray()
    //     0x651050: bl              #0x82746c  ; AllocateArrayStub
    // 0x651054: stur            x0, [fp, #-8]
    // 0x651058: r16 = 20
    //     0x651058: movz            x16, #0x14
    // 0x65105c: StoreField: r0->field_f = r16
    //     0x65105c: stur            w16, [x0, #0xf]
    // 0x651060: r16 = 22
    //     0x651060: movz            x16, #0x16
    // 0x651064: StoreField: r0->field_13 = r16
    //     0x651064: stur            w16, [x0, #0x13]
    // 0x651068: r16 = 24
    //     0x651068: movz            x16, #0x18
    // 0x65106c: ArrayStore: r0[0] = r16  ; List_4
    //     0x65106c: stur            w16, [x0, #0x17]
    // 0x651070: r16 = 26
    //     0x651070: movz            x16, #0x1a
    // 0x651074: StoreField: r0->field_1b = r16
    //     0x651074: stur            w16, [x0, #0x1b]
    // 0x651078: r16 = 28
    //     0x651078: movz            x16, #0x1c
    // 0x65107c: StoreField: r0->field_1f = r16
    //     0x65107c: stur            w16, [x0, #0x1f]
    // 0x651080: r1 = <int>
    //     0x651080: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x651084: r0 = AllocateGrowableArray()
    //     0x651084: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x651088: mov             x1, x0
    // 0x65108c: ldur            x0, [fp, #-8]
    // 0x651090: StoreField: r1->field_f = r0
    //     0x651090: stur            w0, [x1, #0xf]
    // 0x651094: r0 = 10
    //     0x651094: movz            x0, #0xa
    // 0x651098: StoreField: r1->field_b = r0
    //     0x651098: stur            w0, [x1, #0xb]
    // 0x65109c: mov             x2, x1
    // 0x6510a0: ldur            x1, [fp, #-0x18]
    // 0x6510a4: r3 = false
    //     0x6510a4: add             x3, NULL, #0x30  ; false
    // 0x6510a8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6510a8: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6510ac: r0 = buyAll()
    //     0x6510ac: bl              #0x544a08  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll
    // 0x6510b0: ldur            x0, [fp, #-0x18]
    // 0x6510b4: LoadField: r1 = r0->field_43
    //     0x6510b4: ldur            w1, [x0, #0x43]
    // 0x6510b8: DecompressPointer r1
    //     0x6510b8: add             x1, x1, HEAP, lsl #32
    // 0x6510bc: r2 = 22
    //     0x6510bc: movz            x2, #0x16
    // 0x6510c0: r0 = containsKey()
    //     0x6510c0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6510c4: tbnz            w0, #4, #0x65113c
    // 0x6510c8: r1 = "ch11_autobuy_velocity"
    //     0x6510c8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6f0] "ch11_autobuy_velocity"
    //     0x6510cc: ldr             x1, [x1, #0x6f0]
    // 0x6510d0: r0 = prefsGetBool()
    //     0x6510d0: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x6510d4: cmp             w0, NULL
    // 0x6510d8: b.eq            #0x65113c
    // 0x6510dc: tbnz            w0, #4, #0x65113c
    // 0x6510e0: r0 = 6
    //     0x6510e0: movz            x0, #0x6
    // 0x6510e4: mov             x2, x0
    // 0x6510e8: r1 = Null
    //     0x6510e8: mov             x1, NULL
    // 0x6510ec: r0 = AllocateArray()
    //     0x6510ec: bl              #0x82746c  ; AllocateArrayStub
    // 0x6510f0: stur            x0, [fp, #-8]
    // 0x6510f4: r16 = 40
    //     0x6510f4: movz            x16, #0x28
    // 0x6510f8: StoreField: r0->field_f = r16
    //     0x6510f8: stur            w16, [x0, #0xf]
    // 0x6510fc: r16 = 42
    //     0x6510fc: movz            x16, #0x2a
    // 0x651100: StoreField: r0->field_13 = r16
    //     0x651100: stur            w16, [x0, #0x13]
    // 0x651104: r16 = 44
    //     0x651104: movz            x16, #0x2c
    // 0x651108: ArrayStore: r0[0] = r16  ; List_4
    //     0x651108: stur            w16, [x0, #0x17]
    // 0x65110c: r1 = <int>
    //     0x65110c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x651110: r0 = AllocateGrowableArray()
    //     0x651110: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x651114: mov             x1, x0
    // 0x651118: ldur            x0, [fp, #-8]
    // 0x65111c: StoreField: r1->field_f = r0
    //     0x65111c: stur            w0, [x1, #0xf]
    // 0x651120: r0 = 6
    //     0x651120: movz            x0, #0x6
    // 0x651124: StoreField: r1->field_b = r0
    //     0x651124: stur            w0, [x1, #0xb]
    // 0x651128: mov             x2, x1
    // 0x65112c: ldur            x1, [fp, #-0x18]
    // 0x651130: r3 = false
    //     0x651130: add             x3, NULL, #0x30  ; false
    // 0x651134: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x651134: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x651138: r0 = buyAll()
    //     0x651138: bl              #0x544a08  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll
    // 0x65113c: r0 = Null
    //     0x65113c: mov             x0, NULL
    // 0x651140: LeaveFrame
    //     0x651140: mov             SP, fp
    //     0x651144: ldp             fp, lr, [SP], #0x10
    // 0x651148: ret
    //     0x651148: ret             
    // 0x65114c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65114c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x651150: b               #0x650d78
  }
  _ checkAllBoosts(/* No info */) {
    // ** addr: 0x6861c0, size: 0x720
    // 0x6861c0: EnterFrame
    //     0x6861c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6861c4: mov             fp, SP
    // 0x6861c8: AllocStack(0x20)
    //     0x6861c8: sub             SP, SP, #0x20
    // 0x6861cc: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x10 */)
    //     0x6861cc: mov             x0, x1
    //     0x6861d0: stur            x1, [fp, #-0x10]
    // 0x6861d4: CheckStackOverflow
    //     0x6861d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6861d8: cmp             SP, x16
    //     0x6861dc: b.ls            #0x6868d8
    // 0x6861e0: LoadField: r3 = r0->field_43
    //     0x6861e0: ldur            w3, [x0, #0x43]
    // 0x6861e4: DecompressPointer r3
    //     0x6861e4: add             x3, x3, HEAP, lsl #32
    // 0x6861e8: mov             x1, x3
    // 0x6861ec: stur            x3, [fp, #-8]
    // 0x6861f0: r2 = 4
    //     0x6861f0: movz            x2, #0x4
    // 0x6861f4: r0 = _getValueOrData()
    //     0x6861f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6861f8: mov             x1, x0
    // 0x6861fc: ldur            x0, [fp, #-8]
    // 0x686200: LoadField: r2 = r0->field_f
    //     0x686200: ldur            w2, [x0, #0xf]
    // 0x686204: DecompressPointer r2
    //     0x686204: add             x2, x2, HEAP, lsl #32
    // 0x686208: cmp             w2, w1
    // 0x68620c: b.ne            #0x686218
    // 0x686210: r0 = Null
    //     0x686210: mov             x0, NULL
    // 0x686214: b               #0x68621c
    // 0x686218: mov             x0, x1
    // 0x68621c: cmp             w0, NULL
    // 0x686220: b.ne            #0x68622c
    // 0x686224: r0 = 0
    //     0x686224: movz            x0, #0
    // 0x686228: b               #0x68623c
    // 0x68622c: r1 = LoadInt32Instr(r0)
    //     0x68622c: sbfx            x1, x0, #1, #0x1f
    //     0x686230: tbz             w0, #0, #0x686238
    //     0x686234: ldur            x1, [x0, #7]
    // 0x686238: mov             x0, x1
    // 0x68623c: cmp             x0, #3
    // 0x686240: b.lt            #0x686318
    // 0x686244: ldur            x0, [fp, #-0x10]
    // 0x686248: LoadField: r3 = r0->field_33
    //     0x686248: ldur            w3, [x0, #0x33]
    // 0x68624c: DecompressPointer r3
    //     0x68624c: add             x3, x3, HEAP, lsl #32
    // 0x686250: stur            x3, [fp, #-8]
    // 0x686254: r1 = Null
    //     0x686254: mov             x1, NULL
    // 0x686258: r2 = 16
    //     0x686258: movz            x2, #0x10
    // 0x68625c: r0 = CustomNum()
    //     0x68625c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x686260: stur            x0, [fp, #-0x18]
    // 0x686264: r0 = Boost()
    //     0x686264: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686268: mov             x1, x0
    // 0x68626c: r0 = Instance_CustomNum
    //     0x68626c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686270: ldr             x0, [x0, #0xa70]
    // 0x686274: StoreField: r1->field_7 = r0
    //     0x686274: stur            w0, [x1, #7]
    // 0x686278: StoreField: r1->field_b = r0
    //     0x686278: stur            w0, [x1, #0xb]
    // 0x68627c: ldur            x2, [fp, #-0x18]
    // 0x686280: StoreField: r1->field_f = r2
    //     0x686280: stur            w2, [x1, #0xf]
    // 0x686284: StoreField: r1->field_13 = r0
    //     0x686284: stur            w0, [x1, #0x13]
    // 0x686288: mov             x3, x1
    // 0x68628c: ldur            x1, [fp, #-8]
    // 0x686290: r2 = 20
    //     0x686290: movz            x2, #0x14
    // 0x686294: r0 = []=()
    //     0x686294: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686298: r1 = Null
    //     0x686298: mov             x1, NULL
    // 0x68629c: r2 = 16
    //     0x68629c: movz            x2, #0x10
    // 0x6862a0: r0 = CustomNum()
    //     0x6862a0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6862a4: stur            x0, [fp, #-0x18]
    // 0x6862a8: r0 = Boost()
    //     0x6862a8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x6862ac: mov             x1, x0
    // 0x6862b0: r0 = Instance_CustomNum
    //     0x6862b0: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6862b4: ldr             x0, [x0, #0xa70]
    // 0x6862b8: StoreField: r1->field_7 = r0
    //     0x6862b8: stur            w0, [x1, #7]
    // 0x6862bc: StoreField: r1->field_b = r0
    //     0x6862bc: stur            w0, [x1, #0xb]
    // 0x6862c0: ldur            x2, [fp, #-0x18]
    // 0x6862c4: StoreField: r1->field_f = r2
    //     0x6862c4: stur            w2, [x1, #0xf]
    // 0x6862c8: StoreField: r1->field_13 = r0
    //     0x6862c8: stur            w0, [x1, #0x13]
    // 0x6862cc: mov             x3, x1
    // 0x6862d0: ldur            x1, [fp, #-8]
    // 0x6862d4: r2 = 22
    //     0x6862d4: movz            x2, #0x16
    // 0x6862d8: r0 = []=()
    //     0x6862d8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6862dc: r0 = Boost()
    //     0x6862dc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x6862e0: mov             x1, x0
    // 0x6862e4: r0 = Instance_CustomNum
    //     0x6862e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6862e8: ldr             x0, [x0, #0xa70]
    // 0x6862ec: StoreField: r1->field_7 = r0
    //     0x6862ec: stur            w0, [x1, #7]
    // 0x6862f0: StoreField: r1->field_b = r0
    //     0x6862f0: stur            w0, [x1, #0xb]
    // 0x6862f4: r3 = Instance_CustomNum
    //     0x6862f4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6862f8: ldr             x3, [x3, #0xdd0]
    // 0x6862fc: StoreField: r1->field_f = r3
    //     0x6862fc: stur            w3, [x1, #0xf]
    // 0x686300: StoreField: r1->field_13 = r0
    //     0x686300: stur            w0, [x1, #0x13]
    // 0x686304: mov             x3, x1
    // 0x686308: ldur            x1, [fp, #-8]
    // 0x68630c: r2 = 24
    //     0x68630c: movz            x2, #0x18
    // 0x686310: r0 = []=()
    //     0x686310: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686314: b               #0x68652c
    // 0x686318: ldur            x0, [fp, #-0x10]
    // 0x68631c: r3 = Instance_CustomNum
    //     0x68631c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x686320: ldr             x3, [x3, #0xdd0]
    // 0x686324: LoadField: r4 = r0->field_43
    //     0x686324: ldur            w4, [x0, #0x43]
    // 0x686328: DecompressPointer r4
    //     0x686328: add             x4, x4, HEAP, lsl #32
    // 0x68632c: mov             x1, x4
    // 0x686330: stur            x4, [fp, #-8]
    // 0x686334: r2 = 4
    //     0x686334: movz            x2, #0x4
    // 0x686338: r0 = _getValueOrData()
    //     0x686338: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68633c: mov             x1, x0
    // 0x686340: ldur            x0, [fp, #-8]
    // 0x686344: LoadField: r2 = r0->field_f
    //     0x686344: ldur            w2, [x0, #0xf]
    // 0x686348: DecompressPointer r2
    //     0x686348: add             x2, x2, HEAP, lsl #32
    // 0x68634c: cmp             w2, w1
    // 0x686350: b.ne            #0x68635c
    // 0x686354: r0 = Null
    //     0x686354: mov             x0, NULL
    // 0x686358: b               #0x686360
    // 0x68635c: mov             x0, x1
    // 0x686360: cmp             w0, NULL
    // 0x686364: b.ne            #0x686370
    // 0x686368: r0 = 0
    //     0x686368: movz            x0, #0
    // 0x68636c: b               #0x686380
    // 0x686370: r1 = LoadInt32Instr(r0)
    //     0x686370: sbfx            x1, x0, #1, #0x1f
    //     0x686374: tbz             w0, #0, #0x68637c
    //     0x686378: ldur            x1, [x0, #7]
    // 0x68637c: mov             x0, x1
    // 0x686380: cmp             x0, #3
    // 0x686384: b.lt            #0x686444
    // 0x686388: ldur            x0, [fp, #-0x10]
    // 0x68638c: LoadField: r1 = r0->field_33
    //     0x68638c: ldur            w1, [x0, #0x33]
    // 0x686390: DecompressPointer r1
    //     0x686390: add             x1, x1, HEAP, lsl #32
    // 0x686394: stur            x1, [fp, #-8]
    // 0x686398: r0 = Boost()
    //     0x686398: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68639c: mov             x1, x0
    // 0x6863a0: r0 = Instance_CustomNum
    //     0x6863a0: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6863a4: ldr             x0, [x0, #0xa70]
    // 0x6863a8: StoreField: r1->field_7 = r0
    //     0x6863a8: stur            w0, [x1, #7]
    // 0x6863ac: StoreField: r1->field_b = r0
    //     0x6863ac: stur            w0, [x1, #0xb]
    // 0x6863b0: r4 = Instance_CustomNum
    //     0x6863b0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6863b4: ldr             x4, [x4, #0xdd0]
    // 0x6863b8: StoreField: r1->field_f = r4
    //     0x6863b8: stur            w4, [x1, #0xf]
    // 0x6863bc: StoreField: r1->field_13 = r0
    //     0x6863bc: stur            w0, [x1, #0x13]
    // 0x6863c0: mov             x3, x1
    // 0x6863c4: ldur            x1, [fp, #-8]
    // 0x6863c8: r2 = 20
    //     0x6863c8: movz            x2, #0x14
    // 0x6863cc: r0 = []=()
    //     0x6863cc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6863d0: r0 = Boost()
    //     0x6863d0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x6863d4: mov             x1, x0
    // 0x6863d8: r0 = Instance_CustomNum
    //     0x6863d8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6863dc: ldr             x0, [x0, #0xa70]
    // 0x6863e0: StoreField: r1->field_7 = r0
    //     0x6863e0: stur            w0, [x1, #7]
    // 0x6863e4: StoreField: r1->field_b = r0
    //     0x6863e4: stur            w0, [x1, #0xb]
    // 0x6863e8: r2 = Instance_CustomNum
    //     0x6863e8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!CustomNum@828ea1
    //     0x6863ec: ldr             x2, [x2, #0xdd0]
    // 0x6863f0: StoreField: r1->field_f = r2
    //     0x6863f0: stur            w2, [x1, #0xf]
    // 0x6863f4: StoreField: r1->field_13 = r0
    //     0x6863f4: stur            w0, [x1, #0x13]
    // 0x6863f8: mov             x3, x1
    // 0x6863fc: ldur            x1, [fp, #-8]
    // 0x686400: r2 = 22
    //     0x686400: movz            x2, #0x16
    // 0x686404: r0 = []=()
    //     0x686404: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686408: r0 = Boost()
    //     0x686408: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68640c: mov             x1, x0
    // 0x686410: r0 = Instance_CustomNum
    //     0x686410: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686414: ldr             x0, [x0, #0xa70]
    // 0x686418: StoreField: r1->field_7 = r0
    //     0x686418: stur            w0, [x1, #7]
    // 0x68641c: StoreField: r1->field_b = r0
    //     0x68641c: stur            w0, [x1, #0xb]
    // 0x686420: r4 = Instance_CustomNum
    //     0x686420: add             x4, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x686424: ldr             x4, [x4, #0x970]
    // 0x686428: StoreField: r1->field_f = r4
    //     0x686428: stur            w4, [x1, #0xf]
    // 0x68642c: StoreField: r1->field_13 = r0
    //     0x68642c: stur            w0, [x1, #0x13]
    // 0x686430: mov             x3, x1
    // 0x686434: ldur            x1, [fp, #-8]
    // 0x686438: r2 = 24
    //     0x686438: movz            x2, #0x18
    // 0x68643c: r0 = []=()
    //     0x68643c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686440: b               #0x68652c
    // 0x686444: ldur            x0, [fp, #-0x10]
    // 0x686448: LoadField: r3 = r0->field_43
    //     0x686448: ldur            w3, [x0, #0x43]
    // 0x68644c: DecompressPointer r3
    //     0x68644c: add             x3, x3, HEAP, lsl #32
    // 0x686450: mov             x1, x3
    // 0x686454: stur            x3, [fp, #-8]
    // 0x686458: r2 = 4
    //     0x686458: movz            x2, #0x4
    // 0x68645c: r0 = _getValueOrData()
    //     0x68645c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686460: mov             x1, x0
    // 0x686464: ldur            x0, [fp, #-8]
    // 0x686468: LoadField: r2 = r0->field_f
    //     0x686468: ldur            w2, [x0, #0xf]
    // 0x68646c: DecompressPointer r2
    //     0x68646c: add             x2, x2, HEAP, lsl #32
    // 0x686470: cmp             w2, w1
    // 0x686474: b.ne            #0x686480
    // 0x686478: r0 = Null
    //     0x686478: mov             x0, NULL
    // 0x68647c: b               #0x686484
    // 0x686480: mov             x0, x1
    // 0x686484: cmp             w0, NULL
    // 0x686488: b.ne            #0x686494
    // 0x68648c: r0 = 0
    //     0x68648c: movz            x0, #0
    // 0x686490: b               #0x6864a4
    // 0x686494: r1 = LoadInt32Instr(r0)
    //     0x686494: sbfx            x1, x0, #1, #0x1f
    //     0x686498: tbz             w0, #0, #0x6864a0
    //     0x68649c: ldur            x1, [x0, #7]
    // 0x6864a0: mov             x0, x1
    // 0x6864a4: cmp             x0, #2
    // 0x6864a8: b.lt            #0x68652c
    // 0x6864ac: ldur            x0, [fp, #-0x10]
    // 0x6864b0: LoadField: r1 = r0->field_33
    //     0x6864b0: ldur            w1, [x0, #0x33]
    // 0x6864b4: DecompressPointer r1
    //     0x6864b4: add             x1, x1, HEAP, lsl #32
    // 0x6864b8: stur            x1, [fp, #-8]
    // 0x6864bc: r0 = Boost()
    //     0x6864bc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x6864c0: mov             x1, x0
    // 0x6864c4: r0 = Instance_CustomNum
    //     0x6864c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6864c8: ldr             x0, [x0, #0xa70]
    // 0x6864cc: StoreField: r1->field_7 = r0
    //     0x6864cc: stur            w0, [x1, #7]
    // 0x6864d0: StoreField: r1->field_b = r0
    //     0x6864d0: stur            w0, [x1, #0xb]
    // 0x6864d4: r4 = Instance_CustomNum
    //     0x6864d4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x6864d8: ldr             x4, [x4, #0x970]
    // 0x6864dc: StoreField: r1->field_f = r4
    //     0x6864dc: stur            w4, [x1, #0xf]
    // 0x6864e0: StoreField: r1->field_13 = r0
    //     0x6864e0: stur            w0, [x1, #0x13]
    // 0x6864e4: mov             x3, x1
    // 0x6864e8: ldur            x1, [fp, #-8]
    // 0x6864ec: r2 = 20
    //     0x6864ec: movz            x2, #0x14
    // 0x6864f0: r0 = []=()
    //     0x6864f0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6864f4: r0 = Boost()
    //     0x6864f4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x6864f8: mov             x1, x0
    // 0x6864fc: r0 = Instance_CustomNum
    //     0x6864fc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686500: ldr             x0, [x0, #0xa70]
    // 0x686504: StoreField: r1->field_7 = r0
    //     0x686504: stur            w0, [x1, #7]
    // 0x686508: StoreField: r1->field_b = r0
    //     0x686508: stur            w0, [x1, #0xb]
    // 0x68650c: r4 = Instance_CustomNum
    //     0x68650c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x686510: ldr             x4, [x4, #0x970]
    // 0x686514: StoreField: r1->field_f = r4
    //     0x686514: stur            w4, [x1, #0xf]
    // 0x686518: StoreField: r1->field_13 = r0
    //     0x686518: stur            w0, [x1, #0x13]
    // 0x68651c: mov             x3, x1
    // 0x686520: ldur            x1, [fp, #-8]
    // 0x686524: r2 = 22
    //     0x686524: movz            x2, #0x16
    // 0x686528: r0 = []=()
    //     0x686528: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68652c: ldur            x0, [fp, #-0x10]
    // 0x686530: LoadField: r3 = r0->field_43
    //     0x686530: ldur            w3, [x0, #0x43]
    // 0x686534: DecompressPointer r3
    //     0x686534: add             x3, x3, HEAP, lsl #32
    // 0x686538: mov             x1, x3
    // 0x68653c: stur            x3, [fp, #-8]
    // 0x686540: r2 = 26
    //     0x686540: movz            x2, #0x1a
    // 0x686544: r0 = _getValueOrData()
    //     0x686544: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686548: mov             x1, x0
    // 0x68654c: ldur            x0, [fp, #-8]
    // 0x686550: LoadField: r2 = r0->field_f
    //     0x686550: ldur            w2, [x0, #0xf]
    // 0x686554: DecompressPointer r2
    //     0x686554: add             x2, x2, HEAP, lsl #32
    // 0x686558: cmp             w2, w1
    // 0x68655c: b.eq            #0x686568
    // 0x686560: cmp             w1, NULL
    // 0x686564: b.ne            #0x686574
    // 0x686568: r3 = Instance_CustomNum
    //     0x686568: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68656c: ldr             x3, [x3, #0xa70]
    // 0x686570: b               #0x68667c
    // 0x686574: ldur            x0, [fp, #-0x10]
    // 0x686578: LoadField: r3 = r0->field_43
    //     0x686578: ldur            w3, [x0, #0x43]
    // 0x68657c: DecompressPointer r3
    //     0x68657c: add             x3, x3, HEAP, lsl #32
    // 0x686580: mov             x1, x3
    // 0x686584: stur            x3, [fp, #-8]
    // 0x686588: r2 = 26
    //     0x686588: movz            x2, #0x1a
    // 0x68658c: r0 = _getValueOrData()
    //     0x68658c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686590: mov             x1, x0
    // 0x686594: ldur            x0, [fp, #-8]
    // 0x686598: LoadField: r2 = r0->field_f
    //     0x686598: ldur            w2, [x0, #0xf]
    // 0x68659c: DecompressPointer r2
    //     0x68659c: add             x2, x2, HEAP, lsl #32
    // 0x6865a0: cmp             w2, w1
    // 0x6865a4: b.eq            #0x6865bc
    // 0x6865a8: cmp             w1, #2
    // 0x6865ac: b.ne            #0x6865bc
    // 0x6865b0: r0 = Instance_CustomNum
    //     0x6865b0: add             x0, PP, #0x15, lsl #12  ; [pp+0x151f8] Obj!CustomNum@82b2d1
    //     0x6865b4: ldr             x0, [x0, #0x1f8]
    // 0x6865b8: b               #0x686678
    // 0x6865bc: ldur            x0, [fp, #-0x10]
    // 0x6865c0: LoadField: r3 = r0->field_43
    //     0x6865c0: ldur            w3, [x0, #0x43]
    // 0x6865c4: DecompressPointer r3
    //     0x6865c4: add             x3, x3, HEAP, lsl #32
    // 0x6865c8: mov             x1, x3
    // 0x6865cc: stur            x3, [fp, #-8]
    // 0x6865d0: r2 = 26
    //     0x6865d0: movz            x2, #0x1a
    // 0x6865d4: r0 = _getValueOrData()
    //     0x6865d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6865d8: mov             x1, x0
    // 0x6865dc: ldur            x0, [fp, #-8]
    // 0x6865e0: LoadField: r2 = r0->field_f
    //     0x6865e0: ldur            w2, [x0, #0xf]
    // 0x6865e4: DecompressPointer r2
    //     0x6865e4: add             x2, x2, HEAP, lsl #32
    // 0x6865e8: cmp             w2, w1
    // 0x6865ec: b.eq            #0x686604
    // 0x6865f0: cmp             w1, #4
    // 0x6865f4: b.ne            #0x686604
    // 0x6865f8: r0 = Instance_CustomNum
    //     0x6865f8: add             x0, PP, #0x14, lsl #12  ; [pp+0x146f0] Obj!CustomNum@82b341
    //     0x6865fc: ldr             x0, [x0, #0x6f0]
    // 0x686600: b               #0x686678
    // 0x686604: ldur            x0, [fp, #-0x10]
    // 0x686608: LoadField: r3 = r0->field_43
    //     0x686608: ldur            w3, [x0, #0x43]
    // 0x68660c: DecompressPointer r3
    //     0x68660c: add             x3, x3, HEAP, lsl #32
    // 0x686610: mov             x1, x3
    // 0x686614: stur            x3, [fp, #-8]
    // 0x686618: r2 = 26
    //     0x686618: movz            x2, #0x1a
    // 0x68661c: r0 = _getValueOrData()
    //     0x68661c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686620: mov             x1, x0
    // 0x686624: ldur            x0, [fp, #-8]
    // 0x686628: LoadField: r2 = r0->field_f
    //     0x686628: ldur            w2, [x0, #0xf]
    // 0x68662c: DecompressPointer r2
    //     0x68662c: add             x2, x2, HEAP, lsl #32
    // 0x686630: cmp             w2, w1
    // 0x686634: b.eq            #0x686650
    // 0x686638: cmp             w1, #6
    // 0x68663c: b.ne            #0x686650
    // 0x686640: r1 = Null
    //     0x686640: mov             x1, NULL
    // 0x686644: r2 = 0.050000
    //     0x686644: ldr             x2, [PP, #0x6ef0]  ; [pp+0x6ef0] 0.05
    // 0x686648: r0 = CustomNum()
    //     0x686648: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x68664c: b               #0x686678
    // 0x686650: r1 = Null
    //     0x686650: mov             x1, NULL
    // 0x686654: r2 = 0.050000
    //     0x686654: ldr             x2, [PP, #0x6ef0]  ; [pp+0x6ef0] 0.05
    // 0x686658: r0 = CustomNum()
    //     0x686658: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x68665c: r1 = "Unknown upgrade 13 value"
    //     0x68665c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16320] "Unknown upgrade 13 value"
    //     0x686660: ldr             x1, [x1, #0x320]
    // 0x686664: r2 = Null
    //     0x686664: mov             x2, NULL
    // 0x686668: stur            x0, [fp, #-8]
    // 0x68666c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x68666c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x686670: r0 = crashlyticsRecordError()
    //     0x686670: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x686674: ldur            x0, [fp, #-8]
    // 0x686678: mov             x3, x0
    // 0x68667c: ldur            x0, [fp, #-0x10]
    // 0x686680: stur            x3, [fp, #-0x20]
    // 0x686684: LoadField: r4 = r0->field_2f
    //     0x686684: ldur            w4, [x0, #0x2f]
    // 0x686688: DecompressPointer r4
    //     0x686688: add             x4, x4, HEAP, lsl #32
    // 0x68668c: stur            x4, [fp, #-0x18]
    // 0x686690: LoadField: r5 = r0->field_43
    //     0x686690: ldur            w5, [x0, #0x43]
    // 0x686694: DecompressPointer r5
    //     0x686694: add             x5, x5, HEAP, lsl #32
    // 0x686698: mov             x1, x5
    // 0x68669c: stur            x5, [fp, #-8]
    // 0x6866a0: r2 = 22
    //     0x6866a0: movz            x2, #0x16
    // 0x6866a4: r0 = _getValueOrData()
    //     0x6866a4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6866a8: mov             x1, x0
    // 0x6866ac: ldur            x0, [fp, #-8]
    // 0x6866b0: LoadField: r2 = r0->field_f
    //     0x6866b0: ldur            w2, [x0, #0xf]
    // 0x6866b4: DecompressPointer r2
    //     0x6866b4: add             x2, x2, HEAP, lsl #32
    // 0x6866b8: cmp             w2, w1
    // 0x6866bc: b.ne            #0x6866c8
    // 0x6866c0: r0 = Null
    //     0x6866c0: mov             x0, NULL
    // 0x6866c4: b               #0x6866cc
    // 0x6866c8: mov             x0, x1
    // 0x6866cc: cmp             w0, NULL
    // 0x6866d0: b.ne            #0x6866dc
    // 0x6866d4: r2 = 0
    //     0x6866d4: movz            x2, #0
    // 0x6866d8: b               #0x6866ec
    // 0x6866dc: r1 = LoadInt32Instr(r0)
    //     0x6866dc: sbfx            x1, x0, #1, #0x1f
    //     0x6866e0: tbz             w0, #0, #0x6866e8
    //     0x6866e4: ldur            x1, [x0, #7]
    // 0x6866e8: mov             x2, x1
    // 0x6866ec: ldur            x3, [fp, #-0x10]
    // 0x6866f0: ldur            x4, [fp, #-0x20]
    // 0x6866f4: r0 = BoxInt64Instr(r2)
    //     0x6866f4: sbfiz           x0, x2, #1, #0x1f
    //     0x6866f8: cmp             x2, x0, asr #1
    //     0x6866fc: b.eq            #0x686708
    //     0x686700: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x686704: stur            x2, [x0, #7]
    // 0x686708: mov             x2, x0
    // 0x68670c: r1 = Instance_CustomNum
    //     0x68670c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x686710: ldr             x1, [x1, #0x970]
    // 0x686714: r0 = pow()
    //     0x686714: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x686718: stur            x0, [fp, #-8]
    // 0x68671c: r0 = Boost()
    //     0x68671c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686720: mov             x1, x0
    // 0x686724: r0 = Instance_CustomNum
    //     0x686724: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686728: ldr             x0, [x0, #0xa70]
    // 0x68672c: StoreField: r1->field_7 = r0
    //     0x68672c: stur            w0, [x1, #7]
    // 0x686730: ldur            x4, [fp, #-0x20]
    // 0x686734: StoreField: r1->field_b = r4
    //     0x686734: stur            w4, [x1, #0xb]
    // 0x686738: ldur            x2, [fp, #-8]
    // 0x68673c: StoreField: r1->field_f = r2
    //     0x68673c: stur            w2, [x1, #0xf]
    // 0x686740: StoreField: r1->field_13 = r0
    //     0x686740: stur            w0, [x1, #0x13]
    // 0x686744: mov             x3, x1
    // 0x686748: ldur            x1, [fp, #-0x18]
    // 0x68674c: r2 = Instance_Chapter11Stat
    //     0x68674c: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x686750: ldr             x2, [x2, #0x5b0]
    // 0x686754: r0 = []=()
    //     0x686754: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686758: ldur            x0, [fp, #-0x10]
    // 0x68675c: LoadField: r3 = r0->field_43
    //     0x68675c: ldur            w3, [x0, #0x43]
    // 0x686760: DecompressPointer r3
    //     0x686760: add             x3, x3, HEAP, lsl #32
    // 0x686764: mov             x1, x3
    // 0x686768: stur            x3, [fp, #-8]
    // 0x68676c: r2 = 26
    //     0x68676c: movz            x2, #0x1a
    // 0x686770: r0 = _getValueOrData()
    //     0x686770: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x686774: mov             x1, x0
    // 0x686778: ldur            x0, [fp, #-8]
    // 0x68677c: LoadField: r2 = r0->field_f
    //     0x68677c: ldur            w2, [x0, #0xf]
    // 0x686780: DecompressPointer r2
    //     0x686780: add             x2, x2, HEAP, lsl #32
    // 0x686784: cmp             w2, w1
    // 0x686788: b.ne            #0x686794
    // 0x68678c: r0 = Null
    //     0x68678c: mov             x0, NULL
    // 0x686790: b               #0x686798
    // 0x686794: mov             x0, x1
    // 0x686798: cmp             w0, NULL
    // 0x68679c: b.ne            #0x6867a8
    // 0x6867a0: r2 = 0
    //     0x6867a0: movz            x2, #0
    // 0x6867a4: b               #0x6867b8
    // 0x6867a8: r1 = LoadInt32Instr(r0)
    //     0x6867a8: sbfx            x1, x0, #1, #0x1f
    //     0x6867ac: tbz             w0, #0, #0x6867b4
    //     0x6867b0: ldur            x1, [x0, #7]
    // 0x6867b4: mov             x2, x1
    // 0x6867b8: ldur            x3, [fp, #-0x20]
    // 0x6867bc: r0 = BoxInt64Instr(r2)
    //     0x6867bc: sbfiz           x0, x2, #1, #0x1f
    //     0x6867c0: cmp             x2, x0, asr #1
    //     0x6867c4: b.eq            #0x6867d0
    //     0x6867c8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6867cc: stur            x2, [x0, #7]
    // 0x6867d0: mov             x2, x0
    // 0x6867d4: r1 = Instance_CustomNum
    //     0x6867d4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x6867d8: ldr             x1, [x1, #0x970]
    // 0x6867dc: r0 = pow()
    //     0x6867dc: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6867e0: stur            x0, [fp, #-8]
    // 0x6867e4: r0 = Boost()
    //     0x6867e4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x6867e8: mov             x1, x0
    // 0x6867ec: r0 = Instance_CustomNum
    //     0x6867ec: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6867f0: ldr             x0, [x0, #0xa70]
    // 0x6867f4: StoreField: r1->field_7 = r0
    //     0x6867f4: stur            w0, [x1, #7]
    // 0x6867f8: ldur            x4, [fp, #-0x20]
    // 0x6867fc: StoreField: r1->field_b = r4
    //     0x6867fc: stur            w4, [x1, #0xb]
    // 0x686800: ldur            x2, [fp, #-8]
    // 0x686804: StoreField: r1->field_f = r2
    //     0x686804: stur            w2, [x1, #0xf]
    // 0x686808: StoreField: r1->field_13 = r0
    //     0x686808: stur            w0, [x1, #0x13]
    // 0x68680c: mov             x3, x1
    // 0x686810: ldur            x1, [fp, #-0x18]
    // 0x686814: r2 = Instance_Chapter11Stat
    //     0x686814: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x686818: ldr             x2, [x2, #0x5d0]
    // 0x68681c: r0 = []=()
    //     0x68681c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686820: r0 = Boost()
    //     0x686820: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686824: mov             x1, x0
    // 0x686828: r0 = Instance_CustomNum
    //     0x686828: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68682c: ldr             x0, [x0, #0xa70]
    // 0x686830: StoreField: r1->field_7 = r0
    //     0x686830: stur            w0, [x1, #7]
    // 0x686834: ldur            x4, [fp, #-0x20]
    // 0x686838: StoreField: r1->field_b = r4
    //     0x686838: stur            w4, [x1, #0xb]
    // 0x68683c: StoreField: r1->field_f = r0
    //     0x68683c: stur            w0, [x1, #0xf]
    // 0x686840: StoreField: r1->field_13 = r0
    //     0x686840: stur            w0, [x1, #0x13]
    // 0x686844: mov             x3, x1
    // 0x686848: ldur            x1, [fp, #-0x18]
    // 0x68684c: r2 = Instance_Chapter11Stat
    //     0x68684c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11570] Obj!Chapter11Stat@85fda1
    //     0x686850: ldr             x2, [x2, #0x570]
    // 0x686854: r0 = []=()
    //     0x686854: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686858: r0 = Boost()
    //     0x686858: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68685c: mov             x1, x0
    // 0x686860: r0 = Instance_CustomNum
    //     0x686860: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x686864: ldr             x0, [x0, #0xa70]
    // 0x686868: StoreField: r1->field_7 = r0
    //     0x686868: stur            w0, [x1, #7]
    // 0x68686c: ldur            x4, [fp, #-0x20]
    // 0x686870: StoreField: r1->field_b = r4
    //     0x686870: stur            w4, [x1, #0xb]
    // 0x686874: StoreField: r1->field_f = r0
    //     0x686874: stur            w0, [x1, #0xf]
    // 0x686878: StoreField: r1->field_13 = r0
    //     0x686878: stur            w0, [x1, #0x13]
    // 0x68687c: mov             x3, x1
    // 0x686880: ldur            x1, [fp, #-0x18]
    // 0x686884: r2 = Instance_Chapter11Stat
    //     0x686884: add             x2, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Chapter11Stat@85fdc1
    //     0x686888: ldr             x2, [x2, #0x568]
    // 0x68688c: r0 = []=()
    //     0x68688c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x686890: r0 = Boost()
    //     0x686890: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x686894: mov             x1, x0
    // 0x686898: r0 = Instance_CustomNum
    //     0x686898: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68689c: ldr             x0, [x0, #0xa70]
    // 0x6868a0: StoreField: r1->field_7 = r0
    //     0x6868a0: stur            w0, [x1, #7]
    // 0x6868a4: ldur            x2, [fp, #-0x20]
    // 0x6868a8: StoreField: r1->field_b = r2
    //     0x6868a8: stur            w2, [x1, #0xb]
    // 0x6868ac: StoreField: r1->field_f = r0
    //     0x6868ac: stur            w0, [x1, #0xf]
    // 0x6868b0: StoreField: r1->field_13 = r0
    //     0x6868b0: stur            w0, [x1, #0x13]
    // 0x6868b4: mov             x3, x1
    // 0x6868b8: ldur            x1, [fp, #-0x18]
    // 0x6868bc: r2 = Instance_Chapter11Stat
    //     0x6868bc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11560] Obj!Chapter11Stat@85fde1
    //     0x6868c0: ldr             x2, [x2, #0x560]
    // 0x6868c4: r0 = []=()
    //     0x6868c4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6868c8: r0 = Null
    //     0x6868c8: mov             x0, NULL
    // 0x6868cc: LeaveFrame
    //     0x6868cc: mov             SP, fp
    //     0x6868d0: ldp             fp, lr, [SP], #0x10
    // 0x6868d4: ret
    //     0x6868d4: ret             
    // 0x6868d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6868d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6868dc: b               #0x6861e0
  }
  _ build(/* No info */) {
    // ** addr: 0x6969d0, size: 0x150c
    // 0x6969d0: EnterFrame
    //     0x6969d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6969d4: mov             fp, SP
    // 0x6969d8: AllocStack(0xb8)
    //     0x6969d8: sub             SP, SP, #0xb8
    // 0x6969dc: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x6969dc: mov             x0, x1
    //     0x6969e0: stur            x1, [fp, #-8]
    //     0x6969e4: stur            x2, [fp, #-0x10]
    // 0x6969e8: CheckStackOverflow
    //     0x6969e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6969ec: cmp             SP, x16
    //     0x6969f0: b.ls            #0x697ec8
    // 0x6969f4: r1 = 2
    //     0x6969f4: movz            x1, #0x2
    // 0x6969f8: r0 = AllocateContext()
    //     0x6969f8: bl              #0x82637c  ; AllocateContextStub
    // 0x6969fc: ldur            x2, [fp, #-8]
    // 0x696a00: stur            x0, [fp, #-0x58]
    // 0x696a04: StoreField: r0->field_f = r2
    //     0x696a04: stur            w2, [x0, #0xf]
    // 0x696a08: ldur            x1, [fp, #-0x10]
    // 0x696a0c: StoreField: r0->field_13 = r1
    //     0x696a0c: stur            w1, [x0, #0x13]
    // 0x696a10: LoadField: r3 = r2->field_2b
    //     0x696a10: ldur            w3, [x2, #0x2b]
    // 0x696a14: DecompressPointer r3
    //     0x696a14: add             x3, x3, HEAP, lsl #32
    // 0x696a18: stur            x3, [fp, #-0x50]
    // 0x696a1c: LoadField: r4 = r2->field_37
    //     0x696a1c: ldur            w4, [x2, #0x37]
    // 0x696a20: DecompressPointer r4
    //     0x696a20: add             x4, x4, HEAP, lsl #32
    // 0x696a24: stur            x4, [fp, #-0x48]
    // 0x696a28: LoadField: r5 = r2->field_7
    //     0x696a28: ldur            w5, [x2, #7]
    // 0x696a2c: DecompressPointer r5
    //     0x696a2c: add             x5, x5, HEAP, lsl #32
    // 0x696a30: stur            x5, [fp, #-0x40]
    // 0x696a34: LoadField: r6 = r2->field_4b
    //     0x696a34: ldur            w6, [x2, #0x4b]
    // 0x696a38: DecompressPointer r6
    //     0x696a38: add             x6, x6, HEAP, lsl #32
    // 0x696a3c: stur            x6, [fp, #-0x38]
    // 0x696a40: LoadField: r7 = r2->field_47
    //     0x696a40: ldur            w7, [x2, #0x47]
    // 0x696a44: DecompressPointer r7
    //     0x696a44: add             x7, x7, HEAP, lsl #32
    // 0x696a48: stur            x7, [fp, #-0x30]
    // 0x696a4c: LoadField: r8 = r2->field_53
    //     0x696a4c: ldur            w8, [x2, #0x53]
    // 0x696a50: DecompressPointer r8
    //     0x696a50: add             x8, x8, HEAP, lsl #32
    // 0x696a54: stur            x8, [fp, #-0x28]
    // 0x696a58: LoadField: r9 = r2->field_33
    //     0x696a58: ldur            w9, [x2, #0x33]
    // 0x696a5c: DecompressPointer r9
    //     0x696a5c: add             x9, x9, HEAP, lsl #32
    // 0x696a60: stur            x9, [fp, #-0x20]
    // 0x696a64: LoadField: r10 = r2->field_2f
    //     0x696a64: ldur            w10, [x2, #0x2f]
    // 0x696a68: DecompressPointer r10
    //     0x696a68: add             x10, x10, HEAP, lsl #32
    // 0x696a6c: stur            x10, [fp, #-0x18]
    // 0x696a70: LoadField: r11 = r2->field_93
    //     0x696a70: ldur            w11, [x2, #0x93]
    // 0x696a74: DecompressPointer r11
    //     0x696a74: add             x11, x11, HEAP, lsl #32
    // 0x696a78: stur            x11, [fp, #-0x10]
    // 0x696a7c: r1 = <Chapter11Stat>
    //     0x696a7c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x696a80: ldr             x1, [x1, #0xeb8]
    // 0x696a84: r0 = GeneratorGroup()
    //     0x696a84: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x696a88: mov             x3, x0
    // 0x696a8c: ldur            x0, [fp, #-0x48]
    // 0x696a90: stur            x3, [fp, #-0x60]
    // 0x696a94: StoreField: r3->field_1f = r0
    //     0x696a94: stur            w0, [x3, #0x1f]
    // 0x696a98: ldur            x2, [fp, #-8]
    // 0x696a9c: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x696a9c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb48] AnonymousClosure: (0x3da664), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::getCostToBuyOneMoreGenerator (0x3da3d8)
    //     0x696aa0: ldr             x1, [x1, #0xb48]
    // 0x696aa4: r0 = AllocateClosure()
    //     0x696aa4: bl              #0x826750  ; AllocateClosureStub
    // 0x696aa8: mov             x3, x0
    // 0x696aac: ldur            x0, [fp, #-0x60]
    // 0x696ab0: stur            x3, [fp, #-0x48]
    // 0x696ab4: StoreField: r0->field_23 = r3
    //     0x696ab4: stur            w3, [x0, #0x23]
    // 0x696ab8: ldur            x2, [fp, #-8]
    // 0x696abc: r1 = Function 'getGeneratorInfo':.
    //     0x696abc: add             x1, PP, #0x29, lsl #12  ; [pp+0x291c8] AnonymousClosure: (0x699bc4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::getGeneratorInfo (0x80d194)
    //     0x696ac0: ldr             x1, [x1, #0x1c8]
    // 0x696ac4: r0 = AllocateClosure()
    //     0x696ac4: bl              #0x826750  ; AllocateClosureStub
    // 0x696ac8: mov             x3, x0
    // 0x696acc: ldur            x0, [fp, #-0x60]
    // 0x696ad0: stur            x3, [fp, #-0x68]
    // 0x696ad4: StoreField: r0->field_27 = r3
    //     0x696ad4: stur            w3, [x0, #0x27]
    // 0x696ad8: ldur            x1, [fp, #-0x38]
    // 0x696adc: StoreField: r0->field_2b = r1
    //     0x696adc: stur            w1, [x0, #0x2b]
    // 0x696ae0: ldur            x1, [fp, #-0x30]
    // 0x696ae4: StoreField: r0->field_2f = r1
    //     0x696ae4: stur            w1, [x0, #0x2f]
    // 0x696ae8: ldur            x1, [fp, #-0x28]
    // 0x696aec: StoreField: r0->field_33 = r1
    //     0x696aec: stur            w1, [x0, #0x33]
    // 0x696af0: r1 = Function '<anonymous closure>':.
    //     0x696af0: add             x1, PP, #0x29, lsl #12  ; [pp+0x291d0] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x696af4: ldr             x1, [x1, #0x1d0]
    // 0x696af8: r2 = Null
    //     0x696af8: mov             x2, NULL
    // 0x696afc: r0 = AllocateClosure()
    //     0x696afc: bl              #0x826750  ; AllocateClosureStub
    // 0x696b00: mov             x1, x0
    // 0x696b04: ldur            x0, [fp, #-0x60]
    // 0x696b08: StoreField: r0->field_3b = r1
    //     0x696b08: stur            w1, [x0, #0x3b]
    // 0x696b0c: ldur            x3, [fp, #-0x20]
    // 0x696b10: StoreField: r0->field_43 = r3
    //     0x696b10: stur            w3, [x0, #0x43]
    // 0x696b14: ldur            x4, [fp, #-0x18]
    // 0x696b18: StoreField: r0->field_47 = r4
    //     0x696b18: stur            w4, [x0, #0x47]
    // 0x696b1c: ldur            x2, [fp, #-0x58]
    // 0x696b20: r1 = Function '<anonymous closure>':.
    //     0x696b20: add             x1, PP, #0x29, lsl #12  ; [pp+0x291d8] AnonymousClosure: (0x6999f4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696b24: ldr             x1, [x1, #0x1d8]
    // 0x696b28: r0 = AllocateClosure()
    //     0x696b28: bl              #0x826750  ; AllocateClosureStub
    // 0x696b2c: mov             x1, x0
    // 0x696b30: ldur            x0, [fp, #-0x60]
    // 0x696b34: StoreField: r0->field_4f = r1
    //     0x696b34: stur            w1, [x0, #0x4f]
    // 0x696b38: ldur            x2, [fp, #-8]
    // 0x696b3c: r1 = Function 'buyGenerator':.
    //     0x696b3c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x696b40: ldr             x1, [x1, #0x108]
    // 0x696b44: r0 = AllocateClosure()
    //     0x696b44: bl              #0x826750  ; AllocateClosureStub
    // 0x696b48: mov             x3, x0
    // 0x696b4c: ldur            x0, [fp, #-0x60]
    // 0x696b50: stur            x3, [fp, #-0x28]
    // 0x696b54: StoreField: r0->field_5b = r3
    //     0x696b54: stur            w3, [x0, #0x5b]
    // 0x696b58: r1 = Function '<anonymous closure>':.
    //     0x696b58: add             x1, PP, #0x29, lsl #12  ; [pp+0x291e0] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x696b5c: ldr             x1, [x1, #0x1e0]
    // 0x696b60: r2 = Null
    //     0x696b60: mov             x2, NULL
    // 0x696b64: r0 = AllocateClosure()
    //     0x696b64: bl              #0x826750  ; AllocateClosureStub
    // 0x696b68: mov             x1, x0
    // 0x696b6c: ldur            x0, [fp, #-0x60]
    // 0x696b70: ArrayStore: r0[0] = r1  ; List_4
    //     0x696b70: stur            w1, [x0, #0x17]
    // 0x696b74: r1 = Function '<anonymous closure>':.
    //     0x696b74: add             x1, PP, #0x29, lsl #12  ; [pp+0x291e8] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x696b78: ldr             x1, [x1, #0x1e8]
    // 0x696b7c: r2 = Null
    //     0x696b7c: mov             x2, NULL
    // 0x696b80: r0 = AllocateClosure()
    //     0x696b80: bl              #0x826750  ; AllocateClosureStub
    // 0x696b84: mov             x1, x0
    // 0x696b88: ldur            x0, [fp, #-0x60]
    // 0x696b8c: StoreField: r0->field_1b = r1
    //     0x696b8c: stur            w1, [x0, #0x1b]
    // 0x696b90: ldur            x2, [fp, #-8]
    // 0x696b94: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x696b94: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x696b98: ldr             x1, [x1, #0x120]
    // 0x696b9c: r0 = AllocateClosure()
    //     0x696b9c: bl              #0x826750  ; AllocateClosureStub
    // 0x696ba0: mov             x4, x0
    // 0x696ba4: ldur            x0, [fp, #-0x60]
    // 0x696ba8: stur            x4, [fp, #-0x30]
    // 0x696bac: StoreField: r0->field_57 = r4
    //     0x696bac: stur            w4, [x0, #0x57]
    // 0x696bb0: r1 = const [0x1]
    //     0x696bb0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28be8] List<int>(1)
    //     0x696bb4: ldr             x1, [x1, #0xbe8]
    // 0x696bb8: StoreField: r0->field_53 = r1
    //     0x696bb8: stur            w1, [x0, #0x53]
    // 0x696bbc: ldur            x2, [fp, #-8]
    // 0x696bc0: ldur            x3, [fp, #-0x40]
    // 0x696bc4: r1 = Function 'getGeneratorSingleYieldsBoosted':.
    //     0x696bc4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0x54a720), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted (0x54a520)
    //     0x696bc8: ldr             x1, [x1, #0x130]
    // 0x696bcc: r0 = AllocateClosureTA()
    //     0x696bcc: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x696bd0: mov             x4, x0
    // 0x696bd4: ldur            x0, [fp, #-0x60]
    // 0x696bd8: stur            x4, [fp, #-0x38]
    // 0x696bdc: StoreField: r0->field_6b = r4
    //     0x696bdc: stur            w4, [x0, #0x6b]
    // 0x696be0: ldur            x1, [fp, #-0x50]
    // 0x696be4: StoreField: r0->field_4b = r1
    //     0x696be4: stur            w1, [x0, #0x4b]
    // 0x696be8: ldur            x1, [fp, #-0x10]
    // 0x696bec: StoreField: r0->field_67 = r1
    //     0x696bec: stur            w1, [x0, #0x67]
    // 0x696bf0: ldur            x2, [fp, #-8]
    // 0x696bf4: ldur            x3, [fp, #-0x40]
    // 0x696bf8: r1 = Function 'getGeneratorBaseCost':.
    //     0x696bf8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x696bfc: ldr             x1, [x1, #0x138]
    // 0x696c00: r0 = AllocateClosureTA()
    //     0x696c00: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x696c04: mov             x3, x0
    // 0x696c08: ldur            x0, [fp, #-0x60]
    // 0x696c0c: stur            x3, [fp, #-0x10]
    // 0x696c10: StoreField: r0->field_77 = r3
    //     0x696c10: stur            w3, [x0, #0x77]
    // 0x696c14: ldur            x2, [fp, #-8]
    // 0x696c18: r1 = Function 'getGeneratorMultiplier':.
    //     0x696c18: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x696c1c: ldr             x1, [x1, #0x140]
    // 0x696c20: r0 = AllocateClosure()
    //     0x696c20: bl              #0x826750  ; AllocateClosureStub
    // 0x696c24: mov             x3, x0
    // 0x696c28: ldur            x0, [fp, #-0x60]
    // 0x696c2c: stur            x3, [fp, #-0x40]
    // 0x696c30: StoreField: r0->field_7b = r3
    //     0x696c30: stur            w3, [x0, #0x7b]
    // 0x696c34: r4 = "Chapter 11 Generators 1"
    //     0x696c34: add             x4, PP, #0x29, lsl #12  ; [pp+0x291f0] "Chapter 11 Generators 1"
    //     0x696c38: ldr             x4, [x4, #0x1f0]
    // 0x696c3c: StoreField: r0->field_73 = r4
    //     0x696c3c: stur            w4, [x0, #0x73]
    // 0x696c40: r1 = Function '<anonymous closure>':.
    //     0x696c40: add             x1, PP, #0x29, lsl #12  ; [pp+0x291f8] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x696c44: ldr             x1, [x1, #0x1f8]
    // 0x696c48: r2 = Null
    //     0x696c48: mov             x2, NULL
    // 0x696c4c: r0 = AllocateClosure()
    //     0x696c4c: bl              #0x826750  ; AllocateClosureStub
    // 0x696c50: ldur            x2, [fp, #-0x60]
    // 0x696c54: mov             x5, x0
    // 0x696c58: r1 = Null
    //     0x696c58: mov             x1, NULL
    // 0x696c5c: r3 = "Chapter 11 Generators 1"
    //     0x696c5c: add             x3, PP, #0x29, lsl #12  ; [pp+0x291f0] "Chapter 11 Generators 1"
    //     0x696c60: ldr             x3, [x3, #0x1f0]
    // 0x696c64: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x696c64: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x696c68: r0 = IdleFragment()
    //     0x696c68: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x696c6c: r1 = <Widget>
    //     0x696c6c: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x696c70: r2 = 26
    //     0x696c70: movz            x2, #0x1a
    // 0x696c74: stur            x0, [fp, #-0x50]
    // 0x696c78: r0 = AllocateArray()
    //     0x696c78: bl              #0x82746c  ; AllocateArrayStub
    // 0x696c7c: mov             x2, x0
    // 0x696c80: ldur            x0, [fp, #-0x50]
    // 0x696c84: stur            x2, [fp, #-0x78]
    // 0x696c88: StoreField: r2->field_f = r0
    //     0x696c88: stur            w0, [x2, #0xf]
    // 0x696c8c: ldur            x0, [fp, #-8]
    // 0x696c90: LoadField: r3 = r0->field_37
    //     0x696c90: ldur            w3, [x0, #0x37]
    // 0x696c94: DecompressPointer r3
    //     0x696c94: add             x3, x3, HEAP, lsl #32
    // 0x696c98: stur            x3, [fp, #-0x70]
    // 0x696c9c: LoadField: r4 = r0->field_43
    //     0x696c9c: ldur            w4, [x0, #0x43]
    // 0x696ca0: DecompressPointer r4
    //     0x696ca0: add             x4, x4, HEAP, lsl #32
    // 0x696ca4: stur            x4, [fp, #-0x60]
    // 0x696ca8: LoadField: r5 = r0->field_8f
    //     0x696ca8: ldur            w5, [x0, #0x8f]
    // 0x696cac: DecompressPointer r5
    //     0x696cac: add             x5, x5, HEAP, lsl #32
    // 0x696cb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x696cb4: cmp             w5, w16
    // 0x696cb8: b.eq            #0x697ed0
    // 0x696cbc: stur            x5, [fp, #-0x50]
    // 0x696cc0: r1 = <Chapter11Stat>
    //     0x696cc0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x696cc4: ldr             x1, [x1, #0xeb8]
    // 0x696cc8: r0 = UpgradeGroup()
    //     0x696cc8: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x696ccc: mov             x3, x0
    // 0x696cd0: r0 = 1
    //     0x696cd0: movz            x0, #0x1
    // 0x696cd4: stur            x3, [fp, #-0x80]
    // 0x696cd8: StoreField: r3->field_13 = r0
    //     0x696cd8: stur            x0, [x3, #0x13]
    // 0x696cdc: ldur            x1, [fp, #-0x50]
    // 0x696ce0: StoreField: r3->field_1b = r1
    //     0x696ce0: stur            w1, [x3, #0x1b]
    // 0x696ce4: ldur            x1, [fp, #-0x70]
    // 0x696ce8: StoreField: r3->field_1f = r1
    //     0x696ce8: stur            w1, [x3, #0x1f]
    // 0x696cec: ldur            x1, [fp, #-0x60]
    // 0x696cf0: StoreField: r3->field_23 = r1
    //     0x696cf0: stur            w1, [x3, #0x23]
    // 0x696cf4: r1 = Function '<anonymous closure>':.
    //     0x696cf4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29200] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x696cf8: ldr             x1, [x1, #0x200]
    // 0x696cfc: r2 = Null
    //     0x696cfc: mov             x2, NULL
    // 0x696d00: r0 = AllocateClosure()
    //     0x696d00: bl              #0x826750  ; AllocateClosureStub
    // 0x696d04: mov             x1, x0
    // 0x696d08: ldur            x0, [fp, #-0x80]
    // 0x696d0c: StoreField: r0->field_2b = r1
    //     0x696d0c: stur            w1, [x0, #0x2b]
    // 0x696d10: r1 = const [0x1, 0x2, 0x3]
    //     0x696d10: add             x1, PP, #0x26, lsl #12  ; [pp+0x268e0] List<int>(3)
    //     0x696d14: ldr             x1, [x1, #0x8e0]
    // 0x696d18: StoreField: r0->field_f = r1
    //     0x696d18: stur            w1, [x0, #0xf]
    // 0x696d1c: r3 = true
    //     0x696d1c: add             x3, NULL, #0x20  ; true
    // 0x696d20: StoreField: r0->field_27 = r3
    //     0x696d20: stur            w3, [x0, #0x27]
    // 0x696d24: r1 = Instance_UpgradeDisplayMode
    //     0x696d24: add             x1, PP, #0x26, lsl #12  ; [pp+0x26300] Obj!UpgradeDisplayMode@85e861
    //     0x696d28: ldr             x1, [x1, #0x300]
    // 0x696d2c: StoreField: r0->field_2f = r1
    //     0x696d2c: stur            w1, [x0, #0x2f]
    // 0x696d30: r4 = false
    //     0x696d30: add             x4, NULL, #0x30  ; false
    // 0x696d34: StoreField: r0->field_33 = r4
    //     0x696d34: stur            w4, [x0, #0x33]
    // 0x696d38: ldur            x2, [fp, #-0x58]
    // 0x696d3c: r1 = Function '<anonymous closure>':.
    //     0x696d3c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29208] AnonymousClosure: (0x6999a8), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x696d40: ldr             x1, [x1, #0x208]
    // 0x696d44: r0 = AllocateClosure()
    //     0x696d44: bl              #0x826750  ; AllocateClosureStub
    // 0x696d48: ldur            x2, [fp, #-0x80]
    // 0x696d4c: mov             x5, x0
    // 0x696d50: r1 = Null
    //     0x696d50: mov             x1, NULL
    // 0x696d54: r3 = "Chapter 11 Upgrades 1"
    //     0x696d54: add             x3, PP, #0x29, lsl #12  ; [pp+0x29210] "Chapter 11 Upgrades 1"
    //     0x696d58: ldr             x3, [x3, #0x210]
    // 0x696d5c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x696d5c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x696d60: r0 = IdleFragment()
    //     0x696d60: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x696d64: ldur            x1, [fp, #-0x78]
    // 0x696d68: ArrayStore: r1[1] = r0  ; List_4
    //     0x696d68: add             x25, x1, #0x13
    //     0x696d6c: str             w0, [x25]
    //     0x696d70: tbz             w0, #0, #0x696d8c
    //     0x696d74: ldurb           w16, [x1, #-1]
    //     0x696d78: ldurb           w17, [x0, #-1]
    //     0x696d7c: and             x16, x17, x16, lsr #2
    //     0x696d80: tst             x16, HEAP, lsr #32
    //     0x696d84: b.eq            #0x696d8c
    //     0x696d88: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x696d8c: r0 = AutoBuyChip()
    //     0x696d8c: bl              #0x637a20  ; AllocateAutoBuyChipStub -> AutoBuyChip (size=0x18)
    // 0x696d90: mov             x3, x0
    // 0x696d94: r0 = "Auto"
    //     0x696d94: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b8] "Auto"
    //     0x696d98: ldr             x0, [x0, #0x6b8]
    // 0x696d9c: stur            x3, [fp, #-0x50]
    // 0x696da0: StoreField: r3->field_b = r0
    //     0x696da0: stur            w0, [x3, #0xb]
    // 0x696da4: r1 = Function '<anonymous closure>':.
    //     0x696da4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29218] AnonymousClosure: (0x699968), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696da8: ldr             x1, [x1, #0x218]
    // 0x696dac: r2 = Null
    //     0x696dac: mov             x2, NULL
    // 0x696db0: r0 = AllocateClosure()
    //     0x696db0: bl              #0x826750  ; AllocateClosureStub
    // 0x696db4: mov             x1, x0
    // 0x696db8: ldur            x0, [fp, #-0x50]
    // 0x696dbc: StoreField: r0->field_f = r1
    //     0x696dbc: stur            w1, [x0, #0xf]
    // 0x696dc0: r1 = Function '<anonymous closure>':.
    //     0x696dc0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29220] AnonymousClosure: (0x699918), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696dc4: ldr             x1, [x1, #0x220]
    // 0x696dc8: r2 = Null
    //     0x696dc8: mov             x2, NULL
    // 0x696dcc: r0 = AllocateClosure()
    //     0x696dcc: bl              #0x826750  ; AllocateClosureStub
    // 0x696dd0: mov             x1, x0
    // 0x696dd4: ldur            x0, [fp, #-0x50]
    // 0x696dd8: StoreField: r0->field_13 = r1
    //     0x696dd8: stur            w1, [x0, #0x13]
    // 0x696ddc: r0 = Padding()
    //     0x696ddc: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x696de0: mov             x3, x0
    // 0x696de4: r0 = Instance_EdgeInsets
    //     0x696de4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28690] Obj!EdgeInsets@8324f1
    //     0x696de8: ldr             x0, [x0, #0x690]
    // 0x696dec: stur            x3, [fp, #-0x60]
    // 0x696df0: StoreField: r3->field_f = r0
    //     0x696df0: stur            w0, [x3, #0xf]
    // 0x696df4: ldur            x1, [fp, #-0x50]
    // 0x696df8: StoreField: r3->field_b = r1
    //     0x696df8: stur            w1, [x3, #0xb]
    // 0x696dfc: ldur            x2, [fp, #-0x58]
    // 0x696e00: r1 = Function '<anonymous closure>':.
    //     0x696e00: add             x1, PP, #0x29, lsl #12  ; [pp+0x29228] AnonymousClosure: (0x6995a4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696e04: ldr             x1, [x1, #0x228]
    // 0x696e08: r0 = AllocateClosure()
    //     0x696e08: bl              #0x826750  ; AllocateClosureStub
    // 0x696e0c: r16 = false
    //     0x696e0c: add             x16, NULL, #0x30  ; false
    // 0x696e10: r30 = false
    //     0x696e10: add             lr, NULL, #0x30  ; false
    // 0x696e14: stp             lr, x16, [SP, #8]
    // 0x696e18: r16 = false
    //     0x696e18: add             x16, NULL, #0x30  ; false
    // 0x696e1c: str             x16, [SP]
    // 0x696e20: ldur            x2, [fp, #-0x60]
    // 0x696e24: mov             x5, x0
    // 0x696e28: r1 = Null
    //     0x696e28: mov             x1, NULL
    // 0x696e2c: r3 = "auto buy engagement"
    //     0x696e2c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29230] "auto buy engagement"
    //     0x696e30: ldr             x3, [x3, #0x230]
    // 0x696e34: r4 = const [0, 0x7, 0x3, 0x4, drawBackground, 0x4, padding, 0x5, scrollToBottomOnUnlock, 0x6, null]
    //     0x696e34: add             x4, PP, #0x28, lsl #12  ; [pp+0x286a8] List(11) [0, 0x7, 0x3, 0x4, "drawBackground", 0x4, "padding", 0x5, "scrollToBottomOnUnlock", 0x6, Null]
    //     0x696e38: ldr             x4, [x4, #0x6a8]
    // 0x696e3c: r0 = IdleFragment()
    //     0x696e3c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x696e40: stur            x0, [fp, #-0x50]
    // 0x696e44: r0 = CurrencyCounter()
    //     0x696e44: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x696e48: mov             x3, x0
    // 0x696e4c: r0 = "Engagement"
    //     0x696e4c: add             x0, PP, #0x11, lsl #12  ; [pp+0x115b8] "Engagement"
    //     0x696e50: ldr             x0, [x0, #0x5b8]
    // 0x696e54: stur            x3, [fp, #-0x60]
    // 0x696e58: StoreField: r3->field_b = r0
    //     0x696e58: stur            w0, [x3, #0xb]
    // 0x696e5c: ldur            x2, [fp, #-0x58]
    // 0x696e60: r1 = Function '<anonymous closure>':.
    //     0x696e60: add             x1, PP, #0x29, lsl #12  ; [pp+0x29238] AnonymousClosure: (0x699870), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696e64: ldr             x1, [x1, #0x238]
    // 0x696e68: r0 = AllocateClosure()
    //     0x696e68: bl              #0x826750  ; AllocateClosureStub
    // 0x696e6c: mov             x1, x0
    // 0x696e70: ldur            x0, [fp, #-0x60]
    // 0x696e74: StoreField: r0->field_f = r1
    //     0x696e74: stur            w1, [x0, #0xf]
    // 0x696e78: ldur            x2, [fp, #-0x58]
    // 0x696e7c: r1 = Function '<anonymous closure>':.
    //     0x696e7c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29240] AnonymousClosure: (0x6997c0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696e80: ldr             x1, [x1, #0x240]
    // 0x696e84: r0 = AllocateClosure()
    //     0x696e84: bl              #0x826750  ; AllocateClosureStub
    // 0x696e88: mov             x1, x0
    // 0x696e8c: ldur            x0, [fp, #-0x60]
    // 0x696e90: StoreField: r0->field_13 = r1
    //     0x696e90: stur            w1, [x0, #0x13]
    // 0x696e94: r1 = Function '<anonymous closure>':.
    //     0x696e94: add             x1, PP, #0x29, lsl #12  ; [pp+0x29248] AnonymousClosure: (0x6997b4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x696e98: ldr             x1, [x1, #0x248]
    // 0x696e9c: r2 = Null
    //     0x696e9c: mov             x2, NULL
    // 0x696ea0: r0 = AllocateClosure()
    //     0x696ea0: bl              #0x826750  ; AllocateClosureStub
    // 0x696ea4: mov             x1, x0
    // 0x696ea8: ldur            x0, [fp, #-0x60]
    // 0x696eac: ArrayStore: r0[0] = r1  ; List_4
    //     0x696eac: stur            w1, [x0, #0x17]
    // 0x696eb0: ldur            x1, [fp, #-0x50]
    // 0x696eb4: StoreField: r0->field_1b = r1
    //     0x696eb4: stur            w1, [x0, #0x1b]
    // 0x696eb8: r2 = false
    //     0x696eb8: add             x2, NULL, #0x30  ; false
    // 0x696ebc: StoreField: r0->field_1f = r2
    //     0x696ebc: stur            w2, [x0, #0x1f]
    // 0x696ec0: ldur            x3, [fp, #-8]
    // 0x696ec4: LoadField: r4 = r3->field_2b
    //     0x696ec4: ldur            w4, [x3, #0x2b]
    // 0x696ec8: DecompressPointer r4
    //     0x696ec8: add             x4, x4, HEAP, lsl #32
    // 0x696ecc: stur            x4, [fp, #-0x98]
    // 0x696ed0: LoadField: r5 = r3->field_37
    //     0x696ed0: ldur            w5, [x3, #0x37]
    // 0x696ed4: DecompressPointer r5
    //     0x696ed4: add             x5, x5, HEAP, lsl #32
    // 0x696ed8: stur            x5, [fp, #-0x90]
    // 0x696edc: LoadField: r6 = r3->field_4b
    //     0x696edc: ldur            w6, [x3, #0x4b]
    // 0x696ee0: DecompressPointer r6
    //     0x696ee0: add             x6, x6, HEAP, lsl #32
    // 0x696ee4: stur            x6, [fp, #-0x88]
    // 0x696ee8: LoadField: r7 = r3->field_47
    //     0x696ee8: ldur            w7, [x3, #0x47]
    // 0x696eec: DecompressPointer r7
    //     0x696eec: add             x7, x7, HEAP, lsl #32
    // 0x696ef0: stur            x7, [fp, #-0x80]
    // 0x696ef4: LoadField: r8 = r3->field_53
    //     0x696ef4: ldur            w8, [x3, #0x53]
    // 0x696ef8: DecompressPointer r8
    //     0x696ef8: add             x8, x8, HEAP, lsl #32
    // 0x696efc: stur            x8, [fp, #-0x70]
    // 0x696f00: LoadField: r9 = r3->field_93
    //     0x696f00: ldur            w9, [x3, #0x93]
    // 0x696f04: DecompressPointer r9
    //     0x696f04: add             x9, x9, HEAP, lsl #32
    // 0x696f08: stur            x9, [fp, #-0x50]
    // 0x696f0c: r1 = <Chapter11Stat>
    //     0x696f0c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x696f10: ldr             x1, [x1, #0xeb8]
    // 0x696f14: r0 = GeneratorGroup()
    //     0x696f14: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x696f18: mov             x3, x0
    // 0x696f1c: ldur            x0, [fp, #-0x90]
    // 0x696f20: stur            x3, [fp, #-0xa0]
    // 0x696f24: StoreField: r3->field_1f = r0
    //     0x696f24: stur            w0, [x3, #0x1f]
    // 0x696f28: ldur            x0, [fp, #-0x48]
    // 0x696f2c: StoreField: r3->field_23 = r0
    //     0x696f2c: stur            w0, [x3, #0x23]
    // 0x696f30: ldur            x4, [fp, #-0x68]
    // 0x696f34: StoreField: r3->field_27 = r4
    //     0x696f34: stur            w4, [x3, #0x27]
    // 0x696f38: ldur            x1, [fp, #-0x88]
    // 0x696f3c: StoreField: r3->field_2b = r1
    //     0x696f3c: stur            w1, [x3, #0x2b]
    // 0x696f40: ldur            x1, [fp, #-0x80]
    // 0x696f44: StoreField: r3->field_2f = r1
    //     0x696f44: stur            w1, [x3, #0x2f]
    // 0x696f48: ldur            x1, [fp, #-0x70]
    // 0x696f4c: StoreField: r3->field_33 = r1
    //     0x696f4c: stur            w1, [x3, #0x33]
    // 0x696f50: r1 = Function '<anonymous closure>':.
    //     0x696f50: add             x1, PP, #0x29, lsl #12  ; [pp+0x29250] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x696f54: ldr             x1, [x1, #0x250]
    // 0x696f58: r2 = Null
    //     0x696f58: mov             x2, NULL
    // 0x696f5c: r0 = AllocateClosure()
    //     0x696f5c: bl              #0x826750  ; AllocateClosureStub
    // 0x696f60: mov             x1, x0
    // 0x696f64: ldur            x0, [fp, #-0xa0]
    // 0x696f68: StoreField: r0->field_3b = r1
    //     0x696f68: stur            w1, [x0, #0x3b]
    // 0x696f6c: ldur            x3, [fp, #-0x20]
    // 0x696f70: StoreField: r0->field_43 = r3
    //     0x696f70: stur            w3, [x0, #0x43]
    // 0x696f74: ldur            x4, [fp, #-0x18]
    // 0x696f78: StoreField: r0->field_47 = r4
    //     0x696f78: stur            w4, [x0, #0x47]
    // 0x696f7c: ldur            x5, [fp, #-0x28]
    // 0x696f80: StoreField: r0->field_5b = r5
    //     0x696f80: stur            w5, [x0, #0x5b]
    // 0x696f84: r1 = Function '<anonymous closure>':.
    //     0x696f84: add             x1, PP, #0x29, lsl #12  ; [pp+0x29258] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x696f88: ldr             x1, [x1, #0x258]
    // 0x696f8c: r2 = Null
    //     0x696f8c: mov             x2, NULL
    // 0x696f90: r0 = AllocateClosure()
    //     0x696f90: bl              #0x826750  ; AllocateClosureStub
    // 0x696f94: mov             x1, x0
    // 0x696f98: ldur            x0, [fp, #-0xa0]
    // 0x696f9c: ArrayStore: r0[0] = r1  ; List_4
    //     0x696f9c: stur            w1, [x0, #0x17]
    // 0x696fa0: r1 = Function '<anonymous closure>':.
    //     0x696fa0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29260] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x696fa4: ldr             x1, [x1, #0x260]
    // 0x696fa8: r2 = Null
    //     0x696fa8: mov             x2, NULL
    // 0x696fac: r0 = AllocateClosure()
    //     0x696fac: bl              #0x826750  ; AllocateClosureStub
    // 0x696fb0: mov             x1, x0
    // 0x696fb4: ldur            x0, [fp, #-0xa0]
    // 0x696fb8: StoreField: r0->field_1b = r1
    //     0x696fb8: stur            w1, [x0, #0x1b]
    // 0x696fbc: ldur            x3, [fp, #-0x30]
    // 0x696fc0: StoreField: r0->field_57 = r3
    //     0x696fc0: stur            w3, [x0, #0x57]
    // 0x696fc4: r1 = const [0xa, 0xb, 0xc, 0xd, 0xe]
    //     0x696fc4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29268] List<int>(5)
    //     0x696fc8: ldr             x1, [x1, #0x268]
    // 0x696fcc: StoreField: r0->field_53 = r1
    //     0x696fcc: stur            w1, [x0, #0x53]
    // 0x696fd0: ldur            x4, [fp, #-0x38]
    // 0x696fd4: StoreField: r0->field_6b = r4
    //     0x696fd4: stur            w4, [x0, #0x6b]
    // 0x696fd8: ldur            x1, [fp, #-0x98]
    // 0x696fdc: StoreField: r0->field_4b = r1
    //     0x696fdc: stur            w1, [x0, #0x4b]
    // 0x696fe0: ldur            x1, [fp, #-0x60]
    // 0x696fe4: StoreField: r0->field_f = r1
    //     0x696fe4: stur            w1, [x0, #0xf]
    // 0x696fe8: ldur            x1, [fp, #-0x50]
    // 0x696fec: StoreField: r0->field_67 = r1
    //     0x696fec: stur            w1, [x0, #0x67]
    // 0x696ff0: ldur            x5, [fp, #-0x10]
    // 0x696ff4: StoreField: r0->field_77 = r5
    //     0x696ff4: stur            w5, [x0, #0x77]
    // 0x696ff8: ldur            x6, [fp, #-0x40]
    // 0x696ffc: StoreField: r0->field_7b = r6
    //     0x696ffc: stur            w6, [x0, #0x7b]
    // 0x697000: r1 = "Chapter 11 Generators 2"
    //     0x697000: add             x1, PP, #0x29, lsl #12  ; [pp+0x29270] "Chapter 11 Generators 2"
    //     0x697004: ldr             x1, [x1, #0x270]
    // 0x697008: StoreField: r0->field_73 = r1
    //     0x697008: stur            w1, [x0, #0x73]
    // 0x69700c: ldur            x2, [fp, #-0x58]
    // 0x697010: r1 = Function '<anonymous closure>':.
    //     0x697010: add             x1, PP, #0x29, lsl #12  ; [pp+0x29278] AnonymousClosure: (0x699768), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x697014: ldr             x1, [x1, #0x278]
    // 0x697018: r0 = AllocateClosure()
    //     0x697018: bl              #0x826750  ; AllocateClosureStub
    // 0x69701c: ldur            x2, [fp, #-0xa0]
    // 0x697020: mov             x5, x0
    // 0x697024: r1 = Null
    //     0x697024: mov             x1, NULL
    // 0x697028: r3 = "Chapter 11 Generator 2"
    //     0x697028: add             x3, PP, #0x29, lsl #12  ; [pp+0x29280] "Chapter 11 Generator 2"
    //     0x69702c: ldr             x3, [x3, #0x280]
    // 0x697030: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697030: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697034: r0 = IdleFragment()
    //     0x697034: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697038: ldur            x1, [fp, #-0x78]
    // 0x69703c: ArrayStore: r1[2] = r0  ; List_4
    //     0x69703c: add             x25, x1, #0x17
    //     0x697040: str             w0, [x25]
    //     0x697044: tbz             w0, #0, #0x697060
    //     0x697048: ldurb           w16, [x1, #-1]
    //     0x69704c: ldurb           w17, [x0, #-1]
    //     0x697050: and             x16, x17, x16, lsr #2
    //     0x697054: tst             x16, HEAP, lsr #32
    //     0x697058: b.eq            #0x697060
    //     0x69705c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697060: ldur            x0, [fp, #-8]
    // 0x697064: LoadField: r3 = r0->field_37
    //     0x697064: ldur            w3, [x0, #0x37]
    // 0x697068: DecompressPointer r3
    //     0x697068: add             x3, x3, HEAP, lsl #32
    // 0x69706c: stur            x3, [fp, #-0x50]
    // 0x697070: r1 = Function '<anonymous closure>':.
    //     0x697070: add             x1, PP, #0x29, lsl #12  ; [pp+0x29288] AnonymousClosure: (0x69975c), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697074: ldr             x1, [x1, #0x288]
    // 0x697078: r2 = Null
    //     0x697078: mov             x2, NULL
    // 0x69707c: r0 = AllocateClosure()
    //     0x69707c: bl              #0x826750  ; AllocateClosureStub
    // 0x697080: r1 = <Chapter11Stat>
    //     0x697080: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697084: ldr             x1, [x1, #0xeb8]
    // 0x697088: stur            x0, [fp, #-0x60]
    // 0x69708c: r0 = PrestigeButton()
    //     0x69708c: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x697090: mov             x3, x0
    // 0x697094: ldur            x0, [fp, #-0x60]
    // 0x697098: stur            x3, [fp, #-0x70]
    // 0x69709c: StoreField: r3->field_1f = r0
    //     0x69709c: stur            w0, [x3, #0x1f]
    // 0x6970a0: r0 = Instance_Chapter11Stat
    //     0x6970a0: add             x0, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x6970a4: ldr             x0, [x0, #0x5c0]
    // 0x6970a8: StoreField: r3->field_1b = r0
    //     0x6970a8: stur            w0, [x3, #0x1b]
    // 0x6970ac: ldur            x2, [fp, #-8]
    // 0x6970b0: r1 = Function 'silverPrestigePoints':.
    //     0x6970b0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29290] AnonymousClosure: (0x54d9b8), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestigePoints (0x54d7fc)
    //     0x6970b4: ldr             x1, [x1, #0x290]
    // 0x6970b8: r0 = AllocateClosure()
    //     0x6970b8: bl              #0x826750  ; AllocateClosureStub
    // 0x6970bc: mov             x1, x0
    // 0x6970c0: ldur            x0, [fp, #-0x70]
    // 0x6970c4: StoreField: r0->field_2f = r1
    //     0x6970c4: stur            w1, [x0, #0x2f]
    // 0x6970c8: ldur            x2, [fp, #-8]
    // 0x6970cc: r1 = Function 'silverPrestige':.
    //     0x6970cc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x699724), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestige (0x6989a4)
    //     0x6970d0: ldr             x1, [x1, #0x298]
    // 0x6970d4: r0 = AllocateClosure()
    //     0x6970d4: bl              #0x826750  ; AllocateClosureStub
    // 0x6970d8: mov             x3, x0
    // 0x6970dc: ldur            x0, [fp, #-0x70]
    // 0x6970e0: stur            x3, [fp, #-0x60]
    // 0x6970e4: StoreField: r0->field_33 = r3
    //     0x6970e4: stur            w3, [x0, #0x33]
    // 0x6970e8: ldur            x1, [fp, #-0x50]
    // 0x6970ec: ArrayStore: r0[0] = r1  ; List_4
    //     0x6970ec: stur            w1, [x0, #0x17]
    // 0x6970f0: r4 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x6970f0: add             x4, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x6970f4: ldr             x4, [x4, #0x2a0]
    // 0x6970f8: StoreField: r0->field_43 = r4
    //     0x6970f8: stur            w4, [x0, #0x43]
    // 0x6970fc: r1 = Function '<anonymous closure>':.
    //     0x6970fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x292a8] AnonymousClosure: (0x699718), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697100: ldr             x1, [x1, #0x2a8]
    // 0x697104: r2 = Null
    //     0x697104: mov             x2, NULL
    // 0x697108: r0 = AllocateClosure()
    //     0x697108: bl              #0x826750  ; AllocateClosureStub
    // 0x69710c: mov             x1, x0
    // 0x697110: ldur            x0, [fp, #-0x70]
    // 0x697114: StoreField: r0->field_23 = r1
    //     0x697114: stur            w1, [x0, #0x23]
    // 0x697118: r3 = "everything above"
    //     0x697118: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x69711c: ldr             x3, [x3, #0x1b0]
    // 0x697120: StoreField: r0->field_3f = r3
    //     0x697120: stur            w3, [x0, #0x3f]
    // 0x697124: r4 = false
    //     0x697124: add             x4, NULL, #0x30  ; false
    // 0x697128: StoreField: r0->field_f = r4
    //     0x697128: stur            w4, [x0, #0xf]
    // 0x69712c: StoreField: r0->field_4f = r4
    //     0x69712c: stur            w4, [x0, #0x4f]
    // 0x697130: r5 = true
    //     0x697130: add             x5, NULL, #0x20  ; true
    // 0x697134: StoreField: r0->field_2b = r5
    //     0x697134: stur            w5, [x0, #0x2b]
    // 0x697138: StoreField: r0->field_53 = r4
    //     0x697138: stur            w4, [x0, #0x53]
    // 0x69713c: StoreField: r0->field_5b = r5
    //     0x69713c: stur            w5, [x0, #0x5b]
    // 0x697140: r6 = "Gain"
    //     0x697140: add             x6, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x697144: ldr             x6, [x6, #0x1b8]
    // 0x697148: StoreField: r0->field_5f = r6
    //     0x697148: stur            w6, [x0, #0x5f]
    // 0x69714c: ldur            x2, [fp, #-0x58]
    // 0x697150: r1 = Function '<anonymous closure>':.
    //     0x697150: add             x1, PP, #0x29, lsl #12  ; [pp+0x292b0] AnonymousClosure: (0x6996cc), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697154: ldr             x1, [x1, #0x2b0]
    // 0x697158: r0 = AllocateClosure()
    //     0x697158: bl              #0x826750  ; AllocateClosureStub
    // 0x69715c: ldur            x2, [fp, #-0x70]
    // 0x697160: mov             x5, x0
    // 0x697164: r1 = Null
    //     0x697164: mov             x1, NULL
    // 0x697168: r3 = "Chapter 11 Prestige 1"
    //     0x697168: add             x3, PP, #0x29, lsl #12  ; [pp+0x292b8] "Chapter 11 Prestige 1"
    //     0x69716c: ldr             x3, [x3, #0x2b8]
    // 0x697170: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697170: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697174: r0 = IdleFragment()
    //     0x697174: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697178: ldur            x1, [fp, #-0x78]
    // 0x69717c: ArrayStore: r1[3] = r0  ; List_4
    //     0x69717c: add             x25, x1, #0x1b
    //     0x697180: str             w0, [x25]
    //     0x697184: tbz             w0, #0, #0x6971a0
    //     0x697188: ldurb           w16, [x1, #-1]
    //     0x69718c: ldurb           w17, [x0, #-1]
    //     0x697190: and             x16, x17, x16, lsr #2
    //     0x697194: tst             x16, HEAP, lsr #32
    //     0x697198: b.eq            #0x6971a0
    //     0x69719c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6971a0: ldur            x2, [fp, #-8]
    // 0x6971a4: LoadField: r0 = r2->field_37
    //     0x6971a4: ldur            w0, [x2, #0x37]
    // 0x6971a8: DecompressPointer r0
    //     0x6971a8: add             x0, x0, HEAP, lsl #32
    // 0x6971ac: stur            x0, [fp, #-0x70]
    // 0x6971b0: LoadField: r3 = r2->field_3f
    //     0x6971b0: ldur            w3, [x2, #0x3f]
    // 0x6971b4: DecompressPointer r3
    //     0x6971b4: add             x3, x3, HEAP, lsl #32
    // 0x6971b8: stur            x3, [fp, #-0x50]
    // 0x6971bc: r1 = <Chapter11Stat>
    //     0x6971bc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x6971c0: ldr             x1, [x1, #0xeb8]
    // 0x6971c4: r0 = QuestButton()
    //     0x6971c4: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x6971c8: mov             x2, x0
    // 0x6971cc: ldur            x0, [fp, #-0x60]
    // 0x6971d0: stur            x2, [fp, #-0x80]
    // 0x6971d4: StoreField: r2->field_2f = r0
    //     0x6971d4: stur            w0, [x2, #0x2f]
    // 0x6971d8: ldur            x3, [fp, #-0x70]
    // 0x6971dc: StoreField: r2->field_1b = r3
    //     0x6971dc: stur            w3, [x2, #0x1b]
    // 0x6971e0: r1 = Instance_IconData
    //     0x6971e0: add             x1, PP, #0x29, lsl #12  ; [pp+0x292c0] Obj!IconData@8308b1
    //     0x6971e4: ldr             x1, [x1, #0x2c0]
    // 0x6971e8: StoreField: r2->field_1f = r1
    //     0x6971e8: stur            w1, [x2, #0x1f]
    // 0x6971ec: ldur            x4, [fp, #-0x50]
    // 0x6971f0: StoreField: r2->field_2b = r4
    //     0x6971f0: stur            w4, [x2, #0x2b]
    // 0x6971f4: r5 = 1
    //     0x6971f4: movz            x5, #0x1
    // 0x6971f8: StoreField: r2->field_23 = r5
    //     0x6971f8: stur            x5, [x2, #0x23]
    // 0x6971fc: r6 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x6971fc: add             x6, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x697200: ldr             x6, [x6, #0x2a0]
    // 0x697204: StoreField: r2->field_f = r6
    //     0x697204: stur            w6, [x2, #0xf]
    // 0x697208: r1 = const [Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>']
    //     0x697208: add             x1, PP, #0x29, lsl #12  ; [pp+0x292c8] List<QuestLevel<Chapter11Stat>>(5)
    //     0x69720c: ldr             x1, [x1, #0x2c8]
    // 0x697210: StoreField: r2->field_37 = r1
    //     0x697210: stur            w1, [x2, #0x37]
    // 0x697214: r7 = true
    //     0x697214: add             x7, NULL, #0x20  ; true
    // 0x697218: StoreField: r2->field_13 = r7
    //     0x697218: stur            w7, [x2, #0x13]
    // 0x69721c: r1 = <Chapter11Stat>
    //     0x69721c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697220: ldr             x1, [x1, #0xeb8]
    // 0x697224: r0 = QuestButton()
    //     0x697224: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x697228: mov             x3, x0
    // 0x69722c: ldur            x0, [fp, #-0x60]
    // 0x697230: stur            x3, [fp, #-0x88]
    // 0x697234: StoreField: r3->field_2f = r0
    //     0x697234: stur            w0, [x3, #0x2f]
    // 0x697238: ldur            x0, [fp, #-0x70]
    // 0x69723c: StoreField: r3->field_1b = r0
    //     0x69723c: stur            w0, [x3, #0x1b]
    // 0x697240: r0 = Instance_IconData
    //     0x697240: add             x0, PP, #0x29, lsl #12  ; [pp+0x292d0] Obj!IconData@830891
    //     0x697244: ldr             x0, [x0, #0x2d0]
    // 0x697248: StoreField: r3->field_1f = r0
    //     0x697248: stur            w0, [x3, #0x1f]
    // 0x69724c: ldur            x0, [fp, #-0x50]
    // 0x697250: StoreField: r3->field_2b = r0
    //     0x697250: stur            w0, [x3, #0x2b]
    // 0x697254: r0 = 2
    //     0x697254: movz            x0, #0x2
    // 0x697258: StoreField: r3->field_23 = r0
    //     0x697258: stur            x0, [x3, #0x23]
    // 0x69725c: r4 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x69725c: add             x4, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x697260: ldr             x4, [x4, #0x2a0]
    // 0x697264: StoreField: r3->field_f = r4
    //     0x697264: stur            w4, [x3, #0xf]
    // 0x697268: r1 = const [Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>', Instance of 'QuestLevel<Chapter11Stat>']
    //     0x697268: add             x1, PP, #0x29, lsl #12  ; [pp+0x292d8] List<QuestLevel<Chapter11Stat>>(4)
    //     0x69726c: ldr             x1, [x1, #0x2d8]
    // 0x697270: StoreField: r3->field_37 = r1
    //     0x697270: stur            w1, [x3, #0x37]
    // 0x697274: r5 = true
    //     0x697274: add             x5, NULL, #0x20  ; true
    // 0x697278: StoreField: r3->field_13 = r5
    //     0x697278: stur            w5, [x3, #0x13]
    // 0x69727c: r1 = Null
    //     0x69727c: mov             x1, NULL
    // 0x697280: r2 = 4
    //     0x697280: movz            x2, #0x4
    // 0x697284: r0 = AllocateArray()
    //     0x697284: bl              #0x82746c  ; AllocateArrayStub
    // 0x697288: mov             x2, x0
    // 0x69728c: ldur            x0, [fp, #-0x80]
    // 0x697290: stur            x2, [fp, #-0x50]
    // 0x697294: StoreField: r2->field_f = r0
    //     0x697294: stur            w0, [x2, #0xf]
    // 0x697298: ldur            x0, [fp, #-0x88]
    // 0x69729c: StoreField: r2->field_13 = r0
    //     0x69729c: stur            w0, [x2, #0x13]
    // 0x6972a0: r1 = <Widget>
    //     0x6972a0: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6972a4: r0 = AllocateGrowableArray()
    //     0x6972a4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6972a8: mov             x1, x0
    // 0x6972ac: ldur            x0, [fp, #-0x50]
    // 0x6972b0: stur            x1, [fp, #-0x60]
    // 0x6972b4: StoreField: r1->field_f = r0
    //     0x6972b4: stur            w0, [x1, #0xf]
    // 0x6972b8: r0 = 4
    //     0x6972b8: movz            x0, #0x4
    // 0x6972bc: StoreField: r1->field_b = r0
    //     0x6972bc: stur            w0, [x1, #0xb]
    // 0x6972c0: r0 = Column()
    //     0x6972c0: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6972c4: mov             x1, x0
    // 0x6972c8: r0 = Instance_Axis
    //     0x6972c8: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6972cc: stur            x1, [fp, #-0x50]
    // 0x6972d0: StoreField: r1->field_f = r0
    //     0x6972d0: stur            w0, [x1, #0xf]
    // 0x6972d4: r2 = Instance_MainAxisAlignment
    //     0x6972d4: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6972d8: ldr             x2, [x2, #0x200]
    // 0x6972dc: StoreField: r1->field_13 = r2
    //     0x6972dc: stur            w2, [x1, #0x13]
    // 0x6972e0: r3 = Instance_MainAxisSize
    //     0x6972e0: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6972e4: ldr             x3, [x3, #0x70]
    // 0x6972e8: ArrayStore: r1[0] = r3  ; List_4
    //     0x6972e8: stur            w3, [x1, #0x17]
    // 0x6972ec: r4 = Instance_CrossAxisAlignment
    //     0x6972ec: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6972f0: ldr             x4, [x4, #0x78]
    // 0x6972f4: StoreField: r1->field_1b = r4
    //     0x6972f4: stur            w4, [x1, #0x1b]
    // 0x6972f8: r5 = Instance_VerticalDirection
    //     0x6972f8: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6972fc: ldr             x5, [x5, #0x1e8]
    // 0x697300: StoreField: r1->field_23 = r5
    //     0x697300: stur            w5, [x1, #0x23]
    // 0x697304: r6 = Instance_Clip
    //     0x697304: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x697308: ldr             x6, [x6, #0x1b0]
    // 0x69730c: StoreField: r1->field_2b = r6
    //     0x69730c: stur            w6, [x1, #0x2b]
    // 0x697310: StoreField: r1->field_2f = rZR
    //     0x697310: stur            xzr, [x1, #0x2f]
    // 0x697314: ldur            x7, [fp, #-0x60]
    // 0x697318: StoreField: r1->field_b = r7
    //     0x697318: stur            w7, [x1, #0xb]
    // 0x69731c: r0 = Padding()
    //     0x69731c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x697320: mov             x3, x0
    // 0x697324: r0 = Instance_EdgeInsets
    //     0x697324: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a08] Obj!EdgeInsets@831da1
    //     0x697328: ldr             x0, [x0, #0xa08]
    // 0x69732c: stur            x3, [fp, #-0x60]
    // 0x697330: StoreField: r3->field_f = r0
    //     0x697330: stur            w0, [x3, #0xf]
    // 0x697334: ldur            x0, [fp, #-0x50]
    // 0x697338: StoreField: r3->field_b = r0
    //     0x697338: stur            w0, [x3, #0xb]
    // 0x69733c: ldur            x2, [fp, #-0x58]
    // 0x697340: r1 = Function '<anonymous closure>':.
    //     0x697340: add             x1, PP, #0x29, lsl #12  ; [pp+0x292e0] AnonymousClosure: (0x699680), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x697344: ldr             x1, [x1, #0x2e0]
    // 0x697348: r0 = AllocateClosure()
    //     0x697348: bl              #0x826750  ; AllocateClosureStub
    // 0x69734c: ldur            x2, [fp, #-0x60]
    // 0x697350: mov             x5, x0
    // 0x697354: r1 = Null
    //     0x697354: mov             x1, NULL
    // 0x697358: r3 = "Chapter 11 Quests 1"
    //     0x697358: add             x3, PP, #0x29, lsl #12  ; [pp+0x292e8] "Chapter 11 Quests 1"
    //     0x69735c: ldr             x3, [x3, #0x2e8]
    // 0x697360: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697360: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697364: r0 = IdleFragment()
    //     0x697364: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697368: ldur            x1, [fp, #-0x78]
    // 0x69736c: ArrayStore: r1[4] = r0  ; List_4
    //     0x69736c: add             x25, x1, #0x1f
    //     0x697370: str             w0, [x25]
    //     0x697374: tbz             w0, #0, #0x697390
    //     0x697378: ldurb           w16, [x1, #-1]
    //     0x69737c: ldurb           w17, [x0, #-1]
    //     0x697380: and             x16, x17, x16, lsr #2
    //     0x697384: tst             x16, HEAP, lsr #32
    //     0x697388: b.eq            #0x697390
    //     0x69738c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697390: r0 = AutoBuyChip()
    //     0x697390: bl              #0x637a20  ; AllocateAutoBuyChipStub -> AutoBuyChip (size=0x18)
    // 0x697394: mov             x3, x0
    // 0x697398: r0 = "Auto"
    //     0x697398: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b8] "Auto"
    //     0x69739c: ldr             x0, [x0, #0x6b8]
    // 0x6973a0: stur            x3, [fp, #-0x50]
    // 0x6973a4: StoreField: r3->field_b = r0
    //     0x6973a4: stur            w0, [x3, #0xb]
    // 0x6973a8: r1 = Function '<anonymous closure>':.
    //     0x6973a8: add             x1, PP, #0x29, lsl #12  ; [pp+0x292f0] AnonymousClosure: (0x699640), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x6973ac: ldr             x1, [x1, #0x2f0]
    // 0x6973b0: r2 = Null
    //     0x6973b0: mov             x2, NULL
    // 0x6973b4: r0 = AllocateClosure()
    //     0x6973b4: bl              #0x826750  ; AllocateClosureStub
    // 0x6973b8: mov             x1, x0
    // 0x6973bc: ldur            x0, [fp, #-0x50]
    // 0x6973c0: StoreField: r0->field_f = r1
    //     0x6973c0: stur            w1, [x0, #0xf]
    // 0x6973c4: r1 = Function '<anonymous closure>':.
    //     0x6973c4: add             x1, PP, #0x29, lsl #12  ; [pp+0x292f8] AnonymousClosure: (0x6995f0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x6973c8: ldr             x1, [x1, #0x2f8]
    // 0x6973cc: r2 = Null
    //     0x6973cc: mov             x2, NULL
    // 0x6973d0: r0 = AllocateClosure()
    //     0x6973d0: bl              #0x826750  ; AllocateClosureStub
    // 0x6973d4: mov             x1, x0
    // 0x6973d8: ldur            x0, [fp, #-0x50]
    // 0x6973dc: StoreField: r0->field_13 = r1
    //     0x6973dc: stur            w1, [x0, #0x13]
    // 0x6973e0: r0 = Padding()
    //     0x6973e0: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6973e4: mov             x3, x0
    // 0x6973e8: r0 = Instance_EdgeInsets
    //     0x6973e8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28690] Obj!EdgeInsets@8324f1
    //     0x6973ec: ldr             x0, [x0, #0x690]
    // 0x6973f0: stur            x3, [fp, #-0x60]
    // 0x6973f4: StoreField: r3->field_f = r0
    //     0x6973f4: stur            w0, [x3, #0xf]
    // 0x6973f8: ldur            x0, [fp, #-0x50]
    // 0x6973fc: StoreField: r3->field_b = r0
    //     0x6973fc: stur            w0, [x3, #0xb]
    // 0x697400: ldur            x2, [fp, #-0x58]
    // 0x697404: r1 = Function '<anonymous closure>':.
    //     0x697404: add             x1, PP, #0x29, lsl #12  ; [pp+0x29300] AnonymousClosure: (0x6995a4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697408: ldr             x1, [x1, #0x300]
    // 0x69740c: r0 = AllocateClosure()
    //     0x69740c: bl              #0x826750  ; AllocateClosureStub
    // 0x697410: r16 = false
    //     0x697410: add             x16, NULL, #0x30  ; false
    // 0x697414: r30 = false
    //     0x697414: add             lr, NULL, #0x30  ; false
    // 0x697418: stp             lr, x16, [SP, #8]
    // 0x69741c: r16 = false
    //     0x69741c: add             x16, NULL, #0x30  ; false
    // 0x697420: str             x16, [SP]
    // 0x697424: ldur            x2, [fp, #-0x60]
    // 0x697428: mov             x5, x0
    // 0x69742c: r1 = Null
    //     0x69742c: mov             x1, NULL
    // 0x697430: r3 = "auto buy velocity"
    //     0x697430: add             x3, PP, #0x29, lsl #12  ; [pp+0x29308] "auto buy velocity"
    //     0x697434: ldr             x3, [x3, #0x308]
    // 0x697438: r4 = const [0, 0x7, 0x3, 0x4, drawBackground, 0x4, padding, 0x5, scrollToBottomOnUnlock, 0x6, null]
    //     0x697438: add             x4, PP, #0x28, lsl #12  ; [pp+0x286a8] List(11) [0, 0x7, 0x3, 0x4, "drawBackground", 0x4, "padding", 0x5, "scrollToBottomOnUnlock", 0x6, Null]
    //     0x69743c: ldr             x4, [x4, #0x6a8]
    // 0x697440: r0 = IdleFragment()
    //     0x697440: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697444: stur            x0, [fp, #-0x50]
    // 0x697448: r0 = CurrencyCounter()
    //     0x697448: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x69744c: mov             x3, x0
    // 0x697450: r0 = "Velocity"
    //     0x697450: add             x0, PP, #0x11, lsl #12  ; [pp+0x115d8] "Velocity"
    //     0x697454: ldr             x0, [x0, #0x5d8]
    // 0x697458: stur            x3, [fp, #-0x60]
    // 0x69745c: StoreField: r3->field_b = r0
    //     0x69745c: stur            w0, [x3, #0xb]
    // 0x697460: ldur            x2, [fp, #-0x58]
    // 0x697464: r1 = Function '<anonymous closure>':.
    //     0x697464: add             x1, PP, #0x29, lsl #12  ; [pp+0x29310] AnonymousClosure: (0x6994fc), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697468: ldr             x1, [x1, #0x310]
    // 0x69746c: r0 = AllocateClosure()
    //     0x69746c: bl              #0x826750  ; AllocateClosureStub
    // 0x697470: mov             x1, x0
    // 0x697474: ldur            x0, [fp, #-0x60]
    // 0x697478: StoreField: r0->field_f = r1
    //     0x697478: stur            w1, [x0, #0xf]
    // 0x69747c: ldur            x2, [fp, #-0x58]
    // 0x697480: r1 = Function '<anonymous closure>':.
    //     0x697480: add             x1, PP, #0x29, lsl #12  ; [pp+0x29318] AnonymousClosure: (0x699464), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697484: ldr             x1, [x1, #0x318]
    // 0x697488: r0 = AllocateClosure()
    //     0x697488: bl              #0x826750  ; AllocateClosureStub
    // 0x69748c: mov             x1, x0
    // 0x697490: ldur            x0, [fp, #-0x60]
    // 0x697494: StoreField: r0->field_13 = r1
    //     0x697494: stur            w1, [x0, #0x13]
    // 0x697498: r1 = Function '<anonymous closure>':.
    //     0x697498: add             x1, PP, #0x29, lsl #12  ; [pp+0x29320] AnonymousClosure: (0x699458), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x69749c: ldr             x1, [x1, #0x320]
    // 0x6974a0: r2 = Null
    //     0x6974a0: mov             x2, NULL
    // 0x6974a4: r0 = AllocateClosure()
    //     0x6974a4: bl              #0x826750  ; AllocateClosureStub
    // 0x6974a8: mov             x1, x0
    // 0x6974ac: ldur            x0, [fp, #-0x60]
    // 0x6974b0: ArrayStore: r0[0] = r1  ; List_4
    //     0x6974b0: stur            w1, [x0, #0x17]
    // 0x6974b4: ldur            x1, [fp, #-0x50]
    // 0x6974b8: StoreField: r0->field_1b = r1
    //     0x6974b8: stur            w1, [x0, #0x1b]
    // 0x6974bc: r2 = false
    //     0x6974bc: add             x2, NULL, #0x30  ; false
    // 0x6974c0: StoreField: r0->field_1f = r2
    //     0x6974c0: stur            w2, [x0, #0x1f]
    // 0x6974c4: ldur            x3, [fp, #-8]
    // 0x6974c8: LoadField: r4 = r3->field_2b
    //     0x6974c8: ldur            w4, [x3, #0x2b]
    // 0x6974cc: DecompressPointer r4
    //     0x6974cc: add             x4, x4, HEAP, lsl #32
    // 0x6974d0: stur            x4, [fp, #-0x98]
    // 0x6974d4: LoadField: r5 = r3->field_37
    //     0x6974d4: ldur            w5, [x3, #0x37]
    // 0x6974d8: DecompressPointer r5
    //     0x6974d8: add             x5, x5, HEAP, lsl #32
    // 0x6974dc: stur            x5, [fp, #-0x90]
    // 0x6974e0: LoadField: r6 = r3->field_4b
    //     0x6974e0: ldur            w6, [x3, #0x4b]
    // 0x6974e4: DecompressPointer r6
    //     0x6974e4: add             x6, x6, HEAP, lsl #32
    // 0x6974e8: stur            x6, [fp, #-0x88]
    // 0x6974ec: LoadField: r7 = r3->field_47
    //     0x6974ec: ldur            w7, [x3, #0x47]
    // 0x6974f0: DecompressPointer r7
    //     0x6974f0: add             x7, x7, HEAP, lsl #32
    // 0x6974f4: stur            x7, [fp, #-0x80]
    // 0x6974f8: LoadField: r8 = r3->field_53
    //     0x6974f8: ldur            w8, [x3, #0x53]
    // 0x6974fc: DecompressPointer r8
    //     0x6974fc: add             x8, x8, HEAP, lsl #32
    // 0x697500: stur            x8, [fp, #-0x70]
    // 0x697504: LoadField: r9 = r3->field_93
    //     0x697504: ldur            w9, [x3, #0x93]
    // 0x697508: DecompressPointer r9
    //     0x697508: add             x9, x9, HEAP, lsl #32
    // 0x69750c: stur            x9, [fp, #-0x50]
    // 0x697510: r1 = <Chapter11Stat>
    //     0x697510: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697514: ldr             x1, [x1, #0xeb8]
    // 0x697518: r0 = GeneratorGroup()
    //     0x697518: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x69751c: mov             x3, x0
    // 0x697520: ldur            x0, [fp, #-0x90]
    // 0x697524: stur            x3, [fp, #-0xa0]
    // 0x697528: StoreField: r3->field_1f = r0
    //     0x697528: stur            w0, [x3, #0x1f]
    // 0x69752c: ldur            x0, [fp, #-0x48]
    // 0x697530: StoreField: r3->field_23 = r0
    //     0x697530: stur            w0, [x3, #0x23]
    // 0x697534: ldur            x4, [fp, #-0x68]
    // 0x697538: StoreField: r3->field_27 = r4
    //     0x697538: stur            w4, [x3, #0x27]
    // 0x69753c: ldur            x1, [fp, #-0x88]
    // 0x697540: StoreField: r3->field_2b = r1
    //     0x697540: stur            w1, [x3, #0x2b]
    // 0x697544: ldur            x1, [fp, #-0x80]
    // 0x697548: StoreField: r3->field_2f = r1
    //     0x697548: stur            w1, [x3, #0x2f]
    // 0x69754c: ldur            x1, [fp, #-0x70]
    // 0x697550: StoreField: r3->field_33 = r1
    //     0x697550: stur            w1, [x3, #0x33]
    // 0x697554: r1 = Function '<anonymous closure>':.
    //     0x697554: add             x1, PP, #0x29, lsl #12  ; [pp+0x29328] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x697558: ldr             x1, [x1, #0x328]
    // 0x69755c: r2 = Null
    //     0x69755c: mov             x2, NULL
    // 0x697560: r0 = AllocateClosure()
    //     0x697560: bl              #0x826750  ; AllocateClosureStub
    // 0x697564: mov             x1, x0
    // 0x697568: ldur            x0, [fp, #-0xa0]
    // 0x69756c: StoreField: r0->field_3b = r1
    //     0x69756c: stur            w1, [x0, #0x3b]
    // 0x697570: ldur            x3, [fp, #-0x20]
    // 0x697574: StoreField: r0->field_43 = r3
    //     0x697574: stur            w3, [x0, #0x43]
    // 0x697578: ldur            x4, [fp, #-0x18]
    // 0x69757c: StoreField: r0->field_47 = r4
    //     0x69757c: stur            w4, [x0, #0x47]
    // 0x697580: ldur            x5, [fp, #-0x28]
    // 0x697584: StoreField: r0->field_5b = r5
    //     0x697584: stur            w5, [x0, #0x5b]
    // 0x697588: r1 = Function '<anonymous closure>':.
    //     0x697588: add             x1, PP, #0x29, lsl #12  ; [pp+0x29330] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x69758c: ldr             x1, [x1, #0x330]
    // 0x697590: r2 = Null
    //     0x697590: mov             x2, NULL
    // 0x697594: r0 = AllocateClosure()
    //     0x697594: bl              #0x826750  ; AllocateClosureStub
    // 0x697598: mov             x1, x0
    // 0x69759c: ldur            x0, [fp, #-0xa0]
    // 0x6975a0: ArrayStore: r0[0] = r1  ; List_4
    //     0x6975a0: stur            w1, [x0, #0x17]
    // 0x6975a4: r1 = Function '<anonymous closure>':.
    //     0x6975a4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29338] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x6975a8: ldr             x1, [x1, #0x338]
    // 0x6975ac: r2 = Null
    //     0x6975ac: mov             x2, NULL
    // 0x6975b0: r0 = AllocateClosure()
    //     0x6975b0: bl              #0x826750  ; AllocateClosureStub
    // 0x6975b4: mov             x1, x0
    // 0x6975b8: ldur            x0, [fp, #-0xa0]
    // 0x6975bc: StoreField: r0->field_1b = r1
    //     0x6975bc: stur            w1, [x0, #0x1b]
    // 0x6975c0: ldur            x3, [fp, #-0x30]
    // 0x6975c4: StoreField: r0->field_57 = r3
    //     0x6975c4: stur            w3, [x0, #0x57]
    // 0x6975c8: r1 = const [0x14, 0x15, 0x16]
    //     0x6975c8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29340] List<int>(3)
    //     0x6975cc: ldr             x1, [x1, #0x340]
    // 0x6975d0: StoreField: r0->field_53 = r1
    //     0x6975d0: stur            w1, [x0, #0x53]
    // 0x6975d4: ldur            x4, [fp, #-0x38]
    // 0x6975d8: StoreField: r0->field_6b = r4
    //     0x6975d8: stur            w4, [x0, #0x6b]
    // 0x6975dc: ldur            x1, [fp, #-0x98]
    // 0x6975e0: StoreField: r0->field_4b = r1
    //     0x6975e0: stur            w1, [x0, #0x4b]
    // 0x6975e4: ldur            x1, [fp, #-0x60]
    // 0x6975e8: StoreField: r0->field_f = r1
    //     0x6975e8: stur            w1, [x0, #0xf]
    // 0x6975ec: ldur            x1, [fp, #-0x50]
    // 0x6975f0: StoreField: r0->field_67 = r1
    //     0x6975f0: stur            w1, [x0, #0x67]
    // 0x6975f4: ldur            x5, [fp, #-0x10]
    // 0x6975f8: StoreField: r0->field_77 = r5
    //     0x6975f8: stur            w5, [x0, #0x77]
    // 0x6975fc: ldur            x6, [fp, #-0x40]
    // 0x697600: StoreField: r0->field_7b = r6
    //     0x697600: stur            w6, [x0, #0x7b]
    // 0x697604: r1 = "Chapter 11 Generator 3"
    //     0x697604: add             x1, PP, #0x29, lsl #12  ; [pp+0x29348] "Chapter 11 Generator 3"
    //     0x697608: ldr             x1, [x1, #0x348]
    // 0x69760c: StoreField: r0->field_73 = r1
    //     0x69760c: stur            w1, [x0, #0x73]
    // 0x697610: ldur            x2, [fp, #-0x58]
    // 0x697614: r1 = Function '<anonymous closure>':.
    //     0x697614: add             x1, PP, #0x29, lsl #12  ; [pp+0x29350] AnonymousClosure: (0x69940c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x697618: ldr             x1, [x1, #0x350]
    // 0x69761c: r0 = AllocateClosure()
    //     0x69761c: bl              #0x826750  ; AllocateClosureStub
    // 0x697620: ldur            x2, [fp, #-0xa0]
    // 0x697624: mov             x5, x0
    // 0x697628: r1 = Null
    //     0x697628: mov             x1, NULL
    // 0x69762c: r3 = "Chapter 11 Generators 3"
    //     0x69762c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29358] "Chapter 11 Generators 3"
    //     0x697630: ldr             x3, [x3, #0x358]
    // 0x697634: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697634: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697638: r0 = IdleFragment()
    //     0x697638: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69763c: ldur            x1, [fp, #-0x78]
    // 0x697640: ArrayStore: r1[5] = r0  ; List_4
    //     0x697640: add             x25, x1, #0x23
    //     0x697644: str             w0, [x25]
    //     0x697648: tbz             w0, #0, #0x697664
    //     0x69764c: ldurb           w16, [x1, #-1]
    //     0x697650: ldurb           w17, [x0, #-1]
    //     0x697654: and             x16, x17, x16, lsr #2
    //     0x697658: tst             x16, HEAP, lsr #32
    //     0x69765c: b.eq            #0x697664
    //     0x697660: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697664: ldur            x0, [fp, #-8]
    // 0x697668: LoadField: r3 = r0->field_37
    //     0x697668: ldur            w3, [x0, #0x37]
    // 0x69766c: DecompressPointer r3
    //     0x69766c: add             x3, x3, HEAP, lsl #32
    // 0x697670: stur            x3, [fp, #-0x50]
    // 0x697674: r1 = Function '<anonymous closure>':.
    //     0x697674: add             x1, PP, #0x29, lsl #12  ; [pp+0x29360] AnonymousClosure: (0x699400), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697678: ldr             x1, [x1, #0x360]
    // 0x69767c: r2 = Null
    //     0x69767c: mov             x2, NULL
    // 0x697680: r0 = AllocateClosure()
    //     0x697680: bl              #0x826750  ; AllocateClosureStub
    // 0x697684: r1 = <Chapter11Stat>
    //     0x697684: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697688: ldr             x1, [x1, #0xeb8]
    // 0x69768c: stur            x0, [fp, #-0x60]
    // 0x697690: r0 = PrestigeButton()
    //     0x697690: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x697694: mov             x3, x0
    // 0x697698: ldur            x0, [fp, #-0x60]
    // 0x69769c: stur            x3, [fp, #-0x70]
    // 0x6976a0: StoreField: r3->field_1f = r0
    //     0x6976a0: stur            w0, [x3, #0x1f]
    // 0x6976a4: r0 = Instance_Chapter11Stat
    //     0x6976a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x6976a8: ldr             x0, [x0, #0x5e0]
    // 0x6976ac: StoreField: r3->field_1b = r0
    //     0x6976ac: stur            w0, [x3, #0x1b]
    // 0x6976b0: ldur            x2, [fp, #-8]
    // 0x6976b4: r1 = Function 'goldPrestigePoints':.
    //     0x6976b4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29368] AnonymousClosure: (0x54d7c4), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestigePoints (0x54d718)
    //     0x6976b8: ldr             x1, [x1, #0x368]
    // 0x6976bc: r0 = AllocateClosure()
    //     0x6976bc: bl              #0x826750  ; AllocateClosureStub
    // 0x6976c0: mov             x1, x0
    // 0x6976c4: ldur            x0, [fp, #-0x70]
    // 0x6976c8: StoreField: r0->field_2f = r1
    //     0x6976c8: stur            w1, [x0, #0x2f]
    // 0x6976cc: ldur            x2, [fp, #-8]
    // 0x6976d0: r1 = Function 'goldPrestige':.
    //     0x6976d0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29370] AnonymousClosure: (0x6993c8), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestige (0x698440)
    //     0x6976d4: ldr             x1, [x1, #0x370]
    // 0x6976d8: r0 = AllocateClosure()
    //     0x6976d8: bl              #0x826750  ; AllocateClosureStub
    // 0x6976dc: mov             x1, x0
    // 0x6976e0: ldur            x0, [fp, #-0x70]
    // 0x6976e4: StoreField: r0->field_33 = r1
    //     0x6976e4: stur            w1, [x0, #0x33]
    // 0x6976e8: ldur            x1, [fp, #-0x50]
    // 0x6976ec: ArrayStore: r0[0] = r1  ; List_4
    //     0x6976ec: stur            w1, [x0, #0x17]
    // 0x6976f0: r3 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x6976f0: add             x3, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x6976f4: ldr             x3, [x3, #0x2a0]
    // 0x6976f8: StoreField: r0->field_43 = r3
    //     0x6976f8: stur            w3, [x0, #0x43]
    // 0x6976fc: r1 = Function '<anonymous closure>':.
    //     0x6976fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29378] AnonymousClosure: (0x6993bc), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697700: ldr             x1, [x1, #0x378]
    // 0x697704: r2 = Null
    //     0x697704: mov             x2, NULL
    // 0x697708: r0 = AllocateClosure()
    //     0x697708: bl              #0x826750  ; AllocateClosureStub
    // 0x69770c: mov             x1, x0
    // 0x697710: ldur            x0, [fp, #-0x70]
    // 0x697714: StoreField: r0->field_23 = r1
    //     0x697714: stur            w1, [x0, #0x23]
    // 0x697718: r3 = "everything above"
    //     0x697718: add             x3, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x69771c: ldr             x3, [x3, #0x1b0]
    // 0x697720: StoreField: r0->field_3f = r3
    //     0x697720: stur            w3, [x0, #0x3f]
    // 0x697724: r4 = false
    //     0x697724: add             x4, NULL, #0x30  ; false
    // 0x697728: StoreField: r0->field_f = r4
    //     0x697728: stur            w4, [x0, #0xf]
    // 0x69772c: StoreField: r0->field_4f = r4
    //     0x69772c: stur            w4, [x0, #0x4f]
    // 0x697730: r5 = true
    //     0x697730: add             x5, NULL, #0x20  ; true
    // 0x697734: StoreField: r0->field_2b = r5
    //     0x697734: stur            w5, [x0, #0x2b]
    // 0x697738: StoreField: r0->field_53 = r4
    //     0x697738: stur            w4, [x0, #0x53]
    // 0x69773c: StoreField: r0->field_5b = r5
    //     0x69773c: stur            w5, [x0, #0x5b]
    // 0x697740: r6 = "Gain"
    //     0x697740: add             x6, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x697744: ldr             x6, [x6, #0x1b8]
    // 0x697748: StoreField: r0->field_5f = r6
    //     0x697748: stur            w6, [x0, #0x5f]
    // 0x69774c: ldur            x2, [fp, #-0x58]
    // 0x697750: r1 = Function '<anonymous closure>':.
    //     0x697750: add             x1, PP, #0x29, lsl #12  ; [pp+0x29380] AnonymousClosure: (0x699370), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697754: ldr             x1, [x1, #0x380]
    // 0x697758: r0 = AllocateClosure()
    //     0x697758: bl              #0x826750  ; AllocateClosureStub
    // 0x69775c: ldur            x2, [fp, #-0x70]
    // 0x697760: mov             x5, x0
    // 0x697764: r1 = Null
    //     0x697764: mov             x1, NULL
    // 0x697768: r3 = "Chapter 11 Prestige 2"
    //     0x697768: add             x3, PP, #0x29, lsl #12  ; [pp+0x29388] "Chapter 11 Prestige 2"
    //     0x69776c: ldr             x3, [x3, #0x388]
    // 0x697770: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697770: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697774: r0 = IdleFragment()
    //     0x697774: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697778: ldur            x1, [fp, #-0x78]
    // 0x69777c: ArrayStore: r1[6] = r0  ; List_4
    //     0x69777c: add             x25, x1, #0x27
    //     0x697780: str             w0, [x25]
    //     0x697784: tbz             w0, #0, #0x6977a0
    //     0x697788: ldurb           w16, [x1, #-1]
    //     0x69778c: ldurb           w17, [x0, #-1]
    //     0x697790: and             x16, x17, x16, lsr #2
    //     0x697794: tst             x16, HEAP, lsr #32
    //     0x697798: b.eq            #0x6977a0
    //     0x69779c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6977a0: ldur            x2, [fp, #-8]
    // 0x6977a4: LoadField: r0 = r2->field_37
    //     0x6977a4: ldur            w0, [x2, #0x37]
    // 0x6977a8: DecompressPointer r0
    //     0x6977a8: add             x0, x0, HEAP, lsl #32
    // 0x6977ac: stur            x0, [fp, #-0x70]
    // 0x6977b0: LoadField: r3 = r2->field_43
    //     0x6977b0: ldur            w3, [x2, #0x43]
    // 0x6977b4: DecompressPointer r3
    //     0x6977b4: add             x3, x3, HEAP, lsl #32
    // 0x6977b8: stur            x3, [fp, #-0x60]
    // 0x6977bc: LoadField: r4 = r2->field_8f
    //     0x6977bc: ldur            w4, [x2, #0x8f]
    // 0x6977c0: DecompressPointer r4
    //     0x6977c0: add             x4, x4, HEAP, lsl #32
    // 0x6977c4: stur            x4, [fp, #-0x50]
    // 0x6977c8: r1 = <Chapter11Stat>
    //     0x6977c8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x6977cc: ldr             x1, [x1, #0xeb8]
    // 0x6977d0: r0 = UpgradeGroup()
    //     0x6977d0: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6977d4: mov             x3, x0
    // 0x6977d8: r0 = 2
    //     0x6977d8: movz            x0, #0x2
    // 0x6977dc: stur            x3, [fp, #-0x80]
    // 0x6977e0: StoreField: r3->field_13 = r0
    //     0x6977e0: stur            x0, [x3, #0x13]
    // 0x6977e4: ldur            x0, [fp, #-0x50]
    // 0x6977e8: StoreField: r3->field_1b = r0
    //     0x6977e8: stur            w0, [x3, #0x1b]
    // 0x6977ec: ldur            x0, [fp, #-0x70]
    // 0x6977f0: StoreField: r3->field_1f = r0
    //     0x6977f0: stur            w0, [x3, #0x1f]
    // 0x6977f4: ldur            x0, [fp, #-0x60]
    // 0x6977f8: StoreField: r3->field_23 = r0
    //     0x6977f8: stur            w0, [x3, #0x23]
    // 0x6977fc: r1 = Function '<anonymous closure>':.
    //     0x6977fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29390] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x697800: ldr             x1, [x1, #0x390]
    // 0x697804: r2 = Null
    //     0x697804: mov             x2, NULL
    // 0x697808: r0 = AllocateClosure()
    //     0x697808: bl              #0x826750  ; AllocateClosureStub
    // 0x69780c: mov             x1, x0
    // 0x697810: ldur            x0, [fp, #-0x80]
    // 0x697814: StoreField: r0->field_2b = r1
    //     0x697814: stur            w1, [x0, #0x2b]
    // 0x697818: r1 = const [0xb, 0xc, 0xd, 0xe]
    //     0x697818: add             x1, PP, #0x26, lsl #12  ; [pp+0x261f8] List<int>(4)
    //     0x69781c: ldr             x1, [x1, #0x1f8]
    // 0x697820: StoreField: r0->field_f = r1
    //     0x697820: stur            w1, [x0, #0xf]
    // 0x697824: r3 = true
    //     0x697824: add             x3, NULL, #0x20  ; true
    // 0x697828: StoreField: r0->field_27 = r3
    //     0x697828: stur            w3, [x0, #0x27]
    // 0x69782c: r4 = Instance_UpgradeDisplayMode
    //     0x69782c: add             x4, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x697830: ldr             x4, [x4, #0x608]
    // 0x697834: StoreField: r0->field_2f = r4
    //     0x697834: stur            w4, [x0, #0x2f]
    // 0x697838: r5 = false
    //     0x697838: add             x5, NULL, #0x30  ; false
    // 0x69783c: StoreField: r0->field_33 = r5
    //     0x69783c: stur            w5, [x0, #0x33]
    // 0x697840: ldur            x2, [fp, #-0x58]
    // 0x697844: r1 = Function '<anonymous closure>':.
    //     0x697844: add             x1, PP, #0x29, lsl #12  ; [pp+0x29398] AnonymousClosure: (0x6991dc), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x697848: ldr             x1, [x1, #0x398]
    // 0x69784c: r0 = AllocateClosure()
    //     0x69784c: bl              #0x826750  ; AllocateClosureStub
    // 0x697850: ldur            x2, [fp, #-0x80]
    // 0x697854: mov             x5, x0
    // 0x697858: r1 = Null
    //     0x697858: mov             x1, NULL
    // 0x69785c: r3 = "Chapter 11 Upgrades 2"
    //     0x69785c: add             x3, PP, #0x29, lsl #12  ; [pp+0x293a0] "Chapter 11 Upgrades 2"
    //     0x697860: ldr             x3, [x3, #0x3a0]
    // 0x697864: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697864: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697868: r0 = IdleFragment()
    //     0x697868: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69786c: ldur            x1, [fp, #-0x78]
    // 0x697870: ArrayStore: r1[7] = r0  ; List_4
    //     0x697870: add             x25, x1, #0x2b
    //     0x697874: str             w0, [x25]
    //     0x697878: tbz             w0, #0, #0x697894
    //     0x69787c: ldurb           w16, [x1, #-1]
    //     0x697880: ldurb           w17, [x0, #-1]
    //     0x697884: and             x16, x17, x16, lsr #2
    //     0x697888: tst             x16, HEAP, lsr #32
    //     0x69788c: b.eq            #0x697894
    //     0x697890: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697894: ldur            x2, [fp, #-8]
    // 0x697898: LoadField: r0 = r2->field_37
    //     0x697898: ldur            w0, [x2, #0x37]
    // 0x69789c: DecompressPointer r0
    //     0x69789c: add             x0, x0, HEAP, lsl #32
    // 0x6978a0: stur            x0, [fp, #-0x50]
    // 0x6978a4: r1 = <Chapter11Stat>
    //     0x6978a4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x6978a8: ldr             x1, [x1, #0xeb8]
    // 0x6978ac: r0 = IntermissionButton()
    //     0x6978ac: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x6978b0: mov             x3, x0
    // 0x6978b4: ldur            x0, [fp, #-0x50]
    // 0x6978b8: stur            x3, [fp, #-0x60]
    // 0x6978bc: StoreField: r3->field_1b = r0
    //     0x6978bc: stur            w0, [x3, #0x1b]
    // 0x6978c0: r0 = Instance_Tuple2
    //     0x6978c0: add             x0, PP, #0x29, lsl #12  ; [pp+0x293a8] Obj!Tuple2<Chapter11Stat, CustomNum>@8264f1
    //     0x6978c4: ldr             x0, [x0, #0x3a8]
    // 0x6978c8: StoreField: r3->field_1f = r0
    //     0x6978c8: stur            w0, [x3, #0x1f]
    // 0x6978cc: ldur            x2, [fp, #-0x58]
    // 0x6978d0: r1 = Function '<anonymous closure>':.
    //     0x6978d0: add             x1, PP, #0x29, lsl #12  ; [pp+0x293b0] AnonymousClosure: (0x699280), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x6978d4: ldr             x1, [x1, #0x3b0]
    // 0x6978d8: r0 = AllocateClosure()
    //     0x6978d8: bl              #0x826750  ; AllocateClosureStub
    // 0x6978dc: mov             x1, x0
    // 0x6978e0: ldur            x0, [fp, #-0x60]
    // 0x6978e4: StoreField: r0->field_23 = r1
    //     0x6978e4: stur            w1, [x0, #0x23]
    // 0x6978e8: r1 = Function '<anonymous closure>':.
    //     0x6978e8: add             x1, PP, #0x29, lsl #12  ; [pp+0x293b8] AnonymousClosure: (0x699228), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x6978ec: ldr             x1, [x1, #0x3b8]
    // 0x6978f0: r2 = Null
    //     0x6978f0: mov             x2, NULL
    // 0x6978f4: r0 = AllocateClosure()
    //     0x6978f4: bl              #0x826750  ; AllocateClosureStub
    // 0x6978f8: mov             x1, x0
    // 0x6978fc: ldur            x0, [fp, #-0x60]
    // 0x697900: ArrayStore: r0[0] = r1  ; List_4
    //     0x697900: stur            w1, [x0, #0x17]
    // 0x697904: r3 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x697904: add             x3, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x697908: ldr             x3, [x3, #0x2a0]
    // 0x69790c: StoreField: r0->field_f = r3
    //     0x69790c: stur            w3, [x0, #0xf]
    // 0x697910: ldur            x2, [fp, #-0x58]
    // 0x697914: r1 = Function '<anonymous closure>':.
    //     0x697914: add             x1, PP, #0x29, lsl #12  ; [pp+0x293c0] AnonymousClosure: (0x6991dc), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x697918: ldr             x1, [x1, #0x3c0]
    // 0x69791c: r0 = AllocateClosure()
    //     0x69791c: bl              #0x826750  ; AllocateClosureStub
    // 0x697920: ldur            x2, [fp, #-0x58]
    // 0x697924: r1 = Function '<anonymous closure>':.
    //     0x697924: add             x1, PP, #0x29, lsl #12  ; [pp+0x293c8] AnonymousClosure: (0x699050), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697928: ldr             x1, [x1, #0x3c8]
    // 0x69792c: stur            x0, [fp, #-0x50]
    // 0x697930: r0 = AllocateClosure()
    //     0x697930: bl              #0x826750  ; AllocateClosureStub
    // 0x697934: r16 = true
    //     0x697934: add             x16, NULL, #0x20  ; true
    // 0x697938: stp             x0, x16, [SP]
    // 0x69793c: ldur            x2, [fp, #-0x60]
    // 0x697940: ldur            x5, [fp, #-0x50]
    // 0x697944: r1 = Null
    //     0x697944: mov             x1, NULL
    // 0x697948: r3 = "Chapter 11 Intermission 1"
    //     0x697948: add             x3, PP, #0x29, lsl #12  ; [pp+0x293d0] "Chapter 11 Intermission 1"
    //     0x69794c: ldr             x3, [x3, #0x3d0]
    // 0x697950: r4 = const [0, 0x6, 0x2, 0x4, generateMinimizedName, 0x5, scrollToBottomOnUnlock, 0x4, null]
    //     0x697950: add             x4, PP, #0x26, lsl #12  ; [pp+0x260c0] List(9) [0, 0x6, 0x2, 0x4, "generateMinimizedName", 0x5, "scrollToBottomOnUnlock", 0x4, Null]
    //     0x697954: ldr             x4, [x4, #0xc0]
    // 0x697958: r0 = IdleFragment()
    //     0x697958: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x69795c: ldur            x1, [fp, #-0x78]
    // 0x697960: ArrayStore: r1[8] = r0  ; List_4
    //     0x697960: add             x25, x1, #0x2f
    //     0x697964: str             w0, [x25]
    //     0x697968: tbz             w0, #0, #0x697984
    //     0x69796c: ldurb           w16, [x1, #-1]
    //     0x697970: ldurb           w17, [x0, #-1]
    //     0x697974: and             x16, x17, x16, lsr #2
    //     0x697978: tst             x16, HEAP, lsr #32
    //     0x69797c: b.eq            #0x697984
    //     0x697980: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697984: ldur            x2, [fp, #-8]
    // 0x697988: LoadField: r0 = r2->field_2b
    //     0x697988: ldur            w0, [x2, #0x2b]
    // 0x69798c: DecompressPointer r0
    //     0x69798c: add             x0, x0, HEAP, lsl #32
    // 0x697990: stur            x0, [fp, #-0x90]
    // 0x697994: LoadField: r3 = r2->field_37
    //     0x697994: ldur            w3, [x2, #0x37]
    // 0x697998: DecompressPointer r3
    //     0x697998: add             x3, x3, HEAP, lsl #32
    // 0x69799c: stur            x3, [fp, #-0x88]
    // 0x6979a0: LoadField: r4 = r2->field_4b
    //     0x6979a0: ldur            w4, [x2, #0x4b]
    // 0x6979a4: DecompressPointer r4
    //     0x6979a4: add             x4, x4, HEAP, lsl #32
    // 0x6979a8: stur            x4, [fp, #-0x80]
    // 0x6979ac: LoadField: r5 = r2->field_47
    //     0x6979ac: ldur            w5, [x2, #0x47]
    // 0x6979b0: DecompressPointer r5
    //     0x6979b0: add             x5, x5, HEAP, lsl #32
    // 0x6979b4: stur            x5, [fp, #-0x70]
    // 0x6979b8: LoadField: r6 = r2->field_53
    //     0x6979b8: ldur            w6, [x2, #0x53]
    // 0x6979bc: DecompressPointer r6
    //     0x6979bc: add             x6, x6, HEAP, lsl #32
    // 0x6979c0: stur            x6, [fp, #-0x60]
    // 0x6979c4: LoadField: r7 = r2->field_93
    //     0x6979c4: ldur            w7, [x2, #0x93]
    // 0x6979c8: DecompressPointer r7
    //     0x6979c8: add             x7, x7, HEAP, lsl #32
    // 0x6979cc: stur            x7, [fp, #-0x50]
    // 0x6979d0: r1 = <Chapter11Stat>
    //     0x6979d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x6979d4: ldr             x1, [x1, #0xeb8]
    // 0x6979d8: r0 = GeneratorGroup()
    //     0x6979d8: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6979dc: mov             x3, x0
    // 0x6979e0: ldur            x0, [fp, #-0x88]
    // 0x6979e4: stur            x3, [fp, #-0x98]
    // 0x6979e8: StoreField: r3->field_1f = r0
    //     0x6979e8: stur            w0, [x3, #0x1f]
    // 0x6979ec: ldur            x0, [fp, #-0x48]
    // 0x6979f0: StoreField: r3->field_23 = r0
    //     0x6979f0: stur            w0, [x3, #0x23]
    // 0x6979f4: ldur            x0, [fp, #-0x68]
    // 0x6979f8: StoreField: r3->field_27 = r0
    //     0x6979f8: stur            w0, [x3, #0x27]
    // 0x6979fc: ldur            x0, [fp, #-0x80]
    // 0x697a00: StoreField: r3->field_2b = r0
    //     0x697a00: stur            w0, [x3, #0x2b]
    // 0x697a04: ldur            x0, [fp, #-0x70]
    // 0x697a08: StoreField: r3->field_2f = r0
    //     0x697a08: stur            w0, [x3, #0x2f]
    // 0x697a0c: ldur            x0, [fp, #-0x60]
    // 0x697a10: StoreField: r3->field_33 = r0
    //     0x697a10: stur            w0, [x3, #0x33]
    // 0x697a14: ldur            x2, [fp, #-0x58]
    // 0x697a18: r1 = Function '<anonymous closure>':.
    //     0x697a18: add             x1, PP, #0x29, lsl #12  ; [pp+0x293d8] AnonymousClosure: (0x699004), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697a1c: ldr             x1, [x1, #0x3d8]
    // 0x697a20: r0 = AllocateClosure()
    //     0x697a20: bl              #0x826750  ; AllocateClosureStub
    // 0x697a24: mov             x1, x0
    // 0x697a28: ldur            x0, [fp, #-0x98]
    // 0x697a2c: StoreField: r0->field_3b = r1
    //     0x697a2c: stur            w1, [x0, #0x3b]
    // 0x697a30: ldur            x1, [fp, #-0x20]
    // 0x697a34: StoreField: r0->field_43 = r1
    //     0x697a34: stur            w1, [x0, #0x43]
    // 0x697a38: ldur            x1, [fp, #-0x18]
    // 0x697a3c: StoreField: r0->field_47 = r1
    //     0x697a3c: stur            w1, [x0, #0x47]
    // 0x697a40: ldur            x1, [fp, #-0x28]
    // 0x697a44: StoreField: r0->field_5b = r1
    //     0x697a44: stur            w1, [x0, #0x5b]
    // 0x697a48: r1 = Function '<anonymous closure>':.
    //     0x697a48: add             x1, PP, #0x29, lsl #12  ; [pp+0x293e0] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x697a4c: ldr             x1, [x1, #0x3e0]
    // 0x697a50: r2 = Null
    //     0x697a50: mov             x2, NULL
    // 0x697a54: r0 = AllocateClosure()
    //     0x697a54: bl              #0x826750  ; AllocateClosureStub
    // 0x697a58: mov             x1, x0
    // 0x697a5c: ldur            x0, [fp, #-0x98]
    // 0x697a60: ArrayStore: r0[0] = r1  ; List_4
    //     0x697a60: stur            w1, [x0, #0x17]
    // 0x697a64: r1 = Function '<anonymous closure>':.
    //     0x697a64: add             x1, PP, #0x29, lsl #12  ; [pp+0x293e8] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x697a68: ldr             x1, [x1, #0x3e8]
    // 0x697a6c: r2 = Null
    //     0x697a6c: mov             x2, NULL
    // 0x697a70: r0 = AllocateClosure()
    //     0x697a70: bl              #0x826750  ; AllocateClosureStub
    // 0x697a74: mov             x1, x0
    // 0x697a78: ldur            x0, [fp, #-0x98]
    // 0x697a7c: StoreField: r0->field_1b = r1
    //     0x697a7c: stur            w1, [x0, #0x1b]
    // 0x697a80: ldur            x1, [fp, #-0x30]
    // 0x697a84: StoreField: r0->field_57 = r1
    //     0x697a84: stur            w1, [x0, #0x57]
    // 0x697a88: r1 = const [0x1f, 0x20, 0x21]
    //     0x697a88: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d98] List<int>(3)
    //     0x697a8c: ldr             x1, [x1, #0xd98]
    // 0x697a90: StoreField: r0->field_53 = r1
    //     0x697a90: stur            w1, [x0, #0x53]
    // 0x697a94: ldur            x1, [fp, #-0x38]
    // 0x697a98: StoreField: r0->field_6b = r1
    //     0x697a98: stur            w1, [x0, #0x6b]
    // 0x697a9c: ldur            x1, [fp, #-0x90]
    // 0x697aa0: StoreField: r0->field_4b = r1
    //     0x697aa0: stur            w1, [x0, #0x4b]
    // 0x697aa4: ldur            x1, [fp, #-0x50]
    // 0x697aa8: StoreField: r0->field_67 = r1
    //     0x697aa8: stur            w1, [x0, #0x67]
    // 0x697aac: ldur            x1, [fp, #-0x10]
    // 0x697ab0: StoreField: r0->field_77 = r1
    //     0x697ab0: stur            w1, [x0, #0x77]
    // 0x697ab4: ldur            x1, [fp, #-0x40]
    // 0x697ab8: StoreField: r0->field_7b = r1
    //     0x697ab8: stur            w1, [x0, #0x7b]
    // 0x697abc: r1 = "Chapter 11 Generator 4"
    //     0x697abc: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f0] "Chapter 11 Generator 4"
    //     0x697ac0: ldr             x1, [x1, #0x3f0]
    // 0x697ac4: StoreField: r0->field_73 = r1
    //     0x697ac4: stur            w1, [x0, #0x73]
    // 0x697ac8: ldur            x2, [fp, #-0x58]
    // 0x697acc: r1 = Function '<anonymous closure>':.
    //     0x697acc: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f8] AnonymousClosure: (0x697fa0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697ad0: ldr             x1, [x1, #0x3f8]
    // 0x697ad4: r0 = AllocateClosure()
    //     0x697ad4: bl              #0x826750  ; AllocateClosureStub
    // 0x697ad8: ldur            x2, [fp, #-0x98]
    // 0x697adc: mov             x5, x0
    // 0x697ae0: r1 = Null
    //     0x697ae0: mov             x1, NULL
    // 0x697ae4: r3 = "Chapter 11 Generators 4"
    //     0x697ae4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29400] "Chapter 11 Generators 4"
    //     0x697ae8: ldr             x3, [x3, #0x400]
    // 0x697aec: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697aec: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697af0: r0 = IdleFragment()
    //     0x697af0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697af4: ldur            x1, [fp, #-0x78]
    // 0x697af8: ArrayStore: r1[9] = r0  ; List_4
    //     0x697af8: add             x25, x1, #0x33
    //     0x697afc: str             w0, [x25]
    //     0x697b00: tbz             w0, #0, #0x697b1c
    //     0x697b04: ldurb           w16, [x1, #-1]
    //     0x697b08: ldurb           w17, [x0, #-1]
    //     0x697b0c: and             x16, x17, x16, lsr #2
    //     0x697b10: tst             x16, HEAP, lsr #32
    //     0x697b14: b.eq            #0x697b1c
    //     0x697b18: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697b1c: ldur            x0, [fp, #-8]
    // 0x697b20: LoadField: r3 = r0->field_37
    //     0x697b20: ldur            w3, [x0, #0x37]
    // 0x697b24: DecompressPointer r3
    //     0x697b24: add             x3, x3, HEAP, lsl #32
    // 0x697b28: stur            x3, [fp, #-0x10]
    // 0x697b2c: r1 = Function '<anonymous closure>':.
    //     0x697b2c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29408] AnonymousClosure: (0x698ff8), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697b30: ldr             x1, [x1, #0x408]
    // 0x697b34: r2 = Null
    //     0x697b34: mov             x2, NULL
    // 0x697b38: r0 = AllocateClosure()
    //     0x697b38: bl              #0x826750  ; AllocateClosureStub
    // 0x697b3c: r1 = <Chapter11Stat>
    //     0x697b3c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697b40: ldr             x1, [x1, #0xeb8]
    // 0x697b44: stur            x0, [fp, #-0x18]
    // 0x697b48: r0 = PrestigeButton()
    //     0x697b48: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x697b4c: mov             x3, x0
    // 0x697b50: ldur            x0, [fp, #-0x18]
    // 0x697b54: stur            x3, [fp, #-0x20]
    // 0x697b58: StoreField: r3->field_1f = r0
    //     0x697b58: stur            w0, [x3, #0x1f]
    // 0x697b5c: r0 = Instance_Chapter11Stat
    //     0x697b5c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x697b60: ldr             x0, [x0, #0x608]
    // 0x697b64: StoreField: r3->field_1b = r0
    //     0x697b64: stur            w0, [x3, #0x1b]
    // 0x697b68: ldur            x2, [fp, #-8]
    // 0x697b6c: r1 = Function 'titaniumPrestigePoints':.
    //     0x697b6c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29410] AnonymousClosure: (0x698fc0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::titaniumPrestigePoints (0x698f14)
    //     0x697b70: ldr             x1, [x1, #0x410]
    // 0x697b74: r0 = AllocateClosure()
    //     0x697b74: bl              #0x826750  ; AllocateClosureStub
    // 0x697b78: mov             x1, x0
    // 0x697b7c: ldur            x0, [fp, #-0x20]
    // 0x697b80: StoreField: r0->field_2f = r1
    //     0x697b80: stur            w1, [x0, #0x2f]
    // 0x697b84: ldur            x2, [fp, #-8]
    // 0x697b88: r1 = Function 'titaniumPrestige':.
    //     0x697b88: add             x1, PP, #0x29, lsl #12  ; [pp+0x29418] AnonymousClosure: (0x69802c), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::titaniumPrestige (0x698064)
    //     0x697b8c: ldr             x1, [x1, #0x418]
    // 0x697b90: r0 = AllocateClosure()
    //     0x697b90: bl              #0x826750  ; AllocateClosureStub
    // 0x697b94: mov             x1, x0
    // 0x697b98: ldur            x0, [fp, #-0x20]
    // 0x697b9c: StoreField: r0->field_33 = r1
    //     0x697b9c: stur            w1, [x0, #0x33]
    // 0x697ba0: ldur            x1, [fp, #-0x10]
    // 0x697ba4: ArrayStore: r0[0] = r1  ; List_4
    //     0x697ba4: stur            w1, [x0, #0x17]
    // 0x697ba8: r3 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x697ba8: add             x3, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x697bac: ldr             x3, [x3, #0x2a0]
    // 0x697bb0: StoreField: r0->field_43 = r3
    //     0x697bb0: stur            w3, [x0, #0x43]
    // 0x697bb4: r1 = Function '<anonymous closure>':.
    //     0x697bb4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29420] AnonymousClosure: (0x698020), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697bb8: ldr             x1, [x1, #0x420]
    // 0x697bbc: r2 = Null
    //     0x697bbc: mov             x2, NULL
    // 0x697bc0: r0 = AllocateClosure()
    //     0x697bc0: bl              #0x826750  ; AllocateClosureStub
    // 0x697bc4: mov             x1, x0
    // 0x697bc8: ldur            x0, [fp, #-0x20]
    // 0x697bcc: StoreField: r0->field_23 = r1
    //     0x697bcc: stur            w1, [x0, #0x23]
    // 0x697bd0: r1 = "everything above"
    //     0x697bd0: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x697bd4: ldr             x1, [x1, #0x1b0]
    // 0x697bd8: StoreField: r0->field_3f = r1
    //     0x697bd8: stur            w1, [x0, #0x3f]
    // 0x697bdc: r3 = false
    //     0x697bdc: add             x3, NULL, #0x30  ; false
    // 0x697be0: StoreField: r0->field_f = r3
    //     0x697be0: stur            w3, [x0, #0xf]
    // 0x697be4: StoreField: r0->field_4f = r3
    //     0x697be4: stur            w3, [x0, #0x4f]
    // 0x697be8: r4 = true
    //     0x697be8: add             x4, NULL, #0x20  ; true
    // 0x697bec: StoreField: r0->field_2b = r4
    //     0x697bec: stur            w4, [x0, #0x2b]
    // 0x697bf0: StoreField: r0->field_53 = r3
    //     0x697bf0: stur            w3, [x0, #0x53]
    // 0x697bf4: StoreField: r0->field_5b = r4
    //     0x697bf4: stur            w4, [x0, #0x5b]
    // 0x697bf8: r1 = "Gain"
    //     0x697bf8: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x697bfc: ldr             x1, [x1, #0x1b8]
    // 0x697c00: StoreField: r0->field_5f = r1
    //     0x697c00: stur            w1, [x0, #0x5f]
    // 0x697c04: ldur            x2, [fp, #-0x58]
    // 0x697c08: r1 = Function '<anonymous closure>':.
    //     0x697c08: add             x1, PP, #0x29, lsl #12  ; [pp+0x29428] AnonymousClosure: (0x697fa0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697c0c: ldr             x1, [x1, #0x428]
    // 0x697c10: r0 = AllocateClosure()
    //     0x697c10: bl              #0x826750  ; AllocateClosureStub
    // 0x697c14: ldur            x2, [fp, #-0x20]
    // 0x697c18: mov             x5, x0
    // 0x697c1c: r1 = Null
    //     0x697c1c: mov             x1, NULL
    // 0x697c20: r3 = "Chapter 11 Prestige 3"
    //     0x697c20: add             x3, PP, #0x29, lsl #12  ; [pp+0x29430] "Chapter 11 Prestige 3"
    //     0x697c24: ldr             x3, [x3, #0x430]
    // 0x697c28: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697c28: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697c2c: r0 = IdleFragment()
    //     0x697c2c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697c30: ldur            x1, [fp, #-0x78]
    // 0x697c34: ArrayStore: r1[10] = r0  ; List_4
    //     0x697c34: add             x25, x1, #0x37
    //     0x697c38: str             w0, [x25]
    //     0x697c3c: tbz             w0, #0, #0x697c58
    //     0x697c40: ldurb           w16, [x1, #-1]
    //     0x697c44: ldurb           w17, [x0, #-1]
    //     0x697c48: and             x16, x17, x16, lsr #2
    //     0x697c4c: tst             x16, HEAP, lsr #32
    //     0x697c50: b.eq            #0x697c58
    //     0x697c54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697c58: ldur            x0, [fp, #-8]
    // 0x697c5c: LoadField: r2 = r0->field_37
    //     0x697c5c: ldur            w2, [x0, #0x37]
    // 0x697c60: DecompressPointer r2
    //     0x697c60: add             x2, x2, HEAP, lsl #32
    // 0x697c64: stur            x2, [fp, #-0x20]
    // 0x697c68: LoadField: r3 = r0->field_43
    //     0x697c68: ldur            w3, [x0, #0x43]
    // 0x697c6c: DecompressPointer r3
    //     0x697c6c: add             x3, x3, HEAP, lsl #32
    // 0x697c70: stur            x3, [fp, #-0x18]
    // 0x697c74: LoadField: r4 = r0->field_8f
    //     0x697c74: ldur            w4, [x0, #0x8f]
    // 0x697c78: DecompressPointer r4
    //     0x697c78: add             x4, x4, HEAP, lsl #32
    // 0x697c7c: stur            x4, [fp, #-0x10]
    // 0x697c80: r1 = <Chapter11Stat>
    //     0x697c80: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697c84: ldr             x1, [x1, #0xeb8]
    // 0x697c88: r0 = UpgradeGroup()
    //     0x697c88: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x697c8c: mov             x3, x0
    // 0x697c90: r0 = 1
    //     0x697c90: movz            x0, #0x1
    // 0x697c94: stur            x3, [fp, #-0x28]
    // 0x697c98: StoreField: r3->field_13 = r0
    //     0x697c98: stur            x0, [x3, #0x13]
    // 0x697c9c: ldur            x0, [fp, #-0x10]
    // 0x697ca0: StoreField: r3->field_1b = r0
    //     0x697ca0: stur            w0, [x3, #0x1b]
    // 0x697ca4: ldur            x0, [fp, #-0x20]
    // 0x697ca8: StoreField: r3->field_1f = r0
    //     0x697ca8: stur            w0, [x3, #0x1f]
    // 0x697cac: ldur            x0, [fp, #-0x18]
    // 0x697cb0: StoreField: r3->field_23 = r0
    //     0x697cb0: stur            w0, [x3, #0x23]
    // 0x697cb4: r1 = Function '<anonymous closure>':.
    //     0x697cb4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29438] AnonymousClosure: (0x46d8b0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState (0x46d784)
    //     0x697cb8: ldr             x1, [x1, #0x438]
    // 0x697cbc: r2 = Null
    //     0x697cbc: mov             x2, NULL
    // 0x697cc0: r0 = AllocateClosure()
    //     0x697cc0: bl              #0x826750  ; AllocateClosureStub
    // 0x697cc4: mov             x1, x0
    // 0x697cc8: ldur            x0, [fp, #-0x28]
    // 0x697ccc: StoreField: r0->field_2b = r1
    //     0x697ccc: stur            w1, [x0, #0x2b]
    // 0x697cd0: r1 = const [0x15, 0x16]
    //     0x697cd0: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] List<int>(2)
    //     0x697cd4: ldr             x1, [x1, #0x2a0]
    // 0x697cd8: StoreField: r0->field_f = r1
    //     0x697cd8: stur            w1, [x0, #0xf]
    // 0x697cdc: r1 = true
    //     0x697cdc: add             x1, NULL, #0x20  ; true
    // 0x697ce0: StoreField: r0->field_27 = r1
    //     0x697ce0: stur            w1, [x0, #0x27]
    // 0x697ce4: r1 = Instance_UpgradeDisplayMode
    //     0x697ce4: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x697ce8: ldr             x1, [x1, #0x608]
    // 0x697cec: StoreField: r0->field_2f = r1
    //     0x697cec: stur            w1, [x0, #0x2f]
    // 0x697cf0: r1 = false
    //     0x697cf0: add             x1, NULL, #0x30  ; false
    // 0x697cf4: StoreField: r0->field_33 = r1
    //     0x697cf4: stur            w1, [x0, #0x33]
    // 0x697cf8: ldur            x2, [fp, #-0x58]
    // 0x697cfc: r1 = Function '<anonymous closure>':.
    //     0x697cfc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29440] AnonymousClosure: (0x697fa0), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697d00: ldr             x1, [x1, #0x440]
    // 0x697d04: r0 = AllocateClosure()
    //     0x697d04: bl              #0x826750  ; AllocateClosureStub
    // 0x697d08: ldur            x2, [fp, #-0x28]
    // 0x697d0c: mov             x5, x0
    // 0x697d10: r1 = Null
    //     0x697d10: mov             x1, NULL
    // 0x697d14: r3 = "Chapter 11 Upgrades 3"
    //     0x697d14: add             x3, PP, #0x29, lsl #12  ; [pp+0x29448] "Chapter 11 Upgrades 3"
    //     0x697d18: ldr             x3, [x3, #0x448]
    // 0x697d1c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697d1c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697d20: r0 = IdleFragment()
    //     0x697d20: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697d24: ldur            x1, [fp, #-0x78]
    // 0x697d28: ArrayStore: r1[11] = r0  ; List_4
    //     0x697d28: add             x25, x1, #0x3b
    //     0x697d2c: str             w0, [x25]
    //     0x697d30: tbz             w0, #0, #0x697d4c
    //     0x697d34: ldurb           w16, [x1, #-1]
    //     0x697d38: ldurb           w17, [x0, #-1]
    //     0x697d3c: and             x16, x17, x16, lsr #2
    //     0x697d40: tst             x16, HEAP, lsr #32
    //     0x697d44: b.eq            #0x697d4c
    //     0x697d48: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697d4c: ldur            x0, [fp, #-8]
    // 0x697d50: LoadField: r2 = r0->field_37
    //     0x697d50: ldur            w2, [x0, #0x37]
    // 0x697d54: DecompressPointer r2
    //     0x697d54: add             x2, x2, HEAP, lsl #32
    // 0x697d58: stur            x2, [fp, #-0x10]
    // 0x697d5c: r1 = <Chapter11Stat>
    //     0x697d5c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x697d60: ldr             x1, [x1, #0xeb8]
    // 0x697d64: r0 = CompleteChapterButtons()
    //     0x697d64: bl              #0x697edc  ; AllocateCompleteChapterButtonsStub -> CompleteChapterButtons<X0> (size=0x24)
    // 0x697d68: mov             x3, x0
    // 0x697d6c: ldur            x0, [fp, #-0x10]
    // 0x697d70: stur            x3, [fp, #-8]
    // 0x697d74: StoreField: r3->field_f = r0
    //     0x697d74: stur            w0, [x3, #0xf]
    // 0x697d78: r0 = Instance_Tuple2
    //     0x697d78: add             x0, PP, #0x29, lsl #12  ; [pp+0x29450] Obj!Tuple2<Chapter11Stat, CustomNum>@8264d1
    //     0x697d7c: ldr             x0, [x0, #0x450]
    // 0x697d80: StoreField: r3->field_13 = r0
    //     0x697d80: stur            w0, [x3, #0x13]
    // 0x697d84: ldur            x2, [fp, #-0x58]
    // 0x697d88: r1 = Function '<anonymous closure>':.
    //     0x697d88: add             x1, PP, #0x29, lsl #12  ; [pp+0x29458] AnonymousClosure: (0x697f4c), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x697d8c: ldr             x1, [x1, #0x458]
    // 0x697d90: r0 = AllocateClosure()
    //     0x697d90: bl              #0x826750  ; AllocateClosureStub
    // 0x697d94: mov             x1, x0
    // 0x697d98: ldur            x0, [fp, #-8]
    // 0x697d9c: ArrayStore: r0[0] = r1  ; List_4
    //     0x697d9c: stur            w1, [x0, #0x17]
    // 0x697da0: r1 = Closure: (Chapter11Stat?) => String from Function 'humanName': static.
    //     0x697da0: add             x1, PP, #0x29, lsl #12  ; [pp+0x292a0] Closure: (Chapter11Stat?) => String from Function 'humanName': static. (0x248ed99d8b0)
    //     0x697da4: ldr             x1, [x1, #0x2a0]
    // 0x697da8: StoreField: r0->field_1f = r1
    //     0x697da8: stur            w1, [x0, #0x1f]
    // 0x697dac: r1 = Instance_ChapterCompleteButtonType
    //     0x697dac: add             x1, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!ChapterCompleteButtonType@85ea61
    //     0x697db0: ldr             x1, [x1, #0x330]
    // 0x697db4: StoreField: r0->field_1b = r1
    //     0x697db4: stur            w1, [x0, #0x1b]
    // 0x697db8: r1 = Null
    //     0x697db8: mov             x1, NULL
    // 0x697dbc: r2 = 2
    //     0x697dbc: movz            x2, #0x2
    // 0x697dc0: r0 = AllocateArray()
    //     0x697dc0: bl              #0x82746c  ; AllocateArrayStub
    // 0x697dc4: mov             x2, x0
    // 0x697dc8: ldur            x0, [fp, #-8]
    // 0x697dcc: stur            x2, [fp, #-0x10]
    // 0x697dd0: StoreField: r2->field_f = r0
    //     0x697dd0: stur            w0, [x2, #0xf]
    // 0x697dd4: r1 = <Widget>
    //     0x697dd4: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x697dd8: r0 = AllocateGrowableArray()
    //     0x697dd8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x697ddc: mov             x1, x0
    // 0x697de0: ldur            x0, [fp, #-0x10]
    // 0x697de4: stur            x1, [fp, #-8]
    // 0x697de8: StoreField: r1->field_f = r0
    //     0x697de8: stur            w0, [x1, #0xf]
    // 0x697dec: r0 = 2
    //     0x697dec: movz            x0, #0x2
    // 0x697df0: StoreField: r1->field_b = r0
    //     0x697df0: stur            w0, [x1, #0xb]
    // 0x697df4: r0 = Column()
    //     0x697df4: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x697df8: mov             x3, x0
    // 0x697dfc: r0 = Instance_Axis
    //     0x697dfc: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x697e00: stur            x3, [fp, #-0x10]
    // 0x697e04: StoreField: r3->field_f = r0
    //     0x697e04: stur            w0, [x3, #0xf]
    // 0x697e08: r0 = Instance_MainAxisAlignment
    //     0x697e08: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x697e0c: ldr             x0, [x0, #0x200]
    // 0x697e10: StoreField: r3->field_13 = r0
    //     0x697e10: stur            w0, [x3, #0x13]
    // 0x697e14: r0 = Instance_MainAxisSize
    //     0x697e14: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x697e18: ldr             x0, [x0, #0x70]
    // 0x697e1c: ArrayStore: r3[0] = r0  ; List_4
    //     0x697e1c: stur            w0, [x3, #0x17]
    // 0x697e20: r0 = Instance_CrossAxisAlignment
    //     0x697e20: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x697e24: ldr             x0, [x0, #0x78]
    // 0x697e28: StoreField: r3->field_1b = r0
    //     0x697e28: stur            w0, [x3, #0x1b]
    // 0x697e2c: r0 = Instance_VerticalDirection
    //     0x697e2c: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x697e30: ldr             x0, [x0, #0x1e8]
    // 0x697e34: StoreField: r3->field_23 = r0
    //     0x697e34: stur            w0, [x3, #0x23]
    // 0x697e38: r0 = Instance_Clip
    //     0x697e38: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x697e3c: ldr             x0, [x0, #0x1b0]
    // 0x697e40: StoreField: r3->field_2b = r0
    //     0x697e40: stur            w0, [x3, #0x2b]
    // 0x697e44: StoreField: r3->field_2f = rZR
    //     0x697e44: stur            xzr, [x3, #0x2f]
    // 0x697e48: ldur            x0, [fp, #-8]
    // 0x697e4c: StoreField: r3->field_b = r0
    //     0x697e4c: stur            w0, [x3, #0xb]
    // 0x697e50: ldur            x2, [fp, #-0x58]
    // 0x697e54: r1 = Function '<anonymous closure>':.
    //     0x697e54: add             x1, PP, #0x29, lsl #12  ; [pp+0x29460] AnonymousClosure: (0x697f00), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x697e58: ldr             x1, [x1, #0x460]
    // 0x697e5c: r0 = AllocateClosure()
    //     0x697e5c: bl              #0x826750  ; AllocateClosureStub
    // 0x697e60: ldur            x2, [fp, #-0x10]
    // 0x697e64: mov             x5, x0
    // 0x697e68: r1 = Null
    //     0x697e68: mov             x1, NULL
    // 0x697e6c: r3 = "Chapter 11 Complete Chapter"
    //     0x697e6c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29468] "Chapter 11 Complete Chapter"
    //     0x697e70: ldr             x3, [x3, #0x468]
    // 0x697e74: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x697e74: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x697e78: r0 = IdleFragment()
    //     0x697e78: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x697e7c: ldur            x1, [fp, #-0x78]
    // 0x697e80: ArrayStore: r1[12] = r0  ; List_4
    //     0x697e80: add             x25, x1, #0x3f
    //     0x697e84: str             w0, [x25]
    //     0x697e88: tbz             w0, #0, #0x697ea4
    //     0x697e8c: ldurb           w16, [x1, #-1]
    //     0x697e90: ldurb           w17, [x0, #-1]
    //     0x697e94: and             x16, x17, x16, lsr #2
    //     0x697e98: tst             x16, HEAP, lsr #32
    //     0x697e9c: b.eq            #0x697ea4
    //     0x697ea0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x697ea4: r1 = <Widget>
    //     0x697ea4: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x697ea8: r0 = AllocateGrowableArray()
    //     0x697ea8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x697eac: ldur            x1, [fp, #-0x78]
    // 0x697eb0: StoreField: r0->field_f = r1
    //     0x697eb0: stur            w1, [x0, #0xf]
    // 0x697eb4: r1 = 26
    //     0x697eb4: movz            x1, #0x1a
    // 0x697eb8: StoreField: r0->field_b = r1
    //     0x697eb8: stur            w1, [x0, #0xb]
    // 0x697ebc: LeaveFrame
    //     0x697ebc: mov             SP, fp
    //     0x697ec0: ldp             fp, lr, [SP], #0x10
    // 0x697ec4: ret
    //     0x697ec4: ret             
    // 0x697ec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x697ec8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x697ecc: b               #0x6969f4
    // 0x697ed0: r9 = allUpgradeData
    //     0x697ed0: add             x9, PP, #0x29, lsl #12  ; [pp+0x29470] Field <Chapter11GameState.allUpgradeData>: late (offset: 0x90)
    //     0x697ed4: ldr             x9, [x9, #0x470]
    // 0x697ed8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x697ed8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x697f4c, size: 0x54
    // 0x697f4c: EnterFrame
    //     0x697f4c: stp             fp, lr, [SP, #-0x10]!
    //     0x697f50: mov             fp, SP
    // 0x697f54: ldr             x0, [fp, #0x18]
    // 0x697f58: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x697f58: ldur            w1, [x0, #0x17]
    // 0x697f5c: DecompressPointer r1
    //     0x697f5c: add             x1, x1, HEAP, lsl #32
    // 0x697f60: CheckStackOverflow
    //     0x697f60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x697f64: cmp             SP, x16
    //     0x697f68: b.ls            #0x697f98
    // 0x697f6c: LoadField: r0 = r1->field_f
    //     0x697f6c: ldur            w0, [x1, #0xf]
    // 0x697f70: DecompressPointer r0
    //     0x697f70: add             x0, x0, HEAP, lsl #32
    // 0x697f74: LoadField: r2 = r1->field_13
    //     0x697f74: ldur            w2, [x1, #0x13]
    // 0x697f78: DecompressPointer r2
    //     0x697f78: add             x2, x2, HEAP, lsl #32
    // 0x697f7c: mov             x1, x0
    // 0x697f80: r3 = Instance_Tuple2
    //     0x697f80: add             x3, PP, #0x29, lsl #12  ; [pp+0x29478] Obj!Tuple2<int, String>@8264b1
    //     0x697f84: ldr             x3, [x3, #0x478]
    // 0x697f88: r0 = completeChapter()
    //     0x697f88: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x697f8c: LeaveFrame
    //     0x697f8c: mov             SP, fp
    //     0x697f90: ldp             fp, lr, [SP], #0x10
    // 0x697f94: ret
    //     0x697f94: ret             
    // 0x697f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x697f98: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x697f9c: b               #0x697f6c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x697fa0, size: 0x80
    // 0x697fa0: EnterFrame
    //     0x697fa0: stp             fp, lr, [SP, #-0x10]!
    //     0x697fa4: mov             fp, SP
    // 0x697fa8: AllocStack(0x8)
    //     0x697fa8: sub             SP, SP, #8
    // 0x697fac: SetupParameters([dynamic _ /* r0 */])
    //     0x697fac: ldr             x0, [fp, #0x10]
    //     0x697fb0: ldur            w3, [x0, #0x17]
    //     0x697fb4: add             x3, x3, HEAP, lsl #32
    //     0x697fb8: stur            x3, [fp, #-8]
    // 0x697fbc: CheckStackOverflow
    //     0x697fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x697fc0: cmp             SP, x16
    //     0x697fc4: b.ls            #0x698018
    // 0x697fc8: LoadField: r0 = r3->field_f
    //     0x697fc8: ldur            w0, [x3, #0xf]
    // 0x697fcc: DecompressPointer r0
    //     0x697fcc: add             x0, x0, HEAP, lsl #32
    // 0x697fd0: LoadField: r1 = r0->field_f
    //     0x697fd0: ldur            w1, [x0, #0xf]
    // 0x697fd4: DecompressPointer r1
    //     0x697fd4: add             x1, x1, HEAP, lsl #32
    // 0x697fd8: r2 = 46
    //     0x697fd8: movz            x2, #0x2e
    // 0x697fdc: r0 = contains()
    //     0x697fdc: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x697fe0: tbnz            w0, #4, #0x698008
    // 0x697fe4: ldur            x0, [fp, #-8]
    // 0x697fe8: LoadField: r1 = r0->field_f
    //     0x697fe8: ldur            w1, [x0, #0xf]
    // 0x697fec: DecompressPointer r1
    //     0x697fec: add             x1, x1, HEAP, lsl #32
    // 0x697ff0: LoadField: r0 = r1->field_13
    //     0x697ff0: ldur            w0, [x1, #0x13]
    // 0x697ff4: DecompressPointer r0
    //     0x697ff4: add             x0, x0, HEAP, lsl #32
    // 0x697ff8: mov             x1, x0
    // 0x697ffc: r2 = 8
    //     0x697ffc: movz            x2, #0x8
    // 0x698000: r0 = contains()
    //     0x698000: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x698004: b               #0x69800c
    // 0x698008: r0 = false
    //     0x698008: add             x0, NULL, #0x30  ; false
    // 0x69800c: LeaveFrame
    //     0x69800c: mov             SP, fp
    //     0x698010: ldp             fp, lr, [SP], #0x10
    // 0x698014: ret
    //     0x698014: ret             
    // 0x698018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698018: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69801c: b               #0x697fc8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x698020, size: 0xc
    // 0x698020: r0 = "Each titanium member increases associates gained by 1%"
    //     0x698020: add             x0, PP, #0x29, lsl #12  ; [pp+0x29480] "Each titanium member increases associates gained by 1%"
    //     0x698024: ldr             x0, [x0, #0x480]
    // 0x698028: ret
    //     0x698028: ret             
  }
  [closure] void titaniumPrestige(dynamic) {
    // ** addr: 0x69802c, size: 0x38
    // 0x69802c: EnterFrame
    //     0x69802c: stp             fp, lr, [SP, #-0x10]!
    //     0x698030: mov             fp, SP
    // 0x698034: ldr             x0, [fp, #0x10]
    // 0x698038: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x698038: ldur            w1, [x0, #0x17]
    // 0x69803c: DecompressPointer r1
    //     0x69803c: add             x1, x1, HEAP, lsl #32
    // 0x698040: CheckStackOverflow
    //     0x698040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x698044: cmp             SP, x16
    //     0x698048: b.ls            #0x69805c
    // 0x69804c: r0 = titaniumPrestige()
    //     0x69804c: bl              #0x698064  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::titaniumPrestige
    // 0x698050: LeaveFrame
    //     0x698050: mov             SP, fp
    //     0x698054: ldp             fp, lr, [SP], #0x10
    // 0x698058: ret
    //     0x698058: ret             
    // 0x69805c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69805c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698060: b               #0x69804c
  }
  _ titaniumPrestige(/* No info */) {
    // ** addr: 0x698064, size: 0x3dc
    // 0x698064: EnterFrame
    //     0x698064: stp             fp, lr, [SP, #-0x10]!
    //     0x698068: mov             fp, SP
    // 0x69806c: AllocStack(0x18)
    //     0x69806c: sub             SP, SP, #0x18
    // 0x698070: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x8 */)
    //     0x698070: mov             x0, x1
    //     0x698074: stur            x1, [fp, #-8]
    // 0x698078: CheckStackOverflow
    //     0x698078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69807c: cmp             SP, x16
    //     0x698080: b.ls            #0x698438
    // 0x698084: mov             x1, x0
    // 0x698088: r0 = titaniumPrestigePoints()
    //     0x698088: bl              #0x698f14  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::titaniumPrestigePoints
    // 0x69808c: ldur            x1, [fp, #-8]
    // 0x698090: stur            x0, [fp, #-0x10]
    // 0x698094: r0 = goldPrestige()
    //     0x698094: bl              #0x698440  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestige
    // 0x698098: ldur            x0, [fp, #-8]
    // 0x69809c: LoadField: r3 = r0->field_37
    //     0x69809c: ldur            w3, [x0, #0x37]
    // 0x6980a0: DecompressPointer r3
    //     0x6980a0: add             x3, x3, HEAP, lsl #32
    // 0x6980a4: mov             x1, x3
    // 0x6980a8: stur            x3, [fp, #-0x18]
    // 0x6980ac: r2 = Instance_Chapter11Stat
    //     0x6980ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x6980b0: ldr             x2, [x2, #0x608]
    // 0x6980b4: r0 = _getValueOrData()
    //     0x6980b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6980b8: mov             x1, x0
    // 0x6980bc: ldur            x0, [fp, #-0x18]
    // 0x6980c0: LoadField: r2 = r0->field_f
    //     0x6980c0: ldur            w2, [x0, #0xf]
    // 0x6980c4: DecompressPointer r2
    //     0x6980c4: add             x2, x2, HEAP, lsl #32
    // 0x6980c8: cmp             w2, w1
    // 0x6980cc: b.ne            #0x6980d4
    // 0x6980d0: r1 = Null
    //     0x6980d0: mov             x1, NULL
    // 0x6980d4: cmp             w1, NULL
    // 0x6980d8: b.ne            #0x6980e4
    // 0x6980dc: r1 = Instance_CustomNum
    //     0x6980dc: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6980e0: ldr             x1, [x1, #0xaf8]
    // 0x6980e4: ldur            x3, [fp, #-8]
    // 0x6980e8: ldur            x2, [fp, #-0x10]
    // 0x6980ec: r0 = add()
    //     0x6980ec: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6980f0: ldur            x1, [fp, #-0x18]
    // 0x6980f4: mov             x3, x0
    // 0x6980f8: r2 = Instance_Chapter11Stat
    //     0x6980f8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x6980fc: ldr             x2, [x2, #0x608]
    // 0x698100: r0 = []=()
    //     0x698100: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x698104: ldur            x0, [fp, #-8]
    // 0x698108: LoadField: r3 = r0->field_3b
    //     0x698108: ldur            w3, [x0, #0x3b]
    // 0x69810c: DecompressPointer r3
    //     0x69810c: add             x3, x3, HEAP, lsl #32
    // 0x698110: mov             x1, x3
    // 0x698114: stur            x3, [fp, #-0x18]
    // 0x698118: r2 = Instance_Chapter11Stat
    //     0x698118: add             x2, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x69811c: ldr             x2, [x2, #0x608]
    // 0x698120: r0 = _getValueOrData()
    //     0x698120: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698124: mov             x1, x0
    // 0x698128: ldur            x0, [fp, #-0x18]
    // 0x69812c: LoadField: r2 = r0->field_f
    //     0x69812c: ldur            w2, [x0, #0xf]
    // 0x698130: DecompressPointer r2
    //     0x698130: add             x2, x2, HEAP, lsl #32
    // 0x698134: cmp             w2, w1
    // 0x698138: b.ne            #0x698140
    // 0x69813c: r1 = Null
    //     0x69813c: mov             x1, NULL
    // 0x698140: cmp             w1, NULL
    // 0x698144: b.ne            #0x698150
    // 0x698148: r1 = Instance_CustomNum
    //     0x698148: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69814c: ldr             x1, [x1, #0xaf8]
    // 0x698150: ldur            x3, [fp, #-8]
    // 0x698154: ldur            x2, [fp, #-0x10]
    // 0x698158: r0 = add()
    //     0x698158: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x69815c: ldur            x1, [fp, #-0x18]
    // 0x698160: mov             x3, x0
    // 0x698164: r2 = Instance_Chapter11Stat
    //     0x698164: add             x2, PP, #0x11, lsl #12  ; [pp+0x11608] Obj!Chapter11Stat@85fce1
    //     0x698168: ldr             x2, [x2, #0x608]
    // 0x69816c: r0 = []=()
    //     0x69816c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x698170: ldur            x0, [fp, #-8]
    // 0x698174: LoadField: r1 = r0->field_13
    //     0x698174: ldur            w1, [x0, #0x13]
    // 0x698178: DecompressPointer r1
    //     0x698178: add             x1, x1, HEAP, lsl #32
    // 0x69817c: r2 = 16
    //     0x69817c: movz            x2, #0x10
    // 0x698180: r0 = add()
    //     0x698180: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x698184: ldur            x0, [fp, #-8]
    // 0x698188: LoadField: r1 = r0->field_37
    //     0x698188: ldur            w1, [x0, #0x37]
    // 0x69818c: DecompressPointer r1
    //     0x69818c: add             x1, x1, HEAP, lsl #32
    // 0x698190: r2 = Instance_Chapter11Stat
    //     0x698190: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x698194: ldr             x2, [x2, #0x5d0]
    // 0x698198: r0 = remove()
    //     0x698198: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69819c: ldur            x0, [fp, #-8]
    // 0x6981a0: LoadField: r1 = r0->field_3b
    //     0x6981a0: ldur            w1, [x0, #0x3b]
    // 0x6981a4: DecompressPointer r1
    //     0x6981a4: add             x1, x1, HEAP, lsl #32
    // 0x6981a8: r2 = Instance_Chapter11Stat
    //     0x6981a8: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x6981ac: ldr             x2, [x2, #0x5d0]
    // 0x6981b0: r0 = remove()
    //     0x6981b0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6981b4: ldur            x0, [fp, #-8]
    // 0x6981b8: LoadField: r1 = r0->field_37
    //     0x6981b8: ldur            w1, [x0, #0x37]
    // 0x6981bc: DecompressPointer r1
    //     0x6981bc: add             x1, x1, HEAP, lsl #32
    // 0x6981c0: r2 = Instance_Chapter11Stat
    //     0x6981c0: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x6981c4: ldr             x2, [x2, #0x5b0]
    // 0x6981c8: r0 = remove()
    //     0x6981c8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6981cc: ldur            x0, [fp, #-8]
    // 0x6981d0: LoadField: r1 = r0->field_3b
    //     0x6981d0: ldur            w1, [x0, #0x3b]
    // 0x6981d4: DecompressPointer r1
    //     0x6981d4: add             x1, x1, HEAP, lsl #32
    // 0x6981d8: r2 = Instance_Chapter11Stat
    //     0x6981d8: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x6981dc: ldr             x2, [x2, #0x5b0]
    // 0x6981e0: r0 = remove()
    //     0x6981e0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6981e4: ldur            x0, [fp, #-8]
    // 0x6981e8: LoadField: r1 = r0->field_37
    //     0x6981e8: ldur            w1, [x0, #0x37]
    // 0x6981ec: DecompressPointer r1
    //     0x6981ec: add             x1, x1, HEAP, lsl #32
    // 0x6981f0: r2 = Instance_Chapter11Stat
    //     0x6981f0: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x6981f4: ldr             x2, [x2, #0x5e0]
    // 0x6981f8: r0 = remove()
    //     0x6981f8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6981fc: ldur            x0, [fp, #-8]
    // 0x698200: LoadField: r1 = r0->field_3b
    //     0x698200: ldur            w1, [x0, #0x3b]
    // 0x698204: DecompressPointer r1
    //     0x698204: add             x1, x1, HEAP, lsl #32
    // 0x698208: r2 = Instance_Chapter11Stat
    //     0x698208: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x69820c: ldr             x2, [x2, #0x5e0]
    // 0x698210: r0 = remove()
    //     0x698210: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698214: ldur            x0, [fp, #-8]
    // 0x698218: LoadField: r1 = r0->field_37
    //     0x698218: ldur            w1, [x0, #0x37]
    // 0x69821c: DecompressPointer r1
    //     0x69821c: add             x1, x1, HEAP, lsl #32
    // 0x698220: r2 = Instance_Chapter11Stat
    //     0x698220: add             x2, PP, #0x11, lsl #12  ; [pp+0x11560] Obj!Chapter11Stat@85fde1
    //     0x698224: ldr             x2, [x2, #0x560]
    // 0x698228: r0 = remove()
    //     0x698228: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69822c: ldur            x0, [fp, #-8]
    // 0x698230: LoadField: r1 = r0->field_3b
    //     0x698230: ldur            w1, [x0, #0x3b]
    // 0x698234: DecompressPointer r1
    //     0x698234: add             x1, x1, HEAP, lsl #32
    // 0x698238: r2 = Instance_Chapter11Stat
    //     0x698238: add             x2, PP, #0x11, lsl #12  ; [pp+0x11560] Obj!Chapter11Stat@85fde1
    //     0x69823c: ldr             x2, [x2, #0x560]
    // 0x698240: r0 = remove()
    //     0x698240: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698244: ldur            x0, [fp, #-8]
    // 0x698248: LoadField: r1 = r0->field_37
    //     0x698248: ldur            w1, [x0, #0x37]
    // 0x69824c: DecompressPointer r1
    //     0x69824c: add             x1, x1, HEAP, lsl #32
    // 0x698250: r2 = Instance_Chapter11Stat
    //     0x698250: add             x2, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Chapter11Stat@85fdc1
    //     0x698254: ldr             x2, [x2, #0x568]
    // 0x698258: r0 = remove()
    //     0x698258: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69825c: ldur            x0, [fp, #-8]
    // 0x698260: LoadField: r1 = r0->field_3b
    //     0x698260: ldur            w1, [x0, #0x3b]
    // 0x698264: DecompressPointer r1
    //     0x698264: add             x1, x1, HEAP, lsl #32
    // 0x698268: r2 = Instance_Chapter11Stat
    //     0x698268: add             x2, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Chapter11Stat@85fdc1
    //     0x69826c: ldr             x2, [x2, #0x568]
    // 0x698270: r0 = remove()
    //     0x698270: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698274: ldur            x0, [fp, #-8]
    // 0x698278: LoadField: r1 = r0->field_37
    //     0x698278: ldur            w1, [x0, #0x37]
    // 0x69827c: DecompressPointer r1
    //     0x69827c: add             x1, x1, HEAP, lsl #32
    // 0x698280: r2 = Instance_Chapter11Stat
    //     0x698280: add             x2, PP, #0x11, lsl #12  ; [pp+0x11570] Obj!Chapter11Stat@85fda1
    //     0x698284: ldr             x2, [x2, #0x570]
    // 0x698288: r0 = remove()
    //     0x698288: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69828c: ldur            x0, [fp, #-8]
    // 0x698290: LoadField: r1 = r0->field_3b
    //     0x698290: ldur            w1, [x0, #0x3b]
    // 0x698294: DecompressPointer r1
    //     0x698294: add             x1, x1, HEAP, lsl #32
    // 0x698298: r2 = Instance_Chapter11Stat
    //     0x698298: add             x2, PP, #0x11, lsl #12  ; [pp+0x11570] Obj!Chapter11Stat@85fda1
    //     0x69829c: ldr             x2, [x2, #0x570]
    // 0x6982a0: r0 = remove()
    //     0x6982a0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6982a4: ldur            x0, [fp, #-8]
    // 0x6982a8: LoadField: r3 = r0->field_43
    //     0x6982a8: ldur            w3, [x0, #0x43]
    // 0x6982ac: DecompressPointer r3
    //     0x6982ac: add             x3, x3, HEAP, lsl #32
    // 0x6982b0: mov             x1, x3
    // 0x6982b4: stur            x3, [fp, #-0x10]
    // 0x6982b8: r2 = 28
    //     0x6982b8: movz            x2, #0x1c
    // 0x6982bc: r0 = _getValueOrData()
    //     0x6982bc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6982c0: mov             x1, x0
    // 0x6982c4: ldur            x0, [fp, #-0x10]
    // 0x6982c8: LoadField: r2 = r0->field_f
    //     0x6982c8: ldur            w2, [x0, #0xf]
    // 0x6982cc: DecompressPointer r2
    //     0x6982cc: add             x2, x2, HEAP, lsl #32
    // 0x6982d0: cmp             w2, w1
    // 0x6982d4: b.ne            #0x6982e0
    // 0x6982d8: r0 = Null
    //     0x6982d8: mov             x0, NULL
    // 0x6982dc: b               #0x6982e4
    // 0x6982e0: mov             x0, x1
    // 0x6982e4: cmp             w0, NULL
    // 0x6982e8: b.ne            #0x6982f4
    // 0x6982ec: r0 = 0
    //     0x6982ec: movz            x0, #0
    // 0x6982f0: b               #0x698304
    // 0x6982f4: r1 = LoadInt32Instr(r0)
    //     0x6982f4: sbfx            x1, x0, #1, #0x1f
    //     0x6982f8: tbz             w0, #0, #0x698300
    //     0x6982fc: ldur            x1, [x0, #7]
    // 0x698300: mov             x0, x1
    // 0x698304: cmp             x0, #2
    // 0x698308: b.ge            #0x69835c
    // 0x69830c: ldur            x0, [fp, #-8]
    // 0x698310: LoadField: r1 = r0->field_43
    //     0x698310: ldur            w1, [x0, #0x43]
    // 0x698314: DecompressPointer r1
    //     0x698314: add             x1, x1, HEAP, lsl #32
    // 0x698318: r2 = 22
    //     0x698318: movz            x2, #0x16
    // 0x69831c: r0 = remove()
    //     0x69831c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698320: ldur            x0, [fp, #-8]
    // 0x698324: LoadField: r1 = r0->field_43
    //     0x698324: ldur            w1, [x0, #0x43]
    // 0x698328: DecompressPointer r1
    //     0x698328: add             x1, x1, HEAP, lsl #32
    // 0x69832c: r2 = 24
    //     0x69832c: movz            x2, #0x18
    // 0x698330: r0 = remove()
    //     0x698330: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698334: ldur            x0, [fp, #-8]
    // 0x698338: LoadField: r1 = r0->field_43
    //     0x698338: ldur            w1, [x0, #0x43]
    // 0x69833c: DecompressPointer r1
    //     0x69833c: add             x1, x1, HEAP, lsl #32
    // 0x698340: r2 = 26
    //     0x698340: movz            x2, #0x1a
    // 0x698344: r0 = remove()
    //     0x698344: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698348: ldur            x0, [fp, #-8]
    // 0x69834c: LoadField: r1 = r0->field_43
    //     0x69834c: ldur            w1, [x0, #0x43]
    // 0x698350: DecompressPointer r1
    //     0x698350: add             x1, x1, HEAP, lsl #32
    // 0x698354: r2 = 28
    //     0x698354: movz            x2, #0x1c
    // 0x698358: r0 = remove()
    //     0x698358: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69835c: ldur            x0, [fp, #-8]
    // 0x698360: LoadField: r1 = r0->field_47
    //     0x698360: ldur            w1, [x0, #0x47]
    // 0x698364: DecompressPointer r1
    //     0x698364: add             x1, x1, HEAP, lsl #32
    // 0x698368: r2 = 62
    //     0x698368: movz            x2, #0x3e
    // 0x69836c: r0 = remove()
    //     0x69836c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698370: ldur            x0, [fp, #-8]
    // 0x698374: LoadField: r1 = r0->field_47
    //     0x698374: ldur            w1, [x0, #0x47]
    // 0x698378: DecompressPointer r1
    //     0x698378: add             x1, x1, HEAP, lsl #32
    // 0x69837c: r2 = 64
    //     0x69837c: movz            x2, #0x40
    // 0x698380: r0 = remove()
    //     0x698380: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698384: ldur            x0, [fp, #-8]
    // 0x698388: LoadField: r1 = r0->field_47
    //     0x698388: ldur            w1, [x0, #0x47]
    // 0x69838c: DecompressPointer r1
    //     0x69838c: add             x1, x1, HEAP, lsl #32
    // 0x698390: r2 = 66
    //     0x698390: movz            x2, #0x42
    // 0x698394: r0 = remove()
    //     0x698394: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698398: ldur            x0, [fp, #-8]
    // 0x69839c: LoadField: r1 = r0->field_43
    //     0x69839c: ldur            w1, [x0, #0x43]
    // 0x6983a0: DecompressPointer r1
    //     0x6983a0: add             x1, x1, HEAP, lsl #32
    // 0x6983a4: r2 = 28
    //     0x6983a4: movz            x2, #0x1c
    // 0x6983a8: r0 = containsKey()
    //     0x6983a8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6983ac: tbz             w0, #4, #0x698410
    // 0x6983b0: ldur            x0, [fp, #-8]
    // 0x6983b4: LoadField: r1 = r0->field_43
    //     0x6983b4: ldur            w1, [x0, #0x43]
    // 0x6983b8: DecompressPointer r1
    //     0x6983b8: add             x1, x1, HEAP, lsl #32
    // 0x6983bc: r2 = 2
    //     0x6983bc: movz            x2, #0x2
    // 0x6983c0: r0 = remove()
    //     0x6983c0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6983c4: ldur            x0, [fp, #-8]
    // 0x6983c8: LoadField: r1 = r0->field_43
    //     0x6983c8: ldur            w1, [x0, #0x43]
    // 0x6983cc: DecompressPointer r1
    //     0x6983cc: add             x1, x1, HEAP, lsl #32
    // 0x6983d0: r2 = 4
    //     0x6983d0: movz            x2, #0x4
    // 0x6983d4: r0 = remove()
    //     0x6983d4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6983d8: ldur            x0, [fp, #-8]
    // 0x6983dc: LoadField: r1 = r0->field_43
    //     0x6983dc: ldur            w1, [x0, #0x43]
    // 0x6983e0: DecompressPointer r1
    //     0x6983e0: add             x1, x1, HEAP, lsl #32
    // 0x6983e4: r2 = 6
    //     0x6983e4: movz            x2, #0x6
    // 0x6983e8: r0 = remove()
    //     0x6983e8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6983ec: ldur            x0, [fp, #-8]
    // 0x6983f0: LoadField: r1 = r0->field_53
    //     0x6983f0: ldur            w1, [x0, #0x53]
    // 0x6983f4: DecompressPointer r1
    //     0x6983f4: add             x1, x1, HEAP, lsl #32
    // 0x6983f8: r2 = 2
    //     0x6983f8: movz            x2, #0x2
    // 0x6983fc: r0 = remove()
    //     0x6983fc: bl              #0x7e8a40  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x698400: ldur            x0, [fp, #-8]
    // 0x698404: LoadField: r1 = r0->field_4b
    //     0x698404: ldur            w1, [x0, #0x4b]
    // 0x698408: DecompressPointer r1
    //     0x698408: add             x1, x1, HEAP, lsl #32
    // 0x69840c: r0 = clear()
    //     0x69840c: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x698410: ldur            x0, [fp, #-8]
    // 0x698414: LoadField: r1 = r0->field_4b
    //     0x698414: ldur            w1, [x0, #0x4b]
    // 0x698418: DecompressPointer r1
    //     0x698418: add             x1, x1, HEAP, lsl #32
    // 0x69841c: r0 = clear()
    //     0x69841c: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x698420: ldur            x1, [fp, #-8]
    // 0x698424: r0 = resetAndRecomputeBoosts()
    //     0x698424: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x698428: r0 = Null
    //     0x698428: mov             x0, NULL
    // 0x69842c: LeaveFrame
    //     0x69842c: mov             SP, fp
    //     0x698430: ldp             fp, lr, [SP], #0x10
    // 0x698434: ret
    //     0x698434: ret             
    // 0x698438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698438: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69843c: b               #0x698084
  }
  _ goldPrestige(/* No info */) {
    // ** addr: 0x698440, size: 0x564
    // 0x698440: EnterFrame
    //     0x698440: stp             fp, lr, [SP, #-0x10]!
    //     0x698444: mov             fp, SP
    // 0x698448: AllocStack(0x28)
    //     0x698448: sub             SP, SP, #0x28
    // 0x69844c: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x8 */)
    //     0x69844c: mov             x0, x1
    //     0x698450: stur            x1, [fp, #-8]
    // 0x698454: CheckStackOverflow
    //     0x698454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x698458: cmp             SP, x16
    //     0x69845c: b.ls            #0x698984
    // 0x698460: mov             x1, x0
    // 0x698464: r0 = goldPrestigePoints()
    //     0x698464: bl              #0x54d718  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestigePoints
    // 0x698468: ldur            x1, [fp, #-8]
    // 0x69846c: stur            x0, [fp, #-0x10]
    // 0x698470: r0 = silverPrestige()
    //     0x698470: bl              #0x6989a4  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestige
    // 0x698474: ldur            x0, [fp, #-8]
    // 0x698478: LoadField: r3 = r0->field_37
    //     0x698478: ldur            w3, [x0, #0x37]
    // 0x69847c: DecompressPointer r3
    //     0x69847c: add             x3, x3, HEAP, lsl #32
    // 0x698480: mov             x1, x3
    // 0x698484: stur            x3, [fp, #-0x18]
    // 0x698488: r2 = Instance_Chapter11Stat
    //     0x698488: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x69848c: ldr             x2, [x2, #0x5e0]
    // 0x698490: r0 = _getValueOrData()
    //     0x698490: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698494: mov             x1, x0
    // 0x698498: ldur            x0, [fp, #-0x18]
    // 0x69849c: LoadField: r2 = r0->field_f
    //     0x69849c: ldur            w2, [x0, #0xf]
    // 0x6984a0: DecompressPointer r2
    //     0x6984a0: add             x2, x2, HEAP, lsl #32
    // 0x6984a4: cmp             w2, w1
    // 0x6984a8: b.ne            #0x6984b0
    // 0x6984ac: r1 = Null
    //     0x6984ac: mov             x1, NULL
    // 0x6984b0: cmp             w1, NULL
    // 0x6984b4: b.ne            #0x6984c0
    // 0x6984b8: r1 = Instance_CustomNum
    //     0x6984b8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6984bc: ldr             x1, [x1, #0xaf8]
    // 0x6984c0: ldur            x3, [fp, #-8]
    // 0x6984c4: ldur            x2, [fp, #-0x10]
    // 0x6984c8: r0 = add()
    //     0x6984c8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6984cc: ldur            x1, [fp, #-0x18]
    // 0x6984d0: mov             x3, x0
    // 0x6984d4: r2 = Instance_Chapter11Stat
    //     0x6984d4: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x6984d8: ldr             x2, [x2, #0x5e0]
    // 0x6984dc: r0 = []=()
    //     0x6984dc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6984e0: ldur            x0, [fp, #-8]
    // 0x6984e4: LoadField: r3 = r0->field_3b
    //     0x6984e4: ldur            w3, [x0, #0x3b]
    // 0x6984e8: DecompressPointer r3
    //     0x6984e8: add             x3, x3, HEAP, lsl #32
    // 0x6984ec: mov             x1, x3
    // 0x6984f0: stur            x3, [fp, #-0x18]
    // 0x6984f4: r2 = Instance_Chapter11Stat
    //     0x6984f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x6984f8: ldr             x2, [x2, #0x5e0]
    // 0x6984fc: r0 = _getValueOrData()
    //     0x6984fc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698500: mov             x1, x0
    // 0x698504: ldur            x0, [fp, #-0x18]
    // 0x698508: LoadField: r2 = r0->field_f
    //     0x698508: ldur            w2, [x0, #0xf]
    // 0x69850c: DecompressPointer r2
    //     0x69850c: add             x2, x2, HEAP, lsl #32
    // 0x698510: cmp             w2, w1
    // 0x698514: b.ne            #0x69851c
    // 0x698518: r1 = Null
    //     0x698518: mov             x1, NULL
    // 0x69851c: cmp             w1, NULL
    // 0x698520: b.ne            #0x69852c
    // 0x698524: r1 = Instance_CustomNum
    //     0x698524: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698528: ldr             x1, [x1, #0xaf8]
    // 0x69852c: ldur            x3, [fp, #-8]
    // 0x698530: ldur            x2, [fp, #-0x10]
    // 0x698534: r0 = add()
    //     0x698534: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x698538: ldur            x1, [fp, #-0x18]
    // 0x69853c: mov             x3, x0
    // 0x698540: r2 = Instance_Chapter11Stat
    //     0x698540: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x698544: ldr             x2, [x2, #0x5e0]
    // 0x698548: r0 = []=()
    //     0x698548: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69854c: ldur            x0, [fp, #-8]
    // 0x698550: LoadField: r1 = r0->field_13
    //     0x698550: ldur            w1, [x0, #0x13]
    // 0x698554: DecompressPointer r1
    //     0x698554: add             x1, x1, HEAP, lsl #32
    // 0x698558: r2 = 8
    //     0x698558: movz            x2, #0x8
    // 0x69855c: r0 = add()
    //     0x69855c: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x698560: ldur            x0, [fp, #-8]
    // 0x698564: LoadField: r1 = r0->field_43
    //     0x698564: ldur            w1, [x0, #0x43]
    // 0x698568: DecompressPointer r1
    //     0x698568: add             x1, x1, HEAP, lsl #32
    // 0x69856c: r2 = 24
    //     0x69856c: movz            x2, #0x18
    // 0x698570: r0 = containsKey()
    //     0x698570: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x698574: tbz             w0, #4, #0x698584
    // 0x698578: r3 = Instance_CustomNum
    //     0x698578: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x69857c: ldr             x3, [x3, #0xaf8]
    // 0x698580: b               #0x6987c8
    // 0x698584: ldur            x0, [fp, #-8]
    // 0x698588: LoadField: r3 = r0->field_43
    //     0x698588: ldur            w3, [x0, #0x43]
    // 0x69858c: DecompressPointer r3
    //     0x69858c: add             x3, x3, HEAP, lsl #32
    // 0x698590: mov             x1, x3
    // 0x698594: stur            x3, [fp, #-0x10]
    // 0x698598: r2 = 24
    //     0x698598: movz            x2, #0x18
    // 0x69859c: r0 = _getValueOrData()
    //     0x69859c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6985a0: mov             x1, x0
    // 0x6985a4: ldur            x0, [fp, #-0x10]
    // 0x6985a8: LoadField: r2 = r0->field_f
    //     0x6985a8: ldur            w2, [x0, #0xf]
    // 0x6985ac: DecompressPointer r2
    //     0x6985ac: add             x2, x2, HEAP, lsl #32
    // 0x6985b0: cmp             w2, w1
    // 0x6985b4: b.ne            #0x6985c0
    // 0x6985b8: r0 = Null
    //     0x6985b8: mov             x0, NULL
    // 0x6985bc: b               #0x6985c4
    // 0x6985c0: mov             x0, x1
    // 0x6985c4: cmp             w0, NULL
    // 0x6985c8: b.ne            #0x6985d4
    // 0x6985cc: r2 = 0
    //     0x6985cc: movz            x2, #0
    // 0x6985d0: b               #0x6985e4
    // 0x6985d4: r1 = LoadInt32Instr(r0)
    //     0x6985d4: sbfx            x1, x0, #1, #0x1f
    //     0x6985d8: tbz             w0, #0, #0x6985e0
    //     0x6985dc: ldur            x1, [x0, #7]
    // 0x6985e0: mov             x2, x1
    // 0x6985e4: r0 = BoxInt64Instr(r2)
    //     0x6985e4: sbfiz           x0, x2, #1, #0x1f
    //     0x6985e8: cmp             x2, x0, asr #1
    //     0x6985ec: b.eq            #0x6985f8
    //     0x6985f0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6985f4: stur            x2, [x0, #7]
    // 0x6985f8: stur            x0, [fp, #-0x10]
    // 0x6985fc: tbnz            x2, #0x3f, #0x698658
    // 0x698600: mov             x0, x2
    // 0x698604: r1 = 2
    //     0x698604: movz            x1, #0x2
    // 0x698608: r2 = 1
    //     0x698608: movz            x2, #0x1
    // 0x69860c: CheckStackOverflow
    //     0x69860c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x698610: cmp             SP, x16
    //     0x698614: b.ls            #0x69898c
    // 0x698618: cbz             x0, #0x698640
    // 0x69861c: branchIfSmi(r0, 0x698628)
    //     0x69861c: tbz             w0, #0, #0x698628
    // 0x698620: mul             x3, x2, x1
    // 0x698624: mov             x2, x3
    // 0x698628: asr             x3, x0, #1
    // 0x69862c: cbz             x3, #0x698638
    // 0x698630: mul             x4, x1, x1
    // 0x698634: mov             x1, x4
    // 0x698638: mov             x0, x3
    // 0x69863c: b               #0x69860c
    // 0x698640: r0 = BoxInt64Instr(r2)
    //     0x698640: sbfiz           x0, x2, #1, #0x1f
    //     0x698644: cmp             x2, x0, asr #1
    //     0x698648: b.eq            #0x698654
    //     0x69864c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x698650: stur            x2, [x0, #7]
    // 0x698654: b               #0x6987a8
    // 0x698658: r16 = 4
    //     0x698658: movz            x16, #0x4
    // 0x69865c: stp             x16, NULL, [SP]
    // 0x698660: r0 = _Double.fromInteger()
    //     0x698660: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x698664: mov             x1, x0
    // 0x698668: ldur            x0, [fp, #-0x10]
    // 0x69866c: stur            x1, [fp, #-0x18]
    // 0x698670: r2 = 60
    //     0x698670: movz            x2, #0x3c
    // 0x698674: branchIfSmi(r0, 0x698680)
    //     0x698674: tbz             w0, #0, #0x698680
    // 0x698678: r2 = LoadClassIdInstr(r0)
    //     0x698678: ldur            x2, [x0, #-1]
    //     0x69867c: ubfx            x2, x2, #0xc, #0x14
    // 0x698680: str             x0, [SP]
    // 0x698684: mov             x0, x2
    // 0x698688: r0 = GDT[cid_x0 + -0x1000]()
    //     0x698688: sub             lr, x0, #1, lsl #12
    //     0x69868c: ldr             lr, [x21, lr, lsl #3]
    //     0x698690: blr             lr
    // 0x698694: mov             x1, x0
    // 0x698698: ldur            x0, [fp, #-0x18]
    // 0x69869c: LoadField: d0 = r0->field_7
    //     0x69869c: ldur            d0, [x0, #7]
    // 0x6986a0: LoadField: d1 = r1->field_7
    //     0x6986a0: ldur            d1, [x1, #7]
    // 0x6986a4: d30 = 0.000000
    //     0x6986a4: fmov            d30, d0
    // 0x6986a8: d0 = 1.000000
    //     0x6986a8: fmov            d0, #1.00000000
    // 0x6986ac: fcmp            d1, #0.0
    // 0x6986b0: b.vs            #0x6986f4
    // 0x6986b4: b.eq            #0x69877c
    // 0x6986b8: fcmp            d1, d0
    // 0x6986bc: b.eq            #0x6986e4
    // 0x6986c0: d31 = 2.000000
    //     0x6986c0: fmov            d31, #2.00000000
    // 0x6986c4: fcmp            d1, d31
    // 0x6986c8: b.eq            #0x6986ec
    // 0x6986cc: d31 = 3.000000
    //     0x6986cc: fmov            d31, #3.00000000
    // 0x6986d0: fcmp            d1, d31
    // 0x6986d4: b.ne            #0x6986f4
    // 0x6986d8: fmul            d0, d30, d30
    // 0x6986dc: fmul            d0, d0, d30
    // 0x6986e0: b               #0x69877c
    // 0x6986e4: d0 = 0.000000
    //     0x6986e4: fmov            d0, d30
    // 0x6986e8: b               #0x69877c
    // 0x6986ec: fmul            d0, d30, d30
    // 0x6986f0: b               #0x69877c
    // 0x6986f4: fcmp            d30, d0
    // 0x6986f8: b.vs            #0x698708
    // 0x6986fc: b.eq            #0x69877c
    // 0x698700: fcmp            d30, d1
    // 0x698704: b.vc            #0x698714
    // 0x698708: d0 = nan
    //     0x698708: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x69870c: ldr             d0, [x17, #0xe48]
    // 0x698710: b               #0x69877c
    // 0x698714: d0 = -inf
    //     0x698714: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x698718: fcmp            d30, d0
    // 0x69871c: b.eq            #0x698744
    // 0x698720: d0 = 0.500000
    //     0x698720: fmov            d0, #0.50000000
    // 0x698724: fcmp            d1, d0
    // 0x698728: b.ne            #0x698744
    // 0x69872c: fcmp            d30, #0.0
    // 0x698730: b.eq            #0x69873c
    // 0x698734: fsqrt           d0, d30
    // 0x698738: b               #0x69877c
    // 0x69873c: d0 = 0.000000
    //     0x69873c: eor             v0.16b, v0.16b, v0.16b
    // 0x698740: b               #0x69877c
    // 0x698744: d0 = 0.000000
    //     0x698744: fmov            d0, d30
    // 0x698748: stp             fp, lr, [SP, #-0x10]!
    // 0x69874c: mov             fp, SP
    // 0x698750: CallRuntime_LibcPow(double, double) -> double
    //     0x698750: and             SP, SP, #0xfffffffffffffff0
    //     0x698754: mov             sp, SP
    //     0x698758: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x69875c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x698760: blr             x16
    //     0x698764: movz            x16, #0x8
    //     0x698768: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x69876c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x698770: sub             sp, x16, #1, lsl #12
    //     0x698774: mov             SP, fp
    //     0x698778: ldp             fp, lr, [SP], #0x10
    // 0x69877c: r0 = inline_Allocate_Double()
    //     0x69877c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x698780: add             x0, x0, #0x10
    //     0x698784: cmp             x1, x0
    //     0x698788: b.ls            #0x698994
    //     0x69878c: str             x0, [THR, #0x60]  ; THR::top
    //     0x698790: sub             x0, x0, #0xf
    //     0x698794: movz            x1, #0xe19c
    //     0x698798: movk            x1, #0x3, lsl #16
    //     0x69879c: stur            x1, [x0, #-1]
    // 0x6987a0: dmb             ishst
    // 0x6987a4: StoreField: r0->field_7 = d0
    //     0x6987a4: stur            d0, [x0, #7]
    // 0x6987a8: r16 = 0.010000
    //     0x6987a8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x6987ac: ldr             x16, [x16, #0xaa0]
    // 0x6987b0: stp             x0, x16, [SP]
    // 0x6987b4: r0 = *()
    //     0x6987b4: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x6987b8: mov             x2, x0
    // 0x6987bc: r1 = Null
    //     0x6987bc: mov             x1, NULL
    // 0x6987c0: r0 = CustomNum()
    //     0x6987c0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6987c4: mov             x3, x0
    // 0x6987c8: ldur            x0, [fp, #-8]
    // 0x6987cc: stur            x3, [fp, #-0x10]
    // 0x6987d0: LoadField: r1 = r0->field_37
    //     0x6987d0: ldur            w1, [x0, #0x37]
    // 0x6987d4: DecompressPointer r1
    //     0x6987d4: add             x1, x1, HEAP, lsl #32
    // 0x6987d8: r2 = Instance_Chapter11Stat
    //     0x6987d8: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x6987dc: ldr             x2, [x2, #0x5c0]
    // 0x6987e0: r0 = remove()
    //     0x6987e0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6987e4: ldur            x0, [fp, #-8]
    // 0x6987e8: LoadField: r1 = r0->field_3b
    //     0x6987e8: ldur            w1, [x0, #0x3b]
    // 0x6987ec: DecompressPointer r1
    //     0x6987ec: add             x1, x1, HEAP, lsl #32
    // 0x6987f0: r2 = Instance_Chapter11Stat
    //     0x6987f0: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x6987f4: ldr             x2, [x2, #0x5c0]
    // 0x6987f8: r0 = remove()
    //     0x6987f8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6987fc: ldur            x0, [fp, #-8]
    // 0x698800: LoadField: r3 = r0->field_37
    //     0x698800: ldur            w3, [x0, #0x37]
    // 0x698804: DecompressPointer r3
    //     0x698804: add             x3, x3, HEAP, lsl #32
    // 0x698808: mov             x1, x3
    // 0x69880c: stur            x3, [fp, #-0x18]
    // 0x698810: r2 = Instance_Chapter11Stat
    //     0x698810: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x698814: ldr             x2, [x2, #0x5d0]
    // 0x698818: r0 = _getValueOrData()
    //     0x698818: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x69881c: mov             x1, x0
    // 0x698820: ldur            x0, [fp, #-0x18]
    // 0x698824: LoadField: r2 = r0->field_f
    //     0x698824: ldur            w2, [x0, #0xf]
    // 0x698828: DecompressPointer r2
    //     0x698828: add             x2, x2, HEAP, lsl #32
    // 0x69882c: cmp             w2, w1
    // 0x698830: b.ne            #0x698838
    // 0x698834: r1 = Null
    //     0x698834: mov             x1, NULL
    // 0x698838: cmp             w1, NULL
    // 0x69883c: b.ne            #0x69884c
    // 0x698840: r2 = Instance_CustomNum
    //     0x698840: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698844: ldr             x2, [x2, #0xaf8]
    // 0x698848: b               #0x698850
    // 0x69884c: mov             x2, x1
    // 0x698850: ldur            x3, [fp, #-8]
    // 0x698854: ldur            x1, [fp, #-0x10]
    // 0x698858: r0 = mult2()
    //     0x698858: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x69885c: ldur            x1, [fp, #-0x18]
    // 0x698860: mov             x3, x0
    // 0x698864: r2 = Instance_Chapter11Stat
    //     0x698864: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x698868: ldr             x2, [x2, #0x5d0]
    // 0x69886c: r0 = []=()
    //     0x69886c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x698870: ldur            x0, [fp, #-8]
    // 0x698874: LoadField: r1 = r0->field_3b
    //     0x698874: ldur            w1, [x0, #0x3b]
    // 0x698878: DecompressPointer r1
    //     0x698878: add             x1, x1, HEAP, lsl #32
    // 0x69887c: r2 = Instance_Chapter11Stat
    //     0x69887c: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x698880: ldr             x2, [x2, #0x5d0]
    // 0x698884: r0 = remove()
    //     0x698884: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698888: ldur            x0, [fp, #-8]
    // 0x69888c: LoadField: r1 = r0->field_47
    //     0x69888c: ldur            w1, [x0, #0x47]
    // 0x698890: DecompressPointer r1
    //     0x698890: add             x1, x1, HEAP, lsl #32
    // 0x698894: r2 = 40
    //     0x698894: movz            x2, #0x28
    // 0x698898: r0 = remove()
    //     0x698898: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69889c: ldur            x0, [fp, #-8]
    // 0x6988a0: LoadField: r1 = r0->field_47
    //     0x6988a0: ldur            w1, [x0, #0x47]
    // 0x6988a4: DecompressPointer r1
    //     0x6988a4: add             x1, x1, HEAP, lsl #32
    // 0x6988a8: r2 = 42
    //     0x6988a8: movz            x2, #0x2a
    // 0x6988ac: r0 = remove()
    //     0x6988ac: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6988b0: ldur            x0, [fp, #-8]
    // 0x6988b4: LoadField: r1 = r0->field_47
    //     0x6988b4: ldur            w1, [x0, #0x47]
    // 0x6988b8: DecompressPointer r1
    //     0x6988b8: add             x1, x1, HEAP, lsl #32
    // 0x6988bc: r2 = 44
    //     0x6988bc: movz            x2, #0x2c
    // 0x6988c0: r0 = remove()
    //     0x6988c0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6988c4: ldur            x0, [fp, #-8]
    // 0x6988c8: LoadField: r3 = r0->field_43
    //     0x6988c8: ldur            w3, [x0, #0x43]
    // 0x6988cc: DecompressPointer r3
    //     0x6988cc: add             x3, x3, HEAP, lsl #32
    // 0x6988d0: mov             x1, x3
    // 0x6988d4: stur            x3, [fp, #-0x10]
    // 0x6988d8: r2 = 28
    //     0x6988d8: movz            x2, #0x1c
    // 0x6988dc: r0 = _getValueOrData()
    //     0x6988dc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6988e0: mov             x1, x0
    // 0x6988e4: ldur            x0, [fp, #-0x10]
    // 0x6988e8: LoadField: r2 = r0->field_f
    //     0x6988e8: ldur            w2, [x0, #0xf]
    // 0x6988ec: DecompressPointer r2
    //     0x6988ec: add             x2, x2, HEAP, lsl #32
    // 0x6988f0: cmp             w2, w1
    // 0x6988f4: b.ne            #0x698900
    // 0x6988f8: r0 = Null
    //     0x6988f8: mov             x0, NULL
    // 0x6988fc: b               #0x698904
    // 0x698900: mov             x0, x1
    // 0x698904: cmp             w0, NULL
    // 0x698908: b.ne            #0x698914
    // 0x69890c: r0 = 0
    //     0x69890c: movz            x0, #0
    // 0x698910: b               #0x698924
    // 0x698914: r1 = LoadInt32Instr(r0)
    //     0x698914: sbfx            x1, x0, #1, #0x1f
    //     0x698918: tbz             w0, #0, #0x698920
    //     0x69891c: ldur            x1, [x0, #7]
    // 0x698920: mov             x0, x1
    // 0x698924: cmp             x0, #3
    // 0x698928: b.ge            #0x69896c
    // 0x69892c: ldur            x0, [fp, #-8]
    // 0x698930: LoadField: r1 = r0->field_3f
    //     0x698930: ldur            w1, [x0, #0x3f]
    // 0x698934: DecompressPointer r1
    //     0x698934: add             x1, x1, HEAP, lsl #32
    // 0x698938: LoadField: r2 = r1->field_b
    //     0x698938: ldur            w2, [x1, #0xb]
    // 0x69893c: DecompressPointer r2
    //     0x69893c: add             x2, x2, HEAP, lsl #32
    // 0x698940: mov             x1, x2
    // 0x698944: r2 = 2
    //     0x698944: movz            x2, #0x2
    // 0x698948: r0 = remove()
    //     0x698948: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69894c: ldur            x0, [fp, #-8]
    // 0x698950: LoadField: r1 = r0->field_3f
    //     0x698950: ldur            w1, [x0, #0x3f]
    // 0x698954: DecompressPointer r1
    //     0x698954: add             x1, x1, HEAP, lsl #32
    // 0x698958: LoadField: r2 = r1->field_b
    //     0x698958: ldur            w2, [x1, #0xb]
    // 0x69895c: DecompressPointer r2
    //     0x69895c: add             x2, x2, HEAP, lsl #32
    // 0x698960: mov             x1, x2
    // 0x698964: r2 = 4
    //     0x698964: movz            x2, #0x4
    // 0x698968: r0 = remove()
    //     0x698968: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x69896c: ldur            x1, [fp, #-8]
    // 0x698970: r0 = resetAndRecomputeBoosts()
    //     0x698970: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x698974: r0 = Null
    //     0x698974: mov             x0, NULL
    // 0x698978: LeaveFrame
    //     0x698978: mov             SP, fp
    //     0x69897c: ldp             fp, lr, [SP], #0x10
    // 0x698980: ret
    //     0x698980: ret             
    // 0x698984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698984: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698988: b               #0x698460
    // 0x69898c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69898c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698990: b               #0x698618
    // 0x698994: SaveReg d0
    //     0x698994: str             q0, [SP, #-0x10]!
    // 0x698998: r0 = AllocateDouble()
    //     0x698998: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x69899c: RestoreReg d0
    //     0x69899c: ldr             q0, [SP], #0x10
    // 0x6989a0: b               #0x6987a4
  }
  _ silverPrestige(/* No info */) {
    // ** addr: 0x6989a4, size: 0x570
    // 0x6989a4: EnterFrame
    //     0x6989a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6989a8: mov             fp, SP
    // 0x6989ac: AllocStack(0x28)
    //     0x6989ac: sub             SP, SP, #0x28
    // 0x6989b0: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x8 */)
    //     0x6989b0: mov             x0, x1
    //     0x6989b4: stur            x1, [fp, #-8]
    // 0x6989b8: CheckStackOverflow
    //     0x6989b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6989bc: cmp             SP, x16
    //     0x6989c0: b.ls            #0x698ef4
    // 0x6989c4: mov             x1, x0
    // 0x6989c8: r0 = silverPrestigePoints()
    //     0x6989c8: bl              #0x54d7fc  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestigePoints
    // 0x6989cc: mov             x3, x0
    // 0x6989d0: ldur            x0, [fp, #-8]
    // 0x6989d4: stur            x3, [fp, #-0x18]
    // 0x6989d8: LoadField: r4 = r0->field_37
    //     0x6989d8: ldur            w4, [x0, #0x37]
    // 0x6989dc: DecompressPointer r4
    //     0x6989dc: add             x4, x4, HEAP, lsl #32
    // 0x6989e0: mov             x1, x4
    // 0x6989e4: stur            x4, [fp, #-0x10]
    // 0x6989e8: r2 = Instance_Chapter11Stat
    //     0x6989e8: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x6989ec: ldr             x2, [x2, #0x5c0]
    // 0x6989f0: r0 = _getValueOrData()
    //     0x6989f0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6989f4: mov             x1, x0
    // 0x6989f8: ldur            x0, [fp, #-0x10]
    // 0x6989fc: LoadField: r2 = r0->field_f
    //     0x6989fc: ldur            w2, [x0, #0xf]
    // 0x698a00: DecompressPointer r2
    //     0x698a00: add             x2, x2, HEAP, lsl #32
    // 0x698a04: cmp             w2, w1
    // 0x698a08: b.ne            #0x698a10
    // 0x698a0c: r1 = Null
    //     0x698a0c: mov             x1, NULL
    // 0x698a10: cmp             w1, NULL
    // 0x698a14: b.ne            #0x698a20
    // 0x698a18: r1 = Instance_CustomNum
    //     0x698a18: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698a1c: ldr             x1, [x1, #0xaf8]
    // 0x698a20: ldur            x3, [fp, #-8]
    // 0x698a24: ldur            x2, [fp, #-0x18]
    // 0x698a28: r0 = add()
    //     0x698a28: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x698a2c: ldur            x1, [fp, #-0x10]
    // 0x698a30: mov             x3, x0
    // 0x698a34: r2 = Instance_Chapter11Stat
    //     0x698a34: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x698a38: ldr             x2, [x2, #0x5c0]
    // 0x698a3c: r0 = []=()
    //     0x698a3c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x698a40: ldur            x0, [fp, #-8]
    // 0x698a44: LoadField: r3 = r0->field_3b
    //     0x698a44: ldur            w3, [x0, #0x3b]
    // 0x698a48: DecompressPointer r3
    //     0x698a48: add             x3, x3, HEAP, lsl #32
    // 0x698a4c: mov             x1, x3
    // 0x698a50: stur            x3, [fp, #-0x10]
    // 0x698a54: r2 = Instance_Chapter11Stat
    //     0x698a54: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x698a58: ldr             x2, [x2, #0x5c0]
    // 0x698a5c: r0 = _getValueOrData()
    //     0x698a5c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698a60: mov             x1, x0
    // 0x698a64: ldur            x0, [fp, #-0x10]
    // 0x698a68: LoadField: r2 = r0->field_f
    //     0x698a68: ldur            w2, [x0, #0xf]
    // 0x698a6c: DecompressPointer r2
    //     0x698a6c: add             x2, x2, HEAP, lsl #32
    // 0x698a70: cmp             w2, w1
    // 0x698a74: b.ne            #0x698a7c
    // 0x698a78: r1 = Null
    //     0x698a78: mov             x1, NULL
    // 0x698a7c: cmp             w1, NULL
    // 0x698a80: b.ne            #0x698a8c
    // 0x698a84: r1 = Instance_CustomNum
    //     0x698a84: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698a88: ldr             x1, [x1, #0xaf8]
    // 0x698a8c: ldur            x3, [fp, #-8]
    // 0x698a90: ldur            x2, [fp, #-0x18]
    // 0x698a94: r0 = add()
    //     0x698a94: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x698a98: ldur            x1, [fp, #-0x10]
    // 0x698a9c: mov             x3, x0
    // 0x698aa0: r2 = Instance_Chapter11Stat
    //     0x698aa0: add             x2, PP, #0x11, lsl #12  ; [pp+0x115c0] Obj!Chapter11Stat@85fd41
    //     0x698aa4: ldr             x2, [x2, #0x5c0]
    // 0x698aa8: r0 = []=()
    //     0x698aa8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x698aac: ldur            x0, [fp, #-8]
    // 0x698ab0: LoadField: r1 = r0->field_13
    //     0x698ab0: ldur            w1, [x0, #0x13]
    // 0x698ab4: DecompressPointer r1
    //     0x698ab4: add             x1, x1, HEAP, lsl #32
    // 0x698ab8: r2 = 4
    //     0x698ab8: movz            x2, #0x4
    // 0x698abc: r0 = add()
    //     0x698abc: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x698ac0: ldur            x0, [fp, #-8]
    // 0x698ac4: LoadField: r1 = r0->field_43
    //     0x698ac4: ldur            w1, [x0, #0x43]
    // 0x698ac8: DecompressPointer r1
    //     0x698ac8: add             x1, x1, HEAP, lsl #32
    // 0x698acc: r2 = 24
    //     0x698acc: movz            x2, #0x18
    // 0x698ad0: r0 = containsKey()
    //     0x698ad0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x698ad4: tbz             w0, #4, #0x698ae4
    // 0x698ad8: r3 = Instance_CustomNum
    //     0x698ad8: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698adc: ldr             x3, [x3, #0xaf8]
    // 0x698ae0: b               #0x698d28
    // 0x698ae4: ldur            x0, [fp, #-8]
    // 0x698ae8: LoadField: r3 = r0->field_43
    //     0x698ae8: ldur            w3, [x0, #0x43]
    // 0x698aec: DecompressPointer r3
    //     0x698aec: add             x3, x3, HEAP, lsl #32
    // 0x698af0: mov             x1, x3
    // 0x698af4: stur            x3, [fp, #-0x10]
    // 0x698af8: r2 = 24
    //     0x698af8: movz            x2, #0x18
    // 0x698afc: r0 = _getValueOrData()
    //     0x698afc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698b00: mov             x1, x0
    // 0x698b04: ldur            x0, [fp, #-0x10]
    // 0x698b08: LoadField: r2 = r0->field_f
    //     0x698b08: ldur            w2, [x0, #0xf]
    // 0x698b0c: DecompressPointer r2
    //     0x698b0c: add             x2, x2, HEAP, lsl #32
    // 0x698b10: cmp             w2, w1
    // 0x698b14: b.ne            #0x698b20
    // 0x698b18: r0 = Null
    //     0x698b18: mov             x0, NULL
    // 0x698b1c: b               #0x698b24
    // 0x698b20: mov             x0, x1
    // 0x698b24: cmp             w0, NULL
    // 0x698b28: b.ne            #0x698b34
    // 0x698b2c: r2 = 0
    //     0x698b2c: movz            x2, #0
    // 0x698b30: b               #0x698b44
    // 0x698b34: r1 = LoadInt32Instr(r0)
    //     0x698b34: sbfx            x1, x0, #1, #0x1f
    //     0x698b38: tbz             w0, #0, #0x698b40
    //     0x698b3c: ldur            x1, [x0, #7]
    // 0x698b40: mov             x2, x1
    // 0x698b44: r0 = BoxInt64Instr(r2)
    //     0x698b44: sbfiz           x0, x2, #1, #0x1f
    //     0x698b48: cmp             x2, x0, asr #1
    //     0x698b4c: b.eq            #0x698b58
    //     0x698b50: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x698b54: stur            x2, [x0, #7]
    // 0x698b58: stur            x0, [fp, #-0x10]
    // 0x698b5c: tbnz            x2, #0x3f, #0x698bb8
    // 0x698b60: mov             x0, x2
    // 0x698b64: r1 = 2
    //     0x698b64: movz            x1, #0x2
    // 0x698b68: r2 = 1
    //     0x698b68: movz            x2, #0x1
    // 0x698b6c: CheckStackOverflow
    //     0x698b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x698b70: cmp             SP, x16
    //     0x698b74: b.ls            #0x698efc
    // 0x698b78: cbz             x0, #0x698ba0
    // 0x698b7c: branchIfSmi(r0, 0x698b88)
    //     0x698b7c: tbz             w0, #0, #0x698b88
    // 0x698b80: mul             x3, x2, x1
    // 0x698b84: mov             x2, x3
    // 0x698b88: asr             x3, x0, #1
    // 0x698b8c: cbz             x3, #0x698b98
    // 0x698b90: mul             x4, x1, x1
    // 0x698b94: mov             x1, x4
    // 0x698b98: mov             x0, x3
    // 0x698b9c: b               #0x698b6c
    // 0x698ba0: r0 = BoxInt64Instr(r2)
    //     0x698ba0: sbfiz           x0, x2, #1, #0x1f
    //     0x698ba4: cmp             x2, x0, asr #1
    //     0x698ba8: b.eq            #0x698bb4
    //     0x698bac: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x698bb0: stur            x2, [x0, #7]
    // 0x698bb4: b               #0x698d08
    // 0x698bb8: r16 = 4
    //     0x698bb8: movz            x16, #0x4
    // 0x698bbc: stp             x16, NULL, [SP]
    // 0x698bc0: r0 = _Double.fromInteger()
    //     0x698bc0: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x698bc4: mov             x1, x0
    // 0x698bc8: ldur            x0, [fp, #-0x10]
    // 0x698bcc: stur            x1, [fp, #-0x18]
    // 0x698bd0: r2 = 60
    //     0x698bd0: movz            x2, #0x3c
    // 0x698bd4: branchIfSmi(r0, 0x698be0)
    //     0x698bd4: tbz             w0, #0, #0x698be0
    // 0x698bd8: r2 = LoadClassIdInstr(r0)
    //     0x698bd8: ldur            x2, [x0, #-1]
    //     0x698bdc: ubfx            x2, x2, #0xc, #0x14
    // 0x698be0: str             x0, [SP]
    // 0x698be4: mov             x0, x2
    // 0x698be8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x698be8: sub             lr, x0, #1, lsl #12
    //     0x698bec: ldr             lr, [x21, lr, lsl #3]
    //     0x698bf0: blr             lr
    // 0x698bf4: mov             x1, x0
    // 0x698bf8: ldur            x0, [fp, #-0x18]
    // 0x698bfc: LoadField: d0 = r0->field_7
    //     0x698bfc: ldur            d0, [x0, #7]
    // 0x698c00: LoadField: d1 = r1->field_7
    //     0x698c00: ldur            d1, [x1, #7]
    // 0x698c04: d30 = 0.000000
    //     0x698c04: fmov            d30, d0
    // 0x698c08: d0 = 1.000000
    //     0x698c08: fmov            d0, #1.00000000
    // 0x698c0c: fcmp            d1, #0.0
    // 0x698c10: b.vs            #0x698c54
    // 0x698c14: b.eq            #0x698cdc
    // 0x698c18: fcmp            d1, d0
    // 0x698c1c: b.eq            #0x698c44
    // 0x698c20: d31 = 2.000000
    //     0x698c20: fmov            d31, #2.00000000
    // 0x698c24: fcmp            d1, d31
    // 0x698c28: b.eq            #0x698c4c
    // 0x698c2c: d31 = 3.000000
    //     0x698c2c: fmov            d31, #3.00000000
    // 0x698c30: fcmp            d1, d31
    // 0x698c34: b.ne            #0x698c54
    // 0x698c38: fmul            d0, d30, d30
    // 0x698c3c: fmul            d0, d0, d30
    // 0x698c40: b               #0x698cdc
    // 0x698c44: d0 = 0.000000
    //     0x698c44: fmov            d0, d30
    // 0x698c48: b               #0x698cdc
    // 0x698c4c: fmul            d0, d30, d30
    // 0x698c50: b               #0x698cdc
    // 0x698c54: fcmp            d30, d0
    // 0x698c58: b.vs            #0x698c68
    // 0x698c5c: b.eq            #0x698cdc
    // 0x698c60: fcmp            d30, d1
    // 0x698c64: b.vc            #0x698c74
    // 0x698c68: d0 = nan
    //     0x698c68: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x698c6c: ldr             d0, [x17, #0xe48]
    // 0x698c70: b               #0x698cdc
    // 0x698c74: d0 = -inf
    //     0x698c74: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x698c78: fcmp            d30, d0
    // 0x698c7c: b.eq            #0x698ca4
    // 0x698c80: d0 = 0.500000
    //     0x698c80: fmov            d0, #0.50000000
    // 0x698c84: fcmp            d1, d0
    // 0x698c88: b.ne            #0x698ca4
    // 0x698c8c: fcmp            d30, #0.0
    // 0x698c90: b.eq            #0x698c9c
    // 0x698c94: fsqrt           d0, d30
    // 0x698c98: b               #0x698cdc
    // 0x698c9c: d0 = 0.000000
    //     0x698c9c: eor             v0.16b, v0.16b, v0.16b
    // 0x698ca0: b               #0x698cdc
    // 0x698ca4: d0 = 0.000000
    //     0x698ca4: fmov            d0, d30
    // 0x698ca8: stp             fp, lr, [SP, #-0x10]!
    // 0x698cac: mov             fp, SP
    // 0x698cb0: CallRuntime_LibcPow(double, double) -> double
    //     0x698cb0: and             SP, SP, #0xfffffffffffffff0
    //     0x698cb4: mov             sp, SP
    //     0x698cb8: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x698cbc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x698cc0: blr             x16
    //     0x698cc4: movz            x16, #0x8
    //     0x698cc8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x698ccc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x698cd0: sub             sp, x16, #1, lsl #12
    //     0x698cd4: mov             SP, fp
    //     0x698cd8: ldp             fp, lr, [SP], #0x10
    // 0x698cdc: r0 = inline_Allocate_Double()
    //     0x698cdc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x698ce0: add             x0, x0, #0x10
    //     0x698ce4: cmp             x1, x0
    //     0x698ce8: b.ls            #0x698f04
    //     0x698cec: str             x0, [THR, #0x60]  ; THR::top
    //     0x698cf0: sub             x0, x0, #0xf
    //     0x698cf4: movz            x1, #0xe19c
    //     0x698cf8: movk            x1, #0x3, lsl #16
    //     0x698cfc: stur            x1, [x0, #-1]
    // 0x698d00: dmb             ishst
    // 0x698d04: StoreField: r0->field_7 = d0
    //     0x698d04: stur            d0, [x0, #7]
    // 0x698d08: r16 = 0.010000
    //     0x698d08: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x698d0c: ldr             x16, [x16, #0xaa0]
    // 0x698d10: stp             x0, x16, [SP]
    // 0x698d14: r0 = *()
    //     0x698d14: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x698d18: mov             x2, x0
    // 0x698d1c: r1 = Null
    //     0x698d1c: mov             x1, NULL
    // 0x698d20: r0 = CustomNum()
    //     0x698d20: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x698d24: mov             x3, x0
    // 0x698d28: ldur            x0, [fp, #-8]
    // 0x698d2c: stur            x3, [fp, #-0x18]
    // 0x698d30: LoadField: r4 = r0->field_37
    //     0x698d30: ldur            w4, [x0, #0x37]
    // 0x698d34: DecompressPointer r4
    //     0x698d34: add             x4, x4, HEAP, lsl #32
    // 0x698d38: mov             x1, x4
    // 0x698d3c: stur            x4, [fp, #-0x10]
    // 0x698d40: r2 = Instance_Chapter11Stat
    //     0x698d40: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x698d44: ldr             x2, [x2, #0x5b0]
    // 0x698d48: r0 = _getValueOrData()
    //     0x698d48: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698d4c: mov             x1, x0
    // 0x698d50: ldur            x0, [fp, #-0x10]
    // 0x698d54: LoadField: r2 = r0->field_f
    //     0x698d54: ldur            w2, [x0, #0xf]
    // 0x698d58: DecompressPointer r2
    //     0x698d58: add             x2, x2, HEAP, lsl #32
    // 0x698d5c: cmp             w2, w1
    // 0x698d60: b.ne            #0x698d68
    // 0x698d64: r1 = Null
    //     0x698d64: mov             x1, NULL
    // 0x698d68: cmp             w1, NULL
    // 0x698d6c: b.ne            #0x698d7c
    // 0x698d70: r2 = Instance_CustomNum
    //     0x698d70: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698d74: ldr             x2, [x2, #0xaf8]
    // 0x698d78: b               #0x698d80
    // 0x698d7c: mov             x2, x1
    // 0x698d80: ldur            x3, [fp, #-8]
    // 0x698d84: ldur            x1, [fp, #-0x18]
    // 0x698d88: r0 = mult2()
    //     0x698d88: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x698d8c: ldur            x1, [fp, #-0x10]
    // 0x698d90: mov             x3, x0
    // 0x698d94: r2 = Instance_Chapter11Stat
    //     0x698d94: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x698d98: ldr             x2, [x2, #0x5b0]
    // 0x698d9c: r0 = []=()
    //     0x698d9c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x698da0: ldur            x0, [fp, #-8]
    // 0x698da4: LoadField: r1 = r0->field_3b
    //     0x698da4: ldur            w1, [x0, #0x3b]
    // 0x698da8: DecompressPointer r1
    //     0x698da8: add             x1, x1, HEAP, lsl #32
    // 0x698dac: r2 = Instance_Chapter11Stat
    //     0x698dac: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x698db0: ldr             x2, [x2, #0x5b0]
    // 0x698db4: r0 = remove()
    //     0x698db4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698db8: ldur            x0, [fp, #-8]
    // 0x698dbc: LoadField: r1 = r0->field_37
    //     0x698dbc: ldur            w1, [x0, #0x37]
    // 0x698dc0: DecompressPointer r1
    //     0x698dc0: add             x1, x1, HEAP, lsl #32
    // 0x698dc4: r2 = Instance_Chapter11Stat
    //     0x698dc4: add             x2, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x698dc8: ldr             x2, [x2, #0x5a0]
    // 0x698dcc: r0 = remove()
    //     0x698dcc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698dd0: ldur            x0, [fp, #-8]
    // 0x698dd4: LoadField: r1 = r0->field_3b
    //     0x698dd4: ldur            w1, [x0, #0x3b]
    // 0x698dd8: DecompressPointer r1
    //     0x698dd8: add             x1, x1, HEAP, lsl #32
    // 0x698ddc: r2 = Instance_Chapter11Stat
    //     0x698ddc: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x698de0: ldr             x2, [x2, #0x5b0]
    // 0x698de4: r0 = remove()
    //     0x698de4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698de8: ldur            x0, [fp, #-8]
    // 0x698dec: LoadField: r1 = r0->field_3b
    //     0x698dec: ldur            w1, [x0, #0x3b]
    // 0x698df0: DecompressPointer r1
    //     0x698df0: add             x1, x1, HEAP, lsl #32
    // 0x698df4: r2 = Instance_Chapter11Stat
    //     0x698df4: add             x2, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Chapter11Stat@85fd81
    //     0x698df8: ldr             x2, [x2, #0x5a0]
    // 0x698dfc: r0 = remove()
    //     0x698dfc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e00: ldur            x0, [fp, #-8]
    // 0x698e04: LoadField: r1 = r0->field_47
    //     0x698e04: ldur            w1, [x0, #0x47]
    // 0x698e08: DecompressPointer r1
    //     0x698e08: add             x1, x1, HEAP, lsl #32
    // 0x698e0c: r2 = 20
    //     0x698e0c: movz            x2, #0x14
    // 0x698e10: r0 = remove()
    //     0x698e10: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e14: ldur            x0, [fp, #-8]
    // 0x698e18: LoadField: r1 = r0->field_47
    //     0x698e18: ldur            w1, [x0, #0x47]
    // 0x698e1c: DecompressPointer r1
    //     0x698e1c: add             x1, x1, HEAP, lsl #32
    // 0x698e20: r2 = 22
    //     0x698e20: movz            x2, #0x16
    // 0x698e24: r0 = remove()
    //     0x698e24: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e28: ldur            x0, [fp, #-8]
    // 0x698e2c: LoadField: r1 = r0->field_47
    //     0x698e2c: ldur            w1, [x0, #0x47]
    // 0x698e30: DecompressPointer r1
    //     0x698e30: add             x1, x1, HEAP, lsl #32
    // 0x698e34: r2 = 24
    //     0x698e34: movz            x2, #0x18
    // 0x698e38: r0 = remove()
    //     0x698e38: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e3c: ldur            x0, [fp, #-8]
    // 0x698e40: LoadField: r1 = r0->field_47
    //     0x698e40: ldur            w1, [x0, #0x47]
    // 0x698e44: DecompressPointer r1
    //     0x698e44: add             x1, x1, HEAP, lsl #32
    // 0x698e48: r2 = 26
    //     0x698e48: movz            x2, #0x1a
    // 0x698e4c: r0 = remove()
    //     0x698e4c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e50: ldur            x0, [fp, #-8]
    // 0x698e54: LoadField: r1 = r0->field_47
    //     0x698e54: ldur            w1, [x0, #0x47]
    // 0x698e58: DecompressPointer r1
    //     0x698e58: add             x1, x1, HEAP, lsl #32
    // 0x698e5c: r2 = 28
    //     0x698e5c: movz            x2, #0x1c
    // 0x698e60: r0 = remove()
    //     0x698e60: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e64: ldur            x0, [fp, #-8]
    // 0x698e68: LoadField: r1 = r0->field_43
    //     0x698e68: ldur            w1, [x0, #0x43]
    // 0x698e6c: DecompressPointer r1
    //     0x698e6c: add             x1, x1, HEAP, lsl #32
    // 0x698e70: r2 = 28
    //     0x698e70: movz            x2, #0x1c
    // 0x698e74: r0 = containsKey()
    //     0x698e74: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x698e78: tbz             w0, #4, #0x698edc
    // 0x698e7c: ldur            x0, [fp, #-8]
    // 0x698e80: LoadField: r1 = r0->field_43
    //     0x698e80: ldur            w1, [x0, #0x43]
    // 0x698e84: DecompressPointer r1
    //     0x698e84: add             x1, x1, HEAP, lsl #32
    // 0x698e88: r2 = 2
    //     0x698e88: movz            x2, #0x2
    // 0x698e8c: r0 = remove()
    //     0x698e8c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698e90: ldur            x0, [fp, #-8]
    // 0x698e94: LoadField: r1 = r0->field_43
    //     0x698e94: ldur            w1, [x0, #0x43]
    // 0x698e98: DecompressPointer r1
    //     0x698e98: add             x1, x1, HEAP, lsl #32
    // 0x698e9c: r2 = 4
    //     0x698e9c: movz            x2, #0x4
    // 0x698ea0: r0 = remove()
    //     0x698ea0: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698ea4: ldur            x0, [fp, #-8]
    // 0x698ea8: LoadField: r1 = r0->field_43
    //     0x698ea8: ldur            w1, [x0, #0x43]
    // 0x698eac: DecompressPointer r1
    //     0x698eac: add             x1, x1, HEAP, lsl #32
    // 0x698eb0: r2 = 6
    //     0x698eb0: movz            x2, #0x6
    // 0x698eb4: r0 = remove()
    //     0x698eb4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x698eb8: ldur            x0, [fp, #-8]
    // 0x698ebc: LoadField: r1 = r0->field_53
    //     0x698ebc: ldur            w1, [x0, #0x53]
    // 0x698ec0: DecompressPointer r1
    //     0x698ec0: add             x1, x1, HEAP, lsl #32
    // 0x698ec4: r2 = 2
    //     0x698ec4: movz            x2, #0x2
    // 0x698ec8: r0 = remove()
    //     0x698ec8: bl              #0x7e8a40  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x698ecc: ldur            x0, [fp, #-8]
    // 0x698ed0: LoadField: r1 = r0->field_4b
    //     0x698ed0: ldur            w1, [x0, #0x4b]
    // 0x698ed4: DecompressPointer r1
    //     0x698ed4: add             x1, x1, HEAP, lsl #32
    // 0x698ed8: r0 = clear()
    //     0x698ed8: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x698edc: ldur            x1, [fp, #-8]
    // 0x698ee0: r0 = resetAndRecomputeBoosts()
    //     0x698ee0: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x698ee4: r0 = Null
    //     0x698ee4: mov             x0, NULL
    // 0x698ee8: LeaveFrame
    //     0x698ee8: mov             SP, fp
    //     0x698eec: ldp             fp, lr, [SP], #0x10
    // 0x698ef0: ret
    //     0x698ef0: ret             
    // 0x698ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698ef4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698ef8: b               #0x6989c4
    // 0x698efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698efc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698f00: b               #0x698b78
    // 0x698f04: SaveReg d0
    //     0x698f04: str             q0, [SP, #-0x10]!
    // 0x698f08: r0 = AllocateDouble()
    //     0x698f08: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x698f0c: RestoreReg d0
    //     0x698f0c: ldr             q0, [SP], #0x10
    // 0x698f10: b               #0x698d04
  }
  _ titaniumPrestigePoints(/* No info */) {
    // ** addr: 0x698f14, size: 0xac
    // 0x698f14: EnterFrame
    //     0x698f14: stp             fp, lr, [SP, #-0x10]!
    //     0x698f18: mov             fp, SP
    // 0x698f1c: AllocStack(0x10)
    //     0x698f1c: sub             SP, SP, #0x10
    // 0x698f20: SetupParameters(Chapter11GameState this /* r1 => r0, fp-0x10 */)
    //     0x698f20: mov             x0, x1
    //     0x698f24: stur            x1, [fp, #-0x10]
    // 0x698f28: CheckStackOverflow
    //     0x698f28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x698f2c: cmp             SP, x16
    //     0x698f30: b.ls            #0x698fb8
    // 0x698f34: LoadField: r3 = r0->field_3b
    //     0x698f34: ldur            w3, [x0, #0x3b]
    // 0x698f38: DecompressPointer r3
    //     0x698f38: add             x3, x3, HEAP, lsl #32
    // 0x698f3c: mov             x1, x3
    // 0x698f40: stur            x3, [fp, #-8]
    // 0x698f44: r2 = Instance_Chapter11Stat
    //     0x698f44: add             x2, PP, #0x11, lsl #12  ; [pp+0x115e0] Obj!Chapter11Stat@85fd01
    //     0x698f48: ldr             x2, [x2, #0x5e0]
    // 0x698f4c: r0 = _getValueOrData()
    //     0x698f4c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x698f50: mov             x1, x0
    // 0x698f54: ldur            x0, [fp, #-8]
    // 0x698f58: LoadField: r2 = r0->field_f
    //     0x698f58: ldur            w2, [x0, #0xf]
    // 0x698f5c: DecompressPointer r2
    //     0x698f5c: add             x2, x2, HEAP, lsl #32
    // 0x698f60: cmp             w2, w1
    // 0x698f64: b.ne            #0x698f70
    // 0x698f68: r0 = Null
    //     0x698f68: mov             x0, NULL
    // 0x698f6c: b               #0x698f74
    // 0x698f70: mov             x0, x1
    // 0x698f74: cmp             w0, NULL
    // 0x698f78: b.ne            #0x698f84
    // 0x698f7c: r0 = Instance_CustomNum
    //     0x698f7c: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x698f80: ldr             x0, [x0, #0xaf8]
    // 0x698f84: ldur            x1, [fp, #-0x10]
    // 0x698f88: stur            x0, [fp, #-8]
    // 0x698f8c: r0 = goldPrestigePoints()
    //     0x698f8c: bl              #0x54d718  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestigePoints
    // 0x698f90: ldur            x1, [fp, #-8]
    // 0x698f94: mov             x2, x0
    // 0x698f98: r0 = add()
    //     0x698f98: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x698f9c: mov             x1, x0
    // 0x698fa0: r2 = Instance_CustomNum
    //     0x698fa0: add             x2, PP, #0x29, lsl #12  ; [pp+0x29488] Obj!CustomNum@82b5d1
    //     0x698fa4: ldr             x2, [x2, #0x488]
    // 0x698fa8: r0 = mult2()
    //     0x698fa8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x698fac: LeaveFrame
    //     0x698fac: mov             SP, fp
    //     0x698fb0: ldp             fp, lr, [SP], #0x10
    // 0x698fb4: ret
    //     0x698fb4: ret             
    // 0x698fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698fb8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698fbc: b               #0x698f34
  }
  [closure] CustomNum titaniumPrestigePoints(dynamic) {
    // ** addr: 0x698fc0, size: 0x38
    // 0x698fc0: EnterFrame
    //     0x698fc0: stp             fp, lr, [SP, #-0x10]!
    //     0x698fc4: mov             fp, SP
    // 0x698fc8: ldr             x0, [fp, #0x10]
    // 0x698fcc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x698fcc: ldur            w1, [x0, #0x17]
    // 0x698fd0: DecompressPointer r1
    //     0x698fd0: add             x1, x1, HEAP, lsl #32
    // 0x698fd4: CheckStackOverflow
    //     0x698fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x698fd8: cmp             SP, x16
    //     0x698fdc: b.ls            #0x698ff0
    // 0x698fe0: r0 = titaniumPrestigePoints()
    //     0x698fe0: bl              #0x698f14  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::titaniumPrestigePoints
    // 0x698fe4: LeaveFrame
    //     0x698fe4: mov             SP, fp
    //     0x698fe8: ldp             fp, lr, [SP], #0x10
    // 0x698fec: ret
    //     0x698fec: ret             
    // 0x698ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x698ff0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x698ff4: b               #0x698fe0
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x698ff8, size: 0xc
    // 0x698ff8: r0 = "Recruit Titanium Members"
    //     0x698ff8: add             x0, PP, #0x29, lsl #12  ; [pp+0x29490] "Recruit Titanium Members"
    //     0x698ffc: ldr             x0, [x0, #0x490]
    // 0x699000: ret
    //     0x699000: ret             
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x699004, size: 0x4c
    // 0x699004: EnterFrame
    //     0x699004: stp             fp, lr, [SP, #-0x10]!
    //     0x699008: mov             fp, SP
    // 0x69900c: ldr             x0, [fp, #0x10]
    // 0x699010: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x699010: ldur            w1, [x0, #0x17]
    // 0x699014: DecompressPointer r1
    //     0x699014: add             x1, x1, HEAP, lsl #32
    // 0x699018: CheckStackOverflow
    //     0x699018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69901c: cmp             SP, x16
    //     0x699020: b.ls            #0x699048
    // 0x699024: LoadField: r0 = r1->field_f
    //     0x699024: ldur            w0, [x1, #0xf]
    // 0x699028: DecompressPointer r0
    //     0x699028: add             x0, x0, HEAP, lsl #32
    // 0x69902c: LoadField: r1 = r0->field_43
    //     0x69902c: ldur            w1, [x0, #0x43]
    // 0x699030: DecompressPointer r1
    //     0x699030: add             x1, x1, HEAP, lsl #32
    // 0x699034: r2 = 44
    //     0x699034: movz            x2, #0x2c
    // 0x699038: r0 = containsKey()
    //     0x699038: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69903c: LeaveFrame
    //     0x69903c: mov             SP, fp
    //     0x699040: ldp             fp, lr, [SP], #0x10
    // 0x699044: ret
    //     0x699044: ret             
    // 0x699048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699048: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69904c: b               #0x699024
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x699050, size: 0xac
    // 0x699050: EnterFrame
    //     0x699050: stp             fp, lr, [SP, #-0x10]!
    //     0x699054: mov             fp, SP
    // 0x699058: AllocStack(0x10)
    //     0x699058: sub             SP, SP, #0x10
    // 0x69905c: SetupParameters([dynamic _ /* r0 */])
    //     0x69905c: ldr             x0, [fp, #0x10]
    //     0x699060: ldur            w3, [x0, #0x17]
    //     0x699064: add             x3, x3, HEAP, lsl #32
    //     0x699068: stur            x3, [fp, #-8]
    // 0x69906c: CheckStackOverflow
    //     0x69906c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699070: cmp             SP, x16
    //     0x699074: b.ls            #0x6990e8
    // 0x699078: r0 = LoadStaticField(0xf7c)
    //     0x699078: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x69907c: ldr             x0, [x0, #0x1ef8]
    // 0x699080: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x699084: cmp             w0, w16
    // 0x699088: b.eq            #0x6990f0
    // 0x69908c: LoadField: r1 = r0->field_13
    //     0x69908c: ldur            w1, [x0, #0x13]
    // 0x699090: DecompressPointer r1
    //     0x699090: add             x1, x1, HEAP, lsl #32
    // 0x699094: r2 = 46
    //     0x699094: movz            x2, #0x2e
    // 0x699098: r0 = containsKey()
    //     0x699098: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x69909c: tbnz            w0, #4, #0x6990d8
    // 0x6990a0: ldur            x0, [fp, #-8]
    // 0x6990a4: LoadField: r1 = r0->field_f
    //     0x6990a4: ldur            w1, [x0, #0xf]
    // 0x6990a8: DecompressPointer r1
    //     0x6990a8: add             x1, x1, HEAP, lsl #32
    // 0x6990ac: r16 = false
    //     0x6990ac: add             x16, NULL, #0x30  ; false
    // 0x6990b0: str             x16, [SP]
    // 0x6990b4: r2 = 23
    //     0x6990b4: movz            x2, #0x17
    // 0x6990b8: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x6990b8: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x6990bc: ldr             x4, [x4, #0x5c0]
    // 0x6990c0: r0 = notifyDialoguePoint()
    //     0x6990c0: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6990c4: r0 = "Intermission"
    //     0x6990c4: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x6990c8: ldr             x0, [x0, #0x5c8]
    // 0x6990cc: LeaveFrame
    //     0x6990cc: mov             SP, fp
    //     0x6990d0: ldp             fp, lr, [SP], #0x10
    // 0x6990d4: ret
    //     0x6990d4: ret             
    // 0x6990d8: r0 = Null
    //     0x6990d8: mov             x0, NULL
    // 0x6990dc: LeaveFrame
    //     0x6990dc: mov             SP, fp
    //     0x6990e0: ldp             fp, lr, [SP], #0x10
    // 0x6990e4: ret
    //     0x6990e4: ret             
    // 0x6990e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6990e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6990ec: b               #0x699078
    // 0x6990f0: r9 = coreData
    //     0x6990f0: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6990f4: ldr             x9, [x9, #0x530]
    // 0x6990f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6990f8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x699228, size: 0x58
    // 0x699228: EnterFrame
    //     0x699228: stp             fp, lr, [SP, #-0x10]!
    //     0x69922c: mov             fp, SP
    // 0x699230: CheckStackOverflow
    //     0x699230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699234: cmp             SP, x16
    //     0x699238: b.ls            #0x69926c
    // 0x69923c: r0 = LoadStaticField(0xf7c)
    //     0x69923c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x699240: ldr             x0, [x0, #0x1ef8]
    // 0x699244: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x699248: cmp             w0, w16
    // 0x69924c: b.eq            #0x699274
    // 0x699250: LoadField: r1 = r0->field_13
    //     0x699250: ldur            w1, [x0, #0x13]
    // 0x699254: DecompressPointer r1
    //     0x699254: add             x1, x1, HEAP, lsl #32
    // 0x699258: r2 = 46
    //     0x699258: movz            x2, #0x2e
    // 0x69925c: r0 = containsKey()
    //     0x69925c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x699260: LeaveFrame
    //     0x699260: mov             SP, fp
    //     0x699264: ldp             fp, lr, [SP], #0x10
    // 0x699268: ret
    //     0x699268: ret             
    // 0x69926c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69926c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699270: b               #0x69923c
    // 0x699274: r9 = coreData
    //     0x699274: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x699278: ldr             x9, [x9, #0x530]
    // 0x69927c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x69927c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x699280, size: 0x78
    // 0x699280: EnterFrame
    //     0x699280: stp             fp, lr, [SP, #-0x10]!
    //     0x699284: mov             fp, SP
    // 0x699288: AllocStack(0x18)
    //     0x699288: sub             SP, SP, #0x18
    // 0x69928c: SetupParameters(Chapter11GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x69928c: stur            NULL, [fp, #-8]
    //     0x699290: movz            x0, #0
    //     0x699294: add             x1, fp, w0, sxtw #2
    //     0x699298: ldr             x1, [x1, #0x18]
    //     0x69929c: add             x2, fp, w0, sxtw #2
    //     0x6992a0: ldr             x2, [x2, #0x10]
    //     0x6992a4: stur            x2, [fp, #-0x18]
    //     0x6992a8: ldur            w3, [x1, #0x17]
    //     0x6992ac: add             x3, x3, HEAP, lsl #32
    //     0x6992b0: stur            x3, [fp, #-0x10]
    // 0x6992b4: CheckStackOverflow
    //     0x6992b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6992b8: cmp             SP, x16
    //     0x6992bc: b.ls            #0x6992f0
    // 0x6992c0: InitAsync() -> Future<void?>
    //     0x6992c0: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6992c4: bl              #0x34b9a0  ; InitAsyncStub
    // 0x6992c8: ldur            x2, [fp, #-0x10]
    // 0x6992cc: r1 = Function '<anonymous closure>':.
    //     0x6992cc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29498] AnonymousClosure: (0x6992f8), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::build (0x6969d0)
    //     0x6992d0: ldr             x1, [x1, #0x498]
    // 0x6992d4: r0 = AllocateClosure()
    //     0x6992d4: bl              #0x826750  ; AllocateClosureStub
    // 0x6992d8: ldur            x1, [fp, #-0x18]
    // 0x6992dc: mov             x3, x0
    // 0x6992e0: r2 = 23
    //     0x6992e0: movz            x2, #0x17
    // 0x6992e4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6992e4: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6992e8: r0 = displaySlackPage()
    //     0x6992e8: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x6992ec: r0 = ReturnAsync()
    //     0x6992ec: b               #0x353380  ; ReturnAsyncStub
    // 0x6992f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6992f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6992f4: b               #0x6992c0
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6992f8, size: 0x78
    // 0x6992f8: EnterFrame
    //     0x6992f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6992fc: mov             fp, SP
    // 0x699300: AllocStack(0x8)
    //     0x699300: sub             SP, SP, #8
    // 0x699304: SetupParameters([dynamic _ /* r0 */])
    //     0x699304: ldr             x0, [fp, #0x20]
    //     0x699308: ldur            w3, [x0, #0x17]
    //     0x69930c: add             x3, x3, HEAP, lsl #32
    //     0x699310: stur            x3, [fp, #-8]
    // 0x699314: CheckStackOverflow
    //     0x699314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699318: cmp             SP, x16
    //     0x69931c: b.ls            #0x699368
    // 0x699320: LoadField: r1 = r3->field_f
    //     0x699320: ldur            w1, [x3, #0xf]
    // 0x699324: DecompressPointer r1
    //     0x699324: add             x1, x1, HEAP, lsl #32
    // 0x699328: r2 = 23
    //     0x699328: movz            x2, #0x17
    // 0x69932c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x69932c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x699330: r0 = notifyDialoguePoint()
    //     0x699330: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x699334: ldr             x0, [fp, #0x10]
    // 0x699338: r1 = LoadInt32Instr(r0)
    //     0x699338: sbfx            x1, x0, #1, #0x1f
    //     0x69933c: tbz             w0, #0, #0x699344
    //     0x699340: ldur            x1, [x0, #7]
    // 0x699344: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x699344: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x699348: ldur            x0, [fp, #-8]
    // 0x69934c: LoadField: r1 = r0->field_f
    //     0x69934c: ldur            w1, [x0, #0xf]
    // 0x699350: DecompressPointer r1
    //     0x699350: add             x1, x1, HEAP, lsl #32
    // 0x699354: r0 = saveDeferred()
    //     0x699354: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x699358: r0 = Null
    //     0x699358: mov             x0, NULL
    // 0x69935c: LeaveFrame
    //     0x69935c: mov             SP, fp
    //     0x699360: ldp             fp, lr, [SP], #0x10
    // 0x699364: ret
    //     0x699364: ret             
    // 0x699368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699368: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69936c: b               #0x699320
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x699370, size: 0x4c
    // 0x699370: EnterFrame
    //     0x699370: stp             fp, lr, [SP, #-0x10]!
    //     0x699374: mov             fp, SP
    // 0x699378: ldr             x0, [fp, #0x10]
    // 0x69937c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x69937c: ldur            w1, [x0, #0x17]
    // 0x699380: DecompressPointer r1
    //     0x699380: add             x1, x1, HEAP, lsl #32
    // 0x699384: CheckStackOverflow
    //     0x699384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699388: cmp             SP, x16
    //     0x69938c: b.ls            #0x6993b4
    // 0x699390: LoadField: r0 = r1->field_f
    //     0x699390: ldur            w0, [x1, #0xf]
    // 0x699394: DecompressPointer r0
    //     0x699394: add             x0, x0, HEAP, lsl #32
    // 0x699398: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x699398: ldur            w1, [x0, #0x17]
    // 0x69939c: DecompressPointer r1
    //     0x69939c: add             x1, x1, HEAP, lsl #32
    // 0x6993a0: r2 = 42
    //     0x6993a0: movz            x2, #0x2a
    // 0x6993a4: r0 = contains()
    //     0x6993a4: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6993a8: LeaveFrame
    //     0x6993a8: mov             SP, fp
    //     0x6993ac: ldp             fp, lr, [SP], #0x10
    // 0x6993b0: ret
    //     0x6993b0: ret             
    // 0x6993b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6993b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6993b8: b               #0x699390
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6993bc, size: 0xc
    // 0x6993bc: r0 = "Each gold member increases associates gained by 1%"
    //     0x6993bc: add             x0, PP, #0x29, lsl #12  ; [pp+0x294a0] "Each gold member increases associates gained by 1%"
    //     0x6993c0: ldr             x0, [x0, #0x4a0]
    // 0x6993c4: ret
    //     0x6993c4: ret             
  }
  [closure] void goldPrestige(dynamic) {
    // ** addr: 0x6993c8, size: 0x38
    // 0x6993c8: EnterFrame
    //     0x6993c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6993cc: mov             fp, SP
    // 0x6993d0: ldr             x0, [fp, #0x10]
    // 0x6993d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6993d4: ldur            w1, [x0, #0x17]
    // 0x6993d8: DecompressPointer r1
    //     0x6993d8: add             x1, x1, HEAP, lsl #32
    // 0x6993dc: CheckStackOverflow
    //     0x6993dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6993e0: cmp             SP, x16
    //     0x6993e4: b.ls            #0x6993f8
    // 0x6993e8: r0 = goldPrestige()
    //     0x6993e8: bl              #0x698440  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::goldPrestige
    // 0x6993ec: LeaveFrame
    //     0x6993ec: mov             SP, fp
    //     0x6993f0: ldp             fp, lr, [SP], #0x10
    // 0x6993f4: ret
    //     0x6993f4: ret             
    // 0x6993f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6993f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6993fc: b               #0x6993e8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x699400, size: 0xc
    // 0x699400: r0 = "Recruit Gold Members"
    //     0x699400: add             x0, PP, #0x29, lsl #12  ; [pp+0x294a8] "Recruit Gold Members"
    //     0x699404: ldr             x0, [x0, #0x4a8]
    // 0x699408: ret
    //     0x699408: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x699458, size: 0xc
    // 0x699458: r0 = "Each velocity boosts associate speed by 1%."
    //     0x699458: add             x0, PP, #0x29, lsl #12  ; [pp+0x294b0] "Each velocity boosts associate speed by 1%."
    //     0x69945c: ldr             x0, [x0, #0x4b0]
    // 0x699460: ret
    //     0x699460: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x699464, size: 0x98
    // 0x699464: EnterFrame
    //     0x699464: stp             fp, lr, [SP, #-0x10]!
    //     0x699468: mov             fp, SP
    // 0x69946c: AllocStack(0x10)
    //     0x69946c: sub             SP, SP, #0x10
    // 0x699470: SetupParameters([dynamic _ /* r0 */])
    //     0x699470: ldr             x0, [fp, #0x10]
    //     0x699474: ldur            w1, [x0, #0x17]
    //     0x699478: add             x1, x1, HEAP, lsl #32
    // 0x69947c: CheckStackOverflow
    //     0x69947c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699480: cmp             SP, x16
    //     0x699484: b.ls            #0x6994f4
    // 0x699488: LoadField: r0 = r1->field_f
    //     0x699488: ldur            w0, [x1, #0xf]
    // 0x69948c: DecompressPointer r0
    //     0x69948c: add             x0, x0, HEAP, lsl #32
    // 0x699490: LoadField: r3 = r0->field_57
    //     0x699490: ldur            w3, [x0, #0x57]
    // 0x699494: DecompressPointer r3
    //     0x699494: add             x3, x3, HEAP, lsl #32
    // 0x699498: mov             x1, x3
    // 0x69949c: stur            x3, [fp, #-8]
    // 0x6994a0: r2 = Instance_Chapter11Stat
    //     0x6994a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x6994a4: ldr             x2, [x2, #0x5d0]
    // 0x6994a8: r0 = _getValueOrData()
    //     0x6994a8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6994ac: mov             x1, x0
    // 0x6994b0: ldur            x0, [fp, #-8]
    // 0x6994b4: LoadField: r2 = r0->field_f
    //     0x6994b4: ldur            w2, [x0, #0xf]
    // 0x6994b8: DecompressPointer r2
    //     0x6994b8: add             x2, x2, HEAP, lsl #32
    // 0x6994bc: cmp             w2, w1
    // 0x6994c0: b.ne            #0x6994cc
    // 0x6994c4: r0 = Null
    //     0x6994c4: mov             x0, NULL
    // 0x6994c8: b               #0x6994d0
    // 0x6994cc: mov             x0, x1
    // 0x6994d0: cmp             w0, NULL
    // 0x6994d4: b.ne            #0x6994e0
    // 0x6994d8: r0 = Instance_CustomNum
    //     0x6994d8: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6994dc: ldr             x0, [x0, #0xaf8]
    // 0x6994e0: str             x0, [SP]
    // 0x6994e4: r0 = toString()
    //     0x6994e4: bl              #0x7196d8  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toString
    // 0x6994e8: LeaveFrame
    //     0x6994e8: mov             SP, fp
    //     0x6994ec: ldp             fp, lr, [SP], #0x10
    // 0x6994f0: ret
    //     0x6994f0: ret             
    // 0x6994f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6994f4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6994f8: b               #0x699488
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6994fc, size: 0xa8
    // 0x6994fc: EnterFrame
    //     0x6994fc: stp             fp, lr, [SP, #-0x10]!
    //     0x699500: mov             fp, SP
    // 0x699504: AllocStack(0x8)
    //     0x699504: sub             SP, SP, #8
    // 0x699508: SetupParameters([dynamic _ /* r0 */])
    //     0x699508: ldr             x0, [fp, #0x10]
    //     0x69950c: ldur            w1, [x0, #0x17]
    //     0x699510: add             x1, x1, HEAP, lsl #32
    // 0x699514: CheckStackOverflow
    //     0x699514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699518: cmp             SP, x16
    //     0x69951c: b.ls            #0x69959c
    // 0x699520: LoadField: r0 = r1->field_f
    //     0x699520: ldur            w0, [x1, #0xf]
    // 0x699524: DecompressPointer r0
    //     0x699524: add             x0, x0, HEAP, lsl #32
    // 0x699528: LoadField: r3 = r0->field_37
    //     0x699528: ldur            w3, [x0, #0x37]
    // 0x69952c: DecompressPointer r3
    //     0x69952c: add             x3, x3, HEAP, lsl #32
    // 0x699530: mov             x1, x3
    // 0x699534: stur            x3, [fp, #-8]
    // 0x699538: r2 = Instance_Chapter11Stat
    //     0x699538: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] Obj!Chapter11Stat@85fd21
    //     0x69953c: ldr             x2, [x2, #0x5d0]
    // 0x699540: r0 = _getValueOrData()
    //     0x699540: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x699544: mov             x1, x0
    // 0x699548: ldur            x0, [fp, #-8]
    // 0x69954c: LoadField: r2 = r0->field_f
    //     0x69954c: ldur            w2, [x0, #0xf]
    // 0x699550: DecompressPointer r2
    //     0x699550: add             x2, x2, HEAP, lsl #32
    // 0x699554: cmp             w2, w1
    // 0x699558: b.ne            #0x699560
    // 0x69955c: r1 = Null
    //     0x69955c: mov             x1, NULL
    // 0x699560: cmp             w1, NULL
    // 0x699564: b.ne            #0x699570
    // 0x699568: r1 = Null
    //     0x699568: mov             x1, NULL
    // 0x69956c: b               #0x69957c
    // 0x699570: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x699570: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x699574: r0 = toStringConsistentDecimalPlaces()
    //     0x699574: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x699578: mov             x1, x0
    // 0x69957c: cmp             w1, NULL
    // 0x699580: b.ne            #0x69958c
    // 0x699584: r0 = "0"
    //     0x699584: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x699588: b               #0x699590
    // 0x69958c: mov             x0, x1
    // 0x699590: LeaveFrame
    //     0x699590: mov             SP, fp
    //     0x699594: ldp             fp, lr, [SP], #0x10
    // 0x699598: ret
    //     0x699598: ret             
    // 0x69959c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69959c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6995a0: b               #0x699520
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6995a4, size: 0x4c
    // 0x6995a4: EnterFrame
    //     0x6995a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6995a8: mov             fp, SP
    // 0x6995ac: ldr             x0, [fp, #0x10]
    // 0x6995b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6995b0: ldur            w1, [x0, #0x17]
    // 0x6995b4: DecompressPointer r1
    //     0x6995b4: add             x1, x1, HEAP, lsl #32
    // 0x6995b8: CheckStackOverflow
    //     0x6995b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6995bc: cmp             SP, x16
    //     0x6995c0: b.ls            #0x6995e8
    // 0x6995c4: LoadField: r0 = r1->field_f
    //     0x6995c4: ldur            w0, [x1, #0xf]
    // 0x6995c8: DecompressPointer r0
    //     0x6995c8: add             x0, x0, HEAP, lsl #32
    // 0x6995cc: LoadField: r1 = r0->field_43
    //     0x6995cc: ldur            w1, [x0, #0x43]
    // 0x6995d0: DecompressPointer r1
    //     0x6995d0: add             x1, x1, HEAP, lsl #32
    // 0x6995d4: r2 = 22
    //     0x6995d4: movz            x2, #0x16
    // 0x6995d8: r0 = containsKey()
    //     0x6995d8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6995dc: LeaveFrame
    //     0x6995dc: mov             SP, fp
    //     0x6995e0: ldp             fp, lr, [SP], #0x10
    // 0x6995e4: ret
    //     0x6995e4: ret             
    // 0x6995e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6995e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6995ec: b               #0x6995c4
  }
  [closure] void <anonymous closure>(dynamic, bool?) {
    // ** addr: 0x6995f0, size: 0x50
    // 0x6995f0: EnterFrame
    //     0x6995f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6995f4: mov             fp, SP
    // 0x6995f8: CheckStackOverflow
    //     0x6995f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6995fc: cmp             SP, x16
    //     0x699600: b.ls            #0x699638
    // 0x699604: ldr             x0, [fp, #0x10]
    // 0x699608: cmp             w0, NULL
    // 0x69960c: b.ne            #0x699618
    // 0x699610: r2 = false
    //     0x699610: add             x2, NULL, #0x30  ; false
    // 0x699614: b               #0x69961c
    // 0x699618: mov             x2, x0
    // 0x69961c: r1 = "ch11_autobuy_velocity"
    //     0x69961c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6f0] "ch11_autobuy_velocity"
    //     0x699620: ldr             x1, [x1, #0x6f0]
    // 0x699624: r0 = prefsSetBool()
    //     0x699624: bl              #0x4820f0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetBool
    // 0x699628: r0 = Null
    //     0x699628: mov             x0, NULL
    // 0x69962c: LeaveFrame
    //     0x69962c: mov             SP, fp
    //     0x699630: ldp             fp, lr, [SP], #0x10
    // 0x699634: ret
    //     0x699634: ret             
    // 0x699638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699638: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69963c: b               #0x699604
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x699640, size: 0x40
    // 0x699640: EnterFrame
    //     0x699640: stp             fp, lr, [SP, #-0x10]!
    //     0x699644: mov             fp, SP
    // 0x699648: CheckStackOverflow
    //     0x699648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69964c: cmp             SP, x16
    //     0x699650: b.ls            #0x699678
    // 0x699654: r1 = "ch11_autobuy_velocity"
    //     0x699654: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6f0] "ch11_autobuy_velocity"
    //     0x699658: ldr             x1, [x1, #0x6f0]
    // 0x69965c: r0 = prefsGetBool()
    //     0x69965c: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x699660: cmp             w0, NULL
    // 0x699664: b.ne            #0x69966c
    // 0x699668: r0 = false
    //     0x699668: add             x0, NULL, #0x30  ; false
    // 0x69966c: LeaveFrame
    //     0x69966c: mov             SP, fp
    //     0x699670: ldp             fp, lr, [SP], #0x10
    // 0x699674: ret
    //     0x699674: ret             
    // 0x699678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699678: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69967c: b               #0x699654
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6996cc, size: 0x4c
    // 0x6996cc: EnterFrame
    //     0x6996cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6996d0: mov             fp, SP
    // 0x6996d4: ldr             x0, [fp, #0x10]
    // 0x6996d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6996d8: ldur            w1, [x0, #0x17]
    // 0x6996dc: DecompressPointer r1
    //     0x6996dc: add             x1, x1, HEAP, lsl #32
    // 0x6996e0: CheckStackOverflow
    //     0x6996e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6996e4: cmp             SP, x16
    //     0x6996e8: b.ls            #0x699710
    // 0x6996ec: LoadField: r0 = r1->field_f
    //     0x6996ec: ldur            w0, [x1, #0xf]
    // 0x6996f0: DecompressPointer r0
    //     0x6996f0: add             x0, x0, HEAP, lsl #32
    // 0x6996f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6996f4: ldur            w1, [x0, #0x17]
    // 0x6996f8: DecompressPointer r1
    //     0x6996f8: add             x1, x1, HEAP, lsl #32
    // 0x6996fc: r2 = 20
    //     0x6996fc: movz            x2, #0x14
    // 0x699700: r0 = contains()
    //     0x699700: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x699704: LeaveFrame
    //     0x699704: mov             SP, fp
    //     0x699708: ldp             fp, lr, [SP], #0x10
    // 0x69970c: ret
    //     0x69970c: ret             
    // 0x699710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699710: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699714: b               #0x6996ec
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x699718, size: 0xc
    // 0x699718: r0 = "Each silver member increases associates gained by 1%"
    //     0x699718: add             x0, PP, #0x29, lsl #12  ; [pp+0x294b8] "Each silver member increases associates gained by 1%"
    //     0x69971c: ldr             x0, [x0, #0x4b8]
    // 0x699720: ret
    //     0x699720: ret             
  }
  [closure] void silverPrestige(dynamic) {
    // ** addr: 0x699724, size: 0x38
    // 0x699724: EnterFrame
    //     0x699724: stp             fp, lr, [SP, #-0x10]!
    //     0x699728: mov             fp, SP
    // 0x69972c: ldr             x0, [fp, #0x10]
    // 0x699730: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x699730: ldur            w1, [x0, #0x17]
    // 0x699734: DecompressPointer r1
    //     0x699734: add             x1, x1, HEAP, lsl #32
    // 0x699738: CheckStackOverflow
    //     0x699738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69973c: cmp             SP, x16
    //     0x699740: b.ls            #0x699754
    // 0x699744: r0 = silverPrestige()
    //     0x699744: bl              #0x6989a4  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::silverPrestige
    // 0x699748: LeaveFrame
    //     0x699748: mov             SP, fp
    //     0x69974c: ldp             fp, lr, [SP], #0x10
    // 0x699750: ret
    //     0x699750: ret             
    // 0x699754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699754: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699758: b               #0x699744
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x69975c, size: 0xc
    // 0x69975c: r0 = "Recruit Silver Members"
    //     0x69975c: add             x0, PP, #0x29, lsl #12  ; [pp+0x294c0] "Recruit Silver Members"
    //     0x699760: ldr             x0, [x0, #0x4c0]
    // 0x699764: ret
    //     0x699764: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6997b4, size: 0xc
    // 0x6997b4: r0 = "Each engagement boosts associates gained by 1%."
    //     0x6997b4: add             x0, PP, #0x29, lsl #12  ; [pp+0x294c8] "Each engagement boosts associates gained by 1%."
    //     0x6997b8: ldr             x0, [x0, #0x4c8]
    // 0x6997bc: ret
    //     0x6997bc: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6997c0, size: 0xb0
    // 0x6997c0: EnterFrame
    //     0x6997c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6997c4: mov             fp, SP
    // 0x6997c8: AllocStack(0x10)
    //     0x6997c8: sub             SP, SP, #0x10
    // 0x6997cc: SetupParameters([dynamic _ /* r0 */])
    //     0x6997cc: ldr             x0, [fp, #0x10]
    //     0x6997d0: ldur            w1, [x0, #0x17]
    //     0x6997d4: add             x1, x1, HEAP, lsl #32
    // 0x6997d8: CheckStackOverflow
    //     0x6997d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6997dc: cmp             SP, x16
    //     0x6997e0: b.ls            #0x699868
    // 0x6997e4: LoadField: r0 = r1->field_f
    //     0x6997e4: ldur            w0, [x1, #0xf]
    // 0x6997e8: DecompressPointer r0
    //     0x6997e8: add             x0, x0, HEAP, lsl #32
    // 0x6997ec: LoadField: r3 = r0->field_57
    //     0x6997ec: ldur            w3, [x0, #0x57]
    // 0x6997f0: DecompressPointer r3
    //     0x6997f0: add             x3, x3, HEAP, lsl #32
    // 0x6997f4: mov             x1, x3
    // 0x6997f8: stur            x3, [fp, #-8]
    // 0x6997fc: r2 = Instance_Chapter11Stat
    //     0x6997fc: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x699800: ldr             x2, [x2, #0x5b0]
    // 0x699804: r0 = _getValueOrData()
    //     0x699804: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x699808: mov             x1, x0
    // 0x69980c: ldur            x0, [fp, #-8]
    // 0x699810: LoadField: r2 = r0->field_f
    //     0x699810: ldur            w2, [x0, #0xf]
    // 0x699814: DecompressPointer r2
    //     0x699814: add             x2, x2, HEAP, lsl #32
    // 0x699818: cmp             w2, w1
    // 0x69981c: b.ne            #0x699828
    // 0x699820: r0 = Null
    //     0x699820: mov             x0, NULL
    // 0x699824: b               #0x69982c
    // 0x699828: mov             x0, x1
    // 0x69982c: cmp             w0, NULL
    // 0x699830: b.ne            #0x69983c
    // 0x699834: r1 = Null
    //     0x699834: mov             x1, NULL
    // 0x699838: b               #0x699848
    // 0x69983c: str             x0, [SP]
    // 0x699840: r0 = toString()
    //     0x699840: bl              #0x7196d8  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toString
    // 0x699844: mov             x1, x0
    // 0x699848: cmp             w1, NULL
    // 0x69984c: b.ne            #0x699858
    // 0x699850: r0 = "0"
    //     0x699850: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x699854: b               #0x69985c
    // 0x699858: mov             x0, x1
    // 0x69985c: LeaveFrame
    //     0x69985c: mov             SP, fp
    //     0x699860: ldp             fp, lr, [SP], #0x10
    // 0x699864: ret
    //     0x699864: ret             
    // 0x699868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699868: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69986c: b               #0x6997e4
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x699870, size: 0xa8
    // 0x699870: EnterFrame
    //     0x699870: stp             fp, lr, [SP, #-0x10]!
    //     0x699874: mov             fp, SP
    // 0x699878: AllocStack(0x8)
    //     0x699878: sub             SP, SP, #8
    // 0x69987c: SetupParameters([dynamic _ /* r0 */])
    //     0x69987c: ldr             x0, [fp, #0x10]
    //     0x699880: ldur            w1, [x0, #0x17]
    //     0x699884: add             x1, x1, HEAP, lsl #32
    // 0x699888: CheckStackOverflow
    //     0x699888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69988c: cmp             SP, x16
    //     0x699890: b.ls            #0x699910
    // 0x699894: LoadField: r0 = r1->field_f
    //     0x699894: ldur            w0, [x1, #0xf]
    // 0x699898: DecompressPointer r0
    //     0x699898: add             x0, x0, HEAP, lsl #32
    // 0x69989c: LoadField: r3 = r0->field_37
    //     0x69989c: ldur            w3, [x0, #0x37]
    // 0x6998a0: DecompressPointer r3
    //     0x6998a0: add             x3, x3, HEAP, lsl #32
    // 0x6998a4: mov             x1, x3
    // 0x6998a8: stur            x3, [fp, #-8]
    // 0x6998ac: r2 = Instance_Chapter11Stat
    //     0x6998ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!Chapter11Stat@85fd61
    //     0x6998b0: ldr             x2, [x2, #0x5b0]
    // 0x6998b4: r0 = _getValueOrData()
    //     0x6998b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6998b8: mov             x1, x0
    // 0x6998bc: ldur            x0, [fp, #-8]
    // 0x6998c0: LoadField: r2 = r0->field_f
    //     0x6998c0: ldur            w2, [x0, #0xf]
    // 0x6998c4: DecompressPointer r2
    //     0x6998c4: add             x2, x2, HEAP, lsl #32
    // 0x6998c8: cmp             w2, w1
    // 0x6998cc: b.ne            #0x6998d4
    // 0x6998d0: r1 = Null
    //     0x6998d0: mov             x1, NULL
    // 0x6998d4: cmp             w1, NULL
    // 0x6998d8: b.ne            #0x6998e4
    // 0x6998dc: r1 = Null
    //     0x6998dc: mov             x1, NULL
    // 0x6998e0: b               #0x6998f0
    // 0x6998e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6998e4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6998e8: r0 = toStringConsistentDecimalPlaces()
    //     0x6998e8: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6998ec: mov             x1, x0
    // 0x6998f0: cmp             w1, NULL
    // 0x6998f4: b.ne            #0x699900
    // 0x6998f8: r0 = "0"
    //     0x6998f8: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6998fc: b               #0x699904
    // 0x699900: mov             x0, x1
    // 0x699904: LeaveFrame
    //     0x699904: mov             SP, fp
    //     0x699908: ldp             fp, lr, [SP], #0x10
    // 0x69990c: ret
    //     0x69990c: ret             
    // 0x699910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699910: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699914: b               #0x699894
  }
  [closure] void <anonymous closure>(dynamic, bool?) {
    // ** addr: 0x699918, size: 0x50
    // 0x699918: EnterFrame
    //     0x699918: stp             fp, lr, [SP, #-0x10]!
    //     0x69991c: mov             fp, SP
    // 0x699920: CheckStackOverflow
    //     0x699920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699924: cmp             SP, x16
    //     0x699928: b.ls            #0x699960
    // 0x69992c: ldr             x0, [fp, #0x10]
    // 0x699930: cmp             w0, NULL
    // 0x699934: b.ne            #0x699940
    // 0x699938: r2 = false
    //     0x699938: add             x2, NULL, #0x30  ; false
    // 0x69993c: b               #0x699944
    // 0x699940: mov             x2, x0
    // 0x699944: r1 = "ch11_autobuy_engagement"
    //     0x699944: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6e8] "ch11_autobuy_engagement"
    //     0x699948: ldr             x1, [x1, #0x6e8]
    // 0x69994c: r0 = prefsSetBool()
    //     0x69994c: bl              #0x4820f0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetBool
    // 0x699950: r0 = Null
    //     0x699950: mov             x0, NULL
    // 0x699954: LeaveFrame
    //     0x699954: mov             SP, fp
    //     0x699958: ldp             fp, lr, [SP], #0x10
    // 0x69995c: ret
    //     0x69995c: ret             
    // 0x699960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699960: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699964: b               #0x69992c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x699968, size: 0x40
    // 0x699968: EnterFrame
    //     0x699968: stp             fp, lr, [SP, #-0x10]!
    //     0x69996c: mov             fp, SP
    // 0x699970: CheckStackOverflow
    //     0x699970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699974: cmp             SP, x16
    //     0x699978: b.ls            #0x6999a0
    // 0x69997c: r1 = "ch11_autobuy_engagement"
    //     0x69997c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a6e8] "ch11_autobuy_engagement"
    //     0x699980: ldr             x1, [x1, #0x6e8]
    // 0x699984: r0 = prefsGetBool()
    //     0x699984: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x699988: cmp             w0, NULL
    // 0x69998c: b.ne            #0x699994
    // 0x699990: r0 = false
    //     0x699990: add             x0, NULL, #0x30  ; false
    // 0x699994: LeaveFrame
    //     0x699994: mov             SP, fp
    //     0x699998: ldp             fp, lr, [SP], #0x10
    // 0x69999c: ret
    //     0x69999c: ret             
    // 0x6999a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6999a0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6999a4: b               #0x69997c
  }
  [closure] double <anonymous closure>(dynamic, int) {
    // ** addr: 0x6999f4, size: 0x1d0
    // 0x6999f4: EnterFrame
    //     0x6999f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6999f8: mov             fp, SP
    // 0x6999fc: AllocStack(0x10)
    //     0x6999fc: sub             SP, SP, #0x10
    // 0x699a00: SetupParameters([dynamic _ /* r0 */])
    //     0x699a00: ldr             x0, [fp, #0x18]
    //     0x699a04: ldur            w1, [x0, #0x17]
    //     0x699a08: add             x1, x1, HEAP, lsl #32
    // 0x699a0c: CheckStackOverflow
    //     0x699a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699a10: cmp             SP, x16
    //     0x699a14: b.ls            #0x699bac
    // 0x699a18: LoadField: r0 = r1->field_f
    //     0x699a18: ldur            w0, [x1, #0xf]
    // 0x699a1c: DecompressPointer r0
    //     0x699a1c: add             x0, x0, HEAP, lsl #32
    // 0x699a20: LoadField: r3 = r0->field_43
    //     0x699a20: ldur            w3, [x0, #0x43]
    // 0x699a24: DecompressPointer r3
    //     0x699a24: add             x3, x3, HEAP, lsl #32
    // 0x699a28: mov             x1, x3
    // 0x699a2c: stur            x3, [fp, #-8]
    // 0x699a30: r2 = 6
    //     0x699a30: movz            x2, #0x6
    // 0x699a34: r0 = _getValueOrData()
    //     0x699a34: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x699a38: mov             x1, x0
    // 0x699a3c: ldur            x0, [fp, #-8]
    // 0x699a40: LoadField: r2 = r0->field_f
    //     0x699a40: ldur            w2, [x0, #0xf]
    // 0x699a44: DecompressPointer r2
    //     0x699a44: add             x2, x2, HEAP, lsl #32
    // 0x699a48: cmp             w2, w1
    // 0x699a4c: b.ne            #0x699a58
    // 0x699a50: r0 = Null
    //     0x699a50: mov             x0, NULL
    // 0x699a54: b               #0x699a5c
    // 0x699a58: mov             x0, x1
    // 0x699a5c: cmp             w0, NULL
    // 0x699a60: b.ne            #0x699a6c
    // 0x699a64: d0 = 0.000000
    //     0x699a64: eor             v0.16b, v0.16b, v0.16b
    // 0x699a68: b               #0x699b74
    // 0x699a6c: r1 = 60
    //     0x699a6c: movz            x1, #0x3c
    // 0x699a70: branchIfSmi(r0, 0x699a7c)
    //     0x699a70: tbz             w0, #0, #0x699a7c
    // 0x699a74: r1 = LoadClassIdInstr(r0)
    //     0x699a74: ldur            x1, [x0, #-1]
    //     0x699a78: ubfx            x1, x1, #0xc, #0x14
    // 0x699a7c: str             x0, [SP]
    // 0x699a80: mov             x0, x1
    // 0x699a84: r0 = GDT[cid_x0 + -0x1000]()
    //     0x699a84: sub             lr, x0, #1, lsl #12
    //     0x699a88: ldr             lr, [x21, lr, lsl #3]
    //     0x699a8c: blr             lr
    // 0x699a90: LoadField: d1 = r0->field_7
    //     0x699a90: ldur            d1, [x0, #7]
    // 0x699a94: d0 = 1.718282
    //     0x699a94: add             x17, PP, #0x29, lsl #12  ; [pp+0x294d0] IMM: double(1.718281828459045) from 0x3ffb7e151628aed2
    //     0x699a98: ldr             d0, [x17, #0x4d0]
    // 0x699a9c: d30 = 0.000000
    //     0x699a9c: fmov            d30, d0
    // 0x699aa0: d0 = 1.000000
    //     0x699aa0: fmov            d0, #1.00000000
    // 0x699aa4: fcmp            d1, #0.0
    // 0x699aa8: b.vs            #0x699aec
    // 0x699aac: b.eq            #0x699b74
    // 0x699ab0: fcmp            d1, d0
    // 0x699ab4: b.eq            #0x699adc
    // 0x699ab8: d31 = 2.000000
    //     0x699ab8: fmov            d31, #2.00000000
    // 0x699abc: fcmp            d1, d31
    // 0x699ac0: b.eq            #0x699ae4
    // 0x699ac4: d31 = 3.000000
    //     0x699ac4: fmov            d31, #3.00000000
    // 0x699ac8: fcmp            d1, d31
    // 0x699acc: b.ne            #0x699aec
    // 0x699ad0: fmul            d0, d30, d30
    // 0x699ad4: fmul            d0, d0, d30
    // 0x699ad8: b               #0x699b74
    // 0x699adc: d0 = 0.000000
    //     0x699adc: fmov            d0, d30
    // 0x699ae0: b               #0x699b74
    // 0x699ae4: fmul            d0, d30, d30
    // 0x699ae8: b               #0x699b74
    // 0x699aec: fcmp            d30, d0
    // 0x699af0: b.vs            #0x699b00
    // 0x699af4: b.eq            #0x699b74
    // 0x699af8: fcmp            d30, d1
    // 0x699afc: b.vc            #0x699b0c
    // 0x699b00: d0 = nan
    //     0x699b00: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x699b04: ldr             d0, [x17, #0xe48]
    // 0x699b08: b               #0x699b74
    // 0x699b0c: d0 = -inf
    //     0x699b0c: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x699b10: fcmp            d30, d0
    // 0x699b14: b.eq            #0x699b3c
    // 0x699b18: d0 = 0.500000
    //     0x699b18: fmov            d0, #0.50000000
    // 0x699b1c: fcmp            d1, d0
    // 0x699b20: b.ne            #0x699b3c
    // 0x699b24: fcmp            d30, #0.0
    // 0x699b28: b.eq            #0x699b34
    // 0x699b2c: fsqrt           d0, d30
    // 0x699b30: b               #0x699b74
    // 0x699b34: d0 = 0.000000
    //     0x699b34: eor             v0.16b, v0.16b, v0.16b
    // 0x699b38: b               #0x699b74
    // 0x699b3c: d0 = 0.000000
    //     0x699b3c: fmov            d0, d30
    // 0x699b40: stp             fp, lr, [SP, #-0x10]!
    // 0x699b44: mov             fp, SP
    // 0x699b48: CallRuntime_LibcPow(double, double) -> double
    //     0x699b48: and             SP, SP, #0xfffffffffffffff0
    //     0x699b4c: mov             sp, SP
    //     0x699b50: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x699b54: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x699b58: blr             x16
    //     0x699b5c: movz            x16, #0x8
    //     0x699b60: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x699b64: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x699b68: sub             sp, x16, #1, lsl #12
    //     0x699b6c: mov             SP, fp
    //     0x699b70: ldp             fp, lr, [SP], #0x10
    // 0x699b74: r0 = inline_Allocate_Double()
    //     0x699b74: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x699b78: add             x0, x0, #0x10
    //     0x699b7c: cmp             x1, x0
    //     0x699b80: b.ls            #0x699bb4
    //     0x699b84: str             x0, [THR, #0x60]  ; THR::top
    //     0x699b88: sub             x0, x0, #0xf
    //     0x699b8c: movz            x1, #0xe19c
    //     0x699b90: movk            x1, #0x3, lsl #16
    //     0x699b94: stur            x1, [x0, #-1]
    // 0x699b98: dmb             ishst
    // 0x699b9c: StoreField: r0->field_7 = d0
    //     0x699b9c: stur            d0, [x0, #7]
    // 0x699ba0: LeaveFrame
    //     0x699ba0: mov             SP, fp
    //     0x699ba4: ldp             fp, lr, [SP], #0x10
    // 0x699ba8: ret
    //     0x699ba8: ret             
    // 0x699bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699bac: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699bb0: b               #0x699a18
    // 0x699bb4: SaveReg d0
    //     0x699bb4: str             q0, [SP, #-0x10]!
    // 0x699bb8: r0 = AllocateDouble()
    //     0x699bb8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x699bbc: RestoreReg d0
    //     0x699bbc: ldr             q0, [SP], #0x10
    // 0x699bc0: b               #0x699b9c
  }
  [closure] GeneratorInfo<Chapter11Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x699bc4, size: 0x3c
    // 0x699bc4: EnterFrame
    //     0x699bc4: stp             fp, lr, [SP, #-0x10]!
    //     0x699bc8: mov             fp, SP
    // 0x699bcc: ldr             x0, [fp, #0x18]
    // 0x699bd0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x699bd0: ldur            w1, [x0, #0x17]
    // 0x699bd4: DecompressPointer r1
    //     0x699bd4: add             x1, x1, HEAP, lsl #32
    // 0x699bd8: CheckStackOverflow
    //     0x699bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699bdc: cmp             SP, x16
    //     0x699be0: b.ls            #0x699bf8
    // 0x699be4: ldr             x2, [fp, #0x10]
    // 0x699be8: r0 = getGeneratorInfo()
    //     0x699be8: bl              #0x80d194  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::getGeneratorInfo
    // 0x699bec: LeaveFrame
    //     0x699bec: mov             SP, fp
    //     0x699bf0: ldp             fp, lr, [SP], #0x10
    // 0x699bf4: ret
    //     0x699bf4: ret             
    // 0x699bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699bf8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699bfc: b               #0x699be4
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d194, size: 0x7c
    // 0x80d194: EnterFrame
    //     0x80d194: stp             fp, lr, [SP, #-0x10]!
    //     0x80d198: mov             fp, SP
    // 0x80d19c: AllocStack(0x8)
    //     0x80d19c: sub             SP, SP, #8
    // 0x80d1a0: CheckStackOverflow
    //     0x80d1a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d1a4: cmp             SP, x16
    //     0x80d1a8: b.ls            #0x80d1f8
    // 0x80d1ac: LoadField: r0 = r1->field_8b
    //     0x80d1ac: ldur            w0, [x1, #0x8b]
    // 0x80d1b0: DecompressPointer r0
    //     0x80d1b0: add             x0, x0, HEAP, lsl #32
    // 0x80d1b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d1b8: cmp             w0, w16
    // 0x80d1bc: b.eq            #0x80d200
    // 0x80d1c0: mov             x1, x0
    // 0x80d1c4: stur            x0, [fp, #-8]
    // 0x80d1c8: r0 = _getValueOrData()
    //     0x80d1c8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d1cc: ldur            x1, [fp, #-8]
    // 0x80d1d0: LoadField: r2 = r1->field_f
    //     0x80d1d0: ldur            w2, [x1, #0xf]
    // 0x80d1d4: DecompressPointer r2
    //     0x80d1d4: add             x2, x2, HEAP, lsl #32
    // 0x80d1d8: cmp             w2, w0
    // 0x80d1dc: b.ne            #0x80d1e4
    // 0x80d1e0: r0 = Null
    //     0x80d1e0: mov             x0, NULL
    // 0x80d1e4: cmp             w0, NULL
    // 0x80d1e8: b.eq            #0x80d20c
    // 0x80d1ec: LeaveFrame
    //     0x80d1ec: mov             SP, fp
    //     0x80d1f0: ldp             fp, lr, [SP], #0x10
    // 0x80d1f4: ret
    //     0x80d1f4: ret             
    // 0x80d1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d1f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d1fc: b               #0x80d1ac
    // 0x80d200: r9 = generators
    //     0x80d200: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a718] Field <Chapter11GameState.generators>: late (offset: 0x8c)
    //     0x80d204: ldr             x9, [x9, #0x718]
    // 0x80d208: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d208: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d20c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d20c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d114, size: 0xc
    // 0x81d114: r0 = "11"
    //     0x81d114: add             x0, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x81d118: ldr             x0, [x0, #0x328]
    // 0x81d11c: ret
    //     0x81d11c: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f660, size: 0x24
    // 0x81f660: EnterFrame
    //     0x81f660: stp             fp, lr, [SP, #-0x10]!
    //     0x81f664: mov             fp, SP
    // 0x81f668: ldr             x2, [fp, #0x10]
    // 0x81f66c: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f66c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cb48] AnonymousClosure: (0x3da664), in [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::getCostToBuyOneMoreGenerator (0x3da3d8)
    //     0x81f670: ldr             x1, [x1, #0xb48]
    // 0x81f674: r0 = AllocateClosure()
    //     0x81f674: bl              #0x826750  ; AllocateClosureStub
    // 0x81f678: LeaveFrame
    //     0x81f678: mov             SP, fp
    //     0x81f67c: ldp             fp, lr, [SP], #0x10
    // 0x81f680: ret
    //     0x81f680: ret             
  }
}

// class id: 4187, size: 0x14, field offset: 0x14
enum Chapter11Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x72481c, size: 0x64
    // 0x72481c: EnterFrame
    //     0x72481c: stp             fp, lr, [SP, #-0x10]!
    //     0x724820: mov             fp, SP
    // 0x724824: AllocStack(0x10)
    //     0x724824: sub             SP, SP, #0x10
    // 0x724828: SetupParameters(Chapter11Stat this /* r1 => r0, fp-0x8 */)
    //     0x724828: mov             x0, x1
    //     0x72482c: stur            x1, [fp, #-8]
    // 0x724830: CheckStackOverflow
    //     0x724830: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724834: cmp             SP, x16
    //     0x724838: b.ls            #0x724878
    // 0x72483c: r1 = Null
    //     0x72483c: mov             x1, NULL
    // 0x724840: r2 = 4
    //     0x724840: movz            x2, #0x4
    // 0x724844: r0 = AllocateArray()
    //     0x724844: bl              #0x82746c  ; AllocateArrayStub
    // 0x724848: r16 = "Chapter11Stat."
    //     0x724848: add             x16, PP, #0x16, lsl #12  ; [pp+0x16318] "Chapter11Stat."
    //     0x72484c: ldr             x16, [x16, #0x318]
    // 0x724850: StoreField: r0->field_f = r16
    //     0x724850: stur            w16, [x0, #0xf]
    // 0x724854: ldur            x1, [fp, #-8]
    // 0x724858: LoadField: r2 = r1->field_f
    //     0x724858: ldur            w2, [x1, #0xf]
    // 0x72485c: DecompressPointer r2
    //     0x72485c: add             x2, x2, HEAP, lsl #32
    // 0x724860: StoreField: r0->field_13 = r2
    //     0x724860: stur            w2, [x0, #0x13]
    // 0x724864: str             x0, [SP]
    // 0x724868: r0 = _interpolate()
    //     0x724868: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x72486c: LeaveFrame
    //     0x72486c: mov             SP, fp
    //     0x724870: ldp             fp, lr, [SP], #0x10
    // 0x724874: ret
    //     0x724874: ret             
    // 0x724878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724878: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72487c: b               #0x72483c
  }
}
