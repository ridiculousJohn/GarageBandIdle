// lib: , url: package:pretentious/data/Chapters/Chapter15GameState.dart

// class id: 1049452, size: 0x8
class :: {

  static _ humanName(/* No info */) {
    // ** addr: 0x46c038, size: 0x130
    // 0x46c038: cmp             w1, NULL
    // 0x46c03c: b.ne            #0x46c048
    // 0x46c040: r0 = ""
    //     0x46c040: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46c044: ret
    //     0x46c044: ret             
    // 0x46c048: r16 = Instance_Chapter15Stat
    //     0x46c048: add             x16, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x46c04c: ldr             x16, [x16, #0x90]
    // 0x46c050: cmp             w1, w16
    // 0x46c054: b.ne            #0x46c064
    // 0x46c058: r0 = "Symbols"
    //     0x46c058: add             x0, PP, #0x11, lsl #12  ; [pp+0x11098] "Symbols"
    //     0x46c05c: ldr             x0, [x0, #0x98]
    // 0x46c060: ret
    //     0x46c060: ret             
    // 0x46c064: r16 = Instance_Chapter15Stat
    //     0x46c064: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x46c068: ldr             x16, [x16, #0xfd8]
    // 0x46c06c: cmp             w1, w16
    // 0x46c070: b.ne            #0x46c080
    // 0x46c074: r0 = "Bonus Virtual Table"
    //     0x46c074: add             x0, PP, #0x11, lsl #12  ; [pp+0x110a0] "Bonus Virtual Table"
    //     0x46c078: ldr             x0, [x0, #0xa0]
    // 0x46c07c: ret
    //     0x46c07c: ret             
    // 0x46c080: r16 = Instance_Chapter15Stat
    //     0x46c080: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x46c084: ldr             x16, [x16, #0xfe0]
    // 0x46c088: cmp             w1, w16
    // 0x46c08c: b.ne            #0x46c09c
    // 0x46c090: r0 = "Bonus FFI Bridge"
    //     0x46c090: add             x0, PP, #0x11, lsl #12  ; [pp+0x110a8] "Bonus FFI Bridge"
    //     0x46c094: ldr             x0, [x0, #0xa8]
    // 0x46c098: ret
    //     0x46c098: ret             
    // 0x46c09c: r16 = Instance_Chapter15Stat
    //     0x46c09c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x46c0a0: ldr             x16, [x16, #0xfe8]
    // 0x46c0a4: cmp             w1, w16
    // 0x46c0a8: b.ne            #0x46c0b8
    // 0x46c0ac: r0 = "Bonus Pointer Export"
    //     0x46c0ac: add             x0, PP, #0x11, lsl #12  ; [pp+0x110b0] "Bonus Pointer Export"
    //     0x46c0b0: ldr             x0, [x0, #0xb0]
    // 0x46c0b4: ret
    //     0x46c0b4: ret             
    // 0x46c0b8: r16 = Instance_Chapter15Stat
    //     0x46c0b8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x46c0bc: ldr             x16, [x16, #0xff0]
    // 0x46c0c0: cmp             w1, w16
    // 0x46c0c4: b.ne            #0x46c0d4
    // 0x46c0c8: r0 = "Bonus Interupt Stub"
    //     0x46c0c8: add             x0, PP, #0x11, lsl #12  ; [pp+0x110b8] "Bonus Interupt Stub"
    //     0x46c0cc: ldr             x0, [x0, #0xb8]
    // 0x46c0d0: ret
    //     0x46c0d0: ret             
    // 0x46c0d4: r16 = Instance_Chapter15Stat
    //     0x46c0d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x46c0d8: ldr             x16, [x16, #0xc0]
    // 0x46c0dc: cmp             w1, w16
    // 0x46c0e0: b.ne            #0x46c0f0
    // 0x46c0e4: r0 = "Pull Requests"
    //     0x46c0e4: add             x0, PP, #0x11, lsl #12  ; [pp+0x110c8] "Pull Requests"
    //     0x46c0e8: ldr             x0, [x0, #0xc8]
    // 0x46c0ec: ret
    //     0x46c0ec: ret             
    // 0x46c0f0: r16 = Instance_Chapter15Stat
    //     0x46c0f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x46c0f4: ldr             x16, [x16, #0x68]
    // 0x46c0f8: cmp             w1, w16
    // 0x46c0fc: b.ne            #0x46c10c
    // 0x46c100: r0 = "Stars"
    //     0x46c100: add             x0, PP, #0x11, lsl #12  ; [pp+0x110d0] "Stars"
    //     0x46c104: ldr             x0, [x0, #0xd0]
    // 0x46c108: ret
    //     0x46c108: ret             
    // 0x46c10c: r16 = Instance_Chapter15Stat
    //     0x46c10c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x46c110: ldr             x16, [x16, #0xff8]
    // 0x46c114: cmp             w1, w16
    // 0x46c118: b.ne            #0x46c128
    // 0x46c11c: r0 = "Bonus Name Resolver"
    //     0x46c11c: add             x0, PP, #0x11, lsl #12  ; [pp+0x110d8] "Bonus Name Resolver"
    //     0x46c120: ldr             x0, [x0, #0xd8]
    // 0x46c124: ret
    //     0x46c124: ret             
    // 0x46c128: r16 = Instance_Chapter15Stat
    //     0x46c128: add             x16, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x46c12c: ldr             x16, [x16]
    // 0x46c130: cmp             w1, w16
    // 0x46c134: b.ne            #0x46c144
    // 0x46c138: r0 = "Bonus Symbol Lock"
    //     0x46c138: add             x0, PP, #0x11, lsl #12  ; [pp+0x110e0] "Bonus Symbol Lock"
    //     0x46c13c: ldr             x0, [x0, #0xe0]
    // 0x46c140: ret
    //     0x46c140: ret             
    // 0x46c144: r16 = Instance_Chapter15Stat
    //     0x46c144: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x46c148: ldr             x16, [x16, #0xe8]
    // 0x46c14c: cmp             w1, w16
    // 0x46c150: b.ne            #0x46c160
    // 0x46c154: r0 = "Hype"
    //     0x46c154: add             x0, PP, #0x11, lsl #12  ; [pp+0x110f0] "Hype"
    //     0x46c158: ldr             x0, [x0, #0xf0]
    // 0x46c15c: ret
    //     0x46c15c: ret             
    // 0x46c160: r0 = Null
    //     0x46c160: mov             x0, NULL
    // 0x46c164: ret
    //     0x46c164: ret             
  }
  static _ shortenedName(/* No info */) {
    // ** addr: 0x46c198, size: 0x130
    // 0x46c198: cmp             w1, NULL
    // 0x46c19c: b.ne            #0x46c1a8
    // 0x46c1a0: r0 = ""
    //     0x46c1a0: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x46c1a4: ret
    //     0x46c1a4: ret             
    // 0x46c1a8: r16 = Instance_Chapter15Stat
    //     0x46c1a8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x46c1ac: ldr             x16, [x16, #0x90]
    // 0x46c1b0: cmp             w1, w16
    // 0x46c1b4: b.ne            #0x46c1c4
    // 0x46c1b8: r0 = "Sym"
    //     0x46c1b8: add             x0, PP, #0x11, lsl #12  ; [pp+0x110f8] "Sym"
    //     0x46c1bc: ldr             x0, [x0, #0xf8]
    // 0x46c1c0: ret
    //     0x46c1c0: ret             
    // 0x46c1c4: r16 = Instance_Chapter15Stat
    //     0x46c1c4: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x46c1c8: ldr             x16, [x16, #0xfd8]
    // 0x46c1cc: cmp             w1, w16
    // 0x46c1d0: b.ne            #0x46c1e0
    // 0x46c1d4: r0 = "BVT"
    //     0x46c1d4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11100] "BVT"
    //     0x46c1d8: ldr             x0, [x0, #0x100]
    // 0x46c1dc: ret
    //     0x46c1dc: ret             
    // 0x46c1e0: r16 = Instance_Chapter15Stat
    //     0x46c1e0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x46c1e4: ldr             x16, [x16, #0xfe0]
    // 0x46c1e8: cmp             w1, w16
    // 0x46c1ec: b.ne            #0x46c1fc
    // 0x46c1f0: r0 = "BFI"
    //     0x46c1f0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11108] "BFI"
    //     0x46c1f4: ldr             x0, [x0, #0x108]
    // 0x46c1f8: ret
    //     0x46c1f8: ret             
    // 0x46c1fc: r16 = Instance_Chapter15Stat
    //     0x46c1fc: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x46c200: ldr             x16, [x16, #0xfe8]
    // 0x46c204: cmp             w1, w16
    // 0x46c208: b.ne            #0x46c218
    // 0x46c20c: r0 = "BPE"
    //     0x46c20c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11110] "BPE"
    //     0x46c210: ldr             x0, [x0, #0x110]
    // 0x46c214: ret
    //     0x46c214: ret             
    // 0x46c218: r16 = Instance_Chapter15Stat
    //     0x46c218: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x46c21c: ldr             x16, [x16, #0xff0]
    // 0x46c220: cmp             w1, w16
    // 0x46c224: b.ne            #0x46c234
    // 0x46c228: r0 = "BIS"
    //     0x46c228: add             x0, PP, #0x11, lsl #12  ; [pp+0x11118] "BIS"
    //     0x46c22c: ldr             x0, [x0, #0x118]
    // 0x46c230: ret
    //     0x46c230: ret             
    // 0x46c234: r16 = Instance_Chapter15Stat
    //     0x46c234: add             x16, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x46c238: ldr             x16, [x16, #0xc0]
    // 0x46c23c: cmp             w1, w16
    // 0x46c240: b.ne            #0x46c250
    // 0x46c244: r0 = "PR"
    //     0x46c244: add             x0, PP, #0x11, lsl #12  ; [pp+0x11120] "PR"
    //     0x46c248: ldr             x0, [x0, #0x120]
    // 0x46c24c: ret
    //     0x46c24c: ret             
    // 0x46c250: r16 = Instance_Chapter15Stat
    //     0x46c250: add             x16, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x46c254: ldr             x16, [x16, #0x68]
    // 0x46c258: cmp             w1, w16
    // 0x46c25c: b.ne            #0x46c26c
    // 0x46c260: r0 = "Stars"
    //     0x46c260: add             x0, PP, #0x11, lsl #12  ; [pp+0x110d0] "Stars"
    //     0x46c264: ldr             x0, [x0, #0xd0]
    // 0x46c268: ret
    //     0x46c268: ret             
    // 0x46c26c: r16 = Instance_Chapter15Stat
    //     0x46c26c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x46c270: ldr             x16, [x16, #0xff8]
    // 0x46c274: cmp             w1, w16
    // 0x46c278: b.ne            #0x46c288
    // 0x46c27c: r0 = "BNR"
    //     0x46c27c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11128] "BNR"
    //     0x46c280: ldr             x0, [x0, #0x128]
    // 0x46c284: ret
    //     0x46c284: ret             
    // 0x46c288: r16 = Instance_Chapter15Stat
    //     0x46c288: add             x16, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x46c28c: ldr             x16, [x16]
    // 0x46c290: cmp             w1, w16
    // 0x46c294: b.ne            #0x46c2a4
    // 0x46c298: r0 = "BSL"
    //     0x46c298: add             x0, PP, #0x11, lsl #12  ; [pp+0x11130] "BSL"
    //     0x46c29c: ldr             x0, [x0, #0x130]
    // 0x46c2a0: ret
    //     0x46c2a0: ret             
    // 0x46c2a4: r16 = Instance_Chapter15Stat
    //     0x46c2a4: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x46c2a8: ldr             x16, [x16, #0xe8]
    // 0x46c2ac: cmp             w1, w16
    // 0x46c2b0: b.ne            #0x46c2c0
    // 0x46c2b4: r0 = "Hype"
    //     0x46c2b4: add             x0, PP, #0x11, lsl #12  ; [pp+0x110f0] "Hype"
    //     0x46c2b8: ldr             x0, [x0, #0xf0]
    // 0x46c2bc: ret
    //     0x46c2bc: ret             
    // 0x46c2c0: r0 = Null
    //     0x46c2c0: mov             x0, NULL
    // 0x46c2c4: ret
    //     0x46c2c4: ret             
  }
}

// class id: 280, size: 0xac, field offset: 0x8c
class Chapter15GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter15Stat>> generators; // offset: 0x8c
  late Map<int, UpgradeData<Chapter15Stat>> allUpgradeData; // offset: 0x90

  _ getCostToBuyOneMoreGenerator(/* No info */) {
    // ** addr: 0x3db270, size: 0x148
    // 0x3db270: EnterFrame
    //     0x3db270: stp             fp, lr, [SP, #-0x10]!
    //     0x3db274: mov             fp, SP
    // 0x3db278: AllocStack(0x30)
    //     0x3db278: sub             SP, SP, #0x30
    // 0x3db27c: SetupParameters(Chapter15GameState this /* r1 => r3, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x3db27c: mov             x0, x3
    //     0x3db280: stur            x3, [fp, #-0x10]
    //     0x3db284: mov             x3, x1
    //     0x3db288: stur            x1, [fp, #-8]
    // 0x3db28c: CheckStackOverflow
    //     0x3db28c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3db290: cmp             SP, x16
    //     0x3db294: b.ls            #0x3db3ac
    // 0x3db298: mov             x1, x3
    // 0x3db29c: r0 = getGeneratorInfo()
    //     0x3db29c: bl              #0x80d384  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getGeneratorInfo
    // 0x3db2a0: LoadField: r3 = r0->field_27
    //     0x3db2a0: ldur            w3, [x0, #0x27]
    // 0x3db2a4: DecompressPointer r3
    //     0x3db2a4: add             x3, x3, HEAP, lsl #32
    // 0x3db2a8: stur            x3, [fp, #-0x20]
    // 0x3db2ac: cmp             w3, NULL
    // 0x3db2b0: b.eq            #0x3db3b4
    // 0x3db2b4: LoadField: r0 = r3->field_b
    //     0x3db2b4: ldur            w0, [x3, #0xb]
    // 0x3db2b8: DecompressPointer r0
    //     0x3db2b8: add             x0, x0, HEAP, lsl #32
    // 0x3db2bc: ldur            x2, [fp, #-0x10]
    // 0x3db2c0: stur            x0, [fp, #-0x18]
    // 0x3db2c4: r1 = Instance_CustomNum
    //     0x3db2c4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x3db2c8: ldr             x1, [x1, #0x2f0]
    // 0x3db2cc: r0 = pow()
    //     0x3db2cc: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3db2d0: mov             x3, x0
    // 0x3db2d4: ldur            x0, [fp, #-0x20]
    // 0x3db2d8: stur            x3, [fp, #-0x30]
    // 0x3db2dc: LoadField: r4 = r0->field_f
    //     0x3db2dc: ldur            w4, [x0, #0xf]
    // 0x3db2e0: DecompressPointer r4
    //     0x3db2e0: add             x4, x4, HEAP, lsl #32
    // 0x3db2e4: ldur            x0, [fp, #-8]
    // 0x3db2e8: stur            x4, [fp, #-0x28]
    // 0x3db2ec: LoadField: r5 = r0->field_43
    //     0x3db2ec: ldur            w5, [x0, #0x43]
    // 0x3db2f0: DecompressPointer r5
    //     0x3db2f0: add             x5, x5, HEAP, lsl #32
    // 0x3db2f4: mov             x1, x5
    // 0x3db2f8: stur            x5, [fp, #-0x10]
    // 0x3db2fc: r2 = 26
    //     0x3db2fc: movz            x2, #0x1a
    // 0x3db300: r0 = _getValueOrData()
    //     0x3db300: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3db304: mov             x1, x0
    // 0x3db308: ldur            x0, [fp, #-0x10]
    // 0x3db30c: LoadField: r2 = r0->field_f
    //     0x3db30c: ldur            w2, [x0, #0xf]
    // 0x3db310: DecompressPointer r2
    //     0x3db310: add             x2, x2, HEAP, lsl #32
    // 0x3db314: cmp             w2, w1
    // 0x3db318: b.ne            #0x3db324
    // 0x3db31c: r0 = Null
    //     0x3db31c: mov             x0, NULL
    // 0x3db320: b               #0x3db328
    // 0x3db324: mov             x0, x1
    // 0x3db328: cmp             w0, NULL
    // 0x3db32c: b.ne            #0x3db338
    // 0x3db330: r2 = 0
    //     0x3db330: movz            x2, #0
    // 0x3db334: b               #0x3db348
    // 0x3db338: r1 = LoadInt32Instr(r0)
    //     0x3db338: sbfx            x1, x0, #1, #0x1f
    //     0x3db33c: tbz             w0, #0, #0x3db344
    //     0x3db340: ldur            x1, [x0, #7]
    // 0x3db344: mov             x2, x1
    // 0x3db348: ldur            x3, [fp, #-0x18]
    // 0x3db34c: r0 = BoxInt64Instr(r2)
    //     0x3db34c: sbfiz           x0, x2, #1, #0x1f
    //     0x3db350: cmp             x2, x0, asr #1
    //     0x3db354: b.eq            #0x3db360
    //     0x3db358: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x3db35c: stur            x2, [x0, #7]
    // 0x3db360: mov             x2, x0
    // 0x3db364: r1 = Instance_CustomNum
    //     0x3db364: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x3db368: ldr             x1, [x1, #0xce0]
    // 0x3db36c: r0 = pow()
    //     0x3db36c: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x3db370: ldur            x1, [fp, #-0x30]
    // 0x3db374: ldur            x2, [fp, #-0x28]
    // 0x3db378: mov             x3, x0
    // 0x3db37c: r0 = mult3()
    //     0x3db37c: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x3db380: r1 = <Chapter15Stat, CustomNum>
    //     0x3db380: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a648] TypeArguments: <Chapter15Stat, CustomNum>
    //     0x3db384: ldr             x1, [x1, #0x648]
    // 0x3db388: stur            x0, [fp, #-8]
    // 0x3db38c: r0 = Tuple2()
    //     0x3db38c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x3db390: ldur            x1, [fp, #-0x18]
    // 0x3db394: StoreField: r0->field_b = r1
    //     0x3db394: stur            w1, [x0, #0xb]
    // 0x3db398: ldur            x1, [fp, #-8]
    // 0x3db39c: StoreField: r0->field_f = r1
    //     0x3db39c: stur            w1, [x0, #0xf]
    // 0x3db3a0: LeaveFrame
    //     0x3db3a0: mov             SP, fp
    //     0x3db3a4: ldp             fp, lr, [SP], #0x10
    // 0x3db3a8: ret
    //     0x3db3a8: ret             
    // 0x3db3ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3db3ac: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3db3b0: b               #0x3db298
    // 0x3db3b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x3db3b4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<Chapter15Stat, CustomNum> getCostToBuyOneMoreGenerator(dynamic, int, num) {
    // ** addr: 0x3db3b8, size: 0x40
    // 0x3db3b8: EnterFrame
    //     0x3db3b8: stp             fp, lr, [SP, #-0x10]!
    //     0x3db3bc: mov             fp, SP
    // 0x3db3c0: ldr             x0, [fp, #0x20]
    // 0x3db3c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x3db3c4: ldur            w1, [x0, #0x17]
    // 0x3db3c8: DecompressPointer r1
    //     0x3db3c8: add             x1, x1, HEAP, lsl #32
    // 0x3db3cc: CheckStackOverflow
    //     0x3db3cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3db3d0: cmp             SP, x16
    //     0x3db3d4: b.ls            #0x3db3f0
    // 0x3db3d8: ldr             x2, [fp, #0x18]
    // 0x3db3dc: ldr             x3, [fp, #0x10]
    // 0x3db3e0: r0 = getCostToBuyOneMoreGenerator()
    //     0x3db3e0: bl              #0x3db270  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getCostToBuyOneMoreGenerator
    // 0x3db3e4: LeaveFrame
    //     0x3db3e4: mov             SP, fp
    //     0x3db3e8: ldp             fp, lr, [SP], #0x10
    // 0x3db3ec: ret
    //     0x3db3ec: ret             
    // 0x3db3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3db3f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3db3f4: b               #0x3db3d8
  }
  _ Chapter15GameState(/* No info */) {
    // ** addr: 0x46b010, size: 0xe68
    // 0x46b010: EnterFrame
    //     0x46b010: stp             fp, lr, [SP, #-0x10]!
    //     0x46b014: mov             fp, SP
    // 0x46b018: AllocStack(0x48)
    //     0x46b018: sub             SP, SP, #0x48
    // 0x46b01c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46b020: stur            x1, [fp, #-8]
    // 0x46b024: stur            x2, [fp, #-0x10]
    // 0x46b028: CheckStackOverflow
    //     0x46b028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46b02c: cmp             SP, x16
    //     0x46b030: b.ls            #0x46be64
    // 0x46b034: StoreField: r1->field_8b = r0
    //     0x46b034: stur            w0, [x1, #0x8b]
    // 0x46b038: StoreField: r1->field_8f = r0
    //     0x46b038: stur            w0, [x1, #0x8f]
    // 0x46b03c: r0 = IntWrapper()
    //     0x46b03c: bl              #0x46bea4  ; AllocateIntWrapperStub -> IntWrapper (size=0x10)
    // 0x46b040: StoreField: r0->field_7 = rZR
    //     0x46b040: stur            xzr, [x0, #7]
    // 0x46b044: ldur            x2, [fp, #-8]
    // 0x46b048: StoreField: r2->field_93 = r0
    //     0x46b048: stur            w0, [x2, #0x93]
    //     0x46b04c: ldurb           w16, [x2, #-1]
    //     0x46b050: ldurb           w17, [x0, #-1]
    //     0x46b054: and             x16, x17, x16, lsr #2
    //     0x46b058: tst             x16, HEAP, lsr #32
    //     0x46b05c: b.eq            #0x46b064
    //     0x46b060: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x46b064: r1 = <int>
    //     0x46b064: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b068: r0 = _Set()
    //     0x46b068: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x46b06c: r2 = _Uint32List
    //     0x46b06c: ldr             x2, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x46b070: StoreField: r0->field_1b = r2
    //     0x46b070: stur            w2, [x0, #0x1b]
    // 0x46b074: StoreField: r0->field_b = rZR
    //     0x46b074: stur            wzr, [x0, #0xb]
    // 0x46b078: r3 = const []
    //     0x46b078: ldr             x3, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x46b07c: StoreField: r0->field_f = r3
    //     0x46b07c: stur            w3, [x0, #0xf]
    // 0x46b080: StoreField: r0->field_13 = rZR
    //     0x46b080: stur            wzr, [x0, #0x13]
    // 0x46b084: ArrayStore: r0[0] = rZR  ; List_4
    //     0x46b084: stur            wzr, [x0, #0x17]
    // 0x46b088: ldur            x4, [fp, #-8]
    // 0x46b08c: StoreField: r4->field_97 = r0
    //     0x46b08c: stur            w0, [x4, #0x97]
    //     0x46b090: ldurb           w16, [x4, #-1]
    //     0x46b094: ldurb           w17, [x0, #-1]
    //     0x46b098: and             x16, x17, x16, lsr #2
    //     0x46b09c: tst             x16, HEAP, lsr #32
    //     0x46b0a0: b.eq            #0x46b0a8
    //     0x46b0a4: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x46b0a8: r1 = <int>
    //     0x46b0a8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b0ac: r0 = _Set()
    //     0x46b0ac: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x46b0b0: mov             x1, x0
    // 0x46b0b4: r0 = _Uint32List
    //     0x46b0b4: ldr             x0, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x46b0b8: StoreField: r1->field_1b = r0
    //     0x46b0b8: stur            w0, [x1, #0x1b]
    // 0x46b0bc: StoreField: r1->field_b = rZR
    //     0x46b0bc: stur            wzr, [x1, #0xb]
    // 0x46b0c0: r0 = const []
    //     0x46b0c0: ldr             x0, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x46b0c4: StoreField: r1->field_f = r0
    //     0x46b0c4: stur            w0, [x1, #0xf]
    // 0x46b0c8: StoreField: r1->field_13 = rZR
    //     0x46b0c8: stur            wzr, [x1, #0x13]
    // 0x46b0cc: ArrayStore: r1[0] = rZR  ; List_4
    //     0x46b0cc: stur            wzr, [x1, #0x17]
    // 0x46b0d0: mov             x0, x1
    // 0x46b0d4: ldur            x1, [fp, #-8]
    // 0x46b0d8: StoreField: r1->field_9b = r0
    //     0x46b0d8: stur            w0, [x1, #0x9b]
    //     0x46b0dc: ldurb           w16, [x1, #-1]
    //     0x46b0e0: ldurb           w17, [x0, #-1]
    //     0x46b0e4: and             x16, x17, x16, lsr #2
    //     0x46b0e8: tst             x16, HEAP, lsr #32
    //     0x46b0ec: b.eq            #0x46b0f4
    //     0x46b0f0: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x46b0f4: r16 = <int, int>
    //     0x46b0f4: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x46b0f8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x46b0fc: stp             lr, x16, [SP]
    // 0x46b100: r0 = Map._fromLiteral()
    //     0x46b100: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46b104: ldur            x3, [fp, #-8]
    // 0x46b108: StoreField: r3->field_9f = r0
    //     0x46b108: stur            w0, [x3, #0x9f]
    //     0x46b10c: ldurb           w16, [x3, #-1]
    //     0x46b110: ldurb           w17, [x0, #-1]
    //     0x46b114: and             x16, x17, x16, lsr #2
    //     0x46b118: tst             x16, HEAP, lsr #32
    //     0x46b11c: b.eq            #0x46b124
    //     0x46b120: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46b124: r1 = Null
    //     0x46b124: mov             x1, NULL
    // 0x46b128: r2 = 24
    //     0x46b128: movz            x2, #0x18
    // 0x46b12c: r0 = AllocateArray()
    //     0x46b12c: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b130: r16 = 2
    //     0x46b130: movz            x16, #0x2
    // 0x46b134: StoreField: r0->field_f = r16
    //     0x46b134: stur            w16, [x0, #0xf]
    // 0x46b138: r16 = Instance_Chapter15Stat
    //     0x46b138: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x46b13c: ldr             x16, [x16, #0xfd8]
    // 0x46b140: StoreField: r0->field_13 = r16
    //     0x46b140: stur            w16, [x0, #0x13]
    // 0x46b144: r16 = 4
    //     0x46b144: movz            x16, #0x4
    // 0x46b148: ArrayStore: r0[0] = r16  ; List_4
    //     0x46b148: stur            w16, [x0, #0x17]
    // 0x46b14c: r16 = Instance_Chapter15Stat
    //     0x46b14c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x46b150: ldr             x16, [x16, #0xfe0]
    // 0x46b154: StoreField: r0->field_1b = r16
    //     0x46b154: stur            w16, [x0, #0x1b]
    // 0x46b158: r16 = 6
    //     0x46b158: movz            x16, #0x6
    // 0x46b15c: StoreField: r0->field_1f = r16
    //     0x46b15c: stur            w16, [x0, #0x1f]
    // 0x46b160: r16 = Instance_Chapter15Stat
    //     0x46b160: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x46b164: ldr             x16, [x16, #0xfe8]
    // 0x46b168: StoreField: r0->field_23 = r16
    //     0x46b168: stur            w16, [x0, #0x23]
    // 0x46b16c: r16 = 8
    //     0x46b16c: movz            x16, #0x8
    // 0x46b170: StoreField: r0->field_27 = r16
    //     0x46b170: stur            w16, [x0, #0x27]
    // 0x46b174: r16 = Instance_Chapter15Stat
    //     0x46b174: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x46b178: ldr             x16, [x16, #0xff0]
    // 0x46b17c: StoreField: r0->field_2b = r16
    //     0x46b17c: stur            w16, [x0, #0x2b]
    // 0x46b180: r16 = 10
    //     0x46b180: movz            x16, #0xa
    // 0x46b184: StoreField: r0->field_2f = r16
    //     0x46b184: stur            w16, [x0, #0x2f]
    // 0x46b188: r16 = Instance_Chapter15Stat
    //     0x46b188: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x46b18c: ldr             x16, [x16, #0xff8]
    // 0x46b190: StoreField: r0->field_33 = r16
    //     0x46b190: stur            w16, [x0, #0x33]
    // 0x46b194: r16 = 12
    //     0x46b194: movz            x16, #0xc
    // 0x46b198: StoreField: r0->field_37 = r16
    //     0x46b198: stur            w16, [x0, #0x37]
    // 0x46b19c: r16 = Instance_Chapter15Stat
    //     0x46b19c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x46b1a0: ldr             x16, [x16]
    // 0x46b1a4: StoreField: r0->field_3b = r16
    //     0x46b1a4: stur            w16, [x0, #0x3b]
    // 0x46b1a8: r16 = <int, Chapter15Stat>
    //     0x46b1a8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11008] TypeArguments: <int, Chapter15Stat>
    //     0x46b1ac: ldr             x16, [x16, #8]
    // 0x46b1b0: stp             x0, x16, [SP]
    // 0x46b1b4: r0 = Map._fromLiteral()
    //     0x46b1b4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x46b1b8: ldur            x3, [fp, #-8]
    // 0x46b1bc: StoreField: r3->field_a3 = r0
    //     0x46b1bc: stur            w0, [x3, #0xa3]
    //     0x46b1c0: ldurb           w16, [x3, #-1]
    //     0x46b1c4: ldurb           w17, [x0, #-1]
    //     0x46b1c8: and             x16, x17, x16, lsr #2
    //     0x46b1cc: tst             x16, HEAP, lsr #32
    //     0x46b1d0: b.eq            #0x46b1d8
    //     0x46b1d4: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46b1d8: r1 = Null
    //     0x46b1d8: mov             x1, NULL
    // 0x46b1dc: r2 = 320
    //     0x46b1dc: movz            x2, #0x140
    // 0x46b1e0: r0 = CustomNum()
    //     0x46b1e0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b1e4: stur            x0, [fp, #-0x18]
    // 0x46b1e8: r0 = Boost()
    //     0x46b1e8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b1ec: mov             x3, x0
    // 0x46b1f0: ldur            x0, [fp, #-0x18]
    // 0x46b1f4: stur            x3, [fp, #-0x20]
    // 0x46b1f8: StoreField: r3->field_7 = r0
    //     0x46b1f8: stur            w0, [x3, #7]
    // 0x46b1fc: r0 = Instance_CustomNum
    //     0x46b1fc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b200: ldr             x0, [x0, #0xa70]
    // 0x46b204: StoreField: r3->field_b = r0
    //     0x46b204: stur            w0, [x3, #0xb]
    // 0x46b208: StoreField: r3->field_f = r0
    //     0x46b208: stur            w0, [x3, #0xf]
    // 0x46b20c: StoreField: r3->field_13 = r0
    //     0x46b20c: stur            w0, [x3, #0x13]
    // 0x46b210: r1 = Null
    //     0x46b210: mov             x1, NULL
    // 0x46b214: r2 = 2
    //     0x46b214: movz            x2, #0x2
    // 0x46b218: r0 = AllocateArray()
    //     0x46b218: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b21c: stur            x0, [fp, #-0x18]
    // 0x46b220: r16 = 22
    //     0x46b220: movz            x16, #0x16
    // 0x46b224: StoreField: r0->field_f = r16
    //     0x46b224: stur            w16, [x0, #0xf]
    // 0x46b228: r1 = <int>
    //     0x46b228: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b22c: r0 = AllocateGrowableArray()
    //     0x46b22c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b230: mov             x1, x0
    // 0x46b234: ldur            x0, [fp, #-0x18]
    // 0x46b238: stur            x1, [fp, #-0x28]
    // 0x46b23c: StoreField: r1->field_f = r0
    //     0x46b23c: stur            w0, [x1, #0xf]
    // 0x46b240: r2 = 2
    //     0x46b240: movz            x2, #0x2
    // 0x46b244: StoreField: r1->field_b = r2
    //     0x46b244: stur            w2, [x1, #0xb]
    // 0x46b248: r0 = BoostHolder()
    //     0x46b248: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b24c: mov             x3, x0
    // 0x46b250: r0 = 13
    //     0x46b250: movz            x0, #0xd
    // 0x46b254: stur            x3, [fp, #-0x18]
    // 0x46b258: StoreField: r3->field_b = r0
    //     0x46b258: stur            x0, [x3, #0xb]
    // 0x46b25c: r4 = 11
    //     0x46b25c: movz            x4, #0xb
    // 0x46b260: StoreField: r3->field_13 = r4
    //     0x46b260: stur            x4, [x3, #0x13]
    // 0x46b264: ldur            x1, [fp, #-0x20]
    // 0x46b268: StoreField: r3->field_7 = r1
    //     0x46b268: stur            w1, [x3, #7]
    // 0x46b26c: ldur            x1, [fp, #-0x28]
    // 0x46b270: StoreField: r3->field_1b = r1
    //     0x46b270: stur            w1, [x3, #0x1b]
    // 0x46b274: r1 = <BoostHolder>
    //     0x46b274: add             x1, PP, #0x11, lsl #12  ; [pp+0x11010] TypeArguments: <BoostHolder>
    //     0x46b278: ldr             x1, [x1, #0x10]
    // 0x46b27c: r2 = 22
    //     0x46b27c: movz            x2, #0x16
    // 0x46b280: r0 = AllocateArray()
    //     0x46b280: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b284: mov             x3, x0
    // 0x46b288: ldur            x0, [fp, #-0x18]
    // 0x46b28c: stur            x3, [fp, #-0x20]
    // 0x46b290: StoreField: r3->field_f = r0
    //     0x46b290: stur            w0, [x3, #0xf]
    // 0x46b294: r1 = Null
    //     0x46b294: mov             x1, NULL
    // 0x46b298: r2 = 2700000
    //     0x46b298: movz            x2, #0x32e0
    //     0x46b29c: movk            x2, #0x29, lsl #16
    // 0x46b2a0: r0 = CustomNum()
    //     0x46b2a0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b2a4: stur            x0, [fp, #-0x18]
    // 0x46b2a8: r0 = Boost()
    //     0x46b2a8: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b2ac: mov             x3, x0
    // 0x46b2b0: ldur            x0, [fp, #-0x18]
    // 0x46b2b4: stur            x3, [fp, #-0x28]
    // 0x46b2b8: StoreField: r3->field_7 = r0
    //     0x46b2b8: stur            w0, [x3, #7]
    // 0x46b2bc: r0 = Instance_CustomNum
    //     0x46b2bc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b2c0: ldr             x0, [x0, #0xa70]
    // 0x46b2c4: StoreField: r3->field_b = r0
    //     0x46b2c4: stur            w0, [x3, #0xb]
    // 0x46b2c8: StoreField: r3->field_f = r0
    //     0x46b2c8: stur            w0, [x3, #0xf]
    // 0x46b2cc: StoreField: r3->field_13 = r0
    //     0x46b2cc: stur            w0, [x3, #0x13]
    // 0x46b2d0: r1 = Null
    //     0x46b2d0: mov             x1, NULL
    // 0x46b2d4: r2 = 2
    //     0x46b2d4: movz            x2, #0x2
    // 0x46b2d8: r0 = AllocateArray()
    //     0x46b2d8: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b2dc: stur            x0, [fp, #-0x18]
    // 0x46b2e0: r16 = 24
    //     0x46b2e0: movz            x16, #0x18
    // 0x46b2e4: StoreField: r0->field_f = r16
    //     0x46b2e4: stur            w16, [x0, #0xf]
    // 0x46b2e8: r1 = <int>
    //     0x46b2e8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b2ec: r0 = AllocateGrowableArray()
    //     0x46b2ec: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b2f0: mov             x1, x0
    // 0x46b2f4: ldur            x0, [fp, #-0x18]
    // 0x46b2f8: stur            x1, [fp, #-0x30]
    // 0x46b2fc: StoreField: r1->field_f = r0
    //     0x46b2fc: stur            w0, [x1, #0xf]
    // 0x46b300: r2 = 2
    //     0x46b300: movz            x2, #0x2
    // 0x46b304: StoreField: r1->field_b = r2
    //     0x46b304: stur            w2, [x1, #0xb]
    // 0x46b308: r0 = BoostHolder()
    //     0x46b308: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b30c: r3 = 12
    //     0x46b30c: movz            x3, #0xc
    // 0x46b310: StoreField: r0->field_b = r3
    //     0x46b310: stur            x3, [x0, #0xb]
    // 0x46b314: r1 = 88
    //     0x46b314: movz            x1, #0x58
    // 0x46b318: StoreField: r0->field_13 = r1
    //     0x46b318: stur            x1, [x0, #0x13]
    // 0x46b31c: ldur            x1, [fp, #-0x28]
    // 0x46b320: StoreField: r0->field_7 = r1
    //     0x46b320: stur            w1, [x0, #7]
    // 0x46b324: ldur            x1, [fp, #-0x30]
    // 0x46b328: StoreField: r0->field_1b = r1
    //     0x46b328: stur            w1, [x0, #0x1b]
    // 0x46b32c: ldur            x1, [fp, #-0x20]
    // 0x46b330: ArrayStore: r1[1] = r0  ; List_4
    //     0x46b330: add             x25, x1, #0x13
    //     0x46b334: str             w0, [x25]
    //     0x46b338: tbz             w0, #0, #0x46b354
    //     0x46b33c: ldurb           w16, [x1, #-1]
    //     0x46b340: ldurb           w17, [x0, #-1]
    //     0x46b344: and             x16, x17, x16, lsr #2
    //     0x46b348: tst             x16, HEAP, lsr #32
    //     0x46b34c: b.eq            #0x46b354
    //     0x46b350: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b354: r1 = Null
    //     0x46b354: mov             x1, NULL
    // 0x46b358: r2 = 1092
    //     0x46b358: movz            x2, #0x444
    // 0x46b35c: r0 = CustomNum()
    //     0x46b35c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b360: stur            x0, [fp, #-0x18]
    // 0x46b364: r0 = Boost()
    //     0x46b364: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b368: mov             x3, x0
    // 0x46b36c: ldur            x0, [fp, #-0x18]
    // 0x46b370: stur            x3, [fp, #-0x28]
    // 0x46b374: StoreField: r3->field_7 = r0
    //     0x46b374: stur            w0, [x3, #7]
    // 0x46b378: r0 = Instance_CustomNum
    //     0x46b378: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b37c: ldr             x0, [x0, #0xa70]
    // 0x46b380: StoreField: r3->field_b = r0
    //     0x46b380: stur            w0, [x3, #0xb]
    // 0x46b384: StoreField: r3->field_f = r0
    //     0x46b384: stur            w0, [x3, #0xf]
    // 0x46b388: StoreField: r3->field_13 = r0
    //     0x46b388: stur            w0, [x3, #0x13]
    // 0x46b38c: r1 = Null
    //     0x46b38c: mov             x1, NULL
    // 0x46b390: r2 = 2
    //     0x46b390: movz            x2, #0x2
    // 0x46b394: r0 = AllocateArray()
    //     0x46b394: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b398: stur            x0, [fp, #-0x18]
    // 0x46b39c: r16 = 26
    //     0x46b39c: movz            x16, #0x1a
    // 0x46b3a0: StoreField: r0->field_f = r16
    //     0x46b3a0: stur            w16, [x0, #0xf]
    // 0x46b3a4: r1 = <int>
    //     0x46b3a4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b3a8: r0 = AllocateGrowableArray()
    //     0x46b3a8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b3ac: mov             x1, x0
    // 0x46b3b0: ldur            x0, [fp, #-0x18]
    // 0x46b3b4: stur            x1, [fp, #-0x30]
    // 0x46b3b8: StoreField: r1->field_f = r0
    //     0x46b3b8: stur            w0, [x1, #0xf]
    // 0x46b3bc: r2 = 2
    //     0x46b3bc: movz            x2, #0x2
    // 0x46b3c0: StoreField: r1->field_b = r2
    //     0x46b3c0: stur            w2, [x1, #0xb]
    // 0x46b3c4: r0 = BoostHolder()
    //     0x46b3c4: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b3c8: r3 = 14
    //     0x46b3c8: movz            x3, #0xe
    // 0x46b3cc: StoreField: r0->field_b = r3
    //     0x46b3cc: stur            x3, [x0, #0xb]
    // 0x46b3d0: r1 = 16
    //     0x46b3d0: movz            x1, #0x10
    // 0x46b3d4: StoreField: r0->field_13 = r1
    //     0x46b3d4: stur            x1, [x0, #0x13]
    // 0x46b3d8: ldur            x1, [fp, #-0x28]
    // 0x46b3dc: StoreField: r0->field_7 = r1
    //     0x46b3dc: stur            w1, [x0, #7]
    // 0x46b3e0: ldur            x1, [fp, #-0x30]
    // 0x46b3e4: StoreField: r0->field_1b = r1
    //     0x46b3e4: stur            w1, [x0, #0x1b]
    // 0x46b3e8: ldur            x1, [fp, #-0x20]
    // 0x46b3ec: ArrayStore: r1[2] = r0  ; List_4
    //     0x46b3ec: add             x25, x1, #0x17
    //     0x46b3f0: str             w0, [x25]
    //     0x46b3f4: tbz             w0, #0, #0x46b410
    //     0x46b3f8: ldurb           w16, [x1, #-1]
    //     0x46b3fc: ldurb           w17, [x0, #-1]
    //     0x46b400: and             x16, x17, x16, lsr #2
    //     0x46b404: tst             x16, HEAP, lsr #32
    //     0x46b408: b.eq            #0x46b410
    //     0x46b40c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b410: r1 = Null
    //     0x46b410: mov             x1, NULL
    // 0x46b414: r2 = 450
    //     0x46b414: movz            x2, #0x1c2
    // 0x46b418: r0 = CustomNum()
    //     0x46b418: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b41c: stur            x0, [fp, #-0x18]
    // 0x46b420: r0 = Boost()
    //     0x46b420: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b424: mov             x3, x0
    // 0x46b428: r0 = Instance_CustomNum
    //     0x46b428: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b42c: ldr             x0, [x0, #0xa70]
    // 0x46b430: stur            x3, [fp, #-0x28]
    // 0x46b434: StoreField: r3->field_7 = r0
    //     0x46b434: stur            w0, [x3, #7]
    // 0x46b438: StoreField: r3->field_b = r0
    //     0x46b438: stur            w0, [x3, #0xb]
    // 0x46b43c: ldur            x1, [fp, #-0x18]
    // 0x46b440: StoreField: r3->field_f = r1
    //     0x46b440: stur            w1, [x3, #0xf]
    // 0x46b444: StoreField: r3->field_13 = r0
    //     0x46b444: stur            w0, [x3, #0x13]
    // 0x46b448: r1 = Null
    //     0x46b448: mov             x1, NULL
    // 0x46b44c: r2 = 2
    //     0x46b44c: movz            x2, #0x2
    // 0x46b450: r0 = AllocateArray()
    //     0x46b450: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b454: stur            x0, [fp, #-0x18]
    // 0x46b458: r16 = 26
    //     0x46b458: movz            x16, #0x1a
    // 0x46b45c: StoreField: r0->field_f = r16
    //     0x46b45c: stur            w16, [x0, #0xf]
    // 0x46b460: r1 = <int>
    //     0x46b460: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b464: r0 = AllocateGrowableArray()
    //     0x46b464: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b468: mov             x1, x0
    // 0x46b46c: ldur            x0, [fp, #-0x18]
    // 0x46b470: stur            x1, [fp, #-0x30]
    // 0x46b474: StoreField: r1->field_f = r0
    //     0x46b474: stur            w0, [x1, #0xf]
    // 0x46b478: r2 = 2
    //     0x46b478: movz            x2, #0x2
    // 0x46b47c: StoreField: r1->field_b = r2
    //     0x46b47c: stur            w2, [x1, #0xb]
    // 0x46b480: r0 = BoostHolder()
    //     0x46b480: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b484: r3 = 11
    //     0x46b484: movz            x3, #0xb
    // 0x46b488: StoreField: r0->field_b = r3
    //     0x46b488: stur            x3, [x0, #0xb]
    // 0x46b48c: r1 = 70
    //     0x46b48c: movz            x1, #0x46
    // 0x46b490: StoreField: r0->field_13 = r1
    //     0x46b490: stur            x1, [x0, #0x13]
    // 0x46b494: ldur            x1, [fp, #-0x28]
    // 0x46b498: StoreField: r0->field_7 = r1
    //     0x46b498: stur            w1, [x0, #7]
    // 0x46b49c: ldur            x1, [fp, #-0x30]
    // 0x46b4a0: StoreField: r0->field_1b = r1
    //     0x46b4a0: stur            w1, [x0, #0x1b]
    // 0x46b4a4: ldur            x1, [fp, #-0x20]
    // 0x46b4a8: ArrayStore: r1[3] = r0  ; List_4
    //     0x46b4a8: add             x25, x1, #0x1b
    //     0x46b4ac: str             w0, [x25]
    //     0x46b4b0: tbz             w0, #0, #0x46b4cc
    //     0x46b4b4: ldurb           w16, [x1, #-1]
    //     0x46b4b8: ldurb           w17, [x0, #-1]
    //     0x46b4bc: and             x16, x17, x16, lsr #2
    //     0x46b4c0: tst             x16, HEAP, lsr #32
    //     0x46b4c4: b.eq            #0x46b4cc
    //     0x46b4c8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b4cc: r1 = Null
    //     0x46b4cc: mov             x1, NULL
    // 0x46b4d0: r2 = 2100000
    //     0x46b4d0: movz            x2, #0xb20
    //     0x46b4d4: movk            x2, #0x20, lsl #16
    // 0x46b4d8: r0 = CustomNum()
    //     0x46b4d8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b4dc: stur            x0, [fp, #-0x18]
    // 0x46b4e0: r0 = Boost()
    //     0x46b4e0: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b4e4: mov             x3, x0
    // 0x46b4e8: ldur            x0, [fp, #-0x18]
    // 0x46b4ec: stur            x3, [fp, #-0x28]
    // 0x46b4f0: StoreField: r3->field_7 = r0
    //     0x46b4f0: stur            w0, [x3, #7]
    // 0x46b4f4: r0 = Instance_CustomNum
    //     0x46b4f4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b4f8: ldr             x0, [x0, #0xa70]
    // 0x46b4fc: StoreField: r3->field_b = r0
    //     0x46b4fc: stur            w0, [x3, #0xb]
    // 0x46b500: StoreField: r3->field_f = r0
    //     0x46b500: stur            w0, [x3, #0xf]
    // 0x46b504: StoreField: r3->field_13 = r0
    //     0x46b504: stur            w0, [x3, #0x13]
    // 0x46b508: r1 = Null
    //     0x46b508: mov             x1, NULL
    // 0x46b50c: r2 = 2
    //     0x46b50c: movz            x2, #0x2
    // 0x46b510: r0 = AllocateArray()
    //     0x46b510: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b514: stur            x0, [fp, #-0x18]
    // 0x46b518: r16 = 28
    //     0x46b518: movz            x16, #0x1c
    // 0x46b51c: StoreField: r0->field_f = r16
    //     0x46b51c: stur            w16, [x0, #0xf]
    // 0x46b520: r1 = <int>
    //     0x46b520: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b524: r0 = AllocateGrowableArray()
    //     0x46b524: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b528: mov             x1, x0
    // 0x46b52c: ldur            x0, [fp, #-0x18]
    // 0x46b530: stur            x1, [fp, #-0x30]
    // 0x46b534: StoreField: r1->field_f = r0
    //     0x46b534: stur            w0, [x1, #0xf]
    // 0x46b538: r2 = 2
    //     0x46b538: movz            x2, #0x2
    // 0x46b53c: StoreField: r1->field_b = r2
    //     0x46b53c: stur            w2, [x1, #0xb]
    // 0x46b540: r0 = BoostHolder()
    //     0x46b540: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b544: r3 = 12
    //     0x46b544: movz            x3, #0xc
    // 0x46b548: StoreField: r0->field_b = r3
    //     0x46b548: stur            x3, [x0, #0xb]
    // 0x46b54c: r1 = 95
    //     0x46b54c: movz            x1, #0x5f
    // 0x46b550: StoreField: r0->field_13 = r1
    //     0x46b550: stur            x1, [x0, #0x13]
    // 0x46b554: ldur            x1, [fp, #-0x28]
    // 0x46b558: StoreField: r0->field_7 = r1
    //     0x46b558: stur            w1, [x0, #7]
    // 0x46b55c: ldur            x1, [fp, #-0x30]
    // 0x46b560: StoreField: r0->field_1b = r1
    //     0x46b560: stur            w1, [x0, #0x1b]
    // 0x46b564: ldur            x1, [fp, #-0x20]
    // 0x46b568: ArrayStore: r1[4] = r0  ; List_4
    //     0x46b568: add             x25, x1, #0x1f
    //     0x46b56c: str             w0, [x25]
    //     0x46b570: tbz             w0, #0, #0x46b58c
    //     0x46b574: ldurb           w16, [x1, #-1]
    //     0x46b578: ldurb           w17, [x0, #-1]
    //     0x46b57c: and             x16, x17, x16, lsr #2
    //     0x46b580: tst             x16, HEAP, lsr #32
    //     0x46b584: b.eq            #0x46b58c
    //     0x46b588: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b58c: r1 = Null
    //     0x46b58c: mov             x1, NULL
    // 0x46b590: r2 = 280
    //     0x46b590: movz            x2, #0x118
    // 0x46b594: r0 = CustomNum()
    //     0x46b594: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b598: stur            x0, [fp, #-0x18]
    // 0x46b59c: r0 = Boost()
    //     0x46b59c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b5a0: mov             x3, x0
    // 0x46b5a4: r0 = Instance_CustomNum
    //     0x46b5a4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b5a8: ldr             x0, [x0, #0xa70]
    // 0x46b5ac: stur            x3, [fp, #-0x28]
    // 0x46b5b0: StoreField: r3->field_7 = r0
    //     0x46b5b0: stur            w0, [x3, #7]
    // 0x46b5b4: StoreField: r3->field_b = r0
    //     0x46b5b4: stur            w0, [x3, #0xb]
    // 0x46b5b8: ldur            x1, [fp, #-0x18]
    // 0x46b5bc: StoreField: r3->field_f = r1
    //     0x46b5bc: stur            w1, [x3, #0xf]
    // 0x46b5c0: StoreField: r3->field_13 = r0
    //     0x46b5c0: stur            w0, [x3, #0x13]
    // 0x46b5c4: r1 = Null
    //     0x46b5c4: mov             x1, NULL
    // 0x46b5c8: r2 = 2
    //     0x46b5c8: movz            x2, #0x2
    // 0x46b5cc: r0 = AllocateArray()
    //     0x46b5cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b5d0: stur            x0, [fp, #-0x18]
    // 0x46b5d4: r16 = 24
    //     0x46b5d4: movz            x16, #0x18
    // 0x46b5d8: StoreField: r0->field_f = r16
    //     0x46b5d8: stur            w16, [x0, #0xf]
    // 0x46b5dc: r1 = <int>
    //     0x46b5dc: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b5e0: r0 = AllocateGrowableArray()
    //     0x46b5e0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b5e4: mov             x1, x0
    // 0x46b5e8: ldur            x0, [fp, #-0x18]
    // 0x46b5ec: stur            x1, [fp, #-0x30]
    // 0x46b5f0: StoreField: r1->field_f = r0
    //     0x46b5f0: stur            w0, [x1, #0xf]
    // 0x46b5f4: r2 = 2
    //     0x46b5f4: movz            x2, #0x2
    // 0x46b5f8: StoreField: r1->field_b = r2
    //     0x46b5f8: stur            w2, [x1, #0xb]
    // 0x46b5fc: r0 = BoostHolder()
    //     0x46b5fc: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b600: r3 = 11
    //     0x46b600: movz            x3, #0xb
    // 0x46b604: StoreField: r0->field_b = r3
    //     0x46b604: stur            x3, [x0, #0xb]
    // 0x46b608: r4 = 150
    //     0x46b608: movz            x4, #0x96
    // 0x46b60c: StoreField: r0->field_13 = r4
    //     0x46b60c: stur            x4, [x0, #0x13]
    // 0x46b610: ldur            x1, [fp, #-0x28]
    // 0x46b614: StoreField: r0->field_7 = r1
    //     0x46b614: stur            w1, [x0, #7]
    // 0x46b618: ldur            x1, [fp, #-0x30]
    // 0x46b61c: StoreField: r0->field_1b = r1
    //     0x46b61c: stur            w1, [x0, #0x1b]
    // 0x46b620: ldur            x1, [fp, #-0x20]
    // 0x46b624: ArrayStore: r1[5] = r0  ; List_4
    //     0x46b624: add             x25, x1, #0x23
    //     0x46b628: str             w0, [x25]
    //     0x46b62c: tbz             w0, #0, #0x46b648
    //     0x46b630: ldurb           w16, [x1, #-1]
    //     0x46b634: ldurb           w17, [x0, #-1]
    //     0x46b638: and             x16, x17, x16, lsr #2
    //     0x46b63c: tst             x16, HEAP, lsr #32
    //     0x46b640: b.eq            #0x46b648
    //     0x46b644: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b648: r1 = Null
    //     0x46b648: mov             x1, NULL
    // 0x46b64c: r2 = 2800000
    //     0x46b64c: movz            x2, #0xb980
    //     0x46b650: movk            x2, #0x2a, lsl #16
    // 0x46b654: r0 = CustomNum()
    //     0x46b654: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b658: stur            x0, [fp, #-0x18]
    // 0x46b65c: r0 = Boost()
    //     0x46b65c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b660: mov             x3, x0
    // 0x46b664: r0 = Instance_CustomNum
    //     0x46b664: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b668: ldr             x0, [x0, #0xa70]
    // 0x46b66c: stur            x3, [fp, #-0x28]
    // 0x46b670: StoreField: r3->field_7 = r0
    //     0x46b670: stur            w0, [x3, #7]
    // 0x46b674: StoreField: r3->field_b = r0
    //     0x46b674: stur            w0, [x3, #0xb]
    // 0x46b678: ldur            x1, [fp, #-0x18]
    // 0x46b67c: StoreField: r3->field_f = r1
    //     0x46b67c: stur            w1, [x3, #0xf]
    // 0x46b680: StoreField: r3->field_13 = r0
    //     0x46b680: stur            w0, [x3, #0x13]
    // 0x46b684: r1 = Null
    //     0x46b684: mov             x1, NULL
    // 0x46b688: r2 = 2
    //     0x46b688: movz            x2, #0x2
    // 0x46b68c: r0 = AllocateArray()
    //     0x46b68c: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b690: stur            x0, [fp, #-0x18]
    // 0x46b694: r16 = 22
    //     0x46b694: movz            x16, #0x16
    // 0x46b698: StoreField: r0->field_f = r16
    //     0x46b698: stur            w16, [x0, #0xf]
    // 0x46b69c: r1 = <int>
    //     0x46b69c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b6a0: r0 = AllocateGrowableArray()
    //     0x46b6a0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b6a4: mov             x1, x0
    // 0x46b6a8: ldur            x0, [fp, #-0x18]
    // 0x46b6ac: stur            x1, [fp, #-0x30]
    // 0x46b6b0: StoreField: r1->field_f = r0
    //     0x46b6b0: stur            w0, [x1, #0xf]
    // 0x46b6b4: r2 = 2
    //     0x46b6b4: movz            x2, #0x2
    // 0x46b6b8: StoreField: r1->field_b = r2
    //     0x46b6b8: stur            w2, [x1, #0xb]
    // 0x46b6bc: r0 = BoostHolder()
    //     0x46b6bc: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b6c0: r3 = 14
    //     0x46b6c0: movz            x3, #0xe
    // 0x46b6c4: StoreField: r0->field_b = r3
    //     0x46b6c4: stur            x3, [x0, #0xb]
    // 0x46b6c8: r1 = 68
    //     0x46b6c8: movz            x1, #0x44
    // 0x46b6cc: StoreField: r0->field_13 = r1
    //     0x46b6cc: stur            x1, [x0, #0x13]
    // 0x46b6d0: ldur            x1, [fp, #-0x28]
    // 0x46b6d4: StoreField: r0->field_7 = r1
    //     0x46b6d4: stur            w1, [x0, #7]
    // 0x46b6d8: ldur            x1, [fp, #-0x30]
    // 0x46b6dc: StoreField: r0->field_1b = r1
    //     0x46b6dc: stur            w1, [x0, #0x1b]
    // 0x46b6e0: ldur            x1, [fp, #-0x20]
    // 0x46b6e4: ArrayStore: r1[6] = r0  ; List_4
    //     0x46b6e4: add             x25, x1, #0x27
    //     0x46b6e8: str             w0, [x25]
    //     0x46b6ec: tbz             w0, #0, #0x46b708
    //     0x46b6f0: ldurb           w16, [x1, #-1]
    //     0x46b6f4: ldurb           w17, [x0, #-1]
    //     0x46b6f8: and             x16, x17, x16, lsr #2
    //     0x46b6fc: tst             x16, HEAP, lsr #32
    //     0x46b700: b.eq            #0x46b708
    //     0x46b704: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b708: r1 = Null
    //     0x46b708: mov             x1, NULL
    // 0x46b70c: r2 = 1120
    //     0x46b70c: movz            x2, #0x460
    // 0x46b710: r0 = CustomNum()
    //     0x46b710: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b714: stur            x0, [fp, #-0x18]
    // 0x46b718: r0 = Boost()
    //     0x46b718: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b71c: mov             x3, x0
    // 0x46b720: ldur            x0, [fp, #-0x18]
    // 0x46b724: stur            x3, [fp, #-0x28]
    // 0x46b728: StoreField: r3->field_7 = r0
    //     0x46b728: stur            w0, [x3, #7]
    // 0x46b72c: r0 = Instance_CustomNum
    //     0x46b72c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b730: ldr             x0, [x0, #0xa70]
    // 0x46b734: StoreField: r3->field_b = r0
    //     0x46b734: stur            w0, [x3, #0xb]
    // 0x46b738: StoreField: r3->field_f = r0
    //     0x46b738: stur            w0, [x3, #0xf]
    // 0x46b73c: StoreField: r3->field_13 = r0
    //     0x46b73c: stur            w0, [x3, #0x13]
    // 0x46b740: r1 = Null
    //     0x46b740: mov             x1, NULL
    // 0x46b744: r2 = 2
    //     0x46b744: movz            x2, #0x2
    // 0x46b748: r0 = AllocateArray()
    //     0x46b748: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b74c: stur            x0, [fp, #-0x18]
    // 0x46b750: r16 = 28
    //     0x46b750: movz            x16, #0x1c
    // 0x46b754: StoreField: r0->field_f = r16
    //     0x46b754: stur            w16, [x0, #0xf]
    // 0x46b758: r1 = <int>
    //     0x46b758: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b75c: r0 = AllocateGrowableArray()
    //     0x46b75c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b760: mov             x1, x0
    // 0x46b764: ldur            x0, [fp, #-0x18]
    // 0x46b768: stur            x1, [fp, #-0x30]
    // 0x46b76c: StoreField: r1->field_f = r0
    //     0x46b76c: stur            w0, [x1, #0xf]
    // 0x46b770: r2 = 2
    //     0x46b770: movz            x2, #0x2
    // 0x46b774: StoreField: r1->field_b = r2
    //     0x46b774: stur            w2, [x1, #0xb]
    // 0x46b778: r0 = BoostHolder()
    //     0x46b778: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b77c: mov             x1, x0
    // 0x46b780: r0 = 13
    //     0x46b780: movz            x0, #0xd
    // 0x46b784: StoreField: r1->field_b = r0
    //     0x46b784: stur            x0, [x1, #0xb]
    // 0x46b788: r0 = 150
    //     0x46b788: movz            x0, #0x96
    // 0x46b78c: StoreField: r1->field_13 = r0
    //     0x46b78c: stur            x0, [x1, #0x13]
    // 0x46b790: ldur            x0, [fp, #-0x28]
    // 0x46b794: StoreField: r1->field_7 = r0
    //     0x46b794: stur            w0, [x1, #7]
    // 0x46b798: ldur            x0, [fp, #-0x30]
    // 0x46b79c: StoreField: r1->field_1b = r0
    //     0x46b79c: stur            w0, [x1, #0x1b]
    // 0x46b7a0: mov             x0, x1
    // 0x46b7a4: ldur            x1, [fp, #-0x20]
    // 0x46b7a8: ArrayStore: r1[7] = r0  ; List_4
    //     0x46b7a8: add             x25, x1, #0x2b
    //     0x46b7ac: str             w0, [x25]
    //     0x46b7b0: tbz             w0, #0, #0x46b7cc
    //     0x46b7b4: ldurb           w16, [x1, #-1]
    //     0x46b7b8: ldurb           w17, [x0, #-1]
    //     0x46b7bc: and             x16, x17, x16, lsr #2
    //     0x46b7c0: tst             x16, HEAP, lsr #32
    //     0x46b7c4: b.eq            #0x46b7cc
    //     0x46b7c8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b7cc: r1 = Null
    //     0x46b7cc: mov             x1, NULL
    // 0x46b7d0: r2 = 2048
    //     0x46b7d0: movz            x2, #0x800
    // 0x46b7d4: r0 = CustomNum()
    //     0x46b7d4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b7d8: stur            x0, [fp, #-0x18]
    // 0x46b7dc: r0 = Boost()
    //     0x46b7dc: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b7e0: mov             x3, x0
    // 0x46b7e4: r0 = Instance_CustomNum
    //     0x46b7e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b7e8: ldr             x0, [x0, #0xa70]
    // 0x46b7ec: stur            x3, [fp, #-0x28]
    // 0x46b7f0: StoreField: r3->field_7 = r0
    //     0x46b7f0: stur            w0, [x3, #7]
    // 0x46b7f4: StoreField: r3->field_b = r0
    //     0x46b7f4: stur            w0, [x3, #0xb]
    // 0x46b7f8: ldur            x1, [fp, #-0x18]
    // 0x46b7fc: StoreField: r3->field_f = r1
    //     0x46b7fc: stur            w1, [x3, #0xf]
    // 0x46b800: StoreField: r3->field_13 = r0
    //     0x46b800: stur            w0, [x3, #0x13]
    // 0x46b804: r1 = Null
    //     0x46b804: mov             x1, NULL
    // 0x46b808: r2 = 2
    //     0x46b808: movz            x2, #0x2
    // 0x46b80c: r0 = AllocateArray()
    //     0x46b80c: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b810: stur            x0, [fp, #-0x18]
    // 0x46b814: r16 = 24
    //     0x46b814: movz            x16, #0x18
    // 0x46b818: StoreField: r0->field_f = r16
    //     0x46b818: stur            w16, [x0, #0xf]
    // 0x46b81c: r1 = <int>
    //     0x46b81c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b820: r0 = AllocateGrowableArray()
    //     0x46b820: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b824: mov             x1, x0
    // 0x46b828: ldur            x0, [fp, #-0x18]
    // 0x46b82c: stur            x1, [fp, #-0x30]
    // 0x46b830: StoreField: r1->field_f = r0
    //     0x46b830: stur            w0, [x1, #0xf]
    // 0x46b834: r2 = 2
    //     0x46b834: movz            x2, #0x2
    // 0x46b838: StoreField: r1->field_b = r2
    //     0x46b838: stur            w2, [x1, #0xb]
    // 0x46b83c: r0 = BoostHolder()
    //     0x46b83c: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b840: mov             x1, x0
    // 0x46b844: r0 = 12
    //     0x46b844: movz            x0, #0xc
    // 0x46b848: StoreField: r1->field_b = r0
    //     0x46b848: stur            x0, [x1, #0xb]
    // 0x46b84c: r0 = 173
    //     0x46b84c: movz            x0, #0xad
    // 0x46b850: StoreField: r1->field_13 = r0
    //     0x46b850: stur            x0, [x1, #0x13]
    // 0x46b854: ldur            x0, [fp, #-0x28]
    // 0x46b858: StoreField: r1->field_7 = r0
    //     0x46b858: stur            w0, [x1, #7]
    // 0x46b85c: ldur            x0, [fp, #-0x30]
    // 0x46b860: StoreField: r1->field_1b = r0
    //     0x46b860: stur            w0, [x1, #0x1b]
    // 0x46b864: mov             x0, x1
    // 0x46b868: ldur            x1, [fp, #-0x20]
    // 0x46b86c: ArrayStore: r1[8] = r0  ; List_4
    //     0x46b86c: add             x25, x1, #0x2f
    //     0x46b870: str             w0, [x25]
    //     0x46b874: tbz             w0, #0, #0x46b890
    //     0x46b878: ldurb           w16, [x1, #-1]
    //     0x46b87c: ldurb           w17, [x0, #-1]
    //     0x46b880: and             x16, x17, x16, lsr #2
    //     0x46b884: tst             x16, HEAP, lsr #32
    //     0x46b888: b.eq            #0x46b890
    //     0x46b88c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b890: r1 = Null
    //     0x46b890: mov             x1, NULL
    // 0x46b894: r2 = 2000000
    //     0x46b894: movz            x2, #0x8480
    //     0x46b898: movk            x2, #0x1e, lsl #16
    // 0x46b89c: r0 = CustomNum()
    //     0x46b89c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b8a0: stur            x0, [fp, #-0x18]
    // 0x46b8a4: r0 = Boost()
    //     0x46b8a4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b8a8: mov             x3, x0
    // 0x46b8ac: r0 = Instance_CustomNum
    //     0x46b8ac: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b8b0: ldr             x0, [x0, #0xa70]
    // 0x46b8b4: stur            x3, [fp, #-0x28]
    // 0x46b8b8: StoreField: r3->field_7 = r0
    //     0x46b8b8: stur            w0, [x3, #7]
    // 0x46b8bc: StoreField: r3->field_b = r0
    //     0x46b8bc: stur            w0, [x3, #0xb]
    // 0x46b8c0: ldur            x1, [fp, #-0x18]
    // 0x46b8c4: StoreField: r3->field_f = r1
    //     0x46b8c4: stur            w1, [x3, #0xf]
    // 0x46b8c8: StoreField: r3->field_13 = r0
    //     0x46b8c8: stur            w0, [x3, #0x13]
    // 0x46b8cc: r1 = Null
    //     0x46b8cc: mov             x1, NULL
    // 0x46b8d0: r2 = 2
    //     0x46b8d0: movz            x2, #0x2
    // 0x46b8d4: r0 = AllocateArray()
    //     0x46b8d4: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b8d8: stur            x0, [fp, #-0x18]
    // 0x46b8dc: r16 = 26
    //     0x46b8dc: movz            x16, #0x1a
    // 0x46b8e0: StoreField: r0->field_f = r16
    //     0x46b8e0: stur            w16, [x0, #0xf]
    // 0x46b8e4: r1 = <int>
    //     0x46b8e4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b8e8: r0 = AllocateGrowableArray()
    //     0x46b8e8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b8ec: mov             x1, x0
    // 0x46b8f0: ldur            x0, [fp, #-0x18]
    // 0x46b8f4: stur            x1, [fp, #-0x30]
    // 0x46b8f8: StoreField: r1->field_f = r0
    //     0x46b8f8: stur            w0, [x1, #0xf]
    // 0x46b8fc: r2 = 2
    //     0x46b8fc: movz            x2, #0x2
    // 0x46b900: StoreField: r1->field_b = r2
    //     0x46b900: stur            w2, [x1, #0xb]
    // 0x46b904: r0 = BoostHolder()
    //     0x46b904: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b908: mov             x1, x0
    // 0x46b90c: r0 = 14
    //     0x46b90c: movz            x0, #0xe
    // 0x46b910: StoreField: r1->field_b = r0
    //     0x46b910: stur            x0, [x1, #0xb]
    // 0x46b914: r0 = 165
    //     0x46b914: movz            x0, #0xa5
    // 0x46b918: StoreField: r1->field_13 = r0
    //     0x46b918: stur            x0, [x1, #0x13]
    // 0x46b91c: ldur            x0, [fp, #-0x28]
    // 0x46b920: StoreField: r1->field_7 = r0
    //     0x46b920: stur            w0, [x1, #7]
    // 0x46b924: ldur            x0, [fp, #-0x30]
    // 0x46b928: StoreField: r1->field_1b = r0
    //     0x46b928: stur            w0, [x1, #0x1b]
    // 0x46b92c: mov             x0, x1
    // 0x46b930: ldur            x1, [fp, #-0x20]
    // 0x46b934: ArrayStore: r1[9] = r0  ; List_4
    //     0x46b934: add             x25, x1, #0x33
    //     0x46b938: str             w0, [x25]
    //     0x46b93c: tbz             w0, #0, #0x46b958
    //     0x46b940: ldurb           w16, [x1, #-1]
    //     0x46b944: ldurb           w17, [x0, #-1]
    //     0x46b948: and             x16, x17, x16, lsr #2
    //     0x46b94c: tst             x16, HEAP, lsr #32
    //     0x46b950: b.eq            #0x46b958
    //     0x46b954: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46b958: r1 = Null
    //     0x46b958: mov             x1, NULL
    // 0x46b95c: r2 = 1600
    //     0x46b95c: movz            x2, #0x640
    // 0x46b960: r0 = CustomNum()
    //     0x46b960: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46b964: stur            x0, [fp, #-0x18]
    // 0x46b968: r0 = Boost()
    //     0x46b968: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x46b96c: mov             x3, x0
    // 0x46b970: r0 = Instance_CustomNum
    //     0x46b970: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x46b974: ldr             x0, [x0, #0xa70]
    // 0x46b978: stur            x3, [fp, #-0x28]
    // 0x46b97c: StoreField: r3->field_7 = r0
    //     0x46b97c: stur            w0, [x3, #7]
    // 0x46b980: StoreField: r3->field_b = r0
    //     0x46b980: stur            w0, [x3, #0xb]
    // 0x46b984: ldur            x1, [fp, #-0x18]
    // 0x46b988: StoreField: r3->field_f = r1
    //     0x46b988: stur            w1, [x3, #0xf]
    // 0x46b98c: StoreField: r3->field_13 = r0
    //     0x46b98c: stur            w0, [x3, #0x13]
    // 0x46b990: r1 = Null
    //     0x46b990: mov             x1, NULL
    // 0x46b994: r2 = 2
    //     0x46b994: movz            x2, #0x2
    // 0x46b998: r0 = AllocateArray()
    //     0x46b998: bl              #0x82746c  ; AllocateArrayStub
    // 0x46b99c: stur            x0, [fp, #-0x18]
    // 0x46b9a0: r16 = 22
    //     0x46b9a0: movz            x16, #0x16
    // 0x46b9a4: StoreField: r0->field_f = r16
    //     0x46b9a4: stur            w16, [x0, #0xf]
    // 0x46b9a8: r1 = <int>
    //     0x46b9a8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46b9ac: r0 = AllocateGrowableArray()
    //     0x46b9ac: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46b9b0: mov             x1, x0
    // 0x46b9b4: ldur            x0, [fp, #-0x18]
    // 0x46b9b8: stur            x1, [fp, #-0x30]
    // 0x46b9bc: StoreField: r1->field_f = r0
    //     0x46b9bc: stur            w0, [x1, #0xf]
    // 0x46b9c0: r2 = 2
    //     0x46b9c0: movz            x2, #0x2
    // 0x46b9c4: StoreField: r1->field_b = r2
    //     0x46b9c4: stur            w2, [x1, #0xb]
    // 0x46b9c8: r0 = BoostHolder()
    //     0x46b9c8: bl              #0x46be78  ; AllocateBoostHolderStub -> BoostHolder (size=0x20)
    // 0x46b9cc: mov             x1, x0
    // 0x46b9d0: r0 = 11
    //     0x46b9d0: movz            x0, #0xb
    // 0x46b9d4: StoreField: r1->field_b = r0
    //     0x46b9d4: stur            x0, [x1, #0xb]
    // 0x46b9d8: r0 = 275
    //     0x46b9d8: movz            x0, #0x113
    // 0x46b9dc: StoreField: r1->field_13 = r0
    //     0x46b9dc: stur            x0, [x1, #0x13]
    // 0x46b9e0: ldur            x0, [fp, #-0x28]
    // 0x46b9e4: StoreField: r1->field_7 = r0
    //     0x46b9e4: stur            w0, [x1, #7]
    // 0x46b9e8: ldur            x0, [fp, #-0x30]
    // 0x46b9ec: StoreField: r1->field_1b = r0
    //     0x46b9ec: stur            w0, [x1, #0x1b]
    // 0x46b9f0: mov             x0, x1
    // 0x46b9f4: ldur            x1, [fp, #-0x20]
    // 0x46b9f8: ArrayStore: r1[10] = r0  ; List_4
    //     0x46b9f8: add             x25, x1, #0x37
    //     0x46b9fc: str             w0, [x25]
    //     0x46ba00: tbz             w0, #0, #0x46ba1c
    //     0x46ba04: ldurb           w16, [x1, #-1]
    //     0x46ba08: ldurb           w17, [x0, #-1]
    //     0x46ba0c: and             x16, x17, x16, lsr #2
    //     0x46ba10: tst             x16, HEAP, lsr #32
    //     0x46ba14: b.eq            #0x46ba1c
    //     0x46ba18: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46ba1c: r1 = <BoostHolder>
    //     0x46ba1c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11010] TypeArguments: <BoostHolder>
    //     0x46ba20: ldr             x1, [x1, #0x10]
    // 0x46ba24: r0 = AllocateGrowableArray()
    //     0x46ba24: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x46ba28: mov             x1, x0
    // 0x46ba2c: ldur            x0, [fp, #-0x20]
    // 0x46ba30: StoreField: r1->field_f = r0
    //     0x46ba30: stur            w0, [x1, #0xf]
    // 0x46ba34: r3 = 22
    //     0x46ba34: movz            x3, #0x16
    // 0x46ba38: StoreField: r1->field_b = r3
    //     0x46ba38: stur            w3, [x1, #0xb]
    // 0x46ba3c: mov             x0, x1
    // 0x46ba40: ldur            x4, [fp, #-8]
    // 0x46ba44: StoreField: r4->field_a7 = r0
    //     0x46ba44: stur            w0, [x4, #0xa7]
    //     0x46ba48: ldurb           w16, [x4, #-1]
    //     0x46ba4c: ldurb           w17, [x0, #-1]
    //     0x46ba50: and             x16, x17, x16, lsr #2
    //     0x46ba54: tst             x16, HEAP, lsr #32
    //     0x46ba58: b.eq            #0x46ba60
    //     0x46ba5c: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x46ba60: r1 = Function '<anonymous closure>':.
    //     0x46ba60: add             x1, PP, #0x11, lsl #12  ; [pp+0x11018] AnonymousClosure: (0x46c2c8), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x46ba64: ldr             x1, [x1, #0x18]
    // 0x46ba68: r2 = Null
    //     0x46ba68: mov             x2, NULL
    // 0x46ba6c: r0 = AllocateClosure()
    //     0x46ba6c: bl              #0x826750  ; AllocateClosureStub
    // 0x46ba70: r1 = Function '<anonymous closure>':.
    //     0x46ba70: add             x1, PP, #0x11, lsl #12  ; [pp+0x11020] AnonymousClosure: (0x46c168), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x46ba74: ldr             x1, [x1, #0x20]
    // 0x46ba78: r2 = Null
    //     0x46ba78: mov             x2, NULL
    // 0x46ba7c: stur            x0, [fp, #-0x18]
    // 0x46ba80: r0 = AllocateClosure()
    //     0x46ba80: bl              #0x826750  ; AllocateClosureStub
    // 0x46ba84: r1 = Function '<anonymous closure>':.
    //     0x46ba84: add             x1, PP, #0x11, lsl #12  ; [pp+0x11028] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x46ba88: ldr             x1, [x1, #0x28]
    // 0x46ba8c: r2 = Null
    //     0x46ba8c: mov             x2, NULL
    // 0x46ba90: stur            x0, [fp, #-0x20]
    // 0x46ba94: r0 = AllocateClosure()
    //     0x46ba94: bl              #0x826750  ; AllocateClosureStub
    // 0x46ba98: r1 = Function '<anonymous closure>':.
    //     0x46ba98: add             x1, PP, #0x11, lsl #12  ; [pp+0x11030] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46ba9c: ldr             x1, [x1, #0x30]
    // 0x46baa0: r2 = Null
    //     0x46baa0: mov             x2, NULL
    // 0x46baa4: stur            x0, [fp, #-0x28]
    // 0x46baa8: r0 = AllocateClosure()
    //     0x46baa8: bl              #0x826750  ; AllocateClosureStub
    // 0x46baac: ldur            x1, [fp, #-8]
    // 0x46bab0: ldur            x2, [fp, #-0x10]
    // 0x46bab4: ldur            x3, [fp, #-0x18]
    // 0x46bab8: ldur            x5, [fp, #-0x20]
    // 0x46babc: ldur            x6, [fp, #-0x28]
    // 0x46bac0: mov             x7, x0
    // 0x46bac4: r0 = IPlayableGameState()
    //     0x46bac4: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46bac8: ldur            x3, [fp, #-0x10]
    // 0x46bacc: cmp             w3, NULL
    // 0x46bad0: b.ne            #0x46badc
    // 0x46bad4: r3 = Null
    //     0x46bad4: mov             x3, NULL
    // 0x46bad8: b               #0x46bafc
    // 0x46badc: r0 = LoadClassIdInstr(r3)
    //     0x46badc: ldur            x0, [x3, #-1]
    //     0x46bae0: ubfx            x0, x0, #0xc, #0x14
    // 0x46bae4: mov             x1, x3
    // 0x46bae8: r2 = 38
    //     0x46bae8: movz            x2, #0x26
    // 0x46baec: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46baec: sub             lr, x0, #1, lsl #12
    //     0x46baf0: ldr             lr, [x21, lr, lsl #3]
    //     0x46baf4: blr             lr
    // 0x46baf8: mov             x3, x0
    // 0x46bafc: mov             x0, x3
    // 0x46bb00: stur            x3, [fp, #-0x18]
    // 0x46bb04: r2 = Null
    //     0x46bb04: mov             x2, NULL
    // 0x46bb08: r1 = Null
    //     0x46bb08: mov             x1, NULL
    // 0x46bb0c: r8 = Map?
    //     0x46bb0c: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x46bb10: ldr             x8, [x8, #0x38]
    // 0x46bb14: r3 = Null
    //     0x46bb14: add             x3, PP, #0x11, lsl #12  ; [pp+0x11038] Null
    //     0x46bb18: ldr             x3, [x3, #0x38]
    // 0x46bb1c: r0 = Map?()
    //     0x46bb1c: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x46bb20: ldur            x3, [fp, #-0x18]
    // 0x46bb24: cmp             w3, NULL
    // 0x46bb28: b.eq            #0x46bb50
    // 0x46bb2c: r0 = LoadClassIdInstr(r3)
    //     0x46bb2c: ldur            x0, [x3, #-1]
    //     0x46bb30: ubfx            x0, x0, #0xc, #0x14
    // 0x46bb34: mov             x1, x3
    // 0x46bb38: r2 = 0
    //     0x46bb38: movz            x2, #0
    // 0x46bb3c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46bb3c: sub             lr, x0, #1, lsl #12
    //     0x46bb40: ldr             lr, [x21, lr, lsl #3]
    //     0x46bb44: blr             lr
    // 0x46bb48: cmp             w0, NULL
    // 0x46bb4c: b.ne            #0x46bb5c
    // 0x46bb50: r0 = IntWrapper()
    //     0x46bb50: bl              #0x46bea4  ; AllocateIntWrapperStub -> IntWrapper (size=0x10)
    // 0x46bb54: StoreField: r0->field_7 = rZR
    //     0x46bb54: stur            xzr, [x0, #7]
    // 0x46bb58: b               #0x46bbd8
    // 0x46bb5c: ldur            x1, [fp, #-0x18]
    // 0x46bb60: r0 = LoadClassIdInstr(r1)
    //     0x46bb60: ldur            x0, [x1, #-1]
    //     0x46bb64: ubfx            x0, x0, #0xc, #0x14
    // 0x46bb68: r2 = 0
    //     0x46bb68: movz            x2, #0
    // 0x46bb6c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46bb6c: sub             lr, x0, #1, lsl #12
    //     0x46bb70: ldr             lr, [x21, lr, lsl #3]
    //     0x46bb74: blr             lr
    // 0x46bb78: mov             x3, x0
    // 0x46bb7c: r2 = Null
    //     0x46bb7c: mov             x2, NULL
    // 0x46bb80: r1 = Null
    //     0x46bb80: mov             x1, NULL
    // 0x46bb84: stur            x3, [fp, #-0x18]
    // 0x46bb88: branchIfSmi(r0, 0x46bbb0)
    //     0x46bb88: tbz             w0, #0, #0x46bbb0
    // 0x46bb8c: r4 = LoadClassIdInstr(r0)
    //     0x46bb8c: ldur            x4, [x0, #-1]
    //     0x46bb90: ubfx            x4, x4, #0xc, #0x14
    // 0x46bb94: sub             x4, x4, #0x3c
    // 0x46bb98: cmp             x4, #1
    // 0x46bb9c: b.ls            #0x46bbb0
    // 0x46bba0: r8 = int
    //     0x46bba0: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x46bba4: r3 = Null
    //     0x46bba4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11048] Null
    //     0x46bba8: ldr             x3, [x3, #0x48]
    // 0x46bbac: r0 = int()
    //     0x46bbac: bl              #0x82bb04  ; IsType_int_Stub
    // 0x46bbb0: ldur            x0, [fp, #-0x18]
    // 0x46bbb4: r1 = LoadInt32Instr(r0)
    //     0x46bbb4: sbfx            x1, x0, #1, #0x1f
    //     0x46bbb8: tbz             w0, #0, #0x46bbc0
    //     0x46bbbc: ldur            x1, [x0, #7]
    // 0x46bbc0: stur            x1, [fp, #-0x38]
    // 0x46bbc4: r0 = IntWrapper()
    //     0x46bbc4: bl              #0x46bea4  ; AllocateIntWrapperStub -> IntWrapper (size=0x10)
    // 0x46bbc8: mov             x1, x0
    // 0x46bbcc: ldur            x0, [fp, #-0x38]
    // 0x46bbd0: StoreField: r1->field_7 = r0
    //     0x46bbd0: stur            x0, [x1, #7]
    // 0x46bbd4: mov             x0, x1
    // 0x46bbd8: ldur            x3, [fp, #-8]
    // 0x46bbdc: StoreField: r3->field_93 = r0
    //     0x46bbdc: stur            w0, [x3, #0x93]
    //     0x46bbe0: ldurb           w16, [x3, #-1]
    //     0x46bbe4: ldurb           w17, [x0, #-1]
    //     0x46bbe8: and             x16, x17, x16, lsr #2
    //     0x46bbec: tst             x16, HEAP, lsr #32
    //     0x46bbf0: b.eq            #0x46bbf8
    //     0x46bbf4: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46bbf8: LoadField: r0 = r3->field_8b
    //     0x46bbf8: ldur            w0, [x3, #0x8b]
    // 0x46bbfc: DecompressPointer r0
    //     0x46bbfc: add             x0, x0, HEAP, lsl #32
    // 0x46bc00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x46bc04: cmp             w0, w16
    // 0x46bc08: b.eq            #0x46be6c
    // 0x46bc0c: mov             x1, x0
    // 0x46bc10: stur            x0, [fp, #-0x18]
    // 0x46bc14: r2 = 22
    //     0x46bc14: movz            x2, #0x16
    // 0x46bc18: r0 = _getValueOrData()
    //     0x46bc18: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x46bc1c: mov             x1, x0
    // 0x46bc20: ldur            x0, [fp, #-0x18]
    // 0x46bc24: LoadField: r2 = r0->field_f
    //     0x46bc24: ldur            w2, [x0, #0xf]
    // 0x46bc28: DecompressPointer r2
    //     0x46bc28: add             x2, x2, HEAP, lsl #32
    // 0x46bc2c: cmp             w2, w1
    // 0x46bc30: b.ne            #0x46bc3c
    // 0x46bc34: r0 = Null
    //     0x46bc34: mov             x0, NULL
    // 0x46bc38: b               #0x46bc40
    // 0x46bc3c: mov             x0, x1
    // 0x46bc40: cmp             w0, NULL
    // 0x46bc44: b.ne            #0x46bc50
    // 0x46bc48: r0 = Null
    //     0x46bc48: mov             x0, NULL
    // 0x46bc4c: b               #0x46bc70
    // 0x46bc50: LoadField: r1 = r0->field_27
    //     0x46bc50: ldur            w1, [x0, #0x27]
    // 0x46bc54: DecompressPointer r1
    //     0x46bc54: add             x1, x1, HEAP, lsl #32
    // 0x46bc58: cmp             w1, NULL
    // 0x46bc5c: b.ne            #0x46bc68
    // 0x46bc60: r0 = Null
    //     0x46bc60: mov             x0, NULL
    // 0x46bc64: b               #0x46bc70
    // 0x46bc68: LoadField: r0 = r1->field_f
    //     0x46bc68: ldur            w0, [x1, #0xf]
    // 0x46bc6c: DecompressPointer r0
    //     0x46bc6c: add             x0, x0, HEAP, lsl #32
    // 0x46bc70: cmp             w0, NULL
    // 0x46bc74: b.ne            #0x46bc84
    // 0x46bc78: r1 = Instance_CustomNum
    //     0x46bc78: add             x1, PP, #0x11, lsl #12  ; [pp+0x11058] Obj!CustomNum@828c61
    //     0x46bc7c: ldr             x1, [x1, #0x58]
    // 0x46bc80: b               #0x46bc88
    // 0x46bc84: mov             x1, x0
    // 0x46bc88: ldur            x0, [fp, #-8]
    // 0x46bc8c: r2 = Instance_CustomNum
    //     0x46bc8c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x46bc90: ldr             x2, [x2, #0x60]
    // 0x46bc94: r0 = mult2()
    //     0x46bc94: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x46bc98: mov             x3, x0
    // 0x46bc9c: ldur            x0, [fp, #-8]
    // 0x46bca0: stur            x3, [fp, #-0x20]
    // 0x46bca4: LoadField: r4 = r0->field_37
    //     0x46bca4: ldur            w4, [x0, #0x37]
    // 0x46bca8: DecompressPointer r4
    //     0x46bca8: add             x4, x4, HEAP, lsl #32
    // 0x46bcac: mov             x1, x4
    // 0x46bcb0: stur            x4, [fp, #-0x18]
    // 0x46bcb4: r2 = Instance_Chapter15Stat
    //     0x46bcb4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x46bcb8: ldr             x2, [x2, #0x68]
    // 0x46bcbc: r0 = _getValueOrData()
    //     0x46bcbc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x46bcc0: mov             x1, x0
    // 0x46bcc4: ldur            x0, [fp, #-0x18]
    // 0x46bcc8: LoadField: r2 = r0->field_f
    //     0x46bcc8: ldur            w2, [x0, #0xf]
    // 0x46bccc: DecompressPointer r2
    //     0x46bccc: add             x2, x2, HEAP, lsl #32
    // 0x46bcd0: cmp             w2, w1
    // 0x46bcd4: b.ne            #0x46bce0
    // 0x46bcd8: r0 = Null
    //     0x46bcd8: mov             x0, NULL
    // 0x46bcdc: b               #0x46bce4
    // 0x46bce0: mov             x0, x1
    // 0x46bce4: cmp             w0, NULL
    // 0x46bce8: b.ne            #0x46bcf4
    // 0x46bcec: r0 = Instance_CustomNum
    //     0x46bcec: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x46bcf0: ldr             x0, [x0, #0xaf8]
    // 0x46bcf4: ldur            x3, [fp, #-0x20]
    // 0x46bcf8: LoadField: d0 = r3->field_7
    //     0x46bcf8: ldur            d0, [x3, #7]
    // 0x46bcfc: LoadField: d1 = r0->field_7
    //     0x46bcfc: ldur            d1, [x0, #7]
    // 0x46bd00: fcmp            d0, d1
    // 0x46bd04: b.le            #0x46bd20
    // 0x46bd08: ldur            x0, [fp, #-8]
    // 0x46bd0c: LoadField: r1 = r0->field_37
    //     0x46bd0c: ldur            w1, [x0, #0x37]
    // 0x46bd10: DecompressPointer r1
    //     0x46bd10: add             x1, x1, HEAP, lsl #32
    // 0x46bd14: r2 = Instance_Chapter15Stat
    //     0x46bd14: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x46bd18: ldr             x2, [x2, #0x68]
    // 0x46bd1c: r0 = []=()
    //     0x46bd1c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x46bd20: ldur            x1, [fp, #-0x10]
    // 0x46bd24: cmp             w1, NULL
    // 0x46bd28: b.eq            #0x46be54
    // 0x46bd2c: r0 = LoadClassIdInstr(r1)
    //     0x46bd2c: ldur            x0, [x1, #-1]
    //     0x46bd30: ubfx            x0, x0, #0xc, #0x14
    // 0x46bd34: r2 = 2
    //     0x46bd34: movz            x2, #0x2
    // 0x46bd38: r0 = GDT[cid_x0 + -0x1000]()
    //     0x46bd38: sub             lr, x0, #1, lsl #12
    //     0x46bd3c: ldr             lr, [x21, lr, lsl #3]
    //     0x46bd40: blr             lr
    // 0x46bd44: mov             x3, x0
    // 0x46bd48: r2 = Null
    //     0x46bd48: mov             x2, NULL
    // 0x46bd4c: r1 = Null
    //     0x46bd4c: mov             x1, NULL
    // 0x46bd50: stur            x3, [fp, #-0x10]
    // 0x46bd54: cmp             w0, NULL
    // 0x46bd58: b.eq            #0x46bdf4
    // 0x46bd5c: branchIfSmi(r0, 0x46bdf4)
    //     0x46bd5c: tbz             w0, #0, #0x46bdf4
    // 0x46bd60: r3 = LoadClassIdInstr(r0)
    //     0x46bd60: ldur            x3, [x0, #-1]
    //     0x46bd64: ubfx            x3, x3, #0xc, #0x14
    // 0x46bd68: cmp             x3, #0xfd9
    // 0x46bd6c: b.eq            #0x46bdfc
    // 0x46bd70: sub             x3, x3, #0x5a
    // 0x46bd74: cmp             x3, #2
    // 0x46bd78: b.ls            #0x46bdfc
    // 0x46bd7c: r4 = LoadClassIdInstr(r0)
    //     0x46bd7c: ldur            x4, [x0, #-1]
    //     0x46bd80: ubfx            x4, x4, #0xc, #0x14
    // 0x46bd84: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x46bd88: ldr             x3, [x3, #0x18]
    // 0x46bd8c: ldr             x3, [x3, x4, lsl #3]
    // 0x46bd90: LoadField: r3 = r3->field_2b
    //     0x46bd90: ldur            w3, [x3, #0x2b]
    // 0x46bd94: DecompressPointer r3
    //     0x46bd94: add             x3, x3, HEAP, lsl #32
    // 0x46bd98: cmp             w3, NULL
    // 0x46bd9c: b.eq            #0x46bdf4
    // 0x46bda0: LoadField: r3 = r3->field_f
    //     0x46bda0: ldur            w3, [x3, #0xf]
    // 0x46bda4: lsr             x3, x3, #3
    // 0x46bda8: cmp             x3, #0xfd9
    // 0x46bdac: b.eq            #0x46bdfc
    // 0x46bdb0: r3 = SubtypeTestCache
    //     0x46bdb0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11070] SubtypeTestCache
    //     0x46bdb4: ldr             x3, [x3, #0x70]
    // 0x46bdb8: r30 = Subtype1TestCacheStub
    //     0x46bdb8: ldr             lr, [PP, #0x908]  ; [pp+0x908] Stub: Subtype1TestCache (0x322fcc)
    // 0x46bdbc: LoadField: r30 = r30->field_7
    //     0x46bdbc: ldur            lr, [lr, #7]
    // 0x46bdc0: blr             lr
    // 0x46bdc4: cmp             w7, NULL
    // 0x46bdc8: b.eq            #0x46bdd4
    // 0x46bdcc: tbnz            w7, #4, #0x46bdf4
    // 0x46bdd0: b               #0x46bdfc
    // 0x46bdd4: r8 = List
    //     0x46bdd4: add             x8, PP, #0x11, lsl #12  ; [pp+0x11078] Type: List
    //     0x46bdd8: ldr             x8, [x8, #0x78]
    // 0x46bddc: r3 = SubtypeTestCache
    //     0x46bddc: add             x3, PP, #0x11, lsl #12  ; [pp+0x11080] SubtypeTestCache
    //     0x46bde0: ldr             x3, [x3, #0x80]
    // 0x46bde4: r30 = InstanceOfStub
    //     0x46bde4: ldr             lr, [PP, #0x3e8]  ; [pp+0x3e8] Stub: InstanceOf (0x3112f4)
    // 0x46bde8: LoadField: r30 = r30->field_7
    //     0x46bde8: ldur            lr, [lr, #7]
    // 0x46bdec: blr             lr
    // 0x46bdf0: b               #0x46be00
    // 0x46bdf4: r0 = false
    //     0x46bdf4: add             x0, NULL, #0x30  ; false
    // 0x46bdf8: b               #0x46be00
    // 0x46bdfc: r0 = true
    //     0x46bdfc: add             x0, NULL, #0x20  ; true
    // 0x46be00: tbnz            w0, #4, #0x46be38
    // 0x46be04: ldur            x0, [fp, #-8]
    // 0x46be08: ldur            x2, [fp, #-0x10]
    // 0x46be0c: r1 = <int>
    //     0x46be0c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x46be10: r0 = LinkedHashSet.from()
    //     0x46be10: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x46be14: ldur            x1, [fp, #-8]
    // 0x46be18: StoreField: r1->field_9b = r0
    //     0x46be18: stur            w0, [x1, #0x9b]
    //     0x46be1c: ldurb           w16, [x1, #-1]
    //     0x46be20: ldurb           w17, [x0, #-1]
    //     0x46be24: and             x16, x17, x16, lsr #2
    //     0x46be28: tst             x16, HEAP, lsr #32
    //     0x46be2c: b.eq            #0x46be34
    //     0x46be30: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x46be34: b               #0x46be54
    // 0x46be38: ldur            x1, [fp, #-8]
    // 0x46be3c: LoadField: r0 = r1->field_9b
    //     0x46be3c: ldur            w0, [x1, #0x9b]
    // 0x46be40: DecompressPointer r0
    //     0x46be40: add             x0, x0, HEAP, lsl #32
    // 0x46be44: LoadField: r2 = r1->field_97
    //     0x46be44: ldur            w2, [x1, #0x97]
    // 0x46be48: DecompressPointer r2
    //     0x46be48: add             x2, x2, HEAP, lsl #32
    // 0x46be4c: mov             x1, x0
    // 0x46be50: r0 = addAll()
    //     0x46be50: bl              #0x7ad7e0  ; [dart:_compact_hash] _Set::addAll
    // 0x46be54: r0 = Null
    //     0x46be54: mov             x0, NULL
    // 0x46be58: LeaveFrame
    //     0x46be58: mov             SP, fp
    //     0x46be5c: ldp             fp, lr, [SP], #0x10
    // 0x46be60: ret
    //     0x46be60: ret             
    // 0x46be64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46be64: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46be68: b               #0x46b034
    // 0x46be6c: r9 = generators
    //     0x46be6c: add             x9, PP, #0x11, lsl #12  ; [pp+0x11088] Field <Chapter15GameState.generators>: late (offset: 0x8c)
    //     0x46be70: ldr             x9, [x9, #0x88]
    // 0x46be74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x46be74: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic, Chapter15Stat) {
    // ** addr: 0x46c008, size: 0x30
    // 0x46c008: EnterFrame
    //     0x46c008: stp             fp, lr, [SP, #-0x10]!
    //     0x46c00c: mov             fp, SP
    // 0x46c010: CheckStackOverflow
    //     0x46c010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46c014: cmp             SP, x16
    //     0x46c018: b.ls            #0x46c030
    // 0x46c01c: ldr             x1, [fp, #0x10]
    // 0x46c020: r0 = humanName()
    //     0x46c020: bl              #0x46c038  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] ::humanName
    // 0x46c024: LeaveFrame
    //     0x46c024: mov             SP, fp
    //     0x46c028: ldp             fp, lr, [SP], #0x10
    // 0x46c02c: ret
    //     0x46c02c: ret             
    // 0x46c030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46c030: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46c034: b               #0x46c01c
  }
  [closure] String <anonymous closure>(dynamic, Chapter15Stat) {
    // ** addr: 0x46c168, size: 0x30
    // 0x46c168: EnterFrame
    //     0x46c168: stp             fp, lr, [SP, #-0x10]!
    //     0x46c16c: mov             fp, SP
    // 0x46c170: CheckStackOverflow
    //     0x46c170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46c174: cmp             SP, x16
    //     0x46c178: b.ls            #0x46c190
    // 0x46c17c: ldr             x1, [fp, #0x10]
    // 0x46c180: r0 = shortenedName()
    //     0x46c180: bl              #0x46c198  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] ::shortenedName
    // 0x46c184: LeaveFrame
    //     0x46c184: mov             SP, fp
    //     0x46c188: ldp             fp, lr, [SP], #0x10
    // 0x46c18c: ret
    //     0x46c18c: ret             
    // 0x46c190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46c190: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46c194: b               #0x46c17c
  }
  [closure] Chapter15Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46c2c8, size: 0x44
    // 0x46c2c8: r2 = const [Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat', Instance of 'Chapter15Stat']
    //     0x46c2c8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11138] List<Chapter15Stat>(10)
    //     0x46c2cc: ldr             x2, [x2, #0x138]
    // 0x46c2d0: ldr             x3, [SP]
    // 0x46c2d4: r4 = LoadInt32Instr(r3)
    //     0x46c2d4: sbfx            x4, x3, #1, #0x1f
    //     0x46c2d8: tbz             w3, #0, #0x46c2e0
    //     0x46c2dc: ldur            x4, [x3, #7]
    // 0x46c2e0: mov             x1, x4
    // 0x46c2e4: r0 = 10
    //     0x46c2e4: movz            x0, #0xa
    // 0x46c2e8: cmp             x1, x0
    // 0x46c2ec: b.hs            #0x46c300
    // 0x46c2f0: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46c2f0: add             x16, x2, x4, lsl #2
    //     0x46c2f4: ldur            w0, [x16, #0xf]
    // 0x46c2f8: DecompressPointer r0
    //     0x46c2f8: add             x0, x0, HEAP, lsl #32
    // 0x46c2fc: ret
    //     0x46c2fc: ret             
    // 0x46c300: EnterFrame
    //     0x46c300: stp             fp, lr, [SP, #-0x10]!
    //     0x46c304: mov             fp, SP
    // 0x46c308: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46c308: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toMapFile(/* No info */) {
    // ** addr: 0x4e30f8, size: 0x130
    // 0x4e30f8: EnterFrame
    //     0x4e30f8: stp             fp, lr, [SP, #-0x10]!
    //     0x4e30fc: mov             fp, SP
    // 0x4e3100: AllocStack(0x28)
    //     0x4e3100: sub             SP, SP, #0x28
    // 0x4e3104: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x8 */, {dynamic zeroOutIdleTime = false /* r1 */})
    //     0x4e3104: mov             x0, x1
    //     0x4e3108: stur            x1, [fp, #-8]
    //     0x4e310c: ldur            w1, [x4, #0x13]
    //     0x4e3110: ldur            w2, [x4, #0x1f]
    //     0x4e3114: add             x2, x2, HEAP, lsl #32
    //     0x4e3118: add             x16, PP, #0x14, lsl #12  ; [pp+0x143e8] "zeroOutIdleTime"
    //     0x4e311c: ldr             x16, [x16, #0x3e8]
    //     0x4e3120: cmp             w2, w16
    //     0x4e3124: b.ne            #0x4e3140
    //     0x4e3128: ldur            w2, [x4, #0x23]
    //     0x4e312c: add             x2, x2, HEAP, lsl #32
    //     0x4e3130: sub             w3, w1, w2
    //     0x4e3134: add             x1, fp, w3, sxtw #2
    //     0x4e3138: ldr             x1, [x1, #8]
    //     0x4e313c: b               #0x4e3144
    //     0x4e3140: add             x1, NULL, #0x30  ; false
    // 0x4e3144: CheckStackOverflow
    //     0x4e3144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e3148: cmp             SP, x16
    //     0x4e314c: b.ls            #0x4e3220
    // 0x4e3150: str             x1, [SP]
    // 0x4e3154: mov             x1, x0
    // 0x4e3158: r4 = const [0, 0x2, 0x1, 0x1, zeroOutIdleTime, 0x1, null]
    //     0x4e3158: add             x4, PP, #0xe, lsl #12  ; [pp+0xeb78] List(7) [0, 0x2, 0x1, 0x1, "zeroOutIdleTime", 0x1, Null]
    //     0x4e315c: ldr             x4, [x4, #0xb78]
    // 0x4e3160: r0 = toMapFile()
    //     0x4e3160: bl              #0x4e365c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::toMapFile
    // 0x4e3164: r1 = Null
    //     0x4e3164: mov             x1, NULL
    // 0x4e3168: r2 = 8
    //     0x4e3168: movz            x2, #0x8
    // 0x4e316c: stur            x0, [fp, #-0x10]
    // 0x4e3170: r0 = AllocateArray()
    //     0x4e3170: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e3174: mov             x3, x0
    // 0x4e3178: stur            x3, [fp, #-0x18]
    // 0x4e317c: StoreField: r3->field_f = rZR
    //     0x4e317c: stur            wzr, [x3, #0xf]
    // 0x4e3180: ldur            x2, [fp, #-8]
    // 0x4e3184: LoadField: r0 = r2->field_93
    //     0x4e3184: ldur            w0, [x2, #0x93]
    // 0x4e3188: DecompressPointer r0
    //     0x4e3188: add             x0, x0, HEAP, lsl #32
    // 0x4e318c: LoadField: r4 = r0->field_7
    //     0x4e318c: ldur            x4, [x0, #7]
    // 0x4e3190: r0 = BoxInt64Instr(r4)
    //     0x4e3190: sbfiz           x0, x4, #1, #0x1f
    //     0x4e3194: cmp             x4, x0, asr #1
    //     0x4e3198: b.eq            #0x4e31a4
    //     0x4e319c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e31a0: stur            x4, [x0, #7]
    // 0x4e31a4: StoreField: r3->field_13 = r0
    //     0x4e31a4: stur            w0, [x3, #0x13]
    // 0x4e31a8: r16 = 2
    //     0x4e31a8: movz            x16, #0x2
    // 0x4e31ac: ArrayStore: r3[0] = r16  ; List_4
    //     0x4e31ac: stur            w16, [x3, #0x17]
    // 0x4e31b0: LoadField: r0 = r2->field_9b
    //     0x4e31b0: ldur            w0, [x2, #0x9b]
    // 0x4e31b4: DecompressPointer r0
    //     0x4e31b4: add             x0, x0, HEAP, lsl #32
    // 0x4e31b8: mov             x2, x0
    // 0x4e31bc: r1 = <int>
    //     0x4e31bc: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e31c0: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e31c0: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e31c4: ldur            x1, [fp, #-0x18]
    // 0x4e31c8: ArrayStore: r1[3] = r0  ; List_4
    //     0x4e31c8: add             x25, x1, #0x1b
    //     0x4e31cc: str             w0, [x25]
    //     0x4e31d0: tbz             w0, #0, #0x4e31ec
    //     0x4e31d4: ldurb           w16, [x1, #-1]
    //     0x4e31d8: ldurb           w17, [x0, #-1]
    //     0x4e31dc: and             x16, x17, x16, lsr #2
    //     0x4e31e0: tst             x16, HEAP, lsr #32
    //     0x4e31e4: b.eq            #0x4e31ec
    //     0x4e31e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e31ec: r16 = <int, dynamic>
    //     0x4e31ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x4e31f0: ldr             x16, [x16, #0x4f0]
    // 0x4e31f4: ldur            lr, [fp, #-0x18]
    // 0x4e31f8: stp             lr, x16, [SP]
    // 0x4e31fc: r0 = Map._fromLiteral()
    //     0x4e31fc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e3200: ldur            x1, [fp, #-0x10]
    // 0x4e3204: mov             x3, x0
    // 0x4e3208: r2 = 38
    //     0x4e3208: movz            x2, #0x26
    // 0x4e320c: r0 = []=()
    //     0x4e320c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4e3210: ldur            x0, [fp, #-0x10]
    // 0x4e3214: LeaveFrame
    //     0x4e3214: mov             SP, fp
    //     0x4e3218: ldp             fp, lr, [SP], #0x10
    // 0x4e321c: ret
    //     0x4e321c: ret             
    // 0x4e3220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e3220: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e3224: b               #0x4e3150
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e715c, size: 0x78
    // 0x4e715c: EnterFrame
    //     0x4e715c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e7160: mov             fp, SP
    // 0x4e7164: AllocStack(0x18)
    //     0x4e7164: sub             SP, SP, #0x18
    // 0x4e7168: SetupParameters(Chapter15GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e7168: stur            x1, [fp, #-8]
    // 0x4e716c: r1 = 1
    //     0x4e716c: movz            x1, #0x1
    // 0x4e7170: r0 = AllocateContext()
    //     0x4e7170: bl              #0x82637c  ; AllocateContextStub
    // 0x4e7174: mov             x3, x0
    // 0x4e7178: ldur            x0, [fp, #-8]
    // 0x4e717c: stur            x3, [fp, #-0x10]
    // 0x4e7180: StoreField: r3->field_f = r0
    //     0x4e7180: stur            w0, [x3, #0xf]
    // 0x4e7184: mov             x2, x3
    // 0x4e7188: r1 = Function '<anonymous closure>':.
    //     0x4e7188: add             x1, PP, #0x25, lsl #12  ; [pp+0x25720] AnonymousClosure: (0x4e72d4), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::makeHeader (0x4e715c)
    //     0x4e718c: ldr             x1, [x1, #0x720]
    // 0x4e7190: r0 = AllocateClosure()
    //     0x4e7190: bl              #0x826750  ; AllocateClosureStub
    // 0x4e7194: stur            x0, [fp, #-8]
    // 0x4e7198: r0 = MainStatDisplay()
    //     0x4e7198: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e719c: mov             x3, x0
    // 0x4e71a0: ldur            x0, [fp, #-8]
    // 0x4e71a4: stur            x3, [fp, #-0x18]
    // 0x4e71a8: StoreField: r3->field_b = r0
    //     0x4e71a8: stur            w0, [x3, #0xb]
    // 0x4e71ac: ldur            x2, [fp, #-0x10]
    // 0x4e71b0: r1 = Function '<anonymous closure>':.
    //     0x4e71b0: add             x1, PP, #0x25, lsl #12  ; [pp+0x25728] AnonymousClosure: (0x4e71d4), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::makeHeader (0x4e715c)
    //     0x4e71b4: ldr             x1, [x1, #0x728]
    // 0x4e71b8: r0 = AllocateClosure()
    //     0x4e71b8: bl              #0x826750  ; AllocateClosureStub
    // 0x4e71bc: mov             x1, x0
    // 0x4e71c0: ldur            x0, [fp, #-0x18]
    // 0x4e71c4: StoreField: r0->field_f = r1
    //     0x4e71c4: stur            w1, [x0, #0xf]
    // 0x4e71c8: LeaveFrame
    //     0x4e71c8: mov             SP, fp
    //     0x4e71cc: ldp             fp, lr, [SP], #0x10
    // 0x4e71d0: ret
    //     0x4e71d0: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e71d4, size: 0x100
    // 0x4e71d4: EnterFrame
    //     0x4e71d4: stp             fp, lr, [SP, #-0x10]!
    //     0x4e71d8: mov             fp, SP
    // 0x4e71dc: AllocStack(0x18)
    //     0x4e71dc: sub             SP, SP, #0x18
    // 0x4e71e0: SetupParameters([dynamic _ /* r0 */])
    //     0x4e71e0: ldr             x0, [fp, #0x10]
    //     0x4e71e4: ldur            w1, [x0, #0x17]
    //     0x4e71e8: add             x1, x1, HEAP, lsl #32
    // 0x4e71ec: CheckStackOverflow
    //     0x4e71ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e71f0: cmp             SP, x16
    //     0x4e71f4: b.ls            #0x4e72cc
    // 0x4e71f8: LoadField: r0 = r1->field_f
    //     0x4e71f8: ldur            w0, [x1, #0xf]
    // 0x4e71fc: DecompressPointer r0
    //     0x4e71fc: add             x0, x0, HEAP, lsl #32
    // 0x4e7200: LoadField: r3 = r0->field_57
    //     0x4e7200: ldur            w3, [x0, #0x57]
    // 0x4e7204: DecompressPointer r3
    //     0x4e7204: add             x3, x3, HEAP, lsl #32
    // 0x4e7208: mov             x1, x3
    // 0x4e720c: stur            x3, [fp, #-8]
    // 0x4e7210: r2 = Instance_Chapter15Stat
    //     0x4e7210: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x4e7214: ldr             x2, [x2, #0x90]
    // 0x4e7218: r0 = _getValueOrData()
    //     0x4e7218: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e721c: mov             x1, x0
    // 0x4e7220: ldur            x0, [fp, #-8]
    // 0x4e7224: LoadField: r2 = r0->field_f
    //     0x4e7224: ldur            w2, [x0, #0xf]
    // 0x4e7228: DecompressPointer r2
    //     0x4e7228: add             x2, x2, HEAP, lsl #32
    // 0x4e722c: cmp             w2, w1
    // 0x4e7230: b.ne            #0x4e723c
    // 0x4e7234: r0 = Null
    //     0x4e7234: mov             x0, NULL
    // 0x4e7238: b               #0x4e7240
    // 0x4e723c: mov             x0, x1
    // 0x4e7240: stur            x0, [fp, #-8]
    // 0x4e7244: cmp             w0, NULL
    // 0x4e7248: b.eq            #0x4e72bc
    // 0x4e724c: r1 = Null
    //     0x4e724c: mov             x1, NULL
    // 0x4e7250: r2 = 6
    //     0x4e7250: movz            x2, #0x6
    // 0x4e7254: r0 = AllocateArray()
    //     0x4e7254: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e7258: stur            x0, [fp, #-0x10]
    // 0x4e725c: r16 = "("
    //     0x4e725c: ldr             x16, [PP, #0x2218]  ; [pp+0x2218] "("
    // 0x4e7260: StoreField: r0->field_f = r16
    //     0x4e7260: stur            w16, [x0, #0xf]
    // 0x4e7264: ldur            x1, [fp, #-8]
    // 0x4e7268: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e7268: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e726c: r0 = toStringConsistentDecimalPlaces()
    //     0x4e726c: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e7270: ldur            x1, [fp, #-0x10]
    // 0x4e7274: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e7274: add             x25, x1, #0x13
    //     0x4e7278: str             w0, [x25]
    //     0x4e727c: tbz             w0, #0, #0x4e7298
    //     0x4e7280: ldurb           w16, [x1, #-1]
    //     0x4e7284: ldurb           w17, [x0, #-1]
    //     0x4e7288: and             x16, x17, x16, lsr #2
    //     0x4e728c: tst             x16, HEAP, lsr #32
    //     0x4e7290: b.eq            #0x4e7298
    //     0x4e7294: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e7298: ldur            x0, [fp, #-0x10]
    // 0x4e729c: r16 = "/s)"
    //     0x4e729c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a568] "/s)"
    //     0x4e72a0: ldr             x16, [x16, #0x568]
    // 0x4e72a4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4e72a4: stur            w16, [x0, #0x17]
    // 0x4e72a8: str             x0, [SP]
    // 0x4e72ac: r0 = _interpolate()
    //     0x4e72ac: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e72b0: LeaveFrame
    //     0x4e72b0: mov             SP, fp
    //     0x4e72b4: ldp             fp, lr, [SP], #0x10
    // 0x4e72b8: ret
    //     0x4e72b8: ret             
    // 0x4e72bc: r0 = ""
    //     0x4e72bc: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x4e72c0: LeaveFrame
    //     0x4e72c0: mov             SP, fp
    //     0x4e72c4: ldp             fp, lr, [SP], #0x10
    // 0x4e72c8: ret
    //     0x4e72c8: ret             
    // 0x4e72cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e72cc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e72d0: b               #0x4e71f8
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e72d4, size: 0xf4
    // 0x4e72d4: EnterFrame
    //     0x4e72d4: stp             fp, lr, [SP, #-0x10]!
    //     0x4e72d8: mov             fp, SP
    // 0x4e72dc: AllocStack(0x18)
    //     0x4e72dc: sub             SP, SP, #0x18
    // 0x4e72e0: SetupParameters([dynamic _ /* r0 */])
    //     0x4e72e0: ldr             x0, [fp, #0x10]
    //     0x4e72e4: ldur            w3, [x0, #0x17]
    //     0x4e72e8: add             x3, x3, HEAP, lsl #32
    //     0x4e72ec: stur            x3, [fp, #-8]
    // 0x4e72f0: CheckStackOverflow
    //     0x4e72f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e72f4: cmp             SP, x16
    //     0x4e72f8: b.ls            #0x4e73c0
    // 0x4e72fc: r1 = Null
    //     0x4e72fc: mov             x1, NULL
    // 0x4e7300: r2 = 4
    //     0x4e7300: movz            x2, #0x4
    // 0x4e7304: r0 = AllocateArray()
    //     0x4e7304: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e7308: stur            x0, [fp, #-0x10]
    // 0x4e730c: r16 = "Symbols: "
    //     0x4e730c: add             x16, PP, #0x25, lsl #12  ; [pp+0x25730] "Symbols: "
    //     0x4e7310: ldr             x16, [x16, #0x730]
    // 0x4e7314: StoreField: r0->field_f = r16
    //     0x4e7314: stur            w16, [x0, #0xf]
    // 0x4e7318: ldur            x1, [fp, #-8]
    // 0x4e731c: LoadField: r2 = r1->field_f
    //     0x4e731c: ldur            w2, [x1, #0xf]
    // 0x4e7320: DecompressPointer r2
    //     0x4e7320: add             x2, x2, HEAP, lsl #32
    // 0x4e7324: LoadField: r3 = r2->field_37
    //     0x4e7324: ldur            w3, [x2, #0x37]
    // 0x4e7328: DecompressPointer r3
    //     0x4e7328: add             x3, x3, HEAP, lsl #32
    // 0x4e732c: mov             x1, x3
    // 0x4e7330: stur            x3, [fp, #-8]
    // 0x4e7334: r2 = Instance_Chapter15Stat
    //     0x4e7334: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x4e7338: ldr             x2, [x2, #0x90]
    // 0x4e733c: r0 = _getValueOrData()
    //     0x4e733c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e7340: mov             x1, x0
    // 0x4e7344: ldur            x0, [fp, #-8]
    // 0x4e7348: LoadField: r2 = r0->field_f
    //     0x4e7348: ldur            w2, [x0, #0xf]
    // 0x4e734c: DecompressPointer r2
    //     0x4e734c: add             x2, x2, HEAP, lsl #32
    // 0x4e7350: cmp             w2, w1
    // 0x4e7354: b.ne            #0x4e735c
    // 0x4e7358: r1 = Null
    //     0x4e7358: mov             x1, NULL
    // 0x4e735c: cmp             w1, NULL
    // 0x4e7360: b.ne            #0x4e736c
    // 0x4e7364: r0 = Null
    //     0x4e7364: mov             x0, NULL
    // 0x4e7368: b               #0x4e7374
    // 0x4e736c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e736c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e7370: r0 = toStringConsistentDecimalPlaces()
    //     0x4e7370: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e7374: cmp             w0, NULL
    // 0x4e7378: b.ne            #0x4e7380
    // 0x4e737c: r0 = 0
    //     0x4e737c: movz            x0, #0
    // 0x4e7380: ldur            x1, [fp, #-0x10]
    // 0x4e7384: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e7384: add             x25, x1, #0x13
    //     0x4e7388: str             w0, [x25]
    //     0x4e738c: tbz             w0, #0, #0x4e73a8
    //     0x4e7390: ldurb           w16, [x1, #-1]
    //     0x4e7394: ldurb           w17, [x0, #-1]
    //     0x4e7398: and             x16, x17, x16, lsr #2
    //     0x4e739c: tst             x16, HEAP, lsr #32
    //     0x4e73a0: b.eq            #0x4e73a8
    //     0x4e73a4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e73a8: ldur            x16, [fp, #-0x10]
    // 0x4e73ac: str             x16, [SP]
    // 0x4e73b0: r0 = _interpolate()
    //     0x4e73b0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e73b4: LeaveFrame
    //     0x4e73b4: mov             SP, fp
    //     0x4e73b8: ldp             fp, lr, [SP], #0x10
    // 0x4e73bc: ret
    //     0x4e73bc: ret             
    // 0x4e73c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e73c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e73c4: b               #0x4e72fc
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4fc048, size: 0x1b80
    // 0x4fc048: EnterFrame
    //     0x4fc048: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc04c: mov             fp, SP
    // 0x4fc050: AllocStack(0x70)
    //     0x4fc050: sub             SP, SP, #0x70
    // 0x4fc054: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x8 */)
    //     0x4fc054: mov             x0, x1
    //     0x4fc058: stur            x1, [fp, #-8]
    // 0x4fc05c: CheckStackOverflow
    //     0x4fc05c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fc060: cmp             SP, x16
    //     0x4fc064: b.ls            #0x4fdb80
    // 0x4fc068: r1 = Null
    //     0x4fc068: mov             x1, NULL
    // 0x4fc06c: r2 = 40
    //     0x4fc06c: movz            x2, #0x28
    // 0x4fc070: r0 = AllocateArray()
    //     0x4fc070: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc074: r16 = 2
    //     0x4fc074: movz            x16, #0x2
    // 0x4fc078: StoreField: r0->field_f = r16
    //     0x4fc078: stur            w16, [x0, #0xf]
    // 0x4fc07c: r16 = Instance_GeneratorInfo
    //     0x4fc07c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15260] Obj!GeneratorInfo<Chapter15Stat>@82de51
    //     0x4fc080: ldr             x16, [x16, #0x260]
    // 0x4fc084: StoreField: r0->field_13 = r16
    //     0x4fc084: stur            w16, [x0, #0x13]
    // 0x4fc088: r16 = 4
    //     0x4fc088: movz            x16, #0x4
    // 0x4fc08c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fc08c: stur            w16, [x0, #0x17]
    // 0x4fc090: r16 = Instance_GeneratorInfo
    //     0x4fc090: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] Obj!GeneratorInfo<Chapter15Stat>@82de11
    //     0x4fc094: ldr             x16, [x16, #0x268]
    // 0x4fc098: StoreField: r0->field_1b = r16
    //     0x4fc098: stur            w16, [x0, #0x1b]
    // 0x4fc09c: r16 = 6
    //     0x4fc09c: movz            x16, #0x6
    // 0x4fc0a0: StoreField: r0->field_1f = r16
    //     0x4fc0a0: stur            w16, [x0, #0x1f]
    // 0x4fc0a4: r16 = Instance_GeneratorInfo
    //     0x4fc0a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15270] Obj!GeneratorInfo<Chapter15Stat>@82ddd1
    //     0x4fc0a8: ldr             x16, [x16, #0x270]
    // 0x4fc0ac: StoreField: r0->field_23 = r16
    //     0x4fc0ac: stur            w16, [x0, #0x23]
    // 0x4fc0b0: r16 = 8
    //     0x4fc0b0: movz            x16, #0x8
    // 0x4fc0b4: StoreField: r0->field_27 = r16
    //     0x4fc0b4: stur            w16, [x0, #0x27]
    // 0x4fc0b8: r16 = Instance_GeneratorInfo
    //     0x4fc0b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15278] Obj!GeneratorInfo<Chapter15Stat>@82dd91
    //     0x4fc0bc: ldr             x16, [x16, #0x278]
    // 0x4fc0c0: StoreField: r0->field_2b = r16
    //     0x4fc0c0: stur            w16, [x0, #0x2b]
    // 0x4fc0c4: r16 = 10
    //     0x4fc0c4: movz            x16, #0xa
    // 0x4fc0c8: StoreField: r0->field_2f = r16
    //     0x4fc0c8: stur            w16, [x0, #0x2f]
    // 0x4fc0cc: r16 = Instance_GeneratorInfo
    //     0x4fc0cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15280] Obj!GeneratorInfo<Chapter15Stat>@82dd51
    //     0x4fc0d0: ldr             x16, [x16, #0x280]
    // 0x4fc0d4: StoreField: r0->field_33 = r16
    //     0x4fc0d4: stur            w16, [x0, #0x33]
    // 0x4fc0d8: r16 = 12
    //     0x4fc0d8: movz            x16, #0xc
    // 0x4fc0dc: StoreField: r0->field_37 = r16
    //     0x4fc0dc: stur            w16, [x0, #0x37]
    // 0x4fc0e0: r16 = Instance_GeneratorInfo
    //     0x4fc0e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15288] Obj!GeneratorInfo<Chapter15Stat>@82dd11
    //     0x4fc0e4: ldr             x16, [x16, #0x288]
    // 0x4fc0e8: StoreField: r0->field_3b = r16
    //     0x4fc0e8: stur            w16, [x0, #0x3b]
    // 0x4fc0ec: r16 = 22
    //     0x4fc0ec: movz            x16, #0x16
    // 0x4fc0f0: StoreField: r0->field_3f = r16
    //     0x4fc0f0: stur            w16, [x0, #0x3f]
    // 0x4fc0f4: r16 = Instance_GeneratorInfo
    //     0x4fc0f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15290] Obj!GeneratorInfo<Chapter15Stat>@82dcd1
    //     0x4fc0f8: ldr             x16, [x16, #0x290]
    // 0x4fc0fc: StoreField: r0->field_43 = r16
    //     0x4fc0fc: stur            w16, [x0, #0x43]
    // 0x4fc100: r16 = 24
    //     0x4fc100: movz            x16, #0x18
    // 0x4fc104: StoreField: r0->field_47 = r16
    //     0x4fc104: stur            w16, [x0, #0x47]
    // 0x4fc108: r16 = Instance_GeneratorInfo
    //     0x4fc108: add             x16, PP, #0x15, lsl #12  ; [pp+0x15298] Obj!GeneratorInfo<Chapter15Stat>@82dc91
    //     0x4fc10c: ldr             x16, [x16, #0x298]
    // 0x4fc110: StoreField: r0->field_4b = r16
    //     0x4fc110: stur            w16, [x0, #0x4b]
    // 0x4fc114: r16 = 26
    //     0x4fc114: movz            x16, #0x1a
    // 0x4fc118: StoreField: r0->field_4f = r16
    //     0x4fc118: stur            w16, [x0, #0x4f]
    // 0x4fc11c: r16 = Instance_GeneratorInfo
    //     0x4fc11c: add             x16, PP, #0x15, lsl #12  ; [pp+0x152a0] Obj!GeneratorInfo<Chapter15Stat>@82dc51
    //     0x4fc120: ldr             x16, [x16, #0x2a0]
    // 0x4fc124: StoreField: r0->field_53 = r16
    //     0x4fc124: stur            w16, [x0, #0x53]
    // 0x4fc128: r16 = 28
    //     0x4fc128: movz            x16, #0x1c
    // 0x4fc12c: StoreField: r0->field_57 = r16
    //     0x4fc12c: stur            w16, [x0, #0x57]
    // 0x4fc130: r16 = Instance_GeneratorInfo
    //     0x4fc130: add             x16, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!GeneratorInfo<Chapter15Stat>@82dc11
    //     0x4fc134: ldr             x16, [x16, #0x2a8]
    // 0x4fc138: StoreField: r0->field_5b = r16
    //     0x4fc138: stur            w16, [x0, #0x5b]
    // 0x4fc13c: r16 = <int, GeneratorInfo<Chapter15Stat>>
    //     0x4fc13c: add             x16, PP, #0x15, lsl #12  ; [pp+0x152b0] TypeArguments: <int, GeneratorInfo<Chapter15Stat>>
    //     0x4fc140: ldr             x16, [x16, #0x2b0]
    // 0x4fc144: stp             x0, x16, [SP]
    // 0x4fc148: r0 = Map._fromLiteral()
    //     0x4fc148: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fc14c: ldur            x3, [fp, #-8]
    // 0x4fc150: StoreField: r3->field_8b = r0
    //     0x4fc150: stur            w0, [x3, #0x8b]
    //     0x4fc154: ldurb           w16, [x3, #-1]
    //     0x4fc158: ldurb           w17, [x0, #-1]
    //     0x4fc15c: and             x16, x17, x16, lsr #2
    //     0x4fc160: tst             x16, HEAP, lsr #32
    //     0x4fc164: b.eq            #0x4fc16c
    //     0x4fc168: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4fc16c: r1 = Null
    //     0x4fc16c: mov             x1, NULL
    // 0x4fc170: r2 = 44
    //     0x4fc170: movz            x2, #0x2c
    // 0x4fc174: r0 = AllocateArray()
    //     0x4fc174: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc178: stur            x0, [fp, #-0x10]
    // 0x4fc17c: r16 = 2
    //     0x4fc17c: movz            x16, #0x2
    // 0x4fc180: StoreField: r0->field_f = r16
    //     0x4fc180: stur            w16, [x0, #0xf]
    // 0x4fc184: r1 = "Bigger Symbols"
    //     0x4fc184: add             x1, PP, #0x15, lsl #12  ; [pp+0x152b8] "Bigger Symbols"
    //     0x4fc188: ldr             x1, [x1, #0x2b8]
    // 0x4fc18c: r0 = autoString()
    //     0x4fc18c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fc190: stur            x0, [fp, #-0x18]
    // 0x4fc194: r16 = 2
    //     0x4fc194: movz            x16, #0x2
    // 0x4fc198: str             x16, [SP]
    // 0x4fc19c: ldur            x1, [fp, #-8]
    // 0x4fc1a0: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc1a0: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc1a4: ldr             x4, [x4, #0x2c0]
    // 0x4fc1a8: r0 = biggerSymbolBoost()
    //     0x4fc1a8: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc1ac: r1 = Null
    //     0x4fc1ac: mov             x1, NULL
    // 0x4fc1b0: r2 = 4
    //     0x4fc1b0: movz            x2, #0x4
    // 0x4fc1b4: stur            x0, [fp, #-0x20]
    // 0x4fc1b8: r0 = AllocateArray()
    //     0x4fc1b8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc1bc: mov             x1, x0
    // 0x4fc1c0: ldur            x0, [fp, #-0x20]
    // 0x4fc1c4: StoreField: r1->field_f = r0
    //     0x4fc1c4: stur            w0, [x1, #0xf]
    // 0x4fc1c8: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc1c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc1cc: ldr             x16, [x16, #0x2c8]
    // 0x4fc1d0: StoreField: r1->field_13 = r16
    //     0x4fc1d0: stur            w16, [x1, #0x13]
    // 0x4fc1d4: str             x1, [SP]
    // 0x4fc1d8: r0 = _interpolate()
    //     0x4fc1d8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc1dc: stur            x0, [fp, #-0x20]
    // 0x4fc1e0: r16 = 4
    //     0x4fc1e0: movz            x16, #0x4
    // 0x4fc1e4: str             x16, [SP]
    // 0x4fc1e8: ldur            x1, [fp, #-8]
    // 0x4fc1ec: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc1ec: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc1f0: ldr             x4, [x4, #0x2c0]
    // 0x4fc1f4: r0 = biggerSymbolBoost()
    //     0x4fc1f4: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc1f8: r1 = Null
    //     0x4fc1f8: mov             x1, NULL
    // 0x4fc1fc: r2 = 4
    //     0x4fc1fc: movz            x2, #0x4
    // 0x4fc200: stur            x0, [fp, #-0x28]
    // 0x4fc204: r0 = AllocateArray()
    //     0x4fc204: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc208: mov             x1, x0
    // 0x4fc20c: ldur            x0, [fp, #-0x28]
    // 0x4fc210: StoreField: r1->field_f = r0
    //     0x4fc210: stur            w0, [x1, #0xf]
    // 0x4fc214: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc214: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc218: ldr             x16, [x16, #0x2c8]
    // 0x4fc21c: StoreField: r1->field_13 = r16
    //     0x4fc21c: stur            w16, [x1, #0x13]
    // 0x4fc220: str             x1, [SP]
    // 0x4fc224: r0 = _interpolate()
    //     0x4fc224: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc228: stur            x0, [fp, #-0x28]
    // 0x4fc22c: r16 = 6
    //     0x4fc22c: movz            x16, #0x6
    // 0x4fc230: str             x16, [SP]
    // 0x4fc234: ldur            x1, [fp, #-8]
    // 0x4fc238: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc238: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc23c: ldr             x4, [x4, #0x2c0]
    // 0x4fc240: r0 = biggerSymbolBoost()
    //     0x4fc240: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc244: r1 = Null
    //     0x4fc244: mov             x1, NULL
    // 0x4fc248: r2 = 4
    //     0x4fc248: movz            x2, #0x4
    // 0x4fc24c: stur            x0, [fp, #-0x30]
    // 0x4fc250: r0 = AllocateArray()
    //     0x4fc250: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc254: mov             x1, x0
    // 0x4fc258: ldur            x0, [fp, #-0x30]
    // 0x4fc25c: StoreField: r1->field_f = r0
    //     0x4fc25c: stur            w0, [x1, #0xf]
    // 0x4fc260: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc260: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc264: ldr             x16, [x16, #0x2c8]
    // 0x4fc268: StoreField: r1->field_13 = r16
    //     0x4fc268: stur            w16, [x1, #0x13]
    // 0x4fc26c: str             x1, [SP]
    // 0x4fc270: r0 = _interpolate()
    //     0x4fc270: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc274: stur            x0, [fp, #-0x30]
    // 0x4fc278: r16 = 8
    //     0x4fc278: movz            x16, #0x8
    // 0x4fc27c: str             x16, [SP]
    // 0x4fc280: ldur            x1, [fp, #-8]
    // 0x4fc284: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc284: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc288: ldr             x4, [x4, #0x2c0]
    // 0x4fc28c: r0 = biggerSymbolBoost()
    //     0x4fc28c: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc290: r1 = Null
    //     0x4fc290: mov             x1, NULL
    // 0x4fc294: r2 = 4
    //     0x4fc294: movz            x2, #0x4
    // 0x4fc298: stur            x0, [fp, #-0x38]
    // 0x4fc29c: r0 = AllocateArray()
    //     0x4fc29c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc2a0: mov             x1, x0
    // 0x4fc2a4: ldur            x0, [fp, #-0x38]
    // 0x4fc2a8: StoreField: r1->field_f = r0
    //     0x4fc2a8: stur            w0, [x1, #0xf]
    // 0x4fc2ac: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc2ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc2b0: ldr             x16, [x16, #0x2c8]
    // 0x4fc2b4: StoreField: r1->field_13 = r16
    //     0x4fc2b4: stur            w16, [x1, #0x13]
    // 0x4fc2b8: str             x1, [SP]
    // 0x4fc2bc: r0 = _interpolate()
    //     0x4fc2bc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc2c0: stur            x0, [fp, #-0x38]
    // 0x4fc2c4: r16 = 10
    //     0x4fc2c4: movz            x16, #0xa
    // 0x4fc2c8: str             x16, [SP]
    // 0x4fc2cc: ldur            x1, [fp, #-8]
    // 0x4fc2d0: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc2d0: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc2d4: ldr             x4, [x4, #0x2c0]
    // 0x4fc2d8: r0 = biggerSymbolBoost()
    //     0x4fc2d8: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc2dc: r1 = Null
    //     0x4fc2dc: mov             x1, NULL
    // 0x4fc2e0: r2 = 4
    //     0x4fc2e0: movz            x2, #0x4
    // 0x4fc2e4: stur            x0, [fp, #-0x40]
    // 0x4fc2e8: r0 = AllocateArray()
    //     0x4fc2e8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc2ec: mov             x1, x0
    // 0x4fc2f0: ldur            x0, [fp, #-0x40]
    // 0x4fc2f4: StoreField: r1->field_f = r0
    //     0x4fc2f4: stur            w0, [x1, #0xf]
    // 0x4fc2f8: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc2f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc2fc: ldr             x16, [x16, #0x2c8]
    // 0x4fc300: StoreField: r1->field_13 = r16
    //     0x4fc300: stur            w16, [x1, #0x13]
    // 0x4fc304: str             x1, [SP]
    // 0x4fc308: r0 = _interpolate()
    //     0x4fc308: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc30c: stur            x0, [fp, #-0x40]
    // 0x4fc310: r16 = 12
    //     0x4fc310: movz            x16, #0xc
    // 0x4fc314: str             x16, [SP]
    // 0x4fc318: ldur            x1, [fp, #-8]
    // 0x4fc31c: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc31c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc320: ldr             x4, [x4, #0x2c0]
    // 0x4fc324: r0 = biggerSymbolBoost()
    //     0x4fc324: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc328: r1 = Null
    //     0x4fc328: mov             x1, NULL
    // 0x4fc32c: r2 = 4
    //     0x4fc32c: movz            x2, #0x4
    // 0x4fc330: stur            x0, [fp, #-0x48]
    // 0x4fc334: r0 = AllocateArray()
    //     0x4fc334: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc338: mov             x1, x0
    // 0x4fc33c: ldur            x0, [fp, #-0x48]
    // 0x4fc340: StoreField: r1->field_f = r0
    //     0x4fc340: stur            w0, [x1, #0xf]
    // 0x4fc344: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc344: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc348: ldr             x16, [x16, #0x2c8]
    // 0x4fc34c: StoreField: r1->field_13 = r16
    //     0x4fc34c: stur            w16, [x1, #0x13]
    // 0x4fc350: str             x1, [SP]
    // 0x4fc354: r0 = _interpolate()
    //     0x4fc354: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc358: stur            x0, [fp, #-0x48]
    // 0x4fc35c: r16 = 14
    //     0x4fc35c: movz            x16, #0xe
    // 0x4fc360: str             x16, [SP]
    // 0x4fc364: ldur            x1, [fp, #-8]
    // 0x4fc368: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc368: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc36c: ldr             x4, [x4, #0x2c0]
    // 0x4fc370: r0 = biggerSymbolBoost()
    //     0x4fc370: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc374: r1 = Null
    //     0x4fc374: mov             x1, NULL
    // 0x4fc378: r2 = 4
    //     0x4fc378: movz            x2, #0x4
    // 0x4fc37c: stur            x0, [fp, #-0x50]
    // 0x4fc380: r0 = AllocateArray()
    //     0x4fc380: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc384: mov             x1, x0
    // 0x4fc388: ldur            x0, [fp, #-0x50]
    // 0x4fc38c: StoreField: r1->field_f = r0
    //     0x4fc38c: stur            w0, [x1, #0xf]
    // 0x4fc390: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc390: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc394: ldr             x16, [x16, #0x2c8]
    // 0x4fc398: StoreField: r1->field_13 = r16
    //     0x4fc398: stur            w16, [x1, #0x13]
    // 0x4fc39c: str             x1, [SP]
    // 0x4fc3a0: r0 = _interpolate()
    //     0x4fc3a0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc3a4: stur            x0, [fp, #-0x50]
    // 0x4fc3a8: r16 = 16
    //     0x4fc3a8: movz            x16, #0x10
    // 0x4fc3ac: str             x16, [SP]
    // 0x4fc3b0: ldur            x1, [fp, #-8]
    // 0x4fc3b4: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc3b4: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc3b8: ldr             x4, [x4, #0x2c0]
    // 0x4fc3bc: r0 = biggerSymbolBoost()
    //     0x4fc3bc: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x4fc3c0: r1 = Null
    //     0x4fc3c0: mov             x1, NULL
    // 0x4fc3c4: r2 = 4
    //     0x4fc3c4: movz            x2, #0x4
    // 0x4fc3c8: stur            x0, [fp, #-0x58]
    // 0x4fc3cc: r0 = AllocateArray()
    //     0x4fc3cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc3d0: mov             x1, x0
    // 0x4fc3d4: ldur            x0, [fp, #-0x58]
    // 0x4fc3d8: StoreField: r1->field_f = r0
    //     0x4fc3d8: stur            w0, [x1, #0xf]
    // 0x4fc3dc: r16 = "x the number of symbols generated on generate symbols."
    //     0x4fc3dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] "x the number of symbols generated on generate symbols."
    //     0x4fc3e0: ldr             x16, [x16, #0x2c8]
    // 0x4fc3e4: StoreField: r1->field_13 = r16
    //     0x4fc3e4: stur            w16, [x1, #0x13]
    // 0x4fc3e8: str             x1, [SP]
    // 0x4fc3ec: r0 = _interpolate()
    //     0x4fc3ec: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc3f0: r1 = Null
    //     0x4fc3f0: mov             x1, NULL
    // 0x4fc3f4: r2 = 16
    //     0x4fc3f4: movz            x2, #0x10
    // 0x4fc3f8: stur            x0, [fp, #-0x58]
    // 0x4fc3fc: r0 = AllocateArray()
    //     0x4fc3fc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc400: mov             x2, x0
    // 0x4fc404: ldur            x0, [fp, #-0x20]
    // 0x4fc408: stur            x2, [fp, #-0x60]
    // 0x4fc40c: StoreField: r2->field_f = r0
    //     0x4fc40c: stur            w0, [x2, #0xf]
    // 0x4fc410: ldur            x0, [fp, #-0x28]
    // 0x4fc414: StoreField: r2->field_13 = r0
    //     0x4fc414: stur            w0, [x2, #0x13]
    // 0x4fc418: ldur            x0, [fp, #-0x30]
    // 0x4fc41c: ArrayStore: r2[0] = r0  ; List_4
    //     0x4fc41c: stur            w0, [x2, #0x17]
    // 0x4fc420: ldur            x0, [fp, #-0x38]
    // 0x4fc424: StoreField: r2->field_1b = r0
    //     0x4fc424: stur            w0, [x2, #0x1b]
    // 0x4fc428: ldur            x0, [fp, #-0x40]
    // 0x4fc42c: StoreField: r2->field_1f = r0
    //     0x4fc42c: stur            w0, [x2, #0x1f]
    // 0x4fc430: ldur            x0, [fp, #-0x48]
    // 0x4fc434: StoreField: r2->field_23 = r0
    //     0x4fc434: stur            w0, [x2, #0x23]
    // 0x4fc438: ldur            x0, [fp, #-0x50]
    // 0x4fc43c: StoreField: r2->field_27 = r0
    //     0x4fc43c: stur            w0, [x2, #0x27]
    // 0x4fc440: ldur            x0, [fp, #-0x58]
    // 0x4fc444: StoreField: r2->field_2b = r0
    //     0x4fc444: stur            w0, [x2, #0x2b]
    // 0x4fc448: r1 = <String>
    //     0x4fc448: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fc44c: r0 = AllocateGrowableArray()
    //     0x4fc44c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fc450: mov             x2, x0
    // 0x4fc454: ldur            x0, [fp, #-0x60]
    // 0x4fc458: stur            x2, [fp, #-0x20]
    // 0x4fc45c: StoreField: r2->field_f = r0
    //     0x4fc45c: stur            w0, [x2, #0xf]
    // 0x4fc460: r0 = 16
    //     0x4fc460: movz            x0, #0x10
    // 0x4fc464: StoreField: r2->field_b = r0
    //     0x4fc464: stur            w0, [x2, #0xb]
    // 0x4fc468: r1 = <String>
    //     0x4fc468: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fc46c: r0 = Generator()
    //     0x4fc46c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fc470: mov             x3, x0
    // 0x4fc474: ldur            x0, [fp, #-0x20]
    // 0x4fc478: stur            x3, [fp, #-0x28]
    // 0x4fc47c: StoreField: r3->field_b = r0
    //     0x4fc47c: stur            w0, [x3, #0xb]
    // 0x4fc480: r1 = Null
    //     0x4fc480: mov             x1, NULL
    // 0x4fc484: r2 = 16
    //     0x4fc484: movz            x2, #0x10
    // 0x4fc488: r0 = AllocateArray()
    //     0x4fc488: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc48c: stur            x0, [fp, #-0x20]
    // 0x4fc490: r16 = Instance_Tuple2
    //     0x4fc490: add             x16, PP, #0x15, lsl #12  ; [pp+0x152d0] Obj!Tuple2<Chapter15Stat, CustomNum>@824751
    //     0x4fc494: ldr             x16, [x16, #0x2d0]
    // 0x4fc498: StoreField: r0->field_f = r16
    //     0x4fc498: stur            w16, [x0, #0xf]
    // 0x4fc49c: r16 = Instance_Tuple2
    //     0x4fc49c: add             x16, PP, #0x15, lsl #12  ; [pp+0x152d8] Obj!Tuple2<Chapter15Stat, CustomNum>@824731
    //     0x4fc4a0: ldr             x16, [x16, #0x2d8]
    // 0x4fc4a4: StoreField: r0->field_13 = r16
    //     0x4fc4a4: stur            w16, [x0, #0x13]
    // 0x4fc4a8: r16 = Instance_Tuple2
    //     0x4fc4a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152e0] Obj!Tuple2<Chapter15Stat, CustomNum>@824711
    //     0x4fc4ac: ldr             x16, [x16, #0x2e0]
    // 0x4fc4b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fc4b0: stur            w16, [x0, #0x17]
    // 0x4fc4b4: r16 = Instance_Tuple2
    //     0x4fc4b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152e8] Obj!Tuple2<Chapter15Stat, CustomNum>@8246f1
    //     0x4fc4b8: ldr             x16, [x16, #0x2e8]
    // 0x4fc4bc: StoreField: r0->field_1b = r16
    //     0x4fc4bc: stur            w16, [x0, #0x1b]
    // 0x4fc4c0: r16 = Instance_Tuple2
    //     0x4fc4c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!Tuple2<Chapter15Stat, CustomNum>@8246d1
    //     0x4fc4c4: ldr             x16, [x16, #0x2f0]
    // 0x4fc4c8: StoreField: r0->field_1f = r16
    //     0x4fc4c8: stur            w16, [x0, #0x1f]
    // 0x4fc4cc: r16 = Instance_Tuple2
    //     0x4fc4cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f8] Obj!Tuple2<Chapter15Stat, CustomNum>@8246b1
    //     0x4fc4d0: ldr             x16, [x16, #0x2f8]
    // 0x4fc4d4: StoreField: r0->field_23 = r16
    //     0x4fc4d4: stur            w16, [x0, #0x23]
    // 0x4fc4d8: r16 = Instance_Tuple2
    //     0x4fc4d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15300] Obj!Tuple2<Chapter15Stat, CustomNum>@824691
    //     0x4fc4dc: ldr             x16, [x16, #0x300]
    // 0x4fc4e0: StoreField: r0->field_27 = r16
    //     0x4fc4e0: stur            w16, [x0, #0x27]
    // 0x4fc4e4: r16 = Instance_Tuple2
    //     0x4fc4e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Tuple2<Chapter15Stat, CustomNum>@824671
    //     0x4fc4e8: ldr             x16, [x16, #0x308]
    // 0x4fc4ec: StoreField: r0->field_2b = r16
    //     0x4fc4ec: stur            w16, [x0, #0x2b]
    // 0x4fc4f0: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc4f0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc4f4: ldr             x1, [x1, #0x310]
    // 0x4fc4f8: r0 = AllocateGrowableArray()
    //     0x4fc4f8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fc4fc: mov             x2, x0
    // 0x4fc500: ldur            x0, [fp, #-0x20]
    // 0x4fc504: stur            x2, [fp, #-0x30]
    // 0x4fc508: StoreField: r2->field_f = r0
    //     0x4fc508: stur            w0, [x2, #0xf]
    // 0x4fc50c: r0 = 16
    //     0x4fc50c: movz            x0, #0x10
    // 0x4fc510: StoreField: r2->field_b = r0
    //     0x4fc510: stur            w0, [x2, #0xb]
    // 0x4fc514: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc514: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc518: ldr             x1, [x1, #0x310]
    // 0x4fc51c: r0 = Generator()
    //     0x4fc51c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fc520: mov             x2, x0
    // 0x4fc524: ldur            x0, [fp, #-0x30]
    // 0x4fc528: stur            x2, [fp, #-0x20]
    // 0x4fc52c: StoreField: r2->field_b = r0
    //     0x4fc52c: stur            w0, [x2, #0xb]
    // 0x4fc530: r1 = <Chapter15Stat>
    //     0x4fc530: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fc534: ldr             x1, [x1, #0xf98]
    // 0x4fc538: r0 = UpgradeData()
    //     0x4fc538: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fc53c: mov             x1, x0
    // 0x4fc540: ldur            x0, [fp, #-0x18]
    // 0x4fc544: StoreField: r1->field_b = r0
    //     0x4fc544: stur            w0, [x1, #0xb]
    // 0x4fc548: ldur            x0, [fp, #-0x28]
    // 0x4fc54c: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fc54c: stur            w0, [x1, #0x17]
    // 0x4fc550: r0 = Instance_IconData
    //     0x4fc550: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!IconData@830431
    //     0x4fc554: ldr             x0, [x0, #0x318]
    // 0x4fc558: StoreField: r1->field_13 = r0
    //     0x4fc558: stur            w0, [x1, #0x13]
    // 0x4fc55c: ldur            x0, [fp, #-0x20]
    // 0x4fc560: StoreField: r1->field_f = r0
    //     0x4fc560: stur            w0, [x1, #0xf]
    // 0x4fc564: mov             x0, x1
    // 0x4fc568: ldur            x1, [fp, #-0x10]
    // 0x4fc56c: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fc56c: add             x25, x1, #0x13
    //     0x4fc570: str             w0, [x25]
    //     0x4fc574: tbz             w0, #0, #0x4fc590
    //     0x4fc578: ldurb           w16, [x1, #-1]
    //     0x4fc57c: ldurb           w17, [x0, #-1]
    //     0x4fc580: and             x16, x17, x16, lsr #2
    //     0x4fc584: tst             x16, HEAP, lsr #32
    //     0x4fc588: b.eq            #0x4fc590
    //     0x4fc58c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fc590: ldur            x0, [fp, #-0x10]
    // 0x4fc594: r16 = 4
    //     0x4fc594: movz            x16, #0x4
    // 0x4fc598: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fc598: stur            w16, [x0, #0x17]
    // 0x4fc59c: r1 = "Bonus Symbols"
    //     0x4fc59c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15320] "Bonus Symbols"
    //     0x4fc5a0: ldr             x1, [x1, #0x320]
    // 0x4fc5a4: r0 = autoString()
    //     0x4fc5a4: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fc5a8: r1 = Null
    //     0x4fc5a8: mov             x1, NULL
    // 0x4fc5ac: r2 = 12
    //     0x4fc5ac: movz            x2, #0xc
    // 0x4fc5b0: stur            x0, [fp, #-0x18]
    // 0x4fc5b4: r0 = AllocateArray()
    //     0x4fc5b4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc5b8: stur            x0, [fp, #-0x20]
    // 0x4fc5bc: r16 = "Adds bonus generators to the symbol generators."
    //     0x4fc5bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15328] "Adds bonus generators to the symbol generators."
    //     0x4fc5c0: ldr             x16, [x16, #0x328]
    // 0x4fc5c4: StoreField: r0->field_f = r16
    //     0x4fc5c4: stur            w16, [x0, #0xf]
    // 0x4fc5c8: r16 = "Adds more bonus generators to the symbol generators."
    //     0x4fc5c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15330] "Adds more bonus generators to the symbol generators."
    //     0x4fc5cc: ldr             x16, [x16, #0x330]
    // 0x4fc5d0: StoreField: r0->field_13 = r16
    //     0x4fc5d0: stur            w16, [x0, #0x13]
    // 0x4fc5d4: r16 = "Adds more bonus generators to the symbol generators."
    //     0x4fc5d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15330] "Adds more bonus generators to the symbol generators."
    //     0x4fc5d8: ldr             x16, [x16, #0x330]
    // 0x4fc5dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fc5dc: stur            w16, [x0, #0x17]
    // 0x4fc5e0: r16 = "Adds more bonus generators to the symbol generators."
    //     0x4fc5e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15330] "Adds more bonus generators to the symbol generators."
    //     0x4fc5e4: ldr             x16, [x16, #0x330]
    // 0x4fc5e8: StoreField: r0->field_1b = r16
    //     0x4fc5e8: stur            w16, [x0, #0x1b]
    // 0x4fc5ec: r16 = "Adds more bonus generators to the symbol generators."
    //     0x4fc5ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15330] "Adds more bonus generators to the symbol generators."
    //     0x4fc5f0: ldr             x16, [x16, #0x330]
    // 0x4fc5f4: StoreField: r0->field_1f = r16
    //     0x4fc5f4: stur            w16, [x0, #0x1f]
    // 0x4fc5f8: r16 = "Adds more bonus generators to the symbol generators."
    //     0x4fc5f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15330] "Adds more bonus generators to the symbol generators."
    //     0x4fc5fc: ldr             x16, [x16, #0x330]
    // 0x4fc600: StoreField: r0->field_23 = r16
    //     0x4fc600: stur            w16, [x0, #0x23]
    // 0x4fc604: r1 = <String>
    //     0x4fc604: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fc608: r0 = AllocateGrowableArray()
    //     0x4fc608: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fc60c: mov             x2, x0
    // 0x4fc610: ldur            x0, [fp, #-0x20]
    // 0x4fc614: stur            x2, [fp, #-0x28]
    // 0x4fc618: StoreField: r2->field_f = r0
    //     0x4fc618: stur            w0, [x2, #0xf]
    // 0x4fc61c: r0 = 12
    //     0x4fc61c: movz            x0, #0xc
    // 0x4fc620: StoreField: r2->field_b = r0
    //     0x4fc620: stur            w0, [x2, #0xb]
    // 0x4fc624: r1 = <String>
    //     0x4fc624: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fc628: r0 = Generator()
    //     0x4fc628: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fc62c: mov             x3, x0
    // 0x4fc630: ldur            x0, [fp, #-0x28]
    // 0x4fc634: stur            x3, [fp, #-0x20]
    // 0x4fc638: StoreField: r3->field_b = r0
    //     0x4fc638: stur            w0, [x3, #0xb]
    // 0x4fc63c: r1 = Null
    //     0x4fc63c: mov             x1, NULL
    // 0x4fc640: r2 = 12
    //     0x4fc640: movz            x2, #0xc
    // 0x4fc644: r0 = AllocateArray()
    //     0x4fc644: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc648: stur            x0, [fp, #-0x28]
    // 0x4fc64c: r16 = Instance_Tuple2
    //     0x4fc64c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15338] Obj!Tuple2<Chapter15Stat, CustomNum>@824651
    //     0x4fc650: ldr             x16, [x16, #0x338]
    // 0x4fc654: StoreField: r0->field_f = r16
    //     0x4fc654: stur            w16, [x0, #0xf]
    // 0x4fc658: r16 = Instance_Tuple2
    //     0x4fc658: add             x16, PP, #0x15, lsl #12  ; [pp+0x15340] Obj!Tuple2<Chapter15Stat, CustomNum>@824631
    //     0x4fc65c: ldr             x16, [x16, #0x340]
    // 0x4fc660: StoreField: r0->field_13 = r16
    //     0x4fc660: stur            w16, [x0, #0x13]
    // 0x4fc664: r16 = Instance_Tuple2
    //     0x4fc664: add             x16, PP, #0x15, lsl #12  ; [pp+0x15348] Obj!Tuple2<Chapter15Stat, CustomNum>@824611
    //     0x4fc668: ldr             x16, [x16, #0x348]
    // 0x4fc66c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fc66c: stur            w16, [x0, #0x17]
    // 0x4fc670: r16 = Instance_Tuple2
    //     0x4fc670: add             x16, PP, #0x15, lsl #12  ; [pp+0x15350] Obj!Tuple2<Chapter15Stat, CustomNum>@8245f1
    //     0x4fc674: ldr             x16, [x16, #0x350]
    // 0x4fc678: StoreField: r0->field_1b = r16
    //     0x4fc678: stur            w16, [x0, #0x1b]
    // 0x4fc67c: r16 = Instance_Tuple2
    //     0x4fc67c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15358] Obj!Tuple2<Chapter15Stat, CustomNum>@8245d1
    //     0x4fc680: ldr             x16, [x16, #0x358]
    // 0x4fc684: StoreField: r0->field_1f = r16
    //     0x4fc684: stur            w16, [x0, #0x1f]
    // 0x4fc688: r16 = Instance_Tuple2
    //     0x4fc688: add             x16, PP, #0x15, lsl #12  ; [pp+0x15360] Obj!Tuple2<Chapter15Stat, CustomNum>@8245b1
    //     0x4fc68c: ldr             x16, [x16, #0x360]
    // 0x4fc690: StoreField: r0->field_23 = r16
    //     0x4fc690: stur            w16, [x0, #0x23]
    // 0x4fc694: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc694: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc698: ldr             x1, [x1, #0x310]
    // 0x4fc69c: r0 = AllocateGrowableArray()
    //     0x4fc69c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fc6a0: mov             x2, x0
    // 0x4fc6a4: ldur            x0, [fp, #-0x28]
    // 0x4fc6a8: stur            x2, [fp, #-0x30]
    // 0x4fc6ac: StoreField: r2->field_f = r0
    //     0x4fc6ac: stur            w0, [x2, #0xf]
    // 0x4fc6b0: r0 = 12
    //     0x4fc6b0: movz            x0, #0xc
    // 0x4fc6b4: StoreField: r2->field_b = r0
    //     0x4fc6b4: stur            w0, [x2, #0xb]
    // 0x4fc6b8: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc6b8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc6bc: ldr             x1, [x1, #0x310]
    // 0x4fc6c0: r0 = Generator()
    //     0x4fc6c0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fc6c4: mov             x2, x0
    // 0x4fc6c8: ldur            x0, [fp, #-0x30]
    // 0x4fc6cc: stur            x2, [fp, #-0x28]
    // 0x4fc6d0: StoreField: r2->field_b = r0
    //     0x4fc6d0: stur            w0, [x2, #0xb]
    // 0x4fc6d4: r1 = <Chapter15Stat>
    //     0x4fc6d4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fc6d8: ldr             x1, [x1, #0xf98]
    // 0x4fc6dc: r0 = UpgradeData()
    //     0x4fc6dc: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fc6e0: mov             x1, x0
    // 0x4fc6e4: ldur            x0, [fp, #-0x18]
    // 0x4fc6e8: StoreField: r1->field_b = r0
    //     0x4fc6e8: stur            w0, [x1, #0xb]
    // 0x4fc6ec: ldur            x0, [fp, #-0x20]
    // 0x4fc6f0: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fc6f0: stur            w0, [x1, #0x17]
    // 0x4fc6f4: r0 = Instance_IconData
    //     0x4fc6f4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15368] Obj!IconData@830411
    //     0x4fc6f8: ldr             x0, [x0, #0x368]
    // 0x4fc6fc: StoreField: r1->field_13 = r0
    //     0x4fc6fc: stur            w0, [x1, #0x13]
    // 0x4fc700: ldur            x0, [fp, #-0x28]
    // 0x4fc704: StoreField: r1->field_f = r0
    //     0x4fc704: stur            w0, [x1, #0xf]
    // 0x4fc708: mov             x0, x1
    // 0x4fc70c: ldur            x1, [fp, #-0x10]
    // 0x4fc710: ArrayStore: r1[3] = r0  ; List_4
    //     0x4fc710: add             x25, x1, #0x1b
    //     0x4fc714: str             w0, [x25]
    //     0x4fc718: tbz             w0, #0, #0x4fc734
    //     0x4fc71c: ldurb           w16, [x1, #-1]
    //     0x4fc720: ldurb           w17, [x0, #-1]
    //     0x4fc724: and             x16, x17, x16, lsr #2
    //     0x4fc728: tst             x16, HEAP, lsr #32
    //     0x4fc72c: b.eq            #0x4fc734
    //     0x4fc730: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fc734: ldur            x0, [fp, #-0x10]
    // 0x4fc738: r16 = 6
    //     0x4fc738: movz            x16, #0x6
    // 0x4fc73c: StoreField: r0->field_1f = r16
    //     0x4fc73c: stur            w16, [x0, #0x1f]
    // 0x4fc740: r1 = "Bigger Bonuses"
    //     0x4fc740: add             x1, PP, #0x15, lsl #12  ; [pp+0x15370] "Bigger Bonuses"
    //     0x4fc744: ldr             x1, [x1, #0x370]
    // 0x4fc748: r0 = autoString()
    //     0x4fc748: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fc74c: stur            x0, [fp, #-0x18]
    // 0x4fc750: r16 = 2
    //     0x4fc750: movz            x16, #0x2
    // 0x4fc754: str             x16, [SP]
    // 0x4fc758: ldur            x1, [fp, #-8]
    // 0x4fc75c: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc75c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc760: ldr             x4, [x4, #0x2c0]
    // 0x4fc764: r0 = bonusYieldBoost()
    //     0x4fc764: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x4fc768: r0 = inline_Allocate_Double()
    //     0x4fc768: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x4fc76c: add             x0, x0, #0x10
    //     0x4fc770: cmp             x1, x0
    //     0x4fc774: b.ls            #0x4fdb88
    //     0x4fc778: str             x0, [THR, #0x60]  ; THR::top
    //     0x4fc77c: sub             x0, x0, #0xf
    //     0x4fc780: movz            x1, #0xe19c
    //     0x4fc784: movk            x1, #0x3, lsl #16
    //     0x4fc788: stur            x1, [x0, #-1]
    // 0x4fc78c: dmb             ishst
    // 0x4fc790: StoreField: r0->field_7 = d0
    //     0x4fc790: stur            d0, [x0, #7]
    // 0x4fc794: stur            x0, [fp, #-0x20]
    // 0x4fc798: r1 = Null
    //     0x4fc798: mov             x1, NULL
    // 0x4fc79c: r2 = 4
    //     0x4fc79c: movz            x2, #0x4
    // 0x4fc7a0: r0 = AllocateArray()
    //     0x4fc7a0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc7a4: mov             x1, x0
    // 0x4fc7a8: ldur            x0, [fp, #-0x20]
    // 0x4fc7ac: StoreField: r1->field_f = r0
    //     0x4fc7ac: stur            w0, [x1, #0xf]
    // 0x4fc7b0: r16 = "x the bonus symbol generators"
    //     0x4fc7b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15378] "x the bonus symbol generators"
    //     0x4fc7b4: ldr             x16, [x16, #0x378]
    // 0x4fc7b8: StoreField: r1->field_13 = r16
    //     0x4fc7b8: stur            w16, [x1, #0x13]
    // 0x4fc7bc: str             x1, [SP]
    // 0x4fc7c0: r0 = _interpolate()
    //     0x4fc7c0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc7c4: stur            x0, [fp, #-0x20]
    // 0x4fc7c8: r16 = 4
    //     0x4fc7c8: movz            x16, #0x4
    // 0x4fc7cc: str             x16, [SP]
    // 0x4fc7d0: ldur            x1, [fp, #-8]
    // 0x4fc7d4: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc7d4: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc7d8: ldr             x4, [x4, #0x2c0]
    // 0x4fc7dc: r0 = bonusYieldBoost()
    //     0x4fc7dc: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x4fc7e0: r0 = inline_Allocate_Double()
    //     0x4fc7e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x4fc7e4: add             x0, x0, #0x10
    //     0x4fc7e8: cmp             x1, x0
    //     0x4fc7ec: b.ls            #0x4fdb98
    //     0x4fc7f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x4fc7f4: sub             x0, x0, #0xf
    //     0x4fc7f8: movz            x1, #0xe19c
    //     0x4fc7fc: movk            x1, #0x3, lsl #16
    //     0x4fc800: stur            x1, [x0, #-1]
    // 0x4fc804: dmb             ishst
    // 0x4fc808: StoreField: r0->field_7 = d0
    //     0x4fc808: stur            d0, [x0, #7]
    // 0x4fc80c: stur            x0, [fp, #-0x28]
    // 0x4fc810: r1 = Null
    //     0x4fc810: mov             x1, NULL
    // 0x4fc814: r2 = 4
    //     0x4fc814: movz            x2, #0x4
    // 0x4fc818: r0 = AllocateArray()
    //     0x4fc818: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc81c: mov             x1, x0
    // 0x4fc820: ldur            x0, [fp, #-0x28]
    // 0x4fc824: StoreField: r1->field_f = r0
    //     0x4fc824: stur            w0, [x1, #0xf]
    // 0x4fc828: r16 = "x the bonus symbol generators"
    //     0x4fc828: add             x16, PP, #0x15, lsl #12  ; [pp+0x15378] "x the bonus symbol generators"
    //     0x4fc82c: ldr             x16, [x16, #0x378]
    // 0x4fc830: StoreField: r1->field_13 = r16
    //     0x4fc830: stur            w16, [x1, #0x13]
    // 0x4fc834: str             x1, [SP]
    // 0x4fc838: r0 = _interpolate()
    //     0x4fc838: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc83c: stur            x0, [fp, #-0x28]
    // 0x4fc840: r16 = 6
    //     0x4fc840: movz            x16, #0x6
    // 0x4fc844: str             x16, [SP]
    // 0x4fc848: ldur            x1, [fp, #-8]
    // 0x4fc84c: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc84c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc850: ldr             x4, [x4, #0x2c0]
    // 0x4fc854: r0 = bonusYieldBoost()
    //     0x4fc854: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x4fc858: r0 = inline_Allocate_Double()
    //     0x4fc858: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x4fc85c: add             x0, x0, #0x10
    //     0x4fc860: cmp             x1, x0
    //     0x4fc864: b.ls            #0x4fdba8
    //     0x4fc868: str             x0, [THR, #0x60]  ; THR::top
    //     0x4fc86c: sub             x0, x0, #0xf
    //     0x4fc870: movz            x1, #0xe19c
    //     0x4fc874: movk            x1, #0x3, lsl #16
    //     0x4fc878: stur            x1, [x0, #-1]
    // 0x4fc87c: dmb             ishst
    // 0x4fc880: StoreField: r0->field_7 = d0
    //     0x4fc880: stur            d0, [x0, #7]
    // 0x4fc884: stur            x0, [fp, #-0x30]
    // 0x4fc888: r1 = Null
    //     0x4fc888: mov             x1, NULL
    // 0x4fc88c: r2 = 4
    //     0x4fc88c: movz            x2, #0x4
    // 0x4fc890: r0 = AllocateArray()
    //     0x4fc890: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc894: mov             x1, x0
    // 0x4fc898: ldur            x0, [fp, #-0x30]
    // 0x4fc89c: StoreField: r1->field_f = r0
    //     0x4fc89c: stur            w0, [x1, #0xf]
    // 0x4fc8a0: r16 = "x the bonus symbol generators"
    //     0x4fc8a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15378] "x the bonus symbol generators"
    //     0x4fc8a4: ldr             x16, [x16, #0x378]
    // 0x4fc8a8: StoreField: r1->field_13 = r16
    //     0x4fc8a8: stur            w16, [x1, #0x13]
    // 0x4fc8ac: str             x1, [SP]
    // 0x4fc8b0: r0 = _interpolate()
    //     0x4fc8b0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc8b4: stur            x0, [fp, #-0x30]
    // 0x4fc8b8: r16 = 8
    //     0x4fc8b8: movz            x16, #0x8
    // 0x4fc8bc: str             x16, [SP]
    // 0x4fc8c0: ldur            x1, [fp, #-8]
    // 0x4fc8c4: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fc8c4: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fc8c8: ldr             x4, [x4, #0x2c0]
    // 0x4fc8cc: r0 = bonusYieldBoost()
    //     0x4fc8cc: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x4fc8d0: r0 = inline_Allocate_Double()
    //     0x4fc8d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x4fc8d4: add             x0, x0, #0x10
    //     0x4fc8d8: cmp             x1, x0
    //     0x4fc8dc: b.ls            #0x4fdbb8
    //     0x4fc8e0: str             x0, [THR, #0x60]  ; THR::top
    //     0x4fc8e4: sub             x0, x0, #0xf
    //     0x4fc8e8: movz            x1, #0xe19c
    //     0x4fc8ec: movk            x1, #0x3, lsl #16
    //     0x4fc8f0: stur            x1, [x0, #-1]
    // 0x4fc8f4: dmb             ishst
    // 0x4fc8f8: StoreField: r0->field_7 = d0
    //     0x4fc8f8: stur            d0, [x0, #7]
    // 0x4fc8fc: stur            x0, [fp, #-0x38]
    // 0x4fc900: r1 = Null
    //     0x4fc900: mov             x1, NULL
    // 0x4fc904: r2 = 4
    //     0x4fc904: movz            x2, #0x4
    // 0x4fc908: r0 = AllocateArray()
    //     0x4fc908: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc90c: mov             x1, x0
    // 0x4fc910: ldur            x0, [fp, #-0x38]
    // 0x4fc914: StoreField: r1->field_f = r0
    //     0x4fc914: stur            w0, [x1, #0xf]
    // 0x4fc918: r16 = "x the bonus symbol generators"
    //     0x4fc918: add             x16, PP, #0x15, lsl #12  ; [pp+0x15378] "x the bonus symbol generators"
    //     0x4fc91c: ldr             x16, [x16, #0x378]
    // 0x4fc920: StoreField: r1->field_13 = r16
    //     0x4fc920: stur            w16, [x1, #0x13]
    // 0x4fc924: str             x1, [SP]
    // 0x4fc928: r0 = _interpolate()
    //     0x4fc928: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fc92c: r1 = Null
    //     0x4fc92c: mov             x1, NULL
    // 0x4fc930: r2 = 8
    //     0x4fc930: movz            x2, #0x8
    // 0x4fc934: stur            x0, [fp, #-0x38]
    // 0x4fc938: r0 = AllocateArray()
    //     0x4fc938: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc93c: mov             x2, x0
    // 0x4fc940: ldur            x0, [fp, #-0x20]
    // 0x4fc944: stur            x2, [fp, #-0x40]
    // 0x4fc948: StoreField: r2->field_f = r0
    //     0x4fc948: stur            w0, [x2, #0xf]
    // 0x4fc94c: ldur            x0, [fp, #-0x28]
    // 0x4fc950: StoreField: r2->field_13 = r0
    //     0x4fc950: stur            w0, [x2, #0x13]
    // 0x4fc954: ldur            x0, [fp, #-0x30]
    // 0x4fc958: ArrayStore: r2[0] = r0  ; List_4
    //     0x4fc958: stur            w0, [x2, #0x17]
    // 0x4fc95c: ldur            x0, [fp, #-0x38]
    // 0x4fc960: StoreField: r2->field_1b = r0
    //     0x4fc960: stur            w0, [x2, #0x1b]
    // 0x4fc964: r1 = <String>
    //     0x4fc964: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fc968: r0 = AllocateGrowableArray()
    //     0x4fc968: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fc96c: mov             x2, x0
    // 0x4fc970: ldur            x0, [fp, #-0x40]
    // 0x4fc974: stur            x2, [fp, #-0x20]
    // 0x4fc978: StoreField: r2->field_f = r0
    //     0x4fc978: stur            w0, [x2, #0xf]
    // 0x4fc97c: r0 = 8
    //     0x4fc97c: movz            x0, #0x8
    // 0x4fc980: StoreField: r2->field_b = r0
    //     0x4fc980: stur            w0, [x2, #0xb]
    // 0x4fc984: r1 = <String>
    //     0x4fc984: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fc988: r0 = Generator()
    //     0x4fc988: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fc98c: mov             x3, x0
    // 0x4fc990: ldur            x0, [fp, #-0x20]
    // 0x4fc994: stur            x3, [fp, #-0x28]
    // 0x4fc998: StoreField: r3->field_b = r0
    //     0x4fc998: stur            w0, [x3, #0xb]
    // 0x4fc99c: r1 = Null
    //     0x4fc99c: mov             x1, NULL
    // 0x4fc9a0: r2 = 8
    //     0x4fc9a0: movz            x2, #0x8
    // 0x4fc9a4: r0 = AllocateArray()
    //     0x4fc9a4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fc9a8: stur            x0, [fp, #-0x20]
    // 0x4fc9ac: r16 = Instance_Tuple2
    //     0x4fc9ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15380] Obj!Tuple2<Chapter15Stat, CustomNum>@824591
    //     0x4fc9b0: ldr             x16, [x16, #0x380]
    // 0x4fc9b4: StoreField: r0->field_f = r16
    //     0x4fc9b4: stur            w16, [x0, #0xf]
    // 0x4fc9b8: r16 = Instance_Tuple2
    //     0x4fc9b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15388] Obj!Tuple2<Chapter15Stat, CustomNum>@824571
    //     0x4fc9bc: ldr             x16, [x16, #0x388]
    // 0x4fc9c0: StoreField: r0->field_13 = r16
    //     0x4fc9c0: stur            w16, [x0, #0x13]
    // 0x4fc9c4: r16 = Instance_Tuple2
    //     0x4fc9c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15390] Obj!Tuple2<Chapter15Stat, CustomNum>@824551
    //     0x4fc9c8: ldr             x16, [x16, #0x390]
    // 0x4fc9cc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fc9cc: stur            w16, [x0, #0x17]
    // 0x4fc9d0: r16 = Instance_Tuple2
    //     0x4fc9d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15398] Obj!Tuple2<Chapter15Stat, CustomNum>@824531
    //     0x4fc9d4: ldr             x16, [x16, #0x398]
    // 0x4fc9d8: StoreField: r0->field_1b = r16
    //     0x4fc9d8: stur            w16, [x0, #0x1b]
    // 0x4fc9dc: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc9dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fc9e0: ldr             x1, [x1, #0x310]
    // 0x4fc9e4: r0 = AllocateGrowableArray()
    //     0x4fc9e4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fc9e8: mov             x2, x0
    // 0x4fc9ec: ldur            x0, [fp, #-0x20]
    // 0x4fc9f0: stur            x2, [fp, #-0x30]
    // 0x4fc9f4: StoreField: r2->field_f = r0
    //     0x4fc9f4: stur            w0, [x2, #0xf]
    // 0x4fc9f8: r0 = 8
    //     0x4fc9f8: movz            x0, #0x8
    // 0x4fc9fc: StoreField: r2->field_b = r0
    //     0x4fc9fc: stur            w0, [x2, #0xb]
    // 0x4fca00: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fca00: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fca04: ldr             x1, [x1, #0x310]
    // 0x4fca08: r0 = Generator()
    //     0x4fca08: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fca0c: mov             x2, x0
    // 0x4fca10: ldur            x0, [fp, #-0x30]
    // 0x4fca14: stur            x2, [fp, #-0x20]
    // 0x4fca18: StoreField: r2->field_b = r0
    //     0x4fca18: stur            w0, [x2, #0xb]
    // 0x4fca1c: r1 = <Chapter15Stat>
    //     0x4fca1c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fca20: ldr             x1, [x1, #0xf98]
    // 0x4fca24: r0 = UpgradeData()
    //     0x4fca24: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fca28: mov             x1, x0
    // 0x4fca2c: ldur            x0, [fp, #-0x18]
    // 0x4fca30: StoreField: r1->field_b = r0
    //     0x4fca30: stur            w0, [x1, #0xb]
    // 0x4fca34: ldur            x0, [fp, #-0x28]
    // 0x4fca38: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fca38: stur            w0, [x1, #0x17]
    // 0x4fca3c: r0 = Instance_IconData
    //     0x4fca3c: add             x0, PP, #0x15, lsl #12  ; [pp+0x153a0] Obj!IconData@830171
    //     0x4fca40: ldr             x0, [x0, #0x3a0]
    // 0x4fca44: StoreField: r1->field_13 = r0
    //     0x4fca44: stur            w0, [x1, #0x13]
    // 0x4fca48: ldur            x0, [fp, #-0x20]
    // 0x4fca4c: StoreField: r1->field_f = r0
    //     0x4fca4c: stur            w0, [x1, #0xf]
    // 0x4fca50: mov             x0, x1
    // 0x4fca54: ldur            x1, [fp, #-0x10]
    // 0x4fca58: ArrayStore: r1[5] = r0  ; List_4
    //     0x4fca58: add             x25, x1, #0x23
    //     0x4fca5c: str             w0, [x25]
    //     0x4fca60: tbz             w0, #0, #0x4fca7c
    //     0x4fca64: ldurb           w16, [x1, #-1]
    //     0x4fca68: ldurb           w17, [x0, #-1]
    //     0x4fca6c: and             x16, x17, x16, lsr #2
    //     0x4fca70: tst             x16, HEAP, lsr #32
    //     0x4fca74: b.eq            #0x4fca7c
    //     0x4fca78: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fca7c: ldur            x0, [fp, #-0x10]
    // 0x4fca80: r16 = 22
    //     0x4fca80: movz            x16, #0x16
    // 0x4fca84: StoreField: r0->field_27 = r16
    //     0x4fca84: stur            w16, [x0, #0x27]
    // 0x4fca88: r1 = "Multithreading"
    //     0x4fca88: add             x1, PP, #0x15, lsl #12  ; [pp+0x153a8] "Multithreading"
    //     0x4fca8c: ldr             x1, [x1, #0x3a8]
    // 0x4fca90: r0 = autoString()
    //     0x4fca90: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fca94: stur            x0, [fp, #-0x18]
    // 0x4fca98: r16 = 2
    //     0x4fca98: movz            x16, #0x2
    // 0x4fca9c: str             x16, [SP]
    // 0x4fcaa0: ldur            x1, [fp, #-8]
    // 0x4fcaa4: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcaa4: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcaa8: ldr             x4, [x4, #0x2c0]
    // 0x4fcaac: r0 = multithreadingBoost()
    //     0x4fcaac: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcab0: r1 = Null
    //     0x4fcab0: mov             x1, NULL
    // 0x4fcab4: r2 = 4
    //     0x4fcab4: movz            x2, #0x4
    // 0x4fcab8: stur            x0, [fp, #-0x20]
    // 0x4fcabc: r0 = AllocateArray()
    //     0x4fcabc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcac0: mov             x1, x0
    // 0x4fcac4: ldur            x0, [fp, #-0x20]
    // 0x4fcac8: StoreField: r1->field_f = r0
    //     0x4fcac8: stur            w0, [x1, #0xf]
    // 0x4fcacc: r16 = "x yields from all generator symbol sources."
    //     0x4fcacc: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcad0: ldr             x16, [x16, #0x3b0]
    // 0x4fcad4: StoreField: r1->field_13 = r16
    //     0x4fcad4: stur            w16, [x1, #0x13]
    // 0x4fcad8: str             x1, [SP]
    // 0x4fcadc: r0 = _interpolate()
    //     0x4fcadc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcae0: stur            x0, [fp, #-0x20]
    // 0x4fcae4: r16 = 4
    //     0x4fcae4: movz            x16, #0x4
    // 0x4fcae8: str             x16, [SP]
    // 0x4fcaec: ldur            x1, [fp, #-8]
    // 0x4fcaf0: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcaf0: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcaf4: ldr             x4, [x4, #0x2c0]
    // 0x4fcaf8: r0 = multithreadingBoost()
    //     0x4fcaf8: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcafc: r1 = Null
    //     0x4fcafc: mov             x1, NULL
    // 0x4fcb00: r2 = 4
    //     0x4fcb00: movz            x2, #0x4
    // 0x4fcb04: stur            x0, [fp, #-0x28]
    // 0x4fcb08: r0 = AllocateArray()
    //     0x4fcb08: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcb0c: mov             x1, x0
    // 0x4fcb10: ldur            x0, [fp, #-0x28]
    // 0x4fcb14: StoreField: r1->field_f = r0
    //     0x4fcb14: stur            w0, [x1, #0xf]
    // 0x4fcb18: r16 = "x yields from all generator symbol sources."
    //     0x4fcb18: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcb1c: ldr             x16, [x16, #0x3b0]
    // 0x4fcb20: StoreField: r1->field_13 = r16
    //     0x4fcb20: stur            w16, [x1, #0x13]
    // 0x4fcb24: str             x1, [SP]
    // 0x4fcb28: r0 = _interpolate()
    //     0x4fcb28: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcb2c: stur            x0, [fp, #-0x28]
    // 0x4fcb30: r16 = 6
    //     0x4fcb30: movz            x16, #0x6
    // 0x4fcb34: str             x16, [SP]
    // 0x4fcb38: ldur            x1, [fp, #-8]
    // 0x4fcb3c: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcb3c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcb40: ldr             x4, [x4, #0x2c0]
    // 0x4fcb44: r0 = multithreadingBoost()
    //     0x4fcb44: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcb48: r1 = Null
    //     0x4fcb48: mov             x1, NULL
    // 0x4fcb4c: r2 = 4
    //     0x4fcb4c: movz            x2, #0x4
    // 0x4fcb50: stur            x0, [fp, #-0x30]
    // 0x4fcb54: r0 = AllocateArray()
    //     0x4fcb54: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcb58: mov             x1, x0
    // 0x4fcb5c: ldur            x0, [fp, #-0x30]
    // 0x4fcb60: StoreField: r1->field_f = r0
    //     0x4fcb60: stur            w0, [x1, #0xf]
    // 0x4fcb64: r16 = "x yields from all generator symbol sources."
    //     0x4fcb64: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcb68: ldr             x16, [x16, #0x3b0]
    // 0x4fcb6c: StoreField: r1->field_13 = r16
    //     0x4fcb6c: stur            w16, [x1, #0x13]
    // 0x4fcb70: str             x1, [SP]
    // 0x4fcb74: r0 = _interpolate()
    //     0x4fcb74: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcb78: stur            x0, [fp, #-0x30]
    // 0x4fcb7c: r16 = 8
    //     0x4fcb7c: movz            x16, #0x8
    // 0x4fcb80: str             x16, [SP]
    // 0x4fcb84: ldur            x1, [fp, #-8]
    // 0x4fcb88: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcb88: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcb8c: ldr             x4, [x4, #0x2c0]
    // 0x4fcb90: r0 = multithreadingBoost()
    //     0x4fcb90: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcb94: r1 = Null
    //     0x4fcb94: mov             x1, NULL
    // 0x4fcb98: r2 = 4
    //     0x4fcb98: movz            x2, #0x4
    // 0x4fcb9c: stur            x0, [fp, #-0x38]
    // 0x4fcba0: r0 = AllocateArray()
    //     0x4fcba0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcba4: mov             x1, x0
    // 0x4fcba8: ldur            x0, [fp, #-0x38]
    // 0x4fcbac: StoreField: r1->field_f = r0
    //     0x4fcbac: stur            w0, [x1, #0xf]
    // 0x4fcbb0: r16 = "x yields from all generator symbol sources."
    //     0x4fcbb0: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcbb4: ldr             x16, [x16, #0x3b0]
    // 0x4fcbb8: StoreField: r1->field_13 = r16
    //     0x4fcbb8: stur            w16, [x1, #0x13]
    // 0x4fcbbc: str             x1, [SP]
    // 0x4fcbc0: r0 = _interpolate()
    //     0x4fcbc0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcbc4: stur            x0, [fp, #-0x38]
    // 0x4fcbc8: r16 = 10
    //     0x4fcbc8: movz            x16, #0xa
    // 0x4fcbcc: str             x16, [SP]
    // 0x4fcbd0: ldur            x1, [fp, #-8]
    // 0x4fcbd4: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcbd4: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcbd8: ldr             x4, [x4, #0x2c0]
    // 0x4fcbdc: r0 = multithreadingBoost()
    //     0x4fcbdc: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcbe0: r1 = Null
    //     0x4fcbe0: mov             x1, NULL
    // 0x4fcbe4: r2 = 4
    //     0x4fcbe4: movz            x2, #0x4
    // 0x4fcbe8: stur            x0, [fp, #-0x40]
    // 0x4fcbec: r0 = AllocateArray()
    //     0x4fcbec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcbf0: mov             x1, x0
    // 0x4fcbf4: ldur            x0, [fp, #-0x40]
    // 0x4fcbf8: StoreField: r1->field_f = r0
    //     0x4fcbf8: stur            w0, [x1, #0xf]
    // 0x4fcbfc: r16 = "x yields from all generator symbol sources."
    //     0x4fcbfc: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcc00: ldr             x16, [x16, #0x3b0]
    // 0x4fcc04: StoreField: r1->field_13 = r16
    //     0x4fcc04: stur            w16, [x1, #0x13]
    // 0x4fcc08: str             x1, [SP]
    // 0x4fcc0c: r0 = _interpolate()
    //     0x4fcc0c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcc10: stur            x0, [fp, #-0x40]
    // 0x4fcc14: r16 = 12
    //     0x4fcc14: movz            x16, #0xc
    // 0x4fcc18: str             x16, [SP]
    // 0x4fcc1c: ldur            x1, [fp, #-8]
    // 0x4fcc20: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcc20: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcc24: ldr             x4, [x4, #0x2c0]
    // 0x4fcc28: r0 = multithreadingBoost()
    //     0x4fcc28: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcc2c: r1 = Null
    //     0x4fcc2c: mov             x1, NULL
    // 0x4fcc30: r2 = 4
    //     0x4fcc30: movz            x2, #0x4
    // 0x4fcc34: stur            x0, [fp, #-0x48]
    // 0x4fcc38: r0 = AllocateArray()
    //     0x4fcc38: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcc3c: mov             x1, x0
    // 0x4fcc40: ldur            x0, [fp, #-0x48]
    // 0x4fcc44: StoreField: r1->field_f = r0
    //     0x4fcc44: stur            w0, [x1, #0xf]
    // 0x4fcc48: r16 = "x yields from all generator symbol sources."
    //     0x4fcc48: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcc4c: ldr             x16, [x16, #0x3b0]
    // 0x4fcc50: StoreField: r1->field_13 = r16
    //     0x4fcc50: stur            w16, [x1, #0x13]
    // 0x4fcc54: str             x1, [SP]
    // 0x4fcc58: r0 = _interpolate()
    //     0x4fcc58: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcc5c: stur            x0, [fp, #-0x48]
    // 0x4fcc60: r16 = 14
    //     0x4fcc60: movz            x16, #0xe
    // 0x4fcc64: str             x16, [SP]
    // 0x4fcc68: ldur            x1, [fp, #-8]
    // 0x4fcc6c: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcc6c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcc70: ldr             x4, [x4, #0x2c0]
    // 0x4fcc74: r0 = multithreadingBoost()
    //     0x4fcc74: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x4fcc78: r1 = Null
    //     0x4fcc78: mov             x1, NULL
    // 0x4fcc7c: r2 = 4
    //     0x4fcc7c: movz            x2, #0x4
    // 0x4fcc80: stur            x0, [fp, #-0x50]
    // 0x4fcc84: r0 = AllocateArray()
    //     0x4fcc84: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcc88: mov             x1, x0
    // 0x4fcc8c: ldur            x0, [fp, #-0x50]
    // 0x4fcc90: StoreField: r1->field_f = r0
    //     0x4fcc90: stur            w0, [x1, #0xf]
    // 0x4fcc94: r16 = "x yields from all generator symbol sources."
    //     0x4fcc94: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b0] "x yields from all generator symbol sources."
    //     0x4fcc98: ldr             x16, [x16, #0x3b0]
    // 0x4fcc9c: StoreField: r1->field_13 = r16
    //     0x4fcc9c: stur            w16, [x1, #0x13]
    // 0x4fcca0: str             x1, [SP]
    // 0x4fcca4: r0 = _interpolate()
    //     0x4fcca4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcca8: r1 = Null
    //     0x4fcca8: mov             x1, NULL
    // 0x4fccac: r2 = 14
    //     0x4fccac: movz            x2, #0xe
    // 0x4fccb0: stur            x0, [fp, #-0x50]
    // 0x4fccb4: r0 = AllocateArray()
    //     0x4fccb4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fccb8: mov             x2, x0
    // 0x4fccbc: ldur            x0, [fp, #-0x20]
    // 0x4fccc0: stur            x2, [fp, #-0x58]
    // 0x4fccc4: StoreField: r2->field_f = r0
    //     0x4fccc4: stur            w0, [x2, #0xf]
    // 0x4fccc8: ldur            x0, [fp, #-0x28]
    // 0x4fcccc: StoreField: r2->field_13 = r0
    //     0x4fcccc: stur            w0, [x2, #0x13]
    // 0x4fccd0: ldur            x0, [fp, #-0x30]
    // 0x4fccd4: ArrayStore: r2[0] = r0  ; List_4
    //     0x4fccd4: stur            w0, [x2, #0x17]
    // 0x4fccd8: ldur            x0, [fp, #-0x38]
    // 0x4fccdc: StoreField: r2->field_1b = r0
    //     0x4fccdc: stur            w0, [x2, #0x1b]
    // 0x4fcce0: ldur            x0, [fp, #-0x40]
    // 0x4fcce4: StoreField: r2->field_1f = r0
    //     0x4fcce4: stur            w0, [x2, #0x1f]
    // 0x4fcce8: ldur            x0, [fp, #-0x48]
    // 0x4fccec: StoreField: r2->field_23 = r0
    //     0x4fccec: stur            w0, [x2, #0x23]
    // 0x4fccf0: ldur            x0, [fp, #-0x50]
    // 0x4fccf4: StoreField: r2->field_27 = r0
    //     0x4fccf4: stur            w0, [x2, #0x27]
    // 0x4fccf8: r1 = <String>
    //     0x4fccf8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fccfc: r0 = AllocateGrowableArray()
    //     0x4fccfc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fcd00: mov             x2, x0
    // 0x4fcd04: ldur            x0, [fp, #-0x58]
    // 0x4fcd08: stur            x2, [fp, #-0x20]
    // 0x4fcd0c: StoreField: r2->field_f = r0
    //     0x4fcd0c: stur            w0, [x2, #0xf]
    // 0x4fcd10: r0 = 14
    //     0x4fcd10: movz            x0, #0xe
    // 0x4fcd14: StoreField: r2->field_b = r0
    //     0x4fcd14: stur            w0, [x2, #0xb]
    // 0x4fcd18: r1 = <String>
    //     0x4fcd18: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fcd1c: r0 = Generator()
    //     0x4fcd1c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fcd20: mov             x3, x0
    // 0x4fcd24: ldur            x0, [fp, #-0x20]
    // 0x4fcd28: stur            x3, [fp, #-0x28]
    // 0x4fcd2c: StoreField: r3->field_b = r0
    //     0x4fcd2c: stur            w0, [x3, #0xb]
    // 0x4fcd30: r1 = Null
    //     0x4fcd30: mov             x1, NULL
    // 0x4fcd34: r2 = 14
    //     0x4fcd34: movz            x2, #0xe
    // 0x4fcd38: r0 = AllocateArray()
    //     0x4fcd38: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcd3c: stur            x0, [fp, #-0x20]
    // 0x4fcd40: r16 = Instance_Tuple2
    //     0x4fcd40: add             x16, PP, #0x15, lsl #12  ; [pp+0x153b8] Obj!Tuple2<Chapter15Stat, CustomNum>@824511
    //     0x4fcd44: ldr             x16, [x16, #0x3b8]
    // 0x4fcd48: StoreField: r0->field_f = r16
    //     0x4fcd48: stur            w16, [x0, #0xf]
    // 0x4fcd4c: r16 = Instance_Tuple2
    //     0x4fcd4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x153c0] Obj!Tuple2<Chapter15Stat, CustomNum>@8244f1
    //     0x4fcd50: ldr             x16, [x16, #0x3c0]
    // 0x4fcd54: StoreField: r0->field_13 = r16
    //     0x4fcd54: stur            w16, [x0, #0x13]
    // 0x4fcd58: r16 = Instance_Tuple2
    //     0x4fcd58: add             x16, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Tuple2<Chapter15Stat, CustomNum>@8244d1
    //     0x4fcd5c: ldr             x16, [x16, #0x3c8]
    // 0x4fcd60: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fcd60: stur            w16, [x0, #0x17]
    // 0x4fcd64: r16 = Instance_Tuple2
    //     0x4fcd64: add             x16, PP, #0x15, lsl #12  ; [pp+0x153d0] Obj!Tuple2<Chapter15Stat, CustomNum>@8244b1
    //     0x4fcd68: ldr             x16, [x16, #0x3d0]
    // 0x4fcd6c: StoreField: r0->field_1b = r16
    //     0x4fcd6c: stur            w16, [x0, #0x1b]
    // 0x4fcd70: r16 = Instance_Tuple2
    //     0x4fcd70: add             x16, PP, #0x15, lsl #12  ; [pp+0x153d8] Obj!Tuple2<Chapter15Stat, CustomNum>@824491
    //     0x4fcd74: ldr             x16, [x16, #0x3d8]
    // 0x4fcd78: StoreField: r0->field_1f = r16
    //     0x4fcd78: stur            w16, [x0, #0x1f]
    // 0x4fcd7c: r16 = Instance_Tuple2
    //     0x4fcd7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x153e0] Obj!Tuple2<Chapter15Stat, CustomNum>@824471
    //     0x4fcd80: ldr             x16, [x16, #0x3e0]
    // 0x4fcd84: StoreField: r0->field_23 = r16
    //     0x4fcd84: stur            w16, [x0, #0x23]
    // 0x4fcd88: r16 = Instance_Tuple2
    //     0x4fcd88: add             x16, PP, #0x15, lsl #12  ; [pp+0x153e8] Obj!Tuple2<Chapter15Stat, CustomNum>@824451
    //     0x4fcd8c: ldr             x16, [x16, #0x3e8]
    // 0x4fcd90: StoreField: r0->field_27 = r16
    //     0x4fcd90: stur            w16, [x0, #0x27]
    // 0x4fcd94: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fcd94: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fcd98: ldr             x1, [x1, #0x310]
    // 0x4fcd9c: r0 = AllocateGrowableArray()
    //     0x4fcd9c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fcda0: mov             x2, x0
    // 0x4fcda4: ldur            x0, [fp, #-0x20]
    // 0x4fcda8: stur            x2, [fp, #-0x30]
    // 0x4fcdac: StoreField: r2->field_f = r0
    //     0x4fcdac: stur            w0, [x2, #0xf]
    // 0x4fcdb0: r0 = 14
    //     0x4fcdb0: movz            x0, #0xe
    // 0x4fcdb4: StoreField: r2->field_b = r0
    //     0x4fcdb4: stur            w0, [x2, #0xb]
    // 0x4fcdb8: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fcdb8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fcdbc: ldr             x1, [x1, #0x310]
    // 0x4fcdc0: r0 = Generator()
    //     0x4fcdc0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fcdc4: mov             x2, x0
    // 0x4fcdc8: ldur            x0, [fp, #-0x30]
    // 0x4fcdcc: stur            x2, [fp, #-0x20]
    // 0x4fcdd0: StoreField: r2->field_b = r0
    //     0x4fcdd0: stur            w0, [x2, #0xb]
    // 0x4fcdd4: r1 = <Chapter15Stat>
    //     0x4fcdd4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fcdd8: ldr             x1, [x1, #0xf98]
    // 0x4fcddc: r0 = UpgradeData()
    //     0x4fcddc: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fcde0: mov             x3, x0
    // 0x4fcde4: ldur            x0, [fp, #-0x18]
    // 0x4fcde8: stur            x3, [fp, #-0x30]
    // 0x4fcdec: StoreField: r3->field_b = r0
    //     0x4fcdec: stur            w0, [x3, #0xb]
    // 0x4fcdf0: ldur            x0, [fp, #-0x28]
    // 0x4fcdf4: ArrayStore: r3[0] = r0  ; List_4
    //     0x4fcdf4: stur            w0, [x3, #0x17]
    // 0x4fcdf8: r0 = Instance_IconData
    //     0x4fcdf8: add             x0, PP, #0x15, lsl #12  ; [pp+0x153f0] Obj!IconData@82f3b1
    //     0x4fcdfc: ldr             x0, [x0, #0x3f0]
    // 0x4fce00: StoreField: r3->field_13 = r0
    //     0x4fce00: stur            w0, [x3, #0x13]
    // 0x4fce04: ldur            x0, [fp, #-0x20]
    // 0x4fce08: StoreField: r3->field_f = r0
    //     0x4fce08: stur            w0, [x3, #0xf]
    // 0x4fce0c: ldur            x2, [fp, #-8]
    // 0x4fce10: r1 = Function 'resetAndRecomputeBoosts':.
    //     0x4fce10: add             x1, PP, #0x14, lsl #12  ; [pp+0x147e0] AnonymousClosure: (0x458ba0), in [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts (0x458b30)
    //     0x4fce14: ldr             x1, [x1, #0x7e0]
    // 0x4fce18: r0 = AllocateClosure()
    //     0x4fce18: bl              #0x826750  ; AllocateClosureStub
    // 0x4fce1c: mov             x1, x0
    // 0x4fce20: ldur            x0, [fp, #-0x30]
    // 0x4fce24: StoreField: r0->field_1b = r1
    //     0x4fce24: stur            w1, [x0, #0x1b]
    // 0x4fce28: ldur            x1, [fp, #-0x10]
    // 0x4fce2c: ArrayStore: r1[7] = r0  ; List_4
    //     0x4fce2c: add             x25, x1, #0x2b
    //     0x4fce30: str             w0, [x25]
    //     0x4fce34: tbz             w0, #0, #0x4fce50
    //     0x4fce38: ldurb           w16, [x1, #-1]
    //     0x4fce3c: ldurb           w17, [x0, #-1]
    //     0x4fce40: and             x16, x17, x16, lsr #2
    //     0x4fce44: tst             x16, HEAP, lsr #32
    //     0x4fce48: b.eq            #0x4fce50
    //     0x4fce4c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fce50: ldur            x0, [fp, #-0x10]
    // 0x4fce54: r16 = 24
    //     0x4fce54: movz            x16, #0x18
    // 0x4fce58: StoreField: r0->field_2f = r16
    //     0x4fce58: stur            w16, [x0, #0x2f]
    // 0x4fce5c: r1 = "Efficient Symbols"
    //     0x4fce5c: add             x1, PP, #0x15, lsl #12  ; [pp+0x153f8] "Efficient Symbols"
    //     0x4fce60: ldr             x1, [x1, #0x3f8]
    // 0x4fce64: r0 = autoString()
    //     0x4fce64: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fce68: r1 = Null
    //     0x4fce68: mov             x1, NULL
    // 0x4fce6c: r2 = 6
    //     0x4fce6c: movz            x2, #0x6
    // 0x4fce70: stur            x0, [fp, #-0x18]
    // 0x4fce74: r0 = AllocateArray()
    //     0x4fce74: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fce78: stur            x0, [fp, #-0x20]
    // 0x4fce7c: r16 = "Increases the yield of symbol generators by "
    //     0x4fce7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15400] "Increases the yield of symbol generators by "
    //     0x4fce80: ldr             x16, [x16, #0x400]
    // 0x4fce84: StoreField: r0->field_f = r16
    //     0x4fce84: stur            w16, [x0, #0xf]
    // 0x4fce88: r16 = 2
    //     0x4fce88: movz            x16, #0x2
    // 0x4fce8c: str             x16, [SP]
    // 0x4fce90: ldur            x1, [fp, #-8]
    // 0x4fce94: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fce94: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fce98: ldr             x4, [x4, #0x2c0]
    // 0x4fce9c: r0 = efficientSymbolsBoost()
    //     0x4fce9c: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x4fcea0: r0 = DecimalManagement.max2DecimalPlacesRoundDown()
    //     0x4fcea0: bl              #0x4fdbc8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlacesRoundDown
    // 0x4fcea4: ldur            x1, [fp, #-0x20]
    // 0x4fcea8: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fcea8: add             x25, x1, #0x13
    //     0x4fceac: str             w0, [x25]
    //     0x4fceb0: tbz             w0, #0, #0x4fcecc
    //     0x4fceb4: ldurb           w16, [x1, #-1]
    //     0x4fceb8: ldurb           w17, [x0, #-1]
    //     0x4fcebc: and             x16, x17, x16, lsr #2
    //     0x4fcec0: tst             x16, HEAP, lsr #32
    //     0x4fcec4: b.eq            #0x4fcecc
    //     0x4fcec8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fcecc: ldur            x0, [fp, #-0x20]
    // 0x4fced0: r16 = "% for each owned symbol generator."
    //     0x4fced0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] "% for each owned symbol generator."
    //     0x4fced4: ldr             x16, [x16, #0x408]
    // 0x4fced8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fced8: stur            w16, [x0, #0x17]
    // 0x4fcedc: str             x0, [SP]
    // 0x4fcee0: r0 = _interpolate()
    //     0x4fcee0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcee4: r1 = Null
    //     0x4fcee4: mov             x1, NULL
    // 0x4fcee8: r2 = 6
    //     0x4fcee8: movz            x2, #0x6
    // 0x4fceec: stur            x0, [fp, #-0x20]
    // 0x4fcef0: r0 = AllocateArray()
    //     0x4fcef0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcef4: stur            x0, [fp, #-0x28]
    // 0x4fcef8: r16 = "Increases the yield of symbol generators by "
    //     0x4fcef8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15400] "Increases the yield of symbol generators by "
    //     0x4fcefc: ldr             x16, [x16, #0x400]
    // 0x4fcf00: StoreField: r0->field_f = r16
    //     0x4fcf00: stur            w16, [x0, #0xf]
    // 0x4fcf04: r16 = 4
    //     0x4fcf04: movz            x16, #0x4
    // 0x4fcf08: str             x16, [SP]
    // 0x4fcf0c: ldur            x1, [fp, #-8]
    // 0x4fcf10: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcf10: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcf14: ldr             x4, [x4, #0x2c0]
    // 0x4fcf18: r0 = efficientSymbolsBoost()
    //     0x4fcf18: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x4fcf1c: r0 = DecimalManagement.max2DecimalPlacesRoundDown()
    //     0x4fcf1c: bl              #0x4fdbc8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlacesRoundDown
    // 0x4fcf20: ldur            x1, [fp, #-0x28]
    // 0x4fcf24: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fcf24: add             x25, x1, #0x13
    //     0x4fcf28: str             w0, [x25]
    //     0x4fcf2c: tbz             w0, #0, #0x4fcf48
    //     0x4fcf30: ldurb           w16, [x1, #-1]
    //     0x4fcf34: ldurb           w17, [x0, #-1]
    //     0x4fcf38: and             x16, x17, x16, lsr #2
    //     0x4fcf3c: tst             x16, HEAP, lsr #32
    //     0x4fcf40: b.eq            #0x4fcf48
    //     0x4fcf44: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fcf48: ldur            x0, [fp, #-0x28]
    // 0x4fcf4c: r16 = "% for each owned symbol generator."
    //     0x4fcf4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] "% for each owned symbol generator."
    //     0x4fcf50: ldr             x16, [x16, #0x408]
    // 0x4fcf54: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fcf54: stur            w16, [x0, #0x17]
    // 0x4fcf58: str             x0, [SP]
    // 0x4fcf5c: r0 = _interpolate()
    //     0x4fcf5c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcf60: r1 = Null
    //     0x4fcf60: mov             x1, NULL
    // 0x4fcf64: r2 = 6
    //     0x4fcf64: movz            x2, #0x6
    // 0x4fcf68: stur            x0, [fp, #-0x28]
    // 0x4fcf6c: r0 = AllocateArray()
    //     0x4fcf6c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcf70: stur            x0, [fp, #-0x30]
    // 0x4fcf74: r16 = "Increases the yield of symbol generators by "
    //     0x4fcf74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15400] "Increases the yield of symbol generators by "
    //     0x4fcf78: ldr             x16, [x16, #0x400]
    // 0x4fcf7c: StoreField: r0->field_f = r16
    //     0x4fcf7c: stur            w16, [x0, #0xf]
    // 0x4fcf80: r16 = 6
    //     0x4fcf80: movz            x16, #0x6
    // 0x4fcf84: str             x16, [SP]
    // 0x4fcf88: ldur            x1, [fp, #-8]
    // 0x4fcf8c: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fcf8c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fcf90: ldr             x4, [x4, #0x2c0]
    // 0x4fcf94: r0 = efficientSymbolsBoost()
    //     0x4fcf94: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x4fcf98: r0 = DecimalManagement.max2DecimalPlacesRoundDown()
    //     0x4fcf98: bl              #0x4fdbc8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlacesRoundDown
    // 0x4fcf9c: ldur            x1, [fp, #-0x30]
    // 0x4fcfa0: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fcfa0: add             x25, x1, #0x13
    //     0x4fcfa4: str             w0, [x25]
    //     0x4fcfa8: tbz             w0, #0, #0x4fcfc4
    //     0x4fcfac: ldurb           w16, [x1, #-1]
    //     0x4fcfb0: ldurb           w17, [x0, #-1]
    //     0x4fcfb4: and             x16, x17, x16, lsr #2
    //     0x4fcfb8: tst             x16, HEAP, lsr #32
    //     0x4fcfbc: b.eq            #0x4fcfc4
    //     0x4fcfc0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fcfc4: ldur            x0, [fp, #-0x30]
    // 0x4fcfc8: r16 = "% for each owned symbol generator."
    //     0x4fcfc8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] "% for each owned symbol generator."
    //     0x4fcfcc: ldr             x16, [x16, #0x408]
    // 0x4fcfd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fcfd0: stur            w16, [x0, #0x17]
    // 0x4fcfd4: str             x0, [SP]
    // 0x4fcfd8: r0 = _interpolate()
    //     0x4fcfd8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fcfdc: r1 = Null
    //     0x4fcfdc: mov             x1, NULL
    // 0x4fcfe0: r2 = 6
    //     0x4fcfe0: movz            x2, #0x6
    // 0x4fcfe4: stur            x0, [fp, #-0x30]
    // 0x4fcfe8: r0 = AllocateArray()
    //     0x4fcfe8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fcfec: stur            x0, [fp, #-0x38]
    // 0x4fcff0: r16 = "Increases the yield of symbol generators by "
    //     0x4fcff0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15400] "Increases the yield of symbol generators by "
    //     0x4fcff4: ldr             x16, [x16, #0x400]
    // 0x4fcff8: StoreField: r0->field_f = r16
    //     0x4fcff8: stur            w16, [x0, #0xf]
    // 0x4fcffc: r16 = 8
    //     0x4fcffc: movz            x16, #0x8
    // 0x4fd000: str             x16, [SP]
    // 0x4fd004: ldur            x1, [fp, #-8]
    // 0x4fd008: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fd008: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fd00c: ldr             x4, [x4, #0x2c0]
    // 0x4fd010: r0 = efficientSymbolsBoost()
    //     0x4fd010: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x4fd014: r0 = DecimalManagement.max2DecimalPlacesRoundDown()
    //     0x4fd014: bl              #0x4fdbc8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlacesRoundDown
    // 0x4fd018: ldur            x1, [fp, #-0x38]
    // 0x4fd01c: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fd01c: add             x25, x1, #0x13
    //     0x4fd020: str             w0, [x25]
    //     0x4fd024: tbz             w0, #0, #0x4fd040
    //     0x4fd028: ldurb           w16, [x1, #-1]
    //     0x4fd02c: ldurb           w17, [x0, #-1]
    //     0x4fd030: and             x16, x17, x16, lsr #2
    //     0x4fd034: tst             x16, HEAP, lsr #32
    //     0x4fd038: b.eq            #0x4fd040
    //     0x4fd03c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd040: ldur            x0, [fp, #-0x38]
    // 0x4fd044: r16 = "% for each owned symbol generator."
    //     0x4fd044: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] "% for each owned symbol generator."
    //     0x4fd048: ldr             x16, [x16, #0x408]
    // 0x4fd04c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd04c: stur            w16, [x0, #0x17]
    // 0x4fd050: str             x0, [SP]
    // 0x4fd054: r0 = _interpolate()
    //     0x4fd054: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fd058: r1 = Null
    //     0x4fd058: mov             x1, NULL
    // 0x4fd05c: r2 = 6
    //     0x4fd05c: movz            x2, #0x6
    // 0x4fd060: stur            x0, [fp, #-0x38]
    // 0x4fd064: r0 = AllocateArray()
    //     0x4fd064: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd068: stur            x0, [fp, #-0x40]
    // 0x4fd06c: r16 = "Increases the yield of symbol generators by "
    //     0x4fd06c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15400] "Increases the yield of symbol generators by "
    //     0x4fd070: ldr             x16, [x16, #0x400]
    // 0x4fd074: StoreField: r0->field_f = r16
    //     0x4fd074: stur            w16, [x0, #0xf]
    // 0x4fd078: r16 = 10
    //     0x4fd078: movz            x16, #0xa
    // 0x4fd07c: str             x16, [SP]
    // 0x4fd080: ldur            x1, [fp, #-8]
    // 0x4fd084: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fd084: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fd088: ldr             x4, [x4, #0x2c0]
    // 0x4fd08c: r0 = efficientSymbolsBoost()
    //     0x4fd08c: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x4fd090: r0 = DecimalManagement.max2DecimalPlacesRoundDown()
    //     0x4fd090: bl              #0x4fdbc8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlacesRoundDown
    // 0x4fd094: ldur            x1, [fp, #-0x40]
    // 0x4fd098: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fd098: add             x25, x1, #0x13
    //     0x4fd09c: str             w0, [x25]
    //     0x4fd0a0: tbz             w0, #0, #0x4fd0bc
    //     0x4fd0a4: ldurb           w16, [x1, #-1]
    //     0x4fd0a8: ldurb           w17, [x0, #-1]
    //     0x4fd0ac: and             x16, x17, x16, lsr #2
    //     0x4fd0b0: tst             x16, HEAP, lsr #32
    //     0x4fd0b4: b.eq            #0x4fd0bc
    //     0x4fd0b8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd0bc: ldur            x0, [fp, #-0x40]
    // 0x4fd0c0: r16 = "% for each owned symbol generator."
    //     0x4fd0c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] "% for each owned symbol generator."
    //     0x4fd0c4: ldr             x16, [x16, #0x408]
    // 0x4fd0c8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd0c8: stur            w16, [x0, #0x17]
    // 0x4fd0cc: str             x0, [SP]
    // 0x4fd0d0: r0 = _interpolate()
    //     0x4fd0d0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fd0d4: r1 = Null
    //     0x4fd0d4: mov             x1, NULL
    // 0x4fd0d8: r2 = 6
    //     0x4fd0d8: movz            x2, #0x6
    // 0x4fd0dc: stur            x0, [fp, #-0x40]
    // 0x4fd0e0: r0 = AllocateArray()
    //     0x4fd0e0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd0e4: stur            x0, [fp, #-0x48]
    // 0x4fd0e8: r16 = "Increases the yield of symbol generators by "
    //     0x4fd0e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15400] "Increases the yield of symbol generators by "
    //     0x4fd0ec: ldr             x16, [x16, #0x400]
    // 0x4fd0f0: StoreField: r0->field_f = r16
    //     0x4fd0f0: stur            w16, [x0, #0xf]
    // 0x4fd0f4: r16 = 12
    //     0x4fd0f4: movz            x16, #0xc
    // 0x4fd0f8: str             x16, [SP]
    // 0x4fd0fc: ldur            x1, [fp, #-8]
    // 0x4fd100: r4 = const [0, 0x2, 0x1, 0x1, level, 0x1, null]
    //     0x4fd100: add             x4, PP, #0x15, lsl #12  ; [pp+0x152c0] List(7) [0, 0x2, 0x1, 0x1, "level", 0x1, Null]
    //     0x4fd104: ldr             x4, [x4, #0x2c0]
    // 0x4fd108: r0 = efficientSymbolsBoost()
    //     0x4fd108: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x4fd10c: r0 = DecimalManagement.max2DecimalPlacesRoundDown()
    //     0x4fd10c: bl              #0x4fdbc8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.max2DecimalPlacesRoundDown
    // 0x4fd110: ldur            x1, [fp, #-0x48]
    // 0x4fd114: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fd114: add             x25, x1, #0x13
    //     0x4fd118: str             w0, [x25]
    //     0x4fd11c: tbz             w0, #0, #0x4fd138
    //     0x4fd120: ldurb           w16, [x1, #-1]
    //     0x4fd124: ldurb           w17, [x0, #-1]
    //     0x4fd128: and             x16, x17, x16, lsr #2
    //     0x4fd12c: tst             x16, HEAP, lsr #32
    //     0x4fd130: b.eq            #0x4fd138
    //     0x4fd134: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd138: ldur            x0, [fp, #-0x48]
    // 0x4fd13c: r16 = "% for each owned symbol generator."
    //     0x4fd13c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] "% for each owned symbol generator."
    //     0x4fd140: ldr             x16, [x16, #0x408]
    // 0x4fd144: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd144: stur            w16, [x0, #0x17]
    // 0x4fd148: str             x0, [SP]
    // 0x4fd14c: r0 = _interpolate()
    //     0x4fd14c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4fd150: r1 = Null
    //     0x4fd150: mov             x1, NULL
    // 0x4fd154: r2 = 12
    //     0x4fd154: movz            x2, #0xc
    // 0x4fd158: stur            x0, [fp, #-0x48]
    // 0x4fd15c: r0 = AllocateArray()
    //     0x4fd15c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd160: mov             x2, x0
    // 0x4fd164: ldur            x0, [fp, #-0x20]
    // 0x4fd168: stur            x2, [fp, #-0x50]
    // 0x4fd16c: StoreField: r2->field_f = r0
    //     0x4fd16c: stur            w0, [x2, #0xf]
    // 0x4fd170: ldur            x0, [fp, #-0x28]
    // 0x4fd174: StoreField: r2->field_13 = r0
    //     0x4fd174: stur            w0, [x2, #0x13]
    // 0x4fd178: ldur            x0, [fp, #-0x30]
    // 0x4fd17c: ArrayStore: r2[0] = r0  ; List_4
    //     0x4fd17c: stur            w0, [x2, #0x17]
    // 0x4fd180: ldur            x0, [fp, #-0x38]
    // 0x4fd184: StoreField: r2->field_1b = r0
    //     0x4fd184: stur            w0, [x2, #0x1b]
    // 0x4fd188: ldur            x0, [fp, #-0x40]
    // 0x4fd18c: StoreField: r2->field_1f = r0
    //     0x4fd18c: stur            w0, [x2, #0x1f]
    // 0x4fd190: ldur            x0, [fp, #-0x48]
    // 0x4fd194: StoreField: r2->field_23 = r0
    //     0x4fd194: stur            w0, [x2, #0x23]
    // 0x4fd198: r1 = <String>
    //     0x4fd198: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd19c: r0 = AllocateGrowableArray()
    //     0x4fd19c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd1a0: mov             x2, x0
    // 0x4fd1a4: ldur            x0, [fp, #-0x50]
    // 0x4fd1a8: stur            x2, [fp, #-0x20]
    // 0x4fd1ac: StoreField: r2->field_f = r0
    //     0x4fd1ac: stur            w0, [x2, #0xf]
    // 0x4fd1b0: r0 = 12
    //     0x4fd1b0: movz            x0, #0xc
    // 0x4fd1b4: StoreField: r2->field_b = r0
    //     0x4fd1b4: stur            w0, [x2, #0xb]
    // 0x4fd1b8: r1 = <String>
    //     0x4fd1b8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd1bc: r0 = Generator()
    //     0x4fd1bc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd1c0: mov             x3, x0
    // 0x4fd1c4: ldur            x0, [fp, #-0x20]
    // 0x4fd1c8: stur            x3, [fp, #-0x28]
    // 0x4fd1cc: StoreField: r3->field_b = r0
    //     0x4fd1cc: stur            w0, [x3, #0xb]
    // 0x4fd1d0: r1 = Null
    //     0x4fd1d0: mov             x1, NULL
    // 0x4fd1d4: r2 = 12
    //     0x4fd1d4: movz            x2, #0xc
    // 0x4fd1d8: r0 = AllocateArray()
    //     0x4fd1d8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd1dc: stur            x0, [fp, #-0x20]
    // 0x4fd1e0: r16 = Instance_Tuple2
    //     0x4fd1e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15410] Obj!Tuple2<Chapter15Stat, CustomNum>@824431
    //     0x4fd1e4: ldr             x16, [x16, #0x410]
    // 0x4fd1e8: StoreField: r0->field_f = r16
    //     0x4fd1e8: stur            w16, [x0, #0xf]
    // 0x4fd1ec: r16 = Instance_Tuple2
    //     0x4fd1ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15418] Obj!Tuple2<Chapter15Stat, CustomNum>@824411
    //     0x4fd1f0: ldr             x16, [x16, #0x418]
    // 0x4fd1f4: StoreField: r0->field_13 = r16
    //     0x4fd1f4: stur            w16, [x0, #0x13]
    // 0x4fd1f8: r16 = Instance_Tuple2
    //     0x4fd1f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15420] Obj!Tuple2<Chapter15Stat, CustomNum>@8243f1
    //     0x4fd1fc: ldr             x16, [x16, #0x420]
    // 0x4fd200: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd200: stur            w16, [x0, #0x17]
    // 0x4fd204: r16 = Instance_Tuple2
    //     0x4fd204: add             x16, PP, #0x15, lsl #12  ; [pp+0x15428] Obj!Tuple2<Chapter15Stat, CustomNum>@8243d1
    //     0x4fd208: ldr             x16, [x16, #0x428]
    // 0x4fd20c: StoreField: r0->field_1b = r16
    //     0x4fd20c: stur            w16, [x0, #0x1b]
    // 0x4fd210: r16 = Instance_Tuple2
    //     0x4fd210: add             x16, PP, #0x15, lsl #12  ; [pp+0x15430] Obj!Tuple2<Chapter15Stat, CustomNum>@8243b1
    //     0x4fd214: ldr             x16, [x16, #0x430]
    // 0x4fd218: StoreField: r0->field_1f = r16
    //     0x4fd218: stur            w16, [x0, #0x1f]
    // 0x4fd21c: r16 = Instance_Tuple2
    //     0x4fd21c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15438] Obj!Tuple2<Chapter15Stat, CustomNum>@824391
    //     0x4fd220: ldr             x16, [x16, #0x438]
    // 0x4fd224: StoreField: r0->field_23 = r16
    //     0x4fd224: stur            w16, [x0, #0x23]
    // 0x4fd228: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd228: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd22c: ldr             x1, [x1, #0x310]
    // 0x4fd230: r0 = AllocateGrowableArray()
    //     0x4fd230: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd234: mov             x2, x0
    // 0x4fd238: ldur            x0, [fp, #-0x20]
    // 0x4fd23c: stur            x2, [fp, #-0x30]
    // 0x4fd240: StoreField: r2->field_f = r0
    //     0x4fd240: stur            w0, [x2, #0xf]
    // 0x4fd244: r0 = 12
    //     0x4fd244: movz            x0, #0xc
    // 0x4fd248: StoreField: r2->field_b = r0
    //     0x4fd248: stur            w0, [x2, #0xb]
    // 0x4fd24c: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd24c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd250: ldr             x1, [x1, #0x310]
    // 0x4fd254: r0 = Generator()
    //     0x4fd254: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd258: mov             x2, x0
    // 0x4fd25c: ldur            x0, [fp, #-0x30]
    // 0x4fd260: stur            x2, [fp, #-0x20]
    // 0x4fd264: StoreField: r2->field_b = r0
    //     0x4fd264: stur            w0, [x2, #0xb]
    // 0x4fd268: r1 = <Chapter15Stat>
    //     0x4fd268: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fd26c: ldr             x1, [x1, #0xf98]
    // 0x4fd270: r0 = UpgradeData()
    //     0x4fd270: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fd274: mov             x1, x0
    // 0x4fd278: ldur            x0, [fp, #-0x18]
    // 0x4fd27c: StoreField: r1->field_b = r0
    //     0x4fd27c: stur            w0, [x1, #0xb]
    // 0x4fd280: ldur            x0, [fp, #-0x28]
    // 0x4fd284: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fd284: stur            w0, [x1, #0x17]
    // 0x4fd288: r0 = Instance_IconData
    //     0x4fd288: add             x0, PP, #0x15, lsl #12  ; [pp+0x15440] Obj!IconData@8303f1
    //     0x4fd28c: ldr             x0, [x0, #0x440]
    // 0x4fd290: StoreField: r1->field_13 = r0
    //     0x4fd290: stur            w0, [x1, #0x13]
    // 0x4fd294: ldur            x0, [fp, #-0x20]
    // 0x4fd298: StoreField: r1->field_f = r0
    //     0x4fd298: stur            w0, [x1, #0xf]
    // 0x4fd29c: mov             x0, x1
    // 0x4fd2a0: ldur            x1, [fp, #-0x10]
    // 0x4fd2a4: ArrayStore: r1[9] = r0  ; List_4
    //     0x4fd2a4: add             x25, x1, #0x33
    //     0x4fd2a8: str             w0, [x25]
    //     0x4fd2ac: tbz             w0, #0, #0x4fd2c8
    //     0x4fd2b0: ldurb           w16, [x1, #-1]
    //     0x4fd2b4: ldurb           w17, [x0, #-1]
    //     0x4fd2b8: and             x16, x17, x16, lsr #2
    //     0x4fd2bc: tst             x16, HEAP, lsr #32
    //     0x4fd2c0: b.eq            #0x4fd2c8
    //     0x4fd2c4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd2c8: ldur            x0, [fp, #-0x10]
    // 0x4fd2cc: r16 = 26
    //     0x4fd2cc: movz            x16, #0x1a
    // 0x4fd2d0: StoreField: r0->field_37 = r16
    //     0x4fd2d0: stur            w16, [x0, #0x37]
    // 0x4fd2d4: r1 = "Syscall Vector"
    //     0x4fd2d4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15448] "Syscall Vector"
    //     0x4fd2d8: ldr             x1, [x1, #0x448]
    // 0x4fd2dc: r0 = autoString()
    //     0x4fd2dc: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fd2e0: r1 = Null
    //     0x4fd2e0: mov             x1, NULL
    // 0x4fd2e4: r2 = 12
    //     0x4fd2e4: movz            x2, #0xc
    // 0x4fd2e8: stur            x0, [fp, #-0x18]
    // 0x4fd2ec: r0 = AllocateArray()
    //     0x4fd2ec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd2f0: stur            x0, [fp, #-0x20]
    // 0x4fd2f4: r16 = "Reduces all costs by 99%."
    //     0x4fd2f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15450] "Reduces all costs by 99%."
    //     0x4fd2f8: ldr             x16, [x16, #0x450]
    // 0x4fd2fc: StoreField: r0->field_f = r16
    //     0x4fd2fc: stur            w16, [x0, #0xf]
    // 0x4fd300: r16 = "Reduces all costs by another 99%."
    //     0x4fd300: add             x16, PP, #0x15, lsl #12  ; [pp+0x15458] "Reduces all costs by another 99%."
    //     0x4fd304: ldr             x16, [x16, #0x458]
    // 0x4fd308: StoreField: r0->field_13 = r16
    //     0x4fd308: stur            w16, [x0, #0x13]
    // 0x4fd30c: r16 = "Reduces all costs by another 99%."
    //     0x4fd30c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15458] "Reduces all costs by another 99%."
    //     0x4fd310: ldr             x16, [x16, #0x458]
    // 0x4fd314: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd314: stur            w16, [x0, #0x17]
    // 0x4fd318: r16 = "Reduces all costs by another 99%."
    //     0x4fd318: add             x16, PP, #0x15, lsl #12  ; [pp+0x15458] "Reduces all costs by another 99%."
    //     0x4fd31c: ldr             x16, [x16, #0x458]
    // 0x4fd320: StoreField: r0->field_1b = r16
    //     0x4fd320: stur            w16, [x0, #0x1b]
    // 0x4fd324: r16 = "Reduces all costs by another 99%."
    //     0x4fd324: add             x16, PP, #0x15, lsl #12  ; [pp+0x15458] "Reduces all costs by another 99%."
    //     0x4fd328: ldr             x16, [x16, #0x458]
    // 0x4fd32c: StoreField: r0->field_1f = r16
    //     0x4fd32c: stur            w16, [x0, #0x1f]
    // 0x4fd330: r16 = "Reduces all costs by another 99%."
    //     0x4fd330: add             x16, PP, #0x15, lsl #12  ; [pp+0x15458] "Reduces all costs by another 99%."
    //     0x4fd334: ldr             x16, [x16, #0x458]
    // 0x4fd338: StoreField: r0->field_23 = r16
    //     0x4fd338: stur            w16, [x0, #0x23]
    // 0x4fd33c: r1 = <String>
    //     0x4fd33c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd340: r0 = AllocateGrowableArray()
    //     0x4fd340: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd344: mov             x2, x0
    // 0x4fd348: ldur            x0, [fp, #-0x20]
    // 0x4fd34c: stur            x2, [fp, #-0x28]
    // 0x4fd350: StoreField: r2->field_f = r0
    //     0x4fd350: stur            w0, [x2, #0xf]
    // 0x4fd354: r0 = 12
    //     0x4fd354: movz            x0, #0xc
    // 0x4fd358: StoreField: r2->field_b = r0
    //     0x4fd358: stur            w0, [x2, #0xb]
    // 0x4fd35c: r1 = <String>
    //     0x4fd35c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd360: r0 = Generator()
    //     0x4fd360: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd364: mov             x3, x0
    // 0x4fd368: ldur            x0, [fp, #-0x28]
    // 0x4fd36c: stur            x3, [fp, #-0x20]
    // 0x4fd370: StoreField: r3->field_b = r0
    //     0x4fd370: stur            w0, [x3, #0xb]
    // 0x4fd374: r1 = Null
    //     0x4fd374: mov             x1, NULL
    // 0x4fd378: r2 = 12
    //     0x4fd378: movz            x2, #0xc
    // 0x4fd37c: r0 = AllocateArray()
    //     0x4fd37c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd380: stur            x0, [fp, #-0x28]
    // 0x4fd384: r16 = Instance_Tuple2
    //     0x4fd384: add             x16, PP, #0x15, lsl #12  ; [pp+0x15460] Obj!Tuple2<Chapter15Stat, CustomNum>@824371
    //     0x4fd388: ldr             x16, [x16, #0x460]
    // 0x4fd38c: StoreField: r0->field_f = r16
    //     0x4fd38c: stur            w16, [x0, #0xf]
    // 0x4fd390: r16 = Instance_Tuple2
    //     0x4fd390: add             x16, PP, #0x15, lsl #12  ; [pp+0x15468] Obj!Tuple2<Chapter15Stat, CustomNum>@824351
    //     0x4fd394: ldr             x16, [x16, #0x468]
    // 0x4fd398: StoreField: r0->field_13 = r16
    //     0x4fd398: stur            w16, [x0, #0x13]
    // 0x4fd39c: r16 = Instance_Tuple2
    //     0x4fd39c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15470] Obj!Tuple2<Chapter15Stat, CustomNum>@824331
    //     0x4fd3a0: ldr             x16, [x16, #0x470]
    // 0x4fd3a4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd3a4: stur            w16, [x0, #0x17]
    // 0x4fd3a8: r16 = Instance_Tuple2
    //     0x4fd3a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15478] Obj!Tuple2<Chapter15Stat, CustomNum>@824311
    //     0x4fd3ac: ldr             x16, [x16, #0x478]
    // 0x4fd3b0: StoreField: r0->field_1b = r16
    //     0x4fd3b0: stur            w16, [x0, #0x1b]
    // 0x4fd3b4: r16 = Instance_Tuple2
    //     0x4fd3b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15480] Obj!Tuple2<Chapter15Stat, CustomNum>@8242f1
    //     0x4fd3b8: ldr             x16, [x16, #0x480]
    // 0x4fd3bc: StoreField: r0->field_1f = r16
    //     0x4fd3bc: stur            w16, [x0, #0x1f]
    // 0x4fd3c0: r16 = Instance_Tuple2
    //     0x4fd3c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15488] Obj!Tuple2<Chapter15Stat, CustomNum>@8242d1
    //     0x4fd3c4: ldr             x16, [x16, #0x488]
    // 0x4fd3c8: StoreField: r0->field_23 = r16
    //     0x4fd3c8: stur            w16, [x0, #0x23]
    // 0x4fd3cc: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd3cc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd3d0: ldr             x1, [x1, #0x310]
    // 0x4fd3d4: r0 = AllocateGrowableArray()
    //     0x4fd3d4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd3d8: mov             x2, x0
    // 0x4fd3dc: ldur            x0, [fp, #-0x28]
    // 0x4fd3e0: stur            x2, [fp, #-0x30]
    // 0x4fd3e4: StoreField: r2->field_f = r0
    //     0x4fd3e4: stur            w0, [x2, #0xf]
    // 0x4fd3e8: r0 = 12
    //     0x4fd3e8: movz            x0, #0xc
    // 0x4fd3ec: StoreField: r2->field_b = r0
    //     0x4fd3ec: stur            w0, [x2, #0xb]
    // 0x4fd3f0: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd3f0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd3f4: ldr             x1, [x1, #0x310]
    // 0x4fd3f8: r0 = Generator()
    //     0x4fd3f8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd3fc: mov             x2, x0
    // 0x4fd400: ldur            x0, [fp, #-0x30]
    // 0x4fd404: stur            x2, [fp, #-0x28]
    // 0x4fd408: StoreField: r2->field_b = r0
    //     0x4fd408: stur            w0, [x2, #0xb]
    // 0x4fd40c: r1 = <Chapter15Stat>
    //     0x4fd40c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fd410: ldr             x1, [x1, #0xf98]
    // 0x4fd414: r0 = UpgradeData()
    //     0x4fd414: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fd418: mov             x1, x0
    // 0x4fd41c: ldur            x0, [fp, #-0x18]
    // 0x4fd420: StoreField: r1->field_b = r0
    //     0x4fd420: stur            w0, [x1, #0xb]
    // 0x4fd424: ldur            x0, [fp, #-0x20]
    // 0x4fd428: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fd428: stur            w0, [x1, #0x17]
    // 0x4fd42c: r0 = Instance_IconData
    //     0x4fd42c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15490] Obj!IconData@8303d1
    //     0x4fd430: ldr             x0, [x0, #0x490]
    // 0x4fd434: StoreField: r1->field_13 = r0
    //     0x4fd434: stur            w0, [x1, #0x13]
    // 0x4fd438: ldur            x0, [fp, #-0x28]
    // 0x4fd43c: StoreField: r1->field_f = r0
    //     0x4fd43c: stur            w0, [x1, #0xf]
    // 0x4fd440: mov             x0, x1
    // 0x4fd444: ldur            x1, [fp, #-0x10]
    // 0x4fd448: ArrayStore: r1[11] = r0  ; List_4
    //     0x4fd448: add             x25, x1, #0x3b
    //     0x4fd44c: str             w0, [x25]
    //     0x4fd450: tbz             w0, #0, #0x4fd46c
    //     0x4fd454: ldurb           w16, [x1, #-1]
    //     0x4fd458: ldurb           w17, [x0, #-1]
    //     0x4fd45c: and             x16, x17, x16, lsr #2
    //     0x4fd460: tst             x16, HEAP, lsr #32
    //     0x4fd464: b.eq            #0x4fd46c
    //     0x4fd468: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd46c: ldur            x0, [fp, #-0x10]
    // 0x4fd470: r16 = 28
    //     0x4fd470: movz            x16, #0x1c
    // 0x4fd474: StoreField: r0->field_3f = r16
    //     0x4fd474: stur            w16, [x0, #0x3f]
    // 0x4fd478: r1 = "Automated Development"
    //     0x4fd478: add             x1, PP, #0x15, lsl #12  ; [pp+0x15498] "Automated Development"
    //     0x4fd47c: ldr             x1, [x1, #0x498]
    // 0x4fd480: r0 = autoString()
    //     0x4fd480: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fd484: r1 = Null
    //     0x4fd484: mov             x1, NULL
    // 0x4fd488: r2 = 10
    //     0x4fd488: movz            x2, #0xa
    // 0x4fd48c: stur            x0, [fp, #-0x18]
    // 0x4fd490: r0 = AllocateArray()
    //     0x4fd490: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd494: stur            x0, [fp, #-0x20]
    // 0x4fd498: r16 = "Automatically gain a boost equivelant to generating a small number of symbols every second."
    //     0x4fd498: add             x16, PP, #0x15, lsl #12  ; [pp+0x154a0] "Automatically gain a boost equivelant to generating a small number of symbols every second."
    //     0x4fd49c: ldr             x16, [x16, #0x4a0]
    // 0x4fd4a0: StoreField: r0->field_f = r16
    //     0x4fd4a0: stur            w16, [x0, #0xf]
    // 0x4fd4a4: r16 = "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x154a8] "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4a8: ldr             x16, [x16, #0x4a8]
    // 0x4fd4ac: StoreField: r0->field_13 = r16
    //     0x4fd4ac: stur            w16, [x0, #0x13]
    // 0x4fd4b0: r16 = "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x154a8] "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4b4: ldr             x16, [x16, #0x4a8]
    // 0x4fd4b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd4b8: stur            w16, [x0, #0x17]
    // 0x4fd4bc: r16 = "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x154a8] "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4c0: ldr             x16, [x16, #0x4a8]
    // 0x4fd4c4: StoreField: r0->field_1b = r16
    //     0x4fd4c4: stur            w16, [x0, #0x1b]
    // 0x4fd4c8: r16 = "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x154a8] "Gain a boost equivelant to generating a slightly larger number of symbols every second."
    //     0x4fd4cc: ldr             x16, [x16, #0x4a8]
    // 0x4fd4d0: StoreField: r0->field_1f = r16
    //     0x4fd4d0: stur            w16, [x0, #0x1f]
    // 0x4fd4d4: r1 = <String>
    //     0x4fd4d4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd4d8: r0 = AllocateGrowableArray()
    //     0x4fd4d8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd4dc: mov             x2, x0
    // 0x4fd4e0: ldur            x0, [fp, #-0x20]
    // 0x4fd4e4: stur            x2, [fp, #-0x28]
    // 0x4fd4e8: StoreField: r2->field_f = r0
    //     0x4fd4e8: stur            w0, [x2, #0xf]
    // 0x4fd4ec: r0 = 10
    //     0x4fd4ec: movz            x0, #0xa
    // 0x4fd4f0: StoreField: r2->field_b = r0
    //     0x4fd4f0: stur            w0, [x2, #0xb]
    // 0x4fd4f4: r1 = <String>
    //     0x4fd4f4: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd4f8: r0 = Generator()
    //     0x4fd4f8: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd4fc: mov             x3, x0
    // 0x4fd500: ldur            x0, [fp, #-0x28]
    // 0x4fd504: stur            x3, [fp, #-0x20]
    // 0x4fd508: StoreField: r3->field_b = r0
    //     0x4fd508: stur            w0, [x3, #0xb]
    // 0x4fd50c: r1 = Null
    //     0x4fd50c: mov             x1, NULL
    // 0x4fd510: r2 = 10
    //     0x4fd510: movz            x2, #0xa
    // 0x4fd514: r0 = AllocateArray()
    //     0x4fd514: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd518: stur            x0, [fp, #-0x28]
    // 0x4fd51c: r16 = Instance_Tuple2
    //     0x4fd51c: add             x16, PP, #0x15, lsl #12  ; [pp+0x152e0] Obj!Tuple2<Chapter15Stat, CustomNum>@824711
    //     0x4fd520: ldr             x16, [x16, #0x2e0]
    // 0x4fd524: StoreField: r0->field_f = r16
    //     0x4fd524: stur            w16, [x0, #0xf]
    // 0x4fd528: r16 = Instance_Tuple2
    //     0x4fd528: add             x16, PP, #0x15, lsl #12  ; [pp+0x154b0] Obj!Tuple2<Chapter15Stat, CustomNum>@8242b1
    //     0x4fd52c: ldr             x16, [x16, #0x4b0]
    // 0x4fd530: StoreField: r0->field_13 = r16
    //     0x4fd530: stur            w16, [x0, #0x13]
    // 0x4fd534: r16 = Instance_Tuple2
    //     0x4fd534: add             x16, PP, #0x15, lsl #12  ; [pp+0x154b8] Obj!Tuple2<Chapter15Stat, CustomNum>@824291
    //     0x4fd538: ldr             x16, [x16, #0x4b8]
    // 0x4fd53c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd53c: stur            w16, [x0, #0x17]
    // 0x4fd540: r16 = Instance_Tuple2
    //     0x4fd540: add             x16, PP, #0x15, lsl #12  ; [pp+0x154c0] Obj!Tuple2<Chapter15Stat, CustomNum>@824271
    //     0x4fd544: ldr             x16, [x16, #0x4c0]
    // 0x4fd548: StoreField: r0->field_1b = r16
    //     0x4fd548: stur            w16, [x0, #0x1b]
    // 0x4fd54c: r16 = Instance_Tuple2
    //     0x4fd54c: add             x16, PP, #0x15, lsl #12  ; [pp+0x154c8] Obj!Tuple2<Chapter15Stat, CustomNum>@824251
    //     0x4fd550: ldr             x16, [x16, #0x4c8]
    // 0x4fd554: StoreField: r0->field_1f = r16
    //     0x4fd554: stur            w16, [x0, #0x1f]
    // 0x4fd558: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd558: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd55c: ldr             x1, [x1, #0x310]
    // 0x4fd560: r0 = AllocateGrowableArray()
    //     0x4fd560: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd564: mov             x2, x0
    // 0x4fd568: ldur            x0, [fp, #-0x28]
    // 0x4fd56c: stur            x2, [fp, #-0x30]
    // 0x4fd570: StoreField: r2->field_f = r0
    //     0x4fd570: stur            w0, [x2, #0xf]
    // 0x4fd574: r0 = 10
    //     0x4fd574: movz            x0, #0xa
    // 0x4fd578: StoreField: r2->field_b = r0
    //     0x4fd578: stur            w0, [x2, #0xb]
    // 0x4fd57c: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd57c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd580: ldr             x1, [x1, #0x310]
    // 0x4fd584: r0 = Generator()
    //     0x4fd584: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd588: mov             x2, x0
    // 0x4fd58c: ldur            x0, [fp, #-0x30]
    // 0x4fd590: stur            x2, [fp, #-0x28]
    // 0x4fd594: StoreField: r2->field_b = r0
    //     0x4fd594: stur            w0, [x2, #0xb]
    // 0x4fd598: r1 = <Chapter15Stat>
    //     0x4fd598: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fd59c: ldr             x1, [x1, #0xf98]
    // 0x4fd5a0: r0 = UpgradeData()
    //     0x4fd5a0: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fd5a4: mov             x1, x0
    // 0x4fd5a8: ldur            x0, [fp, #-0x18]
    // 0x4fd5ac: StoreField: r1->field_b = r0
    //     0x4fd5ac: stur            w0, [x1, #0xb]
    // 0x4fd5b0: ldur            x0, [fp, #-0x20]
    // 0x4fd5b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fd5b4: stur            w0, [x1, #0x17]
    // 0x4fd5b8: r0 = Instance_IconData
    //     0x4fd5b8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14ce8] Obj!IconData@82fa51
    //     0x4fd5bc: ldr             x0, [x0, #0xce8]
    // 0x4fd5c0: StoreField: r1->field_13 = r0
    //     0x4fd5c0: stur            w0, [x1, #0x13]
    // 0x4fd5c4: ldur            x0, [fp, #-0x28]
    // 0x4fd5c8: StoreField: r1->field_f = r0
    //     0x4fd5c8: stur            w0, [x1, #0xf]
    // 0x4fd5cc: mov             x0, x1
    // 0x4fd5d0: ldur            x1, [fp, #-0x10]
    // 0x4fd5d4: ArrayStore: r1[13] = r0  ; List_4
    //     0x4fd5d4: add             x25, x1, #0x43
    //     0x4fd5d8: str             w0, [x25]
    //     0x4fd5dc: tbz             w0, #0, #0x4fd5f8
    //     0x4fd5e0: ldurb           w16, [x1, #-1]
    //     0x4fd5e4: ldurb           w17, [x0, #-1]
    //     0x4fd5e8: and             x16, x17, x16, lsr #2
    //     0x4fd5ec: tst             x16, HEAP, lsr #32
    //     0x4fd5f0: b.eq            #0x4fd5f8
    //     0x4fd5f4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd5f8: ldur            x0, [fp, #-0x10]
    // 0x4fd5fc: r16 = 202
    //     0x4fd5fc: movz            x16, #0xca
    // 0x4fd600: StoreField: r0->field_47 = r16
    //     0x4fd600: stur            w16, [x0, #0x47]
    // 0x4fd604: r1 = "Skilled Developer"
    //     0x4fd604: add             x1, PP, #0x15, lsl #12  ; [pp+0x154d0] "Skilled Developer"
    //     0x4fd608: ldr             x1, [x1, #0x4d0]
    // 0x4fd60c: r0 = autoString()
    //     0x4fd60c: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fd610: r1 = Null
    //     0x4fd610: mov             x1, NULL
    // 0x4fd614: r2 = 6
    //     0x4fd614: movz            x2, #0x6
    // 0x4fd618: stur            x0, [fp, #-0x18]
    // 0x4fd61c: r0 = AllocateArray()
    //     0x4fd61c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd620: stur            x0, [fp, #-0x20]
    // 0x4fd624: r16 = "Upon prestige all symbol upgrades restart at level 1."
    //     0x4fd624: add             x16, PP, #0x15, lsl #12  ; [pp+0x154d8] "Upon prestige all symbol upgrades restart at level 1."
    //     0x4fd628: ldr             x16, [x16, #0x4d8]
    // 0x4fd62c: StoreField: r0->field_f = r16
    //     0x4fd62c: stur            w16, [x0, #0xf]
    // 0x4fd630: r16 = "Upon prestige all symbol upgrades restart at level 2."
    //     0x4fd630: add             x16, PP, #0x15, lsl #12  ; [pp+0x154e0] "Upon prestige all symbol upgrades restart at level 2."
    //     0x4fd634: ldr             x16, [x16, #0x4e0]
    // 0x4fd638: StoreField: r0->field_13 = r16
    //     0x4fd638: stur            w16, [x0, #0x13]
    // 0x4fd63c: r16 = "Upon prestige all symbol upgrades restart at level 3."
    //     0x4fd63c: add             x16, PP, #0x15, lsl #12  ; [pp+0x154e8] "Upon prestige all symbol upgrades restart at level 3."
    //     0x4fd640: ldr             x16, [x16, #0x4e8]
    // 0x4fd644: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd644: stur            w16, [x0, #0x17]
    // 0x4fd648: r1 = <String>
    //     0x4fd648: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd64c: r0 = AllocateGrowableArray()
    //     0x4fd64c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd650: mov             x2, x0
    // 0x4fd654: ldur            x0, [fp, #-0x20]
    // 0x4fd658: stur            x2, [fp, #-0x28]
    // 0x4fd65c: StoreField: r2->field_f = r0
    //     0x4fd65c: stur            w0, [x2, #0xf]
    // 0x4fd660: r0 = 6
    //     0x4fd660: movz            x0, #0x6
    // 0x4fd664: StoreField: r2->field_b = r0
    //     0x4fd664: stur            w0, [x2, #0xb]
    // 0x4fd668: r1 = <String>
    //     0x4fd668: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd66c: r0 = Generator()
    //     0x4fd66c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd670: mov             x3, x0
    // 0x4fd674: ldur            x0, [fp, #-0x28]
    // 0x4fd678: stur            x3, [fp, #-0x20]
    // 0x4fd67c: StoreField: r3->field_b = r0
    //     0x4fd67c: stur            w0, [x3, #0xb]
    // 0x4fd680: r1 = Null
    //     0x4fd680: mov             x1, NULL
    // 0x4fd684: r2 = 6
    //     0x4fd684: movz            x2, #0x6
    // 0x4fd688: r0 = AllocateArray()
    //     0x4fd688: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd68c: stur            x0, [fp, #-0x28]
    // 0x4fd690: r16 = Instance_Tuple2
    //     0x4fd690: add             x16, PP, #0x15, lsl #12  ; [pp+0x154f0] Obj!Tuple2<Chapter15Stat, CustomNum>@824231
    //     0x4fd694: ldr             x16, [x16, #0x4f0]
    // 0x4fd698: StoreField: r0->field_f = r16
    //     0x4fd698: stur            w16, [x0, #0xf]
    // 0x4fd69c: r16 = Instance_Tuple2
    //     0x4fd69c: add             x16, PP, #0x15, lsl #12  ; [pp+0x154f8] Obj!Tuple2<Chapter15Stat, CustomNum>@824211
    //     0x4fd6a0: ldr             x16, [x16, #0x4f8]
    // 0x4fd6a4: StoreField: r0->field_13 = r16
    //     0x4fd6a4: stur            w16, [x0, #0x13]
    // 0x4fd6a8: r16 = Instance_Tuple2
    //     0x4fd6a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15500] Obj!Tuple2<Chapter15Stat, CustomNum>@8241f1
    //     0x4fd6ac: ldr             x16, [x16, #0x500]
    // 0x4fd6b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd6b0: stur            w16, [x0, #0x17]
    // 0x4fd6b4: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd6b4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd6b8: ldr             x1, [x1, #0x310]
    // 0x4fd6bc: r0 = AllocateGrowableArray()
    //     0x4fd6bc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd6c0: mov             x2, x0
    // 0x4fd6c4: ldur            x0, [fp, #-0x28]
    // 0x4fd6c8: stur            x2, [fp, #-0x30]
    // 0x4fd6cc: StoreField: r2->field_f = r0
    //     0x4fd6cc: stur            w0, [x2, #0xf]
    // 0x4fd6d0: r0 = 6
    //     0x4fd6d0: movz            x0, #0x6
    // 0x4fd6d4: StoreField: r2->field_b = r0
    //     0x4fd6d4: stur            w0, [x2, #0xb]
    // 0x4fd6d8: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd6d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd6dc: ldr             x1, [x1, #0x310]
    // 0x4fd6e0: r0 = Generator()
    //     0x4fd6e0: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd6e4: mov             x2, x0
    // 0x4fd6e8: ldur            x0, [fp, #-0x30]
    // 0x4fd6ec: stur            x2, [fp, #-0x28]
    // 0x4fd6f0: StoreField: r2->field_b = r0
    //     0x4fd6f0: stur            w0, [x2, #0xb]
    // 0x4fd6f4: r1 = <Chapter15Stat>
    //     0x4fd6f4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fd6f8: ldr             x1, [x1, #0xf98]
    // 0x4fd6fc: r0 = UpgradeData()
    //     0x4fd6fc: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fd700: mov             x1, x0
    // 0x4fd704: ldur            x0, [fp, #-0x18]
    // 0x4fd708: StoreField: r1->field_b = r0
    //     0x4fd708: stur            w0, [x1, #0xb]
    // 0x4fd70c: ldur            x0, [fp, #-0x20]
    // 0x4fd710: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fd710: stur            w0, [x1, #0x17]
    // 0x4fd714: r0 = Instance_IconData
    //     0x4fd714: add             x0, PP, #0x15, lsl #12  ; [pp+0x15508] Obj!IconData@8303b1
    //     0x4fd718: ldr             x0, [x0, #0x508]
    // 0x4fd71c: StoreField: r1->field_13 = r0
    //     0x4fd71c: stur            w0, [x1, #0x13]
    // 0x4fd720: ldur            x0, [fp, #-0x28]
    // 0x4fd724: StoreField: r1->field_f = r0
    //     0x4fd724: stur            w0, [x1, #0xf]
    // 0x4fd728: mov             x0, x1
    // 0x4fd72c: ldur            x1, [fp, #-0x10]
    // 0x4fd730: ArrayStore: r1[15] = r0  ; List_4
    //     0x4fd730: add             x25, x1, #0x4b
    //     0x4fd734: str             w0, [x25]
    //     0x4fd738: tbz             w0, #0, #0x4fd754
    //     0x4fd73c: ldurb           w16, [x1, #-1]
    //     0x4fd740: ldurb           w17, [x0, #-1]
    //     0x4fd744: and             x16, x17, x16, lsr #2
    //     0x4fd748: tst             x16, HEAP, lsr #32
    //     0x4fd74c: b.eq            #0x4fd754
    //     0x4fd750: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd754: ldur            x0, [fp, #-0x10]
    // 0x4fd758: r16 = 204
    //     0x4fd758: movz            x16, #0xcc
    // 0x4fd75c: StoreField: r0->field_4f = r16
    //     0x4fd75c: stur            w16, [x0, #0x4f]
    // 0x4fd760: r1 = "Advanced Education"
    //     0x4fd760: add             x1, PP, #0x15, lsl #12  ; [pp+0x15510] "Advanced Education"
    //     0x4fd764: ldr             x1, [x1, #0x510]
    // 0x4fd768: r0 = autoString()
    //     0x4fd768: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fd76c: r1 = Null
    //     0x4fd76c: mov             x1, NULL
    // 0x4fd770: r2 = 4
    //     0x4fd770: movz            x2, #0x4
    // 0x4fd774: stur            x0, [fp, #-0x18]
    // 0x4fd778: r0 = AllocateArray()
    //     0x4fd778: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd77c: stur            x0, [fp, #-0x20]
    // 0x4fd780: r16 = "Increases the power of most symbol upgrades slightly."
    //     0x4fd780: add             x16, PP, #0x15, lsl #12  ; [pp+0x15518] "Increases the power of most symbol upgrades slightly."
    //     0x4fd784: ldr             x16, [x16, #0x518]
    // 0x4fd788: StoreField: r0->field_f = r16
    //     0x4fd788: stur            w16, [x0, #0xf]
    // 0x4fd78c: r16 = "Increases the power of most symbol upgrades a little more."
    //     0x4fd78c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15520] "Increases the power of most symbol upgrades a little more."
    //     0x4fd790: ldr             x16, [x16, #0x520]
    // 0x4fd794: StoreField: r0->field_13 = r16
    //     0x4fd794: stur            w16, [x0, #0x13]
    // 0x4fd798: r1 = <String>
    //     0x4fd798: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd79c: r0 = AllocateGrowableArray()
    //     0x4fd79c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd7a0: mov             x2, x0
    // 0x4fd7a4: ldur            x0, [fp, #-0x20]
    // 0x4fd7a8: stur            x2, [fp, #-0x28]
    // 0x4fd7ac: StoreField: r2->field_f = r0
    //     0x4fd7ac: stur            w0, [x2, #0xf]
    // 0x4fd7b0: r0 = 4
    //     0x4fd7b0: movz            x0, #0x4
    // 0x4fd7b4: StoreField: r2->field_b = r0
    //     0x4fd7b4: stur            w0, [x2, #0xb]
    // 0x4fd7b8: r1 = <String>
    //     0x4fd7b8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd7bc: r0 = Generator()
    //     0x4fd7bc: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd7c0: mov             x3, x0
    // 0x4fd7c4: ldur            x0, [fp, #-0x28]
    // 0x4fd7c8: stur            x3, [fp, #-0x20]
    // 0x4fd7cc: StoreField: r3->field_b = r0
    //     0x4fd7cc: stur            w0, [x3, #0xb]
    // 0x4fd7d0: r1 = Null
    //     0x4fd7d0: mov             x1, NULL
    // 0x4fd7d4: r2 = 4
    //     0x4fd7d4: movz            x2, #0x4
    // 0x4fd7d8: r0 = AllocateArray()
    //     0x4fd7d8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd7dc: stur            x0, [fp, #-0x28]
    // 0x4fd7e0: r16 = Instance_Tuple2
    //     0x4fd7e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15528] Obj!Tuple2<Chapter15Stat, CustomNum>@8241d1
    //     0x4fd7e4: ldr             x16, [x16, #0x528]
    // 0x4fd7e8: StoreField: r0->field_f = r16
    //     0x4fd7e8: stur            w16, [x0, #0xf]
    // 0x4fd7ec: r16 = Instance_Tuple2
    //     0x4fd7ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15530] Obj!Tuple2<Chapter15Stat, CustomNum>@8241b1
    //     0x4fd7f0: ldr             x16, [x16, #0x530]
    // 0x4fd7f4: StoreField: r0->field_13 = r16
    //     0x4fd7f4: stur            w16, [x0, #0x13]
    // 0x4fd7f8: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd7f8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd7fc: ldr             x1, [x1, #0x310]
    // 0x4fd800: r0 = AllocateGrowableArray()
    //     0x4fd800: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd804: mov             x2, x0
    // 0x4fd808: ldur            x0, [fp, #-0x28]
    // 0x4fd80c: stur            x2, [fp, #-0x30]
    // 0x4fd810: StoreField: r2->field_f = r0
    //     0x4fd810: stur            w0, [x2, #0xf]
    // 0x4fd814: r0 = 4
    //     0x4fd814: movz            x0, #0x4
    // 0x4fd818: StoreField: r2->field_b = r0
    //     0x4fd818: stur            w0, [x2, #0xb]
    // 0x4fd81c: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd81c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd820: ldr             x1, [x1, #0x310]
    // 0x4fd824: r0 = Generator()
    //     0x4fd824: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd828: mov             x2, x0
    // 0x4fd82c: ldur            x0, [fp, #-0x30]
    // 0x4fd830: stur            x2, [fp, #-0x28]
    // 0x4fd834: StoreField: r2->field_b = r0
    //     0x4fd834: stur            w0, [x2, #0xb]
    // 0x4fd838: r1 = <Chapter15Stat>
    //     0x4fd838: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fd83c: ldr             x1, [x1, #0xf98]
    // 0x4fd840: r0 = UpgradeData()
    //     0x4fd840: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fd844: mov             x1, x0
    // 0x4fd848: ldur            x0, [fp, #-0x18]
    // 0x4fd84c: StoreField: r1->field_b = r0
    //     0x4fd84c: stur            w0, [x1, #0xb]
    // 0x4fd850: ldur            x0, [fp, #-0x20]
    // 0x4fd854: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fd854: stur            w0, [x1, #0x17]
    // 0x4fd858: r0 = Instance_IconData
    //     0x4fd858: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f18] Obj!IconData@82f8d1
    //     0x4fd85c: ldr             x0, [x0, #0xf18]
    // 0x4fd860: StoreField: r1->field_13 = r0
    //     0x4fd860: stur            w0, [x1, #0x13]
    // 0x4fd864: ldur            x0, [fp, #-0x28]
    // 0x4fd868: StoreField: r1->field_f = r0
    //     0x4fd868: stur            w0, [x1, #0xf]
    // 0x4fd86c: mov             x0, x1
    // 0x4fd870: ldur            x1, [fp, #-0x10]
    // 0x4fd874: ArrayStore: r1[17] = r0  ; List_4
    //     0x4fd874: add             x25, x1, #0x53
    //     0x4fd878: str             w0, [x25]
    //     0x4fd87c: tbz             w0, #0, #0x4fd898
    //     0x4fd880: ldurb           w16, [x1, #-1]
    //     0x4fd884: ldurb           w17, [x0, #-1]
    //     0x4fd888: and             x16, x17, x16, lsr #2
    //     0x4fd88c: tst             x16, HEAP, lsr #32
    //     0x4fd890: b.eq            #0x4fd898
    //     0x4fd894: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd898: ldur            x0, [fp, #-0x10]
    // 0x4fd89c: r16 = 206
    //     0x4fd89c: movz            x16, #0xce
    // 0x4fd8a0: StoreField: r0->field_57 = r16
    //     0x4fd8a0: stur            w16, [x0, #0x57]
    // 0x4fd8a4: r1 = "Public Relations"
    //     0x4fd8a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15538] "Public Relations"
    //     0x4fd8a8: ldr             x1, [x1, #0x538]
    // 0x4fd8ac: r0 = autoString()
    //     0x4fd8ac: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fd8b0: r1 = Null
    //     0x4fd8b0: mov             x1, NULL
    // 0x4fd8b4: r2 = 6
    //     0x4fd8b4: movz            x2, #0x6
    // 0x4fd8b8: stur            x0, [fp, #-0x18]
    // 0x4fd8bc: r0 = AllocateArray()
    //     0x4fd8bc: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd8c0: stur            x0, [fp, #-0x20]
    // 0x4fd8c4: r16 = "10x pull requests"
    //     0x4fd8c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15540] "10x pull requests"
    //     0x4fd8c8: ldr             x16, [x16, #0x540]
    // 0x4fd8cc: StoreField: r0->field_f = r16
    //     0x4fd8cc: stur            w16, [x0, #0xf]
    // 0x4fd8d0: r16 = "Another 10x pull requests"
    //     0x4fd8d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15548] "Another 10x pull requests"
    //     0x4fd8d4: ldr             x16, [x16, #0x548]
    // 0x4fd8d8: StoreField: r0->field_13 = r16
    //     0x4fd8d8: stur            w16, [x0, #0x13]
    // 0x4fd8dc: r16 = "Another 10x pull requests"
    //     0x4fd8dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15548] "Another 10x pull requests"
    //     0x4fd8e0: ldr             x16, [x16, #0x548]
    // 0x4fd8e4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd8e4: stur            w16, [x0, #0x17]
    // 0x4fd8e8: r1 = <String>
    //     0x4fd8e8: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd8ec: r0 = AllocateGrowableArray()
    //     0x4fd8ec: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd8f0: mov             x2, x0
    // 0x4fd8f4: ldur            x0, [fp, #-0x20]
    // 0x4fd8f8: stur            x2, [fp, #-0x28]
    // 0x4fd8fc: StoreField: r2->field_f = r0
    //     0x4fd8fc: stur            w0, [x2, #0xf]
    // 0x4fd900: r0 = 6
    //     0x4fd900: movz            x0, #0x6
    // 0x4fd904: StoreField: r2->field_b = r0
    //     0x4fd904: stur            w0, [x2, #0xb]
    // 0x4fd908: r1 = <String>
    //     0x4fd908: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fd90c: r0 = Generator()
    //     0x4fd90c: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd910: mov             x3, x0
    // 0x4fd914: ldur            x0, [fp, #-0x28]
    // 0x4fd918: stur            x3, [fp, #-0x20]
    // 0x4fd91c: StoreField: r3->field_b = r0
    //     0x4fd91c: stur            w0, [x3, #0xb]
    // 0x4fd920: r1 = Null
    //     0x4fd920: mov             x1, NULL
    // 0x4fd924: r2 = 6
    //     0x4fd924: movz            x2, #0x6
    // 0x4fd928: r0 = AllocateArray()
    //     0x4fd928: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fd92c: stur            x0, [fp, #-0x28]
    // 0x4fd930: r16 = Instance_Tuple2
    //     0x4fd930: add             x16, PP, #0x15, lsl #12  ; [pp+0x15550] Obj!Tuple2<Chapter15Stat, CustomNum>@824191
    //     0x4fd934: ldr             x16, [x16, #0x550]
    // 0x4fd938: StoreField: r0->field_f = r16
    //     0x4fd938: stur            w16, [x0, #0xf]
    // 0x4fd93c: r16 = Instance_Tuple2
    //     0x4fd93c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15558] Obj!Tuple2<Chapter15Stat, CustomNum>@824171
    //     0x4fd940: ldr             x16, [x16, #0x558]
    // 0x4fd944: StoreField: r0->field_13 = r16
    //     0x4fd944: stur            w16, [x0, #0x13]
    // 0x4fd948: r16 = Instance_Tuple2
    //     0x4fd948: add             x16, PP, #0x15, lsl #12  ; [pp+0x15560] Obj!Tuple2<Chapter15Stat, CustomNum>@824151
    //     0x4fd94c: ldr             x16, [x16, #0x560]
    // 0x4fd950: ArrayStore: r0[0] = r16  ; List_4
    //     0x4fd950: stur            w16, [x0, #0x17]
    // 0x4fd954: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd954: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd958: ldr             x1, [x1, #0x310]
    // 0x4fd95c: r0 = AllocateGrowableArray()
    //     0x4fd95c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fd960: mov             x2, x0
    // 0x4fd964: ldur            x0, [fp, #-0x28]
    // 0x4fd968: stur            x2, [fp, #-0x30]
    // 0x4fd96c: StoreField: r2->field_f = r0
    //     0x4fd96c: stur            w0, [x2, #0xf]
    // 0x4fd970: r0 = 6
    //     0x4fd970: movz            x0, #0x6
    // 0x4fd974: StoreField: r2->field_b = r0
    //     0x4fd974: stur            w0, [x2, #0xb]
    // 0x4fd978: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd978: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fd97c: ldr             x1, [x1, #0x310]
    // 0x4fd980: r0 = Generator()
    //     0x4fd980: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fd984: mov             x2, x0
    // 0x4fd988: ldur            x0, [fp, #-0x30]
    // 0x4fd98c: stur            x2, [fp, #-0x28]
    // 0x4fd990: StoreField: r2->field_b = r0
    //     0x4fd990: stur            w0, [x2, #0xb]
    // 0x4fd994: r1 = <Chapter15Stat>
    //     0x4fd994: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fd998: ldr             x1, [x1, #0xf98]
    // 0x4fd99c: r0 = UpgradeData()
    //     0x4fd99c: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fd9a0: mov             x1, x0
    // 0x4fd9a4: ldur            x0, [fp, #-0x18]
    // 0x4fd9a8: StoreField: r1->field_b = r0
    //     0x4fd9a8: stur            w0, [x1, #0xb]
    // 0x4fd9ac: ldur            x0, [fp, #-0x20]
    // 0x4fd9b0: ArrayStore: r1[0] = r0  ; List_4
    //     0x4fd9b0: stur            w0, [x1, #0x17]
    // 0x4fd9b4: r0 = Instance_IconData
    //     0x4fd9b4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15568] Obj!IconData@830391
    //     0x4fd9b8: ldr             x0, [x0, #0x568]
    // 0x4fd9bc: StoreField: r1->field_13 = r0
    //     0x4fd9bc: stur            w0, [x1, #0x13]
    // 0x4fd9c0: ldur            x0, [fp, #-0x28]
    // 0x4fd9c4: StoreField: r1->field_f = r0
    //     0x4fd9c4: stur            w0, [x1, #0xf]
    // 0x4fd9c8: mov             x0, x1
    // 0x4fd9cc: ldur            x1, [fp, #-0x10]
    // 0x4fd9d0: ArrayStore: r1[19] = r0  ; List_4
    //     0x4fd9d0: add             x25, x1, #0x5b
    //     0x4fd9d4: str             w0, [x25]
    //     0x4fd9d8: tbz             w0, #0, #0x4fd9f4
    //     0x4fd9dc: ldurb           w16, [x1, #-1]
    //     0x4fd9e0: ldurb           w17, [x0, #-1]
    //     0x4fd9e4: and             x16, x17, x16, lsr #2
    //     0x4fd9e8: tst             x16, HEAP, lsr #32
    //     0x4fd9ec: b.eq            #0x4fd9f4
    //     0x4fd9f0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fd9f4: ldur            x0, [fp, #-0x10]
    // 0x4fd9f8: r16 = 208
    //     0x4fd9f8: movz            x16, #0xd0
    // 0x4fd9fc: StoreField: r0->field_5f = r16
    //     0x4fd9fc: stur            w16, [x0, #0x5f]
    // 0x4fda00: r1 = "Recruiting Program"
    //     0x4fda00: add             x1, PP, #0x15, lsl #12  ; [pp+0x15570] "Recruiting Program"
    //     0x4fda04: ldr             x1, [x1, #0x570]
    // 0x4fda08: r0 = autoString()
    //     0x4fda08: bl              #0x4f4d78  ; [package:pretentious/widgets/UpgradeButton.dart] Generator::autoString
    // 0x4fda0c: r1 = Null
    //     0x4fda0c: mov             x1, NULL
    // 0x4fda10: r2 = 2
    //     0x4fda10: movz            x2, #0x2
    // 0x4fda14: stur            x0, [fp, #-0x18]
    // 0x4fda18: r0 = AllocateArray()
    //     0x4fda18: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fda1c: stur            x0, [fp, #-0x20]
    // 0x4fda20: r16 = "Unlock buy options for star generators."
    //     0x4fda20: add             x16, PP, #0x15, lsl #12  ; [pp+0x15578] "Unlock buy options for star generators."
    //     0x4fda24: ldr             x16, [x16, #0x578]
    // 0x4fda28: StoreField: r0->field_f = r16
    //     0x4fda28: stur            w16, [x0, #0xf]
    // 0x4fda2c: r1 = <String>
    //     0x4fda2c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fda30: r0 = AllocateGrowableArray()
    //     0x4fda30: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fda34: mov             x2, x0
    // 0x4fda38: ldur            x0, [fp, #-0x20]
    // 0x4fda3c: stur            x2, [fp, #-0x28]
    // 0x4fda40: StoreField: r2->field_f = r0
    //     0x4fda40: stur            w0, [x2, #0xf]
    // 0x4fda44: r0 = 2
    //     0x4fda44: movz            x0, #0x2
    // 0x4fda48: StoreField: r2->field_b = r0
    //     0x4fda48: stur            w0, [x2, #0xb]
    // 0x4fda4c: r1 = <String>
    //     0x4fda4c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x4fda50: r0 = Generator()
    //     0x4fda50: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fda54: mov             x3, x0
    // 0x4fda58: ldur            x0, [fp, #-0x28]
    // 0x4fda5c: stur            x3, [fp, #-0x20]
    // 0x4fda60: StoreField: r3->field_b = r0
    //     0x4fda60: stur            w0, [x3, #0xb]
    // 0x4fda64: r1 = Null
    //     0x4fda64: mov             x1, NULL
    // 0x4fda68: r2 = 2
    //     0x4fda68: movz            x2, #0x2
    // 0x4fda6c: r0 = AllocateArray()
    //     0x4fda6c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4fda70: stur            x0, [fp, #-0x28]
    // 0x4fda74: r16 = Instance_Tuple2
    //     0x4fda74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15580] Obj!Tuple2<Chapter15Stat, CustomNum>@824131
    //     0x4fda78: ldr             x16, [x16, #0x580]
    // 0x4fda7c: StoreField: r0->field_f = r16
    //     0x4fda7c: stur            w16, [x0, #0xf]
    // 0x4fda80: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fda80: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fda84: ldr             x1, [x1, #0x310]
    // 0x4fda88: r0 = AllocateGrowableArray()
    //     0x4fda88: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x4fda8c: mov             x2, x0
    // 0x4fda90: ldur            x0, [fp, #-0x28]
    // 0x4fda94: stur            x2, [fp, #-0x30]
    // 0x4fda98: StoreField: r2->field_f = r0
    //     0x4fda98: stur            w0, [x2, #0xf]
    // 0x4fda9c: r0 = 2
    //     0x4fda9c: movz            x0, #0x2
    // 0x4fdaa0: StoreField: r2->field_b = r0
    //     0x4fdaa0: stur            w0, [x2, #0xb]
    // 0x4fdaa4: r1 = <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fdaa4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15310] TypeArguments: <Tuple2<Chapter15Stat, CustomNum>>
    //     0x4fdaa8: ldr             x1, [x1, #0x310]
    // 0x4fdaac: r0 = Generator()
    //     0x4fdaac: bl              #0x45893c  ; AllocateGeneratorStub -> Generator<X0> (size=0x14)
    // 0x4fdab0: mov             x2, x0
    // 0x4fdab4: ldur            x0, [fp, #-0x30]
    // 0x4fdab8: stur            x2, [fp, #-0x28]
    // 0x4fdabc: StoreField: r2->field_b = r0
    //     0x4fdabc: stur            w0, [x2, #0xb]
    // 0x4fdac0: r1 = <Chapter15Stat>
    //     0x4fdac0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4fdac4: ldr             x1, [x1, #0xf98]
    // 0x4fdac8: r0 = UpgradeData()
    //     0x4fdac8: bl              #0x4f4d6c  ; AllocateUpgradeDataStub -> UpgradeData<X0> (size=0x28)
    // 0x4fdacc: mov             x3, x0
    // 0x4fdad0: ldur            x0, [fp, #-0x18]
    // 0x4fdad4: stur            x3, [fp, #-0x30]
    // 0x4fdad8: StoreField: r3->field_b = r0
    //     0x4fdad8: stur            w0, [x3, #0xb]
    // 0x4fdadc: ldur            x0, [fp, #-0x20]
    // 0x4fdae0: ArrayStore: r3[0] = r0  ; List_4
    //     0x4fdae0: stur            w0, [x3, #0x17]
    // 0x4fdae4: r0 = Instance_IconData
    //     0x4fdae4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15588] Obj!IconData@830371
    //     0x4fdae8: ldr             x0, [x0, #0x588]
    // 0x4fdaec: StoreField: r3->field_13 = r0
    //     0x4fdaec: stur            w0, [x3, #0x13]
    // 0x4fdaf0: ldur            x0, [fp, #-0x28]
    // 0x4fdaf4: StoreField: r3->field_f = r0
    //     0x4fdaf4: stur            w0, [x3, #0xf]
    // 0x4fdaf8: r1 = Function '<anonymous closure>':.
    //     0x4fdaf8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15590] AnonymousClosure: (0x4fe96c), in [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::ensureInitialized (0x4feca4)
    //     0x4fdafc: ldr             x1, [x1, #0x590]
    // 0x4fdb00: r2 = Null
    //     0x4fdb00: mov             x2, NULL
    // 0x4fdb04: r0 = AllocateClosure()
    //     0x4fdb04: bl              #0x826750  ; AllocateClosureStub
    // 0x4fdb08: mov             x1, x0
    // 0x4fdb0c: ldur            x0, [fp, #-0x30]
    // 0x4fdb10: StoreField: r0->field_1b = r1
    //     0x4fdb10: stur            w1, [x0, #0x1b]
    // 0x4fdb14: ldur            x1, [fp, #-0x10]
    // 0x4fdb18: ArrayStore: r1[21] = r0  ; List_4
    //     0x4fdb18: add             x25, x1, #0x63
    //     0x4fdb1c: str             w0, [x25]
    //     0x4fdb20: tbz             w0, #0, #0x4fdb3c
    //     0x4fdb24: ldurb           w16, [x1, #-1]
    //     0x4fdb28: ldurb           w17, [x0, #-1]
    //     0x4fdb2c: and             x16, x17, x16, lsr #2
    //     0x4fdb30: tst             x16, HEAP, lsr #32
    //     0x4fdb34: b.eq            #0x4fdb3c
    //     0x4fdb38: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4fdb3c: r16 = <int, UpgradeData<Chapter15Stat>>
    //     0x4fdb3c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15598] TypeArguments: <int, UpgradeData<Chapter15Stat>>
    //     0x4fdb40: ldr             x16, [x16, #0x598]
    // 0x4fdb44: ldur            lr, [fp, #-0x10]
    // 0x4fdb48: stp             lr, x16, [SP]
    // 0x4fdb4c: r0 = Map._fromLiteral()
    //     0x4fdb4c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4fdb50: ldur            x1, [fp, #-8]
    // 0x4fdb54: StoreField: r1->field_8f = r0
    //     0x4fdb54: stur            w0, [x1, #0x8f]
    //     0x4fdb58: ldurb           w16, [x1, #-1]
    //     0x4fdb5c: ldurb           w17, [x0, #-1]
    //     0x4fdb60: and             x16, x17, x16, lsr #2
    //     0x4fdb64: tst             x16, HEAP, lsr #32
    //     0x4fdb68: b.eq            #0x4fdb70
    //     0x4fdb6c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4fdb70: r0 = Null
    //     0x4fdb70: mov             x0, NULL
    // 0x4fdb74: LeaveFrame
    //     0x4fdb74: mov             SP, fp
    //     0x4fdb78: ldp             fp, lr, [SP], #0x10
    // 0x4fdb7c: ret
    //     0x4fdb7c: ret             
    // 0x4fdb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fdb80: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fdb84: b               #0x4fc068
    // 0x4fdb88: SaveReg d0
    //     0x4fdb88: str             q0, [SP, #-0x10]!
    // 0x4fdb8c: r0 = AllocateDouble()
    //     0x4fdb8c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fdb90: RestoreReg d0
    //     0x4fdb90: ldr             q0, [SP], #0x10
    // 0x4fdb94: b               #0x4fc790
    // 0x4fdb98: SaveReg d0
    //     0x4fdb98: str             q0, [SP, #-0x10]!
    // 0x4fdb9c: r0 = AllocateDouble()
    //     0x4fdb9c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fdba0: RestoreReg d0
    //     0x4fdba0: ldr             q0, [SP], #0x10
    // 0x4fdba4: b               #0x4fc808
    // 0x4fdba8: SaveReg d0
    //     0x4fdba8: str             q0, [SP, #-0x10]!
    // 0x4fdbac: r0 = AllocateDouble()
    //     0x4fdbac: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fdbb0: RestoreReg d0
    //     0x4fdbb0: ldr             q0, [SP], #0x10
    // 0x4fdbb4: b               #0x4fc880
    // 0x4fdbb8: SaveReg d0
    //     0x4fdbb8: str             q0, [SP, #-0x10]!
    // 0x4fdbbc: r0 = AllocateDouble()
    //     0x4fdbbc: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fdbc0: RestoreReg d0
    //     0x4fdbc0: ldr             q0, [SP], #0x10
    // 0x4fdbc4: b               #0x4fc8f8
  }
  _ efficientSymbolsBoost(/* No info */) {
    // ** addr: 0x4fe210, size: 0x244
    // 0x4fe210: EnterFrame
    //     0x4fe210: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe214: mov             fp, SP
    // 0x4fe218: AllocStack(0x30)
    //     0x4fe218: sub             SP, SP, #0x30
    // 0x4fe21c: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */, {dynamic level = Null /* r1 */})
    //     0x4fe21c: mov             x0, x1
    //     0x4fe220: stur            x1, [fp, #-0x10]
    //     0x4fe224: ldur            w1, [x4, #0x13]
    //     0x4fe228: ldur            w2, [x4, #0x1f]
    //     0x4fe22c: add             x2, x2, HEAP, lsl #32
    //     0x4fe230: add             x16, PP, #0x15, lsl #12  ; [pp+0x15250] "level"
    //     0x4fe234: ldr             x16, [x16, #0x250]
    //     0x4fe238: cmp             w2, w16
    //     0x4fe23c: b.ne            #0x4fe258
    //     0x4fe240: ldur            w2, [x4, #0x23]
    //     0x4fe244: add             x2, x2, HEAP, lsl #32
    //     0x4fe248: sub             w3, w1, w2
    //     0x4fe24c: add             x1, fp, w3, sxtw #2
    //     0x4fe250: ldr             x1, [x1, #8]
    //     0x4fe254: b               #0x4fe25c
    //     0x4fe258: mov             x1, NULL
    // 0x4fe25c: CheckStackOverflow
    //     0x4fe25c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fe260: cmp             SP, x16
    //     0x4fe264: b.ls            #0x4fe44c
    // 0x4fe268: cmp             w1, NULL
    // 0x4fe26c: b.ne            #0x4fe2b0
    // 0x4fe270: LoadField: r3 = r0->field_43
    //     0x4fe270: ldur            w3, [x0, #0x43]
    // 0x4fe274: DecompressPointer r3
    //     0x4fe274: add             x3, x3, HEAP, lsl #32
    // 0x4fe278: mov             x1, x3
    // 0x4fe27c: stur            x3, [fp, #-8]
    // 0x4fe280: r2 = 24
    //     0x4fe280: movz            x2, #0x18
    // 0x4fe284: r0 = _getValueOrData()
    //     0x4fe284: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe288: mov             x1, x0
    // 0x4fe28c: ldur            x0, [fp, #-8]
    // 0x4fe290: LoadField: r2 = r0->field_f
    //     0x4fe290: ldur            w2, [x0, #0xf]
    // 0x4fe294: DecompressPointer r2
    //     0x4fe294: add             x2, x2, HEAP, lsl #32
    // 0x4fe298: cmp             w2, w1
    // 0x4fe29c: b.ne            #0x4fe2a8
    // 0x4fe2a0: r0 = Null
    //     0x4fe2a0: mov             x0, NULL
    // 0x4fe2a4: b               #0x4fe2b4
    // 0x4fe2a8: mov             x0, x1
    // 0x4fe2ac: b               #0x4fe2b4
    // 0x4fe2b0: mov             x0, x1
    // 0x4fe2b4: cmp             w0, NULL
    // 0x4fe2b8: b.ne            #0x4fe2c4
    // 0x4fe2bc: r1 = 0
    //     0x4fe2bc: movz            x1, #0
    // 0x4fe2c0: b               #0x4fe2d0
    // 0x4fe2c4: r1 = LoadInt32Instr(r0)
    //     0x4fe2c4: sbfx            x1, x0, #1, #0x1f
    //     0x4fe2c8: tbz             w0, #0, #0x4fe2d0
    //     0x4fe2cc: ldur            x1, [x0, #7]
    // 0x4fe2d0: ldur            x0, [fp, #-0x10]
    // 0x4fe2d4: sub             x3, x1, #1
    // 0x4fe2d8: stur            x3, [fp, #-0x18]
    // 0x4fe2dc: LoadField: r4 = r0->field_43
    //     0x4fe2dc: ldur            w4, [x0, #0x43]
    // 0x4fe2e0: DecompressPointer r4
    //     0x4fe2e0: add             x4, x4, HEAP, lsl #32
    // 0x4fe2e4: mov             x1, x4
    // 0x4fe2e8: stur            x4, [fp, #-8]
    // 0x4fe2ec: r2 = 204
    //     0x4fe2ec: movz            x2, #0xcc
    // 0x4fe2f0: r0 = _getValueOrData()
    //     0x4fe2f0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe2f4: mov             x1, x0
    // 0x4fe2f8: ldur            x0, [fp, #-8]
    // 0x4fe2fc: LoadField: r2 = r0->field_f
    //     0x4fe2fc: ldur            w2, [x0, #0xf]
    // 0x4fe300: DecompressPointer r2
    //     0x4fe300: add             x2, x2, HEAP, lsl #32
    // 0x4fe304: cmp             w2, w1
    // 0x4fe308: b.ne            #0x4fe314
    // 0x4fe30c: r0 = Null
    //     0x4fe30c: mov             x0, NULL
    // 0x4fe310: b               #0x4fe318
    // 0x4fe314: mov             x0, x1
    // 0x4fe318: cmp             w0, NULL
    // 0x4fe31c: b.ne            #0x4fe328
    // 0x4fe320: r1 = 0
    //     0x4fe320: movz            x1, #0
    // 0x4fe324: b               #0x4fe334
    // 0x4fe328: r1 = LoadInt32Instr(r0)
    //     0x4fe328: sbfx            x1, x0, #1, #0x1f
    //     0x4fe32c: tbz             w0, #0, #0x4fe334
    //     0x4fe330: ldur            x1, [x0, #7]
    // 0x4fe334: ldur            x0, [fp, #-0x18]
    // 0x4fe338: d0 = 0.450000
    //     0x4fe338: add             x17, PP, #0x15, lsl #12  ; [pp+0x15258] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x4fe33c: ldr             d0, [x17, #0x258]
    // 0x4fe340: scvtf           d1, x1
    // 0x4fe344: fmul            d2, d1, d0
    // 0x4fe348: scvtf           d0, x0
    // 0x4fe34c: fadd            d1, d0, d2
    // 0x4fe350: stur            d1, [fp, #-0x20]
    // 0x4fe354: r16 = 4
    //     0x4fe354: movz            x16, #0x4
    // 0x4fe358: stp             x16, NULL, [SP]
    // 0x4fe35c: r0 = _Double.fromInteger()
    //     0x4fe35c: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x4fe360: LoadField: d0 = r0->field_7
    //     0x4fe360: ldur            d0, [x0, #7]
    // 0x4fe364: ldur            d1, [fp, #-0x20]
    // 0x4fe368: d30 = 0.000000
    //     0x4fe368: fmov            d30, d0
    // 0x4fe36c: d0 = 1.000000
    //     0x4fe36c: fmov            d0, #1.00000000
    // 0x4fe370: fcmp            d1, #0.0
    // 0x4fe374: b.vs            #0x4fe3b8
    // 0x4fe378: b.eq            #0x4fe440
    // 0x4fe37c: fcmp            d1, d0
    // 0x4fe380: b.eq            #0x4fe3a8
    // 0x4fe384: d31 = 2.000000
    //     0x4fe384: fmov            d31, #2.00000000
    // 0x4fe388: fcmp            d1, d31
    // 0x4fe38c: b.eq            #0x4fe3b0
    // 0x4fe390: d31 = 3.000000
    //     0x4fe390: fmov            d31, #3.00000000
    // 0x4fe394: fcmp            d1, d31
    // 0x4fe398: b.ne            #0x4fe3b8
    // 0x4fe39c: fmul            d0, d30, d30
    // 0x4fe3a0: fmul            d0, d0, d30
    // 0x4fe3a4: b               #0x4fe440
    // 0x4fe3a8: d0 = 0.000000
    //     0x4fe3a8: fmov            d0, d30
    // 0x4fe3ac: b               #0x4fe440
    // 0x4fe3b0: fmul            d0, d30, d30
    // 0x4fe3b4: b               #0x4fe440
    // 0x4fe3b8: fcmp            d30, d0
    // 0x4fe3bc: b.vs            #0x4fe3cc
    // 0x4fe3c0: b.eq            #0x4fe440
    // 0x4fe3c4: fcmp            d30, d1
    // 0x4fe3c8: b.vc            #0x4fe3d8
    // 0x4fe3cc: d0 = nan
    //     0x4fe3cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x4fe3d0: ldr             d0, [x17, #0xe48]
    // 0x4fe3d4: b               #0x4fe440
    // 0x4fe3d8: d0 = -inf
    //     0x4fe3d8: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x4fe3dc: fcmp            d30, d0
    // 0x4fe3e0: b.eq            #0x4fe408
    // 0x4fe3e4: d0 = 0.500000
    //     0x4fe3e4: fmov            d0, #0.50000000
    // 0x4fe3e8: fcmp            d1, d0
    // 0x4fe3ec: b.ne            #0x4fe408
    // 0x4fe3f0: fcmp            d30, #0.0
    // 0x4fe3f4: b.eq            #0x4fe400
    // 0x4fe3f8: fsqrt           d0, d30
    // 0x4fe3fc: b               #0x4fe440
    // 0x4fe400: d0 = 0.000000
    //     0x4fe400: eor             v0.16b, v0.16b, v0.16b
    // 0x4fe404: b               #0x4fe440
    // 0x4fe408: d0 = 0.000000
    //     0x4fe408: fmov            d0, d30
    // 0x4fe40c: stp             fp, lr, [SP, #-0x10]!
    // 0x4fe410: mov             fp, SP
    // 0x4fe414: CallRuntime_LibcPow(double, double) -> double
    //     0x4fe414: and             SP, SP, #0xfffffffffffffff0
    //     0x4fe418: mov             sp, SP
    //     0x4fe41c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x4fe420: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4fe424: blr             x16
    //     0x4fe428: movz            x16, #0x8
    //     0x4fe42c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4fe430: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4fe434: sub             sp, x16, #1, lsl #12
    //     0x4fe438: mov             SP, fp
    //     0x4fe43c: ldp             fp, lr, [SP], #0x10
    // 0x4fe440: LeaveFrame
    //     0x4fe440: mov             SP, fp
    //     0x4fe444: ldp             fp, lr, [SP], #0x10
    // 0x4fe448: ret
    //     0x4fe448: ret             
    // 0x4fe44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe44c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe450: b               #0x4fe268
  }
  _ multithreadingBoost(/* No info */) {
    // ** addr: 0x4fe454, size: 0x1a0
    // 0x4fe454: EnterFrame
    //     0x4fe454: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe458: mov             fp, SP
    // 0x4fe45c: AllocStack(0x18)
    //     0x4fe45c: sub             SP, SP, #0x18
    // 0x4fe460: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */, {dynamic level = Null /* r1 */})
    //     0x4fe460: mov             x0, x1
    //     0x4fe464: stur            x1, [fp, #-0x10]
    //     0x4fe468: ldur            w1, [x4, #0x13]
    //     0x4fe46c: ldur            w2, [x4, #0x1f]
    //     0x4fe470: add             x2, x2, HEAP, lsl #32
    //     0x4fe474: add             x16, PP, #0x15, lsl #12  ; [pp+0x15250] "level"
    //     0x4fe478: ldr             x16, [x16, #0x250]
    //     0x4fe47c: cmp             w2, w16
    //     0x4fe480: b.ne            #0x4fe49c
    //     0x4fe484: ldur            w2, [x4, #0x23]
    //     0x4fe488: add             x2, x2, HEAP, lsl #32
    //     0x4fe48c: sub             w3, w1, w2
    //     0x4fe490: add             x1, fp, w3, sxtw #2
    //     0x4fe494: ldr             x1, [x1, #8]
    //     0x4fe498: b               #0x4fe4a0
    //     0x4fe49c: mov             x1, NULL
    // 0x4fe4a0: CheckStackOverflow
    //     0x4fe4a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fe4a4: cmp             SP, x16
    //     0x4fe4a8: b.ls            #0x4fe5d8
    // 0x4fe4ac: cmp             w1, NULL
    // 0x4fe4b0: b.ne            #0x4fe4f4
    // 0x4fe4b4: LoadField: r3 = r0->field_43
    //     0x4fe4b4: ldur            w3, [x0, #0x43]
    // 0x4fe4b8: DecompressPointer r3
    //     0x4fe4b8: add             x3, x3, HEAP, lsl #32
    // 0x4fe4bc: mov             x1, x3
    // 0x4fe4c0: stur            x3, [fp, #-8]
    // 0x4fe4c4: r2 = 22
    //     0x4fe4c4: movz            x2, #0x16
    // 0x4fe4c8: r0 = _getValueOrData()
    //     0x4fe4c8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe4cc: mov             x1, x0
    // 0x4fe4d0: ldur            x0, [fp, #-8]
    // 0x4fe4d4: LoadField: r2 = r0->field_f
    //     0x4fe4d4: ldur            w2, [x0, #0xf]
    // 0x4fe4d8: DecompressPointer r2
    //     0x4fe4d8: add             x2, x2, HEAP, lsl #32
    // 0x4fe4dc: cmp             w2, w1
    // 0x4fe4e0: b.ne            #0x4fe4ec
    // 0x4fe4e4: r0 = Null
    //     0x4fe4e4: mov             x0, NULL
    // 0x4fe4e8: b               #0x4fe4f8
    // 0x4fe4ec: mov             x0, x1
    // 0x4fe4f0: b               #0x4fe4f8
    // 0x4fe4f4: mov             x0, x1
    // 0x4fe4f8: cmp             w0, NULL
    // 0x4fe4fc: b.ne            #0x4fe508
    // 0x4fe500: r3 = 0
    //     0x4fe500: movz            x3, #0
    // 0x4fe504: b               #0x4fe518
    // 0x4fe508: r1 = LoadInt32Instr(r0)
    //     0x4fe508: sbfx            x1, x0, #1, #0x1f
    //     0x4fe50c: tbz             w0, #0, #0x4fe514
    //     0x4fe510: ldur            x1, [x0, #7]
    // 0x4fe514: mov             x3, x1
    // 0x4fe518: ldur            x0, [fp, #-0x10]
    // 0x4fe51c: stur            x3, [fp, #-0x18]
    // 0x4fe520: LoadField: r4 = r0->field_43
    //     0x4fe520: ldur            w4, [x0, #0x43]
    // 0x4fe524: DecompressPointer r4
    //     0x4fe524: add             x4, x4, HEAP, lsl #32
    // 0x4fe528: mov             x1, x4
    // 0x4fe52c: stur            x4, [fp, #-8]
    // 0x4fe530: r2 = 204
    //     0x4fe530: movz            x2, #0xcc
    // 0x4fe534: r0 = _getValueOrData()
    //     0x4fe534: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe538: mov             x1, x0
    // 0x4fe53c: ldur            x0, [fp, #-8]
    // 0x4fe540: LoadField: r2 = r0->field_f
    //     0x4fe540: ldur            w2, [x0, #0xf]
    // 0x4fe544: DecompressPointer r2
    //     0x4fe544: add             x2, x2, HEAP, lsl #32
    // 0x4fe548: cmp             w2, w1
    // 0x4fe54c: b.ne            #0x4fe558
    // 0x4fe550: r0 = Null
    //     0x4fe550: mov             x0, NULL
    // 0x4fe554: b               #0x4fe55c
    // 0x4fe558: mov             x0, x1
    // 0x4fe55c: cmp             w0, NULL
    // 0x4fe560: b.ne            #0x4fe56c
    // 0x4fe564: r1 = 0
    //     0x4fe564: movz            x1, #0
    // 0x4fe568: b               #0x4fe578
    // 0x4fe56c: r1 = LoadInt32Instr(r0)
    //     0x4fe56c: sbfx            x1, x0, #1, #0x1f
    //     0x4fe570: tbz             w0, #0, #0x4fe578
    //     0x4fe574: ldur            x1, [x0, #7]
    // 0x4fe578: ldur            x0, [fp, #-0x18]
    // 0x4fe57c: d0 = 0.450000
    //     0x4fe57c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15258] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x4fe580: ldr             d0, [x17, #0x258]
    // 0x4fe584: scvtf           d1, x1
    // 0x4fe588: fmul            d2, d1, d0
    // 0x4fe58c: scvtf           d0, x0
    // 0x4fe590: fadd            d1, d0, d2
    // 0x4fe594: r2 = inline_Allocate_Double()
    //     0x4fe594: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x4fe598: add             x2, x2, #0x10
    //     0x4fe59c: cmp             x0, x2
    //     0x4fe5a0: b.ls            #0x4fe5e0
    //     0x4fe5a4: str             x2, [THR, #0x60]  ; THR::top
    //     0x4fe5a8: sub             x2, x2, #0xf
    //     0x4fe5ac: movz            x0, #0xe19c
    //     0x4fe5b0: movk            x0, #0x3, lsl #16
    //     0x4fe5b4: stur            x0, [x2, #-1]
    // 0x4fe5b8: dmb             ishst
    // 0x4fe5bc: StoreField: r2->field_7 = d1
    //     0x4fe5bc: stur            d1, [x2, #7]
    // 0x4fe5c0: r1 = Instance_CustomNum
    //     0x4fe5c0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4fe5c4: ldr             x1, [x1, #0x970]
    // 0x4fe5c8: r0 = pow()
    //     0x4fe5c8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x4fe5cc: LeaveFrame
    //     0x4fe5cc: mov             SP, fp
    //     0x4fe5d0: ldp             fp, lr, [SP], #0x10
    // 0x4fe5d4: ret
    //     0x4fe5d4: ret             
    // 0x4fe5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe5d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe5dc: b               #0x4fe4ac
    // 0x4fe5e0: SaveReg d1
    //     0x4fe5e0: str             q1, [SP, #-0x10]!
    // 0x4fe5e4: r0 = AllocateDouble()
    //     0x4fe5e4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fe5e8: mov             x2, x0
    // 0x4fe5ec: RestoreReg d1
    //     0x4fe5ec: ldr             q1, [SP], #0x10
    // 0x4fe5f0: b               #0x4fe5bc
  }
  _ bonusYieldBoost(/* No info */) {
    // ** addr: 0x4fe5f4, size: 0x15c
    // 0x4fe5f4: EnterFrame
    //     0x4fe5f4: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe5f8: mov             fp, SP
    // 0x4fe5fc: AllocStack(0x18)
    //     0x4fe5fc: sub             SP, SP, #0x18
    // 0x4fe600: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */, {dynamic level = Null /* r1 */})
    //     0x4fe600: mov             x0, x1
    //     0x4fe604: stur            x1, [fp, #-0x10]
    //     0x4fe608: ldur            w1, [x4, #0x13]
    //     0x4fe60c: ldur            w2, [x4, #0x1f]
    //     0x4fe610: add             x2, x2, HEAP, lsl #32
    //     0x4fe614: add             x16, PP, #0x15, lsl #12  ; [pp+0x15250] "level"
    //     0x4fe618: ldr             x16, [x16, #0x250]
    //     0x4fe61c: cmp             w2, w16
    //     0x4fe620: b.ne            #0x4fe63c
    //     0x4fe624: ldur            w2, [x4, #0x23]
    //     0x4fe628: add             x2, x2, HEAP, lsl #32
    //     0x4fe62c: sub             w3, w1, w2
    //     0x4fe630: add             x1, fp, w3, sxtw #2
    //     0x4fe634: ldr             x1, [x1, #8]
    //     0x4fe638: b               #0x4fe640
    //     0x4fe63c: mov             x1, NULL
    // 0x4fe640: CheckStackOverflow
    //     0x4fe640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fe644: cmp             SP, x16
    //     0x4fe648: b.ls            #0x4fe748
    // 0x4fe64c: cmp             w1, NULL
    // 0x4fe650: b.ne            #0x4fe694
    // 0x4fe654: LoadField: r3 = r0->field_43
    //     0x4fe654: ldur            w3, [x0, #0x43]
    // 0x4fe658: DecompressPointer r3
    //     0x4fe658: add             x3, x3, HEAP, lsl #32
    // 0x4fe65c: mov             x1, x3
    // 0x4fe660: stur            x3, [fp, #-8]
    // 0x4fe664: r2 = 6
    //     0x4fe664: movz            x2, #0x6
    // 0x4fe668: r0 = _getValueOrData()
    //     0x4fe668: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe66c: mov             x1, x0
    // 0x4fe670: ldur            x0, [fp, #-8]
    // 0x4fe674: LoadField: r2 = r0->field_f
    //     0x4fe674: ldur            w2, [x0, #0xf]
    // 0x4fe678: DecompressPointer r2
    //     0x4fe678: add             x2, x2, HEAP, lsl #32
    // 0x4fe67c: cmp             w2, w1
    // 0x4fe680: b.ne            #0x4fe68c
    // 0x4fe684: r0 = Null
    //     0x4fe684: mov             x0, NULL
    // 0x4fe688: b               #0x4fe698
    // 0x4fe68c: mov             x0, x1
    // 0x4fe690: b               #0x4fe698
    // 0x4fe694: mov             x0, x1
    // 0x4fe698: cmp             w0, NULL
    // 0x4fe69c: b.ne            #0x4fe6a8
    // 0x4fe6a0: r1 = 0
    //     0x4fe6a0: movz            x1, #0
    // 0x4fe6a4: b               #0x4fe6b4
    // 0x4fe6a8: r1 = LoadInt32Instr(r0)
    //     0x4fe6a8: sbfx            x1, x0, #1, #0x1f
    //     0x4fe6ac: tbz             w0, #0, #0x4fe6b4
    //     0x4fe6b0: ldur            x1, [x0, #7]
    // 0x4fe6b4: ldur            x0, [fp, #-0x10]
    // 0x4fe6b8: add             x3, x1, #1
    // 0x4fe6bc: stur            x3, [fp, #-0x18]
    // 0x4fe6c0: LoadField: r4 = r0->field_43
    //     0x4fe6c0: ldur            w4, [x0, #0x43]
    // 0x4fe6c4: DecompressPointer r4
    //     0x4fe6c4: add             x4, x4, HEAP, lsl #32
    // 0x4fe6c8: mov             x1, x4
    // 0x4fe6cc: stur            x4, [fp, #-8]
    // 0x4fe6d0: r2 = 204
    //     0x4fe6d0: movz            x2, #0xcc
    // 0x4fe6d4: r0 = _getValueOrData()
    //     0x4fe6d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe6d8: mov             x1, x0
    // 0x4fe6dc: ldur            x0, [fp, #-8]
    // 0x4fe6e0: LoadField: r2 = r0->field_f
    //     0x4fe6e0: ldur            w2, [x0, #0xf]
    // 0x4fe6e4: DecompressPointer r2
    //     0x4fe6e4: add             x2, x2, HEAP, lsl #32
    // 0x4fe6e8: cmp             w2, w1
    // 0x4fe6ec: b.ne            #0x4fe6f8
    // 0x4fe6f0: r0 = Null
    //     0x4fe6f0: mov             x0, NULL
    // 0x4fe6f4: b               #0x4fe6fc
    // 0x4fe6f8: mov             x0, x1
    // 0x4fe6fc: cmp             w0, NULL
    // 0x4fe700: b.ne            #0x4fe70c
    // 0x4fe704: r1 = 0
    //     0x4fe704: movz            x1, #0
    // 0x4fe708: b               #0x4fe718
    // 0x4fe70c: r1 = LoadInt32Instr(r0)
    //     0x4fe70c: sbfx            x1, x0, #1, #0x1f
    //     0x4fe710: tbz             w0, #0, #0x4fe718
    //     0x4fe714: ldur            x1, [x0, #7]
    // 0x4fe718: ldur            x0, [fp, #-0x18]
    // 0x4fe71c: d2 = 1.000000
    //     0x4fe71c: fmov            d2, #1.00000000
    // 0x4fe720: d1 = 0.450000
    //     0x4fe720: add             x17, PP, #0x15, lsl #12  ; [pp+0x15258] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x4fe724: ldr             d1, [x17, #0x258]
    // 0x4fe728: scvtf           d3, x1
    // 0x4fe72c: fmul            d4, d3, d1
    // 0x4fe730: fadd            d1, d4, d2
    // 0x4fe734: scvtf           d2, x0
    // 0x4fe738: fmul            d0, d2, d1
    // 0x4fe73c: LeaveFrame
    //     0x4fe73c: mov             SP, fp
    //     0x4fe740: ldp             fp, lr, [SP], #0x10
    // 0x4fe744: ret
    //     0x4fe744: ret             
    // 0x4fe748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe748: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe74c: b               #0x4fe64c
  }
  _ biggerSymbolBoost(/* No info */) {
    // ** addr: 0x4fe750, size: 0x1a0
    // 0x4fe750: EnterFrame
    //     0x4fe750: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe754: mov             fp, SP
    // 0x4fe758: AllocStack(0x18)
    //     0x4fe758: sub             SP, SP, #0x18
    // 0x4fe75c: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */, {dynamic level = Null /* r1 */})
    //     0x4fe75c: mov             x0, x1
    //     0x4fe760: stur            x1, [fp, #-0x10]
    //     0x4fe764: ldur            w1, [x4, #0x13]
    //     0x4fe768: ldur            w2, [x4, #0x1f]
    //     0x4fe76c: add             x2, x2, HEAP, lsl #32
    //     0x4fe770: add             x16, PP, #0x15, lsl #12  ; [pp+0x15250] "level"
    //     0x4fe774: ldr             x16, [x16, #0x250]
    //     0x4fe778: cmp             w2, w16
    //     0x4fe77c: b.ne            #0x4fe798
    //     0x4fe780: ldur            w2, [x4, #0x23]
    //     0x4fe784: add             x2, x2, HEAP, lsl #32
    //     0x4fe788: sub             w3, w1, w2
    //     0x4fe78c: add             x1, fp, w3, sxtw #2
    //     0x4fe790: ldr             x1, [x1, #8]
    //     0x4fe794: b               #0x4fe79c
    //     0x4fe798: mov             x1, NULL
    // 0x4fe79c: CheckStackOverflow
    //     0x4fe79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4fe7a0: cmp             SP, x16
    //     0x4fe7a4: b.ls            #0x4fe8d4
    // 0x4fe7a8: cmp             w1, NULL
    // 0x4fe7ac: b.ne            #0x4fe7f0
    // 0x4fe7b0: LoadField: r3 = r0->field_43
    //     0x4fe7b0: ldur            w3, [x0, #0x43]
    // 0x4fe7b4: DecompressPointer r3
    //     0x4fe7b4: add             x3, x3, HEAP, lsl #32
    // 0x4fe7b8: mov             x1, x3
    // 0x4fe7bc: stur            x3, [fp, #-8]
    // 0x4fe7c0: r2 = 2
    //     0x4fe7c0: movz            x2, #0x2
    // 0x4fe7c4: r0 = _getValueOrData()
    //     0x4fe7c4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe7c8: mov             x1, x0
    // 0x4fe7cc: ldur            x0, [fp, #-8]
    // 0x4fe7d0: LoadField: r2 = r0->field_f
    //     0x4fe7d0: ldur            w2, [x0, #0xf]
    // 0x4fe7d4: DecompressPointer r2
    //     0x4fe7d4: add             x2, x2, HEAP, lsl #32
    // 0x4fe7d8: cmp             w2, w1
    // 0x4fe7dc: b.ne            #0x4fe7e8
    // 0x4fe7e0: r0 = Null
    //     0x4fe7e0: mov             x0, NULL
    // 0x4fe7e4: b               #0x4fe7f4
    // 0x4fe7e8: mov             x0, x1
    // 0x4fe7ec: b               #0x4fe7f4
    // 0x4fe7f0: mov             x0, x1
    // 0x4fe7f4: cmp             w0, NULL
    // 0x4fe7f8: b.ne            #0x4fe804
    // 0x4fe7fc: r3 = 0
    //     0x4fe7fc: movz            x3, #0
    // 0x4fe800: b               #0x4fe814
    // 0x4fe804: r1 = LoadInt32Instr(r0)
    //     0x4fe804: sbfx            x1, x0, #1, #0x1f
    //     0x4fe808: tbz             w0, #0, #0x4fe810
    //     0x4fe80c: ldur            x1, [x0, #7]
    // 0x4fe810: mov             x3, x1
    // 0x4fe814: ldur            x0, [fp, #-0x10]
    // 0x4fe818: stur            x3, [fp, #-0x18]
    // 0x4fe81c: LoadField: r4 = r0->field_43
    //     0x4fe81c: ldur            w4, [x0, #0x43]
    // 0x4fe820: DecompressPointer r4
    //     0x4fe820: add             x4, x4, HEAP, lsl #32
    // 0x4fe824: mov             x1, x4
    // 0x4fe828: stur            x4, [fp, #-8]
    // 0x4fe82c: r2 = 204
    //     0x4fe82c: movz            x2, #0xcc
    // 0x4fe830: r0 = _getValueOrData()
    //     0x4fe830: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fe834: mov             x1, x0
    // 0x4fe838: ldur            x0, [fp, #-8]
    // 0x4fe83c: LoadField: r2 = r0->field_f
    //     0x4fe83c: ldur            w2, [x0, #0xf]
    // 0x4fe840: DecompressPointer r2
    //     0x4fe840: add             x2, x2, HEAP, lsl #32
    // 0x4fe844: cmp             w2, w1
    // 0x4fe848: b.ne            #0x4fe854
    // 0x4fe84c: r0 = Null
    //     0x4fe84c: mov             x0, NULL
    // 0x4fe850: b               #0x4fe858
    // 0x4fe854: mov             x0, x1
    // 0x4fe858: cmp             w0, NULL
    // 0x4fe85c: b.ne            #0x4fe868
    // 0x4fe860: r1 = 0
    //     0x4fe860: movz            x1, #0
    // 0x4fe864: b               #0x4fe874
    // 0x4fe868: r1 = LoadInt32Instr(r0)
    //     0x4fe868: sbfx            x1, x0, #1, #0x1f
    //     0x4fe86c: tbz             w0, #0, #0x4fe874
    //     0x4fe870: ldur            x1, [x0, #7]
    // 0x4fe874: ldur            x0, [fp, #-0x18]
    // 0x4fe878: d0 = 0.450000
    //     0x4fe878: add             x17, PP, #0x15, lsl #12  ; [pp+0x15258] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x4fe87c: ldr             d0, [x17, #0x258]
    // 0x4fe880: scvtf           d1, x1
    // 0x4fe884: fmul            d2, d1, d0
    // 0x4fe888: scvtf           d0, x0
    // 0x4fe88c: fadd            d1, d0, d2
    // 0x4fe890: r2 = inline_Allocate_Double()
    //     0x4fe890: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x4fe894: add             x2, x2, #0x10
    //     0x4fe898: cmp             x0, x2
    //     0x4fe89c: b.ls            #0x4fe8dc
    //     0x4fe8a0: str             x2, [THR, #0x60]  ; THR::top
    //     0x4fe8a4: sub             x2, x2, #0xf
    //     0x4fe8a8: movz            x0, #0xe19c
    //     0x4fe8ac: movk            x0, #0x3, lsl #16
    //     0x4fe8b0: stur            x0, [x2, #-1]
    // 0x4fe8b4: dmb             ishst
    // 0x4fe8b8: StoreField: r2->field_7 = d1
    //     0x4fe8b8: stur            d1, [x2, #7]
    // 0x4fe8bc: r1 = Instance_CustomNum
    //     0x4fe8bc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x4fe8c0: ldr             x1, [x1, #0xef8]
    // 0x4fe8c4: r0 = pow()
    //     0x4fe8c4: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x4fe8c8: LeaveFrame
    //     0x4fe8c8: mov             SP, fp
    //     0x4fe8cc: ldp             fp, lr, [SP], #0x10
    // 0x4fe8d0: ret
    //     0x4fe8d0: ret             
    // 0x4fe8d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe8d4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe8d8: b               #0x4fe7a8
    // 0x4fe8dc: SaveReg d1
    //     0x4fe8dc: str             q1, [SP, #-0x10]!
    // 0x4fe8e0: r0 = AllocateDouble()
    //     0x4fe8e0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4fe8e4: mov             x2, x0
    // 0x4fe8e8: RestoreReg d1
    //     0x4fe8e8: ldr             q1, [SP], #0x10
    // 0x4fe8ec: b               #0x4fe8b8
  }
  _ postUpdateCallback(/* No info */) {
    // ** addr: 0x546f88, size: 0x470
    // 0x546f88: EnterFrame
    //     0x546f88: stp             fp, lr, [SP, #-0x10]!
    //     0x546f8c: mov             fp, SP
    // 0x546f90: AllocStack(0x30)
    //     0x546f90: sub             SP, SP, #0x30
    // 0x546f94: SetupParameters(Chapter15GameState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x546f94: stur            x1, [fp, #-8]
    //     0x546f98: stur            x2, [fp, #-0x10]
    // 0x546f9c: CheckStackOverflow
    //     0x546f9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x546fa0: cmp             SP, x16
    //     0x546fa4: b.ls            #0x5473ac
    // 0x546fa8: r1 = 2
    //     0x546fa8: movz            x1, #0x2
    // 0x546fac: r0 = AllocateContext()
    //     0x546fac: bl              #0x82637c  ; AllocateContextStub
    // 0x546fb0: mov             x2, x0
    // 0x546fb4: ldur            x0, [fp, #-8]
    // 0x546fb8: stur            x2, [fp, #-0x18]
    // 0x546fbc: StoreField: r2->field_f = r0
    //     0x546fbc: stur            w0, [x2, #0xf]
    // 0x546fc0: LoadField: r1 = r0->field_93
    //     0x546fc0: ldur            w1, [x0, #0x93]
    // 0x546fc4: DecompressPointer r1
    //     0x546fc4: add             x1, x1, HEAP, lsl #32
    // 0x546fc8: LoadField: r3 = r1->field_7
    //     0x546fc8: ldur            x3, [x1, #7]
    // 0x546fcc: cmp             x3, #0
    // 0x546fd0: b.le            #0x546fe4
    // 0x546fd4: ldur            x4, [fp, #-0x10]
    // 0x546fd8: sub             x5, x3, x4
    // 0x546fdc: StoreField: r1->field_7 = r5
    //     0x546fdc: stur            x5, [x1, #7]
    // 0x546fe0: b               #0x546fe8
    // 0x546fe4: ldur            x4, [fp, #-0x10]
    // 0x546fe8: mov             x1, x0
    // 0x546fec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x546fec: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x546ff0: r0 = efficientSymbolsBoost()
    //     0x546ff0: bl              #0x4fe210  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::efficientSymbolsBoost
    // 0x546ff4: r0 = inline_Allocate_Double()
    //     0x546ff4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x546ff8: add             x0, x0, #0x10
    //     0x546ffc: cmp             x1, x0
    //     0x547000: b.ls            #0x5473b4
    //     0x547004: str             x0, [THR, #0x60]  ; THR::top
    //     0x547008: sub             x0, x0, #0xf
    //     0x54700c: movz            x1, #0xe19c
    //     0x547010: movk            x1, #0x3, lsl #16
    //     0x547014: stur            x1, [x0, #-1]
    // 0x547018: dmb             ishst
    // 0x54701c: StoreField: r0->field_7 = d0
    //     0x54701c: stur            d0, [x0, #7]
    // 0x547020: ldur            x2, [fp, #-0x18]
    // 0x547024: StoreField: r2->field_13 = r0
    //     0x547024: stur            w0, [x2, #0x13]
    //     0x547028: ldurb           w16, [x2, #-1]
    //     0x54702c: ldurb           w17, [x0, #-1]
    //     0x547030: and             x16, x17, x16, lsr #2
    //     0x547034: tst             x16, HEAP, lsr #32
    //     0x547038: b.eq            #0x547040
    //     0x54703c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x547040: r1 = Function 'setBoost':.
    //     0x547040: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a650] AnonymousClosure: (0x5484d0), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::postUpdateCallback (0x546f88)
    //     0x547044: ldr             x1, [x1, #0x650]
    // 0x547048: r0 = AllocateClosure()
    //     0x547048: bl              #0x826750  ; AllocateClosureStub
    // 0x54704c: mov             x1, x0
    // 0x547050: stur            x1, [fp, #-0x18]
    // 0x547054: r16 = 2
    //     0x547054: movz            x16, #0x2
    // 0x547058: stp             x16, x1, [SP]
    // 0x54705c: mov             x0, x1
    // 0x547060: ClosureCall
    //     0x547060: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x547064: ldur            x2, [x0, #0x1f]
    //     0x547068: blr             x2
    // 0x54706c: ldur            x16, [fp, #-0x18]
    // 0x547070: r30 = 4
    //     0x547070: movz            lr, #0x4
    // 0x547074: stp             lr, x16, [SP]
    // 0x547078: ldur            x0, [fp, #-0x18]
    // 0x54707c: ClosureCall
    //     0x54707c: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x547080: ldur            x2, [x0, #0x1f]
    //     0x547084: blr             x2
    // 0x547088: ldur            x16, [fp, #-0x18]
    // 0x54708c: r30 = 6
    //     0x54708c: movz            lr, #0x6
    // 0x547090: stp             lr, x16, [SP]
    // 0x547094: ldur            x0, [fp, #-0x18]
    // 0x547098: ClosureCall
    //     0x547098: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x54709c: ldur            x2, [x0, #0x1f]
    //     0x5470a0: blr             x2
    // 0x5470a4: ldur            x16, [fp, #-0x18]
    // 0x5470a8: r30 = 8
    //     0x5470a8: movz            lr, #0x8
    // 0x5470ac: stp             lr, x16, [SP]
    // 0x5470b0: ldur            x0, [fp, #-0x18]
    // 0x5470b4: ClosureCall
    //     0x5470b4: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5470b8: ldur            x2, [x0, #0x1f]
    //     0x5470bc: blr             x2
    // 0x5470c0: ldur            x16, [fp, #-0x18]
    // 0x5470c4: r30 = 10
    //     0x5470c4: movz            lr, #0xa
    // 0x5470c8: stp             lr, x16, [SP]
    // 0x5470cc: ldur            x0, [fp, #-0x18]
    // 0x5470d0: ClosureCall
    //     0x5470d0: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5470d4: ldur            x2, [x0, #0x1f]
    //     0x5470d8: blr             x2
    // 0x5470dc: ldur            x16, [fp, #-0x18]
    // 0x5470e0: r30 = 12
    //     0x5470e0: movz            lr, #0xc
    // 0x5470e4: stp             lr, x16, [SP]
    // 0x5470e8: ldur            x0, [fp, #-0x18]
    // 0x5470ec: ClosureCall
    //     0x5470ec: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5470f0: ldur            x2, [x0, #0x1f]
    //     0x5470f4: blr             x2
    // 0x5470f8: ldur            x0, [fp, #-8]
    // 0x5470fc: LoadField: r1 = r0->field_43
    //     0x5470fc: ldur            w1, [x0, #0x43]
    // 0x547100: DecompressPointer r1
    //     0x547100: add             x1, x1, HEAP, lsl #32
    // 0x547104: r2 = 28
    //     0x547104: movz            x2, #0x1c
    // 0x547108: r0 = containsKey()
    //     0x547108: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x54710c: tbnz            w0, #4, #0x54739c
    // 0x547110: ldur            x0, [fp, #-8]
    // 0x547114: ldur            x1, [fp, #-0x10]
    // 0x547118: d1 = 0.000100
    //     0x547118: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfe0] IMM: double(1e-04) from 0x3f1a36e2eb1c432d
    //     0x54711c: ldr             d1, [x17, #0xfe0]
    // 0x547120: d0 = 0.001000
    //     0x547120: ldr             d0, [PP, #0x7490]  ; [pp+0x7490] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0x547124: scvtf           d2, x1
    // 0x547128: fmul            d3, d2, d0
    // 0x54712c: fmul            d0, d3, d1
    // 0x547130: stur            d0, [fp, #-0x20]
    // 0x547134: LoadField: r3 = r0->field_43
    //     0x547134: ldur            w3, [x0, #0x43]
    // 0x547138: DecompressPointer r3
    //     0x547138: add             x3, x3, HEAP, lsl #32
    // 0x54713c: mov             x1, x3
    // 0x547140: stur            x3, [fp, #-0x18]
    // 0x547144: r2 = 28
    //     0x547144: movz            x2, #0x1c
    // 0x547148: r0 = _getValueOrData()
    //     0x547148: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54714c: mov             x1, x0
    // 0x547150: ldur            x0, [fp, #-0x18]
    // 0x547154: LoadField: r2 = r0->field_f
    //     0x547154: ldur            w2, [x0, #0xf]
    // 0x547158: DecompressPointer r2
    //     0x547158: add             x2, x2, HEAP, lsl #32
    // 0x54715c: cmp             w2, w1
    // 0x547160: b.ne            #0x54716c
    // 0x547164: r0 = Null
    //     0x547164: mov             x0, NULL
    // 0x547168: b               #0x547170
    // 0x54716c: mov             x0, x1
    // 0x547170: cmp             w0, NULL
    // 0x547174: b.ne            #0x547180
    // 0x547178: r0 = 1
    //     0x547178: movz            x0, #0x1
    // 0x54717c: b               #0x547190
    // 0x547180: r1 = LoadInt32Instr(r0)
    //     0x547180: sbfx            x1, x0, #1, #0x1f
    //     0x547184: tbz             w0, #0, #0x54718c
    //     0x547188: ldur            x1, [x0, #7]
    // 0x54718c: mov             x0, x1
    // 0x547190: sub             x1, x0, #1
    // 0x547194: stur            x1, [fp, #-0x10]
    // 0x547198: tbnz            x1, #0x3f, #0x5471f4
    // 0x54719c: mov             x0, x1
    // 0x5471a0: r1 = 2
    //     0x5471a0: movz            x1, #0x2
    // 0x5471a4: r2 = 1
    //     0x5471a4: movz            x2, #0x1
    // 0x5471a8: CheckStackOverflow
    //     0x5471a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5471ac: cmp             SP, x16
    //     0x5471b0: b.ls            #0x5473c4
    // 0x5471b4: cbz             x0, #0x5471dc
    // 0x5471b8: branchIfSmi(r0, 0x5471c4)
    //     0x5471b8: tbz             w0, #0, #0x5471c4
    // 0x5471bc: mul             x3, x2, x1
    // 0x5471c0: mov             x2, x3
    // 0x5471c4: asr             x3, x0, #1
    // 0x5471c8: cbz             x3, #0x5471d4
    // 0x5471cc: mul             x4, x1, x1
    // 0x5471d0: mov             x1, x4
    // 0x5471d4: mov             x0, x3
    // 0x5471d8: b               #0x5471a8
    // 0x5471dc: r0 = BoxInt64Instr(r2)
    //     0x5471dc: sbfiz           x0, x2, #1, #0x1f
    //     0x5471e0: cmp             x2, x0, asr #1
    //     0x5471e4: b.eq            #0x5471f0
    //     0x5471e8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x5471ec: stur            x2, [x0, #7]
    // 0x5471f0: b               #0x547358
    // 0x5471f4: r16 = 4
    //     0x5471f4: movz            x16, #0x4
    // 0x5471f8: stp             x16, NULL, [SP]
    // 0x5471fc: r0 = _Double.fromInteger()
    //     0x5471fc: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x547200: mov             x3, x0
    // 0x547204: ldur            x2, [fp, #-0x10]
    // 0x547208: stur            x3, [fp, #-0x18]
    // 0x54720c: r0 = BoxInt64Instr(r2)
    //     0x54720c: sbfiz           x0, x2, #1, #0x1f
    //     0x547210: cmp             x2, x0, asr #1
    //     0x547214: b.eq            #0x547220
    //     0x547218: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x54721c: stur            x2, [x0, #7]
    // 0x547220: r1 = 60
    //     0x547220: movz            x1, #0x3c
    // 0x547224: branchIfSmi(r0, 0x547230)
    //     0x547224: tbz             w0, #0, #0x547230
    // 0x547228: r1 = LoadClassIdInstr(r0)
    //     0x547228: ldur            x1, [x0, #-1]
    //     0x54722c: ubfx            x1, x1, #0xc, #0x14
    // 0x547230: str             x0, [SP]
    // 0x547234: mov             x0, x1
    // 0x547238: r0 = GDT[cid_x0 + -0x1000]()
    //     0x547238: sub             lr, x0, #1, lsl #12
    //     0x54723c: ldr             lr, [x21, lr, lsl #3]
    //     0x547240: blr             lr
    // 0x547244: mov             x1, x0
    // 0x547248: ldur            x0, [fp, #-0x18]
    // 0x54724c: LoadField: d0 = r0->field_7
    //     0x54724c: ldur            d0, [x0, #7]
    // 0x547250: LoadField: d1 = r1->field_7
    //     0x547250: ldur            d1, [x1, #7]
    // 0x547254: d30 = 0.000000
    //     0x547254: fmov            d30, d0
    // 0x547258: d0 = 1.000000
    //     0x547258: fmov            d0, #1.00000000
    // 0x54725c: fcmp            d1, #0.0
    // 0x547260: b.vs            #0x5472a4
    // 0x547264: b.eq            #0x54732c
    // 0x547268: fcmp            d1, d0
    // 0x54726c: b.eq            #0x547294
    // 0x547270: d31 = 2.000000
    //     0x547270: fmov            d31, #2.00000000
    // 0x547274: fcmp            d1, d31
    // 0x547278: b.eq            #0x54729c
    // 0x54727c: d31 = 3.000000
    //     0x54727c: fmov            d31, #3.00000000
    // 0x547280: fcmp            d1, d31
    // 0x547284: b.ne            #0x5472a4
    // 0x547288: fmul            d0, d30, d30
    // 0x54728c: fmul            d0, d0, d30
    // 0x547290: b               #0x54732c
    // 0x547294: d0 = 0.000000
    //     0x547294: fmov            d0, d30
    // 0x547298: b               #0x54732c
    // 0x54729c: fmul            d0, d30, d30
    // 0x5472a0: b               #0x54732c
    // 0x5472a4: fcmp            d30, d0
    // 0x5472a8: b.vs            #0x5472b8
    // 0x5472ac: b.eq            #0x54732c
    // 0x5472b0: fcmp            d30, d1
    // 0x5472b4: b.vc            #0x5472c4
    // 0x5472b8: d0 = nan
    //     0x5472b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x5472bc: ldr             d0, [x17, #0xe48]
    // 0x5472c0: b               #0x54732c
    // 0x5472c4: d0 = -inf
    //     0x5472c4: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x5472c8: fcmp            d30, d0
    // 0x5472cc: b.eq            #0x5472f4
    // 0x5472d0: d0 = 0.500000
    //     0x5472d0: fmov            d0, #0.50000000
    // 0x5472d4: fcmp            d1, d0
    // 0x5472d8: b.ne            #0x5472f4
    // 0x5472dc: fcmp            d30, #0.0
    // 0x5472e0: b.eq            #0x5472ec
    // 0x5472e4: fsqrt           d0, d30
    // 0x5472e8: b               #0x54732c
    // 0x5472ec: d0 = 0.000000
    //     0x5472ec: eor             v0.16b, v0.16b, v0.16b
    // 0x5472f0: b               #0x54732c
    // 0x5472f4: d0 = 0.000000
    //     0x5472f4: fmov            d0, d30
    // 0x5472f8: stp             fp, lr, [SP, #-0x10]!
    // 0x5472fc: mov             fp, SP
    // 0x547300: CallRuntime_LibcPow(double, double) -> double
    //     0x547300: and             SP, SP, #0xfffffffffffffff0
    //     0x547304: mov             sp, SP
    //     0x547308: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x54730c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x547310: blr             x16
    //     0x547314: movz            x16, #0x8
    //     0x547318: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x54731c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x547320: sub             sp, x16, #1, lsl #12
    //     0x547324: mov             SP, fp
    //     0x547328: ldp             fp, lr, [SP], #0x10
    // 0x54732c: r0 = inline_Allocate_Double()
    //     0x54732c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547330: add             x0, x0, #0x10
    //     0x547334: cmp             x1, x0
    //     0x547338: b.ls            #0x5473cc
    //     0x54733c: str             x0, [THR, #0x60]  ; THR::top
    //     0x547340: sub             x0, x0, #0xf
    //     0x547344: movz            x1, #0xe19c
    //     0x547348: movk            x1, #0x3, lsl #16
    //     0x54734c: stur            x1, [x0, #-1]
    // 0x547350: dmb             ishst
    // 0x547354: StoreField: r0->field_7 = d0
    //     0x547354: stur            d0, [x0, #7]
    // 0x547358: ldur            d0, [fp, #-0x20]
    // 0x54735c: r1 = inline_Allocate_Double()
    //     0x54735c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x547360: add             x1, x1, #0x10
    //     0x547364: cmp             x2, x1
    //     0x547368: b.ls            #0x5473dc
    //     0x54736c: str             x1, [THR, #0x60]  ; THR::top
    //     0x547370: sub             x1, x1, #0xf
    //     0x547374: movz            x2, #0xe19c
    //     0x547378: movk            x2, #0x3, lsl #16
    //     0x54737c: stur            x2, [x1, #-1]
    // 0x547380: dmb             ishst
    // 0x547384: StoreField: r1->field_7 = d0
    //     0x547384: stur            d0, [x1, #7]
    // 0x547388: stp             x0, x1, [SP]
    // 0x54738c: r0 = *()
    //     0x54738c: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x547390: LoadField: d0 = r0->field_7
    //     0x547390: ldur            d0, [x0, #7]
    // 0x547394: ldur            x1, [fp, #-8]
    // 0x547398: r0 = generateSymbols()
    //     0x547398: bl              #0x5473f8  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::generateSymbols
    // 0x54739c: r0 = Null
    //     0x54739c: mov             x0, NULL
    // 0x5473a0: LeaveFrame
    //     0x5473a0: mov             SP, fp
    //     0x5473a4: ldp             fp, lr, [SP], #0x10
    // 0x5473a8: ret
    //     0x5473a8: ret             
    // 0x5473ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5473ac: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5473b0: b               #0x546fa8
    // 0x5473b4: SaveReg d0
    //     0x5473b4: str             q0, [SP, #-0x10]!
    // 0x5473b8: r0 = AllocateDouble()
    //     0x5473b8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5473bc: RestoreReg d0
    //     0x5473bc: ldr             q0, [SP], #0x10
    // 0x5473c0: b               #0x54701c
    // 0x5473c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5473c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5473c8: b               #0x5471b4
    // 0x5473cc: SaveReg d0
    //     0x5473cc: str             q0, [SP, #-0x10]!
    // 0x5473d0: r0 = AllocateDouble()
    //     0x5473d0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5473d4: RestoreReg d0
    //     0x5473d4: ldr             q0, [SP], #0x10
    // 0x5473d8: b               #0x547354
    // 0x5473dc: SaveReg d0
    //     0x5473dc: str             q0, [SP, #-0x10]!
    // 0x5473e0: SaveReg r0
    //     0x5473e0: str             x0, [SP, #-8]!
    // 0x5473e4: r0 = AllocateDouble()
    //     0x5473e4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5473e8: mov             x1, x0
    // 0x5473ec: RestoreReg r0
    //     0x5473ec: ldr             x0, [SP], #8
    // 0x5473f0: RestoreReg d0
    //     0x5473f0: ldr             q0, [SP], #0x10
    // 0x5473f4: b               #0x547384
  }
  _ generateSymbols(/* No info */) {
    // ** addr: 0x5473f8, size: 0x10d8
    // 0x5473f8: EnterFrame
    //     0x5473f8: stp             fp, lr, [SP, #-0x10]!
    //     0x5473fc: mov             fp, SP
    // 0x547400: AllocStack(0x58)
    //     0x547400: sub             SP, SP, #0x58
    // 0x547404: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x40 */)
    //     0x547404: mov             x0, x1
    //     0x547408: stur            x1, [fp, #-0x10]
    //     0x54740c: stur            d0, [fp, #-0x40]
    // 0x547410: CheckStackOverflow
    //     0x547410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x547414: cmp             SP, x16
    //     0x547418: b.ls            #0x5482f8
    // 0x54741c: LoadField: r1 = r0->field_3f
    //     0x54741c: ldur            w1, [x0, #0x3f]
    // 0x547420: DecompressPointer r1
    //     0x547420: add             x1, x1, HEAP, lsl #32
    // 0x547424: LoadField: r2 = r1->field_7
    //     0x547424: ldur            w2, [x1, #7]
    // 0x547428: DecompressPointer r2
    //     0x547428: add             x2, x2, HEAP, lsl #32
    // 0x54742c: cmp             w2, #2
    // 0x547430: b.ne            #0x547444
    // 0x547434: r0 = Null
    //     0x547434: mov             x0, NULL
    // 0x547438: LeaveFrame
    //     0x547438: mov             SP, fp
    //     0x54743c: ldp             fp, lr, [SP], #0x10
    // 0x547440: ret
    //     0x547440: ret             
    // 0x547444: LoadField: r3 = r0->field_37
    //     0x547444: ldur            w3, [x0, #0x37]
    // 0x547448: DecompressPointer r3
    //     0x547448: add             x3, x3, HEAP, lsl #32
    // 0x54744c: mov             x1, x3
    // 0x547450: stur            x3, [fp, #-8]
    // 0x547454: r2 = Instance_Chapter15Stat
    //     0x547454: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x547458: ldr             x2, [x2, #0x90]
    // 0x54745c: r0 = _getValueOrData()
    //     0x54745c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547460: ldur            x2, [fp, #-8]
    // 0x547464: LoadField: r1 = r2->field_f
    //     0x547464: ldur            w1, [x2, #0xf]
    // 0x547468: DecompressPointer r1
    //     0x547468: add             x1, x1, HEAP, lsl #32
    // 0x54746c: cmp             w1, w0
    // 0x547470: b.ne            #0x547478
    // 0x547474: r0 = Null
    //     0x547474: mov             x0, NULL
    // 0x547478: cmp             w0, NULL
    // 0x54747c: b.ne            #0x54748c
    // 0x547480: r5 = Instance_CustomNum
    //     0x547480: add             x5, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x547484: ldr             x5, [x5, #0xaf8]
    // 0x547488: b               #0x547490
    // 0x54748c: mov             x5, x0
    // 0x547490: ldur            x3, [fp, #-0x10]
    // 0x547494: stur            x5, [fp, #-0x20]
    // 0x547498: r0 = LoadStaticField(0xf7c)
    //     0x547498: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x54749c: ldr             x0, [x0, #0x1ef8]
    // 0x5474a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5474a4: cmp             w0, w16
    // 0x5474a8: b.eq            #0x548300
    // 0x5474ac: stur            x0, [fp, #-0x18]
    // 0x5474b0: LoadField: r1 = r3->field_23
    //     0x5474b0: ldur            x1, [x3, #0x23]
    // 0x5474b4: r0 = difficultyMultiplier()
    //     0x5474b4: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x5474b8: ldur            x1, [fp, #-0x18]
    // 0x5474bc: mov             x2, x0
    // 0x5474c0: r3 = "15"
    //     0x5474c0: add             x3, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x5474c4: ldr             x3, [x3, #0x348]
    // 0x5474c8: r0 = cachedCompletionTokenBoost()
    //     0x5474c8: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x5474cc: ldur            x1, [fp, #-0x10]
    // 0x5474d0: stur            x0, [fp, #-0x18]
    // 0x5474d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5474d4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5474d8: r0 = biggerSymbolBoost()
    //     0x5474d8: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x5474dc: ldur            x1, [fp, #-0x10]
    // 0x5474e0: stur            x0, [fp, #-0x28]
    // 0x5474e4: r0 = getStatBoosts()
    //     0x5474e4: bl              #0x55ce60  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getStatBoosts
    // 0x5474e8: mov             x1, x0
    // 0x5474ec: r2 = Instance_Chapter15Stat
    //     0x5474ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x5474f0: ldr             x2, [x2, #0x90]
    // 0x5474f4: stur            x0, [fp, #-0x30]
    // 0x5474f8: r0 = _getValueOrData()
    //     0x5474f8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5474fc: mov             x1, x0
    // 0x547500: ldur            x0, [fp, #-0x30]
    // 0x547504: LoadField: r2 = r0->field_f
    //     0x547504: ldur            w2, [x0, #0xf]
    // 0x547508: DecompressPointer r2
    //     0x547508: add             x2, x2, HEAP, lsl #32
    // 0x54750c: cmp             w2, w1
    // 0x547510: b.ne            #0x54751c
    // 0x547514: r0 = Null
    //     0x547514: mov             x0, NULL
    // 0x547518: b               #0x547520
    // 0x54751c: mov             x0, x1
    // 0x547520: cmp             w0, NULL
    // 0x547524: b.ne            #0x547534
    // 0x547528: r5 = Instance_CustomNum
    //     0x547528: add             x5, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54752c: ldr             x5, [x5, #0xa70]
    // 0x547530: b               #0x547538
    // 0x547534: mov             x5, x0
    // 0x547538: ldur            x0, [fp, #-0x10]
    // 0x54753c: ldur            d0, [fp, #-0x40]
    // 0x547540: stur            x5, [fp, #-0x38]
    // 0x547544: r3 = inline_Allocate_Double()
    //     0x547544: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x547548: add             x3, x3, #0x10
    //     0x54754c: cmp             x1, x3
    //     0x547550: b.ls            #0x54830c
    //     0x547554: str             x3, [THR, #0x60]  ; THR::top
    //     0x547558: sub             x3, x3, #0xf
    //     0x54755c: movz            x1, #0xe19c
    //     0x547560: movk            x1, #0x3, lsl #16
    //     0x547564: stur            x1, [x3, #-1]
    // 0x547568: dmb             ishst
    // 0x54756c: StoreField: r3->field_7 = d0
    //     0x54756c: stur            d0, [x3, #7]
    // 0x547570: mov             x2, x3
    // 0x547574: stur            x3, [fp, #-0x30]
    // 0x547578: r1 = Null
    //     0x547578: mov             x1, NULL
    // 0x54757c: r0 = CustomNum()
    //     0x54757c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x547580: ldur            x1, [fp, #-0x18]
    // 0x547584: ldur            x3, [fp, #-0x28]
    // 0x547588: ldur            x5, [fp, #-0x38]
    // 0x54758c: mov             x6, x0
    // 0x547590: r2 = Instance_CustomNum
    //     0x547590: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a658] Obj!CustomNum@82af61
    //     0x547594: ldr             x2, [x2, #0x658]
    // 0x547598: r0 = mult5()
    //     0x547598: bl              #0x3db218  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult5
    // 0x54759c: ldur            x1, [fp, #-0x20]
    // 0x5475a0: mov             x2, x0
    // 0x5475a4: r0 = add()
    //     0x5475a4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5475a8: ldur            x1, [fp, #-8]
    // 0x5475ac: mov             x3, x0
    // 0x5475b0: r2 = Instance_Chapter15Stat
    //     0x5475b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x5475b4: ldr             x2, [x2, #0x90]
    // 0x5475b8: r0 = []=()
    //     0x5475b8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5475bc: ldur            x0, [fp, #-0x10]
    // 0x5475c0: LoadField: r3 = r0->field_3b
    //     0x5475c0: ldur            w3, [x0, #0x3b]
    // 0x5475c4: DecompressPointer r3
    //     0x5475c4: add             x3, x3, HEAP, lsl #32
    // 0x5475c8: mov             x1, x3
    // 0x5475cc: stur            x3, [fp, #-8]
    // 0x5475d0: r2 = Instance_Chapter15Stat
    //     0x5475d0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x5475d4: ldr             x2, [x2, #0x90]
    // 0x5475d8: r0 = _getValueOrData()
    //     0x5475d8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5475dc: mov             x1, x0
    // 0x5475e0: ldur            x0, [fp, #-8]
    // 0x5475e4: LoadField: r2 = r0->field_f
    //     0x5475e4: ldur            w2, [x0, #0xf]
    // 0x5475e8: DecompressPointer r2
    //     0x5475e8: add             x2, x2, HEAP, lsl #32
    // 0x5475ec: cmp             w2, w1
    // 0x5475f0: b.ne            #0x5475f8
    // 0x5475f4: r1 = Null
    //     0x5475f4: mov             x1, NULL
    // 0x5475f8: cmp             w1, NULL
    // 0x5475fc: b.ne            #0x54760c
    // 0x547600: r3 = Instance_CustomNum
    //     0x547600: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x547604: ldr             x3, [x3, #0xaf8]
    // 0x547608: b               #0x547610
    // 0x54760c: mov             x3, x1
    // 0x547610: ldur            x2, [fp, #-0x10]
    // 0x547614: stur            x3, [fp, #-0x20]
    // 0x547618: r4 = LoadStaticField(0xf7c)
    //     0x547618: ldr             x4, [THR, #0x78]  ; THR::field_table_values
    //     0x54761c: ldr             x4, [x4, #0x1ef8]
    // 0x547620: stur            x4, [fp, #-0x18]
    // 0x547624: LoadField: r1 = r2->field_23
    //     0x547624: ldur            x1, [x2, #0x23]
    // 0x547628: r0 = difficultyMultiplier()
    //     0x547628: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x54762c: ldur            x1, [fp, #-0x18]
    // 0x547630: mov             x2, x0
    // 0x547634: r3 = "15"
    //     0x547634: add             x3, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x547638: ldr             x3, [x3, #0x348]
    // 0x54763c: r0 = cachedCompletionTokenBoost()
    //     0x54763c: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x547640: ldur            x1, [fp, #-0x10]
    // 0x547644: stur            x0, [fp, #-0x18]
    // 0x547648: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x547648: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x54764c: r0 = biggerSymbolBoost()
    //     0x54764c: bl              #0x4fe750  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::biggerSymbolBoost
    // 0x547650: ldur            x2, [fp, #-0x30]
    // 0x547654: r1 = Null
    //     0x547654: mov             x1, NULL
    // 0x547658: stur            x0, [fp, #-0x28]
    // 0x54765c: r0 = CustomNum()
    //     0x54765c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x547660: ldur            x1, [fp, #-0x18]
    // 0x547664: ldur            x3, [fp, #-0x28]
    // 0x547668: mov             x5, x0
    // 0x54766c: r2 = Instance_CustomNum
    //     0x54766c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a658] Obj!CustomNum@82af61
    //     0x547670: ldr             x2, [x2, #0x658]
    // 0x547674: r0 = mult4()
    //     0x547674: bl              #0x3dda04  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult4
    // 0x547678: ldur            x1, [fp, #-0x20]
    // 0x54767c: mov             x2, x0
    // 0x547680: r0 = add()
    //     0x547680: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x547684: ldur            x1, [fp, #-8]
    // 0x547688: mov             x3, x0
    // 0x54768c: r2 = Instance_Chapter15Stat
    //     0x54768c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x547690: ldr             x2, [x2, #0x90]
    // 0x547694: r0 = []=()
    //     0x547694: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x547698: ldur            x0, [fp, #-0x10]
    // 0x54769c: LoadField: r3 = r0->field_37
    //     0x54769c: ldur            w3, [x0, #0x37]
    // 0x5476a0: DecompressPointer r3
    //     0x5476a0: add             x3, x3, HEAP, lsl #32
    // 0x5476a4: mov             x1, x3
    // 0x5476a8: stur            x3, [fp, #-8]
    // 0x5476ac: r2 = Instance_Chapter15Stat
    //     0x5476ac: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x5476b0: ldr             x2, [x2, #0xfd8]
    // 0x5476b4: r0 = _getValueOrData()
    //     0x5476b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5476b8: mov             x1, x0
    // 0x5476bc: ldur            x0, [fp, #-8]
    // 0x5476c0: LoadField: r2 = r0->field_f
    //     0x5476c0: ldur            w2, [x0, #0xf]
    // 0x5476c4: DecompressPointer r2
    //     0x5476c4: add             x2, x2, HEAP, lsl #32
    // 0x5476c8: cmp             w2, w1
    // 0x5476cc: b.ne            #0x5476d4
    // 0x5476d0: r1 = Null
    //     0x5476d0: mov             x1, NULL
    // 0x5476d4: cmp             w1, NULL
    // 0x5476d8: b.ne            #0x5476e8
    // 0x5476dc: r4 = Instance_CustomNum
    //     0x5476dc: add             x4, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x5476e0: ldr             x4, [x4, #0xaf8]
    // 0x5476e4: b               #0x5476ec
    // 0x5476e8: mov             x4, x1
    // 0x5476ec: ldur            x3, [fp, #-0x10]
    // 0x5476f0: stur            x4, [fp, #-0x20]
    // 0x5476f4: LoadField: r5 = r3->field_43
    //     0x5476f4: ldur            w5, [x3, #0x43]
    // 0x5476f8: DecompressPointer r5
    //     0x5476f8: add             x5, x5, HEAP, lsl #32
    // 0x5476fc: mov             x1, x5
    // 0x547700: stur            x5, [fp, #-0x18]
    // 0x547704: r2 = 4
    //     0x547704: movz            x2, #0x4
    // 0x547708: r0 = _getValueOrData()
    //     0x547708: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54770c: mov             x1, x0
    // 0x547710: ldur            x0, [fp, #-0x18]
    // 0x547714: LoadField: r2 = r0->field_f
    //     0x547714: ldur            w2, [x0, #0xf]
    // 0x547718: DecompressPointer r2
    //     0x547718: add             x2, x2, HEAP, lsl #32
    // 0x54771c: cmp             w2, w1
    // 0x547720: b.ne            #0x54772c
    // 0x547724: r0 = Null
    //     0x547724: mov             x0, NULL
    // 0x547728: b               #0x547730
    // 0x54772c: mov             x0, x1
    // 0x547730: cmp             w0, NULL
    // 0x547734: b.ne            #0x547740
    // 0x547738: r1 = 0
    //     0x547738: movz            x1, #0
    // 0x54773c: b               #0x54774c
    // 0x547740: r1 = LoadInt32Instr(r0)
    //     0x547740: sbfx            x1, x0, #1, #0x1f
    //     0x547744: tbz             w0, #0, #0x54774c
    //     0x547748: ldur            x1, [x0, #7]
    // 0x54774c: ldur            x0, [fp, #-0x10]
    // 0x547750: ldur            d0, [fp, #-0x40]
    // 0x547754: d1 = 0.100000
    //     0x547754: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x547758: ldr             d1, [x17, #0xc30]
    // 0x54775c: scvtf           d2, x1
    // 0x547760: fmul            d3, d2, d1
    // 0x547764: mov             x1, x0
    // 0x547768: stur            d3, [fp, #-0x48]
    // 0x54776c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x54776c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x547770: r0 = bonusYieldBoost()
    //     0x547770: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x547774: mov             v1.16b, v0.16b
    // 0x547778: ldur            d0, [fp, #-0x48]
    // 0x54777c: fmul            d2, d0, d1
    // 0x547780: ldur            d0, [fp, #-0x40]
    // 0x547784: fmul            d1, d2, d0
    // 0x547788: r2 = inline_Allocate_Double()
    //     0x547788: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x54778c: add             x2, x2, #0x10
    //     0x547790: cmp             x0, x2
    //     0x547794: b.ls            #0x548328
    //     0x547798: str             x2, [THR, #0x60]  ; THR::top
    //     0x54779c: sub             x2, x2, #0xf
    //     0x5477a0: movz            x0, #0xe19c
    //     0x5477a4: movk            x0, #0x3, lsl #16
    //     0x5477a8: stur            x0, [x2, #-1]
    // 0x5477ac: dmb             ishst
    // 0x5477b0: StoreField: r2->field_7 = d1
    //     0x5477b0: stur            d1, [x2, #7]
    // 0x5477b4: r1 = Null
    //     0x5477b4: mov             x1, NULL
    // 0x5477b8: r0 = CustomNum()
    //     0x5477b8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5477bc: ldur            x1, [fp, #-0x20]
    // 0x5477c0: mov             x2, x0
    // 0x5477c4: r0 = add()
    //     0x5477c4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5477c8: ldur            x1, [fp, #-8]
    // 0x5477cc: mov             x3, x0
    // 0x5477d0: r2 = Instance_Chapter15Stat
    //     0x5477d0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x5477d4: ldr             x2, [x2, #0xfd8]
    // 0x5477d8: r0 = []=()
    //     0x5477d8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5477dc: ldur            x0, [fp, #-0x10]
    // 0x5477e0: LoadField: r3 = r0->field_37
    //     0x5477e0: ldur            w3, [x0, #0x37]
    // 0x5477e4: DecompressPointer r3
    //     0x5477e4: add             x3, x3, HEAP, lsl #32
    // 0x5477e8: mov             x1, x3
    // 0x5477ec: stur            x3, [fp, #-8]
    // 0x5477f0: r2 = Instance_Chapter15Stat
    //     0x5477f0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x5477f4: ldr             x2, [x2, #0xfe0]
    // 0x5477f8: r0 = _getValueOrData()
    //     0x5477f8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5477fc: mov             x1, x0
    // 0x547800: ldur            x0, [fp, #-8]
    // 0x547804: LoadField: r2 = r0->field_f
    //     0x547804: ldur            w2, [x0, #0xf]
    // 0x547808: DecompressPointer r2
    //     0x547808: add             x2, x2, HEAP, lsl #32
    // 0x54780c: cmp             w2, w1
    // 0x547810: b.ne            #0x547818
    // 0x547814: r1 = Null
    //     0x547814: mov             x1, NULL
    // 0x547818: cmp             w1, NULL
    // 0x54781c: b.ne            #0x54782c
    // 0x547820: r4 = Instance_CustomNum
    //     0x547820: add             x4, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x547824: ldr             x4, [x4, #0xaf8]
    // 0x547828: b               #0x547830
    // 0x54782c: mov             x4, x1
    // 0x547830: ldur            x3, [fp, #-0x10]
    // 0x547834: stur            x4, [fp, #-0x20]
    // 0x547838: LoadField: r5 = r3->field_43
    //     0x547838: ldur            w5, [x3, #0x43]
    // 0x54783c: DecompressPointer r5
    //     0x54783c: add             x5, x5, HEAP, lsl #32
    // 0x547840: mov             x1, x5
    // 0x547844: stur            x5, [fp, #-0x18]
    // 0x547848: r2 = 4
    //     0x547848: movz            x2, #0x4
    // 0x54784c: r0 = _getValueOrData()
    //     0x54784c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547850: mov             x1, x0
    // 0x547854: ldur            x0, [fp, #-0x18]
    // 0x547858: LoadField: r2 = r0->field_f
    //     0x547858: ldur            w2, [x0, #0xf]
    // 0x54785c: DecompressPointer r2
    //     0x54785c: add             x2, x2, HEAP, lsl #32
    // 0x547860: cmp             w2, w1
    // 0x547864: b.ne            #0x547870
    // 0x547868: r0 = Null
    //     0x547868: mov             x0, NULL
    // 0x54786c: b               #0x547874
    // 0x547870: mov             x0, x1
    // 0x547874: cmp             w0, NULL
    // 0x547878: b.ne            #0x547884
    // 0x54787c: r0 = 0
    //     0x54787c: movz            x0, #0
    // 0x547880: b               #0x547894
    // 0x547884: r1 = LoadInt32Instr(r0)
    //     0x547884: sbfx            x1, x0, #1, #0x1f
    //     0x547888: tbz             w0, #0, #0x547890
    //     0x54788c: ldur            x1, [x0, #7]
    // 0x547890: mov             x0, x1
    // 0x547894: d1 = 0.000000
    //     0x547894: eor             v1.16b, v1.16b, v1.16b
    // 0x547898: d0 = 0.100000
    //     0x547898: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x54789c: ldr             d0, [x17, #0xc30]
    // 0x5478a0: sub             x1, x0, #1
    // 0x5478a4: scvtf           d2, x1
    // 0x5478a8: fmul            d3, d2, d0
    // 0x5478ac: fcmp            d3, d1
    // 0x5478b0: b.le            #0x5478e8
    // 0x5478b4: r0 = inline_Allocate_Double()
    //     0x5478b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5478b8: add             x0, x0, #0x10
    //     0x5478bc: cmp             x1, x0
    //     0x5478c0: b.ls            #0x54833c
    //     0x5478c4: str             x0, [THR, #0x60]  ; THR::top
    //     0x5478c8: sub             x0, x0, #0xf
    //     0x5478cc: movz            x1, #0xe19c
    //     0x5478d0: movk            x1, #0x3, lsl #16
    //     0x5478d4: stur            x1, [x0, #-1]
    // 0x5478d8: dmb             ishst
    // 0x5478dc: StoreField: r0->field_7 = d3
    //     0x5478dc: stur            d3, [x0, #7]
    // 0x5478e0: mov             x2, x0
    // 0x5478e4: b               #0x547948
    // 0x5478e8: fcmp            d1, d3
    // 0x5478ec: b.le            #0x5478f8
    // 0x5478f0: r2 = 0
    //     0x5478f0: movz            x2, #0
    // 0x5478f4: b               #0x547948
    // 0x5478f8: fcmp            d3, #0.0
    // 0x5478fc: b.vs            #0x547918
    // 0x547900: b.ne            #0x54790c
    // 0x547904: r0 = 0.000000
    //     0x547904: fmov            x0, d3
    // 0x547908: cmp             x0, #0
    // 0x54790c: b.ge            #0x547918
    // 0x547910: r2 = 0
    //     0x547910: movz            x2, #0
    // 0x547914: b               #0x547948
    // 0x547918: r0 = inline_Allocate_Double()
    //     0x547918: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x54791c: add             x0, x0, #0x10
    //     0x547920: cmp             x1, x0
    //     0x547924: b.ls            #0x548354
    //     0x547928: str             x0, [THR, #0x60]  ; THR::top
    //     0x54792c: sub             x0, x0, #0xf
    //     0x547930: movz            x1, #0xe19c
    //     0x547934: movk            x1, #0x3, lsl #16
    //     0x547938: stur            x1, [x0, #-1]
    // 0x54793c: dmb             ishst
    // 0x547940: StoreField: r0->field_7 = d3
    //     0x547940: stur            d3, [x0, #7]
    // 0x547944: mov             x2, x0
    // 0x547948: ldur            x0, [fp, #-0x10]
    // 0x54794c: ldur            d2, [fp, #-0x40]
    // 0x547950: mov             x1, x0
    // 0x547954: stur            x2, [fp, #-0x18]
    // 0x547958: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x547958: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x54795c: r0 = bonusYieldBoost()
    //     0x54795c: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x547960: r0 = inline_Allocate_Double()
    //     0x547960: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547964: add             x0, x0, #0x10
    //     0x547968: cmp             x1, x0
    //     0x54796c: b.ls            #0x54836c
    //     0x547970: str             x0, [THR, #0x60]  ; THR::top
    //     0x547974: sub             x0, x0, #0xf
    //     0x547978: movz            x1, #0xe19c
    //     0x54797c: movk            x1, #0x3, lsl #16
    //     0x547980: stur            x1, [x0, #-1]
    // 0x547984: dmb             ishst
    // 0x547988: StoreField: r0->field_7 = d0
    //     0x547988: stur            d0, [x0, #7]
    // 0x54798c: ldur            x1, [fp, #-0x18]
    // 0x547990: r2 = 60
    //     0x547990: movz            x2, #0x3c
    // 0x547994: branchIfSmi(r1, 0x5479a0)
    //     0x547994: tbz             w1, #0, #0x5479a0
    // 0x547998: r2 = LoadClassIdInstr(r1)
    //     0x547998: ldur            x2, [x1, #-1]
    //     0x54799c: ubfx            x2, x2, #0xc, #0x14
    // 0x5479a0: stp             x0, x1, [SP]
    // 0x5479a4: mov             x0, x2
    // 0x5479a8: r0 = GDT[cid_x0 + -0xffd]()
    //     0x5479a8: sub             lr, x0, #0xffd
    //     0x5479ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5479b0: blr             lr
    // 0x5479b4: LoadField: d0 = r0->field_7
    //     0x5479b4: ldur            d0, [x0, #7]
    // 0x5479b8: ldur            d1, [fp, #-0x40]
    // 0x5479bc: fmul            d2, d0, d1
    // 0x5479c0: r2 = inline_Allocate_Double()
    //     0x5479c0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x5479c4: add             x2, x2, #0x10
    //     0x5479c8: cmp             x0, x2
    //     0x5479cc: b.ls            #0x54837c
    //     0x5479d0: str             x2, [THR, #0x60]  ; THR::top
    //     0x5479d4: sub             x2, x2, #0xf
    //     0x5479d8: movz            x0, #0xe19c
    //     0x5479dc: movk            x0, #0x3, lsl #16
    //     0x5479e0: stur            x0, [x2, #-1]
    // 0x5479e4: dmb             ishst
    // 0x5479e8: StoreField: r2->field_7 = d2
    //     0x5479e8: stur            d2, [x2, #7]
    // 0x5479ec: r1 = Null
    //     0x5479ec: mov             x1, NULL
    // 0x5479f0: r0 = CustomNum()
    //     0x5479f0: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5479f4: ldur            x1, [fp, #-0x20]
    // 0x5479f8: mov             x2, x0
    // 0x5479fc: r0 = add()
    //     0x5479fc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x547a00: ldur            x1, [fp, #-8]
    // 0x547a04: mov             x3, x0
    // 0x547a08: r2 = Instance_Chapter15Stat
    //     0x547a08: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x547a0c: ldr             x2, [x2, #0xfe0]
    // 0x547a10: r0 = []=()
    //     0x547a10: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x547a14: ldur            x0, [fp, #-0x10]
    // 0x547a18: LoadField: r3 = r0->field_37
    //     0x547a18: ldur            w3, [x0, #0x37]
    // 0x547a1c: DecompressPointer r3
    //     0x547a1c: add             x3, x3, HEAP, lsl #32
    // 0x547a20: mov             x1, x3
    // 0x547a24: stur            x3, [fp, #-8]
    // 0x547a28: r2 = Instance_Chapter15Stat
    //     0x547a28: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x547a2c: ldr             x2, [x2, #0xfe8]
    // 0x547a30: r0 = _getValueOrData()
    //     0x547a30: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547a34: mov             x1, x0
    // 0x547a38: ldur            x0, [fp, #-8]
    // 0x547a3c: LoadField: r2 = r0->field_f
    //     0x547a3c: ldur            w2, [x0, #0xf]
    // 0x547a40: DecompressPointer r2
    //     0x547a40: add             x2, x2, HEAP, lsl #32
    // 0x547a44: cmp             w2, w1
    // 0x547a48: b.ne            #0x547a50
    // 0x547a4c: r1 = Null
    //     0x547a4c: mov             x1, NULL
    // 0x547a50: cmp             w1, NULL
    // 0x547a54: b.ne            #0x547a64
    // 0x547a58: r4 = Instance_CustomNum
    //     0x547a58: add             x4, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x547a5c: ldr             x4, [x4, #0xaf8]
    // 0x547a60: b               #0x547a68
    // 0x547a64: mov             x4, x1
    // 0x547a68: ldur            x3, [fp, #-0x10]
    // 0x547a6c: stur            x4, [fp, #-0x20]
    // 0x547a70: LoadField: r5 = r3->field_43
    //     0x547a70: ldur            w5, [x3, #0x43]
    // 0x547a74: DecompressPointer r5
    //     0x547a74: add             x5, x5, HEAP, lsl #32
    // 0x547a78: mov             x1, x5
    // 0x547a7c: stur            x5, [fp, #-0x18]
    // 0x547a80: r2 = 4
    //     0x547a80: movz            x2, #0x4
    // 0x547a84: r0 = _getValueOrData()
    //     0x547a84: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547a88: mov             x1, x0
    // 0x547a8c: ldur            x0, [fp, #-0x18]
    // 0x547a90: LoadField: r2 = r0->field_f
    //     0x547a90: ldur            w2, [x0, #0xf]
    // 0x547a94: DecompressPointer r2
    //     0x547a94: add             x2, x2, HEAP, lsl #32
    // 0x547a98: cmp             w2, w1
    // 0x547a9c: b.ne            #0x547aa8
    // 0x547aa0: r0 = Null
    //     0x547aa0: mov             x0, NULL
    // 0x547aa4: b               #0x547aac
    // 0x547aa8: mov             x0, x1
    // 0x547aac: cmp             w0, NULL
    // 0x547ab0: b.ne            #0x547abc
    // 0x547ab4: r0 = 0
    //     0x547ab4: movz            x0, #0
    // 0x547ab8: b               #0x547acc
    // 0x547abc: r1 = LoadInt32Instr(r0)
    //     0x547abc: sbfx            x1, x0, #1, #0x1f
    //     0x547ac0: tbz             w0, #0, #0x547ac8
    //     0x547ac4: ldur            x1, [x0, #7]
    // 0x547ac8: mov             x0, x1
    // 0x547acc: d1 = 0.000000
    //     0x547acc: eor             v1.16b, v1.16b, v1.16b
    // 0x547ad0: d0 = 0.100000
    //     0x547ad0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x547ad4: ldr             d0, [x17, #0xc30]
    // 0x547ad8: sub             x1, x0, #2
    // 0x547adc: scvtf           d2, x1
    // 0x547ae0: fmul            d3, d2, d0
    // 0x547ae4: fcmp            d3, d1
    // 0x547ae8: b.le            #0x547b20
    // 0x547aec: r0 = inline_Allocate_Double()
    //     0x547aec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547af0: add             x0, x0, #0x10
    //     0x547af4: cmp             x1, x0
    //     0x547af8: b.ls            #0x548390
    //     0x547afc: str             x0, [THR, #0x60]  ; THR::top
    //     0x547b00: sub             x0, x0, #0xf
    //     0x547b04: movz            x1, #0xe19c
    //     0x547b08: movk            x1, #0x3, lsl #16
    //     0x547b0c: stur            x1, [x0, #-1]
    // 0x547b10: dmb             ishst
    // 0x547b14: StoreField: r0->field_7 = d3
    //     0x547b14: stur            d3, [x0, #7]
    // 0x547b18: mov             x2, x0
    // 0x547b1c: b               #0x547b80
    // 0x547b20: fcmp            d1, d3
    // 0x547b24: b.le            #0x547b30
    // 0x547b28: r2 = 0
    //     0x547b28: movz            x2, #0
    // 0x547b2c: b               #0x547b80
    // 0x547b30: fcmp            d3, #0.0
    // 0x547b34: b.vs            #0x547b50
    // 0x547b38: b.ne            #0x547b44
    // 0x547b3c: r0 = 0.000000
    //     0x547b3c: fmov            x0, d3
    // 0x547b40: cmp             x0, #0
    // 0x547b44: b.ge            #0x547b50
    // 0x547b48: r2 = 0
    //     0x547b48: movz            x2, #0
    // 0x547b4c: b               #0x547b80
    // 0x547b50: r0 = inline_Allocate_Double()
    //     0x547b50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547b54: add             x0, x0, #0x10
    //     0x547b58: cmp             x1, x0
    //     0x547b5c: b.ls            #0x5483a8
    //     0x547b60: str             x0, [THR, #0x60]  ; THR::top
    //     0x547b64: sub             x0, x0, #0xf
    //     0x547b68: movz            x1, #0xe19c
    //     0x547b6c: movk            x1, #0x3, lsl #16
    //     0x547b70: stur            x1, [x0, #-1]
    // 0x547b74: dmb             ishst
    // 0x547b78: StoreField: r0->field_7 = d3
    //     0x547b78: stur            d3, [x0, #7]
    // 0x547b7c: mov             x2, x0
    // 0x547b80: ldur            x0, [fp, #-0x10]
    // 0x547b84: ldur            d2, [fp, #-0x40]
    // 0x547b88: mov             x1, x0
    // 0x547b8c: stur            x2, [fp, #-0x18]
    // 0x547b90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x547b90: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x547b94: r0 = bonusYieldBoost()
    //     0x547b94: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x547b98: r0 = inline_Allocate_Double()
    //     0x547b98: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547b9c: add             x0, x0, #0x10
    //     0x547ba0: cmp             x1, x0
    //     0x547ba4: b.ls            #0x5483c0
    //     0x547ba8: str             x0, [THR, #0x60]  ; THR::top
    //     0x547bac: sub             x0, x0, #0xf
    //     0x547bb0: movz            x1, #0xe19c
    //     0x547bb4: movk            x1, #0x3, lsl #16
    //     0x547bb8: stur            x1, [x0, #-1]
    // 0x547bbc: dmb             ishst
    // 0x547bc0: StoreField: r0->field_7 = d0
    //     0x547bc0: stur            d0, [x0, #7]
    // 0x547bc4: ldur            x1, [fp, #-0x18]
    // 0x547bc8: r2 = 60
    //     0x547bc8: movz            x2, #0x3c
    // 0x547bcc: branchIfSmi(r1, 0x547bd8)
    //     0x547bcc: tbz             w1, #0, #0x547bd8
    // 0x547bd0: r2 = LoadClassIdInstr(r1)
    //     0x547bd0: ldur            x2, [x1, #-1]
    //     0x547bd4: ubfx            x2, x2, #0xc, #0x14
    // 0x547bd8: stp             x0, x1, [SP]
    // 0x547bdc: mov             x0, x2
    // 0x547be0: r0 = GDT[cid_x0 + -0xffd]()
    //     0x547be0: sub             lr, x0, #0xffd
    //     0x547be4: ldr             lr, [x21, lr, lsl #3]
    //     0x547be8: blr             lr
    // 0x547bec: LoadField: d0 = r0->field_7
    //     0x547bec: ldur            d0, [x0, #7]
    // 0x547bf0: ldur            d1, [fp, #-0x40]
    // 0x547bf4: fmul            d2, d0, d1
    // 0x547bf8: r2 = inline_Allocate_Double()
    //     0x547bf8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x547bfc: add             x2, x2, #0x10
    //     0x547c00: cmp             x0, x2
    //     0x547c04: b.ls            #0x5483d0
    //     0x547c08: str             x2, [THR, #0x60]  ; THR::top
    //     0x547c0c: sub             x2, x2, #0xf
    //     0x547c10: movz            x0, #0xe19c
    //     0x547c14: movk            x0, #0x3, lsl #16
    //     0x547c18: stur            x0, [x2, #-1]
    // 0x547c1c: dmb             ishst
    // 0x547c20: StoreField: r2->field_7 = d2
    //     0x547c20: stur            d2, [x2, #7]
    // 0x547c24: r1 = Null
    //     0x547c24: mov             x1, NULL
    // 0x547c28: r0 = CustomNum()
    //     0x547c28: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x547c2c: ldur            x1, [fp, #-0x20]
    // 0x547c30: mov             x2, x0
    // 0x547c34: r0 = add()
    //     0x547c34: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x547c38: ldur            x1, [fp, #-8]
    // 0x547c3c: mov             x3, x0
    // 0x547c40: r2 = Instance_Chapter15Stat
    //     0x547c40: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x547c44: ldr             x2, [x2, #0xfe8]
    // 0x547c48: r0 = []=()
    //     0x547c48: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x547c4c: ldur            x0, [fp, #-0x10]
    // 0x547c50: LoadField: r3 = r0->field_37
    //     0x547c50: ldur            w3, [x0, #0x37]
    // 0x547c54: DecompressPointer r3
    //     0x547c54: add             x3, x3, HEAP, lsl #32
    // 0x547c58: mov             x1, x3
    // 0x547c5c: stur            x3, [fp, #-8]
    // 0x547c60: r2 = Instance_Chapter15Stat
    //     0x547c60: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x547c64: ldr             x2, [x2, #0xff0]
    // 0x547c68: r0 = _getValueOrData()
    //     0x547c68: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547c6c: mov             x1, x0
    // 0x547c70: ldur            x0, [fp, #-8]
    // 0x547c74: LoadField: r2 = r0->field_f
    //     0x547c74: ldur            w2, [x0, #0xf]
    // 0x547c78: DecompressPointer r2
    //     0x547c78: add             x2, x2, HEAP, lsl #32
    // 0x547c7c: cmp             w2, w1
    // 0x547c80: b.ne            #0x547c88
    // 0x547c84: r1 = Null
    //     0x547c84: mov             x1, NULL
    // 0x547c88: cmp             w1, NULL
    // 0x547c8c: b.ne            #0x547c9c
    // 0x547c90: r4 = Instance_CustomNum
    //     0x547c90: add             x4, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x547c94: ldr             x4, [x4, #0xaf8]
    // 0x547c98: b               #0x547ca0
    // 0x547c9c: mov             x4, x1
    // 0x547ca0: ldur            x3, [fp, #-0x10]
    // 0x547ca4: stur            x4, [fp, #-0x20]
    // 0x547ca8: LoadField: r5 = r3->field_43
    //     0x547ca8: ldur            w5, [x3, #0x43]
    // 0x547cac: DecompressPointer r5
    //     0x547cac: add             x5, x5, HEAP, lsl #32
    // 0x547cb0: mov             x1, x5
    // 0x547cb4: stur            x5, [fp, #-0x18]
    // 0x547cb8: r2 = 4
    //     0x547cb8: movz            x2, #0x4
    // 0x547cbc: r0 = _getValueOrData()
    //     0x547cbc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547cc0: mov             x1, x0
    // 0x547cc4: ldur            x0, [fp, #-0x18]
    // 0x547cc8: LoadField: r2 = r0->field_f
    //     0x547cc8: ldur            w2, [x0, #0xf]
    // 0x547ccc: DecompressPointer r2
    //     0x547ccc: add             x2, x2, HEAP, lsl #32
    // 0x547cd0: cmp             w2, w1
    // 0x547cd4: b.ne            #0x547ce0
    // 0x547cd8: r0 = Null
    //     0x547cd8: mov             x0, NULL
    // 0x547cdc: b               #0x547ce4
    // 0x547ce0: mov             x0, x1
    // 0x547ce4: cmp             w0, NULL
    // 0x547ce8: b.ne            #0x547cf4
    // 0x547cec: r0 = 0
    //     0x547cec: movz            x0, #0
    // 0x547cf0: b               #0x547d04
    // 0x547cf4: r1 = LoadInt32Instr(r0)
    //     0x547cf4: sbfx            x1, x0, #1, #0x1f
    //     0x547cf8: tbz             w0, #0, #0x547d00
    //     0x547cfc: ldur            x1, [x0, #7]
    // 0x547d00: mov             x0, x1
    // 0x547d04: d1 = 0.000000
    //     0x547d04: eor             v1.16b, v1.16b, v1.16b
    // 0x547d08: d0 = 0.100000
    //     0x547d08: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x547d0c: ldr             d0, [x17, #0xc30]
    // 0x547d10: sub             x1, x0, #3
    // 0x547d14: scvtf           d2, x1
    // 0x547d18: fmul            d3, d2, d0
    // 0x547d1c: fcmp            d3, d1
    // 0x547d20: b.le            #0x547d58
    // 0x547d24: r0 = inline_Allocate_Double()
    //     0x547d24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547d28: add             x0, x0, #0x10
    //     0x547d2c: cmp             x1, x0
    //     0x547d30: b.ls            #0x5483e4
    //     0x547d34: str             x0, [THR, #0x60]  ; THR::top
    //     0x547d38: sub             x0, x0, #0xf
    //     0x547d3c: movz            x1, #0xe19c
    //     0x547d40: movk            x1, #0x3, lsl #16
    //     0x547d44: stur            x1, [x0, #-1]
    // 0x547d48: dmb             ishst
    // 0x547d4c: StoreField: r0->field_7 = d3
    //     0x547d4c: stur            d3, [x0, #7]
    // 0x547d50: mov             x2, x0
    // 0x547d54: b               #0x547db8
    // 0x547d58: fcmp            d1, d3
    // 0x547d5c: b.le            #0x547d68
    // 0x547d60: r2 = 0
    //     0x547d60: movz            x2, #0
    // 0x547d64: b               #0x547db8
    // 0x547d68: fcmp            d3, #0.0
    // 0x547d6c: b.vs            #0x547d88
    // 0x547d70: b.ne            #0x547d7c
    // 0x547d74: r0 = 0.000000
    //     0x547d74: fmov            x0, d3
    // 0x547d78: cmp             x0, #0
    // 0x547d7c: b.ge            #0x547d88
    // 0x547d80: r2 = 0
    //     0x547d80: movz            x2, #0
    // 0x547d84: b               #0x547db8
    // 0x547d88: r0 = inline_Allocate_Double()
    //     0x547d88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547d8c: add             x0, x0, #0x10
    //     0x547d90: cmp             x1, x0
    //     0x547d94: b.ls            #0x5483fc
    //     0x547d98: str             x0, [THR, #0x60]  ; THR::top
    //     0x547d9c: sub             x0, x0, #0xf
    //     0x547da0: movz            x1, #0xe19c
    //     0x547da4: movk            x1, #0x3, lsl #16
    //     0x547da8: stur            x1, [x0, #-1]
    // 0x547dac: dmb             ishst
    // 0x547db0: StoreField: r0->field_7 = d3
    //     0x547db0: stur            d3, [x0, #7]
    // 0x547db4: mov             x2, x0
    // 0x547db8: ldur            x0, [fp, #-0x10]
    // 0x547dbc: ldur            d2, [fp, #-0x40]
    // 0x547dc0: mov             x1, x0
    // 0x547dc4: stur            x2, [fp, #-0x18]
    // 0x547dc8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x547dc8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x547dcc: r0 = bonusYieldBoost()
    //     0x547dcc: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x547dd0: r0 = inline_Allocate_Double()
    //     0x547dd0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547dd4: add             x0, x0, #0x10
    //     0x547dd8: cmp             x1, x0
    //     0x547ddc: b.ls            #0x548414
    //     0x547de0: str             x0, [THR, #0x60]  ; THR::top
    //     0x547de4: sub             x0, x0, #0xf
    //     0x547de8: movz            x1, #0xe19c
    //     0x547dec: movk            x1, #0x3, lsl #16
    //     0x547df0: stur            x1, [x0, #-1]
    // 0x547df4: dmb             ishst
    // 0x547df8: StoreField: r0->field_7 = d0
    //     0x547df8: stur            d0, [x0, #7]
    // 0x547dfc: ldur            x1, [fp, #-0x18]
    // 0x547e00: r2 = 60
    //     0x547e00: movz            x2, #0x3c
    // 0x547e04: branchIfSmi(r1, 0x547e10)
    //     0x547e04: tbz             w1, #0, #0x547e10
    // 0x547e08: r2 = LoadClassIdInstr(r1)
    //     0x547e08: ldur            x2, [x1, #-1]
    //     0x547e0c: ubfx            x2, x2, #0xc, #0x14
    // 0x547e10: stp             x0, x1, [SP]
    // 0x547e14: mov             x0, x2
    // 0x547e18: r0 = GDT[cid_x0 + -0xffd]()
    //     0x547e18: sub             lr, x0, #0xffd
    //     0x547e1c: ldr             lr, [x21, lr, lsl #3]
    //     0x547e20: blr             lr
    // 0x547e24: LoadField: d0 = r0->field_7
    //     0x547e24: ldur            d0, [x0, #7]
    // 0x547e28: ldur            d1, [fp, #-0x40]
    // 0x547e2c: fmul            d2, d0, d1
    // 0x547e30: r2 = inline_Allocate_Double()
    //     0x547e30: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x547e34: add             x2, x2, #0x10
    //     0x547e38: cmp             x0, x2
    //     0x547e3c: b.ls            #0x548424
    //     0x547e40: str             x2, [THR, #0x60]  ; THR::top
    //     0x547e44: sub             x2, x2, #0xf
    //     0x547e48: movz            x0, #0xe19c
    //     0x547e4c: movk            x0, #0x3, lsl #16
    //     0x547e50: stur            x0, [x2, #-1]
    // 0x547e54: dmb             ishst
    // 0x547e58: StoreField: r2->field_7 = d2
    //     0x547e58: stur            d2, [x2, #7]
    // 0x547e5c: r1 = Null
    //     0x547e5c: mov             x1, NULL
    // 0x547e60: r0 = CustomNum()
    //     0x547e60: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x547e64: ldur            x1, [fp, #-0x20]
    // 0x547e68: mov             x2, x0
    // 0x547e6c: r0 = add()
    //     0x547e6c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x547e70: ldur            x1, [fp, #-8]
    // 0x547e74: mov             x3, x0
    // 0x547e78: r2 = Instance_Chapter15Stat
    //     0x547e78: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x547e7c: ldr             x2, [x2, #0xff0]
    // 0x547e80: r0 = []=()
    //     0x547e80: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x547e84: ldur            x0, [fp, #-0x10]
    // 0x547e88: LoadField: r3 = r0->field_37
    //     0x547e88: ldur            w3, [x0, #0x37]
    // 0x547e8c: DecompressPointer r3
    //     0x547e8c: add             x3, x3, HEAP, lsl #32
    // 0x547e90: mov             x1, x3
    // 0x547e94: stur            x3, [fp, #-8]
    // 0x547e98: r2 = Instance_Chapter15Stat
    //     0x547e98: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x547e9c: ldr             x2, [x2, #0xff8]
    // 0x547ea0: r0 = _getValueOrData()
    //     0x547ea0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547ea4: mov             x1, x0
    // 0x547ea8: ldur            x0, [fp, #-8]
    // 0x547eac: LoadField: r2 = r0->field_f
    //     0x547eac: ldur            w2, [x0, #0xf]
    // 0x547eb0: DecompressPointer r2
    //     0x547eb0: add             x2, x2, HEAP, lsl #32
    // 0x547eb4: cmp             w2, w1
    // 0x547eb8: b.ne            #0x547ec0
    // 0x547ebc: r1 = Null
    //     0x547ebc: mov             x1, NULL
    // 0x547ec0: cmp             w1, NULL
    // 0x547ec4: b.ne            #0x547ed4
    // 0x547ec8: r4 = Instance_CustomNum
    //     0x547ec8: add             x4, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x547ecc: ldr             x4, [x4, #0xaf8]
    // 0x547ed0: b               #0x547ed8
    // 0x547ed4: mov             x4, x1
    // 0x547ed8: ldur            x3, [fp, #-0x10]
    // 0x547edc: stur            x4, [fp, #-0x20]
    // 0x547ee0: LoadField: r5 = r3->field_43
    //     0x547ee0: ldur            w5, [x3, #0x43]
    // 0x547ee4: DecompressPointer r5
    //     0x547ee4: add             x5, x5, HEAP, lsl #32
    // 0x547ee8: mov             x1, x5
    // 0x547eec: stur            x5, [fp, #-0x18]
    // 0x547ef0: r2 = 4
    //     0x547ef0: movz            x2, #0x4
    // 0x547ef4: r0 = _getValueOrData()
    //     0x547ef4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x547ef8: mov             x1, x0
    // 0x547efc: ldur            x0, [fp, #-0x18]
    // 0x547f00: LoadField: r2 = r0->field_f
    //     0x547f00: ldur            w2, [x0, #0xf]
    // 0x547f04: DecompressPointer r2
    //     0x547f04: add             x2, x2, HEAP, lsl #32
    // 0x547f08: cmp             w2, w1
    // 0x547f0c: b.ne            #0x547f18
    // 0x547f10: r0 = Null
    //     0x547f10: mov             x0, NULL
    // 0x547f14: b               #0x547f1c
    // 0x547f18: mov             x0, x1
    // 0x547f1c: cmp             w0, NULL
    // 0x547f20: b.ne            #0x547f2c
    // 0x547f24: r0 = 0
    //     0x547f24: movz            x0, #0
    // 0x547f28: b               #0x547f3c
    // 0x547f2c: r1 = LoadInt32Instr(r0)
    //     0x547f2c: sbfx            x1, x0, #1, #0x1f
    //     0x547f30: tbz             w0, #0, #0x547f38
    //     0x547f34: ldur            x1, [x0, #7]
    // 0x547f38: mov             x0, x1
    // 0x547f3c: d1 = 0.000000
    //     0x547f3c: eor             v1.16b, v1.16b, v1.16b
    // 0x547f40: d0 = 0.100000
    //     0x547f40: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x547f44: ldr             d0, [x17, #0xc30]
    // 0x547f48: sub             x1, x0, #4
    // 0x547f4c: scvtf           d2, x1
    // 0x547f50: fmul            d3, d2, d0
    // 0x547f54: fcmp            d3, d1
    // 0x547f58: b.le            #0x547f90
    // 0x547f5c: r0 = inline_Allocate_Double()
    //     0x547f5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547f60: add             x0, x0, #0x10
    //     0x547f64: cmp             x1, x0
    //     0x547f68: b.ls            #0x548438
    //     0x547f6c: str             x0, [THR, #0x60]  ; THR::top
    //     0x547f70: sub             x0, x0, #0xf
    //     0x547f74: movz            x1, #0xe19c
    //     0x547f78: movk            x1, #0x3, lsl #16
    //     0x547f7c: stur            x1, [x0, #-1]
    // 0x547f80: dmb             ishst
    // 0x547f84: StoreField: r0->field_7 = d3
    //     0x547f84: stur            d3, [x0, #7]
    // 0x547f88: mov             x2, x0
    // 0x547f8c: b               #0x547ff0
    // 0x547f90: fcmp            d1, d3
    // 0x547f94: b.le            #0x547fa0
    // 0x547f98: r2 = 0
    //     0x547f98: movz            x2, #0
    // 0x547f9c: b               #0x547ff0
    // 0x547fa0: fcmp            d3, #0.0
    // 0x547fa4: b.vs            #0x547fc0
    // 0x547fa8: b.ne            #0x547fb4
    // 0x547fac: r0 = 0.000000
    //     0x547fac: fmov            x0, d3
    // 0x547fb0: cmp             x0, #0
    // 0x547fb4: b.ge            #0x547fc0
    // 0x547fb8: r2 = 0
    //     0x547fb8: movz            x2, #0
    // 0x547fbc: b               #0x547ff0
    // 0x547fc0: r0 = inline_Allocate_Double()
    //     0x547fc0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x547fc4: add             x0, x0, #0x10
    //     0x547fc8: cmp             x1, x0
    //     0x547fcc: b.ls            #0x548450
    //     0x547fd0: str             x0, [THR, #0x60]  ; THR::top
    //     0x547fd4: sub             x0, x0, #0xf
    //     0x547fd8: movz            x1, #0xe19c
    //     0x547fdc: movk            x1, #0x3, lsl #16
    //     0x547fe0: stur            x1, [x0, #-1]
    // 0x547fe4: dmb             ishst
    // 0x547fe8: StoreField: r0->field_7 = d3
    //     0x547fe8: stur            d3, [x0, #7]
    // 0x547fec: mov             x2, x0
    // 0x547ff0: ldur            x0, [fp, #-0x10]
    // 0x547ff4: ldur            d2, [fp, #-0x40]
    // 0x547ff8: mov             x1, x0
    // 0x547ffc: stur            x2, [fp, #-0x18]
    // 0x548000: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x548000: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x548004: r0 = bonusYieldBoost()
    //     0x548004: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x548008: r0 = inline_Allocate_Double()
    //     0x548008: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x54800c: add             x0, x0, #0x10
    //     0x548010: cmp             x1, x0
    //     0x548014: b.ls            #0x548468
    //     0x548018: str             x0, [THR, #0x60]  ; THR::top
    //     0x54801c: sub             x0, x0, #0xf
    //     0x548020: movz            x1, #0xe19c
    //     0x548024: movk            x1, #0x3, lsl #16
    //     0x548028: stur            x1, [x0, #-1]
    // 0x54802c: dmb             ishst
    // 0x548030: StoreField: r0->field_7 = d0
    //     0x548030: stur            d0, [x0, #7]
    // 0x548034: ldur            x1, [fp, #-0x18]
    // 0x548038: r2 = 60
    //     0x548038: movz            x2, #0x3c
    // 0x54803c: branchIfSmi(r1, 0x548048)
    //     0x54803c: tbz             w1, #0, #0x548048
    // 0x548040: r2 = LoadClassIdInstr(r1)
    //     0x548040: ldur            x2, [x1, #-1]
    //     0x548044: ubfx            x2, x2, #0xc, #0x14
    // 0x548048: stp             x0, x1, [SP]
    // 0x54804c: mov             x0, x2
    // 0x548050: r0 = GDT[cid_x0 + -0xffd]()
    //     0x548050: sub             lr, x0, #0xffd
    //     0x548054: ldr             lr, [x21, lr, lsl #3]
    //     0x548058: blr             lr
    // 0x54805c: LoadField: d0 = r0->field_7
    //     0x54805c: ldur            d0, [x0, #7]
    // 0x548060: ldur            d1, [fp, #-0x40]
    // 0x548064: fmul            d2, d0, d1
    // 0x548068: r2 = inline_Allocate_Double()
    //     0x548068: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x54806c: add             x2, x2, #0x10
    //     0x548070: cmp             x0, x2
    //     0x548074: b.ls            #0x548478
    //     0x548078: str             x2, [THR, #0x60]  ; THR::top
    //     0x54807c: sub             x2, x2, #0xf
    //     0x548080: movz            x0, #0xe19c
    //     0x548084: movk            x0, #0x3, lsl #16
    //     0x548088: stur            x0, [x2, #-1]
    // 0x54808c: dmb             ishst
    // 0x548090: StoreField: r2->field_7 = d2
    //     0x548090: stur            d2, [x2, #7]
    // 0x548094: r1 = Null
    //     0x548094: mov             x1, NULL
    // 0x548098: r0 = CustomNum()
    //     0x548098: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x54809c: ldur            x1, [fp, #-0x20]
    // 0x5480a0: mov             x2, x0
    // 0x5480a4: r0 = add()
    //     0x5480a4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5480a8: ldur            x1, [fp, #-8]
    // 0x5480ac: mov             x3, x0
    // 0x5480b0: r2 = Instance_Chapter15Stat
    //     0x5480b0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x5480b4: ldr             x2, [x2, #0xff8]
    // 0x5480b8: r0 = []=()
    //     0x5480b8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5480bc: ldur            x0, [fp, #-0x10]
    // 0x5480c0: LoadField: r3 = r0->field_37
    //     0x5480c0: ldur            w3, [x0, #0x37]
    // 0x5480c4: DecompressPointer r3
    //     0x5480c4: add             x3, x3, HEAP, lsl #32
    // 0x5480c8: mov             x1, x3
    // 0x5480cc: stur            x3, [fp, #-8]
    // 0x5480d0: r2 = Instance_Chapter15Stat
    //     0x5480d0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x5480d4: ldr             x2, [x2]
    // 0x5480d8: r0 = _getValueOrData()
    //     0x5480d8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5480dc: mov             x1, x0
    // 0x5480e0: ldur            x0, [fp, #-8]
    // 0x5480e4: LoadField: r2 = r0->field_f
    //     0x5480e4: ldur            w2, [x0, #0xf]
    // 0x5480e8: DecompressPointer r2
    //     0x5480e8: add             x2, x2, HEAP, lsl #32
    // 0x5480ec: cmp             w2, w1
    // 0x5480f0: b.ne            #0x5480f8
    // 0x5480f4: r1 = Null
    //     0x5480f4: mov             x1, NULL
    // 0x5480f8: cmp             w1, NULL
    // 0x5480fc: b.ne            #0x54810c
    // 0x548100: r4 = Instance_CustomNum
    //     0x548100: add             x4, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x548104: ldr             x4, [x4, #0xaf8]
    // 0x548108: b               #0x548110
    // 0x54810c: mov             x4, x1
    // 0x548110: ldur            x3, [fp, #-0x10]
    // 0x548114: stur            x4, [fp, #-0x20]
    // 0x548118: LoadField: r5 = r3->field_43
    //     0x548118: ldur            w5, [x3, #0x43]
    // 0x54811c: DecompressPointer r5
    //     0x54811c: add             x5, x5, HEAP, lsl #32
    // 0x548120: mov             x1, x5
    // 0x548124: stur            x5, [fp, #-0x18]
    // 0x548128: r2 = 4
    //     0x548128: movz            x2, #0x4
    // 0x54812c: r0 = _getValueOrData()
    //     0x54812c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x548130: mov             x1, x0
    // 0x548134: ldur            x0, [fp, #-0x18]
    // 0x548138: LoadField: r2 = r0->field_f
    //     0x548138: ldur            w2, [x0, #0xf]
    // 0x54813c: DecompressPointer r2
    //     0x54813c: add             x2, x2, HEAP, lsl #32
    // 0x548140: cmp             w2, w1
    // 0x548144: b.ne            #0x548150
    // 0x548148: r0 = Null
    //     0x548148: mov             x0, NULL
    // 0x54814c: b               #0x548154
    // 0x548150: mov             x0, x1
    // 0x548154: cmp             w0, NULL
    // 0x548158: b.ne            #0x548164
    // 0x54815c: r0 = 0
    //     0x54815c: movz            x0, #0
    // 0x548160: b               #0x548174
    // 0x548164: r1 = LoadInt32Instr(r0)
    //     0x548164: sbfx            x1, x0, #1, #0x1f
    //     0x548168: tbz             w0, #0, #0x548170
    //     0x54816c: ldur            x1, [x0, #7]
    // 0x548170: mov             x0, x1
    // 0x548174: d1 = 0.000000
    //     0x548174: eor             v1.16b, v1.16b, v1.16b
    // 0x548178: d0 = 0.100000
    //     0x548178: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x54817c: ldr             d0, [x17, #0xc30]
    // 0x548180: sub             x1, x0, #5
    // 0x548184: scvtf           d2, x1
    // 0x548188: fmul            d3, d2, d0
    // 0x54818c: fcmp            d3, d1
    // 0x548190: b.le            #0x5481c4
    // 0x548194: r0 = inline_Allocate_Double()
    //     0x548194: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x548198: add             x0, x0, #0x10
    //     0x54819c: cmp             x1, x0
    //     0x5481a0: b.ls            #0x54848c
    //     0x5481a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x5481a8: sub             x0, x0, #0xf
    //     0x5481ac: movz            x1, #0xe19c
    //     0x5481b0: movk            x1, #0x3, lsl #16
    //     0x5481b4: stur            x1, [x0, #-1]
    // 0x5481b8: dmb             ishst
    // 0x5481bc: StoreField: r0->field_7 = d3
    //     0x5481bc: stur            d3, [x0, #7]
    // 0x5481c0: b               #0x548220
    // 0x5481c4: fcmp            d1, d3
    // 0x5481c8: b.le            #0x5481d4
    // 0x5481cc: r0 = 0
    //     0x5481cc: movz            x0, #0
    // 0x5481d0: b               #0x548220
    // 0x5481d4: fcmp            d3, #0.0
    // 0x5481d8: b.vs            #0x5481f4
    // 0x5481dc: b.ne            #0x5481e8
    // 0x5481e0: r0 = 0.000000
    //     0x5481e0: fmov            x0, d3
    // 0x5481e4: cmp             x0, #0
    // 0x5481e8: b.ge            #0x5481f4
    // 0x5481ec: r0 = 0
    //     0x5481ec: movz            x0, #0
    // 0x5481f0: b               #0x548220
    // 0x5481f4: r0 = inline_Allocate_Double()
    //     0x5481f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5481f8: add             x0, x0, #0x10
    //     0x5481fc: cmp             x1, x0
    //     0x548200: b.ls            #0x54849c
    //     0x548204: str             x0, [THR, #0x60]  ; THR::top
    //     0x548208: sub             x0, x0, #0xf
    //     0x54820c: movz            x1, #0xe19c
    //     0x548210: movk            x1, #0x3, lsl #16
    //     0x548214: stur            x1, [x0, #-1]
    // 0x548218: dmb             ishst
    // 0x54821c: StoreField: r0->field_7 = d3
    //     0x54821c: stur            d3, [x0, #7]
    // 0x548220: ldur            d0, [fp, #-0x40]
    // 0x548224: ldur            x1, [fp, #-0x10]
    // 0x548228: stur            x0, [fp, #-0x18]
    // 0x54822c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x54822c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x548230: r0 = bonusYieldBoost()
    //     0x548230: bl              #0x4fe5f4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::bonusYieldBoost
    // 0x548234: r0 = inline_Allocate_Double()
    //     0x548234: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x548238: add             x0, x0, #0x10
    //     0x54823c: cmp             x1, x0
    //     0x548240: b.ls            #0x5484ac
    //     0x548244: str             x0, [THR, #0x60]  ; THR::top
    //     0x548248: sub             x0, x0, #0xf
    //     0x54824c: movz            x1, #0xe19c
    //     0x548250: movk            x1, #0x3, lsl #16
    //     0x548254: stur            x1, [x0, #-1]
    // 0x548258: dmb             ishst
    // 0x54825c: StoreField: r0->field_7 = d0
    //     0x54825c: stur            d0, [x0, #7]
    // 0x548260: ldur            x1, [fp, #-0x18]
    // 0x548264: r2 = 60
    //     0x548264: movz            x2, #0x3c
    // 0x548268: branchIfSmi(r1, 0x548274)
    //     0x548268: tbz             w1, #0, #0x548274
    // 0x54826c: r2 = LoadClassIdInstr(r1)
    //     0x54826c: ldur            x2, [x1, #-1]
    //     0x548270: ubfx            x2, x2, #0xc, #0x14
    // 0x548274: stp             x0, x1, [SP]
    // 0x548278: mov             x0, x2
    // 0x54827c: r0 = GDT[cid_x0 + -0xffd]()
    //     0x54827c: sub             lr, x0, #0xffd
    //     0x548280: ldr             lr, [x21, lr, lsl #3]
    //     0x548284: blr             lr
    // 0x548288: LoadField: d0 = r0->field_7
    //     0x548288: ldur            d0, [x0, #7]
    // 0x54828c: ldur            d1, [fp, #-0x40]
    // 0x548290: fmul            d2, d0, d1
    // 0x548294: r2 = inline_Allocate_Double()
    //     0x548294: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x548298: add             x2, x2, #0x10
    //     0x54829c: cmp             x0, x2
    //     0x5482a0: b.ls            #0x5484bc
    //     0x5482a4: str             x2, [THR, #0x60]  ; THR::top
    //     0x5482a8: sub             x2, x2, #0xf
    //     0x5482ac: movz            x0, #0xe19c
    //     0x5482b0: movk            x0, #0x3, lsl #16
    //     0x5482b4: stur            x0, [x2, #-1]
    // 0x5482b8: dmb             ishst
    // 0x5482bc: StoreField: r2->field_7 = d2
    //     0x5482bc: stur            d2, [x2, #7]
    // 0x5482c0: r1 = Null
    //     0x5482c0: mov             x1, NULL
    // 0x5482c4: r0 = CustomNum()
    //     0x5482c4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5482c8: ldur            x1, [fp, #-0x20]
    // 0x5482cc: mov             x2, x0
    // 0x5482d0: r0 = add()
    //     0x5482d0: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5482d4: ldur            x1, [fp, #-8]
    // 0x5482d8: mov             x3, x0
    // 0x5482dc: r2 = Instance_Chapter15Stat
    //     0x5482dc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x5482e0: ldr             x2, [x2]
    // 0x5482e4: r0 = []=()
    //     0x5482e4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5482e8: r0 = Null
    //     0x5482e8: mov             x0, NULL
    // 0x5482ec: LeaveFrame
    //     0x5482ec: mov             SP, fp
    //     0x5482f0: ldp             fp, lr, [SP], #0x10
    // 0x5482f4: ret
    //     0x5482f4: ret             
    // 0x5482f8: r0 = StackOverflowSharedWithFPURegs()
    //     0x5482f8: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x5482fc: b               #0x54741c
    // 0x548300: r9 = coreData
    //     0x548300: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x548304: ldr             x9, [x9, #0x530]
    // 0x548308: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x548308: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x54830c: SaveReg d0
    //     0x54830c: str             q0, [SP, #-0x10]!
    // 0x548310: stp             x0, x5, [SP, #-0x10]!
    // 0x548314: r0 = AllocateDouble()
    //     0x548314: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548318: mov             x3, x0
    // 0x54831c: ldp             x0, x5, [SP], #0x10
    // 0x548320: RestoreReg d0
    //     0x548320: ldr             q0, [SP], #0x10
    // 0x548324: b               #0x54756c
    // 0x548328: stp             q0, q1, [SP, #-0x20]!
    // 0x54832c: r0 = AllocateDouble()
    //     0x54832c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548330: mov             x2, x0
    // 0x548334: ldp             q0, q1, [SP], #0x20
    // 0x548338: b               #0x5477b0
    // 0x54833c: stp             q1, q3, [SP, #-0x20]!
    // 0x548340: SaveReg d0
    //     0x548340: str             q0, [SP, #-0x10]!
    // 0x548344: r0 = AllocateDouble()
    //     0x548344: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548348: RestoreReg d0
    //     0x548348: ldr             q0, [SP], #0x10
    // 0x54834c: ldp             q1, q3, [SP], #0x20
    // 0x548350: b               #0x5478dc
    // 0x548354: stp             q1, q3, [SP, #-0x20]!
    // 0x548358: SaveReg d0
    //     0x548358: str             q0, [SP, #-0x10]!
    // 0x54835c: r0 = AllocateDouble()
    //     0x54835c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548360: RestoreReg d0
    //     0x548360: ldr             q0, [SP], #0x10
    // 0x548364: ldp             q1, q3, [SP], #0x20
    // 0x548368: b               #0x547940
    // 0x54836c: SaveReg d0
    //     0x54836c: str             q0, [SP, #-0x10]!
    // 0x548370: r0 = AllocateDouble()
    //     0x548370: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548374: RestoreReg d0
    //     0x548374: ldr             q0, [SP], #0x10
    // 0x548378: b               #0x547988
    // 0x54837c: stp             q1, q2, [SP, #-0x20]!
    // 0x548380: r0 = AllocateDouble()
    //     0x548380: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548384: mov             x2, x0
    // 0x548388: ldp             q1, q2, [SP], #0x20
    // 0x54838c: b               #0x5479e8
    // 0x548390: stp             q1, q3, [SP, #-0x20]!
    // 0x548394: SaveReg d0
    //     0x548394: str             q0, [SP, #-0x10]!
    // 0x548398: r0 = AllocateDouble()
    //     0x548398: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x54839c: RestoreReg d0
    //     0x54839c: ldr             q0, [SP], #0x10
    // 0x5483a0: ldp             q1, q3, [SP], #0x20
    // 0x5483a4: b               #0x547b14
    // 0x5483a8: stp             q1, q3, [SP, #-0x20]!
    // 0x5483ac: SaveReg d0
    //     0x5483ac: str             q0, [SP, #-0x10]!
    // 0x5483b0: r0 = AllocateDouble()
    //     0x5483b0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5483b4: RestoreReg d0
    //     0x5483b4: ldr             q0, [SP], #0x10
    // 0x5483b8: ldp             q1, q3, [SP], #0x20
    // 0x5483bc: b               #0x547b78
    // 0x5483c0: SaveReg d0
    //     0x5483c0: str             q0, [SP, #-0x10]!
    // 0x5483c4: r0 = AllocateDouble()
    //     0x5483c4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5483c8: RestoreReg d0
    //     0x5483c8: ldr             q0, [SP], #0x10
    // 0x5483cc: b               #0x547bc0
    // 0x5483d0: stp             q1, q2, [SP, #-0x20]!
    // 0x5483d4: r0 = AllocateDouble()
    //     0x5483d4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5483d8: mov             x2, x0
    // 0x5483dc: ldp             q1, q2, [SP], #0x20
    // 0x5483e0: b               #0x547c20
    // 0x5483e4: stp             q1, q3, [SP, #-0x20]!
    // 0x5483e8: SaveReg d0
    //     0x5483e8: str             q0, [SP, #-0x10]!
    // 0x5483ec: r0 = AllocateDouble()
    //     0x5483ec: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5483f0: RestoreReg d0
    //     0x5483f0: ldr             q0, [SP], #0x10
    // 0x5483f4: ldp             q1, q3, [SP], #0x20
    // 0x5483f8: b               #0x547d4c
    // 0x5483fc: stp             q1, q3, [SP, #-0x20]!
    // 0x548400: SaveReg d0
    //     0x548400: str             q0, [SP, #-0x10]!
    // 0x548404: r0 = AllocateDouble()
    //     0x548404: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548408: RestoreReg d0
    //     0x548408: ldr             q0, [SP], #0x10
    // 0x54840c: ldp             q1, q3, [SP], #0x20
    // 0x548410: b               #0x547db0
    // 0x548414: SaveReg d0
    //     0x548414: str             q0, [SP, #-0x10]!
    // 0x548418: r0 = AllocateDouble()
    //     0x548418: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x54841c: RestoreReg d0
    //     0x54841c: ldr             q0, [SP], #0x10
    // 0x548420: b               #0x547df8
    // 0x548424: stp             q1, q2, [SP, #-0x20]!
    // 0x548428: r0 = AllocateDouble()
    //     0x548428: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x54842c: mov             x2, x0
    // 0x548430: ldp             q1, q2, [SP], #0x20
    // 0x548434: b               #0x547e58
    // 0x548438: stp             q1, q3, [SP, #-0x20]!
    // 0x54843c: SaveReg d0
    //     0x54843c: str             q0, [SP, #-0x10]!
    // 0x548440: r0 = AllocateDouble()
    //     0x548440: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548444: RestoreReg d0
    //     0x548444: ldr             q0, [SP], #0x10
    // 0x548448: ldp             q1, q3, [SP], #0x20
    // 0x54844c: b               #0x547f84
    // 0x548450: stp             q1, q3, [SP, #-0x20]!
    // 0x548454: SaveReg d0
    //     0x548454: str             q0, [SP, #-0x10]!
    // 0x548458: r0 = AllocateDouble()
    //     0x548458: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x54845c: RestoreReg d0
    //     0x54845c: ldr             q0, [SP], #0x10
    // 0x548460: ldp             q1, q3, [SP], #0x20
    // 0x548464: b               #0x547fe8
    // 0x548468: SaveReg d0
    //     0x548468: str             q0, [SP, #-0x10]!
    // 0x54846c: r0 = AllocateDouble()
    //     0x54846c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548470: RestoreReg d0
    //     0x548470: ldr             q0, [SP], #0x10
    // 0x548474: b               #0x548030
    // 0x548478: stp             q1, q2, [SP, #-0x20]!
    // 0x54847c: r0 = AllocateDouble()
    //     0x54847c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548480: mov             x2, x0
    // 0x548484: ldp             q1, q2, [SP], #0x20
    // 0x548488: b               #0x548090
    // 0x54848c: SaveReg d3
    //     0x54848c: str             q3, [SP, #-0x10]!
    // 0x548490: r0 = AllocateDouble()
    //     0x548490: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x548494: RestoreReg d3
    //     0x548494: ldr             q3, [SP], #0x10
    // 0x548498: b               #0x5481bc
    // 0x54849c: SaveReg d3
    //     0x54849c: str             q3, [SP, #-0x10]!
    // 0x5484a0: r0 = AllocateDouble()
    //     0x5484a0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5484a4: RestoreReg d3
    //     0x5484a4: ldr             q3, [SP], #0x10
    // 0x5484a8: b               #0x54821c
    // 0x5484ac: SaveReg d0
    //     0x5484ac: str             q0, [SP, #-0x10]!
    // 0x5484b0: r0 = AllocateDouble()
    //     0x5484b0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5484b4: RestoreReg d0
    //     0x5484b4: ldr             q0, [SP], #0x10
    // 0x5484b8: b               #0x54825c
    // 0x5484bc: SaveReg d2
    //     0x5484bc: str             q2, [SP, #-0x10]!
    // 0x5484c0: r0 = AllocateDouble()
    //     0x5484c0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5484c4: mov             x2, x0
    // 0x5484c8: RestoreReg d2
    //     0x5484c8: ldr             q2, [SP], #0x10
    // 0x5484cc: b               #0x5482bc
  }
  [closure] void setBoost(dynamic, int) {
    // ** addr: 0x5484d0, size: 0x15c
    // 0x5484d0: EnterFrame
    //     0x5484d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5484d4: mov             fp, SP
    // 0x5484d8: AllocStack(0x28)
    //     0x5484d8: sub             SP, SP, #0x28
    // 0x5484dc: SetupParameters([dynamic _ /* r0 */])
    //     0x5484dc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd108] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0x5484e0: ldr             d0, [x17, #0x108]
    //     0x5484e4: ldr             x0, [fp, #0x18]
    //     0x5484e8: ldur            w1, [x0, #0x17]
    //     0x5484ec: add             x1, x1, HEAP, lsl #32
    // 0x5484dc: d0 = 0.010000
    // 0x5484f0: CheckStackOverflow
    //     0x5484f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5484f4: cmp             SP, x16
    //     0x5484f8: b.ls            #0x548608
    // 0x5484fc: LoadField: r0 = r1->field_f
    //     0x5484fc: ldur            w0, [x1, #0xf]
    // 0x548500: DecompressPointer r0
    //     0x548500: add             x0, x0, HEAP, lsl #32
    // 0x548504: LoadField: r3 = r0->field_33
    //     0x548504: ldur            w3, [x0, #0x33]
    // 0x548508: DecompressPointer r3
    //     0x548508: add             x3, x3, HEAP, lsl #32
    // 0x54850c: stur            x3, [fp, #-0x10]
    // 0x548510: LoadField: r2 = r1->field_13
    //     0x548510: ldur            w2, [x1, #0x13]
    // 0x548514: DecompressPointer r2
    //     0x548514: add             x2, x2, HEAP, lsl #32
    // 0x548518: LoadField: d1 = r2->field_7
    //     0x548518: ldur            d1, [x2, #7]
    // 0x54851c: fmul            d2, d1, d0
    // 0x548520: stur            d2, [fp, #-0x18]
    // 0x548524: LoadField: r4 = r0->field_47
    //     0x548524: ldur            w4, [x0, #0x47]
    // 0x548528: DecompressPointer r4
    //     0x548528: add             x4, x4, HEAP, lsl #32
    // 0x54852c: mov             x1, x4
    // 0x548530: ldr             x2, [fp, #0x10]
    // 0x548534: stur            x4, [fp, #-8]
    // 0x548538: r0 = _getValueOrData()
    //     0x548538: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54853c: mov             x1, x0
    // 0x548540: ldur            x0, [fp, #-8]
    // 0x548544: LoadField: r2 = r0->field_f
    //     0x548544: ldur            w2, [x0, #0xf]
    // 0x548548: DecompressPointer r2
    //     0x548548: add             x2, x2, HEAP, lsl #32
    // 0x54854c: cmp             w2, w1
    // 0x548550: b.ne            #0x54855c
    // 0x548554: r0 = Null
    //     0x548554: mov             x0, NULL
    // 0x548558: b               #0x548560
    // 0x54855c: mov             x0, x1
    // 0x548560: cmp             w0, NULL
    // 0x548564: b.ne            #0x54856c
    // 0x548568: r0 = 0
    //     0x548568: movz            x0, #0
    // 0x54856c: ldur            d0, [fp, #-0x18]
    // 0x548570: r1 = inline_Allocate_Double()
    //     0x548570: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x548574: add             x1, x1, #0x10
    //     0x548578: cmp             x2, x1
    //     0x54857c: b.ls            #0x548610
    //     0x548580: str             x1, [THR, #0x60]  ; THR::top
    //     0x548584: sub             x1, x1, #0xf
    //     0x548588: movz            x2, #0xe19c
    //     0x54858c: movk            x2, #0x3, lsl #16
    //     0x548590: stur            x2, [x1, #-1]
    // 0x548594: dmb             ishst
    // 0x548598: StoreField: r1->field_7 = d0
    //     0x548598: stur            d0, [x1, #7]
    // 0x54859c: stp             x0, x1, [SP]
    // 0x5485a0: r0 = *()
    //     0x5485a0: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x5485a4: mov             x2, x0
    // 0x5485a8: r1 = Null
    //     0x5485a8: mov             x1, NULL
    // 0x5485ac: r0 = CustomNum()
    //     0x5485ac: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x5485b0: mov             x2, x0
    // 0x5485b4: r1 = Instance_CustomNum
    //     0x5485b4: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x5485b8: ldr             x1, [x1, #0xa70]
    // 0x5485bc: r0 = add()
    //     0x5485bc: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x5485c0: stur            x0, [fp, #-8]
    // 0x5485c4: r0 = Boost()
    //     0x5485c4: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x5485c8: mov             x1, x0
    // 0x5485cc: r0 = Instance_CustomNum
    //     0x5485cc: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x5485d0: ldr             x0, [x0, #0xa70]
    // 0x5485d4: StoreField: r1->field_7 = r0
    //     0x5485d4: stur            w0, [x1, #7]
    // 0x5485d8: StoreField: r1->field_b = r0
    //     0x5485d8: stur            w0, [x1, #0xb]
    // 0x5485dc: ldur            x2, [fp, #-8]
    // 0x5485e0: StoreField: r1->field_f = r2
    //     0x5485e0: stur            w2, [x1, #0xf]
    // 0x5485e4: StoreField: r1->field_13 = r0
    //     0x5485e4: stur            w0, [x1, #0x13]
    // 0x5485e8: mov             x3, x1
    // 0x5485ec: ldur            x1, [fp, #-0x10]
    // 0x5485f0: ldr             x2, [fp, #0x10]
    // 0x5485f4: r0 = []=()
    //     0x5485f4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5485f8: r0 = Null
    //     0x5485f8: mov             x0, NULL
    // 0x5485fc: LeaveFrame
    //     0x5485fc: mov             SP, fp
    //     0x548600: ldp             fp, lr, [SP], #0x10
    // 0x548604: ret
    //     0x548604: ret             
    // 0x548608: r0 = StackOverflowSharedWithFPURegs()
    //     0x548608: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x54860c: b               #0x5484fc
    // 0x548610: SaveReg d0
    //     0x548610: str             q0, [SP, #-0x10]!
    // 0x548614: SaveReg r0
    //     0x548614: str             x0, [SP, #-8]!
    // 0x548618: r0 = AllocateDouble()
    //     0x548618: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x54861c: mov             x1, x0
    // 0x548620: RestoreReg r0
    //     0x548620: ldr             x0, [SP], #8
    // 0x548624: RestoreReg d0
    //     0x548624: ldr             q0, [SP], #0x10
    // 0x548628: b               #0x548598
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55ce60, size: 0x104
    // 0x55ce60: EnterFrame
    //     0x55ce60: stp             fp, lr, [SP, #-0x10]!
    //     0x55ce64: mov             fp, SP
    // 0x55ce68: AllocStack(0x28)
    //     0x55ce68: sub             SP, SP, #0x28
    // 0x55ce6c: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x8 */)
    //     0x55ce6c: mov             x0, x1
    //     0x55ce70: stur            x1, [fp, #-8]
    // 0x55ce74: CheckStackOverflow
    //     0x55ce74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55ce78: cmp             SP, x16
    //     0x55ce7c: b.ls            #0x55cf5c
    // 0x55ce80: r1 = Null
    //     0x55ce80: mov             x1, NULL
    // 0x55ce84: r2 = 4
    //     0x55ce84: movz            x2, #0x4
    // 0x55ce88: r0 = AllocateArray()
    //     0x55ce88: bl              #0x82746c  ; AllocateArrayStub
    // 0x55ce8c: stur            x0, [fp, #-0x18]
    // 0x55ce90: r16 = Instance_Chapter15Stat
    //     0x55ce90: add             x16, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x55ce94: ldr             x16, [x16, #0x90]
    // 0x55ce98: StoreField: r0->field_f = r16
    //     0x55ce98: stur            w16, [x0, #0xf]
    // 0x55ce9c: ldur            x1, [fp, #-8]
    // 0x55cea0: LoadField: r3 = r1->field_37
    //     0x55cea0: ldur            w3, [x1, #0x37]
    // 0x55cea4: DecompressPointer r3
    //     0x55cea4: add             x3, x3, HEAP, lsl #32
    // 0x55cea8: mov             x1, x3
    // 0x55ceac: stur            x3, [fp, #-0x10]
    // 0x55ceb0: r2 = Instance_Chapter15Stat
    //     0x55ceb0: add             x2, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x55ceb4: ldr             x2, [x2, #0xc0]
    // 0x55ceb8: r0 = _getValueOrData()
    //     0x55ceb8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x55cebc: mov             x1, x0
    // 0x55cec0: ldur            x0, [fp, #-0x10]
    // 0x55cec4: LoadField: r2 = r0->field_f
    //     0x55cec4: ldur            w2, [x0, #0xf]
    // 0x55cec8: DecompressPointer r2
    //     0x55cec8: add             x2, x2, HEAP, lsl #32
    // 0x55cecc: cmp             w2, w1
    // 0x55ced0: b.ne            #0x55cedc
    // 0x55ced4: r0 = Null
    //     0x55ced4: mov             x0, NULL
    // 0x55ced8: b               #0x55cee0
    // 0x55cedc: mov             x0, x1
    // 0x55cee0: cmp             w0, NULL
    // 0x55cee4: b.ne            #0x55cef4
    // 0x55cee8: r2 = Instance_CustomNum
    //     0x55cee8: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x55ceec: ldr             x2, [x2, #0xaf8]
    // 0x55cef0: b               #0x55cef8
    // 0x55cef4: mov             x2, x0
    // 0x55cef8: r1 = Instance_CustomNum
    //     0x55cef8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!CustomNum@828b41
    //     0x55cefc: ldr             x1, [x1, #0xce0]
    // 0x55cf00: r0 = mult2()
    //     0x55cf00: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x55cf04: mov             x2, x0
    // 0x55cf08: r1 = Instance_CustomNum
    //     0x55cf08: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x55cf0c: ldr             x1, [x1, #0xa70]
    // 0x55cf10: r0 = add()
    //     0x55cf10: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x55cf14: ldur            x1, [fp, #-0x18]
    // 0x55cf18: ArrayStore: r1[1] = r0  ; List_4
    //     0x55cf18: add             x25, x1, #0x13
    //     0x55cf1c: str             w0, [x25]
    //     0x55cf20: tbz             w0, #0, #0x55cf3c
    //     0x55cf24: ldurb           w16, [x1, #-1]
    //     0x55cf28: ldurb           w17, [x0, #-1]
    //     0x55cf2c: and             x16, x17, x16, lsr #2
    //     0x55cf30: tst             x16, HEAP, lsr #32
    //     0x55cf34: b.eq            #0x55cf3c
    //     0x55cf38: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x55cf3c: r16 = <Chapter15Stat, CustomNum>
    //     0x55cf3c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a648] TypeArguments: <Chapter15Stat, CustomNum>
    //     0x55cf40: ldr             x16, [x16, #0x648]
    // 0x55cf44: ldur            lr, [fp, #-0x18]
    // 0x55cf48: stp             lr, x16, [SP]
    // 0x55cf4c: r0 = Map._fromLiteral()
    //     0x55cf4c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55cf50: LeaveFrame
    //     0x55cf50: mov             SP, fp
    //     0x55cf54: ldp             fp, lr, [SP], #0x10
    // 0x55cf58: ret
    //     0x55cf58: ret             
    // 0x55cf5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55cf5c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55cf60: b               #0x55ce80
  }
  _ checkAllBoosts(/* No info */) {
    // ** addr: 0x68a66c, size: 0x7c4
    // 0x68a66c: EnterFrame
    //     0x68a66c: stp             fp, lr, [SP, #-0x10]!
    //     0x68a670: mov             fp, SP
    // 0x68a674: AllocStack(0x40)
    //     0x68a674: sub             SP, SP, #0x40
    // 0x68a678: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */)
    //     0x68a678: mov             x0, x1
    //     0x68a67c: stur            x1, [fp, #-0x10]
    // 0x68a680: CheckStackOverflow
    //     0x68a680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x68a684: cmp             SP, x16
    //     0x68a688: b.ls            #0x68adf4
    // 0x68a68c: LoadField: r2 = r0->field_2f
    //     0x68a68c: ldur            w2, [x0, #0x2f]
    // 0x68a690: DecompressPointer r2
    //     0x68a690: add             x2, x2, HEAP, lsl #32
    // 0x68a694: mov             x1, x0
    // 0x68a698: stur            x2, [fp, #-8]
    // 0x68a69c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x68a69c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x68a6a0: r0 = multithreadingBoost()
    //     0x68a6a0: bl              #0x4fe454  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::multithreadingBoost
    // 0x68a6a4: mov             x3, x0
    // 0x68a6a8: ldur            x0, [fp, #-0x10]
    // 0x68a6ac: stur            x3, [fp, #-0x20]
    // 0x68a6b0: LoadField: r1 = r0->field_3f
    //     0x68a6b0: ldur            w1, [x0, #0x3f]
    // 0x68a6b4: DecompressPointer r1
    //     0x68a6b4: add             x1, x1, HEAP, lsl #32
    // 0x68a6b8: LoadField: r4 = r1->field_b
    //     0x68a6b8: ldur            w4, [x1, #0xb]
    // 0x68a6bc: DecompressPointer r4
    //     0x68a6bc: add             x4, x4, HEAP, lsl #32
    // 0x68a6c0: mov             x1, x4
    // 0x68a6c4: stur            x4, [fp, #-0x18]
    // 0x68a6c8: r2 = 2
    //     0x68a6c8: movz            x2, #0x2
    // 0x68a6cc: r0 = _getValueOrData()
    //     0x68a6cc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a6d0: mov             x1, x0
    // 0x68a6d4: ldur            x0, [fp, #-0x18]
    // 0x68a6d8: LoadField: r2 = r0->field_f
    //     0x68a6d8: ldur            w2, [x0, #0xf]
    // 0x68a6dc: DecompressPointer r2
    //     0x68a6dc: add             x2, x2, HEAP, lsl #32
    // 0x68a6e0: cmp             w2, w1
    // 0x68a6e4: b.ne            #0x68a6f0
    // 0x68a6e8: r0 = Null
    //     0x68a6e8: mov             x0, NULL
    // 0x68a6ec: b               #0x68a6f4
    // 0x68a6f0: mov             x0, x1
    // 0x68a6f4: cmp             w0, NULL
    // 0x68a6f8: b.ne            #0x68a704
    // 0x68a6fc: r2 = 0
    //     0x68a6fc: movz            x2, #0
    // 0x68a700: b               #0x68a714
    // 0x68a704: r1 = LoadInt32Instr(r0)
    //     0x68a704: sbfx            x1, x0, #1, #0x1f
    //     0x68a708: tbz             w0, #0, #0x68a710
    //     0x68a70c: ldur            x1, [x0, #7]
    // 0x68a710: mov             x2, x1
    // 0x68a714: ldur            x3, [fp, #-0x10]
    // 0x68a718: r0 = BoxInt64Instr(r2)
    //     0x68a718: sbfiz           x0, x2, #1, #0x1f
    //     0x68a71c: cmp             x2, x0, asr #1
    //     0x68a720: b.eq            #0x68a72c
    //     0x68a724: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68a728: stur            x2, [x0, #7]
    // 0x68a72c: mov             x2, x0
    // 0x68a730: r1 = Instance_CustomNum
    //     0x68a730: add             x1, PP, #0x11, lsl #12  ; [pp+0x11ef8] Obj!CustomNum@828ec1
    //     0x68a734: ldr             x1, [x1, #0xef8]
    // 0x68a738: r0 = pow()
    //     0x68a738: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x68a73c: ldur            x1, [fp, #-0x20]
    // 0x68a740: mov             x2, x0
    // 0x68a744: r0 = mult2()
    //     0x68a744: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x68a748: stur            x0, [fp, #-0x18]
    // 0x68a74c: r0 = Boost()
    //     0x68a74c: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a750: mov             x1, x0
    // 0x68a754: r0 = Instance_CustomNum
    //     0x68a754: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a758: ldr             x0, [x0, #0xa70]
    // 0x68a75c: StoreField: r1->field_7 = r0
    //     0x68a75c: stur            w0, [x1, #7]
    // 0x68a760: StoreField: r1->field_b = r0
    //     0x68a760: stur            w0, [x1, #0xb]
    // 0x68a764: ldur            x2, [fp, #-0x18]
    // 0x68a768: StoreField: r1->field_f = r2
    //     0x68a768: stur            w2, [x1, #0xf]
    // 0x68a76c: StoreField: r1->field_13 = r0
    //     0x68a76c: stur            w0, [x1, #0x13]
    // 0x68a770: mov             x3, x1
    // 0x68a774: ldur            x1, [fp, #-8]
    // 0x68a778: r2 = Instance_Chapter15Stat
    //     0x68a778: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x68a77c: ldr             x2, [x2, #0x90]
    // 0x68a780: r0 = []=()
    //     0x68a780: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a784: r1 = Null
    //     0x68a784: mov             x1, NULL
    // 0x68a788: r2 = 6
    //     0x68a788: movz            x2, #0x6
    // 0x68a78c: r0 = CustomNum()
    //     0x68a78c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x68a790: mov             x3, x0
    // 0x68a794: ldur            x0, [fp, #-0x10]
    // 0x68a798: stur            x3, [fp, #-0x20]
    // 0x68a79c: LoadField: r1 = r0->field_3f
    //     0x68a79c: ldur            w1, [x0, #0x3f]
    // 0x68a7a0: DecompressPointer r1
    //     0x68a7a0: add             x1, x1, HEAP, lsl #32
    // 0x68a7a4: LoadField: r4 = r1->field_b
    //     0x68a7a4: ldur            w4, [x1, #0xb]
    // 0x68a7a8: DecompressPointer r4
    //     0x68a7a8: add             x4, x4, HEAP, lsl #32
    // 0x68a7ac: mov             x1, x4
    // 0x68a7b0: stur            x4, [fp, #-0x18]
    // 0x68a7b4: r2 = 2
    //     0x68a7b4: movz            x2, #0x2
    // 0x68a7b8: r0 = _getValueOrData()
    //     0x68a7b8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a7bc: mov             x1, x0
    // 0x68a7c0: ldur            x0, [fp, #-0x18]
    // 0x68a7c4: LoadField: r2 = r0->field_f
    //     0x68a7c4: ldur            w2, [x0, #0xf]
    // 0x68a7c8: DecompressPointer r2
    //     0x68a7c8: add             x2, x2, HEAP, lsl #32
    // 0x68a7cc: cmp             w2, w1
    // 0x68a7d0: b.ne            #0x68a7dc
    // 0x68a7d4: r0 = Null
    //     0x68a7d4: mov             x0, NULL
    // 0x68a7d8: b               #0x68a7e0
    // 0x68a7dc: mov             x0, x1
    // 0x68a7e0: cmp             w0, NULL
    // 0x68a7e4: b.ne            #0x68a7f0
    // 0x68a7e8: r2 = 0
    //     0x68a7e8: movz            x2, #0
    // 0x68a7ec: b               #0x68a800
    // 0x68a7f0: r1 = LoadInt32Instr(r0)
    //     0x68a7f0: sbfx            x1, x0, #1, #0x1f
    //     0x68a7f4: tbz             w0, #0, #0x68a7fc
    //     0x68a7f8: ldur            x1, [x0, #7]
    // 0x68a7fc: mov             x2, x1
    // 0x68a800: ldur            x3, [fp, #-0x10]
    // 0x68a804: r0 = BoxInt64Instr(r2)
    //     0x68a804: sbfiz           x0, x2, #1, #0x1f
    //     0x68a808: cmp             x2, x0, asr #1
    //     0x68a80c: b.eq            #0x68a818
    //     0x68a810: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68a814: stur            x2, [x0, #7]
    // 0x68a818: ldur            x1, [fp, #-0x20]
    // 0x68a81c: mov             x2, x0
    // 0x68a820: r0 = pow()
    //     0x68a820: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x68a824: stur            x0, [fp, #-0x18]
    // 0x68a828: r0 = Boost()
    //     0x68a828: bl              #0x459164  ; AllocateBoostStub -> Boost (size=0x18)
    // 0x68a82c: mov             x1, x0
    // 0x68a830: ldur            x0, [fp, #-0x18]
    // 0x68a834: StoreField: r1->field_7 = r0
    //     0x68a834: stur            w0, [x1, #7]
    // 0x68a838: r0 = Instance_CustomNum
    //     0x68a838: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x68a83c: ldr             x0, [x0, #0xa70]
    // 0x68a840: StoreField: r1->field_b = r0
    //     0x68a840: stur            w0, [x1, #0xb]
    // 0x68a844: StoreField: r1->field_f = r0
    //     0x68a844: stur            w0, [x1, #0xf]
    // 0x68a848: StoreField: r1->field_13 = r0
    //     0x68a848: stur            w0, [x1, #0x13]
    // 0x68a84c: mov             x3, x1
    // 0x68a850: ldur            x1, [fp, #-8]
    // 0x68a854: r2 = Instance_Chapter15Stat
    //     0x68a854: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x68a858: ldr             x2, [x2, #0x68]
    // 0x68a85c: r0 = []=()
    //     0x68a85c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x68a860: ldur            x3, [fp, #-0x10]
    // 0x68a864: LoadField: r4 = r3->field_33
    //     0x68a864: ldur            w4, [x3, #0x33]
    // 0x68a868: DecompressPointer r4
    //     0x68a868: add             x4, x4, HEAP, lsl #32
    // 0x68a86c: stur            x4, [fp, #-0x30]
    // 0x68a870: r5 = 0
    //     0x68a870: movz            x5, #0
    // 0x68a874: stur            x5, [fp, #-0x28]
    // 0x68a878: CheckStackOverflow
    //     0x68a878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x68a87c: cmp             SP, x16
    //     0x68a880: b.ls            #0x68adfc
    // 0x68a884: LoadField: r0 = r3->field_a7
    //     0x68a884: ldur            w0, [x3, #0xa7]
    // 0x68a888: DecompressPointer r0
    //     0x68a888: add             x0, x0, HEAP, lsl #32
    // 0x68a88c: LoadField: r1 = r0->field_b
    //     0x68a88c: ldur            w1, [x0, #0xb]
    // 0x68a890: r2 = LoadInt32Instr(r1)
    //     0x68a890: sbfx            x2, x1, #1, #0x1f
    // 0x68a894: cmp             x5, x2
    // 0x68a898: b.ge            #0x68adc8
    // 0x68a89c: LoadField: r1 = r0->field_f
    //     0x68a89c: ldur            w1, [x0, #0xf]
    // 0x68a8a0: DecompressPointer r1
    //     0x68a8a0: add             x1, x1, HEAP, lsl #32
    // 0x68a8a4: lsl             x6, x5, #1
    // 0x68a8a8: stur            x6, [fp, #-0x20]
    // 0x68a8ac: ArrayLoad: r7 = r1[r5]  ; Unknown_4
    //     0x68a8ac: add             x16, x1, x5, lsl #2
    //     0x68a8b0: ldur            w7, [x16, #0xf]
    // 0x68a8b4: DecompressPointer r7
    //     0x68a8b4: add             x7, x7, HEAP, lsl #32
    // 0x68a8b8: stur            x7, [fp, #-0x18]
    // 0x68a8bc: LoadField: r8 = r3->field_47
    //     0x68a8bc: ldur            w8, [x3, #0x47]
    // 0x68a8c0: DecompressPointer r8
    //     0x68a8c0: add             x8, x8, HEAP, lsl #32
    // 0x68a8c4: stur            x8, [fp, #-8]
    // 0x68a8c8: LoadField: r2 = r7->field_b
    //     0x68a8c8: ldur            x2, [x7, #0xb]
    // 0x68a8cc: r0 = BoxInt64Instr(r2)
    //     0x68a8cc: sbfiz           x0, x2, #1, #0x1f
    //     0x68a8d0: cmp             x2, x0, asr #1
    //     0x68a8d4: b.eq            #0x68a8e0
    //     0x68a8d8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68a8dc: stur            x2, [x0, #7]
    // 0x68a8e0: mov             x1, x8
    // 0x68a8e4: mov             x2, x0
    // 0x68a8e8: r0 = _getValueOrData()
    //     0x68a8e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68a8ec: mov             x1, x0
    // 0x68a8f0: ldur            x0, [fp, #-8]
    // 0x68a8f4: LoadField: r2 = r0->field_f
    //     0x68a8f4: ldur            w2, [x0, #0xf]
    // 0x68a8f8: DecompressPointer r2
    //     0x68a8f8: add             x2, x2, HEAP, lsl #32
    // 0x68a8fc: cmp             w2, w1
    // 0x68a900: b.ne            #0x68a90c
    // 0x68a904: r0 = Null
    //     0x68a904: mov             x0, NULL
    // 0x68a908: b               #0x68a910
    // 0x68a90c: mov             x0, x1
    // 0x68a910: cmp             w0, NULL
    // 0x68a914: b.eq            #0x68ab58
    // 0x68a918: ldur            x1, [fp, #-0x18]
    // 0x68a91c: LoadField: r2 = r1->field_13
    //     0x68a91c: ldur            x2, [x1, #0x13]
    // 0x68a920: scvtf           d0, x2
    // 0x68a924: LoadField: d1 = r0->field_7
    //     0x68a924: ldur            d1, [x0, #7]
    // 0x68a928: fcmp            d1, d0
    // 0x68a92c: b.lt            #0x68ab58
    // 0x68a930: ldur            x0, [fp, #-0x10]
    // 0x68a934: ldur            x3, [fp, #-0x28]
    // 0x68a938: LoadField: r4 = r0->field_97
    //     0x68a938: ldur            w4, [x0, #0x97]
    // 0x68a93c: DecompressPointer r4
    //     0x68a93c: add             x4, x4, HEAP, lsl #32
    // 0x68a940: mov             x1, x4
    // 0x68a944: ldur            x2, [fp, #-0x20]
    // 0x68a948: stur            x4, [fp, #-8]
    // 0x68a94c: r0 = _hashCode()
    //     0x68a94c: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x68a950: ldur            x1, [fp, #-8]
    // 0x68a954: ldur            x2, [fp, #-0x20]
    // 0x68a958: mov             x3, x0
    // 0x68a95c: r0 = _add()
    //     0x68a95c: bl              #0x396d5c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x68a960: ldur            x3, [fp, #-0x10]
    // 0x68a964: LoadField: r2 = r3->field_a7
    //     0x68a964: ldur            w2, [x3, #0xa7]
    // 0x68a968: DecompressPointer r2
    //     0x68a968: add             x2, x2, HEAP, lsl #32
    // 0x68a96c: LoadField: r0 = r2->field_b
    //     0x68a96c: ldur            w0, [x2, #0xb]
    // 0x68a970: r1 = LoadInt32Instr(r0)
    //     0x68a970: sbfx            x1, x0, #1, #0x1f
    // 0x68a974: mov             x0, x1
    // 0x68a978: ldur            x1, [fp, #-0x28]
    // 0x68a97c: cmp             x1, x0
    // 0x68a980: b.hs            #0x68ae04
    // 0x68a984: LoadField: r0 = r2->field_f
    //     0x68a984: ldur            w0, [x2, #0xf]
    // 0x68a988: DecompressPointer r0
    //     0x68a988: add             x0, x0, HEAP, lsl #32
    // 0x68a98c: ldur            x4, [fp, #-0x28]
    // 0x68a990: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68a990: add             x16, x0, x4, lsl #2
    //     0x68a994: ldur            w1, [x16, #0xf]
    // 0x68a998: DecompressPointer r1
    //     0x68a998: add             x1, x1, HEAP, lsl #32
    // 0x68a99c: LoadField: r0 = r1->field_1b
    //     0x68a99c: ldur            w0, [x1, #0x1b]
    // 0x68a9a0: DecompressPointer r0
    //     0x68a9a0: add             x0, x0, HEAP, lsl #32
    // 0x68a9a4: stur            x0, [fp, #-0x20]
    // 0x68a9a8: LoadField: r1 = r0->field_b
    //     0x68a9a8: ldur            w1, [x0, #0xb]
    // 0x68a9ac: r5 = LoadInt32Instr(r1)
    //     0x68a9ac: sbfx            x5, x1, #1, #0x1f
    // 0x68a9b0: stur            x5, [fp, #-0x40]
    // 0x68a9b4: r1 = 0
    //     0x68a9b4: movz            x1, #0
    // 0x68a9b8: ldur            x6, [fp, #-0x30]
    // 0x68a9bc: CheckStackOverflow
    //     0x68a9bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x68a9c0: cmp             SP, x16
    //     0x68a9c4: b.ls            #0x68ae08
    // 0x68a9c8: LoadField: r2 = r0->field_b
    //     0x68a9c8: ldur            w2, [x0, #0xb]
    // 0x68a9cc: r7 = LoadInt32Instr(r2)
    //     0x68a9cc: sbfx            x7, x2, #1, #0x1f
    // 0x68a9d0: cmp             x5, x7
    // 0x68a9d4: b.ne            #0x68add8
    // 0x68a9d8: cmp             x1, x7
    // 0x68a9dc: b.ge            #0x68adb4
    // 0x68a9e0: LoadField: r2 = r0->field_f
    //     0x68a9e0: ldur            w2, [x0, #0xf]
    // 0x68a9e4: DecompressPointer r2
    //     0x68a9e4: add             x2, x2, HEAP, lsl #32
    // 0x68a9e8: ArrayLoad: r7 = r2[r1]  ; Unknown_4
    //     0x68a9e8: add             x16, x2, x1, lsl #2
    //     0x68a9ec: ldur            w7, [x16, #0xf]
    // 0x68a9f0: DecompressPointer r7
    //     0x68a9f0: add             x7, x7, HEAP, lsl #32
    // 0x68a9f4: stur            x7, [fp, #-0x18]
    // 0x68a9f8: add             x8, x1, #1
    // 0x68a9fc: stur            x8, [fp, #-0x38]
    // 0x68aa00: LoadField: r9 = r6->field_f
    //     0x68aa00: ldur            w9, [x6, #0xf]
    // 0x68aa04: DecompressPointer r9
    //     0x68aa04: add             x9, x9, HEAP, lsl #32
    // 0x68aa08: mov             x1, x6
    // 0x68aa0c: mov             x2, x7
    // 0x68aa10: stur            x9, [fp, #-8]
    // 0x68aa14: r0 = _getValueOrData()
    //     0x68aa14: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68aa18: mov             x1, x0
    // 0x68aa1c: ldur            x0, [fp, #-8]
    // 0x68aa20: cmp             w0, w1
    // 0x68aa24: b.ne            #0x68aa94
    // 0x68aa28: ldur            x3, [fp, #-0x10]
    // 0x68aa2c: ldur            x4, [fp, #-0x28]
    // 0x68aa30: LoadField: r2 = r3->field_a7
    //     0x68aa30: ldur            w2, [x3, #0xa7]
    // 0x68aa34: DecompressPointer r2
    //     0x68aa34: add             x2, x2, HEAP, lsl #32
    // 0x68aa38: LoadField: r0 = r2->field_b
    //     0x68aa38: ldur            w0, [x2, #0xb]
    // 0x68aa3c: r1 = LoadInt32Instr(r0)
    //     0x68aa3c: sbfx            x1, x0, #1, #0x1f
    // 0x68aa40: mov             x0, x1
    // 0x68aa44: mov             x1, x4
    // 0x68aa48: cmp             x1, x0
    // 0x68aa4c: b.hs            #0x68ae10
    // 0x68aa50: LoadField: r0 = r2->field_f
    //     0x68aa50: ldur            w0, [x2, #0xf]
    // 0x68aa54: DecompressPointer r0
    //     0x68aa54: add             x0, x0, HEAP, lsl #32
    // 0x68aa58: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68aa58: add             x16, x0, x4, lsl #2
    //     0x68aa5c: ldur            w1, [x16, #0xf]
    // 0x68aa60: DecompressPointer r1
    //     0x68aa60: add             x1, x1, HEAP, lsl #32
    // 0x68aa64: LoadField: r0 = r1->field_7
    //     0x68aa64: ldur            w0, [x1, #7]
    // 0x68aa68: DecompressPointer r0
    //     0x68aa68: add             x0, x0, HEAP, lsl #32
    // 0x68aa6c: ldur            x1, [fp, #-0x30]
    // 0x68aa70: ldur            x2, [fp, #-0x18]
    // 0x68aa74: stur            x0, [fp, #-8]
    // 0x68aa78: r0 = _hashCode()
    //     0x68aa78: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x68aa7c: ldur            x1, [fp, #-0x30]
    // 0x68aa80: ldur            x2, [fp, #-0x18]
    // 0x68aa84: ldur            x3, [fp, #-8]
    // 0x68aa88: mov             x5, x0
    // 0x68aa8c: r0 = _set()
    //     0x68aa8c: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x68aa90: b               #0x68ab40
    // 0x68aa94: ldur            x0, [fp, #-0x30]
    // 0x68aa98: mov             x1, x0
    // 0x68aa9c: ldur            x2, [fp, #-0x18]
    // 0x68aaa0: r0 = _getValueOrData()
    //     0x68aaa0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68aaa4: ldur            x3, [fp, #-0x30]
    // 0x68aaa8: LoadField: r1 = r3->field_f
    //     0x68aaa8: ldur            w1, [x3, #0xf]
    // 0x68aaac: DecompressPointer r1
    //     0x68aaac: add             x1, x1, HEAP, lsl #32
    // 0x68aab0: cmp             w1, w0
    // 0x68aab4: b.ne            #0x68aac0
    // 0x68aab8: r2 = Null
    //     0x68aab8: mov             x2, NULL
    // 0x68aabc: b               #0x68aac4
    // 0x68aac0: mov             x2, x0
    // 0x68aac4: ldur            x4, [fp, #-0x10]
    // 0x68aac8: ldur            x5, [fp, #-0x28]
    // 0x68aacc: cmp             w2, NULL
    // 0x68aad0: b.eq            #0x68ae14
    // 0x68aad4: LoadField: r6 = r4->field_a7
    //     0x68aad4: ldur            w6, [x4, #0xa7]
    // 0x68aad8: DecompressPointer r6
    //     0x68aad8: add             x6, x6, HEAP, lsl #32
    // 0x68aadc: LoadField: r0 = r6->field_b
    //     0x68aadc: ldur            w0, [x6, #0xb]
    // 0x68aae0: r1 = LoadInt32Instr(r0)
    //     0x68aae0: sbfx            x1, x0, #1, #0x1f
    // 0x68aae4: mov             x0, x1
    // 0x68aae8: mov             x1, x5
    // 0x68aaec: cmp             x1, x0
    // 0x68aaf0: b.hs            #0x68ae18
    // 0x68aaf4: LoadField: r0 = r6->field_f
    //     0x68aaf4: ldur            w0, [x6, #0xf]
    // 0x68aaf8: DecompressPointer r0
    //     0x68aaf8: add             x0, x0, HEAP, lsl #32
    // 0x68aafc: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x68aafc: add             x16, x0, x5, lsl #2
    //     0x68ab00: ldur            w1, [x16, #0xf]
    // 0x68ab04: DecompressPointer r1
    //     0x68ab04: add             x1, x1, HEAP, lsl #32
    // 0x68ab08: LoadField: r0 = r1->field_7
    //     0x68ab08: ldur            w0, [x1, #7]
    // 0x68ab0c: DecompressPointer r0
    //     0x68ab0c: add             x0, x0, HEAP, lsl #32
    // 0x68ab10: mov             x1, x2
    // 0x68ab14: mov             x2, x0
    // 0x68ab18: r0 = *()
    //     0x68ab18: bl              #0x543b34  ; [package:pretentious/fragment/lib/Data/Boost.dart] Boost::*
    // 0x68ab1c: ldur            x1, [fp, #-0x30]
    // 0x68ab20: ldur            x2, [fp, #-0x18]
    // 0x68ab24: stur            x0, [fp, #-8]
    // 0x68ab28: r0 = _hashCode()
    //     0x68ab28: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x68ab2c: ldur            x1, [fp, #-0x30]
    // 0x68ab30: ldur            x2, [fp, #-0x18]
    // 0x68ab34: ldur            x3, [fp, #-8]
    // 0x68ab38: mov             x5, x0
    // 0x68ab3c: r0 = _set()
    //     0x68ab3c: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x68ab40: ldur            x1, [fp, #-0x38]
    // 0x68ab44: ldur            x3, [fp, #-0x10]
    // 0x68ab48: ldur            x4, [fp, #-0x28]
    // 0x68ab4c: ldur            x0, [fp, #-0x20]
    // 0x68ab50: ldur            x5, [fp, #-0x40]
    // 0x68ab54: b               #0x68a9b8
    // 0x68ab58: ldur            x3, [fp, #-0x10]
    // 0x68ab5c: ldur            x4, [fp, #-0x28]
    // 0x68ab60: LoadField: r2 = r3->field_9f
    //     0x68ab60: ldur            w2, [x3, #0x9f]
    // 0x68ab64: DecompressPointer r2
    //     0x68ab64: add             x2, x2, HEAP, lsl #32
    // 0x68ab68: LoadField: r5 = r3->field_a7
    //     0x68ab68: ldur            w5, [x3, #0xa7]
    // 0x68ab6c: DecompressPointer r5
    //     0x68ab6c: add             x5, x5, HEAP, lsl #32
    // 0x68ab70: LoadField: r0 = r5->field_b
    //     0x68ab70: ldur            w0, [x5, #0xb]
    // 0x68ab74: r1 = LoadInt32Instr(r0)
    //     0x68ab74: sbfx            x1, x0, #1, #0x1f
    // 0x68ab78: mov             x0, x1
    // 0x68ab7c: mov             x1, x4
    // 0x68ab80: cmp             x1, x0
    // 0x68ab84: b.hs            #0x68ae1c
    // 0x68ab88: LoadField: r0 = r5->field_f
    //     0x68ab88: ldur            w0, [x5, #0xf]
    // 0x68ab8c: DecompressPointer r0
    //     0x68ab8c: add             x0, x0, HEAP, lsl #32
    // 0x68ab90: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68ab90: add             x16, x0, x4, lsl #2
    //     0x68ab94: ldur            w1, [x16, #0xf]
    // 0x68ab98: DecompressPointer r1
    //     0x68ab98: add             x1, x1, HEAP, lsl #32
    // 0x68ab9c: LoadField: r5 = r1->field_b
    //     0x68ab9c: ldur            x5, [x1, #0xb]
    // 0x68aba0: LoadField: r6 = r2->field_f
    //     0x68aba0: ldur            w6, [x2, #0xf]
    // 0x68aba4: DecompressPointer r6
    //     0x68aba4: add             x6, x6, HEAP, lsl #32
    // 0x68aba8: stur            x6, [fp, #-8]
    // 0x68abac: r0 = BoxInt64Instr(r5)
    //     0x68abac: sbfiz           x0, x5, #1, #0x1f
    //     0x68abb0: cmp             x5, x0, asr #1
    //     0x68abb4: b.eq            #0x68abc0
    //     0x68abb8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68abbc: stur            x5, [x0, #7]
    // 0x68abc0: mov             x1, x2
    // 0x68abc4: mov             x2, x0
    // 0x68abc8: r0 = _getValueOrData()
    //     0x68abc8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68abcc: mov             x1, x0
    // 0x68abd0: ldur            x0, [fp, #-8]
    // 0x68abd4: cmp             w0, w1
    // 0x68abd8: b.ne            #0x68ac88
    // 0x68abdc: ldur            x3, [fp, #-0x10]
    // 0x68abe0: ldur            x4, [fp, #-0x28]
    // 0x68abe4: LoadField: r5 = r3->field_9f
    //     0x68abe4: ldur            w5, [x3, #0x9f]
    // 0x68abe8: DecompressPointer r5
    //     0x68abe8: add             x5, x5, HEAP, lsl #32
    // 0x68abec: stur            x5, [fp, #-0x18]
    // 0x68abf0: LoadField: r2 = r3->field_a7
    //     0x68abf0: ldur            w2, [x3, #0xa7]
    // 0x68abf4: DecompressPointer r2
    //     0x68abf4: add             x2, x2, HEAP, lsl #32
    // 0x68abf8: LoadField: r0 = r2->field_b
    //     0x68abf8: ldur            w0, [x2, #0xb]
    // 0x68abfc: r1 = LoadInt32Instr(r0)
    //     0x68abfc: sbfx            x1, x0, #1, #0x1f
    // 0x68ac00: mov             x0, x1
    // 0x68ac04: mov             x1, x4
    // 0x68ac08: cmp             x1, x0
    // 0x68ac0c: b.hs            #0x68ae20
    // 0x68ac10: LoadField: r0 = r2->field_f
    //     0x68ac10: ldur            w0, [x2, #0xf]
    // 0x68ac14: DecompressPointer r0
    //     0x68ac14: add             x0, x0, HEAP, lsl #32
    // 0x68ac18: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68ac18: add             x16, x0, x4, lsl #2
    //     0x68ac1c: ldur            w1, [x16, #0xf]
    // 0x68ac20: DecompressPointer r1
    //     0x68ac20: add             x1, x1, HEAP, lsl #32
    // 0x68ac24: LoadField: r2 = r1->field_b
    //     0x68ac24: ldur            x2, [x1, #0xb]
    // 0x68ac28: LoadField: r6 = r1->field_13
    //     0x68ac28: ldur            x6, [x1, #0x13]
    // 0x68ac2c: stur            x6, [fp, #-0x38]
    // 0x68ac30: r0 = BoxInt64Instr(r2)
    //     0x68ac30: sbfiz           x0, x2, #1, #0x1f
    //     0x68ac34: cmp             x2, x0, asr #1
    //     0x68ac38: b.eq            #0x68ac44
    //     0x68ac3c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68ac40: stur            x2, [x0, #7]
    // 0x68ac44: mov             x1, x5
    // 0x68ac48: mov             x2, x0
    // 0x68ac4c: stur            x0, [fp, #-8]
    // 0x68ac50: r0 = _hashCode()
    //     0x68ac50: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x68ac54: mov             x3, x0
    // 0x68ac58: ldur            x2, [fp, #-0x38]
    // 0x68ac5c: r0 = BoxInt64Instr(r2)
    //     0x68ac5c: sbfiz           x0, x2, #1, #0x1f
    //     0x68ac60: cmp             x2, x0, asr #1
    //     0x68ac64: b.eq            #0x68ac70
    //     0x68ac68: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68ac6c: stur            x2, [x0, #7]
    // 0x68ac70: ldur            x1, [fp, #-0x18]
    // 0x68ac74: ldur            x2, [fp, #-8]
    // 0x68ac78: mov             x5, x3
    // 0x68ac7c: mov             x3, x0
    // 0x68ac80: r0 = _set()
    //     0x68ac80: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x68ac84: b               #0x68adb4
    // 0x68ac88: ldur            x3, [fp, #-0x10]
    // 0x68ac8c: ldur            x4, [fp, #-0x28]
    // 0x68ac90: LoadField: r5 = r3->field_9f
    //     0x68ac90: ldur            w5, [x3, #0x9f]
    // 0x68ac94: DecompressPointer r5
    //     0x68ac94: add             x5, x5, HEAP, lsl #32
    // 0x68ac98: stur            x5, [fp, #-0x18]
    // 0x68ac9c: LoadField: r2 = r3->field_a7
    //     0x68ac9c: ldur            w2, [x3, #0xa7]
    // 0x68aca0: DecompressPointer r2
    //     0x68aca0: add             x2, x2, HEAP, lsl #32
    // 0x68aca4: LoadField: r0 = r2->field_b
    //     0x68aca4: ldur            w0, [x2, #0xb]
    // 0x68aca8: r1 = LoadInt32Instr(r0)
    //     0x68aca8: sbfx            x1, x0, #1, #0x1f
    // 0x68acac: mov             x0, x1
    // 0x68acb0: mov             x1, x4
    // 0x68acb4: cmp             x1, x0
    // 0x68acb8: b.hs            #0x68ae24
    // 0x68acbc: LoadField: r0 = r2->field_f
    //     0x68acbc: ldur            w0, [x2, #0xf]
    // 0x68acc0: DecompressPointer r0
    //     0x68acc0: add             x0, x0, HEAP, lsl #32
    // 0x68acc4: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68acc4: add             x16, x0, x4, lsl #2
    //     0x68acc8: ldur            w1, [x16, #0xf]
    // 0x68accc: DecompressPointer r1
    //     0x68accc: add             x1, x1, HEAP, lsl #32
    // 0x68acd0: LoadField: r2 = r1->field_b
    //     0x68acd0: ldur            x2, [x1, #0xb]
    // 0x68acd4: r0 = BoxInt64Instr(r2)
    //     0x68acd4: sbfiz           x0, x2, #1, #0x1f
    //     0x68acd8: cmp             x2, x0, asr #1
    //     0x68acdc: b.eq            #0x68ace8
    //     0x68ace0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68ace4: stur            x2, [x0, #7]
    // 0x68ace8: mov             x1, x5
    // 0x68acec: mov             x2, x0
    // 0x68acf0: stur            x0, [fp, #-8]
    // 0x68acf4: r0 = _getValueOrData()
    //     0x68acf4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x68acf8: ldur            x3, [fp, #-0x18]
    // 0x68acfc: LoadField: r1 = r3->field_f
    //     0x68acfc: ldur            w1, [x3, #0xf]
    // 0x68ad00: DecompressPointer r1
    //     0x68ad00: add             x1, x1, HEAP, lsl #32
    // 0x68ad04: cmp             w1, w0
    // 0x68ad08: b.ne            #0x68ad14
    // 0x68ad0c: r2 = Null
    //     0x68ad0c: mov             x2, NULL
    // 0x68ad10: b               #0x68ad18
    // 0x68ad14: mov             x2, x0
    // 0x68ad18: ldur            x4, [fp, #-0x10]
    // 0x68ad1c: ldur            x5, [fp, #-0x28]
    // 0x68ad20: cmp             w2, NULL
    // 0x68ad24: b.eq            #0x68ae28
    // 0x68ad28: LoadField: r6 = r4->field_a7
    //     0x68ad28: ldur            w6, [x4, #0xa7]
    // 0x68ad2c: DecompressPointer r6
    //     0x68ad2c: add             x6, x6, HEAP, lsl #32
    // 0x68ad30: LoadField: r0 = r6->field_b
    //     0x68ad30: ldur            w0, [x6, #0xb]
    // 0x68ad34: r1 = LoadInt32Instr(r0)
    //     0x68ad34: sbfx            x1, x0, #1, #0x1f
    // 0x68ad38: mov             x0, x1
    // 0x68ad3c: mov             x1, x5
    // 0x68ad40: cmp             x1, x0
    // 0x68ad44: b.hs            #0x68ae2c
    // 0x68ad48: LoadField: r0 = r6->field_f
    //     0x68ad48: ldur            w0, [x6, #0xf]
    // 0x68ad4c: DecompressPointer r0
    //     0x68ad4c: add             x0, x0, HEAP, lsl #32
    // 0x68ad50: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x68ad50: add             x16, x0, x5, lsl #2
    //     0x68ad54: ldur            w1, [x16, #0xf]
    // 0x68ad58: DecompressPointer r1
    //     0x68ad58: add             x1, x1, HEAP, lsl #32
    // 0x68ad5c: LoadField: r0 = r1->field_13
    //     0x68ad5c: ldur            x0, [x1, #0x13]
    // 0x68ad60: r1 = LoadInt32Instr(r2)
    //     0x68ad60: sbfx            x1, x2, #1, #0x1f
    //     0x68ad64: tbz             w2, #0, #0x68ad6c
    //     0x68ad68: ldur            x1, [x2, #7]
    // 0x68ad6c: cmp             x1, x0
    // 0x68ad70: csel            x6, x0, x1, gt
    // 0x68ad74: mov             x1, x3
    // 0x68ad78: ldur            x2, [fp, #-8]
    // 0x68ad7c: stur            x6, [fp, #-0x38]
    // 0x68ad80: r0 = _hashCode()
    //     0x68ad80: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x68ad84: mov             x3, x0
    // 0x68ad88: ldur            x2, [fp, #-0x38]
    // 0x68ad8c: r0 = BoxInt64Instr(r2)
    //     0x68ad8c: sbfiz           x0, x2, #1, #0x1f
    //     0x68ad90: cmp             x2, x0, asr #1
    //     0x68ad94: b.eq            #0x68ada0
    //     0x68ad98: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x68ad9c: stur            x2, [x0, #7]
    // 0x68ada0: ldur            x1, [fp, #-0x18]
    // 0x68ada4: ldur            x2, [fp, #-8]
    // 0x68ada8: mov             x5, x3
    // 0x68adac: mov             x3, x0
    // 0x68adb0: r0 = _set()
    //     0x68adb0: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x68adb4: ldur            x0, [fp, #-0x28]
    // 0x68adb8: add             x5, x0, #1
    // 0x68adbc: ldur            x3, [fp, #-0x10]
    // 0x68adc0: ldur            x4, [fp, #-0x30]
    // 0x68adc4: b               #0x68a874
    // 0x68adc8: r0 = Null
    //     0x68adc8: mov             x0, NULL
    // 0x68adcc: LeaveFrame
    //     0x68adcc: mov             SP, fp
    //     0x68add0: ldp             fp, lr, [SP], #0x10
    // 0x68add4: ret
    //     0x68add4: ret             
    // 0x68add8: r0 = ConcurrentModificationError()
    //     0x68add8: bl              #0x327c48  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x68addc: mov             x1, x0
    // 0x68ade0: ldur            x0, [fp, #-0x20]
    // 0x68ade4: StoreField: r1->field_b = r0
    //     0x68ade4: stur            w0, [x1, #0xb]
    // 0x68ade8: mov             x0, x1
    // 0x68adec: r0 = Throw()
    //     0x68adec: bl              #0x825670  ; ThrowStub
    // 0x68adf0: brk             #0
    // 0x68adf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68adf4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68adf8: b               #0x68a68c
    // 0x68adfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68adfc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68ae00: b               #0x68a884
    // 0x68ae04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae04: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68ae08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68ae08: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68ae0c: b               #0x68a9c8
    // 0x68ae10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae10: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68ae14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68ae14: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68ae18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae18: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68ae1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae1c: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68ae20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae20: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68ae24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae24: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68ae28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68ae28: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68ae2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68ae2c: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x69940c, size: 0x4c
    // 0x69940c: EnterFrame
    //     0x69940c: stp             fp, lr, [SP, #-0x10]!
    //     0x699410: mov             fp, SP
    // 0x699414: ldr             x0, [fp, #0x10]
    // 0x699418: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x699418: ldur            w1, [x0, #0x17]
    // 0x69941c: DecompressPointer r1
    //     0x69941c: add             x1, x1, HEAP, lsl #32
    // 0x699420: CheckStackOverflow
    //     0x699420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x699424: cmp             SP, x16
    //     0x699428: b.ls            #0x699450
    // 0x69942c: LoadField: r0 = r1->field_f
    //     0x69942c: ldur            w0, [x1, #0xf]
    // 0x699430: DecompressPointer r0
    //     0x699430: add             x0, x0, HEAP, lsl #32
    // 0x699434: LoadField: r1 = r0->field_1f
    //     0x699434: ldur            w1, [x0, #0x1f]
    // 0x699438: DecompressPointer r1
    //     0x699438: add             x1, x1, HEAP, lsl #32
    // 0x69943c: r2 = 2
    //     0x69943c: movz            x2, #0x2
    // 0x699440: r0 = contains()
    //     0x699440: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x699444: LeaveFrame
    //     0x699444: mov             SP, fp
    //     0x699448: ldp             fp, lr, [SP], #0x10
    // 0x69944c: ret
    //     0x69944c: ret             
    // 0x699450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x699450: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x699454: b               #0x69942c
  }
  _ build(/* No info */) {
    // ** addr: 0x6a2d94, size: 0x1018
    // 0x6a2d94: EnterFrame
    //     0x6a2d94: stp             fp, lr, [SP, #-0x10]!
    //     0x6a2d98: mov             fp, SP
    // 0x6a2d9c: AllocStack(0xb0)
    //     0x6a2d9c: sub             SP, SP, #0xb0
    // 0x6a2da0: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x6a2da0: mov             x0, x1
    //     0x6a2da4: stur            x1, [fp, #-8]
    //     0x6a2da8: stur            x2, [fp, #-0x10]
    // 0x6a2dac: CheckStackOverflow
    //     0x6a2dac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a2db0: cmp             SP, x16
    //     0x6a2db4: b.ls            #0x6a3d98
    // 0x6a2db8: r1 = 2
    //     0x6a2db8: movz            x1, #0x2
    // 0x6a2dbc: r0 = AllocateContext()
    //     0x6a2dbc: bl              #0x82637c  ; AllocateContextStub
    // 0x6a2dc0: ldur            x2, [fp, #-8]
    // 0x6a2dc4: stur            x0, [fp, #-0x18]
    // 0x6a2dc8: StoreField: r0->field_f = r2
    //     0x6a2dc8: stur            w2, [x0, #0xf]
    // 0x6a2dcc: ldur            x1, [fp, #-0x10]
    // 0x6a2dd0: StoreField: r0->field_13 = r1
    //     0x6a2dd0: stur            w1, [x0, #0x13]
    // 0x6a2dd4: LoadField: r1 = r2->field_93
    //     0x6a2dd4: ldur            w1, [x2, #0x93]
    // 0x6a2dd8: DecompressPointer r1
    //     0x6a2dd8: add             x1, x1, HEAP, lsl #32
    // 0x6a2ddc: stur            x1, [fp, #-0x10]
    // 0x6a2de0: r0 = ManualButton()
    //     0x6a2de0: bl              #0x69a8c4  ; AllocateManualButtonStub -> ManualButton (size=0x24)
    // 0x6a2de4: ldur            x2, [fp, #-0x18]
    // 0x6a2de8: r1 = Function '<anonymous closure>':.
    //     0x6a2de8: add             x1, PP, #0x28, lsl #12  ; [pp+0x283f0] AnonymousClosure: (0x6a569c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a2dec: ldr             x1, [x1, #0x3f0]
    // 0x6a2df0: stur            x0, [fp, #-0x20]
    // 0x6a2df4: r0 = AllocateClosure()
    //     0x6a2df4: bl              #0x826750  ; AllocateClosureStub
    // 0x6a2df8: mov             x1, x0
    // 0x6a2dfc: ldur            x0, [fp, #-0x20]
    // 0x6a2e00: StoreField: r0->field_b = r1
    //     0x6a2e00: stur            w1, [x0, #0xb]
    // 0x6a2e04: r1 = "Generate Symbols"
    //     0x6a2e04: add             x1, PP, #0x28, lsl #12  ; [pp+0x283f8] "Generate Symbols"
    //     0x6a2e08: ldr             x1, [x1, #0x3f8]
    // 0x6a2e0c: StoreField: r0->field_f = r1
    //     0x6a2e0c: stur            w1, [x0, #0xf]
    // 0x6a2e10: r1 = Instance_TextStyle
    //     0x6a2e10: add             x1, PP, #0x28, lsl #12  ; [pp+0x28400] Obj!TextStyle@849131
    //     0x6a2e14: ldr             x1, [x1, #0x400]
    // 0x6a2e18: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a2e18: stur            w1, [x0, #0x17]
    // 0x6a2e1c: r0 = TimedBlocker()
    //     0x6a2e1c: bl              #0x6a3dac  ; AllocateTimedBlockerStub -> TimedBlocker (size=0x14)
    // 0x6a2e20: mov             x2, x0
    // 0x6a2e24: ldur            x0, [fp, #-0x10]
    // 0x6a2e28: stur            x2, [fp, #-0x30]
    // 0x6a2e2c: StoreField: r2->field_b = r0
    //     0x6a2e2c: stur            w0, [x2, #0xb]
    // 0x6a2e30: ldur            x0, [fp, #-0x20]
    // 0x6a2e34: StoreField: r2->field_f = r0
    //     0x6a2e34: stur            w0, [x2, #0xf]
    // 0x6a2e38: ldur            x0, [fp, #-8]
    // 0x6a2e3c: LoadField: r3 = r0->field_37
    //     0x6a2e3c: ldur            w3, [x0, #0x37]
    // 0x6a2e40: DecompressPointer r3
    //     0x6a2e40: add             x3, x3, HEAP, lsl #32
    // 0x6a2e44: stur            x3, [fp, #-0x28]
    // 0x6a2e48: LoadField: r4 = r0->field_43
    //     0x6a2e48: ldur            w4, [x0, #0x43]
    // 0x6a2e4c: DecompressPointer r4
    //     0x6a2e4c: add             x4, x4, HEAP, lsl #32
    // 0x6a2e50: stur            x4, [fp, #-0x20]
    // 0x6a2e54: LoadField: r5 = r0->field_8f
    //     0x6a2e54: ldur            w5, [x0, #0x8f]
    // 0x6a2e58: DecompressPointer r5
    //     0x6a2e58: add             x5, x5, HEAP, lsl #32
    // 0x6a2e5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a2e60: cmp             w5, w16
    // 0x6a2e64: b.eq            #0x6a3da0
    // 0x6a2e68: stur            x5, [fp, #-0x10]
    // 0x6a2e6c: r1 = <Chapter15Stat>
    //     0x6a2e6c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a2e70: ldr             x1, [x1, #0xf98]
    // 0x6a2e74: r0 = UpgradeGroup()
    //     0x6a2e74: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6a2e78: mov             x3, x0
    // 0x6a2e7c: r0 = 1
    //     0x6a2e7c: movz            x0, #0x1
    // 0x6a2e80: stur            x3, [fp, #-0x38]
    // 0x6a2e84: StoreField: r3->field_13 = r0
    //     0x6a2e84: stur            x0, [x3, #0x13]
    // 0x6a2e88: ldur            x1, [fp, #-0x10]
    // 0x6a2e8c: StoreField: r3->field_1b = r1
    //     0x6a2e8c: stur            w1, [x3, #0x1b]
    // 0x6a2e90: ldur            x1, [fp, #-0x28]
    // 0x6a2e94: StoreField: r3->field_1f = r1
    //     0x6a2e94: stur            w1, [x3, #0x1f]
    // 0x6a2e98: ldur            x1, [fp, #-0x20]
    // 0x6a2e9c: StoreField: r3->field_23 = r1
    //     0x6a2e9c: stur            w1, [x3, #0x23]
    // 0x6a2ea0: r1 = Function '<anonymous closure>':.
    //     0x6a2ea0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28408] AnonymousClosure: (0x46c168), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a2ea4: ldr             x1, [x1, #0x408]
    // 0x6a2ea8: r2 = Null
    //     0x6a2ea8: mov             x2, NULL
    // 0x6a2eac: r0 = AllocateClosure()
    //     0x6a2eac: bl              #0x826750  ; AllocateClosureStub
    // 0x6a2eb0: mov             x1, x0
    // 0x6a2eb4: ldur            x0, [fp, #-0x38]
    // 0x6a2eb8: StoreField: r0->field_2b = r1
    //     0x6a2eb8: stur            w1, [x0, #0x2b]
    // 0x6a2ebc: r1 = const [0x1, 0x2, 0x3]
    //     0x6a2ebc: add             x1, PP, #0x26, lsl #12  ; [pp+0x268e0] List<int>(3)
    //     0x6a2ec0: ldr             x1, [x1, #0x8e0]
    // 0x6a2ec4: StoreField: r0->field_f = r1
    //     0x6a2ec4: stur            w1, [x0, #0xf]
    // 0x6a2ec8: r3 = true
    //     0x6a2ec8: add             x3, NULL, #0x20  ; true
    // 0x6a2ecc: StoreField: r0->field_27 = r3
    //     0x6a2ecc: stur            w3, [x0, #0x27]
    // 0x6a2ed0: r1 = Instance_UpgradeDisplayMode
    //     0x6a2ed0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ad8] Obj!UpgradeDisplayMode@85e881
    //     0x6a2ed4: ldr             x1, [x1, #0xad8]
    // 0x6a2ed8: StoreField: r0->field_2f = r1
    //     0x6a2ed8: stur            w1, [x0, #0x2f]
    // 0x6a2edc: r4 = false
    //     0x6a2edc: add             x4, NULL, #0x30  ; false
    // 0x6a2ee0: StoreField: r0->field_33 = r4
    //     0x6a2ee0: stur            w4, [x0, #0x33]
    // 0x6a2ee4: ldur            x2, [fp, #-0x18]
    // 0x6a2ee8: r1 = Function '<anonymous closure>':.
    //     0x6a2ee8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28410] AnonymousClosure: (0x6999a8), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x6a2eec: ldr             x1, [x1, #0x410]
    // 0x6a2ef0: r0 = AllocateClosure()
    //     0x6a2ef0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a2ef4: ldur            x2, [fp, #-0x38]
    // 0x6a2ef8: mov             x5, x0
    // 0x6a2efc: r1 = Null
    //     0x6a2efc: mov             x1, NULL
    // 0x6a2f00: r3 = "generate symbols upgrades"
    //     0x6a2f00: add             x3, PP, #0x28, lsl #12  ; [pp+0x28418] "generate symbols upgrades"
    //     0x6a2f04: ldr             x3, [x3, #0x418]
    // 0x6a2f08: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a2f08: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a2f0c: r0 = IdleFragment()
    //     0x6a2f0c: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a2f10: r1 = Null
    //     0x6a2f10: mov             x1, NULL
    // 0x6a2f14: r2 = 4
    //     0x6a2f14: movz            x2, #0x4
    // 0x6a2f18: stur            x0, [fp, #-0x10]
    // 0x6a2f1c: r0 = AllocateArray()
    //     0x6a2f1c: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a2f20: mov             x2, x0
    // 0x6a2f24: ldur            x0, [fp, #-0x30]
    // 0x6a2f28: stur            x2, [fp, #-0x20]
    // 0x6a2f2c: StoreField: r2->field_f = r0
    //     0x6a2f2c: stur            w0, [x2, #0xf]
    // 0x6a2f30: ldur            x0, [fp, #-0x10]
    // 0x6a2f34: StoreField: r2->field_13 = r0
    //     0x6a2f34: stur            w0, [x2, #0x13]
    // 0x6a2f38: r1 = <Widget>
    //     0x6a2f38: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a2f3c: r0 = AllocateGrowableArray()
    //     0x6a2f3c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a2f40: mov             x1, x0
    // 0x6a2f44: ldur            x0, [fp, #-0x20]
    // 0x6a2f48: stur            x1, [fp, #-0x10]
    // 0x6a2f4c: StoreField: r1->field_f = r0
    //     0x6a2f4c: stur            w0, [x1, #0xf]
    // 0x6a2f50: r2 = 4
    //     0x6a2f50: movz            x2, #0x4
    // 0x6a2f54: StoreField: r1->field_b = r2
    //     0x6a2f54: stur            w2, [x1, #0xb]
    // 0x6a2f58: r0 = Column()
    //     0x6a2f58: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6a2f5c: mov             x3, x0
    // 0x6a2f60: r0 = Instance_Axis
    //     0x6a2f60: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6a2f64: stur            x3, [fp, #-0x20]
    // 0x6a2f68: StoreField: r3->field_f = r0
    //     0x6a2f68: stur            w0, [x3, #0xf]
    // 0x6a2f6c: r4 = Instance_MainAxisAlignment
    //     0x6a2f6c: add             x4, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6a2f70: ldr             x4, [x4, #0x200]
    // 0x6a2f74: StoreField: r3->field_13 = r4
    //     0x6a2f74: stur            w4, [x3, #0x13]
    // 0x6a2f78: r5 = Instance_MainAxisSize
    //     0x6a2f78: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6a2f7c: ldr             x5, [x5, #0x70]
    // 0x6a2f80: ArrayStore: r3[0] = r5  ; List_4
    //     0x6a2f80: stur            w5, [x3, #0x17]
    // 0x6a2f84: r6 = Instance_CrossAxisAlignment
    //     0x6a2f84: add             x6, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6a2f88: ldr             x6, [x6, #0x78]
    // 0x6a2f8c: StoreField: r3->field_1b = r6
    //     0x6a2f8c: stur            w6, [x3, #0x1b]
    // 0x6a2f90: r7 = Instance_VerticalDirection
    //     0x6a2f90: add             x7, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6a2f94: ldr             x7, [x7, #0x1e8]
    // 0x6a2f98: StoreField: r3->field_23 = r7
    //     0x6a2f98: stur            w7, [x3, #0x23]
    // 0x6a2f9c: r8 = Instance_Clip
    //     0x6a2f9c: add             x8, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6a2fa0: ldr             x8, [x8, #0x1b0]
    // 0x6a2fa4: StoreField: r3->field_2b = r8
    //     0x6a2fa4: stur            w8, [x3, #0x2b]
    // 0x6a2fa8: StoreField: r3->field_2f = rZR
    //     0x6a2fa8: stur            xzr, [x3, #0x2f]
    // 0x6a2fac: ldur            x1, [fp, #-0x10]
    // 0x6a2fb0: StoreField: r3->field_b = r1
    //     0x6a2fb0: stur            w1, [x3, #0xb]
    // 0x6a2fb4: r1 = Function '<anonymous closure>':.
    //     0x6a2fb4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28420] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6a2fb8: ldr             x1, [x1, #0x420]
    // 0x6a2fbc: r2 = Null
    //     0x6a2fbc: mov             x2, NULL
    // 0x6a2fc0: r0 = AllocateClosure()
    //     0x6a2fc0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a2fc4: ldur            x2, [fp, #-0x20]
    // 0x6a2fc8: mov             x5, x0
    // 0x6a2fcc: r1 = Null
    //     0x6a2fcc: mov             x1, NULL
    // 0x6a2fd0: r3 = "Chapter 15 Generate Symbols"
    //     0x6a2fd0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28428] "Chapter 15 Generate Symbols"
    //     0x6a2fd4: ldr             x3, [x3, #0x428]
    // 0x6a2fd8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a2fd8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a2fdc: r0 = IdleFragment()
    //     0x6a2fdc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a2fe0: r1 = <Widget>
    //     0x6a2fe0: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a2fe4: r2 = 20
    //     0x6a2fe4: movz            x2, #0x14
    // 0x6a2fe8: stur            x0, [fp, #-0x10]
    // 0x6a2fec: r0 = AllocateArray()
    //     0x6a2fec: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a2ff0: mov             x2, x0
    // 0x6a2ff4: ldur            x0, [fp, #-0x10]
    // 0x6a2ff8: stur            x2, [fp, #-0x60]
    // 0x6a2ffc: StoreField: r2->field_f = r0
    //     0x6a2ffc: stur            w0, [x2, #0xf]
    // 0x6a3000: ldur            x0, [fp, #-8]
    // 0x6a3004: LoadField: r3 = r0->field_2b
    //     0x6a3004: ldur            w3, [x0, #0x2b]
    // 0x6a3008: DecompressPointer r3
    //     0x6a3008: add             x3, x3, HEAP, lsl #32
    // 0x6a300c: stur            x3, [fp, #-0x58]
    // 0x6a3010: LoadField: r4 = r0->field_37
    //     0x6a3010: ldur            w4, [x0, #0x37]
    // 0x6a3014: DecompressPointer r4
    //     0x6a3014: add             x4, x4, HEAP, lsl #32
    // 0x6a3018: stur            x4, [fp, #-0x50]
    // 0x6a301c: LoadField: r5 = r0->field_7
    //     0x6a301c: ldur            w5, [x0, #7]
    // 0x6a3020: DecompressPointer r5
    //     0x6a3020: add             x5, x5, HEAP, lsl #32
    // 0x6a3024: stur            x5, [fp, #-0x48]
    // 0x6a3028: LoadField: r6 = r0->field_4b
    //     0x6a3028: ldur            w6, [x0, #0x4b]
    // 0x6a302c: DecompressPointer r6
    //     0x6a302c: add             x6, x6, HEAP, lsl #32
    // 0x6a3030: stur            x6, [fp, #-0x40]
    // 0x6a3034: LoadField: r7 = r0->field_47
    //     0x6a3034: ldur            w7, [x0, #0x47]
    // 0x6a3038: DecompressPointer r7
    //     0x6a3038: add             x7, x7, HEAP, lsl #32
    // 0x6a303c: stur            x7, [fp, #-0x38]
    // 0x6a3040: LoadField: r8 = r0->field_53
    //     0x6a3040: ldur            w8, [x0, #0x53]
    // 0x6a3044: DecompressPointer r8
    //     0x6a3044: add             x8, x8, HEAP, lsl #32
    // 0x6a3048: stur            x8, [fp, #-0x30]
    // 0x6a304c: LoadField: r9 = r0->field_33
    //     0x6a304c: ldur            w9, [x0, #0x33]
    // 0x6a3050: DecompressPointer r9
    //     0x6a3050: add             x9, x9, HEAP, lsl #32
    // 0x6a3054: stur            x9, [fp, #-0x28]
    // 0x6a3058: LoadField: r10 = r0->field_2f
    //     0x6a3058: ldur            w10, [x0, #0x2f]
    // 0x6a305c: DecompressPointer r10
    //     0x6a305c: add             x10, x10, HEAP, lsl #32
    // 0x6a3060: stur            x10, [fp, #-0x20]
    // 0x6a3064: LoadField: r11 = r0->field_a3
    //     0x6a3064: ldur            w11, [x0, #0xa3]
    // 0x6a3068: DecompressPointer r11
    //     0x6a3068: add             x11, x11, HEAP, lsl #32
    // 0x6a306c: stur            x11, [fp, #-0x10]
    // 0x6a3070: r1 = <Chapter15Stat>
    //     0x6a3070: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a3074: ldr             x1, [x1, #0xf98]
    // 0x6a3078: r0 = GeneratorGroup()
    //     0x6a3078: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6a307c: mov             x3, x0
    // 0x6a3080: ldur            x0, [fp, #-0x50]
    // 0x6a3084: stur            x3, [fp, #-0x68]
    // 0x6a3088: StoreField: r3->field_1f = r0
    //     0x6a3088: stur            w0, [x3, #0x1f]
    // 0x6a308c: ldur            x2, [fp, #-8]
    // 0x6a3090: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x6a3090: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1caf0] AnonymousClosure: (0x3db3b8), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getCostToBuyOneMoreGenerator (0x3db270)
    //     0x6a3094: ldr             x1, [x1, #0xaf0]
    // 0x6a3098: r0 = AllocateClosure()
    //     0x6a3098: bl              #0x826750  ; AllocateClosureStub
    // 0x6a309c: mov             x3, x0
    // 0x6a30a0: ldur            x0, [fp, #-0x68]
    // 0x6a30a4: stur            x3, [fp, #-0x50]
    // 0x6a30a8: StoreField: r0->field_23 = r3
    //     0x6a30a8: stur            w3, [x0, #0x23]
    // 0x6a30ac: ldur            x2, [fp, #-8]
    // 0x6a30b0: r1 = Function 'getGeneratorInfo':.
    //     0x6a30b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28430] AnonymousClosure: (0x6a5660), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getGeneratorInfo (0x80d384)
    //     0x6a30b4: ldr             x1, [x1, #0x430]
    // 0x6a30b8: r0 = AllocateClosure()
    //     0x6a30b8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a30bc: mov             x3, x0
    // 0x6a30c0: ldur            x0, [fp, #-0x68]
    // 0x6a30c4: stur            x3, [fp, #-0x70]
    // 0x6a30c8: StoreField: r0->field_27 = r3
    //     0x6a30c8: stur            w3, [x0, #0x27]
    // 0x6a30cc: ldur            x1, [fp, #-0x40]
    // 0x6a30d0: StoreField: r0->field_2b = r1
    //     0x6a30d0: stur            w1, [x0, #0x2b]
    // 0x6a30d4: ldur            x1, [fp, #-0x38]
    // 0x6a30d8: StoreField: r0->field_2f = r1
    //     0x6a30d8: stur            w1, [x0, #0x2f]
    // 0x6a30dc: ldur            x1, [fp, #-0x30]
    // 0x6a30e0: StoreField: r0->field_33 = r1
    //     0x6a30e0: stur            w1, [x0, #0x33]
    // 0x6a30e4: r1 = Function '<anonymous closure>':.
    //     0x6a30e4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28438] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x6a30e8: ldr             x1, [x1, #0x438]
    // 0x6a30ec: r2 = Null
    //     0x6a30ec: mov             x2, NULL
    // 0x6a30f0: r0 = AllocateClosure()
    //     0x6a30f0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a30f4: mov             x1, x0
    // 0x6a30f8: ldur            x0, [fp, #-0x68]
    // 0x6a30fc: StoreField: r0->field_3b = r1
    //     0x6a30fc: stur            w1, [x0, #0x3b]
    // 0x6a3100: ldur            x3, [fp, #-0x28]
    // 0x6a3104: StoreField: r0->field_43 = r3
    //     0x6a3104: stur            w3, [x0, #0x43]
    // 0x6a3108: ldur            x4, [fp, #-0x20]
    // 0x6a310c: StoreField: r0->field_47 = r4
    //     0x6a310c: stur            w4, [x0, #0x47]
    // 0x6a3110: ldur            x2, [fp, #-8]
    // 0x6a3114: r1 = Function 'buyGenerator':.
    //     0x6a3114: add             x1, PP, #0x26, lsl #12  ; [pp+0x26108] AnonymousClosure: (0x545ec4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator (0x545790)
    //     0x6a3118: ldr             x1, [x1, #0x108]
    // 0x6a311c: r0 = AllocateClosure()
    //     0x6a311c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3120: mov             x3, x0
    // 0x6a3124: ldur            x0, [fp, #-0x68]
    // 0x6a3128: stur            x3, [fp, #-0x30]
    // 0x6a312c: StoreField: r0->field_5b = r3
    //     0x6a312c: stur            w3, [x0, #0x5b]
    // 0x6a3130: r1 = Function '<anonymous closure>':.
    //     0x6a3130: add             x1, PP, #0x28, lsl #12  ; [pp+0x28440] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a3134: ldr             x1, [x1, #0x440]
    // 0x6a3138: r2 = Null
    //     0x6a3138: mov             x2, NULL
    // 0x6a313c: r0 = AllocateClosure()
    //     0x6a313c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3140: mov             x1, x0
    // 0x6a3144: ldur            x0, [fp, #-0x68]
    // 0x6a3148: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a3148: stur            w1, [x0, #0x17]
    // 0x6a314c: r1 = Function '<anonymous closure>':.
    //     0x6a314c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28448] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a3150: ldr             x1, [x1, #0x448]
    // 0x6a3154: r2 = Null
    //     0x6a3154: mov             x2, NULL
    // 0x6a3158: r0 = AllocateClosure()
    //     0x6a3158: bl              #0x826750  ; AllocateClosureStub
    // 0x6a315c: mov             x1, x0
    // 0x6a3160: ldur            x0, [fp, #-0x68]
    // 0x6a3164: StoreField: r0->field_1b = r1
    //     0x6a3164: stur            w1, [x0, #0x1b]
    // 0x6a3168: ldur            x2, [fp, #-8]
    // 0x6a316c: r1 = Function 'makeGeneratorSubtitleText':.
    //     0x6a316c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] AnonymousClosure: (0x69637c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText (0x6963c4)
    //     0x6a3170: ldr             x1, [x1, #0x120]
    // 0x6a3174: r0 = AllocateClosure()
    //     0x6a3174: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3178: mov             x4, x0
    // 0x6a317c: ldur            x0, [fp, #-0x68]
    // 0x6a3180: stur            x4, [fp, #-0x38]
    // 0x6a3184: StoreField: r0->field_57 = r4
    //     0x6a3184: stur            w4, [x0, #0x57]
    // 0x6a3188: r1 = const [0x1, 0x2, 0x3, 0x4, 0x5, 0x6]
    //     0x6a3188: add             x1, PP, #0x28, lsl #12  ; [pp+0x28450] List<int>(6)
    //     0x6a318c: ldr             x1, [x1, #0x450]
    // 0x6a3190: StoreField: r0->field_53 = r1
    //     0x6a3190: stur            w1, [x0, #0x53]
    // 0x6a3194: ldur            x2, [fp, #-8]
    // 0x6a3198: ldur            x3, [fp, #-0x48]
    // 0x6a319c: r1 = Function 'getGeneratorSingleYieldsBoosted':.
    //     0x6a319c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0x54a720), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted (0x54a520)
    //     0x6a31a0: ldr             x1, [x1, #0x130]
    // 0x6a31a4: r0 = AllocateClosureTA()
    //     0x6a31a4: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x6a31a8: mov             x4, x0
    // 0x6a31ac: ldur            x0, [fp, #-0x68]
    // 0x6a31b0: stur            x4, [fp, #-0x40]
    // 0x6a31b4: StoreField: r0->field_6b = r4
    //     0x6a31b4: stur            w4, [x0, #0x6b]
    // 0x6a31b8: ldur            x1, [fp, #-0x58]
    // 0x6a31bc: StoreField: r0->field_4b = r1
    //     0x6a31bc: stur            w1, [x0, #0x4b]
    // 0x6a31c0: ldur            x1, [fp, #-0x10]
    // 0x6a31c4: StoreField: r0->field_67 = r1
    //     0x6a31c4: stur            w1, [x0, #0x67]
    // 0x6a31c8: ldur            x2, [fp, #-8]
    // 0x6a31cc: ldur            x3, [fp, #-0x48]
    // 0x6a31d0: r1 = Function 'getGeneratorBaseCost':.
    //     0x6a31d0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x6a31d4: ldr             x1, [x1, #0x138]
    // 0x6a31d8: r0 = AllocateClosureTA()
    //     0x6a31d8: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x6a31dc: mov             x3, x0
    // 0x6a31e0: ldur            x0, [fp, #-0x68]
    // 0x6a31e4: stur            x3, [fp, #-0x10]
    // 0x6a31e8: StoreField: r0->field_77 = r3
    //     0x6a31e8: stur            w3, [x0, #0x77]
    // 0x6a31ec: ldur            x2, [fp, #-8]
    // 0x6a31f0: r1 = Function 'getGeneratorMultiplier':.
    //     0x6a31f0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x6a31f4: ldr             x1, [x1, #0x140]
    // 0x6a31f8: r0 = AllocateClosure()
    //     0x6a31f8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a31fc: mov             x3, x0
    // 0x6a3200: ldur            x0, [fp, #-0x68]
    // 0x6a3204: stur            x3, [fp, #-0x48]
    // 0x6a3208: StoreField: r0->field_7b = r3
    //     0x6a3208: stur            w3, [x0, #0x7b]
    // 0x6a320c: r4 = "Chapter 15 Generators 1"
    //     0x6a320c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28458] "Chapter 15 Generators 1"
    //     0x6a3210: ldr             x4, [x4, #0x458]
    // 0x6a3214: StoreField: r0->field_73 = r4
    //     0x6a3214: stur            w4, [x0, #0x73]
    // 0x6a3218: ldur            x2, [fp, #-0x18]
    // 0x6a321c: r1 = Function '<anonymous closure>':.
    //     0x6a321c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28460] AnonymousClosure: (0x6999a8), in [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::build (0x6c0c94)
    //     0x6a3220: ldr             x1, [x1, #0x460]
    // 0x6a3224: r0 = AllocateClosure()
    //     0x6a3224: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3228: ldur            x2, [fp, #-0x68]
    // 0x6a322c: mov             x5, x0
    // 0x6a3230: r1 = Null
    //     0x6a3230: mov             x1, NULL
    // 0x6a3234: r3 = "Chapter 15 Generators 1"
    //     0x6a3234: add             x3, PP, #0x28, lsl #12  ; [pp+0x28458] "Chapter 15 Generators 1"
    //     0x6a3238: ldr             x3, [x3, #0x458]
    // 0x6a323c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a323c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a3240: r0 = IdleFragment()
    //     0x6a3240: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a3244: ldur            x1, [fp, #-0x60]
    // 0x6a3248: ArrayStore: r1[1] = r0  ; List_4
    //     0x6a3248: add             x25, x1, #0x13
    //     0x6a324c: str             w0, [x25]
    //     0x6a3250: tbz             w0, #0, #0x6a326c
    //     0x6a3254: ldurb           w16, [x1, #-1]
    //     0x6a3258: ldurb           w17, [x0, #-1]
    //     0x6a325c: and             x16, x17, x16, lsr #2
    //     0x6a3260: tst             x16, HEAP, lsr #32
    //     0x6a3264: b.eq            #0x6a326c
    //     0x6a3268: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a326c: r1 = Null
    //     0x6a326c: mov             x1, NULL
    // 0x6a3270: r2 = 4
    //     0x6a3270: movz            x2, #0x4
    // 0x6a3274: r0 = AllocateArray()
    //     0x6a3274: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a3278: r16 = "Chapter 15 Upgrades 2 "
    //     0x6a3278: add             x16, PP, #0x28, lsl #12  ; [pp+0x28468] "Chapter 15 Upgrades 2 "
    //     0x6a327c: ldr             x16, [x16, #0x468]
    // 0x6a3280: StoreField: r0->field_f = r16
    //     0x6a3280: stur            w16, [x0, #0xf]
    // 0x6a3284: ldur            x2, [fp, #-8]
    // 0x6a3288: LoadField: r1 = r2->field_43
    //     0x6a3288: ldur            w1, [x2, #0x43]
    // 0x6a328c: DecompressPointer r1
    //     0x6a328c: add             x1, x1, HEAP, lsl #32
    // 0x6a3290: LoadField: r3 = r1->field_13
    //     0x6a3290: ldur            w3, [x1, #0x13]
    // 0x6a3294: r4 = LoadInt32Instr(r3)
    //     0x6a3294: sbfx            x4, x3, #1, #0x1f
    // 0x6a3298: asr             x3, x4, #1
    // 0x6a329c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x6a329c: ldur            w4, [x1, #0x17]
    // 0x6a32a0: r1 = LoadInt32Instr(r4)
    //     0x6a32a0: sbfx            x1, x4, #1, #0x1f
    // 0x6a32a4: sub             x4, x3, x1
    // 0x6a32a8: lsl             x1, x4, #1
    // 0x6a32ac: StoreField: r0->field_13 = r1
    //     0x6a32ac: stur            w1, [x0, #0x13]
    // 0x6a32b0: str             x0, [SP]
    // 0x6a32b4: r0 = _interpolate()
    //     0x6a32b4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6a32b8: ldur            x2, [fp, #-8]
    // 0x6a32bc: stur            x0, [fp, #-0x80]
    // 0x6a32c0: LoadField: r3 = r2->field_37
    //     0x6a32c0: ldur            w3, [x2, #0x37]
    // 0x6a32c4: DecompressPointer r3
    //     0x6a32c4: add             x3, x3, HEAP, lsl #32
    // 0x6a32c8: stur            x3, [fp, #-0x78]
    // 0x6a32cc: LoadField: r4 = r2->field_43
    //     0x6a32cc: ldur            w4, [x2, #0x43]
    // 0x6a32d0: DecompressPointer r4
    //     0x6a32d0: add             x4, x4, HEAP, lsl #32
    // 0x6a32d4: stur            x4, [fp, #-0x68]
    // 0x6a32d8: LoadField: r5 = r2->field_8f
    //     0x6a32d8: ldur            w5, [x2, #0x8f]
    // 0x6a32dc: DecompressPointer r5
    //     0x6a32dc: add             x5, x5, HEAP, lsl #32
    // 0x6a32e0: stur            x5, [fp, #-0x58]
    // 0x6a32e4: r1 = <Chapter15Stat>
    //     0x6a32e4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a32e8: ldr             x1, [x1, #0xf98]
    // 0x6a32ec: r0 = UpgradeGroup()
    //     0x6a32ec: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6a32f0: mov             x3, x0
    // 0x6a32f4: r0 = 2
    //     0x6a32f4: movz            x0, #0x2
    // 0x6a32f8: stur            x3, [fp, #-0x88]
    // 0x6a32fc: StoreField: r3->field_13 = r0
    //     0x6a32fc: stur            x0, [x3, #0x13]
    // 0x6a3300: ldur            x1, [fp, #-0x58]
    // 0x6a3304: StoreField: r3->field_1b = r1
    //     0x6a3304: stur            w1, [x3, #0x1b]
    // 0x6a3308: ldur            x1, [fp, #-0x78]
    // 0x6a330c: StoreField: r3->field_1f = r1
    //     0x6a330c: stur            w1, [x3, #0x1f]
    // 0x6a3310: ldur            x1, [fp, #-0x68]
    // 0x6a3314: StoreField: r3->field_23 = r1
    //     0x6a3314: stur            w1, [x3, #0x23]
    // 0x6a3318: r1 = Function '<anonymous closure>':.
    //     0x6a3318: add             x1, PP, #0x28, lsl #12  ; [pp+0x28470] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a331c: ldr             x1, [x1, #0x470]
    // 0x6a3320: r2 = Null
    //     0x6a3320: mov             x2, NULL
    // 0x6a3324: r0 = AllocateClosure()
    //     0x6a3324: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3328: mov             x1, x0
    // 0x6a332c: ldur            x0, [fp, #-0x88]
    // 0x6a3330: StoreField: r0->field_2b = r1
    //     0x6a3330: stur            w1, [x0, #0x2b]
    // 0x6a3334: r3 = const [0xb, 0xc, 0xd, 0xe]
    //     0x6a3334: add             x3, PP, #0x26, lsl #12  ; [pp+0x261f8] List<int>(4)
    //     0x6a3338: ldr             x3, [x3, #0x1f8]
    // 0x6a333c: StoreField: r0->field_f = r3
    //     0x6a333c: stur            w3, [x0, #0xf]
    // 0x6a3340: r4 = true
    //     0x6a3340: add             x4, NULL, #0x20  ; true
    // 0x6a3344: StoreField: r0->field_27 = r4
    //     0x6a3344: stur            w4, [x0, #0x27]
    // 0x6a3348: r5 = Instance_UpgradeDisplayMode
    //     0x6a3348: add             x5, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x6a334c: ldr             x5, [x5, #0x608]
    // 0x6a3350: StoreField: r0->field_2f = r5
    //     0x6a3350: stur            w5, [x0, #0x2f]
    // 0x6a3354: r6 = false
    //     0x6a3354: add             x6, NULL, #0x30  ; false
    // 0x6a3358: StoreField: r0->field_33 = r6
    //     0x6a3358: stur            w6, [x0, #0x33]
    // 0x6a335c: ldur            x2, [fp, #-0x18]
    // 0x6a3360: r1 = Function '<anonymous closure>':.
    //     0x6a3360: add             x1, PP, #0x28, lsl #12  ; [pp+0x28478] AnonymousClosure: (0x69b1c8), in [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::build (0x6c4f2c)
    //     0x6a3364: ldr             x1, [x1, #0x478]
    // 0x6a3368: r0 = AllocateClosure()
    //     0x6a3368: bl              #0x826750  ; AllocateClosureStub
    // 0x6a336c: ldur            x2, [fp, #-0x88]
    // 0x6a3370: ldur            x3, [fp, #-0x80]
    // 0x6a3374: mov             x5, x0
    // 0x6a3378: r1 = Null
    //     0x6a3378: mov             x1, NULL
    // 0x6a337c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a337c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a3380: r0 = IdleFragment()
    //     0x6a3380: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a3384: ldur            x1, [fp, #-0x60]
    // 0x6a3388: ArrayStore: r1[2] = r0  ; List_4
    //     0x6a3388: add             x25, x1, #0x17
    //     0x6a338c: str             w0, [x25]
    //     0x6a3390: tbz             w0, #0, #0x6a33ac
    //     0x6a3394: ldurb           w16, [x1, #-1]
    //     0x6a3398: ldurb           w17, [x0, #-1]
    //     0x6a339c: and             x16, x17, x16, lsr #2
    //     0x6a33a0: tst             x16, HEAP, lsr #32
    //     0x6a33a4: b.eq            #0x6a33ac
    //     0x6a33a8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a33ac: ldur            x0, [fp, #-8]
    // 0x6a33b0: LoadField: r3 = r0->field_37
    //     0x6a33b0: ldur            w3, [x0, #0x37]
    // 0x6a33b4: DecompressPointer r3
    //     0x6a33b4: add             x3, x3, HEAP, lsl #32
    // 0x6a33b8: stur            x3, [fp, #-0x58]
    // 0x6a33bc: r1 = Function '<anonymous closure>':.
    //     0x6a33bc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28480] AnonymousClosure: (0x6a5654), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a33c0: ldr             x1, [x1, #0x480]
    // 0x6a33c4: r2 = Null
    //     0x6a33c4: mov             x2, NULL
    // 0x6a33c8: r0 = AllocateClosure()
    //     0x6a33c8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a33cc: r1 = <Chapter15Stat>
    //     0x6a33cc: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a33d0: ldr             x1, [x1, #0xf98]
    // 0x6a33d4: stur            x0, [fp, #-0x68]
    // 0x6a33d8: r0 = PrestigeButton()
    //     0x6a33d8: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6a33dc: mov             x3, x0
    // 0x6a33e0: ldur            x0, [fp, #-0x68]
    // 0x6a33e4: stur            x3, [fp, #-0x78]
    // 0x6a33e8: StoreField: r3->field_1f = r0
    //     0x6a33e8: stur            w0, [x3, #0x1f]
    // 0x6a33ec: r0 = Instance_Chapter15Stat
    //     0x6a33ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x6a33f0: ldr             x0, [x0, #0xc0]
    // 0x6a33f4: StoreField: r3->field_1b = r0
    //     0x6a33f4: stur            w0, [x3, #0x1b]
    // 0x6a33f8: ldur            x2, [fp, #-8]
    // 0x6a33fc: r1 = Function 'getPushPrestigePoints':.
    //     0x6a33fc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28488] AnonymousClosure: (0x6a561c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getPushPrestigePoints (0x6a49d4)
    //     0x6a3400: ldr             x1, [x1, #0x488]
    // 0x6a3404: r0 = AllocateClosure()
    //     0x6a3404: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3408: mov             x1, x0
    // 0x6a340c: ldur            x0, [fp, #-0x78]
    // 0x6a3410: StoreField: r0->field_2f = r1
    //     0x6a3410: stur            w1, [x0, #0x2f]
    // 0x6a3414: ldur            x2, [fp, #-8]
    // 0x6a3418: r1 = Function 'applyPullPrestige':.
    //     0x6a3418: add             x1, PP, #0x28, lsl #12  ; [pp+0x28490] AnonymousClosure: (0x6a55e4), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::applyPullPrestige (0x6a41d8)
    //     0x6a341c: ldr             x1, [x1, #0x490]
    // 0x6a3420: r0 = AllocateClosure()
    //     0x6a3420: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3424: mov             x1, x0
    // 0x6a3428: ldur            x0, [fp, #-0x78]
    // 0x6a342c: StoreField: r0->field_33 = r1
    //     0x6a342c: stur            w1, [x0, #0x33]
    // 0x6a3430: ldur            x1, [fp, #-0x58]
    // 0x6a3434: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a3434: stur            w1, [x0, #0x17]
    // 0x6a3438: r3 = Closure: (Chapter15Stat?) => String from Function 'humanName': static.
    //     0x6a3438: add             x3, PP, #0x28, lsl #12  ; [pp+0x28498] Closure: (Chapter15Stat?) => String from Function 'humanName': static. (0x248ed99c008)
    //     0x6a343c: ldr             x3, [x3, #0x498]
    // 0x6a3440: StoreField: r0->field_43 = r3
    //     0x6a3440: stur            w3, [x0, #0x43]
    // 0x6a3444: r1 = Function '<anonymous closure>':.
    //     0x6a3444: add             x1, PP, #0x28, lsl #12  ; [pp+0x284a0] AnonymousClosure: (0x6a55d8), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3448: ldr             x1, [x1, #0x4a0]
    // 0x6a344c: r2 = Null
    //     0x6a344c: mov             x2, NULL
    // 0x6a3450: r0 = AllocateClosure()
    //     0x6a3450: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3454: mov             x1, x0
    // 0x6a3458: ldur            x0, [fp, #-0x78]
    // 0x6a345c: StoreField: r0->field_23 = r1
    //     0x6a345c: stur            w1, [x0, #0x23]
    // 0x6a3460: r1 = "everything above"
    //     0x6a3460: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b0] "everything above"
    //     0x6a3464: ldr             x1, [x1, #0x1b0]
    // 0x6a3468: StoreField: r0->field_3f = r1
    //     0x6a3468: stur            w1, [x0, #0x3f]
    // 0x6a346c: r3 = false
    //     0x6a346c: add             x3, NULL, #0x30  ; false
    // 0x6a3470: StoreField: r0->field_f = r3
    //     0x6a3470: stur            w3, [x0, #0xf]
    // 0x6a3474: StoreField: r0->field_4f = r3
    //     0x6a3474: stur            w3, [x0, #0x4f]
    // 0x6a3478: r4 = true
    //     0x6a3478: add             x4, NULL, #0x20  ; true
    // 0x6a347c: StoreField: r0->field_2b = r4
    //     0x6a347c: stur            w4, [x0, #0x2b]
    // 0x6a3480: StoreField: r0->field_53 = r3
    //     0x6a3480: stur            w3, [x0, #0x53]
    // 0x6a3484: StoreField: r0->field_5b = r4
    //     0x6a3484: stur            w4, [x0, #0x5b]
    // 0x6a3488: r5 = "Gain"
    //     0x6a3488: add             x5, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6a348c: ldr             x5, [x5, #0x1b8]
    // 0x6a3490: StoreField: r0->field_5f = r5
    //     0x6a3490: stur            w5, [x0, #0x5f]
    // 0x6a3494: ldur            x2, [fp, #-0x18]
    // 0x6a3498: r1 = Function '<anonymous closure>':.
    //     0x6a3498: add             x1, PP, #0x28, lsl #12  ; [pp+0x284a8] AnonymousClosure: (0x6a558c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a349c: ldr             x1, [x1, #0x4a8]
    // 0x6a34a0: r0 = AllocateClosure()
    //     0x6a34a0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a34a4: ldur            x2, [fp, #-0x78]
    // 0x6a34a8: mov             x5, x0
    // 0x6a34ac: r1 = Null
    //     0x6a34ac: mov             x1, NULL
    // 0x6a34b0: r3 = "Chapter 15 Prestige 1"
    //     0x6a34b0: add             x3, PP, #0x28, lsl #12  ; [pp+0x284b0] "Chapter 15 Prestige 1"
    //     0x6a34b4: ldr             x3, [x3, #0x4b0]
    // 0x6a34b8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a34b8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a34bc: r0 = IdleFragment()
    //     0x6a34bc: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a34c0: ldur            x1, [fp, #-0x60]
    // 0x6a34c4: ArrayStore: r1[3] = r0  ; List_4
    //     0x6a34c4: add             x25, x1, #0x1b
    //     0x6a34c8: str             w0, [x25]
    //     0x6a34cc: tbz             w0, #0, #0x6a34e8
    //     0x6a34d0: ldurb           w16, [x1, #-1]
    //     0x6a34d4: ldurb           w17, [x0, #-1]
    //     0x6a34d8: and             x16, x17, x16, lsr #2
    //     0x6a34dc: tst             x16, HEAP, lsr #32
    //     0x6a34e0: b.eq            #0x6a34e8
    //     0x6a34e4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a34e8: ldur            x2, [fp, #-8]
    // 0x6a34ec: LoadField: r0 = r2->field_37
    //     0x6a34ec: ldur            w0, [x2, #0x37]
    // 0x6a34f0: DecompressPointer r0
    //     0x6a34f0: add             x0, x0, HEAP, lsl #32
    // 0x6a34f4: stur            x0, [fp, #-0x58]
    // 0x6a34f8: r1 = <Chapter15Stat>
    //     0x6a34f8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a34fc: ldr             x1, [x1, #0xf98]
    // 0x6a3500: r0 = IntermissionButton()
    //     0x6a3500: bl              #0x697ee8  ; AllocateIntermissionButtonStub -> IntermissionButton<X0> (size=0x28)
    // 0x6a3504: mov             x3, x0
    // 0x6a3508: ldur            x0, [fp, #-0x58]
    // 0x6a350c: stur            x3, [fp, #-0x68]
    // 0x6a3510: StoreField: r3->field_1b = r0
    //     0x6a3510: stur            w0, [x3, #0x1b]
    // 0x6a3514: r0 = Instance_Tuple2
    //     0x6a3514: add             x0, PP, #0x28, lsl #12  ; [pp+0x284b8] Obj!Tuple2<Chapter15Stat, CustomNum>@826c51
    //     0x6a3518: ldr             x0, [x0, #0x4b8]
    // 0x6a351c: StoreField: r3->field_1f = r0
    //     0x6a351c: stur            w0, [x3, #0x1f]
    // 0x6a3520: ldur            x2, [fp, #-0x18]
    // 0x6a3524: r1 = Function '<anonymous closure>':.
    //     0x6a3524: add             x1, PP, #0x28, lsl #12  ; [pp+0x284c0] AnonymousClosure: (0x6a549c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3528: ldr             x1, [x1, #0x4c0]
    // 0x6a352c: r0 = AllocateClosure()
    //     0x6a352c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3530: mov             x1, x0
    // 0x6a3534: ldur            x0, [fp, #-0x68]
    // 0x6a3538: StoreField: r0->field_23 = r1
    //     0x6a3538: stur            w1, [x0, #0x23]
    // 0x6a353c: r1 = Function '<anonymous closure>':.
    //     0x6a353c: add             x1, PP, #0x28, lsl #12  ; [pp+0x284c8] Function: [dart:core] Object::_simpleInstanceOfFalse (0x821f2c)
    //     0x6a3540: ldr             x1, [x1, #0x4c8]
    // 0x6a3544: r2 = Null
    //     0x6a3544: mov             x2, NULL
    // 0x6a3548: r0 = AllocateClosure()
    //     0x6a3548: bl              #0x826750  ; AllocateClosureStub
    // 0x6a354c: mov             x1, x0
    // 0x6a3550: ldur            x0, [fp, #-0x68]
    // 0x6a3554: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a3554: stur            w1, [x0, #0x17]
    // 0x6a3558: r3 = Closure: (Chapter15Stat?) => String from Function 'humanName': static.
    //     0x6a3558: add             x3, PP, #0x28, lsl #12  ; [pp+0x28498] Closure: (Chapter15Stat?) => String from Function 'humanName': static. (0x248ed99c008)
    //     0x6a355c: ldr             x3, [x3, #0x498]
    // 0x6a3560: StoreField: r0->field_f = r3
    //     0x6a3560: stur            w3, [x0, #0xf]
    // 0x6a3564: ldur            x2, [fp, #-0x18]
    // 0x6a3568: r1 = Function '<anonymous closure>':.
    //     0x6a3568: add             x1, PP, #0x28, lsl #12  ; [pp+0x284d0] AnonymousClosure: (0x6a53f0), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a356c: ldr             x1, [x1, #0x4d0]
    // 0x6a3570: r0 = AllocateClosure()
    //     0x6a3570: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3574: ldur            x2, [fp, #-0x18]
    // 0x6a3578: r1 = Function '<anonymous closure>':.
    //     0x6a3578: add             x1, PP, #0x28, lsl #12  ; [pp+0x284d8] AnonymousClosure: (0x6a53a4), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a357c: ldr             x1, [x1, #0x4d8]
    // 0x6a3580: stur            x0, [fp, #-0x58]
    // 0x6a3584: r0 = AllocateClosure()
    //     0x6a3584: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3588: ldur            x16, [fp, #-0x58]
    // 0x6a358c: str             x16, [SP]
    // 0x6a3590: ldur            x2, [fp, #-0x68]
    // 0x6a3594: mov             x5, x0
    // 0x6a3598: r1 = Null
    //     0x6a3598: mov             x1, NULL
    // 0x6a359c: r3 = "Chapter 15 Intermission"
    //     0x6a359c: add             x3, PP, #0x28, lsl #12  ; [pp+0x284e0] "Chapter 15 Intermission"
    //     0x6a35a0: ldr             x3, [x3, #0x4e0]
    // 0x6a35a4: r4 = const [0, 0x5, 0x1, 0x4, generateMinimizedName, 0x4, null]
    //     0x6a35a4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26160] List(7) [0, 0x5, 0x1, 0x4, "generateMinimizedName", 0x4, Null]
    //     0x6a35a8: ldr             x4, [x4, #0x160]
    // 0x6a35ac: r0 = IdleFragment()
    //     0x6a35ac: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a35b0: ldur            x1, [fp, #-0x60]
    // 0x6a35b4: ArrayStore: r1[4] = r0  ; List_4
    //     0x6a35b4: add             x25, x1, #0x1f
    //     0x6a35b8: str             w0, [x25]
    //     0x6a35bc: tbz             w0, #0, #0x6a35d8
    //     0x6a35c0: ldurb           w16, [x1, #-1]
    //     0x6a35c4: ldurb           w17, [x0, #-1]
    //     0x6a35c8: and             x16, x17, x16, lsr #2
    //     0x6a35cc: tst             x16, HEAP, lsr #32
    //     0x6a35d0: b.eq            #0x6a35d8
    //     0x6a35d4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a35d8: r0 = CurrencyCounter()
    //     0x6a35d8: bl              #0x697ef4  ; AllocateCurrencyCounterStub -> CurrencyCounter (size=0x28)
    // 0x6a35dc: mov             x3, x0
    // 0x6a35e0: r0 = "Stars"
    //     0x6a35e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x110d0] "Stars"
    //     0x6a35e4: ldr             x0, [x0, #0xd0]
    // 0x6a35e8: stur            x3, [fp, #-0x58]
    // 0x6a35ec: StoreField: r3->field_b = r0
    //     0x6a35ec: stur            w0, [x3, #0xb]
    // 0x6a35f0: ldur            x2, [fp, #-0x18]
    // 0x6a35f4: r1 = Function '<anonymous closure>':.
    //     0x6a35f4: add             x1, PP, #0x28, lsl #12  ; [pp+0x284e8] AnonymousClosure: (0x6a52fc), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a35f8: ldr             x1, [x1, #0x4e8]
    // 0x6a35fc: r0 = AllocateClosure()
    //     0x6a35fc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3600: mov             x1, x0
    // 0x6a3604: ldur            x0, [fp, #-0x58]
    // 0x6a3608: StoreField: r0->field_f = r1
    //     0x6a3608: stur            w1, [x0, #0xf]
    // 0x6a360c: r2 = false
    //     0x6a360c: add             x2, NULL, #0x30  ; false
    // 0x6a3610: StoreField: r0->field_1f = r2
    //     0x6a3610: stur            w2, [x0, #0x1f]
    // 0x6a3614: ldur            x3, [fp, #-8]
    // 0x6a3618: LoadField: r4 = r3->field_2b
    //     0x6a3618: ldur            w4, [x3, #0x2b]
    // 0x6a361c: DecompressPointer r4
    //     0x6a361c: add             x4, x4, HEAP, lsl #32
    // 0x6a3620: stur            x4, [fp, #-0xa0]
    // 0x6a3624: LoadField: r5 = r3->field_37
    //     0x6a3624: ldur            w5, [x3, #0x37]
    // 0x6a3628: DecompressPointer r5
    //     0x6a3628: add             x5, x5, HEAP, lsl #32
    // 0x6a362c: stur            x5, [fp, #-0x98]
    // 0x6a3630: LoadField: r6 = r3->field_9f
    //     0x6a3630: ldur            w6, [x3, #0x9f]
    // 0x6a3634: DecompressPointer r6
    //     0x6a3634: add             x6, x6, HEAP, lsl #32
    // 0x6a3638: stur            x6, [fp, #-0x90]
    // 0x6a363c: LoadField: r7 = r3->field_4b
    //     0x6a363c: ldur            w7, [x3, #0x4b]
    // 0x6a3640: DecompressPointer r7
    //     0x6a3640: add             x7, x7, HEAP, lsl #32
    // 0x6a3644: stur            x7, [fp, #-0x88]
    // 0x6a3648: LoadField: r8 = r3->field_47
    //     0x6a3648: ldur            w8, [x3, #0x47]
    // 0x6a364c: DecompressPointer r8
    //     0x6a364c: add             x8, x8, HEAP, lsl #32
    // 0x6a3650: stur            x8, [fp, #-0x80]
    // 0x6a3654: LoadField: r9 = r3->field_53
    //     0x6a3654: ldur            w9, [x3, #0x53]
    // 0x6a3658: DecompressPointer r9
    //     0x6a3658: add             x9, x9, HEAP, lsl #32
    // 0x6a365c: stur            x9, [fp, #-0x78]
    // 0x6a3660: LoadField: r10 = r3->field_a3
    //     0x6a3660: ldur            w10, [x3, #0xa3]
    // 0x6a3664: DecompressPointer r10
    //     0x6a3664: add             x10, x10, HEAP, lsl #32
    // 0x6a3668: stur            x10, [fp, #-0x68]
    // 0x6a366c: r1 = <Chapter15Stat>
    //     0x6a366c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a3670: ldr             x1, [x1, #0xf98]
    // 0x6a3674: r0 = GeneratorGroup()
    //     0x6a3674: bl              #0x6937b0  ; AllocateGeneratorGroupStub -> GeneratorGroup<X0> (size=0x80)
    // 0x6a3678: mov             x3, x0
    // 0x6a367c: ldur            x0, [fp, #-0x98]
    // 0x6a3680: stur            x3, [fp, #-0xa8]
    // 0x6a3684: StoreField: r3->field_1f = r0
    //     0x6a3684: stur            w0, [x3, #0x1f]
    // 0x6a3688: ldur            x0, [fp, #-0x50]
    // 0x6a368c: StoreField: r3->field_23 = r0
    //     0x6a368c: stur            w0, [x3, #0x23]
    // 0x6a3690: ldur            x0, [fp, #-0x70]
    // 0x6a3694: StoreField: r3->field_27 = r0
    //     0x6a3694: stur            w0, [x3, #0x27]
    // 0x6a3698: ldur            x0, [fp, #-0x88]
    // 0x6a369c: StoreField: r3->field_2b = r0
    //     0x6a369c: stur            w0, [x3, #0x2b]
    // 0x6a36a0: ldur            x0, [fp, #-0x80]
    // 0x6a36a4: StoreField: r3->field_2f = r0
    //     0x6a36a4: stur            w0, [x3, #0x2f]
    // 0x6a36a8: ldur            x0, [fp, #-0x78]
    // 0x6a36ac: StoreField: r3->field_33 = r0
    //     0x6a36ac: stur            w0, [x3, #0x33]
    // 0x6a36b0: ldur            x2, [fp, #-0x18]
    // 0x6a36b4: r1 = Function '<anonymous closure>':.
    //     0x6a36b4: add             x1, PP, #0x28, lsl #12  ; [pp+0x284f0] AnonymousClosure: (0x6a52b0), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a36b8: ldr             x1, [x1, #0x4f0]
    // 0x6a36bc: r0 = AllocateClosure()
    //     0x6a36bc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a36c0: mov             x1, x0
    // 0x6a36c4: ldur            x0, [fp, #-0xa8]
    // 0x6a36c8: StoreField: r0->field_3b = r1
    //     0x6a36c8: stur            w1, [x0, #0x3b]
    // 0x6a36cc: ldur            x1, [fp, #-0x90]
    // 0x6a36d0: StoreField: r0->field_3f = r1
    //     0x6a36d0: stur            w1, [x0, #0x3f]
    // 0x6a36d4: ldur            x1, [fp, #-0x28]
    // 0x6a36d8: StoreField: r0->field_43 = r1
    //     0x6a36d8: stur            w1, [x0, #0x43]
    // 0x6a36dc: ldur            x1, [fp, #-0x20]
    // 0x6a36e0: StoreField: r0->field_47 = r1
    //     0x6a36e0: stur            w1, [x0, #0x47]
    // 0x6a36e4: ldur            x2, [fp, #-0x18]
    // 0x6a36e8: r1 = Function '<anonymous closure>':.
    //     0x6a36e8: add             x1, PP, #0x28, lsl #12  ; [pp+0x284f8] AnonymousClosure: (0x6a51d8), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a36ec: ldr             x1, [x1, #0x4f8]
    // 0x6a36f0: r0 = AllocateClosure()
    //     0x6a36f0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a36f4: mov             x1, x0
    // 0x6a36f8: ldur            x0, [fp, #-0xa8]
    // 0x6a36fc: StoreField: r0->field_4f = r1
    //     0x6a36fc: stur            w1, [x0, #0x4f]
    // 0x6a3700: ldur            x1, [fp, #-0x30]
    // 0x6a3704: StoreField: r0->field_5b = r1
    //     0x6a3704: stur            w1, [x0, #0x5b]
    // 0x6a3708: r1 = Function '<anonymous closure>':.
    //     0x6a3708: add             x1, PP, #0x28, lsl #12  ; [pp+0x28500] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a370c: ldr             x1, [x1, #0x500]
    // 0x6a3710: r2 = Null
    //     0x6a3710: mov             x2, NULL
    // 0x6a3714: r0 = AllocateClosure()
    //     0x6a3714: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3718: mov             x1, x0
    // 0x6a371c: ldur            x0, [fp, #-0xa8]
    // 0x6a3720: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a3720: stur            w1, [x0, #0x17]
    // 0x6a3724: r1 = Function '<anonymous closure>':.
    //     0x6a3724: add             x1, PP, #0x28, lsl #12  ; [pp+0x28508] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a3728: ldr             x1, [x1, #0x508]
    // 0x6a372c: r2 = Null
    //     0x6a372c: mov             x2, NULL
    // 0x6a3730: r0 = AllocateClosure()
    //     0x6a3730: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3734: mov             x1, x0
    // 0x6a3738: ldur            x0, [fp, #-0xa8]
    // 0x6a373c: StoreField: r0->field_1b = r1
    //     0x6a373c: stur            w1, [x0, #0x1b]
    // 0x6a3740: ldur            x1, [fp, #-0x38]
    // 0x6a3744: StoreField: r0->field_57 = r1
    //     0x6a3744: stur            w1, [x0, #0x57]
    // 0x6a3748: r1 = const [0xb, 0xc, 0xd, 0xe]
    //     0x6a3748: add             x1, PP, #0x26, lsl #12  ; [pp+0x261f8] List<int>(4)
    //     0x6a374c: ldr             x1, [x1, #0x1f8]
    // 0x6a3750: StoreField: r0->field_53 = r1
    //     0x6a3750: stur            w1, [x0, #0x53]
    // 0x6a3754: ldur            x2, [fp, #-0x18]
    // 0x6a3758: r1 = Function '<anonymous closure>':.
    //     0x6a3758: add             x1, PP, #0x28, lsl #12  ; [pp+0x28510] AnonymousClosure: (0x6a4d7c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a375c: ldr             x1, [x1, #0x510]
    // 0x6a3760: r0 = AllocateClosure()
    //     0x6a3760: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3764: mov             x1, x0
    // 0x6a3768: ldur            x0, [fp, #-0xa8]
    // 0x6a376c: StoreField: r0->field_63 = r1
    //     0x6a376c: stur            w1, [x0, #0x63]
    // 0x6a3770: ldur            x1, [fp, #-0x40]
    // 0x6a3774: StoreField: r0->field_6b = r1
    //     0x6a3774: stur            w1, [x0, #0x6b]
    // 0x6a3778: ldur            x1, [fp, #-0xa0]
    // 0x6a377c: StoreField: r0->field_4b = r1
    //     0x6a377c: stur            w1, [x0, #0x4b]
    // 0x6a3780: ldur            x1, [fp, #-0x58]
    // 0x6a3784: StoreField: r0->field_f = r1
    //     0x6a3784: stur            w1, [x0, #0xf]
    // 0x6a3788: ldur            x1, [fp, #-0x68]
    // 0x6a378c: StoreField: r0->field_67 = r1
    //     0x6a378c: stur            w1, [x0, #0x67]
    // 0x6a3790: ldur            x1, [fp, #-0x10]
    // 0x6a3794: StoreField: r0->field_77 = r1
    //     0x6a3794: stur            w1, [x0, #0x77]
    // 0x6a3798: ldur            x1, [fp, #-0x48]
    // 0x6a379c: StoreField: r0->field_7b = r1
    //     0x6a379c: stur            w1, [x0, #0x7b]
    // 0x6a37a0: r3 = "Chapter 15 Generators 2"
    //     0x6a37a0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28518] "Chapter 15 Generators 2"
    //     0x6a37a4: ldr             x3, [x3, #0x518]
    // 0x6a37a8: StoreField: r0->field_73 = r3
    //     0x6a37a8: stur            w3, [x0, #0x73]
    // 0x6a37ac: ldur            x2, [fp, #-0x18]
    // 0x6a37b0: r1 = Function '<anonymous closure>':.
    //     0x6a37b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28520] AnonymousClosure: (0x6a4c5c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a37b4: ldr             x1, [x1, #0x520]
    // 0x6a37b8: r0 = AllocateClosure()
    //     0x6a37b8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a37bc: ldur            x2, [fp, #-0xa8]
    // 0x6a37c0: mov             x5, x0
    // 0x6a37c4: r1 = Null
    //     0x6a37c4: mov             x1, NULL
    // 0x6a37c8: r3 = "Chapter 15 Generators 2"
    //     0x6a37c8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28518] "Chapter 15 Generators 2"
    //     0x6a37cc: ldr             x3, [x3, #0x518]
    // 0x6a37d0: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a37d0: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a37d4: r0 = IdleFragment()
    //     0x6a37d4: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a37d8: ldur            x1, [fp, #-0x60]
    // 0x6a37dc: ArrayStore: r1[5] = r0  ; List_4
    //     0x6a37dc: add             x25, x1, #0x23
    //     0x6a37e0: str             w0, [x25]
    //     0x6a37e4: tbz             w0, #0, #0x6a3800
    //     0x6a37e8: ldurb           w16, [x1, #-1]
    //     0x6a37ec: ldurb           w17, [x0, #-1]
    //     0x6a37f0: and             x16, x17, x16, lsr #2
    //     0x6a37f4: tst             x16, HEAP, lsr #32
    //     0x6a37f8: b.eq            #0x6a3800
    //     0x6a37fc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a3800: ldur            x0, [fp, #-8]
    // 0x6a3804: LoadField: r3 = r0->field_37
    //     0x6a3804: ldur            w3, [x0, #0x37]
    // 0x6a3808: DecompressPointer r3
    //     0x6a3808: add             x3, x3, HEAP, lsl #32
    // 0x6a380c: stur            x3, [fp, #-0x10]
    // 0x6a3810: r1 = Function '<anonymous closure>':.
    //     0x6a3810: add             x1, PP, #0x28, lsl #12  ; [pp+0x28528] AnonymousClosure: (0x6a4d70), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3814: ldr             x1, [x1, #0x528]
    // 0x6a3818: r2 = Null
    //     0x6a3818: mov             x2, NULL
    // 0x6a381c: r0 = AllocateClosure()
    //     0x6a381c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3820: r1 = <Chapter15Stat>
    //     0x6a3820: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a3824: ldr             x1, [x1, #0xf98]
    // 0x6a3828: stur            x0, [fp, #-0x20]
    // 0x6a382c: r0 = PrestigeButton()
    //     0x6a382c: bl              #0x693a34  ; AllocatePrestigeButtonStub -> PrestigeButton<X0> (size=0x64)
    // 0x6a3830: mov             x3, x0
    // 0x6a3834: ldur            x0, [fp, #-0x20]
    // 0x6a3838: stur            x3, [fp, #-0x28]
    // 0x6a383c: StoreField: r3->field_1f = r0
    //     0x6a383c: stur            w0, [x3, #0x1f]
    // 0x6a3840: r0 = Instance_Chapter15Stat
    //     0x6a3840: add             x0, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a3844: ldr             x0, [x0, #0xe8]
    // 0x6a3848: StoreField: r3->field_1b = r0
    //     0x6a3848: stur            w0, [x3, #0x1b]
    // 0x6a384c: ldur            x2, [fp, #-8]
    // 0x6a3850: r1 = Function 'getReleasePrestigePoints':.
    //     0x6a3850: add             x1, PP, #0x28, lsl #12  ; [pp+0x28530] AnonymousClosure: (0x6a4d38), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getReleasePrestigePoints (0x6a4148)
    //     0x6a3854: ldr             x1, [x1, #0x530]
    // 0x6a3858: r0 = AllocateClosure()
    //     0x6a3858: bl              #0x826750  ; AllocateClosureStub
    // 0x6a385c: mov             x1, x0
    // 0x6a3860: ldur            x0, [fp, #-0x28]
    // 0x6a3864: StoreField: r0->field_2f = r1
    //     0x6a3864: stur            w1, [x0, #0x2f]
    // 0x6a3868: ldur            x2, [fp, #-8]
    // 0x6a386c: r1 = Function 'applyReleasePrestige':.
    //     0x6a386c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] AnonymousClosure: (0x6a4d00), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::applyReleasePrestige (0x6a3ec4)
    //     0x6a3870: ldr             x1, [x1, #0x538]
    // 0x6a3874: r0 = AllocateClosure()
    //     0x6a3874: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3878: mov             x1, x0
    // 0x6a387c: ldur            x0, [fp, #-0x28]
    // 0x6a3880: StoreField: r0->field_33 = r1
    //     0x6a3880: stur            w1, [x0, #0x33]
    // 0x6a3884: ldur            x1, [fp, #-0x10]
    // 0x6a3888: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a3888: stur            w1, [x0, #0x17]
    // 0x6a388c: r3 = Closure: (Chapter15Stat?) => String from Function 'humanName': static.
    //     0x6a388c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28498] Closure: (Chapter15Stat?) => String from Function 'humanName': static. (0x248ed99c008)
    //     0x6a3890: ldr             x3, [x3, #0x498]
    // 0x6a3894: StoreField: r0->field_43 = r3
    //     0x6a3894: stur            w3, [x0, #0x43]
    // 0x6a3898: r1 = Function '<anonymous closure>':.
    //     0x6a3898: add             x1, PP, #0x28, lsl #12  ; [pp+0x28540] AnonymousClosure: (0x6a4cf4), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a389c: ldr             x1, [x1, #0x540]
    // 0x6a38a0: r2 = Null
    //     0x6a38a0: mov             x2, NULL
    // 0x6a38a4: r0 = AllocateClosure()
    //     0x6a38a4: bl              #0x826750  ; AllocateClosureStub
    // 0x6a38a8: mov             x1, x0
    // 0x6a38ac: ldur            x0, [fp, #-0x28]
    // 0x6a38b0: StoreField: r0->field_23 = r1
    //     0x6a38b0: stur            w1, [x0, #0x23]
    // 0x6a38b4: r1 = "all star generators"
    //     0x6a38b4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28548] "all star generators"
    //     0x6a38b8: ldr             x1, [x1, #0x548]
    // 0x6a38bc: StoreField: r0->field_3f = r1
    //     0x6a38bc: stur            w1, [x0, #0x3f]
    // 0x6a38c0: r3 = false
    //     0x6a38c0: add             x3, NULL, #0x30  ; false
    // 0x6a38c4: StoreField: r0->field_f = r3
    //     0x6a38c4: stur            w3, [x0, #0xf]
    // 0x6a38c8: StoreField: r0->field_4f = r3
    //     0x6a38c8: stur            w3, [x0, #0x4f]
    // 0x6a38cc: r4 = true
    //     0x6a38cc: add             x4, NULL, #0x20  ; true
    // 0x6a38d0: StoreField: r0->field_2b = r4
    //     0x6a38d0: stur            w4, [x0, #0x2b]
    // 0x6a38d4: StoreField: r0->field_53 = r3
    //     0x6a38d4: stur            w3, [x0, #0x53]
    // 0x6a38d8: StoreField: r0->field_5b = r4
    //     0x6a38d8: stur            w4, [x0, #0x5b]
    // 0x6a38dc: r1 = "Gain"
    //     0x6a38dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x261b8] "Gain"
    //     0x6a38e0: ldr             x1, [x1, #0x1b8]
    // 0x6a38e4: StoreField: r0->field_5f = r1
    //     0x6a38e4: stur            w1, [x0, #0x5f]
    // 0x6a38e8: ldur            x2, [fp, #-0x18]
    // 0x6a38ec: r1 = Function '<anonymous closure>':.
    //     0x6a38ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28550] AnonymousClosure: (0x6a4c5c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a38f0: ldr             x1, [x1, #0x550]
    // 0x6a38f4: r0 = AllocateClosure()
    //     0x6a38f4: bl              #0x826750  ; AllocateClosureStub
    // 0x6a38f8: ldur            x2, [fp, #-0x28]
    // 0x6a38fc: mov             x5, x0
    // 0x6a3900: r1 = Null
    //     0x6a3900: mov             x1, NULL
    // 0x6a3904: r3 = "Chapter 15 Prestige 2"
    //     0x6a3904: add             x3, PP, #0x28, lsl #12  ; [pp+0x28558] "Chapter 15 Prestige 2"
    //     0x6a3908: ldr             x3, [x3, #0x558]
    // 0x6a390c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a390c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a3910: r0 = IdleFragment()
    //     0x6a3910: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a3914: ldur            x1, [fp, #-0x60]
    // 0x6a3918: ArrayStore: r1[6] = r0  ; List_4
    //     0x6a3918: add             x25, x1, #0x27
    //     0x6a391c: str             w0, [x25]
    //     0x6a3920: tbz             w0, #0, #0x6a393c
    //     0x6a3924: ldurb           w16, [x1, #-1]
    //     0x6a3928: ldurb           w17, [x0, #-1]
    //     0x6a392c: and             x16, x17, x16, lsr #2
    //     0x6a3930: tst             x16, HEAP, lsr #32
    //     0x6a3934: b.eq            #0x6a393c
    //     0x6a3938: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a393c: r1 = Null
    //     0x6a393c: mov             x1, NULL
    // 0x6a3940: r2 = 4
    //     0x6a3940: movz            x2, #0x4
    // 0x6a3944: r0 = AllocateArray()
    //     0x6a3944: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a3948: r16 = "Chapter 15 Upgrades 3 "
    //     0x6a3948: add             x16, PP, #0x28, lsl #12  ; [pp+0x28560] "Chapter 15 Upgrades 3 "
    //     0x6a394c: ldr             x16, [x16, #0x560]
    // 0x6a3950: StoreField: r0->field_f = r16
    //     0x6a3950: stur            w16, [x0, #0xf]
    // 0x6a3954: ldur            x1, [fp, #-8]
    // 0x6a3958: LoadField: r2 = r1->field_43
    //     0x6a3958: ldur            w2, [x1, #0x43]
    // 0x6a395c: DecompressPointer r2
    //     0x6a395c: add             x2, x2, HEAP, lsl #32
    // 0x6a3960: LoadField: r3 = r2->field_13
    //     0x6a3960: ldur            w3, [x2, #0x13]
    // 0x6a3964: r4 = LoadInt32Instr(r3)
    //     0x6a3964: sbfx            x4, x3, #1, #0x1f
    // 0x6a3968: asr             x3, x4, #1
    // 0x6a396c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x6a396c: ldur            w4, [x2, #0x17]
    // 0x6a3970: r2 = LoadInt32Instr(r4)
    //     0x6a3970: sbfx            x2, x4, #1, #0x1f
    // 0x6a3974: sub             x4, x3, x2
    // 0x6a3978: lsl             x2, x4, #1
    // 0x6a397c: StoreField: r0->field_13 = r2
    //     0x6a397c: stur            w2, [x0, #0x13]
    // 0x6a3980: str             x0, [SP]
    // 0x6a3984: r0 = _interpolate()
    //     0x6a3984: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6a3988: mov             x2, x0
    // 0x6a398c: ldur            x0, [fp, #-8]
    // 0x6a3990: stur            x2, [fp, #-0x30]
    // 0x6a3994: LoadField: r3 = r0->field_37
    //     0x6a3994: ldur            w3, [x0, #0x37]
    // 0x6a3998: DecompressPointer r3
    //     0x6a3998: add             x3, x3, HEAP, lsl #32
    // 0x6a399c: stur            x3, [fp, #-0x28]
    // 0x6a39a0: LoadField: r4 = r0->field_43
    //     0x6a39a0: ldur            w4, [x0, #0x43]
    // 0x6a39a4: DecompressPointer r4
    //     0x6a39a4: add             x4, x4, HEAP, lsl #32
    // 0x6a39a8: stur            x4, [fp, #-0x20]
    // 0x6a39ac: LoadField: r5 = r0->field_8f
    //     0x6a39ac: ldur            w5, [x0, #0x8f]
    // 0x6a39b0: DecompressPointer r5
    //     0x6a39b0: add             x5, x5, HEAP, lsl #32
    // 0x6a39b4: stur            x5, [fp, #-0x10]
    // 0x6a39b8: r1 = <Chapter15Stat>
    //     0x6a39b8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a39bc: ldr             x1, [x1, #0xf98]
    // 0x6a39c0: r0 = UpgradeGroup()
    //     0x6a39c0: bl              #0x6937a4  ; AllocateUpgradeGroupStub -> UpgradeGroup<X0> (size=0x3c)
    // 0x6a39c4: mov             x3, x0
    // 0x6a39c8: r0 = 2
    //     0x6a39c8: movz            x0, #0x2
    // 0x6a39cc: stur            x3, [fp, #-0x38]
    // 0x6a39d0: StoreField: r3->field_13 = r0
    //     0x6a39d0: stur            x0, [x3, #0x13]
    // 0x6a39d4: ldur            x0, [fp, #-0x10]
    // 0x6a39d8: StoreField: r3->field_1b = r0
    //     0x6a39d8: stur            w0, [x3, #0x1b]
    // 0x6a39dc: ldur            x0, [fp, #-0x28]
    // 0x6a39e0: StoreField: r3->field_1f = r0
    //     0x6a39e0: stur            w0, [x3, #0x1f]
    // 0x6a39e4: ldur            x0, [fp, #-0x20]
    // 0x6a39e8: StoreField: r3->field_23 = r0
    //     0x6a39e8: stur            w0, [x3, #0x23]
    // 0x6a39ec: r1 = Function '<anonymous closure>':.
    //     0x6a39ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28568] AnonymousClosure: (0x46c008), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState (0x46b010)
    //     0x6a39f0: ldr             x1, [x1, #0x568]
    // 0x6a39f4: r2 = Null
    //     0x6a39f4: mov             x2, NULL
    // 0x6a39f8: r0 = AllocateClosure()
    //     0x6a39f8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a39fc: mov             x1, x0
    // 0x6a3a00: ldur            x0, [fp, #-0x38]
    // 0x6a3a04: StoreField: r0->field_2b = r1
    //     0x6a3a04: stur            w1, [x0, #0x2b]
    // 0x6a3a08: r1 = const [0x65, 0x66, 0x67, 0x68]
    //     0x6a3a08: add             x1, PP, #0x28, lsl #12  ; [pp+0x28570] List<int>(4)
    //     0x6a3a0c: ldr             x1, [x1, #0x570]
    // 0x6a3a10: StoreField: r0->field_f = r1
    //     0x6a3a10: stur            w1, [x0, #0xf]
    // 0x6a3a14: r3 = true
    //     0x6a3a14: add             x3, NULL, #0x20  ; true
    // 0x6a3a18: StoreField: r0->field_27 = r3
    //     0x6a3a18: stur            w3, [x0, #0x27]
    // 0x6a3a1c: r1 = Instance_UpgradeDisplayMode
    //     0x6a3a1c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10608] Obj!UpgradeDisplayMode@85e8a1
    //     0x6a3a20: ldr             x1, [x1, #0x608]
    // 0x6a3a24: StoreField: r0->field_2f = r1
    //     0x6a3a24: stur            w1, [x0, #0x2f]
    // 0x6a3a28: r1 = false
    //     0x6a3a28: add             x1, NULL, #0x30  ; false
    // 0x6a3a2c: StoreField: r0->field_33 = r1
    //     0x6a3a2c: stur            w1, [x0, #0x33]
    // 0x6a3a30: ldur            x2, [fp, #-0x18]
    // 0x6a3a34: r1 = Function '<anonymous closure>':.
    //     0x6a3a34: add             x1, PP, #0x28, lsl #12  ; [pp+0x28578] AnonymousClosure: (0x6a4c5c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3a38: ldr             x1, [x1, #0x578]
    // 0x6a3a3c: r0 = AllocateClosure()
    //     0x6a3a3c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3a40: ldur            x2, [fp, #-0x38]
    // 0x6a3a44: ldur            x3, [fp, #-0x30]
    // 0x6a3a48: mov             x5, x0
    // 0x6a3a4c: r1 = Null
    //     0x6a3a4c: mov             x1, NULL
    // 0x6a3a50: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a3a50: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a3a54: r0 = IdleFragment()
    //     0x6a3a54: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a3a58: ldur            x1, [fp, #-0x60]
    // 0x6a3a5c: ArrayStore: r1[7] = r0  ; List_4
    //     0x6a3a5c: add             x25, x1, #0x2b
    //     0x6a3a60: str             w0, [x25]
    //     0x6a3a64: tbz             w0, #0, #0x6a3a80
    //     0x6a3a68: ldurb           w16, [x1, #-1]
    //     0x6a3a6c: ldurb           w17, [x0, #-1]
    //     0x6a3a70: and             x16, x17, x16, lsr #2
    //     0x6a3a74: tst             x16, HEAP, lsr #32
    //     0x6a3a78: b.eq            #0x6a3a80
    //     0x6a3a7c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a3a80: ldur            x0, [fp, #-8]
    // 0x6a3a84: LoadField: r3 = r0->field_37
    //     0x6a3a84: ldur            w3, [x0, #0x37]
    // 0x6a3a88: DecompressPointer r3
    //     0x6a3a88: add             x3, x3, HEAP, lsl #32
    // 0x6a3a8c: stur            x3, [fp, #-0x20]
    // 0x6a3a90: LoadField: r4 = r0->field_3f
    //     0x6a3a90: ldur            w4, [x0, #0x3f]
    // 0x6a3a94: DecompressPointer r4
    //     0x6a3a94: add             x4, x4, HEAP, lsl #32
    // 0x6a3a98: ldur            x2, [fp, #-0x18]
    // 0x6a3a9c: stur            x4, [fp, #-0x10]
    // 0x6a3aa0: r1 = Function '<anonymous closure>':.
    //     0x6a3aa0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28580] AnonymousClosure: (0x6a3e58), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3aa4: ldr             x1, [x1, #0x580]
    // 0x6a3aa8: r0 = AllocateClosure()
    //     0x6a3aa8: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3aac: r1 = <Chapter15Stat>
    //     0x6a3aac: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a3ab0: ldr             x1, [x1, #0xf98]
    // 0x6a3ab4: stur            x0, [fp, #-0x28]
    // 0x6a3ab8: r0 = QuestButton()
    //     0x6a3ab8: bl              #0x6933cc  ; AllocateQuestButtonStub -> QuestButton<X0> (size=0x3c)
    // 0x6a3abc: mov             x3, x0
    // 0x6a3ac0: ldur            x0, [fp, #-0x28]
    // 0x6a3ac4: stur            x3, [fp, #-0x30]
    // 0x6a3ac8: StoreField: r3->field_2f = r0
    //     0x6a3ac8: stur            w0, [x3, #0x2f]
    // 0x6a3acc: ldur            x0, [fp, #-0x20]
    // 0x6a3ad0: StoreField: r3->field_1b = r0
    //     0x6a3ad0: stur            w0, [x3, #0x1b]
    // 0x6a3ad4: r0 = Instance_IconData
    //     0x6a3ad4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28588] Obj!IconData@830951
    //     0x6a3ad8: ldr             x0, [x0, #0x588]
    // 0x6a3adc: StoreField: r3->field_1f = r0
    //     0x6a3adc: stur            w0, [x3, #0x1f]
    // 0x6a3ae0: ldur            x0, [fp, #-0x10]
    // 0x6a3ae4: StoreField: r3->field_2b = r0
    //     0x6a3ae4: stur            w0, [x3, #0x2b]
    // 0x6a3ae8: r0 = 1
    //     0x6a3ae8: movz            x0, #0x1
    // 0x6a3aec: StoreField: r3->field_23 = r0
    //     0x6a3aec: stur            x0, [x3, #0x23]
    // 0x6a3af0: r0 = Closure: (Chapter15Stat?) => String from Function 'humanName': static.
    //     0x6a3af0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28498] Closure: (Chapter15Stat?) => String from Function 'humanName': static. (0x248ed99c008)
    //     0x6a3af4: ldr             x0, [x0, #0x498]
    // 0x6a3af8: StoreField: r3->field_f = r0
    //     0x6a3af8: stur            w0, [x3, #0xf]
    // 0x6a3afc: r1 = const [Instance of 'QuestLevel<Chapter15Stat>', Instance of 'QuestLevel<Chapter15Stat>', Instance of 'QuestLevel<Chapter15Stat>']
    //     0x6a3afc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28590] List<QuestLevel<Chapter15Stat>>(3)
    //     0x6a3b00: ldr             x1, [x1, #0x590]
    // 0x6a3b04: StoreField: r3->field_37 = r1
    //     0x6a3b04: stur            w1, [x3, #0x37]
    // 0x6a3b08: r1 = true
    //     0x6a3b08: add             x1, NULL, #0x20  ; true
    // 0x6a3b0c: StoreField: r3->field_13 = r1
    //     0x6a3b0c: stur            w1, [x3, #0x13]
    // 0x6a3b10: r1 = Null
    //     0x6a3b10: mov             x1, NULL
    // 0x6a3b14: r2 = 2
    //     0x6a3b14: movz            x2, #0x2
    // 0x6a3b18: r0 = AllocateArray()
    //     0x6a3b18: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a3b1c: mov             x2, x0
    // 0x6a3b20: ldur            x0, [fp, #-0x30]
    // 0x6a3b24: stur            x2, [fp, #-0x10]
    // 0x6a3b28: StoreField: r2->field_f = r0
    //     0x6a3b28: stur            w0, [x2, #0xf]
    // 0x6a3b2c: r1 = <Widget>
    //     0x6a3b2c: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a3b30: r0 = AllocateGrowableArray()
    //     0x6a3b30: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a3b34: mov             x1, x0
    // 0x6a3b38: ldur            x0, [fp, #-0x10]
    // 0x6a3b3c: stur            x1, [fp, #-0x20]
    // 0x6a3b40: StoreField: r1->field_f = r0
    //     0x6a3b40: stur            w0, [x1, #0xf]
    // 0x6a3b44: r2 = 2
    //     0x6a3b44: movz            x2, #0x2
    // 0x6a3b48: StoreField: r1->field_b = r2
    //     0x6a3b48: stur            w2, [x1, #0xb]
    // 0x6a3b4c: r0 = Column()
    //     0x6a3b4c: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6a3b50: mov             x1, x0
    // 0x6a3b54: r0 = Instance_Axis
    //     0x6a3b54: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6a3b58: stur            x1, [fp, #-0x10]
    // 0x6a3b5c: StoreField: r1->field_f = r0
    //     0x6a3b5c: stur            w0, [x1, #0xf]
    // 0x6a3b60: r2 = Instance_MainAxisAlignment
    //     0x6a3b60: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6a3b64: ldr             x2, [x2, #0x200]
    // 0x6a3b68: StoreField: r1->field_13 = r2
    //     0x6a3b68: stur            w2, [x1, #0x13]
    // 0x6a3b6c: r3 = Instance_MainAxisSize
    //     0x6a3b6c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6a3b70: ldr             x3, [x3, #0x70]
    // 0x6a3b74: ArrayStore: r1[0] = r3  ; List_4
    //     0x6a3b74: stur            w3, [x1, #0x17]
    // 0x6a3b78: r4 = Instance_CrossAxisAlignment
    //     0x6a3b78: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6a3b7c: ldr             x4, [x4, #0x78]
    // 0x6a3b80: StoreField: r1->field_1b = r4
    //     0x6a3b80: stur            w4, [x1, #0x1b]
    // 0x6a3b84: r5 = Instance_VerticalDirection
    //     0x6a3b84: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6a3b88: ldr             x5, [x5, #0x1e8]
    // 0x6a3b8c: StoreField: r1->field_23 = r5
    //     0x6a3b8c: stur            w5, [x1, #0x23]
    // 0x6a3b90: r6 = Instance_Clip
    //     0x6a3b90: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6a3b94: ldr             x6, [x6, #0x1b0]
    // 0x6a3b98: StoreField: r1->field_2b = r6
    //     0x6a3b98: stur            w6, [x1, #0x2b]
    // 0x6a3b9c: StoreField: r1->field_2f = rZR
    //     0x6a3b9c: stur            xzr, [x1, #0x2f]
    // 0x6a3ba0: ldur            x7, [fp, #-0x20]
    // 0x6a3ba4: StoreField: r1->field_b = r7
    //     0x6a3ba4: stur            w7, [x1, #0xb]
    // 0x6a3ba8: r0 = Padding()
    //     0x6a3ba8: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6a3bac: mov             x3, x0
    // 0x6a3bb0: r0 = Instance_EdgeInsets
    //     0x6a3bb0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a08] Obj!EdgeInsets@831da1
    //     0x6a3bb4: ldr             x0, [x0, #0xa08]
    // 0x6a3bb8: stur            x3, [fp, #-0x20]
    // 0x6a3bbc: StoreField: r3->field_f = r0
    //     0x6a3bbc: stur            w0, [x3, #0xf]
    // 0x6a3bc0: ldur            x0, [fp, #-0x10]
    // 0x6a3bc4: StoreField: r3->field_b = r0
    //     0x6a3bc4: stur            w0, [x3, #0xb]
    // 0x6a3bc8: ldur            x2, [fp, #-0x18]
    // 0x6a3bcc: r1 = Function '<anonymous closure>':.
    //     0x6a3bcc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28598] AnonymousClosure: (0x6a3e0c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3bd0: ldr             x1, [x1, #0x598]
    // 0x6a3bd4: r0 = AllocateClosure()
    //     0x6a3bd4: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3bd8: ldur            x2, [fp, #-0x20]
    // 0x6a3bdc: mov             x5, x0
    // 0x6a3be0: r1 = Null
    //     0x6a3be0: mov             x1, NULL
    // 0x6a3be4: r3 = "Chapter 15 Quests 1"
    //     0x6a3be4: add             x3, PP, #0x28, lsl #12  ; [pp+0x285a0] "Chapter 15 Quests 1"
    //     0x6a3be8: ldr             x3, [x3, #0x5a0]
    // 0x6a3bec: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a3bec: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a3bf0: r0 = IdleFragment()
    //     0x6a3bf0: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a3bf4: ldur            x1, [fp, #-0x60]
    // 0x6a3bf8: ArrayStore: r1[8] = r0  ; List_4
    //     0x6a3bf8: add             x25, x1, #0x2f
    //     0x6a3bfc: str             w0, [x25]
    //     0x6a3c00: tbz             w0, #0, #0x6a3c1c
    //     0x6a3c04: ldurb           w16, [x1, #-1]
    //     0x6a3c08: ldurb           w17, [x0, #-1]
    //     0x6a3c0c: and             x16, x17, x16, lsr #2
    //     0x6a3c10: tst             x16, HEAP, lsr #32
    //     0x6a3c14: b.eq            #0x6a3c1c
    //     0x6a3c18: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a3c1c: ldur            x0, [fp, #-8]
    // 0x6a3c20: LoadField: r2 = r0->field_37
    //     0x6a3c20: ldur            w2, [x0, #0x37]
    // 0x6a3c24: DecompressPointer r2
    //     0x6a3c24: add             x2, x2, HEAP, lsl #32
    // 0x6a3c28: stur            x2, [fp, #-0x10]
    // 0x6a3c2c: r1 = <Chapter15Stat>
    //     0x6a3c2c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x6a3c30: ldr             x1, [x1, #0xf98]
    // 0x6a3c34: r0 = CompleteChapterButtons()
    //     0x6a3c34: bl              #0x697edc  ; AllocateCompleteChapterButtonsStub -> CompleteChapterButtons<X0> (size=0x24)
    // 0x6a3c38: mov             x3, x0
    // 0x6a3c3c: ldur            x0, [fp, #-0x10]
    // 0x6a3c40: stur            x3, [fp, #-8]
    // 0x6a3c44: StoreField: r3->field_f = r0
    //     0x6a3c44: stur            w0, [x3, #0xf]
    // 0x6a3c48: r0 = Instance_Tuple2
    //     0x6a3c48: add             x0, PP, #0x28, lsl #12  ; [pp+0x285a8] Obj!Tuple2<Chapter15Stat, CustomNum>@826bd1
    //     0x6a3c4c: ldr             x0, [x0, #0x5a8]
    // 0x6a3c50: StoreField: r3->field_13 = r0
    //     0x6a3c50: stur            w0, [x3, #0x13]
    // 0x6a3c54: ldur            x2, [fp, #-0x18]
    // 0x6a3c58: r1 = Function '<anonymous closure>':.
    //     0x6a3c58: add             x1, PP, #0x28, lsl #12  ; [pp+0x285b0] AnonymousClosure: (0x6a3db8), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3c5c: ldr             x1, [x1, #0x5b0]
    // 0x6a3c60: r0 = AllocateClosure()
    //     0x6a3c60: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3c64: mov             x1, x0
    // 0x6a3c68: ldur            x0, [fp, #-8]
    // 0x6a3c6c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a3c6c: stur            w1, [x0, #0x17]
    // 0x6a3c70: r1 = Closure: (Chapter15Stat?) => String from Function 'humanName': static.
    //     0x6a3c70: add             x1, PP, #0x28, lsl #12  ; [pp+0x28498] Closure: (Chapter15Stat?) => String from Function 'humanName': static. (0x248ed99c008)
    //     0x6a3c74: ldr             x1, [x1, #0x498]
    // 0x6a3c78: StoreField: r0->field_1f = r1
    //     0x6a3c78: stur            w1, [x0, #0x1f]
    // 0x6a3c7c: r1 = Instance_ChapterCompleteButtonType
    //     0x6a3c7c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!ChapterCompleteButtonType@85ea61
    //     0x6a3c80: ldr             x1, [x1, #0x330]
    // 0x6a3c84: StoreField: r0->field_1b = r1
    //     0x6a3c84: stur            w1, [x0, #0x1b]
    // 0x6a3c88: r1 = Null
    //     0x6a3c88: mov             x1, NULL
    // 0x6a3c8c: r2 = 2
    //     0x6a3c8c: movz            x2, #0x2
    // 0x6a3c90: r0 = AllocateArray()
    //     0x6a3c90: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a3c94: mov             x2, x0
    // 0x6a3c98: ldur            x0, [fp, #-8]
    // 0x6a3c9c: stur            x2, [fp, #-0x10]
    // 0x6a3ca0: StoreField: r2->field_f = r0
    //     0x6a3ca0: stur            w0, [x2, #0xf]
    // 0x6a3ca4: r1 = <Widget>
    //     0x6a3ca4: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a3ca8: r0 = AllocateGrowableArray()
    //     0x6a3ca8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a3cac: mov             x1, x0
    // 0x6a3cb0: ldur            x0, [fp, #-0x10]
    // 0x6a3cb4: stur            x1, [fp, #-8]
    // 0x6a3cb8: StoreField: r1->field_f = r0
    //     0x6a3cb8: stur            w0, [x1, #0xf]
    // 0x6a3cbc: r0 = 2
    //     0x6a3cbc: movz            x0, #0x2
    // 0x6a3cc0: StoreField: r1->field_b = r0
    //     0x6a3cc0: stur            w0, [x1, #0xb]
    // 0x6a3cc4: r0 = Column()
    //     0x6a3cc4: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6a3cc8: mov             x3, x0
    // 0x6a3ccc: r0 = Instance_Axis
    //     0x6a3ccc: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6a3cd0: stur            x3, [fp, #-0x10]
    // 0x6a3cd4: StoreField: r3->field_f = r0
    //     0x6a3cd4: stur            w0, [x3, #0xf]
    // 0x6a3cd8: r0 = Instance_MainAxisAlignment
    //     0x6a3cd8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6a3cdc: ldr             x0, [x0, #0x200]
    // 0x6a3ce0: StoreField: r3->field_13 = r0
    //     0x6a3ce0: stur            w0, [x3, #0x13]
    // 0x6a3ce4: r0 = Instance_MainAxisSize
    //     0x6a3ce4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6a3ce8: ldr             x0, [x0, #0x70]
    // 0x6a3cec: ArrayStore: r3[0] = r0  ; List_4
    //     0x6a3cec: stur            w0, [x3, #0x17]
    // 0x6a3cf0: r0 = Instance_CrossAxisAlignment
    //     0x6a3cf0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6a3cf4: ldr             x0, [x0, #0x78]
    // 0x6a3cf8: StoreField: r3->field_1b = r0
    //     0x6a3cf8: stur            w0, [x3, #0x1b]
    // 0x6a3cfc: r0 = Instance_VerticalDirection
    //     0x6a3cfc: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6a3d00: ldr             x0, [x0, #0x1e8]
    // 0x6a3d04: StoreField: r3->field_23 = r0
    //     0x6a3d04: stur            w0, [x3, #0x23]
    // 0x6a3d08: r0 = Instance_Clip
    //     0x6a3d08: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6a3d0c: ldr             x0, [x0, #0x1b0]
    // 0x6a3d10: StoreField: r3->field_2b = r0
    //     0x6a3d10: stur            w0, [x3, #0x2b]
    // 0x6a3d14: StoreField: r3->field_2f = rZR
    //     0x6a3d14: stur            xzr, [x3, #0x2f]
    // 0x6a3d18: ldur            x0, [fp, #-8]
    // 0x6a3d1c: StoreField: r3->field_b = r0
    //     0x6a3d1c: stur            w0, [x3, #0xb]
    // 0x6a3d20: ldur            x2, [fp, #-0x18]
    // 0x6a3d24: r1 = Function '<anonymous closure>':.
    //     0x6a3d24: add             x1, PP, #0x28, lsl #12  ; [pp+0x285b8] AnonymousClosure: (0x69940c), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a3d28: ldr             x1, [x1, #0x5b8]
    // 0x6a3d2c: r0 = AllocateClosure()
    //     0x6a3d2c: bl              #0x826750  ; AllocateClosureStub
    // 0x6a3d30: ldur            x2, [fp, #-0x10]
    // 0x6a3d34: mov             x5, x0
    // 0x6a3d38: r1 = Null
    //     0x6a3d38: mov             x1, NULL
    // 0x6a3d3c: r3 = "Chapter 15 Complete Chapter"
    //     0x6a3d3c: add             x3, PP, #0x28, lsl #12  ; [pp+0x285c0] "Chapter 15 Complete Chapter"
    //     0x6a3d40: ldr             x3, [x3, #0x5c0]
    // 0x6a3d44: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a3d44: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a3d48: r0 = IdleFragment()
    //     0x6a3d48: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a3d4c: ldur            x1, [fp, #-0x60]
    // 0x6a3d50: ArrayStore: r1[9] = r0  ; List_4
    //     0x6a3d50: add             x25, x1, #0x33
    //     0x6a3d54: str             w0, [x25]
    //     0x6a3d58: tbz             w0, #0, #0x6a3d74
    //     0x6a3d5c: ldurb           w16, [x1, #-1]
    //     0x6a3d60: ldurb           w17, [x0, #-1]
    //     0x6a3d64: and             x16, x17, x16, lsr #2
    //     0x6a3d68: tst             x16, HEAP, lsr #32
    //     0x6a3d6c: b.eq            #0x6a3d74
    //     0x6a3d70: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6a3d74: r1 = <Widget>
    //     0x6a3d74: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a3d78: r0 = AllocateGrowableArray()
    //     0x6a3d78: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a3d7c: ldur            x1, [fp, #-0x60]
    // 0x6a3d80: StoreField: r0->field_f = r1
    //     0x6a3d80: stur            w1, [x0, #0xf]
    // 0x6a3d84: r1 = 20
    //     0x6a3d84: movz            x1, #0x14
    // 0x6a3d88: StoreField: r0->field_b = r1
    //     0x6a3d88: stur            w1, [x0, #0xb]
    // 0x6a3d8c: LeaveFrame
    //     0x6a3d8c: mov             SP, fp
    //     0x6a3d90: ldp             fp, lr, [SP], #0x10
    // 0x6a3d94: ret
    //     0x6a3d94: ret             
    // 0x6a3d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a3d98: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a3d9c: b               #0x6a2db8
    // 0x6a3da0: r9 = allUpgradeData
    //     0x6a3da0: add             x9, PP, #0x28, lsl #12  ; [pp+0x285c8] Field <Chapter15GameState.allUpgradeData>: late (offset: 0x90)
    //     0x6a3da4: ldr             x9, [x9, #0x5c8]
    // 0x6a3da8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a3da8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a3db8, size: 0x54
    // 0x6a3db8: EnterFrame
    //     0x6a3db8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a3dbc: mov             fp, SP
    // 0x6a3dc0: ldr             x0, [fp, #0x18]
    // 0x6a3dc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a3dc4: ldur            w1, [x0, #0x17]
    // 0x6a3dc8: DecompressPointer r1
    //     0x6a3dc8: add             x1, x1, HEAP, lsl #32
    // 0x6a3dcc: CheckStackOverflow
    //     0x6a3dcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a3dd0: cmp             SP, x16
    //     0x6a3dd4: b.ls            #0x6a3e04
    // 0x6a3dd8: LoadField: r0 = r1->field_f
    //     0x6a3dd8: ldur            w0, [x1, #0xf]
    // 0x6a3ddc: DecompressPointer r0
    //     0x6a3ddc: add             x0, x0, HEAP, lsl #32
    // 0x6a3de0: LoadField: r2 = r1->field_13
    //     0x6a3de0: ldur            w2, [x1, #0x13]
    // 0x6a3de4: DecompressPointer r2
    //     0x6a3de4: add             x2, x2, HEAP, lsl #32
    // 0x6a3de8: mov             x1, x0
    // 0x6a3dec: r3 = Instance_Tuple2
    //     0x6a3dec: add             x3, PP, #0x28, lsl #12  ; [pp+0x285d0] Obj!Tuple2<int, String>@826bb1
    //     0x6a3df0: ldr             x3, [x3, #0x5d0]
    // 0x6a3df4: r0 = completeChapter()
    //     0x6a3df4: bl              #0x694ac8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::completeChapter
    // 0x6a3df8: LeaveFrame
    //     0x6a3df8: mov             SP, fp
    //     0x6a3dfc: ldp             fp, lr, [SP], #0x10
    // 0x6a3e00: ret
    //     0x6a3e00: ret             
    // 0x6a3e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a3e04: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a3e08: b               #0x6a3dd8
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a3e0c, size: 0x4c
    // 0x6a3e0c: EnterFrame
    //     0x6a3e0c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a3e10: mov             fp, SP
    // 0x6a3e14: ldr             x0, [fp, #0x10]
    // 0x6a3e18: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a3e18: ldur            w1, [x0, #0x17]
    // 0x6a3e1c: DecompressPointer r1
    //     0x6a3e1c: add             x1, x1, HEAP, lsl #32
    // 0x6a3e20: CheckStackOverflow
    //     0x6a3e20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a3e24: cmp             SP, x16
    //     0x6a3e28: b.ls            #0x6a3e50
    // 0x6a3e2c: LoadField: r0 = r1->field_f
    //     0x6a3e2c: ldur            w0, [x1, #0xf]
    // 0x6a3e30: DecompressPointer r0
    //     0x6a3e30: add             x0, x0, HEAP, lsl #32
    // 0x6a3e34: LoadField: r1 = r0->field_1b
    //     0x6a3e34: ldur            w1, [x0, #0x1b]
    // 0x6a3e38: DecompressPointer r1
    //     0x6a3e38: add             x1, x1, HEAP, lsl #32
    // 0x6a3e3c: r2 = 208
    //     0x6a3e3c: movz            x2, #0xd0
    // 0x6a3e40: r0 = contains()
    //     0x6a3e40: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a3e44: LeaveFrame
    //     0x6a3e44: mov             SP, fp
    //     0x6a3e48: ldp             fp, lr, [SP], #0x10
    // 0x6a3e4c: ret
    //     0x6a3e4c: ret             
    // 0x6a3e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a3e50: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a3e54: b               #0x6a3e2c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6a3e58, size: 0x6c
    // 0x6a3e58: EnterFrame
    //     0x6a3e58: stp             fp, lr, [SP, #-0x10]!
    //     0x6a3e5c: mov             fp, SP
    // 0x6a3e60: AllocStack(0x8)
    //     0x6a3e60: sub             SP, SP, #8
    // 0x6a3e64: SetupParameters([dynamic _ /* r0 */])
    //     0x6a3e64: ldr             x0, [fp, #0x10]
    //     0x6a3e68: ldur            w2, [x0, #0x17]
    //     0x6a3e6c: add             x2, x2, HEAP, lsl #32
    //     0x6a3e70: stur            x2, [fp, #-8]
    // 0x6a3e74: CheckStackOverflow
    //     0x6a3e74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a3e78: cmp             SP, x16
    //     0x6a3e7c: b.ls            #0x6a3ebc
    // 0x6a3e80: LoadField: r1 = r2->field_f
    //     0x6a3e80: ldur            w1, [x2, #0xf]
    // 0x6a3e84: DecompressPointer r1
    //     0x6a3e84: add             x1, x1, HEAP, lsl #32
    // 0x6a3e88: r0 = applyPullPrestige()
    //     0x6a3e88: bl              #0x6a41d8  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::applyPullPrestige
    // 0x6a3e8c: ldur            x0, [fp, #-8]
    // 0x6a3e90: LoadField: r1 = r0->field_f
    //     0x6a3e90: ldur            w1, [x0, #0xf]
    // 0x6a3e94: DecompressPointer r1
    //     0x6a3e94: add             x1, x1, HEAP, lsl #32
    // 0x6a3e98: r0 = applyReleasePrestige()
    //     0x6a3e98: bl              #0x6a3ec4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::applyReleasePrestige
    // 0x6a3e9c: ldur            x0, [fp, #-8]
    // 0x6a3ea0: LoadField: r1 = r0->field_f
    //     0x6a3ea0: ldur            w1, [x0, #0xf]
    // 0x6a3ea4: DecompressPointer r1
    //     0x6a3ea4: add             x1, x1, HEAP, lsl #32
    // 0x6a3ea8: r0 = resetAndRecomputeBoosts()
    //     0x6a3ea8: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x6a3eac: r0 = Null
    //     0x6a3eac: mov             x0, NULL
    // 0x6a3eb0: LeaveFrame
    //     0x6a3eb0: mov             SP, fp
    //     0x6a3eb4: ldp             fp, lr, [SP], #0x10
    // 0x6a3eb8: ret
    //     0x6a3eb8: ret             
    // 0x6a3ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a3ebc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a3ec0: b               #0x6a3e80
  }
  _ applyReleasePrestige(/* No info */) {
    // ** addr: 0x6a3ec4, size: 0x284
    // 0x6a3ec4: EnterFrame
    //     0x6a3ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a3ec8: mov             fp, SP
    // 0x6a3ecc: AllocStack(0x18)
    //     0x6a3ecc: sub             SP, SP, #0x18
    // 0x6a3ed0: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x8 */)
    //     0x6a3ed0: mov             x0, x1
    //     0x6a3ed4: stur            x1, [fp, #-8]
    // 0x6a3ed8: CheckStackOverflow
    //     0x6a3ed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a3edc: cmp             SP, x16
    //     0x6a3ee0: b.ls            #0x6a4134
    // 0x6a3ee4: mov             x1, x0
    // 0x6a3ee8: r0 = getReleasePrestigePoints()
    //     0x6a3ee8: bl              #0x6a4148  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getReleasePrestigePoints
    // 0x6a3eec: mov             x3, x0
    // 0x6a3ef0: ldur            x0, [fp, #-8]
    // 0x6a3ef4: stur            x3, [fp, #-0x18]
    // 0x6a3ef8: LoadField: r4 = r0->field_37
    //     0x6a3ef8: ldur            w4, [x0, #0x37]
    // 0x6a3efc: DecompressPointer r4
    //     0x6a3efc: add             x4, x4, HEAP, lsl #32
    // 0x6a3f00: mov             x1, x4
    // 0x6a3f04: stur            x4, [fp, #-0x10]
    // 0x6a3f08: r2 = Instance_Chapter15Stat
    //     0x6a3f08: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a3f0c: ldr             x2, [x2, #0xe8]
    // 0x6a3f10: r0 = _getValueOrData()
    //     0x6a3f10: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a3f14: mov             x1, x0
    // 0x6a3f18: ldur            x0, [fp, #-0x10]
    // 0x6a3f1c: LoadField: r2 = r0->field_f
    //     0x6a3f1c: ldur            w2, [x0, #0xf]
    // 0x6a3f20: DecompressPointer r2
    //     0x6a3f20: add             x2, x2, HEAP, lsl #32
    // 0x6a3f24: cmp             w2, w1
    // 0x6a3f28: b.ne            #0x6a3f30
    // 0x6a3f2c: r1 = Null
    //     0x6a3f2c: mov             x1, NULL
    // 0x6a3f30: cmp             w1, NULL
    // 0x6a3f34: b.ne            #0x6a3f40
    // 0x6a3f38: r1 = Instance_CustomNum
    //     0x6a3f38: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a3f3c: ldr             x1, [x1, #0xaf8]
    // 0x6a3f40: ldur            x3, [fp, #-8]
    // 0x6a3f44: ldur            x2, [fp, #-0x18]
    // 0x6a3f48: r0 = add()
    //     0x6a3f48: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a3f4c: ldur            x1, [fp, #-0x10]
    // 0x6a3f50: mov             x3, x0
    // 0x6a3f54: r2 = Instance_Chapter15Stat
    //     0x6a3f54: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a3f58: ldr             x2, [x2, #0xe8]
    // 0x6a3f5c: r0 = []=()
    //     0x6a3f5c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a3f60: ldur            x0, [fp, #-8]
    // 0x6a3f64: LoadField: r3 = r0->field_3b
    //     0x6a3f64: ldur            w3, [x0, #0x3b]
    // 0x6a3f68: DecompressPointer r3
    //     0x6a3f68: add             x3, x3, HEAP, lsl #32
    // 0x6a3f6c: mov             x1, x3
    // 0x6a3f70: stur            x3, [fp, #-0x10]
    // 0x6a3f74: r2 = Instance_Chapter15Stat
    //     0x6a3f74: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a3f78: ldr             x2, [x2, #0xe8]
    // 0x6a3f7c: r0 = _getValueOrData()
    //     0x6a3f7c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a3f80: mov             x1, x0
    // 0x6a3f84: ldur            x0, [fp, #-0x10]
    // 0x6a3f88: LoadField: r2 = r0->field_f
    //     0x6a3f88: ldur            w2, [x0, #0xf]
    // 0x6a3f8c: DecompressPointer r2
    //     0x6a3f8c: add             x2, x2, HEAP, lsl #32
    // 0x6a3f90: cmp             w2, w1
    // 0x6a3f94: b.ne            #0x6a3f9c
    // 0x6a3f98: r1 = Null
    //     0x6a3f98: mov             x1, NULL
    // 0x6a3f9c: cmp             w1, NULL
    // 0x6a3fa0: b.ne            #0x6a3fac
    // 0x6a3fa4: r1 = Instance_CustomNum
    //     0x6a3fa4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a3fa8: ldr             x1, [x1, #0xaf8]
    // 0x6a3fac: ldur            x3, [fp, #-8]
    // 0x6a3fb0: ldur            x2, [fp, #-0x18]
    // 0x6a3fb4: r0 = add()
    //     0x6a3fb4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a3fb8: ldur            x1, [fp, #-0x10]
    // 0x6a3fbc: mov             x3, x0
    // 0x6a3fc0: r2 = Instance_Chapter15Stat
    //     0x6a3fc0: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a3fc4: ldr             x2, [x2, #0xe8]
    // 0x6a3fc8: r0 = []=()
    //     0x6a3fc8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a3fcc: ldur            x1, [fp, #-8]
    // 0x6a3fd0: r2 = Instance_Chapter15Stat
    //     0x6a3fd0: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a3fd4: ldr             x2, [x2, #0xe8]
    // 0x6a3fd8: r0 = notifyStatGained()
    //     0x6a3fd8: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6a3fdc: ldur            x0, [fp, #-8]
    // 0x6a3fe0: LoadField: r1 = r0->field_4b
    //     0x6a3fe0: ldur            w1, [x0, #0x4b]
    // 0x6a3fe4: DecompressPointer r1
    //     0x6a3fe4: add             x1, x1, HEAP, lsl #32
    // 0x6a3fe8: r0 = clear()
    //     0x6a3fe8: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x6a3fec: ldur            x0, [fp, #-8]
    // 0x6a3ff0: LoadField: r1 = r0->field_47
    //     0x6a3ff0: ldur            w1, [x0, #0x47]
    // 0x6a3ff4: DecompressPointer r1
    //     0x6a3ff4: add             x1, x1, HEAP, lsl #32
    // 0x6a3ff8: r2 = 22
    //     0x6a3ff8: movz            x2, #0x16
    // 0x6a3ffc: r0 = remove()
    //     0x6a3ffc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4000: ldur            x0, [fp, #-8]
    // 0x6a4004: LoadField: r1 = r0->field_47
    //     0x6a4004: ldur            w1, [x0, #0x47]
    // 0x6a4008: DecompressPointer r1
    //     0x6a4008: add             x1, x1, HEAP, lsl #32
    // 0x6a400c: r2 = 24
    //     0x6a400c: movz            x2, #0x18
    // 0x6a4010: r0 = remove()
    //     0x6a4010: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4014: ldur            x0, [fp, #-8]
    // 0x6a4018: LoadField: r1 = r0->field_47
    //     0x6a4018: ldur            w1, [x0, #0x47]
    // 0x6a401c: DecompressPointer r1
    //     0x6a401c: add             x1, x1, HEAP, lsl #32
    // 0x6a4020: r2 = 26
    //     0x6a4020: movz            x2, #0x1a
    // 0x6a4024: r0 = remove()
    //     0x6a4024: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4028: ldur            x0, [fp, #-8]
    // 0x6a402c: LoadField: r1 = r0->field_47
    //     0x6a402c: ldur            w1, [x0, #0x47]
    // 0x6a4030: DecompressPointer r1
    //     0x6a4030: add             x1, x1, HEAP, lsl #32
    // 0x6a4034: r2 = 28
    //     0x6a4034: movz            x2, #0x1c
    // 0x6a4038: r0 = remove()
    //     0x6a4038: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a403c: ldur            x1, [fp, #-8]
    // 0x6a4040: r0 = resetAndRecomputeBoosts()
    //     0x6a4040: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x6a4044: ldur            x0, [fp, #-8]
    // 0x6a4048: LoadField: r1 = r0->field_3b
    //     0x6a4048: ldur            w1, [x0, #0x3b]
    // 0x6a404c: DecompressPointer r1
    //     0x6a404c: add             x1, x1, HEAP, lsl #32
    // 0x6a4050: r2 = Instance_Chapter15Stat
    //     0x6a4050: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x6a4054: ldr             x2, [x2, #0x68]
    // 0x6a4058: r0 = remove()
    //     0x6a4058: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a405c: ldur            x0, [fp, #-8]
    // 0x6a4060: LoadField: r3 = r0->field_8b
    //     0x6a4060: ldur            w3, [x0, #0x8b]
    // 0x6a4064: DecompressPointer r3
    //     0x6a4064: add             x3, x3, HEAP, lsl #32
    // 0x6a4068: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a406c: cmp             w3, w16
    // 0x6a4070: b.eq            #0x6a413c
    // 0x6a4074: mov             x1, x3
    // 0x6a4078: stur            x3, [fp, #-0x10]
    // 0x6a407c: r2 = 22
    //     0x6a407c: movz            x2, #0x16
    // 0x6a4080: r0 = _getValueOrData()
    //     0x6a4080: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4084: mov             x1, x0
    // 0x6a4088: ldur            x0, [fp, #-0x10]
    // 0x6a408c: LoadField: r2 = r0->field_f
    //     0x6a408c: ldur            w2, [x0, #0xf]
    // 0x6a4090: DecompressPointer r2
    //     0x6a4090: add             x2, x2, HEAP, lsl #32
    // 0x6a4094: cmp             w2, w1
    // 0x6a4098: b.ne            #0x6a40a4
    // 0x6a409c: r0 = Null
    //     0x6a409c: mov             x0, NULL
    // 0x6a40a0: b               #0x6a40a8
    // 0x6a40a4: mov             x0, x1
    // 0x6a40a8: cmp             w0, NULL
    // 0x6a40ac: b.ne            #0x6a40b8
    // 0x6a40b0: r0 = Null
    //     0x6a40b0: mov             x0, NULL
    // 0x6a40b4: b               #0x6a40d8
    // 0x6a40b8: LoadField: r1 = r0->field_27
    //     0x6a40b8: ldur            w1, [x0, #0x27]
    // 0x6a40bc: DecompressPointer r1
    //     0x6a40bc: add             x1, x1, HEAP, lsl #32
    // 0x6a40c0: cmp             w1, NULL
    // 0x6a40c4: b.ne            #0x6a40d0
    // 0x6a40c8: r0 = Null
    //     0x6a40c8: mov             x0, NULL
    // 0x6a40cc: b               #0x6a40d8
    // 0x6a40d0: LoadField: r0 = r1->field_f
    //     0x6a40d0: ldur            w0, [x1, #0xf]
    // 0x6a40d4: DecompressPointer r0
    //     0x6a40d4: add             x0, x0, HEAP, lsl #32
    // 0x6a40d8: cmp             w0, NULL
    // 0x6a40dc: b.ne            #0x6a40ec
    // 0x6a40e0: r1 = Instance_CustomNum
    //     0x6a40e0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11058] Obj!CustomNum@828c61
    //     0x6a40e4: ldr             x1, [x1, #0x58]
    // 0x6a40e8: b               #0x6a40f0
    // 0x6a40ec: mov             x1, x0
    // 0x6a40f0: ldur            x0, [fp, #-8]
    // 0x6a40f4: r2 = Instance_CustomNum
    //     0x6a40f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x6a40f8: ldr             x2, [x2, #0x60]
    // 0x6a40fc: r0 = mult2()
    //     0x6a40fc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x6a4100: mov             x1, x0
    // 0x6a4104: ldur            x0, [fp, #-8]
    // 0x6a4108: LoadField: r2 = r0->field_37
    //     0x6a4108: ldur            w2, [x0, #0x37]
    // 0x6a410c: DecompressPointer r2
    //     0x6a410c: add             x2, x2, HEAP, lsl #32
    // 0x6a4110: mov             x3, x1
    // 0x6a4114: mov             x1, x2
    // 0x6a4118: r2 = Instance_Chapter15Stat
    //     0x6a4118: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x6a411c: ldr             x2, [x2, #0x68]
    // 0x6a4120: r0 = []=()
    //     0x6a4120: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4124: r0 = Null
    //     0x6a4124: mov             x0, NULL
    // 0x6a4128: LeaveFrame
    //     0x6a4128: mov             SP, fp
    //     0x6a412c: ldp             fp, lr, [SP], #0x10
    // 0x6a4130: ret
    //     0x6a4130: ret             
    // 0x6a4134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4134: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a4138: b               #0x6a3ee4
    // 0x6a413c: r9 = generators
    //     0x6a413c: add             x9, PP, #0x11, lsl #12  ; [pp+0x11088] Field <Chapter15GameState.generators>: late (offset: 0x8c)
    //     0x6a4140: ldr             x9, [x9, #0x88]
    // 0x6a4144: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a4144: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ getReleasePrestigePoints(/* No info */) {
    // ** addr: 0x6a4148, size: 0x90
    // 0x6a4148: EnterFrame
    //     0x6a4148: stp             fp, lr, [SP, #-0x10]!
    //     0x6a414c: mov             fp, SP
    // 0x6a4150: AllocStack(0x8)
    //     0x6a4150: sub             SP, SP, #8
    // 0x6a4154: CheckStackOverflow
    //     0x6a4154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4158: cmp             SP, x16
    //     0x6a415c: b.ls            #0x6a41d0
    // 0x6a4160: LoadField: r0 = r1->field_3b
    //     0x6a4160: ldur            w0, [x1, #0x3b]
    // 0x6a4164: DecompressPointer r0
    //     0x6a4164: add             x0, x0, HEAP, lsl #32
    // 0x6a4168: mov             x1, x0
    // 0x6a416c: stur            x0, [fp, #-8]
    // 0x6a4170: r2 = Instance_Chapter15Stat
    //     0x6a4170: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x6a4174: ldr             x2, [x2, #0x68]
    // 0x6a4178: r0 = _getValueOrData()
    //     0x6a4178: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a417c: mov             x1, x0
    // 0x6a4180: ldur            x0, [fp, #-8]
    // 0x6a4184: LoadField: r2 = r0->field_f
    //     0x6a4184: ldur            w2, [x0, #0xf]
    // 0x6a4188: DecompressPointer r2
    //     0x6a4188: add             x2, x2, HEAP, lsl #32
    // 0x6a418c: cmp             w2, w1
    // 0x6a4190: b.ne            #0x6a419c
    // 0x6a4194: r0 = Null
    //     0x6a4194: mov             x0, NULL
    // 0x6a4198: b               #0x6a41a0
    // 0x6a419c: mov             x0, x1
    // 0x6a41a0: cmp             w0, NULL
    // 0x6a41a4: b.ne            #0x6a41b4
    // 0x6a41a8: r1 = Instance_CustomNum
    //     0x6a41a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a41ac: ldr             x1, [x1, #0xaf8]
    // 0x6a41b0: b               #0x6a41b8
    // 0x6a41b4: mov             x1, x0
    // 0x6a41b8: r2 = Instance_CustomNum
    //     0x6a41b8: add             x2, PP, #0x28, lsl #12  ; [pp+0x285d8] Obj!CustomNum@82b981
    //     0x6a41bc: ldr             x2, [x2, #0x5d8]
    // 0x6a41c0: r0 = div()
    //     0x6a41c0: bl              #0x460f80  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::div
    // 0x6a41c4: LeaveFrame
    //     0x6a41c4: mov             SP, fp
    //     0x6a41c8: ldp             fp, lr, [SP], #0x10
    // 0x6a41cc: ret
    //     0x6a41cc: ret             
    // 0x6a41d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a41d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a41d4: b               #0x6a4160
  }
  _ applyPullPrestige(/* No info */) {
    // ** addr: 0x6a41d8, size: 0x7fc
    // 0x6a41d8: EnterFrame
    //     0x6a41d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a41dc: mov             fp, SP
    // 0x6a41e0: AllocStack(0x18)
    //     0x6a41e0: sub             SP, SP, #0x18
    // 0x6a41e4: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x8 */)
    //     0x6a41e4: mov             x0, x1
    //     0x6a41e8: stur            x1, [fp, #-8]
    // 0x6a41ec: CheckStackOverflow
    //     0x6a41ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a41f0: cmp             SP, x16
    //     0x6a41f4: b.ls            #0x6a49c0
    // 0x6a41f8: mov             x1, x0
    // 0x6a41fc: r0 = getPushPrestigePoints()
    //     0x6a41fc: bl              #0x6a49d4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getPushPrestigePoints
    // 0x6a4200: mov             x3, x0
    // 0x6a4204: ldur            x0, [fp, #-8]
    // 0x6a4208: stur            x3, [fp, #-0x18]
    // 0x6a420c: LoadField: r4 = r0->field_37
    //     0x6a420c: ldur            w4, [x0, #0x37]
    // 0x6a4210: DecompressPointer r4
    //     0x6a4210: add             x4, x4, HEAP, lsl #32
    // 0x6a4214: mov             x1, x4
    // 0x6a4218: stur            x4, [fp, #-0x10]
    // 0x6a421c: r2 = Instance_Chapter15Stat
    //     0x6a421c: add             x2, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x6a4220: ldr             x2, [x2, #0xc0]
    // 0x6a4224: r0 = _getValueOrData()
    //     0x6a4224: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4228: mov             x1, x0
    // 0x6a422c: ldur            x0, [fp, #-0x10]
    // 0x6a4230: LoadField: r2 = r0->field_f
    //     0x6a4230: ldur            w2, [x0, #0xf]
    // 0x6a4234: DecompressPointer r2
    //     0x6a4234: add             x2, x2, HEAP, lsl #32
    // 0x6a4238: cmp             w2, w1
    // 0x6a423c: b.ne            #0x6a4244
    // 0x6a4240: r1 = Null
    //     0x6a4240: mov             x1, NULL
    // 0x6a4244: cmp             w1, NULL
    // 0x6a4248: b.ne            #0x6a4254
    // 0x6a424c: r1 = Instance_CustomNum
    //     0x6a424c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a4250: ldr             x1, [x1, #0xaf8]
    // 0x6a4254: ldur            x3, [fp, #-8]
    // 0x6a4258: ldur            x2, [fp, #-0x18]
    // 0x6a425c: r0 = add()
    //     0x6a425c: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a4260: ldur            x1, [fp, #-0x10]
    // 0x6a4264: mov             x3, x0
    // 0x6a4268: r2 = Instance_Chapter15Stat
    //     0x6a4268: add             x2, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x6a426c: ldr             x2, [x2, #0xc0]
    // 0x6a4270: r0 = []=()
    //     0x6a4270: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4274: ldur            x0, [fp, #-8]
    // 0x6a4278: LoadField: r3 = r0->field_3b
    //     0x6a4278: ldur            w3, [x0, #0x3b]
    // 0x6a427c: DecompressPointer r3
    //     0x6a427c: add             x3, x3, HEAP, lsl #32
    // 0x6a4280: mov             x1, x3
    // 0x6a4284: stur            x3, [fp, #-0x10]
    // 0x6a4288: r2 = Instance_Chapter15Stat
    //     0x6a4288: add             x2, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x6a428c: ldr             x2, [x2, #0xc0]
    // 0x6a4290: r0 = _getValueOrData()
    //     0x6a4290: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4294: mov             x1, x0
    // 0x6a4298: ldur            x0, [fp, #-0x10]
    // 0x6a429c: LoadField: r2 = r0->field_f
    //     0x6a429c: ldur            w2, [x0, #0xf]
    // 0x6a42a0: DecompressPointer r2
    //     0x6a42a0: add             x2, x2, HEAP, lsl #32
    // 0x6a42a4: cmp             w2, w1
    // 0x6a42a8: b.ne            #0x6a42b0
    // 0x6a42ac: r1 = Null
    //     0x6a42ac: mov             x1, NULL
    // 0x6a42b0: cmp             w1, NULL
    // 0x6a42b4: b.ne            #0x6a42c0
    // 0x6a42b8: r1 = Instance_CustomNum
    //     0x6a42b8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a42bc: ldr             x1, [x1, #0xaf8]
    // 0x6a42c0: ldur            x3, [fp, #-8]
    // 0x6a42c4: ldur            x2, [fp, #-0x18]
    // 0x6a42c8: r0 = add()
    //     0x6a42c8: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a42cc: ldur            x1, [fp, #-0x10]
    // 0x6a42d0: mov             x3, x0
    // 0x6a42d4: r2 = Instance_Chapter15Stat
    //     0x6a42d4: add             x2, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x6a42d8: ldr             x2, [x2, #0xc0]
    // 0x6a42dc: r0 = []=()
    //     0x6a42dc: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a42e0: ldur            x1, [fp, #-8]
    // 0x6a42e4: r2 = Instance_Chapter15Stat
    //     0x6a42e4: add             x2, PP, #0x11, lsl #12  ; [pp+0x110c0] Obj!Chapter15Stat@85f721
    //     0x6a42e8: ldr             x2, [x2, #0xc0]
    // 0x6a42ec: r0 = notifyStatGained()
    //     0x6a42ec: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6a42f0: ldur            x0, [fp, #-8]
    // 0x6a42f4: LoadField: r1 = r0->field_47
    //     0x6a42f4: ldur            w1, [x0, #0x47]
    // 0x6a42f8: DecompressPointer r1
    //     0x6a42f8: add             x1, x1, HEAP, lsl #32
    // 0x6a42fc: r2 = 2
    //     0x6a42fc: movz            x2, #0x2
    // 0x6a4300: r3 = 0.000000
    //     0x6a4300: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a4304: r0 = []=()
    //     0x6a4304: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4308: ldur            x0, [fp, #-8]
    // 0x6a430c: LoadField: r1 = r0->field_47
    //     0x6a430c: ldur            w1, [x0, #0x47]
    // 0x6a4310: DecompressPointer r1
    //     0x6a4310: add             x1, x1, HEAP, lsl #32
    // 0x6a4314: r2 = 4
    //     0x6a4314: movz            x2, #0x4
    // 0x6a4318: r3 = 0.000000
    //     0x6a4318: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a431c: r0 = []=()
    //     0x6a431c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4320: ldur            x0, [fp, #-8]
    // 0x6a4324: LoadField: r1 = r0->field_47
    //     0x6a4324: ldur            w1, [x0, #0x47]
    // 0x6a4328: DecompressPointer r1
    //     0x6a4328: add             x1, x1, HEAP, lsl #32
    // 0x6a432c: r2 = 6
    //     0x6a432c: movz            x2, #0x6
    // 0x6a4330: r3 = 0.000000
    //     0x6a4330: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a4334: r0 = []=()
    //     0x6a4334: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4338: ldur            x0, [fp, #-8]
    // 0x6a433c: LoadField: r1 = r0->field_47
    //     0x6a433c: ldur            w1, [x0, #0x47]
    // 0x6a4340: DecompressPointer r1
    //     0x6a4340: add             x1, x1, HEAP, lsl #32
    // 0x6a4344: r2 = 8
    //     0x6a4344: movz            x2, #0x8
    // 0x6a4348: r3 = 0.000000
    //     0x6a4348: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a434c: r0 = []=()
    //     0x6a434c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4350: ldur            x0, [fp, #-8]
    // 0x6a4354: LoadField: r1 = r0->field_47
    //     0x6a4354: ldur            w1, [x0, #0x47]
    // 0x6a4358: DecompressPointer r1
    //     0x6a4358: add             x1, x1, HEAP, lsl #32
    // 0x6a435c: r2 = 10
    //     0x6a435c: movz            x2, #0xa
    // 0x6a4360: r3 = 0.000000
    //     0x6a4360: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a4364: r0 = []=()
    //     0x6a4364: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4368: ldur            x0, [fp, #-8]
    // 0x6a436c: LoadField: r1 = r0->field_47
    //     0x6a436c: ldur            w1, [x0, #0x47]
    // 0x6a4370: DecompressPointer r1
    //     0x6a4370: add             x1, x1, HEAP, lsl #32
    // 0x6a4374: r2 = 12
    //     0x6a4374: movz            x2, #0xc
    // 0x6a4378: r3 = 0.000000
    //     0x6a4378: ldr             x3, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a437c: r0 = []=()
    //     0x6a437c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4380: ldur            x0, [fp, #-8]
    // 0x6a4384: LoadField: r1 = r0->field_43
    //     0x6a4384: ldur            w1, [x0, #0x43]
    // 0x6a4388: DecompressPointer r1
    //     0x6a4388: add             x1, x1, HEAP, lsl #32
    // 0x6a438c: r2 = 202
    //     0x6a438c: movz            x2, #0xca
    // 0x6a4390: r0 = containsKey()
    //     0x6a4390: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a4394: tbnz            w0, #4, #0x6a46fc
    // 0x6a4398: ldur            x0, [fp, #-8]
    // 0x6a439c: LoadField: r3 = r0->field_43
    //     0x6a439c: ldur            w3, [x0, #0x43]
    // 0x6a43a0: DecompressPointer r3
    //     0x6a43a0: add             x3, x3, HEAP, lsl #32
    // 0x6a43a4: mov             x1, x3
    // 0x6a43a8: stur            x3, [fp, #-0x10]
    // 0x6a43ac: r2 = 202
    //     0x6a43ac: movz            x2, #0xca
    // 0x6a43b0: r0 = _getValueOrData()
    //     0x6a43b0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a43b4: ldur            x2, [fp, #-0x10]
    // 0x6a43b8: LoadField: r1 = r2->field_f
    //     0x6a43b8: ldur            w1, [x2, #0xf]
    // 0x6a43bc: DecompressPointer r1
    //     0x6a43bc: add             x1, x1, HEAP, lsl #32
    // 0x6a43c0: cmp             w1, w0
    // 0x6a43c4: b.ne            #0x6a43cc
    // 0x6a43c8: r0 = Null
    //     0x6a43c8: mov             x0, NULL
    // 0x6a43cc: cmp             w0, NULL
    // 0x6a43d0: b.ne            #0x6a43dc
    // 0x6a43d4: r3 = 0
    //     0x6a43d4: movz            x3, #0
    // 0x6a43d8: b               #0x6a43ec
    // 0x6a43dc: r1 = LoadInt32Instr(r0)
    //     0x6a43dc: sbfx            x1, x0, #1, #0x1f
    //     0x6a43e0: tbz             w0, #0, #0x6a43e8
    //     0x6a43e4: ldur            x1, [x0, #7]
    // 0x6a43e8: mov             x3, x1
    // 0x6a43ec: ldur            x4, [fp, #-8]
    // 0x6a43f0: r0 = BoxInt64Instr(r3)
    //     0x6a43f0: sbfiz           x0, x3, #1, #0x1f
    //     0x6a43f4: cmp             x3, x0, asr #1
    //     0x6a43f8: b.eq            #0x6a4404
    //     0x6a43fc: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a4400: stur            x3, [x0, #7]
    // 0x6a4404: mov             x1, x2
    // 0x6a4408: mov             x3, x0
    // 0x6a440c: r2 = 2
    //     0x6a440c: movz            x2, #0x2
    // 0x6a4410: r0 = []=()
    //     0x6a4410: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4414: ldur            x0, [fp, #-8]
    // 0x6a4418: LoadField: r3 = r0->field_43
    //     0x6a4418: ldur            w3, [x0, #0x43]
    // 0x6a441c: DecompressPointer r3
    //     0x6a441c: add             x3, x3, HEAP, lsl #32
    // 0x6a4420: mov             x1, x3
    // 0x6a4424: stur            x3, [fp, #-0x10]
    // 0x6a4428: r2 = 202
    //     0x6a4428: movz            x2, #0xca
    // 0x6a442c: r0 = _getValueOrData()
    //     0x6a442c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4430: ldur            x2, [fp, #-0x10]
    // 0x6a4434: LoadField: r1 = r2->field_f
    //     0x6a4434: ldur            w1, [x2, #0xf]
    // 0x6a4438: DecompressPointer r1
    //     0x6a4438: add             x1, x1, HEAP, lsl #32
    // 0x6a443c: cmp             w1, w0
    // 0x6a4440: b.ne            #0x6a4448
    // 0x6a4444: r0 = Null
    //     0x6a4444: mov             x0, NULL
    // 0x6a4448: cmp             w0, NULL
    // 0x6a444c: b.ne            #0x6a4458
    // 0x6a4450: r3 = 0
    //     0x6a4450: movz            x3, #0
    // 0x6a4454: b               #0x6a4468
    // 0x6a4458: r1 = LoadInt32Instr(r0)
    //     0x6a4458: sbfx            x1, x0, #1, #0x1f
    //     0x6a445c: tbz             w0, #0, #0x6a4464
    //     0x6a4460: ldur            x1, [x0, #7]
    // 0x6a4464: mov             x3, x1
    // 0x6a4468: ldur            x4, [fp, #-8]
    // 0x6a446c: r0 = BoxInt64Instr(r3)
    //     0x6a446c: sbfiz           x0, x3, #1, #0x1f
    //     0x6a4470: cmp             x3, x0, asr #1
    //     0x6a4474: b.eq            #0x6a4480
    //     0x6a4478: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a447c: stur            x3, [x0, #7]
    // 0x6a4480: mov             x1, x2
    // 0x6a4484: mov             x3, x0
    // 0x6a4488: r2 = 4
    //     0x6a4488: movz            x2, #0x4
    // 0x6a448c: r0 = []=()
    //     0x6a448c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4490: ldur            x0, [fp, #-8]
    // 0x6a4494: LoadField: r3 = r0->field_43
    //     0x6a4494: ldur            w3, [x0, #0x43]
    // 0x6a4498: DecompressPointer r3
    //     0x6a4498: add             x3, x3, HEAP, lsl #32
    // 0x6a449c: mov             x1, x3
    // 0x6a44a0: stur            x3, [fp, #-0x10]
    // 0x6a44a4: r2 = 202
    //     0x6a44a4: movz            x2, #0xca
    // 0x6a44a8: r0 = _getValueOrData()
    //     0x6a44a8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a44ac: ldur            x2, [fp, #-0x10]
    // 0x6a44b0: LoadField: r1 = r2->field_f
    //     0x6a44b0: ldur            w1, [x2, #0xf]
    // 0x6a44b4: DecompressPointer r1
    //     0x6a44b4: add             x1, x1, HEAP, lsl #32
    // 0x6a44b8: cmp             w1, w0
    // 0x6a44bc: b.ne            #0x6a44c4
    // 0x6a44c0: r0 = Null
    //     0x6a44c0: mov             x0, NULL
    // 0x6a44c4: cmp             w0, NULL
    // 0x6a44c8: b.ne            #0x6a44d4
    // 0x6a44cc: r3 = 0
    //     0x6a44cc: movz            x3, #0
    // 0x6a44d0: b               #0x6a44e4
    // 0x6a44d4: r1 = LoadInt32Instr(r0)
    //     0x6a44d4: sbfx            x1, x0, #1, #0x1f
    //     0x6a44d8: tbz             w0, #0, #0x6a44e0
    //     0x6a44dc: ldur            x1, [x0, #7]
    // 0x6a44e0: mov             x3, x1
    // 0x6a44e4: ldur            x4, [fp, #-8]
    // 0x6a44e8: r0 = BoxInt64Instr(r3)
    //     0x6a44e8: sbfiz           x0, x3, #1, #0x1f
    //     0x6a44ec: cmp             x3, x0, asr #1
    //     0x6a44f0: b.eq            #0x6a44fc
    //     0x6a44f4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a44f8: stur            x3, [x0, #7]
    // 0x6a44fc: mov             x1, x2
    // 0x6a4500: mov             x3, x0
    // 0x6a4504: r2 = 6
    //     0x6a4504: movz            x2, #0x6
    // 0x6a4508: r0 = []=()
    //     0x6a4508: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a450c: ldur            x0, [fp, #-8]
    // 0x6a4510: LoadField: r3 = r0->field_43
    //     0x6a4510: ldur            w3, [x0, #0x43]
    // 0x6a4514: DecompressPointer r3
    //     0x6a4514: add             x3, x3, HEAP, lsl #32
    // 0x6a4518: mov             x1, x3
    // 0x6a451c: stur            x3, [fp, #-0x10]
    // 0x6a4520: r2 = 202
    //     0x6a4520: movz            x2, #0xca
    // 0x6a4524: r0 = _getValueOrData()
    //     0x6a4524: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4528: ldur            x2, [fp, #-0x10]
    // 0x6a452c: LoadField: r1 = r2->field_f
    //     0x6a452c: ldur            w1, [x2, #0xf]
    // 0x6a4530: DecompressPointer r1
    //     0x6a4530: add             x1, x1, HEAP, lsl #32
    // 0x6a4534: cmp             w1, w0
    // 0x6a4538: b.ne            #0x6a4540
    // 0x6a453c: r0 = Null
    //     0x6a453c: mov             x0, NULL
    // 0x6a4540: cmp             w0, NULL
    // 0x6a4544: b.ne            #0x6a4550
    // 0x6a4548: r3 = 0
    //     0x6a4548: movz            x3, #0
    // 0x6a454c: b               #0x6a4560
    // 0x6a4550: r1 = LoadInt32Instr(r0)
    //     0x6a4550: sbfx            x1, x0, #1, #0x1f
    //     0x6a4554: tbz             w0, #0, #0x6a455c
    //     0x6a4558: ldur            x1, [x0, #7]
    // 0x6a455c: mov             x3, x1
    // 0x6a4560: ldur            x4, [fp, #-8]
    // 0x6a4564: r0 = BoxInt64Instr(r3)
    //     0x6a4564: sbfiz           x0, x3, #1, #0x1f
    //     0x6a4568: cmp             x3, x0, asr #1
    //     0x6a456c: b.eq            #0x6a4578
    //     0x6a4570: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a4574: stur            x3, [x0, #7]
    // 0x6a4578: mov             x1, x2
    // 0x6a457c: mov             x3, x0
    // 0x6a4580: r2 = 22
    //     0x6a4580: movz            x2, #0x16
    // 0x6a4584: r0 = []=()
    //     0x6a4584: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4588: ldur            x0, [fp, #-8]
    // 0x6a458c: LoadField: r3 = r0->field_43
    //     0x6a458c: ldur            w3, [x0, #0x43]
    // 0x6a4590: DecompressPointer r3
    //     0x6a4590: add             x3, x3, HEAP, lsl #32
    // 0x6a4594: mov             x1, x3
    // 0x6a4598: stur            x3, [fp, #-0x10]
    // 0x6a459c: r2 = 202
    //     0x6a459c: movz            x2, #0xca
    // 0x6a45a0: r0 = _getValueOrData()
    //     0x6a45a0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a45a4: ldur            x2, [fp, #-0x10]
    // 0x6a45a8: LoadField: r1 = r2->field_f
    //     0x6a45a8: ldur            w1, [x2, #0xf]
    // 0x6a45ac: DecompressPointer r1
    //     0x6a45ac: add             x1, x1, HEAP, lsl #32
    // 0x6a45b0: cmp             w1, w0
    // 0x6a45b4: b.ne            #0x6a45bc
    // 0x6a45b8: r0 = Null
    //     0x6a45b8: mov             x0, NULL
    // 0x6a45bc: cmp             w0, NULL
    // 0x6a45c0: b.ne            #0x6a45cc
    // 0x6a45c4: r3 = 0
    //     0x6a45c4: movz            x3, #0
    // 0x6a45c8: b               #0x6a45dc
    // 0x6a45cc: r1 = LoadInt32Instr(r0)
    //     0x6a45cc: sbfx            x1, x0, #1, #0x1f
    //     0x6a45d0: tbz             w0, #0, #0x6a45d8
    //     0x6a45d4: ldur            x1, [x0, #7]
    // 0x6a45d8: mov             x3, x1
    // 0x6a45dc: ldur            x4, [fp, #-8]
    // 0x6a45e0: r0 = BoxInt64Instr(r3)
    //     0x6a45e0: sbfiz           x0, x3, #1, #0x1f
    //     0x6a45e4: cmp             x3, x0, asr #1
    //     0x6a45e8: b.eq            #0x6a45f4
    //     0x6a45ec: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a45f0: stur            x3, [x0, #7]
    // 0x6a45f4: mov             x1, x2
    // 0x6a45f8: mov             x3, x0
    // 0x6a45fc: r2 = 24
    //     0x6a45fc: movz            x2, #0x18
    // 0x6a4600: r0 = []=()
    //     0x6a4600: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4604: ldur            x0, [fp, #-8]
    // 0x6a4608: LoadField: r3 = r0->field_43
    //     0x6a4608: ldur            w3, [x0, #0x43]
    // 0x6a460c: DecompressPointer r3
    //     0x6a460c: add             x3, x3, HEAP, lsl #32
    // 0x6a4610: mov             x1, x3
    // 0x6a4614: stur            x3, [fp, #-0x10]
    // 0x6a4618: r2 = 202
    //     0x6a4618: movz            x2, #0xca
    // 0x6a461c: r0 = _getValueOrData()
    //     0x6a461c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4620: ldur            x2, [fp, #-0x10]
    // 0x6a4624: LoadField: r1 = r2->field_f
    //     0x6a4624: ldur            w1, [x2, #0xf]
    // 0x6a4628: DecompressPointer r1
    //     0x6a4628: add             x1, x1, HEAP, lsl #32
    // 0x6a462c: cmp             w1, w0
    // 0x6a4630: b.ne            #0x6a4638
    // 0x6a4634: r0 = Null
    //     0x6a4634: mov             x0, NULL
    // 0x6a4638: cmp             w0, NULL
    // 0x6a463c: b.ne            #0x6a4648
    // 0x6a4640: r3 = 0
    //     0x6a4640: movz            x3, #0
    // 0x6a4644: b               #0x6a4658
    // 0x6a4648: r1 = LoadInt32Instr(r0)
    //     0x6a4648: sbfx            x1, x0, #1, #0x1f
    //     0x6a464c: tbz             w0, #0, #0x6a4654
    //     0x6a4650: ldur            x1, [x0, #7]
    // 0x6a4654: mov             x3, x1
    // 0x6a4658: ldur            x4, [fp, #-8]
    // 0x6a465c: r0 = BoxInt64Instr(r3)
    //     0x6a465c: sbfiz           x0, x3, #1, #0x1f
    //     0x6a4660: cmp             x3, x0, asr #1
    //     0x6a4664: b.eq            #0x6a4670
    //     0x6a4668: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a466c: stur            x3, [x0, #7]
    // 0x6a4670: mov             x1, x2
    // 0x6a4674: mov             x3, x0
    // 0x6a4678: r2 = 26
    //     0x6a4678: movz            x2, #0x1a
    // 0x6a467c: r0 = []=()
    //     0x6a467c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4680: ldur            x0, [fp, #-8]
    // 0x6a4684: LoadField: r3 = r0->field_43
    //     0x6a4684: ldur            w3, [x0, #0x43]
    // 0x6a4688: DecompressPointer r3
    //     0x6a4688: add             x3, x3, HEAP, lsl #32
    // 0x6a468c: mov             x1, x3
    // 0x6a4690: stur            x3, [fp, #-0x10]
    // 0x6a4694: r2 = 202
    //     0x6a4694: movz            x2, #0xca
    // 0x6a4698: r0 = _getValueOrData()
    //     0x6a4698: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a469c: ldur            x2, [fp, #-0x10]
    // 0x6a46a0: LoadField: r1 = r2->field_f
    //     0x6a46a0: ldur            w1, [x2, #0xf]
    // 0x6a46a4: DecompressPointer r1
    //     0x6a46a4: add             x1, x1, HEAP, lsl #32
    // 0x6a46a8: cmp             w1, w0
    // 0x6a46ac: b.ne            #0x6a46b4
    // 0x6a46b0: r0 = Null
    //     0x6a46b0: mov             x0, NULL
    // 0x6a46b4: cmp             w0, NULL
    // 0x6a46b8: b.ne            #0x6a46c4
    // 0x6a46bc: r3 = 0
    //     0x6a46bc: movz            x3, #0
    // 0x6a46c0: b               #0x6a46d4
    // 0x6a46c4: r1 = LoadInt32Instr(r0)
    //     0x6a46c4: sbfx            x1, x0, #1, #0x1f
    //     0x6a46c8: tbz             w0, #0, #0x6a46d0
    //     0x6a46cc: ldur            x1, [x0, #7]
    // 0x6a46d0: mov             x3, x1
    // 0x6a46d4: r0 = BoxInt64Instr(r3)
    //     0x6a46d4: sbfiz           x0, x3, #1, #0x1f
    //     0x6a46d8: cmp             x3, x0, asr #1
    //     0x6a46dc: b.eq            #0x6a46e8
    //     0x6a46e0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a46e4: stur            x3, [x0, #7]
    // 0x6a46e8: mov             x1, x2
    // 0x6a46ec: mov             x3, x0
    // 0x6a46f0: r2 = 28
    //     0x6a46f0: movz            x2, #0x1c
    // 0x6a46f4: r0 = []=()
    //     0x6a46f4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a46f8: b               #0x6a4788
    // 0x6a46fc: ldur            x0, [fp, #-8]
    // 0x6a4700: LoadField: r1 = r0->field_43
    //     0x6a4700: ldur            w1, [x0, #0x43]
    // 0x6a4704: DecompressPointer r1
    //     0x6a4704: add             x1, x1, HEAP, lsl #32
    // 0x6a4708: r2 = 2
    //     0x6a4708: movz            x2, #0x2
    // 0x6a470c: r0 = remove()
    //     0x6a470c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4710: ldur            x0, [fp, #-8]
    // 0x6a4714: LoadField: r1 = r0->field_43
    //     0x6a4714: ldur            w1, [x0, #0x43]
    // 0x6a4718: DecompressPointer r1
    //     0x6a4718: add             x1, x1, HEAP, lsl #32
    // 0x6a471c: r2 = 4
    //     0x6a471c: movz            x2, #0x4
    // 0x6a4720: r0 = remove()
    //     0x6a4720: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4724: ldur            x0, [fp, #-8]
    // 0x6a4728: LoadField: r1 = r0->field_43
    //     0x6a4728: ldur            w1, [x0, #0x43]
    // 0x6a472c: DecompressPointer r1
    //     0x6a472c: add             x1, x1, HEAP, lsl #32
    // 0x6a4730: r2 = 6
    //     0x6a4730: movz            x2, #0x6
    // 0x6a4734: r0 = remove()
    //     0x6a4734: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4738: ldur            x0, [fp, #-8]
    // 0x6a473c: LoadField: r1 = r0->field_43
    //     0x6a473c: ldur            w1, [x0, #0x43]
    // 0x6a4740: DecompressPointer r1
    //     0x6a4740: add             x1, x1, HEAP, lsl #32
    // 0x6a4744: r2 = 22
    //     0x6a4744: movz            x2, #0x16
    // 0x6a4748: r0 = remove()
    //     0x6a4748: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a474c: ldur            x0, [fp, #-8]
    // 0x6a4750: LoadField: r1 = r0->field_43
    //     0x6a4750: ldur            w1, [x0, #0x43]
    // 0x6a4754: DecompressPointer r1
    //     0x6a4754: add             x1, x1, HEAP, lsl #32
    // 0x6a4758: r2 = 24
    //     0x6a4758: movz            x2, #0x18
    // 0x6a475c: r0 = remove()
    //     0x6a475c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4760: ldur            x0, [fp, #-8]
    // 0x6a4764: LoadField: r1 = r0->field_43
    //     0x6a4764: ldur            w1, [x0, #0x43]
    // 0x6a4768: DecompressPointer r1
    //     0x6a4768: add             x1, x1, HEAP, lsl #32
    // 0x6a476c: r2 = 26
    //     0x6a476c: movz            x2, #0x1a
    // 0x6a4770: r0 = remove()
    //     0x6a4770: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4774: ldur            x0, [fp, #-8]
    // 0x6a4778: LoadField: r1 = r0->field_43
    //     0x6a4778: ldur            w1, [x0, #0x43]
    // 0x6a477c: DecompressPointer r1
    //     0x6a477c: add             x1, x1, HEAP, lsl #32
    // 0x6a4780: r2 = 28
    //     0x6a4780: movz            x2, #0x1c
    // 0x6a4784: r0 = remove()
    //     0x6a4784: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4788: ldur            x0, [fp, #-8]
    // 0x6a478c: LoadField: r1 = r0->field_3f
    //     0x6a478c: ldur            w1, [x0, #0x3f]
    // 0x6a4790: DecompressPointer r1
    //     0x6a4790: add             x1, x1, HEAP, lsl #32
    // 0x6a4794: LoadField: r2 = r1->field_7
    //     0x6a4794: ldur            w2, [x1, #7]
    // 0x6a4798: DecompressPointer r2
    //     0x6a4798: add             x2, x2, HEAP, lsl #32
    // 0x6a479c: cmp             w2, #2
    // 0x6a47a0: b.ne            #0x6a4854
    // 0x6a47a4: LoadField: r3 = r0->field_37
    //     0x6a47a4: ldur            w3, [x0, #0x37]
    // 0x6a47a8: DecompressPointer r3
    //     0x6a47a8: add             x3, x3, HEAP, lsl #32
    // 0x6a47ac: stur            x3, [fp, #-0x18]
    // 0x6a47b0: LoadField: r4 = r0->field_8b
    //     0x6a47b0: ldur            w4, [x0, #0x8b]
    // 0x6a47b4: DecompressPointer r4
    //     0x6a47b4: add             x4, x4, HEAP, lsl #32
    // 0x6a47b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a47bc: cmp             w4, w16
    // 0x6a47c0: b.eq            #0x6a49c8
    // 0x6a47c4: mov             x1, x4
    // 0x6a47c8: stur            x4, [fp, #-0x10]
    // 0x6a47cc: r2 = 2
    //     0x6a47cc: movz            x2, #0x2
    // 0x6a47d0: r0 = _getValueOrData()
    //     0x6a47d0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a47d4: mov             x1, x0
    // 0x6a47d8: ldur            x0, [fp, #-0x10]
    // 0x6a47dc: LoadField: r2 = r0->field_f
    //     0x6a47dc: ldur            w2, [x0, #0xf]
    // 0x6a47e0: DecompressPointer r2
    //     0x6a47e0: add             x2, x2, HEAP, lsl #32
    // 0x6a47e4: cmp             w2, w1
    // 0x6a47e8: b.ne            #0x6a47f4
    // 0x6a47ec: r0 = Null
    //     0x6a47ec: mov             x0, NULL
    // 0x6a47f0: b               #0x6a47f8
    // 0x6a47f4: mov             x0, x1
    // 0x6a47f8: cmp             w0, NULL
    // 0x6a47fc: b.ne            #0x6a4808
    // 0x6a4800: r0 = Null
    //     0x6a4800: mov             x0, NULL
    // 0x6a4804: b               #0x6a4828
    // 0x6a4808: LoadField: r1 = r0->field_27
    //     0x6a4808: ldur            w1, [x0, #0x27]
    // 0x6a480c: DecompressPointer r1
    //     0x6a480c: add             x1, x1, HEAP, lsl #32
    // 0x6a4810: cmp             w1, NULL
    // 0x6a4814: b.ne            #0x6a4820
    // 0x6a4818: r0 = Null
    //     0x6a4818: mov             x0, NULL
    // 0x6a481c: b               #0x6a4828
    // 0x6a4820: LoadField: r0 = r1->field_f
    //     0x6a4820: ldur            w0, [x1, #0xf]
    // 0x6a4824: DecompressPointer r0
    //     0x6a4824: add             x0, x0, HEAP, lsl #32
    // 0x6a4828: cmp             w0, NULL
    // 0x6a482c: b.ne            #0x6a483c
    // 0x6a4830: r3 = Instance_CustomNum
    //     0x6a4830: add             x3, PP, #0x28, lsl #12  ; [pp+0x285e0] Obj!CustomNum@82a561
    //     0x6a4834: ldr             x3, [x3, #0x5e0]
    // 0x6a4838: b               #0x6a4840
    // 0x6a483c: mov             x3, x0
    // 0x6a4840: ldur            x1, [fp, #-0x18]
    // 0x6a4844: r2 = Instance_Chapter15Stat
    //     0x6a4844: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x6a4848: ldr             x2, [x2, #0x90]
    // 0x6a484c: r0 = []=()
    //     0x6a484c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6a4850: b               #0x6a4868
    // 0x6a4854: LoadField: r1 = r0->field_37
    //     0x6a4854: ldur            w1, [x0, #0x37]
    // 0x6a4858: DecompressPointer r1
    //     0x6a4858: add             x1, x1, HEAP, lsl #32
    // 0x6a485c: r2 = Instance_Chapter15Stat
    //     0x6a485c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x6a4860: ldr             x2, [x2, #0x90]
    // 0x6a4864: r0 = remove()
    //     0x6a4864: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4868: ldur            x0, [fp, #-8]
    // 0x6a486c: LoadField: r1 = r0->field_3b
    //     0x6a486c: ldur            w1, [x0, #0x3b]
    // 0x6a4870: DecompressPointer r1
    //     0x6a4870: add             x1, x1, HEAP, lsl #32
    // 0x6a4874: r2 = Instance_Chapter15Stat
    //     0x6a4874: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x6a4878: ldr             x2, [x2, #0x90]
    // 0x6a487c: r0 = remove()
    //     0x6a487c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4880: ldur            x0, [fp, #-8]
    // 0x6a4884: LoadField: r1 = r0->field_37
    //     0x6a4884: ldur            w1, [x0, #0x37]
    // 0x6a4888: DecompressPointer r1
    //     0x6a4888: add             x1, x1, HEAP, lsl #32
    // 0x6a488c: r2 = Instance_Chapter15Stat
    //     0x6a488c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x6a4890: ldr             x2, [x2, #0xfd8]
    // 0x6a4894: r0 = remove()
    //     0x6a4894: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4898: ldur            x0, [fp, #-8]
    // 0x6a489c: LoadField: r1 = r0->field_3b
    //     0x6a489c: ldur            w1, [x0, #0x3b]
    // 0x6a48a0: DecompressPointer r1
    //     0x6a48a0: add             x1, x1, HEAP, lsl #32
    // 0x6a48a4: r2 = Instance_Chapter15Stat
    //     0x6a48a4: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Chapter15Stat@85f801
    //     0x6a48a8: ldr             x2, [x2, #0xfd8]
    // 0x6a48ac: r0 = remove()
    //     0x6a48ac: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a48b0: ldur            x0, [fp, #-8]
    // 0x6a48b4: LoadField: r1 = r0->field_37
    //     0x6a48b4: ldur            w1, [x0, #0x37]
    // 0x6a48b8: DecompressPointer r1
    //     0x6a48b8: add             x1, x1, HEAP, lsl #32
    // 0x6a48bc: r2 = Instance_Chapter15Stat
    //     0x6a48bc: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x6a48c0: ldr             x2, [x2, #0xfe0]
    // 0x6a48c4: r0 = remove()
    //     0x6a48c4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a48c8: ldur            x0, [fp, #-8]
    // 0x6a48cc: LoadField: r1 = r0->field_3b
    //     0x6a48cc: ldur            w1, [x0, #0x3b]
    // 0x6a48d0: DecompressPointer r1
    //     0x6a48d0: add             x1, x1, HEAP, lsl #32
    // 0x6a48d4: r2 = Instance_Chapter15Stat
    //     0x6a48d4: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe0] Obj!Chapter15Stat@85f7e1
    //     0x6a48d8: ldr             x2, [x2, #0xfe0]
    // 0x6a48dc: r0 = remove()
    //     0x6a48dc: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a48e0: ldur            x0, [fp, #-8]
    // 0x6a48e4: LoadField: r1 = r0->field_37
    //     0x6a48e4: ldur            w1, [x0, #0x37]
    // 0x6a48e8: DecompressPointer r1
    //     0x6a48e8: add             x1, x1, HEAP, lsl #32
    // 0x6a48ec: r2 = Instance_Chapter15Stat
    //     0x6a48ec: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x6a48f0: ldr             x2, [x2, #0xfe8]
    // 0x6a48f4: r0 = remove()
    //     0x6a48f4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a48f8: ldur            x0, [fp, #-8]
    // 0x6a48fc: LoadField: r1 = r0->field_3b
    //     0x6a48fc: ldur            w1, [x0, #0x3b]
    // 0x6a4900: DecompressPointer r1
    //     0x6a4900: add             x1, x1, HEAP, lsl #32
    // 0x6a4904: r2 = Instance_Chapter15Stat
    //     0x6a4904: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fe8] Obj!Chapter15Stat@85f7c1
    //     0x6a4908: ldr             x2, [x2, #0xfe8]
    // 0x6a490c: r0 = remove()
    //     0x6a490c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4910: ldur            x0, [fp, #-8]
    // 0x6a4914: LoadField: r1 = r0->field_37
    //     0x6a4914: ldur            w1, [x0, #0x37]
    // 0x6a4918: DecompressPointer r1
    //     0x6a4918: add             x1, x1, HEAP, lsl #32
    // 0x6a491c: r2 = Instance_Chapter15Stat
    //     0x6a491c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x6a4920: ldr             x2, [x2, #0xff0]
    // 0x6a4924: r0 = remove()
    //     0x6a4924: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4928: ldur            x0, [fp, #-8]
    // 0x6a492c: LoadField: r1 = r0->field_3b
    //     0x6a492c: ldur            w1, [x0, #0x3b]
    // 0x6a4930: DecompressPointer r1
    //     0x6a4930: add             x1, x1, HEAP, lsl #32
    // 0x6a4934: r2 = Instance_Chapter15Stat
    //     0x6a4934: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff0] Obj!Chapter15Stat@85f7a1
    //     0x6a4938: ldr             x2, [x2, #0xff0]
    // 0x6a493c: r0 = remove()
    //     0x6a493c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4940: ldur            x0, [fp, #-8]
    // 0x6a4944: LoadField: r1 = r0->field_37
    //     0x6a4944: ldur            w1, [x0, #0x37]
    // 0x6a4948: DecompressPointer r1
    //     0x6a4948: add             x1, x1, HEAP, lsl #32
    // 0x6a494c: r2 = Instance_Chapter15Stat
    //     0x6a494c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x6a4950: ldr             x2, [x2, #0xff8]
    // 0x6a4954: r0 = remove()
    //     0x6a4954: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4958: ldur            x0, [fp, #-8]
    // 0x6a495c: LoadField: r1 = r0->field_3b
    //     0x6a495c: ldur            w1, [x0, #0x3b]
    // 0x6a4960: DecompressPointer r1
    //     0x6a4960: add             x1, x1, HEAP, lsl #32
    // 0x6a4964: r2 = Instance_Chapter15Stat
    //     0x6a4964: add             x2, PP, #0x10, lsl #12  ; [pp+0x10ff8] Obj!Chapter15Stat@85f781
    //     0x6a4968: ldr             x2, [x2, #0xff8]
    // 0x6a496c: r0 = remove()
    //     0x6a496c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4970: ldur            x0, [fp, #-8]
    // 0x6a4974: LoadField: r1 = r0->field_37
    //     0x6a4974: ldur            w1, [x0, #0x37]
    // 0x6a4978: DecompressPointer r1
    //     0x6a4978: add             x1, x1, HEAP, lsl #32
    // 0x6a497c: r2 = Instance_Chapter15Stat
    //     0x6a497c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x6a4980: ldr             x2, [x2]
    // 0x6a4984: r0 = remove()
    //     0x6a4984: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a4988: ldur            x0, [fp, #-8]
    // 0x6a498c: LoadField: r1 = r0->field_3b
    //     0x6a498c: ldur            w1, [x0, #0x3b]
    // 0x6a4990: DecompressPointer r1
    //     0x6a4990: add             x1, x1, HEAP, lsl #32
    // 0x6a4994: r2 = Instance_Chapter15Stat
    //     0x6a4994: add             x2, PP, #0x11, lsl #12  ; [pp+0x11000] Obj!Chapter15Stat@85f761
    //     0x6a4998: ldr             x2, [x2]
    // 0x6a499c: r0 = remove()
    //     0x6a499c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6a49a0: ldur            x1, [fp, #-8]
    // 0x6a49a4: LoadField: r2 = r1->field_93
    //     0x6a49a4: ldur            w2, [x1, #0x93]
    // 0x6a49a8: DecompressPointer r2
    //     0x6a49a8: add             x2, x2, HEAP, lsl #32
    // 0x6a49ac: StoreField: r2->field_7 = rZR
    //     0x6a49ac: stur            xzr, [x2, #7]
    // 0x6a49b0: r0 = Null
    //     0x6a49b0: mov             x0, NULL
    // 0x6a49b4: LeaveFrame
    //     0x6a49b4: mov             SP, fp
    //     0x6a49b8: ldp             fp, lr, [SP], #0x10
    // 0x6a49bc: ret
    //     0x6a49bc: ret             
    // 0x6a49c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a49c0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a49c4: b               #0x6a41f8
    // 0x6a49c8: r9 = generators
    //     0x6a49c8: add             x9, PP, #0x11, lsl #12  ; [pp+0x11088] Field <Chapter15GameState.generators>: late (offset: 0x8c)
    //     0x6a49cc: ldr             x9, [x9, #0x88]
    // 0x6a49d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a49d0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ getPushPrestigePoints(/* No info */) {
    // ** addr: 0x6a49d4, size: 0x1b4
    // 0x6a49d4: EnterFrame
    //     0x6a49d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a49d8: mov             fp, SP
    // 0x6a49dc: AllocStack(0x20)
    //     0x6a49dc: sub             SP, SP, #0x20
    // 0x6a49e0: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x10 */)
    //     0x6a49e0: mov             x0, x1
    //     0x6a49e4: stur            x1, [fp, #-0x10]
    // 0x6a49e8: CheckStackOverflow
    //     0x6a49e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a49ec: cmp             SP, x16
    //     0x6a49f0: b.ls            #0x6a4b80
    // 0x6a49f4: LoadField: r3 = r0->field_3b
    //     0x6a49f4: ldur            w3, [x0, #0x3b]
    // 0x6a49f8: DecompressPointer r3
    //     0x6a49f8: add             x3, x3, HEAP, lsl #32
    // 0x6a49fc: mov             x1, x3
    // 0x6a4a00: stur            x3, [fp, #-8]
    // 0x6a4a04: r2 = Instance_Chapter15Stat
    //     0x6a4a04: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x6a4a08: ldr             x2, [x2, #0x90]
    // 0x6a4a0c: r0 = _getValueOrData()
    //     0x6a4a0c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4a10: mov             x1, x0
    // 0x6a4a14: ldur            x0, [fp, #-8]
    // 0x6a4a18: LoadField: r2 = r0->field_f
    //     0x6a4a18: ldur            w2, [x0, #0xf]
    // 0x6a4a1c: DecompressPointer r2
    //     0x6a4a1c: add             x2, x2, HEAP, lsl #32
    // 0x6a4a20: cmp             w2, w1
    // 0x6a4a24: b.ne            #0x6a4a30
    // 0x6a4a28: r0 = Null
    //     0x6a4a28: mov             x0, NULL
    // 0x6a4a2c: b               #0x6a4a34
    // 0x6a4a30: mov             x0, x1
    // 0x6a4a34: cmp             w0, NULL
    // 0x6a4a38: b.ne            #0x6a4a48
    // 0x6a4a3c: r1 = Instance_CustomNum
    //     0x6a4a3c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a4a40: ldr             x1, [x1, #0xaf8]
    // 0x6a4a44: b               #0x6a4a4c
    // 0x6a4a48: mov             x1, x0
    // 0x6a4a4c: ldur            x0, [fp, #-0x10]
    // 0x6a4a50: r2 = Instance_CustomNum
    //     0x6a4a50: add             x2, PP, #0x28, lsl #12  ; [pp+0x285e8] Obj!CustomNum@82b991
    //     0x6a4a54: ldr             x2, [x2, #0x5e8]
    // 0x6a4a58: r0 = div()
    //     0x6a4a58: bl              #0x460f80  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::div
    // 0x6a4a5c: mov             x3, x0
    // 0x6a4a60: ldur            x0, [fp, #-0x10]
    // 0x6a4a64: stur            x3, [fp, #-0x18]
    // 0x6a4a68: LoadField: r4 = r0->field_43
    //     0x6a4a68: ldur            w4, [x0, #0x43]
    // 0x6a4a6c: DecompressPointer r4
    //     0x6a4a6c: add             x4, x4, HEAP, lsl #32
    // 0x6a4a70: mov             x1, x4
    // 0x6a4a74: stur            x4, [fp, #-8]
    // 0x6a4a78: r2 = 206
    //     0x6a4a78: movz            x2, #0xce
    // 0x6a4a7c: r0 = _getValueOrData()
    //     0x6a4a7c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4a80: mov             x1, x0
    // 0x6a4a84: ldur            x0, [fp, #-8]
    // 0x6a4a88: LoadField: r2 = r0->field_f
    //     0x6a4a88: ldur            w2, [x0, #0xf]
    // 0x6a4a8c: DecompressPointer r2
    //     0x6a4a8c: add             x2, x2, HEAP, lsl #32
    // 0x6a4a90: cmp             w2, w1
    // 0x6a4a94: b.ne            #0x6a4aa0
    // 0x6a4a98: r0 = Null
    //     0x6a4a98: mov             x0, NULL
    // 0x6a4a9c: b               #0x6a4aa4
    // 0x6a4aa0: mov             x0, x1
    // 0x6a4aa4: cmp             w0, NULL
    // 0x6a4aa8: b.ne            #0x6a4ab4
    // 0x6a4aac: r2 = 0
    //     0x6a4aac: movz            x2, #0
    // 0x6a4ab0: b               #0x6a4ac4
    // 0x6a4ab4: r1 = LoadInt32Instr(r0)
    //     0x6a4ab4: sbfx            x1, x0, #1, #0x1f
    //     0x6a4ab8: tbz             w0, #0, #0x6a4ac0
    //     0x6a4abc: ldur            x1, [x0, #7]
    // 0x6a4ac0: mov             x2, x1
    // 0x6a4ac4: ldur            x3, [fp, #-0x10]
    // 0x6a4ac8: r0 = BoxInt64Instr(r2)
    //     0x6a4ac8: sbfiz           x0, x2, #1, #0x1f
    //     0x6a4acc: cmp             x2, x0, asr #1
    //     0x6a4ad0: b.eq            #0x6a4adc
    //     0x6a4ad4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a4ad8: stur            x2, [x0, #7]
    // 0x6a4adc: mov             x2, x0
    // 0x6a4ae0: r1 = Instance_CustomNum
    //     0x6a4ae0: add             x1, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x6a4ae4: ldr             x1, [x1, #0x448]
    // 0x6a4ae8: r0 = pow()
    //     0x6a4ae8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6a4aec: mov             x3, x0
    // 0x6a4af0: ldur            x0, [fp, #-0x10]
    // 0x6a4af4: stur            x3, [fp, #-0x20]
    // 0x6a4af8: LoadField: r4 = r0->field_3b
    //     0x6a4af8: ldur            w4, [x0, #0x3b]
    // 0x6a4afc: DecompressPointer r4
    //     0x6a4afc: add             x4, x4, HEAP, lsl #32
    // 0x6a4b00: mov             x1, x4
    // 0x6a4b04: stur            x4, [fp, #-8]
    // 0x6a4b08: r2 = Instance_Chapter15Stat
    //     0x6a4b08: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e8] Obj!Chapter15Stat@85f701
    //     0x6a4b0c: ldr             x2, [x2, #0xe8]
    // 0x6a4b10: r0 = _getValueOrData()
    //     0x6a4b10: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4b14: mov             x1, x0
    // 0x6a4b18: ldur            x0, [fp, #-8]
    // 0x6a4b1c: LoadField: r2 = r0->field_f
    //     0x6a4b1c: ldur            w2, [x0, #0xf]
    // 0x6a4b20: DecompressPointer r2
    //     0x6a4b20: add             x2, x2, HEAP, lsl #32
    // 0x6a4b24: cmp             w2, w1
    // 0x6a4b28: b.ne            #0x6a4b34
    // 0x6a4b2c: r0 = Null
    //     0x6a4b2c: mov             x0, NULL
    // 0x6a4b30: b               #0x6a4b38
    // 0x6a4b34: mov             x0, x1
    // 0x6a4b38: cmp             w0, NULL
    // 0x6a4b3c: b.ne            #0x6a4b4c
    // 0x6a4b40: r1 = Instance_CustomNum
    //     0x6a4b40: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x6a4b44: ldr             x1, [x1, #0xaf8]
    // 0x6a4b48: b               #0x6a4b50
    // 0x6a4b4c: mov             x1, x0
    // 0x6a4b50: r0 = logMinZero()
    //     0x6a4b50: bl              #0x6a4b88  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::logMinZero
    // 0x6a4b54: mov             x1, x0
    // 0x6a4b58: r2 = Instance_CustomNum
    //     0x6a4b58: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6a4b5c: ldr             x2, [x2, #0xa70]
    // 0x6a4b60: r0 = add()
    //     0x6a4b60: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6a4b64: ldur            x1, [fp, #-0x18]
    // 0x6a4b68: ldur            x2, [fp, #-0x20]
    // 0x6a4b6c: mov             x3, x0
    // 0x6a4b70: r0 = mult3()
    //     0x6a4b70: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x6a4b74: LeaveFrame
    //     0x6a4b74: mov             SP, fp
    //     0x6a4b78: ldp             fp, lr, [SP], #0x10
    // 0x6a4b7c: ret
    //     0x6a4b7c: ret             
    // 0x6a4b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4b80: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a4b84: b               #0x6a49f4
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a4c5c, size: 0x98
    // 0x6a4c5c: EnterFrame
    //     0x6a4c5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4c60: mov             fp, SP
    // 0x6a4c64: AllocStack(0x8)
    //     0x6a4c64: sub             SP, SP, #8
    // 0x6a4c68: SetupParameters([dynamic _ /* r0 */])
    //     0x6a4c68: ldr             x0, [fp, #0x10]
    //     0x6a4c6c: ldur            w3, [x0, #0x17]
    //     0x6a4c70: add             x3, x3, HEAP, lsl #32
    //     0x6a4c74: stur            x3, [fp, #-8]
    // 0x6a4c78: CheckStackOverflow
    //     0x6a4c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4c7c: cmp             SP, x16
    //     0x6a4c80: b.ls            #0x6a4ce0
    // 0x6a4c84: r0 = LoadStaticField(0xf7c)
    //     0x6a4c84: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a4c88: ldr             x0, [x0, #0x1ef8]
    // 0x6a4c8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a4c90: cmp             w0, w16
    // 0x6a4c94: b.eq            #0x6a4ce8
    // 0x6a4c98: LoadField: r1 = r0->field_13
    //     0x6a4c98: ldur            w1, [x0, #0x13]
    // 0x6a4c9c: DecompressPointer r1
    //     0x6a4c9c: add             x1, x1, HEAP, lsl #32
    // 0x6a4ca0: r2 = 66
    //     0x6a4ca0: movz            x2, #0x42
    // 0x6a4ca4: r0 = containsKey()
    //     0x6a4ca4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a4ca8: tbnz            w0, #4, #0x6a4cd0
    // 0x6a4cac: ldur            x0, [fp, #-8]
    // 0x6a4cb0: LoadField: r1 = r0->field_f
    //     0x6a4cb0: ldur            w1, [x0, #0xf]
    // 0x6a4cb4: DecompressPointer r1
    //     0x6a4cb4: add             x1, x1, HEAP, lsl #32
    // 0x6a4cb8: LoadField: r0 = r1->field_1b
    //     0x6a4cb8: ldur            w0, [x1, #0x1b]
    // 0x6a4cbc: DecompressPointer r0
    //     0x6a4cbc: add             x0, x0, HEAP, lsl #32
    // 0x6a4cc0: mov             x1, x0
    // 0x6a4cc4: r2 = 28
    //     0x6a4cc4: movz            x2, #0x1c
    // 0x6a4cc8: r0 = contains()
    //     0x6a4cc8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a4ccc: b               #0x6a4cd4
    // 0x6a4cd0: r0 = false
    //     0x6a4cd0: add             x0, NULL, #0x30  ; false
    // 0x6a4cd4: LeaveFrame
    //     0x6a4cd4: mov             SP, fp
    //     0x6a4cd8: ldp             fp, lr, [SP], #0x10
    // 0x6a4cdc: ret
    //     0x6a4cdc: ret             
    // 0x6a4ce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4ce0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a4ce4: b               #0x6a4c84
    // 0x6a4ce8: r9 = coreData
    //     0x6a4ce8: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6a4cec: ldr             x9, [x9, #0x530]
    // 0x6a4cf0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a4cf0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a4cf4, size: 0xc
    // 0x6a4cf4: r0 = "Boosts pull requests very slightly."
    //     0x6a4cf4: add             x0, PP, #0x28, lsl #12  ; [pp+0x285f0] "Boosts pull requests very slightly."
    //     0x6a4cf8: ldr             x0, [x0, #0x5f0]
    // 0x6a4cfc: ret
    //     0x6a4cfc: ret             
  }
  [closure] void applyReleasePrestige(dynamic) {
    // ** addr: 0x6a4d00, size: 0x38
    // 0x6a4d00: EnterFrame
    //     0x6a4d00: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4d04: mov             fp, SP
    // 0x6a4d08: ldr             x0, [fp, #0x10]
    // 0x6a4d0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a4d0c: ldur            w1, [x0, #0x17]
    // 0x6a4d10: DecompressPointer r1
    //     0x6a4d10: add             x1, x1, HEAP, lsl #32
    // 0x6a4d14: CheckStackOverflow
    //     0x6a4d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4d18: cmp             SP, x16
    //     0x6a4d1c: b.ls            #0x6a4d30
    // 0x6a4d20: r0 = applyReleasePrestige()
    //     0x6a4d20: bl              #0x6a3ec4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::applyReleasePrestige
    // 0x6a4d24: LeaveFrame
    //     0x6a4d24: mov             SP, fp
    //     0x6a4d28: ldp             fp, lr, [SP], #0x10
    // 0x6a4d2c: ret
    //     0x6a4d2c: ret             
    // 0x6a4d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4d30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a4d34: b               #0x6a4d20
  }
  [closure] CustomNum getReleasePrestigePoints(dynamic) {
    // ** addr: 0x6a4d38, size: 0x38
    // 0x6a4d38: EnterFrame
    //     0x6a4d38: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4d3c: mov             fp, SP
    // 0x6a4d40: ldr             x0, [fp, #0x10]
    // 0x6a4d44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a4d44: ldur            w1, [x0, #0x17]
    // 0x6a4d48: DecompressPointer r1
    //     0x6a4d48: add             x1, x1, HEAP, lsl #32
    // 0x6a4d4c: CheckStackOverflow
    //     0x6a4d4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4d50: cmp             SP, x16
    //     0x6a4d54: b.ls            #0x6a4d68
    // 0x6a4d58: r0 = getReleasePrestigePoints()
    //     0x6a4d58: bl              #0x6a4148  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getReleasePrestigePoints
    // 0x6a4d5c: LeaveFrame
    //     0x6a4d5c: mov             SP, fp
    //     0x6a4d60: ldp             fp, lr, [SP], #0x10
    // 0x6a4d64: ret
    //     0x6a4d64: ret             
    // 0x6a4d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4d68: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a4d6c: b               #0x6a4d58
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a4d70, size: 0xc
    // 0x6a4d70: r0 = "Make Release"
    //     0x6a4d70: add             x0, PP, #0x28, lsl #12  ; [pp+0x285f8] "Make Release"
    //     0x6a4d74: ldr             x0, [x0, #0x5f8]
    // 0x6a4d78: ret
    //     0x6a4d78: ret             
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x6a4d7c, size: 0x58
    // 0x6a4d7c: EnterFrame
    //     0x6a4d7c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4d80: mov             fp, SP
    // 0x6a4d84: ldr             x0, [fp, #0x18]
    // 0x6a4d88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a4d88: ldur            w1, [x0, #0x17]
    // 0x6a4d8c: DecompressPointer r1
    //     0x6a4d8c: add             x1, x1, HEAP, lsl #32
    // 0x6a4d90: CheckStackOverflow
    //     0x6a4d90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4d94: cmp             SP, x16
    //     0x6a4d98: b.ls            #0x6a4dcc
    // 0x6a4d9c: LoadField: r0 = r1->field_f
    //     0x6a4d9c: ldur            w0, [x1, #0xf]
    // 0x6a4da0: DecompressPointer r0
    //     0x6a4da0: add             x0, x0, HEAP, lsl #32
    // 0x6a4da4: mov             x1, x0
    // 0x6a4da8: r0 = checkBoosts()
    //     0x6a4da8: bl              #0x6a4dd4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::checkBoosts
    // 0x6a4dac: cmp             w0, NULL
    // 0x6a4db0: b.eq            #0x6a4dbc
    // 0x6a4db4: mov             x1, x0
    // 0x6a4db8: r0 = showToast()
    //     0x6a4db8: bl              #0x489d40  ; [package:custom_tools/BasicFunctions.dart] ::showToast
    // 0x6a4dbc: r0 = Null
    //     0x6a4dbc: mov             x0, NULL
    // 0x6a4dc0: LeaveFrame
    //     0x6a4dc0: mov             SP, fp
    //     0x6a4dc4: ldp             fp, lr, [SP], #0x10
    // 0x6a4dc8: ret
    //     0x6a4dc8: ret             
    // 0x6a4dcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4dcc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a4dd0: b               #0x6a4d9c
  }
  _ checkBoosts(/* No info */) {
    // ** addr: 0x6a4dd4, size: 0x298
    // 0x6a4dd4: EnterFrame
    //     0x6a4dd4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4dd8: mov             fp, SP
    // 0x6a4ddc: AllocStack(0x30)
    //     0x6a4ddc: sub             SP, SP, #0x30
    // 0x6a4de0: SetupParameters(Chapter15GameState this /* r1 => r0, fp-0x28 */)
    //     0x6a4de0: mov             x0, x1
    //     0x6a4de4: stur            x1, [fp, #-0x28]
    // 0x6a4de8: CheckStackOverflow
    //     0x6a4de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4dec: cmp             SP, x16
    //     0x6a4df0: b.ls            #0x6a5054
    // 0x6a4df4: r4 = false
    //     0x6a4df4: add             x4, NULL, #0x30  ; false
    // 0x6a4df8: r3 = 0
    //     0x6a4df8: movz            x3, #0
    // 0x6a4dfc: stur            x4, [fp, #-0x18]
    // 0x6a4e00: stur            x3, [fp, #-0x20]
    // 0x6a4e04: CheckStackOverflow
    //     0x6a4e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4e08: cmp             SP, x16
    //     0x6a4e0c: b.ls            #0x6a505c
    // 0x6a4e10: LoadField: r1 = r0->field_a7
    //     0x6a4e10: ldur            w1, [x0, #0xa7]
    // 0x6a4e14: DecompressPointer r1
    //     0x6a4e14: add             x1, x1, HEAP, lsl #32
    // 0x6a4e18: LoadField: r2 = r1->field_b
    //     0x6a4e18: ldur            w2, [x1, #0xb]
    // 0x6a4e1c: r1 = LoadInt32Instr(r2)
    //     0x6a4e1c: sbfx            x1, x2, #1, #0x1f
    // 0x6a4e20: cmp             x3, x1
    // 0x6a4e24: b.ge            #0x6a5044
    // 0x6a4e28: LoadField: r1 = r0->field_97
    //     0x6a4e28: ldur            w1, [x0, #0x97]
    // 0x6a4e2c: DecompressPointer r1
    //     0x6a4e2c: add             x1, x1, HEAP, lsl #32
    // 0x6a4e30: LoadField: r5 = r1->field_f
    //     0x6a4e30: ldur            w5, [x1, #0xf]
    // 0x6a4e34: DecompressPointer r5
    //     0x6a4e34: add             x5, x5, HEAP, lsl #32
    // 0x6a4e38: stur            x5, [fp, #-0x10]
    // 0x6a4e3c: lsl             x6, x3, #1
    // 0x6a4e40: mov             x2, x6
    // 0x6a4e44: stur            x6, [fp, #-8]
    // 0x6a4e48: r0 = _getKeyOrData()
    //     0x6a4e48: bl              #0x3f7518  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x6a4e4c: mov             x1, x0
    // 0x6a4e50: ldur            x0, [fp, #-0x10]
    // 0x6a4e54: cmp             w0, w1
    // 0x6a4e58: b.ne            #0x6a5028
    // 0x6a4e5c: ldur            x3, [fp, #-0x28]
    // 0x6a4e60: ldur            x4, [fp, #-0x20]
    // 0x6a4e64: LoadField: r2 = r3->field_a7
    //     0x6a4e64: ldur            w2, [x3, #0xa7]
    // 0x6a4e68: DecompressPointer r2
    //     0x6a4e68: add             x2, x2, HEAP, lsl #32
    // 0x6a4e6c: LoadField: r0 = r2->field_b
    //     0x6a4e6c: ldur            w0, [x2, #0xb]
    // 0x6a4e70: r1 = LoadInt32Instr(r0)
    //     0x6a4e70: sbfx            x1, x0, #1, #0x1f
    // 0x6a4e74: mov             x0, x1
    // 0x6a4e78: mov             x1, x4
    // 0x6a4e7c: cmp             x1, x0
    // 0x6a4e80: b.hs            #0x6a5064
    // 0x6a4e84: LoadField: r0 = r2->field_f
    //     0x6a4e84: ldur            w0, [x2, #0xf]
    // 0x6a4e88: DecompressPointer r0
    //     0x6a4e88: add             x0, x0, HEAP, lsl #32
    // 0x6a4e8c: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x6a4e8c: add             x16, x0, x4, lsl #2
    //     0x6a4e90: ldur            w5, [x16, #0xf]
    // 0x6a4e94: DecompressPointer r5
    //     0x6a4e94: add             x5, x5, HEAP, lsl #32
    // 0x6a4e98: stur            x5, [fp, #-0x30]
    // 0x6a4e9c: LoadField: r6 = r3->field_47
    //     0x6a4e9c: ldur            w6, [x3, #0x47]
    // 0x6a4ea0: DecompressPointer r6
    //     0x6a4ea0: add             x6, x6, HEAP, lsl #32
    // 0x6a4ea4: stur            x6, [fp, #-0x10]
    // 0x6a4ea8: LoadField: r2 = r5->field_b
    //     0x6a4ea8: ldur            x2, [x5, #0xb]
    // 0x6a4eac: r0 = BoxInt64Instr(r2)
    //     0x6a4eac: sbfiz           x0, x2, #1, #0x1f
    //     0x6a4eb0: cmp             x2, x0, asr #1
    //     0x6a4eb4: b.eq            #0x6a4ec0
    //     0x6a4eb8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6a4ebc: stur            x2, [x0, #7]
    // 0x6a4ec0: mov             x1, x6
    // 0x6a4ec4: mov             x2, x0
    // 0x6a4ec8: r0 = _getValueOrData()
    //     0x6a4ec8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a4ecc: mov             x1, x0
    // 0x6a4ed0: ldur            x0, [fp, #-0x10]
    // 0x6a4ed4: LoadField: r2 = r0->field_f
    //     0x6a4ed4: ldur            w2, [x0, #0xf]
    // 0x6a4ed8: DecompressPointer r2
    //     0x6a4ed8: add             x2, x2, HEAP, lsl #32
    // 0x6a4edc: cmp             w2, w1
    // 0x6a4ee0: b.ne            #0x6a4eec
    // 0x6a4ee4: r0 = Null
    //     0x6a4ee4: mov             x0, NULL
    // 0x6a4ee8: b               #0x6a4ef0
    // 0x6a4eec: mov             x0, x1
    // 0x6a4ef0: cmp             w0, NULL
    // 0x6a4ef4: b.eq            #0x6a5018
    // 0x6a4ef8: ldur            x1, [fp, #-0x30]
    // 0x6a4efc: LoadField: r2 = r1->field_13
    //     0x6a4efc: ldur            x2, [x1, #0x13]
    // 0x6a4f00: scvtf           d0, x2
    // 0x6a4f04: LoadField: d1 = r0->field_7
    //     0x6a4f04: ldur            d1, [x0, #7]
    // 0x6a4f08: fcmp            d1, d0
    // 0x6a4f0c: b.lt            #0x6a5008
    // 0x6a4f10: ldur            x0, [fp, #-0x18]
    // 0x6a4f14: tbz             w0, #4, #0x6a4f28
    // 0x6a4f18: ldur            x1, [fp, #-0x28]
    // 0x6a4f1c: r0 = resetBoosts()
    //     0x6a4f1c: bl              #0x6c909c  ; [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::resetBoosts
    // 0x6a4f20: ldur            x1, [fp, #-0x28]
    // 0x6a4f24: r0 = checkAllBoosts()
    //     0x6a4f24: bl              #0x68a66c  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::checkAllBoosts
    // 0x6a4f28: r1 = "DisplayBoostToasts"
    //     0x6a4f28: add             x1, PP, #0x26, lsl #12  ; [pp+0x26850] "DisplayBoostToasts"
    //     0x6a4f2c: ldr             x1, [x1, #0x850]
    // 0x6a4f30: r0 = prefsGetBool()
    //     0x6a4f30: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x6a4f34: cmp             w0, NULL
    // 0x6a4f38: b.eq            #0x6a4f40
    // 0x6a4f3c: tbnz            w0, #4, #0x6a4ff8
    // 0x6a4f40: ldur            x0, [fp, #-0x28]
    // 0x6a4f44: LoadField: r1 = r0->field_9b
    //     0x6a4f44: ldur            w1, [x0, #0x9b]
    // 0x6a4f48: DecompressPointer r1
    //     0x6a4f48: add             x1, x1, HEAP, lsl #32
    // 0x6a4f4c: LoadField: r3 = r1->field_f
    //     0x6a4f4c: ldur            w3, [x1, #0xf]
    // 0x6a4f50: DecompressPointer r3
    //     0x6a4f50: add             x3, x3, HEAP, lsl #32
    // 0x6a4f54: ldur            x2, [fp, #-8]
    // 0x6a4f58: stur            x3, [fp, #-0x10]
    // 0x6a4f5c: r0 = _getKeyOrData()
    //     0x6a4f5c: bl              #0x3f7518  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x6a4f60: mov             x1, x0
    // 0x6a4f64: ldur            x0, [fp, #-0x10]
    // 0x6a4f68: cmp             w0, w1
    // 0x6a4f6c: b.eq            #0x6a4f7c
    // 0x6a4f70: ldur            x2, [fp, #-0x28]
    // 0x6a4f74: ldur            x1, [fp, #-0x20]
    // 0x6a4f78: b               #0x6a5000
    // 0x6a4f7c: ldur            x0, [fp, #-0x28]
    // 0x6a4f80: ldur            x3, [fp, #-0x20]
    // 0x6a4f84: LoadField: r1 = r0->field_9b
    //     0x6a4f84: ldur            w1, [x0, #0x9b]
    // 0x6a4f88: DecompressPointer r1
    //     0x6a4f88: add             x1, x1, HEAP, lsl #32
    // 0x6a4f8c: ldur            x2, [fp, #-8]
    // 0x6a4f90: r0 = add()
    //     0x6a4f90: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6a4f94: ldur            x2, [fp, #-0x28]
    // 0x6a4f98: LoadField: r3 = r2->field_a7
    //     0x6a4f98: ldur            w3, [x2, #0xa7]
    // 0x6a4f9c: DecompressPointer r3
    //     0x6a4f9c: add             x3, x3, HEAP, lsl #32
    // 0x6a4fa0: LoadField: r0 = r3->field_b
    //     0x6a4fa0: ldur            w0, [x3, #0xb]
    // 0x6a4fa4: r1 = LoadInt32Instr(r0)
    //     0x6a4fa4: sbfx            x1, x0, #1, #0x1f
    // 0x6a4fa8: mov             x0, x1
    // 0x6a4fac: ldur            x1, [fp, #-0x20]
    // 0x6a4fb0: cmp             x1, x0
    // 0x6a4fb4: b.hs            #0x6a5068
    // 0x6a4fb8: LoadField: r0 = r3->field_f
    //     0x6a4fb8: ldur            w0, [x3, #0xf]
    // 0x6a4fbc: DecompressPointer r0
    //     0x6a4fbc: add             x0, x0, HEAP, lsl #32
    // 0x6a4fc0: ldur            x1, [fp, #-0x20]
    // 0x6a4fc4: ArrayLoad: r3 = r0[r1]  ; Unknown_4
    //     0x6a4fc4: add             x16, x0, x1, lsl #2
    //     0x6a4fc8: ldur            w3, [x16, #0xf]
    // 0x6a4fcc: DecompressPointer r3
    //     0x6a4fcc: add             x3, x3, HEAP, lsl #32
    // 0x6a4fd0: stur            x3, [fp, #-8]
    // 0x6a4fd4: r1 = Function 'getGeneratorInfo':.
    //     0x6a4fd4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28430] AnonymousClosure: (0x6a5660), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getGeneratorInfo (0x80d384)
    //     0x6a4fd8: ldr             x1, [x1, #0x430]
    // 0x6a4fdc: r0 = AllocateClosure()
    //     0x6a4fdc: bl              #0x826750  ; AllocateClosureStub
    // 0x6a4fe0: ldur            x1, [fp, #-8]
    // 0x6a4fe4: mov             x2, x0
    // 0x6a4fe8: r0 = description()
    //     0x6a4fe8: bl              #0x6a506c  ; [package:pretentious/data/BoostHolder.dart] BoostHolder::description
    // 0x6a4fec: LeaveFrame
    //     0x6a4fec: mov             SP, fp
    //     0x6a4ff0: ldp             fp, lr, [SP], #0x10
    // 0x6a4ff4: ret
    //     0x6a4ff4: ret             
    // 0x6a4ff8: ldur            x2, [fp, #-0x28]
    // 0x6a4ffc: ldur            x1, [fp, #-0x20]
    // 0x6a5000: r4 = true
    //     0x6a5000: add             x4, NULL, #0x20  ; true
    // 0x6a5004: b               #0x6a5038
    // 0x6a5008: ldur            x2, [fp, #-0x28]
    // 0x6a500c: ldur            x0, [fp, #-0x18]
    // 0x6a5010: ldur            x1, [fp, #-0x20]
    // 0x6a5014: b               #0x6a5034
    // 0x6a5018: ldur            x2, [fp, #-0x28]
    // 0x6a501c: ldur            x0, [fp, #-0x18]
    // 0x6a5020: ldur            x1, [fp, #-0x20]
    // 0x6a5024: b               #0x6a5034
    // 0x6a5028: ldur            x2, [fp, #-0x28]
    // 0x6a502c: ldur            x0, [fp, #-0x18]
    // 0x6a5030: ldur            x1, [fp, #-0x20]
    // 0x6a5034: mov             x4, x0
    // 0x6a5038: add             x3, x1, #1
    // 0x6a503c: mov             x0, x2
    // 0x6a5040: b               #0x6a4dfc
    // 0x6a5044: r0 = Null
    //     0x6a5044: mov             x0, NULL
    // 0x6a5048: LeaveFrame
    //     0x6a5048: mov             SP, fp
    //     0x6a504c: ldp             fp, lr, [SP], #0x10
    // 0x6a5050: ret
    //     0x6a5050: ret             
    // 0x6a5054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5054: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5058: b               #0x6a4df4
    // 0x6a505c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a505c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5060: b               #0x6a4e10
    // 0x6a5064: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6a5064: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6a5068: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6a5068: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic, int) {
    // ** addr: 0x6a51d8, size: 0xd8
    // 0x6a51d8: EnterFrame
    //     0x6a51d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a51dc: mov             fp, SP
    // 0x6a51e0: ldr             x0, [fp, #0x18]
    // 0x6a51e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a51e4: ldur            w1, [x0, #0x17]
    // 0x6a51e8: DecompressPointer r1
    //     0x6a51e8: add             x1, x1, HEAP, lsl #32
    // 0x6a51ec: CheckStackOverflow
    //     0x6a51ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a51f0: cmp             SP, x16
    //     0x6a51f4: b.ls            #0x6a5298
    // 0x6a51f8: LoadField: r0 = r1->field_f
    //     0x6a51f8: ldur            w0, [x1, #0xf]
    // 0x6a51fc: DecompressPointer r0
    //     0x6a51fc: add             x0, x0, HEAP, lsl #32
    // 0x6a5200: LoadField: r1 = r0->field_47
    //     0x6a5200: ldur            w1, [x0, #0x47]
    // 0x6a5204: DecompressPointer r1
    //     0x6a5204: add             x1, x1, HEAP, lsl #32
    // 0x6a5208: ldr             x2, [fp, #0x10]
    // 0x6a520c: r0 = containsKey()
    //     0x6a520c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a5210: tbnz            w0, #4, #0x6a5288
    // 0x6a5214: r0 = LoadStaticField(0xf98)
    //     0x6a5214: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a5218: ldr             x0, [x0, #0x1f30]
    // 0x6a521c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a5220: cmp             w0, w16
    // 0x6a5224: b.ne            #0x6a5234
    // 0x6a5228: r2 = rng
    //     0x6a5228: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cca0] Field <::.rng>: static late (offset: 0xf98)
    //     0x6a522c: ldr             x2, [x2, #0xca0]
    // 0x6a5230: r0 = InitLateStaticField()
    //     0x6a5230: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x6a5234: mov             x1, x0
    // 0x6a5238: r0 = nextDouble()
    //     0x6a5238: bl              #0x60d7cc  ; [dart:math] _Random::nextDouble
    // 0x6a523c: mov             v1.16b, v0.16b
    // 0x6a5240: d0 = 2.000000
    //     0x6a5240: fmov            d0, #2.00000000
    // 0x6a5244: fmul            d2, d1, d0
    // 0x6a5248: d0 = 1.000000
    //     0x6a5248: fmov            d0, #1.00000000
    // 0x6a524c: fadd            d1, d2, d0
    // 0x6a5250: r0 = inline_Allocate_Double()
    //     0x6a5250: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6a5254: add             x0, x0, #0x10
    //     0x6a5258: cmp             x1, x0
    //     0x6a525c: b.ls            #0x6a52a0
    //     0x6a5260: str             x0, [THR, #0x60]  ; THR::top
    //     0x6a5264: sub             x0, x0, #0xf
    //     0x6a5268: movz            x1, #0xe19c
    //     0x6a526c: movk            x1, #0x3, lsl #16
    //     0x6a5270: stur            x1, [x0, #-1]
    // 0x6a5274: dmb             ishst
    // 0x6a5278: StoreField: r0->field_7 = d1
    //     0x6a5278: stur            d1, [x0, #7]
    // 0x6a527c: LeaveFrame
    //     0x6a527c: mov             SP, fp
    //     0x6a5280: ldp             fp, lr, [SP], #0x10
    // 0x6a5284: ret
    //     0x6a5284: ret             
    // 0x6a5288: r0 = 0.000000
    //     0x6a5288: ldr             x0, [PP, #0x6958]  ; [pp+0x6958] 0
    // 0x6a528c: LeaveFrame
    //     0x6a528c: mov             SP, fp
    //     0x6a5290: ldp             fp, lr, [SP], #0x10
    // 0x6a5294: ret
    //     0x6a5294: ret             
    // 0x6a5298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5298: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a529c: b               #0x6a51f8
    // 0x6a52a0: SaveReg d1
    //     0x6a52a0: str             q1, [SP, #-0x10]!
    // 0x6a52a4: r0 = AllocateDouble()
    //     0x6a52a4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x6a52a8: RestoreReg d1
    //     0x6a52a8: ldr             q1, [SP], #0x10
    // 0x6a52ac: b               #0x6a5278
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a52b0, size: 0x4c
    // 0x6a52b0: EnterFrame
    //     0x6a52b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a52b4: mov             fp, SP
    // 0x6a52b8: ldr             x0, [fp, #0x10]
    // 0x6a52bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a52bc: ldur            w1, [x0, #0x17]
    // 0x6a52c0: DecompressPointer r1
    //     0x6a52c0: add             x1, x1, HEAP, lsl #32
    // 0x6a52c4: CheckStackOverflow
    //     0x6a52c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a52c8: cmp             SP, x16
    //     0x6a52cc: b.ls            #0x6a52f4
    // 0x6a52d0: LoadField: r0 = r1->field_f
    //     0x6a52d0: ldur            w0, [x1, #0xf]
    // 0x6a52d4: DecompressPointer r0
    //     0x6a52d4: add             x0, x0, HEAP, lsl #32
    // 0x6a52d8: LoadField: r1 = r0->field_43
    //     0x6a52d8: ldur            w1, [x0, #0x43]
    // 0x6a52dc: DecompressPointer r1
    //     0x6a52dc: add             x1, x1, HEAP, lsl #32
    // 0x6a52e0: r2 = 208
    //     0x6a52e0: movz            x2, #0xd0
    // 0x6a52e4: r0 = containsKey()
    //     0x6a52e4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a52e8: LeaveFrame
    //     0x6a52e8: mov             SP, fp
    //     0x6a52ec: ldp             fp, lr, [SP], #0x10
    // 0x6a52f0: ret
    //     0x6a52f0: ret             
    // 0x6a52f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a52f4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a52f8: b               #0x6a52d0
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a52fc, size: 0xa8
    // 0x6a52fc: EnterFrame
    //     0x6a52fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5300: mov             fp, SP
    // 0x6a5304: AllocStack(0x8)
    //     0x6a5304: sub             SP, SP, #8
    // 0x6a5308: SetupParameters([dynamic _ /* r0 */])
    //     0x6a5308: ldr             x0, [fp, #0x10]
    //     0x6a530c: ldur            w1, [x0, #0x17]
    //     0x6a5310: add             x1, x1, HEAP, lsl #32
    // 0x6a5314: CheckStackOverflow
    //     0x6a5314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a5318: cmp             SP, x16
    //     0x6a531c: b.ls            #0x6a539c
    // 0x6a5320: LoadField: r0 = r1->field_f
    //     0x6a5320: ldur            w0, [x1, #0xf]
    // 0x6a5324: DecompressPointer r0
    //     0x6a5324: add             x0, x0, HEAP, lsl #32
    // 0x6a5328: LoadField: r3 = r0->field_37
    //     0x6a5328: ldur            w3, [x0, #0x37]
    // 0x6a532c: DecompressPointer r3
    //     0x6a532c: add             x3, x3, HEAP, lsl #32
    // 0x6a5330: mov             x1, x3
    // 0x6a5334: stur            x3, [fp, #-8]
    // 0x6a5338: r2 = Instance_Chapter15Stat
    //     0x6a5338: add             x2, PP, #0x11, lsl #12  ; [pp+0x11068] Obj!Chapter15Stat@85f6e1
    //     0x6a533c: ldr             x2, [x2, #0x68]
    // 0x6a5340: r0 = _getValueOrData()
    //     0x6a5340: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6a5344: mov             x1, x0
    // 0x6a5348: ldur            x0, [fp, #-8]
    // 0x6a534c: LoadField: r2 = r0->field_f
    //     0x6a534c: ldur            w2, [x0, #0xf]
    // 0x6a5350: DecompressPointer r2
    //     0x6a5350: add             x2, x2, HEAP, lsl #32
    // 0x6a5354: cmp             w2, w1
    // 0x6a5358: b.ne            #0x6a5360
    // 0x6a535c: r1 = Null
    //     0x6a535c: mov             x1, NULL
    // 0x6a5360: cmp             w1, NULL
    // 0x6a5364: b.ne            #0x6a5370
    // 0x6a5368: r1 = Null
    //     0x6a5368: mov             x1, NULL
    // 0x6a536c: b               #0x6a537c
    // 0x6a5370: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6a5370: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6a5374: r0 = toStringConsistentDecimalPlaces()
    //     0x6a5374: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x6a5378: mov             x1, x0
    // 0x6a537c: cmp             w1, NULL
    // 0x6a5380: b.ne            #0x6a538c
    // 0x6a5384: r0 = "0"
    //     0x6a5384: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x6a5388: b               #0x6a5390
    // 0x6a538c: mov             x0, x1
    // 0x6a5390: LeaveFrame
    //     0x6a5390: mov             SP, fp
    //     0x6a5394: ldp             fp, lr, [SP], #0x10
    // 0x6a5398: ret
    //     0x6a5398: ret             
    // 0x6a539c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a539c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a53a0: b               #0x6a5320
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a53a4, size: 0x4c
    // 0x6a53a4: EnterFrame
    //     0x6a53a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a53a8: mov             fp, SP
    // 0x6a53ac: ldr             x0, [fp, #0x10]
    // 0x6a53b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a53b0: ldur            w1, [x0, #0x17]
    // 0x6a53b4: DecompressPointer r1
    //     0x6a53b4: add             x1, x1, HEAP, lsl #32
    // 0x6a53b8: CheckStackOverflow
    //     0x6a53b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a53bc: cmp             SP, x16
    //     0x6a53c0: b.ls            #0x6a53e8
    // 0x6a53c4: LoadField: r0 = r1->field_f
    //     0x6a53c4: ldur            w0, [x1, #0xf]
    // 0x6a53c8: DecompressPointer r0
    //     0x6a53c8: add             x0, x0, HEAP, lsl #32
    // 0x6a53cc: LoadField: r1 = r0->field_1b
    //     0x6a53cc: ldur            w1, [x0, #0x1b]
    // 0x6a53d0: DecompressPointer r1
    //     0x6a53d0: add             x1, x1, HEAP, lsl #32
    // 0x6a53d4: r2 = 28
    //     0x6a53d4: movz            x2, #0x1c
    // 0x6a53d8: r0 = contains()
    //     0x6a53d8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a53dc: LeaveFrame
    //     0x6a53dc: mov             SP, fp
    //     0x6a53e0: ldp             fp, lr, [SP], #0x10
    // 0x6a53e4: ret
    //     0x6a53e4: ret             
    // 0x6a53e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a53e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a53ec: b               #0x6a53c4
  }
  [closure] String? <anonymous closure>(dynamic) {
    // ** addr: 0x6a53f0, size: 0xac
    // 0x6a53f0: EnterFrame
    //     0x6a53f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a53f4: mov             fp, SP
    // 0x6a53f8: AllocStack(0x10)
    //     0x6a53f8: sub             SP, SP, #0x10
    // 0x6a53fc: SetupParameters([dynamic _ /* r0 */])
    //     0x6a53fc: ldr             x0, [fp, #0x10]
    //     0x6a5400: ldur            w3, [x0, #0x17]
    //     0x6a5404: add             x3, x3, HEAP, lsl #32
    //     0x6a5408: stur            x3, [fp, #-8]
    // 0x6a540c: CheckStackOverflow
    //     0x6a540c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a5410: cmp             SP, x16
    //     0x6a5414: b.ls            #0x6a5488
    // 0x6a5418: r0 = LoadStaticField(0xf7c)
    //     0x6a5418: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a541c: ldr             x0, [x0, #0x1ef8]
    // 0x6a5420: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a5424: cmp             w0, w16
    // 0x6a5428: b.eq            #0x6a5490
    // 0x6a542c: LoadField: r1 = r0->field_13
    //     0x6a542c: ldur            w1, [x0, #0x13]
    // 0x6a5430: DecompressPointer r1
    //     0x6a5430: add             x1, x1, HEAP, lsl #32
    // 0x6a5434: r2 = 66
    //     0x6a5434: movz            x2, #0x42
    // 0x6a5438: r0 = containsKey()
    //     0x6a5438: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6a543c: tbnz            w0, #4, #0x6a5478
    // 0x6a5440: ldur            x0, [fp, #-8]
    // 0x6a5444: LoadField: r1 = r0->field_f
    //     0x6a5444: ldur            w1, [x0, #0xf]
    // 0x6a5448: DecompressPointer r1
    //     0x6a5448: add             x1, x1, HEAP, lsl #32
    // 0x6a544c: r16 = false
    //     0x6a544c: add             x16, NULL, #0x30  ; false
    // 0x6a5450: str             x16, [SP]
    // 0x6a5454: r2 = 33
    //     0x6a5454: movz            x2, #0x21
    // 0x6a5458: r4 = const [0, 0x3, 0x1, 0x2, notifyFragments, 0x2, null]
    //     0x6a5458: add             x4, PP, #0x26, lsl #12  ; [pp+0x265c0] List(7) [0, 0x3, 0x1, 0x2, "notifyFragments", 0x2, Null]
    //     0x6a545c: ldr             x4, [x4, #0x5c0]
    // 0x6a5460: r0 = notifyDialoguePoint()
    //     0x6a5460: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6a5464: r0 = "Intermission"
    //     0x6a5464: add             x0, PP, #0x26, lsl #12  ; [pp+0x265c8] "Intermission"
    //     0x6a5468: ldr             x0, [x0, #0x5c8]
    // 0x6a546c: LeaveFrame
    //     0x6a546c: mov             SP, fp
    //     0x6a5470: ldp             fp, lr, [SP], #0x10
    // 0x6a5474: ret
    //     0x6a5474: ret             
    // 0x6a5478: r0 = Null
    //     0x6a5478: mov             x0, NULL
    // 0x6a547c: LeaveFrame
    //     0x6a547c: mov             SP, fp
    //     0x6a5480: ldp             fp, lr, [SP], #0x10
    // 0x6a5484: ret
    //     0x6a5484: ret             
    // 0x6a5488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5488: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a548c: b               #0x6a5418
    // 0x6a5490: r9 = coreData
    //     0x6a5490: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x6a5494: ldr             x9, [x9, #0x530]
    // 0x6a5498: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6a5498: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6a549c, size: 0x78
    // 0x6a549c: EnterFrame
    //     0x6a549c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a54a0: mov             fp, SP
    // 0x6a54a4: AllocStack(0x18)
    //     0x6a54a4: sub             SP, SP, #0x18
    // 0x6a54a8: SetupParameters(Chapter15GameState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x6a54a8: stur            NULL, [fp, #-8]
    //     0x6a54ac: movz            x0, #0
    //     0x6a54b0: add             x1, fp, w0, sxtw #2
    //     0x6a54b4: ldr             x1, [x1, #0x18]
    //     0x6a54b8: add             x2, fp, w0, sxtw #2
    //     0x6a54bc: ldr             x2, [x2, #0x10]
    //     0x6a54c0: stur            x2, [fp, #-0x18]
    //     0x6a54c4: ldur            w3, [x1, #0x17]
    //     0x6a54c8: add             x3, x3, HEAP, lsl #32
    //     0x6a54cc: stur            x3, [fp, #-0x10]
    // 0x6a54d0: CheckStackOverflow
    //     0x6a54d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a54d4: cmp             SP, x16
    //     0x6a54d8: b.ls            #0x6a550c
    // 0x6a54dc: InitAsync() -> Future<void?>
    //     0x6a54dc: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6a54e0: bl              #0x34b9a0  ; InitAsyncStub
    // 0x6a54e4: ldur            x2, [fp, #-0x10]
    // 0x6a54e8: r1 = Function '<anonymous closure>':.
    //     0x6a54e8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28600] AnonymousClosure: (0x6a5514), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::build (0x6a2d94)
    //     0x6a54ec: ldr             x1, [x1, #0x600]
    // 0x6a54f0: r0 = AllocateClosure()
    //     0x6a54f0: bl              #0x826750  ; AllocateClosureStub
    // 0x6a54f4: ldur            x1, [fp, #-0x18]
    // 0x6a54f8: mov             x3, x0
    // 0x6a54fc: r2 = 33
    //     0x6a54fc: movz            x2, #0x21
    // 0x6a5500: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6a5500: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6a5504: r0 = displaySlackPage()
    //     0x6a5504: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x6a5508: r0 = ReturnAsync()
    //     0x6a5508: b               #0x353380  ; ReturnAsyncStub
    // 0x6a550c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a550c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5510: b               #0x6a54dc
  }
  [closure] void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6a5514, size: 0x78
    // 0x6a5514: EnterFrame
    //     0x6a5514: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5518: mov             fp, SP
    // 0x6a551c: AllocStack(0x8)
    //     0x6a551c: sub             SP, SP, #8
    // 0x6a5520: SetupParameters([dynamic _ /* r0 */])
    //     0x6a5520: ldr             x0, [fp, #0x20]
    //     0x6a5524: ldur            w3, [x0, #0x17]
    //     0x6a5528: add             x3, x3, HEAP, lsl #32
    //     0x6a552c: stur            x3, [fp, #-8]
    // 0x6a5530: CheckStackOverflow
    //     0x6a5530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a5534: cmp             SP, x16
    //     0x6a5538: b.ls            #0x6a5584
    // 0x6a553c: LoadField: r1 = r3->field_f
    //     0x6a553c: ldur            w1, [x3, #0xf]
    // 0x6a5540: DecompressPointer r1
    //     0x6a5540: add             x1, x1, HEAP, lsl #32
    // 0x6a5544: r2 = 33
    //     0x6a5544: movz            x2, #0x21
    // 0x6a5548: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a5548: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a554c: r0 = notifyDialoguePoint()
    //     0x6a554c: bl              #0x6990fc  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyDialoguePoint
    // 0x6a5550: ldr             x0, [fp, #0x10]
    // 0x6a5554: r1 = LoadInt32Instr(r0)
    //     0x6a5554: sbfx            x1, x0, #1, #0x1f
    //     0x6a5558: tbz             w0, #0, #0x6a5560
    //     0x6a555c: ldur            x1, [x0, #7]
    // 0x6a5560: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x6a5560: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x6a5564: ldur            x0, [fp, #-8]
    // 0x6a5568: LoadField: r1 = r0->field_f
    //     0x6a5568: ldur            w1, [x0, #0xf]
    // 0x6a556c: DecompressPointer r1
    //     0x6a556c: add             x1, x1, HEAP, lsl #32
    // 0x6a5570: r0 = saveDeferred()
    //     0x6a5570: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x6a5574: r0 = Null
    //     0x6a5574: mov             x0, NULL
    // 0x6a5578: LeaveFrame
    //     0x6a5578: mov             SP, fp
    //     0x6a557c: ldp             fp, lr, [SP], #0x10
    // 0x6a5580: ret
    //     0x6a5580: ret             
    // 0x6a5584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5584: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5588: b               #0x6a553c
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x6a558c, size: 0x4c
    // 0x6a558c: EnterFrame
    //     0x6a558c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5590: mov             fp, SP
    // 0x6a5594: ldr             x0, [fp, #0x10]
    // 0x6a5598: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a5598: ldur            w1, [x0, #0x17]
    // 0x6a559c: DecompressPointer r1
    //     0x6a559c: add             x1, x1, HEAP, lsl #32
    // 0x6a55a0: CheckStackOverflow
    //     0x6a55a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a55a4: cmp             SP, x16
    //     0x6a55a8: b.ls            #0x6a55d0
    // 0x6a55ac: LoadField: r0 = r1->field_f
    //     0x6a55ac: ldur            w0, [x1, #0xf]
    // 0x6a55b0: DecompressPointer r0
    //     0x6a55b0: add             x0, x0, HEAP, lsl #32
    // 0x6a55b4: LoadField: r1 = r0->field_1b
    //     0x6a55b4: ldur            w1, [x0, #0x1b]
    // 0x6a55b8: DecompressPointer r1
    //     0x6a55b8: add             x1, x1, HEAP, lsl #32
    // 0x6a55bc: r2 = 4
    //     0x6a55bc: movz            x2, #0x4
    // 0x6a55c0: r0 = contains()
    //     0x6a55c0: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6a55c4: LeaveFrame
    //     0x6a55c4: mov             SP, fp
    //     0x6a55c8: ldp             fp, lr, [SP], #0x10
    // 0x6a55cc: ret
    //     0x6a55cc: ret             
    // 0x6a55d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a55d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a55d4: b               #0x6a55ac
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a55d8, size: 0xc
    // 0x6a55d8: r0 = "Each pull request increases symbol gain by 1%."
    //     0x6a55d8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28608] "Each pull request increases symbol gain by 1%."
    //     0x6a55dc: ldr             x0, [x0, #0x608]
    // 0x6a55e0: ret
    //     0x6a55e0: ret             
  }
  [closure] void applyPullPrestige(dynamic) {
    // ** addr: 0x6a55e4, size: 0x38
    // 0x6a55e4: EnterFrame
    //     0x6a55e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a55e8: mov             fp, SP
    // 0x6a55ec: ldr             x0, [fp, #0x10]
    // 0x6a55f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a55f0: ldur            w1, [x0, #0x17]
    // 0x6a55f4: DecompressPointer r1
    //     0x6a55f4: add             x1, x1, HEAP, lsl #32
    // 0x6a55f8: CheckStackOverflow
    //     0x6a55f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a55fc: cmp             SP, x16
    //     0x6a5600: b.ls            #0x6a5614
    // 0x6a5604: r0 = applyPullPrestige()
    //     0x6a5604: bl              #0x6a41d8  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::applyPullPrestige
    // 0x6a5608: LeaveFrame
    //     0x6a5608: mov             SP, fp
    //     0x6a560c: ldp             fp, lr, [SP], #0x10
    // 0x6a5610: ret
    //     0x6a5610: ret             
    // 0x6a5614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5614: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5618: b               #0x6a5604
  }
  [closure] CustomNum getPushPrestigePoints(dynamic) {
    // ** addr: 0x6a561c, size: 0x38
    // 0x6a561c: EnterFrame
    //     0x6a561c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5620: mov             fp, SP
    // 0x6a5624: ldr             x0, [fp, #0x10]
    // 0x6a5628: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a5628: ldur            w1, [x0, #0x17]
    // 0x6a562c: DecompressPointer r1
    //     0x6a562c: add             x1, x1, HEAP, lsl #32
    // 0x6a5630: CheckStackOverflow
    //     0x6a5630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a5634: cmp             SP, x16
    //     0x6a5638: b.ls            #0x6a564c
    // 0x6a563c: r0 = getPushPrestigePoints()
    //     0x6a563c: bl              #0x6a49d4  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getPushPrestigePoints
    // 0x6a5640: LeaveFrame
    //     0x6a5640: mov             SP, fp
    //     0x6a5644: ldp             fp, lr, [SP], #0x10
    // 0x6a5648: ret
    //     0x6a5648: ret             
    // 0x6a564c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a564c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5650: b               #0x6a563c
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x6a5654, size: 0xc
    // 0x6a5654: r0 = "Merge"
    //     0x6a5654: add             x0, PP, #0x28, lsl #12  ; [pp+0x28610] "Merge"
    //     0x6a5658: ldr             x0, [x0, #0x610]
    // 0x6a565c: ret
    //     0x6a565c: ret             
  }
  [closure] GeneratorInfo<Chapter15Stat> getGeneratorInfo(dynamic, int) {
    // ** addr: 0x6a5660, size: 0x3c
    // 0x6a5660: EnterFrame
    //     0x6a5660: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5664: mov             fp, SP
    // 0x6a5668: ldr             x0, [fp, #0x18]
    // 0x6a566c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6a566c: ldur            w1, [x0, #0x17]
    // 0x6a5670: DecompressPointer r1
    //     0x6a5670: add             x1, x1, HEAP, lsl #32
    // 0x6a5674: CheckStackOverflow
    //     0x6a5674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a5678: cmp             SP, x16
    //     0x6a567c: b.ls            #0x6a5694
    // 0x6a5680: ldr             x2, [fp, #0x10]
    // 0x6a5684: r0 = getGeneratorInfo()
    //     0x6a5684: bl              #0x80d384  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getGeneratorInfo
    // 0x6a5688: LeaveFrame
    //     0x6a5688: mov             SP, fp
    //     0x6a568c: ldp             fp, lr, [SP], #0x10
    // 0x6a5690: ret
    //     0x6a5690: ret             
    // 0x6a5694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5694: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5698: b               #0x6a5680
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6a569c, size: 0xbc
    // 0x6a569c: EnterFrame
    //     0x6a569c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a56a0: mov             fp, SP
    // 0x6a56a4: AllocStack(0x8)
    //     0x6a56a4: sub             SP, SP, #8
    // 0x6a56a8: SetupParameters([dynamic _ /* r0 */])
    //     0x6a56a8: ldr             x0, [fp, #0x10]
    //     0x6a56ac: ldur            w2, [x0, #0x17]
    //     0x6a56b0: add             x2, x2, HEAP, lsl #32
    //     0x6a56b4: stur            x2, [fp, #-8]
    // 0x6a56b8: CheckStackOverflow
    //     0x6a56b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a56bc: cmp             SP, x16
    //     0x6a56c0: b.ls            #0x6a5750
    // 0x6a56c4: LoadField: r0 = r2->field_f
    //     0x6a56c4: ldur            w0, [x2, #0xf]
    // 0x6a56c8: DecompressPointer r0
    //     0x6a56c8: add             x0, x0, HEAP, lsl #32
    // 0x6a56cc: LoadField: r1 = r0->field_93
    //     0x6a56cc: ldur            w1, [x0, #0x93]
    // 0x6a56d0: DecompressPointer r1
    //     0x6a56d0: add             x1, x1, HEAP, lsl #32
    // 0x6a56d4: LoadField: r0 = r1->field_7
    //     0x6a56d4: ldur            x0, [x1, #7]
    // 0x6a56d8: cmp             x0, #0
    // 0x6a56dc: b.le            #0x6a56f0
    // 0x6a56e0: r0 = Null
    //     0x6a56e0: mov             x0, NULL
    // 0x6a56e4: LeaveFrame
    //     0x6a56e4: mov             SP, fp
    //     0x6a56e8: ldp             fp, lr, [SP], #0x10
    // 0x6a56ec: ret
    //     0x6a56ec: ret             
    // 0x6a56f0: r0 = 120000
    //     0x6a56f0: movz            x0, #0xd4c0
    //     0x6a56f4: movk            x0, #0x1, lsl #16
    // 0x6a56f8: StoreField: r1->field_7 = r0
    //     0x6a56f8: stur            x0, [x1, #7]
    // 0x6a56fc: r1 = false
    //     0x6a56fc: add             x1, NULL, #0x30  ; false
    // 0x6a5700: r0 = paused=()
    //     0x6a5700: bl              #0x6a5758  ; [package:pretentious/fragment/lib/Widgets/DebugBar.dart] ::paused=
    // 0x6a5704: ldur            x0, [fp, #-8]
    // 0x6a5708: LoadField: r1 = r0->field_f
    //     0x6a5708: ldur            w1, [x0, #0xf]
    // 0x6a570c: DecompressPointer r1
    //     0x6a570c: add             x1, x1, HEAP, lsl #32
    // 0x6a5710: d0 = 1.000000
    //     0x6a5710: fmov            d0, #1.00000000
    // 0x6a5714: r0 = generateSymbols()
    //     0x6a5714: bl              #0x5473f8  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::generateSymbols
    // 0x6a5718: ldur            x0, [fp, #-8]
    // 0x6a571c: LoadField: r1 = r0->field_f
    //     0x6a571c: ldur            w1, [x0, #0xf]
    // 0x6a5720: DecompressPointer r1
    //     0x6a5720: add             x1, x1, HEAP, lsl #32
    // 0x6a5724: r2 = Instance_Chapter15Stat
    //     0x6a5724: add             x2, PP, #0x11, lsl #12  ; [pp+0x11090] Obj!Chapter15Stat@85f741
    //     0x6a5728: ldr             x2, [x2, #0x90]
    // 0x6a572c: r0 = notifyStatGained()
    //     0x6a572c: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x6a5730: ldur            x0, [fp, #-8]
    // 0x6a5734: LoadField: r1 = r0->field_f
    //     0x6a5734: ldur            w1, [x0, #0xf]
    // 0x6a5738: DecompressPointer r1
    //     0x6a5738: add             x1, x1, HEAP, lsl #32
    // 0x6a573c: r0 = saveDeferred()
    //     0x6a573c: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x6a5740: r0 = Null
    //     0x6a5740: mov             x0, NULL
    // 0x6a5744: LeaveFrame
    //     0x6a5744: mov             SP, fp
    //     0x6a5748: ldp             fp, lr, [SP], #0x10
    // 0x6a574c: ret
    //     0x6a574c: ret             
    // 0x6a5750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5750: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a5754: b               #0x6a56c4
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d384, size: 0x7c
    // 0x80d384: EnterFrame
    //     0x80d384: stp             fp, lr, [SP, #-0x10]!
    //     0x80d388: mov             fp, SP
    // 0x80d38c: AllocStack(0x8)
    //     0x80d38c: sub             SP, SP, #8
    // 0x80d390: CheckStackOverflow
    //     0x80d390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d394: cmp             SP, x16
    //     0x80d398: b.ls            #0x80d3e8
    // 0x80d39c: LoadField: r0 = r1->field_8b
    //     0x80d39c: ldur            w0, [x1, #0x8b]
    // 0x80d3a0: DecompressPointer r0
    //     0x80d3a0: add             x0, x0, HEAP, lsl #32
    // 0x80d3a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d3a8: cmp             w0, w16
    // 0x80d3ac: b.eq            #0x80d3f0
    // 0x80d3b0: mov             x1, x0
    // 0x80d3b4: stur            x0, [fp, #-8]
    // 0x80d3b8: r0 = _getValueOrData()
    //     0x80d3b8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d3bc: ldur            x1, [fp, #-8]
    // 0x80d3c0: LoadField: r2 = r1->field_f
    //     0x80d3c0: ldur            w2, [x1, #0xf]
    // 0x80d3c4: DecompressPointer r2
    //     0x80d3c4: add             x2, x2, HEAP, lsl #32
    // 0x80d3c8: cmp             w2, w0
    // 0x80d3cc: b.ne            #0x80d3d4
    // 0x80d3d0: r0 = Null
    //     0x80d3d0: mov             x0, NULL
    // 0x80d3d4: cmp             w0, NULL
    // 0x80d3d8: b.eq            #0x80d3fc
    // 0x80d3dc: LeaveFrame
    //     0x80d3dc: mov             SP, fp
    //     0x80d3e0: ldp             fp, lr, [SP], #0x10
    // 0x80d3e4: ret
    //     0x80d3e4: ret             
    // 0x80d3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d3e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d3ec: b               #0x80d39c
    // 0x80d3f0: r9 = generators
    //     0x80d3f0: add             x9, PP, #0x11, lsl #12  ; [pp+0x11088] Field <Chapter15GameState.generators>: late (offset: 0x8c)
    //     0x80d3f4: ldr             x9, [x9, #0x88]
    // 0x80d3f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d3f8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d3fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d3fc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d144, size: 0xc
    // 0x81d144: r0 = "15"
    //     0x81d144: add             x0, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x81d148: ldr             x0, [x0, #0x348]
    // 0x81d14c: ret
    //     0x81d14c: ret             
  }
  dynamic getCostToBuyOneMoreGenerator(dynamic) {
    // ** addr: 0x81f6f0, size: 0x24
    // 0x81f6f0: EnterFrame
    //     0x81f6f0: stp             fp, lr, [SP, #-0x10]!
    //     0x81f6f4: mov             fp, SP
    // 0x81f6f8: ldr             x2, [fp, #0x10]
    // 0x81f6fc: r1 = Function 'getCostToBuyOneMoreGenerator':.
    //     0x81f6fc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1caf0] AnonymousClosure: (0x3db3b8), in [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::getCostToBuyOneMoreGenerator (0x3db270)
    //     0x81f700: ldr             x1, [x1, #0xaf0]
    // 0x81f704: r0 = AllocateClosure()
    //     0x81f704: bl              #0x826750  ; AllocateClosureStub
    // 0x81f708: LeaveFrame
    //     0x81f708: mov             SP, fp
    //     0x81f70c: ldp             fp, lr, [SP], #0x10
    // 0x81f710: ret
    //     0x81f710: ret             
  }
}

// class id: 286, size: 0x10, field offset: 0x8
class IntWrapper extends Object {
}

// class id: 2847, size: 0x14, field offset: 0xc
//   const constructor, 
class TimedBlocker extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72c570, size: 0x4c
    // 0x72c570: EnterFrame
    //     0x72c570: stp             fp, lr, [SP, #-0x10]!
    //     0x72c574: mov             fp, SP
    // 0x72c578: AllocStack(0x8)
    //     0x72c578: sub             SP, SP, #8
    // 0x72c57c: CheckStackOverflow
    //     0x72c57c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72c580: cmp             SP, x16
    //     0x72c584: b.ls            #0x72c5b4
    // 0x72c588: r1 = <TimedBlocker>
    //     0x72c588: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2a348] TypeArguments: <TimedBlocker>
    //     0x72c58c: ldr             x1, [x1, #0x348]
    // 0x72c590: r0 = _TimedBlockerState()
    //     0x72c590: bl              #0x72c5bc  ; Allocate_TimedBlockerStateStub -> _TimedBlockerState (size=0x1c)
    // 0x72c594: mov             x1, x0
    // 0x72c598: stur            x0, [fp, #-8]
    // 0x72c59c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72c59c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72c5a0: r0 = SyncState2()
    //     0x72c5a0: bl              #0x72c088  ; [package:state_groups/src/sync_state.dart] SyncState2::SyncState2
    // 0x72c5a4: ldur            x0, [fp, #-8]
    // 0x72c5a8: LeaveFrame
    //     0x72c5a8: mov             SP, fp
    //     0x72c5ac: ldp             fp, lr, [SP], #0x10
    // 0x72c5b0: ret
    //     0x72c5b0: ret             
    // 0x72c5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72c5b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72c5b8: b               #0x72c588
  }
}

// class id: 3547, size: 0x1c, field offset: 0x1c
class _TimedBlockerState extends SyncState2<dynamic> {

  _ initState(/* No info */) {
    // ** addr: 0x575bbc, size: 0x50
    // 0x575bbc: EnterFrame
    //     0x575bbc: stp             fp, lr, [SP, #-0x10]!
    //     0x575bc0: mov             fp, SP
    // 0x575bc4: AllocStack(0x8)
    //     0x575bc4: sub             SP, SP, #8
    // 0x575bc8: SetupParameters(_TimedBlockerState this /* r1 => r0, fp-0x8 */)
    //     0x575bc8: mov             x0, x1
    //     0x575bcc: stur            x1, [fp, #-8]
    // 0x575bd0: CheckStackOverflow
    //     0x575bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x575bd4: cmp             SP, x16
    //     0x575bd8: b.ls            #0x575c04
    // 0x575bdc: mov             x1, x0
    // 0x575be0: r0 = initState()
    //     0x575be0: bl              #0x575c2c  ; [package:state_groups/src/sync_state.dart] SyncState2::initState
    // 0x575be4: ldur            x1, [fp, #-8]
    // 0x575be8: r2 = "tick"
    //     0x575be8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc68] "tick"
    //     0x575bec: ldr             x2, [x2, #0xc68]
    // 0x575bf0: r0 = subscribeToBroadcasts()
    //     0x575bf0: bl              #0x5730ac  ; [package:state_groups/src/sync_state.dart] SyncState2::subscribeToBroadcasts
    // 0x575bf4: r0 = Null
    //     0x575bf4: mov             x0, NULL
    // 0x575bf8: LeaveFrame
    //     0x575bf8: mov             SP, fp
    //     0x575bfc: ldp             fp, lr, [SP], #0x10
    // 0x575c00: ret
    //     0x575c00: ret             
    // 0x575c04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x575c04: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x575c08: b               #0x575bdc
  }
  _ build(/* No info */) {
    // ** addr: 0x5a031c, size: 0x294
    // 0x5a031c: EnterFrame
    //     0x5a031c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a0320: mov             fp, SP
    // 0x5a0324: AllocStack(0x38)
    //     0x5a0324: sub             SP, SP, #0x38
    // 0x5a0328: SetupParameters(_TimedBlockerState this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x20 */)
    //     0x5a0328: mov             x0, x1
    //     0x5a032c: mov             x1, x2
    //     0x5a0330: stur            x2, [fp, #-0x20]
    // 0x5a0334: CheckStackOverflow
    //     0x5a0334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a0338: cmp             SP, x16
    //     0x5a033c: b.ls            #0x5a05a4
    // 0x5a0340: LoadField: r2 = r0->field_b
    //     0x5a0340: ldur            w2, [x0, #0xb]
    // 0x5a0344: DecompressPointer r2
    //     0x5a0344: add             x2, x2, HEAP, lsl #32
    // 0x5a0348: cmp             w2, NULL
    // 0x5a034c: b.eq            #0x5a05ac
    // 0x5a0350: LoadField: r0 = r2->field_b
    //     0x5a0350: ldur            w0, [x2, #0xb]
    // 0x5a0354: DecompressPointer r0
    //     0x5a0354: add             x0, x0, HEAP, lsl #32
    // 0x5a0358: LoadField: r3 = r0->field_7
    //     0x5a0358: ldur            x3, [x0, #7]
    // 0x5a035c: stur            x3, [fp, #-0x18]
    // 0x5a0360: cmp             x3, #0
    // 0x5a0364: r16 = true
    //     0x5a0364: add             x16, NULL, #0x20  ; true
    // 0x5a0368: r17 = false
    //     0x5a0368: add             x17, NULL, #0x30  ; false
    // 0x5a036c: csel            x0, x16, x17, gt
    // 0x5a0370: stur            x0, [fp, #-0x10]
    // 0x5a0374: tbnz            w0, #4, #0x5a0384
    // 0x5a0378: d0 = 0.300000
    //     0x5a0378: add             x17, PP, #0xe, lsl #12  ; [pp+0xe280] IMM: double(0.3) from 0x3fd3333333333333
    //     0x5a037c: ldr             d0, [x17, #0x280]
    // 0x5a0380: b               #0x5a0388
    // 0x5a0384: d0 = 1.000000
    //     0x5a0384: fmov            d0, #1.00000000
    // 0x5a0388: stur            d0, [fp, #-0x38]
    // 0x5a038c: LoadField: r4 = r2->field_f
    //     0x5a038c: ldur            w4, [x2, #0xf]
    // 0x5a0390: DecompressPointer r4
    //     0x5a0390: add             x4, x4, HEAP, lsl #32
    // 0x5a0394: stur            x4, [fp, #-8]
    // 0x5a0398: r0 = AbsorbPointer()
    //     0x5a0398: bl              #0x5a0620  ; AllocateAbsorbPointerStub -> AbsorbPointer (size=0x18)
    // 0x5a039c: mov             x1, x0
    // 0x5a03a0: ldur            x0, [fp, #-0x10]
    // 0x5a03a4: stur            x1, [fp, #-0x28]
    // 0x5a03a8: StoreField: r1->field_f = r0
    //     0x5a03a8: stur            w0, [x1, #0xf]
    // 0x5a03ac: ldur            x2, [fp, #-8]
    // 0x5a03b0: StoreField: r1->field_b = r2
    //     0x5a03b0: stur            w2, [x1, #0xb]
    // 0x5a03b4: r0 = Opacity()
    //     0x5a03b4: bl              #0x5a0614  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x5a03b8: ldur            d0, [fp, #-0x38]
    // 0x5a03bc: stur            x0, [fp, #-8]
    // 0x5a03c0: StoreField: r0->field_f = d0
    //     0x5a03c0: stur            d0, [x0, #0xf]
    // 0x5a03c4: r1 = false
    //     0x5a03c4: add             x1, NULL, #0x30  ; false
    // 0x5a03c8: ArrayStore: r0[0] = r1  ; List_4
    //     0x5a03c8: stur            w1, [x0, #0x17]
    // 0x5a03cc: ldur            x1, [fp, #-0x28]
    // 0x5a03d0: StoreField: r0->field_b = r1
    //     0x5a03d0: stur            w1, [x0, #0xb]
    // 0x5a03d4: r1 = Null
    //     0x5a03d4: mov             x1, NULL
    // 0x5a03d8: r2 = 2
    //     0x5a03d8: movz            x2, #0x2
    // 0x5a03dc: r0 = AllocateArray()
    //     0x5a03dc: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a03e0: mov             x2, x0
    // 0x5a03e4: ldur            x0, [fp, #-8]
    // 0x5a03e8: stur            x2, [fp, #-0x28]
    // 0x5a03ec: StoreField: r2->field_f = r0
    //     0x5a03ec: stur            w0, [x2, #0xf]
    // 0x5a03f0: r1 = <Widget>
    //     0x5a03f0: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x5a03f4: r0 = AllocateGrowableArray()
    //     0x5a03f4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5a03f8: mov             x1, x0
    // 0x5a03fc: ldur            x0, [fp, #-0x28]
    // 0x5a0400: stur            x1, [fp, #-8]
    // 0x5a0404: StoreField: r1->field_f = r0
    //     0x5a0404: stur            w0, [x1, #0xf]
    // 0x5a0408: r0 = 2
    //     0x5a0408: movz            x0, #0x2
    // 0x5a040c: StoreField: r1->field_b = r0
    //     0x5a040c: stur            w0, [x1, #0xb]
    // 0x5a0410: ldur            x0, [fp, #-0x10]
    // 0x5a0414: tbnz            w0, #4, #0x5a0564
    // 0x5a0418: ldur            x0, [fp, #-0x18]
    // 0x5a041c: r16 = 1000
    //     0x5a041c: movz            x16, #0x3e8
    // 0x5a0420: mul             x2, x0, x16
    // 0x5a0424: stur            x2, [fp, #-0x30]
    // 0x5a0428: r0 = Duration()
    //     0x5a0428: bl              #0x326d60  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x5a042c: mov             x1, x0
    // 0x5a0430: ldur            x0, [fp, #-0x30]
    // 0x5a0434: StoreField: r1->field_7 = r0
    //     0x5a0434: stur            x0, [x1, #7]
    // 0x5a0438: r0 = ToStringNoMilliseconds.toStringNoMilliseconds()
    //     0x5a0438: bl              #0x5a05bc  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::ToStringNoMilliseconds.toStringNoMilliseconds
    // 0x5a043c: ldur            x1, [fp, #-0x20]
    // 0x5a0440: stur            x0, [fp, #-0x10]
    // 0x5a0444: r0 = of()
    //     0x5a0444: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x5a0448: mov             x1, x0
    // 0x5a044c: r0 = ThemeDarkMode.darkModeEnabled()
    //     0x5a044c: bl              #0x4e8990  ; [package:custom_tools/BasicExtensions.dart] ::ThemeDarkMode.darkModeEnabled
    // 0x5a0450: tbnz            w0, #4, #0x5a0460
    // 0x5a0454: r2 = const [Instance of 'Shadow']
    //     0x5a0454: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c420] List<Shadow>(1)
    //     0x5a0458: ldr             x2, [x2, #0x420]
    // 0x5a045c: b               #0x5a0464
    // 0x5a0460: r2 = Null
    //     0x5a0460: mov             x2, NULL
    // 0x5a0464: ldur            x0, [fp, #-0x10]
    // 0x5a0468: ldur            x1, [fp, #-8]
    // 0x5a046c: stur            x2, [fp, #-0x20]
    // 0x5a0470: r0 = TextStyle()
    //     0x5a0470: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x5a0474: mov             x1, x0
    // 0x5a0478: r0 = true
    //     0x5a0478: add             x0, NULL, #0x20  ; true
    // 0x5a047c: stur            x1, [fp, #-0x28]
    // 0x5a0480: StoreField: r1->field_7 = r0
    //     0x5a0480: stur            w0, [x1, #7]
    // 0x5a0484: r2 = 32.000000
    //     0x5a0484: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2a0e0] 32
    //     0x5a0488: ldr             x2, [x2, #0xe0]
    // 0x5a048c: StoreField: r1->field_1f = r2
    //     0x5a048c: stur            w2, [x1, #0x1f]
    // 0x5a0490: r2 = Instance_FontWeight
    //     0x5a0490: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c428] Obj!FontWeight@834d21
    //     0x5a0494: ldr             x2, [x2, #0x428]
    // 0x5a0498: StoreField: r1->field_23 = r2
    //     0x5a0498: stur            w2, [x1, #0x23]
    // 0x5a049c: ldur            x2, [fp, #-0x20]
    // 0x5a04a0: StoreField: r1->field_5f = r2
    //     0x5a04a0: stur            w2, [x1, #0x5f]
    // 0x5a04a4: r2 = const [Instance of 'FontFeature']
    //     0x5a04a4: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c2c8] List<FontFeature>(1)
    //     0x5a04a8: ldr             x2, [x2, #0x2c8]
    // 0x5a04ac: StoreField: r1->field_63 = r2
    //     0x5a04ac: stur            w2, [x1, #0x63]
    // 0x5a04b0: r0 = Text()
    //     0x5a04b0: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x5a04b4: mov             x1, x0
    // 0x5a04b8: ldur            x0, [fp, #-0x10]
    // 0x5a04bc: stur            x1, [fp, #-0x20]
    // 0x5a04c0: StoreField: r1->field_b = r0
    //     0x5a04c0: stur            w0, [x1, #0xb]
    // 0x5a04c4: ldur            x0, [fp, #-0x28]
    // 0x5a04c8: StoreField: r1->field_13 = r0
    //     0x5a04c8: stur            w0, [x1, #0x13]
    // 0x5a04cc: r0 = IgnorePointer()
    //     0x5a04cc: bl              #0x4e8d8c  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x5a04d0: mov             x2, x0
    // 0x5a04d4: r0 = true
    //     0x5a04d4: add             x0, NULL, #0x20  ; true
    // 0x5a04d8: stur            x2, [fp, #-0x10]
    // 0x5a04dc: StoreField: r2->field_f = r0
    //     0x5a04dc: stur            w0, [x2, #0xf]
    // 0x5a04e0: ldur            x0, [fp, #-0x20]
    // 0x5a04e4: StoreField: r2->field_b = r0
    //     0x5a04e4: stur            w0, [x2, #0xb]
    // 0x5a04e8: ldur            x0, [fp, #-8]
    // 0x5a04ec: LoadField: r1 = r0->field_b
    //     0x5a04ec: ldur            w1, [x0, #0xb]
    // 0x5a04f0: LoadField: r3 = r0->field_f
    //     0x5a04f0: ldur            w3, [x0, #0xf]
    // 0x5a04f4: DecompressPointer r3
    //     0x5a04f4: add             x3, x3, HEAP, lsl #32
    // 0x5a04f8: LoadField: r4 = r3->field_b
    //     0x5a04f8: ldur            w4, [x3, #0xb]
    // 0x5a04fc: r3 = LoadInt32Instr(r1)
    //     0x5a04fc: sbfx            x3, x1, #1, #0x1f
    // 0x5a0500: stur            x3, [fp, #-0x18]
    // 0x5a0504: r1 = LoadInt32Instr(r4)
    //     0x5a0504: sbfx            x1, x4, #1, #0x1f
    // 0x5a0508: cmp             x3, x1
    // 0x5a050c: b.ne            #0x5a0518
    // 0x5a0510: mov             x1, x0
    // 0x5a0514: r0 = _growToNextCapacity()
    //     0x5a0514: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5a0518: ldur            x2, [fp, #-8]
    // 0x5a051c: ldur            x3, [fp, #-0x18]
    // 0x5a0520: add             x0, x3, #1
    // 0x5a0524: lsl             x1, x0, #1
    // 0x5a0528: StoreField: r2->field_b = r1
    //     0x5a0528: stur            w1, [x2, #0xb]
    // 0x5a052c: LoadField: r1 = r2->field_f
    //     0x5a052c: ldur            w1, [x2, #0xf]
    // 0x5a0530: DecompressPointer r1
    //     0x5a0530: add             x1, x1, HEAP, lsl #32
    // 0x5a0534: ldur            x0, [fp, #-0x10]
    // 0x5a0538: ArrayStore: r1[r3] = r0  ; List_4
    //     0x5a0538: add             x25, x1, x3, lsl #2
    //     0x5a053c: add             x25, x25, #0xf
    //     0x5a0540: str             w0, [x25]
    //     0x5a0544: tbz             w0, #0, #0x5a0560
    //     0x5a0548: ldurb           w16, [x1, #-1]
    //     0x5a054c: ldurb           w17, [x0, #-1]
    //     0x5a0550: and             x16, x17, x16, lsr #2
    //     0x5a0554: tst             x16, HEAP, lsr #32
    //     0x5a0558: b.eq            #0x5a0560
    //     0x5a055c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a0560: b               #0x5a0568
    // 0x5a0564: mov             x2, x1
    // 0x5a0568: r0 = Stack()
    //     0x5a0568: bl              #0x5a05b0  ; AllocateStackStub -> Stack (size=0x20)
    // 0x5a056c: r1 = Instance_Alignment
    //     0x5a056c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe258] Obj!Alignment@833251
    //     0x5a0570: ldr             x1, [x1, #0x258]
    // 0x5a0574: StoreField: r0->field_f = r1
    //     0x5a0574: stur            w1, [x0, #0xf]
    // 0x5a0578: r1 = Instance_StackFit
    //     0x5a0578: add             x1, PP, #0x16, lsl #12  ; [pp+0x168f8] Obj!StackFit@8627c1
    //     0x5a057c: ldr             x1, [x1, #0x8f8]
    // 0x5a0580: ArrayStore: r0[0] = r1  ; List_4
    //     0x5a0580: stur            w1, [x0, #0x17]
    // 0x5a0584: r1 = Instance_Clip
    //     0x5a0584: add             x1, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x5a0588: ldr             x1, [x1, #0x900]
    // 0x5a058c: StoreField: r0->field_1b = r1
    //     0x5a058c: stur            w1, [x0, #0x1b]
    // 0x5a0590: ldur            x1, [fp, #-8]
    // 0x5a0594: StoreField: r0->field_b = r1
    //     0x5a0594: stur            w1, [x0, #0xb]
    // 0x5a0598: LeaveFrame
    //     0x5a0598: mov             SP, fp
    //     0x5a059c: ldp             fp, lr, [SP], #0x10
    // 0x5a05a0: ret
    //     0x5a05a0: ret             
    // 0x5a05a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a05a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a05a8: b               #0x5a0340
    // 0x5a05ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a05ac: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4183, size: 0x14, field offset: 0x14
enum Chapter15Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x7249ac, size: 0x64
    // 0x7249ac: EnterFrame
    //     0x7249ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7249b0: mov             fp, SP
    // 0x7249b4: AllocStack(0x10)
    //     0x7249b4: sub             SP, SP, #0x10
    // 0x7249b8: SetupParameters(Chapter15Stat this /* r1 => r0, fp-0x8 */)
    //     0x7249b8: mov             x0, x1
    //     0x7249bc: stur            x1, [fp, #-8]
    // 0x7249c0: CheckStackOverflow
    //     0x7249c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7249c4: cmp             SP, x16
    //     0x7249c8: b.ls            #0x724a08
    // 0x7249cc: r1 = Null
    //     0x7249cc: mov             x1, NULL
    // 0x7249d0: r2 = 4
    //     0x7249d0: movz            x2, #0x4
    // 0x7249d4: r0 = AllocateArray()
    //     0x7249d4: bl              #0x82746c  ; AllocateArrayStub
    // 0x7249d8: r16 = "Chapter15Stat."
    //     0x7249d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c8] "Chapter15Stat."
    //     0x7249dc: ldr             x16, [x16, #0x5c8]
    // 0x7249e0: StoreField: r0->field_f = r16
    //     0x7249e0: stur            w16, [x0, #0xf]
    // 0x7249e4: ldur            x1, [fp, #-8]
    // 0x7249e8: LoadField: r2 = r1->field_f
    //     0x7249e8: ldur            w2, [x1, #0xf]
    // 0x7249ec: DecompressPointer r2
    //     0x7249ec: add             x2, x2, HEAP, lsl #32
    // 0x7249f0: StoreField: r0->field_13 = r2
    //     0x7249f0: stur            w2, [x0, #0x13]
    // 0x7249f4: str             x0, [SP]
    // 0x7249f8: r0 = _interpolate()
    //     0x7249f8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x7249fc: LeaveFrame
    //     0x7249fc: mov             SP, fp
    //     0x724a00: ldp             fp, lr, [SP], #0x10
    // 0x724a04: ret
    //     0x724a04: ret             
    // 0x724a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724a08: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724a0c: b               #0x7249cc
  }
}
