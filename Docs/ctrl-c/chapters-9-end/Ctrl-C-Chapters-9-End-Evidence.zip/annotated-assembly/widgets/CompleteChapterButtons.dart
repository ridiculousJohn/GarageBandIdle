// lib: , url: package:pretentious/widgets/CompleteChapterButtons.dart

// class id: 1049494, size: 0x8
class :: {

  String completionTokenPercent() {
    // ** addr: 0x59e4fc, size: 0x64
    // 0x59e4fc: EnterFrame
    //     0x59e4fc: stp             fp, lr, [SP, #-0x10]!
    //     0x59e500: mov             fp, SP
    // 0x59e504: AllocStack(0x10)
    //     0x59e504: sub             SP, SP, #0x10
    // 0x59e508: CheckStackOverflow
    //     0x59e508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x59e50c: cmp             SP, x16
    //     0x59e510: b.ls            #0x59e558
    // 0x59e514: r1 = "CompletionTokenBonusPercent"
    //     0x59e514: add             x1, PP, #0xe, lsl #12  ; [pp+0xea98] "CompletionTokenBonusPercent"
    //     0x59e518: ldr             x1, [x1, #0xa98]
    // 0x59e51c: r0 = remoteConfigGetDouble()
    //     0x59e51c: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x59e520: r1 = Null
    //     0x59e520: mov             x1, NULL
    // 0x59e524: r2 = 4
    //     0x59e524: movz            x2, #0x4
    // 0x59e528: stur            x0, [fp, #-8]
    // 0x59e52c: r0 = AllocateArray()
    //     0x59e52c: bl              #0x82746c  ; AllocateArrayStub
    // 0x59e530: mov             x1, x0
    // 0x59e534: ldur            x0, [fp, #-8]
    // 0x59e538: StoreField: r1->field_f = r0
    //     0x59e538: stur            w0, [x1, #0xf]
    // 0x59e53c: r16 = "%"
    //     0x59e53c: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] "%"
    // 0x59e540: StoreField: r1->field_13 = r16
    //     0x59e540: stur            w16, [x1, #0x13]
    // 0x59e544: str             x1, [SP]
    // 0x59e548: r0 = _interpolate()
    //     0x59e548: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x59e54c: LeaveFrame
    //     0x59e54c: mov             SP, fp
    //     0x59e550: ldp             fp, lr, [SP], #0x10
    // 0x59e554: ret
    //     0x59e554: ret             
    // 0x59e558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59e558: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59e55c: b               #0x59e514
  }
  static bool autoCompleteChapter() {
    // ** addr: 0x610a8c, size: 0x64
    // 0x610a8c: EnterFrame
    //     0x610a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x610a90: mov             fp, SP
    // 0x610a94: CheckStackOverflow
    //     0x610a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610a98: cmp             SP, x16
    //     0x610a9c: b.ls            #0x610adc
    // 0x610aa0: r0 = LoadStaticField(0xa6c)
    //     0x610aa0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x610aa4: ldr             x0, [x0, #0x14d8]
    // 0x610aa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x610aac: cmp             w0, w16
    // 0x610ab0: b.eq            #0x610ae4
    // 0x610ab4: mov             x1, x0
    // 0x610ab8: r2 = "AutoCompleteChapter"
    //     0x610ab8: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c960] "AutoCompleteChapter"
    //     0x610abc: ldr             x2, [x2, #0x960]
    // 0x610ac0: r0 = getBool()
    //     0x610ac0: bl              #0x452868  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getBool
    // 0x610ac4: cmp             w0, NULL
    // 0x610ac8: b.ne            #0x610ad0
    // 0x610acc: r0 = false
    //     0x610acc: add             x0, NULL, #0x30  ; false
    // 0x610ad0: LeaveFrame
    //     0x610ad0: mov             SP, fp
    //     0x610ad4: ldp             fp, lr, [SP], #0x10
    // 0x610ad8: ret
    //     0x610ad8: ret             
    // 0x610adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610adc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610ae0: b               #0x610aa0
    // 0x610ae4: r9 = prefs
    //     0x610ae4: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x610ae8: ldr             x9, [x9, #0xc00]
    // 0x610aec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x610aec: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] static bool autoCompleteChapter(dynamic) {
    // ** addr: 0x610af0, size: 0x2c
    // 0x610af0: EnterFrame
    //     0x610af0: stp             fp, lr, [SP, #-0x10]!
    //     0x610af4: mov             fp, SP
    // 0x610af8: CheckStackOverflow
    //     0x610af8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610afc: cmp             SP, x16
    //     0x610b00: b.ls            #0x610b14
    // 0x610b04: r0 = autoCompleteChapter()
    //     0x610b04: bl              #0x610a8c  ; [package:pretentious/widgets/CompleteChapterButtons.dart] ::autoCompleteChapter
    // 0x610b08: LeaveFrame
    //     0x610b08: mov             SP, fp
    //     0x610b0c: ldp             fp, lr, [SP], #0x10
    // 0x610b10: ret
    //     0x610b10: ret             
    // 0x610b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610b14: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610b18: b               #0x610b04
  }
}

// class id: 2824, size: 0x24, field offset: 0xc
//   const constructor, 
class CompleteChapterButtons<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72cc14, size: 0x94
    // 0x72cc14: EnterFrame
    //     0x72cc14: stp             fp, lr, [SP, #-0x10]!
    //     0x72cc18: mov             fp, SP
    // 0x72cc1c: AllocStack(0x8)
    //     0x72cc1c: sub             SP, SP, #8
    // 0x72cc20: CheckStackOverflow
    //     0x72cc20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cc24: cmp             SP, x16
    //     0x72cc28: b.ls            #0x72cca0
    // 0x72cc2c: LoadField: r2 = r1->field_b
    //     0x72cc2c: ldur            w2, [x1, #0xb]
    // 0x72cc30: DecompressPointer r2
    //     0x72cc30: add             x2, x2, HEAP, lsl #32
    // 0x72cc34: r1 = Null
    //     0x72cc34: mov             x1, NULL
    // 0x72cc38: r3 = <CompleteChapterButtons<X0>, void?, CompleteChapterButtons<X0>, X0>
    //     0x72cc38: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2a5e8] TypeArguments: <CompleteChapterButtons<X0>, void?, CompleteChapterButtons<X0>, X0>
    //     0x72cc3c: ldr             x3, [x3, #0x5e8]
    // 0x72cc40: r30 = InstantiateTypeArgumentsStub
    //     0x72cc40: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x72cc44: LoadField: r30 = r30->field_7
    //     0x72cc44: ldur            lr, [lr, #7]
    // 0x72cc48: blr             lr
    // 0x72cc4c: mov             x1, x0
    // 0x72cc50: r0 = CompleteChapterButtonsState()
    //     0x72cc50: bl              #0x72cca8  ; AllocateCompleteChapterButtonsStateStub -> CompleteChapterButtonsState<C3X0> (size=0x1c)
    // 0x72cc54: mov             x1, x0
    // 0x72cc58: r0 = false
    //     0x72cc58: add             x0, NULL, #0x30  ; false
    // 0x72cc5c: stur            x1, [fp, #-8]
    // 0x72cc60: ArrayStore: r1[0] = r0  ; List_4
    //     0x72cc60: stur            w0, [x1, #0x17]
    // 0x72cc64: r0 = LoadStaticField(0x1044)
    //     0x72cc64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x72cc68: ldr             x0, [x0, #0x2088]
    // 0x72cc6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72cc70: cmp             w0, w16
    // 0x72cc74: b.ne            #0x72cc84
    // 0x72cc78: r2 = progressCheckButtons
    //     0x72cc78: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc48] Field <::.progressCheckButtons>: static late (offset: 0x1044)
    //     0x72cc7c: ldr             x2, [x2, #0xc48]
    // 0x72cc80: r0 = InitLateStaticField()
    //     0x72cc80: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x72cc84: ldur            x1, [fp, #-8]
    // 0x72cc88: mov             x2, x0
    // 0x72cc8c: r0 = SyncState()
    //     0x72cc8c: bl              #0x72bee4  ; [package:state_groups/src/sync_state.dart] SyncState::SyncState
    // 0x72cc90: ldur            x0, [fp, #-8]
    // 0x72cc94: LeaveFrame
    //     0x72cc94: mov             SP, fp
    //     0x72cc98: ldp             fp, lr, [SP], #0x10
    // 0x72cc9c: ret
    //     0x72cc9c: ret             
    // 0x72cca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72cca0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72cca4: b               #0x72cc2c
  }
}

// class id: 3295, size: 0x1c, field offset: 0x18
class CompleteChapterButtonsState<C3X0> extends SyncState<C3X0, dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x6102c0, size: 0x360
    // 0x6102c0: EnterFrame
    //     0x6102c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6102c4: mov             fp, SP
    // 0x6102c8: AllocStack(0x40)
    //     0x6102c8: sub             SP, SP, #0x40
    // 0x6102cc: SetupParameters(CompleteChapterButtonsState<C3X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x6102cc: stur            x1, [fp, #-8]
    //     0x6102d0: stur            x2, [fp, #-0x10]
    // 0x6102d4: CheckStackOverflow
    //     0x6102d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6102d8: cmp             SP, x16
    //     0x6102dc: b.ls            #0x610610
    // 0x6102e0: r1 = 2
    //     0x6102e0: movz            x1, #0x2
    // 0x6102e4: r0 = AllocateContext()
    //     0x6102e4: bl              #0x82637c  ; AllocateContextStub
    // 0x6102e8: mov             x3, x0
    // 0x6102ec: ldur            x0, [fp, #-8]
    // 0x6102f0: stur            x3, [fp, #-0x18]
    // 0x6102f4: StoreField: r3->field_f = r0
    //     0x6102f4: stur            w0, [x3, #0xf]
    // 0x6102f8: ldur            x1, [fp, #-0x10]
    // 0x6102fc: StoreField: r3->field_13 = r1
    //     0x6102fc: stur            w1, [x3, #0x13]
    // 0x610300: LoadField: r1 = r0->field_b
    //     0x610300: ldur            w1, [x0, #0xb]
    // 0x610304: DecompressPointer r1
    //     0x610304: add             x1, x1, HEAP, lsl #32
    // 0x610308: cmp             w1, NULL
    // 0x61030c: b.eq            #0x610618
    // 0x610310: LoadField: r4 = r1->field_f
    //     0x610310: ldur            w4, [x1, #0xf]
    // 0x610314: DecompressPointer r4
    //     0x610314: add             x4, x4, HEAP, lsl #32
    // 0x610318: stur            x4, [fp, #-0x10]
    // 0x61031c: LoadField: r2 = r1->field_13
    //     0x61031c: ldur            w2, [x1, #0x13]
    // 0x610320: DecompressPointer r2
    //     0x610320: add             x2, x2, HEAP, lsl #32
    // 0x610324: LoadField: r1 = r2->field_b
    //     0x610324: ldur            w1, [x2, #0xb]
    // 0x610328: DecompressPointer r1
    //     0x610328: add             x1, x1, HEAP, lsl #32
    // 0x61032c: mov             x2, x1
    // 0x610330: mov             x1, x4
    // 0x610334: r0 = _getValueOrData()
    //     0x610334: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x610338: mov             x1, x0
    // 0x61033c: ldur            x0, [fp, #-0x10]
    // 0x610340: LoadField: r2 = r0->field_f
    //     0x610340: ldur            w2, [x0, #0xf]
    // 0x610344: DecompressPointer r2
    //     0x610344: add             x2, x2, HEAP, lsl #32
    // 0x610348: cmp             w2, w1
    // 0x61034c: b.ne            #0x610358
    // 0x610350: r0 = Null
    //     0x610350: mov             x0, NULL
    // 0x610354: b               #0x61035c
    // 0x610358: mov             x0, x1
    // 0x61035c: cmp             w0, NULL
    // 0x610360: b.ne            #0x610370
    // 0x610364: r2 = Instance_CustomNum
    //     0x610364: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x610368: ldr             x2, [x2, #0xaf8]
    // 0x61036c: b               #0x610374
    // 0x610370: mov             x2, x0
    // 0x610374: ldur            x0, [fp, #-8]
    // 0x610378: mov             x1, x0
    // 0x61037c: stur            x2, [fp, #-0x10]
    // 0x610380: r0 = canCompleteChapter()
    //     0x610380: bl              #0x61067c  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::canCompleteChapter
    // 0x610384: mov             x1, x0
    // 0x610388: ldur            x0, [fp, #-8]
    // 0x61038c: ArrayStore: r0[0] = r1  ; List_4
    //     0x61038c: stur            w1, [x0, #0x17]
    // 0x610390: mov             x1, x0
    // 0x610394: r0 = fragmentTitle()
    //     0x610394: bl              #0x610620  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::fragmentTitle
    // 0x610398: stur            x0, [fp, #-0x20]
    // 0x61039c: r0 = Text()
    //     0x61039c: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x6103a0: mov             x3, x0
    // 0x6103a4: ldur            x0, [fp, #-0x20]
    // 0x6103a8: stur            x3, [fp, #-0x28]
    // 0x6103ac: StoreField: r3->field_b = r0
    //     0x6103ac: stur            w0, [x3, #0xb]
    // 0x6103b0: ldur            x0, [fp, #-8]
    // 0x6103b4: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x6103b4: ldur            w4, [x0, #0x17]
    // 0x6103b8: DecompressPointer r4
    //     0x6103b8: add             x4, x4, HEAP, lsl #32
    // 0x6103bc: stur            x4, [fp, #-0x20]
    // 0x6103c0: tbnz            w4, #4, #0x6103dc
    // 0x6103c4: ldur            x2, [fp, #-0x18]
    // 0x6103c8: r1 = Function '<anonymous closure>':.
    //     0x6103c8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2caf8] AnonymousClosure: (0x610770), in [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::build (0x6102c0)
    //     0x6103cc: ldr             x1, [x1, #0xaf8]
    // 0x6103d0: r0 = AllocateClosure()
    //     0x6103d0: bl              #0x826750  ; AllocateClosureStub
    // 0x6103d4: mov             x3, x0
    // 0x6103d8: b               #0x6103e0
    // 0x6103dc: r3 = Null
    //     0x6103dc: mov             x3, NULL
    // 0x6103e0: ldur            x0, [fp, #-0x20]
    // 0x6103e4: stur            x3, [fp, #-0x18]
    // 0x6103e8: tbnz            w0, #4, #0x6103fc
    // 0x6103ec: mov             x0, x3
    // 0x6103f0: r2 = Instance_Text
    //     0x6103f0: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c0c0] Obj!Text@850b21
    //     0x6103f4: ldr             x2, [x2, #0xc0]
    // 0x6103f8: b               #0x610514
    // 0x6103fc: ldur            x0, [fp, #-8]
    // 0x610400: ldur            x4, [fp, #-0x10]
    // 0x610404: r1 = Null
    //     0x610404: mov             x1, NULL
    // 0x610408: r2 = 10
    //     0x610408: movz            x2, #0xa
    // 0x61040c: r0 = AllocateArray()
    //     0x61040c: bl              #0x82746c  ; AllocateArrayStub
    // 0x610410: mov             x3, x0
    // 0x610414: ldur            x0, [fp, #-0x10]
    // 0x610418: stur            x3, [fp, #-0x30]
    // 0x61041c: StoreField: r3->field_f = r0
    //     0x61041c: stur            w0, [x3, #0xf]
    // 0x610420: r16 = " / "
    //     0x610420: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c0d0] " / "
    //     0x610424: ldr             x16, [x16, #0xd0]
    // 0x610428: StoreField: r3->field_13 = r16
    //     0x610428: stur            w16, [x3, #0x13]
    // 0x61042c: ldur            x0, [fp, #-8]
    // 0x610430: LoadField: r1 = r0->field_b
    //     0x610430: ldur            w1, [x0, #0xb]
    // 0x610434: DecompressPointer r1
    //     0x610434: add             x1, x1, HEAP, lsl #32
    // 0x610438: cmp             w1, NULL
    // 0x61043c: b.eq            #0x61061c
    // 0x610440: LoadField: r2 = r1->field_13
    //     0x610440: ldur            w2, [x1, #0x13]
    // 0x610444: DecompressPointer r2
    //     0x610444: add             x2, x2, HEAP, lsl #32
    // 0x610448: LoadField: r4 = r2->field_f
    //     0x610448: ldur            w4, [x2, #0xf]
    // 0x61044c: DecompressPointer r4
    //     0x61044c: add             x4, x4, HEAP, lsl #32
    // 0x610450: ArrayStore: r3[0] = r4  ; List_4
    //     0x610450: stur            w4, [x3, #0x17]
    // 0x610454: r16 = " "
    //     0x610454: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x610458: StoreField: r3->field_1b = r16
    //     0x610458: stur            w16, [x3, #0x1b]
    // 0x61045c: LoadField: r4 = r2->field_b
    //     0x61045c: ldur            w4, [x2, #0xb]
    // 0x610460: DecompressPointer r4
    //     0x610460: add             x4, x4, HEAP, lsl #32
    // 0x610464: stur            x4, [fp, #-0x20]
    // 0x610468: LoadField: r5 = r1->field_1f
    //     0x610468: ldur            w5, [x1, #0x1f]
    // 0x61046c: DecompressPointer r5
    //     0x61046c: add             x5, x5, HEAP, lsl #32
    // 0x610470: stur            x5, [fp, #-0x10]
    // 0x610474: LoadField: r2 = r0->field_7
    //     0x610474: ldur            w2, [x0, #7]
    // 0x610478: DecompressPointer r2
    //     0x610478: add             x2, x2, HEAP, lsl #32
    // 0x61047c: mov             x0, x5
    // 0x610480: r1 = Null
    //     0x610480: mov             x1, NULL
    // 0x610484: r8 = (dynamic this, C3X0?) => String?
    //     0x610484: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x610488: ldr             x8, [x8, #0xe90]
    // 0x61048c: LoadField: r9 = r8->field_7
    //     0x61048c: ldur            x9, [x8, #7]
    // 0x610490: r3 = Null
    //     0x610490: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cb00] Null
    //     0x610494: ldr             x3, [x3, #0xb00]
    // 0x610498: blr             x9
    // 0x61049c: ldur            x16, [fp, #-0x10]
    // 0x6104a0: ldur            lr, [fp, #-0x20]
    // 0x6104a4: stp             lr, x16, [SP]
    // 0x6104a8: ldur            x0, [fp, #-0x10]
    // 0x6104ac: ClosureCall
    //     0x6104ac: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6104b0: ldur            x2, [x0, #0x1f]
    //     0x6104b4: blr             x2
    // 0x6104b8: ldur            x1, [fp, #-0x30]
    // 0x6104bc: ArrayStore: r1[4] = r0  ; List_4
    //     0x6104bc: add             x25, x1, #0x1f
    //     0x6104c0: str             w0, [x25]
    //     0x6104c4: tbz             w0, #0, #0x6104e0
    //     0x6104c8: ldurb           w16, [x1, #-1]
    //     0x6104cc: ldurb           w17, [x0, #-1]
    //     0x6104d0: and             x16, x17, x16, lsr #2
    //     0x6104d4: tst             x16, HEAP, lsr #32
    //     0x6104d8: b.eq            #0x6104e0
    //     0x6104dc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6104e0: ldur            x16, [fp, #-0x30]
    // 0x6104e4: str             x16, [SP]
    // 0x6104e8: r0 = _interpolate()
    //     0x6104e8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6104ec: stur            x0, [fp, #-8]
    // 0x6104f0: r0 = Text()
    //     0x6104f0: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x6104f4: mov             x1, x0
    // 0x6104f8: ldur            x0, [fp, #-8]
    // 0x6104fc: StoreField: r1->field_b = r0
    //     0x6104fc: stur            w0, [x1, #0xb]
    // 0x610500: r0 = Instance_TextStyle
    //     0x610500: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c008] Obj!TextStyle@846dc1
    //     0x610504: ldr             x0, [x0, #8]
    // 0x610508: StoreField: r1->field_13 = r0
    //     0x610508: stur            w0, [x1, #0x13]
    // 0x61050c: mov             x2, x1
    // 0x610510: ldur            x0, [fp, #-0x18]
    // 0x610514: ldur            x1, [fp, #-0x28]
    // 0x610518: stur            x2, [fp, #-8]
    // 0x61051c: r0 = ElevatedButton()
    //     0x61051c: bl              #0x59e9c4  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x44)
    // 0x610520: mov             x3, x0
    // 0x610524: r0 = false
    //     0x610524: add             x0, NULL, #0x30  ; false
    // 0x610528: stur            x3, [fp, #-0x10]
    // 0x61052c: StoreField: r3->field_3f = r0
    //     0x61052c: stur            w0, [x3, #0x3f]
    // 0x610530: ldur            x1, [fp, #-0x18]
    // 0x610534: StoreField: r3->field_b = r1
    //     0x610534: stur            w1, [x3, #0xb]
    // 0x610538: StoreField: r3->field_27 = r0
    //     0x610538: stur            w0, [x3, #0x27]
    // 0x61053c: r0 = true
    //     0x61053c: add             x0, NULL, #0x20  ; true
    // 0x610540: StoreField: r3->field_2f = r0
    //     0x610540: stur            w0, [x3, #0x2f]
    // 0x610544: ldur            x0, [fp, #-8]
    // 0x610548: StoreField: r3->field_3b = r0
    //     0x610548: stur            w0, [x3, #0x3b]
    // 0x61054c: r1 = Null
    //     0x61054c: mov             x1, NULL
    // 0x610550: r2 = 10
    //     0x610550: movz            x2, #0xa
    // 0x610554: r0 = AllocateArray()
    //     0x610554: bl              #0x82746c  ; AllocateArrayStub
    // 0x610558: stur            x0, [fp, #-8]
    // 0x61055c: r16 = Instance_SizedBox
    //     0x61055c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c0e8] Obj!SizedBox@85d561
    //     0x610560: ldr             x16, [x16, #0xe8]
    // 0x610564: StoreField: r0->field_f = r16
    //     0x610564: stur            w16, [x0, #0xf]
    // 0x610568: ldur            x1, [fp, #-0x28]
    // 0x61056c: StoreField: r0->field_13 = r1
    //     0x61056c: stur            w1, [x0, #0x13]
    // 0x610570: r16 = Instance_SizedBox
    //     0x610570: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c0f0] Obj!SizedBox@85d541
    //     0x610574: ldr             x16, [x16, #0xf0]
    // 0x610578: ArrayStore: r0[0] = r16  ; List_4
    //     0x610578: stur            w16, [x0, #0x17]
    // 0x61057c: ldur            x1, [fp, #-0x10]
    // 0x610580: StoreField: r0->field_1b = r1
    //     0x610580: stur            w1, [x0, #0x1b]
    // 0x610584: r16 = Instance_SizedBox
    //     0x610584: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c0e8] Obj!SizedBox@85d561
    //     0x610588: ldr             x16, [x16, #0xe8]
    // 0x61058c: StoreField: r0->field_1f = r16
    //     0x61058c: stur            w16, [x0, #0x1f]
    // 0x610590: r1 = <Widget>
    //     0x610590: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x610594: r0 = AllocateGrowableArray()
    //     0x610594: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x610598: mov             x1, x0
    // 0x61059c: ldur            x0, [fp, #-8]
    // 0x6105a0: stur            x1, [fp, #-0x10]
    // 0x6105a4: StoreField: r1->field_f = r0
    //     0x6105a4: stur            w0, [x1, #0xf]
    // 0x6105a8: r0 = 10
    //     0x6105a8: movz            x0, #0xa
    // 0x6105ac: StoreField: r1->field_b = r0
    //     0x6105ac: stur            w0, [x1, #0xb]
    // 0x6105b0: r0 = Column()
    //     0x6105b0: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6105b4: r1 = Instance_Axis
    //     0x6105b4: ldr             x1, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x6105b8: StoreField: r0->field_f = r1
    //     0x6105b8: stur            w1, [x0, #0xf]
    // 0x6105bc: r1 = Instance_MainAxisAlignment
    //     0x6105bc: add             x1, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6105c0: ldr             x1, [x1, #0x200]
    // 0x6105c4: StoreField: r0->field_13 = r1
    //     0x6105c4: stur            w1, [x0, #0x13]
    // 0x6105c8: r1 = Instance_MainAxisSize
    //     0x6105c8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6105cc: ldr             x1, [x1, #0x70]
    // 0x6105d0: ArrayStore: r0[0] = r1  ; List_4
    //     0x6105d0: stur            w1, [x0, #0x17]
    // 0x6105d4: r1 = Instance_CrossAxisAlignment
    //     0x6105d4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6105d8: ldr             x1, [x1, #0x78]
    // 0x6105dc: StoreField: r0->field_1b = r1
    //     0x6105dc: stur            w1, [x0, #0x1b]
    // 0x6105e0: r1 = Instance_VerticalDirection
    //     0x6105e0: add             x1, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6105e4: ldr             x1, [x1, #0x1e8]
    // 0x6105e8: StoreField: r0->field_23 = r1
    //     0x6105e8: stur            w1, [x0, #0x23]
    // 0x6105ec: r1 = Instance_Clip
    //     0x6105ec: add             x1, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6105f0: ldr             x1, [x1, #0x1b0]
    // 0x6105f4: StoreField: r0->field_2b = r1
    //     0x6105f4: stur            w1, [x0, #0x2b]
    // 0x6105f8: StoreField: r0->field_2f = rZR
    //     0x6105f8: stur            xzr, [x0, #0x2f]
    // 0x6105fc: ldur            x1, [fp, #-0x10]
    // 0x610600: StoreField: r0->field_b = r1
    //     0x610600: stur            w1, [x0, #0xb]
    // 0x610604: LeaveFrame
    //     0x610604: mov             SP, fp
    //     0x610608: ldp             fp, lr, [SP], #0x10
    // 0x61060c: ret
    //     0x61060c: ret             
    // 0x610610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610610: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610614: b               #0x6102e0
    // 0x610618: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610618: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61061c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61061c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ fragmentTitle(/* No info */) {
    // ** addr: 0x610620, size: 0x5c
    // 0x610620: LoadField: r2 = r1->field_b
    //     0x610620: ldur            w2, [x1, #0xb]
    // 0x610624: DecompressPointer r2
    //     0x610624: add             x2, x2, HEAP, lsl #32
    // 0x610628: cmp             w2, NULL
    // 0x61062c: b.eq            #0x610670
    // 0x610630: LoadField: r1 = r2->field_1b
    //     0x610630: ldur            w1, [x2, #0x1b]
    // 0x610634: DecompressPointer r1
    //     0x610634: add             x1, x1, HEAP, lsl #32
    // 0x610638: LoadField: r2 = r1->field_7
    //     0x610638: ldur            x2, [x1, #7]
    // 0x61063c: cmp             x2, #1
    // 0x610640: b.gt            #0x610664
    // 0x610644: cmp             x2, #0
    // 0x610648: b.gt            #0x610658
    // 0x61064c: r0 = "Complete Chapter"
    //     0x61064c: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb58] "Complete Chapter"
    //     0x610650: ldr             x0, [x0, #0xb58]
    // 0x610654: ret
    //     0x610654: ret             
    // 0x610658: r0 = "Reset Chapter"
    //     0x610658: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb80] "Reset Chapter"
    //     0x61065c: ldr             x0, [x0, #0xb80]
    // 0x610660: ret
    //     0x610660: ret             
    // 0x610664: r0 = "Complete Level"
    //     0x610664: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb88] "Complete Level"
    //     0x610668: ldr             x0, [x0, #0xb88]
    // 0x61066c: ret
    //     0x61066c: ret             
    // 0x610670: EnterFrame
    //     0x610670: stp             fp, lr, [SP, #-0x10]!
    //     0x610674: mov             fp, SP
    // 0x610678: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610678: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ canCompleteChapter(/* No info */) {
    // ** addr: 0x61067c, size: 0xf4
    // 0x61067c: EnterFrame
    //     0x61067c: stp             fp, lr, [SP, #-0x10]!
    //     0x610680: mov             fp, SP
    // 0x610684: AllocStack(0x10)
    //     0x610684: sub             SP, SP, #0x10
    // 0x610688: SetupParameters(CompleteChapterButtonsState<C3X0> this /* r1 => r0, fp-0x10 */)
    //     0x610688: mov             x0, x1
    //     0x61068c: stur            x1, [fp, #-0x10]
    // 0x610690: CheckStackOverflow
    //     0x610690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610694: cmp             SP, x16
    //     0x610698: b.ls            #0x610760
    // 0x61069c: LoadField: r1 = r0->field_b
    //     0x61069c: ldur            w1, [x0, #0xb]
    // 0x6106a0: DecompressPointer r1
    //     0x6106a0: add             x1, x1, HEAP, lsl #32
    // 0x6106a4: cmp             w1, NULL
    // 0x6106a8: b.eq            #0x610768
    // 0x6106ac: LoadField: r3 = r1->field_f
    //     0x6106ac: ldur            w3, [x1, #0xf]
    // 0x6106b0: DecompressPointer r3
    //     0x6106b0: add             x3, x3, HEAP, lsl #32
    // 0x6106b4: stur            x3, [fp, #-8]
    // 0x6106b8: LoadField: r2 = r1->field_13
    //     0x6106b8: ldur            w2, [x1, #0x13]
    // 0x6106bc: DecompressPointer r2
    //     0x6106bc: add             x2, x2, HEAP, lsl #32
    // 0x6106c0: LoadField: r1 = r2->field_b
    //     0x6106c0: ldur            w1, [x2, #0xb]
    // 0x6106c4: DecompressPointer r1
    //     0x6106c4: add             x1, x1, HEAP, lsl #32
    // 0x6106c8: mov             x2, x1
    // 0x6106cc: mov             x1, x3
    // 0x6106d0: r0 = _getValueOrData()
    //     0x6106d0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6106d4: ldur            x1, [fp, #-8]
    // 0x6106d8: LoadField: r2 = r1->field_f
    //     0x6106d8: ldur            w2, [x1, #0xf]
    // 0x6106dc: DecompressPointer r2
    //     0x6106dc: add             x2, x2, HEAP, lsl #32
    // 0x6106e0: cmp             w2, w0
    // 0x6106e4: b.ne            #0x6106f0
    // 0x6106e8: r1 = Null
    //     0x6106e8: mov             x1, NULL
    // 0x6106ec: b               #0x6106f4
    // 0x6106f0: mov             x1, x0
    // 0x6106f4: cmp             w1, NULL
    // 0x6106f8: b.ne            #0x610708
    // 0x6106fc: r2 = Instance_CustomNum
    //     0x6106fc: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x610700: ldr             x2, [x2, #0xaf8]
    // 0x610704: b               #0x61070c
    // 0x610708: mov             x2, x1
    // 0x61070c: ldur            x1, [fp, #-0x10]
    // 0x610710: d0 = 0.000000
    //     0x610710: add             x17, PP, #0x10, lsl #12  ; [pp+0x10d38] IMM: double(1e-14) from 0x3d06849b86a12b9b
    //     0x610714: ldr             d0, [x17, #0xd38]
    // 0x610718: LoadField: r3 = r1->field_b
    //     0x610718: ldur            w3, [x1, #0xb]
    // 0x61071c: DecompressPointer r3
    //     0x61071c: add             x3, x3, HEAP, lsl #32
    // 0x610720: cmp             w3, NULL
    // 0x610724: b.eq            #0x61076c
    // 0x610728: LoadField: r1 = r3->field_13
    //     0x610728: ldur            w1, [x3, #0x13]
    // 0x61072c: DecompressPointer r1
    //     0x61072c: add             x1, x1, HEAP, lsl #32
    // 0x610730: LoadField: r3 = r1->field_f
    //     0x610730: ldur            w3, [x1, #0xf]
    // 0x610734: DecompressPointer r3
    //     0x610734: add             x3, x3, HEAP, lsl #32
    // 0x610738: LoadField: d1 = r3->field_7
    //     0x610738: ldur            d1, [x3, #7]
    // 0x61073c: LoadField: d2 = r2->field_7
    //     0x61073c: ldur            d2, [x2, #7]
    // 0x610740: fadd            d3, d2, d0
    // 0x610744: fcmp            d3, d1
    // 0x610748: r16 = true
    //     0x610748: add             x16, NULL, #0x20  ; true
    // 0x61074c: r17 = false
    //     0x61074c: add             x17, NULL, #0x30  ; false
    // 0x610750: csel            x0, x16, x17, ge
    // 0x610754: LeaveFrame
    //     0x610754: mov             SP, fp
    //     0x610758: ldp             fp, lr, [SP], #0x10
    // 0x61075c: ret
    //     0x61075c: ret             
    // 0x610760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610760: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610764: b               #0x61069c
    // 0x610768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610768: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61076c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x61076c: bl              #0x827c54  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x610770, size: 0xa4
    // 0x610770: EnterFrame
    //     0x610770: stp             fp, lr, [SP, #-0x10]!
    //     0x610774: mov             fp, SP
    // 0x610778: AllocStack(0x28)
    //     0x610778: sub             SP, SP, #0x28
    // 0x61077c: SetupParameters([dynamic _ /* r0 */])
    //     0x61077c: ldr             x0, [fp, #0x10]
    //     0x610780: ldur            w2, [x0, #0x17]
    //     0x610784: add             x2, x2, HEAP, lsl #32
    //     0x610788: stur            x2, [fp, #-8]
    // 0x61078c: CheckStackOverflow
    //     0x61078c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610790: cmp             SP, x16
    //     0x610794: b.ls            #0x61080c
    // 0x610798: LoadField: r1 = r2->field_f
    //     0x610798: ldur            w1, [x2, #0xf]
    // 0x61079c: DecompressPointer r1
    //     0x61079c: add             x1, x1, HEAP, lsl #32
    // 0x6107a0: r0 = shouldSkipDialog()
    //     0x6107a0: bl              #0x610a10  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::shouldSkipDialog
    // 0x6107a4: tbnz            w0, #4, #0x6107c8
    // 0x6107a8: ldur            x2, [fp, #-8]
    // 0x6107ac: LoadField: r1 = r2->field_f
    //     0x6107ac: ldur            w1, [x2, #0xf]
    // 0x6107b0: DecompressPointer r1
    //     0x6107b0: add             x1, x1, HEAP, lsl #32
    // 0x6107b4: r0 = completeChapterWrapper()
    //     0x6107b4: bl              #0x610814  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::completeChapterWrapper
    // 0x6107b8: r0 = Null
    //     0x6107b8: mov             x0, NULL
    // 0x6107bc: LeaveFrame
    //     0x6107bc: mov             SP, fp
    //     0x6107c0: ldp             fp, lr, [SP], #0x10
    // 0x6107c4: ret
    //     0x6107c4: ret             
    // 0x6107c8: ldur            x2, [fp, #-8]
    // 0x6107cc: LoadField: r0 = r2->field_13
    //     0x6107cc: ldur            w0, [x2, #0x13]
    // 0x6107d0: DecompressPointer r0
    //     0x6107d0: add             x0, x0, HEAP, lsl #32
    // 0x6107d4: stur            x0, [fp, #-0x10]
    // 0x6107d8: r1 = Function '<anonymous closure>':.
    //     0x6107d8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb10] AnonymousClosure: (0x610b1c), in [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::build (0x6102c0)
    //     0x6107dc: ldr             x1, [x1, #0xb10]
    // 0x6107e0: r0 = AllocateClosure()
    //     0x6107e0: bl              #0x826750  ; AllocateClosureStub
    // 0x6107e4: r16 = <void?>
    //     0x6107e4: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x6107e8: stp             x0, x16, [SP, #8]
    // 0x6107ec: ldur            x16, [fp, #-0x10]
    // 0x6107f0: str             x16, [SP]
    // 0x6107f4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6107f4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6107f8: r0 = showDialog()
    //     0x6107f8: bl              #0x3ecee0  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x6107fc: r0 = Null
    //     0x6107fc: mov             x0, NULL
    // 0x610800: LeaveFrame
    //     0x610800: mov             SP, fp
    //     0x610804: ldp             fp, lr, [SP], #0x10
    // 0x610808: ret
    //     0x610808: ret             
    // 0x61080c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61080c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610810: b               #0x610798
  }
  _ completeChapterWrapper(/* No info */) {
    // ** addr: 0x610814, size: 0x1fc
    // 0x610814: EnterFrame
    //     0x610814: stp             fp, lr, [SP, #-0x10]!
    //     0x610818: mov             fp, SP
    // 0x61081c: AllocStack(0x28)
    //     0x61081c: sub             SP, SP, #0x28
    // 0x610820: SetupParameters(CompleteChapterButtonsState<C3X0> this /* r1 => r0, fp-0x8 */)
    //     0x610820: mov             x0, x1
    //     0x610824: stur            x1, [fp, #-8]
    // 0x610828: CheckStackOverflow
    //     0x610828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61082c: cmp             SP, x16
    //     0x610830: b.ls            #0x6109f8
    // 0x610834: mov             x1, x0
    // 0x610838: r0 = canCompleteChapter()
    //     0x610838: bl              #0x61067c  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::canCompleteChapter
    // 0x61083c: tbnz            w0, #4, #0x610880
    // 0x610840: ldur            x0, [fp, #-8]
    // 0x610844: LoadField: r1 = r0->field_b
    //     0x610844: ldur            w1, [x0, #0xb]
    // 0x610848: DecompressPointer r1
    //     0x610848: add             x1, x1, HEAP, lsl #32
    // 0x61084c: cmp             w1, NULL
    // 0x610850: b.eq            #0x610a00
    // 0x610854: LoadField: r2 = r0->field_f
    //     0x610854: ldur            w2, [x0, #0xf]
    // 0x610858: DecompressPointer r2
    //     0x610858: add             x2, x2, HEAP, lsl #32
    // 0x61085c: cmp             w2, NULL
    // 0x610860: b.eq            #0x610a04
    // 0x610864: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x610864: ldur            w0, [x1, #0x17]
    // 0x610868: DecompressPointer r0
    //     0x610868: add             x0, x0, HEAP, lsl #32
    // 0x61086c: stp             x2, x0, [SP]
    // 0x610870: ClosureCall
    //     0x610870: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x610874: ldur            x2, [x0, #0x1f]
    //     0x610878: blr             x2
    // 0x61087c: b               #0x6109e8
    // 0x610880: ldur            x0, [fp, #-8]
    // 0x610884: r1 = Null
    //     0x610884: mov             x1, NULL
    // 0x610888: r2 = 12
    //     0x610888: movz            x2, #0xc
    // 0x61088c: r0 = AllocateArray()
    //     0x61088c: bl              #0x82746c  ; AllocateArrayStub
    // 0x610890: stur            x0, [fp, #-0x18]
    // 0x610894: r16 = "Unable to complete chapter! Stats: "
    //     0x610894: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2cb70] "Unable to complete chapter! Stats: "
    //     0x610898: ldr             x16, [x16, #0xb70]
    // 0x61089c: StoreField: r0->field_f = r16
    //     0x61089c: stur            w16, [x0, #0xf]
    // 0x6108a0: ldur            x3, [fp, #-8]
    // 0x6108a4: LoadField: r1 = r3->field_b
    //     0x6108a4: ldur            w1, [x3, #0xb]
    // 0x6108a8: DecompressPointer r1
    //     0x6108a8: add             x1, x1, HEAP, lsl #32
    // 0x6108ac: cmp             w1, NULL
    // 0x6108b0: b.eq            #0x610a08
    // 0x6108b4: LoadField: r4 = r1->field_f
    //     0x6108b4: ldur            w4, [x1, #0xf]
    // 0x6108b8: DecompressPointer r4
    //     0x6108b8: add             x4, x4, HEAP, lsl #32
    // 0x6108bc: stur            x4, [fp, #-0x10]
    // 0x6108c0: LoadField: r2 = r1->field_13
    //     0x6108c0: ldur            w2, [x1, #0x13]
    // 0x6108c4: DecompressPointer r2
    //     0x6108c4: add             x2, x2, HEAP, lsl #32
    // 0x6108c8: LoadField: r1 = r2->field_b
    //     0x6108c8: ldur            w1, [x2, #0xb]
    // 0x6108cc: DecompressPointer r1
    //     0x6108cc: add             x1, x1, HEAP, lsl #32
    // 0x6108d0: mov             x2, x1
    // 0x6108d4: mov             x1, x4
    // 0x6108d8: r0 = _getValueOrData()
    //     0x6108d8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6108dc: mov             x1, x0
    // 0x6108e0: ldur            x0, [fp, #-0x10]
    // 0x6108e4: LoadField: r2 = r0->field_f
    //     0x6108e4: ldur            w2, [x0, #0xf]
    // 0x6108e8: DecompressPointer r2
    //     0x6108e8: add             x2, x2, HEAP, lsl #32
    // 0x6108ec: cmp             w2, w1
    // 0x6108f0: b.ne            #0x6108fc
    // 0x6108f4: r0 = Null
    //     0x6108f4: mov             x0, NULL
    // 0x6108f8: b               #0x610900
    // 0x6108fc: mov             x0, x1
    // 0x610900: cmp             w0, NULL
    // 0x610904: b.ne            #0x610910
    // 0x610908: r0 = Instance_CustomNum
    //     0x610908: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x61090c: ldr             x0, [x0, #0xaf8]
    // 0x610910: ldur            x3, [fp, #-8]
    // 0x610914: ldur            x2, [fp, #-0x18]
    // 0x610918: mov             x1, x2
    // 0x61091c: ArrayStore: r1[1] = r0  ; List_4
    //     0x61091c: add             x25, x1, #0x13
    //     0x610920: str             w0, [x25]
    //     0x610924: tbz             w0, #0, #0x610940
    //     0x610928: ldurb           w16, [x1, #-1]
    //     0x61092c: ldurb           w17, [x0, #-1]
    //     0x610930: and             x16, x17, x16, lsr #2
    //     0x610934: tst             x16, HEAP, lsr #32
    //     0x610938: b.eq            #0x610940
    //     0x61093c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x610940: r16 = " "
    //     0x610940: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x610944: ArrayStore: r2[0] = r16  ; List_4
    //     0x610944: stur            w16, [x2, #0x17]
    // 0x610948: LoadField: r0 = r3->field_b
    //     0x610948: ldur            w0, [x3, #0xb]
    // 0x61094c: DecompressPointer r0
    //     0x61094c: add             x0, x0, HEAP, lsl #32
    // 0x610950: cmp             w0, NULL
    // 0x610954: b.eq            #0x610a0c
    // 0x610958: LoadField: r3 = r0->field_13
    //     0x610958: ldur            w3, [x0, #0x13]
    // 0x61095c: DecompressPointer r3
    //     0x61095c: add             x3, x3, HEAP, lsl #32
    // 0x610960: LoadField: r0 = r3->field_b
    //     0x610960: ldur            w0, [x3, #0xb]
    // 0x610964: DecompressPointer r0
    //     0x610964: add             x0, x0, HEAP, lsl #32
    // 0x610968: mov             x1, x2
    // 0x61096c: ArrayStore: r1[3] = r0  ; List_4
    //     0x61096c: add             x25, x1, #0x1b
    //     0x610970: str             w0, [x25]
    //     0x610974: tbz             w0, #0, #0x610990
    //     0x610978: ldurb           w16, [x1, #-1]
    //     0x61097c: ldurb           w17, [x0, #-1]
    //     0x610980: and             x16, x17, x16, lsr #2
    //     0x610984: tst             x16, HEAP, lsr #32
    //     0x610988: b.eq            #0x610990
    //     0x61098c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x610990: r16 = " cost: "
    //     0x610990: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2cb78] " cost: "
    //     0x610994: ldr             x16, [x16, #0xb78]
    // 0x610998: StoreField: r2->field_1f = r16
    //     0x610998: stur            w16, [x2, #0x1f]
    // 0x61099c: mov             x1, x2
    // 0x6109a0: mov             x0, x3
    // 0x6109a4: ArrayStore: r1[5] = r0  ; List_4
    //     0x6109a4: add             x25, x1, #0x23
    //     0x6109a8: str             w0, [x25]
    //     0x6109ac: tbz             w0, #0, #0x6109c8
    //     0x6109b0: ldurb           w16, [x1, #-1]
    //     0x6109b4: ldurb           w17, [x0, #-1]
    //     0x6109b8: and             x16, x17, x16, lsr #2
    //     0x6109bc: tst             x16, HEAP, lsr #32
    //     0x6109c0: b.eq            #0x6109c8
    //     0x6109c4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6109c8: str             x2, [SP]
    // 0x6109cc: r0 = _interpolate()
    //     0x6109cc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6109d0: stur            x0, [fp, #-8]
    // 0x6109d4: r0 = current()
    //     0x6109d4: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x6109d8: ldur            x1, [fp, #-8]
    // 0x6109dc: mov             x2, x0
    // 0x6109e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6109e0: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6109e4: r0 = crashlyticsRecordError()
    //     0x6109e4: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x6109e8: r0 = Null
    //     0x6109e8: mov             x0, NULL
    // 0x6109ec: LeaveFrame
    //     0x6109ec: mov             SP, fp
    //     0x6109f0: ldp             fp, lr, [SP], #0x10
    // 0x6109f4: ret
    //     0x6109f4: ret             
    // 0x6109f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6109f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6109fc: b               #0x610834
    // 0x610a00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610a00: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x610a04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610a04: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x610a08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610a08: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x610a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610a0c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ shouldSkipDialog(/* No info */) {
    // ** addr: 0x610a10, size: 0x7c
    // 0x610a10: EnterFrame
    //     0x610a10: stp             fp, lr, [SP, #-0x10]!
    //     0x610a14: mov             fp, SP
    // 0x610a18: CheckStackOverflow
    //     0x610a18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610a1c: cmp             SP, x16
    //     0x610a20: b.ls            #0x610a80
    // 0x610a24: LoadField: r0 = r1->field_b
    //     0x610a24: ldur            w0, [x1, #0xb]
    // 0x610a28: DecompressPointer r0
    //     0x610a28: add             x0, x0, HEAP, lsl #32
    // 0x610a2c: cmp             w0, NULL
    // 0x610a30: b.eq            #0x610a88
    // 0x610a34: LoadField: r1 = r0->field_1b
    //     0x610a34: ldur            w1, [x0, #0x1b]
    // 0x610a38: DecompressPointer r1
    //     0x610a38: add             x1, x1, HEAP, lsl #32
    // 0x610a3c: LoadField: r0 = r1->field_7
    //     0x610a3c: ldur            x0, [x1, #7]
    // 0x610a40: cmp             x0, #1
    // 0x610a44: b.gt            #0x610a70
    // 0x610a48: cmp             x0, #0
    // 0x610a4c: b.gt            #0x610a60
    // 0x610a50: r0 = autoCompleteChapter()
    //     0x610a50: bl              #0x610a8c  ; [package:pretentious/widgets/CompleteChapterButtons.dart] ::autoCompleteChapter
    // 0x610a54: LeaveFrame
    //     0x610a54: mov             SP, fp
    //     0x610a58: ldp             fp, lr, [SP], #0x10
    // 0x610a5c: ret
    //     0x610a5c: ret             
    // 0x610a60: r0 = false
    //     0x610a60: add             x0, NULL, #0x30  ; false
    // 0x610a64: LeaveFrame
    //     0x610a64: mov             SP, fp
    //     0x610a68: ldp             fp, lr, [SP], #0x10
    // 0x610a6c: ret
    //     0x610a6c: ret             
    // 0x610a70: r0 = false
    //     0x610a70: add             x0, NULL, #0x30  ; false
    // 0x610a74: LeaveFrame
    //     0x610a74: mov             SP, fp
    //     0x610a78: ldp             fp, lr, [SP], #0x10
    // 0x610a7c: ret
    //     0x610a7c: ret             
    // 0x610a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610a80: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610a84: b               #0x610a24
    // 0x610a88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610a88: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x610b1c, size: 0x1bc
    // 0x610b1c: EnterFrame
    //     0x610b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x610b20: mov             fp, SP
    // 0x610b24: AllocStack(0x28)
    //     0x610b24: sub             SP, SP, #0x28
    // 0x610b28: SetupParameters([dynamic _ /* r0 */])
    //     0x610b28: ldr             x0, [fp, #0x18]
    //     0x610b2c: ldur            w1, [x0, #0x17]
    //     0x610b30: add             x1, x1, HEAP, lsl #32
    //     0x610b34: stur            x1, [fp, #-8]
    // 0x610b38: CheckStackOverflow
    //     0x610b38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610b3c: cmp             SP, x16
    //     0x610b40: b.ls            #0x610cd0
    // 0x610b44: r1 = 1
    //     0x610b44: movz            x1, #0x1
    // 0x610b48: r0 = AllocateContext()
    //     0x610b48: bl              #0x82637c  ; AllocateContextStub
    // 0x610b4c: mov             x2, x0
    // 0x610b50: ldur            x0, [fp, #-8]
    // 0x610b54: stur            x2, [fp, #-0x10]
    // 0x610b58: StoreField: r2->field_b = r0
    //     0x610b58: stur            w0, [x2, #0xb]
    // 0x610b5c: ldr             x1, [fp, #0x10]
    // 0x610b60: StoreField: r2->field_f = r1
    //     0x610b60: stur            w1, [x2, #0xf]
    // 0x610b64: LoadField: r1 = r0->field_f
    //     0x610b64: ldur            w1, [x0, #0xf]
    // 0x610b68: DecompressPointer r1
    //     0x610b68: add             x1, x1, HEAP, lsl #32
    // 0x610b6c: r0 = alertTitle()
    //     0x610b6c: bl              #0x6110b8  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::alertTitle
    // 0x610b70: stur            x0, [fp, #-0x18]
    // 0x610b74: r0 = Text()
    //     0x610b74: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x610b78: mov             x2, x0
    // 0x610b7c: ldur            x0, [fp, #-0x18]
    // 0x610b80: stur            x2, [fp, #-0x20]
    // 0x610b84: StoreField: r2->field_b = r0
    //     0x610b84: stur            w0, [x2, #0xb]
    // 0x610b88: ldur            x0, [fp, #-8]
    // 0x610b8c: LoadField: r1 = r0->field_f
    //     0x610b8c: ldur            w1, [x0, #0xf]
    // 0x610b90: DecompressPointer r1
    //     0x610b90: add             x1, x1, HEAP, lsl #32
    // 0x610b94: r0 = makeContent()
    //     0x610b94: bl              #0x610d34  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::makeContent
    // 0x610b98: mov             x2, x0
    // 0x610b9c: ldur            x0, [fp, #-8]
    // 0x610ba0: stur            x2, [fp, #-0x18]
    // 0x610ba4: LoadField: r1 = r0->field_f
    //     0x610ba4: ldur            w1, [x0, #0xf]
    // 0x610ba8: DecompressPointer r1
    //     0x610ba8: add             x1, x1, HEAP, lsl #32
    // 0x610bac: r0 = confirmText()
    //     0x610bac: bl              #0x610cd8  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::confirmText
    // 0x610bb0: stur            x0, [fp, #-8]
    // 0x610bb4: r0 = Text()
    //     0x610bb4: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x610bb8: mov             x1, x0
    // 0x610bbc: ldur            x0, [fp, #-8]
    // 0x610bc0: stur            x1, [fp, #-0x28]
    // 0x610bc4: StoreField: r1->field_b = r0
    //     0x610bc4: stur            w0, [x1, #0xb]
    // 0x610bc8: r0 = TextButton()
    //     0x610bc8: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x610bcc: mov             x3, x0
    // 0x610bd0: r0 = false
    //     0x610bd0: add             x0, NULL, #0x30  ; false
    // 0x610bd4: stur            x3, [fp, #-8]
    // 0x610bd8: StoreField: r3->field_3f = r0
    //     0x610bd8: stur            w0, [x3, #0x3f]
    // 0x610bdc: ldur            x2, [fp, #-0x10]
    // 0x610be0: r1 = Function '<anonymous closure>':.
    //     0x610be0: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb18] AnonymousClosure: (0x611114), in [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::build (0x6102c0)
    //     0x610be4: ldr             x1, [x1, #0xb18]
    // 0x610be8: r0 = AllocateClosure()
    //     0x610be8: bl              #0x826750  ; AllocateClosureStub
    // 0x610bec: mov             x1, x0
    // 0x610bf0: ldur            x0, [fp, #-8]
    // 0x610bf4: StoreField: r0->field_b = r1
    //     0x610bf4: stur            w1, [x0, #0xb]
    // 0x610bf8: r1 = false
    //     0x610bf8: add             x1, NULL, #0x30  ; false
    // 0x610bfc: StoreField: r0->field_27 = r1
    //     0x610bfc: stur            w1, [x0, #0x27]
    // 0x610c00: r2 = true
    //     0x610c00: add             x2, NULL, #0x20  ; true
    // 0x610c04: StoreField: r0->field_2f = r2
    //     0x610c04: stur            w2, [x0, #0x2f]
    // 0x610c08: ldur            x3, [fp, #-0x28]
    // 0x610c0c: StoreField: r0->field_3b = r3
    //     0x610c0c: stur            w3, [x0, #0x3b]
    // 0x610c10: r0 = TextButton()
    //     0x610c10: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x610c14: mov             x3, x0
    // 0x610c18: r0 = false
    //     0x610c18: add             x0, NULL, #0x30  ; false
    // 0x610c1c: stur            x3, [fp, #-0x28]
    // 0x610c20: StoreField: r3->field_3f = r0
    //     0x610c20: stur            w0, [x3, #0x3f]
    // 0x610c24: ldur            x2, [fp, #-0x10]
    // 0x610c28: r1 = Function '<anonymous closure>':.
    //     0x610c28: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb20] AnonymousClosure: (0x605bf8), in [package:pretentious/Popups/ChaptersDisplay.dart] _ChaptersDisplayState::build (0x604a68)
    //     0x610c2c: ldr             x1, [x1, #0xb20]
    // 0x610c30: r0 = AllocateClosure()
    //     0x610c30: bl              #0x826750  ; AllocateClosureStub
    // 0x610c34: mov             x1, x0
    // 0x610c38: ldur            x0, [fp, #-0x28]
    // 0x610c3c: StoreField: r0->field_b = r1
    //     0x610c3c: stur            w1, [x0, #0xb]
    // 0x610c40: r3 = false
    //     0x610c40: add             x3, NULL, #0x30  ; false
    // 0x610c44: StoreField: r0->field_27 = r3
    //     0x610c44: stur            w3, [x0, #0x27]
    // 0x610c48: r1 = true
    //     0x610c48: add             x1, NULL, #0x20  ; true
    // 0x610c4c: StoreField: r0->field_2f = r1
    //     0x610c4c: stur            w1, [x0, #0x2f]
    // 0x610c50: r1 = Instance_Text
    //     0x610c50: add             x1, PP, #0xe, lsl #12  ; [pp+0xe9f8] Obj!Text@84ec31
    //     0x610c54: ldr             x1, [x1, #0x9f8]
    // 0x610c58: StoreField: r0->field_3b = r1
    //     0x610c58: stur            w1, [x0, #0x3b]
    // 0x610c5c: r1 = Null
    //     0x610c5c: mov             x1, NULL
    // 0x610c60: r2 = 4
    //     0x610c60: movz            x2, #0x4
    // 0x610c64: r0 = AllocateArray()
    //     0x610c64: bl              #0x82746c  ; AllocateArrayStub
    // 0x610c68: mov             x2, x0
    // 0x610c6c: ldur            x0, [fp, #-8]
    // 0x610c70: stur            x2, [fp, #-0x10]
    // 0x610c74: StoreField: r2->field_f = r0
    //     0x610c74: stur            w0, [x2, #0xf]
    // 0x610c78: ldur            x0, [fp, #-0x28]
    // 0x610c7c: StoreField: r2->field_13 = r0
    //     0x610c7c: stur            w0, [x2, #0x13]
    // 0x610c80: r1 = <Widget>
    //     0x610c80: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x610c84: r0 = AllocateGrowableArray()
    //     0x610c84: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x610c88: mov             x1, x0
    // 0x610c8c: ldur            x0, [fp, #-0x10]
    // 0x610c90: stur            x1, [fp, #-8]
    // 0x610c94: StoreField: r1->field_f = r0
    //     0x610c94: stur            w0, [x1, #0xf]
    // 0x610c98: r0 = 4
    //     0x610c98: movz            x0, #0x4
    // 0x610c9c: StoreField: r1->field_b = r0
    //     0x610c9c: stur            w0, [x1, #0xb]
    // 0x610ca0: r0 = AlertDialog()
    //     0x610ca0: bl              #0x490074  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x610ca4: ldur            x1, [fp, #-0x20]
    // 0x610ca8: StoreField: r0->field_f = r1
    //     0x610ca8: stur            w1, [x0, #0xf]
    // 0x610cac: ldur            x1, [fp, #-0x18]
    // 0x610cb0: StoreField: r0->field_1b = r1
    //     0x610cb0: stur            w1, [x0, #0x1b]
    // 0x610cb4: ldur            x1, [fp, #-8]
    // 0x610cb8: StoreField: r0->field_27 = r1
    //     0x610cb8: stur            w1, [x0, #0x27]
    // 0x610cbc: r1 = false
    //     0x610cbc: add             x1, NULL, #0x30  ; false
    // 0x610cc0: StoreField: r0->field_6b = r1
    //     0x610cc0: stur            w1, [x0, #0x6b]
    // 0x610cc4: LeaveFrame
    //     0x610cc4: mov             SP, fp
    //     0x610cc8: ldp             fp, lr, [SP], #0x10
    // 0x610ccc: ret
    //     0x610ccc: ret             
    // 0x610cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610cd0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610cd4: b               #0x610b44
  }
  _ confirmText(/* No info */) {
    // ** addr: 0x610cd8, size: 0x5c
    // 0x610cd8: LoadField: r2 = r1->field_b
    //     0x610cd8: ldur            w2, [x1, #0xb]
    // 0x610cdc: DecompressPointer r2
    //     0x610cdc: add             x2, x2, HEAP, lsl #32
    // 0x610ce0: cmp             w2, NULL
    // 0x610ce4: b.eq            #0x610d28
    // 0x610ce8: LoadField: r1 = r2->field_1b
    //     0x610ce8: ldur            w1, [x2, #0x1b]
    // 0x610cec: DecompressPointer r1
    //     0x610cec: add             x1, x1, HEAP, lsl #32
    // 0x610cf0: LoadField: r2 = r1->field_7
    //     0x610cf0: ldur            x2, [x1, #7]
    // 0x610cf4: cmp             x2, #1
    // 0x610cf8: b.gt            #0x610d1c
    // 0x610cfc: cmp             x2, #0
    // 0x610d00: b.gt            #0x610d10
    // 0x610d04: r0 = "Complete"
    //     0x610d04: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb30] "Complete"
    //     0x610d08: ldr             x0, [x0, #0xb30]
    // 0x610d0c: ret
    //     0x610d0c: ret             
    // 0x610d10: r0 = "Reset"
    //     0x610d10: add             x0, PP, #0x10, lsl #12  ; [pp+0x10698] "Reset"
    //     0x610d14: ldr             x0, [x0, #0x698]
    // 0x610d18: ret
    //     0x610d18: ret             
    // 0x610d1c: r0 = "Reset"
    //     0x610d1c: add             x0, PP, #0x10, lsl #12  ; [pp+0x10698] "Reset"
    //     0x610d20: ldr             x0, [x0, #0x698]
    // 0x610d24: ret
    //     0x610d24: ret             
    // 0x610d28: EnterFrame
    //     0x610d28: stp             fp, lr, [SP, #-0x10]!
    //     0x610d2c: mov             fp, SP
    // 0x610d30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x610d30: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ makeContent(/* No info */) {
    // ** addr: 0x610d34, size: 0x2d0
    // 0x610d34: EnterFrame
    //     0x610d34: stp             fp, lr, [SP, #-0x10]!
    //     0x610d38: mov             fp, SP
    // 0x610d3c: AllocStack(0x20)
    //     0x610d3c: sub             SP, SP, #0x20
    // 0x610d40: CheckStackOverflow
    //     0x610d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610d44: cmp             SP, x16
    //     0x610d48: b.ls            #0x610ff8
    // 0x610d4c: LoadField: r0 = r1->field_b
    //     0x610d4c: ldur            w0, [x1, #0xb]
    // 0x610d50: DecompressPointer r0
    //     0x610d50: add             x0, x0, HEAP, lsl #32
    // 0x610d54: cmp             w0, NULL
    // 0x610d58: b.eq            #0x611000
    // 0x610d5c: LoadField: r1 = r0->field_1b
    //     0x610d5c: ldur            w1, [x0, #0x1b]
    // 0x610d60: DecompressPointer r1
    //     0x610d60: add             x1, x1, HEAP, lsl #32
    // 0x610d64: LoadField: r0 = r1->field_7
    //     0x610d64: ldur            x0, [x1, #7]
    // 0x610d68: cmp             x0, #1
    // 0x610d6c: b.gt            #0x610fc8
    // 0x610d70: cmp             x0, #0
    // 0x610d74: b.gt            #0x610f1c
    // 0x610d78: r0 = 6
    //     0x610d78: movz            x0, #0x6
    // 0x610d7c: mov             x2, x0
    // 0x610d80: r1 = Null
    //     0x610d80: mov             x1, NULL
    // 0x610d84: r0 = AllocateArray()
    //     0x610d84: bl              #0x82746c  ; AllocateArrayStub
    // 0x610d88: stur            x0, [fp, #-8]
    // 0x610d8c: r16 = "This will reset the current chapter and reward you with 1 achievement token. Each achievement token will increase the speed of the game by "
    //     0x610d8c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c920] "This will reset the current chapter and reward you with 1 achievement token. Each achievement token will increase the speed of the game by "
    //     0x610d90: ldr             x16, [x16, #0x920]
    // 0x610d94: StoreField: r0->field_f = r16
    //     0x610d94: stur            w16, [x0, #0xf]
    // 0x610d98: r1 = "CompletionTokenBonusPercent"
    //     0x610d98: add             x1, PP, #0xe, lsl #12  ; [pp+0xea98] "CompletionTokenBonusPercent"
    //     0x610d9c: ldr             x1, [x1, #0xa98]
    // 0x610da0: r0 = remoteConfigGetDouble()
    //     0x610da0: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x610da4: r1 = Null
    //     0x610da4: mov             x1, NULL
    // 0x610da8: r2 = 4
    //     0x610da8: movz            x2, #0x4
    // 0x610dac: stur            x0, [fp, #-0x10]
    // 0x610db0: r0 = AllocateArray()
    //     0x610db0: bl              #0x82746c  ; AllocateArrayStub
    // 0x610db4: mov             x1, x0
    // 0x610db8: ldur            x0, [fp, #-0x10]
    // 0x610dbc: StoreField: r1->field_f = r0
    //     0x610dbc: stur            w0, [x1, #0xf]
    // 0x610dc0: r16 = "%"
    //     0x610dc0: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] "%"
    // 0x610dc4: StoreField: r1->field_13 = r16
    //     0x610dc4: stur            w16, [x1, #0x13]
    // 0x610dc8: str             x1, [SP]
    // 0x610dcc: r0 = _interpolate()
    //     0x610dcc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x610dd0: ldur            x1, [fp, #-8]
    // 0x610dd4: ArrayStore: r1[1] = r0  ; List_4
    //     0x610dd4: add             x25, x1, #0x13
    //     0x610dd8: str             w0, [x25]
    //     0x610ddc: tbz             w0, #0, #0x610df8
    //     0x610de0: ldurb           w16, [x1, #-1]
    //     0x610de4: ldurb           w17, [x0, #-1]
    //     0x610de8: and             x16, x17, x16, lsr #2
    //     0x610dec: tst             x16, HEAP, lsr #32
    //     0x610df0: b.eq            #0x610df8
    //     0x610df4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x610df8: ldur            x0, [fp, #-8]
    // 0x610dfc: r16 = "."
    //     0x610dfc: ldr             x16, [PP, #0x108]  ; [pp+0x108] "."
    // 0x610e00: ArrayStore: r0[0] = r16  ; List_4
    //     0x610e00: stur            w16, [x0, #0x17]
    // 0x610e04: str             x0, [SP]
    // 0x610e08: r0 = _interpolate()
    //     0x610e08: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x610e0c: stur            x0, [fp, #-8]
    // 0x610e10: r0 = Text()
    //     0x610e10: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x610e14: mov             x1, x0
    // 0x610e18: ldur            x0, [fp, #-8]
    // 0x610e1c: stur            x1, [fp, #-0x10]
    // 0x610e20: StoreField: r1->field_b = r0
    //     0x610e20: stur            w0, [x1, #0xb]
    // 0x610e24: r0 = BuyOnTapListTile()
    //     0x610e24: bl              #0x611004  ; AllocateBuyOnTapListTileStub -> BuyOnTapListTile (size=0x1c)
    // 0x610e28: mov             x3, x0
    // 0x610e2c: r0 = Instance_Text
    //     0x610e2c: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c928] Obj!Text@850ad1
    //     0x610e30: ldr             x0, [x0, #0x928]
    // 0x610e34: stur            x3, [fp, #-8]
    // 0x610e38: StoreField: r3->field_b = r0
    //     0x610e38: stur            w0, [x3, #0xb]
    // 0x610e3c: r0 = Closure: () => bool from Function 'autoCompleteChapter': static.
    //     0x610e3c: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c930] Closure: () => bool from Function 'autoCompleteChapter': static. (0x248edb40af0)
    //     0x610e40: ldr             x0, [x0, #0x930]
    // 0x610e44: StoreField: r3->field_13 = r0
    //     0x610e44: stur            w0, [x3, #0x13]
    // 0x610e48: r1 = Function '<anonymous closure>':.
    //     0x610e48: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb38] AnonymousClosure: (0x611030), in [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::makeContent (0x610d34)
    //     0x610e4c: ldr             x1, [x1, #0xb38]
    // 0x610e50: r2 = Null
    //     0x610e50: mov             x2, NULL
    // 0x610e54: r0 = AllocateClosure()
    //     0x610e54: bl              #0x826750  ; AllocateClosureStub
    // 0x610e58: mov             x1, x0
    // 0x610e5c: ldur            x0, [fp, #-8]
    // 0x610e60: ArrayStore: r0[0] = r1  ; List_4
    //     0x610e60: stur            w1, [x0, #0x17]
    // 0x610e64: r1 = Null
    //     0x610e64: mov             x1, NULL
    // 0x610e68: r2 = 6
    //     0x610e68: movz            x2, #0x6
    // 0x610e6c: r0 = AllocateArray()
    //     0x610e6c: bl              #0x82746c  ; AllocateArrayStub
    // 0x610e70: mov             x2, x0
    // 0x610e74: ldur            x0, [fp, #-0x10]
    // 0x610e78: stur            x2, [fp, #-0x18]
    // 0x610e7c: StoreField: r2->field_f = r0
    //     0x610e7c: stur            w0, [x2, #0xf]
    // 0x610e80: r16 = Instance_SizedBox
    //     0x610e80: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a488] Obj!SizedBox@85d2a1
    //     0x610e84: ldr             x16, [x16, #0x488]
    // 0x610e88: StoreField: r2->field_13 = r16
    //     0x610e88: stur            w16, [x2, #0x13]
    // 0x610e8c: ldur            x0, [fp, #-8]
    // 0x610e90: ArrayStore: r2[0] = r0  ; List_4
    //     0x610e90: stur            w0, [x2, #0x17]
    // 0x610e94: r1 = <Widget>
    //     0x610e94: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x610e98: r0 = AllocateGrowableArray()
    //     0x610e98: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x610e9c: mov             x1, x0
    // 0x610ea0: ldur            x0, [fp, #-0x18]
    // 0x610ea4: stur            x1, [fp, #-8]
    // 0x610ea8: StoreField: r1->field_f = r0
    //     0x610ea8: stur            w0, [x1, #0xf]
    // 0x610eac: r2 = 6
    //     0x610eac: movz            x2, #0x6
    // 0x610eb0: StoreField: r1->field_b = r2
    //     0x610eb0: stur            w2, [x1, #0xb]
    // 0x610eb4: r0 = Column()
    //     0x610eb4: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x610eb8: mov             x1, x0
    // 0x610ebc: r0 = Instance_Axis
    //     0x610ebc: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x610ec0: StoreField: r1->field_f = r0
    //     0x610ec0: stur            w0, [x1, #0xf]
    // 0x610ec4: r0 = Instance_MainAxisAlignment
    //     0x610ec4: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x610ec8: ldr             x0, [x0, #0x200]
    // 0x610ecc: StoreField: r1->field_13 = r0
    //     0x610ecc: stur            w0, [x1, #0x13]
    // 0x610ed0: r0 = Instance_MainAxisSize
    //     0x610ed0: add             x0, PP, #0x19, lsl #12  ; [pp+0x19208] Obj!MainAxisSize@862a81
    //     0x610ed4: ldr             x0, [x0, #0x208]
    // 0x610ed8: ArrayStore: r1[0] = r0  ; List_4
    //     0x610ed8: stur            w0, [x1, #0x17]
    // 0x610edc: r0 = Instance_CrossAxisAlignment
    //     0x610edc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x610ee0: ldr             x0, [x0, #0x78]
    // 0x610ee4: StoreField: r1->field_1b = r0
    //     0x610ee4: stur            w0, [x1, #0x1b]
    // 0x610ee8: r0 = Instance_VerticalDirection
    //     0x610ee8: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x610eec: ldr             x0, [x0, #0x1e8]
    // 0x610ef0: StoreField: r1->field_23 = r0
    //     0x610ef0: stur            w0, [x1, #0x23]
    // 0x610ef4: r0 = Instance_Clip
    //     0x610ef4: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x610ef8: ldr             x0, [x0, #0x1b0]
    // 0x610efc: StoreField: r1->field_2b = r0
    //     0x610efc: stur            w0, [x1, #0x2b]
    // 0x610f00: StoreField: r1->field_2f = rZR
    //     0x610f00: stur            xzr, [x1, #0x2f]
    // 0x610f04: ldur            x0, [fp, #-8]
    // 0x610f08: StoreField: r1->field_b = r0
    //     0x610f08: stur            w0, [x1, #0xb]
    // 0x610f0c: mov             x0, x1
    // 0x610f10: LeaveFrame
    //     0x610f10: mov             SP, fp
    //     0x610f14: ldp             fp, lr, [SP], #0x10
    // 0x610f18: ret
    //     0x610f18: ret             
    // 0x610f1c: r2 = 6
    //     0x610f1c: movz            x2, #0x6
    // 0x610f20: r1 = Null
    //     0x610f20: mov             x1, NULL
    // 0x610f24: r0 = AllocateArray()
    //     0x610f24: bl              #0x82746c  ; AllocateArrayStub
    // 0x610f28: stur            x0, [fp, #-8]
    // 0x610f2c: r16 = "You\'ve reached the end of the game. But you can still reset the current chapter for 1 achievement token. Each achievement token will increase the speed of the game by "
    //     0x610f2c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2cb40] "You\'ve reached the end of the game. But you can still reset the current chapter for 1 achievement token. Each achievement token will increase the speed of the game by "
    //     0x610f30: ldr             x16, [x16, #0xb40]
    // 0x610f34: StoreField: r0->field_f = r16
    //     0x610f34: stur            w16, [x0, #0xf]
    // 0x610f38: r1 = "CompletionTokenBonusPercent"
    //     0x610f38: add             x1, PP, #0xe, lsl #12  ; [pp+0xea98] "CompletionTokenBonusPercent"
    //     0x610f3c: ldr             x1, [x1, #0xa98]
    // 0x610f40: r0 = remoteConfigGetDouble()
    //     0x610f40: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x610f44: r1 = Null
    //     0x610f44: mov             x1, NULL
    // 0x610f48: r2 = 4
    //     0x610f48: movz            x2, #0x4
    // 0x610f4c: stur            x0, [fp, #-0x10]
    // 0x610f50: r0 = AllocateArray()
    //     0x610f50: bl              #0x82746c  ; AllocateArrayStub
    // 0x610f54: mov             x1, x0
    // 0x610f58: ldur            x0, [fp, #-0x10]
    // 0x610f5c: StoreField: r1->field_f = r0
    //     0x610f5c: stur            w0, [x1, #0xf]
    // 0x610f60: r16 = "%"
    //     0x610f60: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] "%"
    // 0x610f64: StoreField: r1->field_13 = r16
    //     0x610f64: stur            w16, [x1, #0x13]
    // 0x610f68: str             x1, [SP]
    // 0x610f6c: r0 = _interpolate()
    //     0x610f6c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x610f70: ldur            x1, [fp, #-8]
    // 0x610f74: ArrayStore: r1[1] = r0  ; List_4
    //     0x610f74: add             x25, x1, #0x13
    //     0x610f78: str             w0, [x25]
    //     0x610f7c: tbz             w0, #0, #0x610f98
    //     0x610f80: ldurb           w16, [x1, #-1]
    //     0x610f84: ldurb           w17, [x0, #-1]
    //     0x610f88: and             x16, x17, x16, lsr #2
    //     0x610f8c: tst             x16, HEAP, lsr #32
    //     0x610f90: b.eq            #0x610f98
    //     0x610f94: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x610f98: ldur            x0, [fp, #-8]
    // 0x610f9c: r16 = "."
    //     0x610f9c: ldr             x16, [PP, #0x108]  ; [pp+0x108] "."
    // 0x610fa0: ArrayStore: r0[0] = r16  ; List_4
    //     0x610fa0: stur            w16, [x0, #0x17]
    // 0x610fa4: str             x0, [SP]
    // 0x610fa8: r0 = _interpolate()
    //     0x610fa8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x610fac: stur            x0, [fp, #-8]
    // 0x610fb0: r0 = Text()
    //     0x610fb0: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x610fb4: ldur            x1, [fp, #-8]
    // 0x610fb8: StoreField: r0->field_b = r1
    //     0x610fb8: stur            w1, [x0, #0xb]
    // 0x610fbc: LeaveFrame
    //     0x610fbc: mov             SP, fp
    //     0x610fc0: ldp             fp, lr, [SP], #0x10
    // 0x610fc4: ret
    //     0x610fc4: ret             
    // 0x610fc8: cmp             x0, #2
    // 0x610fcc: b.gt            #0x610fe4
    // 0x610fd0: r0 = Instance_Text
    //     0x610fd0: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb48] Obj!Text@850a81
    //     0x610fd4: ldr             x0, [x0, #0xb48]
    // 0x610fd8: LeaveFrame
    //     0x610fd8: mov             SP, fp
    //     0x610fdc: ldp             fp, lr, [SP], #0x10
    // 0x610fe0: ret
    //     0x610fe0: ret             
    // 0x610fe4: r0 = Instance_Text
    //     0x610fe4: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb50] Obj!Text@850a31
    //     0x610fe8: ldr             x0, [x0, #0xb50]
    // 0x610fec: LeaveFrame
    //     0x610fec: mov             SP, fp
    //     0x610ff0: ldp             fp, lr, [SP], #0x10
    // 0x610ff4: ret
    //     0x610ff4: ret             
    // 0x610ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610ff8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610ffc: b               #0x610d4c
    // 0x611000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x611000: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, bool) async {
    // ** addr: 0x611030, size: 0x88
    // 0x611030: EnterFrame
    //     0x611030: stp             fp, lr, [SP, #-0x10]!
    //     0x611034: mov             fp, SP
    // 0x611038: AllocStack(0x18)
    //     0x611038: sub             SP, SP, #0x18
    // 0x61103c: SetupParameters(CompleteChapterButtonsState<C3X0> this /* r1 */, dynamic _ /* r3, fp-0x18 */)
    //     0x61103c: stur            NULL, [fp, #-8]
    //     0x611040: movz            x0, #0
    //     0x611044: add             x1, fp, w0, sxtw #2
    //     0x611048: ldr             x1, [x1, #0x18]
    //     0x61104c: add             x3, fp, w0, sxtw #2
    //     0x611050: ldr             x3, [x3, #0x10]
    //     0x611054: stur            x3, [fp, #-0x18]
    //     0x611058: ldur            w2, [x1, #0x17]
    //     0x61105c: add             x2, x2, HEAP, lsl #32
    //     0x611060: stur            x2, [fp, #-0x10]
    // 0x611064: CheckStackOverflow
    //     0x611064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x611068: cmp             SP, x16
    //     0x61106c: b.ls            #0x6110a4
    // 0x611070: InitAsync() -> Future<void?>
    //     0x611070: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x611074: bl              #0x34b9a0  ; InitAsyncStub
    // 0x611078: r0 = LoadStaticField(0xa6c)
    //     0x611078: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x61107c: ldr             x0, [x0, #0x14d8]
    // 0x611080: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x611084: cmp             w0, w16
    // 0x611088: b.eq            #0x6110ac
    // 0x61108c: mov             x1, x0
    // 0x611090: ldur            x3, [fp, #-0x18]
    // 0x611094: r2 = "AutoCompleteChapter"
    //     0x611094: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c960] "AutoCompleteChapter"
    //     0x611098: ldr             x2, [x2, #0x960]
    // 0x61109c: r0 = setBool()
    //     0x61109c: bl              #0x45282c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setBool
    // 0x6110a0: r0 = ReturnAsync()
    //     0x6110a0: b               #0x353380  ; ReturnAsyncStub
    // 0x6110a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6110a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6110a8: b               #0x611070
    // 0x6110ac: r9 = prefs
    //     0x6110ac: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x6110b0: ldr             x9, [x9, #0xc00]
    // 0x6110b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6110b4: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ alertTitle(/* No info */) {
    // ** addr: 0x6110b8, size: 0x5c
    // 0x6110b8: LoadField: r2 = r1->field_b
    //     0x6110b8: ldur            w2, [x1, #0xb]
    // 0x6110bc: DecompressPointer r2
    //     0x6110bc: add             x2, x2, HEAP, lsl #32
    // 0x6110c0: cmp             w2, NULL
    // 0x6110c4: b.eq            #0x611108
    // 0x6110c8: LoadField: r1 = r2->field_1b
    //     0x6110c8: ldur            w1, [x2, #0x1b]
    // 0x6110cc: DecompressPointer r1
    //     0x6110cc: add             x1, x1, HEAP, lsl #32
    // 0x6110d0: LoadField: r2 = r1->field_7
    //     0x6110d0: ldur            x2, [x1, #7]
    // 0x6110d4: cmp             x2, #1
    // 0x6110d8: b.gt            #0x6110fc
    // 0x6110dc: cmp             x2, #0
    // 0x6110e0: b.gt            #0x6110f0
    // 0x6110e4: r0 = "Complete Chapter"
    //     0x6110e4: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb58] "Complete Chapter"
    //     0x6110e8: ldr             x0, [x0, #0xb58]
    // 0x6110ec: ret
    //     0x6110ec: ret             
    // 0x6110f0: r0 = "Reset Chapter\?"
    //     0x6110f0: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb60] "Reset Chapter\?"
    //     0x6110f4: ldr             x0, [x0, #0xb60]
    // 0x6110f8: ret
    //     0x6110f8: ret             
    // 0x6110fc: r0 = "Reset Level\?"
    //     0x6110fc: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cb68] "Reset Level\?"
    //     0x611100: ldr             x0, [x0, #0xb68]
    // 0x611104: ret
    //     0x611104: ret             
    // 0x611108: EnterFrame
    //     0x611108: stp             fp, lr, [SP, #-0x10]!
    //     0x61110c: mov             fp, SP
    // 0x611110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x611110: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x611114, size: 0x98
    // 0x611114: EnterFrame
    //     0x611114: stp             fp, lr, [SP, #-0x10]!
    //     0x611118: mov             fp, SP
    // 0x61111c: AllocStack(0x28)
    //     0x61111c: sub             SP, SP, #0x28
    // 0x611120: SetupParameters(CompleteChapterButtonsState<C3X0> this /* r1 */)
    //     0x611120: stur            NULL, [fp, #-8]
    //     0x611124: movz            x0, #0
    //     0x611128: add             x1, fp, w0, sxtw #2
    //     0x61112c: ldr             x1, [x1, #0x10]
    //     0x611130: ldur            w2, [x1, #0x17]
    //     0x611134: add             x2, x2, HEAP, lsl #32
    //     0x611138: stur            x2, [fp, #-0x10]
    // 0x61113c: CheckStackOverflow
    //     0x61113c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x611140: cmp             SP, x16
    //     0x611144: b.ls            #0x6111a4
    // 0x611148: InitAsync() -> Future<void?>
    //     0x611148: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x61114c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x611150: ldur            x2, [fp, #-0x10]
    // 0x611154: LoadField: r1 = r2->field_f
    //     0x611154: ldur            w1, [x2, #0xf]
    // 0x611158: DecompressPointer r1
    //     0x611158: add             x1, x1, HEAP, lsl #32
    // 0x61115c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61115c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x611160: r0 = of()
    //     0x611160: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x611164: r16 = <Object?>
    //     0x611164: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x611168: stp             x0, x16, [SP]
    // 0x61116c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x61116c: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x611170: r0 = maybePop()
    //     0x611170: bl              #0x3842c0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x611174: ldur            x2, [fp, #-0x10]
    // 0x611178: r1 = Function '<anonymous closure>':.
    //     0x611178: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb28] AnonymousClosure: (0x6111ac), in [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::build (0x6102c0)
    //     0x61117c: ldr             x1, [x1, #0xb28]
    // 0x611180: stur            x0, [fp, #-0x10]
    // 0x611184: r0 = AllocateClosure()
    //     0x611184: bl              #0x826750  ; AllocateClosureStub
    // 0x611188: r16 = <void?>
    //     0x611188: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x61118c: ldur            lr, [fp, #-0x10]
    // 0x611190: stp             lr, x16, [SP, #8]
    // 0x611194: str             x0, [SP]
    // 0x611198: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x611198: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x61119c: r0 = then()
    //     0x61119c: bl              #0x7cc9a0  ; [dart:async] _Future::then
    // 0x6111a0: r0 = ReturnAsync()
    //     0x6111a0: b               #0x353380  ; ReturnAsyncStub
    // 0x6111a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6111a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6111a8: b               #0x611148
  }
  [closure] Null <anonymous closure>(dynamic, bool) {
    // ** addr: 0x6111ac, size: 0x54
    // 0x6111ac: EnterFrame
    //     0x6111ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6111b0: mov             fp, SP
    // 0x6111b4: ldr             x0, [fp, #0x18]
    // 0x6111b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6111b8: ldur            w1, [x0, #0x17]
    // 0x6111bc: DecompressPointer r1
    //     0x6111bc: add             x1, x1, HEAP, lsl #32
    // 0x6111c0: CheckStackOverflow
    //     0x6111c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6111c4: cmp             SP, x16
    //     0x6111c8: b.ls            #0x6111f8
    // 0x6111cc: ldr             x0, [fp, #0x10]
    // 0x6111d0: tbnz            w0, #4, #0x6111e8
    // 0x6111d4: LoadField: r0 = r1->field_b
    //     0x6111d4: ldur            w0, [x1, #0xb]
    // 0x6111d8: DecompressPointer r0
    //     0x6111d8: add             x0, x0, HEAP, lsl #32
    // 0x6111dc: LoadField: r1 = r0->field_f
    //     0x6111dc: ldur            w1, [x0, #0xf]
    // 0x6111e0: DecompressPointer r1
    //     0x6111e0: add             x1, x1, HEAP, lsl #32
    // 0x6111e4: r0 = completeChapterWrapper()
    //     0x6111e4: bl              #0x610814  ; [package:pretentious/widgets/CompleteChapterButtons.dart] CompleteChapterButtonsState::completeChapterWrapper
    // 0x6111e8: r0 = Null
    //     0x6111e8: mov             x0, NULL
    // 0x6111ec: LeaveFrame
    //     0x6111ec: mov             SP, fp
    //     0x6111f0: ldp             fp, lr, [SP], #0x10
    // 0x6111f4: ret
    //     0x6111f4: ret             
    // 0x6111f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6111f8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6111fc: b               #0x6111cc
  }
}

// class id: 4162, size: 0x14, field offset: 0x14
enum ChapterCompleteButtonType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724f88, size: 0x64
    // 0x724f88: EnterFrame
    //     0x724f88: stp             fp, lr, [SP, #-0x10]!
    //     0x724f8c: mov             fp, SP
    // 0x724f90: AllocStack(0x10)
    //     0x724f90: sub             SP, SP, #0x10
    // 0x724f94: SetupParameters(ChapterCompleteButtonType this /* r1 => r0, fp-0x8 */)
    //     0x724f94: mov             x0, x1
    //     0x724f98: stur            x1, [fp, #-8]
    // 0x724f9c: CheckStackOverflow
    //     0x724f9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724fa0: cmp             SP, x16
    //     0x724fa4: b.ls            #0x724fe4
    // 0x724fa8: r1 = Null
    //     0x724fa8: mov             x1, NULL
    // 0x724fac: r2 = 4
    //     0x724fac: movz            x2, #0x4
    // 0x724fb0: r0 = AllocateArray()
    //     0x724fb0: bl              #0x82746c  ; AllocateArrayStub
    // 0x724fb4: r16 = "ChapterCompleteButtonType."
    //     0x724fb4: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a5e0] "ChapterCompleteButtonType."
    //     0x724fb8: ldr             x16, [x16, #0x5e0]
    // 0x724fbc: StoreField: r0->field_f = r16
    //     0x724fbc: stur            w16, [x0, #0xf]
    // 0x724fc0: ldur            x1, [fp, #-8]
    // 0x724fc4: LoadField: r2 = r1->field_f
    //     0x724fc4: ldur            w2, [x1, #0xf]
    // 0x724fc8: DecompressPointer r2
    //     0x724fc8: add             x2, x2, HEAP, lsl #32
    // 0x724fcc: StoreField: r0->field_13 = r2
    //     0x724fcc: stur            w2, [x0, #0x13]
    // 0x724fd0: str             x0, [SP]
    // 0x724fd4: r0 = _interpolate()
    //     0x724fd4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724fd8: LeaveFrame
    //     0x724fd8: mov             SP, fp
    //     0x724fdc: ldp             fp, lr, [SP], #0x10
    // 0x724fe0: ret
    //     0x724fe0: ret             
    // 0x724fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724fe4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724fe8: b               #0x724fa8
  }
}
