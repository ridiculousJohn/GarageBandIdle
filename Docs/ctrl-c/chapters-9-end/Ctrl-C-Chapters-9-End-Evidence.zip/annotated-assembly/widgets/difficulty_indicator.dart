// lib: , url: package:pretentious/widgets/difficulty_indicator.dart

// class id: 1049516, size: 0x8
class :: {

  static _ getReferenceMultiplier(/* No info */) {
    // ** addr: 0x460fc0, size: 0xdc
    // 0x460fc0: EnterFrame
    //     0x460fc0: stp             fp, lr, [SP, #-0x10]!
    //     0x460fc4: mov             fp, SP
    // 0x460fc8: AllocStack(0x8)
    //     0x460fc8: sub             SP, SP, #8
    // 0x460fcc: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x460fcc: mov             x2, x1
    //     0x460fd0: stur            x1, [fp, #-8]
    // 0x460fd4: CheckStackOverflow
    //     0x460fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x460fd8: cmp             SP, x16
    //     0x460fdc: b.ls            #0x461088
    // 0x460fe0: r0 = LoadStaticField(0xf84)
    //     0x460fe0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x460fe4: ldr             x0, [x0, #0x1f08]
    // 0x460fe8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x460fec: cmp             w0, w16
    // 0x460ff0: b.ne            #0x461000
    // 0x460ff4: r2 = referenceDifficulties
    //     0x460ff4: add             x2, PP, #0x10, lsl #12  ; [pp+0x10cd8] Field <::.referenceDifficulties>: static late (offset: 0xf84)
    //     0x460ff8: ldr             x2, [x2, #0xcd8]
    // 0x460ffc: r0 = InitLateStaticField()
    //     0x460ffc: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x461000: mov             x1, x0
    // 0x461004: ldur            x2, [fp, #-8]
    // 0x461008: stur            x0, [fp, #-8]
    // 0x46100c: r0 = _getValueOrData()
    //     0x46100c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x461010: mov             x1, x0
    // 0x461014: ldur            x0, [fp, #-8]
    // 0x461018: LoadField: r2 = r0->field_f
    //     0x461018: ldur            w2, [x0, #0xf]
    // 0x46101c: DecompressPointer r2
    //     0x46101c: add             x2, x2, HEAP, lsl #32
    // 0x461020: cmp             w2, w1
    // 0x461024: b.ne            #0x461030
    // 0x461028: r5 = Null
    //     0x461028: mov             x5, NULL
    // 0x46102c: b               #0x461034
    // 0x461030: mov             x5, x1
    // 0x461034: stur            x5, [fp, #-8]
    // 0x461038: r0 = LoadStaticField(0xf7c)
    //     0x461038: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x46103c: ldr             x0, [x0, #0x1ef8]
    // 0x461040: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x461044: cmp             w0, w16
    // 0x461048: b.eq            #0x461090
    // 0x46104c: mov             x1, x0
    // 0x461050: r2 = Instance_CustomNum
    //     0x461050: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x461054: ldr             x2, [x2, #0xa70]
    // 0x461058: r3 = Null
    //     0x461058: mov             x3, NULL
    // 0x46105c: r0 = cachedCompletionTokenBoost()
    //     0x46105c: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x461060: ldur            x2, [fp, #-8]
    // 0x461064: cmp             w2, NULL
    // 0x461068: b.eq            #0x461078
    // 0x46106c: mov             x1, x0
    // 0x461070: r0 = div()
    //     0x461070: bl              #0x460f80  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::div
    // 0x461074: b               #0x46107c
    // 0x461078: r0 = Null
    //     0x461078: mov             x0, NULL
    // 0x46107c: LeaveFrame
    //     0x46107c: mov             SP, fp
    //     0x461080: ldp             fp, lr, [SP], #0x10
    // 0x461084: ret
    //     0x461084: ret             
    // 0x461088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x461088: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46108c: b               #0x460fe0
    // 0x461090: r9 = coreData
    //     0x461090: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x461094: ldr             x9, [x9, #0x530]
    // 0x461098: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x461098: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ allowDifficultyChoosing(/* No info */) {
    // ** addr: 0x4619e8, size: 0x138
    // 0x4619e8: EnterFrame
    //     0x4619e8: stp             fp, lr, [SP, #-0x10]!
    //     0x4619ec: mov             fp, SP
    // 0x4619f0: AllocStack(0x10)
    //     0x4619f0: sub             SP, SP, #0x10
    // 0x4619f4: SetupParameters(dynamic _ /* r1 => r5, fp-0x8 */)
    //     0x4619f4: mov             x5, x1
    //     0x4619f8: stur            x1, [fp, #-8]
    // 0x4619fc: CheckStackOverflow
    //     0x4619fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x461a00: cmp             SP, x16
    //     0x461a04: b.ls            #0x461b0c
    // 0x461a08: LoadField: r0 = r5->field_7
    //     0x461a08: ldur            w0, [x5, #7]
    // 0x461a0c: r1 = LoadInt32Instr(r0)
    //     0x461a0c: sbfx            x1, x0, #1, #0x1f
    // 0x461a10: cmp             x1, #2
    // 0x461a14: b.le            #0x461a28
    // 0x461a18: r0 = false
    //     0x461a18: add             x0, NULL, #0x30  ; false
    // 0x461a1c: LeaveFrame
    //     0x461a1c: mov             SP, fp
    //     0x461a20: ldp             fp, lr, [SP], #0x10
    // 0x461a24: ret
    //     0x461a24: ret             
    // 0x461a28: r0 = LoadStaticField(0xf7c)
    //     0x461a28: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x461a2c: ldr             x0, [x0, #0x1ef8]
    // 0x461a30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x461a34: cmp             w0, w16
    // 0x461a38: b.eq            #0x461b14
    // 0x461a3c: mov             x1, x0
    // 0x461a40: r2 = Instance_CustomNum
    //     0x461a40: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x461a44: ldr             x2, [x2, #0xa70]
    // 0x461a48: r3 = Null
    //     0x461a48: mov             x3, NULL
    // 0x461a4c: r0 = cachedCompletionTokenBoost()
    //     0x461a4c: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x461a50: mov             x1, x0
    // 0x461a54: r0 = Instance_CustomNum
    //     0x461a54: add             x0, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x461a58: ldr             x0, [x0, #0x448]
    // 0x461a5c: LoadField: d0 = r0->field_7
    //     0x461a5c: ldur            d0, [x0, #7]
    // 0x461a60: LoadField: d1 = r1->field_7
    //     0x461a60: ldur            d1, [x1, #7]
    // 0x461a64: d2 = 0.000000
    //     0x461a64: add             x17, PP, #0x10, lsl #12  ; [pp+0x10d38] IMM: double(1e-14) from 0x3d06849b86a12b9b
    //     0x461a68: ldr             d2, [x17, #0xd38]
    // 0x461a6c: fadd            d3, d1, d2
    // 0x461a70: fcmp            d3, d0
    // 0x461a74: b.lt            #0x461a88
    // 0x461a78: r0 = true
    //     0x461a78: add             x0, NULL, #0x20  ; true
    // 0x461a7c: LeaveFrame
    //     0x461a7c: mov             SP, fp
    //     0x461a80: ldp             fp, lr, [SP], #0x10
    // 0x461a84: ret
    //     0x461a84: ret             
    // 0x461a88: r0 = LoadStaticField(0xf7c)
    //     0x461a88: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x461a8c: ldr             x0, [x0, #0x1ef8]
    // 0x461a90: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x461a90: ldur            w3, [x0, #0x17]
    // 0x461a94: DecompressPointer r3
    //     0x461a94: add             x3, x3, HEAP, lsl #32
    // 0x461a98: mov             x1, x3
    // 0x461a9c: ldur            x2, [fp, #-8]
    // 0x461aa0: stur            x3, [fp, #-0x10]
    // 0x461aa4: r0 = _getValueOrData()
    //     0x461aa4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x461aa8: ldur            x1, [fp, #-0x10]
    // 0x461aac: LoadField: r2 = r1->field_f
    //     0x461aac: ldur            w2, [x1, #0xf]
    // 0x461ab0: DecompressPointer r2
    //     0x461ab0: add             x2, x2, HEAP, lsl #32
    // 0x461ab4: cmp             w2, w0
    // 0x461ab8: b.ne            #0x461ac4
    // 0x461abc: r1 = Null
    //     0x461abc: mov             x1, NULL
    // 0x461ac0: b               #0x461ac8
    // 0x461ac4: mov             x1, x0
    // 0x461ac8: cmp             w1, NULL
    // 0x461acc: b.ne            #0x461ad8
    // 0x461ad0: d1 = 0.000000
    //     0x461ad0: eor             v1.16b, v1.16b, v1.16b
    // 0x461ad4: b               #0x461ae0
    // 0x461ad8: LoadField: d0 = r1->field_7
    //     0x461ad8: ldur            d0, [x1, #7]
    // 0x461adc: mov             v1.16b, v0.16b
    // 0x461ae0: d0 = 0.000000
    //     0x461ae0: eor             v0.16b, v0.16b, v0.16b
    // 0x461ae4: fcmp            d1, d0
    // 0x461ae8: b.ne            #0x461afc
    // 0x461aec: r0 = false
    //     0x461aec: add             x0, NULL, #0x30  ; false
    // 0x461af0: LeaveFrame
    //     0x461af0: mov             SP, fp
    //     0x461af4: ldp             fp, lr, [SP], #0x10
    // 0x461af8: ret
    //     0x461af8: ret             
    // 0x461afc: r0 = true
    //     0x461afc: add             x0, NULL, #0x20  ; true
    // 0x461b00: LeaveFrame
    //     0x461b00: mov             SP, fp
    //     0x461b04: ldp             fp, lr, [SP], #0x10
    // 0x461b08: ret
    //     0x461b08: ret             
    // 0x461b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x461b0c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x461b10: b               #0x461a08
    // 0x461b14: r9 = coreData
    //     0x461b14: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x461b18: ldr             x9, [x9, #0x530]
    // 0x461b1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x461b1c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ difficultyMultiplier(/* No info */) {
    // ** addr: 0x4e9a04, size: 0x50
    // 0x4e9a04: EnterFrame
    //     0x4e9a04: stp             fp, lr, [SP, #-0x10]!
    //     0x4e9a08: mov             fp, SP
    // 0x4e9a0c: mov             x2, x1
    // 0x4e9a10: CheckStackOverflow
    //     0x4e9a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e9a14: cmp             SP, x16
    //     0x4e9a18: b.ls            #0x4e9a4c
    // 0x4e9a1c: r0 = BoxInt64Instr(r2)
    //     0x4e9a1c: sbfiz           x0, x2, #1, #0x1f
    //     0x4e9a20: cmp             x2, x0, asr #1
    //     0x4e9a24: b.eq            #0x4e9a30
    //     0x4e9a28: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e9a2c: stur            x2, [x0, #7]
    // 0x4e9a30: mov             x2, x0
    // 0x4e9a34: r1 = Instance_CustomNum
    //     0x4e9a34: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x4e9a38: ldr             x1, [x1, #0x970]
    // 0x4e9a3c: r0 = pow()
    //     0x4e9a3c: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x4e9a40: LeaveFrame
    //     0x4e9a40: mov             SP, fp
    //     0x4e9a44: ldp             fp, lr, [SP], #0x10
    // 0x4e9a48: ret
    //     0x4e9a48: ret             
    // 0x4e9a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e9a4c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e9a50: b               #0x4e9a1c
  }
  static _ currentChapterDifficultyMultiplier(/* No info */) {
    // ** addr: 0x5a8d6c, size: 0x70
    // 0x5a8d6c: EnterFrame
    //     0x5a8d6c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8d70: mov             fp, SP
    // 0x5a8d74: AllocStack(0x8)
    //     0x5a8d74: sub             SP, SP, #8
    // 0x5a8d78: CheckStackOverflow
    //     0x5a8d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a8d7c: cmp             SP, x16
    //     0x5a8d80: b.ls            #0x5a8dd4
    // 0x5a8d84: r0 = LoadClassIdInstr(r1)
    //     0x5a8d84: ldur            x0, [x1, #-1]
    //     0x5a8d88: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8d8c: sub             x16, x0, #0x10c
    // 0x5a8d90: cmp             x16, #0x11
    // 0x5a8d94: b.hi            #0x5a8db8
    // 0x5a8d98: LoadField: r0 = r1->field_23
    //     0x5a8d98: ldur            x0, [x1, #0x23]
    // 0x5a8d9c: mov             x1, x0
    // 0x5a8da0: r0 = difficultyMultiplier()
    //     0x5a8da0: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x5a8da4: str             x0, [SP]
    // 0x5a8da8: r0 = toString()
    //     0x5a8da8: bl              #0x7196d8  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toString
    // 0x5a8dac: LeaveFrame
    //     0x5a8dac: mov             SP, fp
    //     0x5a8db0: ldp             fp, lr, [SP], #0x10
    // 0x5a8db4: ret
    //     0x5a8db4: ret             
    // 0x5a8db8: r1 = 0
    //     0x5a8db8: movz            x1, #0
    // 0x5a8dbc: r0 = difficultyMultiplier()
    //     0x5a8dbc: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x5a8dc0: str             x0, [SP]
    // 0x5a8dc4: r0 = toString()
    //     0x5a8dc4: bl              #0x7196d8  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toString
    // 0x5a8dc8: LeaveFrame
    //     0x5a8dc8: mov             SP, fp
    //     0x5a8dcc: ldp             fp, lr, [SP], #0x10
    // 0x5a8dd0: ret
    //     0x5a8dd0: ret             
    // 0x5a8dd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8dd4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8dd8: b               #0x5a8d84
  }
}

// class id: 2797, size: 0x18, field offset: 0xc
//   const constructor, 
class AppleNumberPicker extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d95c, size: 0x30
    // 0x72d95c: EnterFrame
    //     0x72d95c: stp             fp, lr, [SP, #-0x10]!
    //     0x72d960: mov             fp, SP
    // 0x72d964: mov             x0, x1
    // 0x72d968: r1 = <AppleNumberPicker>
    //     0x72d968: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2eb18] TypeArguments: <AppleNumberPicker>
    //     0x72d96c: ldr             x1, [x1, #0xb18]
    // 0x72d970: r0 = _AppleNumberPickerState()
    //     0x72d970: bl              #0x72d98c  ; Allocate_AppleNumberPickerStateStub -> _AppleNumberPickerState (size=0x1c)
    // 0x72d974: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x72d978: StoreField: r0->field_13 = r1
    //     0x72d978: stur            w1, [x0, #0x13]
    // 0x72d97c: ArrayStore: r0[0] = r1  ; List_4
    //     0x72d97c: stur            w1, [x0, #0x17]
    // 0x72d980: LeaveFrame
    //     0x72d980: mov             SP, fp
    //     0x72d984: ldp             fp, lr, [SP], #0x10
    // 0x72d988: ret
    //     0x72d988: ret             
  }
}

// class id: 2798, size: 0x14, field offset: 0xc
//   const constructor, 
class DifficultyChooser extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d924, size: 0x2c
    // 0x72d924: EnterFrame
    //     0x72d924: stp             fp, lr, [SP, #-0x10]!
    //     0x72d928: mov             fp, SP
    // 0x72d92c: mov             x0, x1
    // 0x72d930: r1 = <DifficultyChooser>
    //     0x72d930: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2a300] TypeArguments: <DifficultyChooser>
    //     0x72d934: ldr             x1, [x1, #0x300]
    // 0x72d938: r0 = _DifficultyChooserState()
    //     0x72d938: bl              #0x72d950  ; Allocate_DifficultyChooserStateStub -> _DifficultyChooserState (size=0x18)
    // 0x72d93c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x72d940: StoreField: r0->field_13 = r1
    //     0x72d940: stur            w1, [x0, #0x13]
    // 0x72d944: LeaveFrame
    //     0x72d944: mov             SP, fp
    //     0x72d948: ldp             fp, lr, [SP], #0x10
    // 0x72d94c: ret
    //     0x72d94c: ret             
  }
}

// class id: 2799, size: 0x18, field offset: 0xc
//   const constructor, 
class DifficultyIndicator extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d8c0, size: 0x58
    // 0x72d8c0: EnterFrame
    //     0x72d8c0: stp             fp, lr, [SP, #-0x10]!
    //     0x72d8c4: mov             fp, SP
    // 0x72d8c8: AllocStack(0x8)
    //     0x72d8c8: sub             SP, SP, #8
    // 0x72d8cc: CheckStackOverflow
    //     0x72d8cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72d8d0: cmp             SP, x16
    //     0x72d8d4: b.ls            #0x72d910
    // 0x72d8d8: r1 = <DifficultyIndicator>
    //     0x72d8d8: add             x1, PP, #0x25, lsl #12  ; [pp+0x25650] TypeArguments: <DifficultyIndicator>
    //     0x72d8dc: ldr             x1, [x1, #0x650]
    // 0x72d8e0: r0 = _DifficultyIndicatorState()
    //     0x72d8e0: bl              #0x72d918  ; Allocate_DifficultyIndicatorStateStub -> _DifficultyIndicatorState (size=0x20)
    // 0x72d8e4: mov             x2, x0
    // 0x72d8e8: r0 = true
    //     0x72d8e8: add             x0, NULL, #0x20  ; true
    // 0x72d8ec: stur            x2, [fp, #-8]
    // 0x72d8f0: StoreField: r2->field_1b = r0
    //     0x72d8f0: stur            w0, [x2, #0x1b]
    // 0x72d8f4: mov             x1, x2
    // 0x72d8f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72d8f8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72d8fc: r0 = SyncState2()
    //     0x72d8fc: bl              #0x72c088  ; [package:state_groups/src/sync_state.dart] SyncState2::SyncState2
    // 0x72d900: ldur            x0, [fp, #-8]
    // 0x72d904: LeaveFrame
    //     0x72d904: mov             SP, fp
    //     0x72d908: ldp             fp, lr, [SP], #0x10
    // 0x72d90c: ret
    //     0x72d90c: ret             
    // 0x72d910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72d910: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72d914: b               #0x72d8d8
  }
}

// class id: 3246, size: 0x1c, field offset: 0x14
class _AppleNumberPickerState extends State<dynamic> {

  late FixedExtentScrollController controller; // offset: 0x18
  late int _selectedValue; // offset: 0x14

  _ initState(/* No info */) {
    // ** addr: 0x59b19c, size: 0xcc
    // 0x59b19c: EnterFrame
    //     0x59b19c: stp             fp, lr, [SP, #-0x10]!
    //     0x59b1a0: mov             fp, SP
    // 0x59b1a4: AllocStack(0x18)
    //     0x59b1a4: sub             SP, SP, #0x18
    // 0x59b1a8: SetupParameters(_AppleNumberPickerState this /* r1 => r2, fp-0x10 */)
    //     0x59b1a8: mov             x2, x1
    //     0x59b1ac: stur            x1, [fp, #-0x10]
    // 0x59b1b0: CheckStackOverflow
    //     0x59b1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x59b1b4: cmp             SP, x16
    //     0x59b1b8: b.ls            #0x59b25c
    // 0x59b1bc: LoadField: r0 = r2->field_b
    //     0x59b1bc: ldur            w0, [x2, #0xb]
    // 0x59b1c0: DecompressPointer r0
    //     0x59b1c0: add             x0, x0, HEAP, lsl #32
    // 0x59b1c4: cmp             w0, NULL
    // 0x59b1c8: b.eq            #0x59b264
    // 0x59b1cc: LoadField: r3 = r0->field_f
    //     0x59b1cc: ldur            x3, [x0, #0xf]
    // 0x59b1d0: stur            x3, [fp, #-8]
    // 0x59b1d4: r0 = BoxInt64Instr(r3)
    //     0x59b1d4: sbfiz           x0, x3, #1, #0x1f
    //     0x59b1d8: cmp             x3, x0, asr #1
    //     0x59b1dc: b.eq            #0x59b1e8
    //     0x59b1e0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x59b1e4: stur            x3, [x0, #7]
    // 0x59b1e8: StoreField: r2->field_13 = r0
    //     0x59b1e8: stur            w0, [x2, #0x13]
    //     0x59b1ec: tbz             w0, #0, #0x59b208
    //     0x59b1f0: ldurb           w16, [x2, #-1]
    //     0x59b1f4: ldurb           w17, [x0, #-1]
    //     0x59b1f8: and             x16, x17, x16, lsr #2
    //     0x59b1fc: tst             x16, HEAP, lsr #32
    //     0x59b200: b.eq            #0x59b208
    //     0x59b204: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x59b208: r0 = FixedExtentScrollController()
    //     0x59b208: bl              #0x59b288  ; AllocateFixedExtentScrollControllerStub -> FixedExtentScrollController (size=0x48)
    // 0x59b20c: mov             x2, x0
    // 0x59b210: ldur            x0, [fp, #-8]
    // 0x59b214: stur            x2, [fp, #-0x18]
    // 0x59b218: StoreField: r2->field_3f = r0
    //     0x59b218: stur            x0, [x2, #0x3f]
    // 0x59b21c: mov             x1, x2
    // 0x59b220: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x59b220: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x59b224: r0 = ScrollController()
    //     0x59b224: bl              #0x40a2f8  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x59b228: ldur            x0, [fp, #-0x18]
    // 0x59b22c: ldur            x1, [fp, #-0x10]
    // 0x59b230: ArrayStore: r1[0] = r0  ; List_4
    //     0x59b230: stur            w0, [x1, #0x17]
    //     0x59b234: ldurb           w16, [x1, #-1]
    //     0x59b238: ldurb           w17, [x0, #-1]
    //     0x59b23c: and             x16, x17, x16, lsr #2
    //     0x59b240: tst             x16, HEAP, lsr #32
    //     0x59b244: b.eq            #0x59b24c
    //     0x59b248: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x59b24c: r0 = Null
    //     0x59b24c: mov             x0, NULL
    // 0x59b250: LeaveFrame
    //     0x59b250: mov             SP, fp
    //     0x59b254: ldp             fp, lr, [SP], #0x10
    // 0x59b258: ret
    //     0x59b258: ret             
    // 0x59b25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59b25c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59b260: b               #0x59b1bc
    // 0x59b264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x59b264: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x646388, size: 0xb70
    // 0x646388: EnterFrame
    //     0x646388: stp             fp, lr, [SP, #-0x10]!
    //     0x64638c: mov             fp, SP
    // 0x646390: AllocStack(0x78)
    //     0x646390: sub             SP, SP, #0x78
    // 0x646394: SetupParameters(_AppleNumberPickerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x646394: mov             x0, x1
    //     0x646398: stur            x1, [fp, #-8]
    //     0x64639c: mov             x1, x2
    //     0x6463a0: stur            x2, [fp, #-0x10]
    // 0x6463a4: CheckStackOverflow
    //     0x6463a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6463a8: cmp             SP, x16
    //     0x6463ac: b.ls            #0x646e94
    // 0x6463b0: r1 = 1
    //     0x6463b0: movz            x1, #0x1
    // 0x6463b4: r0 = AllocateContext()
    //     0x6463b4: bl              #0x82637c  ; AllocateContextStub
    // 0x6463b8: mov             x2, x0
    // 0x6463bc: ldur            x0, [fp, #-8]
    // 0x6463c0: stur            x2, [fp, #-0x18]
    // 0x6463c4: StoreField: r2->field_f = r0
    //     0x6463c4: stur            w0, [x2, #0xf]
    // 0x6463c8: ldur            x1, [fp, #-0x10]
    // 0x6463cc: r0 = of()
    //     0x6463cc: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x6463d0: LoadField: r1 = r0->field_3b
    //     0x6463d0: ldur            w1, [x0, #0x3b]
    // 0x6463d4: DecompressPointer r1
    //     0x6463d4: add             x1, x1, HEAP, lsl #32
    // 0x6463d8: stur            x1, [fp, #-0x10]
    // 0x6463dc: r0 = Radius()
    //     0x6463dc: bl              #0x352a28  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6463e0: d0 = 10.000000
    //     0x6463e0: fmov            d0, #10.00000000
    // 0x6463e4: stur            x0, [fp, #-0x20]
    // 0x6463e8: StoreField: r0->field_7 = d0
    //     0x6463e8: stur            d0, [x0, #7]
    // 0x6463ec: StoreField: r0->field_f = d0
    //     0x6463ec: stur            d0, [x0, #0xf]
    // 0x6463f0: r0 = BorderRadius()
    //     0x6463f0: bl              #0x3524c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6463f4: mov             x1, x0
    // 0x6463f8: ldur            x0, [fp, #-0x20]
    // 0x6463fc: stur            x1, [fp, #-0x28]
    // 0x646400: StoreField: r1->field_7 = r0
    //     0x646400: stur            w0, [x1, #7]
    // 0x646404: StoreField: r1->field_b = r0
    //     0x646404: stur            w0, [x1, #0xb]
    // 0x646408: StoreField: r1->field_f = r0
    //     0x646408: stur            w0, [x1, #0xf]
    // 0x64640c: StoreField: r1->field_13 = r0
    //     0x64640c: stur            w0, [x1, #0x13]
    // 0x646410: r0 = BoxDecoration()
    //     0x646410: bl              #0x59ff98  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x646414: mov             x3, x0
    // 0x646418: ldur            x0, [fp, #-0x10]
    // 0x64641c: stur            x3, [fp, #-0x20]
    // 0x646420: StoreField: r3->field_7 = r0
    //     0x646420: stur            w0, [x3, #7]
    // 0x646424: ldur            x0, [fp, #-0x28]
    // 0x646428: StoreField: r3->field_13 = r0
    //     0x646428: stur            w0, [x3, #0x13]
    // 0x64642c: r0 = Instance_BoxShape
    //     0x64642c: add             x0, PP, #0x16, lsl #12  ; [pp+0x168d0] Obj!BoxShape@862d01
    //     0x646430: ldr             x0, [x0, #0x8d0]
    // 0x646434: StoreField: r3->field_23 = r0
    //     0x646434: stur            w0, [x3, #0x23]
    // 0x646438: r1 = _ConstMap len:12
    //     0x646438: add             x1, PP, #0xc, lsl #12  ; [pp+0xc488] Map<int, Color>(12)
    //     0x64643c: ldr             x1, [x1, #0x488]
    // 0x646440: r2 = 600
    //     0x646440: movz            x2, #0x258
    // 0x646444: r0 = []()
    //     0x646444: bl              #0x8247ec  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x646448: stur            x0, [fp, #-0x10]
    // 0x64644c: cmp             w0, NULL
    // 0x646450: b.eq            #0x646e9c
    // 0x646454: r0 = BorderSide()
    //     0x646454: bl              #0x4d9cec  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x646458: mov             x3, x0
    // 0x64645c: ldur            x0, [fp, #-0x10]
    // 0x646460: stur            x3, [fp, #-0x28]
    // 0x646464: StoreField: r3->field_7 = r0
    //     0x646464: stur            w0, [x3, #7]
    // 0x646468: d0 = 1.000000
    //     0x646468: fmov            d0, #1.00000000
    // 0x64646c: StoreField: r3->field_b = d0
    //     0x64646c: stur            d0, [x3, #0xb]
    // 0x646470: r0 = Instance_BorderStyle
    //     0x646470: add             x0, PP, #0xd, lsl #12  ; [pp+0xd898] Obj!BorderStyle@862d41
    //     0x646474: ldr             x0, [x0, #0x898]
    // 0x646478: StoreField: r3->field_13 = r0
    //     0x646478: stur            w0, [x3, #0x13]
    // 0x64647c: d1 = -1.000000
    //     0x64647c: fmov            d1, #-1.00000000
    // 0x646480: ArrayStore: r3[0] = d1  ; List_8
    //     0x646480: stur            d1, [x3, #0x17]
    // 0x646484: r1 = _ConstMap len:12
    //     0x646484: add             x1, PP, #0xc, lsl #12  ; [pp+0xc488] Map<int, Color>(12)
    //     0x646488: ldr             x1, [x1, #0x488]
    // 0x64648c: r2 = 600
    //     0x64648c: movz            x2, #0x258
    // 0x646490: r0 = []()
    //     0x646490: bl              #0x8247ec  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x646494: stur            x0, [fp, #-0x10]
    // 0x646498: cmp             w0, NULL
    // 0x64649c: b.eq            #0x646ea0
    // 0x6464a0: r0 = BorderSide()
    //     0x6464a0: bl              #0x4d9cec  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6464a4: mov             x1, x0
    // 0x6464a8: ldur            x0, [fp, #-0x10]
    // 0x6464ac: stur            x1, [fp, #-0x30]
    // 0x6464b0: StoreField: r1->field_7 = r0
    //     0x6464b0: stur            w0, [x1, #7]
    // 0x6464b4: d0 = 1.000000
    //     0x6464b4: fmov            d0, #1.00000000
    // 0x6464b8: StoreField: r1->field_b = d0
    //     0x6464b8: stur            d0, [x1, #0xb]
    // 0x6464bc: r0 = Instance_BorderStyle
    //     0x6464bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd898] Obj!BorderStyle@862d41
    //     0x6464c0: ldr             x0, [x0, #0x898]
    // 0x6464c4: StoreField: r1->field_13 = r0
    //     0x6464c4: stur            w0, [x1, #0x13]
    // 0x6464c8: d1 = -1.000000
    //     0x6464c8: fmov            d1, #-1.00000000
    // 0x6464cc: ArrayStore: r1[0] = d1  ; List_8
    //     0x6464cc: stur            d1, [x1, #0x17]
    // 0x6464d0: r0 = Border()
    //     0x6464d0: bl              #0x4db5dc  ; AllocateBorderStub -> Border (size=0x18)
    // 0x6464d4: mov             x1, x0
    // 0x6464d8: ldur            x0, [fp, #-0x28]
    // 0x6464dc: stur            x1, [fp, #-0x10]
    // 0x6464e0: StoreField: r1->field_7 = r0
    //     0x6464e0: stur            w0, [x1, #7]
    // 0x6464e4: r0 = Instance_BorderSide
    //     0x6464e4: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cee8] Obj!BorderSide@849221
    //     0x6464e8: ldr             x0, [x0, #0xee8]
    // 0x6464ec: StoreField: r1->field_b = r0
    //     0x6464ec: stur            w0, [x1, #0xb]
    // 0x6464f0: ldur            x2, [fp, #-0x30]
    // 0x6464f4: StoreField: r1->field_f = r2
    //     0x6464f4: stur            w2, [x1, #0xf]
    // 0x6464f8: StoreField: r1->field_13 = r0
    //     0x6464f8: stur            w0, [x1, #0x13]
    // 0x6464fc: r0 = BoxDecoration()
    //     0x6464fc: bl              #0x59ff98  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x646500: mov             x1, x0
    // 0x646504: ldur            x0, [fp, #-0x10]
    // 0x646508: stur            x1, [fp, #-0x28]
    // 0x64650c: StoreField: r1->field_f = r0
    //     0x64650c: stur            w0, [x1, #0xf]
    // 0x646510: r0 = Instance_BoxShape
    //     0x646510: add             x0, PP, #0x16, lsl #12  ; [pp+0x168d0] Obj!BoxShape@862d01
    //     0x646514: ldr             x0, [x0, #0x8d0]
    // 0x646518: StoreField: r1->field_23 = r0
    //     0x646518: stur            w0, [x1, #0x23]
    // 0x64651c: r0 = Container()
    //     0x64651c: bl              #0x5b4cec  ; AllocateContainerStub -> Container (size=0x38)
    // 0x646520: stur            x0, [fp, #-0x10]
    // 0x646524: r16 = inf
    //     0x646524: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a830] inf
    //     0x646528: ldr             x16, [x16, #0x830]
    // 0x64652c: r30 = 50.000000
    //     0x64652c: add             lr, PP, #0x31, lsl #12  ; [pp+0x31e30] 50
    //     0x646530: ldr             lr, [lr, #0xe30]
    // 0x646534: stp             lr, x16, [SP, #8]
    // 0x646538: ldur            x16, [fp, #-0x28]
    // 0x64653c: str             x16, [SP]
    // 0x646540: mov             x1, x0
    // 0x646544: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x646544: add             x4, PP, #0x31, lsl #12  ; [pp+0x31e38] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x646548: ldr             x4, [x4, #0xe38]
    // 0x64654c: r0 = Container()
    //     0x64654c: bl              #0x5b4840  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x646550: ldur            x0, [fp, #-8]
    // 0x646554: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x646554: ldur            w3, [x0, #0x17]
    // 0x646558: DecompressPointer r3
    //     0x646558: add             x3, x3, HEAP, lsl #32
    // 0x64655c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x646560: cmp             w3, w16
    // 0x646564: b.eq            #0x646ea4
    // 0x646568: ldur            x2, [fp, #-0x18]
    // 0x64656c: stur            x3, [fp, #-0x28]
    // 0x646570: r1 = Function '<anonymous closure>':.
    //     0x646570: add             x1, PP, #0x31, lsl #12  ; [pp+0x31e40] AnonymousClosure: (0x6474a4), in [package:pretentious/widgets/difficulty_indicator.dart] _AppleNumberPickerState::build (0x646388)
    //     0x646574: ldr             x1, [x1, #0xe40]
    // 0x646578: r0 = AllocateClosure()
    //     0x646578: bl              #0x826750  ; AllocateClosureStub
    // 0x64657c: stur            x0, [fp, #-0x30]
    // 0x646580: r0 = ListWheelChildBuilderDelegate()
    //     0x646580: bl              #0x646f04  ; AllocateListWheelChildBuilderDelegateStub -> ListWheelChildBuilderDelegate (size=0x14)
    // 0x646584: mov             x1, x0
    // 0x646588: ldur            x0, [fp, #-0x30]
    // 0x64658c: stur            x1, [fp, #-0x38]
    // 0x646590: StoreField: r1->field_7 = r0
    //     0x646590: stur            w0, [x1, #7]
    // 0x646594: r0 = 86
    //     0x646594: movz            x0, #0x56
    // 0x646598: StoreField: r1->field_b = r0
    //     0x646598: stur            x0, [x1, #0xb]
    // 0x64659c: r0 = ListWheelScrollView()
    //     0x64659c: bl              #0x646ef8  ; AllocateListWheelScrollViewStub -> ListWheelScrollView (size=0x74)
    // 0x6465a0: mov             x3, x0
    // 0x6465a4: ldur            x0, [fp, #-0x28]
    // 0x6465a8: stur            x3, [fp, #-0x30]
    // 0x6465ac: StoreField: r3->field_b = r0
    //     0x6465ac: stur            w0, [x3, #0xb]
    // 0x6465b0: r0 = Instance_FixedExtentScrollPhysics
    //     0x6465b0: add             x0, PP, #0x31, lsl #12  ; [pp+0x31e48] Obj!FixedExtentScrollPhysics@830b91
    //     0x6465b4: ldr             x0, [x0, #0xe48]
    // 0x6465b8: StoreField: r3->field_f = r0
    //     0x6465b8: stur            w0, [x3, #0xf]
    // 0x6465bc: d0 = 1.200000
    //     0x6465bc: add             x17, PP, #0x15, lsl #12  ; [pp+0x15008] IMM: double(1.2) from 0x3ff3333333333333
    //     0x6465c0: ldr             d0, [x17, #8]
    // 0x6465c4: StoreField: r3->field_13 = d0
    //     0x6465c4: stur            d0, [x3, #0x13]
    // 0x6465c8: d0 = 0.001000
    //     0x6465c8: ldr             d0, [PP, #0x7490]  ; [pp+0x7490] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0x6465cc: StoreField: r3->field_1b = d0
    //     0x6465cc: stur            d0, [x3, #0x1b]
    // 0x6465d0: StoreField: r3->field_23 = rZR
    //     0x6465d0: stur            xzr, [x3, #0x23]
    // 0x6465d4: r0 = false
    //     0x6465d4: add             x0, NULL, #0x30  ; false
    // 0x6465d8: StoreField: r3->field_2b = r0
    //     0x6465d8: stur            w0, [x3, #0x2b]
    // 0x6465dc: d0 = 1.000000
    //     0x6465dc: fmov            d0, #1.00000000
    // 0x6465e0: StoreField: r3->field_2f = d0
    //     0x6465e0: stur            d0, [x3, #0x2f]
    // 0x6465e4: StoreField: r3->field_37 = d0
    //     0x6465e4: stur            d0, [x3, #0x37]
    // 0x6465e8: d1 = 50.000000
    //     0x6465e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(50) from 0x4049000000000000
    //     0x6465ec: ldr             d1, [x17, #0xf58]
    // 0x6465f0: StoreField: r3->field_3f = d1
    //     0x6465f0: stur            d1, [x3, #0x3f]
    // 0x6465f4: StoreField: r3->field_47 = d0
    //     0x6465f4: stur            d0, [x3, #0x47]
    // 0x6465f8: ldur            x2, [fp, #-0x18]
    // 0x6465fc: r1 = Function '<anonymous closure>':.
    //     0x6465fc: add             x1, PP, #0x31, lsl #12  ; [pp+0x31e50] AnonymousClosure: (0x647370), in [package:pretentious/widgets/difficulty_indicator.dart] _AppleNumberPickerState::build (0x646388)
    //     0x646600: ldr             x1, [x1, #0xe50]
    // 0x646604: r0 = AllocateClosure()
    //     0x646604: bl              #0x826750  ; AllocateClosureStub
    // 0x646608: mov             x1, x0
    // 0x64660c: ldur            x0, [fp, #-0x30]
    // 0x646610: StoreField: r0->field_4f = r1
    //     0x646610: stur            w1, [x0, #0x4f]
    // 0x646614: r1 = false
    //     0x646614: add             x1, NULL, #0x30  ; false
    // 0x646618: StoreField: r0->field_53 = r1
    //     0x646618: stur            w1, [x0, #0x53]
    // 0x64661c: r1 = Instance_Clip
    //     0x64661c: add             x1, PP, #0x16, lsl #12  ; [pp+0x168b0] Obj!Clip@865de1
    //     0x646620: ldr             x1, [x1, #0x8b0]
    // 0x646624: StoreField: r0->field_5b = r1
    //     0x646624: stur            w1, [x0, #0x5b]
    // 0x646628: r1 = Instance_HitTestBehavior
    //     0x646628: add             x1, PP, #0xc, lsl #12  ; [pp+0xc9a8] Obj!HitTestBehavior@8628c1
    //     0x64662c: ldr             x1, [x1, #0x9a8]
    // 0x646630: StoreField: r0->field_5f = r1
    //     0x646630: stur            w1, [x0, #0x5f]
    // 0x646634: r1 = Instance_DragStartBehavior
    //     0x646634: ldr             x1, [PP, #0x70b0]  ; [pp+0x70b0] Obj!DragStartBehavior@863b61
    // 0x646638: StoreField: r0->field_6b = r1
    //     0x646638: stur            w1, [x0, #0x6b]
    // 0x64663c: r1 = Instance_ChangeReportingBehavior
    //     0x64663c: add             x1, PP, #0x31, lsl #12  ; [pp+0x31e58] Obj!ChangeReportingBehavior@8619a1
    //     0x646640: ldr             x1, [x1, #0xe58]
    // 0x646644: StoreField: r0->field_6f = r1
    //     0x646644: stur            w1, [x0, #0x6f]
    // 0x646648: ldur            x1, [fp, #-0x38]
    // 0x64664c: StoreField: r0->field_57 = r1
    //     0x64664c: stur            w1, [x0, #0x57]
    // 0x646650: r1 = Null
    //     0x646650: mov             x1, NULL
    // 0x646654: r2 = 4
    //     0x646654: movz            x2, #0x4
    // 0x646658: r0 = AllocateArray()
    //     0x646658: bl              #0x82746c  ; AllocateArrayStub
    // 0x64665c: mov             x2, x0
    // 0x646660: ldur            x0, [fp, #-0x10]
    // 0x646664: stur            x2, [fp, #-0x28]
    // 0x646668: StoreField: r2->field_f = r0
    //     0x646668: stur            w0, [x2, #0xf]
    // 0x64666c: ldur            x0, [fp, #-0x30]
    // 0x646670: StoreField: r2->field_13 = r0
    //     0x646670: stur            w0, [x2, #0x13]
    // 0x646674: r1 = <Widget>
    //     0x646674: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x646678: r0 = AllocateGrowableArray()
    //     0x646678: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x64667c: mov             x1, x0
    // 0x646680: ldur            x0, [fp, #-0x28]
    // 0x646684: stur            x1, [fp, #-0x10]
    // 0x646688: StoreField: r1->field_f = r0
    //     0x646688: stur            w0, [x1, #0xf]
    // 0x64668c: r0 = 4
    //     0x64668c: movz            x0, #0x4
    // 0x646690: StoreField: r1->field_b = r0
    //     0x646690: stur            w0, [x1, #0xb]
    // 0x646694: r0 = Stack()
    //     0x646694: bl              #0x5a05b0  ; AllocateStackStub -> Stack (size=0x20)
    // 0x646698: mov             x1, x0
    // 0x64669c: r0 = Instance_Alignment
    //     0x64669c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe258] Obj!Alignment@833251
    //     0x6466a0: ldr             x0, [x0, #0x258]
    // 0x6466a4: stur            x1, [fp, #-0x28]
    // 0x6466a8: StoreField: r1->field_f = r0
    //     0x6466a8: stur            w0, [x1, #0xf]
    // 0x6466ac: r0 = Instance_StackFit
    //     0x6466ac: add             x0, PP, #0x16, lsl #12  ; [pp+0x168f8] Obj!StackFit@8627c1
    //     0x6466b0: ldr             x0, [x0, #0x8f8]
    // 0x6466b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x6466b4: stur            w0, [x1, #0x17]
    // 0x6466b8: r0 = Instance_Clip
    //     0x6466b8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x6466bc: ldr             x0, [x0, #0x900]
    // 0x6466c0: StoreField: r1->field_1b = r0
    //     0x6466c0: stur            w0, [x1, #0x1b]
    // 0x6466c4: ldur            x0, [fp, #-0x10]
    // 0x6466c8: StoreField: r1->field_b = r0
    //     0x6466c8: stur            w0, [x1, #0xb]
    // 0x6466cc: r0 = Container()
    //     0x6466cc: bl              #0x5b4cec  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6466d0: stur            x0, [fp, #-0x10]
    // 0x6466d4: r16 = 250.000000
    //     0x6466d4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dec0] 250
    //     0x6466d8: ldr             x16, [x16, #0xec0]
    // 0x6466dc: ldur            lr, [fp, #-0x20]
    // 0x6466e0: stp             lr, x16, [SP, #8]
    // 0x6466e4: ldur            x16, [fp, #-0x28]
    // 0x6466e8: str             x16, [SP]
    // 0x6466ec: mov             x1, x0
    // 0x6466f0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x6466f0: add             x4, PP, #0x31, lsl #12  ; [pp+0x31e60] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x6466f4: ldr             x4, [x4, #0xe60]
    // 0x6466f8: r0 = Container()
    //     0x6466f8: bl              #0x5b4840  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6466fc: ldur            x3, [fp, #-8]
    // 0x646700: LoadField: r4 = r3->field_13
    //     0x646700: ldur            w4, [x3, #0x13]
    // 0x646704: DecompressPointer r4
    //     0x646704: add             x4, x4, HEAP, lsl #32
    // 0x646708: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x64670c: cmp             w4, w16
    // 0x646710: b.eq            #0x646eb0
    // 0x646714: stur            x4, [fp, #-0x30]
    // 0x646718: r2 = LoadInt32Instr(r4)
    //     0x646718: sbfx            x2, x4, #1, #0x1f
    //     0x64671c: tbz             w4, #0, #0x646724
    //     0x646720: ldur            x2, [x4, #7]
    // 0x646724: cmp             x2, #0
    // 0x646728: b.le            #0x64674c
    // 0x64672c: sub             x5, x2, #1
    // 0x646730: r0 = BoxInt64Instr(r5)
    //     0x646730: sbfiz           x0, x5, #1, #0x1f
    //     0x646734: cmp             x5, x0, asr #1
    //     0x646738: b.eq            #0x646744
    //     0x64673c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x646740: stur            x5, [x0, #7]
    // 0x646744: mov             x5, x0
    // 0x646748: b               #0x646750
    // 0x64674c: r5 = Null
    //     0x64674c: mov             x5, NULL
    // 0x646750: stur            x5, [fp, #-0x28]
    // 0x646754: cmp             x2, #0x55
    // 0x646758: b.ge            #0x646778
    // 0x64675c: add             x6, x2, #1
    // 0x646760: r0 = BoxInt64Instr(r6)
    //     0x646760: sbfiz           x0, x6, #1, #0x1f
    //     0x646764: cmp             x6, x0, asr #1
    //     0x646768: b.eq            #0x646774
    //     0x64676c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x646770: stur            x6, [x0, #7]
    // 0x646774: b               #0x64677c
    // 0x646778: r0 = Null
    //     0x646778: mov             x0, NULL
    // 0x64677c: stur            x0, [fp, #-0x20]
    // 0x646780: r1 = Null
    //     0x646780: mov             x1, NULL
    // 0x646784: r2 = 10
    //     0x646784: movz            x2, #0xa
    // 0x646788: r0 = AllocateArray()
    //     0x646788: bl              #0x82746c  ; AllocateArrayStub
    // 0x64678c: stur            x0, [fp, #-0x38]
    // 0x646790: r16 = "Current selection: "
    //     0x646790: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e68] "Current selection: "
    //     0x646794: ldr             x16, [x16, #0xe68]
    // 0x646798: StoreField: r0->field_f = r16
    //     0x646798: stur            w16, [x0, #0xf]
    // 0x64679c: ldur            x2, [fp, #-0x30]
    // 0x6467a0: r1 = Instance_CustomNum
    //     0x6467a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x6467a4: ldr             x1, [x1, #0x970]
    // 0x6467a8: r0 = pow()
    //     0x6467a8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6467ac: ldur            x1, [fp, #-0x38]
    // 0x6467b0: ArrayStore: r1[1] = r0  ; List_4
    //     0x6467b0: add             x25, x1, #0x13
    //     0x6467b4: str             w0, [x25]
    //     0x6467b8: tbz             w0, #0, #0x6467d4
    //     0x6467bc: ldurb           w16, [x1, #-1]
    //     0x6467c0: ldurb           w17, [x0, #-1]
    //     0x6467c4: and             x16, x17, x16, lsr #2
    //     0x6467c8: tst             x16, HEAP, lsr #32
    //     0x6467cc: b.eq            #0x6467d4
    //     0x6467d0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6467d4: ldur            x1, [fp, #-0x38]
    // 0x6467d8: r16 = " difficulty, "
    //     0x6467d8: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e70] " difficulty, "
    //     0x6467dc: ldr             x16, [x16, #0xe70]
    // 0x6467e0: ArrayStore: r1[0] = r16  ; List_4
    //     0x6467e0: stur            w16, [x1, #0x17]
    // 0x6467e4: ldur            x0, [fp, #-8]
    // 0x6467e8: LoadField: r2 = r0->field_13
    //     0x6467e8: ldur            w2, [x0, #0x13]
    // 0x6467ec: DecompressPointer r2
    //     0x6467ec: add             x2, x2, HEAP, lsl #32
    // 0x6467f0: r0 = LoadInt32Instr(r2)
    //     0x6467f0: sbfx            x0, x2, #1, #0x1f
    //     0x6467f4: tbz             w2, #0, #0x6467fc
    //     0x6467f8: ldur            x0, [x2, #7]
    // 0x6467fc: scvtf           d0, x0
    // 0x646800: d1 = 0.100000
    //     0x646800: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x646804: ldr             d1, [x17, #0xc30]
    // 0x646808: fmul            d2, d0, d1
    // 0x64680c: d0 = 1.000000
    //     0x64680c: fmov            d0, #1.00000000
    // 0x646810: fadd            d3, d2, d0
    // 0x646814: stur            d3, [fp, #-0x48]
    // 0x646818: r0 = 60
    //     0x646818: movz            x0, #0x3c
    // 0x64681c: branchIfSmi(r2, 0x646828)
    //     0x64681c: tbz             w2, #0, #0x646828
    // 0x646820: r0 = LoadClassIdInstr(r2)
    //     0x646820: ldur            x0, [x2, #-1]
    //     0x646824: ubfx            x0, x0, #0xc, #0x14
    // 0x646828: str             x2, [SP]
    // 0x64682c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x64682c: sub             lr, x0, #1, lsl #12
    //     0x646830: ldr             lr, [x21, lr, lsl #3]
    //     0x646834: blr             lr
    // 0x646838: LoadField: d0 = r0->field_7
    //     0x646838: ldur            d0, [x0, #7]
    // 0x64683c: d1 = 1.500000
    //     0x64683c: fmov            d1, #1.50000000
    // 0x646840: d30 = 0.000000
    //     0x646840: fmov            d30, d0
    // 0x646844: d0 = 1.000000
    //     0x646844: fmov            d0, #1.00000000
    // 0x646848: fcmp            d1, #0.0
    // 0x64684c: b.vs            #0x646890
    // 0x646850: b.eq            #0x646918
    // 0x646854: fcmp            d1, d0
    // 0x646858: b.eq            #0x646880
    // 0x64685c: d31 = 2.000000
    //     0x64685c: fmov            d31, #2.00000000
    // 0x646860: fcmp            d1, d31
    // 0x646864: b.eq            #0x646888
    // 0x646868: d31 = 3.000000
    //     0x646868: fmov            d31, #3.00000000
    // 0x64686c: fcmp            d1, d31
    // 0x646870: b.ne            #0x646890
    // 0x646874: fmul            d0, d30, d30
    // 0x646878: fmul            d0, d0, d30
    // 0x64687c: b               #0x646918
    // 0x646880: d0 = 0.000000
    //     0x646880: fmov            d0, d30
    // 0x646884: b               #0x646918
    // 0x646888: fmul            d0, d30, d30
    // 0x64688c: b               #0x646918
    // 0x646890: fcmp            d30, d0
    // 0x646894: b.vs            #0x6468a4
    // 0x646898: b.eq            #0x646918
    // 0x64689c: fcmp            d30, d1
    // 0x6468a0: b.vc            #0x6468b0
    // 0x6468a4: d0 = nan
    //     0x6468a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x6468a8: ldr             d0, [x17, #0xe48]
    // 0x6468ac: b               #0x646918
    // 0x6468b0: d0 = -inf
    //     0x6468b0: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x6468b4: fcmp            d30, d0
    // 0x6468b8: b.eq            #0x6468e0
    // 0x6468bc: d0 = 0.500000
    //     0x6468bc: fmov            d0, #0.50000000
    // 0x6468c0: fcmp            d1, d0
    // 0x6468c4: b.ne            #0x6468e0
    // 0x6468c8: fcmp            d30, #0.0
    // 0x6468cc: b.eq            #0x6468d8
    // 0x6468d0: fsqrt           d0, d30
    // 0x6468d4: b               #0x646918
    // 0x6468d8: d0 = 0.000000
    //     0x6468d8: eor             v0.16b, v0.16b, v0.16b
    // 0x6468dc: b               #0x646918
    // 0x6468e0: d0 = 0.000000
    //     0x6468e0: fmov            d0, d30
    // 0x6468e4: stp             fp, lr, [SP, #-0x10]!
    // 0x6468e8: mov             fp, SP
    // 0x6468ec: CallRuntime_LibcPow(double, double) -> double
    //     0x6468ec: and             SP, SP, #0xfffffffffffffff0
    //     0x6468f0: mov             sp, SP
    //     0x6468f4: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x6468f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6468fc: blr             x16
    //     0x646900: movz            x16, #0x8
    //     0x646904: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x646908: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x64690c: sub             sp, x16, #1, lsl #12
    //     0x646910: mov             SP, fp
    //     0x646914: ldp             fp, lr, [SP], #0x10
    // 0x646918: mov             v1.16b, v0.16b
    // 0x64691c: d0 = 0.012000
    //     0x64691c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26378] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0x646920: ldr             d0, [x17, #0x378]
    // 0x646924: fmul            d2, d1, d0
    // 0x646928: ldur            d1, [fp, #-0x48]
    // 0x64692c: fadd            d3, d1, d2
    // 0x646930: r1 = inline_Allocate_Double()
    //     0x646930: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x646934: add             x1, x1, #0x10
    //     0x646938: cmp             x0, x1
    //     0x64693c: b.ls            #0x646ebc
    //     0x646940: str             x1, [THR, #0x60]  ; THR::top
    //     0x646944: sub             x1, x1, #0xf
    //     0x646948: movz            x0, #0xe19c
    //     0x64694c: movk            x0, #0x3, lsl #16
    //     0x646950: stur            x0, [x1, #-1]
    // 0x646954: dmb             ishst
    // 0x646958: StoreField: r1->field_7 = d3
    //     0x646958: stur            d3, [x1, #7]
    // 0x64695c: r2 = 2
    //     0x64695c: movz            x2, #0x2
    // 0x646960: r0 = toStringAsFixed()
    //     0x646960: bl              #0x824944  ; [dart:core] _Double::toStringAsFixed
    // 0x646964: ldur            x1, [fp, #-0x38]
    // 0x646968: ArrayStore: r1[3] = r0  ; List_4
    //     0x646968: add             x25, x1, #0x1b
    //     0x64696c: str             w0, [x25]
    //     0x646970: tbz             w0, #0, #0x64698c
    //     0x646974: ldurb           w16, [x1, #-1]
    //     0x646978: ldurb           w17, [x0, #-1]
    //     0x64697c: and             x16, x17, x16, lsr #2
    //     0x646980: tst             x16, HEAP, lsr #32
    //     0x646984: b.eq            #0x64698c
    //     0x646988: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x64698c: ldur            x0, [fp, #-0x38]
    // 0x646990: r16 = " token multiplier."
    //     0x646990: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e78] " token multiplier."
    //     0x646994: ldr             x16, [x16, #0xe78]
    // 0x646998: StoreField: r0->field_1f = r16
    //     0x646998: stur            w16, [x0, #0x1f]
    // 0x64699c: str             x0, [SP]
    // 0x6469a0: r0 = _interpolate()
    //     0x6469a0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6469a4: mov             x3, x0
    // 0x6469a8: ldur            x0, [fp, #-0x20]
    // 0x6469ac: stur            x3, [fp, #-8]
    // 0x6469b0: cmp             w0, NULL
    // 0x6469b4: b.eq            #0x646bb4
    // 0x6469b8: mov             x2, x0
    // 0x6469bc: r1 = Instance_CustomNum
    //     0x6469bc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x6469c0: ldr             x1, [x1, #0x970]
    // 0x6469c4: r0 = pow()
    //     0x6469c4: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x6469c8: r1 = Null
    //     0x6469c8: mov             x1, NULL
    // 0x6469cc: r2 = 8
    //     0x6469cc: movz            x2, #0x8
    // 0x6469d0: stur            x0, [fp, #-0x30]
    // 0x6469d4: r0 = AllocateArray()
    //     0x6469d4: bl              #0x82746c  ; AllocateArrayStub
    // 0x6469d8: mov             x1, x0
    // 0x6469dc: ldur            x0, [fp, #-0x30]
    // 0x6469e0: stur            x1, [fp, #-0x38]
    // 0x6469e4: StoreField: r1->field_f = r0
    //     0x6469e4: stur            w0, [x1, #0xf]
    // 0x6469e8: r16 = "x difficulty, "
    //     0x6469e8: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e80] "x difficulty, "
    //     0x6469ec: ldr             x16, [x16, #0xe80]
    // 0x6469f0: StoreField: r1->field_13 = r16
    //     0x6469f0: stur            w16, [x1, #0x13]
    // 0x6469f4: ldur            x2, [fp, #-0x20]
    // 0x6469f8: r0 = LoadInt32Instr(r2)
    //     0x6469f8: sbfx            x0, x2, #1, #0x1f
    //     0x6469fc: tbz             w2, #0, #0x646a04
    //     0x646a00: ldur            x0, [x2, #7]
    // 0x646a04: scvtf           d0, x0
    // 0x646a08: d1 = 0.100000
    //     0x646a08: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x646a0c: ldr             d1, [x17, #0xc30]
    // 0x646a10: fmul            d2, d0, d1
    // 0x646a14: d0 = 1.000000
    //     0x646a14: fmov            d0, #1.00000000
    // 0x646a18: fadd            d3, d2, d0
    // 0x646a1c: stur            d3, [fp, #-0x48]
    // 0x646a20: r0 = 60
    //     0x646a20: movz            x0, #0x3c
    // 0x646a24: branchIfSmi(r2, 0x646a30)
    //     0x646a24: tbz             w2, #0, #0x646a30
    // 0x646a28: r0 = LoadClassIdInstr(r2)
    //     0x646a28: ldur            x0, [x2, #-1]
    //     0x646a2c: ubfx            x0, x0, #0xc, #0x14
    // 0x646a30: str             x2, [SP]
    // 0x646a34: r0 = GDT[cid_x0 + -0x1000]()
    //     0x646a34: sub             lr, x0, #1, lsl #12
    //     0x646a38: ldr             lr, [x21, lr, lsl #3]
    //     0x646a3c: blr             lr
    // 0x646a40: LoadField: d0 = r0->field_7
    //     0x646a40: ldur            d0, [x0, #7]
    // 0x646a44: d1 = 1.500000
    //     0x646a44: fmov            d1, #1.50000000
    // 0x646a48: d30 = 0.000000
    //     0x646a48: fmov            d30, d0
    // 0x646a4c: d0 = 1.000000
    //     0x646a4c: fmov            d0, #1.00000000
    // 0x646a50: fcmp            d1, #0.0
    // 0x646a54: b.vs            #0x646a98
    // 0x646a58: b.eq            #0x646b20
    // 0x646a5c: fcmp            d1, d0
    // 0x646a60: b.eq            #0x646a88
    // 0x646a64: d31 = 2.000000
    //     0x646a64: fmov            d31, #2.00000000
    // 0x646a68: fcmp            d1, d31
    // 0x646a6c: b.eq            #0x646a90
    // 0x646a70: d31 = 3.000000
    //     0x646a70: fmov            d31, #3.00000000
    // 0x646a74: fcmp            d1, d31
    // 0x646a78: b.ne            #0x646a98
    // 0x646a7c: fmul            d0, d30, d30
    // 0x646a80: fmul            d0, d0, d30
    // 0x646a84: b               #0x646b20
    // 0x646a88: d0 = 0.000000
    //     0x646a88: fmov            d0, d30
    // 0x646a8c: b               #0x646b20
    // 0x646a90: fmul            d0, d30, d30
    // 0x646a94: b               #0x646b20
    // 0x646a98: fcmp            d30, d0
    // 0x646a9c: b.vs            #0x646aac
    // 0x646aa0: b.eq            #0x646b20
    // 0x646aa4: fcmp            d30, d1
    // 0x646aa8: b.vc            #0x646ab8
    // 0x646aac: d0 = nan
    //     0x646aac: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x646ab0: ldr             d0, [x17, #0xe48]
    // 0x646ab4: b               #0x646b20
    // 0x646ab8: d0 = -inf
    //     0x646ab8: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x646abc: fcmp            d30, d0
    // 0x646ac0: b.eq            #0x646ae8
    // 0x646ac4: d0 = 0.500000
    //     0x646ac4: fmov            d0, #0.50000000
    // 0x646ac8: fcmp            d1, d0
    // 0x646acc: b.ne            #0x646ae8
    // 0x646ad0: fcmp            d30, #0.0
    // 0x646ad4: b.eq            #0x646ae0
    // 0x646ad8: fsqrt           d0, d30
    // 0x646adc: b               #0x646b20
    // 0x646ae0: d0 = 0.000000
    //     0x646ae0: eor             v0.16b, v0.16b, v0.16b
    // 0x646ae4: b               #0x646b20
    // 0x646ae8: d0 = 0.000000
    //     0x646ae8: fmov            d0, d30
    // 0x646aec: stp             fp, lr, [SP, #-0x10]!
    // 0x646af0: mov             fp, SP
    // 0x646af4: CallRuntime_LibcPow(double, double) -> double
    //     0x646af4: and             SP, SP, #0xfffffffffffffff0
    //     0x646af8: mov             sp, SP
    //     0x646afc: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x646b00: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x646b04: blr             x16
    //     0x646b08: movz            x16, #0x8
    //     0x646b0c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x646b10: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x646b14: sub             sp, x16, #1, lsl #12
    //     0x646b18: mov             SP, fp
    //     0x646b1c: ldp             fp, lr, [SP], #0x10
    // 0x646b20: mov             v1.16b, v0.16b
    // 0x646b24: d0 = 0.012000
    //     0x646b24: add             x17, PP, #0x26, lsl #12  ; [pp+0x26378] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0x646b28: ldr             d0, [x17, #0x378]
    // 0x646b2c: fmul            d2, d1, d0
    // 0x646b30: ldur            d1, [fp, #-0x48]
    // 0x646b34: fadd            d3, d1, d2
    // 0x646b38: r1 = inline_Allocate_Double()
    //     0x646b38: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x646b3c: add             x1, x1, #0x10
    //     0x646b40: cmp             x0, x1
    //     0x646b44: b.ls            #0x646ed0
    //     0x646b48: str             x1, [THR, #0x60]  ; THR::top
    //     0x646b4c: sub             x1, x1, #0xf
    //     0x646b50: movz            x0, #0xe19c
    //     0x646b54: movk            x0, #0x3, lsl #16
    //     0x646b58: stur            x0, [x1, #-1]
    // 0x646b5c: dmb             ishst
    // 0x646b60: StoreField: r1->field_7 = d3
    //     0x646b60: stur            d3, [x1, #7]
    // 0x646b64: r2 = 2
    //     0x646b64: movz            x2, #0x2
    // 0x646b68: r0 = toStringAsFixed()
    //     0x646b68: bl              #0x824944  ; [dart:core] _Double::toStringAsFixed
    // 0x646b6c: ldur            x1, [fp, #-0x38]
    // 0x646b70: ArrayStore: r1[2] = r0  ; List_4
    //     0x646b70: add             x25, x1, #0x17
    //     0x646b74: str             w0, [x25]
    //     0x646b78: tbz             w0, #0, #0x646b94
    //     0x646b7c: ldurb           w16, [x1, #-1]
    //     0x646b80: ldurb           w17, [x0, #-1]
    //     0x646b84: and             x16, x17, x16, lsr #2
    //     0x646b88: tst             x16, HEAP, lsr #32
    //     0x646b8c: b.eq            #0x646b94
    //     0x646b90: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x646b94: ldur            x0, [fp, #-0x38]
    // 0x646b98: r16 = " tokens"
    //     0x646b98: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e88] " tokens"
    //     0x646b9c: ldr             x16, [x16, #0xe88]
    // 0x646ba0: StoreField: r0->field_1b = r16
    //     0x646ba0: stur            w16, [x0, #0x1b]
    // 0x646ba4: str             x0, [SP]
    // 0x646ba8: r0 = _interpolate()
    //     0x646ba8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x646bac: mov             x3, x0
    // 0x646bb0: b               #0x646bb8
    // 0x646bb4: r3 = Null
    //     0x646bb4: mov             x3, NULL
    // 0x646bb8: ldur            x0, [fp, #-0x28]
    // 0x646bbc: stur            x3, [fp, #-0x30]
    // 0x646bc0: cmp             w0, NULL
    // 0x646bc4: b.eq            #0x646dc4
    // 0x646bc8: mov             x2, x0
    // 0x646bcc: r1 = Instance_CustomNum
    //     0x646bcc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x646bd0: ldr             x1, [x1, #0x970]
    // 0x646bd4: r0 = pow()
    //     0x646bd4: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x646bd8: r1 = Null
    //     0x646bd8: mov             x1, NULL
    // 0x646bdc: r2 = 8
    //     0x646bdc: movz            x2, #0x8
    // 0x646be0: stur            x0, [fp, #-0x38]
    // 0x646be4: r0 = AllocateArray()
    //     0x646be4: bl              #0x82746c  ; AllocateArrayStub
    // 0x646be8: mov             x1, x0
    // 0x646bec: ldur            x0, [fp, #-0x38]
    // 0x646bf0: stur            x1, [fp, #-0x40]
    // 0x646bf4: StoreField: r1->field_f = r0
    //     0x646bf4: stur            w0, [x1, #0xf]
    // 0x646bf8: r16 = "x difficulty, "
    //     0x646bf8: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e80] "x difficulty, "
    //     0x646bfc: ldr             x16, [x16, #0xe80]
    // 0x646c00: StoreField: r1->field_13 = r16
    //     0x646c00: stur            w16, [x1, #0x13]
    // 0x646c04: ldur            x2, [fp, #-0x28]
    // 0x646c08: r0 = LoadInt32Instr(r2)
    //     0x646c08: sbfx            x0, x2, #1, #0x1f
    //     0x646c0c: tbz             w2, #0, #0x646c14
    //     0x646c10: ldur            x0, [x2, #7]
    // 0x646c14: scvtf           d0, x0
    // 0x646c18: d1 = 0.100000
    //     0x646c18: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x646c1c: ldr             d1, [x17, #0xc30]
    // 0x646c20: fmul            d2, d0, d1
    // 0x646c24: d0 = 1.000000
    //     0x646c24: fmov            d0, #1.00000000
    // 0x646c28: fadd            d1, d2, d0
    // 0x646c2c: stur            d1, [fp, #-0x48]
    // 0x646c30: r0 = 60
    //     0x646c30: movz            x0, #0x3c
    // 0x646c34: branchIfSmi(r2, 0x646c40)
    //     0x646c34: tbz             w2, #0, #0x646c40
    // 0x646c38: r0 = LoadClassIdInstr(r2)
    //     0x646c38: ldur            x0, [x2, #-1]
    //     0x646c3c: ubfx            x0, x0, #0xc, #0x14
    // 0x646c40: str             x2, [SP]
    // 0x646c44: r0 = GDT[cid_x0 + -0x1000]()
    //     0x646c44: sub             lr, x0, #1, lsl #12
    //     0x646c48: ldr             lr, [x21, lr, lsl #3]
    //     0x646c4c: blr             lr
    // 0x646c50: LoadField: d0 = r0->field_7
    //     0x646c50: ldur            d0, [x0, #7]
    // 0x646c54: d1 = 1.500000
    //     0x646c54: fmov            d1, #1.50000000
    // 0x646c58: d30 = 0.000000
    //     0x646c58: fmov            d30, d0
    // 0x646c5c: d0 = 1.000000
    //     0x646c5c: fmov            d0, #1.00000000
    // 0x646c60: fcmp            d1, #0.0
    // 0x646c64: b.vs            #0x646ca8
    // 0x646c68: b.eq            #0x646d30
    // 0x646c6c: fcmp            d1, d0
    // 0x646c70: b.eq            #0x646c98
    // 0x646c74: d31 = 2.000000
    //     0x646c74: fmov            d31, #2.00000000
    // 0x646c78: fcmp            d1, d31
    // 0x646c7c: b.eq            #0x646ca0
    // 0x646c80: d31 = 3.000000
    //     0x646c80: fmov            d31, #3.00000000
    // 0x646c84: fcmp            d1, d31
    // 0x646c88: b.ne            #0x646ca8
    // 0x646c8c: fmul            d0, d30, d30
    // 0x646c90: fmul            d0, d0, d30
    // 0x646c94: b               #0x646d30
    // 0x646c98: d0 = 0.000000
    //     0x646c98: fmov            d0, d30
    // 0x646c9c: b               #0x646d30
    // 0x646ca0: fmul            d0, d30, d30
    // 0x646ca4: b               #0x646d30
    // 0x646ca8: fcmp            d30, d0
    // 0x646cac: b.vs            #0x646cbc
    // 0x646cb0: b.eq            #0x646d30
    // 0x646cb4: fcmp            d30, d1
    // 0x646cb8: b.vc            #0x646cc8
    // 0x646cbc: d0 = nan
    //     0x646cbc: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x646cc0: ldr             d0, [x17, #0xe48]
    // 0x646cc4: b               #0x646d30
    // 0x646cc8: d0 = -inf
    //     0x646cc8: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x646ccc: fcmp            d30, d0
    // 0x646cd0: b.eq            #0x646cf8
    // 0x646cd4: d0 = 0.500000
    //     0x646cd4: fmov            d0, #0.50000000
    // 0x646cd8: fcmp            d1, d0
    // 0x646cdc: b.ne            #0x646cf8
    // 0x646ce0: fcmp            d30, #0.0
    // 0x646ce4: b.eq            #0x646cf0
    // 0x646ce8: fsqrt           d0, d30
    // 0x646cec: b               #0x646d30
    // 0x646cf0: d0 = 0.000000
    //     0x646cf0: eor             v0.16b, v0.16b, v0.16b
    // 0x646cf4: b               #0x646d30
    // 0x646cf8: d0 = 0.000000
    //     0x646cf8: fmov            d0, d30
    // 0x646cfc: stp             fp, lr, [SP, #-0x10]!
    // 0x646d00: mov             fp, SP
    // 0x646d04: CallRuntime_LibcPow(double, double) -> double
    //     0x646d04: and             SP, SP, #0xfffffffffffffff0
    //     0x646d08: mov             sp, SP
    //     0x646d0c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x646d10: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x646d14: blr             x16
    //     0x646d18: movz            x16, #0x8
    //     0x646d1c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x646d20: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x646d24: sub             sp, x16, #1, lsl #12
    //     0x646d28: mov             SP, fp
    //     0x646d2c: ldp             fp, lr, [SP], #0x10
    // 0x646d30: mov             v1.16b, v0.16b
    // 0x646d34: d0 = 0.012000
    //     0x646d34: add             x17, PP, #0x26, lsl #12  ; [pp+0x26378] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0x646d38: ldr             d0, [x17, #0x378]
    // 0x646d3c: fmul            d2, d1, d0
    // 0x646d40: ldur            d0, [fp, #-0x48]
    // 0x646d44: fadd            d1, d0, d2
    // 0x646d48: r1 = inline_Allocate_Double()
    //     0x646d48: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x646d4c: add             x1, x1, #0x10
    //     0x646d50: cmp             x0, x1
    //     0x646d54: b.ls            #0x646ee4
    //     0x646d58: str             x1, [THR, #0x60]  ; THR::top
    //     0x646d5c: sub             x1, x1, #0xf
    //     0x646d60: movz            x0, #0xe19c
    //     0x646d64: movk            x0, #0x3, lsl #16
    //     0x646d68: stur            x0, [x1, #-1]
    // 0x646d6c: dmb             ishst
    // 0x646d70: StoreField: r1->field_7 = d1
    //     0x646d70: stur            d1, [x1, #7]
    // 0x646d74: r2 = 2
    //     0x646d74: movz            x2, #0x2
    // 0x646d78: r0 = toStringAsFixed()
    //     0x646d78: bl              #0x824944  ; [dart:core] _Double::toStringAsFixed
    // 0x646d7c: ldur            x1, [fp, #-0x40]
    // 0x646d80: ArrayStore: r1[2] = r0  ; List_4
    //     0x646d80: add             x25, x1, #0x17
    //     0x646d84: str             w0, [x25]
    //     0x646d88: tbz             w0, #0, #0x646da4
    //     0x646d8c: ldurb           w16, [x1, #-1]
    //     0x646d90: ldurb           w17, [x0, #-1]
    //     0x646d94: and             x16, x17, x16, lsr #2
    //     0x646d98: tst             x16, HEAP, lsr #32
    //     0x646d9c: b.eq            #0x646da4
    //     0x646da0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x646da4: ldur            x0, [fp, #-0x40]
    // 0x646da8: r16 = " tokens"
    //     0x646da8: add             x16, PP, #0x31, lsl #12  ; [pp+0x31e88] " tokens"
    //     0x646dac: ldr             x16, [x16, #0xe88]
    // 0x646db0: StoreField: r0->field_1b = r16
    //     0x646db0: stur            w16, [x0, #0x1b]
    // 0x646db4: str             x0, [SP]
    // 0x646db8: r0 = _interpolate()
    //     0x646db8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x646dbc: mov             x3, x0
    // 0x646dc0: b               #0x646dc8
    // 0x646dc4: r3 = Null
    //     0x646dc4: mov             x3, NULL
    // 0x646dc8: ldur            x0, [fp, #-0x20]
    // 0x646dcc: stur            x3, [fp, #-0x38]
    // 0x646dd0: cmp             w0, NULL
    // 0x646dd4: b.eq            #0x646df0
    // 0x646dd8: ldur            x2, [fp, #-0x18]
    // 0x646ddc: r1 = Function '<anonymous closure>':.
    //     0x646ddc: add             x1, PP, #0x31, lsl #12  ; [pp+0x31e90] AnonymousClosure: (0x6472d0), in [package:pretentious/widgets/difficulty_indicator.dart] _AppleNumberPickerState::build (0x646388)
    //     0x646de0: ldr             x1, [x1, #0xe90]
    // 0x646de4: r0 = AllocateClosure()
    //     0x646de4: bl              #0x826750  ; AllocateClosureStub
    // 0x646de8: mov             x3, x0
    // 0x646dec: b               #0x646df4
    // 0x646df0: r3 = Null
    //     0x646df0: mov             x3, NULL
    // 0x646df4: ldur            x0, [fp, #-0x28]
    // 0x646df8: stur            x3, [fp, #-0x20]
    // 0x646dfc: cmp             w0, NULL
    // 0x646e00: b.eq            #0x646e1c
    // 0x646e04: ldur            x2, [fp, #-0x18]
    // 0x646e08: r1 = Function '<anonymous closure>':.
    //     0x646e08: add             x1, PP, #0x31, lsl #12  ; [pp+0x31e98] AnonymousClosure: (0x646f10), in [package:pretentious/widgets/difficulty_indicator.dart] _AppleNumberPickerState::build (0x646388)
    //     0x646e0c: ldr             x1, [x1, #0xe98]
    // 0x646e10: r0 = AllocateClosure()
    //     0x646e10: bl              #0x826750  ; AllocateClosureStub
    // 0x646e14: mov             x1, x0
    // 0x646e18: b               #0x646e20
    // 0x646e1c: r1 = Null
    //     0x646e1c: mov             x1, NULL
    // 0x646e20: ldur            x0, [fp, #-0x10]
    // 0x646e24: stur            x1, [fp, #-0x18]
    // 0x646e28: r0 = ExcludeSemantics()
    //     0x646e28: bl              #0x408e58  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0x646e2c: mov             x1, x0
    // 0x646e30: r0 = true
    //     0x646e30: add             x0, NULL, #0x20  ; true
    // 0x646e34: stur            x1, [fp, #-0x28]
    // 0x646e38: StoreField: r1->field_f = r0
    //     0x646e38: stur            w0, [x1, #0xf]
    // 0x646e3c: ldur            x0, [fp, #-0x10]
    // 0x646e40: StoreField: r1->field_b = r0
    //     0x646e40: stur            w0, [x1, #0xb]
    // 0x646e44: r0 = Semantics()
    //     0x646e44: bl              #0x3d3a84  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0x646e48: stur            x0, [fp, #-0x10]
    // 0x646e4c: ldur            x16, [fp, #-8]
    // 0x646e50: r30 = true
    //     0x646e50: add             lr, NULL, #0x20  ; true
    // 0x646e54: stp             lr, x16, [SP, #0x20]
    // 0x646e58: ldur            x16, [fp, #-0x30]
    // 0x646e5c: ldur            lr, [fp, #-0x38]
    // 0x646e60: stp             lr, x16, [SP, #0x10]
    // 0x646e64: ldur            x16, [fp, #-0x20]
    // 0x646e68: ldur            lr, [fp, #-0x18]
    // 0x646e6c: stp             lr, x16, [SP]
    // 0x646e70: mov             x1, x0
    // 0x646e74: ldur            x2, [fp, #-0x28]
    // 0x646e78: r4 = const [0, 0x8, 0x6, 0x2, decreasedValue, 0x5, increasedValue, 0x4, onDecrease, 0x7, onIncrease, 0x6, slider, 0x3, value, 0x2, null]
    //     0x646e78: add             x4, PP, #0x31, lsl #12  ; [pp+0x31ea0] List(17) [0, 0x8, 0x6, 0x2, "decreasedValue", 0x5, "increasedValue", 0x4, "onDecrease", 0x7, "onIncrease", 0x6, "slider", 0x3, "value", 0x2, Null]
    //     0x646e7c: ldr             x4, [x4, #0xea0]
    // 0x646e80: r0 = Semantics()
    //     0x646e80: bl              #0x3d24e4  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x646e84: ldur            x0, [fp, #-0x10]
    // 0x646e88: LeaveFrame
    //     0x646e88: mov             SP, fp
    //     0x646e8c: ldp             fp, lr, [SP], #0x10
    // 0x646e90: ret
    //     0x646e90: ret             
    // 0x646e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x646e94: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x646e98: b               #0x6463b0
    // 0x646e9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646e9c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646ea0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646ea0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646ea4: r9 = controller
    //     0x646ea4: add             x9, PP, #0x31, lsl #12  ; [pp+0x31ea8] Field <_AppleNumberPickerState@955301480.controller>: late (offset: 0x18)
    //     0x646ea8: ldr             x9, [x9, #0xea8]
    // 0x646eac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x646eac: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x646eb0: r9 = _selectedValue
    //     0x646eb0: add             x9, PP, #0x31, lsl #12  ; [pp+0x31eb0] Field <_AppleNumberPickerState@955301480._selectedValue@955301480>: late (offset: 0x14)
    //     0x646eb4: ldr             x9, [x9, #0xeb0]
    // 0x646eb8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x646eb8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x646ebc: stp             q0, q3, [SP, #-0x20]!
    // 0x646ec0: r0 = AllocateDouble()
    //     0x646ec0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x646ec4: mov             x1, x0
    // 0x646ec8: ldp             q0, q3, [SP], #0x20
    // 0x646ecc: b               #0x646958
    // 0x646ed0: stp             q0, q3, [SP, #-0x20]!
    // 0x646ed4: r0 = AllocateDouble()
    //     0x646ed4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x646ed8: mov             x1, x0
    // 0x646edc: ldp             q0, q3, [SP], #0x20
    // 0x646ee0: b               #0x646b60
    // 0x646ee4: SaveReg d1
    //     0x646ee4: str             q1, [SP, #-0x10]!
    // 0x646ee8: r0 = AllocateDouble()
    //     0x646ee8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x646eec: mov             x1, x0
    // 0x646ef0: RestoreReg d1
    //     0x646ef0: ldr             q1, [SP], #0x10
    // 0x646ef4: b               #0x646d70
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x646f10, size: 0xa0
    // 0x646f10: EnterFrame
    //     0x646f10: stp             fp, lr, [SP, #-0x10]!
    //     0x646f14: mov             fp, SP
    // 0x646f18: ldr             x0, [fp, #0x10]
    // 0x646f1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x646f1c: ldur            w1, [x0, #0x17]
    // 0x646f20: DecompressPointer r1
    //     0x646f20: add             x1, x1, HEAP, lsl #32
    // 0x646f24: CheckStackOverflow
    //     0x646f24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x646f28: cmp             SP, x16
    //     0x646f2c: b.ls            #0x646f90
    // 0x646f30: LoadField: r0 = r1->field_f
    //     0x646f30: ldur            w0, [x1, #0xf]
    // 0x646f34: DecompressPointer r0
    //     0x646f34: add             x0, x0, HEAP, lsl #32
    // 0x646f38: LoadField: r1 = r0->field_13
    //     0x646f38: ldur            w1, [x0, #0x13]
    // 0x646f3c: DecompressPointer r1
    //     0x646f3c: add             x1, x1, HEAP, lsl #32
    // 0x646f40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x646f44: cmp             w1, w16
    // 0x646f48: b.eq            #0x646f98
    // 0x646f4c: r2 = LoadInt32Instr(r1)
    //     0x646f4c: sbfx            x2, x1, #1, #0x1f
    //     0x646f50: tbz             w1, #0, #0x646f58
    //     0x646f54: ldur            x2, [x1, #7]
    // 0x646f58: sub             x1, x2, #1
    // 0x646f5c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x646f5c: ldur            w2, [x0, #0x17]
    // 0x646f60: DecompressPointer r2
    //     0x646f60: add             x2, x2, HEAP, lsl #32
    // 0x646f64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x646f68: cmp             w2, w16
    // 0x646f6c: b.eq            #0x646fa4
    // 0x646f70: mov             x16, x1
    // 0x646f74: mov             x1, x2
    // 0x646f78: mov             x2, x16
    // 0x646f7c: r0 = animateToItem()
    //     0x646f7c: bl              #0x646fb0  ; [package:flutter/src/widgets/list_wheel_scroll_view.dart] FixedExtentScrollController::animateToItem
    // 0x646f80: r0 = Null
    //     0x646f80: mov             x0, NULL
    // 0x646f84: LeaveFrame
    //     0x646f84: mov             SP, fp
    //     0x646f88: ldp             fp, lr, [SP], #0x10
    // 0x646f8c: ret
    //     0x646f8c: ret             
    // 0x646f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x646f90: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x646f94: b               #0x646f30
    // 0x646f98: r9 = _selectedValue
    //     0x646f98: add             x9, PP, #0x31, lsl #12  ; [pp+0x31eb0] Field <_AppleNumberPickerState@955301480._selectedValue@955301480>: late (offset: 0x14)
    //     0x646f9c: ldr             x9, [x9, #0xeb0]
    // 0x646fa0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x646fa0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x646fa4: r9 = controller
    //     0x646fa4: add             x9, PP, #0x31, lsl #12  ; [pp+0x31ea8] Field <_AppleNumberPickerState@955301480.controller>: late (offset: 0x18)
    //     0x646fa8: ldr             x9, [x9, #0xea8]
    // 0x646fac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x646fac: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6472d0, size: 0xa0
    // 0x6472d0: EnterFrame
    //     0x6472d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6472d4: mov             fp, SP
    // 0x6472d8: ldr             x0, [fp, #0x10]
    // 0x6472dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6472dc: ldur            w1, [x0, #0x17]
    // 0x6472e0: DecompressPointer r1
    //     0x6472e0: add             x1, x1, HEAP, lsl #32
    // 0x6472e4: CheckStackOverflow
    //     0x6472e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6472e8: cmp             SP, x16
    //     0x6472ec: b.ls            #0x647350
    // 0x6472f0: LoadField: r0 = r1->field_f
    //     0x6472f0: ldur            w0, [x1, #0xf]
    // 0x6472f4: DecompressPointer r0
    //     0x6472f4: add             x0, x0, HEAP, lsl #32
    // 0x6472f8: LoadField: r1 = r0->field_13
    //     0x6472f8: ldur            w1, [x0, #0x13]
    // 0x6472fc: DecompressPointer r1
    //     0x6472fc: add             x1, x1, HEAP, lsl #32
    // 0x647300: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x647304: cmp             w1, w16
    // 0x647308: b.eq            #0x647358
    // 0x64730c: r2 = LoadInt32Instr(r1)
    //     0x64730c: sbfx            x2, x1, #1, #0x1f
    //     0x647310: tbz             w1, #0, #0x647318
    //     0x647314: ldur            x2, [x1, #7]
    // 0x647318: add             x1, x2, #1
    // 0x64731c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x64731c: ldur            w2, [x0, #0x17]
    // 0x647320: DecompressPointer r2
    //     0x647320: add             x2, x2, HEAP, lsl #32
    // 0x647324: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x647328: cmp             w2, w16
    // 0x64732c: b.eq            #0x647364
    // 0x647330: mov             x16, x1
    // 0x647334: mov             x1, x2
    // 0x647338: mov             x2, x16
    // 0x64733c: r0 = animateToItem()
    //     0x64733c: bl              #0x646fb0  ; [package:flutter/src/widgets/list_wheel_scroll_view.dart] FixedExtentScrollController::animateToItem
    // 0x647340: r0 = Null
    //     0x647340: mov             x0, NULL
    // 0x647344: LeaveFrame
    //     0x647344: mov             SP, fp
    //     0x647348: ldp             fp, lr, [SP], #0x10
    // 0x64734c: ret
    //     0x64734c: ret             
    // 0x647350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647350: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x647354: b               #0x6472f0
    // 0x647358: r9 = _selectedValue
    //     0x647358: add             x9, PP, #0x31, lsl #12  ; [pp+0x31eb0] Field <_AppleNumberPickerState@955301480._selectedValue@955301480>: late (offset: 0x14)
    //     0x64735c: ldr             x9, [x9, #0xeb0]
    // 0x647360: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x647360: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x647364: r9 = controller
    //     0x647364: add             x9, PP, #0x31, lsl #12  ; [pp+0x31ea8] Field <_AppleNumberPickerState@955301480.controller>: late (offset: 0x18)
    //     0x647368: ldr             x9, [x9, #0xea8]
    // 0x64736c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x64736c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x647370, size: 0xe0
    // 0x647370: EnterFrame
    //     0x647370: stp             fp, lr, [SP, #-0x10]!
    //     0x647374: mov             fp, SP
    // 0x647378: AllocStack(0x20)
    //     0x647378: sub             SP, SP, #0x20
    // 0x64737c: SetupParameters([dynamic _ /* r0 */])
    //     0x64737c: ldr             x0, [fp, #0x18]
    //     0x647380: ldur            w1, [x0, #0x17]
    //     0x647384: add             x1, x1, HEAP, lsl #32
    //     0x647388: stur            x1, [fp, #-8]
    // 0x64738c: CheckStackOverflow
    //     0x64738c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x647390: cmp             SP, x16
    //     0x647394: b.ls            #0x647438
    // 0x647398: r1 = 1
    //     0x647398: movz            x1, #0x1
    // 0x64739c: r0 = AllocateContext()
    //     0x64739c: bl              #0x82637c  ; AllocateContextStub
    // 0x6473a0: mov             x1, x0
    // 0x6473a4: ldur            x0, [fp, #-8]
    // 0x6473a8: StoreField: r1->field_b = r0
    //     0x6473a8: stur            w0, [x1, #0xb]
    // 0x6473ac: ldr             x2, [fp, #0x10]
    // 0x6473b0: StoreField: r1->field_f = r2
    //     0x6473b0: stur            w2, [x1, #0xf]
    // 0x6473b4: LoadField: r3 = r0->field_f
    //     0x6473b4: ldur            w3, [x0, #0xf]
    // 0x6473b8: DecompressPointer r3
    //     0x6473b8: add             x3, x3, HEAP, lsl #32
    // 0x6473bc: mov             x2, x1
    // 0x6473c0: stur            x3, [fp, #-0x10]
    // 0x6473c4: r1 = Function '<anonymous closure>':.
    //     0x6473c4: add             x1, PP, #0x31, lsl #12  ; [pp+0x31ee0] AnonymousClosure: (0x647450), in [package:pretentious/widgets/difficulty_indicator.dart] _AppleNumberPickerState::build (0x646388)
    //     0x6473c8: ldr             x1, [x1, #0xee0]
    // 0x6473cc: r0 = AllocateClosure()
    //     0x6473cc: bl              #0x826750  ; AllocateClosureStub
    // 0x6473d0: ldur            x1, [fp, #-0x10]
    // 0x6473d4: mov             x2, x0
    // 0x6473d8: r0 = setState()
    //     0x6473d8: bl              #0x329714  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x6473dc: ldur            x0, [fp, #-8]
    // 0x6473e0: LoadField: r1 = r0->field_f
    //     0x6473e0: ldur            w1, [x0, #0xf]
    // 0x6473e4: DecompressPointer r1
    //     0x6473e4: add             x1, x1, HEAP, lsl #32
    // 0x6473e8: LoadField: r0 = r1->field_b
    //     0x6473e8: ldur            w0, [x1, #0xb]
    // 0x6473ec: DecompressPointer r0
    //     0x6473ec: add             x0, x0, HEAP, lsl #32
    // 0x6473f0: cmp             w0, NULL
    // 0x6473f4: b.eq            #0x647440
    // 0x6473f8: LoadField: r2 = r1->field_13
    //     0x6473f8: ldur            w2, [x1, #0x13]
    // 0x6473fc: DecompressPointer r2
    //     0x6473fc: add             x2, x2, HEAP, lsl #32
    // 0x647400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x647404: cmp             w2, w16
    // 0x647408: b.eq            #0x647444
    // 0x64740c: LoadField: r1 = r0->field_b
    //     0x64740c: ldur            w1, [x0, #0xb]
    // 0x647410: DecompressPointer r1
    //     0x647410: add             x1, x1, HEAP, lsl #32
    // 0x647414: stp             x2, x1, [SP]
    // 0x647418: mov             x0, x1
    // 0x64741c: ClosureCall
    //     0x64741c: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x647420: ldur            x2, [x0, #0x1f]
    //     0x647424: blr             x2
    // 0x647428: r0 = Null
    //     0x647428: mov             x0, NULL
    // 0x64742c: LeaveFrame
    //     0x64742c: mov             SP, fp
    //     0x647430: ldp             fp, lr, [SP], #0x10
    // 0x647434: ret
    //     0x647434: ret             
    // 0x647438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647438: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64743c: b               #0x647398
    // 0x647440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x647440: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x647444: r9 = _selectedValue
    //     0x647444: add             x9, PP, #0x31, lsl #12  ; [pp+0x31eb0] Field <_AppleNumberPickerState@955301480._selectedValue@955301480>: late (offset: 0x14)
    //     0x647448: ldr             x9, [x9, #0xeb0]
    // 0x64744c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x64744c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x647450, size: 0x54
    // 0x647450: ldr             x1, [SP]
    // 0x647454: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x647454: ldur            w2, [x1, #0x17]
    // 0x647458: DecompressPointer r2
    //     0x647458: add             x2, x2, HEAP, lsl #32
    // 0x64745c: LoadField: r1 = r2->field_b
    //     0x64745c: ldur            w1, [x2, #0xb]
    // 0x647460: DecompressPointer r1
    //     0x647460: add             x1, x1, HEAP, lsl #32
    // 0x647464: LoadField: r3 = r1->field_f
    //     0x647464: ldur            w3, [x1, #0xf]
    // 0x647468: DecompressPointer r3
    //     0x647468: add             x3, x3, HEAP, lsl #32
    // 0x64746c: LoadField: r0 = r2->field_f
    //     0x64746c: ldur            w0, [x2, #0xf]
    // 0x647470: DecompressPointer r0
    //     0x647470: add             x0, x0, HEAP, lsl #32
    // 0x647474: StoreField: r3->field_13 = r0
    //     0x647474: stur            w0, [x3, #0x13]
    //     0x647478: tbz             w0, #0, #0x64749c
    //     0x64747c: ldurb           w16, [x3, #-1]
    //     0x647480: ldurb           w17, [x0, #-1]
    //     0x647484: and             x16, x17, x16, lsr #2
    //     0x647488: tst             x16, HEAP, lsr #32
    //     0x64748c: b.eq            #0x64749c
    //     0x647490: str             lr, [SP, #-8]!
    //     0x647494: bl              #0x825b18  ; WriteBarrierWrappersStub
    //     0x647498: ldr             lr, [SP], #8
    // 0x64749c: r0 = Null
    //     0x64749c: mov             x0, NULL
    // 0x6474a0: ret
    //     0x6474a0: ret             
  }
  [closure] Opacity <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6474a4, size: 0x3ac
    // 0x6474a4: EnterFrame
    //     0x6474a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6474a8: mov             fp, SP
    // 0x6474ac: AllocStack(0x38)
    //     0x6474ac: sub             SP, SP, #0x38
    // 0x6474b0: SetupParameters([dynamic _ /* r0 */])
    //     0x6474b0: ldr             x0, [fp, #0x20]
    //     0x6474b4: ldur            w1, [x0, #0x17]
    //     0x6474b8: add             x1, x1, HEAP, lsl #32
    // 0x6474bc: CheckStackOverflow
    //     0x6474bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6474c0: cmp             SP, x16
    //     0x6474c4: b.ls            #0x647828
    // 0x6474c8: LoadField: r0 = r1->field_f
    //     0x6474c8: ldur            w0, [x1, #0xf]
    // 0x6474cc: DecompressPointer r0
    //     0x6474cc: add             x0, x0, HEAP, lsl #32
    // 0x6474d0: LoadField: r1 = r0->field_13
    //     0x6474d0: ldur            w1, [x0, #0x13]
    // 0x6474d4: DecompressPointer r1
    //     0x6474d4: add             x1, x1, HEAP, lsl #32
    // 0x6474d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6474dc: cmp             w1, w16
    // 0x6474e0: b.eq            #0x647830
    // 0x6474e4: ldr             x0, [fp, #0x10]
    // 0x6474e8: r3 = LoadInt32Instr(r0)
    //     0x6474e8: sbfx            x3, x0, #1, #0x1f
    //     0x6474ec: tbz             w0, #0, #0x6474f4
    //     0x6474f0: ldur            x3, [x0, #7]
    // 0x6474f4: stur            x3, [fp, #-8]
    // 0x6474f8: r2 = LoadInt32Instr(r1)
    //     0x6474f8: sbfx            x2, x1, #1, #0x1f
    //     0x6474fc: tbz             w1, #0, #0x647504
    //     0x647500: ldur            x2, [x1, #7]
    // 0x647504: cmp             x3, x2
    // 0x647508: b.ne            #0x647514
    // 0x64750c: d0 = 1.000000
    //     0x64750c: fmov            d0, #1.00000000
    // 0x647510: b               #0x647518
    // 0x647514: d0 = 0.250000
    //     0x647514: fmov            d0, #0.25000000
    // 0x647518: mov             x2, x0
    // 0x64751c: stur            d0, [fp, #-0x28]
    // 0x647520: r1 = Instance_CustomNum
    //     0x647520: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x647524: ldr             x1, [x1, #0x970]
    // 0x647528: r0 = pow()
    //     0x647528: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x64752c: str             x0, [SP]
    // 0x647530: r0 = toString()
    //     0x647530: bl              #0x7196d8  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toString
    // 0x647534: stur            x0, [fp, #-0x10]
    // 0x647538: r0 = Text()
    //     0x647538: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x64753c: mov             x2, x0
    // 0x647540: ldur            x0, [fp, #-0x10]
    // 0x647544: stur            x2, [fp, #-0x18]
    // 0x647548: StoreField: r2->field_b = r0
    //     0x647548: stur            w0, [x2, #0xb]
    // 0x64754c: r0 = Instance_TextStyle
    //     0x64754c: add             x0, PP, #0x31, lsl #12  ; [pp+0x31ee8] Obj!TextStyle@847ae1
    //     0x647550: ldr             x0, [x0, #0xee8]
    // 0x647554: StoreField: r2->field_13 = r0
    //     0x647554: stur            w0, [x2, #0x13]
    // 0x647558: r3 = Instance_TextAlign
    //     0x647558: ldr             x3, [PP, #0x6998]  ; [pp+0x6998] Obj!TextAlign@865401
    // 0x64755c: StoreField: r2->field_1b = r3
    //     0x64755c: stur            w3, [x2, #0x1b]
    // 0x647560: r1 = <FlexParentData>
    //     0x647560: add             x1, PP, #0x19, lsl #12  ; [pp+0x191f0] TypeArguments: <FlexParentData>
    //     0x647564: ldr             x1, [x1, #0x1f0]
    // 0x647568: r0 = Flexible()
    //     0x647568: bl              #0x59ff8c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x64756c: mov             x2, x0
    // 0x647570: r1 = 1
    //     0x647570: movz            x1, #0x1
    // 0x647574: stur            x2, [fp, #-0x10]
    // 0x647578: StoreField: r2->field_13 = r1
    //     0x647578: stur            x1, [x2, #0x13]
    // 0x64757c: r3 = Instance_FlexFit
    //     0x64757c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a050] Obj!FlexFit@862ac1
    //     0x647580: ldr             x3, [x3, #0x50]
    // 0x647584: StoreField: r2->field_1b = r3
    //     0x647584: stur            w3, [x2, #0x1b]
    // 0x647588: ldur            x0, [fp, #-0x18]
    // 0x64758c: StoreField: r2->field_b = r0
    //     0x64758c: stur            w0, [x2, #0xb]
    // 0x647590: ldur            x0, [fp, #-8]
    // 0x647594: scvtf           d0, x0
    // 0x647598: d1 = 0.100000
    //     0x647598: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x64759c: ldr             d1, [x17, #0xc30]
    // 0x6475a0: fmul            d2, d0, d1
    // 0x6475a4: d0 = 1.000000
    //     0x6475a4: fmov            d0, #1.00000000
    // 0x6475a8: fadd            d1, d2, d0
    // 0x6475ac: ldr             x0, [fp, #0x10]
    // 0x6475b0: stur            d1, [fp, #-0x30]
    // 0x6475b4: r4 = 60
    //     0x6475b4: movz            x4, #0x3c
    // 0x6475b8: branchIfSmi(r0, 0x6475c4)
    //     0x6475b8: tbz             w0, #0, #0x6475c4
    // 0x6475bc: r4 = LoadClassIdInstr(r0)
    //     0x6475bc: ldur            x4, [x0, #-1]
    //     0x6475c0: ubfx            x4, x4, #0xc, #0x14
    // 0x6475c4: str             x0, [SP]
    // 0x6475c8: mov             x0, x4
    // 0x6475cc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x6475cc: sub             lr, x0, #1, lsl #12
    //     0x6475d0: ldr             lr, [x21, lr, lsl #3]
    //     0x6475d4: blr             lr
    // 0x6475d8: LoadField: d0 = r0->field_7
    //     0x6475d8: ldur            d0, [x0, #7]
    // 0x6475dc: d1 = 1.500000
    //     0x6475dc: fmov            d1, #1.50000000
    // 0x6475e0: d30 = 0.000000
    //     0x6475e0: fmov            d30, d0
    // 0x6475e4: d0 = 1.000000
    //     0x6475e4: fmov            d0, #1.00000000
    // 0x6475e8: fcmp            d1, #0.0
    // 0x6475ec: b.vs            #0x647630
    // 0x6475f0: b.eq            #0x6476b8
    // 0x6475f4: fcmp            d1, d0
    // 0x6475f8: b.eq            #0x647620
    // 0x6475fc: d31 = 2.000000
    //     0x6475fc: fmov            d31, #2.00000000
    // 0x647600: fcmp            d1, d31
    // 0x647604: b.eq            #0x647628
    // 0x647608: d31 = 3.000000
    //     0x647608: fmov            d31, #3.00000000
    // 0x64760c: fcmp            d1, d31
    // 0x647610: b.ne            #0x647630
    // 0x647614: fmul            d0, d30, d30
    // 0x647618: fmul            d0, d0, d30
    // 0x64761c: b               #0x6476b8
    // 0x647620: d0 = 0.000000
    //     0x647620: fmov            d0, d30
    // 0x647624: b               #0x6476b8
    // 0x647628: fmul            d0, d30, d30
    // 0x64762c: b               #0x6476b8
    // 0x647630: fcmp            d30, d0
    // 0x647634: b.vs            #0x647644
    // 0x647638: b.eq            #0x6476b8
    // 0x64763c: fcmp            d30, d1
    // 0x647640: b.vc            #0x647650
    // 0x647644: d0 = nan
    //     0x647644: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x647648: ldr             d0, [x17, #0xe48]
    // 0x64764c: b               #0x6476b8
    // 0x647650: d0 = -inf
    //     0x647650: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x647654: fcmp            d30, d0
    // 0x647658: b.eq            #0x647680
    // 0x64765c: d0 = 0.500000
    //     0x64765c: fmov            d0, #0.50000000
    // 0x647660: fcmp            d1, d0
    // 0x647664: b.ne            #0x647680
    // 0x647668: fcmp            d30, #0.0
    // 0x64766c: b.eq            #0x647678
    // 0x647670: fsqrt           d0, d30
    // 0x647674: b               #0x6476b8
    // 0x647678: d0 = 0.000000
    //     0x647678: eor             v0.16b, v0.16b, v0.16b
    // 0x64767c: b               #0x6476b8
    // 0x647680: d0 = 0.000000
    //     0x647680: fmov            d0, d30
    // 0x647684: stp             fp, lr, [SP, #-0x10]!
    // 0x647688: mov             fp, SP
    // 0x64768c: CallRuntime_LibcPow(double, double) -> double
    //     0x64768c: and             SP, SP, #0xfffffffffffffff0
    //     0x647690: mov             sp, SP
    //     0x647694: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x647698: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x64769c: blr             x16
    //     0x6476a0: movz            x16, #0x8
    //     0x6476a4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6476a8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x6476ac: sub             sp, x16, #1, lsl #12
    //     0x6476b0: mov             SP, fp
    //     0x6476b4: ldp             fp, lr, [SP], #0x10
    // 0x6476b8: mov             v1.16b, v0.16b
    // 0x6476bc: d0 = 0.012000
    //     0x6476bc: add             x17, PP, #0x26, lsl #12  ; [pp+0x26378] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0x6476c0: ldr             d0, [x17, #0x378]
    // 0x6476c4: fmul            d2, d1, d0
    // 0x6476c8: ldur            d0, [fp, #-0x30]
    // 0x6476cc: fadd            d1, d0, d2
    // 0x6476d0: r1 = inline_Allocate_Double()
    //     0x6476d0: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x6476d4: add             x1, x1, #0x10
    //     0x6476d8: cmp             x0, x1
    //     0x6476dc: b.ls            #0x64783c
    //     0x6476e0: str             x1, [THR, #0x60]  ; THR::top
    //     0x6476e4: sub             x1, x1, #0xf
    //     0x6476e8: movz            x0, #0xe19c
    //     0x6476ec: movk            x0, #0x3, lsl #16
    //     0x6476f0: stur            x0, [x1, #-1]
    // 0x6476f4: dmb             ishst
    // 0x6476f8: StoreField: r1->field_7 = d1
    //     0x6476f8: stur            d1, [x1, #7]
    // 0x6476fc: r2 = 2
    //     0x6476fc: movz            x2, #0x2
    // 0x647700: r0 = toStringAsFixed()
    //     0x647700: bl              #0x824944  ; [dart:core] _Double::toStringAsFixed
    // 0x647704: stur            x0, [fp, #-0x18]
    // 0x647708: r0 = Text()
    //     0x647708: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x64770c: mov             x2, x0
    // 0x647710: ldur            x0, [fp, #-0x18]
    // 0x647714: stur            x2, [fp, #-0x20]
    // 0x647718: StoreField: r2->field_b = r0
    //     0x647718: stur            w0, [x2, #0xb]
    // 0x64771c: r0 = Instance_TextStyle
    //     0x64771c: add             x0, PP, #0x31, lsl #12  ; [pp+0x31ee8] Obj!TextStyle@847ae1
    //     0x647720: ldr             x0, [x0, #0xee8]
    // 0x647724: StoreField: r2->field_13 = r0
    //     0x647724: stur            w0, [x2, #0x13]
    // 0x647728: r0 = Instance_TextAlign
    //     0x647728: ldr             x0, [PP, #0x6998]  ; [pp+0x6998] Obj!TextAlign@865401
    // 0x64772c: StoreField: r2->field_1b = r0
    //     0x64772c: stur            w0, [x2, #0x1b]
    // 0x647730: r1 = <FlexParentData>
    //     0x647730: add             x1, PP, #0x19, lsl #12  ; [pp+0x191f0] TypeArguments: <FlexParentData>
    //     0x647734: ldr             x1, [x1, #0x1f0]
    // 0x647738: r0 = Flexible()
    //     0x647738: bl              #0x59ff8c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x64773c: mov             x3, x0
    // 0x647740: r0 = 1
    //     0x647740: movz            x0, #0x1
    // 0x647744: stur            x3, [fp, #-0x18]
    // 0x647748: StoreField: r3->field_13 = r0
    //     0x647748: stur            x0, [x3, #0x13]
    // 0x64774c: r0 = Instance_FlexFit
    //     0x64774c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a050] Obj!FlexFit@862ac1
    //     0x647750: ldr             x0, [x0, #0x50]
    // 0x647754: StoreField: r3->field_1b = r0
    //     0x647754: stur            w0, [x3, #0x1b]
    // 0x647758: ldur            x0, [fp, #-0x20]
    // 0x64775c: StoreField: r3->field_b = r0
    //     0x64775c: stur            w0, [x3, #0xb]
    // 0x647760: r1 = Null
    //     0x647760: mov             x1, NULL
    // 0x647764: r2 = 4
    //     0x647764: movz            x2, #0x4
    // 0x647768: r0 = AllocateArray()
    //     0x647768: bl              #0x82746c  ; AllocateArrayStub
    // 0x64776c: mov             x2, x0
    // 0x647770: ldur            x0, [fp, #-0x10]
    // 0x647774: stur            x2, [fp, #-0x20]
    // 0x647778: StoreField: r2->field_f = r0
    //     0x647778: stur            w0, [x2, #0xf]
    // 0x64777c: ldur            x0, [fp, #-0x18]
    // 0x647780: StoreField: r2->field_13 = r0
    //     0x647780: stur            w0, [x2, #0x13]
    // 0x647784: r1 = <Widget>
    //     0x647784: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x647788: r0 = AllocateGrowableArray()
    //     0x647788: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x64778c: mov             x1, x0
    // 0x647790: ldur            x0, [fp, #-0x20]
    // 0x647794: stur            x1, [fp, #-0x10]
    // 0x647798: StoreField: r1->field_f = r0
    //     0x647798: stur            w0, [x1, #0xf]
    // 0x64779c: r0 = 4
    //     0x64779c: movz            x0, #0x4
    // 0x6477a0: StoreField: r1->field_b = r0
    //     0x6477a0: stur            w0, [x1, #0xb]
    // 0x6477a4: r0 = Row()
    //     0x6477a4: bl              #0x59e9b8  ; AllocateRowStub -> Row (size=0x38)
    // 0x6477a8: mov             x1, x0
    // 0x6477ac: r0 = Instance_Axis
    //     0x6477ac: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x6477b0: stur            x1, [fp, #-0x18]
    // 0x6477b4: StoreField: r1->field_f = r0
    //     0x6477b4: stur            w0, [x1, #0xf]
    // 0x6477b8: r0 = Instance_MainAxisAlignment
    //     0x6477b8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x6477bc: ldr             x0, [x0, #0x200]
    // 0x6477c0: StoreField: r1->field_13 = r0
    //     0x6477c0: stur            w0, [x1, #0x13]
    // 0x6477c4: r0 = Instance_MainAxisSize
    //     0x6477c4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6477c8: ldr             x0, [x0, #0x70]
    // 0x6477cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x6477cc: stur            w0, [x1, #0x17]
    // 0x6477d0: r0 = Instance_CrossAxisAlignment
    //     0x6477d0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x6477d4: ldr             x0, [x0, #0x78]
    // 0x6477d8: StoreField: r1->field_1b = r0
    //     0x6477d8: stur            w0, [x1, #0x1b]
    // 0x6477dc: r0 = Instance_VerticalDirection
    //     0x6477dc: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x6477e0: ldr             x0, [x0, #0x1e8]
    // 0x6477e4: StoreField: r1->field_23 = r0
    //     0x6477e4: stur            w0, [x1, #0x23]
    // 0x6477e8: r0 = Instance_Clip
    //     0x6477e8: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x6477ec: ldr             x0, [x0, #0x1b0]
    // 0x6477f0: StoreField: r1->field_2b = r0
    //     0x6477f0: stur            w0, [x1, #0x2b]
    // 0x6477f4: StoreField: r1->field_2f = rZR
    //     0x6477f4: stur            xzr, [x1, #0x2f]
    // 0x6477f8: ldur            x0, [fp, #-0x10]
    // 0x6477fc: StoreField: r1->field_b = r0
    //     0x6477fc: stur            w0, [x1, #0xb]
    // 0x647800: r0 = Opacity()
    //     0x647800: bl              #0x5a0614  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x647804: ldur            d0, [fp, #-0x28]
    // 0x647808: StoreField: r0->field_f = d0
    //     0x647808: stur            d0, [x0, #0xf]
    // 0x64780c: r1 = false
    //     0x64780c: add             x1, NULL, #0x30  ; false
    // 0x647810: ArrayStore: r0[0] = r1  ; List_4
    //     0x647810: stur            w1, [x0, #0x17]
    // 0x647814: ldur            x1, [fp, #-0x18]
    // 0x647818: StoreField: r0->field_b = r1
    //     0x647818: stur            w1, [x0, #0xb]
    // 0x64781c: LeaveFrame
    //     0x64781c: mov             SP, fp
    //     0x647820: ldp             fp, lr, [SP], #0x10
    // 0x647824: ret
    //     0x647824: ret             
    // 0x647828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647828: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64782c: b               #0x6474c8
    // 0x647830: r9 = _selectedValue
    //     0x647830: add             x9, PP, #0x31, lsl #12  ; [pp+0x31eb0] Field <_AppleNumberPickerState@955301480._selectedValue@955301480>: late (offset: 0x14)
    //     0x647834: ldr             x9, [x9, #0xeb0]
    // 0x647838: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x647838: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x64783c: SaveReg d1
    //     0x64783c: str             q1, [SP, #-0x10]!
    // 0x647840: r0 = AllocateDouble()
    //     0x647840: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x647844: mov             x1, x0
    // 0x647848: RestoreReg d1
    //     0x647848: ldr             q1, [SP], #0x10
    // 0x64784c: b               #0x6476f8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x650b98, size: 0x54
    // 0x650b98: EnterFrame
    //     0x650b98: stp             fp, lr, [SP, #-0x10]!
    //     0x650b9c: mov             fp, SP
    // 0x650ba0: CheckStackOverflow
    //     0x650ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x650ba4: cmp             SP, x16
    //     0x650ba8: b.ls            #0x650bd8
    // 0x650bac: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x650bac: ldur            w0, [x1, #0x17]
    // 0x650bb0: DecompressPointer r0
    //     0x650bb0: add             x0, x0, HEAP, lsl #32
    // 0x650bb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x650bb8: cmp             w0, w16
    // 0x650bbc: b.eq            #0x650be0
    // 0x650bc0: mov             x1, x0
    // 0x650bc4: r0 = dispose()
    //     0x650bc4: bl              #0x685b10  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x650bc8: r0 = Null
    //     0x650bc8: mov             x0, NULL
    // 0x650bcc: LeaveFrame
    //     0x650bcc: mov             SP, fp
    //     0x650bd0: ldp             fp, lr, [SP], #0x10
    // 0x650bd4: ret
    //     0x650bd4: ret             
    // 0x650bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x650bd8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650bdc: b               #0x650bac
    // 0x650be0: r9 = controller
    //     0x650be0: add             x9, PP, #0x31, lsl #12  ; [pp+0x31ea8] Field <_AppleNumberPickerState@955301480.controller>: late (offset: 0x18)
    //     0x650be4: ldr             x9, [x9, #0xea8]
    // 0x650be8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x650be8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3247, size: 0x18, field offset: 0x14
class _DifficultyChooserState extends State<dynamic> {

  late int currentDifficulty; // offset: 0x14

  _ initState(/* No info */) {
    // ** addr: 0x59b0e4, size: 0x98
    // 0x59b0e4: EnterFrame
    //     0x59b0e4: stp             fp, lr, [SP, #-0x10]!
    //     0x59b0e8: mov             fp, SP
    // 0x59b0ec: AllocStack(0x8)
    //     0x59b0ec: sub             SP, SP, #8
    // 0x59b0f0: SetupParameters(_DifficultyChooserState this /* r1 => r0, fp-0x8 */)
    //     0x59b0f0: mov             x0, x1
    //     0x59b0f4: stur            x1, [fp, #-8]
    // 0x59b0f8: CheckStackOverflow
    //     0x59b0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x59b0fc: cmp             SP, x16
    //     0x59b100: b.ls            #0x59b170
    // 0x59b104: LoadField: r1 = r0->field_b
    //     0x59b104: ldur            w1, [x0, #0xb]
    // 0x59b108: DecompressPointer r1
    //     0x59b108: add             x1, x1, HEAP, lsl #32
    // 0x59b10c: cmp             w1, NULL
    // 0x59b110: b.eq            #0x59b178
    // 0x59b114: LoadField: r2 = r1->field_b
    //     0x59b114: ldur            w2, [x1, #0xb]
    // 0x59b118: DecompressPointer r2
    //     0x59b118: add             x2, x2, HEAP, lsl #32
    // 0x59b11c: mov             x1, x2
    // 0x59b120: r0 = getDifficultyIndex()
    //     0x59b120: bl              #0x460dcc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::getDifficultyIndex
    // 0x59b124: mov             x2, x0
    // 0x59b128: r0 = BoxInt64Instr(r2)
    //     0x59b128: sbfiz           x0, x2, #1, #0x1f
    //     0x59b12c: cmp             x2, x0, asr #1
    //     0x59b130: b.eq            #0x59b13c
    //     0x59b134: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x59b138: stur            x2, [x0, #7]
    // 0x59b13c: ldur            x1, [fp, #-8]
    // 0x59b140: StoreField: r1->field_13 = r0
    //     0x59b140: stur            w0, [x1, #0x13]
    //     0x59b144: tbz             w0, #0, #0x59b160
    //     0x59b148: ldurb           w16, [x1, #-1]
    //     0x59b14c: ldurb           w17, [x0, #-1]
    //     0x59b150: and             x16, x17, x16, lsr #2
    //     0x59b154: tst             x16, HEAP, lsr #32
    //     0x59b158: b.eq            #0x59b160
    //     0x59b15c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x59b160: r0 = Null
    //     0x59b160: mov             x0, NULL
    // 0x59b164: LeaveFrame
    //     0x59b164: mov             SP, fp
    //     0x59b168: ldp             fp, lr, [SP], #0x10
    // 0x59b16c: ret
    //     0x59b16c: ret             
    // 0x59b170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59b170: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59b174: b               #0x59b104
    // 0x59b178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x59b178: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x645830, size: 0x5ac
    // 0x645830: EnterFrame
    //     0x645830: stp             fp, lr, [SP, #-0x10]!
    //     0x645834: mov             fp, SP
    // 0x645838: AllocStack(0x40)
    //     0x645838: sub             SP, SP, #0x40
    // 0x64583c: SetupParameters(_DifficultyChooserState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x64583c: stur            x1, [fp, #-8]
    //     0x645840: stur            x2, [fp, #-0x10]
    // 0x645844: CheckStackOverflow
    //     0x645844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x645848: cmp             SP, x16
    //     0x64584c: b.ls            #0x645db8
    // 0x645850: r1 = 2
    //     0x645850: movz            x1, #0x2
    // 0x645854: r0 = AllocateContext()
    //     0x645854: bl              #0x82637c  ; AllocateContextStub
    // 0x645858: mov             x2, x0
    // 0x64585c: ldur            x0, [fp, #-8]
    // 0x645860: stur            x2, [fp, #-0x18]
    // 0x645864: StoreField: r2->field_f = r0
    //     0x645864: stur            w0, [x2, #0xf]
    // 0x645868: ldur            x1, [fp, #-0x10]
    // 0x64586c: StoreField: r2->field_13 = r1
    //     0x64586c: stur            w1, [x2, #0x13]
    // 0x645870: LoadField: r1 = r0->field_b
    //     0x645870: ldur            w1, [x0, #0xb]
    // 0x645874: DecompressPointer r1
    //     0x645874: add             x1, x1, HEAP, lsl #32
    // 0x645878: cmp             w1, NULL
    // 0x64587c: b.eq            #0x645dc0
    // 0x645880: LoadField: r3 = r1->field_b
    //     0x645880: ldur            w3, [x1, #0xb]
    // 0x645884: DecompressPointer r3
    //     0x645884: add             x3, x3, HEAP, lsl #32
    // 0x645888: mov             x1, x3
    // 0x64588c: r0 = getReferenceMultiplier()
    //     0x64588c: bl              #0x460fc0  ; [package:pretentious/widgets/difficulty_indicator.dart] ::getReferenceMultiplier
    // 0x645890: r1 = Null
    //     0x645890: mov             x1, NULL
    // 0x645894: r2 = 10
    //     0x645894: movz            x2, #0xa
    // 0x645898: stur            x0, [fp, #-0x10]
    // 0x64589c: r0 = AllocateArray()
    //     0x64589c: bl              #0x82746c  ; AllocateArrayStub
    // 0x6458a0: stur            x0, [fp, #-0x20]
    // 0x6458a4: r16 = "The current difficulty is "
    //     0x6458a4: add             x16, PP, #0x2b, lsl #12  ; [pp+0x2bff0] "The current difficulty is "
    //     0x6458a8: ldr             x16, [x16, #0xff0]
    // 0x6458ac: StoreField: r0->field_f = r16
    //     0x6458ac: stur            w16, [x0, #0xf]
    // 0x6458b0: ldur            x2, [fp, #-8]
    // 0x6458b4: LoadField: r1 = r2->field_b
    //     0x6458b4: ldur            w1, [x2, #0xb]
    // 0x6458b8: DecompressPointer r1
    //     0x6458b8: add             x1, x1, HEAP, lsl #32
    // 0x6458bc: cmp             w1, NULL
    // 0x6458c0: b.eq            #0x645dc4
    // 0x6458c4: LoadField: r3 = r1->field_f
    //     0x6458c4: ldur            w3, [x1, #0xf]
    // 0x6458c8: DecompressPointer r3
    //     0x6458c8: add             x3, x3, HEAP, lsl #32
    // 0x6458cc: mov             x1, x3
    // 0x6458d0: r0 = currentChapterDifficultyMultiplier()
    //     0x6458d0: bl              #0x5a8d6c  ; [package:pretentious/widgets/difficulty_indicator.dart] ::currentChapterDifficultyMultiplier
    // 0x6458d4: ldur            x1, [fp, #-0x20]
    // 0x6458d8: ArrayStore: r1[1] = r0  ; List_4
    //     0x6458d8: add             x25, x1, #0x13
    //     0x6458dc: str             w0, [x25]
    //     0x6458e0: tbz             w0, #0, #0x6458fc
    //     0x6458e4: ldurb           w16, [x1, #-1]
    //     0x6458e8: ldurb           w17, [x0, #-1]
    //     0x6458ec: and             x16, x17, x16, lsr #2
    //     0x6458f0: tst             x16, HEAP, lsr #32
    //     0x6458f4: b.eq            #0x6458fc
    //     0x6458f8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6458fc: ldur            x0, [fp, #-0x20]
    // 0x645900: r16 = "x. It will be set to "
    //     0x645900: add             x16, PP, #0x2b, lsl #12  ; [pp+0x2bff8] "x. It will be set to "
    //     0x645904: ldr             x16, [x16, #0xff8]
    // 0x645908: ArrayStore: r0[0] = r16  ; List_4
    //     0x645908: stur            w16, [x0, #0x17]
    // 0x64590c: ldur            x2, [fp, #-8]
    // 0x645910: LoadField: r1 = r2->field_b
    //     0x645910: ldur            w1, [x2, #0xb]
    // 0x645914: DecompressPointer r1
    //     0x645914: add             x1, x1, HEAP, lsl #32
    // 0x645918: cmp             w1, NULL
    // 0x64591c: b.eq            #0x645dc8
    // 0x645920: LoadField: r3 = r1->field_b
    //     0x645920: ldur            w3, [x1, #0xb]
    // 0x645924: DecompressPointer r3
    //     0x645924: add             x3, x3, HEAP, lsl #32
    // 0x645928: mov             x1, x3
    // 0x64592c: r0 = getDifficultyIndex()
    //     0x64592c: bl              #0x460dcc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::getDifficultyIndex
    // 0x645930: mov             x1, x0
    // 0x645934: r0 = difficultyMultiplier()
    //     0x645934: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x645938: ldur            x1, [fp, #-0x20]
    // 0x64593c: ArrayStore: r1[3] = r0  ; List_4
    //     0x64593c: add             x25, x1, #0x1b
    //     0x645940: str             w0, [x25]
    //     0x645944: tbz             w0, #0, #0x645960
    //     0x645948: ldurb           w16, [x1, #-1]
    //     0x64594c: ldurb           w17, [x0, #-1]
    //     0x645950: and             x16, x17, x16, lsr #2
    //     0x645954: tst             x16, HEAP, lsr #32
    //     0x645958: b.eq            #0x645960
    //     0x64595c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x645960: ldur            x0, [fp, #-0x20]
    // 0x645964: r16 = "x on level complete or restart."
    //     0x645964: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c000] "x on level complete or restart."
    //     0x645968: ldr             x16, [x16]
    // 0x64596c: StoreField: r0->field_1f = r16
    //     0x64596c: stur            w16, [x0, #0x1f]
    // 0x645970: str             x0, [SP]
    // 0x645974: r0 = _interpolate()
    //     0x645974: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x645978: stur            x0, [fp, #-0x20]
    // 0x64597c: r0 = Text()
    //     0x64597c: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x645980: mov             x3, x0
    // 0x645984: ldur            x0, [fp, #-0x20]
    // 0x645988: stur            x3, [fp, #-0x28]
    // 0x64598c: StoreField: r3->field_b = r0
    //     0x64598c: stur            w0, [x3, #0xb]
    // 0x645990: r0 = Instance_TextStyle
    //     0x645990: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c008] Obj!TextStyle@846dc1
    //     0x645994: ldr             x0, [x0, #8]
    // 0x645998: StoreField: r3->field_13 = r0
    //     0x645998: stur            w0, [x3, #0x13]
    // 0x64599c: ldur            x4, [fp, #-0x10]
    // 0x6459a0: cmp             w4, NULL
    // 0x6459a4: b.eq            #0x645a24
    // 0x6459a8: r1 = Null
    //     0x6459a8: mov             x1, NULL
    // 0x6459ac: r2 = 6
    //     0x6459ac: movz            x2, #0x6
    // 0x6459b0: r0 = AllocateArray()
    //     0x6459b0: bl              #0x82746c  ; AllocateArrayStub
    // 0x6459b4: r16 = "The reference difficulty is "
    //     0x6459b4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c010] "The reference difficulty is "
    //     0x6459b8: ldr             x16, [x16, #0x10]
    // 0x6459bc: StoreField: r0->field_f = r16
    //     0x6459bc: stur            w16, [x0, #0xf]
    // 0x6459c0: ldur            x1, [fp, #-0x10]
    // 0x6459c4: StoreField: r0->field_13 = r1
    //     0x6459c4: stur            w1, [x0, #0x13]
    // 0x6459c8: r16 = "x."
    //     0x6459c8: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c018] "x."
    //     0x6459cc: ldr             x16, [x16, #0x18]
    // 0x6459d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x6459d0: stur            w16, [x0, #0x17]
    // 0x6459d4: str             x0, [SP]
    // 0x6459d8: r0 = _interpolate()
    //     0x6459d8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6459dc: stur            x0, [fp, #-0x10]
    // 0x6459e0: r0 = Text()
    //     0x6459e0: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x6459e4: mov             x1, x0
    // 0x6459e8: ldur            x0, [fp, #-0x10]
    // 0x6459ec: stur            x1, [fp, #-0x20]
    // 0x6459f0: StoreField: r1->field_b = r0
    //     0x6459f0: stur            w0, [x1, #0xb]
    // 0x6459f4: r0 = Instance_TextStyle
    //     0x6459f4: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c008] Obj!TextStyle@846dc1
    //     0x6459f8: ldr             x0, [x0, #8]
    // 0x6459fc: StoreField: r1->field_13 = r0
    //     0x6459fc: stur            w0, [x1, #0x13]
    // 0x645a00: r0 = Padding()
    //     0x645a00: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x645a04: mov             x1, x0
    // 0x645a08: r0 = Instance_EdgeInsets
    //     0x645a08: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c020] Obj!EdgeInsets@831d11
    //     0x645a0c: ldr             x0, [x0, #0x20]
    // 0x645a10: StoreField: r1->field_f = r0
    //     0x645a10: stur            w0, [x1, #0xf]
    // 0x645a14: ldur            x0, [fp, #-0x20]
    // 0x645a18: StoreField: r1->field_b = r0
    //     0x645a18: stur            w0, [x1, #0xb]
    // 0x645a1c: mov             x3, x1
    // 0x645a20: b               #0x645a28
    // 0x645a24: r3 = Instance_SizedBox
    //     0x645a24: ldr             x3, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x645a28: ldur            x0, [fp, #-8]
    // 0x645a2c: stur            x3, [fp, #-0x10]
    // 0x645a30: r1 = Null
    //     0x645a30: mov             x1, NULL
    // 0x645a34: r2 = 4
    //     0x645a34: movz            x2, #0x4
    // 0x645a38: r0 = AllocateArray()
    //     0x645a38: bl              #0x82746c  ; AllocateArrayStub
    // 0x645a3c: r16 = "difficulty_index_"
    //     0x645a3c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cd0] "difficulty_index_"
    //     0x645a40: ldr             x16, [x16, #0xcd0]
    // 0x645a44: StoreField: r0->field_f = r16
    //     0x645a44: stur            w16, [x0, #0xf]
    // 0x645a48: ldur            x1, [fp, #-8]
    // 0x645a4c: LoadField: r2 = r1->field_b
    //     0x645a4c: ldur            w2, [x1, #0xb]
    // 0x645a50: DecompressPointer r2
    //     0x645a50: add             x2, x2, HEAP, lsl #32
    // 0x645a54: cmp             w2, NULL
    // 0x645a58: b.eq            #0x645dcc
    // 0x645a5c: LoadField: r3 = r2->field_b
    //     0x645a5c: ldur            w3, [x2, #0xb]
    // 0x645a60: DecompressPointer r3
    //     0x645a60: add             x3, x3, HEAP, lsl #32
    // 0x645a64: StoreField: r0->field_13 = r3
    //     0x645a64: stur            w3, [x0, #0x13]
    // 0x645a68: str             x0, [SP]
    // 0x645a6c: r0 = _interpolate()
    //     0x645a6c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x645a70: mov             x1, x0
    // 0x645a74: r0 = prefsGetInt()
    //     0x645a74: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x645a78: cmp             w0, NULL
    // 0x645a7c: b.ne            #0x645a8c
    // 0x645a80: r3 = Instance_Padding
    //     0x645a80: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c028] Obj!Padding@85df61
    //     0x645a84: ldr             x3, [x3, #0x28]
    // 0x645a88: b               #0x645a90
    // 0x645a8c: r3 = Instance_SizedBox
    //     0x645a8c: ldr             x3, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x645a90: ldur            x0, [fp, #-8]
    // 0x645a94: ldur            x2, [fp, #-0x28]
    // 0x645a98: ldur            x1, [fp, #-0x10]
    // 0x645a9c: stur            x3, [fp, #-0x20]
    // 0x645aa0: LoadField: r4 = r0->field_13
    //     0x645aa0: ldur            w4, [x0, #0x13]
    // 0x645aa4: DecompressPointer r4
    //     0x645aa4: add             x4, x4, HEAP, lsl #32
    // 0x645aa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x645aac: cmp             w4, w16
    // 0x645ab0: b.eq            #0x645dd0
    // 0x645ab4: r0 = LoadInt32Instr(r4)
    //     0x645ab4: sbfx            x0, x4, #1, #0x1f
    //     0x645ab8: tbz             w4, #0, #0x645ac0
    //     0x645abc: ldur            x0, [x4, #7]
    // 0x645ac0: stur            x0, [fp, #-0x30]
    // 0x645ac4: r0 = AppleNumberPicker()
    //     0x645ac4: bl              #0x645ddc  ; AllocateAppleNumberPickerStub -> AppleNumberPicker (size=0x18)
    // 0x645ac8: mov             x3, x0
    // 0x645acc: ldur            x0, [fp, #-0x30]
    // 0x645ad0: stur            x3, [fp, #-8]
    // 0x645ad4: StoreField: r3->field_f = r0
    //     0x645ad4: stur            x0, [x3, #0xf]
    // 0x645ad8: ldur            x2, [fp, #-0x18]
    // 0x645adc: r1 = Function '<anonymous closure>':.
    //     0x645adc: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c030] AnonymousClosure: (0x646340), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x645ae0: ldr             x1, [x1, #0x30]
    // 0x645ae4: r0 = AllocateClosure()
    //     0x645ae4: bl              #0x826750  ; AllocateClosureStub
    // 0x645ae8: mov             x1, x0
    // 0x645aec: ldur            x0, [fp, #-8]
    // 0x645af0: StoreField: r0->field_b = r1
    //     0x645af0: stur            w1, [x0, #0xb]
    // 0x645af4: r1 = <FlexParentData>
    //     0x645af4: add             x1, PP, #0x19, lsl #12  ; [pp+0x191f0] TypeArguments: <FlexParentData>
    //     0x645af8: ldr             x1, [x1, #0x1f0]
    // 0x645afc: r0 = Flexible()
    //     0x645afc: bl              #0x59ff8c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x645b00: mov             x3, x0
    // 0x645b04: r0 = 1
    //     0x645b04: movz            x0, #0x1
    // 0x645b08: stur            x3, [fp, #-0x38]
    // 0x645b0c: StoreField: r3->field_13 = r0
    //     0x645b0c: stur            x0, [x3, #0x13]
    // 0x645b10: r0 = Instance_FlexFit
    //     0x645b10: add             x0, PP, #0x19, lsl #12  ; [pp+0x191f8] Obj!FlexFit@862ae1
    //     0x645b14: ldr             x0, [x0, #0x1f8]
    // 0x645b18: StoreField: r3->field_1b = r0
    //     0x645b18: stur            w0, [x3, #0x1b]
    // 0x645b1c: ldur            x0, [fp, #-8]
    // 0x645b20: StoreField: r3->field_b = r0
    //     0x645b20: stur            w0, [x3, #0xb]
    // 0x645b24: r1 = Null
    //     0x645b24: mov             x1, NULL
    // 0x645b28: r2 = 16
    //     0x645b28: movz            x2, #0x10
    // 0x645b2c: r0 = AllocateArray()
    //     0x645b2c: bl              #0x82746c  ; AllocateArrayStub
    // 0x645b30: stur            x0, [fp, #-8]
    // 0x645b34: r16 = Instance_Text
    //     0x645b34: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c038] Obj!Text@852f11
    //     0x645b38: ldr             x16, [x16, #0x38]
    // 0x645b3c: StoreField: r0->field_f = r16
    //     0x645b3c: stur            w16, [x0, #0xf]
    // 0x645b40: r16 = Instance_SizedBox
    //     0x645b40: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a658] Obj!SizedBox@85d201
    //     0x645b44: ldr             x16, [x16, #0x658]
    // 0x645b48: StoreField: r0->field_13 = r16
    //     0x645b48: stur            w16, [x0, #0x13]
    // 0x645b4c: ldur            x1, [fp, #-0x28]
    // 0x645b50: ArrayStore: r0[0] = r1  ; List_4
    //     0x645b50: stur            w1, [x0, #0x17]
    // 0x645b54: ldur            x1, [fp, #-0x10]
    // 0x645b58: StoreField: r0->field_1b = r1
    //     0x645b58: stur            w1, [x0, #0x1b]
    // 0x645b5c: ldur            x1, [fp, #-0x20]
    // 0x645b60: StoreField: r0->field_1f = r1
    //     0x645b60: stur            w1, [x0, #0x1f]
    // 0x645b64: r16 = Instance_SizedBox
    //     0x645b64: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cb80] Obj!SizedBox@85d221
    //     0x645b68: ldr             x16, [x16, #0xb80]
    // 0x645b6c: StoreField: r0->field_23 = r16
    //     0x645b6c: stur            w16, [x0, #0x23]
    // 0x645b70: r16 = Instance_ExcludeSemantics
    //     0x645b70: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c040] Obj!ExcludeSemantics@85d1b1
    //     0x645b74: ldr             x16, [x16, #0x40]
    // 0x645b78: StoreField: r0->field_27 = r16
    //     0x645b78: stur            w16, [x0, #0x27]
    // 0x645b7c: ldur            x1, [fp, #-0x38]
    // 0x645b80: StoreField: r0->field_2b = r1
    //     0x645b80: stur            w1, [x0, #0x2b]
    // 0x645b84: r1 = <Widget>
    //     0x645b84: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x645b88: r0 = AllocateGrowableArray()
    //     0x645b88: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x645b8c: mov             x1, x0
    // 0x645b90: ldur            x0, [fp, #-8]
    // 0x645b94: stur            x1, [fp, #-0x10]
    // 0x645b98: StoreField: r1->field_f = r0
    //     0x645b98: stur            w0, [x1, #0xf]
    // 0x645b9c: r0 = 16
    //     0x645b9c: movz            x0, #0x10
    // 0x645ba0: StoreField: r1->field_b = r0
    //     0x645ba0: stur            w0, [x1, #0xb]
    // 0x645ba4: r0 = Column()
    //     0x645ba4: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x645ba8: mov             x1, x0
    // 0x645bac: r0 = Instance_Axis
    //     0x645bac: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x645bb0: stur            x1, [fp, #-8]
    // 0x645bb4: StoreField: r1->field_f = r0
    //     0x645bb4: stur            w0, [x1, #0xf]
    // 0x645bb8: r0 = Instance_MainAxisAlignment
    //     0x645bb8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x645bbc: ldr             x0, [x0, #0x200]
    // 0x645bc0: StoreField: r1->field_13 = r0
    //     0x645bc0: stur            w0, [x1, #0x13]
    // 0x645bc4: r0 = Instance_MainAxisSize
    //     0x645bc4: add             x0, PP, #0x19, lsl #12  ; [pp+0x19208] Obj!MainAxisSize@862a81
    //     0x645bc8: ldr             x0, [x0, #0x208]
    // 0x645bcc: ArrayStore: r1[0] = r0  ; List_4
    //     0x645bcc: stur            w0, [x1, #0x17]
    // 0x645bd0: r0 = Instance_CrossAxisAlignment
    //     0x645bd0: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1bd18] Obj!CrossAxisAlignment@862981
    //     0x645bd4: ldr             x0, [x0, #0xd18]
    // 0x645bd8: StoreField: r1->field_1b = r0
    //     0x645bd8: stur            w0, [x1, #0x1b]
    // 0x645bdc: r0 = Instance_VerticalDirection
    //     0x645bdc: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x645be0: ldr             x0, [x0, #0x1e8]
    // 0x645be4: StoreField: r1->field_23 = r0
    //     0x645be4: stur            w0, [x1, #0x23]
    // 0x645be8: r0 = Instance_Clip
    //     0x645be8: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x645bec: ldr             x0, [x0, #0x1b0]
    // 0x645bf0: StoreField: r1->field_2b = r0
    //     0x645bf0: stur            w0, [x1, #0x2b]
    // 0x645bf4: StoreField: r1->field_2f = rZR
    //     0x645bf4: stur            xzr, [x1, #0x2f]
    // 0x645bf8: ldur            x0, [fp, #-0x10]
    // 0x645bfc: StoreField: r1->field_b = r0
    //     0x645bfc: stur            w0, [x1, #0xb]
    // 0x645c00: r0 = TextButton()
    //     0x645c00: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x645c04: mov             x3, x0
    // 0x645c08: r0 = false
    //     0x645c08: add             x0, NULL, #0x30  ; false
    // 0x645c0c: stur            x3, [fp, #-0x10]
    // 0x645c10: StoreField: r3->field_3f = r0
    //     0x645c10: stur            w0, [x3, #0x3f]
    // 0x645c14: ldur            x2, [fp, #-0x18]
    // 0x645c18: r1 = Function '<anonymous closure>':.
    //     0x645c18: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c048] AnonymousClosure: (0x646034), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x645c1c: ldr             x1, [x1, #0x48]
    // 0x645c20: r0 = AllocateClosure()
    //     0x645c20: bl              #0x826750  ; AllocateClosureStub
    // 0x645c24: mov             x1, x0
    // 0x645c28: ldur            x0, [fp, #-0x10]
    // 0x645c2c: StoreField: r0->field_b = r1
    //     0x645c2c: stur            w1, [x0, #0xb]
    // 0x645c30: r1 = false
    //     0x645c30: add             x1, NULL, #0x30  ; false
    // 0x645c34: StoreField: r0->field_27 = r1
    //     0x645c34: stur            w1, [x0, #0x27]
    // 0x645c38: r2 = true
    //     0x645c38: add             x2, NULL, #0x20  ; true
    // 0x645c3c: StoreField: r0->field_2f = r2
    //     0x645c3c: stur            w2, [x0, #0x2f]
    // 0x645c40: r3 = Instance_Text
    //     0x645c40: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c050] Obj!Text@852d81
    //     0x645c44: ldr             x3, [x3, #0x50]
    // 0x645c48: StoreField: r0->field_3b = r3
    //     0x645c48: stur            w3, [x0, #0x3b]
    // 0x645c4c: r0 = TextButton()
    //     0x645c4c: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x645c50: mov             x3, x0
    // 0x645c54: r0 = false
    //     0x645c54: add             x0, NULL, #0x30  ; false
    // 0x645c58: stur            x3, [fp, #-0x20]
    // 0x645c5c: StoreField: r3->field_3f = r0
    //     0x645c5c: stur            w0, [x3, #0x3f]
    // 0x645c60: ldur            x2, [fp, #-0x18]
    // 0x645c64: r1 = Function '<anonymous closure>':.
    //     0x645c64: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c058] AnonymousClosure: (0x645f20), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x645c68: ldr             x1, [x1, #0x58]
    // 0x645c6c: r0 = AllocateClosure()
    //     0x645c6c: bl              #0x826750  ; AllocateClosureStub
    // 0x645c70: mov             x1, x0
    // 0x645c74: ldur            x0, [fp, #-0x20]
    // 0x645c78: StoreField: r0->field_b = r1
    //     0x645c78: stur            w1, [x0, #0xb]
    // 0x645c7c: r1 = false
    //     0x645c7c: add             x1, NULL, #0x30  ; false
    // 0x645c80: StoreField: r0->field_27 = r1
    //     0x645c80: stur            w1, [x0, #0x27]
    // 0x645c84: r2 = true
    //     0x645c84: add             x2, NULL, #0x20  ; true
    // 0x645c88: StoreField: r0->field_2f = r2
    //     0x645c88: stur            w2, [x0, #0x2f]
    // 0x645c8c: r3 = Instance_Text
    //     0x645c8c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c060] Obj!Text@852d31
    //     0x645c90: ldr             x3, [x3, #0x60]
    // 0x645c94: StoreField: r0->field_3b = r3
    //     0x645c94: stur            w3, [x0, #0x3b]
    // 0x645c98: r0 = TextButton()
    //     0x645c98: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x645c9c: mov             x3, x0
    // 0x645ca0: r0 = false
    //     0x645ca0: add             x0, NULL, #0x30  ; false
    // 0x645ca4: stur            x3, [fp, #-0x28]
    // 0x645ca8: StoreField: r3->field_3f = r0
    //     0x645ca8: stur            w0, [x3, #0x3f]
    // 0x645cac: ldur            x2, [fp, #-0x18]
    // 0x645cb0: r1 = Function '<anonymous closure>':.
    //     0x645cb0: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c068] AnonymousClosure: (0x645e44), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x645cb4: ldr             x1, [x1, #0x68]
    // 0x645cb8: r0 = AllocateClosure()
    //     0x645cb8: bl              #0x826750  ; AllocateClosureStub
    // 0x645cbc: mov             x1, x0
    // 0x645cc0: ldur            x0, [fp, #-0x28]
    // 0x645cc4: StoreField: r0->field_b = r1
    //     0x645cc4: stur            w1, [x0, #0xb]
    // 0x645cc8: r1 = false
    //     0x645cc8: add             x1, NULL, #0x30  ; false
    // 0x645ccc: StoreField: r0->field_27 = r1
    //     0x645ccc: stur            w1, [x0, #0x27]
    // 0x645cd0: r2 = true
    //     0x645cd0: add             x2, NULL, #0x20  ; true
    // 0x645cd4: StoreField: r0->field_2f = r2
    //     0x645cd4: stur            w2, [x0, #0x2f]
    // 0x645cd8: r3 = Instance_Text
    //     0x645cd8: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c070] Obj!Text@852ce1
    //     0x645cdc: ldr             x3, [x3, #0x70]
    // 0x645ce0: StoreField: r0->field_3b = r3
    //     0x645ce0: stur            w3, [x0, #0x3b]
    // 0x645ce4: r0 = TextButton()
    //     0x645ce4: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x645ce8: mov             x3, x0
    // 0x645cec: r0 = false
    //     0x645cec: add             x0, NULL, #0x30  ; false
    // 0x645cf0: stur            x3, [fp, #-0x38]
    // 0x645cf4: StoreField: r3->field_3f = r0
    //     0x645cf4: stur            w0, [x3, #0x3f]
    // 0x645cf8: ldur            x2, [fp, #-0x18]
    // 0x645cfc: r1 = Function '<anonymous closure>':.
    //     0x645cfc: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c078] AnonymousClosure: (0x645de8), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x645d00: ldr             x1, [x1, #0x78]
    // 0x645d04: r0 = AllocateClosure()
    //     0x645d04: bl              #0x826750  ; AllocateClosureStub
    // 0x645d08: mov             x1, x0
    // 0x645d0c: ldur            x0, [fp, #-0x38]
    // 0x645d10: StoreField: r0->field_b = r1
    //     0x645d10: stur            w1, [x0, #0xb]
    // 0x645d14: r3 = false
    //     0x645d14: add             x3, NULL, #0x30  ; false
    // 0x645d18: StoreField: r0->field_27 = r3
    //     0x645d18: stur            w3, [x0, #0x27]
    // 0x645d1c: r1 = true
    //     0x645d1c: add             x1, NULL, #0x20  ; true
    // 0x645d20: StoreField: r0->field_2f = r1
    //     0x645d20: stur            w1, [x0, #0x2f]
    // 0x645d24: r1 = Instance_Text
    //     0x645d24: add             x1, PP, #0x25, lsl #12  ; [pp+0x25a00] Obj!Text@84f451
    //     0x645d28: ldr             x1, [x1, #0xa00]
    // 0x645d2c: StoreField: r0->field_3b = r1
    //     0x645d2c: stur            w1, [x0, #0x3b]
    // 0x645d30: r1 = Null
    //     0x645d30: mov             x1, NULL
    // 0x645d34: r2 = 8
    //     0x645d34: movz            x2, #0x8
    // 0x645d38: r0 = AllocateArray()
    //     0x645d38: bl              #0x82746c  ; AllocateArrayStub
    // 0x645d3c: mov             x2, x0
    // 0x645d40: ldur            x0, [fp, #-0x10]
    // 0x645d44: stur            x2, [fp, #-0x18]
    // 0x645d48: StoreField: r2->field_f = r0
    //     0x645d48: stur            w0, [x2, #0xf]
    // 0x645d4c: ldur            x0, [fp, #-0x20]
    // 0x645d50: StoreField: r2->field_13 = r0
    //     0x645d50: stur            w0, [x2, #0x13]
    // 0x645d54: ldur            x0, [fp, #-0x28]
    // 0x645d58: ArrayStore: r2[0] = r0  ; List_4
    //     0x645d58: stur            w0, [x2, #0x17]
    // 0x645d5c: ldur            x0, [fp, #-0x38]
    // 0x645d60: StoreField: r2->field_1b = r0
    //     0x645d60: stur            w0, [x2, #0x1b]
    // 0x645d64: r1 = <Widget>
    //     0x645d64: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x645d68: r0 = AllocateGrowableArray()
    //     0x645d68: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x645d6c: mov             x1, x0
    // 0x645d70: ldur            x0, [fp, #-0x18]
    // 0x645d74: stur            x1, [fp, #-0x10]
    // 0x645d78: StoreField: r1->field_f = r0
    //     0x645d78: stur            w0, [x1, #0xf]
    // 0x645d7c: r0 = 8
    //     0x645d7c: movz            x0, #0x8
    // 0x645d80: StoreField: r1->field_b = r0
    //     0x645d80: stur            w0, [x1, #0xb]
    // 0x645d84: r0 = AlertDialog()
    //     0x645d84: bl              #0x490074  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x645d88: r1 = Instance_Focus
    //     0x645d88: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c080] Obj!Focus@857a51
    //     0x645d8c: ldr             x1, [x1, #0x80]
    // 0x645d90: StoreField: r0->field_f = r1
    //     0x645d90: stur            w1, [x0, #0xf]
    // 0x645d94: ldur            x1, [fp, #-8]
    // 0x645d98: StoreField: r0->field_1b = r1
    //     0x645d98: stur            w1, [x0, #0x1b]
    // 0x645d9c: ldur            x1, [fp, #-0x10]
    // 0x645da0: StoreField: r0->field_27 = r1
    //     0x645da0: stur            w1, [x0, #0x27]
    // 0x645da4: r1 = false
    //     0x645da4: add             x1, NULL, #0x30  ; false
    // 0x645da8: StoreField: r0->field_6b = r1
    //     0x645da8: stur            w1, [x0, #0x6b]
    // 0x645dac: LeaveFrame
    //     0x645dac: mov             SP, fp
    //     0x645db0: ldp             fp, lr, [SP], #0x10
    // 0x645db4: ret
    //     0x645db4: ret             
    // 0x645db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x645db8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x645dbc: b               #0x645850
    // 0x645dc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x645dc0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x645dc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x645dc4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x645dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x645dc8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x645dcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x645dcc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x645dd0: r9 = currentDifficulty
    //     0x645dd0: add             x9, PP, #0x2c, lsl #12  ; [pp+0x2c088] Field <_DifficultyChooserState@955301480.currentDifficulty>: late (offset: 0x14)
    //     0x645dd4: ldr             x9, [x9, #0x88]
    // 0x645dd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x645dd8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x645de8, size: 0x5c
    // 0x645de8: EnterFrame
    //     0x645de8: stp             fp, lr, [SP, #-0x10]!
    //     0x645dec: mov             fp, SP
    // 0x645df0: AllocStack(0x10)
    //     0x645df0: sub             SP, SP, #0x10
    // 0x645df4: SetupParameters([dynamic _ /* r0 */])
    //     0x645df4: ldr             x0, [fp, #0x10]
    //     0x645df8: ldur            w1, [x0, #0x17]
    //     0x645dfc: add             x1, x1, HEAP, lsl #32
    // 0x645e00: CheckStackOverflow
    //     0x645e00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x645e04: cmp             SP, x16
    //     0x645e08: b.ls            #0x645e3c
    // 0x645e0c: LoadField: r0 = r1->field_13
    //     0x645e0c: ldur            w0, [x1, #0x13]
    // 0x645e10: DecompressPointer r0
    //     0x645e10: add             x0, x0, HEAP, lsl #32
    // 0x645e14: mov             x1, x0
    // 0x645e18: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x645e18: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x645e1c: r0 = of()
    //     0x645e1c: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x645e20: r16 = <Object?>
    //     0x645e20: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x645e24: stp             x0, x16, [SP]
    // 0x645e28: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x645e28: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x645e2c: r0 = maybePop()
    //     0x645e2c: bl              #0x3842c0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x645e30: LeaveFrame
    //     0x645e30: mov             SP, fp
    //     0x645e34: ldp             fp, lr, [SP], #0x10
    // 0x645e38: ret
    //     0x645e38: ret             
    // 0x645e3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x645e3c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x645e40: b               #0x645e0c
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x645e44, size: 0xdc
    // 0x645e44: EnterFrame
    //     0x645e44: stp             fp, lr, [SP, #-0x10]!
    //     0x645e48: mov             fp, SP
    // 0x645e4c: AllocStack(0x28)
    //     0x645e4c: sub             SP, SP, #0x28
    // 0x645e50: SetupParameters(_DifficultyChooserState this /* r1 */)
    //     0x645e50: stur            NULL, [fp, #-8]
    //     0x645e54: movz            x0, #0
    //     0x645e58: add             x1, fp, w0, sxtw #2
    //     0x645e5c: ldr             x1, [x1, #0x10]
    //     0x645e60: ldur            w2, [x1, #0x17]
    //     0x645e64: add             x2, x2, HEAP, lsl #32
    //     0x645e68: stur            x2, [fp, #-0x10]
    // 0x645e6c: CheckStackOverflow
    //     0x645e6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x645e70: cmp             SP, x16
    //     0x645e74: b.ls            #0x645f14
    // 0x645e78: InitAsync() -> Future<void?>
    //     0x645e78: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x645e7c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x645e80: r1 = Null
    //     0x645e80: mov             x1, NULL
    // 0x645e84: r2 = 4
    //     0x645e84: movz            x2, #0x4
    // 0x645e88: r0 = AllocateArray()
    //     0x645e88: bl              #0x82746c  ; AllocateArrayStub
    // 0x645e8c: r16 = "difficulty_index_"
    //     0x645e8c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cd0] "difficulty_index_"
    //     0x645e90: ldr             x16, [x16, #0xcd0]
    // 0x645e94: StoreField: r0->field_f = r16
    //     0x645e94: stur            w16, [x0, #0xf]
    // 0x645e98: ldur            x1, [fp, #-0x10]
    // 0x645e9c: LoadField: r2 = r1->field_f
    //     0x645e9c: ldur            w2, [x1, #0xf]
    // 0x645ea0: DecompressPointer r2
    //     0x645ea0: add             x2, x2, HEAP, lsl #32
    // 0x645ea4: LoadField: r3 = r2->field_b
    //     0x645ea4: ldur            w3, [x2, #0xb]
    // 0x645ea8: DecompressPointer r3
    //     0x645ea8: add             x3, x3, HEAP, lsl #32
    // 0x645eac: cmp             w3, NULL
    // 0x645eb0: b.eq            #0x645f1c
    // 0x645eb4: LoadField: r2 = r3->field_b
    //     0x645eb4: ldur            w2, [x3, #0xb]
    // 0x645eb8: DecompressPointer r2
    //     0x645eb8: add             x2, x2, HEAP, lsl #32
    // 0x645ebc: StoreField: r0->field_13 = r2
    //     0x645ebc: stur            w2, [x0, #0x13]
    // 0x645ec0: str             x0, [SP]
    // 0x645ec4: r0 = _interpolate()
    //     0x645ec4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x645ec8: mov             x1, x0
    // 0x645ecc: r0 = prefsRemove()
    //     0x645ecc: bl              #0x633dd0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsRemove
    // 0x645ed0: r1 = "updated_difficulty_indicator"
    //     0x645ed0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26070] "updated_difficulty_indicator"
    //     0x645ed4: ldr             x1, [x1, #0x70]
    // 0x645ed8: r0 = broadcastToListeners()
    //     0x645ed8: bl              #0x4513b8  ; [package:state_groups/src/sync_state.dart] ::broadcastToListeners
    // 0x645edc: ldur            x0, [fp, #-0x10]
    // 0x645ee0: LoadField: r1 = r0->field_13
    //     0x645ee0: ldur            w1, [x0, #0x13]
    // 0x645ee4: DecompressPointer r1
    //     0x645ee4: add             x1, x1, HEAP, lsl #32
    // 0x645ee8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x645ee8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x645eec: r0 = of()
    //     0x645eec: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x645ef0: r16 = <Object?>
    //     0x645ef0: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x645ef4: stp             x0, x16, [SP]
    // 0x645ef8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x645ef8: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x645efc: r0 = maybePop()
    //     0x645efc: bl              #0x3842c0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x645f00: mov             x1, x0
    // 0x645f04: stur            x1, [fp, #-0x18]
    // 0x645f08: r0 = Await()
    //     0x645f08: bl              #0x34b75c  ; AwaitStub
    // 0x645f0c: r0 = Null
    //     0x645f0c: mov             x0, NULL
    // 0x645f10: r0 = ReturnAsyncNotFuture()
    //     0x645f10: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x645f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x645f14: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x645f18: b               #0x645e78
    // 0x645f1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x645f1c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x645f20, size: 0x114
    // 0x645f20: EnterFrame
    //     0x645f20: stp             fp, lr, [SP, #-0x10]!
    //     0x645f24: mov             fp, SP
    // 0x645f28: AllocStack(0x28)
    //     0x645f28: sub             SP, SP, #0x28
    // 0x645f2c: SetupParameters(_DifficultyChooserState this /* r1 */)
    //     0x645f2c: stur            NULL, [fp, #-8]
    //     0x645f30: movz            x0, #0
    //     0x645f34: add             x1, fp, w0, sxtw #2
    //     0x645f38: ldr             x1, [x1, #0x10]
    //     0x645f3c: ldur            w2, [x1, #0x17]
    //     0x645f40: add             x2, x2, HEAP, lsl #32
    //     0x645f44: stur            x2, [fp, #-0x10]
    // 0x645f48: CheckStackOverflow
    //     0x645f48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x645f4c: cmp             SP, x16
    //     0x645f50: b.ls            #0x64601c
    // 0x645f54: InitAsync() -> Future<void?>
    //     0x645f54: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x645f58: bl              #0x34b9a0  ; InitAsyncStub
    // 0x645f5c: r1 = Null
    //     0x645f5c: mov             x1, NULL
    // 0x645f60: r2 = 4
    //     0x645f60: movz            x2, #0x4
    // 0x645f64: r0 = AllocateArray()
    //     0x645f64: bl              #0x82746c  ; AllocateArrayStub
    // 0x645f68: r16 = "difficulty_index_"
    //     0x645f68: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cd0] "difficulty_index_"
    //     0x645f6c: ldr             x16, [x16, #0xcd0]
    // 0x645f70: StoreField: r0->field_f = r16
    //     0x645f70: stur            w16, [x0, #0xf]
    // 0x645f74: ldur            x1, [fp, #-0x10]
    // 0x645f78: LoadField: r2 = r1->field_f
    //     0x645f78: ldur            w2, [x1, #0xf]
    // 0x645f7c: DecompressPointer r2
    //     0x645f7c: add             x2, x2, HEAP, lsl #32
    // 0x645f80: LoadField: r3 = r2->field_b
    //     0x645f80: ldur            w3, [x2, #0xb]
    // 0x645f84: DecompressPointer r3
    //     0x645f84: add             x3, x3, HEAP, lsl #32
    // 0x645f88: cmp             w3, NULL
    // 0x645f8c: b.eq            #0x646024
    // 0x645f90: LoadField: r2 = r3->field_b
    //     0x645f90: ldur            w2, [x3, #0xb]
    // 0x645f94: DecompressPointer r2
    //     0x645f94: add             x2, x2, HEAP, lsl #32
    // 0x645f98: StoreField: r0->field_13 = r2
    //     0x645f98: stur            w2, [x0, #0x13]
    // 0x645f9c: str             x0, [SP]
    // 0x645fa0: r0 = _interpolate()
    //     0x645fa0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x645fa4: mov             x1, x0
    // 0x645fa8: ldur            x0, [fp, #-0x10]
    // 0x645fac: LoadField: r2 = r0->field_f
    //     0x645fac: ldur            w2, [x0, #0xf]
    // 0x645fb0: DecompressPointer r2
    //     0x645fb0: add             x2, x2, HEAP, lsl #32
    // 0x645fb4: LoadField: r3 = r2->field_13
    //     0x645fb4: ldur            w3, [x2, #0x13]
    // 0x645fb8: DecompressPointer r3
    //     0x645fb8: add             x3, x3, HEAP, lsl #32
    // 0x645fbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x645fc0: cmp             w3, w16
    // 0x645fc4: b.eq            #0x646028
    // 0x645fc8: r2 = LoadInt32Instr(r3)
    //     0x645fc8: sbfx            x2, x3, #1, #0x1f
    //     0x645fcc: tbz             w3, #0, #0x645fd4
    //     0x645fd0: ldur            x2, [x3, #7]
    // 0x645fd4: r0 = prefsSetInt()
    //     0x645fd4: bl              #0x35e50c  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetInt
    // 0x645fd8: r1 = "updated_difficulty_indicator"
    //     0x645fd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26070] "updated_difficulty_indicator"
    //     0x645fdc: ldr             x1, [x1, #0x70]
    // 0x645fe0: r0 = broadcastToListeners()
    //     0x645fe0: bl              #0x4513b8  ; [package:state_groups/src/sync_state.dart] ::broadcastToListeners
    // 0x645fe4: ldur            x0, [fp, #-0x10]
    // 0x645fe8: LoadField: r1 = r0->field_13
    //     0x645fe8: ldur            w1, [x0, #0x13]
    // 0x645fec: DecompressPointer r1
    //     0x645fec: add             x1, x1, HEAP, lsl #32
    // 0x645ff0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x645ff0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x645ff4: r0 = of()
    //     0x645ff4: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x645ff8: r16 = <Object?>
    //     0x645ff8: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x645ffc: stp             x0, x16, [SP]
    // 0x646000: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x646000: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x646004: r0 = maybePop()
    //     0x646004: bl              #0x3842c0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x646008: mov             x1, x0
    // 0x64600c: stur            x1, [fp, #-0x18]
    // 0x646010: r0 = Await()
    //     0x646010: bl              #0x34b75c  ; AwaitStub
    // 0x646014: r0 = Null
    //     0x646014: mov             x0, NULL
    // 0x646018: r0 = ReturnAsyncNotFuture()
    //     0x646018: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x64601c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64601c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x646020: b               #0x645f54
    // 0x646024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646024: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646028: r9 = currentDifficulty
    //     0x646028: add             x9, PP, #0x2c, lsl #12  ; [pp+0x2c088] Field <_DifficultyChooserState@955301480.currentDifficulty>: late (offset: 0x14)
    //     0x64602c: ldr             x9, [x9, #0x88]
    // 0x646030: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x646030: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x646034, size: 0x84
    // 0x646034: EnterFrame
    //     0x646034: stp             fp, lr, [SP, #-0x10]!
    //     0x646038: mov             fp, SP
    // 0x64603c: AllocStack(0x38)
    //     0x64603c: sub             SP, SP, #0x38
    // 0x646040: SetupParameters(_DifficultyChooserState this /* r1 */)
    //     0x646040: stur            NULL, [fp, #-8]
    //     0x646044: movz            x0, #0
    //     0x646048: add             x1, fp, w0, sxtw #2
    //     0x64604c: ldr             x1, [x1, #0x10]
    //     0x646050: ldur            w2, [x1, #0x17]
    //     0x646054: add             x2, x2, HEAP, lsl #32
    //     0x646058: stur            x2, [fp, #-0x10]
    // 0x64605c: CheckStackOverflow
    //     0x64605c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x646060: cmp             SP, x16
    //     0x646064: b.ls            #0x6460b0
    // 0x646068: InitAsync() -> Future<void?>
    //     0x646068: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x64606c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x646070: ldur            x2, [fp, #-0x10]
    // 0x646074: LoadField: r0 = r2->field_13
    //     0x646074: ldur            w0, [x2, #0x13]
    // 0x646078: DecompressPointer r0
    //     0x646078: add             x0, x0, HEAP, lsl #32
    // 0x64607c: stur            x0, [fp, #-0x18]
    // 0x646080: r1 = Function '<anonymous closure>':.
    //     0x646080: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c090] AnonymousClosure: (0x6460b8), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x646084: ldr             x1, [x1, #0x90]
    // 0x646088: r0 = AllocateClosure()
    //     0x646088: bl              #0x826750  ; AllocateClosureStub
    // 0x64608c: r16 = <void?>
    //     0x64608c: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x646090: stp             x0, x16, [SP, #0x10]
    // 0x646094: ldur            x16, [fp, #-0x18]
    // 0x646098: r30 = true
    //     0x646098: add             lr, NULL, #0x20  ; true
    // 0x64609c: stp             lr, x16, [SP]
    // 0x6460a0: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x6460a0: add             x4, PP, #0xe, lsl #12  ; [pp+0xe4f8] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x6460a4: ldr             x4, [x4, #0x4f8]
    // 0x6460a8: r0 = showDialog()
    //     0x6460a8: bl              #0x3ecee0  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x6460ac: r0 = ReturnAsync()
    //     0x6460ac: b               #0x353380  ; ReturnAsyncStub
    // 0x6460b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6460b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6460b4: b               #0x646068
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6460b8, size: 0x130
    // 0x6460b8: EnterFrame
    //     0x6460b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6460bc: mov             fp, SP
    // 0x6460c0: AllocStack(0x18)
    //     0x6460c0: sub             SP, SP, #0x18
    // 0x6460c4: SetupParameters([dynamic _ /* r0 */])
    //     0x6460c4: ldr             x0, [fp, #0x18]
    //     0x6460c8: ldur            w2, [x0, #0x17]
    //     0x6460cc: add             x2, x2, HEAP, lsl #32
    //     0x6460d0: stur            x2, [fp, #-8]
    // 0x6460d4: r0 = TextButton()
    //     0x6460d4: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x6460d8: mov             x3, x0
    // 0x6460dc: r0 = false
    //     0x6460dc: add             x0, NULL, #0x30  ; false
    // 0x6460e0: stur            x3, [fp, #-0x10]
    // 0x6460e4: StoreField: r3->field_3f = r0
    //     0x6460e4: stur            w0, [x3, #0x3f]
    // 0x6460e8: ldur            x2, [fp, #-8]
    // 0x6460ec: r1 = Function '<anonymous closure>':.
    //     0x6460ec: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c098] AnonymousClosure: (0x6461e8), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyChooserState::build (0x645830)
    //     0x6460f0: ldr             x1, [x1, #0x98]
    // 0x6460f4: r0 = AllocateClosure()
    //     0x6460f4: bl              #0x826750  ; AllocateClosureStub
    // 0x6460f8: mov             x1, x0
    // 0x6460fc: ldur            x0, [fp, #-0x10]
    // 0x646100: StoreField: r0->field_b = r1
    //     0x646100: stur            w1, [x0, #0xb]
    // 0x646104: r1 = false
    //     0x646104: add             x1, NULL, #0x30  ; false
    // 0x646108: StoreField: r0->field_27 = r1
    //     0x646108: stur            w1, [x0, #0x27]
    // 0x64610c: r2 = true
    //     0x64610c: add             x2, NULL, #0x20  ; true
    // 0x646110: StoreField: r0->field_2f = r2
    //     0x646110: stur            w2, [x0, #0x2f]
    // 0x646114: r3 = Instance_Text
    //     0x646114: add             x3, PP, #0x23, lsl #12  ; [pp+0x23d20] Obj!Text@84f361
    //     0x646118: ldr             x3, [x3, #0xd20]
    // 0x64611c: StoreField: r0->field_3b = r3
    //     0x64611c: stur            w3, [x0, #0x3b]
    // 0x646120: r0 = TextButton()
    //     0x646120: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x646124: mov             x3, x0
    // 0x646128: r0 = false
    //     0x646128: add             x0, NULL, #0x30  ; false
    // 0x64612c: stur            x3, [fp, #-0x18]
    // 0x646130: StoreField: r3->field_3f = r0
    //     0x646130: stur            w0, [x3, #0x3f]
    // 0x646134: ldur            x2, [fp, #-8]
    // 0x646138: r1 = Function '<anonymous closure>':.
    //     0x646138: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0a0] AnonymousClosure: (0x5a4e9c), in [package:pretentious/Popups/MenuPopup/MenuPopup.dart] MenuPopupState::build (0x620ce4)
    //     0x64613c: ldr             x1, [x1, #0xa0]
    // 0x646140: r0 = AllocateClosure()
    //     0x646140: bl              #0x826750  ; AllocateClosureStub
    // 0x646144: mov             x1, x0
    // 0x646148: ldur            x0, [fp, #-0x18]
    // 0x64614c: StoreField: r0->field_b = r1
    //     0x64614c: stur            w1, [x0, #0xb]
    // 0x646150: r3 = false
    //     0x646150: add             x3, NULL, #0x30  ; false
    // 0x646154: StoreField: r0->field_27 = r3
    //     0x646154: stur            w3, [x0, #0x27]
    // 0x646158: r1 = true
    //     0x646158: add             x1, NULL, #0x20  ; true
    // 0x64615c: StoreField: r0->field_2f = r1
    //     0x64615c: stur            w1, [x0, #0x2f]
    // 0x646160: r1 = Instance_Text
    //     0x646160: add             x1, PP, #0x23, lsl #12  ; [pp+0x23d30] Obj!Text@84f311
    //     0x646164: ldr             x1, [x1, #0xd30]
    // 0x646168: StoreField: r0->field_3b = r1
    //     0x646168: stur            w1, [x0, #0x3b]
    // 0x64616c: r1 = Null
    //     0x64616c: mov             x1, NULL
    // 0x646170: r2 = 4
    //     0x646170: movz            x2, #0x4
    // 0x646174: r0 = AllocateArray()
    //     0x646174: bl              #0x82746c  ; AllocateArrayStub
    // 0x646178: mov             x2, x0
    // 0x64617c: ldur            x0, [fp, #-0x10]
    // 0x646180: stur            x2, [fp, #-8]
    // 0x646184: StoreField: r2->field_f = r0
    //     0x646184: stur            w0, [x2, #0xf]
    // 0x646188: ldur            x0, [fp, #-0x18]
    // 0x64618c: StoreField: r2->field_13 = r0
    //     0x64618c: stur            w0, [x2, #0x13]
    // 0x646190: r1 = <Widget>
    //     0x646190: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x646194: r0 = AllocateGrowableArray()
    //     0x646194: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x646198: mov             x1, x0
    // 0x64619c: ldur            x0, [fp, #-8]
    // 0x6461a0: stur            x1, [fp, #-0x10]
    // 0x6461a4: StoreField: r1->field_f = r0
    //     0x6461a4: stur            w0, [x1, #0xf]
    // 0x6461a8: r0 = 4
    //     0x6461a8: movz            x0, #0x4
    // 0x6461ac: StoreField: r1->field_b = r0
    //     0x6461ac: stur            w0, [x1, #0xb]
    // 0x6461b0: r0 = AlertDialog()
    //     0x6461b0: bl              #0x490074  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x6461b4: r1 = Instance_Text
    //     0x6461b4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0a8] Obj!Text@852e21
    //     0x6461b8: ldr             x1, [x1, #0xa8]
    // 0x6461bc: StoreField: r0->field_f = r1
    //     0x6461bc: stur            w1, [x0, #0xf]
    // 0x6461c0: r1 = Instance_Text
    //     0x6461c0: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0b0] Obj!Text@852dd1
    //     0x6461c4: ldr             x1, [x1, #0xb0]
    // 0x6461c8: StoreField: r0->field_1b = r1
    //     0x6461c8: stur            w1, [x0, #0x1b]
    // 0x6461cc: ldur            x1, [fp, #-0x10]
    // 0x6461d0: StoreField: r0->field_27 = r1
    //     0x6461d0: stur            w1, [x0, #0x27]
    // 0x6461d4: r1 = false
    //     0x6461d4: add             x1, NULL, #0x30  ; false
    // 0x6461d8: StoreField: r0->field_6b = r1
    //     0x6461d8: stur            w1, [x0, #0x6b]
    // 0x6461dc: LeaveFrame
    //     0x6461dc: mov             SP, fp
    //     0x6461e0: ldp             fp, lr, [SP], #0x10
    // 0x6461e4: ret
    //     0x6461e4: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x6461e8, size: 0x158
    // 0x6461e8: EnterFrame
    //     0x6461e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6461ec: mov             fp, SP
    // 0x6461f0: AllocStack(0x28)
    //     0x6461f0: sub             SP, SP, #0x28
    // 0x6461f4: SetupParameters(_DifficultyChooserState this /* r1 */)
    //     0x6461f4: stur            NULL, [fp, #-8]
    //     0x6461f8: movz            x0, #0
    //     0x6461fc: add             x1, fp, w0, sxtw #2
    //     0x646200: ldr             x1, [x1, #0x10]
    //     0x646204: ldur            w2, [x1, #0x17]
    //     0x646208: add             x2, x2, HEAP, lsl #32
    //     0x64620c: stur            x2, [fp, #-0x10]
    // 0x646210: CheckStackOverflow
    //     0x646210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x646214: cmp             SP, x16
    //     0x646218: b.ls            #0x646328
    // 0x64621c: InitAsync() -> Future<void?>
    //     0x64621c: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x646220: bl              #0x34b9a0  ; InitAsyncStub
    // 0x646224: r1 = Null
    //     0x646224: mov             x1, NULL
    // 0x646228: r2 = 4
    //     0x646228: movz            x2, #0x4
    // 0x64622c: r0 = AllocateArray()
    //     0x64622c: bl              #0x82746c  ; AllocateArrayStub
    // 0x646230: r16 = "difficulty_index_"
    //     0x646230: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cd0] "difficulty_index_"
    //     0x646234: ldr             x16, [x16, #0xcd0]
    // 0x646238: StoreField: r0->field_f = r16
    //     0x646238: stur            w16, [x0, #0xf]
    // 0x64623c: ldur            x1, [fp, #-0x10]
    // 0x646240: LoadField: r2 = r1->field_f
    //     0x646240: ldur            w2, [x1, #0xf]
    // 0x646244: DecompressPointer r2
    //     0x646244: add             x2, x2, HEAP, lsl #32
    // 0x646248: LoadField: r3 = r2->field_b
    //     0x646248: ldur            w3, [x2, #0xb]
    // 0x64624c: DecompressPointer r3
    //     0x64624c: add             x3, x3, HEAP, lsl #32
    // 0x646250: cmp             w3, NULL
    // 0x646254: b.eq            #0x646330
    // 0x646258: LoadField: r2 = r3->field_b
    //     0x646258: ldur            w2, [x3, #0xb]
    // 0x64625c: DecompressPointer r2
    //     0x64625c: add             x2, x2, HEAP, lsl #32
    // 0x646260: StoreField: r0->field_13 = r2
    //     0x646260: stur            w2, [x0, #0x13]
    // 0x646264: str             x0, [SP]
    // 0x646268: r0 = _interpolate()
    //     0x646268: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x64626c: mov             x1, x0
    // 0x646270: ldur            x0, [fp, #-0x10]
    // 0x646274: LoadField: r2 = r0->field_f
    //     0x646274: ldur            w2, [x0, #0xf]
    // 0x646278: DecompressPointer r2
    //     0x646278: add             x2, x2, HEAP, lsl #32
    // 0x64627c: LoadField: r3 = r2->field_13
    //     0x64627c: ldur            w3, [x2, #0x13]
    // 0x646280: DecompressPointer r3
    //     0x646280: add             x3, x3, HEAP, lsl #32
    // 0x646284: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x646288: cmp             w3, w16
    // 0x64628c: b.eq            #0x646334
    // 0x646290: r2 = LoadInt32Instr(r3)
    //     0x646290: sbfx            x2, x3, #1, #0x1f
    //     0x646294: tbz             w3, #0, #0x64629c
    //     0x646298: ldur            x2, [x3, #7]
    // 0x64629c: r0 = prefsSetInt()
    //     0x64629c: bl              #0x35e50c  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetInt
    // 0x6462a0: r1 = "updated_difficulty_indicator"
    //     0x6462a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26070] "updated_difficulty_indicator"
    //     0x6462a4: ldr             x1, [x1, #0x70]
    // 0x6462a8: r0 = broadcastToListeners()
    //     0x6462a8: bl              #0x4513b8  ; [package:state_groups/src/sync_state.dart] ::broadcastToListeners
    // 0x6462ac: r0 = resetCurrentChapterAndUpdateUI()
    //     0x6462ac: bl              #0x5a20a8  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::resetCurrentChapterAndUpdateUI
    // 0x6462b0: ldur            x0, [fp, #-0x10]
    // 0x6462b4: LoadField: r1 = r0->field_13
    //     0x6462b4: ldur            w1, [x0, #0x13]
    // 0x6462b8: DecompressPointer r1
    //     0x6462b8: add             x1, x1, HEAP, lsl #32
    // 0x6462bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6462bc: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6462c0: r0 = of()
    //     0x6462c0: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x6462c4: r16 = <Object?>
    //     0x6462c4: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x6462c8: stp             x0, x16, [SP]
    // 0x6462cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6462cc: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6462d0: r0 = maybePop()
    //     0x6462d0: bl              #0x3842c0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x6462d4: mov             x1, x0
    // 0x6462d8: stur            x1, [fp, #-0x18]
    // 0x6462dc: r0 = Await()
    //     0x6462dc: bl              #0x34b75c  ; AwaitStub
    // 0x6462e0: ldur            x0, [fp, #-0x10]
    // 0x6462e4: LoadField: r1 = r0->field_13
    //     0x6462e4: ldur            w1, [x0, #0x13]
    // 0x6462e8: DecompressPointer r1
    //     0x6462e8: add             x1, x1, HEAP, lsl #32
    // 0x6462ec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6462ec: ldur            w2, [x1, #0x17]
    // 0x6462f0: DecompressPointer r2
    //     0x6462f0: add             x2, x2, HEAP, lsl #32
    // 0x6462f4: cmp             w2, NULL
    // 0x6462f8: b.eq            #0x646320
    // 0x6462fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6462fc: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x646300: r0 = of()
    //     0x646300: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x646304: r16 = <Object?>
    //     0x646304: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x646308: stp             x0, x16, [SP]
    // 0x64630c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x64630c: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x646310: r0 = maybePop()
    //     0x646310: bl              #0x3842c0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x646314: mov             x1, x0
    // 0x646318: stur            x1, [fp, #-0x18]
    // 0x64631c: r0 = Await()
    //     0x64631c: bl              #0x34b75c  ; AwaitStub
    // 0x646320: r0 = Null
    //     0x646320: mov             x0, NULL
    // 0x646324: r0 = ReturnAsyncNotFuture()
    //     0x646324: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x646328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x646328: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64632c: b               #0x64621c
    // 0x646330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646330: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646334: r9 = currentDifficulty
    //     0x646334: add             x9, PP, #0x2c, lsl #12  ; [pp+0x2c088] Field <_DifficultyChooserState@955301480.currentDifficulty>: late (offset: 0x14)
    //     0x646338: ldr             x9, [x9, #0x88]
    // 0x64633c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x64633c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x646340, size: 0x48
    // 0x646340: ldr             x1, [SP, #8]
    // 0x646344: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x646344: ldur            w2, [x1, #0x17]
    // 0x646348: DecompressPointer r2
    //     0x646348: add             x2, x2, HEAP, lsl #32
    // 0x64634c: LoadField: r1 = r2->field_f
    //     0x64634c: ldur            w1, [x2, #0xf]
    // 0x646350: DecompressPointer r1
    //     0x646350: add             x1, x1, HEAP, lsl #32
    // 0x646354: ldr             x0, [SP]
    // 0x646358: StoreField: r1->field_13 = r0
    //     0x646358: stur            w0, [x1, #0x13]
    //     0x64635c: tbz             w0, #0, #0x646380
    //     0x646360: ldurb           w16, [x1, #-1]
    //     0x646364: ldurb           w17, [x0, #-1]
    //     0x646368: and             x16, x17, x16, lsr #2
    //     0x64636c: tst             x16, HEAP, lsr #32
    //     0x646370: b.eq            #0x646380
    //     0x646374: str             lr, [SP, #-8]!
    //     0x646378: bl              #0x825ad8  ; WriteBarrierWrappersStub
    //     0x64637c: ldr             lr, [SP], #8
    // 0x646380: r0 = Null
    //     0x646380: mov             x0, NULL
    // 0x646384: ret
    //     0x646384: ret             
  }
}

// class id: 3539, size: 0x20, field offset: 0x1c
class _DifficultyIndicatorState extends SyncState2<dynamic> {

  _ initState(/* No info */) {
    // ** addr: 0x575f10, size: 0x98
    // 0x575f10: EnterFrame
    //     0x575f10: stp             fp, lr, [SP, #-0x10]!
    //     0x575f14: mov             fp, SP
    // 0x575f18: AllocStack(0x10)
    //     0x575f18: sub             SP, SP, #0x10
    // 0x575f1c: SetupParameters(_DifficultyIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0x575f1c: mov             x0, x1
    //     0x575f20: stur            x1, [fp, #-8]
    // 0x575f24: CheckStackOverflow
    //     0x575f24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x575f28: cmp             SP, x16
    //     0x575f2c: b.ls            #0x575f9c
    // 0x575f30: mov             x1, x0
    // 0x575f34: r0 = initState()
    //     0x575f34: bl              #0x575c2c  ; [package:state_groups/src/sync_state.dart] SyncState2::initState
    // 0x575f38: ldur            x1, [fp, #-8]
    // 0x575f3c: r2 = "updated_difficulty_indicator"
    //     0x575f3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26070] "updated_difficulty_indicator"
    //     0x575f40: ldr             x2, [x2, #0x70]
    // 0x575f44: r0 = subscribeToBroadcasts()
    //     0x575f44: bl              #0x5730ac  ; [package:state_groups/src/sync_state.dart] SyncState2::subscribeToBroadcasts
    // 0x575f48: ldur            x2, [fp, #-8]
    // 0x575f4c: LoadField: r0 = r2->field_b
    //     0x575f4c: ldur            w0, [x2, #0xb]
    // 0x575f50: DecompressPointer r0
    //     0x575f50: add             x0, x0, HEAP, lsl #32
    // 0x575f54: cmp             w0, NULL
    // 0x575f58: b.eq            #0x575fa4
    // 0x575f5c: LoadField: r1 = r0->field_f
    //     0x575f5c: ldur            w1, [x0, #0xf]
    // 0x575f60: DecompressPointer r1
    //     0x575f60: add             x1, x1, HEAP, lsl #32
    // 0x575f64: tbz             w1, #4, #0x575f8c
    // 0x575f68: LoadField: r3 = r0->field_b
    //     0x575f68: ldur            w3, [x0, #0xb]
    // 0x575f6c: DecompressPointer r3
    //     0x575f6c: add             x3, x3, HEAP, lsl #32
    // 0x575f70: stur            x3, [fp, #-0x10]
    // 0x575f74: r1 = Function 'listener':.
    //     0x575f74: add             x1, PP, #0x26, lsl #12  ; [pp+0x26060] AnonymousClosure: (0x575fc8), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyIndicatorState::listener (0x576000)
    //     0x575f78: ldr             x1, [x1, #0x60]
    // 0x575f7c: r0 = AllocateClosure()
    //     0x575f7c: bl              #0x826750  ; AllocateClosureStub
    // 0x575f80: ldur            x1, [fp, #-0x10]
    // 0x575f84: mov             x2, x0
    // 0x575f88: r0 = addListener()
    //     0x575f88: bl              #0x3ce4ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x575f8c: r0 = Null
    //     0x575f8c: mov             x0, NULL
    // 0x575f90: LeaveFrame
    //     0x575f90: mov             SP, fp
    //     0x575f94: ldp             fp, lr, [SP], #0x10
    // 0x575f98: ret
    //     0x575f98: ret             
    // 0x575f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x575f9c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x575fa0: b               #0x575f30
    // 0x575fa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x575fa4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void listener(dynamic) {
    // ** addr: 0x575fc8, size: 0x38
    // 0x575fc8: EnterFrame
    //     0x575fc8: stp             fp, lr, [SP, #-0x10]!
    //     0x575fcc: mov             fp, SP
    // 0x575fd0: ldr             x0, [fp, #0x10]
    // 0x575fd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x575fd4: ldur            w1, [x0, #0x17]
    // 0x575fd8: DecompressPointer r1
    //     0x575fd8: add             x1, x1, HEAP, lsl #32
    // 0x575fdc: CheckStackOverflow
    //     0x575fdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x575fe0: cmp             SP, x16
    //     0x575fe4: b.ls            #0x575ff8
    // 0x575fe8: r0 = listener()
    //     0x575fe8: bl              #0x576000  ; [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyIndicatorState::listener
    // 0x575fec: LeaveFrame
    //     0x575fec: mov             SP, fp
    //     0x575ff0: ldp             fp, lr, [SP], #0x10
    // 0x575ff4: ret
    //     0x575ff4: ret             
    // 0x575ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x575ff8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x575ffc: b               #0x575fe8
  }
  _ listener(/* No info */) {
    // ** addr: 0x576000, size: 0xbc
    // 0x576000: EnterFrame
    //     0x576000: stp             fp, lr, [SP, #-0x10]!
    //     0x576004: mov             fp, SP
    // 0x576008: AllocStack(0x10)
    //     0x576008: sub             SP, SP, #0x10
    // 0x57600c: SetupParameters(_DifficultyIndicatorState this /* r1 => r1, fp-0x8 */)
    //     0x57600c: stur            x1, [fp, #-8]
    // 0x576010: CheckStackOverflow
    //     0x576010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x576014: cmp             SP, x16
    //     0x576018: b.ls            #0x5760b0
    // 0x57601c: r1 = 2
    //     0x57601c: movz            x1, #0x2
    // 0x576020: r0 = AllocateContext()
    //     0x576020: bl              #0x82637c  ; AllocateContextStub
    // 0x576024: mov             x2, x0
    // 0x576028: ldur            x0, [fp, #-8]
    // 0x57602c: stur            x2, [fp, #-0x10]
    // 0x576030: StoreField: r2->field_f = r0
    //     0x576030: stur            w0, [x2, #0xf]
    // 0x576034: LoadField: r1 = r0->field_b
    //     0x576034: ldur            w1, [x0, #0xb]
    // 0x576038: DecompressPointer r1
    //     0x576038: add             x1, x1, HEAP, lsl #32
    // 0x57603c: cmp             w1, NULL
    // 0x576040: b.eq            #0x5760b8
    // 0x576044: LoadField: r3 = r1->field_b
    //     0x576044: ldur            w3, [x1, #0xb]
    // 0x576048: DecompressPointer r3
    //     0x576048: add             x3, x3, HEAP, lsl #32
    // 0x57604c: mov             x1, x3
    // 0x576050: r0 = offset()
    //     0x576050: bl              #0x40a774  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::offset
    // 0x576054: mov             v1.16b, v0.16b
    // 0x576058: d0 = 0.000000
    //     0x576058: eor             v0.16b, v0.16b, v0.16b
    // 0x57605c: fcmp            d0, d1
    // 0x576060: r16 = true
    //     0x576060: add             x16, NULL, #0x20  ; true
    // 0x576064: r17 = false
    //     0x576064: add             x17, NULL, #0x30  ; false
    // 0x576068: csel            x0, x16, x17, ge
    // 0x57606c: ldur            x2, [fp, #-0x10]
    // 0x576070: StoreField: r2->field_13 = r0
    //     0x576070: stur            w0, [x2, #0x13]
    // 0x576074: ldur            x3, [fp, #-8]
    // 0x576078: LoadField: r1 = r3->field_1b
    //     0x576078: ldur            w1, [x3, #0x1b]
    // 0x57607c: DecompressPointer r1
    //     0x57607c: add             x1, x1, HEAP, lsl #32
    // 0x576080: cmp             w1, w0
    // 0x576084: b.eq            #0x5760a0
    // 0x576088: r1 = Function '<anonymous closure>':.
    //     0x576088: add             x1, PP, #0x26, lsl #12  ; [pp+0x26068] AnonymousClosure: (0x5760bc), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionChanged (0x5760e4)
    //     0x57608c: ldr             x1, [x1, #0x68]
    // 0x576090: r0 = AllocateClosure()
    //     0x576090: bl              #0x826750  ; AllocateClosureStub
    // 0x576094: ldur            x1, [fp, #-8]
    // 0x576098: mov             x2, x0
    // 0x57609c: r0 = setState()
    //     0x57609c: bl              #0x329714  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x5760a0: r0 = Null
    //     0x5760a0: mov             x0, NULL
    // 0x5760a4: LeaveFrame
    //     0x5760a4: mov             SP, fp
    //     0x5760a8: ldp             fp, lr, [SP], #0x10
    // 0x5760ac: ret
    //     0x5760ac: ret             
    // 0x5760b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5760b0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5760b4: b               #0x57601c
    // 0x5760b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5760b8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x5a8884, size: 0x4b0
    // 0x5a8884: EnterFrame
    //     0x5a8884: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8888: mov             fp, SP
    // 0x5a888c: AllocStack(0x50)
    //     0x5a888c: sub             SP, SP, #0x50
    // 0x5a8890: SetupParameters(_DifficultyIndicatorState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x5a8890: stur            x1, [fp, #-8]
    //     0x5a8894: stur            x2, [fp, #-0x10]
    // 0x5a8898: CheckStackOverflow
    //     0x5a8898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a889c: cmp             SP, x16
    //     0x5a88a0: b.ls            #0x5a8d24
    // 0x5a88a4: r1 = 3
    //     0x5a88a4: movz            x1, #0x3
    // 0x5a88a8: r0 = AllocateContext()
    //     0x5a88a8: bl              #0x82637c  ; AllocateContextStub
    // 0x5a88ac: mov             x2, x0
    // 0x5a88b0: ldur            x0, [fp, #-8]
    // 0x5a88b4: stur            x2, [fp, #-0x18]
    // 0x5a88b8: StoreField: r2->field_f = r0
    //     0x5a88b8: stur            w0, [x2, #0xf]
    // 0x5a88bc: ldur            x1, [fp, #-0x10]
    // 0x5a88c0: StoreField: r2->field_13 = r1
    //     0x5a88c0: stur            w1, [x2, #0x13]
    // 0x5a88c4: LoadField: r1 = r0->field_b
    //     0x5a88c4: ldur            w1, [x0, #0xb]
    // 0x5a88c8: DecompressPointer r1
    //     0x5a88c8: add             x1, x1, HEAP, lsl #32
    // 0x5a88cc: cmp             w1, NULL
    // 0x5a88d0: b.eq            #0x5a8d2c
    // 0x5a88d4: LoadField: r3 = r1->field_13
    //     0x5a88d4: ldur            w3, [x1, #0x13]
    // 0x5a88d8: DecompressPointer r3
    //     0x5a88d8: add             x3, x3, HEAP, lsl #32
    // 0x5a88dc: mov             x1, x3
    // 0x5a88e0: r0 = allowDifficultyChoosing()
    //     0x5a88e0: bl              #0x4619e8  ; [package:pretentious/widgets/difficulty_indicator.dart] ::allowDifficultyChoosing
    // 0x5a88e4: tbz             w0, #4, #0x5a88f8
    // 0x5a88e8: r0 = Instance_SizedBox
    //     0x5a88e8: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x5a88ec: LeaveFrame
    //     0x5a88ec: mov             SP, fp
    //     0x5a88f0: ldp             fp, lr, [SP], #0x10
    // 0x5a88f4: ret
    //     0x5a88f4: ret             
    // 0x5a88f8: ldur            x0, [fp, #-8]
    // 0x5a88fc: ldur            x2, [fp, #-0x18]
    // 0x5a8900: LoadField: r1 = r2->field_13
    //     0x5a8900: ldur            w1, [x2, #0x13]
    // 0x5a8904: DecompressPointer r1
    //     0x5a8904: add             x1, x1, HEAP, lsl #32
    // 0x5a8908: r0 = of()
    //     0x5a8908: bl              #0x5a6984  ; [package:pretentious/pages/MainPage.dart] CurrentChapter::of
    // 0x5a890c: mov             x4, x0
    // 0x5a8910: ldur            x3, [fp, #-0x18]
    // 0x5a8914: stur            x4, [fp, #-0x20]
    // 0x5a8918: ArrayStore: r3[0] = r0  ; List_4
    //     0x5a8918: stur            w0, [x3, #0x17]
    //     0x5a891c: ldurb           w16, [x3, #-1]
    //     0x5a8920: ldurb           w17, [x0, #-1]
    //     0x5a8924: and             x16, x17, x16, lsr #2
    //     0x5a8928: tst             x16, HEAP, lsr #32
    //     0x5a892c: b.eq            #0x5a8934
    //     0x5a8930: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x5a8934: ldur            x0, [fp, #-8]
    // 0x5a8938: LoadField: r1 = r0->field_1b
    //     0x5a8938: ldur            w1, [x0, #0x1b]
    // 0x5a893c: DecompressPointer r1
    //     0x5a893c: add             x1, x1, HEAP, lsl #32
    // 0x5a8940: tbnz            w1, #4, #0x5a894c
    // 0x5a8944: d0 = 1.000000
    //     0x5a8944: fmov            d0, #1.00000000
    // 0x5a8948: b               #0x5a8950
    // 0x5a894c: d0 = 0.000000
    //     0x5a894c: eor             v0.16b, v0.16b, v0.16b
    // 0x5a8950: stur            d0, [fp, #-0x40]
    // 0x5a8954: tbz             w1, #4, #0x5a8964
    // 0x5a8958: r5 = Instance_Cubic
    //     0x5a8958: add             x5, PP, #0x20, lsl #12  ; [pp+0x20e70] Obj!Cubic@8342d1
    //     0x5a895c: ldr             x5, [x5, #0xe70]
    // 0x5a8960: b               #0x5a896c
    // 0x5a8964: r5 = Instance_Cubic
    //     0x5a8964: add             x5, PP, #0x26, lsl #12  ; [pp+0x26010] Obj!Cubic@834451
    //     0x5a8968: ldr             x5, [x5, #0x10]
    // 0x5a896c: stur            x5, [fp, #-0x10]
    // 0x5a8970: LoadField: r1 = r3->field_13
    //     0x5a8970: ldur            w1, [x3, #0x13]
    // 0x5a8974: DecompressPointer r1
    //     0x5a8974: add             x1, x1, HEAP, lsl #32
    // 0x5a8978: r2 = true
    //     0x5a8978: add             x2, NULL, #0x20  ; true
    // 0x5a897c: r0 = makeBackgroundColour()
    //     0x5a897c: bl              #0x5a8ddc  ; [package:pretentious/widgets/IdleFragment.dart] ::makeBackgroundColour
    // 0x5a8980: ldur            x2, [fp, #-0x18]
    // 0x5a8984: stur            x0, [fp, #-0x28]
    // 0x5a8988: LoadField: r1 = r2->field_13
    //     0x5a8988: ldur            w1, [x2, #0x13]
    // 0x5a898c: DecompressPointer r1
    //     0x5a898c: add             x1, x1, HEAP, lsl #32
    // 0x5a8990: r0 = of()
    //     0x5a8990: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x5a8994: LoadField: r1 = r0->field_6f
    //     0x5a8994: ldur            w1, [x0, #0x6f]
    // 0x5a8998: DecompressPointer r1
    //     0x5a8998: add             x1, x1, HEAP, lsl #32
    // 0x5a899c: d0 = 0.250000
    //     0x5a899c: fmov            d0, #0.25000000
    // 0x5a89a0: r0 = withOpacity()
    //     0x5a89a0: bl              #0x7edc50  ; [dart:ui] Color::withOpacity
    // 0x5a89a4: stur            x0, [fp, #-0x30]
    // 0x5a89a8: r0 = BoxShadow()
    //     0x5a89a8: bl              #0x4c11b4  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x5a89ac: stur            x0, [fp, #-0x38]
    // 0x5a89b0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x5a89b0: stur            xzr, [x0, #0x17]
    // 0x5a89b4: r1 = Instance_BlurStyle
    //     0x5a89b4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d648] Obj!BlurStyle@865d01
    //     0x5a89b8: ldr             x1, [x1, #0x648]
    // 0x5a89bc: StoreField: r0->field_1f = r1
    //     0x5a89bc: stur            w1, [x0, #0x1f]
    // 0x5a89c0: ldur            x1, [fp, #-0x30]
    // 0x5a89c4: StoreField: r0->field_7 = r1
    //     0x5a89c4: stur            w1, [x0, #7]
    // 0x5a89c8: r1 = Instance_Offset
    //     0x5a89c8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26018] Obj!Offset@8405c1
    //     0x5a89cc: ldr             x1, [x1, #0x18]
    // 0x5a89d0: StoreField: r0->field_b = r1
    //     0x5a89d0: stur            w1, [x0, #0xb]
    // 0x5a89d4: d0 = 6.000000
    //     0x5a89d4: fmov            d0, #6.00000000
    // 0x5a89d8: StoreField: r0->field_f = d0
    //     0x5a89d8: stur            d0, [x0, #0xf]
    // 0x5a89dc: r1 = Null
    //     0x5a89dc: mov             x1, NULL
    // 0x5a89e0: r2 = 2
    //     0x5a89e0: movz            x2, #0x2
    // 0x5a89e4: r0 = AllocateArray()
    //     0x5a89e4: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a89e8: mov             x2, x0
    // 0x5a89ec: ldur            x0, [fp, #-0x38]
    // 0x5a89f0: stur            x2, [fp, #-0x30]
    // 0x5a89f4: StoreField: r2->field_f = r0
    //     0x5a89f4: stur            w0, [x2, #0xf]
    // 0x5a89f8: r1 = <BoxShadow>
    //     0x5a89f8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1afd0] TypeArguments: <BoxShadow>
    //     0x5a89fc: ldr             x1, [x1, #0xfd0]
    // 0x5a8a00: r0 = AllocateGrowableArray()
    //     0x5a8a00: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5a8a04: mov             x1, x0
    // 0x5a8a08: ldur            x0, [fp, #-0x30]
    // 0x5a8a0c: stur            x1, [fp, #-0x38]
    // 0x5a8a10: StoreField: r1->field_f = r0
    //     0x5a8a10: stur            w0, [x1, #0xf]
    // 0x5a8a14: r0 = 2
    //     0x5a8a14: movz            x0, #0x2
    // 0x5a8a18: StoreField: r1->field_b = r0
    //     0x5a8a18: stur            w0, [x1, #0xb]
    // 0x5a8a1c: r0 = BoxDecoration()
    //     0x5a8a1c: bl              #0x59ff98  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x5a8a20: mov             x3, x0
    // 0x5a8a24: ldur            x0, [fp, #-0x28]
    // 0x5a8a28: stur            x3, [fp, #-0x30]
    // 0x5a8a2c: StoreField: r3->field_7 = r0
    //     0x5a8a2c: stur            w0, [x3, #7]
    // 0x5a8a30: r0 = Instance_BorderRadius
    //     0x5a8a30: add             x0, PP, #0x26, lsl #12  ; [pp+0x26020] Obj!BorderRadius@832f71
    //     0x5a8a34: ldr             x0, [x0, #0x20]
    // 0x5a8a38: StoreField: r3->field_13 = r0
    //     0x5a8a38: stur            w0, [x3, #0x13]
    // 0x5a8a3c: ldur            x0, [fp, #-0x38]
    // 0x5a8a40: ArrayStore: r3[0] = r0  ; List_4
    //     0x5a8a40: stur            w0, [x3, #0x17]
    // 0x5a8a44: r0 = Instance_BoxShape
    //     0x5a8a44: add             x0, PP, #0x16, lsl #12  ; [pp+0x168d0] Obj!BoxShape@862d01
    //     0x5a8a48: ldr             x0, [x0, #0x8d0]
    // 0x5a8a4c: StoreField: r3->field_23 = r0
    //     0x5a8a4c: stur            w0, [x3, #0x23]
    // 0x5a8a50: r1 = Null
    //     0x5a8a50: mov             x1, NULL
    // 0x5a8a54: r2 = 4
    //     0x5a8a54: movz            x2, #0x4
    // 0x5a8a58: r0 = AllocateArray()
    //     0x5a8a58: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a8a5c: stur            x0, [fp, #-0x28]
    // 0x5a8a60: r16 = "Difficulty: "
    //     0x5a8a60: add             x16, PP, #0x26, lsl #12  ; [pp+0x26028] "Difficulty: "
    //     0x5a8a64: ldr             x16, [x16, #0x28]
    // 0x5a8a68: StoreField: r0->field_f = r16
    //     0x5a8a68: stur            w16, [x0, #0xf]
    // 0x5a8a6c: ldur            x1, [fp, #-0x20]
    // 0x5a8a70: r0 = currentChapterDifficultyMultiplier()
    //     0x5a8a70: bl              #0x5a8d6c  ; [package:pretentious/widgets/difficulty_indicator.dart] ::currentChapterDifficultyMultiplier
    // 0x5a8a74: ldur            x1, [fp, #-0x28]
    // 0x5a8a78: ArrayStore: r1[1] = r0  ; List_4
    //     0x5a8a78: add             x25, x1, #0x13
    //     0x5a8a7c: str             w0, [x25]
    //     0x5a8a80: tbz             w0, #0, #0x5a8a9c
    //     0x5a8a84: ldurb           w16, [x1, #-1]
    //     0x5a8a88: ldurb           w17, [x0, #-1]
    //     0x5a8a8c: and             x16, x17, x16, lsr #2
    //     0x5a8a90: tst             x16, HEAP, lsr #32
    //     0x5a8a94: b.eq            #0x5a8a9c
    //     0x5a8a98: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a8a9c: ldur            x16, [fp, #-0x28]
    // 0x5a8aa0: str             x16, [SP]
    // 0x5a8aa4: r0 = _interpolate()
    //     0x5a8aa4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x5a8aa8: stur            x0, [fp, #-0x20]
    // 0x5a8aac: r0 = Text()
    //     0x5a8aac: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x5a8ab0: mov             x3, x0
    // 0x5a8ab4: ldur            x0, [fp, #-0x20]
    // 0x5a8ab8: stur            x3, [fp, #-0x28]
    // 0x5a8abc: StoreField: r3->field_b = r0
    //     0x5a8abc: stur            w0, [x3, #0xb]
    // 0x5a8ac0: r0 = Instance_TextStyle
    //     0x5a8ac0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26030] Obj!TextStyle@846f11
    //     0x5a8ac4: ldr             x0, [x0, #0x30]
    // 0x5a8ac8: StoreField: r3->field_13 = r0
    //     0x5a8ac8: stur            w0, [x3, #0x13]
    // 0x5a8acc: r1 = Null
    //     0x5a8acc: mov             x1, NULL
    // 0x5a8ad0: r2 = 6
    //     0x5a8ad0: movz            x2, #0x6
    // 0x5a8ad4: r0 = AllocateArray()
    //     0x5a8ad4: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a8ad8: stur            x0, [fp, #-0x20]
    // 0x5a8adc: r16 = "(Next: "
    //     0x5a8adc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26038] "(Next: "
    //     0x5a8ae0: ldr             x16, [x16, #0x38]
    // 0x5a8ae4: StoreField: r0->field_f = r16
    //     0x5a8ae4: stur            w16, [x0, #0xf]
    // 0x5a8ae8: ldur            x1, [fp, #-8]
    // 0x5a8aec: LoadField: r2 = r1->field_b
    //     0x5a8aec: ldur            w2, [x1, #0xb]
    // 0x5a8af0: DecompressPointer r2
    //     0x5a8af0: add             x2, x2, HEAP, lsl #32
    // 0x5a8af4: cmp             w2, NULL
    // 0x5a8af8: b.eq            #0x5a8d30
    // 0x5a8afc: LoadField: r1 = r2->field_13
    //     0x5a8afc: ldur            w1, [x2, #0x13]
    // 0x5a8b00: DecompressPointer r1
    //     0x5a8b00: add             x1, x1, HEAP, lsl #32
    // 0x5a8b04: r0 = getDifficultyIndex()
    //     0x5a8b04: bl              #0x460dcc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::getDifficultyIndex
    // 0x5a8b08: mov             x2, x0
    // 0x5a8b0c: r0 = BoxInt64Instr(r2)
    //     0x5a8b0c: sbfiz           x0, x2, #1, #0x1f
    //     0x5a8b10: cmp             x2, x0, asr #1
    //     0x5a8b14: b.eq            #0x5a8b20
    //     0x5a8b18: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x5a8b1c: stur            x2, [x0, #7]
    // 0x5a8b20: mov             x2, x0
    // 0x5a8b24: r1 = Instance_CustomNum
    //     0x5a8b24: add             x1, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!CustomNum@828d61
    //     0x5a8b28: ldr             x1, [x1, #0x970]
    // 0x5a8b2c: r0 = pow()
    //     0x5a8b2c: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x5a8b30: ldur            x1, [fp, #-0x20]
    // 0x5a8b34: ArrayStore: r1[1] = r0  ; List_4
    //     0x5a8b34: add             x25, x1, #0x13
    //     0x5a8b38: str             w0, [x25]
    //     0x5a8b3c: tbz             w0, #0, #0x5a8b58
    //     0x5a8b40: ldurb           w16, [x1, #-1]
    //     0x5a8b44: ldurb           w17, [x0, #-1]
    //     0x5a8b48: and             x16, x17, x16, lsr #2
    //     0x5a8b4c: tst             x16, HEAP, lsr #32
    //     0x5a8b50: b.eq            #0x5a8b58
    //     0x5a8b54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a8b58: ldur            x0, [fp, #-0x20]
    // 0x5a8b5c: r16 = ")"
    //     0x5a8b5c: ldr             x16, [PP, #0x2228]  ; [pp+0x2228] ")"
    // 0x5a8b60: ArrayStore: r0[0] = r16  ; List_4
    //     0x5a8b60: stur            w16, [x0, #0x17]
    // 0x5a8b64: str             x0, [SP]
    // 0x5a8b68: r0 = _interpolate()
    //     0x5a8b68: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x5a8b6c: stur            x0, [fp, #-8]
    // 0x5a8b70: r0 = Text()
    //     0x5a8b70: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x5a8b74: mov             x3, x0
    // 0x5a8b78: ldur            x0, [fp, #-8]
    // 0x5a8b7c: stur            x3, [fp, #-0x20]
    // 0x5a8b80: StoreField: r3->field_b = r0
    //     0x5a8b80: stur            w0, [x3, #0xb]
    // 0x5a8b84: r0 = Instance_TextStyle
    //     0x5a8b84: add             x0, PP, #0x26, lsl #12  ; [pp+0x26040] Obj!TextStyle@846ea1
    //     0x5a8b88: ldr             x0, [x0, #0x40]
    // 0x5a8b8c: StoreField: r3->field_13 = r0
    //     0x5a8b8c: stur            w0, [x3, #0x13]
    // 0x5a8b90: r1 = Null
    //     0x5a8b90: mov             x1, NULL
    // 0x5a8b94: r2 = 4
    //     0x5a8b94: movz            x2, #0x4
    // 0x5a8b98: r0 = AllocateArray()
    //     0x5a8b98: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a8b9c: mov             x2, x0
    // 0x5a8ba0: ldur            x0, [fp, #-0x28]
    // 0x5a8ba4: stur            x2, [fp, #-8]
    // 0x5a8ba8: StoreField: r2->field_f = r0
    //     0x5a8ba8: stur            w0, [x2, #0xf]
    // 0x5a8bac: ldur            x0, [fp, #-0x20]
    // 0x5a8bb0: StoreField: r2->field_13 = r0
    //     0x5a8bb0: stur            w0, [x2, #0x13]
    // 0x5a8bb4: r1 = <Widget>
    //     0x5a8bb4: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x5a8bb8: r0 = AllocateGrowableArray()
    //     0x5a8bb8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5a8bbc: mov             x1, x0
    // 0x5a8bc0: ldur            x0, [fp, #-8]
    // 0x5a8bc4: stur            x1, [fp, #-0x20]
    // 0x5a8bc8: StoreField: r1->field_f = r0
    //     0x5a8bc8: stur            w0, [x1, #0xf]
    // 0x5a8bcc: r0 = 4
    //     0x5a8bcc: movz            x0, #0x4
    // 0x5a8bd0: StoreField: r1->field_b = r0
    //     0x5a8bd0: stur            w0, [x1, #0xb]
    // 0x5a8bd4: r0 = Column()
    //     0x5a8bd4: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x5a8bd8: mov             x1, x0
    // 0x5a8bdc: r0 = Instance_Axis
    //     0x5a8bdc: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x5a8be0: stur            x1, [fp, #-8]
    // 0x5a8be4: StoreField: r1->field_f = r0
    //     0x5a8be4: stur            w0, [x1, #0xf]
    // 0x5a8be8: r0 = Instance_MainAxisAlignment
    //     0x5a8be8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x5a8bec: ldr             x0, [x0, #0x200]
    // 0x5a8bf0: StoreField: r1->field_13 = r0
    //     0x5a8bf0: stur            w0, [x1, #0x13]
    // 0x5a8bf4: r0 = Instance_MainAxisSize
    //     0x5a8bf4: add             x0, PP, #0x19, lsl #12  ; [pp+0x19208] Obj!MainAxisSize@862a81
    //     0x5a8bf8: ldr             x0, [x0, #0x208]
    // 0x5a8bfc: ArrayStore: r1[0] = r0  ; List_4
    //     0x5a8bfc: stur            w0, [x1, #0x17]
    // 0x5a8c00: r0 = Instance_CrossAxisAlignment
    //     0x5a8c00: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x5a8c04: ldr             x0, [x0, #0x78]
    // 0x5a8c08: StoreField: r1->field_1b = r0
    //     0x5a8c08: stur            w0, [x1, #0x1b]
    // 0x5a8c0c: r0 = Instance_VerticalDirection
    //     0x5a8c0c: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x5a8c10: ldr             x0, [x0, #0x1e8]
    // 0x5a8c14: StoreField: r1->field_23 = r0
    //     0x5a8c14: stur            w0, [x1, #0x23]
    // 0x5a8c18: r0 = Instance_Clip
    //     0x5a8c18: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x5a8c1c: ldr             x0, [x0, #0x1b0]
    // 0x5a8c20: StoreField: r1->field_2b = r0
    //     0x5a8c20: stur            w0, [x1, #0x2b]
    // 0x5a8c24: StoreField: r1->field_2f = rZR
    //     0x5a8c24: stur            xzr, [x1, #0x2f]
    // 0x5a8c28: ldur            x0, [fp, #-0x20]
    // 0x5a8c2c: StoreField: r1->field_b = r0
    //     0x5a8c2c: stur            w0, [x1, #0xb]
    // 0x5a8c30: r0 = Padding()
    //     0x5a8c30: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x5a8c34: mov             x1, x0
    // 0x5a8c38: r0 = Instance_EdgeInsets
    //     0x5a8c38: add             x0, PP, #0x26, lsl #12  ; [pp+0x26048] Obj!EdgeInsets@831f81
    //     0x5a8c3c: ldr             x0, [x0, #0x48]
    // 0x5a8c40: stur            x1, [fp, #-0x20]
    // 0x5a8c44: StoreField: r1->field_f = r0
    //     0x5a8c44: stur            w0, [x1, #0xf]
    // 0x5a8c48: ldur            x0, [fp, #-8]
    // 0x5a8c4c: StoreField: r1->field_b = r0
    //     0x5a8c4c: stur            w0, [x1, #0xb]
    // 0x5a8c50: r0 = DecoratedBox()
    //     0x5a8c50: bl              #0x59ff80  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x5a8c54: mov             x1, x0
    // 0x5a8c58: ldur            x0, [fp, #-0x30]
    // 0x5a8c5c: stur            x1, [fp, #-8]
    // 0x5a8c60: StoreField: r1->field_f = r0
    //     0x5a8c60: stur            w0, [x1, #0xf]
    // 0x5a8c64: r0 = Instance_DecorationPosition
    //     0x5a8c64: add             x0, PP, #0x16, lsl #12  ; [pp+0x168e0] Obj!DecorationPosition@8628a1
    //     0x5a8c68: ldr             x0, [x0, #0x8e0]
    // 0x5a8c6c: StoreField: r1->field_13 = r0
    //     0x5a8c6c: stur            w0, [x1, #0x13]
    // 0x5a8c70: ldur            x0, [fp, #-0x20]
    // 0x5a8c74: StoreField: r1->field_b = r0
    //     0x5a8c74: stur            w0, [x1, #0xb]
    // 0x5a8c78: r0 = GestureDetector()
    //     0x5a8c78: bl              #0x5a4268  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x5a8c7c: ldur            x2, [fp, #-0x18]
    // 0x5a8c80: r1 = Function '<anonymous closure>':.
    //     0x5a8c80: add             x1, PP, #0x26, lsl #12  ; [pp+0x26050] AnonymousClosure: (0x5aa104), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyIndicatorState::build (0x5a8884)
    //     0x5a8c84: ldr             x1, [x1, #0x50]
    // 0x5a8c88: stur            x0, [fp, #-0x18]
    // 0x5a8c8c: r0 = AllocateClosure()
    //     0x5a8c8c: bl              #0x826750  ; AllocateClosureStub
    // 0x5a8c90: ldur            x16, [fp, #-8]
    // 0x5a8c94: stp             x0, x16, [SP]
    // 0x5a8c98: ldur            x1, [fp, #-0x18]
    // 0x5a8c9c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x1, onTap, 0x2, null]
    //     0x5a8c9c: add             x4, PP, #0x25, lsl #12  ; [pp+0x25a80] List(9) [0, 0x3, 0x2, 0x1, "child", 0x1, "onTap", 0x2, Null]
    //     0x5a8ca0: ldr             x4, [x4, #0xa80]
    // 0x5a8ca4: r0 = GestureDetector()
    //     0x5a8ca4: bl              #0x5a3d1c  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x5a8ca8: r0 = Padding()
    //     0x5a8ca8: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x5a8cac: mov             x1, x0
    // 0x5a8cb0: r0 = Instance_EdgeInsets
    //     0x5a8cb0: ldr             x0, [PP, #0x7350]  ; [pp+0x7350] Obj!EdgeInsets@831bc1
    // 0x5a8cb4: stur            x1, [fp, #-8]
    // 0x5a8cb8: StoreField: r1->field_f = r0
    //     0x5a8cb8: stur            w0, [x1, #0xf]
    // 0x5a8cbc: ldur            x0, [fp, #-0x18]
    // 0x5a8cc0: StoreField: r1->field_b = r0
    //     0x5a8cc0: stur            w0, [x1, #0xb]
    // 0x5a8cc4: r0 = AnimatedAlign()
    //     0x5a8cc4: bl              #0x5a8d40  ; AllocateAnimatedAlignStub -> AnimatedAlign (size=0x2c)
    // 0x5a8cc8: mov             x1, x0
    // 0x5a8ccc: r0 = Instance_Alignment
    //     0x5a8ccc: add             x0, PP, #0x16, lsl #12  ; [pp+0x168e8] Obj!Alignment@833291
    //     0x5a8cd0: ldr             x0, [x0, #0x8e8]
    // 0x5a8cd4: stur            x1, [fp, #-0x18]
    // 0x5a8cd8: ArrayStore: r1[0] = r0  ; List_4
    //     0x5a8cd8: stur            w0, [x1, #0x17]
    // 0x5a8cdc: ldur            x0, [fp, #-8]
    // 0x5a8ce0: StoreField: r1->field_1b = r0
    //     0x5a8ce0: stur            w0, [x1, #0x1b]
    // 0x5a8ce4: ldur            d0, [fp, #-0x40]
    // 0x5a8ce8: StoreField: r1->field_1f = d0
    //     0x5a8ce8: stur            d0, [x1, #0x1f]
    // 0x5a8cec: ldur            x0, [fp, #-0x10]
    // 0x5a8cf0: StoreField: r1->field_b = r0
    //     0x5a8cf0: stur            w0, [x1, #0xb]
    // 0x5a8cf4: r0 = Instance_Duration
    //     0x5a8cf4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbbd0] Obj!Duration@8661b1
    //     0x5a8cf8: ldr             x0, [x0, #0xbd0]
    // 0x5a8cfc: StoreField: r1->field_f = r0
    //     0x5a8cfc: stur            w0, [x1, #0xf]
    // 0x5a8d00: r0 = ClipRect()
    //     0x5a8d00: bl              #0x5a8d34  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0x5a8d04: r1 = Instance_Clip
    //     0x5a8d04: add             x1, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x5a8d08: ldr             x1, [x1, #0x900]
    // 0x5a8d0c: StoreField: r0->field_13 = r1
    //     0x5a8d0c: stur            w1, [x0, #0x13]
    // 0x5a8d10: ldur            x1, [fp, #-0x18]
    // 0x5a8d14: StoreField: r0->field_b = r1
    //     0x5a8d14: stur            w1, [x0, #0xb]
    // 0x5a8d18: LeaveFrame
    //     0x5a8d18: mov             SP, fp
    //     0x5a8d1c: ldp             fp, lr, [SP], #0x10
    // 0x5a8d20: ret
    //     0x5a8d20: ret             
    // 0x5a8d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8d24: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8d28: b               #0x5a88a4
    // 0x5a8d2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a8d2c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a8d30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a8d30: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5aa104, size: 0x6c
    // 0x5aa104: EnterFrame
    //     0x5aa104: stp             fp, lr, [SP, #-0x10]!
    //     0x5aa108: mov             fp, SP
    // 0x5aa10c: AllocStack(0x20)
    //     0x5aa10c: sub             SP, SP, #0x20
    // 0x5aa110: SetupParameters([dynamic _ /* r0 */])
    //     0x5aa110: ldr             x0, [fp, #0x10]
    //     0x5aa114: ldur            w2, [x0, #0x17]
    //     0x5aa118: add             x2, x2, HEAP, lsl #32
    // 0x5aa11c: CheckStackOverflow
    //     0x5aa11c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5aa120: cmp             SP, x16
    //     0x5aa124: b.ls            #0x5aa168
    // 0x5aa128: LoadField: r0 = r2->field_13
    //     0x5aa128: ldur            w0, [x2, #0x13]
    // 0x5aa12c: DecompressPointer r0
    //     0x5aa12c: add             x0, x0, HEAP, lsl #32
    // 0x5aa130: stur            x0, [fp, #-8]
    // 0x5aa134: r1 = Function '<anonymous closure>':.
    //     0x5aa134: add             x1, PP, #0x26, lsl #12  ; [pp+0x26058] AnonymousClosure: (0x5aa170), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyIndicatorState::build (0x5a8884)
    //     0x5aa138: ldr             x1, [x1, #0x58]
    // 0x5aa13c: r0 = AllocateClosure()
    //     0x5aa13c: bl              #0x826750  ; AllocateClosureStub
    // 0x5aa140: r16 = <void?>
    //     0x5aa140: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x5aa144: stp             x0, x16, [SP, #8]
    // 0x5aa148: ldur            x16, [fp, #-8]
    // 0x5aa14c: str             x16, [SP]
    // 0x5aa150: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5aa150: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5aa154: r0 = showDialog()
    //     0x5aa154: bl              #0x3ecee0  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x5aa158: r0 = Null
    //     0x5aa158: mov             x0, NULL
    // 0x5aa15c: LeaveFrame
    //     0x5aa15c: mov             SP, fp
    //     0x5aa160: ldp             fp, lr, [SP], #0x10
    // 0x5aa164: ret
    //     0x5aa164: ret             
    // 0x5aa168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aa168: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5aa16c: b               #0x5aa128
  }
  [closure] DifficultyChooser <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x5aa170, size: 0x6c
    // 0x5aa170: EnterFrame
    //     0x5aa170: stp             fp, lr, [SP, #-0x10]!
    //     0x5aa174: mov             fp, SP
    // 0x5aa178: AllocStack(0x10)
    //     0x5aa178: sub             SP, SP, #0x10
    // 0x5aa17c: SetupParameters([dynamic _ /* r0 */])
    //     0x5aa17c: ldr             x0, [fp, #0x18]
    //     0x5aa180: ldur            w1, [x0, #0x17]
    //     0x5aa184: add             x1, x1, HEAP, lsl #32
    // 0x5aa188: LoadField: r0 = r1->field_f
    //     0x5aa188: ldur            w0, [x1, #0xf]
    // 0x5aa18c: DecompressPointer r0
    //     0x5aa18c: add             x0, x0, HEAP, lsl #32
    // 0x5aa190: LoadField: r2 = r0->field_b
    //     0x5aa190: ldur            w2, [x0, #0xb]
    // 0x5aa194: DecompressPointer r2
    //     0x5aa194: add             x2, x2, HEAP, lsl #32
    // 0x5aa198: cmp             w2, NULL
    // 0x5aa19c: b.eq            #0x5aa1d8
    // 0x5aa1a0: LoadField: r0 = r2->field_13
    //     0x5aa1a0: ldur            w0, [x2, #0x13]
    // 0x5aa1a4: DecompressPointer r0
    //     0x5aa1a4: add             x0, x0, HEAP, lsl #32
    // 0x5aa1a8: stur            x0, [fp, #-0x10]
    // 0x5aa1ac: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x5aa1ac: ldur            w2, [x1, #0x17]
    // 0x5aa1b0: DecompressPointer r2
    //     0x5aa1b0: add             x2, x2, HEAP, lsl #32
    // 0x5aa1b4: stur            x2, [fp, #-8]
    // 0x5aa1b8: r0 = DifficultyChooser()
    //     0x5aa1b8: bl              #0x5aa1dc  ; AllocateDifficultyChooserStub -> DifficultyChooser (size=0x14)
    // 0x5aa1bc: ldur            x1, [fp, #-0x10]
    // 0x5aa1c0: StoreField: r0->field_b = r1
    //     0x5aa1c0: stur            w1, [x0, #0xb]
    // 0x5aa1c4: ldur            x1, [fp, #-8]
    // 0x5aa1c8: StoreField: r0->field_f = r1
    //     0x5aa1c8: stur            w1, [x0, #0xf]
    // 0x5aa1cc: LeaveFrame
    //     0x5aa1cc: mov             SP, fp
    //     0x5aa1d0: ldp             fp, lr, [SP], #0x10
    // 0x5aa1d4: ret
    //     0x5aa1d4: ret             
    // 0x5aa1d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5aa1d8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x647cc4, size: 0x7c
    // 0x647cc4: EnterFrame
    //     0x647cc4: stp             fp, lr, [SP, #-0x10]!
    //     0x647cc8: mov             fp, SP
    // 0x647ccc: AllocStack(0x10)
    //     0x647ccc: sub             SP, SP, #0x10
    // 0x647cd0: SetupParameters(_DifficultyIndicatorState this /* r1 => r0, fp-0x10 */)
    //     0x647cd0: mov             x0, x1
    //     0x647cd4: stur            x1, [fp, #-0x10]
    // 0x647cd8: CheckStackOverflow
    //     0x647cd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x647cdc: cmp             SP, x16
    //     0x647ce0: b.ls            #0x647d34
    // 0x647ce4: LoadField: r1 = r0->field_b
    //     0x647ce4: ldur            w1, [x0, #0xb]
    // 0x647ce8: DecompressPointer r1
    //     0x647ce8: add             x1, x1, HEAP, lsl #32
    // 0x647cec: cmp             w1, NULL
    // 0x647cf0: b.eq            #0x647d3c
    // 0x647cf4: LoadField: r3 = r1->field_b
    //     0x647cf4: ldur            w3, [x1, #0xb]
    // 0x647cf8: DecompressPointer r3
    //     0x647cf8: add             x3, x3, HEAP, lsl #32
    // 0x647cfc: mov             x2, x0
    // 0x647d00: stur            x3, [fp, #-8]
    // 0x647d04: r1 = Function 'listener':.
    //     0x647d04: add             x1, PP, #0x26, lsl #12  ; [pp+0x26060] AnonymousClosure: (0x575fc8), in [package:pretentious/widgets/difficulty_indicator.dart] _DifficultyIndicatorState::listener (0x576000)
    //     0x647d08: ldr             x1, [x1, #0x60]
    // 0x647d0c: r0 = AllocateClosure()
    //     0x647d0c: bl              #0x826750  ; AllocateClosureStub
    // 0x647d10: ldur            x1, [fp, #-8]
    // 0x647d14: mov             x2, x0
    // 0x647d18: r0 = removeListener()
    //     0x647d18: bl              #0x773ec4  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x647d1c: ldur            x1, [fp, #-0x10]
    // 0x647d20: r0 = dispose()
    //     0x647d20: bl              #0x647998  ; [package:state_groups/src/sync_state.dart] SyncState2::dispose
    // 0x647d24: r0 = Null
    //     0x647d24: mov             x0, NULL
    // 0x647d28: LeaveFrame
    //     0x647d28: mov             SP, fp
    //     0x647d2c: ldp             fp, lr, [SP], #0x10
    // 0x647d30: ret
    //     0x647d30: ret             
    // 0x647d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647d34: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x647d38: b               #0x647ce4
    // 0x647d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x647d3c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
