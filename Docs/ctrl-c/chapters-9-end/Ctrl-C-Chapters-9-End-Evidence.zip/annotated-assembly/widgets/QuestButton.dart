// lib: , url: package:pretentious/widgets/QuestButton.dart

// class id: 1049510, size: 0x8
class :: {
}

// class id: 249, size: 0x20, field offset: 0x8
//   const constructor, 
class QuestLevel<X0> extends Object {

  Tuple2<Chapter7Stat, CustomNum> field_10;
  _OneByteString field_14;
  _OneByteString field_18;
  _OneByteString field_1c;
}

// class id: 2806, size: 0x3c, field offset: 0xc
//   const constructor, 
class QuestButton<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d540, size: 0x98
    // 0x72d540: EnterFrame
    //     0x72d540: stp             fp, lr, [SP, #-0x10]!
    //     0x72d544: mov             fp, SP
    // 0x72d548: AllocStack(0x8)
    //     0x72d548: sub             SP, SP, #8
    // 0x72d54c: CheckStackOverflow
    //     0x72d54c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72d550: cmp             SP, x16
    //     0x72d554: b.ls            #0x72d5d0
    // 0x72d558: LoadField: r2 = r1->field_b
    //     0x72d558: ldur            w2, [x1, #0xb]
    // 0x72d55c: DecompressPointer r2
    //     0x72d55c: add             x2, x2, HEAP, lsl #32
    // 0x72d560: r1 = Null
    //     0x72d560: mov             x1, NULL
    // 0x72d564: r3 = <QuestButton<X0>, void?, QuestButton<X0>, X0>
    //     0x72d564: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2a328] TypeArguments: <QuestButton<X0>, void?, QuestButton<X0>, X0>
    //     0x72d568: ldr             x3, [x3, #0x328]
    // 0x72d56c: r30 = InstantiateTypeArgumentsStub
    //     0x72d56c: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x72d570: LoadField: r30 = r30->field_7
    //     0x72d570: ldur            lr, [lr, #7]
    // 0x72d574: blr             lr
    // 0x72d578: mov             x1, x0
    // 0x72d57c: r0 = QuestButtonState()
    //     0x72d57c: bl              #0x72d5d8  ; AllocateQuestButtonStateStub -> QuestButtonState<C3X0> (size=0x1c)
    // 0x72d580: mov             x1, x0
    // 0x72d584: r0 = Instance_QuestState
    //     0x72d584: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a330] Obj!QuestState@85e9c1
    //     0x72d588: ldr             x0, [x0, #0x330]
    // 0x72d58c: stur            x1, [fp, #-8]
    // 0x72d590: ArrayStore: r1[0] = r0  ; List_4
    //     0x72d590: stur            w0, [x1, #0x17]
    // 0x72d594: r0 = LoadStaticField(0x103c)
    //     0x72d594: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x72d598: ldr             x0, [x0, #0x2078]
    // 0x72d59c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72d5a0: cmp             w0, w16
    // 0x72d5a4: b.ne            #0x72d5b4
    // 0x72d5a8: r2 = quests
    //     0x72d5a8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc40] Field <::.quests>: static late (offset: 0x103c)
    //     0x72d5ac: ldr             x2, [x2, #0xc40]
    // 0x72d5b0: r0 = InitLateStaticField()
    //     0x72d5b0: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x72d5b4: ldur            x1, [fp, #-8]
    // 0x72d5b8: mov             x2, x0
    // 0x72d5bc: r0 = SyncState()
    //     0x72d5bc: bl              #0x72bee4  ; [package:state_groups/src/sync_state.dart] SyncState::SyncState
    // 0x72d5c0: ldur            x0, [fp, #-8]
    // 0x72d5c4: LeaveFrame
    //     0x72d5c4: mov             SP, fp
    //     0x72d5c8: ldp             fp, lr, [SP], #0x10
    // 0x72d5cc: ret
    //     0x72d5cc: ret             
    // 0x72d5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72d5d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72d5d4: b               #0x72d558
  }
}

// class id: 3285, size: 0x1c, field offset: 0x18
class QuestButtonState<C3X0> extends SyncState<C3X0, dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x61a6d0, size: 0x324
    // 0x61a6d0: EnterFrame
    //     0x61a6d0: stp             fp, lr, [SP, #-0x10]!
    //     0x61a6d4: mov             fp, SP
    // 0x61a6d8: AllocStack(0x50)
    //     0x61a6d8: sub             SP, SP, #0x50
    // 0x61a6dc: SetupParameters(QuestButtonState<C3X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x61a6dc: stur            x1, [fp, #-8]
    //     0x61a6e0: stur            x2, [fp, #-0x10]
    // 0x61a6e4: CheckStackOverflow
    //     0x61a6e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61a6e8: cmp             SP, x16
    //     0x61a6ec: b.ls            #0x61a9e8
    // 0x61a6f0: r1 = 3
    //     0x61a6f0: movz            x1, #0x3
    // 0x61a6f4: r0 = AllocateContext()
    //     0x61a6f4: bl              #0x82637c  ; AllocateContextStub
    // 0x61a6f8: mov             x2, x0
    // 0x61a6fc: ldur            x0, [fp, #-8]
    // 0x61a700: stur            x2, [fp, #-0x18]
    // 0x61a704: StoreField: r2->field_f = r0
    //     0x61a704: stur            w0, [x2, #0xf]
    // 0x61a708: ldur            x1, [fp, #-0x10]
    // 0x61a70c: StoreField: r2->field_13 = r1
    //     0x61a70c: stur            w1, [x2, #0x13]
    // 0x61a710: mov             x1, x0
    // 0x61a714: r0 = getState()
    //     0x61a714: bl              #0x61ad7c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getState
    // 0x61a718: ldur            x3, [fp, #-8]
    // 0x61a71c: ArrayStore: r3[0] = r0  ; List_4
    //     0x61a71c: stur            w0, [x3, #0x17]
    //     0x61a720: ldurb           w16, [x3, #-1]
    //     0x61a724: ldurb           w17, [x0, #-1]
    //     0x61a728: and             x16, x17, x16, lsr #2
    //     0x61a72c: tst             x16, HEAP, lsr #32
    //     0x61a730: b.eq            #0x61a738
    //     0x61a734: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x61a738: ldur            x0, [fp, #-0x18]
    // 0x61a73c: LoadField: r2 = r0->field_13
    //     0x61a73c: ldur            w2, [x0, #0x13]
    // 0x61a740: DecompressPointer r2
    //     0x61a740: add             x2, x2, HEAP, lsl #32
    // 0x61a744: mov             x1, x3
    // 0x61a748: r0 = getOverrideColor()
    //     0x61a748: bl              #0x61abbc  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getOverrideColor
    // 0x61a74c: mov             x4, x0
    // 0x61a750: ldur            x3, [fp, #-0x18]
    // 0x61a754: stur            x4, [fp, #-0x10]
    // 0x61a758: ArrayStore: r3[0] = r0  ; List_4
    //     0x61a758: stur            w0, [x3, #0x17]
    //     0x61a75c: ldurb           w16, [x3, #-1]
    //     0x61a760: ldurb           w17, [x0, #-1]
    //     0x61a764: and             x16, x17, x16, lsr #2
    //     0x61a768: tst             x16, HEAP, lsr #32
    //     0x61a76c: b.eq            #0x61a774
    //     0x61a770: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x61a774: mov             x2, x3
    // 0x61a778: r1 = Function 'makeQuestText':.
    //     0x61a778: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c228] AnonymousClosure: (0x61c1b4), in [package:pretentious/widgets/QuestButton.dart] QuestButtonState::build (0x61a6d0)
    //     0x61a77c: ldr             x1, [x1, #0x228]
    // 0x61a780: r0 = AllocateClosure()
    //     0x61a780: bl              #0x826750  ; AllocateClosureStub
    // 0x61a784: ldur            x1, [fp, #-8]
    // 0x61a788: stur            x0, [fp, #-0x28]
    // 0x61a78c: LoadField: r2 = r1->field_b
    //     0x61a78c: ldur            w2, [x1, #0xb]
    // 0x61a790: DecompressPointer r2
    //     0x61a790: add             x2, x2, HEAP, lsl #32
    // 0x61a794: cmp             w2, NULL
    // 0x61a798: b.eq            #0x61a9f0
    // 0x61a79c: LoadField: r3 = r2->field_1f
    //     0x61a79c: ldur            w3, [x2, #0x1f]
    // 0x61a7a0: DecompressPointer r3
    //     0x61a7a0: add             x3, x3, HEAP, lsl #32
    // 0x61a7a4: stur            x3, [fp, #-0x20]
    // 0x61a7a8: r0 = Icon()
    //     0x61a7a8: bl              #0x5d1874  ; AllocateIconStub -> Icon (size=0x40)
    // 0x61a7ac: mov             x3, x0
    // 0x61a7b0: ldur            x0, [fp, #-0x20]
    // 0x61a7b4: stur            x3, [fp, #-0x30]
    // 0x61a7b8: StoreField: r3->field_b = r0
    //     0x61a7b8: stur            w0, [x3, #0xb]
    // 0x61a7bc: ldur            x0, [fp, #-0x10]
    // 0x61a7c0: StoreField: r3->field_23 = r0
    //     0x61a7c0: stur            w0, [x3, #0x23]
    // 0x61a7c4: r1 = Null
    //     0x61a7c4: mov             x1, NULL
    // 0x61a7c8: r2 = 2
    //     0x61a7c8: movz            x2, #0x2
    // 0x61a7cc: r0 = AllocateArray()
    //     0x61a7cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x61a7d0: mov             x2, x0
    // 0x61a7d4: ldur            x0, [fp, #-0x30]
    // 0x61a7d8: stur            x2, [fp, #-0x20]
    // 0x61a7dc: StoreField: r2->field_f = r0
    //     0x61a7dc: stur            w0, [x2, #0xf]
    // 0x61a7e0: r1 = <Widget>
    //     0x61a7e0: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x61a7e4: r0 = AllocateGrowableArray()
    //     0x61a7e4: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x61a7e8: mov             x1, x0
    // 0x61a7ec: ldur            x0, [fp, #-0x20]
    // 0x61a7f0: stur            x1, [fp, #-0x30]
    // 0x61a7f4: StoreField: r1->field_f = r0
    //     0x61a7f4: stur            w0, [x1, #0xf]
    // 0x61a7f8: r0 = 2
    //     0x61a7f8: movz            x0, #0x2
    // 0x61a7fc: StoreField: r1->field_b = r0
    //     0x61a7fc: stur            w0, [x1, #0xb]
    // 0x61a800: ldur            x16, [fp, #-0x28]
    // 0x61a804: str             x16, [SP]
    // 0x61a808: ldur            x0, [fp, #-0x28]
    // 0x61a80c: ClosureCall
    //     0x61a80c: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61a810: ldur            x2, [x0, #0x1f]
    //     0x61a814: blr             x2
    // 0x61a818: ldur            x1, [fp, #-0x30]
    // 0x61a81c: mov             x2, x0
    // 0x61a820: r0 = addAll()
    //     0x61a820: bl              #0x328214  ; [dart:core] _GrowableList::addAll
    // 0x61a824: ldur            x1, [fp, #-8]
    // 0x61a828: r0 = getRightText()
    //     0x61a828: bl              #0x61a9f4  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getRightText
    // 0x61a82c: stur            x0, [fp, #-8]
    // 0x61a830: r0 = TextStyle()
    //     0x61a830: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x61a834: mov             x1, x0
    // 0x61a838: r0 = true
    //     0x61a838: add             x0, NULL, #0x20  ; true
    // 0x61a83c: stur            x1, [fp, #-0x20]
    // 0x61a840: StoreField: r1->field_7 = r0
    //     0x61a840: stur            w0, [x1, #7]
    // 0x61a844: ldur            x0, [fp, #-0x10]
    // 0x61a848: StoreField: r1->field_b = r0
    //     0x61a848: stur            w0, [x1, #0xb]
    // 0x61a84c: r0 = Text()
    //     0x61a84c: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61a850: mov             x1, x0
    // 0x61a854: ldur            x0, [fp, #-8]
    // 0x61a858: stur            x1, [fp, #-0x10]
    // 0x61a85c: StoreField: r1->field_b = r0
    //     0x61a85c: stur            w0, [x1, #0xb]
    // 0x61a860: ldur            x0, [fp, #-0x20]
    // 0x61a864: StoreField: r1->field_13 = r0
    //     0x61a864: stur            w0, [x1, #0x13]
    // 0x61a868: r0 = Padding()
    //     0x61a868: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x61a86c: mov             x2, x0
    // 0x61a870: r0 = Instance_EdgeInsets
    //     0x61a870: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c148] Obj!EdgeInsets@832701
    //     0x61a874: ldr             x0, [x0, #0x148]
    // 0x61a878: stur            x2, [fp, #-8]
    // 0x61a87c: StoreField: r2->field_f = r0
    //     0x61a87c: stur            w0, [x2, #0xf]
    // 0x61a880: ldur            x0, [fp, #-0x10]
    // 0x61a884: StoreField: r2->field_b = r0
    //     0x61a884: stur            w0, [x2, #0xb]
    // 0x61a888: ldur            x0, [fp, #-0x30]
    // 0x61a88c: LoadField: r1 = r0->field_b
    //     0x61a88c: ldur            w1, [x0, #0xb]
    // 0x61a890: LoadField: r3 = r0->field_f
    //     0x61a890: ldur            w3, [x0, #0xf]
    // 0x61a894: DecompressPointer r3
    //     0x61a894: add             x3, x3, HEAP, lsl #32
    // 0x61a898: LoadField: r4 = r3->field_b
    //     0x61a898: ldur            w4, [x3, #0xb]
    // 0x61a89c: r3 = LoadInt32Instr(r1)
    //     0x61a89c: sbfx            x3, x1, #1, #0x1f
    // 0x61a8a0: stur            x3, [fp, #-0x38]
    // 0x61a8a4: r1 = LoadInt32Instr(r4)
    //     0x61a8a4: sbfx            x1, x4, #1, #0x1f
    // 0x61a8a8: cmp             x3, x1
    // 0x61a8ac: b.ne            #0x61a8b8
    // 0x61a8b0: mov             x1, x0
    // 0x61a8b4: r0 = _growToNextCapacity()
    //     0x61a8b4: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x61a8b8: ldur            x2, [fp, #-0x30]
    // 0x61a8bc: ldur            x3, [fp, #-0x38]
    // 0x61a8c0: add             x0, x3, #1
    // 0x61a8c4: lsl             x1, x0, #1
    // 0x61a8c8: StoreField: r2->field_b = r1
    //     0x61a8c8: stur            w1, [x2, #0xb]
    // 0x61a8cc: LoadField: r1 = r2->field_f
    //     0x61a8cc: ldur            w1, [x2, #0xf]
    // 0x61a8d0: DecompressPointer r1
    //     0x61a8d0: add             x1, x1, HEAP, lsl #32
    // 0x61a8d4: ldur            x0, [fp, #-8]
    // 0x61a8d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x61a8d8: add             x25, x1, x3, lsl #2
    //     0x61a8dc: add             x25, x25, #0xf
    //     0x61a8e0: str             w0, [x25]
    //     0x61a8e4: tbz             w0, #0, #0x61a900
    //     0x61a8e8: ldurb           w16, [x1, #-1]
    //     0x61a8ec: ldurb           w17, [x0, #-1]
    //     0x61a8f0: and             x16, x17, x16, lsr #2
    //     0x61a8f4: tst             x16, HEAP, lsr #32
    //     0x61a8f8: b.eq            #0x61a900
    //     0x61a8fc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61a900: r0 = Row()
    //     0x61a900: bl              #0x59e9b8  ; AllocateRowStub -> Row (size=0x38)
    // 0x61a904: mov             x1, x0
    // 0x61a908: r0 = Instance_Axis
    //     0x61a908: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x61a90c: stur            x1, [fp, #-8]
    // 0x61a910: StoreField: r1->field_f = r0
    //     0x61a910: stur            w0, [x1, #0xf]
    // 0x61a914: r0 = Instance_MainAxisAlignment
    //     0x61a914: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x61a918: ldr             x0, [x0, #0x200]
    // 0x61a91c: StoreField: r1->field_13 = r0
    //     0x61a91c: stur            w0, [x1, #0x13]
    // 0x61a920: r0 = Instance_MainAxisSize
    //     0x61a920: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x61a924: ldr             x0, [x0, #0x70]
    // 0x61a928: ArrayStore: r1[0] = r0  ; List_4
    //     0x61a928: stur            w0, [x1, #0x17]
    // 0x61a92c: r0 = Instance_CrossAxisAlignment
    //     0x61a92c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x61a930: ldr             x0, [x0, #0x78]
    // 0x61a934: StoreField: r1->field_1b = r0
    //     0x61a934: stur            w0, [x1, #0x1b]
    // 0x61a938: r0 = Instance_VerticalDirection
    //     0x61a938: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x61a93c: ldr             x0, [x0, #0x1e8]
    // 0x61a940: StoreField: r1->field_23 = r0
    //     0x61a940: stur            w0, [x1, #0x23]
    // 0x61a944: r0 = Instance_Clip
    //     0x61a944: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x61a948: ldr             x0, [x0, #0x1b0]
    // 0x61a94c: StoreField: r1->field_2b = r0
    //     0x61a94c: stur            w0, [x1, #0x2b]
    // 0x61a950: StoreField: r1->field_2f = rZR
    //     0x61a950: stur            xzr, [x1, #0x2f]
    // 0x61a954: ldur            x0, [fp, #-0x30]
    // 0x61a958: StoreField: r1->field_b = r0
    //     0x61a958: stur            w0, [x1, #0xb]
    // 0x61a95c: r0 = SizedBox()
    //     0x61a95c: bl              #0x59ffb0  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x61a960: mov             x1, x0
    // 0x61a964: r0 = 60.000000
    //     0x61a964: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c230] 60
    //     0x61a968: ldr             x0, [x0, #0x230]
    // 0x61a96c: stur            x1, [fp, #-0x10]
    // 0x61a970: StoreField: r1->field_13 = r0
    //     0x61a970: stur            w0, [x1, #0x13]
    // 0x61a974: ldur            x0, [fp, #-8]
    // 0x61a978: StoreField: r1->field_b = r0
    //     0x61a978: stur            w0, [x1, #0xb]
    // 0x61a97c: r0 = Padding()
    //     0x61a97c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x61a980: mov             x1, x0
    // 0x61a984: r0 = Instance_EdgeInsets
    //     0x61a984: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a058] Obj!EdgeInsets@8326d1
    //     0x61a988: ldr             x0, [x0, #0x58]
    // 0x61a98c: stur            x1, [fp, #-8]
    // 0x61a990: StoreField: r1->field_f = r0
    //     0x61a990: stur            w0, [x1, #0xf]
    // 0x61a994: ldur            x0, [fp, #-0x10]
    // 0x61a998: StoreField: r1->field_b = r0
    //     0x61a998: stur            w0, [x1, #0xb]
    // 0x61a99c: r0 = GestureDetector()
    //     0x61a99c: bl              #0x5a4268  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x61a9a0: ldur            x2, [fp, #-0x18]
    // 0x61a9a4: r1 = Function '<anonymous closure>':.
    //     0x61a9a4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c238] AnonymousClosure: (0x61b380), in [package:pretentious/widgets/QuestButton.dart] QuestButtonState::build (0x61a6d0)
    //     0x61a9a8: ldr             x1, [x1, #0x238]
    // 0x61a9ac: stur            x0, [fp, #-0x10]
    // 0x61a9b0: r0 = AllocateClosure()
    //     0x61a9b0: bl              #0x826750  ; AllocateClosureStub
    // 0x61a9b4: r16 = Instance_HitTestBehavior
    //     0x61a9b4: add             x16, PP, #0xc, lsl #12  ; [pp+0xc910] Obj!HitTestBehavior@862901
    //     0x61a9b8: ldr             x16, [x16, #0x910]
    // 0x61a9bc: stp             x0, x16, [SP, #8]
    // 0x61a9c0: ldur            x16, [fp, #-8]
    // 0x61a9c4: str             x16, [SP]
    // 0x61a9c8: ldur            x1, [fp, #-0x10]
    // 0x61a9cc: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x1, child, 0x3, onTap, 0x2, null]
    //     0x61a9cc: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a840] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0x61a9d0: ldr             x4, [x4, #0x840]
    // 0x61a9d4: r0 = GestureDetector()
    //     0x61a9d4: bl              #0x5a3d1c  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x61a9d8: ldur            x0, [fp, #-0x10]
    // 0x61a9dc: LeaveFrame
    //     0x61a9dc: mov             SP, fp
    //     0x61a9e0: ldp             fp, lr, [SP], #0x10
    // 0x61a9e4: ret
    //     0x61a9e4: ret             
    // 0x61a9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61a9e8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61a9ec: b               #0x61a6f0
    // 0x61a9f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61a9f0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getRightText(/* No info */) {
    // ** addr: 0x61a9f4, size: 0x128
    // 0x61a9f4: EnterFrame
    //     0x61a9f4: stp             fp, lr, [SP, #-0x10]!
    //     0x61a9f8: mov             fp, SP
    // 0x61a9fc: AllocStack(0x18)
    //     0x61a9fc: sub             SP, SP, #0x18
    // 0x61aa00: CheckStackOverflow
    //     0x61aa00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61aa04: cmp             SP, x16
    //     0x61aa08: b.ls            #0x61ab14
    // 0x61aa0c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x61aa0c: ldur            w0, [x1, #0x17]
    // 0x61aa10: DecompressPointer r0
    //     0x61aa10: add             x0, x0, HEAP, lsl #32
    // 0x61aa14: LoadField: r2 = r0->field_7
    //     0x61aa14: ldur            x2, [x0, #7]
    // 0x61aa18: cmp             x2, #2
    // 0x61aa1c: b.gt            #0x61aa68
    // 0x61aa20: cmp             x2, #1
    // 0x61aa24: b.gt            #0x61aa58
    // 0x61aa28: cmp             x2, #0
    // 0x61aa2c: b.gt            #0x61aa44
    // 0x61aa30: r0 = "Tap To Start"
    //     0x61aa30: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c300] "Tap To Start"
    //     0x61aa34: ldr             x0, [x0, #0x300]
    // 0x61aa38: LeaveFrame
    //     0x61aa38: mov             SP, fp
    //     0x61aa3c: ldp             fp, lr, [SP], #0x10
    // 0x61aa40: ret
    //     0x61aa40: ret             
    // 0x61aa44: r0 = "Unavailable"
    //     0x61aa44: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c308] "Unavailable"
    //     0x61aa48: ldr             x0, [x0, #0x308]
    // 0x61aa4c: LeaveFrame
    //     0x61aa4c: mov             SP, fp
    //     0x61aa50: ldp             fp, lr, [SP], #0x10
    // 0x61aa54: ret
    //     0x61aa54: ret             
    // 0x61aa58: r0 = ""
    //     0x61aa58: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x61aa5c: LeaveFrame
    //     0x61aa5c: mov             SP, fp
    //     0x61aa60: ldp             fp, lr, [SP], #0x10
    // 0x61aa64: ret
    //     0x61aa64: ret             
    // 0x61aa68: cmp             x2, #3
    // 0x61aa6c: b.gt            #0x61ab00
    // 0x61aa70: r0 = remainingTime()
    //     0x61aa70: bl              #0x61ab1c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::remainingTime
    // 0x61aa74: stur            x0, [fp, #-8]
    // 0x61aa78: cmp             w0, NULL
    // 0x61aa7c: b.eq            #0x61aaec
    // 0x61aa80: r1 = Null
    //     0x61aa80: mov             x1, NULL
    // 0x61aa84: r2 = 6
    //     0x61aa84: movz            x2, #0x6
    // 0x61aa88: r0 = AllocateArray()
    //     0x61aa88: bl              #0x82746c  ; AllocateArrayStub
    // 0x61aa8c: stur            x0, [fp, #-0x10]
    // 0x61aa90: r16 = "Tap To Complete ("
    //     0x61aa90: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c310] "Tap To Complete ("
    //     0x61aa94: ldr             x16, [x16, #0x310]
    // 0x61aa98: StoreField: r0->field_f = r16
    //     0x61aa98: stur            w16, [x0, #0xf]
    // 0x61aa9c: ldur            x1, [fp, #-8]
    // 0x61aaa0: r0 = ToStringNoMilliseconds.toStringNoMilliseconds()
    //     0x61aaa0: bl              #0x5a05bc  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::ToStringNoMilliseconds.toStringNoMilliseconds
    // 0x61aaa4: ldur            x1, [fp, #-0x10]
    // 0x61aaa8: ArrayStore: r1[1] = r0  ; List_4
    //     0x61aaa8: add             x25, x1, #0x13
    //     0x61aaac: str             w0, [x25]
    //     0x61aab0: tbz             w0, #0, #0x61aacc
    //     0x61aab4: ldurb           w16, [x1, #-1]
    //     0x61aab8: ldurb           w17, [x0, #-1]
    //     0x61aabc: and             x16, x17, x16, lsr #2
    //     0x61aac0: tst             x16, HEAP, lsr #32
    //     0x61aac4: b.eq            #0x61aacc
    //     0x61aac8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61aacc: ldur            x0, [fp, #-0x10]
    // 0x61aad0: r16 = ")"
    //     0x61aad0: ldr             x16, [PP, #0x2228]  ; [pp+0x2228] ")"
    // 0x61aad4: ArrayStore: r0[0] = r16  ; List_4
    //     0x61aad4: stur            w16, [x0, #0x17]
    // 0x61aad8: str             x0, [SP]
    // 0x61aadc: r0 = _interpolate()
    //     0x61aadc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61aae0: LeaveFrame
    //     0x61aae0: mov             SP, fp
    //     0x61aae4: ldp             fp, lr, [SP], #0x10
    // 0x61aae8: ret
    //     0x61aae8: ret             
    // 0x61aaec: r0 = "Tap To Complete"
    //     0x61aaec: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c318] "Tap To Complete"
    //     0x61aaf0: ldr             x0, [x0, #0x318]
    // 0x61aaf4: LeaveFrame
    //     0x61aaf4: mov             SP, fp
    //     0x61aaf8: ldp             fp, lr, [SP], #0x10
    // 0x61aafc: ret
    //     0x61aafc: ret             
    // 0x61ab00: r0 = "Done"
    //     0x61ab00: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b908] "Done"
    //     0x61ab04: ldr             x0, [x0, #0x908]
    // 0x61ab08: LeaveFrame
    //     0x61ab08: mov             SP, fp
    //     0x61ab0c: ldp             fp, lr, [SP], #0x10
    // 0x61ab10: ret
    //     0x61ab10: ret             
    // 0x61ab14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61ab14: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61ab18: b               #0x61aa0c
  }
  _ remainingTime(/* No info */) {
    // ** addr: 0x61ab1c, size: 0xa0
    // 0x61ab1c: EnterFrame
    //     0x61ab1c: stp             fp, lr, [SP, #-0x10]!
    //     0x61ab20: mov             fp, SP
    // 0x61ab24: AllocStack(0x10)
    //     0x61ab24: sub             SP, SP, #0x10
    // 0x61ab28: CheckStackOverflow
    //     0x61ab28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61ab2c: cmp             SP, x16
    //     0x61ab30: b.ls            #0x61abb0
    // 0x61ab34: LoadField: r0 = r1->field_b
    //     0x61ab34: ldur            w0, [x1, #0xb]
    // 0x61ab38: DecompressPointer r0
    //     0x61ab38: add             x0, x0, HEAP, lsl #32
    // 0x61ab3c: cmp             w0, NULL
    // 0x61ab40: b.eq            #0x61abb8
    // 0x61ab44: LoadField: r1 = r0->field_2b
    //     0x61ab44: ldur            w1, [x0, #0x2b]
    // 0x61ab48: DecompressPointer r1
    //     0x61ab48: add             x1, x1, HEAP, lsl #32
    // 0x61ab4c: LoadField: r0 = r1->field_f
    //     0x61ab4c: ldur            w0, [x1, #0xf]
    // 0x61ab50: DecompressPointer r0
    //     0x61ab50: add             x0, x0, HEAP, lsl #32
    // 0x61ab54: stur            x0, [fp, #-8]
    // 0x61ab58: cmp             w0, NULL
    // 0x61ab5c: b.ne            #0x61ab70
    // 0x61ab60: r0 = Null
    //     0x61ab60: mov             x0, NULL
    // 0x61ab64: LeaveFrame
    //     0x61ab64: mov             SP, fp
    //     0x61ab68: ldp             fp, lr, [SP], #0x10
    // 0x61ab6c: ret
    //     0x61ab6c: ret             
    // 0x61ab70: r0 = DateTime()
    //     0x61ab70: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x61ab74: mov             x1, x0
    // 0x61ab78: r0 = false
    //     0x61ab78: add             x0, NULL, #0x30  ; false
    // 0x61ab7c: stur            x1, [fp, #-0x10]
    // 0x61ab80: StoreField: r1->field_7 = r0
    //     0x61ab80: stur            w0, [x1, #7]
    // 0x61ab84: r0 = _getCurrentMicros()
    //     0x61ab84: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x61ab88: r1 = LoadInt32Instr(r0)
    //     0x61ab88: sbfx            x1, x0, #1, #0x1f
    //     0x61ab8c: tbz             w0, #0, #0x61ab94
    //     0x61ab90: ldur            x1, [x0, #7]
    // 0x61ab94: ldur            x2, [fp, #-0x10]
    // 0x61ab98: StoreField: r2->field_b = r1
    //     0x61ab98: stur            x1, [x2, #0xb]
    // 0x61ab9c: ldur            x1, [fp, #-8]
    // 0x61aba0: r0 = difference()
    //     0x61aba0: bl              #0x36dbb8  ; [dart:core] DateTime::difference
    // 0x61aba4: LeaveFrame
    //     0x61aba4: mov             SP, fp
    //     0x61aba8: ldp             fp, lr, [SP], #0x10
    // 0x61abac: ret
    //     0x61abac: ret             
    // 0x61abb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61abb0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61abb4: b               #0x61ab34
    // 0x61abb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61abb8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getOverrideColor(/* No info */) {
    // ** addr: 0x61abbc, size: 0xe8
    // 0x61abbc: EnterFrame
    //     0x61abbc: stp             fp, lr, [SP, #-0x10]!
    //     0x61abc0: mov             fp, SP
    // 0x61abc4: mov             x0, x1
    // 0x61abc8: mov             x1, x2
    // 0x61abcc: CheckStackOverflow
    //     0x61abcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61abd0: cmp             SP, x16
    //     0x61abd4: b.ls            #0x61ac9c
    // 0x61abd8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x61abd8: ldur            w2, [x0, #0x17]
    // 0x61abdc: DecompressPointer r2
    //     0x61abdc: add             x2, x2, HEAP, lsl #32
    // 0x61abe0: LoadField: r0 = r2->field_7
    //     0x61abe0: ldur            x0, [x2, #7]
    // 0x61abe4: cmp             x0, #2
    // 0x61abe8: b.gt            #0x61ac40
    // 0x61abec: cmp             x0, #1
    // 0x61abf0: b.gt            #0x61ac28
    // 0x61abf4: cmp             x0, #0
    // 0x61abf8: b.gt            #0x61ac0c
    // 0x61abfc: r0 = Null
    //     0x61abfc: mov             x0, NULL
    // 0x61ac00: LeaveFrame
    //     0x61ac00: mov             SP, fp
    //     0x61ac04: ldp             fp, lr, [SP], #0x10
    // 0x61ac08: ret
    //     0x61ac08: ret             
    // 0x61ac0c: r0 = of()
    //     0x61ac0c: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x61ac10: LoadField: r1 = r0->field_43
    //     0x61ac10: ldur            w1, [x0, #0x43]
    // 0x61ac14: DecompressPointer r1
    //     0x61ac14: add             x1, x1, HEAP, lsl #32
    // 0x61ac18: mov             x0, x1
    // 0x61ac1c: LeaveFrame
    //     0x61ac1c: mov             SP, fp
    //     0x61ac20: ldp             fp, lr, [SP], #0x10
    // 0x61ac24: ret
    //     0x61ac24: ret             
    // 0x61ac28: r1 = Instance_MaterialColor
    //     0x61ac28: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c320] Obj!MaterialColor@83fa31
    //     0x61ac2c: ldr             x1, [x1, #0x320]
    // 0x61ac30: r0 = shade600()
    //     0x61ac30: bl              #0x61ad34  ; [package:flutter/src/material/colors.dart] MaterialColor::shade600
    // 0x61ac34: LeaveFrame
    //     0x61ac34: mov             SP, fp
    //     0x61ac38: ldp             fp, lr, [SP], #0x10
    // 0x61ac3c: ret
    //     0x61ac3c: ret             
    // 0x61ac40: cmp             x0, #3
    // 0x61ac44: b.gt            #0x61ac80
    // 0x61ac48: r0 = of()
    //     0x61ac48: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x61ac4c: mov             x1, x0
    // 0x61ac50: r0 = ThemeDarkMode.darkModeEnabled()
    //     0x61ac50: bl              #0x4e8990  ; [package:custom_tools/BasicExtensions.dart] ::ThemeDarkMode.darkModeEnabled
    // 0x61ac54: tbnz            w0, #4, #0x61ac68
    // 0x61ac58: r1 = Instance_MaterialColor
    //     0x61ac58: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c320] Obj!MaterialColor@83fa31
    //     0x61ac5c: ldr             x1, [x1, #0x320]
    // 0x61ac60: r0 = shade300()
    //     0x61ac60: bl              #0x61acec  ; [package:flutter/src/material/colors.dart] MaterialColor::shade300
    // 0x61ac64: b               #0x61ac74
    // 0x61ac68: r1 = Instance_MaterialColor
    //     0x61ac68: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c320] Obj!MaterialColor@83fa31
    //     0x61ac6c: ldr             x1, [x1, #0x320]
    // 0x61ac70: r0 = shade900()
    //     0x61ac70: bl              #0x61aca4  ; [package:flutter/src/material/colors.dart] MaterialColor::shade900
    // 0x61ac74: LeaveFrame
    //     0x61ac74: mov             SP, fp
    //     0x61ac78: ldp             fp, lr, [SP], #0x10
    // 0x61ac7c: ret
    //     0x61ac7c: ret             
    // 0x61ac80: r0 = of()
    //     0x61ac80: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x61ac84: LoadField: r1 = r0->field_5b
    //     0x61ac84: ldur            w1, [x0, #0x5b]
    // 0x61ac88: DecompressPointer r1
    //     0x61ac88: add             x1, x1, HEAP, lsl #32
    // 0x61ac8c: mov             x0, x1
    // 0x61ac90: LeaveFrame
    //     0x61ac90: mov             SP, fp
    //     0x61ac94: ldp             fp, lr, [SP], #0x10
    // 0x61ac98: ret
    //     0x61ac98: ret             
    // 0x61ac9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61ac9c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61aca0: b               #0x61abd8
  }
  _ getState(/* No info */) {
    // ** addr: 0x61ad7c, size: 0xe8
    // 0x61ad7c: EnterFrame
    //     0x61ad7c: stp             fp, lr, [SP, #-0x10]!
    //     0x61ad80: mov             fp, SP
    // 0x61ad84: AllocStack(0x8)
    //     0x61ad84: sub             SP, SP, #8
    // 0x61ad88: SetupParameters(QuestButtonState<C3X0> this /* r1 => r0, fp-0x8 */)
    //     0x61ad88: mov             x0, x1
    //     0x61ad8c: stur            x1, [fp, #-8]
    // 0x61ad90: CheckStackOverflow
    //     0x61ad90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61ad94: cmp             SP, x16
    //     0x61ad98: b.ls            #0x61ae58
    // 0x61ad9c: mov             x1, x0
    // 0x61ada0: r0 = hasNextQuest()
    //     0x61ada0: bl              #0x61b184  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::hasNextQuest
    // 0x61ada4: tbz             w0, #4, #0x61adbc
    // 0x61ada8: r0 = Instance_QuestState
    //     0x61ada8: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c250] Obj!QuestState@85e9e1
    //     0x61adac: ldr             x0, [x0, #0x250]
    // 0x61adb0: LeaveFrame
    //     0x61adb0: mov             SP, fp
    //     0x61adb4: ldp             fp, lr, [SP], #0x10
    // 0x61adb8: ret
    //     0x61adb8: ret             
    // 0x61adbc: ldur            x1, [fp, #-8]
    // 0x61adc0: LoadField: r0 = r1->field_b
    //     0x61adc0: ldur            w0, [x1, #0xb]
    // 0x61adc4: DecompressPointer r0
    //     0x61adc4: add             x0, x0, HEAP, lsl #32
    // 0x61adc8: cmp             w0, NULL
    // 0x61adcc: b.eq            #0x61ae60
    // 0x61add0: LoadField: r2 = r0->field_2b
    //     0x61add0: ldur            w2, [x0, #0x2b]
    // 0x61add4: DecompressPointer r2
    //     0x61add4: add             x2, x2, HEAP, lsl #32
    // 0x61add8: LoadField: r3 = r2->field_7
    //     0x61add8: ldur            w3, [x2, #7]
    // 0x61addc: DecompressPointer r3
    //     0x61addc: add             x3, x3, HEAP, lsl #32
    // 0x61ade0: cmp             w3, NULL
    // 0x61ade4: b.ne            #0x61adfc
    // 0x61ade8: r0 = Instance_QuestState
    //     0x61ade8: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a330] Obj!QuestState@85e9c1
    //     0x61adec: ldr             x0, [x0, #0x330]
    // 0x61adf0: LeaveFrame
    //     0x61adf0: mov             SP, fp
    //     0x61adf4: ldp             fp, lr, [SP], #0x10
    // 0x61adf8: ret
    //     0x61adf8: ret             
    // 0x61adfc: LoadField: r2 = r0->field_23
    //     0x61adfc: ldur            x2, [x0, #0x23]
    // 0x61ae00: r0 = LoadInt32Instr(r3)
    //     0x61ae00: sbfx            x0, x3, #1, #0x1f
    //     0x61ae04: tbz             w3, #0, #0x61ae0c
    //     0x61ae08: ldur            x0, [x3, #7]
    // 0x61ae0c: cmp             x0, x2
    // 0x61ae10: b.ne            #0x61ae44
    // 0x61ae14: r0 = checkCanBeCompleted()
    //     0x61ae14: bl              #0x61ae64  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::checkCanBeCompleted
    // 0x61ae18: tbnz            w0, #4, #0x61ae30
    // 0x61ae1c: r0 = Instance_QuestState
    //     0x61ae1c: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c240] Obj!QuestState@85e9a1
    //     0x61ae20: ldr             x0, [x0, #0x240]
    // 0x61ae24: LeaveFrame
    //     0x61ae24: mov             SP, fp
    //     0x61ae28: ldp             fp, lr, [SP], #0x10
    // 0x61ae2c: ret
    //     0x61ae2c: ret             
    // 0x61ae30: r0 = Instance_QuestState
    //     0x61ae30: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c298] Obj!QuestState@85e981
    //     0x61ae34: ldr             x0, [x0, #0x298]
    // 0x61ae38: LeaveFrame
    //     0x61ae38: mov             SP, fp
    //     0x61ae3c: ldp             fp, lr, [SP], #0x10
    // 0x61ae40: ret
    //     0x61ae40: ret             
    // 0x61ae44: r0 = Instance_QuestState
    //     0x61ae44: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c328] Obj!QuestState@85e961
    //     0x61ae48: ldr             x0, [x0, #0x328]
    // 0x61ae4c: LeaveFrame
    //     0x61ae4c: mov             SP, fp
    //     0x61ae50: ldp             fp, lr, [SP], #0x10
    // 0x61ae54: ret
    //     0x61ae54: ret             
    // 0x61ae58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61ae58: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61ae5c: b               #0x61ad9c
    // 0x61ae60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61ae60: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ checkCanBeCompleted(/* No info */) {
    // ** addr: 0x61ae64, size: 0xac
    // 0x61ae64: EnterFrame
    //     0x61ae64: stp             fp, lr, [SP, #-0x10]!
    //     0x61ae68: mov             fp, SP
    // 0x61ae6c: AllocStack(0x30)
    //     0x61ae6c: sub             SP, SP, #0x30
    // 0x61ae70: SetupParameters(QuestButtonState<C3X0> this /* r1 => r0, fp-0x8 */)
    //     0x61ae70: mov             x0, x1
    //     0x61ae74: stur            x1, [fp, #-8]
    // 0x61ae78: CheckStackOverflow
    //     0x61ae78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61ae7c: cmp             SP, x16
    //     0x61ae80: b.ls            #0x61af04
    // 0x61ae84: LoadField: r2 = r0->field_7
    //     0x61ae84: ldur            w2, [x0, #7]
    // 0x61ae88: DecompressPointer r2
    //     0x61ae88: add             x2, x2, HEAP, lsl #32
    // 0x61ae8c: r1 = Null
    //     0x61ae8c: mov             x1, NULL
    // 0x61ae90: r3 = <C3X0>
    //     0x61ae90: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e50] TypeArguments: <C3X0>
    //     0x61ae94: ldr             x3, [x3, #0xe50]
    // 0x61ae98: r0 = Null
    //     0x61ae98: mov             x0, NULL
    // 0x61ae9c: cmp             x2, x0
    // 0x61aea0: b.eq            #0x61aeb0
    // 0x61aea4: r30 = InstantiateTypeArgumentsStub
    //     0x61aea4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x61aea8: LoadField: r30 = r30->field_7
    //     0x61aea8: ldur            lr, [lr, #7]
    // 0x61aeac: blr             lr
    // 0x61aeb0: ldur            x1, [fp, #-8]
    // 0x61aeb4: stur            x0, [fp, #-0x18]
    // 0x61aeb8: LoadField: r2 = r1->field_b
    //     0x61aeb8: ldur            w2, [x1, #0xb]
    // 0x61aebc: DecompressPointer r2
    //     0x61aebc: add             x2, x2, HEAP, lsl #32
    // 0x61aec0: cmp             w2, NULL
    // 0x61aec4: b.eq            #0x61af0c
    // 0x61aec8: LoadField: r3 = r2->field_1b
    //     0x61aec8: ldur            w3, [x2, #0x1b]
    // 0x61aecc: DecompressPointer r3
    //     0x61aecc: add             x3, x3, HEAP, lsl #32
    // 0x61aed0: stur            x3, [fp, #-0x10]
    // 0x61aed4: r0 = currentLevelOrLastCompleted()
    //     0x61aed4: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61aed8: LoadField: r1 = r0->field_f
    //     0x61aed8: ldur            w1, [x0, #0xf]
    // 0x61aedc: DecompressPointer r1
    //     0x61aedc: add             x1, x1, HEAP, lsl #32
    // 0x61aee0: ldur            x16, [fp, #-0x18]
    // 0x61aee4: ldur            lr, [fp, #-0x10]
    // 0x61aee8: stp             lr, x16, [SP, #8]
    // 0x61aeec: str             x1, [SP]
    // 0x61aef0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x61aef0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x61aef4: r0 = MapOperations.isSupersetOfTuple()
    //     0x61aef4: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x61aef8: LeaveFrame
    //     0x61aef8: mov             SP, fp
    //     0x61aefc: ldp             fp, lr, [SP], #0x10
    // 0x61af00: ret
    //     0x61af00: ret             
    // 0x61af04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61af04: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61af08: b               #0x61ae84
    // 0x61af0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61af0c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ currentLevelOrLastCompleted(/* No info */) {
    // ** addr: 0x61af10, size: 0x274
    // 0x61af10: EnterFrame
    //     0x61af10: stp             fp, lr, [SP, #-0x10]!
    //     0x61af14: mov             fp, SP
    // 0x61af18: AllocStack(0x28)
    //     0x61af18: sub             SP, SP, #0x28
    // 0x61af1c: SetupParameters(QuestButtonState<C3X0> this /* r1 => r3, fp-0x10 */)
    //     0x61af1c: mov             x3, x1
    //     0x61af20: stur            x1, [fp, #-0x10]
    // 0x61af24: CheckStackOverflow
    //     0x61af24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61af28: cmp             SP, x16
    //     0x61af2c: b.ls            #0x61b160
    // 0x61af30: LoadField: r0 = r3->field_b
    //     0x61af30: ldur            w0, [x3, #0xb]
    // 0x61af34: DecompressPointer r0
    //     0x61af34: add             x0, x0, HEAP, lsl #32
    // 0x61af38: cmp             w0, NULL
    // 0x61af3c: b.eq            #0x61b168
    // 0x61af40: LoadField: r1 = r0->field_2b
    //     0x61af40: ldur            w1, [x0, #0x2b]
    // 0x61af44: DecompressPointer r1
    //     0x61af44: add             x1, x1, HEAP, lsl #32
    // 0x61af48: LoadField: r4 = r1->field_b
    //     0x61af48: ldur            w4, [x1, #0xb]
    // 0x61af4c: DecompressPointer r4
    //     0x61af4c: add             x4, x4, HEAP, lsl #32
    // 0x61af50: stur            x4, [fp, #-8]
    // 0x61af54: LoadField: r2 = r0->field_23
    //     0x61af54: ldur            x2, [x0, #0x23]
    // 0x61af58: r0 = BoxInt64Instr(r2)
    //     0x61af58: sbfiz           x0, x2, #1, #0x1f
    //     0x61af5c: cmp             x2, x0, asr #1
    //     0x61af60: b.eq            #0x61af6c
    //     0x61af64: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61af68: stur            x2, [x0, #7]
    // 0x61af6c: mov             x1, x4
    // 0x61af70: mov             x2, x0
    // 0x61af74: r0 = _getValueOrData()
    //     0x61af74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x61af78: mov             x1, x0
    // 0x61af7c: ldur            x0, [fp, #-8]
    // 0x61af80: LoadField: r2 = r0->field_f
    //     0x61af80: ldur            w2, [x0, #0xf]
    // 0x61af84: DecompressPointer r2
    //     0x61af84: add             x2, x2, HEAP, lsl #32
    // 0x61af88: cmp             w2, w1
    // 0x61af8c: b.ne            #0x61af98
    // 0x61af90: r0 = Null
    //     0x61af90: mov             x0, NULL
    // 0x61af94: b               #0x61af9c
    // 0x61af98: mov             x0, x1
    // 0x61af9c: cmp             w0, NULL
    // 0x61afa0: b.ne            #0x61afac
    // 0x61afa4: r2 = 0
    //     0x61afa4: movz            x2, #0
    // 0x61afa8: b               #0x61afbc
    // 0x61afac: r1 = LoadInt32Instr(r0)
    //     0x61afac: sbfx            x1, x0, #1, #0x1f
    //     0x61afb0: tbz             w0, #0, #0x61afb8
    //     0x61afb4: ldur            x1, [x0, #7]
    // 0x61afb8: mov             x2, x1
    // 0x61afbc: ldur            x1, [fp, #-0x10]
    // 0x61afc0: stur            x2, [fp, #-0x18]
    // 0x61afc4: LoadField: r0 = r1->field_b
    //     0x61afc4: ldur            w0, [x1, #0xb]
    // 0x61afc8: DecompressPointer r0
    //     0x61afc8: add             x0, x0, HEAP, lsl #32
    // 0x61afcc: cmp             w0, NULL
    // 0x61afd0: b.eq            #0x61b16c
    // 0x61afd4: LoadField: r3 = r0->field_37
    //     0x61afd4: ldur            w3, [x0, #0x37]
    // 0x61afd8: DecompressPointer r3
    //     0x61afd8: add             x3, x3, HEAP, lsl #32
    // 0x61afdc: r0 = LoadClassIdInstr(r3)
    //     0x61afdc: ldur            x0, [x3, #-1]
    //     0x61afe0: ubfx            x0, x0, #0xc, #0x14
    // 0x61afe4: str             x3, [SP]
    // 0x61afe8: r0 = GDT[cid_x0 + 0x79d0]()
    //     0x61afe8: movz            x17, #0x79d0
    //     0x61afec: add             lr, x0, x17
    //     0x61aff0: ldr             lr, [x21, lr, lsl #3]
    //     0x61aff4: blr             lr
    // 0x61aff8: r1 = LoadInt32Instr(r0)
    //     0x61aff8: sbfx            x1, x0, #1, #0x1f
    // 0x61affc: sub             x0, x1, #1
    // 0x61b000: ldur            x1, [fp, #-0x18]
    // 0x61b004: cmp             x1, x0
    // 0x61b008: csel            x2, x0, x1, gt
    // 0x61b00c: ldur            x3, [fp, #-0x10]
    // 0x61b010: LoadField: r0 = r3->field_b
    //     0x61b010: ldur            w0, [x3, #0xb]
    // 0x61b014: DecompressPointer r0
    //     0x61b014: add             x0, x0, HEAP, lsl #32
    // 0x61b018: cmp             w0, NULL
    // 0x61b01c: b.eq            #0x61b170
    // 0x61b020: LoadField: r4 = r0->field_37
    //     0x61b020: ldur            w4, [x0, #0x37]
    // 0x61b024: DecompressPointer r4
    //     0x61b024: add             x4, x4, HEAP, lsl #32
    // 0x61b028: r0 = BoxInt64Instr(r2)
    //     0x61b028: sbfiz           x0, x2, #1, #0x1f
    //     0x61b02c: cmp             x2, x0, asr #1
    //     0x61b030: b.eq            #0x61b03c
    //     0x61b034: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b038: stur            x2, [x0, #7]
    // 0x61b03c: mov             x1, x0
    // 0x61b040: stur            x1, [fp, #-8]
    // 0x61b044: r0 = LoadClassIdInstr(r4)
    //     0x61b044: ldur            x0, [x4, #-1]
    //     0x61b048: ubfx            x0, x0, #0xc, #0x14
    // 0x61b04c: stp             x1, x4, [SP]
    // 0x61b050: r0 = GDT[cid_x0 + -0xfff]()
    //     0x61b050: sub             lr, x0, #0xfff
    //     0x61b054: ldr             lr, [x21, lr, lsl #3]
    //     0x61b058: blr             lr
    // 0x61b05c: LoadField: r1 = r0->field_b
    //     0x61b05c: ldur            w1, [x0, #0xb]
    // 0x61b060: DecompressPointer r1
    //     0x61b060: add             x1, x1, HEAP, lsl #32
    // 0x61b064: cmp             w1, NULL
    // 0x61b068: b.eq            #0x61b0d4
    // 0x61b06c: ldur            x1, [fp, #-0x10]
    // 0x61b070: LoadField: r0 = r1->field_b
    //     0x61b070: ldur            w0, [x1, #0xb]
    // 0x61b074: DecompressPointer r0
    //     0x61b074: add             x0, x0, HEAP, lsl #32
    // 0x61b078: cmp             w0, NULL
    // 0x61b07c: b.eq            #0x61b174
    // 0x61b080: LoadField: r2 = r0->field_37
    //     0x61b080: ldur            w2, [x0, #0x37]
    // 0x61b084: DecompressPointer r2
    //     0x61b084: add             x2, x2, HEAP, lsl #32
    // 0x61b088: r0 = LoadClassIdInstr(r2)
    //     0x61b088: ldur            x0, [x2, #-1]
    //     0x61b08c: ubfx            x0, x0, #0xc, #0x14
    // 0x61b090: ldur            x16, [fp, #-8]
    // 0x61b094: stp             x16, x2, [SP]
    // 0x61b098: r0 = GDT[cid_x0 + -0xfff]()
    //     0x61b098: sub             lr, x0, #0xfff
    //     0x61b09c: ldr             lr, [x21, lr, lsl #3]
    //     0x61b0a0: blr             lr
    // 0x61b0a4: LoadField: r1 = r0->field_b
    //     0x61b0a4: ldur            w1, [x0, #0xb]
    // 0x61b0a8: DecompressPointer r1
    //     0x61b0a8: add             x1, x1, HEAP, lsl #32
    // 0x61b0ac: cmp             w1, NULL
    // 0x61b0b0: b.eq            #0x61b178
    // 0x61b0b4: str             x1, [SP]
    // 0x61b0b8: mov             x0, x1
    // 0x61b0bc: ClosureCall
    //     0x61b0bc: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61b0c0: ldur            x2, [x0, #0x1f]
    //     0x61b0c4: blr             x2
    // 0x61b0c8: r16 = true
    //     0x61b0c8: add             x16, NULL, #0x20  ; true
    // 0x61b0cc: cmp             w0, w16
    // 0x61b0d0: b.ne            #0x61b11c
    // 0x61b0d4: ldur            x0, [fp, #-0x10]
    // 0x61b0d8: LoadField: r1 = r0->field_b
    //     0x61b0d8: ldur            w1, [x0, #0xb]
    // 0x61b0dc: DecompressPointer r1
    //     0x61b0dc: add             x1, x1, HEAP, lsl #32
    // 0x61b0e0: cmp             w1, NULL
    // 0x61b0e4: b.eq            #0x61b17c
    // 0x61b0e8: LoadField: r0 = r1->field_37
    //     0x61b0e8: ldur            w0, [x1, #0x37]
    // 0x61b0ec: DecompressPointer r0
    //     0x61b0ec: add             x0, x0, HEAP, lsl #32
    // 0x61b0f0: r1 = LoadClassIdInstr(r0)
    //     0x61b0f0: ldur            x1, [x0, #-1]
    //     0x61b0f4: ubfx            x1, x1, #0xc, #0x14
    // 0x61b0f8: ldur            x16, [fp, #-8]
    // 0x61b0fc: stp             x16, x0, [SP]
    // 0x61b100: mov             x0, x1
    // 0x61b104: r0 = GDT[cid_x0 + -0xfff]()
    //     0x61b104: sub             lr, x0, #0xfff
    //     0x61b108: ldr             lr, [x21, lr, lsl #3]
    //     0x61b10c: blr             lr
    // 0x61b110: LeaveFrame
    //     0x61b110: mov             SP, fp
    //     0x61b114: ldp             fp, lr, [SP], #0x10
    // 0x61b118: ret
    //     0x61b118: ret             
    // 0x61b11c: ldur            x0, [fp, #-0x10]
    // 0x61b120: LoadField: r1 = r0->field_b
    //     0x61b120: ldur            w1, [x0, #0xb]
    // 0x61b124: DecompressPointer r1
    //     0x61b124: add             x1, x1, HEAP, lsl #32
    // 0x61b128: cmp             w1, NULL
    // 0x61b12c: b.eq            #0x61b180
    // 0x61b130: LoadField: r0 = r1->field_37
    //     0x61b130: ldur            w0, [x1, #0x37]
    // 0x61b134: DecompressPointer r0
    //     0x61b134: add             x0, x0, HEAP, lsl #32
    // 0x61b138: r1 = LoadClassIdInstr(r0)
    //     0x61b138: ldur            x1, [x0, #-1]
    //     0x61b13c: ubfx            x1, x1, #0xc, #0x14
    // 0x61b140: stp             xzr, x0, [SP]
    // 0x61b144: mov             x0, x1
    // 0x61b148: r0 = GDT[cid_x0 + -0xfff]()
    //     0x61b148: sub             lr, x0, #0xfff
    //     0x61b14c: ldr             lr, [x21, lr, lsl #3]
    //     0x61b150: blr             lr
    // 0x61b154: LeaveFrame
    //     0x61b154: mov             SP, fp
    //     0x61b158: ldp             fp, lr, [SP], #0x10
    // 0x61b15c: ret
    //     0x61b15c: ret             
    // 0x61b160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61b160: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61b164: b               #0x61af30
    // 0x61b168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b168: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b16c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b16c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b170: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b174: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b174: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b178: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b17c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b17c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b180: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ hasNextQuest(/* No info */) {
    // ** addr: 0x61b184, size: 0x1fc
    // 0x61b184: EnterFrame
    //     0x61b184: stp             fp, lr, [SP, #-0x10]!
    //     0x61b188: mov             fp, SP
    // 0x61b18c: AllocStack(0x28)
    //     0x61b18c: sub             SP, SP, #0x28
    // 0x61b190: SetupParameters(QuestButtonState<C3X0> this /* r1 => r3, fp-0x10 */)
    //     0x61b190: mov             x3, x1
    //     0x61b194: stur            x1, [fp, #-0x10]
    // 0x61b198: CheckStackOverflow
    //     0x61b198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61b19c: cmp             SP, x16
    //     0x61b1a0: b.ls            #0x61b364
    // 0x61b1a4: LoadField: r0 = r3->field_b
    //     0x61b1a4: ldur            w0, [x3, #0xb]
    // 0x61b1a8: DecompressPointer r0
    //     0x61b1a8: add             x0, x0, HEAP, lsl #32
    // 0x61b1ac: cmp             w0, NULL
    // 0x61b1b0: b.eq            #0x61b36c
    // 0x61b1b4: LoadField: r1 = r0->field_2b
    //     0x61b1b4: ldur            w1, [x0, #0x2b]
    // 0x61b1b8: DecompressPointer r1
    //     0x61b1b8: add             x1, x1, HEAP, lsl #32
    // 0x61b1bc: LoadField: r4 = r1->field_b
    //     0x61b1bc: ldur            w4, [x1, #0xb]
    // 0x61b1c0: DecompressPointer r4
    //     0x61b1c0: add             x4, x4, HEAP, lsl #32
    // 0x61b1c4: stur            x4, [fp, #-8]
    // 0x61b1c8: LoadField: r2 = r0->field_23
    //     0x61b1c8: ldur            x2, [x0, #0x23]
    // 0x61b1cc: r0 = BoxInt64Instr(r2)
    //     0x61b1cc: sbfiz           x0, x2, #1, #0x1f
    //     0x61b1d0: cmp             x2, x0, asr #1
    //     0x61b1d4: b.eq            #0x61b1e0
    //     0x61b1d8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b1dc: stur            x2, [x0, #7]
    // 0x61b1e0: mov             x1, x4
    // 0x61b1e4: mov             x2, x0
    // 0x61b1e8: r0 = _getValueOrData()
    //     0x61b1e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x61b1ec: mov             x1, x0
    // 0x61b1f0: ldur            x0, [fp, #-8]
    // 0x61b1f4: LoadField: r2 = r0->field_f
    //     0x61b1f4: ldur            w2, [x0, #0xf]
    // 0x61b1f8: DecompressPointer r2
    //     0x61b1f8: add             x2, x2, HEAP, lsl #32
    // 0x61b1fc: cmp             w2, w1
    // 0x61b200: b.ne            #0x61b20c
    // 0x61b204: r0 = Null
    //     0x61b204: mov             x0, NULL
    // 0x61b208: b               #0x61b210
    // 0x61b20c: mov             x0, x1
    // 0x61b210: cmp             w0, NULL
    // 0x61b214: b.ne            #0x61b220
    // 0x61b218: r2 = 0
    //     0x61b218: movz            x2, #0
    // 0x61b21c: b               #0x61b230
    // 0x61b220: r1 = LoadInt32Instr(r0)
    //     0x61b220: sbfx            x1, x0, #1, #0x1f
    //     0x61b224: tbz             w0, #0, #0x61b22c
    //     0x61b228: ldur            x1, [x0, #7]
    // 0x61b22c: mov             x2, x1
    // 0x61b230: ldur            x1, [fp, #-0x10]
    // 0x61b234: stur            x2, [fp, #-0x18]
    // 0x61b238: LoadField: r0 = r1->field_b
    //     0x61b238: ldur            w0, [x1, #0xb]
    // 0x61b23c: DecompressPointer r0
    //     0x61b23c: add             x0, x0, HEAP, lsl #32
    // 0x61b240: cmp             w0, NULL
    // 0x61b244: b.eq            #0x61b370
    // 0x61b248: LoadField: r3 = r0->field_37
    //     0x61b248: ldur            w3, [x0, #0x37]
    // 0x61b24c: DecompressPointer r3
    //     0x61b24c: add             x3, x3, HEAP, lsl #32
    // 0x61b250: r0 = LoadClassIdInstr(r3)
    //     0x61b250: ldur            x0, [x3, #-1]
    //     0x61b254: ubfx            x0, x0, #0xc, #0x14
    // 0x61b258: str             x3, [SP]
    // 0x61b25c: r0 = GDT[cid_x0 + 0x79d0]()
    //     0x61b25c: movz            x17, #0x79d0
    //     0x61b260: add             lr, x0, x17
    //     0x61b264: ldr             lr, [x21, lr, lsl #3]
    //     0x61b268: blr             lr
    // 0x61b26c: mov             x3, x0
    // 0x61b270: ldur            x2, [fp, #-0x18]
    // 0x61b274: r0 = BoxInt64Instr(r2)
    //     0x61b274: sbfiz           x0, x2, #1, #0x1f
    //     0x61b278: cmp             x2, x0, asr #1
    //     0x61b27c: b.eq            #0x61b288
    //     0x61b280: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b284: stur            x2, [x0, #7]
    // 0x61b288: mov             x1, x0
    // 0x61b28c: stur            x1, [fp, #-8]
    // 0x61b290: r0 = LoadInt32Instr(r3)
    //     0x61b290: sbfx            x0, x3, #1, #0x1f
    // 0x61b294: cmp             x2, x0
    // 0x61b298: b.lt            #0x61b2ac
    // 0x61b29c: r0 = false
    //     0x61b29c: add             x0, NULL, #0x30  ; false
    // 0x61b2a0: LeaveFrame
    //     0x61b2a0: mov             SP, fp
    //     0x61b2a4: ldp             fp, lr, [SP], #0x10
    // 0x61b2a8: ret
    //     0x61b2a8: ret             
    // 0x61b2ac: ldur            x2, [fp, #-0x10]
    // 0x61b2b0: LoadField: r0 = r2->field_b
    //     0x61b2b0: ldur            w0, [x2, #0xb]
    // 0x61b2b4: DecompressPointer r0
    //     0x61b2b4: add             x0, x0, HEAP, lsl #32
    // 0x61b2b8: cmp             w0, NULL
    // 0x61b2bc: b.eq            #0x61b374
    // 0x61b2c0: LoadField: r3 = r0->field_37
    //     0x61b2c0: ldur            w3, [x0, #0x37]
    // 0x61b2c4: DecompressPointer r3
    //     0x61b2c4: add             x3, x3, HEAP, lsl #32
    // 0x61b2c8: r0 = LoadClassIdInstr(r3)
    //     0x61b2c8: ldur            x0, [x3, #-1]
    //     0x61b2cc: ubfx            x0, x0, #0xc, #0x14
    // 0x61b2d0: stp             x1, x3, [SP]
    // 0x61b2d4: r0 = GDT[cid_x0 + -0xfff]()
    //     0x61b2d4: sub             lr, x0, #0xfff
    //     0x61b2d8: ldr             lr, [x21, lr, lsl #3]
    //     0x61b2dc: blr             lr
    // 0x61b2e0: LoadField: r1 = r0->field_b
    //     0x61b2e0: ldur            w1, [x0, #0xb]
    // 0x61b2e4: DecompressPointer r1
    //     0x61b2e4: add             x1, x1, HEAP, lsl #32
    // 0x61b2e8: cmp             w1, NULL
    // 0x61b2ec: b.ne            #0x61b2f8
    // 0x61b2f0: r0 = true
    //     0x61b2f0: add             x0, NULL, #0x20  ; true
    // 0x61b2f4: b               #0x61b358
    // 0x61b2f8: ldur            x0, [fp, #-0x10]
    // 0x61b2fc: LoadField: r1 = r0->field_b
    //     0x61b2fc: ldur            w1, [x0, #0xb]
    // 0x61b300: DecompressPointer r1
    //     0x61b300: add             x1, x1, HEAP, lsl #32
    // 0x61b304: cmp             w1, NULL
    // 0x61b308: b.eq            #0x61b378
    // 0x61b30c: LoadField: r0 = r1->field_37
    //     0x61b30c: ldur            w0, [x1, #0x37]
    // 0x61b310: DecompressPointer r0
    //     0x61b310: add             x0, x0, HEAP, lsl #32
    // 0x61b314: r1 = LoadClassIdInstr(r0)
    //     0x61b314: ldur            x1, [x0, #-1]
    //     0x61b318: ubfx            x1, x1, #0xc, #0x14
    // 0x61b31c: ldur            x16, [fp, #-8]
    // 0x61b320: stp             x16, x0, [SP]
    // 0x61b324: mov             x0, x1
    // 0x61b328: r0 = GDT[cid_x0 + -0xfff]()
    //     0x61b328: sub             lr, x0, #0xfff
    //     0x61b32c: ldr             lr, [x21, lr, lsl #3]
    //     0x61b330: blr             lr
    // 0x61b334: LoadField: r1 = r0->field_b
    //     0x61b334: ldur            w1, [x0, #0xb]
    // 0x61b338: DecompressPointer r1
    //     0x61b338: add             x1, x1, HEAP, lsl #32
    // 0x61b33c: cmp             w1, NULL
    // 0x61b340: b.eq            #0x61b37c
    // 0x61b344: str             x1, [SP]
    // 0x61b348: mov             x0, x1
    // 0x61b34c: ClosureCall
    //     0x61b34c: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61b350: ldur            x2, [x0, #0x1f]
    //     0x61b354: blr             x2
    // 0x61b358: LeaveFrame
    //     0x61b358: mov             SP, fp
    //     0x61b35c: ldp             fp, lr, [SP], #0x10
    // 0x61b360: ret
    //     0x61b360: ret             
    // 0x61b364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61b364: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61b368: b               #0x61b1a4
    // 0x61b36c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b36c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b370: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b370: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b374: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b374: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b378: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b378: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b37c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b37c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x61b380, size: 0x464
    // 0x61b380: EnterFrame
    //     0x61b380: stp             fp, lr, [SP, #-0x10]!
    //     0x61b384: mov             fp, SP
    // 0x61b388: AllocStack(0x40)
    //     0x61b388: sub             SP, SP, #0x40
    // 0x61b38c: SetupParameters(QuestButtonState<C3X0> this /* r1 */)
    //     0x61b38c: stur            NULL, [fp, #-8]
    //     0x61b390: movz            x0, #0
    //     0x61b394: add             x1, fp, w0, sxtw #2
    //     0x61b398: ldr             x1, [x1, #0x10]
    //     0x61b39c: ldur            w2, [x1, #0x17]
    //     0x61b3a0: add             x2, x2, HEAP, lsl #32
    //     0x61b3a4: stur            x2, [fp, #-0x10]
    // 0x61b3a8: CheckStackOverflow
    //     0x61b3a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61b3ac: cmp             SP, x16
    //     0x61b3b0: b.ls            #0x61b7b8
    // 0x61b3b4: InitAsync() -> Future<void?>
    //     0x61b3b4: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x61b3b8: bl              #0x34b9a0  ; InitAsyncStub
    // 0x61b3bc: r1 = 1
    //     0x61b3bc: movz            x1, #0x1
    // 0x61b3c0: r0 = AllocateContext()
    //     0x61b3c0: bl              #0x82637c  ; AllocateContextStub
    // 0x61b3c4: mov             x2, x0
    // 0x61b3c8: ldur            x0, [fp, #-0x10]
    // 0x61b3cc: stur            x2, [fp, #-0x18]
    // 0x61b3d0: StoreField: r2->field_b = r0
    //     0x61b3d0: stur            w0, [x2, #0xb]
    // 0x61b3d4: LoadField: r1 = r0->field_f
    //     0x61b3d4: ldur            w1, [x0, #0xf]
    // 0x61b3d8: DecompressPointer r1
    //     0x61b3d8: add             x1, x1, HEAP, lsl #32
    // 0x61b3dc: r0 = getState()
    //     0x61b3dc: bl              #0x61ad7c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getState
    // 0x61b3e0: mov             x1, x0
    // 0x61b3e4: ldur            x2, [fp, #-0x18]
    // 0x61b3e8: StoreField: r2->field_f = r0
    //     0x61b3e8: stur            w0, [x2, #0xf]
    //     0x61b3ec: ldurb           w16, [x2, #-1]
    //     0x61b3f0: ldurb           w17, [x0, #-1]
    //     0x61b3f4: and             x16, x17, x16, lsr #2
    //     0x61b3f8: tst             x16, HEAP, lsr #32
    //     0x61b3fc: b.eq            #0x61b404
    //     0x61b400: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x61b404: r16 = Instance_QuestState
    //     0x61b404: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c240] Obj!QuestState@85e9a1
    //     0x61b408: ldr             x16, [x16, #0x240]
    // 0x61b40c: cmp             w1, w16
    // 0x61b410: b.ne            #0x61b6e0
    // 0x61b414: ldur            x0, [fp, #-0x10]
    // 0x61b418: LoadField: r1 = r0->field_f
    //     0x61b418: ldur            w1, [x0, #0xf]
    // 0x61b41c: DecompressPointer r1
    //     0x61b41c: add             x1, x1, HEAP, lsl #32
    // 0x61b420: r0 = remainingTime()
    //     0x61b420: bl              #0x61ab1c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::remainingTime
    // 0x61b424: cmp             w0, NULL
    // 0x61b428: b.eq            #0x61b458
    // 0x61b42c: LoadField: r1 = r0->field_7
    //     0x61b42c: ldur            x1, [x0, #7]
    // 0x61b430: tbz             x1, #0x3f, #0x61b450
    // 0x61b434: ldur            x1, [fp, #-0x10]
    // 0x61b438: LoadField: r0 = r1->field_f
    //     0x61b438: ldur            w0, [x1, #0xf]
    // 0x61b43c: DecompressPointer r0
    //     0x61b43c: add             x0, x0, HEAP, lsl #32
    // 0x61b440: mov             x1, x0
    // 0x61b444: r0 = endQuest()
    //     0x61b444: bl              #0x61b878  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::endQuest
    // 0x61b448: r0 = Null
    //     0x61b448: mov             x0, NULL
    // 0x61b44c: r0 = ReturnAsyncNotFuture()
    //     0x61b44c: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x61b450: ldur            x1, [fp, #-0x10]
    // 0x61b454: b               #0x61b45c
    // 0x61b458: ldur            x1, [fp, #-0x10]
    // 0x61b45c: LoadField: r0 = r1->field_f
    //     0x61b45c: ldur            w0, [x1, #0xf]
    // 0x61b460: DecompressPointer r0
    //     0x61b460: add             x0, x0, HEAP, lsl #32
    // 0x61b464: LoadField: r2 = r0->field_b
    //     0x61b464: ldur            w2, [x0, #0xb]
    // 0x61b468: DecompressPointer r2
    //     0x61b468: add             x2, x2, HEAP, lsl #32
    // 0x61b46c: cmp             w2, NULL
    // 0x61b470: b.eq            #0x61b7c0
    // 0x61b474: LoadField: r0 = r2->field_33
    //     0x61b474: ldur            w0, [x2, #0x33]
    // 0x61b478: DecompressPointer r0
    //     0x61b478: add             x0, x0, HEAP, lsl #32
    // 0x61b47c: cmp             w0, NULL
    // 0x61b480: b.eq            #0x61b4a4
    // 0x61b484: LoadField: r0 = r2->field_33
    //     0x61b484: ldur            w0, [x2, #0x33]
    // 0x61b488: DecompressPointer r0
    //     0x61b488: add             x0, x0, HEAP, lsl #32
    // 0x61b48c: cmp             w0, NULL
    // 0x61b490: b.eq            #0x61b7c4
    // 0x61b494: str             x0, [SP]
    // 0x61b498: ClosureCall
    //     0x61b498: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61b49c: ldur            x2, [x0, #0x1f]
    //     0x61b4a0: blr             x2
    // 0x61b4a4: ldur            x0, [fp, #-0x10]
    // 0x61b4a8: LoadField: r1 = r0->field_13
    //     0x61b4a8: ldur            w1, [x0, #0x13]
    // 0x61b4ac: DecompressPointer r1
    //     0x61b4ac: add             x1, x1, HEAP, lsl #32
    // 0x61b4b0: r0 = of()
    //     0x61b4b0: bl              #0x5a6984  ; [package:pretentious/pages/MainPage.dart] CurrentChapter::of
    // 0x61b4b4: mov             x1, x0
    // 0x61b4b8: ldur            x0, [fp, #-0x10]
    // 0x61b4bc: LoadField: r2 = r0->field_f
    //     0x61b4bc: ldur            w2, [x0, #0xf]
    // 0x61b4c0: DecompressPointer r2
    //     0x61b4c0: add             x2, x2, HEAP, lsl #32
    // 0x61b4c4: LoadField: r3 = r2->field_b
    //     0x61b4c4: ldur            w3, [x2, #0xb]
    // 0x61b4c8: DecompressPointer r3
    //     0x61b4c8: add             x3, x3, HEAP, lsl #32
    // 0x61b4cc: cmp             w3, NULL
    // 0x61b4d0: b.eq            #0x61b7c8
    // 0x61b4d4: LoadField: r2 = r3->field_23
    //     0x61b4d4: ldur            x2, [x3, #0x23]
    // 0x61b4d8: r0 = notifyQuest()
    //     0x61b4d8: bl              #0x61b7e4  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyQuest
    // 0x61b4dc: r0 = LoadStaticField(0x1040)
    //     0x61b4dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x61b4e0: ldr             x0, [x0, #0x2080]
    // 0x61b4e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x61b4e8: cmp             w0, w16
    // 0x61b4ec: b.ne            #0x61b4fc
    // 0x61b4f0: r2 = fragments
    //     0x61b4f0: add             x2, PP, #0x10, lsl #12  ; [pp+0x100b8] Field <::.fragments>: static late (offset: 0x1040)
    //     0x61b4f4: ldr             x2, [x2, #0xb8]
    // 0x61b4f8: r0 = InitLateStaticField()
    //     0x61b4f8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x61b4fc: mov             x1, x0
    // 0x61b500: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61b500: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61b504: r0 = notifyAll()
    //     0x61b504: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x61b508: ldur            x3, [fp, #-0x10]
    // 0x61b50c: LoadField: r0 = r3->field_f
    //     0x61b50c: ldur            w0, [x3, #0xf]
    // 0x61b510: DecompressPointer r0
    //     0x61b510: add             x0, x0, HEAP, lsl #32
    // 0x61b514: LoadField: r1 = r0->field_b
    //     0x61b514: ldur            w1, [x0, #0xb]
    // 0x61b518: DecompressPointer r1
    //     0x61b518: add             x1, x1, HEAP, lsl #32
    // 0x61b51c: cmp             w1, NULL
    // 0x61b520: b.eq            #0x61b7cc
    // 0x61b524: LoadField: r0 = r1->field_2b
    //     0x61b524: ldur            w0, [x1, #0x2b]
    // 0x61b528: DecompressPointer r0
    //     0x61b528: add             x0, x0, HEAP, lsl #32
    // 0x61b52c: LoadField: r4 = r0->field_b
    //     0x61b52c: ldur            w4, [x0, #0xb]
    // 0x61b530: DecompressPointer r4
    //     0x61b530: add             x4, x4, HEAP, lsl #32
    // 0x61b534: stur            x4, [fp, #-0x20]
    // 0x61b538: LoadField: r2 = r1->field_23
    //     0x61b538: ldur            x2, [x1, #0x23]
    // 0x61b53c: r0 = BoxInt64Instr(r2)
    //     0x61b53c: sbfiz           x0, x2, #1, #0x1f
    //     0x61b540: cmp             x2, x0, asr #1
    //     0x61b544: b.eq            #0x61b550
    //     0x61b548: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b54c: stur            x2, [x0, #7]
    // 0x61b550: mov             x1, x4
    // 0x61b554: mov             x2, x0
    // 0x61b558: r0 = _getValueOrData()
    //     0x61b558: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x61b55c: mov             x1, x0
    // 0x61b560: ldur            x0, [fp, #-0x20]
    // 0x61b564: LoadField: r2 = r0->field_f
    //     0x61b564: ldur            w2, [x0, #0xf]
    // 0x61b568: DecompressPointer r2
    //     0x61b568: add             x2, x2, HEAP, lsl #32
    // 0x61b56c: cmp             w2, w1
    // 0x61b570: b.ne            #0x61b578
    // 0x61b574: r1 = Null
    //     0x61b574: mov             x1, NULL
    // 0x61b578: stur            x1, [fp, #-0x20]
    // 0x61b57c: cmp             w1, NULL
    // 0x61b580: b.eq            #0x61b630
    // 0x61b584: ldur            x2, [fp, #-0x10]
    // 0x61b588: LoadField: r0 = r2->field_f
    //     0x61b588: ldur            w0, [x2, #0xf]
    // 0x61b58c: DecompressPointer r0
    //     0x61b58c: add             x0, x0, HEAP, lsl #32
    // 0x61b590: LoadField: r3 = r0->field_b
    //     0x61b590: ldur            w3, [x0, #0xb]
    // 0x61b594: DecompressPointer r3
    //     0x61b594: add             x3, x3, HEAP, lsl #32
    // 0x61b598: cmp             w3, NULL
    // 0x61b59c: b.eq            #0x61b7d0
    // 0x61b5a0: LoadField: r0 = r3->field_37
    //     0x61b5a0: ldur            w0, [x3, #0x37]
    // 0x61b5a4: DecompressPointer r0
    //     0x61b5a4: add             x0, x0, HEAP, lsl #32
    // 0x61b5a8: r3 = LoadClassIdInstr(r0)
    //     0x61b5a8: ldur            x3, [x0, #-1]
    //     0x61b5ac: ubfx            x3, x3, #0xc, #0x14
    // 0x61b5b0: str             x0, [SP]
    // 0x61b5b4: mov             x0, x3
    // 0x61b5b8: r0 = GDT[cid_x0 + 0x79d0]()
    //     0x61b5b8: movz            x17, #0x79d0
    //     0x61b5bc: add             lr, x0, x17
    //     0x61b5c0: ldr             lr, [x21, lr, lsl #3]
    //     0x61b5c4: blr             lr
    // 0x61b5c8: mov             x1, x0
    // 0x61b5cc: ldur            x0, [fp, #-0x20]
    // 0x61b5d0: r2 = LoadInt32Instr(r0)
    //     0x61b5d0: sbfx            x2, x0, #1, #0x1f
    //     0x61b5d4: tbz             w0, #0, #0x61b5dc
    //     0x61b5d8: ldur            x2, [x0, #7]
    // 0x61b5dc: r3 = LoadInt32Instr(r1)
    //     0x61b5dc: sbfx            x3, x1, #1, #0x1f
    // 0x61b5e0: cmp             x2, x3
    // 0x61b5e4: b.le            #0x61b62c
    // 0x61b5e8: r1 = Null
    //     0x61b5e8: mov             x1, NULL
    // 0x61b5ec: r2 = 4
    //     0x61b5ec: movz            x2, #0x4
    // 0x61b5f0: r0 = AllocateArray()
    //     0x61b5f0: bl              #0x82746c  ; AllocateArrayStub
    // 0x61b5f4: r16 = "Quest already completed! Current level: "
    //     0x61b5f4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c248] "Quest already completed! Current level: "
    //     0x61b5f8: ldr             x16, [x16, #0x248]
    // 0x61b5fc: StoreField: r0->field_f = r16
    //     0x61b5fc: stur            w16, [x0, #0xf]
    // 0x61b600: ldur            x1, [fp, #-0x20]
    // 0x61b604: StoreField: r0->field_13 = r1
    //     0x61b604: stur            w1, [x0, #0x13]
    // 0x61b608: str             x0, [SP]
    // 0x61b60c: r0 = _interpolate()
    //     0x61b60c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61b610: stur            x0, [fp, #-0x28]
    // 0x61b614: r0 = current()
    //     0x61b614: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x61b618: ldur            x1, [fp, #-0x28]
    // 0x61b61c: mov             x2, x0
    // 0x61b620: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x61b620: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x61b624: r0 = crashlyticsRecordError()
    //     0x61b624: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x61b628: b               #0x61b6bc
    // 0x61b62c: mov             x1, x0
    // 0x61b630: ldur            x4, [fp, #-0x10]
    // 0x61b634: LoadField: r0 = r4->field_f
    //     0x61b634: ldur            w0, [x4, #0xf]
    // 0x61b638: DecompressPointer r0
    //     0x61b638: add             x0, x0, HEAP, lsl #32
    // 0x61b63c: LoadField: r2 = r0->field_b
    //     0x61b63c: ldur            w2, [x0, #0xb]
    // 0x61b640: DecompressPointer r2
    //     0x61b640: add             x2, x2, HEAP, lsl #32
    // 0x61b644: cmp             w2, NULL
    // 0x61b648: b.eq            #0x61b7d4
    // 0x61b64c: LoadField: r0 = r2->field_2b
    //     0x61b64c: ldur            w0, [x2, #0x2b]
    // 0x61b650: DecompressPointer r0
    //     0x61b650: add             x0, x0, HEAP, lsl #32
    // 0x61b654: LoadField: r3 = r0->field_b
    //     0x61b654: ldur            w3, [x0, #0xb]
    // 0x61b658: DecompressPointer r3
    //     0x61b658: add             x3, x3, HEAP, lsl #32
    // 0x61b65c: LoadField: r5 = r2->field_23
    //     0x61b65c: ldur            x5, [x2, #0x23]
    // 0x61b660: cmp             w1, NULL
    // 0x61b664: b.ne            #0x61b670
    // 0x61b668: r0 = 0
    //     0x61b668: movz            x0, #0
    // 0x61b66c: b               #0x61b67c
    // 0x61b670: r0 = LoadInt32Instr(r1)
    //     0x61b670: sbfx            x0, x1, #1, #0x1f
    //     0x61b674: tbz             w1, #0, #0x61b67c
    //     0x61b678: ldur            x0, [x1, #7]
    // 0x61b67c: add             x2, x0, #1
    // 0x61b680: r0 = BoxInt64Instr(r5)
    //     0x61b680: sbfiz           x0, x5, #1, #0x1f
    //     0x61b684: cmp             x5, x0, asr #1
    //     0x61b688: b.eq            #0x61b694
    //     0x61b68c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b690: stur            x5, [x0, #7]
    // 0x61b694: mov             x5, x0
    // 0x61b698: r0 = BoxInt64Instr(r2)
    //     0x61b698: sbfiz           x0, x2, #1, #0x1f
    //     0x61b69c: cmp             x2, x0, asr #1
    //     0x61b6a0: b.eq            #0x61b6ac
    //     0x61b6a4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b6a8: stur            x2, [x0, #7]
    // 0x61b6ac: mov             x1, x3
    // 0x61b6b0: mov             x2, x5
    // 0x61b6b4: mov             x3, x0
    // 0x61b6b8: r0 = []=()
    //     0x61b6b8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x61b6bc: ldur            x3, [fp, #-0x10]
    // 0x61b6c0: LoadField: r1 = r3->field_f
    //     0x61b6c0: ldur            w1, [x3, #0xf]
    // 0x61b6c4: DecompressPointer r1
    //     0x61b6c4: add             x1, x1, HEAP, lsl #32
    // 0x61b6c8: r0 = endQuest()
    //     0x61b6c8: bl              #0x61b878  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::endQuest
    // 0x61b6cc: r0 = currentActiveState()
    //     0x61b6cc: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x61b6d0: mov             x1, x0
    // 0x61b6d4: r0 = saveDeferred()
    //     0x61b6d4: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x61b6d8: r0 = Null
    //     0x61b6d8: mov             x0, NULL
    // 0x61b6dc: r0 = ReturnAsyncNotFuture()
    //     0x61b6dc: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x61b6e0: ldur            x3, [fp, #-0x10]
    // 0x61b6e4: r16 = Instance_QuestState
    //     0x61b6e4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c250] Obj!QuestState@85e9e1
    //     0x61b6e8: ldr             x16, [x16, #0x250]
    // 0x61b6ec: cmp             w1, w16
    // 0x61b6f0: b.ne            #0x61b77c
    // 0x61b6f4: LoadField: r0 = r3->field_f
    //     0x61b6f4: ldur            w0, [x3, #0xf]
    // 0x61b6f8: DecompressPointer r0
    //     0x61b6f8: add             x0, x0, HEAP, lsl #32
    // 0x61b6fc: LoadField: r1 = r0->field_b
    //     0x61b6fc: ldur            w1, [x0, #0xb]
    // 0x61b700: DecompressPointer r1
    //     0x61b700: add             x1, x1, HEAP, lsl #32
    // 0x61b704: cmp             w1, NULL
    // 0x61b708: b.eq            #0x61b7d8
    // 0x61b70c: LoadField: r0 = r1->field_33
    //     0x61b70c: ldur            w0, [x1, #0x33]
    // 0x61b710: DecompressPointer r0
    //     0x61b710: add             x0, x0, HEAP, lsl #32
    // 0x61b714: cmp             w0, NULL
    // 0x61b718: b.eq            #0x61b73c
    // 0x61b71c: LoadField: r0 = r1->field_33
    //     0x61b71c: ldur            w0, [x1, #0x33]
    // 0x61b720: DecompressPointer r0
    //     0x61b720: add             x0, x0, HEAP, lsl #32
    // 0x61b724: cmp             w0, NULL
    // 0x61b728: b.eq            #0x61b7dc
    // 0x61b72c: str             x0, [SP]
    // 0x61b730: ClosureCall
    //     0x61b730: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61b734: ldur            x2, [x0, #0x1f]
    //     0x61b738: blr             x2
    // 0x61b73c: ldur            x0, [fp, #-0x10]
    // 0x61b740: LoadField: r1 = r0->field_13
    //     0x61b740: ldur            w1, [x0, #0x13]
    // 0x61b744: DecompressPointer r1
    //     0x61b744: add             x1, x1, HEAP, lsl #32
    // 0x61b748: r0 = of()
    //     0x61b748: bl              #0x5a6984  ; [package:pretentious/pages/MainPage.dart] CurrentChapter::of
    // 0x61b74c: mov             x1, x0
    // 0x61b750: ldur            x0, [fp, #-0x10]
    // 0x61b754: LoadField: r2 = r0->field_f
    //     0x61b754: ldur            w2, [x0, #0xf]
    // 0x61b758: DecompressPointer r2
    //     0x61b758: add             x2, x2, HEAP, lsl #32
    // 0x61b75c: LoadField: r0 = r2->field_b
    //     0x61b75c: ldur            w0, [x2, #0xb]
    // 0x61b760: DecompressPointer r0
    //     0x61b760: add             x0, x0, HEAP, lsl #32
    // 0x61b764: cmp             w0, NULL
    // 0x61b768: b.eq            #0x61b7e0
    // 0x61b76c: LoadField: r2 = r0->field_23
    //     0x61b76c: ldur            x2, [x0, #0x23]
    // 0x61b770: r0 = notifyQuest()
    //     0x61b770: bl              #0x61b7e4  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::notifyQuest
    // 0x61b774: r0 = Null
    //     0x61b774: mov             x0, NULL
    // 0x61b778: r0 = ReturnAsyncNotFuture()
    //     0x61b778: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x61b77c: mov             x0, x3
    // 0x61b780: LoadField: r3 = r0->field_13
    //     0x61b780: ldur            w3, [x0, #0x13]
    // 0x61b784: DecompressPointer r3
    //     0x61b784: add             x3, x3, HEAP, lsl #32
    // 0x61b788: stur            x3, [fp, #-0x20]
    // 0x61b78c: r1 = Function '<anonymous closure>':.
    //     0x61b78c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c258] AnonymousClosure: (0x61b9c4), in [package:pretentious/widgets/QuestButton.dart] QuestButtonState::build (0x61a6d0)
    //     0x61b790: ldr             x1, [x1, #0x258]
    // 0x61b794: r0 = AllocateClosure()
    //     0x61b794: bl              #0x826750  ; AllocateClosureStub
    // 0x61b798: r16 = <void?>
    //     0x61b798: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x61b79c: stp             x0, x16, [SP, #8]
    // 0x61b7a0: ldur            x16, [fp, #-0x20]
    // 0x61b7a4: str             x16, [SP]
    // 0x61b7a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x61b7a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x61b7ac: r0 = showDialog()
    //     0x61b7ac: bl              #0x3ecee0  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x61b7b0: r0 = Null
    //     0x61b7b0: mov             x0, NULL
    // 0x61b7b4: r0 = ReturnAsyncNotFuture()
    //     0x61b7b4: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x61b7b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61b7b8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61b7bc: b               #0x61b3b4
    // 0x61b7c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7c0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7c4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7c8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7cc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7d0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7d4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7d8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7dc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b7e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b7e0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ endQuest(/* No info */) {
    // ** addr: 0x61b878, size: 0x14c
    // 0x61b878: EnterFrame
    //     0x61b878: stp             fp, lr, [SP, #-0x10]!
    //     0x61b87c: mov             fp, SP
    // 0x61b880: AllocStack(0x20)
    //     0x61b880: sub             SP, SP, #0x20
    // 0x61b884: SetupParameters(QuestButtonState<C3X0> this /* r1 => r3, fp-0x18 */)
    //     0x61b884: mov             x3, x1
    //     0x61b888: stur            x1, [fp, #-0x18]
    // 0x61b88c: CheckStackOverflow
    //     0x61b88c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61b890: cmp             SP, x16
    //     0x61b894: b.ls            #0x61b9b4
    // 0x61b898: LoadField: r0 = r3->field_b
    //     0x61b898: ldur            w0, [x3, #0xb]
    // 0x61b89c: DecompressPointer r0
    //     0x61b89c: add             x0, x0, HEAP, lsl #32
    // 0x61b8a0: cmp             w0, NULL
    // 0x61b8a4: b.eq            #0x61b9bc
    // 0x61b8a8: LoadField: r1 = r0->field_2b
    //     0x61b8a8: ldur            w1, [x0, #0x2b]
    // 0x61b8ac: DecompressPointer r1
    //     0x61b8ac: add             x1, x1, HEAP, lsl #32
    // 0x61b8b0: LoadField: r4 = r1->field_7
    //     0x61b8b0: ldur            w4, [x1, #7]
    // 0x61b8b4: DecompressPointer r4
    //     0x61b8b4: add             x4, x4, HEAP, lsl #32
    // 0x61b8b8: stur            x4, [fp, #-0x10]
    // 0x61b8bc: LoadField: r2 = r0->field_23
    //     0x61b8bc: ldur            x2, [x0, #0x23]
    // 0x61b8c0: r0 = BoxInt64Instr(r2)
    //     0x61b8c0: sbfiz           x0, x2, #1, #0x1f
    //     0x61b8c4: cmp             x2, x0, asr #1
    //     0x61b8c8: b.eq            #0x61b8d4
    //     0x61b8cc: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61b8d0: stur            x2, [x0, #7]
    // 0x61b8d4: stur            x0, [fp, #-8]
    // 0x61b8d8: cmp             w4, w0
    // 0x61b8dc: b.eq            #0x61b96c
    // 0x61b8e0: and             w16, w4, w0
    // 0x61b8e4: branchIfSmi(r16, 0x61b918)
    //     0x61b8e4: tbz             w16, #0, #0x61b918
    // 0x61b8e8: r16 = LoadClassIdInstr(r4)
    //     0x61b8e8: ldur            x16, [x4, #-1]
    //     0x61b8ec: ubfx            x16, x16, #0xc, #0x14
    // 0x61b8f0: cmp             x16, #0x3d
    // 0x61b8f4: b.ne            #0x61b918
    // 0x61b8f8: r16 = LoadClassIdInstr(r0)
    //     0x61b8f8: ldur            x16, [x0, #-1]
    //     0x61b8fc: ubfx            x16, x16, #0xc, #0x14
    // 0x61b900: cmp             x16, #0x3d
    // 0x61b904: b.ne            #0x61b918
    // 0x61b908: LoadField: r16 = r4->field_7
    //     0x61b908: ldur            x16, [x4, #7]
    // 0x61b90c: LoadField: r17 = r0->field_7
    //     0x61b90c: ldur            x17, [x0, #7]
    // 0x61b910: cmp             x16, x17
    // 0x61b914: b.eq            #0x61b96c
    // 0x61b918: r1 = Null
    //     0x61b918: mov             x1, NULL
    // 0x61b91c: r2 = 8
    //     0x61b91c: movz            x2, #0x8
    // 0x61b920: r0 = AllocateArray()
    //     0x61b920: bl              #0x82746c  ; AllocateArrayStub
    // 0x61b924: r16 = "Trying to end quest "
    //     0x61b924: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c2b8] "Trying to end quest "
    //     0x61b928: ldr             x16, [x16, #0x2b8]
    // 0x61b92c: StoreField: r0->field_f = r16
    //     0x61b92c: stur            w16, [x0, #0xf]
    // 0x61b930: ldur            x1, [fp, #-0x10]
    // 0x61b934: StoreField: r0->field_13 = r1
    //     0x61b934: stur            w1, [x0, #0x13]
    // 0x61b938: r16 = " from quest "
    //     0x61b938: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c2c0] " from quest "
    //     0x61b93c: ldr             x16, [x16, #0x2c0]
    // 0x61b940: ArrayStore: r0[0] = r16  ; List_4
    //     0x61b940: stur            w16, [x0, #0x17]
    // 0x61b944: ldur            x1, [fp, #-8]
    // 0x61b948: StoreField: r0->field_1b = r1
    //     0x61b948: stur            w1, [x0, #0x1b]
    // 0x61b94c: str             x0, [SP]
    // 0x61b950: r0 = _interpolate()
    //     0x61b950: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61b954: stur            x0, [fp, #-8]
    // 0x61b958: r0 = current()
    //     0x61b958: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x61b95c: ldur            x1, [fp, #-8]
    // 0x61b960: mov             x2, x0
    // 0x61b964: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x61b964: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x61b968: r0 = crashlyticsRecordError()
    //     0x61b968: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x61b96c: ldur            x0, [fp, #-0x18]
    // 0x61b970: LoadField: r1 = r0->field_b
    //     0x61b970: ldur            w1, [x0, #0xb]
    // 0x61b974: DecompressPointer r1
    //     0x61b974: add             x1, x1, HEAP, lsl #32
    // 0x61b978: cmp             w1, NULL
    // 0x61b97c: b.eq            #0x61b9c0
    // 0x61b980: LoadField: r0 = r1->field_2b
    //     0x61b980: ldur            w0, [x1, #0x2b]
    // 0x61b984: DecompressPointer r0
    //     0x61b984: add             x0, x0, HEAP, lsl #32
    // 0x61b988: StoreField: r0->field_7 = rNULL
    //     0x61b988: stur            NULL, [x0, #7]
    // 0x61b98c: LoadField: r0 = r1->field_2f
    //     0x61b98c: ldur            w0, [x1, #0x2f]
    // 0x61b990: DecompressPointer r0
    //     0x61b990: add             x0, x0, HEAP, lsl #32
    // 0x61b994: str             x0, [SP]
    // 0x61b998: ClosureCall
    //     0x61b998: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61b99c: ldur            x2, [x0, #0x1f]
    //     0x61b9a0: blr             x2
    // 0x61b9a4: r0 = Null
    //     0x61b9a4: mov             x0, NULL
    // 0x61b9a8: LeaveFrame
    //     0x61b9a8: mov             SP, fp
    //     0x61b9ac: ldp             fp, lr, [SP], #0x10
    // 0x61b9b0: ret
    //     0x61b9b0: ret             
    // 0x61b9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61b9b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61b9b8: b               #0x61b898
    // 0x61b9bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b9bc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61b9c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61b9c0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x61b9c4, size: 0x5a0
    // 0x61b9c4: EnterFrame
    //     0x61b9c4: stp             fp, lr, [SP, #-0x10]!
    //     0x61b9c8: mov             fp, SP
    // 0x61b9cc: AllocStack(0x58)
    //     0x61b9cc: sub             SP, SP, #0x58
    // 0x61b9d0: SetupParameters([dynamic _ /* r0 */])
    //     0x61b9d0: ldr             x0, [fp, #0x18]
    //     0x61b9d4: ldur            w1, [x0, #0x17]
    //     0x61b9d8: add             x1, x1, HEAP, lsl #32
    //     0x61b9dc: stur            x1, [fp, #-8]
    // 0x61b9e0: CheckStackOverflow
    //     0x61b9e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61b9e4: cmp             SP, x16
    //     0x61b9e8: b.ls            #0x61bf54
    // 0x61b9ec: r1 = 1
    //     0x61b9ec: movz            x1, #0x1
    // 0x61b9f0: r0 = AllocateContext()
    //     0x61b9f0: bl              #0x82637c  ; AllocateContextStub
    // 0x61b9f4: mov             x2, x0
    // 0x61b9f8: ldur            x0, [fp, #-8]
    // 0x61b9fc: stur            x2, [fp, #-0x18]
    // 0x61ba00: StoreField: r2->field_b = r0
    //     0x61ba00: stur            w0, [x2, #0xb]
    // 0x61ba04: ldr             x1, [fp, #0x10]
    // 0x61ba08: StoreField: r2->field_f = r1
    //     0x61ba08: stur            w1, [x2, #0xf]
    // 0x61ba0c: LoadField: r3 = r0->field_b
    //     0x61ba0c: ldur            w3, [x0, #0xb]
    // 0x61ba10: DecompressPointer r3
    //     0x61ba10: add             x3, x3, HEAP, lsl #32
    // 0x61ba14: stur            x3, [fp, #-0x10]
    // 0x61ba18: LoadField: r1 = r3->field_f
    //     0x61ba18: ldur            w1, [x3, #0xf]
    // 0x61ba1c: DecompressPointer r1
    //     0x61ba1c: add             x1, x1, HEAP, lsl #32
    // 0x61ba20: r0 = currentLevelOrLastCompleted()
    //     0x61ba20: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61ba24: LoadField: r1 = r0->field_13
    //     0x61ba24: ldur            w1, [x0, #0x13]
    // 0x61ba28: DecompressPointer r1
    //     0x61ba28: add             x1, x1, HEAP, lsl #32
    // 0x61ba2c: stur            x1, [fp, #-0x20]
    // 0x61ba30: r0 = Text()
    //     0x61ba30: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61ba34: mov             x2, x0
    // 0x61ba38: ldur            x0, [fp, #-0x20]
    // 0x61ba3c: stur            x2, [fp, #-0x28]
    // 0x61ba40: StoreField: r2->field_b = r0
    //     0x61ba40: stur            w0, [x2, #0xb]
    // 0x61ba44: ldur            x0, [fp, #-0x10]
    // 0x61ba48: LoadField: r1 = r0->field_f
    //     0x61ba48: ldur            w1, [x0, #0xf]
    // 0x61ba4c: DecompressPointer r1
    //     0x61ba4c: add             x1, x1, HEAP, lsl #32
    // 0x61ba50: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x61ba50: ldur            w3, [x1, #0x17]
    // 0x61ba54: DecompressPointer r3
    //     0x61ba54: add             x3, x3, HEAP, lsl #32
    // 0x61ba58: r16 = Instance_QuestState
    //     0x61ba58: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c250] Obj!QuestState@85e9e1
    //     0x61ba5c: ldr             x16, [x16, #0x250]
    // 0x61ba60: cmp             w3, w16
    // 0x61ba64: b.ne            #0x61ba90
    // 0x61ba68: r0 = currentLevelOrLastCompleted()
    //     0x61ba68: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61ba6c: LoadField: r1 = r0->field_1b
    //     0x61ba6c: ldur            w1, [x0, #0x1b]
    // 0x61ba70: DecompressPointer r1
    //     0x61ba70: add             x1, x1, HEAP, lsl #32
    // 0x61ba74: stur            x1, [fp, #-0x20]
    // 0x61ba78: r0 = Text()
    //     0x61ba78: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61ba7c: mov             x1, x0
    // 0x61ba80: ldur            x0, [fp, #-0x20]
    // 0x61ba84: StoreField: r1->field_b = r0
    //     0x61ba84: stur            w0, [x1, #0xb]
    // 0x61ba88: mov             x2, x1
    // 0x61ba8c: b               #0x61bcd8
    // 0x61ba90: r0 = currentLevelOrLastCompleted()
    //     0x61ba90: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61ba94: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x61ba94: ldur            w3, [x0, #0x17]
    // 0x61ba98: DecompressPointer r3
    //     0x61ba98: add             x3, x3, HEAP, lsl #32
    // 0x61ba9c: stur            x3, [fp, #-0x20]
    // 0x61baa0: r1 = Null
    //     0x61baa0: mov             x1, NULL
    // 0x61baa4: r2 = 10
    //     0x61baa4: movz            x2, #0xa
    // 0x61baa8: r0 = AllocateArray()
    //     0x61baa8: bl              #0x82746c  ; AllocateArrayStub
    // 0x61baac: mov             x3, x0
    // 0x61bab0: ldur            x0, [fp, #-0x20]
    // 0x61bab4: stur            x3, [fp, #-0x30]
    // 0x61bab8: StoreField: r3->field_f = r0
    //     0x61bab8: stur            w0, [x3, #0xf]
    // 0x61babc: r16 = "\n\n"
    //     0x61babc: ldr             x16, [PP, #0x5700]  ; [pp+0x5700] "\n\n"
    // 0x61bac0: StoreField: r3->field_13 = r16
    //     0x61bac0: stur            w16, [x3, #0x13]
    // 0x61bac4: ldur            x0, [fp, #-0x10]
    // 0x61bac8: LoadField: r4 = r0->field_f
    //     0x61bac8: ldur            w4, [x0, #0xf]
    // 0x61bacc: DecompressPointer r4
    //     0x61bacc: add             x4, x4, HEAP, lsl #32
    // 0x61bad0: stur            x4, [fp, #-0x20]
    // 0x61bad4: LoadField: r1 = r4->field_b
    //     0x61bad4: ldur            w1, [x4, #0xb]
    // 0x61bad8: DecompressPointer r1
    //     0x61bad8: add             x1, x1, HEAP, lsl #32
    // 0x61badc: cmp             w1, NULL
    // 0x61bae0: b.eq            #0x61bf5c
    // 0x61bae4: LoadField: r2 = r1->field_13
    //     0x61bae4: ldur            w2, [x1, #0x13]
    // 0x61bae8: DecompressPointer r2
    //     0x61bae8: add             x2, x2, HEAP, lsl #32
    // 0x61baec: tbnz            w2, #4, #0x61bc34
    // 0x61baf0: r1 = Null
    //     0x61baf0: mov             x1, NULL
    // 0x61baf4: r2 = 10
    //     0x61baf4: movz            x2, #0xa
    // 0x61baf8: r0 = AllocateArray()
    //     0x61baf8: bl              #0x82746c  ; AllocateArrayStub
    // 0x61bafc: stur            x0, [fp, #-0x38]
    // 0x61bb00: r16 = "Goal: Get "
    //     0x61bb00: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c260] "Goal: Get "
    //     0x61bb04: ldr             x16, [x16, #0x260]
    // 0x61bb08: StoreField: r0->field_f = r16
    //     0x61bb08: stur            w16, [x0, #0xf]
    // 0x61bb0c: ldur            x1, [fp, #-0x20]
    // 0x61bb10: r0 = currentLevelOrLastCompleted()
    //     0x61bb10: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61bb14: LoadField: r1 = r0->field_f
    //     0x61bb14: ldur            w1, [x0, #0xf]
    // 0x61bb18: DecompressPointer r1
    //     0x61bb18: add             x1, x1, HEAP, lsl #32
    // 0x61bb1c: LoadField: r0 = r1->field_f
    //     0x61bb1c: ldur            w0, [x1, #0xf]
    // 0x61bb20: DecompressPointer r0
    //     0x61bb20: add             x0, x0, HEAP, lsl #32
    // 0x61bb24: ldur            x1, [fp, #-0x38]
    // 0x61bb28: ArrayStore: r1[1] = r0  ; List_4
    //     0x61bb28: add             x25, x1, #0x13
    //     0x61bb2c: str             w0, [x25]
    //     0x61bb30: tbz             w0, #0, #0x61bb4c
    //     0x61bb34: ldurb           w16, [x1, #-1]
    //     0x61bb38: ldurb           w17, [x0, #-1]
    //     0x61bb3c: and             x16, x17, x16, lsr #2
    //     0x61bb40: tst             x16, HEAP, lsr #32
    //     0x61bb44: b.eq            #0x61bb4c
    //     0x61bb48: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61bb4c: ldur            x0, [fp, #-0x38]
    // 0x61bb50: r16 = " "
    //     0x61bb50: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x61bb54: ArrayStore: r0[0] = r16  ; List_4
    //     0x61bb54: stur            w16, [x0, #0x17]
    // 0x61bb58: ldur            x2, [fp, #-0x10]
    // 0x61bb5c: LoadField: r1 = r2->field_f
    //     0x61bb5c: ldur            w1, [x2, #0xf]
    // 0x61bb60: DecompressPointer r1
    //     0x61bb60: add             x1, x1, HEAP, lsl #32
    // 0x61bb64: LoadField: r3 = r1->field_b
    //     0x61bb64: ldur            w3, [x1, #0xb]
    // 0x61bb68: DecompressPointer r3
    //     0x61bb68: add             x3, x3, HEAP, lsl #32
    // 0x61bb6c: stur            x3, [fp, #-0x20]
    // 0x61bb70: cmp             w3, NULL
    // 0x61bb74: b.eq            #0x61bf60
    // 0x61bb78: r0 = currentLevelOrLastCompleted()
    //     0x61bb78: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61bb7c: LoadField: r1 = r0->field_f
    //     0x61bb7c: ldur            w1, [x0, #0xf]
    // 0x61bb80: DecompressPointer r1
    //     0x61bb80: add             x1, x1, HEAP, lsl #32
    // 0x61bb84: LoadField: r3 = r1->field_b
    //     0x61bb84: ldur            w3, [x1, #0xb]
    // 0x61bb88: DecompressPointer r3
    //     0x61bb88: add             x3, x3, HEAP, lsl #32
    // 0x61bb8c: ldur            x0, [fp, #-0x20]
    // 0x61bb90: stur            x3, [fp, #-0x48]
    // 0x61bb94: LoadField: r4 = r0->field_f
    //     0x61bb94: ldur            w4, [x0, #0xf]
    // 0x61bb98: DecompressPointer r4
    //     0x61bb98: add             x4, x4, HEAP, lsl #32
    // 0x61bb9c: ldur            x5, [fp, #-0x10]
    // 0x61bba0: stur            x4, [fp, #-0x40]
    // 0x61bba4: LoadField: r0 = r5->field_f
    //     0x61bba4: ldur            w0, [x5, #0xf]
    // 0x61bba8: DecompressPointer r0
    //     0x61bba8: add             x0, x0, HEAP, lsl #32
    // 0x61bbac: LoadField: r2 = r0->field_7
    //     0x61bbac: ldur            w2, [x0, #7]
    // 0x61bbb0: DecompressPointer r2
    //     0x61bbb0: add             x2, x2, HEAP, lsl #32
    // 0x61bbb4: mov             x0, x4
    // 0x61bbb8: r1 = Null
    //     0x61bbb8: mov             x1, NULL
    // 0x61bbbc: r8 = (dynamic this, C3X0?) => String?
    //     0x61bbbc: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x61bbc0: ldr             x8, [x8, #0xe90]
    // 0x61bbc4: LoadField: r9 = r8->field_7
    //     0x61bbc4: ldur            x9, [x8, #7]
    // 0x61bbc8: r3 = Null
    //     0x61bbc8: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c268] Null
    //     0x61bbcc: ldr             x3, [x3, #0x268]
    // 0x61bbd0: blr             x9
    // 0x61bbd4: ldur            x16, [fp, #-0x40]
    // 0x61bbd8: ldur            lr, [fp, #-0x48]
    // 0x61bbdc: stp             lr, x16, [SP]
    // 0x61bbe0: ldur            x0, [fp, #-0x40]
    // 0x61bbe4: ClosureCall
    //     0x61bbe4: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x61bbe8: ldur            x2, [x0, #0x1f]
    //     0x61bbec: blr             x2
    // 0x61bbf0: ldur            x1, [fp, #-0x38]
    // 0x61bbf4: ArrayStore: r1[3] = r0  ; List_4
    //     0x61bbf4: add             x25, x1, #0x1b
    //     0x61bbf8: str             w0, [x25]
    //     0x61bbfc: tbz             w0, #0, #0x61bc18
    //     0x61bc00: ldurb           w16, [x1, #-1]
    //     0x61bc04: ldurb           w17, [x0, #-1]
    //     0x61bc08: and             x16, x17, x16, lsr #2
    //     0x61bc0c: tst             x16, HEAP, lsr #32
    //     0x61bc10: b.eq            #0x61bc18
    //     0x61bc14: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61bc18: ldur            x0, [fp, #-0x38]
    // 0x61bc1c: r16 = ".\n\n"
    //     0x61bc1c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c278] ".\n\n"
    //     0x61bc20: ldr             x16, [x16, #0x278]
    // 0x61bc24: StoreField: r0->field_1f = r16
    //     0x61bc24: stur            w16, [x0, #0x1f]
    // 0x61bc28: str             x0, [SP]
    // 0x61bc2c: r0 = _interpolate()
    //     0x61bc2c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61bc30: b               #0x61bc38
    // 0x61bc34: r0 = ""
    //     0x61bc34: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x61bc38: ldur            x2, [fp, #-0x10]
    // 0x61bc3c: ldur            x3, [fp, #-0x30]
    // 0x61bc40: mov             x1, x3
    // 0x61bc44: ArrayStore: r1[2] = r0  ; List_4
    //     0x61bc44: add             x25, x1, #0x17
    //     0x61bc48: str             w0, [x25]
    //     0x61bc4c: tbz             w0, #0, #0x61bc68
    //     0x61bc50: ldurb           w16, [x1, #-1]
    //     0x61bc54: ldurb           w17, [x0, #-1]
    //     0x61bc58: and             x16, x17, x16, lsr #2
    //     0x61bc5c: tst             x16, HEAP, lsr #32
    //     0x61bc60: b.eq            #0x61bc68
    //     0x61bc64: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61bc68: r16 = "On complete: "
    //     0x61bc68: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c280] "On complete: "
    //     0x61bc6c: ldr             x16, [x16, #0x280]
    // 0x61bc70: StoreField: r3->field_1b = r16
    //     0x61bc70: stur            w16, [x3, #0x1b]
    // 0x61bc74: LoadField: r1 = r2->field_f
    //     0x61bc74: ldur            w1, [x2, #0xf]
    // 0x61bc78: DecompressPointer r1
    //     0x61bc78: add             x1, x1, HEAP, lsl #32
    // 0x61bc7c: r0 = currentLevelOrLastCompleted()
    //     0x61bc7c: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61bc80: LoadField: r1 = r0->field_1b
    //     0x61bc80: ldur            w1, [x0, #0x1b]
    // 0x61bc84: DecompressPointer r1
    //     0x61bc84: add             x1, x1, HEAP, lsl #32
    // 0x61bc88: mov             x0, x1
    // 0x61bc8c: ldur            x1, [fp, #-0x30]
    // 0x61bc90: ArrayStore: r1[4] = r0  ; List_4
    //     0x61bc90: add             x25, x1, #0x1f
    //     0x61bc94: str             w0, [x25]
    //     0x61bc98: tbz             w0, #0, #0x61bcb4
    //     0x61bc9c: ldurb           w16, [x1, #-1]
    //     0x61bca0: ldurb           w17, [x0, #-1]
    //     0x61bca4: and             x16, x17, x16, lsr #2
    //     0x61bca8: tst             x16, HEAP, lsr #32
    //     0x61bcac: b.eq            #0x61bcb4
    //     0x61bcb0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61bcb4: ldur            x16, [fp, #-0x30]
    // 0x61bcb8: str             x16, [SP]
    // 0x61bcbc: r0 = _interpolate()
    //     0x61bcbc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61bcc0: stur            x0, [fp, #-0x10]
    // 0x61bcc4: r0 = Text()
    //     0x61bcc4: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61bcc8: mov             x1, x0
    // 0x61bccc: ldur            x0, [fp, #-0x10]
    // 0x61bcd0: StoreField: r1->field_b = r0
    //     0x61bcd0: stur            w0, [x1, #0xb]
    // 0x61bcd4: mov             x2, x1
    // 0x61bcd8: ldur            x1, [fp, #-8]
    // 0x61bcdc: ldur            x0, [fp, #-0x28]
    // 0x61bce0: stur            x2, [fp, #-0x10]
    // 0x61bce4: r0 = SingleChildScrollView()
    //     0x61bce4: bl              #0x5a4e90  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x61bce8: mov             x1, x0
    // 0x61bcec: r0 = Instance_Axis
    //     0x61bcec: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x61bcf0: stur            x1, [fp, #-0x20]
    // 0x61bcf4: StoreField: r1->field_b = r0
    //     0x61bcf4: stur            w0, [x1, #0xb]
    // 0x61bcf8: r0 = false
    //     0x61bcf8: add             x0, NULL, #0x30  ; false
    // 0x61bcfc: StoreField: r1->field_f = r0
    //     0x61bcfc: stur            w0, [x1, #0xf]
    // 0x61bd00: ldur            x2, [fp, #-0x10]
    // 0x61bd04: StoreField: r1->field_23 = r2
    //     0x61bd04: stur            w2, [x1, #0x23]
    // 0x61bd08: r2 = Instance_DragStartBehavior
    //     0x61bd08: ldr             x2, [PP, #0x70b0]  ; [pp+0x70b0] Obj!DragStartBehavior@863b61
    // 0x61bd0c: StoreField: r1->field_27 = r2
    //     0x61bd0c: stur            w2, [x1, #0x27]
    // 0x61bd10: r2 = Instance_Clip
    //     0x61bd10: add             x2, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x61bd14: ldr             x2, [x2, #0x900]
    // 0x61bd18: StoreField: r1->field_2b = r2
    //     0x61bd18: stur            w2, [x1, #0x2b]
    // 0x61bd1c: r2 = Instance_HitTestBehavior
    //     0x61bd1c: add             x2, PP, #0xc, lsl #12  ; [pp+0xc9a8] Obj!HitTestBehavior@8628c1
    //     0x61bd20: ldr             x2, [x2, #0x9a8]
    // 0x61bd24: StoreField: r1->field_2f = r2
    //     0x61bd24: stur            w2, [x1, #0x2f]
    // 0x61bd28: ldur            x2, [fp, #-8]
    // 0x61bd2c: LoadField: r3 = r2->field_f
    //     0x61bd2c: ldur            w3, [x2, #0xf]
    // 0x61bd30: DecompressPointer r3
    //     0x61bd30: add             x3, x3, HEAP, lsl #32
    // 0x61bd34: stur            x3, [fp, #-0x10]
    // 0x61bd38: r16 = Instance_QuestState
    //     0x61bd38: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a330] Obj!QuestState@85e9c1
    //     0x61bd3c: ldr             x16, [x16, #0x330]
    // 0x61bd40: cmp             w3, w16
    // 0x61bd44: r16 = true
    //     0x61bd44: add             x16, NULL, #0x20  ; true
    // 0x61bd48: r17 = false
    //     0x61bd48: add             x17, NULL, #0x30  ; false
    // 0x61bd4c: csel            x2, x16, x17, eq
    // 0x61bd50: stur            x2, [fp, #-8]
    // 0x61bd54: r0 = TextButton()
    //     0x61bd54: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x61bd58: mov             x3, x0
    // 0x61bd5c: r0 = false
    //     0x61bd5c: add             x0, NULL, #0x30  ; false
    // 0x61bd60: stur            x3, [fp, #-0x30]
    // 0x61bd64: StoreField: r3->field_3f = r0
    //     0x61bd64: stur            w0, [x3, #0x3f]
    // 0x61bd68: ldur            x2, [fp, #-0x18]
    // 0x61bd6c: r1 = Function '<anonymous closure>':.
    //     0x61bd6c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c288] AnonymousClosure: (0x61bfe8), in [package:pretentious/widgets/QuestButton.dart] QuestButtonState::build (0x61a6d0)
    //     0x61bd70: ldr             x1, [x1, #0x288]
    // 0x61bd74: r0 = AllocateClosure()
    //     0x61bd74: bl              #0x826750  ; AllocateClosureStub
    // 0x61bd78: mov             x1, x0
    // 0x61bd7c: ldur            x0, [fp, #-0x30]
    // 0x61bd80: StoreField: r0->field_b = r1
    //     0x61bd80: stur            w1, [x0, #0xb]
    // 0x61bd84: r1 = false
    //     0x61bd84: add             x1, NULL, #0x30  ; false
    // 0x61bd88: StoreField: r0->field_27 = r1
    //     0x61bd88: stur            w1, [x0, #0x27]
    // 0x61bd8c: r2 = true
    //     0x61bd8c: add             x2, NULL, #0x20  ; true
    // 0x61bd90: StoreField: r0->field_2f = r2
    //     0x61bd90: stur            w2, [x0, #0x2f]
    // 0x61bd94: r3 = Instance_Text
    //     0x61bd94: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c290] Obj!Text@850cb1
    //     0x61bd98: ldr             x3, [x3, #0x290]
    // 0x61bd9c: StoreField: r0->field_3b = r3
    //     0x61bd9c: stur            w3, [x0, #0x3b]
    // 0x61bda0: r0 = Visibility()
    //     0x61bda0: bl              #0x608d08  ; AllocateVisibilityStub -> Visibility (size=0x30)
    // 0x61bda4: mov             x1, x0
    // 0x61bda8: ldur            x0, [fp, #-0x30]
    // 0x61bdac: stur            x1, [fp, #-0x38]
    // 0x61bdb0: StoreField: r1->field_b = r0
    //     0x61bdb0: stur            w0, [x1, #0xb]
    // 0x61bdb4: r0 = Instance_SizedBox
    //     0x61bdb4: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x61bdb8: StoreField: r1->field_f = r0
    //     0x61bdb8: stur            w0, [x1, #0xf]
    // 0x61bdbc: ldur            x2, [fp, #-8]
    // 0x61bdc0: StoreField: r1->field_13 = r2
    //     0x61bdc0: stur            w2, [x1, #0x13]
    // 0x61bdc4: r2 = false
    //     0x61bdc4: add             x2, NULL, #0x30  ; false
    // 0x61bdc8: ArrayStore: r1[0] = r2  ; List_4
    //     0x61bdc8: stur            w2, [x1, #0x17]
    // 0x61bdcc: StoreField: r1->field_1b = r2
    //     0x61bdcc: stur            w2, [x1, #0x1b]
    // 0x61bdd0: StoreField: r1->field_1f = r2
    //     0x61bdd0: stur            w2, [x1, #0x1f]
    // 0x61bdd4: StoreField: r1->field_23 = r2
    //     0x61bdd4: stur            w2, [x1, #0x23]
    // 0x61bdd8: StoreField: r1->field_27 = r2
    //     0x61bdd8: stur            w2, [x1, #0x27]
    // 0x61bddc: StoreField: r1->field_2b = r2
    //     0x61bddc: stur            w2, [x1, #0x2b]
    // 0x61bde0: ldur            x3, [fp, #-0x10]
    // 0x61bde4: r16 = Instance_QuestState
    //     0x61bde4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c298] Obj!QuestState@85e981
    //     0x61bde8: ldr             x16, [x16, #0x298]
    // 0x61bdec: cmp             w3, w16
    // 0x61bdf0: r16 = true
    //     0x61bdf0: add             x16, NULL, #0x20  ; true
    // 0x61bdf4: r17 = false
    //     0x61bdf4: add             x17, NULL, #0x30  ; false
    // 0x61bdf8: csel            x4, x16, x17, eq
    // 0x61bdfc: stur            x4, [fp, #-8]
    // 0x61be00: r0 = TextButton()
    //     0x61be00: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x61be04: mov             x3, x0
    // 0x61be08: r0 = false
    //     0x61be08: add             x0, NULL, #0x30  ; false
    // 0x61be0c: stur            x3, [fp, #-0x10]
    // 0x61be10: StoreField: r3->field_3f = r0
    //     0x61be10: stur            w0, [x3, #0x3f]
    // 0x61be14: ldur            x2, [fp, #-0x18]
    // 0x61be18: r1 = Function '<anonymous closure>':.
    //     0x61be18: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c2a0] AnonymousClosure: (0x61bf64), in [package:pretentious/widgets/QuestButton.dart] QuestButtonState::build (0x61a6d0)
    //     0x61be1c: ldr             x1, [x1, #0x2a0]
    // 0x61be20: r0 = AllocateClosure()
    //     0x61be20: bl              #0x826750  ; AllocateClosureStub
    // 0x61be24: mov             x1, x0
    // 0x61be28: ldur            x0, [fp, #-0x10]
    // 0x61be2c: StoreField: r0->field_b = r1
    //     0x61be2c: stur            w1, [x0, #0xb]
    // 0x61be30: r1 = false
    //     0x61be30: add             x1, NULL, #0x30  ; false
    // 0x61be34: StoreField: r0->field_27 = r1
    //     0x61be34: stur            w1, [x0, #0x27]
    // 0x61be38: r2 = true
    //     0x61be38: add             x2, NULL, #0x20  ; true
    // 0x61be3c: StoreField: r0->field_2f = r2
    //     0x61be3c: stur            w2, [x0, #0x2f]
    // 0x61be40: r3 = Instance_Text
    //     0x61be40: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c2a8] Obj!Text@850c61
    //     0x61be44: ldr             x3, [x3, #0x2a8]
    // 0x61be48: StoreField: r0->field_3b = r3
    //     0x61be48: stur            w3, [x0, #0x3b]
    // 0x61be4c: r0 = Visibility()
    //     0x61be4c: bl              #0x608d08  ; AllocateVisibilityStub -> Visibility (size=0x30)
    // 0x61be50: mov             x1, x0
    // 0x61be54: ldur            x0, [fp, #-0x10]
    // 0x61be58: stur            x1, [fp, #-0x30]
    // 0x61be5c: StoreField: r1->field_b = r0
    //     0x61be5c: stur            w0, [x1, #0xb]
    // 0x61be60: r0 = Instance_SizedBox
    //     0x61be60: ldr             x0, [PP, #0x6cf8]  ; [pp+0x6cf8] Obj!SizedBox@85d1e1
    // 0x61be64: StoreField: r1->field_f = r0
    //     0x61be64: stur            w0, [x1, #0xf]
    // 0x61be68: ldur            x0, [fp, #-8]
    // 0x61be6c: StoreField: r1->field_13 = r0
    //     0x61be6c: stur            w0, [x1, #0x13]
    // 0x61be70: r0 = false
    //     0x61be70: add             x0, NULL, #0x30  ; false
    // 0x61be74: ArrayStore: r1[0] = r0  ; List_4
    //     0x61be74: stur            w0, [x1, #0x17]
    // 0x61be78: StoreField: r1->field_1b = r0
    //     0x61be78: stur            w0, [x1, #0x1b]
    // 0x61be7c: StoreField: r1->field_1f = r0
    //     0x61be7c: stur            w0, [x1, #0x1f]
    // 0x61be80: StoreField: r1->field_23 = r0
    //     0x61be80: stur            w0, [x1, #0x23]
    // 0x61be84: StoreField: r1->field_27 = r0
    //     0x61be84: stur            w0, [x1, #0x27]
    // 0x61be88: StoreField: r1->field_2b = r0
    //     0x61be88: stur            w0, [x1, #0x2b]
    // 0x61be8c: r0 = TextButton()
    //     0x61be8c: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x61be90: mov             x3, x0
    // 0x61be94: r0 = false
    //     0x61be94: add             x0, NULL, #0x30  ; false
    // 0x61be98: stur            x3, [fp, #-8]
    // 0x61be9c: StoreField: r3->field_3f = r0
    //     0x61be9c: stur            w0, [x3, #0x3f]
    // 0x61bea0: ldur            x2, [fp, #-0x18]
    // 0x61bea4: r1 = Function '<anonymous closure>':.
    //     0x61bea4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c2b0] AnonymousClosure: (0x4900b0), in [package:pretentious/widgets/ChapterViewport.dart] ChapterViewportState::displayChapter10Email (0x48fefc)
    //     0x61bea8: ldr             x1, [x1, #0x2b0]
    // 0x61beac: r0 = AllocateClosure()
    //     0x61beac: bl              #0x826750  ; AllocateClosureStub
    // 0x61beb0: mov             x1, x0
    // 0x61beb4: ldur            x0, [fp, #-8]
    // 0x61beb8: StoreField: r0->field_b = r1
    //     0x61beb8: stur            w1, [x0, #0xb]
    // 0x61bebc: r3 = false
    //     0x61bebc: add             x3, NULL, #0x30  ; false
    // 0x61bec0: StoreField: r0->field_27 = r3
    //     0x61bec0: stur            w3, [x0, #0x27]
    // 0x61bec4: r1 = true
    //     0x61bec4: add             x1, NULL, #0x20  ; true
    // 0x61bec8: StoreField: r0->field_2f = r1
    //     0x61bec8: stur            w1, [x0, #0x2f]
    // 0x61becc: r1 = Instance_Text
    //     0x61becc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe9f8] Obj!Text@84ec31
    //     0x61bed0: ldr             x1, [x1, #0x9f8]
    // 0x61bed4: StoreField: r0->field_3b = r1
    //     0x61bed4: stur            w1, [x0, #0x3b]
    // 0x61bed8: r1 = Null
    //     0x61bed8: mov             x1, NULL
    // 0x61bedc: r2 = 6
    //     0x61bedc: movz            x2, #0x6
    // 0x61bee0: r0 = AllocateArray()
    //     0x61bee0: bl              #0x82746c  ; AllocateArrayStub
    // 0x61bee4: mov             x2, x0
    // 0x61bee8: ldur            x0, [fp, #-0x38]
    // 0x61beec: stur            x2, [fp, #-0x10]
    // 0x61bef0: StoreField: r2->field_f = r0
    //     0x61bef0: stur            w0, [x2, #0xf]
    // 0x61bef4: ldur            x0, [fp, #-0x30]
    // 0x61bef8: StoreField: r2->field_13 = r0
    //     0x61bef8: stur            w0, [x2, #0x13]
    // 0x61befc: ldur            x0, [fp, #-8]
    // 0x61bf00: ArrayStore: r2[0] = r0  ; List_4
    //     0x61bf00: stur            w0, [x2, #0x17]
    // 0x61bf04: r1 = <Widget>
    //     0x61bf04: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x61bf08: r0 = AllocateGrowableArray()
    //     0x61bf08: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x61bf0c: mov             x1, x0
    // 0x61bf10: ldur            x0, [fp, #-0x10]
    // 0x61bf14: stur            x1, [fp, #-8]
    // 0x61bf18: StoreField: r1->field_f = r0
    //     0x61bf18: stur            w0, [x1, #0xf]
    // 0x61bf1c: r0 = 6
    //     0x61bf1c: movz            x0, #0x6
    // 0x61bf20: StoreField: r1->field_b = r0
    //     0x61bf20: stur            w0, [x1, #0xb]
    // 0x61bf24: r0 = AlertDialog()
    //     0x61bf24: bl              #0x490074  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x61bf28: ldur            x1, [fp, #-0x28]
    // 0x61bf2c: StoreField: r0->field_f = r1
    //     0x61bf2c: stur            w1, [x0, #0xf]
    // 0x61bf30: ldur            x1, [fp, #-0x20]
    // 0x61bf34: StoreField: r0->field_1b = r1
    //     0x61bf34: stur            w1, [x0, #0x1b]
    // 0x61bf38: ldur            x1, [fp, #-8]
    // 0x61bf3c: StoreField: r0->field_27 = r1
    //     0x61bf3c: stur            w1, [x0, #0x27]
    // 0x61bf40: r1 = false
    //     0x61bf40: add             x1, NULL, #0x30  ; false
    // 0x61bf44: StoreField: r0->field_6b = r1
    //     0x61bf44: stur            w1, [x0, #0x6b]
    // 0x61bf48: LeaveFrame
    //     0x61bf48: mov             SP, fp
    //     0x61bf4c: ldp             fp, lr, [SP], #0x10
    // 0x61bf50: ret
    //     0x61bf50: ret             
    // 0x61bf54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61bf54: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61bf58: b               #0x61b9ec
    // 0x61bf5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61bf5c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61bf60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61bf60: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x61bf64, size: 0x84
    // 0x61bf64: EnterFrame
    //     0x61bf64: stp             fp, lr, [SP, #-0x10]!
    //     0x61bf68: mov             fp, SP
    // 0x61bf6c: AllocStack(0x18)
    //     0x61bf6c: sub             SP, SP, #0x18
    // 0x61bf70: SetupParameters([dynamic _ /* r0 */])
    //     0x61bf70: ldr             x0, [fp, #0x10]
    //     0x61bf74: ldur            w2, [x0, #0x17]
    //     0x61bf78: add             x2, x2, HEAP, lsl #32
    //     0x61bf7c: stur            x2, [fp, #-8]
    // 0x61bf80: CheckStackOverflow
    //     0x61bf80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61bf84: cmp             SP, x16
    //     0x61bf88: b.ls            #0x61bfe0
    // 0x61bf8c: LoadField: r0 = r2->field_b
    //     0x61bf8c: ldur            w0, [x2, #0xb]
    // 0x61bf90: DecompressPointer r0
    //     0x61bf90: add             x0, x0, HEAP, lsl #32
    // 0x61bf94: LoadField: r1 = r0->field_b
    //     0x61bf94: ldur            w1, [x0, #0xb]
    // 0x61bf98: DecompressPointer r1
    //     0x61bf98: add             x1, x1, HEAP, lsl #32
    // 0x61bf9c: LoadField: r0 = r1->field_f
    //     0x61bf9c: ldur            w0, [x1, #0xf]
    // 0x61bfa0: DecompressPointer r0
    //     0x61bfa0: add             x0, x0, HEAP, lsl #32
    // 0x61bfa4: mov             x1, x0
    // 0x61bfa8: r0 = endQuest()
    //     0x61bfa8: bl              #0x61b878  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::endQuest
    // 0x61bfac: ldur            x0, [fp, #-8]
    // 0x61bfb0: LoadField: r1 = r0->field_f
    //     0x61bfb0: ldur            w1, [x0, #0xf]
    // 0x61bfb4: DecompressPointer r1
    //     0x61bfb4: add             x1, x1, HEAP, lsl #32
    // 0x61bfb8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61bfb8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61bfbc: r0 = of()
    //     0x61bfbc: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x61bfc0: r16 = <Object?>
    //     0x61bfc0: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x61bfc4: stp             x0, x16, [SP]
    // 0x61bfc8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x61bfc8: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x61bfcc: r0 = pop()
    //     0x61bfcc: bl              #0x38447c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x61bfd0: r0 = Null
    //     0x61bfd0: mov             x0, NULL
    // 0x61bfd4: LeaveFrame
    //     0x61bfd4: mov             SP, fp
    //     0x61bfd8: ldp             fp, lr, [SP], #0x10
    // 0x61bfdc: ret
    //     0x61bfdc: ret             
    // 0x61bfe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61bfe0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61bfe4: b               #0x61bf8c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x61bfe8, size: 0x1cc
    // 0x61bfe8: EnterFrame
    //     0x61bfe8: stp             fp, lr, [SP, #-0x10]!
    //     0x61bfec: mov             fp, SP
    // 0x61bff0: AllocStack(0x30)
    //     0x61bff0: sub             SP, SP, #0x30
    // 0x61bff4: SetupParameters([dynamic _ /* r0 */])
    //     0x61bff4: ldr             x0, [fp, #0x10]
    //     0x61bff8: ldur            w2, [x0, #0x17]
    //     0x61bffc: add             x2, x2, HEAP, lsl #32
    //     0x61c000: stur            x2, [fp, #-0x18]
    // 0x61c004: CheckStackOverflow
    //     0x61c004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61c008: cmp             SP, x16
    //     0x61c00c: b.ls            #0x61c19c
    // 0x61c010: LoadField: r0 = r2->field_b
    //     0x61c010: ldur            w0, [x2, #0xb]
    // 0x61c014: DecompressPointer r0
    //     0x61c014: add             x0, x0, HEAP, lsl #32
    // 0x61c018: LoadField: r3 = r0->field_b
    //     0x61c018: ldur            w3, [x0, #0xb]
    // 0x61c01c: DecompressPointer r3
    //     0x61c01c: add             x3, x3, HEAP, lsl #32
    // 0x61c020: stur            x3, [fp, #-0x10]
    // 0x61c024: LoadField: r0 = r3->field_f
    //     0x61c024: ldur            w0, [x3, #0xf]
    // 0x61c028: DecompressPointer r0
    //     0x61c028: add             x0, x0, HEAP, lsl #32
    // 0x61c02c: LoadField: r4 = r0->field_b
    //     0x61c02c: ldur            w4, [x0, #0xb]
    // 0x61c030: DecompressPointer r4
    //     0x61c030: add             x4, x4, HEAP, lsl #32
    // 0x61c034: cmp             w4, NULL
    // 0x61c038: b.eq            #0x61c1a4
    // 0x61c03c: LoadField: r5 = r4->field_2b
    //     0x61c03c: ldur            w5, [x4, #0x2b]
    // 0x61c040: DecompressPointer r5
    //     0x61c040: add             x5, x5, HEAP, lsl #32
    // 0x61c044: LoadField: r6 = r4->field_23
    //     0x61c044: ldur            x6, [x4, #0x23]
    // 0x61c048: r0 = BoxInt64Instr(r6)
    //     0x61c048: sbfiz           x0, x6, #1, #0x1f
    //     0x61c04c: cmp             x6, x0, asr #1
    //     0x61c050: b.eq            #0x61c05c
    //     0x61c054: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x61c058: stur            x6, [x0, #7]
    // 0x61c05c: StoreField: r5->field_7 = r0
    //     0x61c05c: stur            w0, [x5, #7]
    //     0x61c060: tbz             w0, #0, #0x61c07c
    //     0x61c064: ldurb           w16, [x5, #-1]
    //     0x61c068: ldurb           w17, [x0, #-1]
    //     0x61c06c: and             x16, x17, x16, lsr #2
    //     0x61c070: tst             x16, HEAP, lsr #32
    //     0x61c074: b.eq            #0x61c07c
    //     0x61c078: bl              #0x825b58  ; WriteBarrierWrappersStub
    // 0x61c07c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x61c07c: ldur            w0, [x4, #0x17]
    // 0x61c080: DecompressPointer r0
    //     0x61c080: add             x0, x0, HEAP, lsl #32
    // 0x61c084: cmp             w0, NULL
    // 0x61c088: b.eq            #0x61c120
    // 0x61c08c: LoadField: r0 = r4->field_2b
    //     0x61c08c: ldur            w0, [x4, #0x2b]
    // 0x61c090: DecompressPointer r0
    //     0x61c090: add             x0, x0, HEAP, lsl #32
    // 0x61c094: stur            x0, [fp, #-8]
    // 0x61c098: r0 = DateTime()
    //     0x61c098: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x61c09c: mov             x1, x0
    // 0x61c0a0: r0 = false
    //     0x61c0a0: add             x0, NULL, #0x30  ; false
    // 0x61c0a4: stur            x1, [fp, #-0x20]
    // 0x61c0a8: StoreField: r1->field_7 = r0
    //     0x61c0a8: stur            w0, [x1, #7]
    // 0x61c0ac: r0 = _getCurrentMicros()
    //     0x61c0ac: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x61c0b0: r1 = LoadInt32Instr(r0)
    //     0x61c0b0: sbfx            x1, x0, #1, #0x1f
    //     0x61c0b4: tbz             w0, #0, #0x61c0bc
    //     0x61c0b8: ldur            x1, [x0, #7]
    // 0x61c0bc: ldur            x0, [fp, #-0x20]
    // 0x61c0c0: StoreField: r0->field_b = r1
    //     0x61c0c0: stur            x1, [x0, #0xb]
    // 0x61c0c4: ldur            x3, [fp, #-0x10]
    // 0x61c0c8: LoadField: r1 = r3->field_f
    //     0x61c0c8: ldur            w1, [x3, #0xf]
    // 0x61c0cc: DecompressPointer r1
    //     0x61c0cc: add             x1, x1, HEAP, lsl #32
    // 0x61c0d0: LoadField: r2 = r1->field_b
    //     0x61c0d0: ldur            w2, [x1, #0xb]
    // 0x61c0d4: DecompressPointer r2
    //     0x61c0d4: add             x2, x2, HEAP, lsl #32
    // 0x61c0d8: cmp             w2, NULL
    // 0x61c0dc: b.eq            #0x61c1a8
    // 0x61c0e0: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x61c0e0: ldur            w1, [x2, #0x17]
    // 0x61c0e4: DecompressPointer r1
    //     0x61c0e4: add             x1, x1, HEAP, lsl #32
    // 0x61c0e8: cmp             w1, NULL
    // 0x61c0ec: b.eq            #0x61c1ac
    // 0x61c0f0: mov             x2, x1
    // 0x61c0f4: mov             x1, x0
    // 0x61c0f8: r0 = add()
    //     0x61c0f8: bl              #0x360130  ; [dart:core] DateTime::add
    // 0x61c0fc: ldur            x1, [fp, #-8]
    // 0x61c100: StoreField: r1->field_f = r0
    //     0x61c100: stur            w0, [x1, #0xf]
    //     0x61c104: ldurb           w16, [x1, #-1]
    //     0x61c108: ldurb           w17, [x0, #-1]
    //     0x61c10c: and             x16, x17, x16, lsr #2
    //     0x61c110: tst             x16, HEAP, lsr #32
    //     0x61c114: b.eq            #0x61c11c
    //     0x61c118: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x61c11c: b               #0x61c12c
    // 0x61c120: LoadField: r0 = r4->field_2b
    //     0x61c120: ldur            w0, [x4, #0x2b]
    // 0x61c124: DecompressPointer r0
    //     0x61c124: add             x0, x0, HEAP, lsl #32
    // 0x61c128: StoreField: r0->field_f = rNULL
    //     0x61c128: stur            NULL, [x0, #0xf]
    // 0x61c12c: ldur            x1, [fp, #-0x18]
    // 0x61c130: ldur            x0, [fp, #-0x10]
    // 0x61c134: LoadField: r2 = r0->field_f
    //     0x61c134: ldur            w2, [x0, #0xf]
    // 0x61c138: DecompressPointer r2
    //     0x61c138: add             x2, x2, HEAP, lsl #32
    // 0x61c13c: LoadField: r0 = r2->field_b
    //     0x61c13c: ldur            w0, [x2, #0xb]
    // 0x61c140: DecompressPointer r0
    //     0x61c140: add             x0, x0, HEAP, lsl #32
    // 0x61c144: cmp             w0, NULL
    // 0x61c148: b.eq            #0x61c1b0
    // 0x61c14c: LoadField: r2 = r0->field_2f
    //     0x61c14c: ldur            w2, [x0, #0x2f]
    // 0x61c150: DecompressPointer r2
    //     0x61c150: add             x2, x2, HEAP, lsl #32
    // 0x61c154: str             x2, [SP]
    // 0x61c158: mov             x0, x2
    // 0x61c15c: ClosureCall
    //     0x61c15c: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x61c160: ldur            x2, [x0, #0x1f]
    //     0x61c164: blr             x2
    // 0x61c168: ldur            x0, [fp, #-0x18]
    // 0x61c16c: LoadField: r1 = r0->field_f
    //     0x61c16c: ldur            w1, [x0, #0xf]
    // 0x61c170: DecompressPointer r1
    //     0x61c170: add             x1, x1, HEAP, lsl #32
    // 0x61c174: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61c174: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61c178: r0 = of()
    //     0x61c178: bl              #0x438790  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x61c17c: r16 = <Object?>
    //     0x61c17c: ldr             x16, [PP, #0xb30]  ; [pp+0xb30] TypeArguments: <Object?>
    // 0x61c180: stp             x0, x16, [SP]
    // 0x61c184: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x61c184: ldr             x4, [PP, #0x928]  ; [pp+0x928] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x61c188: r0 = pop()
    //     0x61c188: bl              #0x38447c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x61c18c: r0 = Null
    //     0x61c18c: mov             x0, NULL
    // 0x61c190: LeaveFrame
    //     0x61c190: mov             SP, fp
    //     0x61c194: ldp             fp, lr, [SP], #0x10
    // 0x61c198: ret
    //     0x61c198: ret             
    // 0x61c19c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61c19c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61c1a0: b               #0x61c010
    // 0x61c1a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61c1a4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61c1a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61c1a8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61c1ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61c1ac: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61c1b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61c1b0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] List<Widget> makeQuestText(dynamic) {
    // ** addr: 0x61c1b4, size: 0x430
    // 0x61c1b4: EnterFrame
    //     0x61c1b4: stp             fp, lr, [SP, #-0x10]!
    //     0x61c1b8: mov             fp, SP
    // 0x61c1bc: AllocStack(0x30)
    //     0x61c1bc: sub             SP, SP, #0x30
    // 0x61c1c0: SetupParameters([dynamic _ /* r0 */])
    //     0x61c1c0: ldr             x0, [fp, #0x10]
    //     0x61c1c4: ldur            w2, [x0, #0x17]
    //     0x61c1c8: add             x2, x2, HEAP, lsl #32
    //     0x61c1cc: stur            x2, [fp, #-8]
    // 0x61c1d0: CheckStackOverflow
    //     0x61c1d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61c1d4: cmp             SP, x16
    //     0x61c1d8: b.ls            #0x61c5dc
    // 0x61c1dc: LoadField: r1 = r2->field_f
    //     0x61c1dc: ldur            w1, [x2, #0xf]
    // 0x61c1e0: DecompressPointer r1
    //     0x61c1e0: add             x1, x1, HEAP, lsl #32
    // 0x61c1e4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x61c1e4: ldur            w0, [x1, #0x17]
    // 0x61c1e8: DecompressPointer r0
    //     0x61c1e8: add             x0, x0, HEAP, lsl #32
    // 0x61c1ec: LoadField: r3 = r0->field_7
    //     0x61c1ec: ldur            x3, [x0, #7]
    // 0x61c1f0: cmp             x3, #2
    // 0x61c1f4: b.gt            #0x61c3ac
    // 0x61c1f8: cmp             x3, #1
    // 0x61c1fc: b.gt            #0x61c224
    // 0x61c200: mov             x5, x2
    // 0x61c204: r6 = true
    //     0x61c204: add             x6, NULL, #0x20  ; true
    // 0x61c208: r0 = Instance_TextAlign
    //     0x61c208: ldr             x0, [PP, #0x6998]  ; [pp+0x6998] Obj!TextAlign@865401
    // 0x61c20c: r3 = const [Instance of 'FontFeature']
    //     0x61c20c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c2c8] List<FontFeature>(1)
    //     0x61c210: ldr             x3, [x3, #0x2c8]
    // 0x61c214: r4 = Instance_FlexFit
    //     0x61c214: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a050] Obj!FlexFit@862ac1
    //     0x61c218: ldr             x4, [x4, #0x50]
    // 0x61c21c: r2 = 1
    //     0x61c21c: movz            x2, #0x1
    // 0x61c220: b               #0x61c3cc
    // 0x61c224: r0 = getLeftText()
    //     0x61c224: bl              #0x61ca58  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getLeftText
    // 0x61c228: mov             x1, x0
    // 0x61c22c: ldur            x0, [fp, #-8]
    // 0x61c230: stur            x1, [fp, #-0x18]
    // 0x61c234: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x61c234: ldur            w2, [x0, #0x17]
    // 0x61c238: DecompressPointer r2
    //     0x61c238: add             x2, x2, HEAP, lsl #32
    // 0x61c23c: stur            x2, [fp, #-0x10]
    // 0x61c240: r0 = TextStyle()
    //     0x61c240: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x61c244: mov             x1, x0
    // 0x61c248: r0 = true
    //     0x61c248: add             x0, NULL, #0x20  ; true
    // 0x61c24c: stur            x1, [fp, #-0x20]
    // 0x61c250: StoreField: r1->field_7 = r0
    //     0x61c250: stur            w0, [x1, #7]
    // 0x61c254: ldur            x2, [fp, #-0x10]
    // 0x61c258: StoreField: r1->field_b = r2
    //     0x61c258: stur            w2, [x1, #0xb]
    // 0x61c25c: r0 = Text()
    //     0x61c25c: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61c260: mov             x2, x0
    // 0x61c264: ldur            x0, [fp, #-0x18]
    // 0x61c268: stur            x2, [fp, #-0x28]
    // 0x61c26c: StoreField: r2->field_b = r0
    //     0x61c26c: stur            w0, [x2, #0xb]
    // 0x61c270: ldur            x0, [fp, #-0x20]
    // 0x61c274: StoreField: r2->field_13 = r0
    //     0x61c274: stur            w0, [x2, #0x13]
    // 0x61c278: ldur            x0, [fp, #-8]
    // 0x61c27c: LoadField: r1 = r0->field_f
    //     0x61c27c: ldur            w1, [x0, #0xf]
    // 0x61c280: DecompressPointer r1
    //     0x61c280: add             x1, x1, HEAP, lsl #32
    // 0x61c284: r0 = getCenterText()
    //     0x61c284: bl              #0x61c5e4  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getCenterText
    // 0x61c288: stur            x0, [fp, #-0x18]
    // 0x61c28c: r0 = TextStyle()
    //     0x61c28c: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x61c290: mov             x1, x0
    // 0x61c294: r0 = true
    //     0x61c294: add             x0, NULL, #0x20  ; true
    // 0x61c298: stur            x1, [fp, #-0x20]
    // 0x61c29c: StoreField: r1->field_7 = r0
    //     0x61c29c: stur            w0, [x1, #7]
    // 0x61c2a0: ldur            x2, [fp, #-0x10]
    // 0x61c2a4: StoreField: r1->field_b = r2
    //     0x61c2a4: stur            w2, [x1, #0xb]
    // 0x61c2a8: r3 = const [Instance of 'FontFeature']
    //     0x61c2a8: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c2c8] List<FontFeature>(1)
    //     0x61c2ac: ldr             x3, [x3, #0x2c8]
    // 0x61c2b0: StoreField: r1->field_63 = r3
    //     0x61c2b0: stur            w3, [x1, #0x63]
    // 0x61c2b4: r0 = Text()
    //     0x61c2b4: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61c2b8: mov             x2, x0
    // 0x61c2bc: ldur            x0, [fp, #-0x18]
    // 0x61c2c0: stur            x2, [fp, #-0x30]
    // 0x61c2c4: StoreField: r2->field_b = r0
    //     0x61c2c4: stur            w0, [x2, #0xb]
    // 0x61c2c8: ldur            x0, [fp, #-0x20]
    // 0x61c2cc: StoreField: r2->field_13 = r0
    //     0x61c2cc: stur            w0, [x2, #0x13]
    // 0x61c2d0: r0 = Instance_TextAlign
    //     0x61c2d0: ldr             x0, [PP, #0x6998]  ; [pp+0x6998] Obj!TextAlign@865401
    // 0x61c2d4: StoreField: r2->field_1b = r0
    //     0x61c2d4: stur            w0, [x2, #0x1b]
    // 0x61c2d8: r1 = <FlexParentData>
    //     0x61c2d8: add             x1, PP, #0x19, lsl #12  ; [pp+0x191f0] TypeArguments: <FlexParentData>
    //     0x61c2dc: ldr             x1, [x1, #0x1f0]
    // 0x61c2e0: r0 = Flexible()
    //     0x61c2e0: bl              #0x59ff8c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x61c2e4: r2 = 1
    //     0x61c2e4: movz            x2, #0x1
    // 0x61c2e8: stur            x0, [fp, #-0x18]
    // 0x61c2ec: StoreField: r0->field_13 = r2
    //     0x61c2ec: stur            x2, [x0, #0x13]
    // 0x61c2f0: r4 = Instance_FlexFit
    //     0x61c2f0: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a050] Obj!FlexFit@862ac1
    //     0x61c2f4: ldr             x4, [x4, #0x50]
    // 0x61c2f8: StoreField: r0->field_1b = r4
    //     0x61c2f8: stur            w4, [x0, #0x1b]
    // 0x61c2fc: ldur            x1, [fp, #-0x30]
    // 0x61c300: StoreField: r0->field_b = r1
    //     0x61c300: stur            w1, [x0, #0xb]
    // 0x61c304: ldur            x5, [fp, #-8]
    // 0x61c308: LoadField: r1 = r5->field_f
    //     0x61c308: ldur            w1, [x5, #0xf]
    // 0x61c30c: DecompressPointer r1
    //     0x61c30c: add             x1, x1, HEAP, lsl #32
    // 0x61c310: r0 = getRightText()
    //     0x61c310: bl              #0x61a9f4  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getRightText
    // 0x61c314: stur            x0, [fp, #-0x20]
    // 0x61c318: r0 = TextStyle()
    //     0x61c318: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x61c31c: r6 = true
    //     0x61c31c: add             x6, NULL, #0x20  ; true
    // 0x61c320: stur            x0, [fp, #-0x30]
    // 0x61c324: StoreField: r0->field_7 = r6
    //     0x61c324: stur            w6, [x0, #7]
    // 0x61c328: ldur            x1, [fp, #-0x10]
    // 0x61c32c: StoreField: r0->field_b = r1
    //     0x61c32c: stur            w1, [x0, #0xb]
    // 0x61c330: r0 = Text()
    //     0x61c330: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61c334: mov             x3, x0
    // 0x61c338: ldur            x0, [fp, #-0x20]
    // 0x61c33c: stur            x3, [fp, #-0x10]
    // 0x61c340: StoreField: r3->field_b = r0
    //     0x61c340: stur            w0, [x3, #0xb]
    // 0x61c344: ldur            x0, [fp, #-0x30]
    // 0x61c348: StoreField: r3->field_13 = r0
    //     0x61c348: stur            w0, [x3, #0x13]
    // 0x61c34c: r1 = Null
    //     0x61c34c: mov             x1, NULL
    // 0x61c350: r2 = 8
    //     0x61c350: movz            x2, #0x8
    // 0x61c354: r0 = AllocateArray()
    //     0x61c354: bl              #0x82746c  ; AllocateArrayStub
    // 0x61c358: stur            x0, [fp, #-0x20]
    // 0x61c35c: r16 = Instance_SizedBox
    //     0x61c35c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a800] Obj!SizedBox@85d3e1
    //     0x61c360: ldr             x16, [x16, #0x800]
    // 0x61c364: StoreField: r0->field_f = r16
    //     0x61c364: stur            w16, [x0, #0xf]
    // 0x61c368: ldur            x1, [fp, #-0x28]
    // 0x61c36c: StoreField: r0->field_13 = r1
    //     0x61c36c: stur            w1, [x0, #0x13]
    // 0x61c370: ldur            x1, [fp, #-0x18]
    // 0x61c374: ArrayStore: r0[0] = r1  ; List_4
    //     0x61c374: stur            w1, [x0, #0x17]
    // 0x61c378: ldur            x1, [fp, #-0x10]
    // 0x61c37c: StoreField: r0->field_1b = r1
    //     0x61c37c: stur            w1, [x0, #0x1b]
    // 0x61c380: r1 = <Widget>
    //     0x61c380: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x61c384: r0 = AllocateGrowableArray()
    //     0x61c384: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x61c388: mov             x1, x0
    // 0x61c38c: ldur            x0, [fp, #-0x20]
    // 0x61c390: StoreField: r1->field_f = r0
    //     0x61c390: stur            w0, [x1, #0xf]
    // 0x61c394: r0 = 8
    //     0x61c394: movz            x0, #0x8
    // 0x61c398: StoreField: r1->field_b = r0
    //     0x61c398: stur            w0, [x1, #0xb]
    // 0x61c39c: mov             x0, x1
    // 0x61c3a0: LeaveFrame
    //     0x61c3a0: mov             SP, fp
    //     0x61c3a4: ldp             fp, lr, [SP], #0x10
    // 0x61c3a8: ret
    //     0x61c3a8: ret             
    // 0x61c3ac: mov             x5, x2
    // 0x61c3b0: r6 = true
    //     0x61c3b0: add             x6, NULL, #0x20  ; true
    // 0x61c3b4: r0 = Instance_TextAlign
    //     0x61c3b4: ldr             x0, [PP, #0x6998]  ; [pp+0x6998] Obj!TextAlign@865401
    // 0x61c3b8: r3 = const [Instance of 'FontFeature']
    //     0x61c3b8: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c2c8] List<FontFeature>(1)
    //     0x61c3bc: ldr             x3, [x3, #0x2c8]
    // 0x61c3c0: r4 = Instance_FlexFit
    //     0x61c3c0: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a050] Obj!FlexFit@862ac1
    //     0x61c3c4: ldr             x4, [x4, #0x50]
    // 0x61c3c8: r2 = 1
    //     0x61c3c8: movz            x2, #0x1
    // 0x61c3cc: r0 = getLeftText()
    //     0x61c3cc: bl              #0x61ca58  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getLeftText
    // 0x61c3d0: mov             x1, x0
    // 0x61c3d4: ldur            x0, [fp, #-8]
    // 0x61c3d8: stur            x1, [fp, #-0x18]
    // 0x61c3dc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x61c3dc: ldur            w2, [x0, #0x17]
    // 0x61c3e0: DecompressPointer r2
    //     0x61c3e0: add             x2, x2, HEAP, lsl #32
    // 0x61c3e4: stur            x2, [fp, #-0x10]
    // 0x61c3e8: r0 = TextStyle()
    //     0x61c3e8: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x61c3ec: mov             x1, x0
    // 0x61c3f0: r0 = true
    //     0x61c3f0: add             x0, NULL, #0x20  ; true
    // 0x61c3f4: stur            x1, [fp, #-0x20]
    // 0x61c3f8: StoreField: r1->field_7 = r0
    //     0x61c3f8: stur            w0, [x1, #7]
    // 0x61c3fc: ldur            x2, [fp, #-0x10]
    // 0x61c400: StoreField: r1->field_b = r2
    //     0x61c400: stur            w2, [x1, #0xb]
    // 0x61c404: r0 = Text()
    //     0x61c404: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61c408: mov             x2, x0
    // 0x61c40c: ldur            x0, [fp, #-0x18]
    // 0x61c410: stur            x2, [fp, #-0x28]
    // 0x61c414: StoreField: r2->field_b = r0
    //     0x61c414: stur            w0, [x2, #0xb]
    // 0x61c418: ldur            x0, [fp, #-0x20]
    // 0x61c41c: StoreField: r2->field_13 = r0
    //     0x61c41c: stur            w0, [x2, #0x13]
    // 0x61c420: ldur            x0, [fp, #-8]
    // 0x61c424: LoadField: r1 = r0->field_f
    //     0x61c424: ldur            w1, [x0, #0xf]
    // 0x61c428: DecompressPointer r1
    //     0x61c428: add             x1, x1, HEAP, lsl #32
    // 0x61c42c: r0 = getCenterText()
    //     0x61c42c: bl              #0x61c5e4  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getCenterText
    // 0x61c430: stur            x0, [fp, #-8]
    // 0x61c434: r0 = TextStyle()
    //     0x61c434: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x61c438: mov             x1, x0
    // 0x61c43c: r0 = true
    //     0x61c43c: add             x0, NULL, #0x20  ; true
    // 0x61c440: stur            x1, [fp, #-0x18]
    // 0x61c444: StoreField: r1->field_7 = r0
    //     0x61c444: stur            w0, [x1, #7]
    // 0x61c448: ldur            x0, [fp, #-0x10]
    // 0x61c44c: StoreField: r1->field_b = r0
    //     0x61c44c: stur            w0, [x1, #0xb]
    // 0x61c450: r0 = const [Instance of 'FontFeature']
    //     0x61c450: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c2c8] List<FontFeature>(1)
    //     0x61c454: ldr             x0, [x0, #0x2c8]
    // 0x61c458: StoreField: r1->field_63 = r0
    //     0x61c458: stur            w0, [x1, #0x63]
    // 0x61c45c: r0 = Text()
    //     0x61c45c: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x61c460: mov             x3, x0
    // 0x61c464: ldur            x0, [fp, #-8]
    // 0x61c468: stur            x3, [fp, #-0x10]
    // 0x61c46c: StoreField: r3->field_b = r0
    //     0x61c46c: stur            w0, [x3, #0xb]
    // 0x61c470: ldur            x0, [fp, #-0x18]
    // 0x61c474: StoreField: r3->field_13 = r0
    //     0x61c474: stur            w0, [x3, #0x13]
    // 0x61c478: r0 = Instance_TextAlign
    //     0x61c478: ldr             x0, [PP, #0x6998]  ; [pp+0x6998] Obj!TextAlign@865401
    // 0x61c47c: StoreField: r3->field_1b = r0
    //     0x61c47c: stur            w0, [x3, #0x1b]
    // 0x61c480: r1 = Null
    //     0x61c480: mov             x1, NULL
    // 0x61c484: r2 = 6
    //     0x61c484: movz            x2, #0x6
    // 0x61c488: r0 = AllocateArray()
    //     0x61c488: bl              #0x82746c  ; AllocateArrayStub
    // 0x61c48c: stur            x0, [fp, #-8]
    // 0x61c490: r16 = Instance_SizedBox
    //     0x61c490: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a800] Obj!SizedBox@85d3e1
    //     0x61c494: ldr             x16, [x16, #0x800]
    // 0x61c498: StoreField: r0->field_f = r16
    //     0x61c498: stur            w16, [x0, #0xf]
    // 0x61c49c: ldur            x1, [fp, #-0x28]
    // 0x61c4a0: StoreField: r0->field_13 = r1
    //     0x61c4a0: stur            w1, [x0, #0x13]
    // 0x61c4a4: ldur            x1, [fp, #-0x10]
    // 0x61c4a8: ArrayStore: r0[0] = r1  ; List_4
    //     0x61c4a8: stur            w1, [x0, #0x17]
    // 0x61c4ac: r1 = <Widget>
    //     0x61c4ac: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x61c4b0: r0 = AllocateGrowableArray()
    //     0x61c4b0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x61c4b4: mov             x1, x0
    // 0x61c4b8: ldur            x0, [fp, #-8]
    // 0x61c4bc: stur            x1, [fp, #-0x10]
    // 0x61c4c0: StoreField: r1->field_f = r0
    //     0x61c4c0: stur            w0, [x1, #0xf]
    // 0x61c4c4: r0 = 6
    //     0x61c4c4: movz            x0, #0x6
    // 0x61c4c8: StoreField: r1->field_b = r0
    //     0x61c4c8: stur            w0, [x1, #0xb]
    // 0x61c4cc: r0 = Row()
    //     0x61c4cc: bl              #0x59e9b8  ; AllocateRowStub -> Row (size=0x38)
    // 0x61c4d0: mov             x1, x0
    // 0x61c4d4: r0 = Instance_Axis
    //     0x61c4d4: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x61c4d8: stur            x1, [fp, #-8]
    // 0x61c4dc: StoreField: r1->field_f = r0
    //     0x61c4dc: stur            w0, [x1, #0xf]
    // 0x61c4e0: r2 = Instance_MainAxisAlignment
    //     0x61c4e0: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x61c4e4: ldr             x2, [x2, #0x200]
    // 0x61c4e8: StoreField: r1->field_13 = r2
    //     0x61c4e8: stur            w2, [x1, #0x13]
    // 0x61c4ec: r2 = Instance_MainAxisSize
    //     0x61c4ec: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x61c4f0: ldr             x2, [x2, #0x70]
    // 0x61c4f4: ArrayStore: r1[0] = r2  ; List_4
    //     0x61c4f4: stur            w2, [x1, #0x17]
    // 0x61c4f8: r2 = Instance_CrossAxisAlignment
    //     0x61c4f8: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x61c4fc: ldr             x2, [x2, #0x78]
    // 0x61c500: StoreField: r1->field_1b = r2
    //     0x61c500: stur            w2, [x1, #0x1b]
    // 0x61c504: r2 = Instance_VerticalDirection
    //     0x61c504: add             x2, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x61c508: ldr             x2, [x2, #0x1e8]
    // 0x61c50c: StoreField: r1->field_23 = r2
    //     0x61c50c: stur            w2, [x1, #0x23]
    // 0x61c510: r2 = Instance_Clip
    //     0x61c510: add             x2, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x61c514: ldr             x2, [x2, #0x1b0]
    // 0x61c518: StoreField: r1->field_2b = r2
    //     0x61c518: stur            w2, [x1, #0x2b]
    // 0x61c51c: StoreField: r1->field_2f = rZR
    //     0x61c51c: stur            xzr, [x1, #0x2f]
    // 0x61c520: ldur            x2, [fp, #-0x10]
    // 0x61c524: StoreField: r1->field_b = r2
    //     0x61c524: stur            w2, [x1, #0xb]
    // 0x61c528: r0 = SingleChildScrollView()
    //     0x61c528: bl              #0x5a4e90  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x61c52c: mov             x2, x0
    // 0x61c530: r0 = Instance_Axis
    //     0x61c530: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x61c534: stur            x2, [fp, #-0x10]
    // 0x61c538: StoreField: r2->field_b = r0
    //     0x61c538: stur            w0, [x2, #0xb]
    // 0x61c53c: r0 = false
    //     0x61c53c: add             x0, NULL, #0x30  ; false
    // 0x61c540: StoreField: r2->field_f = r0
    //     0x61c540: stur            w0, [x2, #0xf]
    // 0x61c544: ldur            x0, [fp, #-8]
    // 0x61c548: StoreField: r2->field_23 = r0
    //     0x61c548: stur            w0, [x2, #0x23]
    // 0x61c54c: r0 = Instance_DragStartBehavior
    //     0x61c54c: ldr             x0, [PP, #0x70b0]  ; [pp+0x70b0] Obj!DragStartBehavior@863b61
    // 0x61c550: StoreField: r2->field_27 = r0
    //     0x61c550: stur            w0, [x2, #0x27]
    // 0x61c554: r0 = Instance_Clip
    //     0x61c554: add             x0, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x61c558: ldr             x0, [x0, #0x900]
    // 0x61c55c: StoreField: r2->field_2b = r0
    //     0x61c55c: stur            w0, [x2, #0x2b]
    // 0x61c560: r0 = Instance_HitTestBehavior
    //     0x61c560: add             x0, PP, #0xc, lsl #12  ; [pp+0xc9a8] Obj!HitTestBehavior@8628c1
    //     0x61c564: ldr             x0, [x0, #0x9a8]
    // 0x61c568: StoreField: r2->field_2f = r0
    //     0x61c568: stur            w0, [x2, #0x2f]
    // 0x61c56c: r1 = <FlexParentData>
    //     0x61c56c: add             x1, PP, #0x19, lsl #12  ; [pp+0x191f0] TypeArguments: <FlexParentData>
    //     0x61c570: ldr             x1, [x1, #0x1f0]
    // 0x61c574: r0 = Flexible()
    //     0x61c574: bl              #0x59ff8c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x61c578: mov             x3, x0
    // 0x61c57c: r0 = 1
    //     0x61c57c: movz            x0, #0x1
    // 0x61c580: stur            x3, [fp, #-8]
    // 0x61c584: StoreField: r3->field_13 = r0
    //     0x61c584: stur            x0, [x3, #0x13]
    // 0x61c588: r0 = Instance_FlexFit
    //     0x61c588: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a050] Obj!FlexFit@862ac1
    //     0x61c58c: ldr             x0, [x0, #0x50]
    // 0x61c590: StoreField: r3->field_1b = r0
    //     0x61c590: stur            w0, [x3, #0x1b]
    // 0x61c594: ldur            x0, [fp, #-0x10]
    // 0x61c598: StoreField: r3->field_b = r0
    //     0x61c598: stur            w0, [x3, #0xb]
    // 0x61c59c: r1 = Null
    //     0x61c59c: mov             x1, NULL
    // 0x61c5a0: r2 = 2
    //     0x61c5a0: movz            x2, #0x2
    // 0x61c5a4: r0 = AllocateArray()
    //     0x61c5a4: bl              #0x82746c  ; AllocateArrayStub
    // 0x61c5a8: mov             x2, x0
    // 0x61c5ac: ldur            x0, [fp, #-8]
    // 0x61c5b0: stur            x2, [fp, #-0x10]
    // 0x61c5b4: StoreField: r2->field_f = r0
    //     0x61c5b4: stur            w0, [x2, #0xf]
    // 0x61c5b8: r1 = <Widget>
    //     0x61c5b8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x61c5bc: r0 = AllocateGrowableArray()
    //     0x61c5bc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x61c5c0: ldur            x1, [fp, #-0x10]
    // 0x61c5c4: StoreField: r0->field_f = r1
    //     0x61c5c4: stur            w1, [x0, #0xf]
    // 0x61c5c8: r1 = 2
    //     0x61c5c8: movz            x1, #0x2
    // 0x61c5cc: StoreField: r0->field_b = r1
    //     0x61c5cc: stur            w1, [x0, #0xb]
    // 0x61c5d0: LeaveFrame
    //     0x61c5d0: mov             SP, fp
    //     0x61c5d4: ldp             fp, lr, [SP], #0x10
    // 0x61c5d8: ret
    //     0x61c5d8: ret             
    // 0x61c5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61c5dc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61c5e0: b               #0x61c1dc
  }
  _ getCenterText(/* No info */) {
    // ** addr: 0x61c5e4, size: 0x474
    // 0x61c5e4: EnterFrame
    //     0x61c5e4: stp             fp, lr, [SP, #-0x10]!
    //     0x61c5e8: mov             fp, SP
    // 0x61c5ec: AllocStack(0x48)
    //     0x61c5ec: sub             SP, SP, #0x48
    // 0x61c5f0: SetupParameters(QuestButtonState<C3X0> this /* r1 => r0, fp-0x10 */)
    //     0x61c5f0: mov             x0, x1
    //     0x61c5f4: stur            x1, [fp, #-0x10]
    // 0x61c5f8: CheckStackOverflow
    //     0x61c5f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61c5fc: cmp             SP, x16
    //     0x61c600: b.ls            #0x61ca3c
    // 0x61c604: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x61c604: ldur            w1, [x0, #0x17]
    // 0x61c608: DecompressPointer r1
    //     0x61c608: add             x1, x1, HEAP, lsl #32
    // 0x61c60c: LoadField: r2 = r1->field_7
    //     0x61c60c: ldur            x2, [x1, #7]
    // 0x61c610: cmp             x2, #2
    // 0x61c614: b.gt            #0x61c9f4
    // 0x61c618: cmp             x2, #1
    // 0x61c61c: b.le            #0x61ca2c
    // 0x61c620: LoadField: r1 = r0->field_b
    //     0x61c620: ldur            w1, [x0, #0xb]
    // 0x61c624: DecompressPointer r1
    //     0x61c624: add             x1, x1, HEAP, lsl #32
    // 0x61c628: cmp             w1, NULL
    // 0x61c62c: b.eq            #0x61ca44
    // 0x61c630: LoadField: r2 = r1->field_1b
    //     0x61c630: ldur            w2, [x1, #0x1b]
    // 0x61c634: DecompressPointer r2
    //     0x61c634: add             x2, x2, HEAP, lsl #32
    // 0x61c638: mov             x1, x0
    // 0x61c63c: stur            x2, [fp, #-8]
    // 0x61c640: r0 = currentLevelOrLastCompleted()
    //     0x61c640: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61c644: LoadField: r1 = r0->field_f
    //     0x61c644: ldur            w1, [x0, #0xf]
    // 0x61c648: DecompressPointer r1
    //     0x61c648: add             x1, x1, HEAP, lsl #32
    // 0x61c64c: LoadField: r2 = r1->field_b
    //     0x61c64c: ldur            w2, [x1, #0xb]
    // 0x61c650: DecompressPointer r2
    //     0x61c650: add             x2, x2, HEAP, lsl #32
    // 0x61c654: ldur            x1, [fp, #-8]
    // 0x61c658: r0 = _getValueOrData()
    //     0x61c658: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x61c65c: mov             x1, x0
    // 0x61c660: ldur            x0, [fp, #-8]
    // 0x61c664: LoadField: r2 = r0->field_f
    //     0x61c664: ldur            w2, [x0, #0xf]
    // 0x61c668: DecompressPointer r2
    //     0x61c668: add             x2, x2, HEAP, lsl #32
    // 0x61c66c: cmp             w2, w1
    // 0x61c670: b.ne            #0x61c67c
    // 0x61c674: r0 = Null
    //     0x61c674: mov             x0, NULL
    // 0x61c678: b               #0x61c680
    // 0x61c67c: mov             x0, x1
    // 0x61c680: ldur            x1, [fp, #-0x10]
    // 0x61c684: stur            x0, [fp, #-8]
    // 0x61c688: r0 = remainingTime()
    //     0x61c688: bl              #0x61ab1c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::remainingTime
    // 0x61c68c: stur            x0, [fp, #-0x38]
    // 0x61c690: cmp             w0, NULL
    // 0x61c694: b.ne            #0x61c818
    // 0x61c698: ldur            x2, [fp, #-8]
    // 0x61c69c: cmp             w2, NULL
    // 0x61c6a0: b.ne            #0x61c6ac
    // 0x61c6a4: r3 = 0
    //     0x61c6a4: movz            x3, #0
    // 0x61c6a8: b               #0x61c6bc
    // 0x61c6ac: mov             x1, x2
    // 0x61c6b0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61c6b0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61c6b4: r0 = toStringConsistentDecimalPlaces()
    //     0x61c6b4: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x61c6b8: mov             x3, x0
    // 0x61c6bc: ldur            x0, [fp, #-0x10]
    // 0x61c6c0: stur            x3, [fp, #-0x18]
    // 0x61c6c4: r1 = Null
    //     0x61c6c4: mov             x1, NULL
    // 0x61c6c8: r2 = 10
    //     0x61c6c8: movz            x2, #0xa
    // 0x61c6cc: r0 = AllocateArray()
    //     0x61c6cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x61c6d0: mov             x2, x0
    // 0x61c6d4: ldur            x0, [fp, #-0x18]
    // 0x61c6d8: stur            x2, [fp, #-0x20]
    // 0x61c6dc: StoreField: r2->field_f = r0
    //     0x61c6dc: stur            w0, [x2, #0xf]
    // 0x61c6e0: r16 = " / "
    //     0x61c6e0: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c0d0] " / "
    //     0x61c6e4: ldr             x16, [x16, #0xd0]
    // 0x61c6e8: StoreField: r2->field_13 = r16
    //     0x61c6e8: stur            w16, [x2, #0x13]
    // 0x61c6ec: ldur            x1, [fp, #-0x10]
    // 0x61c6f0: r0 = currentLevelOrLastCompleted()
    //     0x61c6f0: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61c6f4: LoadField: r1 = r0->field_f
    //     0x61c6f4: ldur            w1, [x0, #0xf]
    // 0x61c6f8: DecompressPointer r1
    //     0x61c6f8: add             x1, x1, HEAP, lsl #32
    // 0x61c6fc: LoadField: r0 = r1->field_f
    //     0x61c6fc: ldur            w0, [x1, #0xf]
    // 0x61c700: DecompressPointer r0
    //     0x61c700: add             x0, x0, HEAP, lsl #32
    // 0x61c704: cmp             w0, NULL
    // 0x61c708: b.eq            #0x61ca48
    // 0x61c70c: mov             x1, x0
    // 0x61c710: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61c710: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61c714: r0 = toStringConsistentDecimalPlaces()
    //     0x61c714: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x61c718: ldur            x1, [fp, #-0x20]
    // 0x61c71c: ArrayStore: r1[2] = r0  ; List_4
    //     0x61c71c: add             x25, x1, #0x17
    //     0x61c720: str             w0, [x25]
    //     0x61c724: tbz             w0, #0, #0x61c740
    //     0x61c728: ldurb           w16, [x1, #-1]
    //     0x61c72c: ldurb           w17, [x0, #-1]
    //     0x61c730: and             x16, x17, x16, lsr #2
    //     0x61c734: tst             x16, HEAP, lsr #32
    //     0x61c738: b.eq            #0x61c740
    //     0x61c73c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61c740: ldur            x0, [fp, #-0x20]
    // 0x61c744: r16 = " "
    //     0x61c744: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x61c748: StoreField: r0->field_1b = r16
    //     0x61c748: stur            w16, [x0, #0x1b]
    // 0x61c74c: ldur            x2, [fp, #-0x10]
    // 0x61c750: LoadField: r3 = r2->field_b
    //     0x61c750: ldur            w3, [x2, #0xb]
    // 0x61c754: DecompressPointer r3
    //     0x61c754: add             x3, x3, HEAP, lsl #32
    // 0x61c758: stur            x3, [fp, #-0x18]
    // 0x61c75c: cmp             w3, NULL
    // 0x61c760: b.eq            #0x61ca4c
    // 0x61c764: mov             x1, x2
    // 0x61c768: r0 = currentLevelOrLastCompleted()
    //     0x61c768: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61c76c: LoadField: r1 = r0->field_f
    //     0x61c76c: ldur            w1, [x0, #0xf]
    // 0x61c770: DecompressPointer r1
    //     0x61c770: add             x1, x1, HEAP, lsl #32
    // 0x61c774: LoadField: r3 = r1->field_b
    //     0x61c774: ldur            w3, [x1, #0xb]
    // 0x61c778: DecompressPointer r3
    //     0x61c778: add             x3, x3, HEAP, lsl #32
    // 0x61c77c: ldur            x0, [fp, #-0x18]
    // 0x61c780: stur            x3, [fp, #-0x30]
    // 0x61c784: LoadField: r4 = r0->field_f
    //     0x61c784: ldur            w4, [x0, #0xf]
    // 0x61c788: DecompressPointer r4
    //     0x61c788: add             x4, x4, HEAP, lsl #32
    // 0x61c78c: ldur            x5, [fp, #-0x10]
    // 0x61c790: stur            x4, [fp, #-0x28]
    // 0x61c794: LoadField: r2 = r5->field_7
    //     0x61c794: ldur            w2, [x5, #7]
    // 0x61c798: DecompressPointer r2
    //     0x61c798: add             x2, x2, HEAP, lsl #32
    // 0x61c79c: mov             x0, x4
    // 0x61c7a0: r1 = Null
    //     0x61c7a0: mov             x1, NULL
    // 0x61c7a4: r8 = (dynamic this, C3X0?) => String?
    //     0x61c7a4: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x61c7a8: ldr             x8, [x8, #0xe90]
    // 0x61c7ac: LoadField: r9 = r8->field_7
    //     0x61c7ac: ldur            x9, [x8, #7]
    // 0x61c7b0: r3 = Null
    //     0x61c7b0: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c2d0] Null
    //     0x61c7b4: ldr             x3, [x3, #0x2d0]
    // 0x61c7b8: blr             x9
    // 0x61c7bc: ldur            x16, [fp, #-0x28]
    // 0x61c7c0: ldur            lr, [fp, #-0x30]
    // 0x61c7c4: stp             lr, x16, [SP]
    // 0x61c7c8: ldur            x0, [fp, #-0x28]
    // 0x61c7cc: ClosureCall
    //     0x61c7cc: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x61c7d0: ldur            x2, [x0, #0x1f]
    //     0x61c7d4: blr             x2
    // 0x61c7d8: ldur            x1, [fp, #-0x20]
    // 0x61c7dc: ArrayStore: r1[4] = r0  ; List_4
    //     0x61c7dc: add             x25, x1, #0x1f
    //     0x61c7e0: str             w0, [x25]
    //     0x61c7e4: tbz             w0, #0, #0x61c800
    //     0x61c7e8: ldurb           w16, [x1, #-1]
    //     0x61c7ec: ldurb           w17, [x0, #-1]
    //     0x61c7f0: and             x16, x17, x16, lsr #2
    //     0x61c7f4: tst             x16, HEAP, lsr #32
    //     0x61c7f8: b.eq            #0x61c800
    //     0x61c7fc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61c800: ldur            x16, [fp, #-0x20]
    // 0x61c804: str             x16, [SP]
    // 0x61c808: r0 = _interpolate()
    //     0x61c808: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61c80c: LeaveFrame
    //     0x61c80c: mov             SP, fp
    //     0x61c810: ldp             fp, lr, [SP], #0x10
    // 0x61c814: ret
    //     0x61c814: ret             
    // 0x61c818: ldur            x5, [fp, #-0x10]
    // 0x61c81c: ldur            x2, [fp, #-8]
    // 0x61c820: LoadField: r1 = r0->field_7
    //     0x61c820: ldur            x1, [x0, #7]
    // 0x61c824: tbz             x1, #0x3f, #0x61c830
    // 0x61c828: mov             x1, x5
    // 0x61c82c: r0 = endQuest()
    //     0x61c82c: bl              #0x61b878  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::endQuest
    // 0x61c830: ldur            x1, [fp, #-8]
    // 0x61c834: cmp             w1, NULL
    // 0x61c838: b.ne            #0x61c844
    // 0x61c83c: r3 = 0
    //     0x61c83c: movz            x3, #0
    // 0x61c840: b               #0x61c850
    // 0x61c844: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61c844: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61c848: r0 = toStringConsistentDecimalPlaces()
    //     0x61c848: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x61c84c: mov             x3, x0
    // 0x61c850: ldur            x0, [fp, #-0x10]
    // 0x61c854: stur            x3, [fp, #-8]
    // 0x61c858: r1 = Null
    //     0x61c858: mov             x1, NULL
    // 0x61c85c: r2 = 16
    //     0x61c85c: movz            x2, #0x10
    // 0x61c860: r0 = AllocateArray()
    //     0x61c860: bl              #0x82746c  ; AllocateArrayStub
    // 0x61c864: mov             x2, x0
    // 0x61c868: ldur            x0, [fp, #-8]
    // 0x61c86c: stur            x2, [fp, #-0x18]
    // 0x61c870: StoreField: r2->field_f = r0
    //     0x61c870: stur            w0, [x2, #0xf]
    // 0x61c874: r16 = " / "
    //     0x61c874: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c0d0] " / "
    //     0x61c878: ldr             x16, [x16, #0xd0]
    // 0x61c87c: StoreField: r2->field_13 = r16
    //     0x61c87c: stur            w16, [x2, #0x13]
    // 0x61c880: ldur            x1, [fp, #-0x10]
    // 0x61c884: r0 = currentLevelOrLastCompleted()
    //     0x61c884: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61c888: LoadField: r1 = r0->field_f
    //     0x61c888: ldur            w1, [x0, #0xf]
    // 0x61c88c: DecompressPointer r1
    //     0x61c88c: add             x1, x1, HEAP, lsl #32
    // 0x61c890: LoadField: r0 = r1->field_f
    //     0x61c890: ldur            w0, [x1, #0xf]
    // 0x61c894: DecompressPointer r0
    //     0x61c894: add             x0, x0, HEAP, lsl #32
    // 0x61c898: cmp             w0, NULL
    // 0x61c89c: b.eq            #0x61ca50
    // 0x61c8a0: mov             x1, x0
    // 0x61c8a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x61c8a4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x61c8a8: r0 = toStringConsistentDecimalPlaces()
    //     0x61c8a8: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x61c8ac: ldur            x1, [fp, #-0x18]
    // 0x61c8b0: ArrayStore: r1[2] = r0  ; List_4
    //     0x61c8b0: add             x25, x1, #0x17
    //     0x61c8b4: str             w0, [x25]
    //     0x61c8b8: tbz             w0, #0, #0x61c8d4
    //     0x61c8bc: ldurb           w16, [x1, #-1]
    //     0x61c8c0: ldurb           w17, [x0, #-1]
    //     0x61c8c4: and             x16, x17, x16, lsr #2
    //     0x61c8c8: tst             x16, HEAP, lsr #32
    //     0x61c8cc: b.eq            #0x61c8d4
    //     0x61c8d0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61c8d4: ldur            x0, [fp, #-0x18]
    // 0x61c8d8: r16 = " "
    //     0x61c8d8: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x61c8dc: StoreField: r0->field_1b = r16
    //     0x61c8dc: stur            w16, [x0, #0x1b]
    // 0x61c8e0: ldur            x2, [fp, #-0x10]
    // 0x61c8e4: LoadField: r3 = r2->field_b
    //     0x61c8e4: ldur            w3, [x2, #0xb]
    // 0x61c8e8: DecompressPointer r3
    //     0x61c8e8: add             x3, x3, HEAP, lsl #32
    // 0x61c8ec: stur            x3, [fp, #-8]
    // 0x61c8f0: cmp             w3, NULL
    // 0x61c8f4: b.eq            #0x61ca54
    // 0x61c8f8: mov             x1, x2
    // 0x61c8fc: r0 = currentLevelOrLastCompleted()
    //     0x61c8fc: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61c900: LoadField: r1 = r0->field_f
    //     0x61c900: ldur            w1, [x0, #0xf]
    // 0x61c904: DecompressPointer r1
    //     0x61c904: add             x1, x1, HEAP, lsl #32
    // 0x61c908: LoadField: r3 = r1->field_b
    //     0x61c908: ldur            w3, [x1, #0xb]
    // 0x61c90c: DecompressPointer r3
    //     0x61c90c: add             x3, x3, HEAP, lsl #32
    // 0x61c910: ldur            x0, [fp, #-8]
    // 0x61c914: stur            x3, [fp, #-0x28]
    // 0x61c918: LoadField: r4 = r0->field_f
    //     0x61c918: ldur            w4, [x0, #0xf]
    // 0x61c91c: DecompressPointer r4
    //     0x61c91c: add             x4, x4, HEAP, lsl #32
    // 0x61c920: ldur            x0, [fp, #-0x10]
    // 0x61c924: stur            x4, [fp, #-0x20]
    // 0x61c928: LoadField: r2 = r0->field_7
    //     0x61c928: ldur            w2, [x0, #7]
    // 0x61c92c: DecompressPointer r2
    //     0x61c92c: add             x2, x2, HEAP, lsl #32
    // 0x61c930: mov             x0, x4
    // 0x61c934: r1 = Null
    //     0x61c934: mov             x1, NULL
    // 0x61c938: r8 = (dynamic this, C3X0?) => String?
    //     0x61c938: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x61c93c: ldr             x8, [x8, #0xe90]
    // 0x61c940: LoadField: r9 = r8->field_7
    //     0x61c940: ldur            x9, [x8, #7]
    // 0x61c944: r3 = Null
    //     0x61c944: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c2e0] Null
    //     0x61c948: ldr             x3, [x3, #0x2e0]
    // 0x61c94c: blr             x9
    // 0x61c950: ldur            x16, [fp, #-0x20]
    // 0x61c954: ldur            lr, [fp, #-0x28]
    // 0x61c958: stp             lr, x16, [SP]
    // 0x61c95c: ldur            x0, [fp, #-0x20]
    // 0x61c960: ClosureCall
    //     0x61c960: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x61c964: ldur            x2, [x0, #0x1f]
    //     0x61c968: blr             x2
    // 0x61c96c: ldur            x1, [fp, #-0x18]
    // 0x61c970: ArrayStore: r1[4] = r0  ; List_4
    //     0x61c970: add             x25, x1, #0x1f
    //     0x61c974: str             w0, [x25]
    //     0x61c978: tbz             w0, #0, #0x61c994
    //     0x61c97c: ldurb           w16, [x1, #-1]
    //     0x61c980: ldurb           w17, [x0, #-1]
    //     0x61c984: and             x16, x17, x16, lsr #2
    //     0x61c988: tst             x16, HEAP, lsr #32
    //     0x61c98c: b.eq            #0x61c994
    //     0x61c990: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61c994: ldur            x0, [fp, #-0x18]
    // 0x61c998: r16 = " Remaining: ("
    //     0x61c998: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c2f0] " Remaining: ("
    //     0x61c99c: ldr             x16, [x16, #0x2f0]
    // 0x61c9a0: StoreField: r0->field_23 = r16
    //     0x61c9a0: stur            w16, [x0, #0x23]
    // 0x61c9a4: ldur            x1, [fp, #-0x38]
    // 0x61c9a8: r0 = ToStringNoMilliseconds.toStringNoMilliseconds()
    //     0x61c9a8: bl              #0x5a05bc  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::ToStringNoMilliseconds.toStringNoMilliseconds
    // 0x61c9ac: ldur            x1, [fp, #-0x18]
    // 0x61c9b0: ArrayStore: r1[6] = r0  ; List_4
    //     0x61c9b0: add             x25, x1, #0x27
    //     0x61c9b4: str             w0, [x25]
    //     0x61c9b8: tbz             w0, #0, #0x61c9d4
    //     0x61c9bc: ldurb           w16, [x1, #-1]
    //     0x61c9c0: ldurb           w17, [x0, #-1]
    //     0x61c9c4: and             x16, x17, x16, lsr #2
    //     0x61c9c8: tst             x16, HEAP, lsr #32
    //     0x61c9cc: b.eq            #0x61c9d4
    //     0x61c9d0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x61c9d4: ldur            x0, [fp, #-0x18]
    // 0x61c9d8: r16 = ")"
    //     0x61c9d8: ldr             x16, [PP, #0x2228]  ; [pp+0x2228] ")"
    // 0x61c9dc: StoreField: r0->field_2b = r16
    //     0x61c9dc: stur            w16, [x0, #0x2b]
    // 0x61c9e0: str             x0, [SP]
    // 0x61c9e4: r0 = _interpolate()
    //     0x61c9e4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x61c9e8: LeaveFrame
    //     0x61c9e8: mov             SP, fp
    //     0x61c9ec: ldp             fp, lr, [SP], #0x10
    // 0x61c9f0: ret
    //     0x61c9f0: ret             
    // 0x61c9f4: cmp             x2, #3
    // 0x61c9f8: b.gt            #0x61ca2c
    // 0x61c9fc: mov             x1, x0
    // 0x61ca00: r0 = remainingTime()
    //     0x61ca00: bl              #0x61ab1c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::remainingTime
    // 0x61ca04: cmp             w0, NULL
    // 0x61ca08: b.eq            #0x61ca1c
    // 0x61ca0c: LoadField: r1 = r0->field_7
    //     0x61ca0c: ldur            x1, [x0, #7]
    // 0x61ca10: tbz             x1, #0x3f, #0x61ca1c
    // 0x61ca14: ldur            x1, [fp, #-0x10]
    // 0x61ca18: r0 = endQuest()
    //     0x61ca18: bl              #0x61b878  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::endQuest
    // 0x61ca1c: r0 = ""
    //     0x61ca1c: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x61ca20: LeaveFrame
    //     0x61ca20: mov             SP, fp
    //     0x61ca24: ldp             fp, lr, [SP], #0x10
    // 0x61ca28: ret
    //     0x61ca28: ret             
    // 0x61ca2c: r0 = ""
    //     0x61ca2c: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x61ca30: LeaveFrame
    //     0x61ca30: mov             SP, fp
    //     0x61ca34: ldp             fp, lr, [SP], #0x10
    // 0x61ca38: ret
    //     0x61ca38: ret             
    // 0x61ca3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61ca3c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61ca40: b               #0x61c604
    // 0x61ca44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61ca44: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61ca48: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61ca48: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x61ca4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61ca4c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61ca50: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61ca50: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x61ca54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61ca54: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getLeftText(/* No info */) {
    // ** addr: 0x61ca58, size: 0x64
    // 0x61ca58: EnterFrame
    //     0x61ca58: stp             fp, lr, [SP, #-0x10]!
    //     0x61ca5c: mov             fp, SP
    // 0x61ca60: CheckStackOverflow
    //     0x61ca60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61ca64: cmp             SP, x16
    //     0x61ca68: b.ls            #0x61cab4
    // 0x61ca6c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x61ca6c: ldur            w0, [x1, #0x17]
    // 0x61ca70: DecompressPointer r0
    //     0x61ca70: add             x0, x0, HEAP, lsl #32
    // 0x61ca74: LoadField: r2 = r0->field_7
    //     0x61ca74: ldur            x2, [x0, #7]
    // 0x61ca78: cmp             x2, #2
    // 0x61ca7c: b.gt            #0x61ca98
    // 0x61ca80: cmp             x2, #1
    // 0x61ca84: b.le            #0x61ca98
    // 0x61ca88: r0 = ""
    //     0x61ca88: ldr             x0, [PP, #0x100]  ; [pp+0x100] ""
    // 0x61ca8c: LeaveFrame
    //     0x61ca8c: mov             SP, fp
    //     0x61ca90: ldp             fp, lr, [SP], #0x10
    // 0x61ca94: ret
    //     0x61ca94: ret             
    // 0x61ca98: r0 = currentLevelOrLastCompleted()
    //     0x61ca98: bl              #0x61af10  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::currentLevelOrLastCompleted
    // 0x61ca9c: LoadField: r1 = r0->field_13
    //     0x61ca9c: ldur            w1, [x0, #0x13]
    // 0x61caa0: DecompressPointer r1
    //     0x61caa0: add             x1, x1, HEAP, lsl #32
    // 0x61caa4: mov             x0, x1
    // 0x61caa8: LeaveFrame
    //     0x61caa8: mov             SP, fp
    //     0x61caac: ldp             fp, lr, [SP], #0x10
    // 0x61cab0: ret
    //     0x61cab0: ret             
    // 0x61cab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61cab4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61cab8: b               #0x61ca6c
  }
  _ shouldUpdate(/* No info */) {
    // ** addr: 0x734bd8, size: 0x100
    // 0x734bd8: EnterFrame
    //     0x734bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x734bdc: mov             fp, SP
    // 0x734be0: AllocStack(0x8)
    //     0x734be0: sub             SP, SP, #8
    // 0x734be4: SetupParameters(QuestButtonState<C3X0> this /* r1 => r0, fp-0x8 */)
    //     0x734be4: mov             x0, x1
    //     0x734be8: stur            x1, [fp, #-8]
    // 0x734bec: CheckStackOverflow
    //     0x734bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x734bf0: cmp             SP, x16
    //     0x734bf4: b.ls            #0x734ccc
    // 0x734bf8: mov             x1, x0
    // 0x734bfc: r0 = getState()
    //     0x734bfc: bl              #0x61ad7c  ; [package:pretentious/widgets/QuestButton.dart] QuestButtonState::getState
    // 0x734c00: ldur            x2, [fp, #-8]
    // 0x734c04: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x734c04: ldur            w3, [x2, #0x17]
    // 0x734c08: DecompressPointer r3
    //     0x734c08: add             x3, x3, HEAP, lsl #32
    // 0x734c0c: cmp             w0, w3
    // 0x734c10: b.ne            #0x734c9c
    // 0x734c14: LoadField: r4 = r2->field_b
    //     0x734c14: ldur            w4, [x2, #0xb]
    // 0x734c18: DecompressPointer r4
    //     0x734c18: add             x4, x4, HEAP, lsl #32
    // 0x734c1c: cmp             w4, NULL
    // 0x734c20: b.eq            #0x734cd4
    // 0x734c24: LoadField: r2 = r4->field_2b
    //     0x734c24: ldur            w2, [x4, #0x2b]
    // 0x734c28: DecompressPointer r2
    //     0x734c28: add             x2, x2, HEAP, lsl #32
    // 0x734c2c: LoadField: r5 = r2->field_f
    //     0x734c2c: ldur            w5, [x2, #0xf]
    // 0x734c30: DecompressPointer r5
    //     0x734c30: add             x5, x5, HEAP, lsl #32
    // 0x734c34: cmp             w5, NULL
    // 0x734c38: b.eq            #0x734ca4
    // 0x734c3c: LoadField: r5 = r2->field_7
    //     0x734c3c: ldur            w5, [x2, #7]
    // 0x734c40: DecompressPointer r5
    //     0x734c40: add             x5, x5, HEAP, lsl #32
    // 0x734c44: LoadField: r2 = r4->field_23
    //     0x734c44: ldur            x2, [x4, #0x23]
    // 0x734c48: r0 = BoxInt64Instr(r2)
    //     0x734c48: sbfiz           x0, x2, #1, #0x1f
    //     0x734c4c: cmp             x2, x0, asr #1
    //     0x734c50: b.eq            #0x734c5c
    //     0x734c54: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x734c58: stur            x2, [x0, #7]
    // 0x734c5c: cmp             w5, w0
    // 0x734c60: b.eq            #0x734c9c
    // 0x734c64: and             w16, w5, w0
    // 0x734c68: branchIfSmi(r16, 0x734ca4)
    //     0x734c68: tbz             w16, #0, #0x734ca4
    // 0x734c6c: r16 = LoadClassIdInstr(r5)
    //     0x734c6c: ldur            x16, [x5, #-1]
    //     0x734c70: ubfx            x16, x16, #0xc, #0x14
    // 0x734c74: cmp             x16, #0x3d
    // 0x734c78: b.ne            #0x734ca4
    // 0x734c7c: r16 = LoadClassIdInstr(r0)
    //     0x734c7c: ldur            x16, [x0, #-1]
    //     0x734c80: ubfx            x16, x16, #0xc, #0x14
    // 0x734c84: cmp             x16, #0x3d
    // 0x734c88: b.ne            #0x734ca4
    // 0x734c8c: LoadField: r16 = r5->field_7
    //     0x734c8c: ldur            x16, [x5, #7]
    // 0x734c90: LoadField: r17 = r0->field_7
    //     0x734c90: ldur            x17, [x0, #7]
    // 0x734c94: cmp             x16, x17
    // 0x734c98: b.ne            #0x734ca4
    // 0x734c9c: r0 = true
    //     0x734c9c: add             x0, NULL, #0x20  ; true
    // 0x734ca0: b               #0x734cc0
    // 0x734ca4: r16 = Instance_QuestState
    //     0x734ca4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c298] Obj!QuestState@85e981
    //     0x734ca8: ldr             x16, [x16, #0x298]
    // 0x734cac: cmp             w3, w16
    // 0x734cb0: r16 = true
    //     0x734cb0: add             x16, NULL, #0x20  ; true
    // 0x734cb4: r17 = false
    //     0x734cb4: add             x17, NULL, #0x30  ; false
    // 0x734cb8: csel            x1, x16, x17, eq
    // 0x734cbc: mov             x0, x1
    // 0x734cc0: LeaveFrame
    //     0x734cc0: mov             SP, fp
    //     0x734cc4: ldp             fp, lr, [SP], #0x10
    // 0x734cc8: ret
    //     0x734cc8: ret             
    // 0x734ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x734ccc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x734cd0: b               #0x734bf8
    // 0x734cd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x734cd4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4160, size: 0x14, field offset: 0x14
enum QuestState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x725050, size: 0x64
    // 0x725050: EnterFrame
    //     0x725050: stp             fp, lr, [SP, #-0x10]!
    //     0x725054: mov             fp, SP
    // 0x725058: AllocStack(0x10)
    //     0x725058: sub             SP, SP, #0x10
    // 0x72505c: SetupParameters(QuestState this /* r1 => r0, fp-0x8 */)
    //     0x72505c: mov             x0, x1
    //     0x725060: stur            x1, [fp, #-8]
    // 0x725064: CheckStackOverflow
    //     0x725064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x725068: cmp             SP, x16
    //     0x72506c: b.ls            #0x7250ac
    // 0x725070: r1 = Null
    //     0x725070: mov             x1, NULL
    // 0x725074: r2 = 4
    //     0x725074: movz            x2, #0x4
    // 0x725078: r0 = AllocateArray()
    //     0x725078: bl              #0x82746c  ; AllocateArrayStub
    // 0x72507c: r16 = "QuestState."
    //     0x72507c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c220] "QuestState."
    //     0x725080: ldr             x16, [x16, #0x220]
    // 0x725084: StoreField: r0->field_f = r16
    //     0x725084: stur            w16, [x0, #0xf]
    // 0x725088: ldur            x1, [fp, #-8]
    // 0x72508c: LoadField: r2 = r1->field_f
    //     0x72508c: ldur            w2, [x1, #0xf]
    // 0x725090: DecompressPointer r2
    //     0x725090: add             x2, x2, HEAP, lsl #32
    // 0x725094: StoreField: r0->field_13 = r2
    //     0x725094: stur            w2, [x0, #0x13]
    // 0x725098: str             x0, [SP]
    // 0x72509c: r0 = _interpolate()
    //     0x72509c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x7250a0: LeaveFrame
    //     0x7250a0: mov             SP, fp
    //     0x7250a4: ldp             fp, lr, [SP], #0x10
    // 0x7250a8: ret
    //     0x7250a8: ret             
    // 0x7250ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7250ac: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7250b0: b               #0x725070
  }
}
