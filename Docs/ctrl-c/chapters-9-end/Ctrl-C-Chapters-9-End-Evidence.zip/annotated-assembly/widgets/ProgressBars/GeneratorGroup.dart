// lib: , url: package:pretentious/widgets/ProgressBars/GeneratorGroup.dart

// class id: 1049507, size: 0x8
class :: {

  static late StateGroup2 autoButtonGroup; // offset: 0xfb8
  static late StateGroup<void> generatorStateGroup; // offset: 0xfb4

  static StateGroup2 autoButtonGroup() {
    // ** addr: 0x45228c, size: 0x70
    // 0x45228c: EnterFrame
    //     0x45228c: stp             fp, lr, [SP, #-0x10]!
    //     0x452290: mov             fp, SP
    // 0x452294: AllocStack(0x8)
    //     0x452294: sub             SP, SP, #8
    // 0x452298: CheckStackOverflow
    //     0x452298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45229c: cmp             SP, x16
    //     0x4522a0: b.ls            #0x4522f4
    // 0x4522a4: r1 = <SyncState2<StatefulWidget>>
    //     0x4522a4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfc88] TypeArguments: <SyncState2<StatefulWidget>>
    //     0x4522a8: ldr             x1, [x1, #0xc88]
    // 0x4522ac: r0 = _Set()
    //     0x4522ac: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x4522b0: mov             x1, x0
    // 0x4522b4: stur            x0, [fp, #-8]
    // 0x4522b8: r0 = Shader._()
    //     0x4522b8: bl              #0x81c9dc  ; [dart:ui] Shader::Shader._
    // 0x4522bc: ldur            x0, [fp, #-8]
    // 0x4522c0: r1 = _Uint32List
    //     0x4522c0: ldr             x1, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x4522c4: StoreField: r0->field_1b = r1
    //     0x4522c4: stur            w1, [x0, #0x1b]
    // 0x4522c8: StoreField: r0->field_b = rZR
    //     0x4522c8: stur            wzr, [x0, #0xb]
    // 0x4522cc: r1 = const []
    //     0x4522cc: ldr             x1, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x4522d0: StoreField: r0->field_f = r1
    //     0x4522d0: stur            w1, [x0, #0xf]
    // 0x4522d4: StoreField: r0->field_13 = rZR
    //     0x4522d4: stur            wzr, [x0, #0x13]
    // 0x4522d8: ArrayStore: r0[0] = rZR  ; List_4
    //     0x4522d8: stur            wzr, [x0, #0x17]
    // 0x4522dc: r0 = StateGroup2()
    //     0x4522dc: bl              #0x4522fc  ; AllocateStateGroup2Stub -> StateGroup2 (size=0xc)
    // 0x4522e0: ldur            x1, [fp, #-8]
    // 0x4522e4: StoreField: r0->field_7 = r1
    //     0x4522e4: stur            w1, [x0, #7]
    // 0x4522e8: LeaveFrame
    //     0x4522e8: mov             SP, fp
    //     0x4522ec: ldp             fp, lr, [SP], #0x10
    // 0x4522f0: ret
    //     0x4522f0: ret             
    // 0x4522f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4522f4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4522f8: b               #0x4522a4
  }
  static _ getPerSecond(/* No info */) {
    // ** addr: 0x616a68, size: 0x70
    // 0x616a68: EnterFrame
    //     0x616a68: stp             fp, lr, [SP, #-0x10]!
    //     0x616a6c: mov             fp, SP
    // 0x616a70: AllocStack(0x10)
    //     0x616a70: sub             SP, SP, #0x10
    // 0x616a74: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x616a74: mov             x0, x1
    //     0x616a78: stur            x1, [fp, #-8]
    // 0x616a7c: CheckStackOverflow
    //     0x616a7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616a80: cmp             SP, x16
    //     0x616a84: b.ls            #0x616ad0
    // 0x616a88: r1 = Null
    //     0x616a88: mov             x1, NULL
    // 0x616a8c: r2 = 4
    //     0x616a8c: movz            x2, #0x4
    // 0x616a90: r0 = AllocateArray()
    //     0x616a90: bl              #0x82746c  ; AllocateArrayStub
    // 0x616a94: r16 = "per_second_"
    //     0x616a94: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c830] "per_second_"
    //     0x616a98: ldr             x16, [x16, #0x830]
    // 0x616a9c: StoreField: r0->field_f = r16
    //     0x616a9c: stur            w16, [x0, #0xf]
    // 0x616aa0: ldur            x1, [fp, #-8]
    // 0x616aa4: StoreField: r0->field_13 = r1
    //     0x616aa4: stur            w1, [x0, #0x13]
    // 0x616aa8: str             x0, [SP]
    // 0x616aac: r0 = _interpolate()
    //     0x616aac: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616ab0: mov             x1, x0
    // 0x616ab4: r0 = prefsGetBool()
    //     0x616ab4: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x616ab8: cmp             w0, NULL
    // 0x616abc: b.ne            #0x616ac4
    // 0x616ac0: r0 = false
    //     0x616ac0: add             x0, NULL, #0x30  ; false
    // 0x616ac4: LeaveFrame
    //     0x616ac4: mov             SP, fp
    //     0x616ac8: ldp             fp, lr, [SP], #0x10
    // 0x616acc: ret
    //     0x616acc: ret             
    // 0x616ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616ad0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616ad4: b               #0x616a88
  }
  static _ getBuyOption(/* No info */) {
    // ** addr: 0x616ad8, size: 0xac
    // 0x616ad8: EnterFrame
    //     0x616ad8: stp             fp, lr, [SP, #-0x10]!
    //     0x616adc: mov             fp, SP
    // 0x616ae0: AllocStack(0x10)
    //     0x616ae0: sub             SP, SP, #0x10
    // 0x616ae4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x616ae4: mov             x0, x1
    //     0x616ae8: stur            x1, [fp, #-8]
    // 0x616aec: CheckStackOverflow
    //     0x616aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616af0: cmp             SP, x16
    //     0x616af4: b.ls            #0x616b78
    // 0x616af8: r1 = Null
    //     0x616af8: mov             x1, NULL
    // 0x616afc: r2 = 4
    //     0x616afc: movz            x2, #0x4
    // 0x616b00: r0 = AllocateArray()
    //     0x616b00: bl              #0x82746c  ; AllocateArrayStub
    // 0x616b04: r16 = "buy_option_"
    //     0x616b04: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c818] "buy_option_"
    //     0x616b08: ldr             x16, [x16, #0x818]
    // 0x616b0c: StoreField: r0->field_f = r16
    //     0x616b0c: stur            w16, [x0, #0xf]
    // 0x616b10: ldur            x1, [fp, #-8]
    // 0x616b14: StoreField: r0->field_13 = r1
    //     0x616b14: stur            w1, [x0, #0x13]
    // 0x616b18: str             x0, [SP]
    // 0x616b1c: r0 = _interpolate()
    //     0x616b1c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616b20: mov             x1, x0
    // 0x616b24: r0 = prefsGetInt()
    //     0x616b24: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x616b28: cmp             w0, NULL
    // 0x616b2c: b.ne            #0x616b38
    // 0x616b30: r3 = 0
    //     0x616b30: movz            x3, #0
    // 0x616b34: b               #0x616b48
    // 0x616b38: r2 = LoadInt32Instr(r0)
    //     0x616b38: sbfx            x2, x0, #1, #0x1f
    //     0x616b3c: tbz             w0, #0, #0x616b44
    //     0x616b40: ldur            x2, [x0, #7]
    // 0x616b44: mov             x3, x2
    // 0x616b48: r2 = const [Instance of 'BuyOption', Instance of 'BuyOption', Instance of 'BuyOption']
    //     0x616b48: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c838] List<BuyOption>(3)
    //     0x616b4c: ldr             x2, [x2, #0x838]
    // 0x616b50: mov             x1, x3
    // 0x616b54: r0 = 3
    //     0x616b54: movz            x0, #0x3
    // 0x616b58: cmp             x1, x0
    // 0x616b5c: b.hs            #0x616b80
    // 0x616b60: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0x616b60: add             x16, x2, x3, lsl #2
    //     0x616b64: ldur            w0, [x16, #0xf]
    // 0x616b68: DecompressPointer r0
    //     0x616b68: add             x0, x0, HEAP, lsl #32
    // 0x616b6c: LeaveFrame
    //     0x616b6c: mov             SP, fp
    //     0x616b70: ldp             fp, lr, [SP], #0x10
    // 0x616b74: ret
    //     0x616b74: ret             
    // 0x616b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616b78: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616b7c: b               #0x616af8
    // 0x616b80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x616b80: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ cycleBuyOption(/* No info */) {
    // ** addr: 0x616c64, size: 0x1b0
    // 0x616c64: EnterFrame
    //     0x616c64: stp             fp, lr, [SP, #-0x10]!
    //     0x616c68: mov             fp, SP
    // 0x616c6c: AllocStack(0x20)
    //     0x616c6c: sub             SP, SP, #0x20
    // 0x616c70: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x616c70: mov             x3, x1
    //     0x616c74: mov             x0, x2
    //     0x616c78: stur            x1, [fp, #-8]
    //     0x616c7c: stur            x2, [fp, #-0x10]
    // 0x616c80: CheckStackOverflow
    //     0x616c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616c84: cmp             SP, x16
    //     0x616c88: b.ls            #0x616dfc
    // 0x616c8c: r1 = Null
    //     0x616c8c: mov             x1, NULL
    // 0x616c90: r2 = 4
    //     0x616c90: movz            x2, #0x4
    // 0x616c94: r0 = AllocateArray()
    //     0x616c94: bl              #0x82746c  ; AllocateArrayStub
    // 0x616c98: r16 = "buy_option_"
    //     0x616c98: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c818] "buy_option_"
    //     0x616c9c: ldr             x16, [x16, #0x818]
    // 0x616ca0: StoreField: r0->field_f = r16
    //     0x616ca0: stur            w16, [x0, #0xf]
    // 0x616ca4: ldur            x1, [fp, #-8]
    // 0x616ca8: StoreField: r0->field_13 = r1
    //     0x616ca8: stur            w1, [x0, #0x13]
    // 0x616cac: str             x0, [SP]
    // 0x616cb0: r0 = _interpolate()
    //     0x616cb0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616cb4: r1 = Null
    //     0x616cb4: mov             x1, NULL
    // 0x616cb8: r2 = 4
    //     0x616cb8: movz            x2, #0x4
    // 0x616cbc: stur            x0, [fp, #-0x18]
    // 0x616cc0: r0 = AllocateArray()
    //     0x616cc0: bl              #0x82746c  ; AllocateArrayStub
    // 0x616cc4: r16 = "buy_option_"
    //     0x616cc4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c818] "buy_option_"
    //     0x616cc8: ldr             x16, [x16, #0x818]
    // 0x616ccc: StoreField: r0->field_f = r16
    //     0x616ccc: stur            w16, [x0, #0xf]
    // 0x616cd0: ldur            x1, [fp, #-8]
    // 0x616cd4: StoreField: r0->field_13 = r1
    //     0x616cd4: stur            w1, [x0, #0x13]
    // 0x616cd8: str             x0, [SP]
    // 0x616cdc: r0 = _interpolate()
    //     0x616cdc: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616ce0: mov             x1, x0
    // 0x616ce4: r0 = prefsGetInt()
    //     0x616ce4: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x616ce8: cmp             w0, NULL
    // 0x616cec: b.ne            #0x616cf8
    // 0x616cf0: r1 = 0
    //     0x616cf0: movz            x1, #0
    // 0x616cf4: b               #0x616d04
    // 0x616cf8: r1 = LoadInt32Instr(r0)
    //     0x616cf8: sbfx            x1, x0, #1, #0x1f
    //     0x616cfc: tbz             w0, #0, #0x616d04
    //     0x616d00: ldur            x1, [x0, #7]
    // 0x616d04: ldur            x0, [fp, #-0x10]
    // 0x616d08: r3 = 3
    //     0x616d08: movz            x3, #0x3
    // 0x616d0c: add             x2, x1, #1
    // 0x616d10: sdiv            x4, x2, x3
    // 0x616d14: msub            x1, x4, x3, x2
    // 0x616d18: cmp             x1, xzr
    // 0x616d1c: b.lt            #0x616e04
    // 0x616d20: mov             x2, x1
    // 0x616d24: ldur            x1, [fp, #-0x18]
    // 0x616d28: r0 = prefsSetInt()
    //     0x616d28: bl              #0x35e50c  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetInt
    // 0x616d2c: ldur            x0, [fp, #-0x10]
    // 0x616d30: tbz             w0, #4, #0x616dec
    // 0x616d34: ldur            x1, [fp, #-8]
    // 0x616d38: r0 = getBuyOption()
    //     0x616d38: bl              #0x616ad8  ; [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] ::getBuyOption
    // 0x616d3c: r16 = Instance_BuyOption
    //     0x616d3c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c820] Obj!BuyOption@85ea01
    //     0x616d40: ldr             x16, [x16, #0x820]
    // 0x616d44: cmp             w0, w16
    // 0x616d48: b.ne            #0x616dec
    // 0x616d4c: ldur            x0, [fp, #-8]
    // 0x616d50: r1 = Null
    //     0x616d50: mov             x1, NULL
    // 0x616d54: r2 = 4
    //     0x616d54: movz            x2, #0x4
    // 0x616d58: r0 = AllocateArray()
    //     0x616d58: bl              #0x82746c  ; AllocateArrayStub
    // 0x616d5c: r16 = "buy_option_"
    //     0x616d5c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c818] "buy_option_"
    //     0x616d60: ldr             x16, [x16, #0x818]
    // 0x616d64: StoreField: r0->field_f = r16
    //     0x616d64: stur            w16, [x0, #0xf]
    // 0x616d68: ldur            x1, [fp, #-8]
    // 0x616d6c: StoreField: r0->field_13 = r1
    //     0x616d6c: stur            w1, [x0, #0x13]
    // 0x616d70: str             x0, [SP]
    // 0x616d74: r0 = _interpolate()
    //     0x616d74: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616d78: r1 = Null
    //     0x616d78: mov             x1, NULL
    // 0x616d7c: r2 = 4
    //     0x616d7c: movz            x2, #0x4
    // 0x616d80: stur            x0, [fp, #-0x10]
    // 0x616d84: r0 = AllocateArray()
    //     0x616d84: bl              #0x82746c  ; AllocateArrayStub
    // 0x616d88: r16 = "buy_option_"
    //     0x616d88: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c818] "buy_option_"
    //     0x616d8c: ldr             x16, [x16, #0x818]
    // 0x616d90: StoreField: r0->field_f = r16
    //     0x616d90: stur            w16, [x0, #0xf]
    // 0x616d94: ldur            x1, [fp, #-8]
    // 0x616d98: StoreField: r0->field_13 = r1
    //     0x616d98: stur            w1, [x0, #0x13]
    // 0x616d9c: str             x0, [SP]
    // 0x616da0: r0 = _interpolate()
    //     0x616da0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616da4: mov             x1, x0
    // 0x616da8: r0 = prefsGetInt()
    //     0x616da8: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x616dac: cmp             w0, NULL
    // 0x616db0: b.ne            #0x616dbc
    // 0x616db4: r1 = 0
    //     0x616db4: movz            x1, #0
    // 0x616db8: b               #0x616dc8
    // 0x616dbc: r1 = LoadInt32Instr(r0)
    //     0x616dbc: sbfx            x1, x0, #1, #0x1f
    //     0x616dc0: tbz             w0, #0, #0x616dc8
    //     0x616dc4: ldur            x1, [x0, #7]
    // 0x616dc8: r0 = 3
    //     0x616dc8: movz            x0, #0x3
    // 0x616dcc: add             x2, x1, #1
    // 0x616dd0: sdiv            x3, x2, x0
    // 0x616dd4: msub            x1, x3, x0, x2
    // 0x616dd8: cmp             x1, xzr
    // 0x616ddc: b.lt            #0x616e0c
    // 0x616de0: mov             x2, x1
    // 0x616de4: ldur            x1, [fp, #-0x10]
    // 0x616de8: r0 = prefsSetInt()
    //     0x616de8: bl              #0x35e50c  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetInt
    // 0x616dec: r0 = Null
    //     0x616dec: mov             x0, NULL
    // 0x616df0: LeaveFrame
    //     0x616df0: mov             SP, fp
    //     0x616df4: ldp             fp, lr, [SP], #0x10
    // 0x616df8: ret
    //     0x616df8: ret             
    // 0x616dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616dfc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616e00: b               #0x616c8c
    // 0x616e04: add             x1, x1, x3
    // 0x616e08: b               #0x616d20
    // 0x616e0c: add             x1, x1, x0
    // 0x616e10: b               #0x616de0
  }
  static void cyclePerSecond(String) {
    // ** addr: 0x616ed8, size: 0xac
    // 0x616ed8: EnterFrame
    //     0x616ed8: stp             fp, lr, [SP, #-0x10]!
    //     0x616edc: mov             fp, SP
    // 0x616ee0: AllocStack(0x18)
    //     0x616ee0: sub             SP, SP, #0x18
    // 0x616ee4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x616ee4: mov             x0, x1
    //     0x616ee8: stur            x1, [fp, #-8]
    // 0x616eec: CheckStackOverflow
    //     0x616eec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616ef0: cmp             SP, x16
    //     0x616ef4: b.ls            #0x616f7c
    // 0x616ef8: r1 = Null
    //     0x616ef8: mov             x1, NULL
    // 0x616efc: r2 = 4
    //     0x616efc: movz            x2, #0x4
    // 0x616f00: r0 = AllocateArray()
    //     0x616f00: bl              #0x82746c  ; AllocateArrayStub
    // 0x616f04: r16 = "per_second_"
    //     0x616f04: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c830] "per_second_"
    //     0x616f08: ldr             x16, [x16, #0x830]
    // 0x616f0c: StoreField: r0->field_f = r16
    //     0x616f0c: stur            w16, [x0, #0xf]
    // 0x616f10: ldur            x1, [fp, #-8]
    // 0x616f14: StoreField: r0->field_13 = r1
    //     0x616f14: stur            w1, [x0, #0x13]
    // 0x616f18: str             x0, [SP]
    // 0x616f1c: r0 = _interpolate()
    //     0x616f1c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616f20: r1 = Null
    //     0x616f20: mov             x1, NULL
    // 0x616f24: r2 = 4
    //     0x616f24: movz            x2, #0x4
    // 0x616f28: stur            x0, [fp, #-0x10]
    // 0x616f2c: r0 = AllocateArray()
    //     0x616f2c: bl              #0x82746c  ; AllocateArrayStub
    // 0x616f30: r16 = "per_second_"
    //     0x616f30: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c830] "per_second_"
    //     0x616f34: ldr             x16, [x16, #0x830]
    // 0x616f38: StoreField: r0->field_f = r16
    //     0x616f38: stur            w16, [x0, #0xf]
    // 0x616f3c: ldur            x1, [fp, #-8]
    // 0x616f40: StoreField: r0->field_13 = r1
    //     0x616f40: stur            w1, [x0, #0x13]
    // 0x616f44: str             x0, [SP]
    // 0x616f48: r0 = _interpolate()
    //     0x616f48: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x616f4c: mov             x1, x0
    // 0x616f50: r0 = prefsGetBool()
    //     0x616f50: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x616f54: cmp             w0, NULL
    // 0x616f58: b.ne            #0x616f60
    // 0x616f5c: r0 = false
    //     0x616f5c: add             x0, NULL, #0x30  ; false
    // 0x616f60: eor             x2, x0, #0x10
    // 0x616f64: ldur            x1, [fp, #-0x10]
    // 0x616f68: r0 = prefsSetBool()
    //     0x616f68: bl              #0x4820f0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetBool
    // 0x616f6c: r0 = Null
    //     0x616f6c: mov             x0, NULL
    // 0x616f70: LeaveFrame
    //     0x616f70: mov             SP, fp
    //     0x616f74: ldp             fp, lr, [SP], #0x10
    // 0x616f78: ret
    //     0x616f78: ret             
    // 0x616f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616f7c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616f80: b               #0x616ef8
  }
}

// class id: 2809, size: 0x2c, field offset: 0xc
//   const constructor, 
class AutoDialog<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d360, size: 0x9c
    // 0x72d360: EnterFrame
    //     0x72d360: stp             fp, lr, [SP, #-0x10]!
    //     0x72d364: mov             fp, SP
    // 0x72d368: AllocStack(0x18)
    //     0x72d368: sub             SP, SP, #0x18
    // 0x72d36c: CheckStackOverflow
    //     0x72d36c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72d370: cmp             SP, x16
    //     0x72d374: b.ls            #0x72d3f4
    // 0x72d378: LoadField: r2 = r1->field_b
    //     0x72d378: ldur            w2, [x1, #0xb]
    // 0x72d37c: DecompressPointer r2
    //     0x72d37c: add             x2, x2, HEAP, lsl #32
    // 0x72d380: r1 = Null
    //     0x72d380: mov             x1, NULL
    // 0x72d384: r3 = <AutoDialog<X0>, X0>
    //     0x72d384: add             x3, PP, #0x33, lsl #12  ; [pp+0x335a0] TypeArguments: <AutoDialog<X0>, X0>
    //     0x72d388: ldr             x3, [x3, #0x5a0]
    // 0x72d38c: r30 = InstantiateTypeArgumentsStub
    //     0x72d38c: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x72d390: LoadField: r30 = r30->field_7
    //     0x72d390: ldur            lr, [lr, #7]
    // 0x72d394: blr             lr
    // 0x72d398: stur            x0, [fp, #-8]
    // 0x72d39c: r0 = LoadStaticField(0xfb8)
    //     0x72d39c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x72d3a0: ldr             x0, [x0, #0x1f70]
    // 0x72d3a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72d3a8: cmp             w0, w16
    // 0x72d3ac: b.ne            #0x72d3bc
    // 0x72d3b0: r2 = autoButtonGroup
    //     0x72d3b0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc20] Field <::.autoButtonGroup>: static late (offset: 0xfb8)
    //     0x72d3b4: ldr             x2, [x2, #0xc20]
    // 0x72d3b8: r0 = InitLateStaticField()
    //     0x72d3b8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x72d3bc: ldur            x1, [fp, #-8]
    // 0x72d3c0: stur            x0, [fp, #-8]
    // 0x72d3c4: r0 = _AutoDialogState()
    //     0x72d3c4: bl              #0x72d3fc  ; Allocate_AutoDialogStateStub -> _AutoDialogState<C1X0> (size=0x1c)
    // 0x72d3c8: stur            x0, [fp, #-0x10]
    // 0x72d3cc: ldur            x16, [fp, #-8]
    // 0x72d3d0: str             x16, [SP]
    // 0x72d3d4: mov             x1, x0
    // 0x72d3d8: r4 = const [0, 0x2, 0x1, 0x1, group, 0x1, null]
    //     0x72d3d8: add             x4, PP, #0x19, lsl #12  ; [pp+0x19ba0] List(7) [0, 0x2, 0x1, 0x1, "group", 0x1, Null]
    //     0x72d3dc: ldr             x4, [x4, #0xba0]
    // 0x72d3e0: r0 = SyncState2()
    //     0x72d3e0: bl              #0x72c088  ; [package:state_groups/src/sync_state.dart] SyncState2::SyncState2
    // 0x72d3e4: ldur            x0, [fp, #-0x10]
    // 0x72d3e8: LeaveFrame
    //     0x72d3e8: mov             SP, fp
    //     0x72d3ec: ldp             fp, lr, [SP], #0x10
    // 0x72d3f0: ret
    //     0x72d3f0: ret             
    // 0x72d3f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72d3f4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72d3f8: b               #0x72d378
  }
}

// class id: 2810, size: 0x2c, field offset: 0xc
//   const constructor, 
class AutoButton<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d2b8, size: 0x9c
    // 0x72d2b8: EnterFrame
    //     0x72d2b8: stp             fp, lr, [SP, #-0x10]!
    //     0x72d2bc: mov             fp, SP
    // 0x72d2c0: AllocStack(0x18)
    //     0x72d2c0: sub             SP, SP, #0x18
    // 0x72d2c4: CheckStackOverflow
    //     0x72d2c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72d2c8: cmp             SP, x16
    //     0x72d2cc: b.ls            #0x72d34c
    // 0x72d2d0: LoadField: r2 = r1->field_b
    //     0x72d2d0: ldur            w2, [x1, #0xb]
    // 0x72d2d4: DecompressPointer r2
    //     0x72d2d4: add             x2, x2, HEAP, lsl #32
    // 0x72d2d8: r1 = Null
    //     0x72d2d8: mov             x1, NULL
    // 0x72d2dc: r3 = <AutoButton<X0>, X0>
    //     0x72d2dc: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f230] TypeArguments: <AutoButton<X0>, X0>
    //     0x72d2e0: ldr             x3, [x3, #0x230]
    // 0x72d2e4: r30 = InstantiateTypeArgumentsStub
    //     0x72d2e4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x72d2e8: LoadField: r30 = r30->field_7
    //     0x72d2e8: ldur            lr, [lr, #7]
    // 0x72d2ec: blr             lr
    // 0x72d2f0: stur            x0, [fp, #-8]
    // 0x72d2f4: r0 = LoadStaticField(0xfb8)
    //     0x72d2f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x72d2f8: ldr             x0, [x0, #0x1f70]
    // 0x72d2fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72d300: cmp             w0, w16
    // 0x72d304: b.ne            #0x72d314
    // 0x72d308: r2 = autoButtonGroup
    //     0x72d308: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc20] Field <::.autoButtonGroup>: static late (offset: 0xfb8)
    //     0x72d30c: ldr             x2, [x2, #0xc20]
    // 0x72d310: r0 = InitLateStaticField()
    //     0x72d310: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x72d314: ldur            x1, [fp, #-8]
    // 0x72d318: stur            x0, [fp, #-8]
    // 0x72d31c: r0 = AutoButtonState()
    //     0x72d31c: bl              #0x72d354  ; AllocateAutoButtonStateStub -> AutoButtonState<C1X0> (size=0x1c)
    // 0x72d320: stur            x0, [fp, #-0x10]
    // 0x72d324: ldur            x16, [fp, #-8]
    // 0x72d328: str             x16, [SP]
    // 0x72d32c: mov             x1, x0
    // 0x72d330: r4 = const [0, 0x2, 0x1, 0x1, group, 0x1, null]
    //     0x72d330: add             x4, PP, #0x19, lsl #12  ; [pp+0x19ba0] List(7) [0, 0x2, 0x1, 0x1, "group", 0x1, Null]
    //     0x72d334: ldr             x4, [x4, #0xba0]
    // 0x72d338: r0 = SyncState2()
    //     0x72d338: bl              #0x72c088  ; [package:state_groups/src/sync_state.dart] SyncState2::SyncState2
    // 0x72d33c: ldur            x0, [fp, #-0x10]
    // 0x72d340: LeaveFrame
    //     0x72d340: mov             SP, fp
    //     0x72d344: ldp             fp, lr, [SP], #0x10
    // 0x72d348: ret
    //     0x72d348: ret             
    // 0x72d34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72d34c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72d350: b               #0x72d2d0
  }
}

// class id: 2811, size: 0x80, field offset: 0xc
//   const constructor, 
class GeneratorGroup<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x72d21c, size: 0x90
    // 0x72d21c: EnterFrame
    //     0x72d21c: stp             fp, lr, [SP, #-0x10]!
    //     0x72d220: mov             fp, SP
    // 0x72d224: AllocStack(0x8)
    //     0x72d224: sub             SP, SP, #8
    // 0x72d228: CheckStackOverflow
    //     0x72d228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72d22c: cmp             SP, x16
    //     0x72d230: b.ls            #0x72d2a4
    // 0x72d234: LoadField: r2 = r1->field_b
    //     0x72d234: ldur            w2, [x1, #0xb]
    // 0x72d238: DecompressPointer r2
    //     0x72d238: add             x2, x2, HEAP, lsl #32
    // 0x72d23c: r1 = Null
    //     0x72d23c: mov             x1, NULL
    // 0x72d240: r3 = <GeneratorGroup<X0>, void?, GeneratorGroup<X0>, X0>
    //     0x72d240: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2a5b8] TypeArguments: <GeneratorGroup<X0>, void?, GeneratorGroup<X0>, X0>
    //     0x72d244: ldr             x3, [x3, #0x5b8]
    // 0x72d248: r30 = InstantiateTypeArgumentsStub
    //     0x72d248: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x72d24c: LoadField: r30 = r30->field_7
    //     0x72d24c: ldur            lr, [lr, #7]
    // 0x72d250: blr             lr
    // 0x72d254: stur            x0, [fp, #-8]
    // 0x72d258: r0 = LoadStaticField(0xfb4)
    //     0x72d258: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x72d25c: ldr             x0, [x0, #0x1f68]
    // 0x72d260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72d264: cmp             w0, w16
    // 0x72d268: b.ne            #0x72d278
    // 0x72d26c: r2 = generatorStateGroup
    //     0x72d26c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x72d270: ldr             x2, [x2, #0x138]
    // 0x72d274: r0 = InitLateStaticField()
    //     0x72d274: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x72d278: ldur            x1, [fp, #-8]
    // 0x72d27c: stur            x0, [fp, #-8]
    // 0x72d280: r0 = GeneratorGroupState()
    //     0x72d280: bl              #0x72d2ac  ; AllocateGeneratorGroupStateStub -> GeneratorGroupState<C3X0> (size=0x18)
    // 0x72d284: mov             x1, x0
    // 0x72d288: ldur            x2, [fp, #-8]
    // 0x72d28c: stur            x0, [fp, #-8]
    // 0x72d290: r0 = SyncState()
    //     0x72d290: bl              #0x72bee4  ; [package:state_groups/src/sync_state.dart] SyncState::SyncState
    // 0x72d294: ldur            x0, [fp, #-8]
    // 0x72d298: LeaveFrame
    //     0x72d298: mov             SP, fp
    //     0x72d29c: ldp             fp, lr, [SP], #0x10
    // 0x72d2a0: ret
    //     0x72d2a0: ret             
    // 0x72d2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72d2a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72d2a8: b               #0x72d234
  }
}

// class id: 3288, size: 0x18, field offset: 0x18
class GeneratorGroupState<C3X0> extends SyncState<C3X0, dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x6153ac, size: 0x1560
    // 0x6153ac: EnterFrame
    //     0x6153ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6153b0: mov             fp, SP
    // 0x6153b4: AllocStack(0x120)
    //     0x6153b4: sub             SP, SP, #0x120
    // 0x6153b8: SetupParameters(GeneratorGroupState<C3X0> this /* r1 => r1, fp-0x8 */)
    //     0x6153b8: stur            x1, [fp, #-8]
    // 0x6153bc: CheckStackOverflow
    //     0x6153bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6153c0: cmp             SP, x16
    //     0x6153c4: b.ls            #0x61689c
    // 0x6153c8: r1 = 2
    //     0x6153c8: movz            x1, #0x2
    // 0x6153cc: r0 = AllocateContext()
    //     0x6153cc: bl              #0x82637c  ; AllocateContextStub
    // 0x6153d0: mov             x2, x0
    // 0x6153d4: ldur            x0, [fp, #-8]
    // 0x6153d8: stur            x2, [fp, #-0x10]
    // 0x6153dc: StoreField: r2->field_f = r0
    //     0x6153dc: stur            w0, [x2, #0xf]
    // 0x6153e0: LoadField: r1 = r0->field_b
    //     0x6153e0: ldur            w1, [x0, #0xb]
    // 0x6153e4: DecompressPointer r1
    //     0x6153e4: add             x1, x1, HEAP, lsl #32
    // 0x6153e8: cmp             w1, NULL
    // 0x6153ec: b.eq            #0x6168a4
    // 0x6153f0: LoadField: r3 = r1->field_73
    //     0x6153f0: ldur            w3, [x1, #0x73]
    // 0x6153f4: DecompressPointer r3
    //     0x6153f4: add             x3, x3, HEAP, lsl #32
    // 0x6153f8: mov             x1, x3
    // 0x6153fc: r0 = getBuyOption()
    //     0x6153fc: bl              #0x616ad8  ; [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] ::getBuyOption
    // 0x615400: ldur            x2, [fp, #-0x10]
    // 0x615404: StoreField: r2->field_13 = r0
    //     0x615404: stur            w0, [x2, #0x13]
    //     0x615408: ldurb           w16, [x2, #-1]
    //     0x61540c: ldurb           w17, [x0, #-1]
    //     0x615410: and             x16, x17, x16, lsr #2
    //     0x615414: tst             x16, HEAP, lsr #32
    //     0x615418: b.eq            #0x615420
    //     0x61541c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x615420: ldur            x0, [fp, #-8]
    // 0x615424: LoadField: r1 = r0->field_b
    //     0x615424: ldur            w1, [x0, #0xb]
    // 0x615428: DecompressPointer r1
    //     0x615428: add             x1, x1, HEAP, lsl #32
    // 0x61542c: cmp             w1, NULL
    // 0x615430: b.eq            #0x6168a8
    // 0x615434: LoadField: r3 = r1->field_73
    //     0x615434: ldur            w3, [x1, #0x73]
    // 0x615438: DecompressPointer r3
    //     0x615438: add             x3, x3, HEAP, lsl #32
    // 0x61543c: mov             x1, x3
    // 0x615440: r0 = getPerSecond()
    //     0x615440: bl              #0x616a68  ; [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] ::getPerSecond
    // 0x615444: mov             x2, x0
    // 0x615448: ldur            x1, [fp, #-8]
    // 0x61544c: stur            x2, [fp, #-0x18]
    // 0x615450: LoadField: r0 = r1->field_b
    //     0x615450: ldur            w0, [x1, #0xb]
    // 0x615454: DecompressPointer r0
    //     0x615454: add             x0, x0, HEAP, lsl #32
    // 0x615458: cmp             w0, NULL
    // 0x61545c: b.eq            #0x6168ac
    // 0x615460: LoadField: r3 = r0->field_3b
    //     0x615460: ldur            w3, [x0, #0x3b]
    // 0x615464: DecompressPointer r3
    //     0x615464: add             x3, x3, HEAP, lsl #32
    // 0x615468: str             x3, [SP]
    // 0x61546c: mov             x0, x3
    // 0x615470: ClosureCall
    //     0x615470: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x615474: ldur            x2, [x0, #0x1f]
    //     0x615478: blr             x2
    // 0x61547c: r16 = true
    //     0x61547c: add             x16, NULL, #0x20  ; true
    // 0x615480: cmp             w0, w16
    // 0x615484: b.eq            #0x61549c
    // 0x615488: ldur            x0, [fp, #-0x10]
    // 0x61548c: r1 = Instance_BuyOption
    //     0x61548c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27850] Obj!BuyOption@85ea41
    //     0x615490: ldr             x1, [x1, #0x850]
    // 0x615494: StoreField: r0->field_13 = r1
    //     0x615494: stur            w1, [x0, #0x13]
    // 0x615498: b               #0x6154a0
    // 0x61549c: ldur            x0, [fp, #-0x10]
    // 0x6154a0: ldur            x3, [fp, #-8]
    // 0x6154a4: r1 = <Widget>
    //     0x6154a4: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6154a8: r2 = 0
    //     0x6154a8: movz            x2, #0
    // 0x6154ac: r0 = _GrowableList()
    //     0x6154ac: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x6154b0: mov             x3, x0
    // 0x6154b4: ldur            x2, [fp, #-8]
    // 0x6154b8: stur            x3, [fp, #-0x20]
    // 0x6154bc: LoadField: r0 = r2->field_b
    //     0x6154bc: ldur            w0, [x2, #0xb]
    // 0x6154c0: DecompressPointer r0
    //     0x6154c0: add             x0, x0, HEAP, lsl #32
    // 0x6154c4: cmp             w0, NULL
    // 0x6154c8: b.eq            #0x6168b0
    // 0x6154cc: LoadField: r1 = r0->field_53
    //     0x6154cc: ldur            w1, [x0, #0x53]
    // 0x6154d0: DecompressPointer r1
    //     0x6154d0: add             x1, x1, HEAP, lsl #32
    // 0x6154d4: r0 = LoadClassIdInstr(r1)
    //     0x6154d4: ldur            x0, [x1, #-1]
    //     0x6154d8: ubfx            x0, x0, #0xc, #0x14
    // 0x6154dc: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x6154dc: movz            x17, #0x7df6
    //     0x6154e0: add             lr, x0, x17
    //     0x6154e4: ldr             lr, [x21, lr, lsl #3]
    //     0x6154e8: blr             lr
    // 0x6154ec: mov             x3, x0
    // 0x6154f0: ldur            x2, [fp, #-8]
    // 0x6154f4: stur            x3, [fp, #-0x40]
    // 0x6154f8: LoadField: r4 = r2->field_7
    //     0x6154f8: ldur            w4, [x2, #7]
    // 0x6154fc: DecompressPointer r4
    //     0x6154fc: add             x4, x4, HEAP, lsl #32
    // 0x615500: stur            x4, [fp, #-0x38]
    // 0x615504: ldur            x5, [fp, #-0x20]
    // 0x615508: r8 = false
    //     0x615508: add             x8, NULL, #0x30  ; false
    // 0x61550c: r7 = false
    //     0x61550c: add             x7, NULL, #0x30  ; false
    // 0x615510: ldur            x6, [fp, #-0x18]
    // 0x615514: stur            x8, [fp, #-0x28]
    // 0x615518: stur            x7, [fp, #-0x30]
    // 0x61551c: CheckStackOverflow
    //     0x61551c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615520: cmp             SP, x16
    //     0x615524: b.ls            #0x6168b4
    // 0x615528: r0 = LoadClassIdInstr(r3)
    //     0x615528: ldur            x0, [x3, #-1]
    //     0x61552c: ubfx            x0, x0, #0xc, #0x14
    // 0x615530: mov             x1, x3
    // 0x615534: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x615534: sub             lr, x0, #0xfc4
    //     0x615538: ldr             lr, [x21, lr, lsl #3]
    //     0x61553c: blr             lr
    // 0x615540: tbnz            w0, #4, #0x615f8c
    // 0x615544: ldur            x2, [fp, #-8]
    // 0x615548: ldur            x3, [fp, #-0x40]
    // 0x61554c: r0 = LoadClassIdInstr(r3)
    //     0x61554c: ldur            x0, [x3, #-1]
    //     0x615550: ubfx            x0, x0, #0xc, #0x14
    // 0x615554: mov             x1, x3
    // 0x615558: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x615558: sub             lr, x0, #0xfb6
    //     0x61555c: ldr             lr, [x21, lr, lsl #3]
    //     0x615560: blr             lr
    // 0x615564: mov             x2, x0
    // 0x615568: ldur            x1, [fp, #-8]
    // 0x61556c: stur            x2, [fp, #-0x48]
    // 0x615570: LoadField: r0 = r1->field_b
    //     0x615570: ldur            w0, [x1, #0xb]
    // 0x615574: DecompressPointer r0
    //     0x615574: add             x0, x0, HEAP, lsl #32
    // 0x615578: cmp             w0, NULL
    // 0x61557c: b.eq            #0x6168bc
    // 0x615580: LoadField: r3 = r0->field_27
    //     0x615580: ldur            w3, [x0, #0x27]
    // 0x615584: DecompressPointer r3
    //     0x615584: add             x3, x3, HEAP, lsl #32
    // 0x615588: stp             x2, x3, [SP]
    // 0x61558c: mov             x0, x3
    // 0x615590: ClosureCall
    //     0x615590: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x615594: ldur            x2, [x0, #0x1f]
    //     0x615598: blr             x2
    // 0x61559c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x61559c: ldur            w1, [x0, #0x17]
    // 0x6155a0: DecompressPointer r1
    //     0x6155a0: add             x1, x1, HEAP, lsl #32
    // 0x6155a4: cmp             w1, NULL
    // 0x6155a8: b.eq            #0x615610
    // 0x6155ac: ldur            x1, [fp, #-8]
    // 0x6155b0: LoadField: r0 = r1->field_b
    //     0x6155b0: ldur            w0, [x1, #0xb]
    // 0x6155b4: DecompressPointer r0
    //     0x6155b4: add             x0, x0, HEAP, lsl #32
    // 0x6155b8: cmp             w0, NULL
    // 0x6155bc: b.eq            #0x6168c0
    // 0x6155c0: LoadField: r2 = r0->field_27
    //     0x6155c0: ldur            w2, [x0, #0x27]
    // 0x6155c4: DecompressPointer r2
    //     0x6155c4: add             x2, x2, HEAP, lsl #32
    // 0x6155c8: ldur            x16, [fp, #-0x48]
    // 0x6155cc: stp             x16, x2, [SP]
    // 0x6155d0: mov             x0, x2
    // 0x6155d4: ClosureCall
    //     0x6155d4: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6155d8: ldur            x2, [x0, #0x1f]
    //     0x6155dc: blr             x2
    // 0x6155e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6155e0: ldur            w1, [x0, #0x17]
    // 0x6155e4: DecompressPointer r1
    //     0x6155e4: add             x1, x1, HEAP, lsl #32
    // 0x6155e8: cmp             w1, NULL
    // 0x6155ec: b.eq            #0x6168c4
    // 0x6155f0: str             x1, [SP]
    // 0x6155f4: mov             x0, x1
    // 0x6155f8: ClosureCall
    //     0x6155f8: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6155fc: ldur            x2, [x0, #0x1f]
    //     0x615600: blr             x2
    // 0x615604: r16 = true
    //     0x615604: add             x16, NULL, #0x20  ; true
    // 0x615608: cmp             w0, w16
    // 0x61560c: b.ne            #0x615664
    // 0x615610: ldur            x0, [fp, #-8]
    // 0x615614: LoadField: r1 = r0->field_b
    //     0x615614: ldur            w1, [x0, #0xb]
    // 0x615618: DecompressPointer r1
    //     0x615618: add             x1, x1, HEAP, lsl #32
    // 0x61561c: cmp             w1, NULL
    // 0x615620: b.eq            #0x6168c8
    // 0x615624: LoadField: r2 = r1->field_13
    //     0x615624: ldur            w2, [x1, #0x13]
    // 0x615628: DecompressPointer r2
    //     0x615628: add             x2, x2, HEAP, lsl #32
    // 0x61562c: cmp             w2, NULL
    // 0x615630: b.eq            #0x615674
    // 0x615634: LoadField: r2 = r1->field_2f
    //     0x615634: ldur            w2, [x1, #0x2f]
    // 0x615638: DecompressPointer r2
    //     0x615638: add             x2, x2, HEAP, lsl #32
    // 0x61563c: LoadField: r3 = r2->field_f
    //     0x61563c: ldur            w3, [x2, #0xf]
    // 0x615640: DecompressPointer r3
    //     0x615640: add             x3, x3, HEAP, lsl #32
    // 0x615644: mov             x1, x2
    // 0x615648: ldur            x2, [fp, #-0x48]
    // 0x61564c: stur            x3, [fp, #-0x50]
    // 0x615650: r0 = _getValueOrData()
    //     0x615650: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x615654: mov             x1, x0
    // 0x615658: ldur            x0, [fp, #-0x50]
    // 0x61565c: cmp             w0, w1
    // 0x615660: b.ne            #0x615674
    // 0x615664: ldur            x8, [fp, #-0x28]
    // 0x615668: ldur            x7, [fp, #-0x30]
    // 0x61566c: ldur            x2, [fp, #-0x20]
    // 0x615670: b               #0x615f78
    // 0x615674: ldur            x1, [fp, #-8]
    // 0x615678: LoadField: r0 = r1->field_b
    //     0x615678: ldur            w0, [x1, #0xb]
    // 0x61567c: DecompressPointer r0
    //     0x61567c: add             x0, x0, HEAP, lsl #32
    // 0x615680: cmp             w0, NULL
    // 0x615684: b.eq            #0x6168cc
    // 0x615688: LoadField: r2 = r0->field_27
    //     0x615688: ldur            w2, [x0, #0x27]
    // 0x61568c: DecompressPointer r2
    //     0x61568c: add             x2, x2, HEAP, lsl #32
    // 0x615690: ldur            x16, [fp, #-0x48]
    // 0x615694: stp             x16, x2, [SP]
    // 0x615698: mov             x0, x2
    // 0x61569c: ClosureCall
    //     0x61569c: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6156a0: ldur            x2, [x0, #0x1f]
    //     0x6156a4: blr             x2
    // 0x6156a8: mov             x2, x0
    // 0x6156ac: ldur            x1, [fp, #-8]
    // 0x6156b0: stur            x2, [fp, #-0x50]
    // 0x6156b4: LoadField: r0 = r1->field_b
    //     0x6156b4: ldur            w0, [x1, #0xb]
    // 0x6156b8: DecompressPointer r0
    //     0x6156b8: add             x0, x0, HEAP, lsl #32
    // 0x6156bc: cmp             w0, NULL
    // 0x6156c0: b.eq            #0x6168d0
    // 0x6156c4: LoadField: r3 = r0->field_27
    //     0x6156c4: ldur            w3, [x0, #0x27]
    // 0x6156c8: DecompressPointer r3
    //     0x6156c8: add             x3, x3, HEAP, lsl #32
    // 0x6156cc: ldur            x16, [fp, #-0x48]
    // 0x6156d0: stp             x16, x3, [SP]
    // 0x6156d4: mov             x0, x3
    // 0x6156d8: ClosureCall
    //     0x6156d8: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6156dc: ldur            x2, [x0, #0x1f]
    //     0x6156e0: blr             x2
    // 0x6156e4: LoadField: r1 = r0->field_1f
    //     0x6156e4: ldur            w1, [x0, #0x1f]
    // 0x6156e8: DecompressPointer r1
    //     0x6156e8: add             x1, x1, HEAP, lsl #32
    // 0x6156ec: cmp             w1, NULL
    // 0x6156f0: b.eq            #0x615b78
    // 0x6156f4: ldur            x0, [fp, #-0x30]
    // 0x6156f8: tbz             w0, #4, #0x61578c
    // 0x6156fc: ldur            x3, [fp, #-8]
    // 0x615700: LoadField: r1 = r3->field_b
    //     0x615700: ldur            w1, [x3, #0xb]
    // 0x615704: DecompressPointer r1
    //     0x615704: add             x1, x1, HEAP, lsl #32
    // 0x615708: cmp             w1, NULL
    // 0x61570c: b.eq            #0x6168d4
    // 0x615710: LoadField: r2 = r1->field_33
    //     0x615710: ldur            w2, [x1, #0x33]
    // 0x615714: DecompressPointer r2
    //     0x615714: add             x2, x2, HEAP, lsl #32
    // 0x615718: LoadField: r4 = r2->field_f
    //     0x615718: ldur            w4, [x2, #0xf]
    // 0x61571c: DecompressPointer r4
    //     0x61571c: add             x4, x4, HEAP, lsl #32
    // 0x615720: mov             x1, x2
    // 0x615724: ldur            x2, [fp, #-0x48]
    // 0x615728: stur            x4, [fp, #-0x58]
    // 0x61572c: r0 = _getKeyOrData()
    //     0x61572c: bl              #0x3f7518  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x615730: mov             x1, x0
    // 0x615734: ldur            x0, [fp, #-0x58]
    // 0x615738: cmp             w0, w1
    // 0x61573c: b.ne            #0x61578c
    // 0x615740: ldur            x1, [fp, #-8]
    // 0x615744: LoadField: r0 = r1->field_b
    //     0x615744: ldur            w0, [x1, #0xb]
    // 0x615748: DecompressPointer r0
    //     0x615748: add             x0, x0, HEAP, lsl #32
    // 0x61574c: cmp             w0, NULL
    // 0x615750: b.eq            #0x6168d8
    // 0x615754: LoadField: r2 = r0->field_27
    //     0x615754: ldur            w2, [x0, #0x27]
    // 0x615758: DecompressPointer r2
    //     0x615758: add             x2, x2, HEAP, lsl #32
    // 0x61575c: ldur            x16, [fp, #-0x48]
    // 0x615760: stp             x16, x2, [SP]
    // 0x615764: mov             x0, x2
    // 0x615768: ClosureCall
    //     0x615768: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x61576c: ldur            x2, [x0, #0x1f]
    //     0x615770: blr             x2
    // 0x615774: LoadField: r1 = r0->field_2b
    //     0x615774: ldur            w1, [x0, #0x2b]
    // 0x615778: DecompressPointer r1
    //     0x615778: add             x1, x1, HEAP, lsl #32
    // 0x61577c: cmp             w1, NULL
    // 0x615780: b.eq            #0x61578c
    // 0x615784: r5 = true
    //     0x615784: add             x5, NULL, #0x20  ; true
    // 0x615788: b               #0x615790
    // 0x61578c: ldur            x5, [fp, #-0x30]
    // 0x615790: ldur            x3, [fp, #-8]
    // 0x615794: ldur            x4, [fp, #-0x50]
    // 0x615798: stur            x5, [fp, #-0xb8]
    // 0x61579c: LoadField: r6 = r3->field_b
    //     0x61579c: ldur            w6, [x3, #0xb]
    // 0x6157a0: DecompressPointer r6
    //     0x6157a0: add             x6, x6, HEAP, lsl #32
    // 0x6157a4: stur            x6, [fp, #-0xb0]
    // 0x6157a8: cmp             w6, NULL
    // 0x6157ac: b.eq            #0x6168dc
    // 0x6157b0: LoadField: r7 = r6->field_4b
    //     0x6157b0: ldur            w7, [x6, #0x4b]
    // 0x6157b4: DecompressPointer r7
    //     0x6157b4: add             x7, x7, HEAP, lsl #32
    // 0x6157b8: stur            x7, [fp, #-0xa8]
    // 0x6157bc: LoadField: r8 = r6->field_1f
    //     0x6157bc: ldur            w8, [x6, #0x1f]
    // 0x6157c0: DecompressPointer r8
    //     0x6157c0: add             x8, x8, HEAP, lsl #32
    // 0x6157c4: stur            x8, [fp, #-0xa0]
    // 0x6157c8: LoadField: r9 = r6->field_23
    //     0x6157c8: ldur            w9, [x6, #0x23]
    // 0x6157cc: DecompressPointer r9
    //     0x6157cc: add             x9, x9, HEAP, lsl #32
    // 0x6157d0: stur            x9, [fp, #-0x98]
    // 0x6157d4: LoadField: r10 = r6->field_2b
    //     0x6157d4: ldur            w10, [x6, #0x2b]
    // 0x6157d8: DecompressPointer r10
    //     0x6157d8: add             x10, x10, HEAP, lsl #32
    // 0x6157dc: stur            x10, [fp, #-0x90]
    // 0x6157e0: LoadField: r11 = r6->field_2f
    //     0x6157e0: ldur            w11, [x6, #0x2f]
    // 0x6157e4: DecompressPointer r11
    //     0x6157e4: add             x11, x11, HEAP, lsl #32
    // 0x6157e8: stur            x11, [fp, #-0x88]
    // 0x6157ec: LoadField: r12 = r6->field_27
    //     0x6157ec: ldur            w12, [x6, #0x27]
    // 0x6157f0: DecompressPointer r12
    //     0x6157f0: add             x12, x12, HEAP, lsl #32
    // 0x6157f4: stur            x12, [fp, #-0x80]
    // 0x6157f8: LoadField: r13 = r6->field_3f
    //     0x6157f8: ldur            w13, [x6, #0x3f]
    // 0x6157fc: DecompressPointer r13
    //     0x6157fc: add             x13, x13, HEAP, lsl #32
    // 0x615800: stur            x13, [fp, #-0x78]
    // 0x615804: LoadField: r14 = r6->field_43
    //     0x615804: ldur            w14, [x6, #0x43]
    // 0x615808: DecompressPointer r14
    //     0x615808: add             x14, x14, HEAP, lsl #32
    // 0x61580c: stur            x14, [fp, #-0x70]
    // 0x615810: LoadField: r19 = r6->field_47
    //     0x615810: ldur            w19, [x6, #0x47]
    // 0x615814: DecompressPointer r19
    //     0x615814: add             x19, x19, HEAP, lsl #32
    // 0x615818: stur            x19, [fp, #-0x68]
    // 0x61581c: LoadField: r20 = r6->field_4f
    //     0x61581c: ldur            w20, [x6, #0x4f]
    // 0x615820: DecompressPointer r20
    //     0x615820: add             x20, x20, HEAP, lsl #32
    // 0x615824: stur            x20, [fp, #-0x60]
    // 0x615828: LoadField: r23 = r6->field_5b
    //     0x615828: ldur            w23, [x6, #0x5b]
    // 0x61582c: DecompressPointer r23
    //     0x61582c: add             x23, x23, HEAP, lsl #32
    // 0x615830: mov             x0, x23
    // 0x615834: ldur            x2, [fp, #-0x38]
    // 0x615838: stur            x23, [fp, #-0x58]
    // 0x61583c: r1 = Null
    //     0x61583c: mov             x1, NULL
    // 0x615840: r8 = (dynamic this, Map<int, double>, ((dynamic this, int, num) => Tuple2<C3X0, CustomNum>)?, int, int, bool allowSave, bool test) => num
    //     0x615840: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c5b8] FunctionType: (dynamic this, Map<int, double>, ((dynamic this, int, num) => Tuple2<C3X0, CustomNum>)?, int, int, bool allowSave, bool test) => num
    //     0x615844: ldr             x8, [x8, #0x5b8]
    // 0x615848: LoadField: r9 = r8->field_7
    //     0x615848: ldur            x9, [x8, #7]
    // 0x61584c: r3 = Null
    //     0x61584c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c718] Null
    //     0x615850: ldr             x3, [x3, #0x718]
    // 0x615854: blr             x9
    // 0x615858: ldur            x3, [fp, #-0xb0]
    // 0x61585c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x61585c: ldur            w4, [x3, #0x17]
    // 0x615860: DecompressPointer r4
    //     0x615860: add             x4, x4, HEAP, lsl #32
    // 0x615864: mov             x0, x4
    // 0x615868: ldur            x2, [fp, #-0x38]
    // 0x61586c: stur            x4, [fp, #-0xc0]
    // 0x615870: r1 = Null
    //     0x615870: mov             x1, NULL
    // 0x615874: r8 = (dynamic this, C3X0?) => String?
    //     0x615874: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x615878: ldr             x8, [x8, #0xe90]
    // 0x61587c: LoadField: r9 = r8->field_7
    //     0x61587c: ldur            x9, [x8, #7]
    // 0x615880: r3 = Null
    //     0x615880: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c728] Null
    //     0x615884: ldr             x3, [x3, #0x728]
    // 0x615888: blr             x9
    // 0x61588c: ldur            x3, [fp, #-0xb0]
    // 0x615890: LoadField: r4 = r3->field_1b
    //     0x615890: ldur            w4, [x3, #0x1b]
    // 0x615894: DecompressPointer r4
    //     0x615894: add             x4, x4, HEAP, lsl #32
    // 0x615898: mov             x0, x4
    // 0x61589c: ldur            x2, [fp, #-0x38]
    // 0x6158a0: stur            x4, [fp, #-0xc8]
    // 0x6158a4: r1 = Null
    //     0x6158a4: mov             x1, NULL
    // 0x6158a8: r8 = (dynamic this, C3X0?) => String?
    //     0x6158a8: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x6158ac: ldr             x8, [x8, #0xe90]
    // 0x6158b0: LoadField: r9 = r8->field_7
    //     0x6158b0: ldur            x9, [x8, #7]
    // 0x6158b4: r3 = Null
    //     0x6158b4: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c738] Null
    //     0x6158b8: ldr             x3, [x3, #0x738]
    // 0x6158bc: blr             x9
    // 0x6158c0: ldur            x0, [fp, #-0xb0]
    // 0x6158c4: LoadField: r1 = r0->field_5f
    //     0x6158c4: ldur            w1, [x0, #0x5f]
    // 0x6158c8: DecompressPointer r1
    //     0x6158c8: add             x1, x1, HEAP, lsl #32
    // 0x6158cc: stur            x1, [fp, #-0xd8]
    // 0x6158d0: LoadField: r2 = r0->field_63
    //     0x6158d0: ldur            w2, [x0, #0x63]
    // 0x6158d4: DecompressPointer r2
    //     0x6158d4: add             x2, x2, HEAP, lsl #32
    // 0x6158d8: stur            x2, [fp, #-0xf8]
    // 0x6158dc: LoadField: r3 = r0->field_6b
    //     0x6158dc: ldur            w3, [x0, #0x6b]
    // 0x6158e0: DecompressPointer r3
    //     0x6158e0: add             x3, x3, HEAP, lsl #32
    // 0x6158e4: stur            x3, [fp, #-0xf0]
    // 0x6158e8: LoadField: r4 = r0->field_67
    //     0x6158e8: ldur            w4, [x0, #0x67]
    // 0x6158ec: DecompressPointer r4
    //     0x6158ec: add             x4, x4, HEAP, lsl #32
    // 0x6158f0: ldur            x5, [fp, #-0x50]
    // 0x6158f4: stur            x4, [fp, #-0xe8]
    // 0x6158f8: LoadField: r6 = r5->field_f
    //     0x6158f8: ldur            w6, [x5, #0xf]
    // 0x6158fc: DecompressPointer r6
    //     0x6158fc: add             x6, x6, HEAP, lsl #32
    // 0x615900: stur            x6, [fp, #-0xe0]
    // 0x615904: LoadField: r5 = r0->field_13
    //     0x615904: ldur            w5, [x0, #0x13]
    // 0x615908: DecompressPointer r5
    //     0x615908: add             x5, x5, HEAP, lsl #32
    // 0x61590c: cmp             w5, NULL
    // 0x615910: b.ne            #0x61592c
    // 0x615914: SaveReg r0
    //     0x615914: str             x0, [SP, #-8]!
    // 0x615918: r0 = "Buy"
    //     0x615918: add             x0, PP, #0x16, lsl #12  ; [pp+0x16cb0] "Buy"
    //     0x61591c: ldr             x0, [x0, #0xcb0]
    // 0x615920: stur            x0, [fp, #-0xd0]
    // 0x615924: RestoreReg r0
    //     0x615924: ldr             x0, [SP], #8
    // 0x615928: b               #0x615930
    // 0x61592c: stur            x5, [fp, #-0xd0]
    // 0x615930: ldur            x8, [fp, #-8]
    // 0x615934: ldur            x9, [fp, #-0xa8]
    // 0x615938: ldur            x10, [fp, #-0xa0]
    // 0x61593c: ldur            x11, [fp, #-0x98]
    // 0x615940: ldur            x12, [fp, #-0x90]
    // 0x615944: ldur            x13, [fp, #-0x88]
    // 0x615948: ldur            x14, [fp, #-0x80]
    // 0x61594c: ldur            x19, [fp, #-0x78]
    // 0x615950: ldur            x20, [fp, #-0x70]
    // 0x615954: ldur            x23, [fp, #-0x68]
    // 0x615958: ldur            x24, [fp, #-0x60]
    // 0x61595c: ldur            x25, [fp, #-0x58]
    // 0x615960: ldur            x7, [fp, #-0xc0]
    // 0x615964: ldur            x5, [fp, #-0xc8]
    // 0x615968: LoadField: r1 = r0->field_77
    //     0x615968: ldur            w1, [x0, #0x77]
    // 0x61596c: DecompressPointer r1
    //     0x61596c: add             x1, x1, HEAP, lsl #32
    // 0x615970: ldur            x16, [fp, #-0x48]
    // 0x615974: stp             x16, x1, [SP]
    // 0x615978: mov             x0, x1
    // 0x61597c: ClosureCall
    //     0x61597c: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x615980: ldur            x2, [x0, #0x1f]
    //     0x615984: blr             x2
    // 0x615988: mov             x2, x0
    // 0x61598c: ldur            x1, [fp, #-8]
    // 0x615990: stur            x2, [fp, #-0xb0]
    // 0x615994: LoadField: r0 = r1->field_b
    //     0x615994: ldur            w0, [x1, #0xb]
    // 0x615998: DecompressPointer r0
    //     0x615998: add             x0, x0, HEAP, lsl #32
    // 0x61599c: cmp             w0, NULL
    // 0x6159a0: b.eq            #0x6168e0
    // 0x6159a4: LoadField: r3 = r0->field_7b
    //     0x6159a4: ldur            w3, [x0, #0x7b]
    // 0x6159a8: DecompressPointer r3
    //     0x6159a8: add             x3, x3, HEAP, lsl #32
    // 0x6159ac: ldur            x16, [fp, #-0x48]
    // 0x6159b0: stp             x16, x3, [SP]
    // 0x6159b4: mov             x0, x3
    // 0x6159b8: ClosureCall
    //     0x6159b8: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6159bc: ldur            x2, [x0, #0x1f]
    //     0x6159c0: blr             x2
    // 0x6159c4: ldur            x2, [fp, #-0x38]
    // 0x6159c8: r1 = Null
    //     0x6159c8: mov             x1, NULL
    // 0x6159cc: r3 = <C3X0>
    //     0x6159cc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e50] TypeArguments: <C3X0>
    //     0x6159d0: ldr             x3, [x3, #0xe50]
    // 0x6159d4: stur            x0, [fp, #-0x100]
    // 0x6159d8: r0 = Null
    //     0x6159d8: mov             x0, NULL
    // 0x6159dc: cmp             x2, x0
    // 0x6159e0: b.eq            #0x6159f0
    // 0x6159e4: r30 = InstantiateTypeArgumentsStub
    //     0x6159e4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x6159e8: LoadField: r30 = r30->field_7
    //     0x6159e8: ldur            lr, [lr, #7]
    // 0x6159ec: blr             lr
    // 0x6159f0: mov             x1, x0
    // 0x6159f4: r0 = ProgressBar()
    //     0x6159f4: bl              #0x616a5c  ; AllocateProgressBarStub -> ProgressBar<X0> (size=0x78)
    // 0x6159f8: mov             x3, x0
    // 0x6159fc: ldur            x0, [fp, #-0x18]
    // 0x615a00: r17 = -264
    //     0x615a00: movn            x17, #0x107
    // 0x615a04: str             x3, [fp, x17]
    // 0x615a08: StoreField: r3->field_2f = r0
    //     0x615a08: stur            w0, [x3, #0x2f]
    // 0x615a0c: ldur            x1, [fp, #-0xa0]
    // 0x615a10: StoreField: r3->field_1b = r1
    //     0x615a10: stur            w1, [x3, #0x1b]
    // 0x615a14: ldur            x1, [fp, #-0x98]
    // 0x615a18: ArrayStore: r3[0] = r1  ; List_4
    //     0x615a18: stur            w1, [x3, #0x17]
    // 0x615a1c: ldur            x4, [fp, #-0x48]
    // 0x615a20: r1 = LoadInt32Instr(r4)
    //     0x615a20: sbfx            x1, x4, #1, #0x1f
    //     0x615a24: tbz             w4, #0, #0x615a2c
    //     0x615a28: ldur            x1, [x4, #7]
    // 0x615a2c: StoreField: r3->field_1f = r1
    //     0x615a2c: stur            x1, [x3, #0x1f]
    // 0x615a30: ldur            x1, [fp, #-0x90]
    // 0x615a34: StoreField: r3->field_27 = r1
    //     0x615a34: stur            w1, [x3, #0x27]
    // 0x615a38: ldur            x1, [fp, #-0x88]
    // 0x615a3c: StoreField: r3->field_2b = r1
    //     0x615a3c: stur            w1, [x3, #0x2b]
    // 0x615a40: ldur            x2, [fp, #-0x10]
    // 0x615a44: r1 = Function '<anonymous closure>':.
    //     0x615a44: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c748] AnonymousClosure: (0x616fb8), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] GeneratorGroupState::build (0x6153ac)
    //     0x615a48: ldr             x1, [x1, #0x748]
    // 0x615a4c: r0 = AllocateClosure()
    //     0x615a4c: bl              #0x826750  ; AllocateClosureStub
    // 0x615a50: mov             x1, x0
    // 0x615a54: r17 = -264
    //     0x615a54: movn            x17, #0x107
    // 0x615a58: ldr             x0, [fp, x17]
    // 0x615a5c: StoreField: r0->field_33 = r1
    //     0x615a5c: stur            w1, [x0, #0x33]
    // 0x615a60: ldur            x1, [fp, #-0x80]
    // 0x615a64: StoreField: r0->field_37 = r1
    //     0x615a64: stur            w1, [x0, #0x37]
    // 0x615a68: ldur            x1, [fp, #-0x78]
    // 0x615a6c: StoreField: r0->field_3b = r1
    //     0x615a6c: stur            w1, [x0, #0x3b]
    // 0x615a70: ldur            x1, [fp, #-0x70]
    // 0x615a74: StoreField: r0->field_3f = r1
    //     0x615a74: stur            w1, [x0, #0x3f]
    // 0x615a78: ldur            x1, [fp, #-0x68]
    // 0x615a7c: StoreField: r0->field_47 = r1
    //     0x615a7c: stur            w1, [x0, #0x47]
    // 0x615a80: ldur            x1, [fp, #-0x60]
    // 0x615a84: StoreField: r0->field_4b = r1
    //     0x615a84: stur            w1, [x0, #0x4b]
    // 0x615a88: ldur            x1, [fp, #-0x58]
    // 0x615a8c: StoreField: r0->field_53 = r1
    //     0x615a8c: stur            w1, [x0, #0x53]
    // 0x615a90: ldur            x1, [fp, #-0xc0]
    // 0x615a94: StoreField: r0->field_f = r1
    //     0x615a94: stur            w1, [x0, #0xf]
    // 0x615a98: ldur            x1, [fp, #-0xc8]
    // 0x615a9c: StoreField: r0->field_13 = r1
    //     0x615a9c: stur            w1, [x0, #0x13]
    // 0x615aa0: ldur            x1, [fp, #-0xf0]
    // 0x615aa4: StoreField: r0->field_5f = r1
    //     0x615aa4: stur            w1, [x0, #0x5f]
    // 0x615aa8: ldur            x1, [fp, #-0xa8]
    // 0x615aac: StoreField: r0->field_43 = r1
    //     0x615aac: stur            w1, [x0, #0x43]
    // 0x615ab0: ldur            x1, [fp, #-0xe8]
    // 0x615ab4: StoreField: r0->field_63 = r1
    //     0x615ab4: stur            w1, [x0, #0x63]
    // 0x615ab8: ldur            x1, [fp, #-0xd8]
    // 0x615abc: StoreField: r0->field_57 = r1
    //     0x615abc: stur            w1, [x0, #0x57]
    // 0x615ac0: ldur            x1, [fp, #-0xf8]
    // 0x615ac4: StoreField: r0->field_5b = r1
    //     0x615ac4: stur            w1, [x0, #0x5b]
    // 0x615ac8: ldur            x1, [fp, #-0xe0]
    // 0x615acc: StoreField: r0->field_67 = r1
    //     0x615acc: stur            w1, [x0, #0x67]
    // 0x615ad0: ldur            x1, [fp, #-0xd0]
    // 0x615ad4: StoreField: r0->field_6b = r1
    //     0x615ad4: stur            w1, [x0, #0x6b]
    // 0x615ad8: ldur            x1, [fp, #-0xb0]
    // 0x615adc: StoreField: r0->field_6f = r1
    //     0x615adc: stur            w1, [x0, #0x6f]
    // 0x615ae0: ldur            x1, [fp, #-0x100]
    // 0x615ae4: StoreField: r0->field_73 = r1
    //     0x615ae4: stur            w1, [x0, #0x73]
    // 0x615ae8: ldur            x2, [fp, #-0x20]
    // 0x615aec: LoadField: r1 = r2->field_b
    //     0x615aec: ldur            w1, [x2, #0xb]
    // 0x615af0: LoadField: r3 = r2->field_f
    //     0x615af0: ldur            w3, [x2, #0xf]
    // 0x615af4: DecompressPointer r3
    //     0x615af4: add             x3, x3, HEAP, lsl #32
    // 0x615af8: LoadField: r4 = r3->field_b
    //     0x615af8: ldur            w4, [x3, #0xb]
    // 0x615afc: r3 = LoadInt32Instr(r1)
    //     0x615afc: sbfx            x3, x1, #1, #0x1f
    // 0x615b00: r17 = -272
    //     0x615b00: movn            x17, #0x10f
    // 0x615b04: str             x3, [fp, x17]
    // 0x615b08: r1 = LoadInt32Instr(r4)
    //     0x615b08: sbfx            x1, x4, #1, #0x1f
    // 0x615b0c: cmp             x3, x1
    // 0x615b10: b.ne            #0x615b1c
    // 0x615b14: mov             x1, x2
    // 0x615b18: r0 = _growToNextCapacity()
    //     0x615b18: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x615b1c: ldur            x3, [fp, #-0x20]
    // 0x615b20: r17 = -272
    //     0x615b20: movn            x17, #0x10f
    // 0x615b24: ldr             x2, [fp, x17]
    // 0x615b28: add             x0, x2, #1
    // 0x615b2c: lsl             x1, x0, #1
    // 0x615b30: StoreField: r3->field_b = r1
    //     0x615b30: stur            w1, [x3, #0xb]
    // 0x615b34: LoadField: r1 = r3->field_f
    //     0x615b34: ldur            w1, [x3, #0xf]
    // 0x615b38: DecompressPointer r1
    //     0x615b38: add             x1, x1, HEAP, lsl #32
    // 0x615b3c: r17 = -264
    //     0x615b3c: movn            x17, #0x107
    // 0x615b40: ldr             x0, [fp, x17]
    // 0x615b44: ArrayStore: r1[r2] = r0  ; List_4
    //     0x615b44: add             x25, x1, x2, lsl #2
    //     0x615b48: add             x25, x25, #0xf
    //     0x615b4c: str             w0, [x25]
    //     0x615b50: tbz             w0, #0, #0x615b6c
    //     0x615b54: ldurb           w16, [x1, #-1]
    //     0x615b58: ldurb           w17, [x0, #-1]
    //     0x615b5c: and             x16, x17, x16, lsr #2
    //     0x615b60: tst             x16, HEAP, lsr #32
    //     0x615b64: b.eq            #0x615b6c
    //     0x615b68: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x615b6c: ldur            x4, [fp, #-0xb8]
    // 0x615b70: r5 = true
    //     0x615b70: add             x5, NULL, #0x20  ; true
    // 0x615b74: b               #0x615e50
    // 0x615b78: ldur            x6, [fp, #-8]
    // 0x615b7c: ldur            x3, [fp, #-0x20]
    // 0x615b80: ldur            x4, [fp, #-0x48]
    // 0x615b84: ldur            x5, [fp, #-0x50]
    // 0x615b88: LoadField: r7 = r6->field_b
    //     0x615b88: ldur            w7, [x6, #0xb]
    // 0x615b8c: DecompressPointer r7
    //     0x615b8c: add             x7, x7, HEAP, lsl #32
    // 0x615b90: stur            x7, [fp, #-0x78]
    // 0x615b94: cmp             w7, NULL
    // 0x615b98: b.eq            #0x6168e4
    // 0x615b9c: LoadField: r8 = r7->field_2f
    //     0x615b9c: ldur            w8, [x7, #0x2f]
    // 0x615ba0: DecompressPointer r8
    //     0x615ba0: add             x8, x8, HEAP, lsl #32
    // 0x615ba4: stur            x8, [fp, #-0x70]
    // 0x615ba8: LoadField: r9 = r7->field_1f
    //     0x615ba8: ldur            w9, [x7, #0x1f]
    // 0x615bac: DecompressPointer r9
    //     0x615bac: add             x9, x9, HEAP, lsl #32
    // 0x615bb0: stur            x9, [fp, #-0x68]
    // 0x615bb4: LoadField: r10 = r7->field_23
    //     0x615bb4: ldur            w10, [x7, #0x23]
    // 0x615bb8: DecompressPointer r10
    //     0x615bb8: add             x10, x10, HEAP, lsl #32
    // 0x615bbc: stur            x10, [fp, #-0x60]
    // 0x615bc0: LoadField: r11 = r7->field_5b
    //     0x615bc0: ldur            w11, [x7, #0x5b]
    // 0x615bc4: DecompressPointer r11
    //     0x615bc4: add             x11, x11, HEAP, lsl #32
    // 0x615bc8: mov             x0, x11
    // 0x615bcc: ldur            x2, [fp, #-0x38]
    // 0x615bd0: stur            x11, [fp, #-0x58]
    // 0x615bd4: r1 = Null
    //     0x615bd4: mov             x1, NULL
    // 0x615bd8: r8 = (dynamic this, Map<int, double>, ((dynamic this, int, num) => Tuple2<C3X0, CustomNum>)?, int, int, bool allowSave, bool test) => num
    //     0x615bd8: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c5b8] FunctionType: (dynamic this, Map<int, double>, ((dynamic this, int, num) => Tuple2<C3X0, CustomNum>)?, int, int, bool allowSave, bool test) => num
    //     0x615bdc: ldr             x8, [x8, #0x5b8]
    // 0x615be0: LoadField: r9 = r8->field_7
    //     0x615be0: ldur            x9, [x8, #7]
    // 0x615be4: r3 = Null
    //     0x615be4: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c750] Null
    //     0x615be8: ldr             x3, [x3, #0x750]
    // 0x615bec: blr             x9
    // 0x615bf0: ldur            x3, [fp, #-0x78]
    // 0x615bf4: LoadField: r4 = r3->field_57
    //     0x615bf4: ldur            w4, [x3, #0x57]
    // 0x615bf8: DecompressPointer r4
    //     0x615bf8: add             x4, x4, HEAP, lsl #32
    // 0x615bfc: mov             x0, x4
    // 0x615c00: ldur            x2, [fp, #-0x38]
    // 0x615c04: stur            x4, [fp, #-0x80]
    // 0x615c08: r1 = Null
    //     0x615c08: mov             x1, NULL
    // 0x615c0c: r8 = (dynamic this, Tuple2<C3X0, CustomNum>, Map<C3X0, CustomNum>, num, CustomNum?) => Tuple2<String, String?>
    //     0x615c0c: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c5e0] FunctionType: (dynamic this, Tuple2<C3X0, CustomNum>, Map<C3X0, CustomNum>, num, CustomNum?) => Tuple2<String, String?>
    //     0x615c10: ldr             x8, [x8, #0x5e0]
    // 0x615c14: LoadField: r9 = r8->field_7
    //     0x615c14: ldur            x9, [x8, #7]
    // 0x615c18: r3 = Null
    //     0x615c18: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c760] Null
    //     0x615c1c: ldr             x3, [x3, #0x760]
    // 0x615c20: blr             x9
    // 0x615c24: ldur            x0, [fp, #-0x78]
    // 0x615c28: LoadField: r1 = r0->field_6b
    //     0x615c28: ldur            w1, [x0, #0x6b]
    // 0x615c2c: DecompressPointer r1
    //     0x615c2c: add             x1, x1, HEAP, lsl #32
    // 0x615c30: stur            x1, [fp, #-0x88]
    // 0x615c34: r0 = LoadStaticField(0xfc0)
    //     0x615c34: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x615c38: ldr             x0, [x0, #0x1f80]
    // 0x615c3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x615c40: cmp             w0, w16
    // 0x615c44: b.ne            #0x615c54
    // 0x615c48: r2 = buyableTileStates
    //     0x615c48: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc50] Field <::.buyableTileStates>: static late (offset: 0xfc0)
    //     0x615c4c: ldr             x2, [x2, #0xc50]
    // 0x615c50: r0 = InitLateStaticField()
    //     0x615c50: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x615c54: ldur            x0, [fp, #-0x50]
    // 0x615c58: LoadField: r1 = r0->field_1b
    //     0x615c58: ldur            w1, [x0, #0x1b]
    // 0x615c5c: DecompressPointer r1
    //     0x615c5c: add             x1, x1, HEAP, lsl #32
    // 0x615c60: ldur            x2, [fp, #-8]
    // 0x615c64: stur            x1, [fp, #-0xa0]
    // 0x615c68: LoadField: r3 = r2->field_b
    //     0x615c68: ldur            w3, [x2, #0xb]
    // 0x615c6c: DecompressPointer r3
    //     0x615c6c: add             x3, x3, HEAP, lsl #32
    // 0x615c70: cmp             w3, NULL
    // 0x615c74: b.eq            #0x6168e8
    // 0x615c78: LoadField: r4 = r3->field_5f
    //     0x615c78: ldur            w4, [x3, #0x5f]
    // 0x615c7c: DecompressPointer r4
    //     0x615c7c: add             x4, x4, HEAP, lsl #32
    // 0x615c80: stur            x4, [fp, #-0x98]
    // 0x615c84: LoadField: r5 = r3->field_67
    //     0x615c84: ldur            w5, [x3, #0x67]
    // 0x615c88: DecompressPointer r5
    //     0x615c88: add             x5, x5, HEAP, lsl #32
    // 0x615c8c: stur            x5, [fp, #-0x90]
    // 0x615c90: LoadField: r6 = r0->field_f
    //     0x615c90: ldur            w6, [x0, #0xf]
    // 0x615c94: DecompressPointer r6
    //     0x615c94: add             x6, x6, HEAP, lsl #32
    // 0x615c98: stur            x6, [fp, #-0x78]
    // 0x615c9c: LoadField: r0 = r3->field_77
    //     0x615c9c: ldur            w0, [x3, #0x77]
    // 0x615ca0: DecompressPointer r0
    //     0x615ca0: add             x0, x0, HEAP, lsl #32
    // 0x615ca4: ldur            x16, [fp, #-0x48]
    // 0x615ca8: stp             x16, x0, [SP]
    // 0x615cac: ClosureCall
    //     0x615cac: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x615cb0: ldur            x2, [x0, #0x1f]
    //     0x615cb4: blr             x2
    // 0x615cb8: mov             x2, x0
    // 0x615cbc: ldur            x1, [fp, #-8]
    // 0x615cc0: stur            x2, [fp, #-0x50]
    // 0x615cc4: LoadField: r0 = r1->field_b
    //     0x615cc4: ldur            w0, [x1, #0xb]
    // 0x615cc8: DecompressPointer r0
    //     0x615cc8: add             x0, x0, HEAP, lsl #32
    // 0x615ccc: cmp             w0, NULL
    // 0x615cd0: b.eq            #0x6168ec
    // 0x615cd4: LoadField: r3 = r0->field_7b
    //     0x615cd4: ldur            w3, [x0, #0x7b]
    // 0x615cd8: DecompressPointer r3
    //     0x615cd8: add             x3, x3, HEAP, lsl #32
    // 0x615cdc: ldur            x16, [fp, #-0x48]
    // 0x615ce0: stp             x16, x3, [SP]
    // 0x615ce4: mov             x0, x3
    // 0x615ce8: ClosureCall
    //     0x615ce8: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x615cec: ldur            x2, [x0, #0x1f]
    //     0x615cf0: blr             x2
    // 0x615cf4: ldur            x2, [fp, #-0x38]
    // 0x615cf8: r1 = Null
    //     0x615cf8: mov             x1, NULL
    // 0x615cfc: r3 = <C3X0>
    //     0x615cfc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e50] TypeArguments: <C3X0>
    //     0x615d00: ldr             x3, [x3, #0xe50]
    // 0x615d04: stur            x0, [fp, #-0xa8]
    // 0x615d08: r0 = Null
    //     0x615d08: mov             x0, NULL
    // 0x615d0c: cmp             x2, x0
    // 0x615d10: b.eq            #0x615d20
    // 0x615d14: r30 = InstantiateTypeArgumentsStub
    //     0x615d14: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x615d18: LoadField: r30 = r30->field_7
    //     0x615d18: ldur            lr, [lr, #7]
    // 0x615d1c: blr             lr
    // 0x615d20: mov             x1, x0
    // 0x615d24: r0 = BuyableTile()
    //     0x615d24: bl              #0x616a50  ; AllocateBuyableTileStub -> BuyableTile<X0> (size=0x54)
    // 0x615d28: mov             x3, x0
    // 0x615d2c: ldur            x0, [fp, #-0x68]
    // 0x615d30: stur            x3, [fp, #-0xb0]
    // 0x615d34: StoreField: r3->field_1f = r0
    //     0x615d34: stur            w0, [x3, #0x1f]
    // 0x615d38: ldur            x0, [fp, #-0x70]
    // 0x615d3c: StoreField: r3->field_13 = r0
    //     0x615d3c: stur            w0, [x3, #0x13]
    // 0x615d40: ldur            x0, [fp, #-0x48]
    // 0x615d44: r1 = LoadInt32Instr(r0)
    //     0x615d44: sbfx            x1, x0, #1, #0x1f
    //     0x615d48: tbz             w0, #0, #0x615d50
    //     0x615d4c: ldur            x1, [x0, #7]
    // 0x615d50: ArrayStore: r3[0] = r1  ; List_8
    //     0x615d50: stur            x1, [x3, #0x17]
    // 0x615d54: ldur            x1, [fp, #-0x60]
    // 0x615d58: StoreField: r3->field_2b = r1
    //     0x615d58: stur            w1, [x3, #0x2b]
    // 0x615d5c: ldur            x1, [fp, #-0x58]
    // 0x615d60: StoreField: r3->field_2f = r1
    //     0x615d60: stur            w1, [x3, #0x2f]
    // 0x615d64: ldur            x1, [fp, #-0x98]
    // 0x615d68: StoreField: r3->field_43 = r1
    //     0x615d68: stur            w1, [x3, #0x43]
    // 0x615d6c: ldur            x1, [fp, #-0x80]
    // 0x615d70: StoreField: r3->field_33 = r1
    //     0x615d70: stur            w1, [x3, #0x33]
    // 0x615d74: ldur            x1, [fp, #-0xa0]
    // 0x615d78: StoreField: r3->field_23 = r1
    //     0x615d78: stur            w1, [x3, #0x23]
    // 0x615d7c: ldur            x1, [fp, #-0x88]
    // 0x615d80: StoreField: r3->field_3f = r1
    //     0x615d80: stur            w1, [x3, #0x3f]
    // 0x615d84: ldur            x1, [fp, #-0x78]
    // 0x615d88: StoreField: r3->field_f = r1
    //     0x615d88: stur            w1, [x3, #0xf]
    // 0x615d8c: r4 = ""
    //     0x615d8c: ldr             x4, [PP, #0x100]  ; [pp+0x100] ""
    // 0x615d90: StoreField: r3->field_27 = r4
    //     0x615d90: stur            w4, [x3, #0x27]
    // 0x615d94: ldur            x1, [fp, #-0x90]
    // 0x615d98: StoreField: r3->field_37 = r1
    //     0x615d98: stur            w1, [x3, #0x37]
    // 0x615d9c: r1 = Function '<anonymous closure>':.
    //     0x615d9c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c770] AnonymousClosure: (0x616f84), in [package:pretentious/data/Chapters/Chapter2GameState.dart] Chapter2GameState::build (0x6ab3bc)
    //     0x615da0: ldr             x1, [x1, #0x770]
    // 0x615da4: r2 = Null
    //     0x615da4: mov             x2, NULL
    // 0x615da8: r0 = AllocateClosure()
    //     0x615da8: bl              #0x826750  ; AllocateClosureStub
    // 0x615dac: mov             x1, x0
    // 0x615db0: ldur            x0, [fp, #-0xb0]
    // 0x615db4: StoreField: r0->field_47 = r1
    //     0x615db4: stur            w1, [x0, #0x47]
    // 0x615db8: ldur            x1, [fp, #-0x50]
    // 0x615dbc: StoreField: r0->field_4b = r1
    //     0x615dbc: stur            w1, [x0, #0x4b]
    // 0x615dc0: ldur            x1, [fp, #-0xa8]
    // 0x615dc4: StoreField: r0->field_4f = r1
    //     0x615dc4: stur            w1, [x0, #0x4f]
    // 0x615dc8: ldur            x2, [fp, #-0x20]
    // 0x615dcc: LoadField: r1 = r2->field_b
    //     0x615dcc: ldur            w1, [x2, #0xb]
    // 0x615dd0: LoadField: r3 = r2->field_f
    //     0x615dd0: ldur            w3, [x2, #0xf]
    // 0x615dd4: DecompressPointer r3
    //     0x615dd4: add             x3, x3, HEAP, lsl #32
    // 0x615dd8: LoadField: r4 = r3->field_b
    //     0x615dd8: ldur            w4, [x3, #0xb]
    // 0x615ddc: r3 = LoadInt32Instr(r1)
    //     0x615ddc: sbfx            x3, x1, #1, #0x1f
    // 0x615de0: r17 = -272
    //     0x615de0: movn            x17, #0x10f
    // 0x615de4: str             x3, [fp, x17]
    // 0x615de8: r1 = LoadInt32Instr(r4)
    //     0x615de8: sbfx            x1, x4, #1, #0x1f
    // 0x615dec: cmp             x3, x1
    // 0x615df0: b.ne            #0x615dfc
    // 0x615df4: mov             x1, x2
    // 0x615df8: r0 = _growToNextCapacity()
    //     0x615df8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x615dfc: ldur            x3, [fp, #-0x20]
    // 0x615e00: r17 = -272
    //     0x615e00: movn            x17, #0x10f
    // 0x615e04: ldr             x2, [fp, x17]
    // 0x615e08: add             x0, x2, #1
    // 0x615e0c: lsl             x1, x0, #1
    // 0x615e10: StoreField: r3->field_b = r1
    //     0x615e10: stur            w1, [x3, #0xb]
    // 0x615e14: LoadField: r1 = r3->field_f
    //     0x615e14: ldur            w1, [x3, #0xf]
    // 0x615e18: DecompressPointer r1
    //     0x615e18: add             x1, x1, HEAP, lsl #32
    // 0x615e1c: ldur            x0, [fp, #-0xb0]
    // 0x615e20: ArrayStore: r1[r2] = r0  ; List_4
    //     0x615e20: add             x25, x1, x2, lsl #2
    //     0x615e24: add             x25, x25, #0xf
    //     0x615e28: str             w0, [x25]
    //     0x615e2c: tbz             w0, #0, #0x615e48
    //     0x615e30: ldurb           w16, [x1, #-1]
    //     0x615e34: ldurb           w17, [x0, #-1]
    //     0x615e38: and             x16, x17, x16, lsr #2
    //     0x615e3c: tst             x16, HEAP, lsr #32
    //     0x615e40: b.eq            #0x615e48
    //     0x615e44: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x615e48: ldur            x5, [fp, #-0x28]
    // 0x615e4c: ldur            x4, [fp, #-0x30]
    // 0x615e50: ldur            x0, [fp, #-8]
    // 0x615e54: stur            x5, [fp, #-0x58]
    // 0x615e58: stur            x4, [fp, #-0x60]
    // 0x615e5c: LoadField: r1 = r0->field_b
    //     0x615e5c: ldur            w1, [x0, #0xb]
    // 0x615e60: DecompressPointer r1
    //     0x615e60: add             x1, x1, HEAP, lsl #32
    // 0x615e64: cmp             w1, NULL
    // 0x615e68: b.eq            #0x6168f0
    // 0x615e6c: LoadField: r6 = r1->field_6f
    //     0x615e6c: ldur            w6, [x1, #0x6f]
    // 0x615e70: DecompressPointer r6
    //     0x615e70: add             x6, x6, HEAP, lsl #32
    // 0x615e74: stur            x6, [fp, #-0x50]
    // 0x615e78: cmp             w6, NULL
    // 0x615e7c: b.ne            #0x615e88
    // 0x615e80: r0 = Null
    //     0x615e80: mov             x0, NULL
    // 0x615e84: b               #0x615eb8
    // 0x615e88: mov             x1, x6
    // 0x615e8c: ldur            x2, [fp, #-0x48]
    // 0x615e90: r0 = _getValueOrData()
    //     0x615e90: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x615e94: mov             x1, x0
    // 0x615e98: ldur            x0, [fp, #-0x50]
    // 0x615e9c: LoadField: r2 = r0->field_f
    //     0x615e9c: ldur            w2, [x0, #0xf]
    // 0x615ea0: DecompressPointer r2
    //     0x615ea0: add             x2, x2, HEAP, lsl #32
    // 0x615ea4: cmp             w2, w1
    // 0x615ea8: b.ne            #0x615eb4
    // 0x615eac: r0 = Null
    //     0x615eac: mov             x0, NULL
    // 0x615eb0: b               #0x615eb8
    // 0x615eb4: mov             x0, x1
    // 0x615eb8: stur            x0, [fp, #-0x48]
    // 0x615ebc: cmp             w0, NULL
    // 0x615ec0: b.eq            #0x615f6c
    // 0x615ec4: ldur            x1, [fp, #-0x20]
    // 0x615ec8: r0 = Padding()
    //     0x615ec8: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x615ecc: mov             x2, x0
    // 0x615ed0: r0 = Instance_EdgeInsets
    //     0x615ed0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe260] Obj!EdgeInsets@8321f1
    //     0x615ed4: ldr             x0, [x0, #0x260]
    // 0x615ed8: stur            x2, [fp, #-0x50]
    // 0x615edc: StoreField: r2->field_f = r0
    //     0x615edc: stur            w0, [x2, #0xf]
    // 0x615ee0: ldur            x1, [fp, #-0x48]
    // 0x615ee4: StoreField: r2->field_b = r1
    //     0x615ee4: stur            w1, [x2, #0xb]
    // 0x615ee8: ldur            x3, [fp, #-0x20]
    // 0x615eec: LoadField: r1 = r3->field_b
    //     0x615eec: ldur            w1, [x3, #0xb]
    // 0x615ef0: LoadField: r4 = r3->field_f
    //     0x615ef0: ldur            w4, [x3, #0xf]
    // 0x615ef4: DecompressPointer r4
    //     0x615ef4: add             x4, x4, HEAP, lsl #32
    // 0x615ef8: LoadField: r5 = r4->field_b
    //     0x615ef8: ldur            w5, [x4, #0xb]
    // 0x615efc: r4 = LoadInt32Instr(r1)
    //     0x615efc: sbfx            x4, x1, #1, #0x1f
    // 0x615f00: r17 = -272
    //     0x615f00: movn            x17, #0x10f
    // 0x615f04: str             x4, [fp, x17]
    // 0x615f08: r1 = LoadInt32Instr(r5)
    //     0x615f08: sbfx            x1, x5, #1, #0x1f
    // 0x615f0c: cmp             x4, x1
    // 0x615f10: b.ne            #0x615f1c
    // 0x615f14: mov             x1, x3
    // 0x615f18: r0 = _growToNextCapacity()
    //     0x615f18: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x615f1c: ldur            x2, [fp, #-0x20]
    // 0x615f20: r17 = -272
    //     0x615f20: movn            x17, #0x10f
    // 0x615f24: ldr             x3, [fp, x17]
    // 0x615f28: add             x0, x3, #1
    // 0x615f2c: lsl             x1, x0, #1
    // 0x615f30: StoreField: r2->field_b = r1
    //     0x615f30: stur            w1, [x2, #0xb]
    // 0x615f34: LoadField: r1 = r2->field_f
    //     0x615f34: ldur            w1, [x2, #0xf]
    // 0x615f38: DecompressPointer r1
    //     0x615f38: add             x1, x1, HEAP, lsl #32
    // 0x615f3c: ldur            x0, [fp, #-0x50]
    // 0x615f40: ArrayStore: r1[r3] = r0  ; List_4
    //     0x615f40: add             x25, x1, x3, lsl #2
    //     0x615f44: add             x25, x25, #0xf
    //     0x615f48: str             w0, [x25]
    //     0x615f4c: tbz             w0, #0, #0x615f68
    //     0x615f50: ldurb           w16, [x1, #-1]
    //     0x615f54: ldurb           w17, [x0, #-1]
    //     0x615f58: and             x16, x17, x16, lsr #2
    //     0x615f5c: tst             x16, HEAP, lsr #32
    //     0x615f60: b.eq            #0x615f68
    //     0x615f64: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x615f68: b               #0x615f70
    // 0x615f6c: ldur            x2, [fp, #-0x20]
    // 0x615f70: ldur            x8, [fp, #-0x58]
    // 0x615f74: ldur            x7, [fp, #-0x60]
    // 0x615f78: mov             x5, x2
    // 0x615f7c: ldur            x2, [fp, #-8]
    // 0x615f80: ldur            x3, [fp, #-0x40]
    // 0x615f84: ldur            x4, [fp, #-0x38]
    // 0x615f88: b               #0x615510
    // 0x615f8c: ldur            x2, [fp, #-0x20]
    // 0x615f90: ldur            x0, [fp, #-0x28]
    // 0x615f94: tbnz            w0, #4, #0x616284
    // 0x615f98: ldur            x1, [fp, #-8]
    // 0x615f9c: LoadField: r0 = r1->field_b
    //     0x615f9c: ldur            w0, [x1, #0xb]
    // 0x615fa0: DecompressPointer r0
    //     0x615fa0: add             x0, x0, HEAP, lsl #32
    // 0x615fa4: cmp             w0, NULL
    // 0x615fa8: b.eq            #0x6168f4
    // 0x615fac: LoadField: r3 = r0->field_3b
    //     0x615fac: ldur            w3, [x0, #0x3b]
    // 0x615fb0: DecompressPointer r3
    //     0x615fb0: add             x3, x3, HEAP, lsl #32
    // 0x615fb4: str             x3, [SP]
    // 0x615fb8: mov             x0, x3
    // 0x615fbc: ClosureCall
    //     0x615fbc: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x615fc0: ldur            x2, [x0, #0x1f]
    //     0x615fc4: blr             x2
    // 0x615fc8: r16 = true
    //     0x615fc8: add             x16, NULL, #0x20  ; true
    // 0x615fcc: cmp             w0, w16
    // 0x615fd0: b.ne            #0x616284
    // 0x615fd4: ldur            x0, [fp, #-0x18]
    // 0x615fd8: tbnz            w0, #4, #0x615fe8
    // 0x615fdc: r0 = "Per Second"
    //     0x615fdc: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c778] "Per Second"
    //     0x615fe0: ldr             x0, [x0, #0x778]
    // 0x615fe4: b               #0x615ff0
    // 0x615fe8: r0 = "Raw"
    //     0x615fe8: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c780] "Raw"
    //     0x615fec: ldr             x0, [x0, #0x780]
    // 0x615ff0: ldur            x2, [fp, #-0x10]
    // 0x615ff4: stur            x0, [fp, #-0x18]
    // 0x615ff8: r0 = Text()
    //     0x615ff8: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x615ffc: mov             x1, x0
    // 0x616000: ldur            x0, [fp, #-0x18]
    // 0x616004: stur            x1, [fp, #-0x28]
    // 0x616008: StoreField: r1->field_b = r0
    //     0x616008: stur            w0, [x1, #0xb]
    // 0x61600c: r0 = OutlinedButton()
    //     0x61600c: bl              #0x5a427c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x44)
    // 0x616010: mov             x3, x0
    // 0x616014: r0 = false
    //     0x616014: add             x0, NULL, #0x30  ; false
    // 0x616018: stur            x3, [fp, #-0x18]
    // 0x61601c: StoreField: r3->field_3f = r0
    //     0x61601c: stur            w0, [x3, #0x3f]
    // 0x616020: ldur            x2, [fp, #-0x10]
    // 0x616024: r1 = Function '<anonymous closure>':.
    //     0x616024: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c788] AnonymousClosure: (0x616e14), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] GeneratorGroupState::build (0x6153ac)
    //     0x616028: ldr             x1, [x1, #0x788]
    // 0x61602c: r0 = AllocateClosure()
    //     0x61602c: bl              #0x826750  ; AllocateClosureStub
    // 0x616030: mov             x1, x0
    // 0x616034: ldur            x0, [fp, #-0x18]
    // 0x616038: StoreField: r0->field_b = r1
    //     0x616038: stur            w1, [x0, #0xb]
    // 0x61603c: r1 = false
    //     0x61603c: add             x1, NULL, #0x30  ; false
    // 0x616040: StoreField: r0->field_27 = r1
    //     0x616040: stur            w1, [x0, #0x27]
    // 0x616044: r2 = true
    //     0x616044: add             x2, NULL, #0x20  ; true
    // 0x616048: StoreField: r0->field_2f = r2
    //     0x616048: stur            w2, [x0, #0x2f]
    // 0x61604c: ldur            x3, [fp, #-0x28]
    // 0x616050: StoreField: r0->field_3b = r3
    //     0x616050: stur            w3, [x0, #0x3b]
    // 0x616054: ldur            x3, [fp, #-0x10]
    // 0x616058: LoadField: r4 = r3->field_13
    //     0x616058: ldur            w4, [x3, #0x13]
    // 0x61605c: DecompressPointer r4
    //     0x61605c: add             x4, x4, HEAP, lsl #32
    // 0x616060: r16 = Instance_BuyOption
    //     0x616060: add             x16, PP, #0x27, lsl #12  ; [pp+0x27850] Obj!BuyOption@85ea41
    //     0x616064: ldr             x16, [x16, #0x850]
    // 0x616068: cmp             w4, w16
    // 0x61606c: b.ne            #0x61607c
    // 0x616070: r4 = "Buy One"
    //     0x616070: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2c790] "Buy One"
    //     0x616074: ldr             x4, [x4, #0x790]
    // 0x616078: b               #0x6160a0
    // 0x61607c: r16 = Instance_BuyOption
    //     0x61607c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c798] Obj!BuyOption@85ea21
    //     0x616080: ldr             x16, [x16, #0x798]
    // 0x616084: cmp             w4, w16
    // 0x616088: b.ne            #0x616098
    // 0x61608c: r4 = "Buy Max"
    //     0x61608c: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2c7a0] "Buy Max"
    //     0x616090: ldr             x4, [x4, #0x7a0]
    // 0x616094: b               #0x6160a0
    // 0x616098: r4 = "Buy Next"
    //     0x616098: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2c7a8] "Buy Next"
    //     0x61609c: ldr             x4, [x4, #0x7a8]
    // 0x6160a0: stur            x4, [fp, #-0x28]
    // 0x6160a4: r0 = Text()
    //     0x6160a4: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x6160a8: mov             x3, x0
    // 0x6160ac: ldur            x0, [fp, #-0x28]
    // 0x6160b0: stur            x3, [fp, #-0x40]
    // 0x6160b4: StoreField: r3->field_b = r0
    //     0x6160b4: stur            w0, [x3, #0xb]
    // 0x6160b8: r1 = Null
    //     0x6160b8: mov             x1, NULL
    // 0x6160bc: r2 = 6
    //     0x6160bc: movz            x2, #0x6
    // 0x6160c0: r0 = AllocateArray()
    //     0x6160c0: bl              #0x82746c  ; AllocateArrayStub
    // 0x6160c4: stur            x0, [fp, #-0x28]
    // 0x6160c8: r16 = Instance_SizedBox
    //     0x6160c8: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c7b0] Obj!SizedBox@85d5a1
    //     0x6160cc: ldr             x16, [x16, #0x7b0]
    // 0x6160d0: StoreField: r0->field_f = r16
    //     0x6160d0: stur            w16, [x0, #0xf]
    // 0x6160d4: ldur            x1, [fp, #-0x40]
    // 0x6160d8: StoreField: r0->field_13 = r1
    //     0x6160d8: stur            w1, [x0, #0x13]
    // 0x6160dc: r16 = Instance_Icon
    //     0x6160dc: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c7b8] Obj!Icon@856c31
    //     0x6160e0: ldr             x16, [x16, #0x7b8]
    // 0x6160e4: ArrayStore: r0[0] = r16  ; List_4
    //     0x6160e4: stur            w16, [x0, #0x17]
    // 0x6160e8: r1 = <Widget>
    //     0x6160e8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6160ec: r0 = AllocateGrowableArray()
    //     0x6160ec: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6160f0: mov             x1, x0
    // 0x6160f4: ldur            x0, [fp, #-0x28]
    // 0x6160f8: stur            x1, [fp, #-0x40]
    // 0x6160fc: StoreField: r1->field_f = r0
    //     0x6160fc: stur            w0, [x1, #0xf]
    // 0x616100: r2 = 6
    //     0x616100: movz            x2, #0x6
    // 0x616104: StoreField: r1->field_b = r2
    //     0x616104: stur            w2, [x1, #0xb]
    // 0x616108: r0 = Row()
    //     0x616108: bl              #0x59e9b8  ; AllocateRowStub -> Row (size=0x38)
    // 0x61610c: mov             x1, x0
    // 0x616110: r0 = Instance_Axis
    //     0x616110: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x616114: stur            x1, [fp, #-0x28]
    // 0x616118: StoreField: r1->field_f = r0
    //     0x616118: stur            w0, [x1, #0xf]
    // 0x61611c: r2 = Instance_MainAxisAlignment
    //     0x61611c: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x616120: ldr             x2, [x2, #0x200]
    // 0x616124: StoreField: r1->field_13 = r2
    //     0x616124: stur            w2, [x1, #0x13]
    // 0x616128: r3 = Instance_MainAxisSize
    //     0x616128: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x61612c: ldr             x3, [x3, #0x70]
    // 0x616130: ArrayStore: r1[0] = r3  ; List_4
    //     0x616130: stur            w3, [x1, #0x17]
    // 0x616134: r4 = Instance_CrossAxisAlignment
    //     0x616134: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x616138: ldr             x4, [x4, #0x78]
    // 0x61613c: StoreField: r1->field_1b = r4
    //     0x61613c: stur            w4, [x1, #0x1b]
    // 0x616140: r5 = Instance_VerticalDirection
    //     0x616140: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x616144: ldr             x5, [x5, #0x1e8]
    // 0x616148: StoreField: r1->field_23 = r5
    //     0x616148: stur            w5, [x1, #0x23]
    // 0x61614c: r6 = Instance_Clip
    //     0x61614c: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x616150: ldr             x6, [x6, #0x1b0]
    // 0x616154: StoreField: r1->field_2b = r6
    //     0x616154: stur            w6, [x1, #0x2b]
    // 0x616158: StoreField: r1->field_2f = rZR
    //     0x616158: stur            xzr, [x1, #0x2f]
    // 0x61615c: ldur            x7, [fp, #-0x40]
    // 0x616160: StoreField: r1->field_b = r7
    //     0x616160: stur            w7, [x1, #0xb]
    // 0x616164: r0 = OutlinedButton()
    //     0x616164: bl              #0x5a427c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x44)
    // 0x616168: mov             x3, x0
    // 0x61616c: r0 = false
    //     0x61616c: add             x0, NULL, #0x30  ; false
    // 0x616170: stur            x3, [fp, #-0x40]
    // 0x616174: StoreField: r3->field_3f = r0
    //     0x616174: stur            w0, [x3, #0x3f]
    // 0x616178: ldur            x2, [fp, #-0x10]
    // 0x61617c: r1 = Function '<anonymous closure>':.
    //     0x61617c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c7c0] AnonymousClosure: (0x616b84), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] GeneratorGroupState::build (0x6153ac)
    //     0x616180: ldr             x1, [x1, #0x7c0]
    // 0x616184: r0 = AllocateClosure()
    //     0x616184: bl              #0x826750  ; AllocateClosureStub
    // 0x616188: mov             x1, x0
    // 0x61618c: ldur            x0, [fp, #-0x40]
    // 0x616190: StoreField: r0->field_b = r1
    //     0x616190: stur            w1, [x0, #0xb]
    // 0x616194: r1 = false
    //     0x616194: add             x1, NULL, #0x30  ; false
    // 0x616198: StoreField: r0->field_27 = r1
    //     0x616198: stur            w1, [x0, #0x27]
    // 0x61619c: r1 = true
    //     0x61619c: add             x1, NULL, #0x20  ; true
    // 0x6161a0: StoreField: r0->field_2f = r1
    //     0x6161a0: stur            w1, [x0, #0x2f]
    // 0x6161a4: ldur            x1, [fp, #-0x28]
    // 0x6161a8: StoreField: r0->field_3b = r1
    //     0x6161a8: stur            w1, [x0, #0x3b]
    // 0x6161ac: r1 = Null
    //     0x6161ac: mov             x1, NULL
    // 0x6161b0: r2 = 6
    //     0x6161b0: movz            x2, #0x6
    // 0x6161b4: r0 = AllocateArray()
    //     0x6161b4: bl              #0x82746c  ; AllocateArrayStub
    // 0x6161b8: mov             x2, x0
    // 0x6161bc: ldur            x0, [fp, #-0x18]
    // 0x6161c0: stur            x2, [fp, #-0x10]
    // 0x6161c4: StoreField: r2->field_f = r0
    //     0x6161c4: stur            w0, [x2, #0xf]
    // 0x6161c8: r16 = Instance_Flexible
    //     0x6161c8: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c348] Obj!Flexible@85e0a1
    //     0x6161cc: ldr             x16, [x16, #0x348]
    // 0x6161d0: StoreField: r2->field_13 = r16
    //     0x6161d0: stur            w16, [x2, #0x13]
    // 0x6161d4: ldur            x0, [fp, #-0x40]
    // 0x6161d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x6161d8: stur            w0, [x2, #0x17]
    // 0x6161dc: r1 = <Widget>
    //     0x6161dc: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6161e0: r0 = AllocateGrowableArray()
    //     0x6161e0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6161e4: mov             x1, x0
    // 0x6161e8: ldur            x0, [fp, #-0x10]
    // 0x6161ec: stur            x1, [fp, #-0x18]
    // 0x6161f0: StoreField: r1->field_f = r0
    //     0x6161f0: stur            w0, [x1, #0xf]
    // 0x6161f4: r0 = 6
    //     0x6161f4: movz            x0, #0x6
    // 0x6161f8: StoreField: r1->field_b = r0
    //     0x6161f8: stur            w0, [x1, #0xb]
    // 0x6161fc: r0 = Row()
    //     0x6161fc: bl              #0x59e9b8  ; AllocateRowStub -> Row (size=0x38)
    // 0x616200: mov             x1, x0
    // 0x616204: r0 = Instance_Axis
    //     0x616204: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x616208: stur            x1, [fp, #-0x10]
    // 0x61620c: StoreField: r1->field_f = r0
    //     0x61620c: stur            w0, [x1, #0xf]
    // 0x616210: r2 = Instance_MainAxisAlignment
    //     0x616210: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x616214: ldr             x2, [x2, #0x200]
    // 0x616218: StoreField: r1->field_13 = r2
    //     0x616218: stur            w2, [x1, #0x13]
    // 0x61621c: r3 = Instance_MainAxisSize
    //     0x61621c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x616220: ldr             x3, [x3, #0x70]
    // 0x616224: ArrayStore: r1[0] = r3  ; List_4
    //     0x616224: stur            w3, [x1, #0x17]
    // 0x616228: r4 = Instance_CrossAxisAlignment
    //     0x616228: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x61622c: ldr             x4, [x4, #0x78]
    // 0x616230: StoreField: r1->field_1b = r4
    //     0x616230: stur            w4, [x1, #0x1b]
    // 0x616234: r5 = Instance_VerticalDirection
    //     0x616234: add             x5, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x616238: ldr             x5, [x5, #0x1e8]
    // 0x61623c: StoreField: r1->field_23 = r5
    //     0x61623c: stur            w5, [x1, #0x23]
    // 0x616240: r6 = Instance_Clip
    //     0x616240: add             x6, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x616244: ldr             x6, [x6, #0x1b0]
    // 0x616248: StoreField: r1->field_2b = r6
    //     0x616248: stur            w6, [x1, #0x2b]
    // 0x61624c: StoreField: r1->field_2f = rZR
    //     0x61624c: stur            xzr, [x1, #0x2f]
    // 0x616250: ldur            x7, [fp, #-0x18]
    // 0x616254: StoreField: r1->field_b = r7
    //     0x616254: stur            w7, [x1, #0xb]
    // 0x616258: r0 = Padding()
    //     0x616258: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x61625c: mov             x1, x0
    // 0x616260: r0 = Instance_EdgeInsets
    //     0x616260: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c7c8] Obj!EdgeInsets@8325e1
    //     0x616264: ldr             x0, [x0, #0x7c8]
    // 0x616268: StoreField: r1->field_f = r0
    //     0x616268: stur            w0, [x1, #0xf]
    // 0x61626c: ldur            x0, [fp, #-0x10]
    // 0x616270: StoreField: r1->field_b = r0
    //     0x616270: stur            w0, [x1, #0xb]
    // 0x616274: mov             x3, x1
    // 0x616278: ldur            x1, [fp, #-0x20]
    // 0x61627c: r2 = 0
    //     0x61627c: movz            x2, #0
    // 0x616280: r0 = insert()
    //     0x616280: bl              #0x3623a4  ; [dart:core] _GrowableList::insert
    // 0x616284: ldur            x0, [fp, #-8]
    // 0x616288: LoadField: r1 = r0->field_b
    //     0x616288: ldur            w1, [x0, #0xb]
    // 0x61628c: DecompressPointer r1
    //     0x61628c: add             x1, x1, HEAP, lsl #32
    // 0x616290: cmp             w1, NULL
    // 0x616294: b.eq            #0x6168f8
    // 0x616298: LoadField: r3 = r1->field_f
    //     0x616298: ldur            w3, [x1, #0xf]
    // 0x61629c: DecompressPointer r3
    //     0x61629c: add             x3, x3, HEAP, lsl #32
    // 0x6162a0: cmp             w3, NULL
    // 0x6162a4: b.eq            #0x6162b4
    // 0x6162a8: ldur            x1, [fp, #-0x20]
    // 0x6162ac: r2 = 0
    //     0x6162ac: movz            x2, #0
    // 0x6162b0: r0 = insert()
    //     0x6162b0: bl              #0x3623a4  ; [dart:core] _GrowableList::insert
    // 0x6162b4: ldur            x0, [fp, #-8]
    // 0x6162b8: r1 = <Widget>
    //     0x6162b8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6162bc: r2 = 0
    //     0x6162bc: movz            x2, #0
    // 0x6162c0: r0 = _GrowableList()
    //     0x6162c0: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x6162c4: mov             x2, x0
    // 0x6162c8: ldur            x0, [fp, #-8]
    // 0x6162cc: stur            x2, [fp, #-0x10]
    // 0x6162d0: LoadField: r1 = r0->field_b
    //     0x6162d0: ldur            w1, [x0, #0xb]
    // 0x6162d4: DecompressPointer r1
    //     0x6162d4: add             x1, x1, HEAP, lsl #32
    // 0x6162d8: cmp             w1, NULL
    // 0x6162dc: b.eq            #0x6168fc
    // 0x6162e0: LoadField: r3 = r1->field_13
    //     0x6162e0: ldur            w3, [x1, #0x13]
    // 0x6162e4: DecompressPointer r3
    //     0x6162e4: add             x3, x3, HEAP, lsl #32
    // 0x6162e8: cmp             w3, NULL
    // 0x6162ec: b.eq            #0x616510
    // 0x6162f0: mov             x1, x0
    // 0x6162f4: r0 = getIndexToAdd()
    //     0x6162f4: bl              #0x616924  ; [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] GeneratorGroupState::getIndexToAdd
    // 0x6162f8: mov             x3, x0
    // 0x6162fc: stur            x3, [fp, #-0x68]
    // 0x616300: cmp             w3, NULL
    // 0x616304: b.eq            #0x616508
    // 0x616308: ldur            x4, [fp, #-8]
    // 0x61630c: ldur            x5, [fp, #-0x10]
    // 0x616310: LoadField: r6 = r4->field_b
    //     0x616310: ldur            w6, [x4, #0xb]
    // 0x616314: DecompressPointer r6
    //     0x616314: add             x6, x6, HEAP, lsl #32
    // 0x616318: stur            x6, [fp, #-0x60]
    // 0x61631c: cmp             w6, NULL
    // 0x616320: b.eq            #0x616900
    // 0x616324: LoadField: r7 = r6->field_13
    //     0x616324: ldur            w7, [x6, #0x13]
    // 0x616328: DecompressPointer r7
    //     0x616328: add             x7, x7, HEAP, lsl #32
    // 0x61632c: stur            x7, [fp, #-0x58]
    // 0x616330: cmp             w7, NULL
    // 0x616334: b.eq            #0x616904
    // 0x616338: LoadField: r8 = r6->field_23
    //     0x616338: ldur            w8, [x6, #0x23]
    // 0x61633c: DecompressPointer r8
    //     0x61633c: add             x8, x8, HEAP, lsl #32
    // 0x616340: stur            x8, [fp, #-0x50]
    // 0x616344: LoadField: r9 = r6->field_27
    //     0x616344: ldur            w9, [x6, #0x27]
    // 0x616348: DecompressPointer r9
    //     0x616348: add             x9, x9, HEAP, lsl #32
    // 0x61634c: stur            x9, [fp, #-0x48]
    // 0x616350: LoadField: r10 = r6->field_2f
    //     0x616350: ldur            w10, [x6, #0x2f]
    // 0x616354: DecompressPointer r10
    //     0x616354: add             x10, x10, HEAP, lsl #32
    // 0x616358: stur            x10, [fp, #-0x40]
    // 0x61635c: LoadField: r11 = r6->field_1f
    //     0x61635c: ldur            w11, [x6, #0x1f]
    // 0x616360: DecompressPointer r11
    //     0x616360: add             x11, x11, HEAP, lsl #32
    // 0x616364: stur            x11, [fp, #-0x28]
    // 0x616368: LoadField: r12 = r6->field_5b
    //     0x616368: ldur            w12, [x6, #0x5b]
    // 0x61636c: DecompressPointer r12
    //     0x61636c: add             x12, x12, HEAP, lsl #32
    // 0x616370: mov             x0, x12
    // 0x616374: ldur            x2, [fp, #-0x38]
    // 0x616378: stur            x12, [fp, #-0x18]
    // 0x61637c: r1 = Null
    //     0x61637c: mov             x1, NULL
    // 0x616380: r8 = (dynamic this, Map<int, double>, ((dynamic this, int, num) => Tuple2<C3X0, CustomNum>)?, int, int, bool allowSave, bool test) => num
    //     0x616380: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c5b8] FunctionType: (dynamic this, Map<int, double>, ((dynamic this, int, num) => Tuple2<C3X0, CustomNum>)?, int, int, bool allowSave, bool test) => num
    //     0x616384: ldr             x8, [x8, #0x5b8]
    // 0x616388: LoadField: r9 = r8->field_7
    //     0x616388: ldur            x9, [x8, #7]
    // 0x61638c: r3 = Null
    //     0x61638c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c7d0] Null
    //     0x616390: ldr             x3, [x3, #0x7d0]
    // 0x616394: blr             x9
    // 0x616398: ldur            x0, [fp, #-0x60]
    // 0x61639c: LoadField: r3 = r0->field_5f
    //     0x61639c: ldur            w3, [x0, #0x5f]
    // 0x6163a0: DecompressPointer r3
    //     0x6163a0: add             x3, x3, HEAP, lsl #32
    // 0x6163a4: stur            x3, [fp, #-0x78]
    // 0x6163a8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x6163a8: ldur            w4, [x0, #0x17]
    // 0x6163ac: DecompressPointer r4
    //     0x6163ac: add             x4, x4, HEAP, lsl #32
    // 0x6163b0: mov             x0, x4
    // 0x6163b4: ldur            x2, [fp, #-0x38]
    // 0x6163b8: stur            x4, [fp, #-0x70]
    // 0x6163bc: r1 = Null
    //     0x6163bc: mov             x1, NULL
    // 0x6163c0: r8 = (dynamic this, C3X0?) => String?
    //     0x6163c0: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x6163c4: ldr             x8, [x8, #0xe90]
    // 0x6163c8: LoadField: r9 = r8->field_7
    //     0x6163c8: ldur            x9, [x8, #7]
    // 0x6163cc: r3 = Null
    //     0x6163cc: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c7e0] Null
    //     0x6163d0: ldr             x3, [x3, #0x7e0]
    // 0x6163d4: blr             x9
    // 0x6163d8: ldur            x2, [fp, #-0x38]
    // 0x6163dc: r1 = Null
    //     0x6163dc: mov             x1, NULL
    // 0x6163e0: r3 = <C3X0>
    //     0x6163e0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e50] TypeArguments: <C3X0>
    //     0x6163e4: ldr             x3, [x3, #0xe50]
    // 0x6163e8: r0 = Null
    //     0x6163e8: mov             x0, NULL
    // 0x6163ec: cmp             x2, x0
    // 0x6163f0: b.eq            #0x616400
    // 0x6163f4: r30 = InstantiateTypeArgumentsStub
    //     0x6163f4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x6163f8: LoadField: r30 = r30->field_7
    //     0x6163f8: ldur            lr, [lr, #7]
    // 0x6163fc: blr             lr
    // 0x616400: mov             x1, x0
    // 0x616404: r0 = GeneratorBuyButton()
    //     0x616404: bl              #0x616918  ; AllocateGeneratorBuyButtonStub -> GeneratorBuyButton<X0> (size=0x38)
    // 0x616408: mov             x1, x0
    // 0x61640c: ldur            x0, [fp, #-0x50]
    // 0x616410: stur            x1, [fp, #-0x60]
    // 0x616414: ArrayStore: r1[0] = r0  ; List_4
    //     0x616414: stur            w0, [x1, #0x17]
    // 0x616418: ldur            x0, [fp, #-0x48]
    // 0x61641c: StoreField: r1->field_23 = r0
    //     0x61641c: stur            w0, [x1, #0x23]
    // 0x616420: ldur            x0, [fp, #-0x40]
    // 0x616424: StoreField: r1->field_27 = r0
    //     0x616424: stur            w0, [x1, #0x27]
    // 0x616428: ldur            x0, [fp, #-0x68]
    // 0x61642c: r2 = LoadInt32Instr(r0)
    //     0x61642c: sbfx            x2, x0, #1, #0x1f
    //     0x616430: tbz             w0, #0, #0x616438
    //     0x616434: ldur            x2, [x0, #7]
    // 0x616438: StoreField: r1->field_1b = r2
    //     0x616438: stur            x2, [x1, #0x1b]
    // 0x61643c: ldur            x0, [fp, #-0x28]
    // 0x616440: StoreField: r1->field_2b = r0
    //     0x616440: stur            w0, [x1, #0x2b]
    // 0x616444: ldur            x0, [fp, #-0x18]
    // 0x616448: StoreField: r1->field_2f = r0
    //     0x616448: stur            w0, [x1, #0x2f]
    // 0x61644c: ldur            x0, [fp, #-0x70]
    // 0x616450: StoreField: r1->field_13 = r0
    //     0x616450: stur            w0, [x1, #0x13]
    // 0x616454: ldur            x0, [fp, #-0x58]
    // 0x616458: StoreField: r1->field_f = r0
    //     0x616458: stur            w0, [x1, #0xf]
    // 0x61645c: ldur            x0, [fp, #-0x78]
    // 0x616460: StoreField: r1->field_33 = r0
    //     0x616460: stur            w0, [x1, #0x33]
    // 0x616464: r0 = Padding()
    //     0x616464: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x616468: mov             x2, x0
    // 0x61646c: r0 = Instance_EdgeInsets
    //     0x61646c: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c7f0] Obj!EdgeInsets@8325b1
    //     0x616470: ldr             x0, [x0, #0x7f0]
    // 0x616474: stur            x2, [fp, #-0x18]
    // 0x616478: StoreField: r2->field_f = r0
    //     0x616478: stur            w0, [x2, #0xf]
    // 0x61647c: ldur            x0, [fp, #-0x60]
    // 0x616480: StoreField: r2->field_b = r0
    //     0x616480: stur            w0, [x2, #0xb]
    // 0x616484: ldur            x0, [fp, #-0x10]
    // 0x616488: LoadField: r1 = r0->field_b
    //     0x616488: ldur            w1, [x0, #0xb]
    // 0x61648c: LoadField: r3 = r0->field_f
    //     0x61648c: ldur            w3, [x0, #0xf]
    // 0x616490: DecompressPointer r3
    //     0x616490: add             x3, x3, HEAP, lsl #32
    // 0x616494: LoadField: r4 = r3->field_b
    //     0x616494: ldur            w4, [x3, #0xb]
    // 0x616498: r3 = LoadInt32Instr(r1)
    //     0x616498: sbfx            x3, x1, #1, #0x1f
    // 0x61649c: r17 = -272
    //     0x61649c: movn            x17, #0x10f
    // 0x6164a0: str             x3, [fp, x17]
    // 0x6164a4: r1 = LoadInt32Instr(r4)
    //     0x6164a4: sbfx            x1, x4, #1, #0x1f
    // 0x6164a8: cmp             x3, x1
    // 0x6164ac: b.ne            #0x6164b8
    // 0x6164b0: mov             x1, x0
    // 0x6164b4: r0 = _growToNextCapacity()
    //     0x6164b4: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6164b8: ldur            x3, [fp, #-0x10]
    // 0x6164bc: r17 = -272
    //     0x6164bc: movn            x17, #0x10f
    // 0x6164c0: ldr             x2, [fp, x17]
    // 0x6164c4: add             x0, x2, #1
    // 0x6164c8: lsl             x1, x0, #1
    // 0x6164cc: StoreField: r3->field_b = r1
    //     0x6164cc: stur            w1, [x3, #0xb]
    // 0x6164d0: LoadField: r1 = r3->field_f
    //     0x6164d0: ldur            w1, [x3, #0xf]
    // 0x6164d4: DecompressPointer r1
    //     0x6164d4: add             x1, x1, HEAP, lsl #32
    // 0x6164d8: ldur            x0, [fp, #-0x18]
    // 0x6164dc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6164dc: add             x25, x1, x2, lsl #2
    //     0x6164e0: add             x25, x25, #0xf
    //     0x6164e4: str             w0, [x25]
    //     0x6164e8: tbz             w0, #0, #0x616504
    //     0x6164ec: ldurb           w16, [x1, #-1]
    //     0x6164f0: ldurb           w17, [x0, #-1]
    //     0x6164f4: and             x16, x17, x16, lsr #2
    //     0x6164f8: tst             x16, HEAP, lsr #32
    //     0x6164fc: b.eq            #0x616504
    //     0x616500: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x616504: b               #0x616514
    // 0x616508: ldur            x3, [fp, #-0x10]
    // 0x61650c: b               #0x616514
    // 0x616510: mov             x3, x2
    // 0x616514: ldur            x0, [fp, #-0x30]
    // 0x616518: tbnz            w0, #4, #0x6166c4
    // 0x61651c: ldur            x0, [fp, #-8]
    // 0x616520: LoadField: r4 = r0->field_b
    //     0x616520: ldur            w4, [x0, #0xb]
    // 0x616524: DecompressPointer r4
    //     0x616524: add             x4, x4, HEAP, lsl #32
    // 0x616528: stur            x4, [fp, #-0x28]
    // 0x61652c: cmp             w4, NULL
    // 0x616530: b.eq            #0x616908
    // 0x616534: LoadField: r5 = r4->field_2f
    //     0x616534: ldur            w5, [x4, #0x2f]
    // 0x616538: DecompressPointer r5
    //     0x616538: add             x5, x5, HEAP, lsl #32
    // 0x61653c: stur            x5, [fp, #-0x18]
    // 0x616540: LoadField: r6 = r4->field_1b
    //     0x616540: ldur            w6, [x4, #0x1b]
    // 0x616544: DecompressPointer r6
    //     0x616544: add             x6, x6, HEAP, lsl #32
    // 0x616548: mov             x0, x6
    // 0x61654c: ldur            x2, [fp, #-0x38]
    // 0x616550: stur            x6, [fp, #-8]
    // 0x616554: r1 = Null
    //     0x616554: mov             x1, NULL
    // 0x616558: r8 = (dynamic this, C3X0?) => String?
    //     0x616558: add             x8, PP, #0x2b, lsl #12  ; [pp+0x2be90] FunctionType: (dynamic this, C3X0?) => String?
    //     0x61655c: ldr             x8, [x8, #0xe90]
    // 0x616560: LoadField: r9 = r8->field_7
    //     0x616560: ldur            x9, [x8, #7]
    // 0x616564: r3 = Null
    //     0x616564: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c7f8] Null
    //     0x616568: ldr             x3, [x3, #0x7f8]
    // 0x61656c: blr             x9
    // 0x616570: ldur            x0, [fp, #-0x28]
    // 0x616574: LoadField: r4 = r0->field_37
    //     0x616574: ldur            w4, [x0, #0x37]
    // 0x616578: DecompressPointer r4
    //     0x616578: add             x4, x4, HEAP, lsl #32
    // 0x61657c: stur            x4, [fp, #-0x58]
    // 0x616580: LoadField: r5 = r0->field_33
    //     0x616580: ldur            w5, [x0, #0x33]
    // 0x616584: DecompressPointer r5
    //     0x616584: add             x5, x5, HEAP, lsl #32
    // 0x616588: stur            x5, [fp, #-0x50]
    // 0x61658c: LoadField: r6 = r0->field_1f
    //     0x61658c: ldur            w6, [x0, #0x1f]
    // 0x616590: DecompressPointer r6
    //     0x616590: add             x6, x6, HEAP, lsl #32
    // 0x616594: stur            x6, [fp, #-0x48]
    // 0x616598: LoadField: r7 = r0->field_53
    //     0x616598: ldur            w7, [x0, #0x53]
    // 0x61659c: DecompressPointer r7
    //     0x61659c: add             x7, x7, HEAP, lsl #32
    // 0x6165a0: stur            x7, [fp, #-0x40]
    // 0x6165a4: LoadField: r8 = r0->field_27
    //     0x6165a4: ldur            w8, [x0, #0x27]
    // 0x6165a8: DecompressPointer r8
    //     0x6165a8: add             x8, x8, HEAP, lsl #32
    // 0x6165ac: ldur            x2, [fp, #-0x38]
    // 0x6165b0: stur            x8, [fp, #-0x30]
    // 0x6165b4: r1 = Null
    //     0x6165b4: mov             x1, NULL
    // 0x6165b8: r3 = <C3X0>
    //     0x6165b8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e50] TypeArguments: <C3X0>
    //     0x6165bc: ldr             x3, [x3, #0xe50]
    // 0x6165c0: r0 = Null
    //     0x6165c0: mov             x0, NULL
    // 0x6165c4: cmp             x2, x0
    // 0x6165c8: b.eq            #0x6165d8
    // 0x6165cc: r30 = InstantiateTypeArgumentsStub
    //     0x6165cc: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x6165d0: LoadField: r30 = r30->field_7
    //     0x6165d0: ldur            lr, [lr, #7]
    // 0x6165d4: blr             lr
    // 0x6165d8: mov             x1, x0
    // 0x6165dc: r0 = AutoButton()
    //     0x6165dc: bl              #0x61690c  ; AllocateAutoButtonStub -> AutoButton<X0> (size=0x2c)
    // 0x6165e0: mov             x1, x0
    // 0x6165e4: ldur            x0, [fp, #-0x48]
    // 0x6165e8: stur            x1, [fp, #-0x28]
    // 0x6165ec: StoreField: r1->field_1b = r0
    //     0x6165ec: stur            w0, [x1, #0x1b]
    // 0x6165f0: ldur            x0, [fp, #-0x40]
    // 0x6165f4: StoreField: r1->field_1f = r0
    //     0x6165f4: stur            w0, [x1, #0x1f]
    // 0x6165f8: ldur            x0, [fp, #-0x30]
    // 0x6165fc: StoreField: r1->field_23 = r0
    //     0x6165fc: stur            w0, [x1, #0x23]
    // 0x616600: ldur            x0, [fp, #-0x50]
    // 0x616604: StoreField: r1->field_27 = r0
    //     0x616604: stur            w0, [x1, #0x27]
    // 0x616608: ldur            x0, [fp, #-0x58]
    // 0x61660c: ArrayStore: r1[0] = r0  ; List_4
    //     0x61660c: stur            w0, [x1, #0x17]
    // 0x616610: ldur            x0, [fp, #-8]
    // 0x616614: StoreField: r1->field_13 = r0
    //     0x616614: stur            w0, [x1, #0x13]
    // 0x616618: ldur            x0, [fp, #-0x18]
    // 0x61661c: StoreField: r1->field_f = r0
    //     0x61661c: stur            w0, [x1, #0xf]
    // 0x616620: r0 = Padding()
    //     0x616620: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x616624: mov             x2, x0
    // 0x616628: r0 = Instance_EdgeInsets
    //     0x616628: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c808] Obj!EdgeInsets@832581
    //     0x61662c: ldr             x0, [x0, #0x808]
    // 0x616630: stur            x2, [fp, #-8]
    // 0x616634: StoreField: r2->field_f = r0
    //     0x616634: stur            w0, [x2, #0xf]
    // 0x616638: ldur            x0, [fp, #-0x28]
    // 0x61663c: StoreField: r2->field_b = r0
    //     0x61663c: stur            w0, [x2, #0xb]
    // 0x616640: ldur            x0, [fp, #-0x10]
    // 0x616644: LoadField: r1 = r0->field_b
    //     0x616644: ldur            w1, [x0, #0xb]
    // 0x616648: LoadField: r3 = r0->field_f
    //     0x616648: ldur            w3, [x0, #0xf]
    // 0x61664c: DecompressPointer r3
    //     0x61664c: add             x3, x3, HEAP, lsl #32
    // 0x616650: LoadField: r4 = r3->field_b
    //     0x616650: ldur            w4, [x3, #0xb]
    // 0x616654: r3 = LoadInt32Instr(r1)
    //     0x616654: sbfx            x3, x1, #1, #0x1f
    // 0x616658: r17 = -272
    //     0x616658: movn            x17, #0x10f
    // 0x61665c: str             x3, [fp, x17]
    // 0x616660: r1 = LoadInt32Instr(r4)
    //     0x616660: sbfx            x1, x4, #1, #0x1f
    // 0x616664: cmp             x3, x1
    // 0x616668: b.ne            #0x616674
    // 0x61666c: mov             x1, x0
    // 0x616670: r0 = _growToNextCapacity()
    //     0x616670: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x616674: ldur            x2, [fp, #-0x10]
    // 0x616678: r17 = -272
    //     0x616678: movn            x17, #0x10f
    // 0x61667c: ldr             x3, [fp, x17]
    // 0x616680: add             x0, x3, #1
    // 0x616684: lsl             x1, x0, #1
    // 0x616688: StoreField: r2->field_b = r1
    //     0x616688: stur            w1, [x2, #0xb]
    // 0x61668c: LoadField: r1 = r2->field_f
    //     0x61668c: ldur            w1, [x2, #0xf]
    // 0x616690: DecompressPointer r1
    //     0x616690: add             x1, x1, HEAP, lsl #32
    // 0x616694: ldur            x0, [fp, #-8]
    // 0x616698: ArrayStore: r1[r3] = r0  ; List_4
    //     0x616698: add             x25, x1, x3, lsl #2
    //     0x61669c: add             x25, x25, #0xf
    //     0x6166a0: str             w0, [x25]
    //     0x6166a4: tbz             w0, #0, #0x6166c0
    //     0x6166a8: ldurb           w16, [x1, #-1]
    //     0x6166ac: ldurb           w17, [x0, #-1]
    //     0x6166b0: and             x16, x17, x16, lsr #2
    //     0x6166b4: tst             x16, HEAP, lsr #32
    //     0x6166b8: b.eq            #0x6166c0
    //     0x6166bc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6166c0: b               #0x6166c8
    // 0x6166c4: mov             x2, x3
    // 0x6166c8: LoadField: r0 = r2->field_b
    //     0x6166c8: ldur            w0, [x2, #0xb]
    // 0x6166cc: cbz             w0, #0x6167b8
    // 0x6166d0: ldur            x1, [fp, #-0x20]
    // 0x6166d4: r0 = Row()
    //     0x6166d4: bl              #0x59e9b8  ; AllocateRowStub -> Row (size=0x38)
    // 0x6166d8: mov             x2, x0
    // 0x6166dc: r0 = Instance_Axis
    //     0x6166dc: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x6166e0: stur            x2, [fp, #-8]
    // 0x6166e4: StoreField: r2->field_f = r0
    //     0x6166e4: stur            w0, [x2, #0xf]
    // 0x6166e8: r0 = Instance_MainAxisAlignment
    //     0x6166e8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d858] Obj!MainAxisAlignment@8629e1
    //     0x6166ec: ldr             x0, [x0, #0x858]
    // 0x6166f0: StoreField: r2->field_13 = r0
    //     0x6166f0: stur            w0, [x2, #0x13]
    // 0x6166f4: r0 = Instance_MainAxisSize
    //     0x6166f4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x6166f8: ldr             x0, [x0, #0x70]
    // 0x6166fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x6166fc: stur            w0, [x2, #0x17]
    // 0x616700: r3 = Instance_CrossAxisAlignment
    //     0x616700: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x616704: ldr             x3, [x3, #0x78]
    // 0x616708: StoreField: r2->field_1b = r3
    //     0x616708: stur            w3, [x2, #0x1b]
    // 0x61670c: r4 = Instance_VerticalDirection
    //     0x61670c: add             x4, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x616710: ldr             x4, [x4, #0x1e8]
    // 0x616714: StoreField: r2->field_23 = r4
    //     0x616714: stur            w4, [x2, #0x23]
    // 0x616718: r5 = Instance_Clip
    //     0x616718: add             x5, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x61671c: ldr             x5, [x5, #0x1b0]
    // 0x616720: StoreField: r2->field_2b = r5
    //     0x616720: stur            w5, [x2, #0x2b]
    // 0x616724: StoreField: r2->field_2f = rZR
    //     0x616724: stur            xzr, [x2, #0x2f]
    // 0x616728: ldur            x1, [fp, #-0x10]
    // 0x61672c: StoreField: r2->field_b = r1
    //     0x61672c: stur            w1, [x2, #0xb]
    // 0x616730: ldur            x6, [fp, #-0x20]
    // 0x616734: LoadField: r1 = r6->field_b
    //     0x616734: ldur            w1, [x6, #0xb]
    // 0x616738: LoadField: r7 = r6->field_f
    //     0x616738: ldur            w7, [x6, #0xf]
    // 0x61673c: DecompressPointer r7
    //     0x61673c: add             x7, x7, HEAP, lsl #32
    // 0x616740: LoadField: r8 = r7->field_b
    //     0x616740: ldur            w8, [x7, #0xb]
    // 0x616744: r7 = LoadInt32Instr(r1)
    //     0x616744: sbfx            x7, x1, #1, #0x1f
    // 0x616748: r17 = -272
    //     0x616748: movn            x17, #0x10f
    // 0x61674c: str             x7, [fp, x17]
    // 0x616750: r1 = LoadInt32Instr(r8)
    //     0x616750: sbfx            x1, x8, #1, #0x1f
    // 0x616754: cmp             x7, x1
    // 0x616758: b.ne            #0x616764
    // 0x61675c: mov             x1, x6
    // 0x616760: r0 = _growToNextCapacity()
    //     0x616760: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x616764: ldur            x2, [fp, #-0x20]
    // 0x616768: r17 = -272
    //     0x616768: movn            x17, #0x10f
    // 0x61676c: ldr             x3, [fp, x17]
    // 0x616770: add             x0, x3, #1
    // 0x616774: lsl             x1, x0, #1
    // 0x616778: StoreField: r2->field_b = r1
    //     0x616778: stur            w1, [x2, #0xb]
    // 0x61677c: LoadField: r1 = r2->field_f
    //     0x61677c: ldur            w1, [x2, #0xf]
    // 0x616780: DecompressPointer r1
    //     0x616780: add             x1, x1, HEAP, lsl #32
    // 0x616784: ldur            x0, [fp, #-8]
    // 0x616788: ArrayStore: r1[r3] = r0  ; List_4
    //     0x616788: add             x25, x1, x3, lsl #2
    //     0x61678c: add             x25, x25, #0xf
    //     0x616790: str             w0, [x25]
    //     0x616794: tbz             w0, #0, #0x6167b0
    //     0x616798: ldurb           w16, [x1, #-1]
    //     0x61679c: ldurb           w17, [x0, #-1]
    //     0x6167a0: and             x16, x17, x16, lsr #2
    //     0x6167a4: tst             x16, HEAP, lsr #32
    //     0x6167a8: b.eq            #0x6167b0
    //     0x6167ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6167b0: mov             x0, x2
    // 0x6167b4: b               #0x61681c
    // 0x6167b8: ldur            x2, [fp, #-0x20]
    // 0x6167bc: LoadField: r0 = r2->field_b
    //     0x6167bc: ldur            w0, [x2, #0xb]
    // 0x6167c0: LoadField: r1 = r2->field_f
    //     0x6167c0: ldur            w1, [x2, #0xf]
    // 0x6167c4: DecompressPointer r1
    //     0x6167c4: add             x1, x1, HEAP, lsl #32
    // 0x6167c8: LoadField: r3 = r1->field_b
    //     0x6167c8: ldur            w3, [x1, #0xb]
    // 0x6167cc: r4 = LoadInt32Instr(r0)
    //     0x6167cc: sbfx            x4, x0, #1, #0x1f
    // 0x6167d0: r17 = -272
    //     0x6167d0: movn            x17, #0x10f
    // 0x6167d4: str             x4, [fp, x17]
    // 0x6167d8: r0 = LoadInt32Instr(r3)
    //     0x6167d8: sbfx            x0, x3, #1, #0x1f
    // 0x6167dc: cmp             x4, x0
    // 0x6167e0: b.ne            #0x6167ec
    // 0x6167e4: mov             x1, x2
    // 0x6167e8: r0 = _growToNextCapacity()
    //     0x6167e8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6167ec: ldur            x0, [fp, #-0x20]
    // 0x6167f0: r17 = -272
    //     0x6167f0: movn            x17, #0x10f
    // 0x6167f4: ldr             x1, [fp, x17]
    // 0x6167f8: add             x2, x1, #1
    // 0x6167fc: lsl             x3, x2, #1
    // 0x616800: StoreField: r0->field_b = r3
    //     0x616800: stur            w3, [x0, #0xb]
    // 0x616804: LoadField: r2 = r0->field_f
    //     0x616804: ldur            w2, [x0, #0xf]
    // 0x616808: DecompressPointer r2
    //     0x616808: add             x2, x2, HEAP, lsl #32
    // 0x61680c: add             x3, x2, x1, lsl #2
    // 0x616810: r16 = Instance_SizedBox
    //     0x616810: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7f8] Obj!SizedBox@85d2e1
    //     0x616814: ldr             x16, [x16, #0x7f8]
    // 0x616818: StoreField: r3->field_f = r16
    //     0x616818: stur            w16, [x3, #0xf]
    // 0x61681c: r0 = Column()
    //     0x61681c: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x616820: mov             x1, x0
    // 0x616824: r0 = Instance_Axis
    //     0x616824: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x616828: stur            x1, [fp, #-8]
    // 0x61682c: StoreField: r1->field_f = r0
    //     0x61682c: stur            w0, [x1, #0xf]
    // 0x616830: r0 = Instance_MainAxisAlignment
    //     0x616830: add             x0, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x616834: ldr             x0, [x0, #0x200]
    // 0x616838: StoreField: r1->field_13 = r0
    //     0x616838: stur            w0, [x1, #0x13]
    // 0x61683c: r0 = Instance_MainAxisSize
    //     0x61683c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a070] Obj!MainAxisSize@862aa1
    //     0x616840: ldr             x0, [x0, #0x70]
    // 0x616844: ArrayStore: r1[0] = r0  ; List_4
    //     0x616844: stur            w0, [x1, #0x17]
    // 0x616848: r0 = Instance_CrossAxisAlignment
    //     0x616848: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x61684c: ldr             x0, [x0, #0x78]
    // 0x616850: StoreField: r1->field_1b = r0
    //     0x616850: stur            w0, [x1, #0x1b]
    // 0x616854: r0 = Instance_VerticalDirection
    //     0x616854: add             x0, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x616858: ldr             x0, [x0, #0x1e8]
    // 0x61685c: StoreField: r1->field_23 = r0
    //     0x61685c: stur            w0, [x1, #0x23]
    // 0x616860: r0 = Instance_Clip
    //     0x616860: add             x0, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x616864: ldr             x0, [x0, #0x1b0]
    // 0x616868: StoreField: r1->field_2b = r0
    //     0x616868: stur            w0, [x1, #0x2b]
    // 0x61686c: StoreField: r1->field_2f = rZR
    //     0x61686c: stur            xzr, [x1, #0x2f]
    // 0x616870: ldur            x0, [fp, #-0x20]
    // 0x616874: StoreField: r1->field_b = r0
    //     0x616874: stur            w0, [x1, #0xb]
    // 0x616878: r0 = SizedBox()
    //     0x616878: bl              #0x59ffb0  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x61687c: r1 = inf
    //     0x61687c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a830] inf
    //     0x616880: ldr             x1, [x1, #0x830]
    // 0x616884: StoreField: r0->field_f = r1
    //     0x616884: stur            w1, [x0, #0xf]
    // 0x616888: ldur            x1, [fp, #-8]
    // 0x61688c: StoreField: r0->field_b = r1
    //     0x61688c: stur            w1, [x0, #0xb]
    // 0x616890: LeaveFrame
    //     0x616890: mov             SP, fp
    //     0x616894: ldp             fp, lr, [SP], #0x10
    // 0x616898: ret
    //     0x616898: ret             
    // 0x61689c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61689c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6168a0: b               #0x6153c8
    // 0x6168a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168a4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168a8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168ac: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168b0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6168b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6168b8: b               #0x615528
    // 0x6168bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168bc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168c0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168c4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168c8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168cc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168d0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168d4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168d8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168dc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168e0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168e4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168e8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168ec: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168f0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168f4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168f8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168fc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616900: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616904: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616908: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getIndexToAdd(/* No info */) {
    // ** addr: 0x616924, size: 0x12c
    // 0x616924: EnterFrame
    //     0x616924: stp             fp, lr, [SP, #-0x10]!
    //     0x616928: mov             fp, SP
    // 0x61692c: AllocStack(0x20)
    //     0x61692c: sub             SP, SP, #0x20
    // 0x616930: SetupParameters(GeneratorGroupState<C3X0> this /* r1 => r2, fp-0x8 */)
    //     0x616930: mov             x2, x1
    //     0x616934: stur            x1, [fp, #-8]
    // 0x616938: CheckStackOverflow
    //     0x616938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61693c: cmp             SP, x16
    //     0x616940: b.ls            #0x616a38
    // 0x616944: LoadField: r0 = r2->field_b
    //     0x616944: ldur            w0, [x2, #0xb]
    // 0x616948: DecompressPointer r0
    //     0x616948: add             x0, x0, HEAP, lsl #32
    // 0x61694c: cmp             w0, NULL
    // 0x616950: b.eq            #0x616a40
    // 0x616954: LoadField: r1 = r0->field_53
    //     0x616954: ldur            w1, [x0, #0x53]
    // 0x616958: DecompressPointer r1
    //     0x616958: add             x1, x1, HEAP, lsl #32
    // 0x61695c: r0 = LoadClassIdInstr(r1)
    //     0x61695c: ldur            x0, [x1, #-1]
    //     0x616960: ubfx            x0, x0, #0xc, #0x14
    // 0x616964: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x616964: movz            x17, #0x7df6
    //     0x616968: add             lr, x0, x17
    //     0x61696c: ldr             lr, [x21, lr, lsl #3]
    //     0x616970: blr             lr
    // 0x616974: mov             x2, x0
    // 0x616978: stur            x2, [fp, #-0x10]
    // 0x61697c: ldur            x3, [fp, #-8]
    // 0x616980: CheckStackOverflow
    //     0x616980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616984: cmp             SP, x16
    //     0x616988: b.ls            #0x616a44
    // 0x61698c: r0 = LoadClassIdInstr(r2)
    //     0x61698c: ldur            x0, [x2, #-1]
    //     0x616990: ubfx            x0, x0, #0xc, #0x14
    // 0x616994: mov             x1, x2
    // 0x616998: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x616998: sub             lr, x0, #0xfc4
    //     0x61699c: ldr             lr, [x21, lr, lsl #3]
    //     0x6169a0: blr             lr
    // 0x6169a4: tbnz            w0, #4, #0x616a28
    // 0x6169a8: ldur            x3, [fp, #-8]
    // 0x6169ac: ldur            x2, [fp, #-0x10]
    // 0x6169b0: r0 = LoadClassIdInstr(r2)
    //     0x6169b0: ldur            x0, [x2, #-1]
    //     0x6169b4: ubfx            x0, x0, #0xc, #0x14
    // 0x6169b8: mov             x1, x2
    // 0x6169bc: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x6169bc: sub             lr, x0, #0xfb6
    //     0x6169c0: ldr             lr, [x21, lr, lsl #3]
    //     0x6169c4: blr             lr
    // 0x6169c8: mov             x3, x0
    // 0x6169cc: ldur            x0, [fp, #-8]
    // 0x6169d0: stur            x3, [fp, #-0x20]
    // 0x6169d4: LoadField: r1 = r0->field_b
    //     0x6169d4: ldur            w1, [x0, #0xb]
    // 0x6169d8: DecompressPointer r1
    //     0x6169d8: add             x1, x1, HEAP, lsl #32
    // 0x6169dc: cmp             w1, NULL
    // 0x6169e0: b.eq            #0x616a4c
    // 0x6169e4: LoadField: r2 = r1->field_2f
    //     0x6169e4: ldur            w2, [x1, #0x2f]
    // 0x6169e8: DecompressPointer r2
    //     0x6169e8: add             x2, x2, HEAP, lsl #32
    // 0x6169ec: LoadField: r4 = r2->field_f
    //     0x6169ec: ldur            w4, [x2, #0xf]
    // 0x6169f0: DecompressPointer r4
    //     0x6169f0: add             x4, x4, HEAP, lsl #32
    // 0x6169f4: mov             x1, x2
    // 0x6169f8: mov             x2, x3
    // 0x6169fc: stur            x4, [fp, #-0x18]
    // 0x616a00: r0 = _getValueOrData()
    //     0x616a00: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x616a04: ldur            x1, [fp, #-0x18]
    // 0x616a08: cmp             w1, w0
    // 0x616a0c: b.eq            #0x616a18
    // 0x616a10: ldur            x2, [fp, #-0x10]
    // 0x616a14: b               #0x61697c
    // 0x616a18: ldur            x0, [fp, #-0x20]
    // 0x616a1c: LeaveFrame
    //     0x616a1c: mov             SP, fp
    //     0x616a20: ldp             fp, lr, [SP], #0x10
    // 0x616a24: ret
    //     0x616a24: ret             
    // 0x616a28: r0 = Null
    //     0x616a28: mov             x0, NULL
    // 0x616a2c: LeaveFrame
    //     0x616a2c: mov             SP, fp
    //     0x616a30: ldp             fp, lr, [SP], #0x10
    // 0x616a34: ret
    //     0x616a34: ret             
    // 0x616a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616a38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616a3c: b               #0x616944
    // 0x616a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616a40: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616a44: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616a48: b               #0x61698c
    // 0x616a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616a4c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x616b84, size: 0x60
    // 0x616b84: EnterFrame
    //     0x616b84: stp             fp, lr, [SP, #-0x10]!
    //     0x616b88: mov             fp, SP
    // 0x616b8c: AllocStack(0x8)
    //     0x616b8c: sub             SP, SP, #8
    // 0x616b90: SetupParameters([dynamic _ /* r0 */])
    //     0x616b90: ldr             x0, [fp, #0x10]
    //     0x616b94: ldur            w2, [x0, #0x17]
    //     0x616b98: add             x2, x2, HEAP, lsl #32
    // 0x616b9c: CheckStackOverflow
    //     0x616b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616ba0: cmp             SP, x16
    //     0x616ba4: b.ls            #0x616bdc
    // 0x616ba8: LoadField: r0 = r2->field_f
    //     0x616ba8: ldur            w0, [x2, #0xf]
    // 0x616bac: DecompressPointer r0
    //     0x616bac: add             x0, x0, HEAP, lsl #32
    // 0x616bb0: stur            x0, [fp, #-8]
    // 0x616bb4: r1 = Function '<anonymous closure>':.
    //     0x616bb4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c810] AnonymousClosure: (0x616be4), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] GeneratorGroupState::build (0x6153ac)
    //     0x616bb8: ldr             x1, [x1, #0x810]
    // 0x616bbc: r0 = AllocateClosure()
    //     0x616bbc: bl              #0x826750  ; AllocateClosureStub
    // 0x616bc0: ldur            x1, [fp, #-8]
    // 0x616bc4: mov             x2, x0
    // 0x616bc8: r0 = setState()
    //     0x616bc8: bl              #0x329714  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x616bcc: r0 = Null
    //     0x616bcc: mov             x0, NULL
    // 0x616bd0: LeaveFrame
    //     0x616bd0: mov             SP, fp
    //     0x616bd4: ldp             fp, lr, [SP], #0x10
    // 0x616bd8: ret
    //     0x616bd8: ret             
    // 0x616bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616bdc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616be0: b               #0x616ba8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x616be4, size: 0x80
    // 0x616be4: EnterFrame
    //     0x616be4: stp             fp, lr, [SP, #-0x10]!
    //     0x616be8: mov             fp, SP
    // 0x616bec: ldr             x0, [fp, #0x10]
    // 0x616bf0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x616bf0: ldur            w1, [x0, #0x17]
    // 0x616bf4: DecompressPointer r1
    //     0x616bf4: add             x1, x1, HEAP, lsl #32
    // 0x616bf8: CheckStackOverflow
    //     0x616bf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616bfc: cmp             SP, x16
    //     0x616c00: b.ls            #0x616c58
    // 0x616c04: LoadField: r0 = r1->field_f
    //     0x616c04: ldur            w0, [x1, #0xf]
    // 0x616c08: DecompressPointer r0
    //     0x616c08: add             x0, x0, HEAP, lsl #32
    // 0x616c0c: LoadField: r1 = r0->field_b
    //     0x616c0c: ldur            w1, [x0, #0xb]
    // 0x616c10: DecompressPointer r1
    //     0x616c10: add             x1, x1, HEAP, lsl #32
    // 0x616c14: cmp             w1, NULL
    // 0x616c18: b.eq            #0x616c60
    // 0x616c1c: LoadField: r0 = r1->field_73
    //     0x616c1c: ldur            w0, [x1, #0x73]
    // 0x616c20: DecompressPointer r0
    //     0x616c20: add             x0, x0, HEAP, lsl #32
    // 0x616c24: LoadField: r2 = r1->field_3f
    //     0x616c24: ldur            w2, [x1, #0x3f]
    // 0x616c28: DecompressPointer r2
    //     0x616c28: add             x2, x2, HEAP, lsl #32
    // 0x616c2c: cmp             w2, NULL
    // 0x616c30: r16 = true
    //     0x616c30: add             x16, NULL, #0x20  ; true
    // 0x616c34: r17 = false
    //     0x616c34: add             x17, NULL, #0x30  ; false
    // 0x616c38: csel            x1, x16, x17, ne
    // 0x616c3c: mov             x2, x1
    // 0x616c40: mov             x1, x0
    // 0x616c44: r0 = cycleBuyOption()
    //     0x616c44: bl              #0x616c64  ; [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] ::cycleBuyOption
    // 0x616c48: r0 = Null
    //     0x616c48: mov             x0, NULL
    // 0x616c4c: LeaveFrame
    //     0x616c4c: mov             SP, fp
    //     0x616c50: ldp             fp, lr, [SP], #0x10
    // 0x616c54: ret
    //     0x616c54: ret             
    // 0x616c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616c58: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616c5c: b               #0x616c04
    // 0x616c60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616c60: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x616e14, size: 0x60
    // 0x616e14: EnterFrame
    //     0x616e14: stp             fp, lr, [SP, #-0x10]!
    //     0x616e18: mov             fp, SP
    // 0x616e1c: AllocStack(0x8)
    //     0x616e1c: sub             SP, SP, #8
    // 0x616e20: SetupParameters([dynamic _ /* r0 */])
    //     0x616e20: ldr             x0, [fp, #0x10]
    //     0x616e24: ldur            w2, [x0, #0x17]
    //     0x616e28: add             x2, x2, HEAP, lsl #32
    // 0x616e2c: CheckStackOverflow
    //     0x616e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616e30: cmp             SP, x16
    //     0x616e34: b.ls            #0x616e6c
    // 0x616e38: LoadField: r0 = r2->field_f
    //     0x616e38: ldur            w0, [x2, #0xf]
    // 0x616e3c: DecompressPointer r0
    //     0x616e3c: add             x0, x0, HEAP, lsl #32
    // 0x616e40: stur            x0, [fp, #-8]
    // 0x616e44: r1 = Function '<anonymous closure>':.
    //     0x616e44: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c828] AnonymousClosure: (0x616e74), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] GeneratorGroupState::build (0x6153ac)
    //     0x616e48: ldr             x1, [x1, #0x828]
    // 0x616e4c: r0 = AllocateClosure()
    //     0x616e4c: bl              #0x826750  ; AllocateClosureStub
    // 0x616e50: ldur            x1, [fp, #-8]
    // 0x616e54: mov             x2, x0
    // 0x616e58: r0 = setState()
    //     0x616e58: bl              #0x329714  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x616e5c: r0 = Null
    //     0x616e5c: mov             x0, NULL
    // 0x616e60: LeaveFrame
    //     0x616e60: mov             SP, fp
    //     0x616e64: ldp             fp, lr, [SP], #0x10
    // 0x616e68: ret
    //     0x616e68: ret             
    // 0x616e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616e6c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616e70: b               #0x616e38
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x616e74, size: 0x64
    // 0x616e74: EnterFrame
    //     0x616e74: stp             fp, lr, [SP, #-0x10]!
    //     0x616e78: mov             fp, SP
    // 0x616e7c: ldr             x0, [fp, #0x10]
    // 0x616e80: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x616e80: ldur            w1, [x0, #0x17]
    // 0x616e84: DecompressPointer r1
    //     0x616e84: add             x1, x1, HEAP, lsl #32
    // 0x616e88: CheckStackOverflow
    //     0x616e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x616e8c: cmp             SP, x16
    //     0x616e90: b.ls            #0x616ecc
    // 0x616e94: LoadField: r0 = r1->field_f
    //     0x616e94: ldur            w0, [x1, #0xf]
    // 0x616e98: DecompressPointer r0
    //     0x616e98: add             x0, x0, HEAP, lsl #32
    // 0x616e9c: LoadField: r1 = r0->field_b
    //     0x616e9c: ldur            w1, [x0, #0xb]
    // 0x616ea0: DecompressPointer r1
    //     0x616ea0: add             x1, x1, HEAP, lsl #32
    // 0x616ea4: cmp             w1, NULL
    // 0x616ea8: b.eq            #0x616ed4
    // 0x616eac: LoadField: r0 = r1->field_73
    //     0x616eac: ldur            w0, [x1, #0x73]
    // 0x616eb0: DecompressPointer r0
    //     0x616eb0: add             x0, x0, HEAP, lsl #32
    // 0x616eb4: mov             x1, x0
    // 0x616eb8: r0 = cyclePerSecond()
    //     0x616eb8: bl              #0x616ed8  ; [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] ::cyclePerSecond
    // 0x616ebc: r0 = Null
    //     0x616ebc: mov             x0, NULL
    // 0x616ec0: LeaveFrame
    //     0x616ec0: mov             SP, fp
    //     0x616ec4: ldp             fp, lr, [SP], #0x10
    // 0x616ec8: ret
    //     0x616ec8: ret             
    // 0x616ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616ecc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616ed0: b               #0x616e94
    // 0x616ed4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616ed4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] BuyOption <anonymous closure>(dynamic) {
    // ** addr: 0x616fb8, size: 0x18
    // 0x616fb8: ldr             x1, [SP]
    // 0x616fbc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x616fbc: ldur            w2, [x1, #0x17]
    // 0x616fc0: DecompressPointer r2
    //     0x616fc0: add             x2, x2, HEAP, lsl #32
    // 0x616fc4: LoadField: r0 = r2->field_13
    //     0x616fc4: ldur            w0, [x2, #0x13]
    // 0x616fc8: DecompressPointer r0
    //     0x616fc8: add             x0, x0, HEAP, lsl #32
    // 0x616fcc: ret
    //     0x616fcc: ret             
  }
}

// class id: 3541, size: 0x1c, field offset: 0x1c
class _AutoDialogState<C1X0> extends SyncState2<C1X0> {

  _ build(/* No info */) {
    // ** addr: 0x5a46a0, size: 0x7e4
    // 0x5a46a0: EnterFrame
    //     0x5a46a0: stp             fp, lr, [SP, #-0x10]!
    //     0x5a46a4: mov             fp, SP
    // 0x5a46a8: AllocStack(0x80)
    //     0x5a46a8: sub             SP, SP, #0x80
    // 0x5a46ac: SetupParameters(_AutoDialogState<C1X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x5a46ac: stur            x1, [fp, #-8]
    //     0x5a46b0: stur            x2, [fp, #-0x10]
    // 0x5a46b4: CheckStackOverflow
    //     0x5a46b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a46b8: cmp             SP, x16
    //     0x5a46bc: b.ls            #0x5a4e54
    // 0x5a46c0: r1 = 2
    //     0x5a46c0: movz            x1, #0x2
    // 0x5a46c4: r0 = AllocateContext()
    //     0x5a46c4: bl              #0x82637c  ; AllocateContextStub
    // 0x5a46c8: mov             x3, x0
    // 0x5a46cc: ldur            x0, [fp, #-8]
    // 0x5a46d0: stur            x3, [fp, #-0x18]
    // 0x5a46d4: StoreField: r3->field_f = r0
    //     0x5a46d4: stur            w0, [x3, #0xf]
    // 0x5a46d8: ldur            x1, [fp, #-0x10]
    // 0x5a46dc: StoreField: r3->field_13 = r1
    //     0x5a46dc: stur            w1, [x3, #0x13]
    // 0x5a46e0: r1 = Null
    //     0x5a46e0: mov             x1, NULL
    // 0x5a46e4: r2 = 4
    //     0x5a46e4: movz            x2, #0x4
    // 0x5a46e8: r0 = AllocateArray()
    //     0x5a46e8: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a46ec: stur            x0, [fp, #-0x10]
    // 0x5a46f0: r16 = Instance_Text
    //     0x5a46f0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34590] Obj!Text@84f401
    //     0x5a46f4: ldr             x16, [x16, #0x590]
    // 0x5a46f8: StoreField: r0->field_f = r16
    //     0x5a46f8: stur            w16, [x0, #0xf]
    // 0x5a46fc: r16 = Instance_SizedBox
    //     0x5a46fc: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a658] Obj!SizedBox@85d201
    //     0x5a4700: ldr             x16, [x16, #0x658]
    // 0x5a4704: StoreField: r0->field_13 = r16
    //     0x5a4704: stur            w16, [x0, #0x13]
    // 0x5a4708: r1 = <Widget>
    //     0x5a4708: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x5a470c: r0 = AllocateGrowableArray()
    //     0x5a470c: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5a4710: mov             x2, x0
    // 0x5a4714: ldur            x0, [fp, #-0x10]
    // 0x5a4718: stur            x2, [fp, #-0x20]
    // 0x5a471c: StoreField: r2->field_f = r0
    //     0x5a471c: stur            w0, [x2, #0xf]
    // 0x5a4720: r0 = 4
    //     0x5a4720: movz            x0, #0x4
    // 0x5a4724: StoreField: r2->field_b = r0
    //     0x5a4724: stur            w0, [x2, #0xb]
    // 0x5a4728: ldur            x3, [fp, #-8]
    // 0x5a472c: LoadField: r0 = r3->field_b
    //     0x5a472c: ldur            w0, [x3, #0xb]
    // 0x5a4730: DecompressPointer r0
    //     0x5a4730: add             x0, x0, HEAP, lsl #32
    // 0x5a4734: cmp             w0, NULL
    // 0x5a4738: b.eq            #0x5a4e5c
    // 0x5a473c: LoadField: r1 = r0->field_1b
    //     0x5a473c: ldur            w1, [x0, #0x1b]
    // 0x5a4740: DecompressPointer r1
    //     0x5a4740: add             x1, x1, HEAP, lsl #32
    // 0x5a4744: r0 = LoadClassIdInstr(r1)
    //     0x5a4744: ldur            x0, [x1, #-1]
    //     0x5a4748: ubfx            x0, x0, #0xc, #0x14
    // 0x5a474c: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x5a474c: movz            x17, #0x7df6
    //     0x5a4750: add             lr, x0, x17
    //     0x5a4754: ldr             lr, [x21, lr, lsl #3]
    //     0x5a4758: blr             lr
    // 0x5a475c: mov             x3, x0
    // 0x5a4760: ldur            x2, [fp, #-8]
    // 0x5a4764: stur            x3, [fp, #-0x28]
    // 0x5a4768: LoadField: r4 = r2->field_7
    //     0x5a4768: ldur            w4, [x2, #7]
    // 0x5a476c: DecompressPointer r4
    //     0x5a476c: add             x4, x4, HEAP, lsl #32
    // 0x5a4770: stur            x4, [fp, #-0x10]
    // 0x5a4774: ldur            x5, [fp, #-0x20]
    // 0x5a4778: ldur            x6, [fp, #-0x18]
    // 0x5a477c: CheckStackOverflow
    //     0x5a477c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a4780: cmp             SP, x16
    //     0x5a4784: b.ls            #0x5a4e60
    // 0x5a4788: r0 = LoadClassIdInstr(r3)
    //     0x5a4788: ldur            x0, [x3, #-1]
    //     0x5a478c: ubfx            x0, x0, #0xc, #0x14
    // 0x5a4790: mov             x1, x3
    // 0x5a4794: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x5a4794: sub             lr, x0, #0xfc4
    //     0x5a4798: ldr             lr, [x21, lr, lsl #3]
    //     0x5a479c: blr             lr
    // 0x5a47a0: tbnz            w0, #4, #0x5a4cf4
    // 0x5a47a4: ldur            x0, [fp, #-8]
    // 0x5a47a8: ldur            x2, [fp, #-0x18]
    // 0x5a47ac: ldur            x1, [fp, #-0x28]
    // 0x5a47b0: r1 = 3
    //     0x5a47b0: movz            x1, #0x3
    // 0x5a47b4: r0 = AllocateContext()
    //     0x5a47b4: bl              #0x82637c  ; AllocateContextStub
    // 0x5a47b8: mov             x3, x0
    // 0x5a47bc: ldur            x2, [fp, #-0x18]
    // 0x5a47c0: stur            x3, [fp, #-0x30]
    // 0x5a47c4: StoreField: r3->field_b = r2
    //     0x5a47c4: stur            w2, [x3, #0xb]
    // 0x5a47c8: ldur            x4, [fp, #-0x28]
    // 0x5a47cc: r0 = LoadClassIdInstr(r4)
    //     0x5a47cc: ldur            x0, [x4, #-1]
    //     0x5a47d0: ubfx            x0, x0, #0xc, #0x14
    // 0x5a47d4: mov             x1, x4
    // 0x5a47d8: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x5a47d8: sub             lr, x0, #0xfb6
    //     0x5a47dc: ldr             lr, [x21, lr, lsl #3]
    //     0x5a47e0: blr             lr
    // 0x5a47e4: mov             x4, x0
    // 0x5a47e8: ldur            x3, [fp, #-0x30]
    // 0x5a47ec: stur            x4, [fp, #-0x40]
    // 0x5a47f0: StoreField: r3->field_f = r0
    //     0x5a47f0: stur            w0, [x3, #0xf]
    //     0x5a47f4: tbz             w0, #0, #0x5a4810
    //     0x5a47f8: ldurb           w16, [x3, #-1]
    //     0x5a47fc: ldurb           w17, [x0, #-1]
    //     0x5a4800: and             x16, x17, x16, lsr #2
    //     0x5a4804: tst             x16, HEAP, lsr #32
    //     0x5a4808: b.eq            #0x5a4810
    //     0x5a480c: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x5a4810: ldur            x0, [fp, #-8]
    // 0x5a4814: LoadField: r1 = r0->field_b
    //     0x5a4814: ldur            w1, [x0, #0xb]
    // 0x5a4818: DecompressPointer r1
    //     0x5a4818: add             x1, x1, HEAP, lsl #32
    // 0x5a481c: cmp             w1, NULL
    // 0x5a4820: b.eq            #0x5a4e68
    // 0x5a4824: LoadField: r2 = r1->field_f
    //     0x5a4824: ldur            w2, [x1, #0xf]
    // 0x5a4828: DecompressPointer r2
    //     0x5a4828: add             x2, x2, HEAP, lsl #32
    // 0x5a482c: LoadField: r5 = r2->field_f
    //     0x5a482c: ldur            w5, [x2, #0xf]
    // 0x5a4830: DecompressPointer r5
    //     0x5a4830: add             x5, x5, HEAP, lsl #32
    // 0x5a4834: mov             x1, x2
    // 0x5a4838: mov             x2, x4
    // 0x5a483c: stur            x5, [fp, #-0x38]
    // 0x5a4840: r0 = _getValueOrData()
    //     0x5a4840: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a4844: mov             x1, x0
    // 0x5a4848: ldur            x0, [fp, #-0x38]
    // 0x5a484c: cmp             w0, w1
    // 0x5a4850: b.ne            #0x5a485c
    // 0x5a4854: ldur            x2, [fp, #-0x20]
    // 0x5a4858: b               #0x5a4ce0
    // 0x5a485c: ldur            x1, [fp, #-8]
    // 0x5a4860: ldur            x2, [fp, #-0x30]
    // 0x5a4864: LoadField: r0 = r1->field_b
    //     0x5a4864: ldur            w0, [x1, #0xb]
    // 0x5a4868: DecompressPointer r0
    //     0x5a4868: add             x0, x0, HEAP, lsl #32
    // 0x5a486c: cmp             w0, NULL
    // 0x5a4870: b.eq            #0x5a4e6c
    // 0x5a4874: LoadField: r3 = r0->field_1f
    //     0x5a4874: ldur            w3, [x0, #0x1f]
    // 0x5a4878: DecompressPointer r3
    //     0x5a4878: add             x3, x3, HEAP, lsl #32
    // 0x5a487c: ldur            x16, [fp, #-0x40]
    // 0x5a4880: stp             x16, x3, [SP]
    // 0x5a4884: mov             x0, x3
    // 0x5a4888: ClosureCall
    //     0x5a4888: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5a488c: ldur            x2, [x0, #0x1f]
    //     0x5a4890: blr             x2
    // 0x5a4894: LoadField: r3 = r0->field_2b
    //     0x5a4894: ldur            w3, [x0, #0x2b]
    // 0x5a4898: DecompressPointer r3
    //     0x5a4898: add             x3, x3, HEAP, lsl #32
    // 0x5a489c: stur            x3, [fp, #-0x48]
    // 0x5a48a0: cmp             w3, NULL
    // 0x5a48a4: b.eq            #0x5a4e70
    // 0x5a48a8: mov             x0, x3
    // 0x5a48ac: ldur            x4, [fp, #-0x30]
    // 0x5a48b0: StoreField: r4->field_13 = r0
    //     0x5a48b0: stur            w0, [x4, #0x13]
    //     0x5a48b4: ldurb           w16, [x4, #-1]
    //     0x5a48b8: ldurb           w17, [x0, #-1]
    //     0x5a48bc: and             x16, x17, x16, lsr #2
    //     0x5a48c0: tst             x16, HEAP, lsr #32
    //     0x5a48c4: b.eq            #0x5a48cc
    //     0x5a48c8: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x5a48cc: ldur            x0, [fp, #-8]
    // 0x5a48d0: LoadField: r1 = r0->field_b
    //     0x5a48d0: ldur            w1, [x0, #0xb]
    // 0x5a48d4: DecompressPointer r1
    //     0x5a48d4: add             x1, x1, HEAP, lsl #32
    // 0x5a48d8: cmp             w1, NULL
    // 0x5a48dc: b.eq            #0x5a4e74
    // 0x5a48e0: LoadField: r2 = r1->field_23
    //     0x5a48e0: ldur            w2, [x1, #0x23]
    // 0x5a48e4: DecompressPointer r2
    //     0x5a48e4: add             x2, x2, HEAP, lsl #32
    // 0x5a48e8: LoadField: r5 = r2->field_f
    //     0x5a48e8: ldur            w5, [x2, #0xf]
    // 0x5a48ec: DecompressPointer r5
    //     0x5a48ec: add             x5, x5, HEAP, lsl #32
    // 0x5a48f0: mov             x1, x2
    // 0x5a48f4: ldur            x2, [fp, #-0x40]
    // 0x5a48f8: stur            x5, [fp, #-0x38]
    // 0x5a48fc: r0 = _getKeyOrData()
    //     0x5a48fc: bl              #0x3f7518  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x5a4900: mov             x1, x0
    // 0x5a4904: ldur            x0, [fp, #-0x38]
    // 0x5a4908: cmp             w0, w1
    // 0x5a490c: r16 = true
    //     0x5a490c: add             x16, NULL, #0x20  ; true
    // 0x5a4910: r17 = false
    //     0x5a4910: add             x17, NULL, #0x30  ; false
    // 0x5a4914: csel            x4, x16, x17, ne
    // 0x5a4918: ldur            x0, [fp, #-0x30]
    // 0x5a491c: stur            x4, [fp, #-0x50]
    // 0x5a4920: ArrayStore: r0[0] = r4  ; List_4
    //     0x5a4920: stur            w4, [x0, #0x17]
    // 0x5a4924: tbz             w4, #4, #0x5a4990
    // 0x5a4928: ldur            x5, [fp, #-8]
    // 0x5a492c: ldur            x2, [fp, #-0x10]
    // 0x5a4930: r1 = Null
    //     0x5a4930: mov             x1, NULL
    // 0x5a4934: r3 = <C1X0>
    //     0x5a4934: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a4938: ldr             x3, [x3, #0xe38]
    // 0x5a493c: r0 = Null
    //     0x5a493c: mov             x0, NULL
    // 0x5a4940: cmp             x2, x0
    // 0x5a4944: b.eq            #0x5a4954
    // 0x5a4948: r30 = InstantiateTypeArgumentsStub
    //     0x5a4948: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a494c: LoadField: r30 = r30->field_7
    //     0x5a494c: ldur            lr, [lr, #7]
    // 0x5a4950: blr             lr
    // 0x5a4954: mov             x1, x0
    // 0x5a4958: ldur            x0, [fp, #-8]
    // 0x5a495c: LoadField: r2 = r0->field_b
    //     0x5a495c: ldur            w2, [x0, #0xb]
    // 0x5a4960: DecompressPointer r2
    //     0x5a4960: add             x2, x2, HEAP, lsl #32
    // 0x5a4964: cmp             w2, NULL
    // 0x5a4968: b.eq            #0x5a4e78
    // 0x5a496c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x5a496c: ldur            w3, [x2, #0x17]
    // 0x5a4970: DecompressPointer r3
    //     0x5a4970: add             x3, x3, HEAP, lsl #32
    // 0x5a4974: stp             x3, x1, [SP, #8]
    // 0x5a4978: ldur            x16, [fp, #-0x48]
    // 0x5a497c: str             x16, [SP]
    // 0x5a4980: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a4980: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a4984: r0 = MapOperations.isSupersetOfTuple()
    //     0x5a4984: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x5a4988: mov             x2, x0
    // 0x5a498c: b               #0x5a4994
    // 0x5a4990: r2 = false
    //     0x5a4990: add             x2, NULL, #0x30  ; false
    // 0x5a4994: ldur            x1, [fp, #-8]
    // 0x5a4998: stur            x2, [fp, #-0x38]
    // 0x5a499c: LoadField: r0 = r1->field_b
    //     0x5a499c: ldur            w0, [x1, #0xb]
    // 0x5a49a0: DecompressPointer r0
    //     0x5a49a0: add             x0, x0, HEAP, lsl #32
    // 0x5a49a4: cmp             w0, NULL
    // 0x5a49a8: b.eq            #0x5a4e7c
    // 0x5a49ac: LoadField: r3 = r0->field_1f
    //     0x5a49ac: ldur            w3, [x0, #0x1f]
    // 0x5a49b0: DecompressPointer r3
    //     0x5a49b0: add             x3, x3, HEAP, lsl #32
    // 0x5a49b4: ldur            x16, [fp, #-0x40]
    // 0x5a49b8: stp             x16, x3, [SP]
    // 0x5a49bc: mov             x0, x3
    // 0x5a49c0: ClosureCall
    //     0x5a49c0: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5a49c4: ldur            x2, [x0, #0x1f]
    //     0x5a49c8: blr             x2
    // 0x5a49cc: LoadField: r1 = r0->field_1b
    //     0x5a49cc: ldur            w1, [x0, #0x1b]
    // 0x5a49d0: DecompressPointer r1
    //     0x5a49d0: add             x1, x1, HEAP, lsl #32
    // 0x5a49d4: stur            x1, [fp, #-0x40]
    // 0x5a49d8: r0 = Text()
    //     0x5a49d8: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x5a49dc: mov             x1, x0
    // 0x5a49e0: ldur            x0, [fp, #-0x40]
    // 0x5a49e4: stur            x1, [fp, #-0x58]
    // 0x5a49e8: StoreField: r1->field_b = r0
    //     0x5a49e8: stur            w0, [x1, #0xb]
    // 0x5a49ec: r0 = SingleChildScrollView()
    //     0x5a49ec: bl              #0x5a4e90  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x5a49f0: mov             x3, x0
    // 0x5a49f4: r0 = Instance_Axis
    //     0x5a49f4: ldr             x0, [PP, #0x6740]  ; [pp+0x6740] Obj!Axis@862e21
    // 0x5a49f8: stur            x3, [fp, #-0x40]
    // 0x5a49fc: StoreField: r3->field_b = r0
    //     0x5a49fc: stur            w0, [x3, #0xb]
    // 0x5a4a00: r4 = false
    //     0x5a4a00: add             x4, NULL, #0x30  ; false
    // 0x5a4a04: StoreField: r3->field_f = r4
    //     0x5a4a04: stur            w4, [x3, #0xf]
    // 0x5a4a08: ldur            x1, [fp, #-0x58]
    // 0x5a4a0c: StoreField: r3->field_23 = r1
    //     0x5a4a0c: stur            w1, [x3, #0x23]
    // 0x5a4a10: r5 = Instance_DragStartBehavior
    //     0x5a4a10: ldr             x5, [PP, #0x70b0]  ; [pp+0x70b0] Obj!DragStartBehavior@863b61
    // 0x5a4a14: StoreField: r3->field_27 = r5
    //     0x5a4a14: stur            w5, [x3, #0x27]
    // 0x5a4a18: r6 = Instance_Clip
    //     0x5a4a18: add             x6, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x5a4a1c: ldr             x6, [x6, #0x900]
    // 0x5a4a20: StoreField: r3->field_2b = r6
    //     0x5a4a20: stur            w6, [x3, #0x2b]
    // 0x5a4a24: r7 = Instance_HitTestBehavior
    //     0x5a4a24: add             x7, PP, #0xc, lsl #12  ; [pp+0xc9a8] Obj!HitTestBehavior@8628c1
    //     0x5a4a28: ldr             x7, [x7, #0x9a8]
    // 0x5a4a2c: StoreField: r3->field_2f = r7
    //     0x5a4a2c: stur            w7, [x3, #0x2f]
    // 0x5a4a30: ldur            x8, [fp, #-0x38]
    // 0x5a4a34: tbnz            w8, #4, #0x5a4a50
    // 0x5a4a38: ldur            x2, [fp, #-0x30]
    // 0x5a4a3c: r1 = Function '<anonymous closure>':.
    //     0x5a4a3c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34598] AnonymousClosure: (0x5a5214), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] _AutoDialogState::build (0x5a46a0)
    //     0x5a4a40: ldr             x1, [x1, #0x598]
    // 0x5a4a44: r0 = AllocateClosure()
    //     0x5a4a44: bl              #0x826750  ; AllocateClosureStub
    // 0x5a4a48: mov             x3, x0
    // 0x5a4a4c: b               #0x5a4a54
    // 0x5a4a50: r3 = Null
    //     0x5a4a50: mov             x3, NULL
    // 0x5a4a54: ldur            x0, [fp, #-0x50]
    // 0x5a4a58: stur            x3, [fp, #-0x58]
    // 0x5a4a5c: tbnz            w0, #4, #0x5a4a70
    // 0x5a4a60: mov             x0, x3
    // 0x5a4a64: r3 = Instance_Text
    //     0x5a4a64: add             x3, PP, #0x34, lsl #12  ; [pp+0x345a0] Obj!Text@84f3b1
    //     0x5a4a68: ldr             x3, [x3, #0x5a0]
    // 0x5a4a6c: b               #0x5a4b80
    // 0x5a4a70: ldur            x0, [fp, #-0x38]
    // 0x5a4a74: tbnz            w0, #4, #0x5a4a84
    // 0x5a4a78: r0 = Instance_Text
    //     0x5a4a78: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c1c8] Obj!Text@84f4a1
    //     0x5a4a7c: ldr             x0, [x0, #0x1c8]
    // 0x5a4a80: b               #0x5a4b78
    // 0x5a4a84: ldur            x0, [fp, #-8]
    // 0x5a4a88: ldur            x4, [fp, #-0x48]
    // 0x5a4a8c: LoadField: r5 = r4->field_f
    //     0x5a4a8c: ldur            w5, [x4, #0xf]
    // 0x5a4a90: DecompressPointer r5
    //     0x5a4a90: add             x5, x5, HEAP, lsl #32
    // 0x5a4a94: stur            x5, [fp, #-0x38]
    // 0x5a4a98: r1 = Null
    //     0x5a4a98: mov             x1, NULL
    // 0x5a4a9c: r2 = 6
    //     0x5a4a9c: movz            x2, #0x6
    // 0x5a4aa0: r0 = AllocateArray()
    //     0x5a4aa0: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a4aa4: mov             x3, x0
    // 0x5a4aa8: ldur            x0, [fp, #-0x38]
    // 0x5a4aac: stur            x3, [fp, #-0x60]
    // 0x5a4ab0: StoreField: r3->field_f = r0
    //     0x5a4ab0: stur            w0, [x3, #0xf]
    // 0x5a4ab4: r16 = " "
    //     0x5a4ab4: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x5a4ab8: StoreField: r3->field_13 = r16
    //     0x5a4ab8: stur            w16, [x3, #0x13]
    // 0x5a4abc: ldur            x4, [fp, #-8]
    // 0x5a4ac0: LoadField: r0 = r4->field_b
    //     0x5a4ac0: ldur            w0, [x4, #0xb]
    // 0x5a4ac4: DecompressPointer r0
    //     0x5a4ac4: add             x0, x0, HEAP, lsl #32
    // 0x5a4ac8: cmp             w0, NULL
    // 0x5a4acc: b.eq            #0x5a4e80
    // 0x5a4ad0: ldur            x1, [fp, #-0x48]
    // 0x5a4ad4: LoadField: r5 = r1->field_b
    //     0x5a4ad4: ldur            w5, [x1, #0xb]
    // 0x5a4ad8: DecompressPointer r5
    //     0x5a4ad8: add             x5, x5, HEAP, lsl #32
    // 0x5a4adc: stur            x5, [fp, #-0x50]
    // 0x5a4ae0: LoadField: r6 = r0->field_27
    //     0x5a4ae0: ldur            w6, [x0, #0x27]
    // 0x5a4ae4: DecompressPointer r6
    //     0x5a4ae4: add             x6, x6, HEAP, lsl #32
    // 0x5a4ae8: mov             x0, x6
    // 0x5a4aec: ldur            x2, [fp, #-0x10]
    // 0x5a4af0: stur            x6, [fp, #-0x38]
    // 0x5a4af4: r1 = Null
    //     0x5a4af4: mov             x1, NULL
    // 0x5a4af8: r8 = (dynamic this, C1X0?) => String?
    //     0x5a4af8: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c638] FunctionType: (dynamic this, C1X0?) => String?
    //     0x5a4afc: ldr             x8, [x8, #0x638]
    // 0x5a4b00: LoadField: r9 = r8->field_7
    //     0x5a4b00: ldur            x9, [x8, #7]
    // 0x5a4b04: r3 = Null
    //     0x5a4b04: add             x3, PP, #0x34, lsl #12  ; [pp+0x345a8] Null
    //     0x5a4b08: ldr             x3, [x3, #0x5a8]
    // 0x5a4b0c: blr             x9
    // 0x5a4b10: ldur            x16, [fp, #-0x38]
    // 0x5a4b14: ldur            lr, [fp, #-0x50]
    // 0x5a4b18: stp             lr, x16, [SP]
    // 0x5a4b1c: ldur            x0, [fp, #-0x38]
    // 0x5a4b20: ClosureCall
    //     0x5a4b20: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5a4b24: ldur            x2, [x0, #0x1f]
    //     0x5a4b28: blr             x2
    // 0x5a4b2c: ldur            x1, [fp, #-0x60]
    // 0x5a4b30: ArrayStore: r1[2] = r0  ; List_4
    //     0x5a4b30: add             x25, x1, #0x17
    //     0x5a4b34: str             w0, [x25]
    //     0x5a4b38: tbz             w0, #0, #0x5a4b54
    //     0x5a4b3c: ldurb           w16, [x1, #-1]
    //     0x5a4b40: ldurb           w17, [x0, #-1]
    //     0x5a4b44: and             x16, x17, x16, lsr #2
    //     0x5a4b48: tst             x16, HEAP, lsr #32
    //     0x5a4b4c: b.eq            #0x5a4b54
    //     0x5a4b50: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a4b54: ldur            x16, [fp, #-0x60]
    // 0x5a4b58: str             x16, [SP]
    // 0x5a4b5c: r0 = _interpolate()
    //     0x5a4b5c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x5a4b60: stur            x0, [fp, #-0x38]
    // 0x5a4b64: r0 = Text()
    //     0x5a4b64: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x5a4b68: mov             x1, x0
    // 0x5a4b6c: ldur            x0, [fp, #-0x38]
    // 0x5a4b70: StoreField: r1->field_b = r0
    //     0x5a4b70: stur            w0, [x1, #0xb]
    // 0x5a4b74: mov             x0, x1
    // 0x5a4b78: mov             x3, x0
    // 0x5a4b7c: ldur            x0, [fp, #-0x58]
    // 0x5a4b80: ldur            x1, [fp, #-0x40]
    // 0x5a4b84: ldur            x2, [fp, #-0x20]
    // 0x5a4b88: stur            x3, [fp, #-0x38]
    // 0x5a4b8c: r0 = Padding()
    //     0x5a4b8c: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x5a4b90: mov             x1, x0
    // 0x5a4b94: r0 = Instance_EdgeInsets
    //     0x5a4b94: add             x0, PP, #0x34, lsl #12  ; [pp+0x345b8] Obj!EdgeInsets@831ec1
    //     0x5a4b98: ldr             x0, [x0, #0x5b8]
    // 0x5a4b9c: stur            x1, [fp, #-0x48]
    // 0x5a4ba0: StoreField: r1->field_f = r0
    //     0x5a4ba0: stur            w0, [x1, #0xf]
    // 0x5a4ba4: ldur            x2, [fp, #-0x38]
    // 0x5a4ba8: StoreField: r1->field_b = r2
    //     0x5a4ba8: stur            w2, [x1, #0xb]
    // 0x5a4bac: r0 = TextButton()
    //     0x5a4bac: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x5a4bb0: mov             x1, x0
    // 0x5a4bb4: r0 = false
    //     0x5a4bb4: add             x0, NULL, #0x30  ; false
    // 0x5a4bb8: stur            x1, [fp, #-0x38]
    // 0x5a4bbc: StoreField: r1->field_3f = r0
    //     0x5a4bbc: stur            w0, [x1, #0x3f]
    // 0x5a4bc0: ldur            x2, [fp, #-0x58]
    // 0x5a4bc4: StoreField: r1->field_b = r2
    //     0x5a4bc4: stur            w2, [x1, #0xb]
    // 0x5a4bc8: StoreField: r1->field_27 = r0
    //     0x5a4bc8: stur            w0, [x1, #0x27]
    // 0x5a4bcc: r2 = true
    //     0x5a4bcc: add             x2, NULL, #0x20  ; true
    // 0x5a4bd0: StoreField: r1->field_2f = r2
    //     0x5a4bd0: stur            w2, [x1, #0x2f]
    // 0x5a4bd4: ldur            x3, [fp, #-0x48]
    // 0x5a4bd8: StoreField: r1->field_3b = r3
    //     0x5a4bd8: stur            w3, [x1, #0x3b]
    // 0x5a4bdc: r0 = GestureDetector()
    //     0x5a4bdc: bl              #0x5a4268  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x5a4be0: mov             x3, x0
    // 0x5a4be4: ldur            x0, [fp, #-0x38]
    // 0x5a4be8: stur            x3, [fp, #-0x48]
    // 0x5a4bec: StoreField: r3->field_b = r0
    //     0x5a4bec: stur            w0, [x3, #0xb]
    // 0x5a4bf0: ldur            x2, [fp, #-0x30]
    // 0x5a4bf4: r1 = Function '<anonymous closure>':.
    //     0x5a4bf4: add             x1, PP, #0x34, lsl #12  ; [pp+0x345c0] AnonymousClosure: (0x5a5170), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] _AutoDialogState::build (0x5a46a0)
    //     0x5a4bf8: ldr             x1, [x1, #0x5c0]
    // 0x5a4bfc: r0 = AllocateClosure()
    //     0x5a4bfc: bl              #0x826750  ; AllocateClosureStub
    // 0x5a4c00: mov             x1, x0
    // 0x5a4c04: ldur            x0, [fp, #-0x48]
    // 0x5a4c08: ArrayStore: r0[0] = r1  ; List_4
    //     0x5a4c08: stur            w1, [x0, #0x17]
    // 0x5a4c0c: r1 = false
    //     0x5a4c0c: add             x1, NULL, #0x30  ; false
    // 0x5a4c10: StoreField: r0->field_f7 = r1
    //     0x5a4c10: stur            w1, [x0, #0xf7]
    // 0x5a4c14: r2 = Instance_DragStartBehavior
    //     0x5a4c14: ldr             x2, [PP, #0x70b0]  ; [pp+0x70b0] Obj!DragStartBehavior@863b61
    // 0x5a4c18: StoreField: r0->field_fb = r2
    //     0x5a4c18: stur            w2, [x0, #0xfb]
    // 0x5a4c1c: r17 = 259
    //     0x5a4c1c: movz            x17, #0x103
    // 0x5a4c20: str             w1, [x0, x17]
    // 0x5a4c24: r3 = Instance_Offset
    //     0x5a4c24: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a128] Obj!Offset@8405a1
    //     0x5a4c28: ldr             x3, [x3, #0x128]
    // 0x5a4c2c: r17 = 263
    //     0x5a4c2c: movz            x17, #0x107
    // 0x5a4c30: str             w3, [x0, x17]
    // 0x5a4c34: r0 = ListTile()
    //     0x5a4c34: bl              #0x5a4e84  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x5a4c38: mov             x2, x0
    // 0x5a4c3c: ldur            x0, [fp, #-0x40]
    // 0x5a4c40: stur            x2, [fp, #-0x30]
    // 0x5a4c44: StoreField: r2->field_f = r0
    //     0x5a4c44: stur            w0, [x2, #0xf]
    // 0x5a4c48: ldur            x0, [fp, #-0x48]
    // 0x5a4c4c: ArrayStore: r2[0] = r0  ; List_4
    //     0x5a4c4c: stur            w0, [x2, #0x17]
    // 0x5a4c50: r0 = true
    //     0x5a4c50: add             x0, NULL, #0x20  ; true
    // 0x5a4c54: StoreField: r2->field_4b = r0
    //     0x5a4c54: stur            w0, [x2, #0x4b]
    // 0x5a4c58: r3 = false
    //     0x5a4c58: add             x3, NULL, #0x30  ; false
    // 0x5a4c5c: StoreField: r2->field_5f = r3
    //     0x5a4c5c: stur            w3, [x2, #0x5f]
    // 0x5a4c60: StoreField: r2->field_73 = r3
    //     0x5a4c60: stur            w3, [x2, #0x73]
    // 0x5a4c64: StoreField: r2->field_97 = r0
    //     0x5a4c64: stur            w0, [x2, #0x97]
    // 0x5a4c68: ldur            x4, [fp, #-0x20]
    // 0x5a4c6c: LoadField: r1 = r4->field_b
    //     0x5a4c6c: ldur            w1, [x4, #0xb]
    // 0x5a4c70: LoadField: r5 = r4->field_f
    //     0x5a4c70: ldur            w5, [x4, #0xf]
    // 0x5a4c74: DecompressPointer r5
    //     0x5a4c74: add             x5, x5, HEAP, lsl #32
    // 0x5a4c78: LoadField: r6 = r5->field_b
    //     0x5a4c78: ldur            w6, [x5, #0xb]
    // 0x5a4c7c: r5 = LoadInt32Instr(r1)
    //     0x5a4c7c: sbfx            x5, x1, #1, #0x1f
    // 0x5a4c80: stur            x5, [fp, #-0x68]
    // 0x5a4c84: r1 = LoadInt32Instr(r6)
    //     0x5a4c84: sbfx            x1, x6, #1, #0x1f
    // 0x5a4c88: cmp             x5, x1
    // 0x5a4c8c: b.ne            #0x5a4c98
    // 0x5a4c90: mov             x1, x4
    // 0x5a4c94: r0 = _growToNextCapacity()
    //     0x5a4c94: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5a4c98: ldur            x2, [fp, #-0x20]
    // 0x5a4c9c: ldur            x3, [fp, #-0x68]
    // 0x5a4ca0: add             x0, x3, #1
    // 0x5a4ca4: lsl             x1, x0, #1
    // 0x5a4ca8: StoreField: r2->field_b = r1
    //     0x5a4ca8: stur            w1, [x2, #0xb]
    // 0x5a4cac: LoadField: r1 = r2->field_f
    //     0x5a4cac: ldur            w1, [x2, #0xf]
    // 0x5a4cb0: DecompressPointer r1
    //     0x5a4cb0: add             x1, x1, HEAP, lsl #32
    // 0x5a4cb4: ldur            x0, [fp, #-0x30]
    // 0x5a4cb8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x5a4cb8: add             x25, x1, x3, lsl #2
    //     0x5a4cbc: add             x25, x25, #0xf
    //     0x5a4cc0: str             w0, [x25]
    //     0x5a4cc4: tbz             w0, #0, #0x5a4ce0
    //     0x5a4cc8: ldurb           w16, [x1, #-1]
    //     0x5a4ccc: ldurb           w17, [x0, #-1]
    //     0x5a4cd0: and             x16, x17, x16, lsr #2
    //     0x5a4cd4: tst             x16, HEAP, lsr #32
    //     0x5a4cd8: b.eq            #0x5a4ce0
    //     0x5a4cdc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a4ce0: mov             x5, x2
    // 0x5a4ce4: ldur            x2, [fp, #-8]
    // 0x5a4ce8: ldur            x3, [fp, #-0x28]
    // 0x5a4cec: ldur            x4, [fp, #-0x10]
    // 0x5a4cf0: b               #0x5a4778
    // 0x5a4cf4: ldur            x2, [fp, #-0x20]
    // 0x5a4cf8: r0 = Column()
    //     0x5a4cf8: bl              #0x4e8d74  ; AllocateColumnStub -> Column (size=0x38)
    // 0x5a4cfc: mov             x1, x0
    // 0x5a4d00: r0 = Instance_Axis
    //     0x5a4d00: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x5a4d04: stur            x1, [fp, #-8]
    // 0x5a4d08: StoreField: r1->field_f = r0
    //     0x5a4d08: stur            w0, [x1, #0xf]
    // 0x5a4d0c: r2 = Instance_MainAxisAlignment
    //     0x5a4d0c: add             x2, PP, #0x19, lsl #12  ; [pp+0x19200] Obj!MainAxisAlignment@862a61
    //     0x5a4d10: ldr             x2, [x2, #0x200]
    // 0x5a4d14: StoreField: r1->field_13 = r2
    //     0x5a4d14: stur            w2, [x1, #0x13]
    // 0x5a4d18: r2 = Instance_MainAxisSize
    //     0x5a4d18: add             x2, PP, #0x19, lsl #12  ; [pp+0x19208] Obj!MainAxisSize@862a81
    //     0x5a4d1c: ldr             x2, [x2, #0x208]
    // 0x5a4d20: ArrayStore: r1[0] = r2  ; List_4
    //     0x5a4d20: stur            w2, [x1, #0x17]
    // 0x5a4d24: r2 = Instance_CrossAxisAlignment
    //     0x5a4d24: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a078] Obj!CrossAxisAlignment@862961
    //     0x5a4d28: ldr             x2, [x2, #0x78]
    // 0x5a4d2c: StoreField: r1->field_1b = r2
    //     0x5a4d2c: stur            w2, [x1, #0x1b]
    // 0x5a4d30: r2 = Instance_VerticalDirection
    //     0x5a4d30: add             x2, PP, #0x19, lsl #12  ; [pp+0x191e8] Obj!VerticalDirection@862e01
    //     0x5a4d34: ldr             x2, [x2, #0x1e8]
    // 0x5a4d38: StoreField: r1->field_23 = r2
    //     0x5a4d38: stur            w2, [x1, #0x23]
    // 0x5a4d3c: r2 = Instance_Clip
    //     0x5a4d3c: add             x2, PP, #0x19, lsl #12  ; [pp+0x191b0] Obj!Clip@865dc1
    //     0x5a4d40: ldr             x2, [x2, #0x1b0]
    // 0x5a4d44: StoreField: r1->field_2b = r2
    //     0x5a4d44: stur            w2, [x1, #0x2b]
    // 0x5a4d48: StoreField: r1->field_2f = rZR
    //     0x5a4d48: stur            xzr, [x1, #0x2f]
    // 0x5a4d4c: ldur            x2, [fp, #-0x20]
    // 0x5a4d50: StoreField: r1->field_b = r2
    //     0x5a4d50: stur            w2, [x1, #0xb]
    // 0x5a4d54: r0 = SingleChildScrollView()
    //     0x5a4d54: bl              #0x5a4e90  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x5a4d58: mov             x1, x0
    // 0x5a4d5c: r0 = Instance_Axis
    //     0x5a4d5c: ldr             x0, [PP, #0x6738]  ; [pp+0x6738] Obj!Axis@862e41
    // 0x5a4d60: stur            x1, [fp, #-0x10]
    // 0x5a4d64: StoreField: r1->field_b = r0
    //     0x5a4d64: stur            w0, [x1, #0xb]
    // 0x5a4d68: r0 = false
    //     0x5a4d68: add             x0, NULL, #0x30  ; false
    // 0x5a4d6c: StoreField: r1->field_f = r0
    //     0x5a4d6c: stur            w0, [x1, #0xf]
    // 0x5a4d70: ldur            x2, [fp, #-8]
    // 0x5a4d74: StoreField: r1->field_23 = r2
    //     0x5a4d74: stur            w2, [x1, #0x23]
    // 0x5a4d78: r2 = Instance_DragStartBehavior
    //     0x5a4d78: ldr             x2, [PP, #0x70b0]  ; [pp+0x70b0] Obj!DragStartBehavior@863b61
    // 0x5a4d7c: StoreField: r1->field_27 = r2
    //     0x5a4d7c: stur            w2, [x1, #0x27]
    // 0x5a4d80: r2 = Instance_Clip
    //     0x5a4d80: add             x2, PP, #0x16, lsl #12  ; [pp+0x16900] Obj!Clip@865d81
    //     0x5a4d84: ldr             x2, [x2, #0x900]
    // 0x5a4d88: StoreField: r1->field_2b = r2
    //     0x5a4d88: stur            w2, [x1, #0x2b]
    // 0x5a4d8c: r2 = Instance_HitTestBehavior
    //     0x5a4d8c: add             x2, PP, #0xc, lsl #12  ; [pp+0xc9a8] Obj!HitTestBehavior@8628c1
    //     0x5a4d90: ldr             x2, [x2, #0x9a8]
    // 0x5a4d94: StoreField: r1->field_2f = r2
    //     0x5a4d94: stur            w2, [x1, #0x2f]
    // 0x5a4d98: r0 = TextButton()
    //     0x5a4d98: bl              #0x490080  ; AllocateTextButtonStub -> TextButton (size=0x44)
    // 0x5a4d9c: mov             x3, x0
    // 0x5a4da0: r0 = false
    //     0x5a4da0: add             x0, NULL, #0x30  ; false
    // 0x5a4da4: stur            x3, [fp, #-8]
    // 0x5a4da8: StoreField: r3->field_3f = r0
    //     0x5a4da8: stur            w0, [x3, #0x3f]
    // 0x5a4dac: ldur            x2, [fp, #-0x18]
    // 0x5a4db0: r1 = Function '<anonymous closure>':.
    //     0x5a4db0: add             x1, PP, #0x34, lsl #12  ; [pp+0x345c8] AnonymousClosure: (0x5a4e9c), in [package:pretentious/Popups/MenuPopup/MenuPopup.dart] MenuPopupState::build (0x620ce4)
    //     0x5a4db4: ldr             x1, [x1, #0x5c8]
    // 0x5a4db8: r0 = AllocateClosure()
    //     0x5a4db8: bl              #0x826750  ; AllocateClosureStub
    // 0x5a4dbc: mov             x1, x0
    // 0x5a4dc0: ldur            x0, [fp, #-8]
    // 0x5a4dc4: StoreField: r0->field_b = r1
    //     0x5a4dc4: stur            w1, [x0, #0xb]
    // 0x5a4dc8: r3 = false
    //     0x5a4dc8: add             x3, NULL, #0x30  ; false
    // 0x5a4dcc: StoreField: r0->field_27 = r3
    //     0x5a4dcc: stur            w3, [x0, #0x27]
    // 0x5a4dd0: r1 = true
    //     0x5a4dd0: add             x1, NULL, #0x20  ; true
    // 0x5a4dd4: StoreField: r0->field_2f = r1
    //     0x5a4dd4: stur            w1, [x0, #0x2f]
    // 0x5a4dd8: r1 = Instance_Text
    //     0x5a4dd8: add             x1, PP, #0x25, lsl #12  ; [pp+0x25a00] Obj!Text@84f451
    //     0x5a4ddc: ldr             x1, [x1, #0xa00]
    // 0x5a4de0: StoreField: r0->field_3b = r1
    //     0x5a4de0: stur            w1, [x0, #0x3b]
    // 0x5a4de4: r1 = Null
    //     0x5a4de4: mov             x1, NULL
    // 0x5a4de8: r2 = 2
    //     0x5a4de8: movz            x2, #0x2
    // 0x5a4dec: r0 = AllocateArray()
    //     0x5a4dec: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a4df0: mov             x2, x0
    // 0x5a4df4: ldur            x0, [fp, #-8]
    // 0x5a4df8: stur            x2, [fp, #-0x18]
    // 0x5a4dfc: StoreField: r2->field_f = r0
    //     0x5a4dfc: stur            w0, [x2, #0xf]
    // 0x5a4e00: r1 = <Widget>
    //     0x5a4e00: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x5a4e04: r0 = AllocateGrowableArray()
    //     0x5a4e04: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x5a4e08: mov             x1, x0
    // 0x5a4e0c: ldur            x0, [fp, #-0x18]
    // 0x5a4e10: stur            x1, [fp, #-8]
    // 0x5a4e14: StoreField: r1->field_f = r0
    //     0x5a4e14: stur            w0, [x1, #0xf]
    // 0x5a4e18: r0 = 2
    //     0x5a4e18: movz            x0, #0x2
    // 0x5a4e1c: StoreField: r1->field_b = r0
    //     0x5a4e1c: stur            w0, [x1, #0xb]
    // 0x5a4e20: r0 = AlertDialog()
    //     0x5a4e20: bl              #0x490074  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x5a4e24: r1 = Instance_Text
    //     0x5a4e24: add             x1, PP, #0x34, lsl #12  ; [pp+0x345d0] Obj!Text@84f221
    //     0x5a4e28: ldr             x1, [x1, #0x5d0]
    // 0x5a4e2c: StoreField: r0->field_f = r1
    //     0x5a4e2c: stur            w1, [x0, #0xf]
    // 0x5a4e30: ldur            x1, [fp, #-0x10]
    // 0x5a4e34: StoreField: r0->field_1b = r1
    //     0x5a4e34: stur            w1, [x0, #0x1b]
    // 0x5a4e38: ldur            x1, [fp, #-8]
    // 0x5a4e3c: StoreField: r0->field_27 = r1
    //     0x5a4e3c: stur            w1, [x0, #0x27]
    // 0x5a4e40: r1 = false
    //     0x5a4e40: add             x1, NULL, #0x30  ; false
    // 0x5a4e44: StoreField: r0->field_6b = r1
    //     0x5a4e44: stur            w1, [x0, #0x6b]
    // 0x5a4e48: LeaveFrame
    //     0x5a4e48: mov             SP, fp
    //     0x5a4e4c: ldp             fp, lr, [SP], #0x10
    // 0x5a4e50: ret
    //     0x5a4e50: ret             
    // 0x5a4e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a4e54: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a4e58: b               #0x5a46c0
    // 0x5a4e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e5c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a4e60: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a4e64: b               #0x5a4788
    // 0x5a4e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e68: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e6c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e70: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e74: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e78: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e7c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4e80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4e80: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5a5170, size: 0xa4
    // 0x5a5170: EnterFrame
    //     0x5a5170: stp             fp, lr, [SP, #-0x10]!
    //     0x5a5174: mov             fp, SP
    // 0x5a5178: AllocStack(0x8)
    //     0x5a5178: sub             SP, SP, #8
    // 0x5a517c: SetupParameters([dynamic _ /* r0 */])
    //     0x5a517c: ldr             x0, [fp, #0x10]
    //     0x5a5180: ldur            w1, [x0, #0x17]
    //     0x5a5184: add             x1, x1, HEAP, lsl #32
    // 0x5a5188: CheckStackOverflow
    //     0x5a5188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a518c: cmp             SP, x16
    //     0x5a5190: b.ls            #0x5a5204
    // 0x5a5194: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x5a5194: ldur            w0, [x1, #0x17]
    // 0x5a5198: DecompressPointer r0
    //     0x5a5198: add             x0, x0, HEAP, lsl #32
    // 0x5a519c: tbnz            w0, #4, #0x5a51f4
    // 0x5a51a0: LoadField: r0 = r1->field_b
    //     0x5a51a0: ldur            w0, [x1, #0xb]
    // 0x5a51a4: DecompressPointer r0
    //     0x5a51a4: add             x0, x0, HEAP, lsl #32
    // 0x5a51a8: LoadField: r1 = r0->field_f
    //     0x5a51a8: ldur            w1, [x0, #0xf]
    // 0x5a51ac: DecompressPointer r1
    //     0x5a51ac: add             x1, x1, HEAP, lsl #32
    // 0x5a51b0: LoadField: r0 = r1->field_b
    //     0x5a51b0: ldur            w0, [x1, #0xb]
    // 0x5a51b4: DecompressPointer r0
    //     0x5a51b4: add             x0, x0, HEAP, lsl #32
    // 0x5a51b8: cmp             w0, NULL
    // 0x5a51bc: b.eq            #0x5a520c
    // 0x5a51c0: LoadField: r1 = r0->field_13
    //     0x5a51c0: ldur            w1, [x0, #0x13]
    // 0x5a51c4: DecompressPointer r1
    //     0x5a51c4: add             x1, x1, HEAP, lsl #32
    // 0x5a51c8: cmp             w1, NULL
    // 0x5a51cc: b.eq            #0x5a51f4
    // 0x5a51d0: LoadField: r1 = r0->field_13
    //     0x5a51d0: ldur            w1, [x0, #0x13]
    // 0x5a51d4: DecompressPointer r1
    //     0x5a51d4: add             x1, x1, HEAP, lsl #32
    // 0x5a51d8: cmp             w1, NULL
    // 0x5a51dc: b.eq            #0x5a5210
    // 0x5a51e0: str             x1, [SP]
    // 0x5a51e4: mov             x0, x1
    // 0x5a51e8: ClosureCall
    //     0x5a51e8: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5a51ec: ldur            x2, [x0, #0x1f]
    //     0x5a51f0: blr             x2
    // 0x5a51f4: r0 = Null
    //     0x5a51f4: mov             x0, NULL
    // 0x5a51f8: LeaveFrame
    //     0x5a51f8: mov             SP, fp
    //     0x5a51fc: ldp             fp, lr, [SP], #0x10
    // 0x5a5200: ret
    //     0x5a5200: ret             
    // 0x5a5204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a5204: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a5208: b               #0x5a5194
    // 0x5a520c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a520c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a5210: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a5210: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5a5214, size: 0x218
    // 0x5a5214: EnterFrame
    //     0x5a5214: stp             fp, lr, [SP, #-0x10]!
    //     0x5a5218: mov             fp, SP
    // 0x5a521c: AllocStack(0x30)
    //     0x5a521c: sub             SP, SP, #0x30
    // 0x5a5220: SetupParameters([dynamic _ /* r0 */])
    //     0x5a5220: ldr             x0, [fp, #0x10]
    //     0x5a5224: ldur            w1, [x0, #0x17]
    //     0x5a5228: add             x1, x1, HEAP, lsl #32
    //     0x5a522c: stur            x1, [fp, #-0x10]
    // 0x5a5230: CheckStackOverflow
    //     0x5a5230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a5234: cmp             SP, x16
    //     0x5a5238: b.ls            #0x5a5410
    // 0x5a523c: LoadField: r2 = r1->field_b
    //     0x5a523c: ldur            w2, [x1, #0xb]
    // 0x5a5240: DecompressPointer r2
    //     0x5a5240: add             x2, x2, HEAP, lsl #32
    // 0x5a5244: stur            x2, [fp, #-8]
    // 0x5a5248: LoadField: r0 = r2->field_f
    //     0x5a5248: ldur            w0, [x2, #0xf]
    // 0x5a524c: DecompressPointer r0
    //     0x5a524c: add             x0, x0, HEAP, lsl #32
    // 0x5a5250: LoadField: r3 = r0->field_b
    //     0x5a5250: ldur            w3, [x0, #0xb]
    // 0x5a5254: DecompressPointer r3
    //     0x5a5254: add             x3, x3, HEAP, lsl #32
    // 0x5a5258: cmp             w3, NULL
    // 0x5a525c: b.eq            #0x5a5418
    // 0x5a5260: LoadField: r0 = r3->field_13
    //     0x5a5260: ldur            w0, [x3, #0x13]
    // 0x5a5264: DecompressPointer r0
    //     0x5a5264: add             x0, x0, HEAP, lsl #32
    // 0x5a5268: cmp             w0, NULL
    // 0x5a526c: b.eq            #0x5a5290
    // 0x5a5270: LoadField: r0 = r3->field_13
    //     0x5a5270: ldur            w0, [x3, #0x13]
    // 0x5a5274: DecompressPointer r0
    //     0x5a5274: add             x0, x0, HEAP, lsl #32
    // 0x5a5278: cmp             w0, NULL
    // 0x5a527c: b.eq            #0x5a541c
    // 0x5a5280: str             x0, [SP]
    // 0x5a5284: ClosureCall
    //     0x5a5284: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5a5288: ldur            x2, [x0, #0x1f]
    //     0x5a528c: blr             x2
    // 0x5a5290: ldur            x0, [fp, #-0x10]
    // 0x5a5294: ldur            x4, [fp, #-8]
    // 0x5a5298: LoadField: r5 = r4->field_f
    //     0x5a5298: ldur            w5, [x4, #0xf]
    // 0x5a529c: DecompressPointer r5
    //     0x5a529c: add             x5, x5, HEAP, lsl #32
    // 0x5a52a0: stur            x5, [fp, #-0x18]
    // 0x5a52a4: LoadField: r2 = r5->field_7
    //     0x5a52a4: ldur            w2, [x5, #7]
    // 0x5a52a8: DecompressPointer r2
    //     0x5a52a8: add             x2, x2, HEAP, lsl #32
    // 0x5a52ac: r1 = Null
    //     0x5a52ac: mov             x1, NULL
    // 0x5a52b0: r3 = <C1X0>
    //     0x5a52b0: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a52b4: ldr             x3, [x3, #0xe38]
    // 0x5a52b8: r0 = Null
    //     0x5a52b8: mov             x0, NULL
    // 0x5a52bc: cmp             x2, x0
    // 0x5a52c0: b.eq            #0x5a52d0
    // 0x5a52c4: r30 = InstantiateTypeArgumentsStub
    //     0x5a52c4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a52c8: LoadField: r30 = r30->field_7
    //     0x5a52c8: ldur            lr, [lr, #7]
    // 0x5a52cc: blr             lr
    // 0x5a52d0: mov             x1, x0
    // 0x5a52d4: ldur            x0, [fp, #-0x18]
    // 0x5a52d8: LoadField: r2 = r0->field_b
    //     0x5a52d8: ldur            w2, [x0, #0xb]
    // 0x5a52dc: DecompressPointer r2
    //     0x5a52dc: add             x2, x2, HEAP, lsl #32
    // 0x5a52e0: cmp             w2, NULL
    // 0x5a52e4: b.eq            #0x5a5420
    // 0x5a52e8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x5a52e8: ldur            w0, [x2, #0x17]
    // 0x5a52ec: DecompressPointer r0
    //     0x5a52ec: add             x0, x0, HEAP, lsl #32
    // 0x5a52f0: ldur            x2, [fp, #-0x10]
    // 0x5a52f4: LoadField: r3 = r2->field_13
    //     0x5a52f4: ldur            w3, [x2, #0x13]
    // 0x5a52f8: DecompressPointer r3
    //     0x5a52f8: add             x3, x3, HEAP, lsl #32
    // 0x5a52fc: stur            x3, [fp, #-0x18]
    // 0x5a5300: stp             x0, x1, [SP, #8]
    // 0x5a5304: str             x3, [SP]
    // 0x5a5308: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a5308: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a530c: r0 = MapOperations.isSupersetOfTuple()
    //     0x5a530c: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x5a5310: tbz             w0, #4, #0x5a5324
    // 0x5a5314: r0 = Null
    //     0x5a5314: mov             x0, NULL
    // 0x5a5318: LeaveFrame
    //     0x5a5318: mov             SP, fp
    //     0x5a531c: ldp             fp, lr, [SP], #0x10
    // 0x5a5320: ret
    //     0x5a5320: ret             
    // 0x5a5324: ldur            x0, [fp, #-0x10]
    // 0x5a5328: ldur            x3, [fp, #-8]
    // 0x5a532c: LoadField: r1 = r3->field_f
    //     0x5a532c: ldur            w1, [x3, #0xf]
    // 0x5a5330: DecompressPointer r1
    //     0x5a5330: add             x1, x1, HEAP, lsl #32
    // 0x5a5334: LoadField: r2 = r1->field_b
    //     0x5a5334: ldur            w2, [x1, #0xb]
    // 0x5a5338: DecompressPointer r2
    //     0x5a5338: add             x2, x2, HEAP, lsl #32
    // 0x5a533c: cmp             w2, NULL
    // 0x5a5340: b.eq            #0x5a5424
    // 0x5a5344: LoadField: r1 = r2->field_23
    //     0x5a5344: ldur            w1, [x2, #0x23]
    // 0x5a5348: DecompressPointer r1
    //     0x5a5348: add             x1, x1, HEAP, lsl #32
    // 0x5a534c: LoadField: r2 = r0->field_f
    //     0x5a534c: ldur            w2, [x0, #0xf]
    // 0x5a5350: DecompressPointer r2
    //     0x5a5350: add             x2, x2, HEAP, lsl #32
    // 0x5a5354: r0 = add()
    //     0x5a5354: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x5a5358: ldur            x0, [fp, #-8]
    // 0x5a535c: LoadField: r4 = r0->field_f
    //     0x5a535c: ldur            w4, [x0, #0xf]
    // 0x5a5360: DecompressPointer r4
    //     0x5a5360: add             x4, x4, HEAP, lsl #32
    // 0x5a5364: stur            x4, [fp, #-0x10]
    // 0x5a5368: LoadField: r2 = r4->field_7
    //     0x5a5368: ldur            w2, [x4, #7]
    // 0x5a536c: DecompressPointer r2
    //     0x5a536c: add             x2, x2, HEAP, lsl #32
    // 0x5a5370: r1 = Null
    //     0x5a5370: mov             x1, NULL
    // 0x5a5374: r3 = <C1X0>
    //     0x5a5374: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a5378: ldr             x3, [x3, #0xe38]
    // 0x5a537c: r0 = Null
    //     0x5a537c: mov             x0, NULL
    // 0x5a5380: cmp             x2, x0
    // 0x5a5384: b.eq            #0x5a5394
    // 0x5a5388: r30 = InstantiateTypeArgumentsStub
    //     0x5a5388: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a538c: LoadField: r30 = r30->field_7
    //     0x5a538c: ldur            lr, [lr, #7]
    // 0x5a5390: blr             lr
    // 0x5a5394: mov             x1, x0
    // 0x5a5398: ldur            x0, [fp, #-0x10]
    // 0x5a539c: LoadField: r2 = r0->field_b
    //     0x5a539c: ldur            w2, [x0, #0xb]
    // 0x5a53a0: DecompressPointer r2
    //     0x5a53a0: add             x2, x2, HEAP, lsl #32
    // 0x5a53a4: cmp             w2, NULL
    // 0x5a53a8: b.eq            #0x5a5428
    // 0x5a53ac: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x5a53ac: ldur            w0, [x2, #0x17]
    // 0x5a53b0: DecompressPointer r0
    //     0x5a53b0: add             x0, x0, HEAP, lsl #32
    // 0x5a53b4: stp             x0, x1, [SP, #8]
    // 0x5a53b8: ldur            x16, [fp, #-0x18]
    // 0x5a53bc: str             x16, [SP]
    // 0x5a53c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a53c0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a53c4: r0 = MapOperations.subtractTuple()
    //     0x5a53c4: bl              #0x539e38  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.subtractTuple
    // 0x5a53c8: r0 = currentActiveState()
    //     0x5a53c8: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x5a53cc: mov             x1, x0
    // 0x5a53d0: r0 = saveDeferred()
    //     0x5a53d0: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x5a53d4: r0 = LoadStaticField(0xfb4)
    //     0x5a53d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a53d8: ldr             x0, [x0, #0x1f68]
    // 0x5a53dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a53e0: cmp             w0, w16
    // 0x5a53e4: b.ne            #0x5a53f4
    // 0x5a53e8: r2 = generatorStateGroup
    //     0x5a53e8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x5a53ec: ldr             x2, [x2, #0x138]
    // 0x5a53f0: r0 = InitLateStaticField()
    //     0x5a53f0: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a53f4: mov             x1, x0
    // 0x5a53f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5a53f8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5a53fc: r0 = notifyAll()
    //     0x5a53fc: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x5a5400: r0 = Null
    //     0x5a5400: mov             x0, NULL
    // 0x5a5404: LeaveFrame
    //     0x5a5404: mov             SP, fp
    //     0x5a5408: ldp             fp, lr, [SP], #0x10
    // 0x5a540c: ret
    //     0x5a540c: ret             
    // 0x5a5410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a5410: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a5414: b               #0x5a523c
    // 0x5a5418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a5418: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a541c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a541c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a5420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a5420: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a5424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a5424: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a5428: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a5428: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3542, size: 0x1c, field offset: 0x1c
class AutoButtonState<C1X0> extends SyncState2<C1X0> {

  _ build(/* No info */) {
    // ** addr: 0x5a3950, size: 0x3cc
    // 0x5a3950: EnterFrame
    //     0x5a3950: stp             fp, lr, [SP, #-0x10]!
    //     0x5a3954: mov             fp, SP
    // 0x5a3958: AllocStack(0x48)
    //     0x5a3958: sub             SP, SP, #0x48
    // 0x5a395c: SetupParameters(AutoButtonState<C1X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x5a395c: stur            x1, [fp, #-8]
    //     0x5a3960: stur            x2, [fp, #-0x10]
    // 0x5a3964: CheckStackOverflow
    //     0x5a3964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a3968: cmp             SP, x16
    //     0x5a396c: b.ls            #0x5a3cf8
    // 0x5a3970: r1 = 3
    //     0x5a3970: movz            x1, #0x3
    // 0x5a3974: r0 = AllocateContext()
    //     0x5a3974: bl              #0x82637c  ; AllocateContextStub
    // 0x5a3978: mov             x3, x0
    // 0x5a397c: ldur            x2, [fp, #-8]
    // 0x5a3980: stur            x3, [fp, #-0x18]
    // 0x5a3984: StoreField: r3->field_f = r2
    //     0x5a3984: stur            w2, [x3, #0xf]
    // 0x5a3988: ldur            x0, [fp, #-0x10]
    // 0x5a398c: StoreField: r3->field_13 = r0
    //     0x5a398c: stur            w0, [x3, #0x13]
    // 0x5a3990: LoadField: r0 = r2->field_b
    //     0x5a3990: ldur            w0, [x2, #0xb]
    // 0x5a3994: DecompressPointer r0
    //     0x5a3994: add             x0, x0, HEAP, lsl #32
    // 0x5a3998: cmp             w0, NULL
    // 0x5a399c: b.eq            #0x5a3d00
    // 0x5a39a0: LoadField: r1 = r0->field_1f
    //     0x5a39a0: ldur            w1, [x0, #0x1f]
    // 0x5a39a4: DecompressPointer r1
    //     0x5a39a4: add             x1, x1, HEAP, lsl #32
    // 0x5a39a8: r0 = LoadClassIdInstr(r1)
    //     0x5a39a8: ldur            x0, [x1, #-1]
    //     0x5a39ac: ubfx            x0, x0, #0xc, #0x14
    // 0x5a39b0: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x5a39b0: movz            x17, #0x7df6
    //     0x5a39b4: add             lr, x0, x17
    //     0x5a39b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5a39bc: blr             lr
    // 0x5a39c0: mov             x3, x0
    // 0x5a39c4: ldur            x2, [fp, #-8]
    // 0x5a39c8: stur            x3, [fp, #-0x20]
    // 0x5a39cc: LoadField: r4 = r2->field_7
    //     0x5a39cc: ldur            w4, [x2, #7]
    // 0x5a39d0: DecompressPointer r4
    //     0x5a39d0: add             x4, x4, HEAP, lsl #32
    // 0x5a39d4: stur            x4, [fp, #-0x10]
    // 0x5a39d8: ldur            x5, [fp, #-0x18]
    // 0x5a39dc: CheckStackOverflow
    //     0x5a39dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a39e0: cmp             SP, x16
    //     0x5a39e4: b.ls            #0x5a3d04
    // 0x5a39e8: r0 = LoadClassIdInstr(r3)
    //     0x5a39e8: ldur            x0, [x3, #-1]
    //     0x5a39ec: ubfx            x0, x0, #0xc, #0x14
    // 0x5a39f0: mov             x1, x3
    // 0x5a39f4: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x5a39f4: sub             lr, x0, #0xfc4
    //     0x5a39f8: ldr             lr, [x21, lr, lsl #3]
    //     0x5a39fc: blr             lr
    // 0x5a3a00: tbnz            w0, #4, #0x5a3bbc
    // 0x5a3a04: ldur            x2, [fp, #-8]
    // 0x5a3a08: ldur            x3, [fp, #-0x20]
    // 0x5a3a0c: r0 = LoadClassIdInstr(r3)
    //     0x5a3a0c: ldur            x0, [x3, #-1]
    //     0x5a3a10: ubfx            x0, x0, #0xc, #0x14
    // 0x5a3a14: mov             x1, x3
    // 0x5a3a18: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x5a3a18: sub             lr, x0, #0xfb6
    //     0x5a3a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x5a3a20: blr             lr
    // 0x5a3a24: mov             x3, x0
    // 0x5a3a28: ldur            x0, [fp, #-8]
    // 0x5a3a2c: stur            x3, [fp, #-0x30]
    // 0x5a3a30: LoadField: r1 = r0->field_b
    //     0x5a3a30: ldur            w1, [x0, #0xb]
    // 0x5a3a34: DecompressPointer r1
    //     0x5a3a34: add             x1, x1, HEAP, lsl #32
    // 0x5a3a38: cmp             w1, NULL
    // 0x5a3a3c: b.eq            #0x5a3d0c
    // 0x5a3a40: LoadField: r2 = r1->field_f
    //     0x5a3a40: ldur            w2, [x1, #0xf]
    // 0x5a3a44: DecompressPointer r2
    //     0x5a3a44: add             x2, x2, HEAP, lsl #32
    // 0x5a3a48: LoadField: r4 = r2->field_f
    //     0x5a3a48: ldur            w4, [x2, #0xf]
    // 0x5a3a4c: DecompressPointer r4
    //     0x5a3a4c: add             x4, x4, HEAP, lsl #32
    // 0x5a3a50: mov             x1, x2
    // 0x5a3a54: mov             x2, x3
    // 0x5a3a58: stur            x4, [fp, #-0x28]
    // 0x5a3a5c: r0 = _getValueOrData()
    //     0x5a3a5c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a3a60: mov             x1, x0
    // 0x5a3a64: ldur            x0, [fp, #-0x28]
    // 0x5a3a68: cmp             w0, w1
    // 0x5a3a6c: b.ne            #0x5a3a78
    // 0x5a3a70: ldur            x3, [fp, #-0x18]
    // 0x5a3a74: b               #0x5a3ba8
    // 0x5a3a78: ldur            x0, [fp, #-8]
    // 0x5a3a7c: LoadField: r1 = r0->field_b
    //     0x5a3a7c: ldur            w1, [x0, #0xb]
    // 0x5a3a80: DecompressPointer r1
    //     0x5a3a80: add             x1, x1, HEAP, lsl #32
    // 0x5a3a84: cmp             w1, NULL
    // 0x5a3a88: b.eq            #0x5a3d10
    // 0x5a3a8c: LoadField: r2 = r1->field_27
    //     0x5a3a8c: ldur            w2, [x1, #0x27]
    // 0x5a3a90: DecompressPointer r2
    //     0x5a3a90: add             x2, x2, HEAP, lsl #32
    // 0x5a3a94: LoadField: r3 = r2->field_f
    //     0x5a3a94: ldur            w3, [x2, #0xf]
    // 0x5a3a98: DecompressPointer r3
    //     0x5a3a98: add             x3, x3, HEAP, lsl #32
    // 0x5a3a9c: mov             x1, x2
    // 0x5a3aa0: ldur            x2, [fp, #-0x30]
    // 0x5a3aa4: stur            x3, [fp, #-0x28]
    // 0x5a3aa8: r0 = _getKeyOrData()
    //     0x5a3aa8: bl              #0x3f7518  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x5a3aac: mov             x1, x0
    // 0x5a3ab0: ldur            x0, [fp, #-0x28]
    // 0x5a3ab4: cmp             w0, w1
    // 0x5a3ab8: b.ne            #0x5a3ba4
    // 0x5a3abc: ldur            x1, [fp, #-8]
    // 0x5a3ac0: LoadField: r0 = r1->field_b
    //     0x5a3ac0: ldur            w0, [x1, #0xb]
    // 0x5a3ac4: DecompressPointer r0
    //     0x5a3ac4: add             x0, x0, HEAP, lsl #32
    // 0x5a3ac8: cmp             w0, NULL
    // 0x5a3acc: b.eq            #0x5a3d14
    // 0x5a3ad0: LoadField: r2 = r0->field_23
    //     0x5a3ad0: ldur            w2, [x0, #0x23]
    // 0x5a3ad4: DecompressPointer r2
    //     0x5a3ad4: add             x2, x2, HEAP, lsl #32
    // 0x5a3ad8: ldur            x16, [fp, #-0x30]
    // 0x5a3adc: stp             x16, x2, [SP]
    // 0x5a3ae0: mov             x0, x2
    // 0x5a3ae4: ClosureCall
    //     0x5a3ae4: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5a3ae8: ldur            x2, [x0, #0x1f]
    //     0x5a3aec: blr             x2
    // 0x5a3af0: LoadField: r4 = r0->field_2b
    //     0x5a3af0: ldur            w4, [x0, #0x2b]
    // 0x5a3af4: DecompressPointer r4
    //     0x5a3af4: add             x4, x4, HEAP, lsl #32
    // 0x5a3af8: stur            x4, [fp, #-0x28]
    // 0x5a3afc: cmp             w4, NULL
    // 0x5a3b00: b.eq            #0x5a3b9c
    // 0x5a3b04: ldur            x0, [fp, #-8]
    // 0x5a3b08: ldur            x2, [fp, #-0x10]
    // 0x5a3b0c: r1 = Null
    //     0x5a3b0c: mov             x1, NULL
    // 0x5a3b10: r3 = <C1X0>
    //     0x5a3b10: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a3b14: ldr             x3, [x3, #0xe38]
    // 0x5a3b18: r0 = Null
    //     0x5a3b18: mov             x0, NULL
    // 0x5a3b1c: cmp             x2, x0
    // 0x5a3b20: b.eq            #0x5a3b30
    // 0x5a3b24: r30 = InstantiateTypeArgumentsStub
    //     0x5a3b24: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a3b28: LoadField: r30 = r30->field_7
    //     0x5a3b28: ldur            lr, [lr, #7]
    // 0x5a3b2c: blr             lr
    // 0x5a3b30: mov             x1, x0
    // 0x5a3b34: ldur            x0, [fp, #-8]
    // 0x5a3b38: LoadField: r2 = r0->field_b
    //     0x5a3b38: ldur            w2, [x0, #0xb]
    // 0x5a3b3c: DecompressPointer r2
    //     0x5a3b3c: add             x2, x2, HEAP, lsl #32
    // 0x5a3b40: cmp             w2, NULL
    // 0x5a3b44: b.eq            #0x5a3d18
    // 0x5a3b48: LoadField: r3 = r2->field_1b
    //     0x5a3b48: ldur            w3, [x2, #0x1b]
    // 0x5a3b4c: DecompressPointer r3
    //     0x5a3b4c: add             x3, x3, HEAP, lsl #32
    // 0x5a3b50: stp             x3, x1, [SP, #8]
    // 0x5a3b54: ldur            x16, [fp, #-0x28]
    // 0x5a3b58: str             x16, [SP]
    // 0x5a3b5c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a3b5c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a3b60: r0 = MapOperations.isSupersetOfTuple()
    //     0x5a3b60: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x5a3b64: tbnz            w0, #4, #0x5a3b94
    // 0x5a3b68: ldur            x3, [fp, #-0x18]
    // 0x5a3b6c: ldur            x0, [fp, #-0x30]
    // 0x5a3b70: ArrayStore: r3[0] = r0  ; List_4
    //     0x5a3b70: stur            w0, [x3, #0x17]
    //     0x5a3b74: tbz             w0, #0, #0x5a3b90
    //     0x5a3b78: ldurb           w16, [x3, #-1]
    //     0x5a3b7c: ldurb           w17, [x0, #-1]
    //     0x5a3b80: and             x16, x17, x16, lsr #2
    //     0x5a3b84: tst             x16, HEAP, lsr #32
    //     0x5a3b88: b.eq            #0x5a3b90
    //     0x5a3b8c: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x5a3b90: b               #0x5a3ba8
    // 0x5a3b94: ldur            x3, [fp, #-0x18]
    // 0x5a3b98: b               #0x5a3ba8
    // 0x5a3b9c: ldur            x3, [fp, #-0x18]
    // 0x5a3ba0: b               #0x5a3ba8
    // 0x5a3ba4: ldur            x3, [fp, #-0x18]
    // 0x5a3ba8: ldur            x2, [fp, #-8]
    // 0x5a3bac: mov             x5, x3
    // 0x5a3bb0: ldur            x3, [fp, #-0x20]
    // 0x5a3bb4: ldur            x4, [fp, #-0x10]
    // 0x5a3bb8: b               #0x5a39dc
    // 0x5a3bbc: ldur            x3, [fp, #-0x18]
    // 0x5a3bc0: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x5a3bc0: ldur            w0, [x3, #0x17]
    // 0x5a3bc4: DecompressPointer r0
    //     0x5a3bc4: add             x0, x0, HEAP, lsl #32
    // 0x5a3bc8: stur            x0, [fp, #-8]
    // 0x5a3bcc: cmp             w0, NULL
    // 0x5a3bd0: b.eq            #0x5a3bec
    // 0x5a3bd4: mov             x2, x3
    // 0x5a3bd8: r1 = Function '<anonymous closure>':.
    //     0x5a3bd8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32070] AnonymousClosure: (0x5a4454), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] AutoButtonState::build (0x5a3950)
    //     0x5a3bdc: ldr             x1, [x1, #0x70]
    // 0x5a3be0: r0 = AllocateClosure()
    //     0x5a3be0: bl              #0x826750  ; AllocateClosureStub
    // 0x5a3be4: mov             x2, x0
    // 0x5a3be8: b               #0x5a3bf0
    // 0x5a3bec: r2 = Null
    //     0x5a3bec: mov             x2, NULL
    // 0x5a3bf0: ldur            x0, [fp, #-8]
    // 0x5a3bf4: stur            x2, [fp, #-0x10]
    // 0x5a3bf8: cmp             w0, NULL
    // 0x5a3bfc: b.ne            #0x5a3c0c
    // 0x5a3c00: mov             x0, x2
    // 0x5a3c04: r1 = Null
    //     0x5a3c04: mov             x1, NULL
    // 0x5a3c08: b               #0x5a3c28
    // 0x5a3c0c: ldur            x0, [fp, #-0x18]
    // 0x5a3c10: LoadField: r1 = r0->field_13
    //     0x5a3c10: ldur            w1, [x0, #0x13]
    // 0x5a3c14: DecompressPointer r1
    //     0x5a3c14: add             x1, x1, HEAP, lsl #32
    // 0x5a3c18: r0 = of()
    //     0x5a3c18: bl              #0x438c0c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x5a3c1c: LoadField: r1 = r0->field_5b
    //     0x5a3c1c: ldur            w1, [x0, #0x5b]
    // 0x5a3c20: DecompressPointer r1
    //     0x5a3c20: add             x1, x1, HEAP, lsl #32
    // 0x5a3c24: ldur            x0, [fp, #-0x10]
    // 0x5a3c28: stur            x1, [fp, #-8]
    // 0x5a3c2c: r0 = TextStyle()
    //     0x5a3c2c: bl              #0x43c070  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x5a3c30: mov             x1, x0
    // 0x5a3c34: r0 = true
    //     0x5a3c34: add             x0, NULL, #0x20  ; true
    // 0x5a3c38: stur            x1, [fp, #-0x20]
    // 0x5a3c3c: StoreField: r1->field_7 = r0
    //     0x5a3c3c: stur            w0, [x1, #7]
    // 0x5a3c40: r2 = Instance_TextDecoration
    //     0x5a3c40: add             x2, PP, #0x32, lsl #12  ; [pp+0x32078] Obj!TextDecoration@834cb1
    //     0x5a3c44: ldr             x2, [x2, #0x78]
    // 0x5a3c48: StoreField: r1->field_4b = r2
    //     0x5a3c48: stur            w2, [x1, #0x4b]
    // 0x5a3c4c: ldur            x2, [fp, #-8]
    // 0x5a3c50: StoreField: r1->field_4f = r2
    //     0x5a3c50: stur            w2, [x1, #0x4f]
    // 0x5a3c54: r0 = Text()
    //     0x5a3c54: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x5a3c58: mov             x1, x0
    // 0x5a3c5c: r0 = "Auto"
    //     0x5a3c5c: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b8] "Auto"
    //     0x5a3c60: ldr             x0, [x0, #0x6b8]
    // 0x5a3c64: stur            x1, [fp, #-8]
    // 0x5a3c68: StoreField: r1->field_b = r0
    //     0x5a3c68: stur            w0, [x1, #0xb]
    // 0x5a3c6c: ldur            x0, [fp, #-0x20]
    // 0x5a3c70: StoreField: r1->field_13 = r0
    //     0x5a3c70: stur            w0, [x1, #0x13]
    // 0x5a3c74: r0 = OutlinedButton()
    //     0x5a3c74: bl              #0x5a427c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x44)
    // 0x5a3c78: mov             x1, x0
    // 0x5a3c7c: r0 = false
    //     0x5a3c7c: add             x0, NULL, #0x30  ; false
    // 0x5a3c80: stur            x1, [fp, #-0x20]
    // 0x5a3c84: StoreField: r1->field_3f = r0
    //     0x5a3c84: stur            w0, [x1, #0x3f]
    // 0x5a3c88: ldur            x2, [fp, #-0x10]
    // 0x5a3c8c: StoreField: r1->field_b = r2
    //     0x5a3c8c: stur            w2, [x1, #0xb]
    // 0x5a3c90: StoreField: r1->field_27 = r0
    //     0x5a3c90: stur            w0, [x1, #0x27]
    // 0x5a3c94: r0 = true
    //     0x5a3c94: add             x0, NULL, #0x20  ; true
    // 0x5a3c98: StoreField: r1->field_2f = r0
    //     0x5a3c98: stur            w0, [x1, #0x2f]
    // 0x5a3c9c: ldur            x0, [fp, #-8]
    // 0x5a3ca0: StoreField: r1->field_3b = r0
    //     0x5a3ca0: stur            w0, [x1, #0x3b]
    // 0x5a3ca4: r0 = GestureDetector()
    //     0x5a3ca4: bl              #0x5a4268  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x5a3ca8: ldur            x2, [fp, #-0x18]
    // 0x5a3cac: r1 = Function '<anonymous closure>':.
    //     0x5a3cac: add             x1, PP, #0x32, lsl #12  ; [pp+0x32080] AnonymousClosure: (0x5a4288), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] AutoButtonState::build (0x5a3950)
    //     0x5a3cb0: ldr             x1, [x1, #0x80]
    // 0x5a3cb4: stur            x0, [fp, #-8]
    // 0x5a3cb8: r0 = AllocateClosure()
    //     0x5a3cb8: bl              #0x826750  ; AllocateClosureStub
    // 0x5a3cbc: ldur            x16, [fp, #-0x20]
    // 0x5a3cc0: stp             x16, x0, [SP]
    // 0x5a3cc4: ldur            x1, [fp, #-8]
    // 0x5a3cc8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onLongPress, 0x1, null]
    //     0x5a3cc8: add             x4, PP, #0x32, lsl #12  ; [pp+0x32088] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onLongPress", 0x1, Null]
    //     0x5a3ccc: ldr             x4, [x4, #0x88]
    // 0x5a3cd0: r0 = GestureDetector()
    //     0x5a3cd0: bl              #0x5a3d1c  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x5a3cd4: r0 = Padding()
    //     0x5a3cd4: bl              #0x58c128  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x5a3cd8: r1 = Instance_EdgeInsets
    //     0x5a3cd8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32090] Obj!EdgeInsets@831e91
    //     0x5a3cdc: ldr             x1, [x1, #0x90]
    // 0x5a3ce0: StoreField: r0->field_f = r1
    //     0x5a3ce0: stur            w1, [x0, #0xf]
    // 0x5a3ce4: ldur            x1, [fp, #-8]
    // 0x5a3ce8: StoreField: r0->field_b = r1
    //     0x5a3ce8: stur            w1, [x0, #0xb]
    // 0x5a3cec: LeaveFrame
    //     0x5a3cec: mov             SP, fp
    //     0x5a3cf0: ldp             fp, lr, [SP], #0x10
    // 0x5a3cf4: ret
    //     0x5a3cf4: ret             
    // 0x5a3cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a3cf8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a3cfc: b               #0x5a3970
    // 0x5a3d00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a3d00: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a3d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a3d04: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a3d08: b               #0x5a39e8
    // 0x5a3d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a3d0c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a3d10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a3d10: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a3d14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a3d14: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a3d18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a3d18: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x5a4288, size: 0x8c
    // 0x5a4288: EnterFrame
    //     0x5a4288: stp             fp, lr, [SP, #-0x10]!
    //     0x5a428c: mov             fp, SP
    // 0x5a4290: AllocStack(0x30)
    //     0x5a4290: sub             SP, SP, #0x30
    // 0x5a4294: SetupParameters(AutoButtonState<C1X0> this /* r1 */)
    //     0x5a4294: stur            NULL, [fp, #-8]
    //     0x5a4298: movz            x0, #0
    //     0x5a429c: add             x1, fp, w0, sxtw #2
    //     0x5a42a0: ldr             x1, [x1, #0x10]
    //     0x5a42a4: ldur            w2, [x1, #0x17]
    //     0x5a42a8: add             x2, x2, HEAP, lsl #32
    //     0x5a42ac: stur            x2, [fp, #-0x10]
    // 0x5a42b0: CheckStackOverflow
    //     0x5a42b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a42b4: cmp             SP, x16
    //     0x5a42b8: b.ls            #0x5a430c
    // 0x5a42bc: InitAsync() -> Future<void?>
    //     0x5a42bc: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x5a42c0: bl              #0x34b9a0  ; InitAsyncStub
    // 0x5a42c4: ldur            x2, [fp, #-0x10]
    // 0x5a42c8: LoadField: r0 = r2->field_13
    //     0x5a42c8: ldur            w0, [x2, #0x13]
    // 0x5a42cc: DecompressPointer r0
    //     0x5a42cc: add             x0, x0, HEAP, lsl #32
    // 0x5a42d0: stur            x0, [fp, #-0x18]
    // 0x5a42d4: LoadField: r1 = r2->field_f
    //     0x5a42d4: ldur            w1, [x2, #0xf]
    // 0x5a42d8: DecompressPointer r1
    //     0x5a42d8: add             x1, x1, HEAP, lsl #32
    // 0x5a42dc: LoadField: r3 = r1->field_7
    //     0x5a42dc: ldur            w3, [x1, #7]
    // 0x5a42e0: DecompressPointer r3
    //     0x5a42e0: add             x3, x3, HEAP, lsl #32
    // 0x5a42e4: r1 = Function '<anonymous closure>':.
    //     0x5a42e4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32098] AnonymousClosure: (0x5a4314), in [package:pretentious/widgets/ProgressBars/GeneratorGroup.dart] AutoButtonState::build (0x5a3950)
    //     0x5a42e8: ldr             x1, [x1, #0x98]
    // 0x5a42ec: r0 = AllocateClosureTA()
    //     0x5a42ec: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x5a42f0: r16 = <void?>
    //     0x5a42f0: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x5a42f4: stp             x0, x16, [SP, #8]
    // 0x5a42f8: ldur            x16, [fp, #-0x18]
    // 0x5a42fc: str             x16, [SP]
    // 0x5a4300: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a4300: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a4304: r0 = showDialog()
    //     0x5a4304: bl              #0x3ecee0  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x5a4308: r0 = ReturnAsync()
    //     0x5a4308: b               #0x353380  ; ReturnAsyncStub
    // 0x5a430c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a430c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a4310: b               #0x5a42bc
  }
  [closure] AutoDialog<C1X0> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x5a4314, size: 0x134
    // 0x5a4314: EnterFrame
    //     0x5a4314: stp             fp, lr, [SP, #-0x10]!
    //     0x5a4318: mov             fp, SP
    // 0x5a431c: AllocStack(0x48)
    //     0x5a431c: sub             SP, SP, #0x48
    // 0x5a4320: SetupParameters([dynamic _ /* r0 */])
    //     0x5a4320: ldr             x0, [fp, #0x18]
    //     0x5a4324: ldur            w1, [x0, #0x17]
    //     0x5a4328: add             x1, x1, HEAP, lsl #32
    // 0x5a432c: LoadField: r0 = r1->field_f
    //     0x5a432c: ldur            w0, [x1, #0xf]
    // 0x5a4330: DecompressPointer r0
    //     0x5a4330: add             x0, x0, HEAP, lsl #32
    // 0x5a4334: LoadField: r3 = r0->field_b
    //     0x5a4334: ldur            w3, [x0, #0xb]
    // 0x5a4338: DecompressPointer r3
    //     0x5a4338: add             x3, x3, HEAP, lsl #32
    // 0x5a433c: stur            x3, [fp, #-0x20]
    // 0x5a4340: cmp             w3, NULL
    // 0x5a4344: b.eq            #0x5a4444
    // 0x5a4348: LoadField: r4 = r3->field_f
    //     0x5a4348: ldur            w4, [x3, #0xf]
    // 0x5a434c: DecompressPointer r4
    //     0x5a434c: add             x4, x4, HEAP, lsl #32
    // 0x5a4350: stur            x4, [fp, #-0x18]
    // 0x5a4354: LoadField: r5 = r3->field_13
    //     0x5a4354: ldur            w5, [x3, #0x13]
    // 0x5a4358: DecompressPointer r5
    //     0x5a4358: add             x5, x5, HEAP, lsl #32
    // 0x5a435c: stur            x5, [fp, #-0x10]
    // 0x5a4360: LoadField: r6 = r0->field_7
    //     0x5a4360: ldur            w6, [x0, #7]
    // 0x5a4364: DecompressPointer r6
    //     0x5a4364: add             x6, x6, HEAP, lsl #32
    // 0x5a4368: mov             x0, x5
    // 0x5a436c: mov             x2, x6
    // 0x5a4370: stur            x6, [fp, #-8]
    // 0x5a4374: r1 = Null
    //     0x5a4374: mov             x1, NULL
    // 0x5a4378: r8 = (dynamic this, C1X0?) => String?
    //     0x5a4378: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c638] FunctionType: (dynamic this, C1X0?) => String?
    //     0x5a437c: ldr             x8, [x8, #0x638]
    // 0x5a4380: LoadField: r9 = r8->field_7
    //     0x5a4380: ldur            x9, [x8, #7]
    // 0x5a4384: r3 = Null
    //     0x5a4384: add             x3, PP, #0x32, lsl #12  ; [pp+0x320a0] Null
    //     0x5a4388: ldr             x3, [x3, #0xa0]
    // 0x5a438c: blr             x9
    // 0x5a4390: ldur            x0, [fp, #-0x20]
    // 0x5a4394: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x5a4394: ldur            w4, [x0, #0x17]
    // 0x5a4398: DecompressPointer r4
    //     0x5a4398: add             x4, x4, HEAP, lsl #32
    // 0x5a439c: stur            x4, [fp, #-0x48]
    // 0x5a43a0: LoadField: r5 = r0->field_1b
    //     0x5a43a0: ldur            w5, [x0, #0x1b]
    // 0x5a43a4: DecompressPointer r5
    //     0x5a43a4: add             x5, x5, HEAP, lsl #32
    // 0x5a43a8: stur            x5, [fp, #-0x40]
    // 0x5a43ac: LoadField: r6 = r0->field_1f
    //     0x5a43ac: ldur            w6, [x0, #0x1f]
    // 0x5a43b0: DecompressPointer r6
    //     0x5a43b0: add             x6, x6, HEAP, lsl #32
    // 0x5a43b4: stur            x6, [fp, #-0x38]
    // 0x5a43b8: LoadField: r7 = r0->field_23
    //     0x5a43b8: ldur            w7, [x0, #0x23]
    // 0x5a43bc: DecompressPointer r7
    //     0x5a43bc: add             x7, x7, HEAP, lsl #32
    // 0x5a43c0: stur            x7, [fp, #-0x30]
    // 0x5a43c4: LoadField: r8 = r0->field_27
    //     0x5a43c4: ldur            w8, [x0, #0x27]
    // 0x5a43c8: DecompressPointer r8
    //     0x5a43c8: add             x8, x8, HEAP, lsl #32
    // 0x5a43cc: ldur            x2, [fp, #-8]
    // 0x5a43d0: stur            x8, [fp, #-0x28]
    // 0x5a43d4: r1 = Null
    //     0x5a43d4: mov             x1, NULL
    // 0x5a43d8: r3 = <C1X0>
    //     0x5a43d8: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a43dc: ldr             x3, [x3, #0xe38]
    // 0x5a43e0: r0 = Null
    //     0x5a43e0: mov             x0, NULL
    // 0x5a43e4: cmp             x2, x0
    // 0x5a43e8: b.eq            #0x5a43f8
    // 0x5a43ec: r30 = InstantiateTypeArgumentsStub
    //     0x5a43ec: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a43f0: LoadField: r30 = r30->field_7
    //     0x5a43f0: ldur            lr, [lr, #7]
    // 0x5a43f4: blr             lr
    // 0x5a43f8: mov             x1, x0
    // 0x5a43fc: r0 = AutoDialog()
    //     0x5a43fc: bl              #0x5a4448  ; AllocateAutoDialogStub -> AutoDialog<X0> (size=0x2c)
    // 0x5a4400: ldur            x1, [fp, #-0x40]
    // 0x5a4404: ArrayStore: r0[0] = r1  ; List_4
    //     0x5a4404: stur            w1, [x0, #0x17]
    // 0x5a4408: ldur            x1, [fp, #-0x38]
    // 0x5a440c: StoreField: r0->field_1b = r1
    //     0x5a440c: stur            w1, [x0, #0x1b]
    // 0x5a4410: ldur            x1, [fp, #-0x30]
    // 0x5a4414: StoreField: r0->field_1f = r1
    //     0x5a4414: stur            w1, [x0, #0x1f]
    // 0x5a4418: ldur            x1, [fp, #-0x28]
    // 0x5a441c: StoreField: r0->field_23 = r1
    //     0x5a441c: stur            w1, [x0, #0x23]
    // 0x5a4420: ldur            x1, [fp, #-0x48]
    // 0x5a4424: StoreField: r0->field_13 = r1
    //     0x5a4424: stur            w1, [x0, #0x13]
    // 0x5a4428: ldur            x1, [fp, #-0x10]
    // 0x5a442c: StoreField: r0->field_27 = r1
    //     0x5a442c: stur            w1, [x0, #0x27]
    // 0x5a4430: ldur            x1, [fp, #-0x18]
    // 0x5a4434: StoreField: r0->field_f = r1
    //     0x5a4434: stur            w1, [x0, #0xf]
    // 0x5a4438: LeaveFrame
    //     0x5a4438: mov             SP, fp
    //     0x5a443c: ldp             fp, lr, [SP], #0x10
    // 0x5a4440: ret
    //     0x5a4440: ret             
    // 0x5a4444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4444: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5a4454, size: 0x24c
    // 0x5a4454: EnterFrame
    //     0x5a4454: stp             fp, lr, [SP, #-0x10]!
    //     0x5a4458: mov             fp, SP
    // 0x5a445c: AllocStack(0x30)
    //     0x5a445c: sub             SP, SP, #0x30
    // 0x5a4460: SetupParameters([dynamic _ /* r0 */])
    //     0x5a4460: ldr             x0, [fp, #0x10]
    //     0x5a4464: ldur            w1, [x0, #0x17]
    //     0x5a4468: add             x1, x1, HEAP, lsl #32
    //     0x5a446c: stur            x1, [fp, #-8]
    // 0x5a4470: CheckStackOverflow
    //     0x5a4470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a4474: cmp             SP, x16
    //     0x5a4478: b.ls            #0x5a467c
    // 0x5a447c: LoadField: r0 = r1->field_f
    //     0x5a447c: ldur            w0, [x1, #0xf]
    // 0x5a4480: DecompressPointer r0
    //     0x5a4480: add             x0, x0, HEAP, lsl #32
    // 0x5a4484: LoadField: r2 = r0->field_b
    //     0x5a4484: ldur            w2, [x0, #0xb]
    // 0x5a4488: DecompressPointer r2
    //     0x5a4488: add             x2, x2, HEAP, lsl #32
    // 0x5a448c: cmp             w2, NULL
    // 0x5a4490: b.eq            #0x5a4684
    // 0x5a4494: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x5a4494: ldur            w0, [x2, #0x17]
    // 0x5a4498: DecompressPointer r0
    //     0x5a4498: add             x0, x0, HEAP, lsl #32
    // 0x5a449c: cmp             w0, NULL
    // 0x5a44a0: b.eq            #0x5a44b4
    // 0x5a44a4: str             x0, [SP]
    // 0x5a44a8: ClosureCall
    //     0x5a44a8: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5a44ac: ldur            x2, [x0, #0x1f]
    //     0x5a44b0: blr             x2
    // 0x5a44b4: ldur            x1, [fp, #-8]
    // 0x5a44b8: LoadField: r0 = r1->field_f
    //     0x5a44b8: ldur            w0, [x1, #0xf]
    // 0x5a44bc: DecompressPointer r0
    //     0x5a44bc: add             x0, x0, HEAP, lsl #32
    // 0x5a44c0: LoadField: r2 = r0->field_b
    //     0x5a44c0: ldur            w2, [x0, #0xb]
    // 0x5a44c4: DecompressPointer r2
    //     0x5a44c4: add             x2, x2, HEAP, lsl #32
    // 0x5a44c8: cmp             w2, NULL
    // 0x5a44cc: b.eq            #0x5a4688
    // 0x5a44d0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x5a44d0: ldur            w0, [x1, #0x17]
    // 0x5a44d4: DecompressPointer r0
    //     0x5a44d4: add             x0, x0, HEAP, lsl #32
    // 0x5a44d8: cmp             w0, NULL
    // 0x5a44dc: b.eq            #0x5a468c
    // 0x5a44e0: LoadField: r3 = r2->field_23
    //     0x5a44e0: ldur            w3, [x2, #0x23]
    // 0x5a44e4: DecompressPointer r3
    //     0x5a44e4: add             x3, x3, HEAP, lsl #32
    // 0x5a44e8: stp             x0, x3, [SP]
    // 0x5a44ec: mov             x0, x3
    // 0x5a44f0: ClosureCall
    //     0x5a44f0: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5a44f4: ldur            x2, [x0, #0x1f]
    //     0x5a44f8: blr             x2
    // 0x5a44fc: LoadField: r4 = r0->field_2b
    //     0x5a44fc: ldur            w4, [x0, #0x2b]
    // 0x5a4500: DecompressPointer r4
    //     0x5a4500: add             x4, x4, HEAP, lsl #32
    // 0x5a4504: stur            x4, [fp, #-0x18]
    // 0x5a4508: cmp             w4, NULL
    // 0x5a450c: b.eq            #0x5a4690
    // 0x5a4510: ldur            x0, [fp, #-8]
    // 0x5a4514: LoadField: r5 = r0->field_f
    //     0x5a4514: ldur            w5, [x0, #0xf]
    // 0x5a4518: DecompressPointer r5
    //     0x5a4518: add             x5, x5, HEAP, lsl #32
    // 0x5a451c: stur            x5, [fp, #-0x10]
    // 0x5a4520: LoadField: r2 = r5->field_7
    //     0x5a4520: ldur            w2, [x5, #7]
    // 0x5a4524: DecompressPointer r2
    //     0x5a4524: add             x2, x2, HEAP, lsl #32
    // 0x5a4528: r1 = Null
    //     0x5a4528: mov             x1, NULL
    // 0x5a452c: r3 = <C1X0>
    //     0x5a452c: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a4530: ldr             x3, [x3, #0xe38]
    // 0x5a4534: r0 = Null
    //     0x5a4534: mov             x0, NULL
    // 0x5a4538: cmp             x2, x0
    // 0x5a453c: b.eq            #0x5a454c
    // 0x5a4540: r30 = InstantiateTypeArgumentsStub
    //     0x5a4540: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a4544: LoadField: r30 = r30->field_7
    //     0x5a4544: ldur            lr, [lr, #7]
    // 0x5a4548: blr             lr
    // 0x5a454c: mov             x1, x0
    // 0x5a4550: ldur            x0, [fp, #-0x10]
    // 0x5a4554: LoadField: r2 = r0->field_b
    //     0x5a4554: ldur            w2, [x0, #0xb]
    // 0x5a4558: DecompressPointer r2
    //     0x5a4558: add             x2, x2, HEAP, lsl #32
    // 0x5a455c: cmp             w2, NULL
    // 0x5a4560: b.eq            #0x5a4694
    // 0x5a4564: LoadField: r0 = r2->field_1b
    //     0x5a4564: ldur            w0, [x2, #0x1b]
    // 0x5a4568: DecompressPointer r0
    //     0x5a4568: add             x0, x0, HEAP, lsl #32
    // 0x5a456c: stp             x0, x1, [SP, #8]
    // 0x5a4570: ldur            x16, [fp, #-0x18]
    // 0x5a4574: str             x16, [SP]
    // 0x5a4578: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a4578: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a457c: r0 = MapOperations.isSupersetOfTuple()
    //     0x5a457c: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x5a4580: tbz             w0, #4, #0x5a4594
    // 0x5a4584: r0 = Null
    //     0x5a4584: mov             x0, NULL
    // 0x5a4588: LeaveFrame
    //     0x5a4588: mov             SP, fp
    //     0x5a458c: ldp             fp, lr, [SP], #0x10
    // 0x5a4590: ret
    //     0x5a4590: ret             
    // 0x5a4594: ldur            x0, [fp, #-8]
    // 0x5a4598: LoadField: r1 = r0->field_f
    //     0x5a4598: ldur            w1, [x0, #0xf]
    // 0x5a459c: DecompressPointer r1
    //     0x5a459c: add             x1, x1, HEAP, lsl #32
    // 0x5a45a0: LoadField: r2 = r1->field_b
    //     0x5a45a0: ldur            w2, [x1, #0xb]
    // 0x5a45a4: DecompressPointer r2
    //     0x5a45a4: add             x2, x2, HEAP, lsl #32
    // 0x5a45a8: cmp             w2, NULL
    // 0x5a45ac: b.eq            #0x5a4698
    // 0x5a45b0: LoadField: r1 = r2->field_27
    //     0x5a45b0: ldur            w1, [x2, #0x27]
    // 0x5a45b4: DecompressPointer r1
    //     0x5a45b4: add             x1, x1, HEAP, lsl #32
    // 0x5a45b8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x5a45b8: ldur            w2, [x0, #0x17]
    // 0x5a45bc: DecompressPointer r2
    //     0x5a45bc: add             x2, x2, HEAP, lsl #32
    // 0x5a45c0: r0 = add()
    //     0x5a45c0: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x5a45c4: ldur            x0, [fp, #-8]
    // 0x5a45c8: LoadField: r4 = r0->field_f
    //     0x5a45c8: ldur            w4, [x0, #0xf]
    // 0x5a45cc: DecompressPointer r4
    //     0x5a45cc: add             x4, x4, HEAP, lsl #32
    // 0x5a45d0: stur            x4, [fp, #-0x10]
    // 0x5a45d4: LoadField: r2 = r4->field_7
    //     0x5a45d4: ldur            w2, [x4, #7]
    // 0x5a45d8: DecompressPointer r2
    //     0x5a45d8: add             x2, x2, HEAP, lsl #32
    // 0x5a45dc: r1 = Null
    //     0x5a45dc: mov             x1, NULL
    // 0x5a45e0: r3 = <C1X0>
    //     0x5a45e0: add             x3, PP, #0xa, lsl #12  ; [pp+0xae38] TypeArguments: <C1X0>
    //     0x5a45e4: ldr             x3, [x3, #0xe38]
    // 0x5a45e8: r0 = Null
    //     0x5a45e8: mov             x0, NULL
    // 0x5a45ec: cmp             x2, x0
    // 0x5a45f0: b.eq            #0x5a4600
    // 0x5a45f4: r30 = InstantiateTypeArgumentsStub
    //     0x5a45f4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x5a45f8: LoadField: r30 = r30->field_7
    //     0x5a45f8: ldur            lr, [lr, #7]
    // 0x5a45fc: blr             lr
    // 0x5a4600: mov             x1, x0
    // 0x5a4604: ldur            x0, [fp, #-0x10]
    // 0x5a4608: LoadField: r2 = r0->field_b
    //     0x5a4608: ldur            w2, [x0, #0xb]
    // 0x5a460c: DecompressPointer r2
    //     0x5a460c: add             x2, x2, HEAP, lsl #32
    // 0x5a4610: cmp             w2, NULL
    // 0x5a4614: b.eq            #0x5a469c
    // 0x5a4618: LoadField: r0 = r2->field_1b
    //     0x5a4618: ldur            w0, [x2, #0x1b]
    // 0x5a461c: DecompressPointer r0
    //     0x5a461c: add             x0, x0, HEAP, lsl #32
    // 0x5a4620: stp             x0, x1, [SP, #8]
    // 0x5a4624: ldur            x16, [fp, #-0x18]
    // 0x5a4628: str             x16, [SP]
    // 0x5a462c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a462c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a4630: r0 = MapOperations.subtractTuple()
    //     0x5a4630: bl              #0x539e38  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.subtractTuple
    // 0x5a4634: r0 = currentActiveState()
    //     0x5a4634: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x5a4638: mov             x1, x0
    // 0x5a463c: r0 = saveDeferred()
    //     0x5a463c: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x5a4640: r0 = LoadStaticField(0xfb4)
    //     0x5a4640: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a4644: ldr             x0, [x0, #0x1f68]
    // 0x5a4648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a464c: cmp             w0, w16
    // 0x5a4650: b.ne            #0x5a4660
    // 0x5a4654: r2 = generatorStateGroup
    //     0x5a4654: add             x2, PP, #0x15, lsl #12  ; [pp+0x15138] Field <::.generatorStateGroup>: static late (offset: 0xfb4)
    //     0x5a4658: ldr             x2, [x2, #0x138]
    // 0x5a465c: r0 = InitLateStaticField()
    //     0x5a465c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a4660: mov             x1, x0
    // 0x5a4664: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5a4664: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5a4668: r0 = notifyAll()
    //     0x5a4668: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x5a466c: r0 = Null
    //     0x5a466c: mov             x0, NULL
    // 0x5a4670: LeaveFrame
    //     0x5a4670: mov             SP, fp
    //     0x5a4674: ldp             fp, lr, [SP], #0x10
    // 0x5a4678: ret
    //     0x5a4678: ret             
    // 0x5a467c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a467c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a4680: b               #0x5a447c
    // 0x5a4684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4684: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4688: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a468c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a468c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4690: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4694: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a4698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a4698: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5a469c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a469c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4161, size: 0x14, field offset: 0x14
enum BuyOption extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724fec, size: 0x64
    // 0x724fec: EnterFrame
    //     0x724fec: stp             fp, lr, [SP, #-0x10]!
    //     0x724ff0: mov             fp, SP
    // 0x724ff4: AllocStack(0x10)
    //     0x724ff4: sub             SP, SP, #0x10
    // 0x724ff8: SetupParameters(BuyOption this /* r1 => r0, fp-0x8 */)
    //     0x724ff8: mov             x0, x1
    //     0x724ffc: stur            x1, [fp, #-8]
    // 0x725000: CheckStackOverflow
    //     0x725000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x725004: cmp             SP, x16
    //     0x725008: b.ls            #0x725048
    // 0x72500c: r1 = Null
    //     0x72500c: mov             x1, NULL
    // 0x725010: r2 = 4
    //     0x725010: movz            x2, #0x4
    // 0x725014: r0 = AllocateArray()
    //     0x725014: bl              #0x82746c  ; AllocateArrayStub
    // 0x725018: r16 = "BuyOption."
    //     0x725018: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a5c0] "BuyOption."
    //     0x72501c: ldr             x16, [x16, #0x5c0]
    // 0x725020: StoreField: r0->field_f = r16
    //     0x725020: stur            w16, [x0, #0xf]
    // 0x725024: ldur            x1, [fp, #-8]
    // 0x725028: LoadField: r2 = r1->field_f
    //     0x725028: ldur            w2, [x1, #0xf]
    // 0x72502c: DecompressPointer r2
    //     0x72502c: add             x2, x2, HEAP, lsl #32
    // 0x725030: StoreField: r0->field_13 = r2
    //     0x725030: stur            w2, [x0, #0x13]
    // 0x725034: str             x0, [SP]
    // 0x725038: r0 = _interpolate()
    //     0x725038: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x72503c: LeaveFrame
    //     0x72503c: mov             SP, fp
    //     0x725040: ldp             fp, lr, [SP], #0x10
    // 0x725044: ret
    //     0x725044: ret             
    // 0x725048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x725048: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72504c: b               #0x72500c
  }
}
