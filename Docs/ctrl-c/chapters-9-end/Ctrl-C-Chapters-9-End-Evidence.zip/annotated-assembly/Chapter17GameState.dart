// lib: , url: package:pretentious/data/Chapters/Chapter17GameState.dart

// class id: 1049454, size: 0x8
class :: {
}

// class id: 278, size: 0x90, field offset: 0x8c
class Chapter17GameState extends IPlayableGameState<dynamic> {

  late Map<int, GeneratorInfo<Chapter17Stat>> generators; // offset: 0x8c

  _ Chapter17GameState(/* No info */) {
    // ** addr: 0x46ace8, size: 0xb0
    // 0x46ace8: EnterFrame
    //     0x46ace8: stp             fp, lr, [SP, #-0x10]!
    //     0x46acec: mov             fp, SP
    // 0x46acf0: AllocStack(0x28)
    //     0x46acf0: sub             SP, SP, #0x28
    // 0x46acf4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x46acf8: mov             x4, x1
    // 0x46acfc: mov             x3, x2
    // 0x46ad00: stur            x1, [fp, #-8]
    // 0x46ad04: stur            x2, [fp, #-0x10]
    // 0x46ad08: CheckStackOverflow
    //     0x46ad08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x46ad0c: cmp             SP, x16
    //     0x46ad10: b.ls            #0x46ad90
    // 0x46ad14: StoreField: r4->field_8b = r0
    //     0x46ad14: stur            w0, [x4, #0x8b]
    // 0x46ad18: r1 = Function '<anonymous closure>':.
    //     0x46ad18: add             x1, PP, #0x10, lsl #12  ; [pp+0x10f68] AnonymousClosure: (0x46ae2c), in [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::Chapter17GameState (0x46ace8)
    //     0x46ad1c: ldr             x1, [x1, #0xf68]
    // 0x46ad20: r2 = Null
    //     0x46ad20: mov             x2, NULL
    // 0x46ad24: r0 = AllocateClosure()
    //     0x46ad24: bl              #0x826750  ; AllocateClosureStub
    // 0x46ad28: r1 = Function '<anonymous closure>':.
    //     0x46ad28: add             x1, PP, #0x10, lsl #12  ; [pp+0x10f70] AnonymousClosure: (0x46ae04), in [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::Chapter17GameState (0x46ace8)
    //     0x46ad2c: ldr             x1, [x1, #0xf70]
    // 0x46ad30: r2 = Null
    //     0x46ad30: mov             x2, NULL
    // 0x46ad34: stur            x0, [fp, #-0x18]
    // 0x46ad38: r0 = AllocateClosure()
    //     0x46ad38: bl              #0x826750  ; AllocateClosureStub
    // 0x46ad3c: r1 = Function '<anonymous closure>':.
    //     0x46ad3c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10f78] AnonymousClosure: (0x46addc), in [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::Chapter17GameState (0x46ace8)
    //     0x46ad40: ldr             x1, [x1, #0xf78]
    // 0x46ad44: r2 = Null
    //     0x46ad44: mov             x2, NULL
    // 0x46ad48: stur            x0, [fp, #-0x20]
    // 0x46ad4c: r0 = AllocateClosure()
    //     0x46ad4c: bl              #0x826750  ; AllocateClosureStub
    // 0x46ad50: r1 = Function '<anonymous closure>':.
    //     0x46ad50: add             x1, PP, #0x10, lsl #12  ; [pp+0x10f80] Function: [package:flutter/src/widgets/icon_data.dart] IconData::codePoint (0x6da134)
    //     0x46ad54: ldr             x1, [x1, #0xf80]
    // 0x46ad58: r2 = Null
    //     0x46ad58: mov             x2, NULL
    // 0x46ad5c: stur            x0, [fp, #-0x28]
    // 0x46ad60: r0 = AllocateClosure()
    //     0x46ad60: bl              #0x826750  ; AllocateClosureStub
    // 0x46ad64: ldur            x1, [fp, #-8]
    // 0x46ad68: ldur            x2, [fp, #-0x10]
    // 0x46ad6c: ldur            x3, [fp, #-0x18]
    // 0x46ad70: ldur            x5, [fp, #-0x20]
    // 0x46ad74: ldur            x6, [fp, #-0x28]
    // 0x46ad78: mov             x7, x0
    // 0x46ad7c: r0 = IPlayableGameState()
    //     0x46ad7c: bl              #0x45f64c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::IPlayableGameState
    // 0x46ad80: r0 = Null
    //     0x46ad80: mov             x0, NULL
    // 0x46ad84: LeaveFrame
    //     0x46ad84: mov             SP, fp
    //     0x46ad88: ldp             fp, lr, [SP], #0x10
    // 0x46ad8c: ret
    //     0x46ad8c: ret             
    // 0x46ad90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x46ad90: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x46ad94: b               #0x46ad14
  }
  [closure] String <anonymous closure>(dynamic, Chapter17Stat) {
    // ** addr: 0x46addc, size: 0x28
    // 0x46addc: ldr             x1, [SP]
    // 0x46ade0: r16 = Instance_Chapter17Stat
    //     0x46ade0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10f88] Obj!Chapter17Stat@85f6a1
    //     0x46ade4: ldr             x16, [x16, #0xf88]
    // 0x46ade8: cmp             w1, w16
    // 0x46adec: b.ne            #0x46adfc
    // 0x46adf0: r0 = "Contributions"
    //     0x46adf0: add             x0, PP, #0x10, lsl #12  ; [pp+0x10f90] "Contributions"
    //     0x46adf4: ldr             x0, [x0, #0xf90]
    // 0x46adf8: b               #0x46ae00
    // 0x46adfc: r0 = Null
    //     0x46adfc: mov             x0, NULL
    // 0x46ae00: ret
    //     0x46ae00: ret             
  }
  [closure] String <anonymous closure>(dynamic, Chapter17Stat) {
    // ** addr: 0x46ae04, size: 0x28
    // 0x46ae04: ldr             x1, [SP]
    // 0x46ae08: r16 = Instance_Chapter17Stat
    //     0x46ae08: add             x16, PP, #0x10, lsl #12  ; [pp+0x10f88] Obj!Chapter17Stat@85f6a1
    //     0x46ae0c: ldr             x16, [x16, #0xf88]
    // 0x46ae10: cmp             w1, w16
    // 0x46ae14: b.ne            #0x46ae24
    // 0x46ae18: r0 = "Contr"
    //     0x46ae18: add             x0, PP, #0x10, lsl #12  ; [pp+0x10f98] "Contr"
    //     0x46ae1c: ldr             x0, [x0, #0xf98]
    // 0x46ae20: b               #0x46ae28
    // 0x46ae24: r0 = Null
    //     0x46ae24: mov             x0, NULL
    // 0x46ae28: ret
    //     0x46ae28: ret             
  }
  [closure] Chapter17Stat <anonymous closure>(dynamic, int) {
    // ** addr: 0x46ae2c, size: 0x44
    // 0x46ae2c: r2 = const [Instance of 'Chapter17Stat']
    //     0x46ae2c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fa0] List<Chapter17Stat>(1)
    //     0x46ae30: ldr             x2, [x2, #0xfa0]
    // 0x46ae34: ldr             x3, [SP]
    // 0x46ae38: r4 = LoadInt32Instr(r3)
    //     0x46ae38: sbfx            x4, x3, #1, #0x1f
    //     0x46ae3c: tbz             w3, #0, #0x46ae44
    //     0x46ae40: ldur            x4, [x3, #7]
    // 0x46ae44: mov             x1, x4
    // 0x46ae48: r0 = 1
    //     0x46ae48: movz            x0, #0x1
    // 0x46ae4c: cmp             x1, x0
    // 0x46ae50: b.hs            #0x46ae64
    // 0x46ae54: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x46ae54: add             x16, x2, x4, lsl #2
    //     0x46ae58: ldur            w0, [x16, #0xf]
    // 0x46ae5c: DecompressPointer r0
    //     0x46ae5c: add             x0, x0, HEAP, lsl #32
    // 0x46ae60: ret
    //     0x46ae60: ret             
    // 0x46ae64: EnterFrame
    //     0x46ae64: stp             fp, lr, [SP, #-0x10]!
    //     0x46ae68: mov             fp, SP
    // 0x46ae6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x46ae6c: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ makeHeader(/* No info */) {
    // ** addr: 0x4e7530, size: 0x74
    // 0x4e7530: EnterFrame
    //     0x4e7530: stp             fp, lr, [SP, #-0x10]!
    //     0x4e7534: mov             fp, SP
    // 0x4e7538: AllocStack(0x10)
    //     0x4e7538: sub             SP, SP, #0x10
    // 0x4e753c: SetupParameters(Chapter17GameState this /* r1 => r1, fp-0x8 */)
    //     0x4e753c: stur            x1, [fp, #-8]
    // 0x4e7540: r1 = 1
    //     0x4e7540: movz            x1, #0x1
    // 0x4e7544: r0 = AllocateContext()
    //     0x4e7544: bl              #0x82637c  ; AllocateContextStub
    // 0x4e7548: mov             x1, x0
    // 0x4e754c: ldur            x0, [fp, #-8]
    // 0x4e7550: StoreField: r1->field_f = r0
    //     0x4e7550: stur            w0, [x1, #0xf]
    // 0x4e7554: mov             x2, x1
    // 0x4e7558: r1 = Function '<anonymous closure>':.
    //     0x4e7558: add             x1, PP, #0x25, lsl #12  ; [pp+0x256f8] AnonymousClosure: (0x4e75a4), in [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::makeHeader (0x4e7530)
    //     0x4e755c: ldr             x1, [x1, #0x6f8]
    // 0x4e7560: r0 = AllocateClosure()
    //     0x4e7560: bl              #0x826750  ; AllocateClosureStub
    // 0x4e7564: stur            x0, [fp, #-8]
    // 0x4e7568: r0 = MainStatDisplay()
    //     0x4e7568: bl              #0x4e5e04  ; AllocateMainStatDisplayStub -> MainStatDisplay (size=0x14)
    // 0x4e756c: mov             x3, x0
    // 0x4e7570: ldur            x0, [fp, #-8]
    // 0x4e7574: stur            x3, [fp, #-0x10]
    // 0x4e7578: StoreField: r3->field_b = r0
    //     0x4e7578: stur            w0, [x3, #0xb]
    // 0x4e757c: r1 = Function '<anonymous closure>':.
    //     0x4e757c: add             x1, PP, #0x25, lsl #12  ; [pp+0x25700] AnonymousClosure: (0x7b6794), in [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::makeHeader (0x4e78b8)
    //     0x4e7580: ldr             x1, [x1, #0x700]
    // 0x4e7584: r2 = Null
    //     0x4e7584: mov             x2, NULL
    // 0x4e7588: r0 = AllocateClosure()
    //     0x4e7588: bl              #0x826750  ; AllocateClosureStub
    // 0x4e758c: mov             x1, x0
    // 0x4e7590: ldur            x0, [fp, #-0x10]
    // 0x4e7594: StoreField: r0->field_f = r1
    //     0x4e7594: stur            w1, [x0, #0xf]
    // 0x4e7598: LeaveFrame
    //     0x4e7598: mov             SP, fp
    //     0x4e759c: ldp             fp, lr, [SP], #0x10
    // 0x4e75a0: ret
    //     0x4e75a0: ret             
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x4e75a4, size: 0xf4
    // 0x4e75a4: EnterFrame
    //     0x4e75a4: stp             fp, lr, [SP, #-0x10]!
    //     0x4e75a8: mov             fp, SP
    // 0x4e75ac: AllocStack(0x18)
    //     0x4e75ac: sub             SP, SP, #0x18
    // 0x4e75b0: SetupParameters([dynamic _ /* r0 */])
    //     0x4e75b0: ldr             x0, [fp, #0x10]
    //     0x4e75b4: ldur            w3, [x0, #0x17]
    //     0x4e75b8: add             x3, x3, HEAP, lsl #32
    //     0x4e75bc: stur            x3, [fp, #-8]
    // 0x4e75c0: CheckStackOverflow
    //     0x4e75c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e75c4: cmp             SP, x16
    //     0x4e75c8: b.ls            #0x4e7690
    // 0x4e75cc: r1 = Null
    //     0x4e75cc: mov             x1, NULL
    // 0x4e75d0: r2 = 4
    //     0x4e75d0: movz            x2, #0x4
    // 0x4e75d4: r0 = AllocateArray()
    //     0x4e75d4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e75d8: stur            x0, [fp, #-0x10]
    // 0x4e75dc: r16 = "Contributions: "
    //     0x4e75dc: add             x16, PP, #0x25, lsl #12  ; [pp+0x25708] "Contributions: "
    //     0x4e75e0: ldr             x16, [x16, #0x708]
    // 0x4e75e4: StoreField: r0->field_f = r16
    //     0x4e75e4: stur            w16, [x0, #0xf]
    // 0x4e75e8: ldur            x1, [fp, #-8]
    // 0x4e75ec: LoadField: r2 = r1->field_f
    //     0x4e75ec: ldur            w2, [x1, #0xf]
    // 0x4e75f0: DecompressPointer r2
    //     0x4e75f0: add             x2, x2, HEAP, lsl #32
    // 0x4e75f4: LoadField: r3 = r2->field_37
    //     0x4e75f4: ldur            w3, [x2, #0x37]
    // 0x4e75f8: DecompressPointer r3
    //     0x4e75f8: add             x3, x3, HEAP, lsl #32
    // 0x4e75fc: mov             x1, x3
    // 0x4e7600: stur            x3, [fp, #-8]
    // 0x4e7604: r2 = Instance_Chapter17Stat
    //     0x4e7604: add             x2, PP, #0x10, lsl #12  ; [pp+0x10f88] Obj!Chapter17Stat@85f6a1
    //     0x4e7608: ldr             x2, [x2, #0xf88]
    // 0x4e760c: r0 = _getValueOrData()
    //     0x4e760c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4e7610: mov             x1, x0
    // 0x4e7614: ldur            x0, [fp, #-8]
    // 0x4e7618: LoadField: r2 = r0->field_f
    //     0x4e7618: ldur            w2, [x0, #0xf]
    // 0x4e761c: DecompressPointer r2
    //     0x4e761c: add             x2, x2, HEAP, lsl #32
    // 0x4e7620: cmp             w2, w1
    // 0x4e7624: b.ne            #0x4e762c
    // 0x4e7628: r1 = Null
    //     0x4e7628: mov             x1, NULL
    // 0x4e762c: cmp             w1, NULL
    // 0x4e7630: b.ne            #0x4e763c
    // 0x4e7634: r0 = Null
    //     0x4e7634: mov             x0, NULL
    // 0x4e7638: b               #0x4e7644
    // 0x4e763c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4e763c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4e7640: r0 = toStringConsistentDecimalPlaces()
    //     0x4e7640: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x4e7644: cmp             w0, NULL
    // 0x4e7648: b.ne            #0x4e7650
    // 0x4e764c: r0 = 0
    //     0x4e764c: movz            x0, #0
    // 0x4e7650: ldur            x1, [fp, #-0x10]
    // 0x4e7654: ArrayStore: r1[1] = r0  ; List_4
    //     0x4e7654: add             x25, x1, #0x13
    //     0x4e7658: str             w0, [x25]
    //     0x4e765c: tbz             w0, #0, #0x4e7678
    //     0x4e7660: ldurb           w16, [x1, #-1]
    //     0x4e7664: ldurb           w17, [x0, #-1]
    //     0x4e7668: and             x16, x17, x16, lsr #2
    //     0x4e766c: tst             x16, HEAP, lsr #32
    //     0x4e7670: b.eq            #0x4e7678
    //     0x4e7674: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e7678: ldur            x16, [fp, #-0x10]
    // 0x4e767c: str             x16, [SP]
    // 0x4e7680: r0 = _interpolate()
    //     0x4e7680: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e7684: LeaveFrame
    //     0x4e7684: mov             SP, fp
    //     0x4e7688: ldp             fp, lr, [SP], #0x10
    // 0x4e768c: ret
    //     0x4e768c: ret             
    // 0x4e7690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e7690: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e7694: b               #0x4e75cc
  }
  _ ensureInitialized(/* No info */) {
    // ** addr: 0x4feb34, size: 0x7c
    // 0x4feb34: EnterFrame
    //     0x4feb34: stp             fp, lr, [SP, #-0x10]!
    //     0x4feb38: mov             fp, SP
    // 0x4feb3c: AllocStack(0x18)
    //     0x4feb3c: sub             SP, SP, #0x18
    // 0x4feb40: SetupParameters(Chapter17GameState this /* r1 => r1, fp-0x8 */)
    //     0x4feb40: stur            x1, [fp, #-8]
    // 0x4feb44: CheckStackOverflow
    //     0x4feb44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4feb48: cmp             SP, x16
    //     0x4feb4c: b.ls            #0x4feba8
    // 0x4feb50: r16 = <int, GeneratorInfo<Chapter17Stat>>
    //     0x4feb50: add             x16, PP, #0x15, lsl #12  ; [pp+0x15228] TypeArguments: <int, GeneratorInfo<Chapter17Stat>>
    //     0x4feb54: ldr             x16, [x16, #0x228]
    // 0x4feb58: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4feb5c: stp             lr, x16, [SP]
    // 0x4feb60: r0 = Map._fromLiteral()
    //     0x4feb60: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4feb64: ldur            x1, [fp, #-8]
    // 0x4feb68: StoreField: r1->field_8b = r0
    //     0x4feb68: stur            w0, [x1, #0x8b]
    //     0x4feb6c: ldurb           w16, [x1, #-1]
    //     0x4feb70: ldurb           w17, [x0, #-1]
    //     0x4feb74: and             x16, x17, x16, lsr #2
    //     0x4feb78: tst             x16, HEAP, lsr #32
    //     0x4feb7c: b.eq            #0x4feb84
    //     0x4feb80: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4feb84: r16 = <int, UpgradeData<Chapter17Stat>>
    //     0x4feb84: add             x16, PP, #0x15, lsl #12  ; [pp+0x15230] TypeArguments: <int, UpgradeData<Chapter17Stat>>
    //     0x4feb88: ldr             x16, [x16, #0x230]
    // 0x4feb8c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4feb90: stp             lr, x16, [SP]
    // 0x4feb94: r0 = Map._fromLiteral()
    //     0x4feb94: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4feb98: r0 = Null
    //     0x4feb98: mov             x0, NULL
    // 0x4feb9c: LeaveFrame
    //     0x4feb9c: mov             SP, fp
    //     0x4feba0: ldp             fp, lr, [SP], #0x10
    // 0x4feba4: ret
    //     0x4feba4: ret             
    // 0x4feba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4feba8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4febac: b               #0x4feb50
  }
  _ getStatBoosts(/* No info */) {
    // ** addr: 0x55cfa4, size: 0x40
    // 0x55cfa4: EnterFrame
    //     0x55cfa4: stp             fp, lr, [SP, #-0x10]!
    //     0x55cfa8: mov             fp, SP
    // 0x55cfac: AllocStack(0x10)
    //     0x55cfac: sub             SP, SP, #0x10
    // 0x55cfb0: CheckStackOverflow
    //     0x55cfb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55cfb4: cmp             SP, x16
    //     0x55cfb8: b.ls            #0x55cfdc
    // 0x55cfbc: r16 = <Chapter17Stat, CustomNum>
    //     0x55cfbc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a628] TypeArguments: <Chapter17Stat, CustomNum>
    //     0x55cfc0: ldr             x16, [x16, #0x628]
    // 0x55cfc4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x55cfc8: stp             lr, x16, [SP]
    // 0x55cfcc: r0 = Map._fromLiteral()
    //     0x55cfcc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x55cfd0: LeaveFrame
    //     0x55cfd0: mov             SP, fp
    //     0x55cfd4: ldp             fp, lr, [SP], #0x10
    // 0x55cfd8: ret
    //     0x55cfd8: ret             
    // 0x55cfdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55cfdc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55cfe0: b               #0x55cfbc
  }
  _ build(/* No info */) {
    // ** addr: 0x6a584c, size: 0x94
    // 0x6a584c: EnterFrame
    //     0x6a584c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5850: mov             fp, SP
    // 0x6a5854: AllocStack(0x10)
    //     0x6a5854: sub             SP, SP, #0x10
    // 0x6a5858: CheckStackOverflow
    //     0x6a5858: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a585c: cmp             SP, x16
    //     0x6a5860: b.ls            #0x6a58d8
    // 0x6a5864: r1 = Function '<anonymous closure>':.
    //     0x6a5864: add             x1, PP, #0x28, lsl #12  ; [pp+0x283c8] Function: [dart:core] Object::_simpleInstanceOfTrue (0x81ca90)
    //     0x6a5868: ldr             x1, [x1, #0x3c8]
    // 0x6a586c: r2 = Null
    //     0x6a586c: mov             x2, NULL
    // 0x6a5870: r0 = AllocateClosure()
    //     0x6a5870: bl              #0x826750  ; AllocateClosureStub
    // 0x6a5874: mov             x5, x0
    // 0x6a5878: r1 = Null
    //     0x6a5878: mov             x1, NULL
    // 0x6a587c: r2 = Instance_WarningWidget
    //     0x6a587c: add             x2, PP, #0x28, lsl #12  ; [pp+0x283d0] Obj!WarningWidget@84e941
    //     0x6a5880: ldr             x2, [x2, #0x3d0]
    // 0x6a5884: r3 = "Ch17 Under Development"
    //     0x6a5884: add             x3, PP, #0x28, lsl #12  ; [pp+0x283d8] "Ch17 Under Development"
    //     0x6a5888: ldr             x3, [x3, #0x3d8]
    // 0x6a588c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x6a588c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x6a5890: r0 = IdleFragment()
    //     0x6a5890: bl              #0x66a3e0  ; [package:pretentious/widgets/IdleFragment.dart] IdleFragment::IdleFragment
    // 0x6a5894: r1 = Null
    //     0x6a5894: mov             x1, NULL
    // 0x6a5898: r2 = 2
    //     0x6a5898: movz            x2, #0x2
    // 0x6a589c: stur            x0, [fp, #-8]
    // 0x6a58a0: r0 = AllocateArray()
    //     0x6a58a0: bl              #0x82746c  ; AllocateArrayStub
    // 0x6a58a4: mov             x2, x0
    // 0x6a58a8: ldur            x0, [fp, #-8]
    // 0x6a58ac: stur            x2, [fp, #-0x10]
    // 0x6a58b0: StoreField: r2->field_f = r0
    //     0x6a58b0: stur            w0, [x2, #0xf]
    // 0x6a58b4: r1 = <Widget>
    //     0x6a58b4: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x6a58b8: r0 = AllocateGrowableArray()
    //     0x6a58b8: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x6a58bc: ldur            x1, [fp, #-0x10]
    // 0x6a58c0: StoreField: r0->field_f = r1
    //     0x6a58c0: stur            w1, [x0, #0xf]
    // 0x6a58c4: r1 = 2
    //     0x6a58c4: movz            x1, #0x2
    // 0x6a58c8: StoreField: r0->field_b = r1
    //     0x6a58c8: stur            w1, [x0, #0xb]
    // 0x6a58cc: LeaveFrame
    //     0x6a58cc: mov             SP, fp
    //     0x6a58d0: ldp             fp, lr, [SP], #0x10
    // 0x6a58d4: ret
    //     0x6a58d4: ret             
    // 0x6a58d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a58d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a58dc: b               #0x6a5864
  }
  _ getGeneratorInfo(/* No info */) {
    // ** addr: 0x80d47c, size: 0x7c
    // 0x80d47c: EnterFrame
    //     0x80d47c: stp             fp, lr, [SP, #-0x10]!
    //     0x80d480: mov             fp, SP
    // 0x80d484: AllocStack(0x8)
    //     0x80d484: sub             SP, SP, #8
    // 0x80d488: CheckStackOverflow
    //     0x80d488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80d48c: cmp             SP, x16
    //     0x80d490: b.ls            #0x80d4e0
    // 0x80d494: LoadField: r0 = r1->field_8b
    //     0x80d494: ldur            w0, [x1, #0x8b]
    // 0x80d498: DecompressPointer r0
    //     0x80d498: add             x0, x0, HEAP, lsl #32
    // 0x80d49c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x80d4a0: cmp             w0, w16
    // 0x80d4a4: b.eq            #0x80d4e8
    // 0x80d4a8: mov             x1, x0
    // 0x80d4ac: stur            x0, [fp, #-8]
    // 0x80d4b0: r0 = _getValueOrData()
    //     0x80d4b0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x80d4b4: ldur            x1, [fp, #-8]
    // 0x80d4b8: LoadField: r2 = r1->field_f
    //     0x80d4b8: ldur            w2, [x1, #0xf]
    // 0x80d4bc: DecompressPointer r2
    //     0x80d4bc: add             x2, x2, HEAP, lsl #32
    // 0x80d4c0: cmp             w2, w0
    // 0x80d4c4: b.ne            #0x80d4cc
    // 0x80d4c8: r0 = Null
    //     0x80d4c8: mov             x0, NULL
    // 0x80d4cc: cmp             w0, NULL
    // 0x80d4d0: b.eq            #0x80d4f4
    // 0x80d4d4: LeaveFrame
    //     0x80d4d4: mov             SP, fp
    //     0x80d4d8: ldp             fp, lr, [SP], #0x10
    // 0x80d4dc: ret
    //     0x80d4dc: ret             
    // 0x80d4e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x80d4e0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80d4e4: b               #0x80d494
    // 0x80d4e8: r9 = generators
    //     0x80d4e8: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a630] Field <Chapter17GameState.generators>: late (offset: 0x8c)
    //     0x80d4ec: ldr             x9, [x9, #0x630]
    // 0x80d4f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80d4f0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x80d4f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80d4f4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ saveName(/* No info */) {
    // ** addr: 0x81d15c, size: 0xc
    // 0x81d15c: r0 = "17"
    //     0x81d15c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x81d160: ldr             x0, [x0, #0x358]
    // 0x81d164: ret
    //     0x81d164: ret             
  }
}

// class id: 4181, size: 0x14, field offset: 0x14
enum Chapter17Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724a74, size: 0x64
    // 0x724a74: EnterFrame
    //     0x724a74: stp             fp, lr, [SP, #-0x10]!
    //     0x724a78: mov             fp, SP
    // 0x724a7c: AllocStack(0x10)
    //     0x724a7c: sub             SP, SP, #0x10
    // 0x724a80: SetupParameters(Chapter17Stat this /* r1 => r0, fp-0x8 */)
    //     0x724a80: mov             x0, x1
    //     0x724a84: stur            x1, [fp, #-8]
    // 0x724a88: CheckStackOverflow
    //     0x724a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724a8c: cmp             SP, x16
    //     0x724a90: b.ls            #0x724ad0
    // 0x724a94: r1 = Null
    //     0x724a94: mov             x1, NULL
    // 0x724a98: r2 = 4
    //     0x724a98: movz            x2, #0x4
    // 0x724a9c: r0 = AllocateArray()
    //     0x724a9c: bl              #0x82746c  ; AllocateArrayStub
    // 0x724aa0: r16 = "Chapter17Stat."
    //     0x724aa0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15220] "Chapter17Stat."
    //     0x724aa4: ldr             x16, [x16, #0x220]
    // 0x724aa8: StoreField: r0->field_f = r16
    //     0x724aa8: stur            w16, [x0, #0xf]
    // 0x724aac: ldur            x1, [fp, #-8]
    // 0x724ab0: LoadField: r2 = r1->field_f
    //     0x724ab0: ldur            w2, [x1, #0xf]
    // 0x724ab4: DecompressPointer r2
    //     0x724ab4: add             x2, x2, HEAP, lsl #32
    // 0x724ab8: StoreField: r0->field_13 = r2
    //     0x724ab8: stur            w2, [x0, #0x13]
    // 0x724abc: str             x0, [SP]
    // 0x724ac0: r0 = _interpolate()
    //     0x724ac0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724ac4: LeaveFrame
    //     0x724ac4: mov             SP, fp
    //     0x724ac8: ldp             fp, lr, [SP], #0x10
    // 0x724acc: ret
    //     0x724acc: ret             
    // 0x724ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724ad0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724ad4: b               #0x724a94
  }
}
