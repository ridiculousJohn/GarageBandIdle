// lib: , url: package:pretentious/data/StoryPointManager.dart

// class id: 1049474, size: 0x8
class :: {

  static bool storyPointUnplayedAndMarkAsPlayedIfUnplayed(int) {
    // ** addr: 0x452458, size: 0xfc
    // 0x452458: EnterFrame
    //     0x452458: stp             fp, lr, [SP, #-0x10]!
    //     0x45245c: mov             fp, SP
    // 0x452460: AllocStack(0x10)
    //     0x452460: sub             SP, SP, #0x10
    // 0x452464: SetupParameters(dynamic _ /* r1 => r2 */)
    //     0x452464: mov             x2, x1
    // 0x452468: CheckStackOverflow
    //     0x452468: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45246c: cmp             SP, x16
    //     0x452470: b.ls            #0x452540
    // 0x452474: r0 = LoadStaticField(0xf7c)
    //     0x452474: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x452478: ldr             x0, [x0, #0x1ef8]
    // 0x45247c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x452480: cmp             w0, w16
    // 0x452484: b.eq            #0x452548
    // 0x452488: LoadField: r3 = r0->field_13
    //     0x452488: ldur            w3, [x0, #0x13]
    // 0x45248c: DecompressPointer r3
    //     0x45248c: add             x3, x3, HEAP, lsl #32
    // 0x452490: r0 = BoxInt64Instr(r2)
    //     0x452490: sbfiz           x0, x2, #1, #0x1f
    //     0x452494: cmp             x2, x0, asr #1
    //     0x452498: b.eq            #0x4524a4
    //     0x45249c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4524a0: stur            x2, [x0, #7]
    // 0x4524a4: mov             x1, x3
    // 0x4524a8: mov             x2, x0
    // 0x4524ac: stur            x0, [fp, #-8]
    // 0x4524b0: r0 = containsKey()
    //     0x4524b0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x4524b4: tbz             w0, #4, #0x452530
    // 0x4524b8: r0 = LoadStaticField(0xf7c)
    //     0x4524b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4524bc: ldr             x0, [x0, #0x1ef8]
    // 0x4524c0: LoadField: r1 = r0->field_13
    //     0x4524c0: ldur            w1, [x0, #0x13]
    // 0x4524c4: DecompressPointer r1
    //     0x4524c4: add             x1, x1, HEAP, lsl #32
    // 0x4524c8: stur            x1, [fp, #-0x10]
    // 0x4524cc: r0 = _getCurrentMicros()
    //     0x4524cc: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x4524d0: r1 = LoadInt32Instr(r0)
    //     0x4524d0: sbfx            x1, x0, #1, #0x1f
    //     0x4524d4: tbz             w0, #0, #0x4524dc
    //     0x4524d8: ldur            x1, [x0, #7]
    // 0x4524dc: tbz             x1, #0x3f, #0x4524e8
    // 0x4524e0: r2 = 999
    //     0x4524e0: movz            x2, #0x3e7
    // 0x4524e4: b               #0x4524ec
    // 0x4524e8: r2 = 0
    //     0x4524e8: movz            x2, #0
    // 0x4524ec: r0 = 1000
    //     0x4524ec: movz            x0, #0x3e8
    // 0x4524f0: sub             x3, x1, x2
    // 0x4524f4: sdiv            x2, x3, x0
    // 0x4524f8: r0 = BoxInt64Instr(r2)
    //     0x4524f8: sbfiz           x0, x2, #1, #0x1f
    //     0x4524fc: cmp             x2, x0, asr #1
    //     0x452500: b.eq            #0x45250c
    //     0x452504: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x452508: stur            x2, [x0, #7]
    // 0x45250c: ldur            x1, [fp, #-0x10]
    // 0x452510: ldur            x2, [fp, #-8]
    // 0x452514: mov             x3, x0
    // 0x452518: r0 = []=()
    //     0x452518: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x45251c: r0 = saveCoreData()
    //     0x45251c: bl              #0x452554  ; [package:pretentious/data/CoreData.dart] ::saveCoreData
    // 0x452520: r0 = true
    //     0x452520: add             x0, NULL, #0x20  ; true
    // 0x452524: LeaveFrame
    //     0x452524: mov             SP, fp
    //     0x452528: ldp             fp, lr, [SP], #0x10
    // 0x45252c: ret
    //     0x45252c: ret             
    // 0x452530: r0 = false
    //     0x452530: add             x0, NULL, #0x30  ; false
    // 0x452534: LeaveFrame
    //     0x452534: mov             SP, fp
    //     0x452538: ldp             fp, lr, [SP], #0x10
    // 0x45253c: ret
    //     0x45253c: ret             
    // 0x452540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x452540: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x452544: b               #0x452474
    // 0x452548: r9 = coreData
    //     0x452548: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x45254c: ldr             x9, [x9, #0x530]
    // 0x452550: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x452550: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ displaySlackPageAndIncrementAct(/* No info */) {
    // ** addr: 0x622380, size: 0xb0
    // 0x622380: EnterFrame
    //     0x622380: stp             fp, lr, [SP, #-0x10]!
    //     0x622384: mov             fp, SP
    // 0x622388: AllocStack(0x30)
    //     0x622388: sub             SP, SP, #0x30
    // 0x62238c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x62238c: stur            x1, [fp, #-8]
    //     0x622390: stur            x2, [fp, #-0x10]
    //     0x622394: stur            x3, [fp, #-0x18]
    // 0x622398: CheckStackOverflow
    //     0x622398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x62239c: cmp             SP, x16
    //     0x6223a0: b.ls            #0x622428
    // 0x6223a4: r1 = 3
    //     0x6223a4: movz            x1, #0x3
    // 0x6223a8: r0 = AllocateContext()
    //     0x6223a8: bl              #0x82637c  ; AllocateContextStub
    // 0x6223ac: mov             x1, x0
    // 0x6223b0: ldur            x0, [fp, #-8]
    // 0x6223b4: StoreField: r1->field_f = r0
    //     0x6223b4: stur            w0, [x1, #0xf]
    // 0x6223b8: ldur            x2, [fp, #-0x10]
    // 0x6223bc: StoreField: r1->field_13 = r2
    //     0x6223bc: stur            w2, [x1, #0x13]
    // 0x6223c0: ldur            x3, [fp, #-0x18]
    // 0x6223c4: ArrayStore: r1[0] = r3  ; List_4
    //     0x6223c4: stur            w3, [x1, #0x17]
    // 0x6223c8: cmp             w3, NULL
    // 0x6223cc: r16 = true
    //     0x6223cc: add             x16, NULL, #0x20  ; true
    // 0x6223d0: r17 = false
    //     0x6223d0: add             x17, NULL, #0x30  ; false
    // 0x6223d4: csel            x4, x16, x17, eq
    // 0x6223d8: stur            x4, [fp, #-0x28]
    // 0x6223dc: r3 = LoadInt32Instr(r2)
    //     0x6223dc: sbfx            x3, x2, #1, #0x1f
    //     0x6223e0: tbz             w2, #0, #0x6223e8
    //     0x6223e4: ldur            x3, [x2, #7]
    // 0x6223e8: mov             x2, x1
    // 0x6223ec: stur            x3, [fp, #-0x20]
    // 0x6223f0: r1 = Function '<anonymous closure>': static.
    //     0x6223f0: add             x1, PP, #0x25, lsl #12  ; [pp+0x25948] AnonymousClosure: static (0x6226dc), in [package:pretentious/data/StoryPointManager.dart] ::displaySlackPageAndIncrementAct (0x622380)
    //     0x6223f4: ldr             x1, [x1, #0x948]
    // 0x6223f8: r0 = AllocateClosure()
    //     0x6223f8: bl              #0x826750  ; AllocateClosureStub
    // 0x6223fc: ldur            x16, [fp, #-0x28]
    // 0x622400: str             x16, [SP]
    // 0x622404: ldur            x1, [fp, #-8]
    // 0x622408: ldur            x2, [fp, #-0x20]
    // 0x62240c: mov             x3, x0
    // 0x622410: r4 = const [0, 0x4, 0x1, 0x3, autoCloseAfterCustomAction, 0x3, null]
    //     0x622410: add             x4, PP, #0x25, lsl #12  ; [pp+0x25950] List(7) [0, 0x4, 0x1, 0x3, "autoCloseAfterCustomAction", 0x3, Null]
    //     0x622414: ldr             x4, [x4, #0x950]
    // 0x622418: r0 = displaySlackPage()
    //     0x622418: bl              #0x622430  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage
    // 0x62241c: LeaveFrame
    //     0x62241c: mov             SP, fp
    //     0x622420: ldp             fp, lr, [SP], #0x10
    // 0x622424: ret
    //     0x622424: ret             
    // 0x622428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622428: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62242c: b               #0x6223a4
  }
  static _ displaySlackPage(/* No info */) {
    // ** addr: 0x622430, size: 0xe0
    // 0x622430: EnterFrame
    //     0x622430: stp             fp, lr, [SP, #-0x10]!
    //     0x622434: mov             fp, SP
    // 0x622438: AllocStack(0x40)
    //     0x622438: sub             SP, SP, #0x40
    // 0x62243c: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, {dynamic autoCloseAfterCustomAction = true /* r0, fp-0x8 */})
    //     0x62243c: stur            x1, [fp, #-0x10]
    //     0x622440: stur            x2, [fp, #-0x18]
    //     0x622444: stur            x3, [fp, #-0x20]
    //     0x622448: ldur            w0, [x4, #0x13]
    //     0x62244c: ldur            w5, [x4, #0x1f]
    //     0x622450: add             x5, x5, HEAP, lsl #32
    //     0x622454: add             x16, PP, #0x25, lsl #12  ; [pp+0x25960] "autoCloseAfterCustomAction"
    //     0x622458: ldr             x16, [x16, #0x960]
    //     0x62245c: cmp             w5, w16
    //     0x622460: b.ne            #0x62247c
    //     0x622464: ldur            w5, [x4, #0x23]
    //     0x622468: add             x5, x5, HEAP, lsl #32
    //     0x62246c: sub             w4, w0, w5
    //     0x622470: add             x0, fp, w4, sxtw #2
    //     0x622474: ldr             x0, [x0, #8]
    //     0x622478: b               #0x622480
    //     0x62247c: add             x0, NULL, #0x20  ; true
    //     0x622480: stur            x0, [fp, #-8]
    // 0x622484: CheckStackOverflow
    //     0x622484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622488: cmp             SP, x16
    //     0x62248c: b.ls            #0x622508
    // 0x622490: r1 = 4
    //     0x622490: movz            x1, #0x4
    // 0x622494: r0 = AllocateContext()
    //     0x622494: bl              #0x82637c  ; AllocateContextStub
    // 0x622498: mov             x2, x0
    // 0x62249c: ldur            x3, [fp, #-0x10]
    // 0x6224a0: StoreField: r2->field_f = r3
    //     0x6224a0: stur            w3, [x2, #0xf]
    // 0x6224a4: ldur            x4, [fp, #-0x18]
    // 0x6224a8: r0 = BoxInt64Instr(r4)
    //     0x6224a8: sbfiz           x0, x4, #1, #0x1f
    //     0x6224ac: cmp             x4, x0, asr #1
    //     0x6224b0: b.eq            #0x6224bc
    //     0x6224b4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6224b8: stur            x4, [x0, #7]
    // 0x6224bc: StoreField: r2->field_13 = r0
    //     0x6224bc: stur            w0, [x2, #0x13]
    // 0x6224c0: ldur            x0, [fp, #-0x20]
    // 0x6224c4: ArrayStore: r2[0] = r0  ; List_4
    //     0x6224c4: stur            w0, [x2, #0x17]
    // 0x6224c8: ldur            x0, [fp, #-8]
    // 0x6224cc: StoreField: r2->field_1b = r0
    //     0x6224cc: stur            w0, [x2, #0x1b]
    // 0x6224d0: r1 = Function '<anonymous closure>': static.
    //     0x6224d0: add             x1, PP, #0x25, lsl #12  ; [pp+0x25968] AnonymousClosure: static (0x622510), in [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage (0x622430)
    //     0x6224d4: ldr             x1, [x1, #0x968]
    // 0x6224d8: r0 = AllocateClosure()
    //     0x6224d8: bl              #0x826750  ; AllocateClosureStub
    // 0x6224dc: r16 = <void?>
    //     0x6224dc: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x6224e0: stp             x0, x16, [SP, #0x10]
    // 0x6224e4: ldur            x16, [fp, #-0x10]
    // 0x6224e8: r30 = false
    //     0x6224e8: add             lr, NULL, #0x30  ; false
    // 0x6224ec: stp             lr, x16, [SP]
    // 0x6224f0: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x6224f0: add             x4, PP, #0xe, lsl #12  ; [pp+0xe4f8] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x6224f4: ldr             x4, [x4, #0x4f8]
    // 0x6224f8: r0 = showDialog()
    //     0x6224f8: bl              #0x3ecee0  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x6224fc: LeaveFrame
    //     0x6224fc: mov             SP, fp
    //     0x622500: ldp             fp, lr, [SP], #0x10
    // 0x622504: ret
    //     0x622504: ret             
    // 0x622508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622508: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62250c: b               #0x622490
  }
  [closure] static PhonePopupRaw <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x622510, size: 0x164
    // 0x622510: EnterFrame
    //     0x622510: stp             fp, lr, [SP, #-0x10]!
    //     0x622514: mov             fp, SP
    // 0x622518: AllocStack(0x38)
    //     0x622518: sub             SP, SP, #0x38
    // 0x62251c: SetupParameters([dynamic _ /* r0 */])
    //     0x62251c: ldr             x0, [fp, #0x18]
    //     0x622520: ldur            w3, [x0, #0x17]
    //     0x622524: add             x3, x3, HEAP, lsl #32
    //     0x622528: stur            x3, [fp, #-8]
    // 0x62252c: CheckStackOverflow
    //     0x62252c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622530: cmp             SP, x16
    //     0x622534: b.ls            #0x622658
    // 0x622538: LoadField: r2 = r3->field_13
    //     0x622538: ldur            w2, [x3, #0x13]
    // 0x62253c: DecompressPointer r2
    //     0x62253c: add             x2, x2, HEAP, lsl #32
    // 0x622540: r1 = _ConstMap len:35
    //     0x622540: add             x1, PP, #0xe, lsl #12  ; [pp+0xe930] Map<int, StoryPoint>(35)
    //     0x622544: ldr             x1, [x1, #0x930]
    // 0x622548: r0 = []()
    //     0x622548: bl              #0x8247ec  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x62254c: cmp             w0, NULL
    // 0x622550: b.eq            #0x622660
    // 0x622554: LoadField: r3 = r0->field_b
    //     0x622554: ldur            w3, [x0, #0xb]
    // 0x622558: DecompressPointer r3
    //     0x622558: add             x3, x3, HEAP, lsl #32
    // 0x62255c: ldur            x0, [fp, #-8]
    // 0x622560: stur            x3, [fp, #-0x10]
    // 0x622564: LoadField: r2 = r0->field_13
    //     0x622564: ldur            w2, [x0, #0x13]
    // 0x622568: DecompressPointer r2
    //     0x622568: add             x2, x2, HEAP, lsl #32
    // 0x62256c: r1 = _ConstMap len:35
    //     0x62256c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe930] Map<int, StoryPoint>(35)
    //     0x622570: ldr             x1, [x1, #0x930]
    // 0x622574: r0 = []()
    //     0x622574: bl              #0x8247ec  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x622578: cmp             w0, NULL
    // 0x62257c: b.eq            #0x622664
    // 0x622580: LoadField: r3 = r0->field_7
    //     0x622580: ldur            w3, [x0, #7]
    // 0x622584: DecompressPointer r3
    //     0x622584: add             x3, x3, HEAP, lsl #32
    // 0x622588: stur            x3, [fp, #-0x18]
    // 0x62258c: r0 = LoadStaticField(0xf7c)
    //     0x62258c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x622590: ldr             x0, [x0, #0x1ef8]
    // 0x622594: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x622598: cmp             w0, w16
    // 0x62259c: b.eq            #0x622668
    // 0x6225a0: LoadField: r1 = r0->field_13
    //     0x6225a0: ldur            w1, [x0, #0x13]
    // 0x6225a4: DecompressPointer r1
    //     0x6225a4: add             x1, x1, HEAP, lsl #32
    // 0x6225a8: ldur            x0, [fp, #-8]
    // 0x6225ac: LoadField: r2 = r0->field_13
    //     0x6225ac: ldur            w2, [x0, #0x13]
    // 0x6225b0: DecompressPointer r2
    //     0x6225b0: add             x2, x2, HEAP, lsl #32
    // 0x6225b4: r0 = containsKey()
    //     0x6225b4: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6225b8: ldur            x2, [fp, #-8]
    // 0x6225bc: stur            x0, [fp, #-0x20]
    // 0x6225c0: LoadField: r1 = r2->field_f
    //     0x6225c0: ldur            w1, [x2, #0xf]
    // 0x6225c4: DecompressPointer r1
    //     0x6225c4: add             x1, x1, HEAP, lsl #32
    // 0x6225c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6225c8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6225cc: r0 = _of()
    //     0x6225cc: bl              #0x404a6c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x6225d0: LoadField: r1 = r0->field_37
    //     0x6225d0: ldur            w1, [x0, #0x37]
    // 0x6225d4: DecompressPointer r1
    //     0x6225d4: add             x1, x1, HEAP, lsl #32
    // 0x6225d8: ldur            x2, [fp, #-8]
    // 0x6225dc: stur            x1, [fp, #-0x30]
    // 0x6225e0: LoadField: r0 = r2->field_1b
    //     0x6225e0: ldur            w0, [x2, #0x1b]
    // 0x6225e4: DecompressPointer r0
    //     0x6225e4: add             x0, x0, HEAP, lsl #32
    // 0x6225e8: stur            x0, [fp, #-0x28]
    // 0x6225ec: r0 = SlackPage()
    //     0x6225ec: bl              #0x48f7b0  ; AllocateSlackPageStub -> SlackPage (size=0x2c)
    // 0x6225f0: mov             x3, x0
    // 0x6225f4: ldur            x0, [fp, #-0x10]
    // 0x6225f8: stur            x3, [fp, #-0x38]
    // 0x6225fc: StoreField: r3->field_b = r0
    //     0x6225fc: stur            w0, [x3, #0xb]
    // 0x622600: ldur            x0, [fp, #-0x18]
    // 0x622604: StoreField: r3->field_23 = r0
    //     0x622604: stur            w0, [x3, #0x23]
    // 0x622608: ldur            x2, [fp, #-8]
    // 0x62260c: r1 = Function '<anonymous closure>': static.
    //     0x62260c: add             x1, PP, #0x25, lsl #12  ; [pp+0x25970] AnonymousClosure: static (0x622674), in [package:pretentious/data/StoryPointManager.dart] ::displaySlackPage (0x622430)
    //     0x622610: ldr             x1, [x1, #0x970]
    // 0x622614: r0 = AllocateClosure()
    //     0x622614: bl              #0x826750  ; AllocateClosureStub
    // 0x622618: ldur            x2, [fp, #-0x38]
    // 0x62261c: StoreField: r2->field_f = r0
    //     0x62261c: stur            w0, [x2, #0xf]
    // 0x622620: ldur            x0, [fp, #-0x20]
    // 0x622624: StoreField: r2->field_13 = r0
    //     0x622624: stur            w0, [x2, #0x13]
    // 0x622628: d0 = 0.900000
    //     0x622628: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf28] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x62262c: ldr             d0, [x17, #0xf28]
    // 0x622630: ArrayStore: r2[0] = d0  ; List_8
    //     0x622630: stur            d0, [x2, #0x17]
    // 0x622634: ldur            x0, [fp, #-0x28]
    // 0x622638: StoreField: r2->field_1f = r0
    //     0x622638: stur            w0, [x2, #0x1f]
    // 0x62263c: ldur            x0, [fp, #-0x30]
    // 0x622640: StoreField: r2->field_27 = r0
    //     0x622640: stur            w0, [x2, #0x27]
    // 0x622644: r1 = Null
    //     0x622644: mov             x1, NULL
    // 0x622648: r0 = PhonePopupRaw()
    //     0x622648: bl              #0x48f580  ; [package:pretentious/Popups/PhonePopupRaw.dart] PhonePopupRaw::PhonePopupRaw
    // 0x62264c: LeaveFrame
    //     0x62264c: mov             SP, fp
    //     0x622650: ldp             fp, lr, [SP], #0x10
    // 0x622654: ret
    //     0x622654: ret             
    // 0x622658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622658: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62265c: b               #0x622538
    // 0x622660: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x622660: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x622664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x622664: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x622668: r9 = coreData
    //     0x622668: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x62266c: ldr             x9, [x9, #0x530]
    // 0x622670: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x622670: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] static void <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x622674, size: 0x68
    // 0x622674: EnterFrame
    //     0x622674: stp             fp, lr, [SP, #-0x10]!
    //     0x622678: mov             fp, SP
    // 0x62267c: AllocStack(0x18)
    //     0x62267c: sub             SP, SP, #0x18
    // 0x622680: SetupParameters([dynamic _ /* r0 */])
    //     0x622680: ldr             x0, [fp, #0x18]
    //     0x622684: ldur            w1, [x0, #0x17]
    //     0x622688: add             x1, x1, HEAP, lsl #32
    // 0x62268c: CheckStackOverflow
    //     0x62268c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622690: cmp             SP, x16
    //     0x622694: b.ls            #0x6226d4
    // 0x622698: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x622698: ldur            w0, [x1, #0x17]
    // 0x62269c: DecompressPointer r0
    //     0x62269c: add             x0, x0, HEAP, lsl #32
    // 0x6226a0: LoadField: r2 = r1->field_f
    //     0x6226a0: ldur            w2, [x1, #0xf]
    // 0x6226a4: DecompressPointer r2
    //     0x6226a4: add             x2, x2, HEAP, lsl #32
    // 0x6226a8: LoadField: r3 = r1->field_13
    //     0x6226a8: ldur            w3, [x1, #0x13]
    // 0x6226ac: DecompressPointer r3
    //     0x6226ac: add             x3, x3, HEAP, lsl #32
    // 0x6226b0: stp             x2, x0, [SP, #8]
    // 0x6226b4: str             x3, [SP]
    // 0x6226b8: ClosureCall
    //     0x6226b8: ldr             x4, [PP, #0x3c8]  ; [pp+0x3c8] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x6226bc: ldur            x2, [x0, #0x1f]
    //     0x6226c0: blr             x2
    // 0x6226c4: r0 = Null
    //     0x6226c4: mov             x0, NULL
    // 0x6226c8: LeaveFrame
    //     0x6226c8: mov             SP, fp
    //     0x6226cc: ldp             fp, lr, [SP], #0x10
    // 0x6226d0: ret
    //     0x6226d0: ret             
    // 0x6226d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6226d4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6226d8: b               #0x622698
  }
  [closure] static void <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x6226dc, size: 0xf4
    // 0x6226dc: EnterFrame
    //     0x6226dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6226e0: mov             fp, SP
    // 0x6226e4: AllocStack(0x38)
    //     0x6226e4: sub             SP, SP, #0x38
    // 0x6226e8: SetupParameters([dynamic _ /* r0 */])
    //     0x6226e8: ldr             x0, [fp, #0x20]
    //     0x6226ec: ldur            w2, [x0, #0x17]
    //     0x6226f0: add             x2, x2, HEAP, lsl #32
    //     0x6226f4: stur            x2, [fp, #-8]
    // 0x6226f8: CheckStackOverflow
    //     0x6226f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6226fc: cmp             SP, x16
    //     0x622700: b.ls            #0x6227c8
    // 0x622704: LoadField: r0 = r2->field_13
    //     0x622704: ldur            w0, [x2, #0x13]
    // 0x622708: DecompressPointer r0
    //     0x622708: add             x0, x0, HEAP, lsl #32
    // 0x62270c: r1 = LoadInt32Instr(r0)
    //     0x62270c: sbfx            x1, x0, #1, #0x1f
    //     0x622710: tbz             w0, #0, #0x622718
    //     0x622714: ldur            x1, [x0, #7]
    // 0x622718: r0 = storyPointUnplayedAndMarkAsPlayedIfUnplayed()
    //     0x622718: bl              #0x452458  ; [package:pretentious/data/StoryPointManager.dart] ::storyPointUnplayedAndMarkAsPlayedIfUnplayed
    // 0x62271c: ldur            x2, [fp, #-8]
    // 0x622720: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x622720: ldur            w0, [x2, #0x17]
    // 0x622724: DecompressPointer r0
    //     0x622724: add             x0, x0, HEAP, lsl #32
    // 0x622728: stur            x0, [fp, #-0x18]
    // 0x62272c: cmp             w0, NULL
    // 0x622730: b.eq            #0x6227b8
    // 0x622734: LoadField: r1 = r2->field_f
    //     0x622734: ldur            w1, [x2, #0xf]
    // 0x622738: DecompressPointer r1
    //     0x622738: add             x1, x1, HEAP, lsl #32
    // 0x62273c: stur            x1, [fp, #-0x10]
    // 0x622740: r0 = TransitionPage()
    //     0x622740: bl              #0x6227d0  ; AllocateTransitionPageStub -> TransitionPage (size=0x10)
    // 0x622744: mov             x2, x0
    // 0x622748: ldur            x0, [fp, #-0x18]
    // 0x62274c: stur            x2, [fp, #-0x20]
    // 0x622750: StoreField: r2->field_b = r0
    //     0x622750: stur            w0, [x2, #0xb]
    // 0x622754: r1 = <void?>
    //     0x622754: ldr             x1, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x622758: r0 = FadePageRoute()
    //     0x622758: bl              #0x48fab8  ; AllocateFadePageRouteStub -> FadePageRoute<X0> (size=0xc8)
    // 0x62275c: mov             x1, x0
    // 0x622760: ldur            x2, [fp, #-0x20]
    // 0x622764: stur            x0, [fp, #-0x18]
    // 0x622768: r0 = FadePageRoute()
    //     0x622768: bl              #0x48f8a4  ; [package:pretentious/pages/TransitionPage.dart] FadePageRoute::FadePageRoute
    // 0x62276c: r16 = <void?, Object?>
    //     0x62276c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe948] TypeArguments: <void?, Object?>
    //     0x622770: ldr             x16, [x16, #0x948]
    // 0x622774: ldur            lr, [fp, #-0x10]
    // 0x622778: stp             lr, x16, [SP, #8]
    // 0x62277c: ldur            x16, [fp, #-0x18]
    // 0x622780: str             x16, [SP]
    // 0x622784: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x622784: ldr             x4, [PP, #0x16a0]  ; [pp+0x16a0] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x622788: r0 = pushReplacement()
    //     0x622788: bl              #0x48f108  ; [package:flutter/src/widgets/navigator.dart] Navigator::pushReplacement
    // 0x62278c: ldur            x2, [fp, #-8]
    // 0x622790: r1 = Function '<anonymous closure>': static.
    //     0x622790: add             x1, PP, #0x25, lsl #12  ; [pp+0x25958] AnonymousClosure: static (0x6227dc), in [package:pretentious/data/StoryPointManager.dart] ::displaySlackPageAndIncrementAct (0x622380)
    //     0x622794: ldr             x1, [x1, #0x958]
    // 0x622798: stur            x0, [fp, #-8]
    // 0x62279c: r0 = AllocateClosure()
    //     0x62279c: bl              #0x826750  ; AllocateClosureStub
    // 0x6227a0: r16 = <void?>
    //     0x6227a0: ldr             x16, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x6227a4: ldur            lr, [fp, #-8]
    // 0x6227a8: stp             lr, x16, [SP, #8]
    // 0x6227ac: str             x0, [SP]
    // 0x6227b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6227b0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6227b4: r0 = then()
    //     0x6227b4: bl              #0x7cc9a0  ; [dart:async] _Future::then
    // 0x6227b8: r0 = Null
    //     0x6227b8: mov             x0, NULL
    // 0x6227bc: LeaveFrame
    //     0x6227bc: mov             SP, fp
    //     0x6227c0: ldp             fp, lr, [SP], #0x10
    // 0x6227c4: ret
    //     0x6227c4: ret             
    // 0x6227c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6227c8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6227cc: b               #0x622704
  }
  [closure] static Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x6227dc, size: 0x48
    // 0x6227dc: EnterFrame
    //     0x6227dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6227e0: mov             fp, SP
    // 0x6227e4: ldr             x0, [fp, #0x18]
    // 0x6227e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6227e8: ldur            w1, [x0, #0x17]
    // 0x6227ec: DecompressPointer r1
    //     0x6227ec: add             x1, x1, HEAP, lsl #32
    // 0x6227f0: CheckStackOverflow
    //     0x6227f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6227f4: cmp             SP, x16
    //     0x6227f8: b.ls            #0x62281c
    // 0x6227fc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x6227fc: ldur            w0, [x1, #0x17]
    // 0x622800: DecompressPointer r0
    //     0x622800: add             x0, x0, HEAP, lsl #32
    // 0x622804: mov             x1, x0
    // 0x622808: r0 = changeChapter()
    //     0x622808: bl              #0x48fd08  ; [package:pretentious/Popups/ChaptersDisplay.dart] ::changeChapter
    // 0x62280c: r0 = Null
    //     0x62280c: mov             x0, NULL
    // 0x622810: LeaveFrame
    //     0x622810: mov             SP, fp
    //     0x622814: ldp             fp, lr, [SP], #0x10
    // 0x622818: ret
    //     0x622818: ret             
    // 0x62281c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62281c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622820: b               #0x6227fc
  }
}

// class id: 259, size: 0x10, field offset: 0x8
//   const constructor, 
class StoryPoint extends Object {

  _OneByteString field_8;
  _ImmutableList<Tuple2<Character, String>> field_c;
}

// class id: 4168, size: 0x14, field offset: 0x14
enum Character extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724df8, size: 0x64
    // 0x724df8: EnterFrame
    //     0x724df8: stp             fp, lr, [SP, #-0x10]!
    //     0x724dfc: mov             fp, SP
    // 0x724e00: AllocStack(0x10)
    //     0x724e00: sub             SP, SP, #0x10
    // 0x724e04: SetupParameters(Character this /* r1 => r0, fp-0x8 */)
    //     0x724e04: mov             x0, x1
    //     0x724e08: stur            x1, [fp, #-8]
    // 0x724e0c: CheckStackOverflow
    //     0x724e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724e10: cmp             SP, x16
    //     0x724e14: b.ls            #0x724e54
    // 0x724e18: r1 = Null
    //     0x724e18: mov             x1, NULL
    // 0x724e1c: r2 = 4
    //     0x724e1c: movz            x2, #0x4
    // 0x724e20: r0 = AllocateArray()
    //     0x724e20: bl              #0x82746c  ; AllocateArrayStub
    // 0x724e24: r16 = "Character."
    //     0x724e24: add             x16, PP, #0x16, lsl #12  ; [pp+0x16950] "Character."
    //     0x724e28: ldr             x16, [x16, #0x950]
    // 0x724e2c: StoreField: r0->field_f = r16
    //     0x724e2c: stur            w16, [x0, #0xf]
    // 0x724e30: ldur            x1, [fp, #-8]
    // 0x724e34: LoadField: r2 = r1->field_f
    //     0x724e34: ldur            w2, [x1, #0xf]
    // 0x724e38: DecompressPointer r2
    //     0x724e38: add             x2, x2, HEAP, lsl #32
    // 0x724e3c: StoreField: r0->field_13 = r2
    //     0x724e3c: stur            w2, [x0, #0x13]
    // 0x724e40: str             x0, [SP]
    // 0x724e44: r0 = _interpolate()
    //     0x724e44: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724e48: LeaveFrame
    //     0x724e48: mov             SP, fp
    //     0x724e4c: ldp             fp, lr, [SP], #0x10
    // 0x724e50: ret
    //     0x724e50: ret             
    // 0x724e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724e54: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724e58: b               #0x724e18
  }
}
