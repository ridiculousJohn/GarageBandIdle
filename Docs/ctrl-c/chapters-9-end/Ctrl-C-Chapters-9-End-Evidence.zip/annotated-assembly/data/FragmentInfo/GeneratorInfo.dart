// lib: , url: package:pretentious/data/FragmentInfo/GeneratorInfo.dart

// class id: 1049471, size: 0x8
class :: {
}

// class id: 261, size: 0x38, field offset: 0x8
//   const constructor, 
class GeneratorInfo<X0> extends Object {

  bool field_c;
  bool field_10;
  bool field_14;
  _OneByteString field_1c;
  _ConstMap<Chapter9Stat, CustomNum> field_24;
  Tuple2<Chapter9Stat, CustomNum> field_28;
  _Double field_20;
  Tuple2<Chapter15Stat, CustomNum> field_30;
  _ConstMap<Chapter13Stat, CustomNum> field_34;
  Tuple2<Stat, CustomNum> field_2c;

  _ effectiveSecondsToComplete(/* No info */) {
    // ** addr: 0x53a284, size: 0x29c
    // 0x53a284: EnterFrame
    //     0x53a284: stp             fp, lr, [SP, #-0x10]!
    //     0x53a288: mov             fp, SP
    // 0x53a28c: AllocStack(0x38)
    //     0x53a28c: sub             SP, SP, #0x38
    // 0x53a290: SetupParameters(GeneratorInfo<X0> this /* r1 => r8, fp-0x10 */, dynamic _ /* r2 => r6, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */, dynamic _ /* r5 => r4, fp-0x28 */, dynamic _ /* r6 => r3, fp-0x30 */, dynamic _ /* r7 => r7, fp-0x38 */)
    //     0x53a290: mov             x8, x1
    //     0x53a294: mov             x4, x5
    //     0x53a298: stur            x5, [fp, #-0x28]
    //     0x53a29c: mov             x5, x3
    //     0x53a2a0: stur            x3, [fp, #-0x20]
    //     0x53a2a4: mov             x3, x6
    //     0x53a2a8: stur            x6, [fp, #-0x30]
    //     0x53a2ac: mov             x6, x2
    //     0x53a2b0: stur            x1, [fp, #-0x10]
    //     0x53a2b4: stur            x2, [fp, #-0x18]
    //     0x53a2b8: stur            x7, [fp, #-0x38]
    // 0x53a2bc: CheckStackOverflow
    //     0x53a2bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53a2c0: cmp             SP, x16
    //     0x53a2c4: b.ls            #0x53a510
    // 0x53a2c8: LoadField: r9 = r8->field_7
    //     0x53a2c8: ldur            w9, [x8, #7]
    // 0x53a2cc: DecompressPointer r9
    //     0x53a2cc: add             x9, x9, HEAP, lsl #32
    // 0x53a2d0: mov             x0, x5
    // 0x53a2d4: mov             x2, x9
    // 0x53a2d8: stur            x9, [fp, #-8]
    // 0x53a2dc: r1 = Null
    //     0x53a2dc: mov             x1, NULL
    // 0x53a2e0: r8 = GeneratorInfo<X0>
    //     0x53a2e0: add             x8, PP, #0x17, lsl #12  ; [pp+0x170b8] Type: GeneratorInfo<X0>
    //     0x53a2e4: ldr             x8, [x8, #0xb8]
    // 0x53a2e8: LoadField: r9 = r8->field_7
    //     0x53a2e8: ldur            x9, [x8, #7]
    // 0x53a2ec: r3 = Null
    //     0x53a2ec: add             x3, PP, #0x17, lsl #12  ; [pp+0x170c0] Null
    //     0x53a2f0: ldr             x3, [x3, #0xc0]
    // 0x53a2f4: blr             x9
    // 0x53a2f8: ldur            x0, [fp, #-0x30]
    // 0x53a2fc: ldur            x2, [fp, #-8]
    // 0x53a300: r1 = Null
    //     0x53a300: mov             x1, NULL
    // 0x53a304: r8 = Map<X0, Boost>
    //     0x53a304: add             x8, PP, #0x17, lsl #12  ; [pp+0x170d0] Type: Map<X0, Boost>
    //     0x53a308: ldr             x8, [x8, #0xd0]
    // 0x53a30c: LoadField: r9 = r8->field_7
    //     0x53a30c: ldur            x9, [x8, #7]
    // 0x53a310: r3 = Null
    //     0x53a310: add             x3, PP, #0x17, lsl #12  ; [pp+0x170d8] Null
    //     0x53a314: ldr             x3, [x3, #0xd8]
    // 0x53a318: blr             x9
    // 0x53a31c: ldur            x2, [fp, #-0x18]
    // 0x53a320: r0 = BoxInt64Instr(r2)
    //     0x53a320: sbfiz           x0, x2, #1, #0x1f
    //     0x53a324: cmp             x2, x0, asr #1
    //     0x53a328: b.eq            #0x53a334
    //     0x53a32c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x53a330: stur            x2, [x0, #7]
    // 0x53a334: ldur            x1, [fp, #-0x28]
    // 0x53a338: mov             x2, x0
    // 0x53a33c: r0 = _getValueOrData()
    //     0x53a33c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53a340: mov             x1, x0
    // 0x53a344: ldur            x0, [fp, #-0x28]
    // 0x53a348: LoadField: r2 = r0->field_f
    //     0x53a348: ldur            w2, [x0, #0xf]
    // 0x53a34c: DecompressPointer r2
    //     0x53a34c: add             x2, x2, HEAP, lsl #32
    // 0x53a350: cmp             w2, w1
    // 0x53a354: b.ne            #0x53a360
    // 0x53a358: r0 = Null
    //     0x53a358: mov             x0, NULL
    // 0x53a35c: b               #0x53a364
    // 0x53a360: mov             x0, x1
    // 0x53a364: cmp             w0, NULL
    // 0x53a368: b.ne            #0x53a374
    // 0x53a36c: r0 = Null
    //     0x53a36c: mov             x0, NULL
    // 0x53a370: b               #0x53a380
    // 0x53a374: LoadField: r1 = r0->field_7
    //     0x53a374: ldur            w1, [x0, #7]
    // 0x53a378: DecompressPointer r1
    //     0x53a378: add             x1, x1, HEAP, lsl #32
    // 0x53a37c: mov             x0, x1
    // 0x53a380: cmp             w0, NULL
    // 0x53a384: b.ne            #0x53a394
    // 0x53a388: r1 = Instance_CustomNum
    //     0x53a388: add             x1, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x53a38c: ldr             x1, [x1, #0xa70]
    // 0x53a390: b               #0x53a398
    // 0x53a394: mov             x1, x0
    // 0x53a398: ldur            x3, [fp, #-0x20]
    // 0x53a39c: ldur            x0, [fp, #-0x38]
    // 0x53a3a0: LoadField: r2 = r0->field_7
    //     0x53a3a0: ldur            w2, [x0, #7]
    // 0x53a3a4: DecompressPointer r2
    //     0x53a3a4: add             x2, x2, HEAP, lsl #32
    // 0x53a3a8: r0 = mult2()
    //     0x53a3a8: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x53a3ac: mov             x2, x0
    // 0x53a3b0: ldur            x0, [fp, #-0x20]
    // 0x53a3b4: stur            x2, [fp, #-8]
    // 0x53a3b8: LoadField: r1 = r0->field_23
    //     0x53a3b8: ldur            w1, [x0, #0x23]
    // 0x53a3bc: DecompressPointer r1
    //     0x53a3bc: add             x1, x1, HEAP, lsl #32
    // 0x53a3c0: r0 = LoadClassIdInstr(r1)
    //     0x53a3c0: ldur            x0, [x1, #-1]
    //     0x53a3c4: ubfx            x0, x0, #0xc, #0x14
    // 0x53a3c8: r0 = GDT[cid_x0 + -0xcb]()
    //     0x53a3c8: sub             lr, x0, #0xcb
    //     0x53a3cc: ldr             lr, [x21, lr, lsl #3]
    //     0x53a3d0: blr             lr
    // 0x53a3d4: r1 = LoadClassIdInstr(r0)
    //     0x53a3d4: ldur            x1, [x0, #-1]
    //     0x53a3d8: ubfx            x1, x1, #0xc, #0x14
    // 0x53a3dc: mov             x16, x0
    // 0x53a3e0: mov             x0, x1
    // 0x53a3e4: mov             x1, x16
    // 0x53a3e8: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x53a3e8: movz            x17, #0x7df6
    //     0x53a3ec: add             lr, x0, x17
    //     0x53a3f0: ldr             lr, [x21, lr, lsl #3]
    //     0x53a3f4: blr             lr
    // 0x53a3f8: mov             x2, x0
    // 0x53a3fc: stur            x2, [fp, #-0x20]
    // 0x53a400: ldur            x4, [fp, #-8]
    // 0x53a404: ldur            x3, [fp, #-0x30]
    // 0x53a408: stur            x4, [fp, #-8]
    // 0x53a40c: CheckStackOverflow
    //     0x53a40c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53a410: cmp             SP, x16
    //     0x53a414: b.ls            #0x53a518
    // 0x53a418: r0 = LoadClassIdInstr(r2)
    //     0x53a418: ldur            x0, [x2, #-1]
    //     0x53a41c: ubfx            x0, x0, #0xc, #0x14
    // 0x53a420: mov             x1, x2
    // 0x53a424: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x53a424: sub             lr, x0, #0xfc4
    //     0x53a428: ldr             lr, [x21, lr, lsl #3]
    //     0x53a42c: blr             lr
    // 0x53a430: tbnz            w0, #4, #0x53a4c0
    // 0x53a434: ldur            x3, [fp, #-0x30]
    // 0x53a438: ldur            x2, [fp, #-0x20]
    // 0x53a43c: r0 = LoadClassIdInstr(r2)
    //     0x53a43c: ldur            x0, [x2, #-1]
    //     0x53a440: ubfx            x0, x0, #0xc, #0x14
    // 0x53a444: mov             x1, x2
    // 0x53a448: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x53a448: sub             lr, x0, #0xfb6
    //     0x53a44c: ldr             lr, [x21, lr, lsl #3]
    //     0x53a450: blr             lr
    // 0x53a454: ldur            x1, [fp, #-0x30]
    // 0x53a458: mov             x2, x0
    // 0x53a45c: r0 = _getValueOrData()
    //     0x53a45c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53a460: mov             x1, x0
    // 0x53a464: ldur            x0, [fp, #-0x30]
    // 0x53a468: LoadField: r2 = r0->field_f
    //     0x53a468: ldur            w2, [x0, #0xf]
    // 0x53a46c: DecompressPointer r2
    //     0x53a46c: add             x2, x2, HEAP, lsl #32
    // 0x53a470: cmp             w2, w1
    // 0x53a474: b.ne            #0x53a47c
    // 0x53a478: r1 = Null
    //     0x53a478: mov             x1, NULL
    // 0x53a47c: cmp             w1, NULL
    // 0x53a480: b.eq            #0x53a4b0
    // 0x53a484: ldur            x3, [fp, #-8]
    // 0x53a488: LoadField: r2 = r1->field_7
    //     0x53a488: ldur            w2, [x1, #7]
    // 0x53a48c: DecompressPointer r2
    //     0x53a48c: add             x2, x2, HEAP, lsl #32
    // 0x53a490: LoadField: d0 = r3->field_7
    //     0x53a490: ldur            d0, [x3, #7]
    // 0x53a494: LoadField: d1 = r2->field_7
    //     0x53a494: ldur            d1, [x2, #7]
    // 0x53a498: fadd            d2, d0, d1
    // 0x53a49c: mov             v0.16b, v2.16b
    // 0x53a4a0: r1 = Null
    //     0x53a4a0: mov             x1, NULL
    // 0x53a4a4: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53a4a4: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53a4a8: mov             x4, x0
    // 0x53a4ac: b               #0x53a4b8
    // 0x53a4b0: ldur            x3, [fp, #-8]
    // 0x53a4b4: mov             x4, x3
    // 0x53a4b8: ldur            x2, [fp, #-0x20]
    // 0x53a4bc: b               #0x53a404
    // 0x53a4c0: ldur            x0, [fp, #-0x10]
    // 0x53a4c4: ldur            x3, [fp, #-8]
    // 0x53a4c8: LoadField: r1 = r0->field_1f
    //     0x53a4c8: ldur            w1, [x0, #0x1f]
    // 0x53a4cc: DecompressPointer r1
    //     0x53a4cc: add             x1, x1, HEAP, lsl #32
    // 0x53a4d0: cmp             w1, NULL
    // 0x53a4d4: b.ne            #0x53a4e0
    // 0x53a4d8: r2 = 0
    //     0x53a4d8: movz            x2, #0
    // 0x53a4dc: b               #0x53a4e4
    // 0x53a4e0: mov             x2, x1
    // 0x53a4e4: r1 = Null
    //     0x53a4e4: mov             x1, NULL
    // 0x53a4e8: r0 = CustomNum()
    //     0x53a4e8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x53a4ec: ldur            x1, [fp, #-8]
    // 0x53a4f0: stur            x0, [fp, #-8]
    // 0x53a4f4: r0 = invert()
    //     0x53a4f4: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x53a4f8: ldur            x1, [fp, #-8]
    // 0x53a4fc: mov             x2, x0
    // 0x53a500: r0 = mult2()
    //     0x53a500: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x53a504: LeaveFrame
    //     0x53a504: mov             SP, fp
    //     0x53a508: ldp             fp, lr, [SP], #0x10
    // 0x53a50c: ret
    //     0x53a50c: ret             
    // 0x53a510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53a510: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53a514: b               #0x53a2c8
    // 0x53a518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53a518: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53a51c: b               #0x53a418
  }
}
