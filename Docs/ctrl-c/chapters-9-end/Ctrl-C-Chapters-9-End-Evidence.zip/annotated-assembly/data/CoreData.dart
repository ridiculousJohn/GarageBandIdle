// lib: , url: package:pretentious/data/CoreData.dart

// class id: 1049470, size: 0x8
class :: {

  static late CoreData coreData; // offset: 0xf7c
  static late Map<String, CustomNum> referenceDifficulties; // offset: 0xf84

  static Future<void> saveCoreData() {
    // ** addr: 0x452554, size: 0xb0
    // 0x452554: EnterFrame
    //     0x452554: stp             fp, lr, [SP, #-0x10]!
    //     0x452558: mov             fp, SP
    // 0x45255c: AllocStack(0x10)
    //     0x45255c: sub             SP, SP, #0x10
    // 0x452560: CheckStackOverflow
    //     0x452560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x452564: cmp             SP, x16
    //     0x452568: b.ls            #0x4525f0
    // 0x45256c: r0 = LoadStaticField(0xf7c)
    //     0x45256c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x452570: ldr             x0, [x0, #0x1ef8]
    // 0x452574: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x452578: cmp             w0, w16
    // 0x45257c: b.eq            #0x4525f8
    // 0x452580: mov             x1, x0
    // 0x452584: r0 = toMap()
    //     0x452584: bl              #0x452604  ; [package:pretentious/data/CoreData.dart] CoreData::toMap
    // 0x452588: mov             x2, x0
    // 0x45258c: r1 = Instance_BinaryCodec
    //     0x45258c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb80] Obj!BinaryCodec@85e381
    //     0x452590: ldr             x1, [x1, #0xb80]
    // 0x452594: r0 = encode()
    //     0x452594: bl              #0x370294  ; [dart:convert] Codec::encode
    // 0x452598: r1 = Function '<anonymous closure>': static.
    //     0x452598: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4d0] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x45259c: ldr             x1, [x1, #0x4d0]
    // 0x4525a0: r2 = Null
    //     0x4525a0: mov             x2, NULL
    // 0x4525a4: stur            x0, [fp, #-8]
    // 0x4525a8: r0 = AllocateClosure()
    //     0x4525a8: bl              #0x826750  ; AllocateClosureStub
    // 0x4525ac: r1 = Function '<anonymous closure>': static.
    //     0x4525ac: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4d8] Function: [dart:ui] Shader::Shader._ (0x81c9dc)
    //     0x4525b0: ldr             x1, [x1, #0x4d8]
    // 0x4525b4: r2 = Null
    //     0x4525b4: mov             x2, NULL
    // 0x4525b8: stur            x0, [fp, #-0x10]
    // 0x4525bc: r0 = AllocateClosure()
    //     0x4525bc: bl              #0x826750  ; AllocateClosureStub
    // 0x4525c0: ldur            x2, [fp, #-8]
    // 0x4525c4: ldur            x3, [fp, #-0x10]
    // 0x4525c8: mov             x5, x0
    // 0x4525cc: r1 = "CoreData1"
    //     0x4525cc: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4e0] "CoreData1"
    //     0x4525d0: ldr             x1, [x1, #0x4e0]
    // 0x4525d4: r6 = "CoreData2"
    //     0x4525d4: add             x6, PP, #0xf, lsl #12  ; [pp+0xf4e8] "CoreData2"
    //     0x4525d8: ldr             x6, [x6, #0x4e8]
    // 0x4525dc: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x4525dc: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x4525e0: r0 = saveToFile()
    //     0x4525e0: bl              #0x353220  ; [package:custom_tools/SaveLoadManager.dart] ::saveToFile
    // 0x4525e4: LeaveFrame
    //     0x4525e4: mov             SP, fp
    //     0x4525e8: ldp             fp, lr, [SP], #0x10
    // 0x4525ec: ret
    //     0x4525ec: ret             
    // 0x4525f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4525f0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4525f4: b               #0x45256c
    // 0x4525f8: r9 = coreData
    //     0x4525f8: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x4525fc: ldr             x9, [x9, #0x530]
    // 0x452600: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x452600: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static Map<String, CustomNum> referenceDifficulties() {
    // ** addr: 0x461580, size: 0x468
    // 0x461580: EnterFrame
    //     0x461580: stp             fp, lr, [SP, #-0x10]!
    //     0x461584: mov             fp, SP
    // 0x461588: AllocStack(0x18)
    //     0x461588: sub             SP, SP, #0x18
    // 0x46158c: CheckStackOverflow
    //     0x46158c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x461590: cmp             SP, x16
    //     0x461594: b.ls            #0x4619e0
    // 0x461598: r1 = Null
    //     0x461598: mov             x1, NULL
    // 0x46159c: r2 = 68
    //     0x46159c: movz            x2, #0x44
    // 0x4615a0: r0 = AllocateArray()
    //     0x4615a0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4615a4: stur            x0, [fp, #-8]
    // 0x4615a8: r16 = "1"
    //     0x4615a8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x4615ac: ldr             x16, [x16, #0x9c8]
    // 0x4615b0: StoreField: r0->field_f = r16
    //     0x4615b0: stur            w16, [x0, #0xf]
    // 0x4615b4: r16 = Instance_CustomNum
    //     0x4615b4: add             x16, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x4615b8: ldr             x16, [x16, #0xa70]
    // 0x4615bc: StoreField: r0->field_13 = r16
    //     0x4615bc: stur            w16, [x0, #0x13]
    // 0x4615c0: r16 = "2"
    //     0x4615c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x4615c4: ldr             x16, [x16, #0x2e0]
    // 0x4615c8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4615c8: stur            w16, [x0, #0x17]
    // 0x4615cc: r16 = Instance_CustomNum
    //     0x4615cc: add             x16, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x4615d0: ldr             x16, [x16, #0xa70]
    // 0x4615d4: StoreField: r0->field_1b = r16
    //     0x4615d4: stur            w16, [x0, #0x1b]
    // 0x4615d8: r16 = "3"
    //     0x4615d8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4615dc: ldr             x16, [x16, #0x2f0]
    // 0x4615e0: StoreField: r0->field_1f = r16
    //     0x4615e0: stur            w16, [x0, #0x1f]
    // 0x4615e4: r16 = Instance_CustomNum
    //     0x4615e4: add             x16, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x4615e8: ldr             x16, [x16, #0xa70]
    // 0x4615ec: StoreField: r0->field_23 = r16
    //     0x4615ec: stur            w16, [x0, #0x23]
    // 0x4615f0: r16 = "4"
    //     0x4615f0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x4615f4: ldr             x16, [x16, #0x2f8]
    // 0x4615f8: StoreField: r0->field_27 = r16
    //     0x4615f8: stur            w16, [x0, #0x27]
    // 0x4615fc: r1 = Null
    //     0x4615fc: mov             x1, NULL
    // 0x461600: r2 = 1.386000
    //     0x461600: add             x2, PP, #0x10, lsl #12  ; [pp+0x10cf8] 1.386
    //     0x461604: ldr             x2, [x2, #0xcf8]
    // 0x461608: r0 = CustomNum()
    //     0x461608: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46160c: ldur            x1, [fp, #-8]
    // 0x461610: ArrayStore: r1[7] = r0  ; List_4
    //     0x461610: add             x25, x1, #0x2b
    //     0x461614: str             w0, [x25]
    //     0x461618: tbz             w0, #0, #0x461634
    //     0x46161c: ldurb           w16, [x1, #-1]
    //     0x461620: ldurb           w17, [x0, #-1]
    //     0x461624: and             x16, x17, x16, lsr #2
    //     0x461628: tst             x16, HEAP, lsr #32
    //     0x46162c: b.eq            #0x461634
    //     0x461630: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461634: ldur            x0, [fp, #-8]
    // 0x461638: r16 = "5"
    //     0x461638: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x46163c: ldr             x16, [x16, #0x300]
    // 0x461640: StoreField: r0->field_2f = r16
    //     0x461640: stur            w16, [x0, #0x2f]
    // 0x461644: r1 = Null
    //     0x461644: mov             x1, NULL
    // 0x461648: r2 = 1.871000
    //     0x461648: add             x2, PP, #0x10, lsl #12  ; [pp+0x10d00] 1.871
    //     0x46164c: ldr             x2, [x2, #0xd00]
    // 0x461650: r0 = CustomNum()
    //     0x461650: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461654: ldur            x1, [fp, #-8]
    // 0x461658: ArrayStore: r1[9] = r0  ; List_4
    //     0x461658: add             x25, x1, #0x33
    //     0x46165c: str             w0, [x25]
    //     0x461660: tbz             w0, #0, #0x46167c
    //     0x461664: ldurb           w16, [x1, #-1]
    //     0x461668: ldurb           w17, [x0, #-1]
    //     0x46166c: and             x16, x17, x16, lsr #2
    //     0x461670: tst             x16, HEAP, lsr #32
    //     0x461674: b.eq            #0x46167c
    //     0x461678: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46167c: ldur            x0, [fp, #-8]
    // 0x461680: r16 = "6"
    //     0x461680: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x461684: ldr             x16, [x16, #0x308]
    // 0x461688: StoreField: r0->field_37 = r16
    //     0x461688: stur            w16, [x0, #0x37]
    // 0x46168c: r1 = Null
    //     0x46168c: mov             x1, NULL
    // 0x461690: r2 = 2.993760
    //     0x461690: add             x2, PP, #0x10, lsl #12  ; [pp+0x10d08] 2.99376
    //     0x461694: ldr             x2, [x2, #0xd08]
    // 0x461698: r0 = CustomNum()
    //     0x461698: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46169c: ldur            x1, [fp, #-8]
    // 0x4616a0: ArrayStore: r1[11] = r0  ; List_4
    //     0x4616a0: add             x25, x1, #0x3b
    //     0x4616a4: str             w0, [x25]
    //     0x4616a8: tbz             w0, #0, #0x4616c4
    //     0x4616ac: ldurb           w16, [x1, #-1]
    //     0x4616b0: ldurb           w17, [x0, #-1]
    //     0x4616b4: and             x16, x17, x16, lsr #2
    //     0x4616b8: tst             x16, HEAP, lsr #32
    //     0x4616bc: b.eq            #0x4616c4
    //     0x4616c0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4616c4: ldur            x0, [fp, #-8]
    // 0x4616c8: r16 = "7"
    //     0x4616c8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x4616cc: ldr             x16, [x16, #0x310]
    // 0x4616d0: StoreField: r0->field_3f = r16
    //     0x4616d0: stur            w16, [x0, #0x3f]
    // 0x4616d4: r1 = Null
    //     0x4616d4: mov             x1, NULL
    // 0x4616d8: r2 = 4
    //     0x4616d8: movz            x2, #0x4
    // 0x4616dc: r0 = CustomNum()
    //     0x4616dc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4616e0: ldur            x1, [fp, #-8]
    // 0x4616e4: ArrayStore: r1[13] = r0  ; List_4
    //     0x4616e4: add             x25, x1, #0x43
    //     0x4616e8: str             w0, [x25]
    //     0x4616ec: tbz             w0, #0, #0x461708
    //     0x4616f0: ldurb           w16, [x1, #-1]
    //     0x4616f4: ldurb           w17, [x0, #-1]
    //     0x4616f8: and             x16, x17, x16, lsr #2
    //     0x4616fc: tst             x16, HEAP, lsr #32
    //     0x461700: b.eq            #0x461708
    //     0x461704: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461708: ldur            x0, [fp, #-8]
    // 0x46170c: r16 = "8"
    //     0x46170c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x461710: ldr             x16, [x16, #0x318]
    // 0x461714: StoreField: r0->field_47 = r16
    //     0x461714: stur            w16, [x0, #0x47]
    // 0x461718: r1 = Null
    //     0x461718: mov             x1, NULL
    // 0x46171c: r2 = 4.027088
    //     0x46171c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10d10] 4.02708796875
    //     0x461720: ldr             x2, [x2, #0xd10]
    // 0x461724: r0 = CustomNum()
    //     0x461724: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461728: ldur            x1, [fp, #-8]
    // 0x46172c: ArrayStore: r1[15] = r0  ; List_4
    //     0x46172c: add             x25, x1, #0x4b
    //     0x461730: str             w0, [x25]
    //     0x461734: tbz             w0, #0, #0x461750
    //     0x461738: ldurb           w16, [x1, #-1]
    //     0x46173c: ldurb           w17, [x0, #-1]
    //     0x461740: and             x16, x17, x16, lsr #2
    //     0x461744: tst             x16, HEAP, lsr #32
    //     0x461748: b.eq            #0x461750
    //     0x46174c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461750: ldur            x0, [fp, #-8]
    // 0x461754: r16 = "9"
    //     0x461754: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x461758: ldr             x16, [x16, #0x320]
    // 0x46175c: StoreField: r0->field_4f = r16
    //     0x46175c: stur            w16, [x0, #0x4f]
    // 0x461760: r1 = Null
    //     0x461760: mov             x1, NULL
    // 0x461764: r2 = 12
    //     0x461764: movz            x2, #0xc
    // 0x461768: r0 = CustomNum()
    //     0x461768: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x46176c: ldur            x1, [fp, #-8]
    // 0x461770: ArrayStore: r1[17] = r0  ; List_4
    //     0x461770: add             x25, x1, #0x53
    //     0x461774: str             w0, [x25]
    //     0x461778: tbz             w0, #0, #0x461794
    //     0x46177c: ldurb           w16, [x1, #-1]
    //     0x461780: ldurb           w17, [x0, #-1]
    //     0x461784: and             x16, x17, x16, lsr #2
    //     0x461788: tst             x16, HEAP, lsr #32
    //     0x46178c: b.eq            #0x461794
    //     0x461790: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461794: ldur            x0, [fp, #-8]
    // 0x461798: r16 = "10"
    //     0x461798: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x46179c: ldr             x16, [x16, #0x9d0]
    // 0x4617a0: StoreField: r0->field_57 = r16
    //     0x4617a0: stur            w16, [x0, #0x57]
    // 0x4617a4: r1 = Null
    //     0x4617a4: mov             x1, NULL
    // 0x4617a8: r2 = 18
    //     0x4617a8: movz            x2, #0x12
    // 0x4617ac: r0 = CustomNum()
    //     0x4617ac: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4617b0: ldur            x1, [fp, #-8]
    // 0x4617b4: ArrayStore: r1[19] = r0  ; List_4
    //     0x4617b4: add             x25, x1, #0x5b
    //     0x4617b8: str             w0, [x25]
    //     0x4617bc: tbz             w0, #0, #0x4617d8
    //     0x4617c0: ldurb           w16, [x1, #-1]
    //     0x4617c4: ldurb           w17, [x0, #-1]
    //     0x4617c8: and             x16, x17, x16, lsr #2
    //     0x4617cc: tst             x16, HEAP, lsr #32
    //     0x4617d0: b.eq            #0x4617d8
    //     0x4617d4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4617d8: ldur            x0, [fp, #-8]
    // 0x4617dc: r16 = "11"
    //     0x4617dc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x4617e0: ldr             x16, [x16, #0x328]
    // 0x4617e4: StoreField: r0->field_5f = r16
    //     0x4617e4: stur            w16, [x0, #0x5f]
    // 0x4617e8: r1 = Null
    //     0x4617e8: mov             x1, NULL
    // 0x4617ec: r2 = 13.500000
    //     0x4617ec: add             x2, PP, #0x10, lsl #12  ; [pp+0x10d18] 13.5
    //     0x4617f0: ldr             x2, [x2, #0xd18]
    // 0x4617f4: r0 = CustomNum()
    //     0x4617f4: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4617f8: ldur            x1, [fp, #-8]
    // 0x4617fc: ArrayStore: r1[21] = r0  ; List_4
    //     0x4617fc: add             x25, x1, #0x63
    //     0x461800: str             w0, [x25]
    //     0x461804: tbz             w0, #0, #0x461820
    //     0x461808: ldurb           w16, [x1, #-1]
    //     0x46180c: ldurb           w17, [x0, #-1]
    //     0x461810: and             x16, x17, x16, lsr #2
    //     0x461814: tst             x16, HEAP, lsr #32
    //     0x461818: b.eq            #0x461820
    //     0x46181c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461820: ldur            x0, [fp, #-8]
    // 0x461824: r16 = "12"
    //     0x461824: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x461828: ldr             x16, [x16, #0x330]
    // 0x46182c: StoreField: r0->field_67 = r16
    //     0x46182c: stur            w16, [x0, #0x67]
    // 0x461830: r1 = Null
    //     0x461830: mov             x1, NULL
    // 0x461834: r2 = 20.250000
    //     0x461834: add             x2, PP, #0x10, lsl #12  ; [pp+0x10d20] 20.25
    //     0x461838: ldr             x2, [x2, #0xd20]
    // 0x46183c: r0 = CustomNum()
    //     0x46183c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461840: ldur            x1, [fp, #-8]
    // 0x461844: ArrayStore: r1[23] = r0  ; List_4
    //     0x461844: add             x25, x1, #0x6b
    //     0x461848: str             w0, [x25]
    //     0x46184c: tbz             w0, #0, #0x461868
    //     0x461850: ldurb           w16, [x1, #-1]
    //     0x461854: ldurb           w17, [x0, #-1]
    //     0x461858: and             x16, x17, x16, lsr #2
    //     0x46185c: tst             x16, HEAP, lsr #32
    //     0x461860: b.eq            #0x461868
    //     0x461864: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461868: ldur            x0, [fp, #-8]
    // 0x46186c: r16 = "13"
    //     0x46186c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x461870: ldr             x16, [x16, #0x338]
    // 0x461874: StoreField: r0->field_6f = r16
    //     0x461874: stur            w16, [x0, #0x6f]
    // 0x461878: r1 = Null
    //     0x461878: mov             x1, NULL
    // 0x46187c: r2 = 40.500000
    //     0x46187c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10d28] 40.5
    //     0x461880: ldr             x2, [x2, #0xd28]
    // 0x461884: r0 = CustomNum()
    //     0x461884: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461888: ldur            x1, [fp, #-8]
    // 0x46188c: ArrayStore: r1[25] = r0  ; List_4
    //     0x46188c: add             x25, x1, #0x73
    //     0x461890: str             w0, [x25]
    //     0x461894: tbz             w0, #0, #0x4618b0
    //     0x461898: ldurb           w16, [x1, #-1]
    //     0x46189c: ldurb           w17, [x0, #-1]
    //     0x4618a0: and             x16, x17, x16, lsr #2
    //     0x4618a4: tst             x16, HEAP, lsr #32
    //     0x4618a8: b.eq            #0x4618b0
    //     0x4618ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4618b0: ldur            x0, [fp, #-8]
    // 0x4618b4: r16 = "14"
    //     0x4618b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x4618b8: ldr             x16, [x16, #0x340]
    // 0x4618bc: StoreField: r0->field_77 = r16
    //     0x4618bc: stur            w16, [x0, #0x77]
    // 0x4618c0: r1 = Null
    //     0x4618c0: mov             x1, NULL
    // 0x4618c4: r2 = 162
    //     0x4618c4: movz            x2, #0xa2
    // 0x4618c8: r0 = CustomNum()
    //     0x4618c8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x4618cc: ldur            x1, [fp, #-8]
    // 0x4618d0: ArrayStore: r1[27] = r0  ; List_4
    //     0x4618d0: add             x25, x1, #0x7b
    //     0x4618d4: str             w0, [x25]
    //     0x4618d8: tbz             w0, #0, #0x4618f4
    //     0x4618dc: ldurb           w16, [x1, #-1]
    //     0x4618e0: ldurb           w17, [x0, #-1]
    //     0x4618e4: and             x16, x17, x16, lsr #2
    //     0x4618e8: tst             x16, HEAP, lsr #32
    //     0x4618ec: b.eq            #0x4618f4
    //     0x4618f0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4618f4: ldur            x0, [fp, #-8]
    // 0x4618f8: r16 = "15"
    //     0x4618f8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x4618fc: ldr             x16, [x16, #0x348]
    // 0x461900: StoreField: r0->field_7f = r16
    //     0x461900: stur            w16, [x0, #0x7f]
    // 0x461904: r1 = Null
    //     0x461904: mov             x1, NULL
    // 0x461908: r2 = 486
    //     0x461908: movz            x2, #0x1e6
    // 0x46190c: r0 = CustomNum()
    //     0x46190c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461910: ldur            x1, [fp, #-8]
    // 0x461914: ArrayStore: r1[29] = r0  ; List_4
    //     0x461914: add             x25, x1, #0x83
    //     0x461918: str             w0, [x25]
    //     0x46191c: tbz             w0, #0, #0x461938
    //     0x461920: ldurb           w16, [x1, #-1]
    //     0x461924: ldurb           w17, [x0, #-1]
    //     0x461928: and             x16, x17, x16, lsr #2
    //     0x46192c: tst             x16, HEAP, lsr #32
    //     0x461930: b.eq            #0x461938
    //     0x461934: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x461938: ldur            x0, [fp, #-8]
    // 0x46193c: r16 = "16"
    //     0x46193c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x461940: ldr             x16, [x16, #0x350]
    // 0x461944: StoreField: r0->field_87 = r16
    //     0x461944: stur            w16, [x0, #0x87]
    // 0x461948: r1 = Null
    //     0x461948: mov             x1, NULL
    // 0x46194c: r2 = 1944
    //     0x46194c: movz            x2, #0x798
    // 0x461950: r0 = CustomNum()
    //     0x461950: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461954: ldur            x1, [fp, #-8]
    // 0x461958: ArrayStore: r1[31] = r0  ; List_4
    //     0x461958: add             x25, x1, #0x8b
    //     0x46195c: str             w0, [x25]
    //     0x461960: tbz             w0, #0, #0x46197c
    //     0x461964: ldurb           w16, [x1, #-1]
    //     0x461968: ldurb           w17, [x0, #-1]
    //     0x46196c: and             x16, x17, x16, lsr #2
    //     0x461970: tst             x16, HEAP, lsr #32
    //     0x461974: b.eq            #0x46197c
    //     0x461978: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x46197c: ldur            x0, [fp, #-8]
    // 0x461980: r16 = "17"
    //     0x461980: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x461984: ldr             x16, [x16, #0x358]
    // 0x461988: StoreField: r0->field_8f = r16
    //     0x461988: stur            w16, [x0, #0x8f]
    // 0x46198c: r1 = Null
    //     0x46198c: mov             x1, NULL
    // 0x461990: r2 = 9720
    //     0x461990: movz            x2, #0x25f8
    // 0x461994: r0 = CustomNum()
    //     0x461994: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461998: ldur            x1, [fp, #-8]
    // 0x46199c: ArrayStore: r1[33] = r0  ; List_4
    //     0x46199c: add             x25, x1, #0x93
    //     0x4619a0: str             w0, [x25]
    //     0x4619a4: tbz             w0, #0, #0x4619c0
    //     0x4619a8: ldurb           w16, [x1, #-1]
    //     0x4619ac: ldurb           w17, [x0, #-1]
    //     0x4619b0: and             x16, x17, x16, lsr #2
    //     0x4619b4: tst             x16, HEAP, lsr #32
    //     0x4619b8: b.eq            #0x4619c0
    //     0x4619bc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4619c0: r16 = <String, CustomNum>
    //     0x4619c0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10d30] TypeArguments: <String, CustomNum>
    //     0x4619c4: ldr             x16, [x16, #0xd30]
    // 0x4619c8: ldur            lr, [fp, #-8]
    // 0x4619cc: stp             lr, x16, [SP]
    // 0x4619d0: r0 = Map._fromLiteral()
    //     0x4619d0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4619d4: LeaveFrame
    //     0x4619d4: mov             SP, fp
    //     0x4619d8: ldp             fp, lr, [SP], #0x10
    // 0x4619dc: ret
    //     0x4619dc: ret             
    // 0x4619e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4619e0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4619e4: b               #0x461598
  }
  static Future<void> deferredSaveCoreData() async {
    // ** addr: 0x46268c, size: 0x130
    // 0x46268c: EnterFrame
    //     0x46268c: stp             fp, lr, [SP, #-0x10]!
    //     0x462690: mov             fp, SP
    // 0x462694: AllocStack(0x28)
    //     0x462694: sub             SP, SP, #0x28
    // 0x462698: SetupParameters()
    //     0x462698: stur            NULL, [fp, #-8]
    // 0x46269c: CheckStackOverflow
    //     0x46269c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4626a0: cmp             SP, x16
    //     0x4626a4: b.ls            #0x4627b4
    // 0x4626a8: InitAsync() -> Future<void?>
    //     0x4626a8: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x4626ac: bl              #0x34b9a0  ; InitAsyncStub
    // 0x4626b0: r0 = _getCurrentMicros()
    //     0x4626b0: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x4626b4: r1 = LoadInt32Instr(r0)
    //     0x4626b4: sbfx            x1, x0, #1, #0x1f
    //     0x4626b8: tbz             w0, #0, #0x4626c0
    //     0x4626bc: ldur            x1, [x0, #7]
    // 0x4626c0: tbz             x1, #0x3f, #0x4626cc
    // 0x4626c4: r2 = 999
    //     0x4626c4: movz            x2, #0x3e7
    // 0x4626c8: b               #0x4626d0
    // 0x4626cc: r2 = 0
    //     0x4626cc: movz            x2, #0
    // 0x4626d0: r0 = 1000
    //     0x4626d0: movz            x0, #0x3e8
    // 0x4626d4: sub             x3, x1, x2
    // 0x4626d8: sdiv            x4, x3, x0
    // 0x4626dc: stur            x4, [fp, #-0x18]
    // 0x4626e0: r0 = BoxInt64Instr(r4)
    //     0x4626e0: sbfiz           x0, x4, #1, #0x1f
    //     0x4626e4: cmp             x4, x0, asr #1
    //     0x4626e8: b.eq            #0x4626f4
    //     0x4626ec: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4626f0: stur            x4, [x0, #7]
    // 0x4626f4: mov             x2, x0
    // 0x4626f8: stur            x0, [fp, #-0x10]
    // 0x4626fc: StoreStaticField(0xf80, r2)
    //     0x4626fc: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x462700: str             x2, [x1, #0x1f00]
    // 0x462704: r1 = <void?>
    //     0x462704: ldr             x1, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    // 0x462708: r2 = Instance_Duration
    //     0x462708: ldr             x2, [PP, #0x2ce0]  ; [pp+0x2ce0] Obj!Duration@866101
    // 0x46270c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x46270c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x462710: r0 = Future.delayed()
    //     0x462710: bl              #0x35dfd4  ; [dart:async] Future::Future.delayed
    // 0x462714: mov             x1, x0
    // 0x462718: stur            x1, [fp, #-0x20]
    // 0x46271c: r0 = Await()
    //     0x46271c: bl              #0x34b75c  ; AwaitStub
    // 0x462720: r0 = LoadStaticField(0xf80)
    //     0x462720: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x462724: ldr             x0, [x0, #0x1f00]
    // 0x462728: ldur            x1, [fp, #-0x10]
    // 0x46272c: cmp             w1, w0
    // 0x462730: b.eq            #0x46276c
    // 0x462734: and             w16, w1, w0
    // 0x462738: branchIfSmi(r16, 0x4627ac)
    //     0x462738: tbz             w16, #0, #0x4627ac
    // 0x46273c: r16 = LoadClassIdInstr(r1)
    //     0x46273c: ldur            x16, [x1, #-1]
    //     0x462740: ubfx            x16, x16, #0xc, #0x14
    // 0x462744: cmp             x16, #0x3d
    // 0x462748: b.ne            #0x4627ac
    // 0x46274c: r16 = LoadClassIdInstr(r0)
    //     0x46274c: ldur            x16, [x0, #-1]
    //     0x462750: ubfx            x16, x16, #0xc, #0x14
    // 0x462754: cmp             x16, #0x3d
    // 0x462758: b.ne            #0x4627ac
    // 0x46275c: LoadField: r16 = r1->field_7
    //     0x46275c: ldur            x16, [x1, #7]
    // 0x462760: LoadField: r17 = r0->field_7
    //     0x462760: ldur            x17, [x0, #7]
    // 0x462764: cmp             x16, x17
    // 0x462768: b.ne            #0x4627ac
    // 0x46276c: r0 = LoadStaticField(0x750)
    //     0x46276c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x462770: ldr             x0, [x0, #0xea0]
    // 0x462774: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x462778: cmp             w0, w16
    // 0x46277c: b.ne            #0x462788
    // 0x462780: r2 = debugPrint
    //     0x462780: ldr             x2, [PP, #0x2240]  ; [pp+0x2240] Field <::.debugPrint>: static late (offset: 0x750)
    // 0x462784: r0 = InitLateStaticField()
    //     0x462784: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x462788: str             NULL, [SP]
    // 0x46278c: r1 = "Saving core data"
    //     0x46278c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10de0] "Saving core data"
    //     0x462790: ldr             x1, [x1, #0xde0]
    // 0x462794: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x462794: ldr             x4, [PP, #0x2260]  ; [pp+0x2260] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x462798: r0 = debugPrintThrottled()
    //     0x462798: bl              #0x370404  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x46279c: r0 = saveCoreData()
    //     0x46279c: bl              #0x452554  ; [package:pretentious/data/CoreData.dart] ::saveCoreData
    // 0x4627a0: mov             x1, x0
    // 0x4627a4: stur            x1, [fp, #-0x10]
    // 0x4627a8: r0 = Await()
    //     0x4627a8: bl              #0x34b75c  ; AwaitStub
    // 0x4627ac: r0 = Null
    //     0x4627ac: mov             x0, NULL
    // 0x4627b0: r0 = ReturnAsyncNotFuture()
    //     0x4627b0: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x4627b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4627b4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4627b8: b               #0x4626a8
  }
  static Future<void> initCoreData() async {
    // ** addr: 0x47fb70, size: 0x4c4
    // 0x47fb70: EnterFrame
    //     0x47fb70: stp             fp, lr, [SP, #-0x10]!
    //     0x47fb74: mov             fp, SP
    // 0x47fb78: AllocStack(0x60)
    //     0x47fb78: sub             SP, SP, #0x60
    // 0x47fb7c: SetupParameters()
    //     0x47fb7c: stur            NULL, [fp, #-8]
    // 0x47fb80: CheckStackOverflow
    //     0x47fb80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x47fb84: cmp             SP, x16
    //     0x47fb88: b.ls            #0x48002c
    // 0x47fb8c: InitAsync() -> Future<void?>
    //     0x47fb8c: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x47fb90: bl              #0x34b9a0  ; InitAsyncStub
    // 0x47fb94: r1 = "CoreData1"
    //     0x47fb94: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4e0] "CoreData1"
    //     0x47fb98: ldr             x1, [x1, #0x4e0]
    // 0x47fb9c: r2 = "CoreData3"
    //     0x47fb9c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12830] "CoreData3"
    //     0x47fba0: ldr             x2, [x2, #0x830]
    // 0x47fba4: r3 = Null
    //     0x47fba4: mov             x3, NULL
    // 0x47fba8: r5 = "CoreData2"
    //     0x47fba8: add             x5, PP, #0xf, lsl #12  ; [pp+0xf4e8] "CoreData2"
    //     0x47fbac: ldr             x5, [x5, #0x4e8]
    // 0x47fbb0: r0 = readMostRecentValidSaveFile()
    //     0x47fbb0: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x47fbb4: mov             x1, x0
    // 0x47fbb8: stur            x1, [fp, #-0x10]
    // 0x47fbbc: r0 = Await()
    //     0x47fbbc: bl              #0x34b75c  ; AwaitStub
    // 0x47fbc0: cmp             w0, NULL
    // 0x47fbc4: b.eq            #0x47fbec
    // 0x47fbc8: LoadField: r2 = r0->field_f
    //     0x47fbc8: ldur            w2, [x0, #0xf]
    // 0x47fbcc: DecompressPointer r2
    //     0x47fbcc: add             x2, x2, HEAP, lsl #32
    // 0x47fbd0: r1 = Null
    //     0x47fbd0: mov             x1, NULL
    // 0x47fbd4: r0 = CoreData.fromData()
    //     0x47fbd4: bl              #0x481438  ; [package:pretentious/data/CoreData.dart] CoreData::CoreData.fromData
    // 0x47fbd8: mov             x2, x0
    // 0x47fbdc: StoreStaticField(0xf7c, r2)
    //     0x47fbdc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x47fbe0: str             x2, [x0, #0x1ef8]
    // 0x47fbe4: r0 = Null
    //     0x47fbe4: mov             x0, NULL
    // 0x47fbe8: r0 = ReturnAsyncNotFuture()
    //     0x47fbe8: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x47fbec: r1 = "StoryPoints1"
    //     0x47fbec: add             x1, PP, #0x12, lsl #12  ; [pp+0x12838] "StoryPoints1"
    //     0x47fbf0: ldr             x1, [x1, #0x838]
    // 0x47fbf4: r2 = "StoryPoints3"
    //     0x47fbf4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12840] "StoryPoints3"
    //     0x47fbf8: ldr             x2, [x2, #0x840]
    // 0x47fbfc: r3 = Null
    //     0x47fbfc: mov             x3, NULL
    // 0x47fc00: r5 = "StoryPoints2"
    //     0x47fc00: add             x5, PP, #0x12, lsl #12  ; [pp+0x12848] "StoryPoints2"
    //     0x47fc04: ldr             x5, [x5, #0x848]
    // 0x47fc08: r0 = readMostRecentValidSaveFile()
    //     0x47fc08: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x47fc0c: mov             x1, x0
    // 0x47fc10: stur            x1, [fp, #-0x10]
    // 0x47fc14: r0 = Await()
    //     0x47fc14: bl              #0x34b75c  ; AwaitStub
    // 0x47fc18: stur            x0, [fp, #-0x10]
    // 0x47fc1c: cmp             w0, NULL
    // 0x47fc20: b.eq            #0x47ff1c
    // 0x47fc24: r0 = LoadStaticField(0x750)
    //     0x47fc24: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x47fc28: ldr             x0, [x0, #0xea0]
    // 0x47fc2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x47fc30: cmp             w0, w16
    // 0x47fc34: b.ne            #0x47fc40
    // 0x47fc38: r2 = debugPrint
    //     0x47fc38: ldr             x2, [PP, #0x2240]  ; [pp+0x2240] Field <::.debugPrint>: static late (offset: 0x750)
    // 0x47fc3c: r0 = InitLateStaticField()
    //     0x47fc3c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x47fc40: str             NULL, [SP]
    // 0x47fc44: r1 = "Loading legacy data."
    //     0x47fc44: add             x1, PP, #0x12, lsl #12  ; [pp+0x12850] "Loading legacy data."
    //     0x47fc48: ldr             x1, [x1, #0x850]
    // 0x47fc4c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x47fc4c: ldr             x4, [PP, #0x2260]  ; [pp+0x2260] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x47fc50: r0 = debugPrintThrottled()
    //     0x47fc50: bl              #0x370404  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x47fc54: ldur            x0, [fp, #-0x10]
    // 0x47fc58: LoadField: r3 = r0->field_f
    //     0x47fc58: ldur            w3, [x0, #0xf]
    // 0x47fc5c: DecompressPointer r3
    //     0x47fc5c: add             x3, x3, HEAP, lsl #32
    // 0x47fc60: stur            x3, [fp, #-0x18]
    // 0x47fc64: r0 = LoadClassIdInstr(r3)
    //     0x47fc64: ldur            x0, [x3, #-1]
    //     0x47fc68: ubfx            x0, x0, #0xc, #0x14
    // 0x47fc6c: mov             x1, x3
    // 0x47fc70: r2 = 2
    //     0x47fc70: movz            x2, #0x2
    // 0x47fc74: r0 = GDT[cid_x0 + -0xf99]()
    //     0x47fc74: sub             lr, x0, #0xf99
    //     0x47fc78: ldr             lr, [x21, lr, lsl #3]
    //     0x47fc7c: blr             lr
    // 0x47fc80: tbnz            w0, #4, #0x47fe10
    // 0x47fc84: ldur            x3, [fp, #-0x18]
    // 0x47fc88: r0 = LoadClassIdInstr(r3)
    //     0x47fc88: ldur            x0, [x3, #-1]
    //     0x47fc8c: ubfx            x0, x0, #0xc, #0x14
    // 0x47fc90: mov             x1, x3
    // 0x47fc94: r2 = 2
    //     0x47fc94: movz            x2, #0x2
    // 0x47fc98: r0 = GDT[cid_x0 + -0x1000]()
    //     0x47fc98: sub             lr, x0, #1, lsl #12
    //     0x47fc9c: ldr             lr, [x21, lr, lsl #3]
    //     0x47fca0: blr             lr
    // 0x47fca4: r1 = 60
    //     0x47fca4: movz            x1, #0x3c
    // 0x47fca8: branchIfSmi(r0, 0x47fcb4)
    //     0x47fca8: tbz             w0, #0, #0x47fcb4
    // 0x47fcac: r1 = LoadClassIdInstr(r0)
    //     0x47fcac: ldur            x1, [x0, #-1]
    //     0x47fcb0: ubfx            x1, x1, #0xc, #0x14
    // 0x47fcb4: sub             x16, x1, #0x3c
    // 0x47fcb8: cmp             x16, #1
    // 0x47fcbc: b.ls            #0x47fdfc
    // 0x47fcc0: ldur            x1, [fp, #-0x18]
    // 0x47fcc4: r0 = DateTime()
    //     0x47fcc4: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x47fcc8: mov             x1, x0
    // 0x47fccc: r0 = false
    //     0x47fccc: add             x0, NULL, #0x30  ; false
    // 0x47fcd0: stur            x1, [fp, #-0x10]
    // 0x47fcd4: StoreField: r1->field_7 = r0
    //     0x47fcd4: stur            w0, [x1, #7]
    // 0x47fcd8: r0 = _getCurrentMicros()
    //     0x47fcd8: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x47fcdc: r1 = LoadInt32Instr(r0)
    //     0x47fcdc: sbfx            x1, x0, #1, #0x1f
    //     0x47fce0: tbz             w0, #0, #0x47fce8
    //     0x47fce4: ldur            x1, [x0, #7]
    // 0x47fce8: ldur            x3, [fp, #-0x10]
    // 0x47fcec: StoreField: r3->field_b = r1
    //     0x47fcec: stur            x1, [x3, #0xb]
    // 0x47fcf0: ldur            x1, [fp, #-0x18]
    // 0x47fcf4: r0 = LoadClassIdInstr(r1)
    //     0x47fcf4: ldur            x0, [x1, #-1]
    //     0x47fcf8: ubfx            x0, x0, #0xc, #0x14
    // 0x47fcfc: r2 = 2
    //     0x47fcfc: movz            x2, #0x2
    // 0x47fd00: r0 = GDT[cid_x0 + -0x1000]()
    //     0x47fd00: sub             lr, x0, #1, lsl #12
    //     0x47fd04: ldr             lr, [x21, lr, lsl #3]
    //     0x47fd08: blr             lr
    // 0x47fd0c: mov             x3, x0
    // 0x47fd10: r2 = Null
    //     0x47fd10: mov             x2, NULL
    // 0x47fd14: r1 = Null
    //     0x47fd14: mov             x1, NULL
    // 0x47fd18: stur            x3, [fp, #-0x20]
    // 0x47fd1c: r8 = Map
    //     0x47fd1c: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x47fd20: r3 = Null
    //     0x47fd20: add             x3, PP, #0x12, lsl #12  ; [pp+0x12860] Null
    //     0x47fd24: ldr             x3, [x3, #0x860]
    // 0x47fd28: r0 = Map()
    //     0x47fd28: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x47fd2c: ldur            x2, [fp, #-0x20]
    // 0x47fd30: r1 = <int, int>
    //     0x47fd30: ldr             x1, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x47fd34: r0 = LinkedHashMap.from()
    //     0x47fd34: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x47fd38: stur            x0, [fp, #-0x20]
    // 0x47fd3c: r16 = <String, double>
    //     0x47fd3c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12870] TypeArguments: <String, double>
    //     0x47fd40: ldr             x16, [x16, #0x870]
    // 0x47fd44: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fd48: stp             lr, x16, [SP]
    // 0x47fd4c: r0 = Map._fromLiteral()
    //     0x47fd4c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fd50: stur            x0, [fp, #-0x28]
    // 0x47fd54: r16 = <String, String>
    //     0x47fd54: ldr             x16, [PP, #0x2c48]  ; [pp+0x2c48] TypeArguments: <String, String>
    // 0x47fd58: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fd5c: stp             lr, x16, [SP]
    // 0x47fd60: r0 = Map._fromLiteral()
    //     0x47fd60: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fd64: stur            x0, [fp, #-0x30]
    // 0x47fd68: r16 = <String, int>
    //     0x47fd68: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x47fd6c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fd70: stp             lr, x16, [SP]
    // 0x47fd74: r0 = Map._fromLiteral()
    //     0x47fd74: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fd78: r1 = <int>
    //     0x47fd78: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x47fd7c: stur            x0, [fp, #-0x38]
    // 0x47fd80: r0 = _Set()
    //     0x47fd80: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x47fd84: r2 = _Uint32List
    //     0x47fd84: ldr             x2, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x47fd88: stur            x0, [fp, #-0x40]
    // 0x47fd8c: StoreField: r0->field_1b = r2
    //     0x47fd8c: stur            w2, [x0, #0x1b]
    // 0x47fd90: StoreField: r0->field_b = rZR
    //     0x47fd90: stur            wzr, [x0, #0xb]
    // 0x47fd94: r3 = const []
    //     0x47fd94: ldr             x3, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x47fd98: StoreField: r0->field_f = r3
    //     0x47fd98: stur            w3, [x0, #0xf]
    // 0x47fd9c: StoreField: r0->field_13 = rZR
    //     0x47fd9c: stur            wzr, [x0, #0x13]
    // 0x47fda0: ArrayStore: r0[0] = rZR  ; List_4
    //     0x47fda0: stur            wzr, [x0, #0x17]
    // 0x47fda4: r16 = <String, int>
    //     0x47fda4: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x47fda8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fdac: stp             lr, x16, [SP]
    // 0x47fdb0: r0 = Map._fromLiteral()
    //     0x47fdb0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fdb4: stur            x0, [fp, #-0x48]
    // 0x47fdb8: r0 = CoreData()
    //     0x47fdb8: bl              #0x48142c  ; AllocateCoreDataStub -> CoreData (size=0x2c)
    // 0x47fdbc: stur            x0, [fp, #-0x50]
    // 0x47fdc0: ldur            x16, [fp, #-0x40]
    // 0x47fdc4: ldur            lr, [fp, #-0x48]
    // 0x47fdc8: stp             lr, x16, [SP]
    // 0x47fdcc: mov             x1, x0
    // 0x47fdd0: ldur            x2, [fp, #-0x10]
    // 0x47fdd4: ldur            x3, [fp, #-0x20]
    // 0x47fdd8: ldur            x5, [fp, #-0x28]
    // 0x47fddc: ldur            x6, [fp, #-0x30]
    // 0x47fde0: ldur            x7, [fp, #-0x38]
    // 0x47fde4: r0 = CoreData()
    //     0x47fde4: bl              #0x480034  ; [package:pretentious/data/CoreData.dart] CoreData::CoreData
    // 0x47fde8: ldur            x2, [fp, #-0x50]
    // 0x47fdec: StoreStaticField(0xf7c, r2)
    //     0x47fdec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x47fdf0: str             x2, [x0, #0x1ef8]
    // 0x47fdf4: r0 = Null
    //     0x47fdf4: mov             x0, NULL
    // 0x47fdf8: r0 = ReturnAsyncNotFuture()
    //     0x47fdf8: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x47fdfc: ldur            x1, [fp, #-0x18]
    // 0x47fe00: r0 = false
    //     0x47fe00: add             x0, NULL, #0x30  ; false
    // 0x47fe04: r2 = _Uint32List
    //     0x47fe04: ldr             x2, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x47fe08: r3 = const []
    //     0x47fe08: ldr             x3, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x47fe0c: b               #0x47fe20
    // 0x47fe10: ldur            x1, [fp, #-0x18]
    // 0x47fe14: r0 = false
    //     0x47fe14: add             x0, NULL, #0x30  ; false
    // 0x47fe18: r2 = _Uint32List
    //     0x47fe18: ldr             x2, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x47fe1c: r3 = const []
    //     0x47fe1c: ldr             x3, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x47fe20: r0 = DateTime()
    //     0x47fe20: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x47fe24: mov             x1, x0
    // 0x47fe28: r0 = false
    //     0x47fe28: add             x0, NULL, #0x30  ; false
    // 0x47fe2c: stur            x1, [fp, #-0x10]
    // 0x47fe30: StoreField: r1->field_7 = r0
    //     0x47fe30: stur            w0, [x1, #7]
    // 0x47fe34: r0 = _getCurrentMicros()
    //     0x47fe34: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x47fe38: r1 = LoadInt32Instr(r0)
    //     0x47fe38: sbfx            x1, x0, #1, #0x1f
    //     0x47fe3c: tbz             w0, #0, #0x47fe44
    //     0x47fe40: ldur            x1, [x0, #7]
    // 0x47fe44: ldur            x0, [fp, #-0x10]
    // 0x47fe48: StoreField: r0->field_b = r1
    //     0x47fe48: stur            x1, [x0, #0xb]
    // 0x47fe4c: ldur            x2, [fp, #-0x18]
    // 0x47fe50: r1 = <int, int>
    //     0x47fe50: ldr             x1, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x47fe54: r0 = LinkedHashMap.from()
    //     0x47fe54: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x47fe58: stur            x0, [fp, #-0x18]
    // 0x47fe5c: r16 = <String, double>
    //     0x47fe5c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12870] TypeArguments: <String, double>
    //     0x47fe60: ldr             x16, [x16, #0x870]
    // 0x47fe64: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fe68: stp             lr, x16, [SP]
    // 0x47fe6c: r0 = Map._fromLiteral()
    //     0x47fe6c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fe70: stur            x0, [fp, #-0x20]
    // 0x47fe74: r16 = <String, String>
    //     0x47fe74: ldr             x16, [PP, #0x2c48]  ; [pp+0x2c48] TypeArguments: <String, String>
    // 0x47fe78: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fe7c: stp             lr, x16, [SP]
    // 0x47fe80: r0 = Map._fromLiteral()
    //     0x47fe80: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fe84: stur            x0, [fp, #-0x28]
    // 0x47fe88: r16 = <String, int>
    //     0x47fe88: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x47fe8c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fe90: stp             lr, x16, [SP]
    // 0x47fe94: r0 = Map._fromLiteral()
    //     0x47fe94: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fe98: r1 = <int>
    //     0x47fe98: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x47fe9c: stur            x0, [fp, #-0x30]
    // 0x47fea0: r0 = _Set()
    //     0x47fea0: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x47fea4: r1 = _Uint32List
    //     0x47fea4: ldr             x1, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x47fea8: stur            x0, [fp, #-0x38]
    // 0x47feac: StoreField: r0->field_1b = r1
    //     0x47feac: stur            w1, [x0, #0x1b]
    // 0x47feb0: StoreField: r0->field_b = rZR
    //     0x47feb0: stur            wzr, [x0, #0xb]
    // 0x47feb4: r2 = const []
    //     0x47feb4: ldr             x2, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x47feb8: StoreField: r0->field_f = r2
    //     0x47feb8: stur            w2, [x0, #0xf]
    // 0x47febc: StoreField: r0->field_13 = rZR
    //     0x47febc: stur            wzr, [x0, #0x13]
    // 0x47fec0: ArrayStore: r0[0] = rZR  ; List_4
    //     0x47fec0: stur            wzr, [x0, #0x17]
    // 0x47fec4: r16 = <String, int>
    //     0x47fec4: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x47fec8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47fecc: stp             lr, x16, [SP]
    // 0x47fed0: r0 = Map._fromLiteral()
    //     0x47fed0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47fed4: stur            x0, [fp, #-0x40]
    // 0x47fed8: r0 = CoreData()
    //     0x47fed8: bl              #0x48142c  ; AllocateCoreDataStub -> CoreData (size=0x2c)
    // 0x47fedc: stur            x0, [fp, #-0x48]
    // 0x47fee0: ldur            x16, [fp, #-0x38]
    // 0x47fee4: ldur            lr, [fp, #-0x40]
    // 0x47fee8: stp             lr, x16, [SP]
    // 0x47feec: mov             x1, x0
    // 0x47fef0: ldur            x2, [fp, #-0x10]
    // 0x47fef4: ldur            x3, [fp, #-0x18]
    // 0x47fef8: ldur            x5, [fp, #-0x20]
    // 0x47fefc: ldur            x6, [fp, #-0x28]
    // 0x47ff00: ldur            x7, [fp, #-0x30]
    // 0x47ff04: r0 = CoreData()
    //     0x47ff04: bl              #0x480034  ; [package:pretentious/data/CoreData.dart] CoreData::CoreData
    // 0x47ff08: ldur            x2, [fp, #-0x48]
    // 0x47ff0c: StoreStaticField(0xf7c, r2)
    //     0x47ff0c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x47ff10: str             x2, [x0, #0x1ef8]
    // 0x47ff14: r0 = Null
    //     0x47ff14: mov             x0, NULL
    // 0x47ff18: r0 = ReturnAsyncNotFuture()
    //     0x47ff18: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x47ff1c: r0 = false
    //     0x47ff1c: add             x0, NULL, #0x30  ; false
    // 0x47ff20: r1 = _Uint32List
    //     0x47ff20: ldr             x1, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x47ff24: r2 = const []
    //     0x47ff24: ldr             x2, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x47ff28: r0 = DateTime()
    //     0x47ff28: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x47ff2c: mov             x1, x0
    // 0x47ff30: r0 = false
    //     0x47ff30: add             x0, NULL, #0x30  ; false
    // 0x47ff34: stur            x1, [fp, #-0x10]
    // 0x47ff38: StoreField: r1->field_7 = r0
    //     0x47ff38: stur            w0, [x1, #7]
    // 0x47ff3c: r0 = _getCurrentMicros()
    //     0x47ff3c: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x47ff40: r1 = LoadInt32Instr(r0)
    //     0x47ff40: sbfx            x1, x0, #1, #0x1f
    //     0x47ff44: tbz             w0, #0, #0x47ff4c
    //     0x47ff48: ldur            x1, [x0, #7]
    // 0x47ff4c: ldur            x2, [fp, #-0x10]
    // 0x47ff50: StoreField: r2->field_b = r1
    //     0x47ff50: stur            x1, [x2, #0xb]
    // 0x47ff54: r16 = <int, int>
    //     0x47ff54: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x47ff58: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47ff5c: stp             lr, x16, [SP]
    // 0x47ff60: r0 = Map._fromLiteral()
    //     0x47ff60: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47ff64: stur            x0, [fp, #-0x18]
    // 0x47ff68: r16 = <String, double>
    //     0x47ff68: add             x16, PP, #0x12, lsl #12  ; [pp+0x12870] TypeArguments: <String, double>
    //     0x47ff6c: ldr             x16, [x16, #0x870]
    // 0x47ff70: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47ff74: stp             lr, x16, [SP]
    // 0x47ff78: r0 = Map._fromLiteral()
    //     0x47ff78: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47ff7c: stur            x0, [fp, #-0x20]
    // 0x47ff80: r16 = <String, String>
    //     0x47ff80: ldr             x16, [PP, #0x2c48]  ; [pp+0x2c48] TypeArguments: <String, String>
    // 0x47ff84: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47ff88: stp             lr, x16, [SP]
    // 0x47ff8c: r0 = Map._fromLiteral()
    //     0x47ff8c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47ff90: stur            x0, [fp, #-0x28]
    // 0x47ff94: r16 = <String, int>
    //     0x47ff94: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x47ff98: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47ff9c: stp             lr, x16, [SP]
    // 0x47ffa0: r0 = Map._fromLiteral()
    //     0x47ffa0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47ffa4: r1 = <int>
    //     0x47ffa4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x47ffa8: stur            x0, [fp, #-0x30]
    // 0x47ffac: r0 = _Set()
    //     0x47ffac: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x47ffb0: mov             x1, x0
    // 0x47ffb4: r0 = _Uint32List
    //     0x47ffb4: ldr             x0, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x47ffb8: stur            x1, [fp, #-0x38]
    // 0x47ffbc: StoreField: r1->field_1b = r0
    //     0x47ffbc: stur            w0, [x1, #0x1b]
    // 0x47ffc0: StoreField: r1->field_b = rZR
    //     0x47ffc0: stur            wzr, [x1, #0xb]
    // 0x47ffc4: r0 = const []
    //     0x47ffc4: ldr             x0, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x47ffc8: StoreField: r1->field_f = r0
    //     0x47ffc8: stur            w0, [x1, #0xf]
    // 0x47ffcc: StoreField: r1->field_13 = rZR
    //     0x47ffcc: stur            wzr, [x1, #0x13]
    // 0x47ffd0: ArrayStore: r1[0] = rZR  ; List_4
    //     0x47ffd0: stur            wzr, [x1, #0x17]
    // 0x47ffd4: r16 = <String, int>
    //     0x47ffd4: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x47ffd8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x47ffdc: stp             lr, x16, [SP]
    // 0x47ffe0: r0 = Map._fromLiteral()
    //     0x47ffe0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x47ffe4: stur            x0, [fp, #-0x40]
    // 0x47ffe8: r0 = CoreData()
    //     0x47ffe8: bl              #0x48142c  ; AllocateCoreDataStub -> CoreData (size=0x2c)
    // 0x47ffec: stur            x0, [fp, #-0x48]
    // 0x47fff0: ldur            x16, [fp, #-0x38]
    // 0x47fff4: ldur            lr, [fp, #-0x40]
    // 0x47fff8: stp             lr, x16, [SP]
    // 0x47fffc: mov             x1, x0
    // 0x480000: ldur            x2, [fp, #-0x10]
    // 0x480004: ldur            x3, [fp, #-0x18]
    // 0x480008: ldur            x5, [fp, #-0x20]
    // 0x48000c: ldur            x6, [fp, #-0x28]
    // 0x480010: ldur            x7, [fp, #-0x30]
    // 0x480014: r0 = CoreData()
    //     0x480014: bl              #0x480034  ; [package:pretentious/data/CoreData.dart] CoreData::CoreData
    // 0x480018: ldur            x2, [fp, #-0x48]
    // 0x48001c: StoreStaticField(0xf7c, r2)
    //     0x48001c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x480020: str             x2, [x1, #0x1ef8]
    // 0x480024: r0 = Null
    //     0x480024: mov             x0, NULL
    // 0x480028: r0 = ReturnAsyncNotFuture()
    //     0x480028: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x48002c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x48002c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x480030: b               #0x47fb8c
  }
  static double getCompletionTokenExponent() {
    // ** addr: 0x481030, size: 0x68
    // 0x481030: EnterFrame
    //     0x481030: stp             fp, lr, [SP, #-0x10]!
    //     0x481034: mov             fp, SP
    // 0x481038: CheckStackOverflow
    //     0x481038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x48103c: cmp             SP, x16
    //     0x481040: b.ls            #0x481090
    // 0x481044: r0 = prefsGetDouble()
    //     0x481044: bl              #0x481098  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetDouble
    // 0x481048: cmp             w0, NULL
    // 0x48104c: b.ne            #0x481058
    // 0x481050: d1 = 1.000000
    //     0x481050: fmov            d1, #1.00000000
    // 0x481054: b               #0x48105c
    // 0x481058: LoadField: d1 = r0->field_7
    //     0x481058: ldur            d1, [x0, #7]
    // 0x48105c: d0 = 1.000000
    //     0x48105c: fmov            d0, #1.00000000
    // 0x481060: fcmp            d1, d0
    // 0x481064: b.gt            #0x481074
    // 0x481068: d2 = 0.000000
    //     0x481068: eor             v2.16b, v2.16b, v2.16b
    // 0x48106c: fcmp            d2, d1
    // 0x481070: b.le            #0x481080
    // 0x481074: LeaveFrame
    //     0x481074: mov             SP, fp
    //     0x481078: ldp             fp, lr, [SP], #0x10
    // 0x48107c: ret
    //     0x48107c: ret             
    // 0x481080: mov             v0.16b, v1.16b
    // 0x481084: LeaveFrame
    //     0x481084: mov             SP, fp
    //     0x481088: ldp             fp, lr, [SP], #0x10
    // 0x48108c: ret
    //     0x48108c: ret             
    // 0x481090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x481090: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x481094: b               #0x481044
  }
}

// class id: 262, size: 0x2c, field offset: 0x8
class CoreData extends Object {

  _ toMap(/* No info */) {
    // ** addr: 0x452604, size: 0x228
    // 0x452604: EnterFrame
    //     0x452604: stp             fp, lr, [SP, #-0x10]!
    //     0x452608: mov             fp, SP
    // 0x45260c: AllocStack(0x20)
    //     0x45260c: sub             SP, SP, #0x20
    // 0x452610: SetupParameters(CoreData this /* r1 => r0, fp-0x8 */)
    //     0x452610: mov             x0, x1
    //     0x452614: stur            x1, [fp, #-8]
    // 0x452618: CheckStackOverflow
    //     0x452618: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45261c: cmp             SP, x16
    //     0x452620: b.ls            #0x452824
    // 0x452624: r1 = Null
    //     0x452624: mov             x1, NULL
    // 0x452628: r2 = 28
    //     0x452628: movz            x2, #0x1c
    // 0x45262c: r0 = AllocateArray()
    //     0x45262c: bl              #0x82746c  ; AllocateArrayStub
    // 0x452630: mov             x3, x0
    // 0x452634: stur            x3, [fp, #-0x10]
    // 0x452638: StoreField: r3->field_f = rZR
    //     0x452638: stur            wzr, [x3, #0xf]
    // 0x45263c: ldur            x4, [fp, #-8]
    // 0x452640: LoadField: r0 = r4->field_f
    //     0x452640: ldur            w0, [x4, #0xf]
    // 0x452644: DecompressPointer r0
    //     0x452644: add             x0, x0, HEAP, lsl #32
    // 0x452648: LoadField: r1 = r0->field_b
    //     0x452648: ldur            x1, [x0, #0xb]
    // 0x45264c: tbz             x1, #0x3f, #0x452658
    // 0x452650: r2 = 999
    //     0x452650: movz            x2, #0x3e7
    // 0x452654: b               #0x45265c
    // 0x452658: r2 = 0
    //     0x452658: movz            x2, #0
    // 0x45265c: r0 = 1000
    //     0x45265c: movz            x0, #0x3e8
    // 0x452660: sub             x5, x1, x2
    // 0x452664: sdiv            x2, x5, x0
    // 0x452668: r0 = BoxInt64Instr(r2)
    //     0x452668: sbfiz           x0, x2, #1, #0x1f
    //     0x45266c: cmp             x2, x0, asr #1
    //     0x452670: b.eq            #0x45267c
    //     0x452674: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x452678: stur            x2, [x0, #7]
    // 0x45267c: mov             x1, x3
    // 0x452680: ArrayStore: r1[1] = r0  ; List_4
    //     0x452680: add             x25, x1, #0x13
    //     0x452684: str             w0, [x25]
    //     0x452688: tbz             w0, #0, #0x4526a4
    //     0x45268c: ldurb           w16, [x1, #-1]
    //     0x452690: ldurb           w17, [x0, #-1]
    //     0x452694: and             x16, x17, x16, lsr #2
    //     0x452698: tst             x16, HEAP, lsr #32
    //     0x45269c: b.eq            #0x4526a4
    //     0x4526a0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4526a4: r16 = 2
    //     0x4526a4: movz            x16, #0x2
    // 0x4526a8: ArrayStore: r3[0] = r16  ; List_4
    //     0x4526a8: stur            w16, [x3, #0x17]
    // 0x4526ac: LoadField: r0 = r4->field_13
    //     0x4526ac: ldur            w0, [x4, #0x13]
    // 0x4526b0: DecompressPointer r0
    //     0x4526b0: add             x0, x0, HEAP, lsl #32
    // 0x4526b4: mov             x1, x3
    // 0x4526b8: ArrayStore: r1[3] = r0  ; List_4
    //     0x4526b8: add             x25, x1, #0x1b
    //     0x4526bc: str             w0, [x25]
    //     0x4526c0: tbz             w0, #0, #0x4526dc
    //     0x4526c4: ldurb           w16, [x1, #-1]
    //     0x4526c8: ldurb           w17, [x0, #-1]
    //     0x4526cc: and             x16, x17, x16, lsr #2
    //     0x4526d0: tst             x16, HEAP, lsr #32
    //     0x4526d4: b.eq            #0x4526dc
    //     0x4526d8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4526dc: r16 = 4
    //     0x4526dc: movz            x16, #0x4
    // 0x4526e0: StoreField: r3->field_1f = r16
    //     0x4526e0: stur            w16, [x3, #0x1f]
    // 0x4526e4: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x4526e4: ldur            w0, [x4, #0x17]
    // 0x4526e8: DecompressPointer r0
    //     0x4526e8: add             x0, x0, HEAP, lsl #32
    // 0x4526ec: mov             x1, x3
    // 0x4526f0: ArrayStore: r1[5] = r0  ; List_4
    //     0x4526f0: add             x25, x1, #0x23
    //     0x4526f4: str             w0, [x25]
    //     0x4526f8: tbz             w0, #0, #0x452714
    //     0x4526fc: ldurb           w16, [x1, #-1]
    //     0x452700: ldurb           w17, [x0, #-1]
    //     0x452704: and             x16, x17, x16, lsr #2
    //     0x452708: tst             x16, HEAP, lsr #32
    //     0x45270c: b.eq            #0x452714
    //     0x452710: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x452714: r16 = 6
    //     0x452714: movz            x16, #0x6
    // 0x452718: StoreField: r3->field_27 = r16
    //     0x452718: stur            w16, [x3, #0x27]
    // 0x45271c: LoadField: r0 = r4->field_1b
    //     0x45271c: ldur            w0, [x4, #0x1b]
    // 0x452720: DecompressPointer r0
    //     0x452720: add             x0, x0, HEAP, lsl #32
    // 0x452724: mov             x1, x3
    // 0x452728: ArrayStore: r1[7] = r0  ; List_4
    //     0x452728: add             x25, x1, #0x2b
    //     0x45272c: str             w0, [x25]
    //     0x452730: tbz             w0, #0, #0x45274c
    //     0x452734: ldurb           w16, [x1, #-1]
    //     0x452738: ldurb           w17, [x0, #-1]
    //     0x45273c: and             x16, x17, x16, lsr #2
    //     0x452740: tst             x16, HEAP, lsr #32
    //     0x452744: b.eq            #0x45274c
    //     0x452748: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x45274c: r16 = 8
    //     0x45274c: movz            x16, #0x8
    // 0x452750: StoreField: r3->field_2f = r16
    //     0x452750: stur            w16, [x3, #0x2f]
    // 0x452754: LoadField: r0 = r4->field_1f
    //     0x452754: ldur            w0, [x4, #0x1f]
    // 0x452758: DecompressPointer r0
    //     0x452758: add             x0, x0, HEAP, lsl #32
    // 0x45275c: mov             x1, x3
    // 0x452760: ArrayStore: r1[9] = r0  ; List_4
    //     0x452760: add             x25, x1, #0x33
    //     0x452764: str             w0, [x25]
    //     0x452768: tbz             w0, #0, #0x452784
    //     0x45276c: ldurb           w16, [x1, #-1]
    //     0x452770: ldurb           w17, [x0, #-1]
    //     0x452774: and             x16, x17, x16, lsr #2
    //     0x452778: tst             x16, HEAP, lsr #32
    //     0x45277c: b.eq            #0x452784
    //     0x452780: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x452784: r16 = 10
    //     0x452784: movz            x16, #0xa
    // 0x452788: StoreField: r3->field_37 = r16
    //     0x452788: stur            w16, [x3, #0x37]
    // 0x45278c: LoadField: r2 = r4->field_23
    //     0x45278c: ldur            w2, [x4, #0x23]
    // 0x452790: DecompressPointer r2
    //     0x452790: add             x2, x2, HEAP, lsl #32
    // 0x452794: r1 = <int>
    //     0x452794: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x452798: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x452798: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x45279c: ldur            x1, [fp, #-0x10]
    // 0x4527a0: ArrayStore: r1[11] = r0  ; List_4
    //     0x4527a0: add             x25, x1, #0x3b
    //     0x4527a4: str             w0, [x25]
    //     0x4527a8: tbz             w0, #0, #0x4527c4
    //     0x4527ac: ldurb           w16, [x1, #-1]
    //     0x4527b0: ldurb           w17, [x0, #-1]
    //     0x4527b4: and             x16, x17, x16, lsr #2
    //     0x4527b8: tst             x16, HEAP, lsr #32
    //     0x4527bc: b.eq            #0x4527c4
    //     0x4527c0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4527c4: ldur            x2, [fp, #-0x10]
    // 0x4527c8: r16 = 12
    //     0x4527c8: movz            x16, #0xc
    // 0x4527cc: StoreField: r2->field_3f = r16
    //     0x4527cc: stur            w16, [x2, #0x3f]
    // 0x4527d0: ldur            x0, [fp, #-8]
    // 0x4527d4: LoadField: r1 = r0->field_27
    //     0x4527d4: ldur            w1, [x0, #0x27]
    // 0x4527d8: DecompressPointer r1
    //     0x4527d8: add             x1, x1, HEAP, lsl #32
    // 0x4527dc: mov             x0, x1
    // 0x4527e0: mov             x1, x2
    // 0x4527e4: ArrayStore: r1[13] = r0  ; List_4
    //     0x4527e4: add             x25, x1, #0x43
    //     0x4527e8: str             w0, [x25]
    //     0x4527ec: tbz             w0, #0, #0x452808
    //     0x4527f0: ldurb           w16, [x1, #-1]
    //     0x4527f4: ldurb           w17, [x0, #-1]
    //     0x4527f8: and             x16, x17, x16, lsr #2
    //     0x4527fc: tst             x16, HEAP, lsr #32
    //     0x452800: b.eq            #0x452808
    //     0x452804: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x452808: r16 = <int, dynamic>
    //     0x452808: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x45280c: ldr             x16, [x16, #0x4f0]
    // 0x452810: stp             x2, x16, [SP]
    // 0x452814: r0 = Map._fromLiteral()
    //     0x452814: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x452818: LeaveFrame
    //     0x452818: mov             SP, fp
    //     0x45281c: ldp             fp, lr, [SP], #0x10
    // 0x452820: ret
    //     0x452820: ret             
    // 0x452824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x452824: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x452828: b               #0x452624
  }
  _ cachedCompletionTokenBoost(/* No info */) {
    // ** addr: 0x46109c, size: 0x170
    // 0x46109c: EnterFrame
    //     0x46109c: stp             fp, lr, [SP, #-0x10]!
    //     0x4610a0: mov             fp, SP
    // 0x4610a4: AllocStack(0x28)
    //     0x4610a4: sub             SP, SP, #0x28
    // 0x4610a8: SetupParameters(CoreData this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x4610a8: mov             x0, x3
    //     0x4610ac: stur            x3, [fp, #-0x18]
    //     0x4610b0: mov             x3, x1
    //     0x4610b4: stur            x1, [fp, #-8]
    //     0x4610b8: stur            x2, [fp, #-0x10]
    // 0x4610bc: CheckStackOverflow
    //     0x4610bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4610c0: cmp             SP, x16
    //     0x4610c4: b.ls            #0x4611fc
    // 0x4610c8: LoadField: r1 = r3->field_7
    //     0x4610c8: ldur            w1, [x3, #7]
    // 0x4610cc: DecompressPointer r1
    //     0x4610cc: add             x1, x1, HEAP, lsl #32
    // 0x4610d0: cmp             w1, NULL
    // 0x4610d4: b.ne            #0x461100
    // 0x4610d8: r1 = "Cached boost is null!"
    //     0x4610d8: add             x1, PP, #0x10, lsl #12  ; [pp+0x10ce0] "Cached boost is null!"
    //     0x4610dc: ldr             x1, [x1, #0xce0]
    // 0x4610e0: r2 = Null
    //     0x4610e0: mov             x2, NULL
    // 0x4610e4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4610e4: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4610e8: r0 = crashlyticsRecordError()
    //     0x4610e8: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x4610ec: r0 = Instance_CustomNum
    //     0x4610ec: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x4610f0: ldr             x0, [x0, #0xa70]
    // 0x4610f4: LeaveFrame
    //     0x4610f4: mov             SP, fp
    //     0x4610f8: ldp             fp, lr, [SP], #0x10
    // 0x4610fc: ret
    //     0x4610fc: ret             
    // 0x461100: cmp             w0, NULL
    // 0x461104: b.eq            #0x4611c4
    // 0x461108: mov             x1, x0
    // 0x46110c: r0 = allowDifficultyChoosing()
    //     0x46110c: bl              #0x4619e8  ; [package:pretentious/widgets/difficulty_indicator.dart] ::allowDifficultyChoosing
    // 0x461110: tbnz            w0, #4, #0x4611bc
    // 0x461114: ldur            x0, [fp, #-0x18]
    // 0x461118: r1 = Null
    //     0x461118: mov             x1, NULL
    // 0x46111c: r2 = 6
    //     0x46111c: movz            x2, #0x6
    // 0x461120: r0 = AllocateArray()
    //     0x461120: bl              #0x82746c  ; AllocateArrayStub
    // 0x461124: r16 = "chapter_"
    //     0x461124: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ce8] "chapter_"
    //     0x461128: ldr             x16, [x16, #0xce8]
    // 0x46112c: StoreField: r0->field_f = r16
    //     0x46112c: stur            w16, [x0, #0xf]
    // 0x461130: ldur            x1, [fp, #-0x18]
    // 0x461134: StoreField: r0->field_13 = r1
    //     0x461134: stur            w1, [x0, #0x13]
    // 0x461138: r16 = "_difficulty_multiplier"
    //     0x461138: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cf0] "_difficulty_multiplier"
    //     0x46113c: ldr             x16, [x16, #0xcf0]
    // 0x461140: ArrayStore: r0[0] = r16  ; List_4
    //     0x461140: stur            w16, [x0, #0x17]
    // 0x461144: str             x0, [SP]
    // 0x461148: r0 = _interpolate()
    //     0x461148: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x46114c: mov             x1, x0
    // 0x461150: r0 = remoteConfigGetDouble()
    //     0x461150: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x461154: stur            x0, [fp, #-0x20]
    // 0x461158: cmp             w0, NULL
    // 0x46115c: b.eq            #0x4611b4
    // 0x461160: ldur            x1, [fp, #-8]
    // 0x461164: LoadField: r2 = r1->field_7
    //     0x461164: ldur            w2, [x1, #7]
    // 0x461168: DecompressPointer r2
    //     0x461168: add             x2, x2, HEAP, lsl #32
    // 0x46116c: stur            x2, [fp, #-0x18]
    // 0x461170: cmp             w2, NULL
    // 0x461174: b.eq            #0x461204
    // 0x461178: ldur            x1, [fp, #-0x10]
    // 0x46117c: r0 = invert()
    //     0x46117c: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x461180: ldur            x2, [fp, #-0x20]
    // 0x461184: r1 = Null
    //     0x461184: mov             x1, NULL
    // 0x461188: stur            x0, [fp, #-0x20]
    // 0x46118c: r0 = CustomNum()
    //     0x46118c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x461190: mov             x1, x0
    // 0x461194: r0 = invert()
    //     0x461194: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x461198: ldur            x1, [fp, #-0x18]
    // 0x46119c: ldur            x2, [fp, #-0x20]
    // 0x4611a0: mov             x3, x0
    // 0x4611a4: r0 = mult3()
    //     0x4611a4: bl              #0x3da118  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult3
    // 0x4611a8: LeaveFrame
    //     0x4611a8: mov             SP, fp
    //     0x4611ac: ldp             fp, lr, [SP], #0x10
    // 0x4611b0: ret
    //     0x4611b0: ret             
    // 0x4611b4: ldur            x1, [fp, #-8]
    // 0x4611b8: b               #0x4611c8
    // 0x4611bc: ldur            x1, [fp, #-8]
    // 0x4611c0: b               #0x4611c8
    // 0x4611c4: mov             x1, x3
    // 0x4611c8: LoadField: r0 = r1->field_7
    //     0x4611c8: ldur            w0, [x1, #7]
    // 0x4611cc: DecompressPointer r0
    //     0x4611cc: add             x0, x0, HEAP, lsl #32
    // 0x4611d0: stur            x0, [fp, #-0x18]
    // 0x4611d4: cmp             w0, NULL
    // 0x4611d8: b.eq            #0x461208
    // 0x4611dc: ldur            x1, [fp, #-0x10]
    // 0x4611e0: r0 = invert()
    //     0x4611e0: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x4611e4: ldur            x1, [fp, #-0x18]
    // 0x4611e8: mov             x2, x0
    // 0x4611ec: r0 = mult2()
    //     0x4611ec: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x4611f0: LeaveFrame
    //     0x4611f0: mov             SP, fp
    //     0x4611f4: ldp             fp, lr, [SP], #0x10
    // 0x4611f8: ret
    //     0x4611f8: ret             
    // 0x4611fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4611fc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x461200: b               #0x4610c8
    // 0x461204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x461204: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x461208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x461208: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] CustomNum cachedCompletionTokenBoost(dynamic, CustomNum, String?) {
    // ** addr: 0x46120c, size: 0x40
    // 0x46120c: EnterFrame
    //     0x46120c: stp             fp, lr, [SP, #-0x10]!
    //     0x461210: mov             fp, SP
    // 0x461214: ldr             x0, [fp, #0x20]
    // 0x461218: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x461218: ldur            w1, [x0, #0x17]
    // 0x46121c: DecompressPointer r1
    //     0x46121c: add             x1, x1, HEAP, lsl #32
    // 0x461220: CheckStackOverflow
    //     0x461220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x461224: cmp             SP, x16
    //     0x461228: b.ls            #0x461244
    // 0x46122c: ldr             x2, [fp, #0x18]
    // 0x461230: ldr             x3, [fp, #0x10]
    // 0x461234: r0 = cachedCompletionTokenBoost()
    //     0x461234: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x461238: LeaveFrame
    //     0x461238: mov             SP, fp
    //     0x46123c: ldp             fp, lr, [SP], #0x10
    // 0x461240: ret
    //     0x461240: ret             
    // 0x461244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x461244: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x461248: b               #0x46122c
  }
  _ CoreData(/* No info */) {
    // ** addr: 0x480034, size: 0x2b4
    // 0x480034: EnterFrame
    //     0x480034: stp             fp, lr, [SP, #-0x10]!
    //     0x480038: mov             fp, SP
    // 0x48003c: AllocStack(0x38)
    //     0x48003c: sub             SP, SP, #0x38
    // 0x480040: SetupParameters(CoreData this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r4, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */, dynamic _ /* r7 => r0, fp-0x30 */)
    //     0x480040: mov             x4, x3
    //     0x480044: stur            x3, [fp, #-0x18]
    //     0x480048: mov             x3, x5
    //     0x48004c: stur            x5, [fp, #-0x20]
    //     0x480050: mov             x5, x2
    //     0x480054: stur            x2, [fp, #-0x10]
    //     0x480058: mov             x2, x6
    //     0x48005c: stur            x6, [fp, #-0x28]
    //     0x480060: mov             x6, x1
    //     0x480064: mov             x0, x7
    //     0x480068: stur            x1, [fp, #-8]
    //     0x48006c: stur            x7, [fp, #-0x30]
    // 0x480070: CheckStackOverflow
    //     0x480070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x480074: cmp             SP, x16
    //     0x480078: b.ls            #0x4802e0
    // 0x48007c: r1 = <String>
    //     0x48007c: ldr             x1, [PP, #0x878]  ; [pp+0x878] TypeArguments: <String>
    // 0x480080: r0 = _Set()
    //     0x480080: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x480084: mov             x3, x0
    // 0x480088: r0 = _Uint32List
    //     0x480088: ldr             x0, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x48008c: stur            x3, [fp, #-0x38]
    // 0x480090: StoreField: r3->field_1b = r0
    //     0x480090: stur            w0, [x3, #0x1b]
    // 0x480094: StoreField: r3->field_b = rZR
    //     0x480094: stur            wzr, [x3, #0xb]
    // 0x480098: r0 = const []
    //     0x480098: ldr             x0, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x48009c: StoreField: r3->field_f = r0
    //     0x48009c: stur            w0, [x3, #0xf]
    // 0x4800a0: StoreField: r3->field_13 = rZR
    //     0x4800a0: stur            wzr, [x3, #0x13]
    // 0x4800a4: ArrayStore: r3[0] = rZR  ; List_4
    //     0x4800a4: stur            wzr, [x3, #0x17]
    // 0x4800a8: mov             x1, x3
    // 0x4800ac: r2 = "1"
    //     0x4800ac: add             x2, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x4800b0: ldr             x2, [x2, #0x9c8]
    // 0x4800b4: r0 = add()
    //     0x4800b4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4800b8: ldur            x1, [fp, #-0x38]
    // 0x4800bc: r2 = "2"
    //     0x4800bc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x4800c0: ldr             x2, [x2, #0x2e0]
    // 0x4800c4: r0 = add()
    //     0x4800c4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4800c8: ldur            x1, [fp, #-0x38]
    // 0x4800cc: r2 = "3"
    //     0x4800cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4800d0: ldr             x2, [x2, #0x2f0]
    // 0x4800d4: r0 = add()
    //     0x4800d4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4800d8: ldur            x1, [fp, #-0x38]
    // 0x4800dc: r2 = "4"
    //     0x4800dc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x4800e0: ldr             x2, [x2, #0x2f8]
    // 0x4800e4: r0 = add()
    //     0x4800e4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4800e8: ldur            x1, [fp, #-0x38]
    // 0x4800ec: r2 = "5"
    //     0x4800ec: add             x2, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x4800f0: ldr             x2, [x2, #0x300]
    // 0x4800f4: r0 = add()
    //     0x4800f4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4800f8: ldur            x1, [fp, #-0x38]
    // 0x4800fc: r2 = "6"
    //     0x4800fc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x480100: ldr             x2, [x2, #0x308]
    // 0x480104: r0 = add()
    //     0x480104: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480108: ldur            x1, [fp, #-0x38]
    // 0x48010c: r2 = "7"
    //     0x48010c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x480110: ldr             x2, [x2, #0x310]
    // 0x480114: r0 = add()
    //     0x480114: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480118: ldur            x1, [fp, #-0x38]
    // 0x48011c: r2 = "8"
    //     0x48011c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x480120: ldr             x2, [x2, #0x318]
    // 0x480124: r0 = add()
    //     0x480124: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480128: ldur            x1, [fp, #-0x38]
    // 0x48012c: r2 = "9"
    //     0x48012c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x480130: ldr             x2, [x2, #0x320]
    // 0x480134: r0 = add()
    //     0x480134: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480138: ldur            x1, [fp, #-0x38]
    // 0x48013c: r2 = "10"
    //     0x48013c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x480140: ldr             x2, [x2, #0x9d0]
    // 0x480144: r0 = add()
    //     0x480144: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480148: ldur            x1, [fp, #-0x38]
    // 0x48014c: r2 = "11"
    //     0x48014c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x480150: ldr             x2, [x2, #0x328]
    // 0x480154: r0 = add()
    //     0x480154: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480158: ldur            x1, [fp, #-0x38]
    // 0x48015c: r2 = "12"
    //     0x48015c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x480160: ldr             x2, [x2, #0x330]
    // 0x480164: r0 = add()
    //     0x480164: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480168: ldur            x1, [fp, #-0x38]
    // 0x48016c: r2 = "13"
    //     0x48016c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x480170: ldr             x2, [x2, #0x338]
    // 0x480174: r0 = add()
    //     0x480174: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480178: ldur            x1, [fp, #-0x38]
    // 0x48017c: r2 = "14"
    //     0x48017c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x480180: ldr             x2, [x2, #0x340]
    // 0x480184: r0 = add()
    //     0x480184: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480188: ldur            x1, [fp, #-0x38]
    // 0x48018c: r2 = "15"
    //     0x48018c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x480190: ldr             x2, [x2, #0x348]
    // 0x480194: r0 = add()
    //     0x480194: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x480198: ldur            x1, [fp, #-0x38]
    // 0x48019c: r2 = "16"
    //     0x48019c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x4801a0: ldr             x2, [x2, #0x350]
    // 0x4801a4: r0 = add()
    //     0x4801a4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4801a8: ldur            x1, [fp, #-0x38]
    // 0x4801ac: r2 = "17"
    //     0x4801ac: add             x2, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x4801b0: ldr             x2, [x2, #0x358]
    // 0x4801b4: r0 = add()
    //     0x4801b4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4801b8: ldur            x1, [fp, #-0x38]
    // 0x4801bc: r2 = "Bonus"
    //     0x4801bc: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x4801c0: ldr             x2, [x2, #0xa68]
    // 0x4801c4: r0 = add()
    //     0x4801c4: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x4801c8: ldur            x0, [fp, #-0x38]
    // 0x4801cc: ldur            x1, [fp, #-8]
    // 0x4801d0: StoreField: r1->field_b = r0
    //     0x4801d0: stur            w0, [x1, #0xb]
    //     0x4801d4: ldurb           w16, [x1, #-1]
    //     0x4801d8: ldurb           w17, [x0, #-1]
    //     0x4801dc: and             x16, x17, x16, lsr #2
    //     0x4801e0: tst             x16, HEAP, lsr #32
    //     0x4801e4: b.eq            #0x4801ec
    //     0x4801e8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4801ec: ldur            x0, [fp, #-0x10]
    // 0x4801f0: StoreField: r1->field_f = r0
    //     0x4801f0: stur            w0, [x1, #0xf]
    //     0x4801f4: ldurb           w16, [x1, #-1]
    //     0x4801f8: ldurb           w17, [x0, #-1]
    //     0x4801fc: and             x16, x17, x16, lsr #2
    //     0x480200: tst             x16, HEAP, lsr #32
    //     0x480204: b.eq            #0x48020c
    //     0x480208: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x48020c: ldur            x0, [fp, #-0x18]
    // 0x480210: StoreField: r1->field_13 = r0
    //     0x480210: stur            w0, [x1, #0x13]
    //     0x480214: ldurb           w16, [x1, #-1]
    //     0x480218: ldurb           w17, [x0, #-1]
    //     0x48021c: and             x16, x17, x16, lsr #2
    //     0x480220: tst             x16, HEAP, lsr #32
    //     0x480224: b.eq            #0x48022c
    //     0x480228: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x48022c: ldur            x0, [fp, #-0x20]
    // 0x480230: ArrayStore: r1[0] = r0  ; List_4
    //     0x480230: stur            w0, [x1, #0x17]
    //     0x480234: ldurb           w16, [x1, #-1]
    //     0x480238: ldurb           w17, [x0, #-1]
    //     0x48023c: and             x16, x17, x16, lsr #2
    //     0x480240: tst             x16, HEAP, lsr #32
    //     0x480244: b.eq            #0x48024c
    //     0x480248: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x48024c: ldur            x0, [fp, #-0x28]
    // 0x480250: StoreField: r1->field_1b = r0
    //     0x480250: stur            w0, [x1, #0x1b]
    //     0x480254: ldurb           w16, [x1, #-1]
    //     0x480258: ldurb           w17, [x0, #-1]
    //     0x48025c: and             x16, x17, x16, lsr #2
    //     0x480260: tst             x16, HEAP, lsr #32
    //     0x480264: b.eq            #0x48026c
    //     0x480268: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x48026c: ldur            x0, [fp, #-0x30]
    // 0x480270: StoreField: r1->field_1f = r0
    //     0x480270: stur            w0, [x1, #0x1f]
    //     0x480274: ldurb           w16, [x1, #-1]
    //     0x480278: ldurb           w17, [x0, #-1]
    //     0x48027c: and             x16, x17, x16, lsr #2
    //     0x480280: tst             x16, HEAP, lsr #32
    //     0x480284: b.eq            #0x48028c
    //     0x480288: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x48028c: ldr             x0, [fp, #0x18]
    // 0x480290: StoreField: r1->field_23 = r0
    //     0x480290: stur            w0, [x1, #0x23]
    //     0x480294: ldurb           w16, [x1, #-1]
    //     0x480298: ldurb           w17, [x0, #-1]
    //     0x48029c: and             x16, x17, x16, lsr #2
    //     0x4802a0: tst             x16, HEAP, lsr #32
    //     0x4802a4: b.eq            #0x4802ac
    //     0x4802a8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4802ac: ldr             x0, [fp, #0x10]
    // 0x4802b0: StoreField: r1->field_27 = r0
    //     0x4802b0: stur            w0, [x1, #0x27]
    //     0x4802b4: ldurb           w16, [x1, #-1]
    //     0x4802b8: ldurb           w17, [x0, #-1]
    //     0x4802bc: and             x16, x17, x16, lsr #2
    //     0x4802c0: tst             x16, HEAP, lsr #32
    //     0x4802c4: b.eq            #0x4802cc
    //     0x4802c8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x4802cc: r0 = recomputeTokenBoost()
    //     0x4802cc: bl              #0x4802e8  ; [package:pretentious/data/CoreData.dart] CoreData::recomputeTokenBoost
    // 0x4802d0: r0 = Null
    //     0x4802d0: mov             x0, NULL
    // 0x4802d4: LeaveFrame
    //     0x4802d4: mov             SP, fp
    //     0x4802d8: ldp             fp, lr, [SP], #0x10
    // 0x4802dc: ret
    //     0x4802dc: ret             
    // 0x4802e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4802e0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4802e4: b               #0x48007c
  }
  _ recomputeTokenBoost(/* No info */) {
    // ** addr: 0x4802e8, size: 0xc24
    // 0x4802e8: EnterFrame
    //     0x4802e8: stp             fp, lr, [SP, #-0x10]!
    //     0x4802ec: mov             fp, SP
    // 0x4802f0: AllocStack(0x90)
    //     0x4802f0: sub             SP, SP, #0x90
    // 0x4802f4: SetupParameters(CoreData this /* r1 => r0, fp-0x8 */)
    //     0x4802f4: mov             x0, x1
    //     0x4802f8: stur            x1, [fp, #-8]
    // 0x4802fc: CheckStackOverflow
    //     0x4802fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x480300: cmp             SP, x16
    //     0x480304: b.ls            #0x480e30
    // 0x480308: mov             x1, x0
    // 0x48030c: r0 = numAssignedTokens()
    //     0x48030c: bl              #0x48130c  ; [package:pretentious/data/CoreData.dart] CoreData::numAssignedTokens
    // 0x480310: mov             x3, x0
    // 0x480314: ldur            x0, [fp, #-8]
    // 0x480318: stur            x3, [fp, #-0x18]
    // 0x48031c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x48031c: ldur            w4, [x0, #0x17]
    // 0x480320: DecompressPointer r4
    //     0x480320: add             x4, x4, HEAP, lsl #32
    // 0x480324: mov             x1, x4
    // 0x480328: stur            x4, [fp, #-0x10]
    // 0x48032c: r2 = "Bonus"
    //     0x48032c: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x480330: ldr             x2, [x2, #0xa68]
    // 0x480334: r0 = _getValueOrData()
    //     0x480334: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x480338: ldur            x2, [fp, #-0x10]
    // 0x48033c: LoadField: r1 = r2->field_f
    //     0x48033c: ldur            w1, [x2, #0xf]
    // 0x480340: DecompressPointer r1
    //     0x480340: add             x1, x1, HEAP, lsl #32
    // 0x480344: cmp             w1, w0
    // 0x480348: b.ne            #0x480350
    // 0x48034c: r0 = Null
    //     0x48034c: mov             x0, NULL
    // 0x480350: cmp             w0, NULL
    // 0x480354: b.ne            #0x480360
    // 0x480358: r4 = 0
    //     0x480358: movz            x4, #0
    // 0x48035c: b               #0x480364
    // 0x480360: mov             x4, x0
    // 0x480364: ldur            x3, [fp, #-0x18]
    // 0x480368: r0 = BoxInt64Instr(r3)
    //     0x480368: sbfiz           x0, x3, #1, #0x1f
    //     0x48036c: cmp             x3, x0, asr #1
    //     0x480370: b.eq            #0x48037c
    //     0x480374: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x480378: stur            x3, [x0, #7]
    // 0x48037c: stp             x4, x0, [SP]
    // 0x480380: r0 = >()
    //     0x480380: bl              #0x824e2c  ; [dart:core] _IntegerImplementation::>
    // 0x480384: tbnz            w0, #4, #0x480398
    // 0x480388: ldur            x0, [fp, #-8]
    // 0x48038c: LoadField: r1 = r0->field_27
    //     0x48038c: ldur            w1, [x0, #0x27]
    // 0x480390: DecompressPointer r1
    //     0x480390: add             x1, x1, HEAP, lsl #32
    // 0x480394: r0 = clear()
    //     0x480394: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x480398: ldur            x0, [fp, #-8]
    // 0x48039c: r2 = Instance_CustomNum
    //     0x48039c: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x4803a0: ldr             x2, [x2, #0xa70]
    // 0x4803a4: StoreField: r0->field_7 = r2
    //     0x4803a4: stur            w2, [x0, #7]
    // 0x4803a8: LoadField: r1 = r0->field_b
    //     0x4803a8: ldur            w1, [x0, #0xb]
    // 0x4803ac: DecompressPointer r1
    //     0x4803ac: add             x1, x1, HEAP, lsl #32
    // 0x4803b0: r0 = iterator()
    //     0x4803b0: bl              #0x6530c0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x4803b4: mov             x2, x0
    // 0x4803b8: ldur            x0, [fp, #-8]
    // 0x4803bc: stur            x2, [fp, #-0x38]
    // 0x4803c0: LoadField: r3 = r0->field_27
    //     0x4803c0: ldur            w3, [x0, #0x27]
    // 0x4803c4: DecompressPointer r3
    //     0x4803c4: add             x3, x3, HEAP, lsl #32
    // 0x4803c8: stur            x3, [fp, #-0x30]
    // 0x4803cc: LoadField: r4 = r3->field_7
    //     0x4803cc: ldur            w4, [x3, #7]
    // 0x4803d0: DecompressPointer r4
    //     0x4803d0: add             x4, x4, HEAP, lsl #32
    // 0x4803d4: stur            x4, [fp, #-0x28]
    // 0x4803d8: LoadField: r5 = r2->field_7
    //     0x4803d8: ldur            w5, [x2, #7]
    // 0x4803dc: DecompressPointer r5
    //     0x4803dc: add             x5, x5, HEAP, lsl #32
    // 0x4803e0: stur            x5, [fp, #-0x20]
    // 0x4803e4: d0 = 0.000000
    //     0x4803e4: eor             v0.16b, v0.16b, v0.16b
    // 0x4803e8: ldur            x6, [fp, #-0x10]
    // 0x4803ec: stur            d0, [fp, #-0x68]
    // 0x4803f0: CheckStackOverflow
    //     0x4803f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4803f4: cmp             SP, x16
    //     0x4803f8: b.ls            #0x480e38
    // 0x4803fc: mov             x1, x2
    // 0x480400: r0 = moveNext()
    //     0x480400: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x480404: tbnz            w0, #4, #0x480c5c
    // 0x480408: ldur            x3, [fp, #-0x38]
    // 0x48040c: LoadField: r4 = r3->field_33
    //     0x48040c: ldur            w4, [x3, #0x33]
    // 0x480410: DecompressPointer r4
    //     0x480410: add             x4, x4, HEAP, lsl #32
    // 0x480414: stur            x4, [fp, #-0x40]
    // 0x480418: cmp             w4, NULL
    // 0x48041c: b.ne            #0x480450
    // 0x480420: mov             x0, x4
    // 0x480424: ldur            x2, [fp, #-0x20]
    // 0x480428: r1 = Null
    //     0x480428: mov             x1, NULL
    // 0x48042c: cmp             w2, NULL
    // 0x480430: b.eq            #0x480450
    // 0x480434: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x480434: ldur            w4, [x2, #0x17]
    // 0x480438: DecompressPointer r4
    //     0x480438: add             x4, x4, HEAP, lsl #32
    // 0x48043c: r8 = X0
    //     0x48043c: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x480440: LoadField: r9 = r4->field_7
    //     0x480440: ldur            x9, [x4, #7]
    // 0x480444: r3 = Null
    //     0x480444: add             x3, PP, #0xe, lsl #12  ; [pp+0xea78] Null
    //     0x480448: ldr             x3, [x3, #0xa78]
    // 0x48044c: blr             x9
    // 0x480450: ldur            x2, [fp, #-0x40]
    // 0x480454: r0 = LoadClassIdInstr(r2)
    //     0x480454: ldur            x0, [x2, #-1]
    //     0x480458: ubfx            x0, x0, #0xc, #0x14
    // 0x48045c: r16 = "Bonus"
    //     0x48045c: add             x16, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x480460: ldr             x16, [x16, #0xa68]
    // 0x480464: stp             x16, x2, [SP]
    // 0x480468: mov             lr, x0
    // 0x48046c: ldr             lr, [x21, lr, lsl #3]
    // 0x480470: blr             lr
    // 0x480474: tbnz            w0, #4, #0x480814
    // 0x480478: ldur            x0, [fp, #-8]
    // 0x48047c: ldur            x3, [fp, #-0x10]
    // 0x480480: LoadField: r4 = r0->field_7
    //     0x480480: ldur            w4, [x0, #7]
    // 0x480484: DecompressPointer r4
    //     0x480484: add             x4, x4, HEAP, lsl #32
    // 0x480488: stur            x4, [fp, #-0x48]
    // 0x48048c: cmp             w4, NULL
    // 0x480490: b.eq            #0x480e40
    // 0x480494: mov             x1, x3
    // 0x480498: ldur            x2, [fp, #-0x40]
    // 0x48049c: r0 = _getValueOrData()
    //     0x48049c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4804a0: mov             x1, x0
    // 0x4804a4: ldur            x0, [fp, #-0x10]
    // 0x4804a8: LoadField: r2 = r0->field_f
    //     0x4804a8: ldur            w2, [x0, #0xf]
    // 0x4804ac: DecompressPointer r2
    //     0x4804ac: add             x2, x2, HEAP, lsl #32
    // 0x4804b0: cmp             w2, w1
    // 0x4804b4: b.ne            #0x4804bc
    // 0x4804b8: r1 = Null
    //     0x4804b8: mov             x1, NULL
    // 0x4804bc: cmp             w1, NULL
    // 0x4804c0: b.ne            #0x4804cc
    // 0x4804c4: d0 = 0.000000
    //     0x4804c4: eor             v0.16b, v0.16b, v0.16b
    // 0x4804c8: b               #0x4804d0
    // 0x4804cc: LoadField: d0 = r1->field_7
    //     0x4804cc: ldur            d0, [x1, #7]
    // 0x4804d0: ldur            x4, [fp, #-0x30]
    // 0x4804d4: ldur            x2, [fp, #-0x28]
    // 0x4804d8: stur            d0, [fp, #-0x70]
    // 0x4804dc: r1 = Null
    //     0x4804dc: mov             x1, NULL
    // 0x4804e0: r3 = <X1>
    //     0x4804e0: ldr             x3, [PP, #0x1fb8]  ; [pp+0x1fb8] TypeArguments: <X1>
    // 0x4804e4: r0 = Null
    //     0x4804e4: mov             x0, NULL
    // 0x4804e8: cmp             x2, x0
    // 0x4804ec: b.eq            #0x4804fc
    // 0x4804f0: r30 = InstantiateTypeArgumentsStub
    //     0x4804f0: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x4804f4: LoadField: r30 = r30->field_7
    //     0x4804f4: ldur            lr, [lr, #7]
    // 0x4804f8: blr             lr
    // 0x4804fc: mov             x1, x0
    // 0x480500: r0 = _CompactValuesIterable()
    //     0x480500: bl              #0x358260  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x480504: mov             x1, x0
    // 0x480508: ldur            x0, [fp, #-0x30]
    // 0x48050c: StoreField: r1->field_b = r0
    //     0x48050c: stur            w0, [x1, #0xb]
    // 0x480510: r0 = iterator()
    //     0x480510: bl              #0x536500  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x480514: stur            x0, [fp, #-0x58]
    // 0x480518: LoadField: r2 = r0->field_7
    //     0x480518: ldur            w2, [x0, #7]
    // 0x48051c: DecompressPointer r2
    //     0x48051c: add             x2, x2, HEAP, lsl #32
    // 0x480520: stur            x2, [fp, #-0x50]
    // 0x480524: r3 = 0
    //     0x480524: movz            x3, #0
    // 0x480528: stur            x3, [fp, #-0x18]
    // 0x48052c: CheckStackOverflow
    //     0x48052c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x480530: cmp             SP, x16
    //     0x480534: b.ls            #0x480e44
    // 0x480538: mov             x1, x0
    // 0x48053c: r0 = moveNext()
    //     0x48053c: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x480540: tbnz            w0, #4, #0x4805b0
    // 0x480544: ldur            x3, [fp, #-0x58]
    // 0x480548: LoadField: r4 = r3->field_33
    //     0x480548: ldur            w4, [x3, #0x33]
    // 0x48054c: DecompressPointer r4
    //     0x48054c: add             x4, x4, HEAP, lsl #32
    // 0x480550: stur            x4, [fp, #-0x60]
    // 0x480554: cmp             w4, NULL
    // 0x480558: b.ne            #0x48058c
    // 0x48055c: mov             x0, x4
    // 0x480560: ldur            x2, [fp, #-0x50]
    // 0x480564: r1 = Null
    //     0x480564: mov             x1, NULL
    // 0x480568: cmp             w2, NULL
    // 0x48056c: b.eq            #0x48058c
    // 0x480570: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x480570: ldur            w4, [x2, #0x17]
    // 0x480574: DecompressPointer r4
    //     0x480574: add             x4, x4, HEAP, lsl #32
    // 0x480578: r8 = X0
    //     0x480578: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x48057c: LoadField: r9 = r4->field_7
    //     0x48057c: ldur            x9, [x4, #7]
    // 0x480580: r3 = Null
    //     0x480580: add             x3, PP, #0xe, lsl #12  ; [pp+0xea88] Null
    //     0x480584: ldr             x3, [x3, #0xa88]
    // 0x480588: blr             x9
    // 0x48058c: ldur            x1, [fp, #-0x18]
    // 0x480590: ldur            x0, [fp, #-0x60]
    // 0x480594: r2 = LoadInt32Instr(r0)
    //     0x480594: sbfx            x2, x0, #1, #0x1f
    //     0x480598: tbz             w0, #0, #0x4805a0
    //     0x48059c: ldur            x2, [x0, #7]
    // 0x4805a0: add             x3, x1, x2
    // 0x4805a4: ldur            x0, [fp, #-0x58]
    // 0x4805a8: ldur            x2, [fp, #-0x50]
    // 0x4805ac: b               #0x480528
    // 0x4805b0: ldur            d0, [fp, #-0x70]
    // 0x4805b4: ldur            x1, [fp, #-0x18]
    // 0x4805b8: d1 = 0.000000
    //     0x4805b8: eor             v1.16b, v1.16b, v1.16b
    // 0x4805bc: scvtf           d2, x1
    // 0x4805c0: fsub            d3, d0, d2
    // 0x4805c4: fmax            v0.2d, v1.2d, v3.2d
    // 0x4805c8: stur            d0, [fp, #-0x70]
    // 0x4805cc: fcmp            d0, d1
    // 0x4805d0: b.ne            #0x4805dc
    // 0x4805d4: d0 = 1.000000
    //     0x4805d4: fmov            d0, #1.00000000
    // 0x4805d8: b               #0x4806ac
    // 0x4805dc: r1 = "CompletionTokenBonusPercent"
    //     0x4805dc: add             x1, PP, #0xe, lsl #12  ; [pp+0xea98] "CompletionTokenBonusPercent"
    //     0x4805e0: ldr             x1, [x1, #0xa98]
    // 0x4805e4: r0 = remoteConfigGetDouble()
    //     0x4805e4: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x4805e8: cmp             w0, NULL
    // 0x4805ec: b.ne            #0x4805f4
    // 0x4805f0: r0 = 10
    //     0x4805f0: movz            x0, #0xa
    // 0x4805f4: ldur            d0, [fp, #-0x70]
    // 0x4805f8: r16 = 0.010000
    //     0x4805f8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x4805fc: ldr             x16, [x16, #0xaa0]
    // 0x480600: stp             x0, x16, [SP]
    // 0x480604: r0 = *()
    //     0x480604: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x480608: LoadField: d0 = r0->field_7
    //     0x480608: ldur            d0, [x0, #7]
    // 0x48060c: ldur            d1, [fp, #-0x70]
    // 0x480610: fmul            d2, d0, d1
    // 0x480614: d0 = 1.000000
    //     0x480614: fmov            d0, #1.00000000
    // 0x480618: fadd            d1, d2, d0
    // 0x48061c: stur            d1, [fp, #-0x70]
    // 0x480620: fcmp            d0, d1
    // 0x480624: b.le            #0x4806a8
    // 0x480628: r1 = Null
    //     0x480628: mov             x1, NULL
    // 0x48062c: r2 = 6
    //     0x48062c: movz            x2, #0x6
    // 0x480630: r0 = AllocateArray()
    //     0x480630: bl              #0x82746c  ; AllocateArrayStub
    // 0x480634: r16 = "Multiplier is "
    //     0x480634: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa8] "Multiplier is "
    //     0x480638: ldr             x16, [x16, #0xaa8]
    // 0x48063c: StoreField: r0->field_f = r16
    //     0x48063c: stur            w16, [x0, #0xf]
    // 0x480640: ldur            d1, [fp, #-0x70]
    // 0x480644: r1 = inline_Allocate_Double()
    //     0x480644: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x480648: add             x1, x1, #0x10
    //     0x48064c: cmp             x2, x1
    //     0x480650: b.ls            #0x480e4c
    //     0x480654: str             x1, [THR, #0x60]  ; THR::top
    //     0x480658: sub             x1, x1, #0xf
    //     0x48065c: movz            x2, #0xe19c
    //     0x480660: movk            x2, #0x3, lsl #16
    //     0x480664: stur            x2, [x1, #-1]
    // 0x480668: dmb             ishst
    // 0x48066c: StoreField: r1->field_7 = d1
    //     0x48066c: stur            d1, [x1, #7]
    // 0x480670: StoreField: r0->field_13 = r1
    //     0x480670: stur            w1, [x0, #0x13]
    // 0x480674: r16 = "!"
    //     0x480674: add             x16, PP, #0xe, lsl #12  ; [pp+0xeab0] "!"
    //     0x480678: ldr             x16, [x16, #0xab0]
    // 0x48067c: ArrayStore: r0[0] = r16  ; List_4
    //     0x48067c: stur            w16, [x0, #0x17]
    // 0x480680: str             x0, [SP]
    // 0x480684: r0 = _interpolate()
    //     0x480684: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x480688: stur            x0, [fp, #-0x50]
    // 0x48068c: r0 = current()
    //     0x48068c: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x480690: ldur            x1, [fp, #-0x50]
    // 0x480694: mov             x2, x0
    // 0x480698: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x480698: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x48069c: r0 = crashlyticsRecordError()
    //     0x48069c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x4806a0: d0 = 1.000000
    //     0x4806a0: fmov            d0, #1.00000000
    // 0x4806a4: b               #0x4806ac
    // 0x4806a8: mov             v0.16b, v1.16b
    // 0x4806ac: stur            d0, [fp, #-0x70]
    // 0x4806b0: fcmp            d0, #0.0
    // 0x4806b4: b.vs            #0x48073c
    // 0x4806b8: b.ne            #0x4806c4
    // 0x4806bc: r0 = 0.000000
    //     0x4806bc: fmov            x0, d0
    // 0x4806c0: cmp             x0, #0
    // 0x4806c4: b.ge            #0x48073c
    // 0x4806c8: r1 = Null
    //     0x4806c8: mov             x1, NULL
    // 0x4806cc: r2 = 4
    //     0x4806cc: movz            x2, #0x4
    // 0x4806d0: r0 = AllocateArray()
    //     0x4806d0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4806d4: r16 = "Negative value: "
    //     0x4806d4: add             x16, PP, #0xe, lsl #12  ; [pp+0xeab8] "Negative value: "
    //     0x4806d8: ldr             x16, [x16, #0xab8]
    // 0x4806dc: StoreField: r0->field_f = r16
    //     0x4806dc: stur            w16, [x0, #0xf]
    // 0x4806e0: ldur            d0, [fp, #-0x70]
    // 0x4806e4: r1 = inline_Allocate_Double()
    //     0x4806e4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x4806e8: add             x1, x1, #0x10
    //     0x4806ec: cmp             x2, x1
    //     0x4806f0: b.ls            #0x480e68
    //     0x4806f4: str             x1, [THR, #0x60]  ; THR::top
    //     0x4806f8: sub             x1, x1, #0xf
    //     0x4806fc: movz            x2, #0xe19c
    //     0x480700: movk            x2, #0x3, lsl #16
    //     0x480704: stur            x2, [x1, #-1]
    // 0x480708: dmb             ishst
    // 0x48070c: StoreField: r1->field_7 = d0
    //     0x48070c: stur            d0, [x1, #7]
    // 0x480710: StoreField: r0->field_13 = r1
    //     0x480710: stur            w1, [x0, #0x13]
    // 0x480714: str             x0, [SP]
    // 0x480718: r0 = _interpolate()
    //     0x480718: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x48071c: stur            x0, [fp, #-0x50]
    // 0x480720: r0 = current()
    //     0x480720: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x480724: ldur            x1, [fp, #-0x50]
    // 0x480728: mov             x2, x0
    // 0x48072c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x48072c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x480730: r0 = crashlyticsRecordError()
    //     0x480730: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x480734: r2 = 0
    //     0x480734: movz            x2, #0
    // 0x480738: b               #0x48076c
    // 0x48073c: r0 = inline_Allocate_Double()
    //     0x48073c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x480740: add             x0, x0, #0x10
    //     0x480744: cmp             x1, x0
    //     0x480748: b.ls            #0x480e84
    //     0x48074c: str             x0, [THR, #0x60]  ; THR::top
    //     0x480750: sub             x0, x0, #0xf
    //     0x480754: movz            x1, #0xe19c
    //     0x480758: movk            x1, #0x3, lsl #16
    //     0x48075c: stur            x1, [x0, #-1]
    // 0x480760: dmb             ishst
    // 0x480764: StoreField: r0->field_7 = d0
    //     0x480764: stur            d0, [x0, #7]
    // 0x480768: mov             x2, x0
    // 0x48076c: ldur            x1, [fp, #-8]
    // 0x480770: ldur            x0, [fp, #-0x48]
    // 0x480774: LoadField: d0 = r0->field_7
    //     0x480774: ldur            d0, [x0, #7]
    // 0x480778: stur            d0, [fp, #-0x70]
    // 0x48077c: r0 = 60
    //     0x48077c: movz            x0, #0x3c
    // 0x480780: branchIfSmi(r2, 0x48078c)
    //     0x480780: tbz             w2, #0, #0x48078c
    // 0x480784: r0 = LoadClassIdInstr(r2)
    //     0x480784: ldur            x0, [x2, #-1]
    //     0x480788: ubfx            x0, x0, #0xc, #0x14
    // 0x48078c: str             x2, [SP]
    // 0x480790: r0 = GDT[cid_x0 + -0x1000]()
    //     0x480790: sub             lr, x0, #1, lsl #12
    //     0x480794: ldr             lr, [x21, lr, lsl #3]
    //     0x480798: blr             lr
    // 0x48079c: LoadField: d0 = r0->field_7
    //     0x48079c: ldur            d0, [x0, #7]
    // 0x4807a0: stp             fp, lr, [SP, #-0x10]!
    // 0x4807a4: mov             fp, SP
    // 0x4807a8: CallRuntime_LibcLog(double) -> double
    //     0x4807a8: and             SP, SP, #0xfffffffffffffff0
    //     0x4807ac: mov             sp, SP
    //     0x4807b0: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x4807b4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4807b8: blr             x16
    //     0x4807bc: movz            x16, #0x8
    //     0x4807c0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4807c4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4807c8: sub             sp, x16, #1, lsl #12
    //     0x4807cc: mov             SP, fp
    //     0x4807d0: ldp             fp, lr, [SP], #0x10
    // 0x4807d4: mov             v1.16b, v0.16b
    // 0x4807d8: ldur            d0, [fp, #-0x70]
    // 0x4807dc: fadd            d2, d0, d1
    // 0x4807e0: mov             v0.16b, v2.16b
    // 0x4807e4: r1 = Null
    //     0x4807e4: mov             x1, NULL
    // 0x4807e8: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x4807e8: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x4807ec: ldur            x2, [fp, #-8]
    // 0x4807f0: StoreField: r2->field_7 = r0
    //     0x4807f0: stur            w0, [x2, #7]
    //     0x4807f4: ldurb           w16, [x2, #-1]
    //     0x4807f8: ldurb           w17, [x0, #-1]
    //     0x4807fc: and             x16, x17, x16, lsr #2
    //     0x480800: tst             x16, HEAP, lsr #32
    //     0x480804: b.eq            #0x48080c
    //     0x480808: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x48080c: ldur            d0, [fp, #-0x68]
    // 0x480810: b               #0x480c44
    // 0x480814: ldur            x2, [fp, #-8]
    // 0x480818: r0 = LoadStaticField(0xa6c)
    //     0x480818: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x48081c: ldr             x0, [x0, #0x14d8]
    // 0x480820: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x480824: cmp             w0, w16
    // 0x480828: b.eq            #0x480e94
    // 0x48082c: mov             x1, x0
    // 0x480830: r0 = get()
    //     0x480830: bl              #0x372f24  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::get
    // 0x480834: mov             x3, x0
    // 0x480838: stur            x3, [fp, #-0x48]
    // 0x48083c: r0 = 60
    //     0x48083c: movz            x0, #0x3c
    // 0x480840: branchIfSmi(r3, 0x48084c)
    //     0x480840: tbz             w3, #0, #0x48084c
    // 0x480844: r0 = LoadClassIdInstr(r3)
    //     0x480844: ldur            x0, [x3, #-1]
    //     0x480848: ubfx            x0, x0, #0xc, #0x14
    // 0x48084c: sub             x16, x0, #0x3c
    // 0x480850: cmp             x16, #1
    // 0x480854: b.hi            #0x480884
    // 0x480858: r0 = 60
    //     0x480858: movz            x0, #0x3c
    // 0x48085c: branchIfSmi(r3, 0x480868)
    //     0x48085c: tbz             w3, #0, #0x480868
    // 0x480860: r0 = LoadClassIdInstr(r3)
    //     0x480860: ldur            x0, [x3, #-1]
    //     0x480864: ubfx            x0, x0, #0xc, #0x14
    // 0x480868: str             x3, [SP]
    // 0x48086c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x48086c: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x480870: r0 = GDT[cid_x0 + 0x3019]()
    //     0x480870: movz            x17, #0x3019
    //     0x480874: add             lr, x0, x17
    //     0x480878: ldr             lr, [x21, lr, lsl #3]
    //     0x48087c: blr             lr
    // 0x480880: b               #0x4808d0
    // 0x480884: mov             x0, x3
    // 0x480888: r2 = Null
    //     0x480888: mov             x2, NULL
    // 0x48088c: r1 = Null
    //     0x48088c: mov             x1, NULL
    // 0x480890: r4 = 60
    //     0x480890: movz            x4, #0x3c
    // 0x480894: branchIfSmi(r0, 0x4808a0)
    //     0x480894: tbz             w0, #0, #0x4808a0
    // 0x480898: r4 = LoadClassIdInstr(r0)
    //     0x480898: ldur            x4, [x0, #-1]
    //     0x48089c: ubfx            x4, x4, #0xc, #0x14
    // 0x4808a0: sub             x4, x4, #0x5e
    // 0x4808a4: cmp             x4, #1
    // 0x4808a8: b.ls            #0x4808bc
    // 0x4808ac: r8 = String?
    //     0x4808ac: ldr             x8, [PP, #0xaf0]  ; [pp+0xaf0] Type: String?
    // 0x4808b0: r3 = Null
    //     0x4808b0: add             x3, PP, #0xe, lsl #12  ; [pp+0xeac0] Null
    //     0x4808b4: ldr             x3, [x3, #0xac0]
    // 0x4808b8: r0 = String?()
    //     0x4808b8: bl              #0x32906c  ; IsType_String?_Stub
    // 0x4808bc: ldur            x0, [fp, #-0x48]
    // 0x4808c0: cmp             w0, NULL
    // 0x4808c4: b.ne            #0x4808d0
    // 0x4808c8: r0 = "1"
    //     0x4808c8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x4808cc: ldr             x0, [x0, #0x9c8]
    // 0x4808d0: ldur            x2, [fp, #-0x40]
    // 0x4808d4: r1 = LoadClassIdInstr(r2)
    //     0x4808d4: ldur            x1, [x2, #-1]
    //     0x4808d8: ubfx            x1, x1, #0xc, #0x14
    // 0x4808dc: stp             x0, x2, [SP]
    // 0x4808e0: mov             x0, x1
    // 0x4808e4: mov             lr, x0
    // 0x4808e8: ldr             lr, [x21, lr, lsl #3]
    // 0x4808ec: blr             lr
    // 0x4808f0: tbnz            w0, #4, #0x480938
    // 0x4808f4: ldur            x0, [fp, #-0x10]
    // 0x4808f8: mov             x1, x0
    // 0x4808fc: ldur            x2, [fp, #-0x40]
    // 0x480900: r0 = _getValueOrData()
    //     0x480900: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x480904: mov             x1, x0
    // 0x480908: ldur            x0, [fp, #-0x10]
    // 0x48090c: LoadField: r2 = r0->field_f
    //     0x48090c: ldur            w2, [x0, #0xf]
    // 0x480910: DecompressPointer r2
    //     0x480910: add             x2, x2, HEAP, lsl #32
    // 0x480914: cmp             w2, w1
    // 0x480918: b.ne            #0x480920
    // 0x48091c: r1 = Null
    //     0x48091c: mov             x1, NULL
    // 0x480920: cmp             w1, NULL
    // 0x480924: b.ne            #0x480930
    // 0x480928: d0 = 0.000000
    //     0x480928: eor             v0.16b, v0.16b, v0.16b
    // 0x48092c: b               #0x480940
    // 0x480930: LoadField: d0 = r1->field_7
    //     0x480930: ldur            d0, [x1, #7]
    // 0x480934: b               #0x480940
    // 0x480938: ldur            x0, [fp, #-0x10]
    // 0x48093c: ldur            d0, [fp, #-0x68]
    // 0x480940: ldur            x3, [fp, #-8]
    // 0x480944: stur            d0, [fp, #-0x70]
    // 0x480948: LoadField: r4 = r3->field_7
    //     0x480948: ldur            w4, [x3, #7]
    // 0x48094c: DecompressPointer r4
    //     0x48094c: add             x4, x4, HEAP, lsl #32
    // 0x480950: stur            x4, [fp, #-0x48]
    // 0x480954: cmp             w4, NULL
    // 0x480958: b.eq            #0x480ea0
    // 0x48095c: mov             x1, x0
    // 0x480960: ldur            x2, [fp, #-0x40]
    // 0x480964: r0 = _getValueOrData()
    //     0x480964: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x480968: mov             x1, x0
    // 0x48096c: ldur            x0, [fp, #-0x10]
    // 0x480970: LoadField: r2 = r0->field_f
    //     0x480970: ldur            w2, [x0, #0xf]
    // 0x480974: DecompressPointer r2
    //     0x480974: add             x2, x2, HEAP, lsl #32
    // 0x480978: cmp             w2, w1
    // 0x48097c: b.ne            #0x480984
    // 0x480980: r1 = Null
    //     0x480980: mov             x1, NULL
    // 0x480984: cmp             w1, NULL
    // 0x480988: b.ne            #0x480994
    // 0x48098c: d0 = 0.000000
    //     0x48098c: eor             v0.16b, v0.16b, v0.16b
    // 0x480990: b               #0x48099c
    // 0x480994: LoadField: d1 = r1->field_7
    //     0x480994: ldur            d1, [x1, #7]
    // 0x480998: mov             v0.16b, v1.16b
    // 0x48099c: ldur            x3, [fp, #-0x30]
    // 0x4809a0: mov             x1, x3
    // 0x4809a4: ldur            x2, [fp, #-0x40]
    // 0x4809a8: stur            d0, [fp, #-0x78]
    // 0x4809ac: r0 = _getValueOrData()
    //     0x4809ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4809b0: mov             x1, x0
    // 0x4809b4: ldur            x0, [fp, #-0x30]
    // 0x4809b8: LoadField: r2 = r0->field_f
    //     0x4809b8: ldur            w2, [x0, #0xf]
    // 0x4809bc: DecompressPointer r2
    //     0x4809bc: add             x2, x2, HEAP, lsl #32
    // 0x4809c0: cmp             w2, w1
    // 0x4809c4: b.ne            #0x4809cc
    // 0x4809c8: r1 = Null
    //     0x4809c8: mov             x1, NULL
    // 0x4809cc: cmp             w1, NULL
    // 0x4809d0: b.ne            #0x4809dc
    // 0x4809d4: r1 = 0
    //     0x4809d4: movz            x1, #0
    // 0x4809d8: b               #0x4809ec
    // 0x4809dc: r2 = LoadInt32Instr(r1)
    //     0x4809dc: sbfx            x2, x1, #1, #0x1f
    //     0x4809e0: tbz             w1, #0, #0x4809e8
    //     0x4809e4: ldur            x2, [x1, #7]
    // 0x4809e8: mov             x1, x2
    // 0x4809ec: ldur            d0, [fp, #-0x78]
    // 0x4809f0: d1 = 0.000000
    //     0x4809f0: eor             v1.16b, v1.16b, v1.16b
    // 0x4809f4: scvtf           d2, x1
    // 0x4809f8: fadd            d3, d0, d2
    // 0x4809fc: stur            d3, [fp, #-0x80]
    // 0x480a00: fcmp            d3, d1
    // 0x480a04: b.ne            #0x480a10
    // 0x480a08: d0 = 1.000000
    //     0x480a08: fmov            d0, #1.00000000
    // 0x480a0c: b               #0x480ae0
    // 0x480a10: r1 = "CompletionTokenBonusPercent"
    //     0x480a10: add             x1, PP, #0xe, lsl #12  ; [pp+0xea98] "CompletionTokenBonusPercent"
    //     0x480a14: ldr             x1, [x1, #0xa98]
    // 0x480a18: r0 = remoteConfigGetDouble()
    //     0x480a18: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x480a1c: cmp             w0, NULL
    // 0x480a20: b.ne            #0x480a28
    // 0x480a24: r0 = 10
    //     0x480a24: movz            x0, #0xa
    // 0x480a28: ldur            d0, [fp, #-0x80]
    // 0x480a2c: r16 = 0.010000
    //     0x480a2c: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x480a30: ldr             x16, [x16, #0xaa0]
    // 0x480a34: stp             x0, x16, [SP]
    // 0x480a38: r0 = *()
    //     0x480a38: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x480a3c: LoadField: d0 = r0->field_7
    //     0x480a3c: ldur            d0, [x0, #7]
    // 0x480a40: ldur            d1, [fp, #-0x80]
    // 0x480a44: fmul            d2, d0, d1
    // 0x480a48: d0 = 1.000000
    //     0x480a48: fmov            d0, #1.00000000
    // 0x480a4c: fadd            d1, d2, d0
    // 0x480a50: stur            d1, [fp, #-0x78]
    // 0x480a54: fcmp            d0, d1
    // 0x480a58: b.le            #0x480adc
    // 0x480a5c: r1 = Null
    //     0x480a5c: mov             x1, NULL
    // 0x480a60: r2 = 6
    //     0x480a60: movz            x2, #0x6
    // 0x480a64: r0 = AllocateArray()
    //     0x480a64: bl              #0x82746c  ; AllocateArrayStub
    // 0x480a68: r16 = "Multiplier is "
    //     0x480a68: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa8] "Multiplier is "
    //     0x480a6c: ldr             x16, [x16, #0xaa8]
    // 0x480a70: StoreField: r0->field_f = r16
    //     0x480a70: stur            w16, [x0, #0xf]
    // 0x480a74: ldur            d1, [fp, #-0x78]
    // 0x480a78: r1 = inline_Allocate_Double()
    //     0x480a78: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x480a7c: add             x1, x1, #0x10
    //     0x480a80: cmp             x2, x1
    //     0x480a84: b.ls            #0x480ea4
    //     0x480a88: str             x1, [THR, #0x60]  ; THR::top
    //     0x480a8c: sub             x1, x1, #0xf
    //     0x480a90: movz            x2, #0xe19c
    //     0x480a94: movk            x2, #0x3, lsl #16
    //     0x480a98: stur            x2, [x1, #-1]
    // 0x480a9c: dmb             ishst
    // 0x480aa0: StoreField: r1->field_7 = d1
    //     0x480aa0: stur            d1, [x1, #7]
    // 0x480aa4: StoreField: r0->field_13 = r1
    //     0x480aa4: stur            w1, [x0, #0x13]
    // 0x480aa8: r16 = "!"
    //     0x480aa8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeab0] "!"
    //     0x480aac: ldr             x16, [x16, #0xab0]
    // 0x480ab0: ArrayStore: r0[0] = r16  ; List_4
    //     0x480ab0: stur            w16, [x0, #0x17]
    // 0x480ab4: str             x0, [SP]
    // 0x480ab8: r0 = _interpolate()
    //     0x480ab8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x480abc: stur            x0, [fp, #-0x40]
    // 0x480ac0: r0 = current()
    //     0x480ac0: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x480ac4: ldur            x1, [fp, #-0x40]
    // 0x480ac8: mov             x2, x0
    // 0x480acc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x480acc: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x480ad0: r0 = crashlyticsRecordError()
    //     0x480ad0: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x480ad4: d0 = 1.000000
    //     0x480ad4: fmov            d0, #1.00000000
    // 0x480ad8: b               #0x480ae0
    // 0x480adc: mov             v0.16b, v1.16b
    // 0x480ae0: stur            d0, [fp, #-0x78]
    // 0x480ae4: fcmp            d0, #0.0
    // 0x480ae8: b.vs            #0x480b70
    // 0x480aec: b.ne            #0x480af8
    // 0x480af0: r0 = 0.000000
    //     0x480af0: fmov            x0, d0
    // 0x480af4: cmp             x0, #0
    // 0x480af8: b.ge            #0x480b70
    // 0x480afc: r1 = Null
    //     0x480afc: mov             x1, NULL
    // 0x480b00: r2 = 4
    //     0x480b00: movz            x2, #0x4
    // 0x480b04: r0 = AllocateArray()
    //     0x480b04: bl              #0x82746c  ; AllocateArrayStub
    // 0x480b08: r16 = "Negative value: "
    //     0x480b08: add             x16, PP, #0xe, lsl #12  ; [pp+0xeab8] "Negative value: "
    //     0x480b0c: ldr             x16, [x16, #0xab8]
    // 0x480b10: StoreField: r0->field_f = r16
    //     0x480b10: stur            w16, [x0, #0xf]
    // 0x480b14: ldur            d0, [fp, #-0x78]
    // 0x480b18: r1 = inline_Allocate_Double()
    //     0x480b18: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x480b1c: add             x1, x1, #0x10
    //     0x480b20: cmp             x2, x1
    //     0x480b24: b.ls            #0x480ec0
    //     0x480b28: str             x1, [THR, #0x60]  ; THR::top
    //     0x480b2c: sub             x1, x1, #0xf
    //     0x480b30: movz            x2, #0xe19c
    //     0x480b34: movk            x2, #0x3, lsl #16
    //     0x480b38: stur            x2, [x1, #-1]
    // 0x480b3c: dmb             ishst
    // 0x480b40: StoreField: r1->field_7 = d0
    //     0x480b40: stur            d0, [x1, #7]
    // 0x480b44: StoreField: r0->field_13 = r1
    //     0x480b44: stur            w1, [x0, #0x13]
    // 0x480b48: str             x0, [SP]
    // 0x480b4c: r0 = _interpolate()
    //     0x480b4c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x480b50: stur            x0, [fp, #-0x40]
    // 0x480b54: r0 = current()
    //     0x480b54: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x480b58: ldur            x1, [fp, #-0x40]
    // 0x480b5c: mov             x2, x0
    // 0x480b60: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x480b60: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x480b64: r0 = crashlyticsRecordError()
    //     0x480b64: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x480b68: r2 = 0
    //     0x480b68: movz            x2, #0
    // 0x480b6c: b               #0x480ba0
    // 0x480b70: r0 = inline_Allocate_Double()
    //     0x480b70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x480b74: add             x0, x0, #0x10
    //     0x480b78: cmp             x1, x0
    //     0x480b7c: b.ls            #0x480edc
    //     0x480b80: str             x0, [THR, #0x60]  ; THR::top
    //     0x480b84: sub             x0, x0, #0xf
    //     0x480b88: movz            x1, #0xe19c
    //     0x480b8c: movk            x1, #0x3, lsl #16
    //     0x480b90: stur            x1, [x0, #-1]
    // 0x480b94: dmb             ishst
    // 0x480b98: StoreField: r0->field_7 = d0
    //     0x480b98: stur            d0, [x0, #7]
    // 0x480b9c: mov             x2, x0
    // 0x480ba0: ldur            x1, [fp, #-8]
    // 0x480ba4: ldur            x0, [fp, #-0x48]
    // 0x480ba8: LoadField: d0 = r0->field_7
    //     0x480ba8: ldur            d0, [x0, #7]
    // 0x480bac: stur            d0, [fp, #-0x78]
    // 0x480bb0: r0 = 60
    //     0x480bb0: movz            x0, #0x3c
    // 0x480bb4: branchIfSmi(r2, 0x480bc0)
    //     0x480bb4: tbz             w2, #0, #0x480bc0
    // 0x480bb8: r0 = LoadClassIdInstr(r2)
    //     0x480bb8: ldur            x0, [x2, #-1]
    //     0x480bbc: ubfx            x0, x0, #0xc, #0x14
    // 0x480bc0: str             x2, [SP]
    // 0x480bc4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x480bc4: sub             lr, x0, #1, lsl #12
    //     0x480bc8: ldr             lr, [x21, lr, lsl #3]
    //     0x480bcc: blr             lr
    // 0x480bd0: LoadField: d0 = r0->field_7
    //     0x480bd0: ldur            d0, [x0, #7]
    // 0x480bd4: stp             fp, lr, [SP, #-0x10]!
    // 0x480bd8: mov             fp, SP
    // 0x480bdc: CallRuntime_LibcLog(double) -> double
    //     0x480bdc: and             SP, SP, #0xfffffffffffffff0
    //     0x480be0: mov             sp, SP
    //     0x480be4: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x480be8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x480bec: blr             x16
    //     0x480bf0: movz            x16, #0x8
    //     0x480bf4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x480bf8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x480bfc: sub             sp, x16, #1, lsl #12
    //     0x480c00: mov             SP, fp
    //     0x480c04: ldp             fp, lr, [SP], #0x10
    // 0x480c08: mov             v1.16b, v0.16b
    // 0x480c0c: ldur            d0, [fp, #-0x78]
    // 0x480c10: fadd            d2, d0, d1
    // 0x480c14: mov             v0.16b, v2.16b
    // 0x480c18: r1 = Null
    //     0x480c18: mov             x1, NULL
    // 0x480c1c: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x480c1c: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x480c20: ldur            x2, [fp, #-8]
    // 0x480c24: StoreField: r2->field_7 = r0
    //     0x480c24: stur            w0, [x2, #7]
    //     0x480c28: ldurb           w16, [x2, #-1]
    //     0x480c2c: ldurb           w17, [x0, #-1]
    //     0x480c30: and             x16, x17, x16, lsr #2
    //     0x480c34: tst             x16, HEAP, lsr #32
    //     0x480c38: b.eq            #0x480c40
    //     0x480c3c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x480c40: ldur            d0, [fp, #-0x70]
    // 0x480c44: mov             x0, x2
    // 0x480c48: ldur            x2, [fp, #-0x38]
    // 0x480c4c: ldur            x3, [fp, #-0x30]
    // 0x480c50: ldur            x5, [fp, #-0x20]
    // 0x480c54: ldur            x4, [fp, #-0x28]
    // 0x480c58: b               #0x4803e8
    // 0x480c5c: ldur            x2, [fp, #-8]
    // 0x480c60: LoadField: r0 = r2->field_7
    //     0x480c60: ldur            w0, [x2, #7]
    // 0x480c64: DecompressPointer r0
    //     0x480c64: add             x0, x0, HEAP, lsl #32
    // 0x480c68: stur            x0, [fp, #-0x10]
    // 0x480c6c: cmp             w0, NULL
    // 0x480c70: b.eq            #0x480eec
    // 0x480c74: mov             x1, x2
    // 0x480c78: ldur            d0, [fp, #-0x68]
    // 0x480c7c: r0 = getPenalty()
    //     0x480c7c: bl              #0x481180  ; [package:pretentious/data/CoreData.dart] CoreData::getPenalty
    // 0x480c80: mov             x1, x0
    // 0x480c84: r0 = invert()
    //     0x480c84: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x480c88: ldur            x1, [fp, #-0x10]
    // 0x480c8c: mov             x2, x0
    // 0x480c90: r0 = mult2()
    //     0x480c90: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x480c94: ldur            x3, [fp, #-8]
    // 0x480c98: StoreField: r3->field_7 = r0
    //     0x480c98: stur            w0, [x3, #7]
    //     0x480c9c: ldurb           w16, [x3, #-1]
    //     0x480ca0: ldurb           w17, [x0, #-1]
    //     0x480ca4: and             x16, x17, x16, lsr #2
    //     0x480ca8: tst             x16, HEAP, lsr #32
    //     0x480cac: b.eq            #0x480cb4
    //     0x480cb0: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x480cb4: r1 = Null
    //     0x480cb4: mov             x1, NULL
    // 0x480cb8: r2 = 6
    //     0x480cb8: movz            x2, #0x6
    // 0x480cbc: r0 = AllocateArray()
    //     0x480cbc: bl              #0x82746c  ; AllocateArrayStub
    // 0x480cc0: stur            x0, [fp, #-0x10]
    // 0x480cc4: r16 = "ch_"
    //     0x480cc4: add             x16, PP, #0xe, lsl #12  ; [pp+0xead0] "ch_"
    //     0x480cc8: ldr             x16, [x16, #0xad0]
    // 0x480ccc: StoreField: r0->field_f = r16
    //     0x480ccc: stur            w16, [x0, #0xf]
    // 0x480cd0: r0 = currentChapterName()
    //     0x480cd0: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x480cd4: ldur            x1, [fp, #-0x10]
    // 0x480cd8: ArrayStore: r1[1] = r0  ; List_4
    //     0x480cd8: add             x25, x1, #0x13
    //     0x480cdc: str             w0, [x25]
    //     0x480ce0: tbz             w0, #0, #0x480cfc
    //     0x480ce4: ldurb           w16, [x1, #-1]
    //     0x480ce8: ldurb           w17, [x0, #-1]
    //     0x480cec: and             x16, x17, x16, lsr #2
    //     0x480cf0: tst             x16, HEAP, lsr #32
    //     0x480cf4: b.eq            #0x480cfc
    //     0x480cf8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x480cfc: ldur            x0, [fp, #-0x10]
    // 0x480d00: r16 = "_multiplier"
    //     0x480d00: add             x16, PP, #0xe, lsl #12  ; [pp+0xead8] "_multiplier"
    //     0x480d04: ldr             x16, [x16, #0xad8]
    // 0x480d08: ArrayStore: r0[0] = r16  ; List_4
    //     0x480d08: stur            w16, [x0, #0x17]
    // 0x480d0c: str             x0, [SP]
    // 0x480d10: r0 = _interpolate()
    //     0x480d10: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x480d14: mov             x1, x0
    // 0x480d18: r0 = remoteConfigGetDouble()
    //     0x480d18: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x480d1c: cmp             w0, NULL
    // 0x480d20: b.eq            #0x480d78
    // 0x480d24: ldur            x3, [fp, #-8]
    // 0x480d28: LoadField: r4 = r3->field_7
    //     0x480d28: ldur            w4, [x3, #7]
    // 0x480d2c: DecompressPointer r4
    //     0x480d2c: add             x4, x4, HEAP, lsl #32
    // 0x480d30: stur            x4, [fp, #-0x10]
    // 0x480d34: cmp             w4, NULL
    // 0x480d38: b.eq            #0x480ef0
    // 0x480d3c: mov             x2, x0
    // 0x480d40: r1 = Null
    //     0x480d40: mov             x1, NULL
    // 0x480d44: r0 = CustomNum()
    //     0x480d44: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x480d48: ldur            x1, [fp, #-0x10]
    // 0x480d4c: mov             x2, x0
    // 0x480d50: r0 = mult2()
    //     0x480d50: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x480d54: ldur            x1, [fp, #-8]
    // 0x480d58: StoreField: r1->field_7 = r0
    //     0x480d58: stur            w0, [x1, #7]
    //     0x480d5c: ldurb           w16, [x1, #-1]
    //     0x480d60: ldurb           w17, [x0, #-1]
    //     0x480d64: and             x16, x17, x16, lsr #2
    //     0x480d68: tst             x16, HEAP, lsr #32
    //     0x480d6c: b.eq            #0x480d74
    //     0x480d70: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x480d74: b               #0x480d7c
    // 0x480d78: ldur            x1, [fp, #-8]
    // 0x480d7c: r0 = Instance_CustomNum
    //     0x480d7c: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x480d80: ldr             x0, [x0, #0xa70]
    // 0x480d84: LoadField: r2 = r1->field_7
    //     0x480d84: ldur            w2, [x1, #7]
    // 0x480d88: DecompressPointer r2
    //     0x480d88: add             x2, x2, HEAP, lsl #32
    // 0x480d8c: cmp             w2, NULL
    // 0x480d90: b.eq            #0x480ef4
    // 0x480d94: LoadField: d0 = r0->field_7
    //     0x480d94: ldur            d0, [x0, #7]
    // 0x480d98: LoadField: d1 = r2->field_7
    //     0x480d98: ldur            d1, [x2, #7]
    // 0x480d9c: fcmp            d0, d1
    // 0x480da0: b.le            #0x480db4
    // 0x480da4: StoreField: r1->field_7 = r0
    //     0x480da4: stur            w0, [x1, #7]
    // 0x480da8: r0 = Instance_CustomNum
    //     0x480da8: add             x0, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x480dac: ldr             x0, [x0, #0xa70]
    // 0x480db0: b               #0x480db8
    // 0x480db4: mov             x0, x2
    // 0x480db8: stur            x0, [fp, #-0x10]
    // 0x480dbc: r0 = getCompletionTokenExponent()
    //     0x480dbc: bl              #0x481030  ; [package:pretentious/data/CoreData.dart] ::getCompletionTokenExponent
    // 0x480dc0: r2 = inline_Allocate_Double()
    //     0x480dc0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x480dc4: add             x2, x2, #0x10
    //     0x480dc8: cmp             x0, x2
    //     0x480dcc: b.ls            #0x480ef8
    //     0x480dd0: str             x2, [THR, #0x60]  ; THR::top
    //     0x480dd4: sub             x2, x2, #0xf
    //     0x480dd8: movz            x0, #0xe19c
    //     0x480ddc: movk            x0, #0x3, lsl #16
    //     0x480de0: stur            x0, [x2, #-1]
    // 0x480de4: dmb             ishst
    // 0x480de8: StoreField: r2->field_7 = d0
    //     0x480de8: stur            d0, [x2, #7]
    // 0x480dec: ldur            x1, [fp, #-0x10]
    // 0x480df0: r0 = pow()
    //     0x480df0: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x480df4: ldur            x1, [fp, #-8]
    // 0x480df8: StoreField: r1->field_7 = r0
    //     0x480df8: stur            w0, [x1, #7]
    //     0x480dfc: ldurb           w16, [x1, #-1]
    //     0x480e00: ldurb           w17, [x0, #-1]
    //     0x480e04: and             x16, x17, x16, lsr #2
    //     0x480e08: tst             x16, HEAP, lsr #32
    //     0x480e0c: b.eq            #0x480e14
    //     0x480e10: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x480e14: r1 = "completion_token_update"
    //     0x480e14: add             x1, PP, #0xe, lsl #12  ; [pp+0xeae0] "completion_token_update"
    //     0x480e18: ldr             x1, [x1, #0xae0]
    // 0x480e1c: r0 = broadcastToListeners()
    //     0x480e1c: bl              #0x4513b8  ; [package:state_groups/src/sync_state.dart] ::broadcastToListeners
    // 0x480e20: r0 = Null
    //     0x480e20: mov             x0, NULL
    // 0x480e24: LeaveFrame
    //     0x480e24: mov             SP, fp
    //     0x480e28: ldp             fp, lr, [SP], #0x10
    // 0x480e2c: ret
    //     0x480e2c: ret             
    // 0x480e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x480e30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x480e34: b               #0x480308
    // 0x480e38: r0 = StackOverflowSharedWithFPURegs()
    //     0x480e38: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x480e3c: b               #0x4803fc
    // 0x480e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x480e40: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x480e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x480e44: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x480e48: b               #0x480538
    // 0x480e4c: SaveReg d1
    //     0x480e4c: str             q1, [SP, #-0x10]!
    // 0x480e50: SaveReg r0
    //     0x480e50: str             x0, [SP, #-8]!
    // 0x480e54: r0 = AllocateDouble()
    //     0x480e54: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480e58: mov             x1, x0
    // 0x480e5c: RestoreReg r0
    //     0x480e5c: ldr             x0, [SP], #8
    // 0x480e60: RestoreReg d1
    //     0x480e60: ldr             q1, [SP], #0x10
    // 0x480e64: b               #0x48066c
    // 0x480e68: SaveReg d0
    //     0x480e68: str             q0, [SP, #-0x10]!
    // 0x480e6c: SaveReg r0
    //     0x480e6c: str             x0, [SP, #-8]!
    // 0x480e70: r0 = AllocateDouble()
    //     0x480e70: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480e74: mov             x1, x0
    // 0x480e78: RestoreReg r0
    //     0x480e78: ldr             x0, [SP], #8
    // 0x480e7c: RestoreReg d0
    //     0x480e7c: ldr             q0, [SP], #0x10
    // 0x480e80: b               #0x48070c
    // 0x480e84: SaveReg d0
    //     0x480e84: str             q0, [SP, #-0x10]!
    // 0x480e88: r0 = AllocateDouble()
    //     0x480e88: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480e8c: RestoreReg d0
    //     0x480e8c: ldr             q0, [SP], #0x10
    // 0x480e90: b               #0x480764
    // 0x480e94: r9 = prefs
    //     0x480e94: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x480e98: ldr             x9, [x9, #0xc00]
    // 0x480e9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x480e9c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x480ea0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x480ea0: bl              #0x827c54  ; NullCastErrorSharedWithFPURegsStub
    // 0x480ea4: SaveReg d1
    //     0x480ea4: str             q1, [SP, #-0x10]!
    // 0x480ea8: SaveReg r0
    //     0x480ea8: str             x0, [SP, #-8]!
    // 0x480eac: r0 = AllocateDouble()
    //     0x480eac: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480eb0: mov             x1, x0
    // 0x480eb4: RestoreReg r0
    //     0x480eb4: ldr             x0, [SP], #8
    // 0x480eb8: RestoreReg d1
    //     0x480eb8: ldr             q1, [SP], #0x10
    // 0x480ebc: b               #0x480aa0
    // 0x480ec0: SaveReg d0
    //     0x480ec0: str             q0, [SP, #-0x10]!
    // 0x480ec4: SaveReg r0
    //     0x480ec4: str             x0, [SP, #-8]!
    // 0x480ec8: r0 = AllocateDouble()
    //     0x480ec8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480ecc: mov             x1, x0
    // 0x480ed0: RestoreReg r0
    //     0x480ed0: ldr             x0, [SP], #8
    // 0x480ed4: RestoreReg d0
    //     0x480ed4: ldr             q0, [SP], #0x10
    // 0x480ed8: b               #0x480b40
    // 0x480edc: SaveReg d0
    //     0x480edc: str             q0, [SP, #-0x10]!
    // 0x480ee0: r0 = AllocateDouble()
    //     0x480ee0: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480ee4: RestoreReg d0
    //     0x480ee4: ldr             q0, [SP], #0x10
    // 0x480ee8: b               #0x480b98
    // 0x480eec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x480eec: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x480ef0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x480ef0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x480ef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x480ef4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x480ef8: SaveReg d0
    //     0x480ef8: str             q0, [SP, #-0x10]!
    // 0x480efc: r0 = AllocateDouble()
    //     0x480efc: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x480f00: mov             x2, x0
    // 0x480f04: RestoreReg d0
    //     0x480f04: ldr             q0, [SP], #0x10
    // 0x480f08: b               #0x480de8
  }
  _ getPenalty(/* No info */) {
    // ** addr: 0x481180, size: 0x18c
    // 0x481180: EnterFrame
    //     0x481180: stp             fp, lr, [SP, #-0x10]!
    //     0x481184: mov             fp, SP
    // 0x481188: AllocStack(0x18)
    //     0x481188: sub             SP, SP, #0x18
    // 0x48118c: SetupParameters(dynamic _ /* d0 => d0, fp-0x8 */)
    //     0x48118c: stur            d0, [fp, #-8]
    // 0x481190: CheckStackOverflow
    //     0x481190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x481194: cmp             SP, x16
    //     0x481198: b.ls            #0x4812b8
    // 0x48119c: r1 = "CompletionTokenPenaltyPercent"
    //     0x48119c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb30] "CompletionTokenPenaltyPercent"
    //     0x4811a0: ldr             x1, [x1, #0xb30]
    // 0x4811a4: r0 = remoteConfigGetDouble()
    //     0x4811a4: bl              #0x46127c  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetDouble
    // 0x4811a8: cmp             w0, NULL
    // 0x4811ac: b.ne            #0x4811b4
    // 0x4811b0: r0 = 0
    //     0x4811b0: movz            x0, #0
    // 0x4811b4: ldur            d0, [fp, #-8]
    // 0x4811b8: r16 = 0.010000
    //     0x4811b8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeaa0] 0.01
    //     0x4811bc: ldr             x16, [x16, #0xaa0]
    // 0x4811c0: stp             x0, x16, [SP]
    // 0x4811c4: r0 = *()
    //     0x4811c4: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x4811c8: LoadField: d0 = r0->field_7
    //     0x4811c8: ldur            d0, [x0, #7]
    // 0x4811cc: d1 = 1.000000
    //     0x4811cc: fmov            d1, #1.00000000
    // 0x4811d0: fadd            d2, d0, d1
    // 0x4811d4: r2 = inline_Allocate_Double()
    //     0x4811d4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x4811d8: add             x2, x2, #0x10
    //     0x4811dc: cmp             x0, x2
    //     0x4811e0: b.ls            #0x4812c0
    //     0x4811e4: str             x2, [THR, #0x60]  ; THR::top
    //     0x4811e8: sub             x2, x2, #0xf
    //     0x4811ec: movz            x0, #0xe19c
    //     0x4811f0: movk            x0, #0x3, lsl #16
    //     0x4811f4: stur            x0, [x2, #-1]
    // 0x4811f8: dmb             ishst
    // 0x4811fc: StoreField: r2->field_7 = d2
    //     0x4811fc: stur            d2, [x2, #7]
    // 0x481200: r1 = Null
    //     0x481200: mov             x1, NULL
    // 0x481204: r0 = CustomNum()
    //     0x481204: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x481208: ldur            d0, [fp, #-8]
    // 0x48120c: d1 = 5.000000
    //     0x48120c: fmov            d1, #5.00000000
    // 0x481210: fsub            d2, d0, d1
    // 0x481214: d0 = 0.000000
    //     0x481214: eor             v0.16b, v0.16b, v0.16b
    // 0x481218: fcmp            d0, d2
    // 0x48121c: b.le            #0x481228
    // 0x481220: r2 = 0
    //     0x481220: movz            x2, #0
    // 0x481224: b               #0x4812a4
    // 0x481228: fcmp            d2, d0
    // 0x48122c: b.le            #0x481264
    // 0x481230: r1 = inline_Allocate_Double()
    //     0x481230: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x481234: add             x1, x1, #0x10
    //     0x481238: cmp             x2, x1
    //     0x48123c: b.ls            #0x4812d4
    //     0x481240: str             x1, [THR, #0x60]  ; THR::top
    //     0x481244: sub             x1, x1, #0xf
    //     0x481248: movz            x2, #0xe19c
    //     0x48124c: movk            x2, #0x3, lsl #16
    //     0x481250: stur            x2, [x1, #-1]
    // 0x481254: dmb             ishst
    // 0x481258: StoreField: r1->field_7 = d2
    //     0x481258: stur            d2, [x1, #7]
    // 0x48125c: mov             x2, x1
    // 0x481260: b               #0x4812a4
    // 0x481264: fcmp            d2, d2
    // 0x481268: b.vc            #0x4812a0
    // 0x48126c: r1 = inline_Allocate_Double()
    //     0x48126c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x481270: add             x1, x1, #0x10
    //     0x481274: cmp             x2, x1
    //     0x481278: b.ls            #0x4812f0
    //     0x48127c: str             x1, [THR, #0x60]  ; THR::top
    //     0x481280: sub             x1, x1, #0xf
    //     0x481284: movz            x2, #0xe19c
    //     0x481288: movk            x2, #0x3, lsl #16
    //     0x48128c: stur            x2, [x1, #-1]
    // 0x481290: dmb             ishst
    // 0x481294: StoreField: r1->field_7 = d2
    //     0x481294: stur            d2, [x1, #7]
    // 0x481298: mov             x2, x1
    // 0x48129c: b               #0x4812a4
    // 0x4812a0: r2 = 0
    //     0x4812a0: movz            x2, #0
    // 0x4812a4: mov             x1, x0
    // 0x4812a8: r0 = pow()
    //     0x4812a8: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x4812ac: LeaveFrame
    //     0x4812ac: mov             SP, fp
    //     0x4812b0: ldp             fp, lr, [SP], #0x10
    // 0x4812b4: ret
    //     0x4812b4: ret             
    // 0x4812b8: r0 = StackOverflowSharedWithFPURegs()
    //     0x4812b8: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x4812bc: b               #0x48119c
    // 0x4812c0: SaveReg d2
    //     0x4812c0: str             q2, [SP, #-0x10]!
    // 0x4812c4: r0 = AllocateDouble()
    //     0x4812c4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4812c8: mov             x2, x0
    // 0x4812cc: RestoreReg d2
    //     0x4812cc: ldr             q2, [SP], #0x10
    // 0x4812d0: b               #0x4811fc
    // 0x4812d4: SaveReg d2
    //     0x4812d4: str             q2, [SP, #-0x10]!
    // 0x4812d8: SaveReg r0
    //     0x4812d8: str             x0, [SP, #-8]!
    // 0x4812dc: r0 = AllocateDouble()
    //     0x4812dc: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4812e0: mov             x1, x0
    // 0x4812e4: RestoreReg r0
    //     0x4812e4: ldr             x0, [SP], #8
    // 0x4812e8: RestoreReg d2
    //     0x4812e8: ldr             q2, [SP], #0x10
    // 0x4812ec: b               #0x481258
    // 0x4812f0: SaveReg d2
    //     0x4812f0: str             q2, [SP, #-0x10]!
    // 0x4812f4: SaveReg r0
    //     0x4812f4: str             x0, [SP, #-8]!
    // 0x4812f8: r0 = AllocateDouble()
    //     0x4812f8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4812fc: mov             x1, x0
    // 0x481300: RestoreReg r0
    //     0x481300: ldr             x0, [SP], #8
    // 0x481304: RestoreReg d2
    //     0x481304: ldr             q2, [SP], #0x10
    // 0x481308: b               #0x481294
  }
  _ numAssignedTokens(/* No info */) {
    // ** addr: 0x48130c, size: 0x120
    // 0x48130c: EnterFrame
    //     0x48130c: stp             fp, lr, [SP, #-0x10]!
    //     0x481310: mov             fp, SP
    // 0x481314: AllocStack(0x20)
    //     0x481314: sub             SP, SP, #0x20
    // 0x481318: CheckStackOverflow
    //     0x481318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x48131c: cmp             SP, x16
    //     0x481320: b.ls            #0x48141c
    // 0x481324: LoadField: r0 = r1->field_27
    //     0x481324: ldur            w0, [x1, #0x27]
    // 0x481328: DecompressPointer r0
    //     0x481328: add             x0, x0, HEAP, lsl #32
    // 0x48132c: stur            x0, [fp, #-8]
    // 0x481330: LoadField: r2 = r0->field_7
    //     0x481330: ldur            w2, [x0, #7]
    // 0x481334: DecompressPointer r2
    //     0x481334: add             x2, x2, HEAP, lsl #32
    // 0x481338: r1 = Null
    //     0x481338: mov             x1, NULL
    // 0x48133c: r3 = <X1>
    //     0x48133c: ldr             x3, [PP, #0x1fb8]  ; [pp+0x1fb8] TypeArguments: <X1>
    // 0x481340: r0 = Null
    //     0x481340: mov             x0, NULL
    // 0x481344: cmp             x2, x0
    // 0x481348: b.eq            #0x481358
    // 0x48134c: r30 = InstantiateTypeArgumentsStub
    //     0x48134c: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x481350: LoadField: r30 = r30->field_7
    //     0x481350: ldur            lr, [lr, #7]
    // 0x481354: blr             lr
    // 0x481358: mov             x1, x0
    // 0x48135c: r0 = _CompactValuesIterable()
    //     0x48135c: bl              #0x358260  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x481360: mov             x1, x0
    // 0x481364: ldur            x0, [fp, #-8]
    // 0x481368: StoreField: r1->field_b = r0
    //     0x481368: stur            w0, [x1, #0xb]
    // 0x48136c: r0 = iterator()
    //     0x48136c: bl              #0x536500  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x481370: stur            x0, [fp, #-0x18]
    // 0x481374: LoadField: r2 = r0->field_7
    //     0x481374: ldur            w2, [x0, #7]
    // 0x481378: DecompressPointer r2
    //     0x481378: add             x2, x2, HEAP, lsl #32
    // 0x48137c: stur            x2, [fp, #-8]
    // 0x481380: r3 = 0
    //     0x481380: movz            x3, #0
    // 0x481384: stur            x3, [fp, #-0x10]
    // 0x481388: CheckStackOverflow
    //     0x481388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x48138c: cmp             SP, x16
    //     0x481390: b.ls            #0x481424
    // 0x481394: mov             x1, x0
    // 0x481398: r0 = moveNext()
    //     0x481398: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x48139c: tbnz            w0, #4, #0x48140c
    // 0x4813a0: ldur            x3, [fp, #-0x18]
    // 0x4813a4: LoadField: r4 = r3->field_33
    //     0x4813a4: ldur            w4, [x3, #0x33]
    // 0x4813a8: DecompressPointer r4
    //     0x4813a8: add             x4, x4, HEAP, lsl #32
    // 0x4813ac: stur            x4, [fp, #-0x20]
    // 0x4813b0: cmp             w4, NULL
    // 0x4813b4: b.ne            #0x4813e8
    // 0x4813b8: mov             x0, x4
    // 0x4813bc: ldur            x2, [fp, #-8]
    // 0x4813c0: r1 = Null
    //     0x4813c0: mov             x1, NULL
    // 0x4813c4: cmp             w2, NULL
    // 0x4813c8: b.eq            #0x4813e8
    // 0x4813cc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x4813cc: ldur            w4, [x2, #0x17]
    // 0x4813d0: DecompressPointer r4
    //     0x4813d0: add             x4, x4, HEAP, lsl #32
    // 0x4813d4: r8 = X0
    //     0x4813d4: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x4813d8: LoadField: r9 = r4->field_7
    //     0x4813d8: ldur            x9, [x4, #7]
    // 0x4813dc: r3 = Null
    //     0x4813dc: add             x3, PP, #0xe, lsl #12  ; [pp+0xeb58] Null
    //     0x4813e0: ldr             x3, [x3, #0xb58]
    // 0x4813e4: blr             x9
    // 0x4813e8: ldur            x0, [fp, #-0x10]
    // 0x4813ec: ldur            x1, [fp, #-0x20]
    // 0x4813f0: r2 = LoadInt32Instr(r1)
    //     0x4813f0: sbfx            x2, x1, #1, #0x1f
    //     0x4813f4: tbz             w1, #0, #0x4813fc
    //     0x4813f8: ldur            x2, [x1, #7]
    // 0x4813fc: add             x3, x0, x2
    // 0x481400: ldur            x0, [fp, #-0x18]
    // 0x481404: ldur            x2, [fp, #-8]
    // 0x481408: b               #0x481384
    // 0x48140c: ldur            x0, [fp, #-0x10]
    // 0x481410: LeaveFrame
    //     0x481410: mov             SP, fp
    //     0x481414: ldp             fp, lr, [SP], #0x10
    // 0x481418: ret
    //     0x481418: ret             
    // 0x48141c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x48141c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x481420: b               #0x481324
    // 0x481424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x481424: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x481428: b               #0x481394
  }
  factory _ CoreData.fromData(/* No info */) {
    // ** addr: 0x481438, size: 0x600
    // 0x481438: EnterFrame
    //     0x481438: stp             fp, lr, [SP, #-0x10]!
    //     0x48143c: mov             fp, SP
    // 0x481440: AllocStack(0x50)
    //     0x481440: sub             SP, SP, #0x50
    // 0x481444: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x481444: mov             x0, x1
    //     0x481448: mov             x1, x2
    //     0x48144c: stur            x2, [fp, #-8]
    // 0x481450: CheckStackOverflow
    //     0x481450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x481454: cmp             SP, x16
    //     0x481458: b.ls            #0x481a28
    // 0x48145c: r16 = <String, double>
    //     0x48145c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12870] TypeArguments: <String, double>
    //     0x481460: ldr             x16, [x16, #0x870]
    // 0x481464: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x481468: stp             lr, x16, [SP]
    // 0x48146c: r0 = Map._fromLiteral()
    //     0x48146c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x481470: mov             x4, x0
    // 0x481474: ldur            x3, [fp, #-8]
    // 0x481478: stur            x4, [fp, #-0x10]
    // 0x48147c: r0 = LoadClassIdInstr(r3)
    //     0x48147c: ldur            x0, [x3, #-1]
    //     0x481480: ubfx            x0, x0, #0xc, #0x14
    // 0x481484: mov             x1, x3
    // 0x481488: r2 = 4
    //     0x481488: movz            x2, #0x4
    // 0x48148c: r0 = GDT[cid_x0 + -0xf99]()
    //     0x48148c: sub             lr, x0, #0xf99
    //     0x481490: ldr             lr, [x21, lr, lsl #3]
    //     0x481494: blr             lr
    // 0x481498: tbnz            w0, #4, #0x4816d8
    // 0x48149c: ldur            x3, [fp, #-8]
    // 0x4814a0: r0 = LoadClassIdInstr(r3)
    //     0x4814a0: ldur            x0, [x3, #-1]
    //     0x4814a4: ubfx            x0, x0, #0xc, #0x14
    // 0x4814a8: mov             x1, x3
    // 0x4814ac: r2 = 4
    //     0x4814ac: movz            x2, #0x4
    // 0x4814b0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4814b0: sub             lr, x0, #1, lsl #12
    //     0x4814b4: ldr             lr, [x21, lr, lsl #3]
    //     0x4814b8: blr             lr
    // 0x4814bc: mov             x3, x0
    // 0x4814c0: r2 = Null
    //     0x4814c0: mov             x2, NULL
    // 0x4814c4: r1 = Null
    //     0x4814c4: mov             x1, NULL
    // 0x4814c8: stur            x3, [fp, #-0x18]
    // 0x4814cc: r8 = Map
    //     0x4814cc: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x4814d0: r3 = Null
    //     0x4814d0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12878] Null
    //     0x4814d4: ldr             x3, [x3, #0x878]
    // 0x4814d8: r0 = Map()
    //     0x4814d8: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x4814dc: ldur            x1, [fp, #-0x18]
    // 0x4814e0: r0 = LoadClassIdInstr(r1)
    //     0x4814e0: ldur            x0, [x1, #-1]
    //     0x4814e4: ubfx            x0, x0, #0xc, #0x14
    // 0x4814e8: r0 = GDT[cid_x0 + -0xfa3]()
    //     0x4814e8: sub             lr, x0, #0xfa3
    //     0x4814ec: ldr             lr, [x21, lr, lsl #3]
    //     0x4814f0: blr             lr
    // 0x4814f4: r1 = LoadClassIdInstr(r0)
    //     0x4814f4: ldur            x1, [x0, #-1]
    //     0x4814f8: ubfx            x1, x1, #0xc, #0x14
    // 0x4814fc: mov             x16, x0
    // 0x481500: mov             x0, x1
    // 0x481504: mov             x1, x16
    // 0x481508: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x481508: movz            x17, #0x7df6
    //     0x48150c: add             lr, x0, x17
    //     0x481510: ldr             lr, [x21, lr, lsl #3]
    //     0x481514: blr             lr
    // 0x481518: mov             x2, x0
    // 0x48151c: stur            x2, [fp, #-0x18]
    // 0x481520: CheckStackOverflow
    //     0x481520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x481524: cmp             SP, x16
    //     0x481528: b.ls            #0x481a30
    // 0x48152c: r0 = LoadClassIdInstr(r2)
    //     0x48152c: ldur            x0, [x2, #-1]
    //     0x481530: ubfx            x0, x0, #0xc, #0x14
    // 0x481534: mov             x1, x2
    // 0x481538: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x481538: sub             lr, x0, #0xfc4
    //     0x48153c: ldr             lr, [x21, lr, lsl #3]
    //     0x481540: blr             lr
    // 0x481544: tbnz            w0, #4, #0x4816d8
    // 0x481548: ldur            x2, [fp, #-0x18]
    // 0x48154c: r0 = LoadClassIdInstr(r2)
    //     0x48154c: ldur            x0, [x2, #-1]
    //     0x481550: ubfx            x0, x0, #0xc, #0x14
    // 0x481554: mov             x1, x2
    // 0x481558: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x481558: sub             lr, x0, #0xfb6
    //     0x48155c: ldr             lr, [x21, lr, lsl #3]
    //     0x481560: blr             lr
    // 0x481564: LoadField: r3 = r0->field_f
    //     0x481564: ldur            w3, [x0, #0xf]
    // 0x481568: DecompressPointer r3
    //     0x481568: add             x3, x3, HEAP, lsl #32
    // 0x48156c: stur            x3, [fp, #-0x28]
    // 0x481570: r1 = 60
    //     0x481570: movz            x1, #0x3c
    // 0x481574: branchIfSmi(r3, 0x481580)
    //     0x481574: tbz             w3, #0, #0x481580
    // 0x481578: r1 = LoadClassIdInstr(r3)
    //     0x481578: ldur            x1, [x3, #-1]
    //     0x48157c: ubfx            x1, x1, #0xc, #0x14
    // 0x481580: sub             x16, x1, #0x3c
    // 0x481584: cmp             x16, #1
    // 0x481588: b.hi            #0x481638
    // 0x48158c: LoadField: r4 = r0->field_b
    //     0x48158c: ldur            w4, [x0, #0xb]
    // 0x481590: DecompressPointer r4
    //     0x481590: add             x4, x4, HEAP, lsl #32
    // 0x481594: mov             x0, x4
    // 0x481598: stur            x4, [fp, #-0x20]
    // 0x48159c: r2 = Null
    //     0x48159c: mov             x2, NULL
    // 0x4815a0: r1 = Null
    //     0x4815a0: mov             x1, NULL
    // 0x4815a4: r4 = 60
    //     0x4815a4: movz            x4, #0x3c
    // 0x4815a8: branchIfSmi(r0, 0x4815b4)
    //     0x4815a8: tbz             w0, #0, #0x4815b4
    // 0x4815ac: r4 = LoadClassIdInstr(r0)
    //     0x4815ac: ldur            x4, [x0, #-1]
    //     0x4815b0: ubfx            x4, x4, #0xc, #0x14
    // 0x4815b4: sub             x4, x4, #0x5e
    // 0x4815b8: cmp             x4, #1
    // 0x4815bc: b.ls            #0x4815d0
    // 0x4815c0: r8 = String
    //     0x4815c0: ldr             x8, [PP, #0x348]  ; [pp+0x348] Type: String
    // 0x4815c4: r3 = Null
    //     0x4815c4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12888] Null
    //     0x4815c8: ldr             x3, [x3, #0x888]
    // 0x4815cc: r0 = String()
    //     0x4815cc: bl              #0x82b41c  ; IsType_String_Stub
    // 0x4815d0: ldur            x0, [fp, #-0x28]
    // 0x4815d4: r2 = Null
    //     0x4815d4: mov             x2, NULL
    // 0x4815d8: r1 = Null
    //     0x4815d8: mov             x1, NULL
    // 0x4815dc: branchIfSmi(r0, 0x481604)
    //     0x4815dc: tbz             w0, #0, #0x481604
    // 0x4815e0: r4 = LoadClassIdInstr(r0)
    //     0x4815e0: ldur            x4, [x0, #-1]
    //     0x4815e4: ubfx            x4, x4, #0xc, #0x14
    // 0x4815e8: sub             x4, x4, #0x3c
    // 0x4815ec: cmp             x4, #1
    // 0x4815f0: b.ls            #0x481604
    // 0x4815f4: r8 = int
    //     0x4815f4: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x4815f8: r3 = Null
    //     0x4815f8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12898] Null
    //     0x4815fc: ldr             x3, [x3, #0x898]
    // 0x481600: r0 = int()
    //     0x481600: bl              #0x82bb04  ; IsType_int_Stub
    // 0x481604: ldur            x16, [fp, #-0x28]
    // 0x481608: stp             x16, NULL, [SP]
    // 0x48160c: r0 = _Double.fromInteger()
    //     0x48160c: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x481610: ldur            x1, [fp, #-0x10]
    // 0x481614: ldur            x2, [fp, #-0x20]
    // 0x481618: stur            x0, [fp, #-0x30]
    // 0x48161c: r0 = _hashCode()
    //     0x48161c: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x481620: ldur            x1, [fp, #-0x10]
    // 0x481624: ldur            x2, [fp, #-0x20]
    // 0x481628: ldur            x3, [fp, #-0x30]
    // 0x48162c: mov             x5, x0
    // 0x481630: r0 = _set()
    //     0x481630: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x481634: b               #0x4816d0
    // 0x481638: LoadField: r3 = r0->field_b
    //     0x481638: ldur            w3, [x0, #0xb]
    // 0x48163c: DecompressPointer r3
    //     0x48163c: add             x3, x3, HEAP, lsl #32
    // 0x481640: mov             x0, x3
    // 0x481644: stur            x3, [fp, #-0x20]
    // 0x481648: r2 = Null
    //     0x481648: mov             x2, NULL
    // 0x48164c: r1 = Null
    //     0x48164c: mov             x1, NULL
    // 0x481650: r4 = 60
    //     0x481650: movz            x4, #0x3c
    // 0x481654: branchIfSmi(r0, 0x481660)
    //     0x481654: tbz             w0, #0, #0x481660
    // 0x481658: r4 = LoadClassIdInstr(r0)
    //     0x481658: ldur            x4, [x0, #-1]
    //     0x48165c: ubfx            x4, x4, #0xc, #0x14
    // 0x481660: sub             x4, x4, #0x5e
    // 0x481664: cmp             x4, #1
    // 0x481668: b.ls            #0x48167c
    // 0x48166c: r8 = String
    //     0x48166c: ldr             x8, [PP, #0x348]  ; [pp+0x348] Type: String
    // 0x481670: r3 = Null
    //     0x481670: add             x3, PP, #0x12, lsl #12  ; [pp+0x128a8] Null
    //     0x481674: ldr             x3, [x3, #0x8a8]
    // 0x481678: r0 = String()
    //     0x481678: bl              #0x82b41c  ; IsType_String_Stub
    // 0x48167c: ldur            x0, [fp, #-0x28]
    // 0x481680: r2 = Null
    //     0x481680: mov             x2, NULL
    // 0x481684: r1 = Null
    //     0x481684: mov             x1, NULL
    // 0x481688: r4 = 60
    //     0x481688: movz            x4, #0x3c
    // 0x48168c: branchIfSmi(r0, 0x481698)
    //     0x48168c: tbz             w0, #0, #0x481698
    // 0x481690: r4 = LoadClassIdInstr(r0)
    //     0x481690: ldur            x4, [x0, #-1]
    //     0x481694: ubfx            x4, x4, #0xc, #0x14
    // 0x481698: cmp             x4, #0x3e
    // 0x48169c: b.eq            #0x4816b0
    // 0x4816a0: r8 = double
    //     0x4816a0: ldr             x8, [PP, #0xc50]  ; [pp+0xc50] Type: double
    // 0x4816a4: r3 = Null
    //     0x4816a4: add             x3, PP, #0x12, lsl #12  ; [pp+0x128b8] Null
    //     0x4816a8: ldr             x3, [x3, #0x8b8]
    // 0x4816ac: r0 = double()
    //     0x4816ac: bl              #0x82b4cc  ; IsType_double_Stub
    // 0x4816b0: ldur            x1, [fp, #-0x10]
    // 0x4816b4: ldur            x2, [fp, #-0x20]
    // 0x4816b8: r0 = _hashCode()
    //     0x4816b8: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x4816bc: ldur            x1, [fp, #-0x10]
    // 0x4816c0: ldur            x2, [fp, #-0x20]
    // 0x4816c4: ldur            x3, [fp, #-0x28]
    // 0x4816c8: mov             x5, x0
    // 0x4816cc: r0 = _set()
    //     0x4816cc: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x4816d0: ldur            x2, [fp, #-0x18]
    // 0x4816d4: b               #0x481520
    // 0x4816d8: ldur            x3, [fp, #-8]
    // 0x4816dc: r0 = LoadClassIdInstr(r3)
    //     0x4816dc: ldur            x0, [x3, #-1]
    //     0x4816e0: ubfx            x0, x0, #0xc, #0x14
    // 0x4816e4: mov             x1, x3
    // 0x4816e8: r2 = 0
    //     0x4816e8: movz            x2, #0
    // 0x4816ec: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4816ec: sub             lr, x0, #1, lsl #12
    //     0x4816f0: ldr             lr, [x21, lr, lsl #3]
    //     0x4816f4: blr             lr
    // 0x4816f8: mov             x3, x0
    // 0x4816fc: r2 = Null
    //     0x4816fc: mov             x2, NULL
    // 0x481700: r1 = Null
    //     0x481700: mov             x1, NULL
    // 0x481704: stur            x3, [fp, #-0x18]
    // 0x481708: branchIfSmi(r0, 0x481730)
    //     0x481708: tbz             w0, #0, #0x481730
    // 0x48170c: r4 = LoadClassIdInstr(r0)
    //     0x48170c: ldur            x4, [x0, #-1]
    //     0x481710: ubfx            x4, x4, #0xc, #0x14
    // 0x481714: sub             x4, x4, #0x3c
    // 0x481718: cmp             x4, #1
    // 0x48171c: b.ls            #0x481730
    // 0x481720: r8 = int
    //     0x481720: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x481724: r3 = Null
    //     0x481724: add             x3, PP, #0x12, lsl #12  ; [pp+0x128c8] Null
    //     0x481728: ldr             x3, [x3, #0x8c8]
    // 0x48172c: r0 = int()
    //     0x48172c: bl              #0x82bb04  ; IsType_int_Stub
    // 0x481730: r0 = DateTime()
    //     0x481730: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x481734: mov             x1, x0
    // 0x481738: ldur            x2, [fp, #-0x18]
    // 0x48173c: stur            x0, [fp, #-0x18]
    // 0x481740: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x481740: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x481744: r0 = DateTime.fromMillisecondsSinceEpoch()
    //     0x481744: bl              #0x450518  ; [dart:core] DateTime::DateTime.fromMillisecondsSinceEpoch
    // 0x481748: ldur            x3, [fp, #-8]
    // 0x48174c: r0 = LoadClassIdInstr(r3)
    //     0x48174c: ldur            x0, [x3, #-1]
    //     0x481750: ubfx            x0, x0, #0xc, #0x14
    // 0x481754: mov             x1, x3
    // 0x481758: r2 = 2
    //     0x481758: movz            x2, #0x2
    // 0x48175c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x48175c: sub             lr, x0, #1, lsl #12
    //     0x481760: ldr             lr, [x21, lr, lsl #3]
    //     0x481764: blr             lr
    // 0x481768: mov             x3, x0
    // 0x48176c: r2 = Null
    //     0x48176c: mov             x2, NULL
    // 0x481770: r1 = Null
    //     0x481770: mov             x1, NULL
    // 0x481774: stur            x3, [fp, #-0x20]
    // 0x481778: r8 = Map
    //     0x481778: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x48177c: r3 = Null
    //     0x48177c: add             x3, PP, #0x12, lsl #12  ; [pp+0x128d8] Null
    //     0x481780: ldr             x3, [x3, #0x8d8]
    // 0x481784: r0 = Map()
    //     0x481784: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x481788: ldur            x2, [fp, #-0x20]
    // 0x48178c: r1 = <int, int>
    //     0x48178c: ldr             x1, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x481790: r0 = LinkedHashMap.from()
    //     0x481790: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x481794: mov             x4, x0
    // 0x481798: ldur            x3, [fp, #-8]
    // 0x48179c: stur            x4, [fp, #-0x20]
    // 0x4817a0: r0 = LoadClassIdInstr(r3)
    //     0x4817a0: ldur            x0, [x3, #-1]
    //     0x4817a4: ubfx            x0, x0, #0xc, #0x14
    // 0x4817a8: mov             x1, x3
    // 0x4817ac: r2 = 6
    //     0x4817ac: movz            x2, #0x6
    // 0x4817b0: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4817b0: sub             lr, x0, #0xf99
    //     0x4817b4: ldr             lr, [x21, lr, lsl #3]
    //     0x4817b8: blr             lr
    // 0x4817bc: tbnz            w0, #4, #0x481814
    // 0x4817c0: ldur            x3, [fp, #-8]
    // 0x4817c4: r0 = LoadClassIdInstr(r3)
    //     0x4817c4: ldur            x0, [x3, #-1]
    //     0x4817c8: ubfx            x0, x0, #0xc, #0x14
    // 0x4817cc: mov             x1, x3
    // 0x4817d0: r2 = 6
    //     0x4817d0: movz            x2, #0x6
    // 0x4817d4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4817d4: sub             lr, x0, #1, lsl #12
    //     0x4817d8: ldr             lr, [x21, lr, lsl #3]
    //     0x4817dc: blr             lr
    // 0x4817e0: mov             x3, x0
    // 0x4817e4: r2 = Null
    //     0x4817e4: mov             x2, NULL
    // 0x4817e8: r1 = Null
    //     0x4817e8: mov             x1, NULL
    // 0x4817ec: stur            x3, [fp, #-0x28]
    // 0x4817f0: r8 = Map
    //     0x4817f0: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x4817f4: r3 = Null
    //     0x4817f4: add             x3, PP, #0x12, lsl #12  ; [pp+0x128e8] Null
    //     0x4817f8: ldr             x3, [x3, #0x8e8]
    // 0x4817fc: r0 = Map()
    //     0x4817fc: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x481800: ldur            x2, [fp, #-0x28]
    // 0x481804: r1 = <String, String>
    //     0x481804: ldr             x1, [PP, #0x2c48]  ; [pp+0x2c48] TypeArguments: <String, String>
    // 0x481808: r0 = LinkedHashMap.from()
    //     0x481808: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x48180c: mov             x6, x0
    // 0x481810: b               #0x481828
    // 0x481814: r16 = <String, String>
    //     0x481814: ldr             x16, [PP, #0x2c48]  ; [pp+0x2c48] TypeArguments: <String, String>
    // 0x481818: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x48181c: stp             lr, x16, [SP]
    // 0x481820: r0 = Map._fromLiteral()
    //     0x481820: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x481824: mov             x6, x0
    // 0x481828: ldur            x3, [fp, #-8]
    // 0x48182c: stur            x6, [fp, #-0x28]
    // 0x481830: r0 = LoadClassIdInstr(r3)
    //     0x481830: ldur            x0, [x3, #-1]
    //     0x481834: ubfx            x0, x0, #0xc, #0x14
    // 0x481838: mov             x1, x3
    // 0x48183c: r2 = 8
    //     0x48183c: movz            x2, #0x8
    // 0x481840: r0 = GDT[cid_x0 + -0xf99]()
    //     0x481840: sub             lr, x0, #0xf99
    //     0x481844: ldr             lr, [x21, lr, lsl #3]
    //     0x481848: blr             lr
    // 0x48184c: tbnz            w0, #4, #0x4818a4
    // 0x481850: ldur            x3, [fp, #-8]
    // 0x481854: r0 = LoadClassIdInstr(r3)
    //     0x481854: ldur            x0, [x3, #-1]
    //     0x481858: ubfx            x0, x0, #0xc, #0x14
    // 0x48185c: mov             x1, x3
    // 0x481860: r2 = 8
    //     0x481860: movz            x2, #0x8
    // 0x481864: r0 = GDT[cid_x0 + -0x1000]()
    //     0x481864: sub             lr, x0, #1, lsl #12
    //     0x481868: ldr             lr, [x21, lr, lsl #3]
    //     0x48186c: blr             lr
    // 0x481870: mov             x3, x0
    // 0x481874: r2 = Null
    //     0x481874: mov             x2, NULL
    // 0x481878: r1 = Null
    //     0x481878: mov             x1, NULL
    // 0x48187c: stur            x3, [fp, #-0x30]
    // 0x481880: r8 = Map
    //     0x481880: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x481884: r3 = Null
    //     0x481884: add             x3, PP, #0x12, lsl #12  ; [pp+0x128f8] Null
    //     0x481888: ldr             x3, [x3, #0x8f8]
    // 0x48188c: r0 = Map()
    //     0x48188c: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x481890: ldur            x2, [fp, #-0x30]
    // 0x481894: r1 = <String, int>
    //     0x481894: ldr             x1, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x481898: r0 = LinkedHashMap.from()
    //     0x481898: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x48189c: mov             x7, x0
    // 0x4818a0: b               #0x4818b8
    // 0x4818a4: r16 = <String, int>
    //     0x4818a4: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x4818a8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4818ac: stp             lr, x16, [SP]
    // 0x4818b0: r0 = Map._fromLiteral()
    //     0x4818b0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4818b4: mov             x7, x0
    // 0x4818b8: ldur            x3, [fp, #-8]
    // 0x4818bc: stur            x7, [fp, #-0x30]
    // 0x4818c0: r0 = LoadClassIdInstr(r3)
    //     0x4818c0: ldur            x0, [x3, #-1]
    //     0x4818c4: ubfx            x0, x0, #0xc, #0x14
    // 0x4818c8: mov             x1, x3
    // 0x4818cc: r2 = 10
    //     0x4818cc: movz            x2, #0xa
    // 0x4818d0: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4818d0: sub             lr, x0, #0xf99
    //     0x4818d4: ldr             lr, [x21, lr, lsl #3]
    //     0x4818d8: blr             lr
    // 0x4818dc: tbnz            w0, #4, #0x481934
    // 0x4818e0: ldur            x3, [fp, #-8]
    // 0x4818e4: r0 = LoadClassIdInstr(r3)
    //     0x4818e4: ldur            x0, [x3, #-1]
    //     0x4818e8: ubfx            x0, x0, #0xc, #0x14
    // 0x4818ec: mov             x1, x3
    // 0x4818f0: r2 = 10
    //     0x4818f0: movz            x2, #0xa
    // 0x4818f4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4818f4: sub             lr, x0, #1, lsl #12
    //     0x4818f8: ldr             lr, [x21, lr, lsl #3]
    //     0x4818fc: blr             lr
    // 0x481900: mov             x3, x0
    // 0x481904: r2 = Null
    //     0x481904: mov             x2, NULL
    // 0x481908: r1 = Null
    //     0x481908: mov             x1, NULL
    // 0x48190c: stur            x3, [fp, #-0x38]
    // 0x481910: r8 = Iterable
    //     0x481910: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x481914: r3 = Null
    //     0x481914: add             x3, PP, #0x12, lsl #12  ; [pp+0x12908] Null
    //     0x481918: ldr             x3, [x3, #0x908]
    // 0x48191c: r0 = Iterable()
    //     0x48191c: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x481920: ldur            x2, [fp, #-0x38]
    // 0x481924: r1 = <int>
    //     0x481924: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x481928: r0 = LinkedHashSet.from()
    //     0x481928: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x48192c: mov             x4, x0
    // 0x481930: b               #0x481960
    // 0x481934: r1 = <int>
    //     0x481934: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x481938: r0 = _Set()
    //     0x481938: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x48193c: mov             x1, x0
    // 0x481940: r0 = _Uint32List
    //     0x481940: ldr             x0, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x481944: StoreField: r1->field_1b = r0
    //     0x481944: stur            w0, [x1, #0x1b]
    // 0x481948: StoreField: r1->field_b = rZR
    //     0x481948: stur            wzr, [x1, #0xb]
    // 0x48194c: r0 = const []
    //     0x48194c: ldr             x0, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x481950: StoreField: r1->field_f = r0
    //     0x481950: stur            w0, [x1, #0xf]
    // 0x481954: StoreField: r1->field_13 = rZR
    //     0x481954: stur            wzr, [x1, #0x13]
    // 0x481958: ArrayStore: r1[0] = rZR  ; List_4
    //     0x481958: stur            wzr, [x1, #0x17]
    // 0x48195c: mov             x4, x1
    // 0x481960: ldur            x3, [fp, #-8]
    // 0x481964: stur            x4, [fp, #-0x38]
    // 0x481968: r0 = LoadClassIdInstr(r3)
    //     0x481968: ldur            x0, [x3, #-1]
    //     0x48196c: ubfx            x0, x0, #0xc, #0x14
    // 0x481970: mov             x1, x3
    // 0x481974: r2 = 12
    //     0x481974: movz            x2, #0xc
    // 0x481978: r0 = GDT[cid_x0 + -0xf99]()
    //     0x481978: sub             lr, x0, #0xf99
    //     0x48197c: ldr             lr, [x21, lr, lsl #3]
    //     0x481980: blr             lr
    // 0x481984: tbnz            w0, #4, #0x4819d4
    // 0x481988: ldur            x1, [fp, #-8]
    // 0x48198c: r0 = LoadClassIdInstr(r1)
    //     0x48198c: ldur            x0, [x1, #-1]
    //     0x481990: ubfx            x0, x0, #0xc, #0x14
    // 0x481994: r2 = 12
    //     0x481994: movz            x2, #0xc
    // 0x481998: r0 = GDT[cid_x0 + -0x1000]()
    //     0x481998: sub             lr, x0, #1, lsl #12
    //     0x48199c: ldr             lr, [x21, lr, lsl #3]
    //     0x4819a0: blr             lr
    // 0x4819a4: mov             x3, x0
    // 0x4819a8: r2 = Null
    //     0x4819a8: mov             x2, NULL
    // 0x4819ac: r1 = Null
    //     0x4819ac: mov             x1, NULL
    // 0x4819b0: stur            x3, [fp, #-8]
    // 0x4819b4: r8 = Map
    //     0x4819b4: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x4819b8: r3 = Null
    //     0x4819b8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12918] Null
    //     0x4819bc: ldr             x3, [x3, #0x918]
    // 0x4819c0: r0 = Map()
    //     0x4819c0: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x4819c4: ldur            x2, [fp, #-8]
    // 0x4819c8: r1 = <String, int>
    //     0x4819c8: ldr             x1, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x4819cc: r0 = LinkedHashMap.from()
    //     0x4819cc: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x4819d0: b               #0x4819e4
    // 0x4819d4: r16 = <String, int>
    //     0x4819d4: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x4819d8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4819dc: stp             lr, x16, [SP]
    // 0x4819e0: r0 = Map._fromLiteral()
    //     0x4819e0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4819e4: stur            x0, [fp, #-8]
    // 0x4819e8: r0 = CoreData()
    //     0x4819e8: bl              #0x48142c  ; AllocateCoreDataStub -> CoreData (size=0x2c)
    // 0x4819ec: stur            x0, [fp, #-0x40]
    // 0x4819f0: ldur            x16, [fp, #-0x38]
    // 0x4819f4: ldur            lr, [fp, #-8]
    // 0x4819f8: stp             lr, x16, [SP]
    // 0x4819fc: mov             x1, x0
    // 0x481a00: ldur            x2, [fp, #-0x18]
    // 0x481a04: ldur            x3, [fp, #-0x20]
    // 0x481a08: ldur            x5, [fp, #-0x10]
    // 0x481a0c: ldur            x6, [fp, #-0x28]
    // 0x481a10: ldur            x7, [fp, #-0x30]
    // 0x481a14: r0 = CoreData()
    //     0x481a14: bl              #0x480034  ; [package:pretentious/data/CoreData.dart] CoreData::CoreData
    // 0x481a18: ldur            x0, [fp, #-0x40]
    // 0x481a1c: LeaveFrame
    //     0x481a1c: mov             SP, fp
    //     0x481a20: ldp             fp, lr, [SP], #0x10
    // 0x481a24: ret
    //     0x481a24: ret             
    // 0x481a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x481a28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x481a2c: b               #0x48145c
    // 0x481a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x481a30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x481a34: b               #0x48152c
  }
  _ addMultipleCompletionTokens(/* No info */) async {
    // ** addr: 0x49144c, size: 0x230
    // 0x49144c: EnterFrame
    //     0x49144c: stp             fp, lr, [SP, #-0x10]!
    //     0x491450: mov             fp, SP
    // 0x491454: AllocStack(0x20)
    //     0x491454: sub             SP, SP, #0x20
    // 0x491458: SetupParameters(CoreData this /* r1 => r1, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0x491458: stur            NULL, [fp, #-8]
    //     0x49145c: stur            x1, [fp, #-0x10]
    //     0x491460: stur            d0, [fp, #-0x20]
    // 0x491464: CheckStackOverflow
    //     0x491464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x491468: cmp             SP, x16
    //     0x49146c: b.ls            #0x491614
    // 0x491470: InitAsync() -> Future<void?>
    //     0x491470: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x491474: bl              #0x34b9a0  ; InitAsyncStub
    // 0x491478: ldur            x0, [fp, #-0x10]
    // 0x49147c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x49147c: ldur            w3, [x0, #0x17]
    // 0x491480: DecompressPointer r3
    //     0x491480: add             x3, x3, HEAP, lsl #32
    // 0x491484: mov             x1, x3
    // 0x491488: stur            x3, [fp, #-0x18]
    // 0x49148c: r2 = "Bonus"
    //     0x49148c: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x491490: ldr             x2, [x2, #0xa68]
    // 0x491494: r0 = containsKey()
    //     0x491494: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x491498: tbnz            w0, #4, #0x491518
    // 0x49149c: ldur            x0, [fp, #-0x18]
    // 0x4914a0: mov             x1, x0
    // 0x4914a4: r2 = "Bonus"
    //     0x4914a4: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x4914a8: ldr             x2, [x2, #0xa68]
    // 0x4914ac: r0 = _getValueOrData()
    //     0x4914ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4914b0: ldur            x1, [fp, #-0x18]
    // 0x4914b4: LoadField: r2 = r1->field_f
    //     0x4914b4: ldur            w2, [x1, #0xf]
    // 0x4914b8: DecompressPointer r2
    //     0x4914b8: add             x2, x2, HEAP, lsl #32
    // 0x4914bc: cmp             w2, w0
    // 0x4914c0: b.ne            #0x4914c8
    // 0x4914c4: r0 = Null
    //     0x4914c4: mov             x0, NULL
    // 0x4914c8: ldur            d0, [fp, #-0x20]
    // 0x4914cc: cmp             w0, NULL
    // 0x4914d0: b.eq            #0x49161c
    // 0x4914d4: LoadField: d1 = r0->field_7
    //     0x4914d4: ldur            d1, [x0, #7]
    // 0x4914d8: fadd            d2, d1, d0
    // 0x4914dc: r3 = inline_Allocate_Double()
    //     0x4914dc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x4914e0: add             x3, x3, #0x10
    //     0x4914e4: cmp             x0, x3
    //     0x4914e8: b.ls            #0x491620
    //     0x4914ec: str             x3, [THR, #0x60]  ; THR::top
    //     0x4914f0: sub             x3, x3, #0xf
    //     0x4914f4: movz            x0, #0xe19c
    //     0x4914f8: movk            x0, #0x3, lsl #16
    //     0x4914fc: stur            x0, [x3, #-1]
    // 0x491500: dmb             ishst
    // 0x491504: StoreField: r3->field_7 = d2
    //     0x491504: stur            d2, [x3, #7]
    // 0x491508: r2 = "Bonus"
    //     0x491508: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x49150c: ldr             x2, [x2, #0xa68]
    // 0x491510: r0 = []=()
    //     0x491510: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x491514: b               #0x491558
    // 0x491518: ldur            d0, [fp, #-0x20]
    // 0x49151c: ldur            x1, [fp, #-0x18]
    // 0x491520: r3 = inline_Allocate_Double()
    //     0x491520: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x491524: add             x3, x3, #0x10
    //     0x491528: cmp             x0, x3
    //     0x49152c: b.ls            #0x49163c
    //     0x491530: str             x3, [THR, #0x60]  ; THR::top
    //     0x491534: sub             x3, x3, #0xf
    //     0x491538: movz            x0, #0xe19c
    //     0x49153c: movk            x0, #0x3, lsl #16
    //     0x491540: stur            x0, [x3, #-1]
    // 0x491544: dmb             ishst
    // 0x491548: StoreField: r3->field_7 = d0
    //     0x491548: stur            d0, [x3, #7]
    // 0x49154c: r2 = "Bonus"
    //     0x49154c: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x491550: ldr             x2, [x2, #0xa68]
    // 0x491554: r0 = []=()
    //     0x491554: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x491558: ldur            x1, [fp, #-0x10]
    // 0x49155c: r0 = recomputeTokenBoost()
    //     0x49155c: bl              #0x4802e8  ; [package:pretentious/data/CoreData.dart] CoreData::recomputeTokenBoost
    // 0x491560: r0 = saveCoreData()
    //     0x491560: bl              #0x452554  ; [package:pretentious/data/CoreData.dart] ::saveCoreData
    // 0x491564: mov             x1, x0
    // 0x491568: stur            x1, [fp, #-0x10]
    // 0x49156c: r0 = Await()
    //     0x49156c: bl              #0x34b75c  ; AwaitStub
    // 0x491570: r1 = "bonus_tokens"
    //     0x491570: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4c8] "bonus_tokens"
    //     0x491574: ldr             x1, [x1, #0x4c8]
    // 0x491578: r0 = prefsGetInt()
    //     0x491578: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x49157c: cmp             w0, NULL
    // 0x491580: b.ne            #0x49158c
    // 0x491584: r19 = 0
    //     0x491584: movz            x19, #0
    // 0x491588: b               #0x49159c
    // 0x49158c: r1 = LoadInt32Instr(r0)
    //     0x49158c: sbfx            x1, x0, #1, #0x1f
    //     0x491590: tbz             w0, #0, #0x491598
    //     0x491594: ldur            x1, [x0, #7]
    // 0x491598: mov             x19, x1
    // 0x49159c: ldur            d0, [fp, #-0x20]
    // 0x4915a0: stp             fp, lr, [SP, #-0x10]!
    // 0x4915a4: mov             fp, SP
    // 0x4915a8: CallRuntime_LibcRound(double) -> double
    //     0x4915a8: and             SP, SP, #0xfffffffffffffff0
    //     0x4915ac: mov             sp, SP
    //     0x4915b0: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x4915b4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4915b8: blr             x16
    //     0x4915bc: movz            x16, #0x8
    //     0x4915c0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4915c4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4915c8: sub             sp, x16, #1, lsl #12
    //     0x4915cc: mov             SP, fp
    //     0x4915d0: ldp             fp, lr, [SP], #0x10
    // 0x4915d4: fcmp            d0, d0
    // 0x4915d8: b.vs            #0x491658
    // 0x4915dc: fcvtzs          x0, d0
    // 0x4915e0: asr             x16, x0, #0x1e
    // 0x4915e4: cmp             x16, x0, asr #63
    // 0x4915e8: b.ne            #0x491658
    // 0x4915ec: lsl             x0, x0, #1
    // 0x4915f0: r1 = LoadInt32Instr(r0)
    //     0x4915f0: sbfx            x1, x0, #1, #0x1f
    //     0x4915f4: tbz             w0, #0, #0x4915fc
    //     0x4915f8: ldur            x1, [x0, #7]
    // 0x4915fc: add             x2, x19, x1
    // 0x491600: r1 = "bonus_tokens"
    //     0x491600: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4c8] "bonus_tokens"
    //     0x491604: ldr             x1, [x1, #0x4c8]
    // 0x491608: r0 = prefsSetInt()
    //     0x491608: bl              #0x35e50c  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetInt
    // 0x49160c: r0 = Null
    //     0x49160c: mov             x0, NULL
    // 0x491610: r0 = ReturnAsyncNotFuture()
    //     0x491610: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x491614: r0 = StackOverflowSharedWithFPURegs()
    //     0x491614: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x491618: b               #0x491470
    // 0x49161c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x49161c: bl              #0x827c54  ; NullCastErrorSharedWithFPURegsStub
    // 0x491620: stp             q0, q2, [SP, #-0x20]!
    // 0x491624: SaveReg r1
    //     0x491624: str             x1, [SP, #-8]!
    // 0x491628: r0 = AllocateDouble()
    //     0x491628: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x49162c: mov             x3, x0
    // 0x491630: RestoreReg r1
    //     0x491630: ldr             x1, [SP], #8
    // 0x491634: ldp             q0, q2, [SP], #0x20
    // 0x491638: b               #0x491504
    // 0x49163c: SaveReg d0
    //     0x49163c: str             q0, [SP, #-0x10]!
    // 0x491640: SaveReg r1
    //     0x491640: str             x1, [SP, #-8]!
    // 0x491644: r0 = AllocateDouble()
    //     0x491644: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x491648: mov             x3, x0
    // 0x49164c: RestoreReg r1
    //     0x49164c: ldr             x1, [SP], #8
    // 0x491650: RestoreReg d0
    //     0x491650: ldr             q0, [SP], #0x10
    // 0x491654: b               #0x491548
    // 0x491658: SaveReg d0
    //     0x491658: str             q0, [SP, #-0x10]!
    // 0x49165c: SaveReg r19
    //     0x49165c: str             x19, [SP, #-8]!
    // 0x491660: r0 = 76
    //     0x491660: movz            x0, #0x4c
    // 0x491664: r30 = DoubleToIntegerStub
    //     0x491664: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x491668: LoadField: r30 = r30->field_7
    //     0x491668: ldur            lr, [lr, #7]
    // 0x49166c: blr             lr
    // 0x491670: RestoreReg r19
    //     0x491670: ldr             x19, [SP], #8
    // 0x491674: RestoreReg d0
    //     0x491674: ldr             q0, [SP], #0x10
    // 0x491678: b               #0x4915f0
  }
  _ getBonusTokenScalingFactor(/* No info */) {
    // ** addr: 0x49167c, size: 0x354
    // 0x49167c: EnterFrame
    //     0x49167c: stp             fp, lr, [SP, #-0x10]!
    //     0x491680: mov             fp, SP
    // 0x491684: AllocStack(0x30)
    //     0x491684: sub             SP, SP, #0x30
    // 0x491688: CheckStackOverflow
    //     0x491688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49168c: cmp             SP, x16
    //     0x491690: b.ls            #0x491968
    // 0x491694: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x491694: ldur            w0, [x1, #0x17]
    // 0x491698: DecompressPointer r0
    //     0x491698: add             x0, x0, HEAP, lsl #32
    // 0x49169c: mov             x1, x0
    // 0x4916a0: stur            x0, [fp, #-8]
    // 0x4916a4: r2 = "Bonus"
    //     0x4916a4: add             x2, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x4916a8: ldr             x2, [x2, #0xa68]
    // 0x4916ac: r0 = _getValueOrData()
    //     0x4916ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4916b0: mov             x1, x0
    // 0x4916b4: ldur            x0, [fp, #-8]
    // 0x4916b8: LoadField: r2 = r0->field_f
    //     0x4916b8: ldur            w2, [x0, #0xf]
    // 0x4916bc: DecompressPointer r2
    //     0x4916bc: add             x2, x2, HEAP, lsl #32
    // 0x4916c0: cmp             w2, w1
    // 0x4916c4: b.ne            #0x4916cc
    // 0x4916c8: r1 = Null
    //     0x4916c8: mov             x1, NULL
    // 0x4916cc: cmp             w1, NULL
    // 0x4916d0: b.ne            #0x4916dc
    // 0x4916d4: d0 = 0.000000
    //     0x4916d4: eor             v0.16b, v0.16b, v0.16b
    // 0x4916d8: b               #0x4916e0
    // 0x4916dc: LoadField: d0 = r1->field_7
    //     0x4916dc: ldur            d0, [x1, #7]
    // 0x4916e0: stur            d0, [fp, #-0x20]
    // 0x4916e4: r1 = <MapEntry<String, double>, String, double>
    //     0x4916e4: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4f8] TypeArguments: <MapEntry<String, double>, String, double>
    //     0x4916e8: ldr             x1, [x1, #0x4f8]
    // 0x4916ec: r0 = _CompactEntriesIterable()
    //     0x4916ec: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x4916f0: mov             x1, x0
    // 0x4916f4: ldur            x0, [fp, #-8]
    // 0x4916f8: StoreField: r1->field_b = r0
    //     0x4916f8: stur            w0, [x1, #0xb]
    // 0x4916fc: r0 = iterator()
    //     0x4916fc: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x491700: ldur            d0, [fp, #-0x20]
    // 0x491704: stur            x0, [fp, #-0x10]
    // 0x491708: r1 = inline_Allocate_Double()
    //     0x491708: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x49170c: add             x1, x1, #0x10
    //     0x491710: cmp             x2, x1
    //     0x491714: b.ls            #0x491970
    //     0x491718: str             x1, [THR, #0x60]  ; THR::top
    //     0x49171c: sub             x1, x1, #0xf
    //     0x491720: movz            x2, #0xe19c
    //     0x491724: movk            x2, #0x3, lsl #16
    //     0x491728: stur            x2, [x1, #-1]
    // 0x49172c: dmb             ishst
    // 0x491730: StoreField: r1->field_7 = d0
    //     0x491730: stur            d0, [x1, #7]
    // 0x491734: mov             x2, x1
    // 0x491738: stur            x2, [fp, #-8]
    // 0x49173c: CheckStackOverflow
    //     0x49173c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x491740: cmp             SP, x16
    //     0x491744: b.ls            #0x49198c
    // 0x491748: mov             x1, x0
    // 0x49174c: r0 = moveNext()
    //     0x49174c: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x491750: tbnz            w0, #4, #0x49190c
    // 0x491754: ldur            x1, [fp, #-0x10]
    // 0x491758: LoadField: r0 = r1->field_2b
    //     0x491758: ldur            w0, [x1, #0x2b]
    // 0x49175c: DecompressPointer r0
    //     0x49175c: add             x0, x0, HEAP, lsl #32
    // 0x491760: cmp             w0, NULL
    // 0x491764: b.eq            #0x49195c
    // 0x491768: LoadField: r2 = r0->field_b
    //     0x491768: ldur            w2, [x0, #0xb]
    // 0x49176c: DecompressPointer r2
    //     0x49176c: add             x2, x2, HEAP, lsl #32
    // 0x491770: cmp             w2, NULL
    // 0x491774: b.eq            #0x491994
    // 0x491778: LoadField: r3 = r2->field_7
    //     0x491778: ldur            w3, [x2, #7]
    // 0x49177c: r2 = LoadInt32Instr(r3)
    //     0x49177c: sbfx            x2, x3, #1, #0x1f
    // 0x491780: cmp             x2, #2
    // 0x491784: b.gt            #0x491900
    // 0x491788: ldur            x2, [fp, #-8]
    // 0x49178c: LoadField: r3 = r0->field_f
    //     0x49178c: ldur            w3, [x0, #0xf]
    // 0x491790: DecompressPointer r3
    //     0x491790: add             x3, x3, HEAP, lsl #32
    // 0x491794: stur            x3, [fp, #-0x18]
    // 0x491798: r0 = 60
    //     0x491798: movz            x0, #0x3c
    // 0x49179c: branchIfSmi(r2, 0x4917a8)
    //     0x49179c: tbz             w2, #0, #0x4917a8
    // 0x4917a0: r0 = LoadClassIdInstr(r2)
    //     0x4917a0: ldur            x0, [x2, #-1]
    //     0x4917a4: ubfx            x0, x0, #0xc, #0x14
    // 0x4917a8: stp             x3, x2, [SP]
    // 0x4917ac: r0 = GDT[cid_x0 + -0xffa]()
    //     0x4917ac: sub             lr, x0, #0xffa
    //     0x4917b0: ldr             lr, [x21, lr, lsl #3]
    //     0x4917b4: blr             lr
    // 0x4917b8: tbnz            w0, #4, #0x4917c4
    // 0x4917bc: ldur            x0, [fp, #-8]
    // 0x4917c0: b               #0x4918f8
    // 0x4917c4: ldur            x1, [fp, #-8]
    // 0x4917c8: r0 = 60
    //     0x4917c8: movz            x0, #0x3c
    // 0x4917cc: branchIfSmi(r1, 0x4917d8)
    //     0x4917cc: tbz             w1, #0, #0x4917d8
    // 0x4917d0: r0 = LoadClassIdInstr(r1)
    //     0x4917d0: ldur            x0, [x1, #-1]
    //     0x4917d4: ubfx            x0, x0, #0xc, #0x14
    // 0x4917d8: ldur            x16, [fp, #-0x18]
    // 0x4917dc: stp             x16, x1, [SP]
    // 0x4917e0: r0 = GDT[cid_x0 + -0xe74]()
    //     0x4917e0: sub             lr, x0, #0xe74
    //     0x4917e4: ldr             lr, [x21, lr, lsl #3]
    //     0x4917e8: blr             lr
    // 0x4917ec: tbnz            w0, #4, #0x4917f8
    // 0x4917f0: ldur            x0, [fp, #-0x18]
    // 0x4917f4: b               #0x4918f8
    // 0x4917f8: ldur            x1, [fp, #-0x18]
    // 0x4917fc: r0 = 60
    //     0x4917fc: movz            x0, #0x3c
    // 0x491800: branchIfSmi(r1, 0x49180c)
    //     0x491800: tbz             w1, #0, #0x49180c
    // 0x491804: r0 = LoadClassIdInstr(r1)
    //     0x491804: ldur            x0, [x1, #-1]
    //     0x491808: ubfx            x0, x0, #0xc, #0x14
    // 0x49180c: cmp             x0, #0x3e
    // 0x491810: b.ne            #0x491898
    // 0x491814: ldur            x2, [fp, #-8]
    // 0x491818: r0 = 60
    //     0x491818: movz            x0, #0x3c
    // 0x49181c: branchIfSmi(r2, 0x491828)
    //     0x49181c: tbz             w2, #0, #0x491828
    // 0x491820: r0 = LoadClassIdInstr(r2)
    //     0x491820: ldur            x0, [x2, #-1]
    //     0x491824: ubfx            x0, x0, #0xc, #0x14
    // 0x491828: cmp             x0, #0x3e
    // 0x49182c: b.ne            #0x491878
    // 0x491830: d0 = 0.000000
    //     0x491830: eor             v0.16b, v0.16b, v0.16b
    // 0x491834: LoadField: d1 = r2->field_7
    //     0x491834: ldur            d1, [x2, #7]
    // 0x491838: fcmp            d1, d0
    // 0x49183c: b.ne            #0x49187c
    // 0x491840: LoadField: d2 = r1->field_7
    //     0x491840: ldur            d2, [x1, #7]
    // 0x491844: fadd            d3, d1, d2
    // 0x491848: r0 = inline_Allocate_Double()
    //     0x491848: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x49184c: add             x0, x0, #0x10
    //     0x491850: cmp             x1, x0
    //     0x491854: b.ls            #0x491998
    //     0x491858: str             x0, [THR, #0x60]  ; THR::top
    //     0x49185c: sub             x0, x0, #0xf
    //     0x491860: movz            x1, #0xe19c
    //     0x491864: movk            x1, #0x3, lsl #16
    //     0x491868: stur            x1, [x0, #-1]
    // 0x49186c: dmb             ishst
    // 0x491870: StoreField: r0->field_7 = d3
    //     0x491870: stur            d3, [x0, #7]
    // 0x491874: b               #0x4918f8
    // 0x491878: d0 = 0.000000
    //     0x491878: eor             v0.16b, v0.16b, v0.16b
    // 0x49187c: LoadField: d1 = r1->field_7
    //     0x49187c: ldur            d1, [x1, #7]
    // 0x491880: fcmp            d1, d1
    // 0x491884: b.vc            #0x491890
    // 0x491888: mov             x0, x1
    // 0x49188c: b               #0x4918f8
    // 0x491890: mov             x0, x2
    // 0x491894: b               #0x4918f8
    // 0x491898: ldur            x2, [fp, #-8]
    // 0x49189c: d0 = 0.000000
    //     0x49189c: eor             v0.16b, v0.16b, v0.16b
    // 0x4918a0: r0 = 60
    //     0x4918a0: movz            x0, #0x3c
    // 0x4918a4: branchIfSmi(r1, 0x4918b0)
    //     0x4918a4: tbz             w1, #0, #0x4918b0
    // 0x4918a8: r0 = LoadClassIdInstr(r1)
    //     0x4918a8: ldur            x0, [x1, #-1]
    //     0x4918ac: ubfx            x0, x0, #0xc, #0x14
    // 0x4918b0: stp             xzr, x1, [SP]
    // 0x4918b4: mov             lr, x0
    // 0x4918b8: ldr             lr, [x21, lr, lsl #3]
    // 0x4918bc: blr             lr
    // 0x4918c0: tbnz            w0, #4, #0x4918f4
    // 0x4918c4: ldur            x1, [fp, #-8]
    // 0x4918c8: r0 = 60
    //     0x4918c8: movz            x0, #0x3c
    // 0x4918cc: branchIfSmi(r1, 0x4918d8)
    //     0x4918cc: tbz             w1, #0, #0x4918d8
    // 0x4918d0: r0 = LoadClassIdInstr(r1)
    //     0x4918d0: ldur            x0, [x1, #-1]
    //     0x4918d4: ubfx            x0, x0, #0xc, #0x14
    // 0x4918d8: str             x1, [SP]
    // 0x4918dc: r0 = GDT[cid_x0 + -0xdbf]()
    //     0x4918dc: sub             lr, x0, #0xdbf
    //     0x4918e0: ldr             lr, [x21, lr, lsl #3]
    //     0x4918e4: blr             lr
    // 0x4918e8: tbnz            w0, #4, #0x4918f4
    // 0x4918ec: ldur            x0, [fp, #-0x18]
    // 0x4918f0: b               #0x4918f8
    // 0x4918f4: ldur            x0, [fp, #-8]
    // 0x4918f8: mov             x2, x0
    // 0x4918fc: b               #0x491904
    // 0x491900: ldur            x2, [fp, #-8]
    // 0x491904: ldur            x0, [fp, #-0x10]
    // 0x491908: b               #0x491738
    // 0x49190c: ldur            x0, [fp, #-8]
    // 0x491910: d0 = 0.050000
    //     0x491910: ldr             d0, [PP, #0x7488]  ; [pp+0x7488] IMM: double(0.05) from 0x3fa999999999999a
    // 0x491914: r1 = 1
    //     0x491914: movz            x1, #0x1
    // 0x491918: LoadField: d1 = r0->field_7
    //     0x491918: ldur            d1, [x0, #7]
    // 0x49191c: fmul            d2, d1, d0
    // 0x491920: fcmp            d2, d2
    // 0x491924: b.vs            #0x4919a8
    // 0x491928: fcvtps          x0, d2
    // 0x49192c: asr             x16, x0, #0x1e
    // 0x491930: cmp             x16, x0, asr #63
    // 0x491934: b.ne            #0x4919a8
    // 0x491938: lsl             x0, x0, #1
    // 0x49193c: r2 = LoadInt32Instr(r0)
    //     0x49193c: sbfx            x2, x0, #1, #0x1f
    //     0x491940: tbz             w0, #0, #0x491948
    //     0x491944: ldur            x2, [x0, #7]
    // 0x491948: cmp             x1, x2
    // 0x49194c: csel            x0, x2, x1, lt
    // 0x491950: LeaveFrame
    //     0x491950: mov             SP, fp
    //     0x491954: ldp             fp, lr, [SP], #0x10
    // 0x491958: ret
    //     0x491958: ret             
    // 0x49195c: r0 = noElement()
    //     0x49195c: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x491960: r0 = Throw()
    //     0x491960: bl              #0x825670  ; ThrowStub
    // 0x491964: brk             #0
    // 0x491968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x491968: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49196c: b               #0x491694
    // 0x491970: SaveReg d0
    //     0x491970: str             q0, [SP, #-0x10]!
    // 0x491974: SaveReg r0
    //     0x491974: str             x0, [SP, #-8]!
    // 0x491978: r0 = AllocateDouble()
    //     0x491978: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x49197c: mov             x1, x0
    // 0x491980: RestoreReg r0
    //     0x491980: ldr             x0, [SP], #8
    // 0x491984: RestoreReg d0
    //     0x491984: ldr             q0, [SP], #0x10
    // 0x491988: b               #0x491730
    // 0x49198c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49198c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x491990: b               #0x491748
    // 0x491994: r0 = NullErrorSharedWithoutFPURegs()
    //     0x491994: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x491998: stp             q0, q3, [SP, #-0x20]!
    // 0x49199c: r0 = AllocateDouble()
    //     0x49199c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4919a0: ldp             q0, q3, [SP], #0x20
    // 0x4919a4: b               #0x491870
    // 0x4919a8: SaveReg d2
    //     0x4919a8: str             q2, [SP, #-0x10]!
    // 0x4919ac: SaveReg r1
    //     0x4919ac: str             x1, [SP, #-8]!
    // 0x4919b0: d0 = 0.000000
    //     0x4919b0: fmov            d0, d2
    // 0x4919b4: r0 = 66
    //     0x4919b4: movz            x0, #0x42
    // 0x4919b8: r30 = DoubleToIntegerStub
    //     0x4919b8: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x4919bc: LoadField: r30 = r30->field_7
    //     0x4919bc: ldur            lr, [lr, #7]
    // 0x4919c0: blr             lr
    // 0x4919c4: RestoreReg r1
    //     0x4919c4: ldr             x1, [SP], #8
    // 0x4919c8: RestoreReg d2
    //     0x4919c8: ldr             q2, [SP], #0x10
    // 0x4919cc: b               #0x49193c
  }
  _ makeSecondaryTable(/* No info */) {
    // ** addr: 0x59e694, size: 0x318
    // 0x59e694: EnterFrame
    //     0x59e694: stp             fp, lr, [SP, #-0x10]!
    //     0x59e698: mov             fp, SP
    // 0x59e69c: AllocStack(0x50)
    //     0x59e69c: sub             SP, SP, #0x50
    // 0x59e6a0: r0 = 2
    //     0x59e6a0: movz            x0, #0x2
    // 0x59e6a4: mov             x3, x1
    // 0x59e6a8: stur            x1, [fp, #-8]
    // 0x59e6ac: CheckStackOverflow
    //     0x59e6ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x59e6b0: cmp             SP, x16
    //     0x59e6b4: b.ls            #0x59e99c
    // 0x59e6b8: mov             x2, x0
    // 0x59e6bc: r1 = Null
    //     0x59e6bc: mov             x1, NULL
    // 0x59e6c0: r0 = AllocateArray()
    //     0x59e6c0: bl              #0x82746c  ; AllocateArrayStub
    // 0x59e6c4: stur            x0, [fp, #-0x10]
    // 0x59e6c8: r16 = Instance_TableRow
    //     0x59e6c8: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ff78] Obj!TableRow@82f1a1
    //     0x59e6cc: ldr             x16, [x16, #0xf78]
    // 0x59e6d0: StoreField: r0->field_f = r16
    //     0x59e6d0: stur            w16, [x0, #0xf]
    // 0x59e6d4: r1 = <TableRow>
    //     0x59e6d4: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2ff80] TypeArguments: <TableRow>
    //     0x59e6d8: ldr             x1, [x1, #0xf80]
    // 0x59e6dc: r0 = AllocateGrowableArray()
    //     0x59e6dc: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x59e6e0: mov             x2, x0
    // 0x59e6e4: ldur            x0, [fp, #-0x10]
    // 0x59e6e8: stur            x2, [fp, #-0x18]
    // 0x59e6ec: StoreField: r2->field_f = r0
    //     0x59e6ec: stur            w0, [x2, #0xf]
    // 0x59e6f0: r0 = 2
    //     0x59e6f0: movz            x0, #0x2
    // 0x59e6f4: StoreField: r2->field_b = r0
    //     0x59e6f4: stur            w0, [x2, #0xb]
    // 0x59e6f8: ldur            x0, [fp, #-8]
    // 0x59e6fc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x59e6fc: ldur            w3, [x0, #0x17]
    // 0x59e700: DecompressPointer r3
    //     0x59e700: add             x3, x3, HEAP, lsl #32
    // 0x59e704: stur            x3, [fp, #-0x10]
    // 0x59e708: r1 = <MapEntry<String, double>, String, double>
    //     0x59e708: add             x1, PP, #0xf, lsl #12  ; [pp+0xf4f8] TypeArguments: <MapEntry<String, double>, String, double>
    //     0x59e70c: ldr             x1, [x1, #0x4f8]
    // 0x59e710: r0 = _CompactEntriesIterable()
    //     0x59e710: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x59e714: mov             x1, x0
    // 0x59e718: ldur            x0, [fp, #-0x10]
    // 0x59e71c: StoreField: r1->field_b = r0
    //     0x59e71c: stur            w0, [x1, #0xb]
    // 0x59e720: r0 = iterator()
    //     0x59e720: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x59e724: mov             x2, x0
    // 0x59e728: ldur            x0, [fp, #-8]
    // 0x59e72c: stur            x2, [fp, #-0x28]
    // 0x59e730: LoadField: r3 = r0->field_1b
    //     0x59e730: ldur            w3, [x0, #0x1b]
    // 0x59e734: DecompressPointer r3
    //     0x59e734: add             x3, x3, HEAP, lsl #32
    // 0x59e738: stur            x3, [fp, #-0x20]
    // 0x59e73c: ldur            x4, [fp, #-0x18]
    // 0x59e740: r5 = true
    //     0x59e740: add             x5, NULL, #0x20  ; true
    // 0x59e744: stur            x5, [fp, #-0x10]
    // 0x59e748: CheckStackOverflow
    //     0x59e748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x59e74c: cmp             SP, x16
    //     0x59e750: b.ls            #0x59e9a4
    // 0x59e754: mov             x1, x2
    // 0x59e758: r0 = moveNext()
    //     0x59e758: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x59e75c: tbnz            w0, #4, #0x59e97c
    // 0x59e760: ldur            x0, [fp, #-0x28]
    // 0x59e764: LoadField: r3 = r0->field_2b
    //     0x59e764: ldur            w3, [x0, #0x2b]
    // 0x59e768: DecompressPointer r3
    //     0x59e768: add             x3, x3, HEAP, lsl #32
    // 0x59e76c: stur            x3, [fp, #-0x40]
    // 0x59e770: cmp             w3, NULL
    // 0x59e774: b.eq            #0x59e990
    // 0x59e778: ldur            x4, [fp, #-8]
    // 0x59e77c: LoadField: r1 = r4->field_b
    //     0x59e77c: ldur            w1, [x4, #0xb]
    // 0x59e780: DecompressPointer r1
    //     0x59e780: add             x1, x1, HEAP, lsl #32
    // 0x59e784: LoadField: r5 = r3->field_b
    //     0x59e784: ldur            w5, [x3, #0xb]
    // 0x59e788: DecompressPointer r5
    //     0x59e788: add             x5, x5, HEAP, lsl #32
    // 0x59e78c: stur            x5, [fp, #-0x38]
    // 0x59e790: LoadField: r6 = r1->field_f
    //     0x59e790: ldur            w6, [x1, #0xf]
    // 0x59e794: DecompressPointer r6
    //     0x59e794: add             x6, x6, HEAP, lsl #32
    // 0x59e798: mov             x2, x5
    // 0x59e79c: stur            x6, [fp, #-0x30]
    // 0x59e7a0: r0 = _getKeyOrData()
    //     0x59e7a0: bl              #0x3f7518  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x59e7a4: mov             x1, x0
    // 0x59e7a8: ldur            x0, [fp, #-0x30]
    // 0x59e7ac: cmp             w0, w1
    // 0x59e7b0: b.eq            #0x59e7c0
    // 0x59e7b4: ldur            x5, [fp, #-0x10]
    // 0x59e7b8: ldur            x2, [fp, #-0x18]
    // 0x59e7bc: b               #0x59e968
    // 0x59e7c0: ldur            x0, [fp, #-0x10]
    // 0x59e7c4: tbnz            w0, #4, #0x59e7d4
    // 0x59e7c8: r4 = Instance_BoxDecoration
    //     0x59e7c8: add             x4, PP, #0x2f, lsl #12  ; [pp+0x2ff88] Obj!BoxDecoration@84ac61
    //     0x59e7cc: ldr             x4, [x4, #0xf88]
    // 0x59e7d0: b               #0x59e7d8
    // 0x59e7d4: r4 = Null
    //     0x59e7d4: mov             x4, NULL
    // 0x59e7d8: ldur            x3, [fp, #-0x20]
    // 0x59e7dc: mov             x1, x3
    // 0x59e7e0: ldur            x2, [fp, #-0x38]
    // 0x59e7e4: stur            x4, [fp, #-0x30]
    // 0x59e7e8: r0 = _getValueOrData()
    //     0x59e7e8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x59e7ec: mov             x1, x0
    // 0x59e7f0: ldur            x0, [fp, #-0x20]
    // 0x59e7f4: LoadField: r2 = r0->field_f
    //     0x59e7f4: ldur            w2, [x0, #0xf]
    // 0x59e7f8: DecompressPointer r2
    //     0x59e7f8: add             x2, x2, HEAP, lsl #32
    // 0x59e7fc: cmp             w2, w1
    // 0x59e800: b.ne            #0x59e808
    // 0x59e804: r1 = Null
    //     0x59e804: mov             x1, NULL
    // 0x59e808: cmp             w1, NULL
    // 0x59e80c: b.ne            #0x59e818
    // 0x59e810: ldur            x4, [fp, #-0x38]
    // 0x59e814: b               #0x59e81c
    // 0x59e818: mov             x4, x1
    // 0x59e81c: ldur            x1, [fp, #-0x30]
    // 0x59e820: ldur            x2, [fp, #-0x40]
    // 0x59e824: ldur            x3, [fp, #-0x18]
    // 0x59e828: stur            x4, [fp, #-0x38]
    // 0x59e82c: r0 = Text()
    //     0x59e82c: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x59e830: mov             x3, x0
    // 0x59e834: ldur            x0, [fp, #-0x38]
    // 0x59e838: stur            x3, [fp, #-0x48]
    // 0x59e83c: StoreField: r3->field_b = r0
    //     0x59e83c: stur            w0, [x3, #0xb]
    // 0x59e840: ldur            x0, [fp, #-0x40]
    // 0x59e844: LoadField: r1 = r0->field_f
    //     0x59e844: ldur            w1, [x0, #0xf]
    // 0x59e848: DecompressPointer r1
    //     0x59e848: add             x1, x1, HEAP, lsl #32
    // 0x59e84c: r0 = 60
    //     0x59e84c: movz            x0, #0x3c
    // 0x59e850: branchIfSmi(r1, 0x59e85c)
    //     0x59e850: tbz             w1, #0, #0x59e85c
    // 0x59e854: r0 = LoadClassIdInstr(r1)
    //     0x59e854: ldur            x0, [x1, #-1]
    //     0x59e858: ubfx            x0, x0, #0xc, #0x14
    // 0x59e85c: r2 = 2
    //     0x59e85c: movz            x2, #0x2
    // 0x59e860: r0 = GDT[cid_x0 + -0xfef]()
    //     0x59e860: sub             lr, x0, #0xfef
    //     0x59e864: ldr             lr, [x21, lr, lsl #3]
    //     0x59e868: blr             lr
    // 0x59e86c: stur            x0, [fp, #-0x38]
    // 0x59e870: r0 = Text()
    //     0x59e870: bl              #0x4e8984  ; AllocateTextStub -> Text (size=0x50)
    // 0x59e874: mov             x3, x0
    // 0x59e878: ldur            x0, [fp, #-0x38]
    // 0x59e87c: stur            x3, [fp, #-0x40]
    // 0x59e880: StoreField: r3->field_b = r0
    //     0x59e880: stur            w0, [x3, #0xb]
    // 0x59e884: r1 = Null
    //     0x59e884: mov             x1, NULL
    // 0x59e888: r2 = 4
    //     0x59e888: movz            x2, #0x4
    // 0x59e88c: r0 = AllocateArray()
    //     0x59e88c: bl              #0x82746c  ; AllocateArrayStub
    // 0x59e890: mov             x2, x0
    // 0x59e894: ldur            x0, [fp, #-0x48]
    // 0x59e898: stur            x2, [fp, #-0x38]
    // 0x59e89c: StoreField: r2->field_f = r0
    //     0x59e89c: stur            w0, [x2, #0xf]
    // 0x59e8a0: ldur            x0, [fp, #-0x40]
    // 0x59e8a4: StoreField: r2->field_13 = r0
    //     0x59e8a4: stur            w0, [x2, #0x13]
    // 0x59e8a8: r1 = <Widget>
    //     0x59e8a8: ldr             x1, [PP, #0x7188]  ; [pp+0x7188] TypeArguments: <Widget>
    // 0x59e8ac: r0 = AllocateGrowableArray()
    //     0x59e8ac: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x59e8b0: mov             x1, x0
    // 0x59e8b4: ldur            x0, [fp, #-0x38]
    // 0x59e8b8: stur            x1, [fp, #-0x40]
    // 0x59e8bc: StoreField: r1->field_f = r0
    //     0x59e8bc: stur            w0, [x1, #0xf]
    // 0x59e8c0: r0 = 4
    //     0x59e8c0: movz            x0, #0x4
    // 0x59e8c4: StoreField: r1->field_b = r0
    //     0x59e8c4: stur            w0, [x1, #0xb]
    // 0x59e8c8: r0 = TableRow()
    //     0x59e8c8: bl              #0x59e9ac  ; AllocateTableRowStub -> TableRow (size=0x14)
    // 0x59e8cc: mov             x2, x0
    // 0x59e8d0: ldur            x0, [fp, #-0x30]
    // 0x59e8d4: stur            x2, [fp, #-0x38]
    // 0x59e8d8: StoreField: r2->field_b = r0
    //     0x59e8d8: stur            w0, [x2, #0xb]
    // 0x59e8dc: ldur            x0, [fp, #-0x40]
    // 0x59e8e0: StoreField: r2->field_f = r0
    //     0x59e8e0: stur            w0, [x2, #0xf]
    // 0x59e8e4: ldur            x0, [fp, #-0x18]
    // 0x59e8e8: LoadField: r1 = r0->field_b
    //     0x59e8e8: ldur            w1, [x0, #0xb]
    // 0x59e8ec: LoadField: r3 = r0->field_f
    //     0x59e8ec: ldur            w3, [x0, #0xf]
    // 0x59e8f0: DecompressPointer r3
    //     0x59e8f0: add             x3, x3, HEAP, lsl #32
    // 0x59e8f4: LoadField: r4 = r3->field_b
    //     0x59e8f4: ldur            w4, [x3, #0xb]
    // 0x59e8f8: r3 = LoadInt32Instr(r1)
    //     0x59e8f8: sbfx            x3, x1, #1, #0x1f
    // 0x59e8fc: stur            x3, [fp, #-0x50]
    // 0x59e900: r1 = LoadInt32Instr(r4)
    //     0x59e900: sbfx            x1, x4, #1, #0x1f
    // 0x59e904: cmp             x3, x1
    // 0x59e908: b.ne            #0x59e914
    // 0x59e90c: mov             x1, x0
    // 0x59e910: r0 = _growToNextCapacity()
    //     0x59e910: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x59e914: ldur            x4, [fp, #-0x10]
    // 0x59e918: ldur            x2, [fp, #-0x18]
    // 0x59e91c: ldur            x3, [fp, #-0x50]
    // 0x59e920: add             x0, x3, #1
    // 0x59e924: lsl             x1, x0, #1
    // 0x59e928: StoreField: r2->field_b = r1
    //     0x59e928: stur            w1, [x2, #0xb]
    // 0x59e92c: LoadField: r1 = r2->field_f
    //     0x59e92c: ldur            w1, [x2, #0xf]
    // 0x59e930: DecompressPointer r1
    //     0x59e930: add             x1, x1, HEAP, lsl #32
    // 0x59e934: ldur            x0, [fp, #-0x38]
    // 0x59e938: ArrayStore: r1[r3] = r0  ; List_4
    //     0x59e938: add             x25, x1, x3, lsl #2
    //     0x59e93c: add             x25, x25, #0xf
    //     0x59e940: str             w0, [x25]
    //     0x59e944: tbz             w0, #0, #0x59e960
    //     0x59e948: ldurb           w16, [x1, #-1]
    //     0x59e94c: ldurb           w17, [x0, #-1]
    //     0x59e950: and             x16, x17, x16, lsr #2
    //     0x59e954: tst             x16, HEAP, lsr #32
    //     0x59e958: b.eq            #0x59e960
    //     0x59e95c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x59e960: eor             x0, x4, #0x10
    // 0x59e964: mov             x5, x0
    // 0x59e968: ldur            x0, [fp, #-8]
    // 0x59e96c: mov             x4, x2
    // 0x59e970: ldur            x2, [fp, #-0x28]
    // 0x59e974: ldur            x3, [fp, #-0x20]
    // 0x59e978: b               #0x59e744
    // 0x59e97c: ldur            x2, [fp, #-0x18]
    // 0x59e980: mov             x0, x2
    // 0x59e984: LeaveFrame
    //     0x59e984: mov             SP, fp
    //     0x59e988: ldp             fp, lr, [SP], #0x10
    // 0x59e98c: ret
    //     0x59e98c: ret             
    // 0x59e990: r0 = noElement()
    //     0x59e990: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x59e994: r0 = Throw()
    //     0x59e994: bl              #0x825670  ; ThrowStub
    // 0x59e998: brk             #0
    // 0x59e99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59e99c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59e9a0: b               #0x59e6b8
    // 0x59e9a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59e9a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59e9a8: b               #0x59e754
  }
  _ getAdditionalDialogs(/* No info */) {
    // ** addr: 0x621c30, size: 0x6b0
    // 0x621c30: EnterFrame
    //     0x621c30: stp             fp, lr, [SP, #-0x10]!
    //     0x621c34: mov             fp, SP
    // 0x621c38: AllocStack(0x38)
    //     0x621c38: sub             SP, SP, #0x38
    // 0x621c3c: SetupParameters(CoreData this /* r1 => r0, fp-0x8 */)
    //     0x621c3c: mov             x0, x1
    //     0x621c40: stur            x1, [fp, #-8]
    // 0x621c44: CheckStackOverflow
    //     0x621c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x621c48: cmp             SP, x16
    //     0x621c4c: b.ls            #0x6222c8
    // 0x621c50: r1 = <Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>>
    //     0x621c50: add             x1, PP, #0x25, lsl #12  ; [pp+0x25868] TypeArguments: <Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>>
    //     0x621c54: ldr             x1, [x1, #0x868]
    // 0x621c58: r2 = 0
    //     0x621c58: movz            x2, #0
    // 0x621c5c: r0 = _GrowableList()
    //     0x621c5c: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x621c60: stur            x0, [fp, #-0x10]
    // 0x621c64: r1 = LoadStaticField(0xf1c)
    //     0x621c64: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x621c68: ldr             x1, [x1, #0x1e38]
    // 0x621c6c: tbnz            w1, #4, #0x621d50
    // 0x621c70: r1 = <String, String, String?, (dynamic this, BuildContext) => Future<void?>>
    //     0x621c70: add             x1, PP, #0x25, lsl #12  ; [pp+0x25870] TypeArguments: <String, String, String?, (dynamic this, BuildContext) => Future<void?>>
    //     0x621c74: ldr             x1, [x1, #0x870]
    // 0x621c78: r0 = Tuple4()
    //     0x621c78: bl              #0x48f61c  ; AllocateTuple4Stub -> Tuple4<X0, X1, X2, X3> (size=0x1c)
    // 0x621c7c: mov             x3, x0
    // 0x621c80: r0 = "Saving Blocked"
    //     0x621c80: add             x0, PP, #0x25, lsl #12  ; [pp+0x25878] "Saving Blocked"
    //     0x621c84: ldr             x0, [x0, #0x878]
    // 0x621c88: stur            x3, [fp, #-0x18]
    // 0x621c8c: StoreField: r3->field_b = r0
    //     0x621c8c: stur            w0, [x3, #0xb]
    // 0x621c90: r0 = "An error occurred. Please restart the app."
    //     0x621c90: add             x0, PP, #0x25, lsl #12  ; [pp+0x25880] "An error occurred. Please restart the app."
    //     0x621c94: ldr             x0, [x0, #0x880]
    // 0x621c98: StoreField: r3->field_f = r0
    //     0x621c98: stur            w0, [x3, #0xf]
    // 0x621c9c: r1 = Function '<anonymous closure>':.
    //     0x621c9c: add             x1, PP, #0x25, lsl #12  ; [pp+0x25888] AnonymousClosure: (0x622970), in [package:pretentious/data/CoreData.dart] CoreData::getAdditionalDialogs (0x621c30)
    //     0x621ca0: ldr             x1, [x1, #0x888]
    // 0x621ca4: r2 = Null
    //     0x621ca4: mov             x2, NULL
    // 0x621ca8: r0 = AllocateClosure()
    //     0x621ca8: bl              #0x826750  ; AllocateClosureStub
    // 0x621cac: ldur            x3, [fp, #-0x18]
    // 0x621cb0: ArrayStore: r3[0] = r0  ; List_4
    //     0x621cb0: stur            w0, [x3, #0x17]
    // 0x621cb4: mov             x0, x3
    // 0x621cb8: r2 = Null
    //     0x621cb8: mov             x2, NULL
    // 0x621cbc: r1 = Null
    //     0x621cbc: mov             x1, NULL
    // 0x621cc0: r8 = Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x621cc0: add             x8, PP, #0x25, lsl #12  ; [pp+0x25890] Type: Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x621cc4: ldr             x8, [x8, #0x890]
    // 0x621cc8: r3 = Null
    //     0x621cc8: add             x3, PP, #0x25, lsl #12  ; [pp+0x25898] Null
    //     0x621ccc: ldr             x3, [x3, #0x898]
    // 0x621cd0: r0 = DefaultTypeTest()
    //     0x621cd0: bl              #0x8252e8  ; DefaultTypeTestStub
    // 0x621cd4: ldur            x0, [fp, #-0x10]
    // 0x621cd8: LoadField: r1 = r0->field_b
    //     0x621cd8: ldur            w1, [x0, #0xb]
    // 0x621cdc: LoadField: r2 = r0->field_f
    //     0x621cdc: ldur            w2, [x0, #0xf]
    // 0x621ce0: DecompressPointer r2
    //     0x621ce0: add             x2, x2, HEAP, lsl #32
    // 0x621ce4: LoadField: r3 = r2->field_b
    //     0x621ce4: ldur            w3, [x2, #0xb]
    // 0x621ce8: r2 = LoadInt32Instr(r1)
    //     0x621ce8: sbfx            x2, x1, #1, #0x1f
    // 0x621cec: stur            x2, [fp, #-0x20]
    // 0x621cf0: r1 = LoadInt32Instr(r3)
    //     0x621cf0: sbfx            x1, x3, #1, #0x1f
    // 0x621cf4: cmp             x2, x1
    // 0x621cf8: b.ne            #0x621d04
    // 0x621cfc: mov             x1, x0
    // 0x621d00: r0 = _growToNextCapacity()
    //     0x621d00: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x621d04: ldur            x3, [fp, #-0x10]
    // 0x621d08: ldur            x2, [fp, #-0x20]
    // 0x621d0c: add             x0, x2, #1
    // 0x621d10: lsl             x1, x0, #1
    // 0x621d14: StoreField: r3->field_b = r1
    //     0x621d14: stur            w1, [x3, #0xb]
    // 0x621d18: LoadField: r1 = r3->field_f
    //     0x621d18: ldur            w1, [x3, #0xf]
    // 0x621d1c: DecompressPointer r1
    //     0x621d1c: add             x1, x1, HEAP, lsl #32
    // 0x621d20: ldur            x0, [fp, #-0x18]
    // 0x621d24: ArrayStore: r1[r2] = r0  ; List_4
    //     0x621d24: add             x25, x1, x2, lsl #2
    //     0x621d28: add             x25, x25, #0xf
    //     0x621d2c: str             w0, [x25]
    //     0x621d30: tbz             w0, #0, #0x621d4c
    //     0x621d34: ldurb           w16, [x1, #-1]
    //     0x621d38: ldurb           w17, [x0, #-1]
    //     0x621d3c: and             x16, x17, x16, lsr #2
    //     0x621d40: tst             x16, HEAP, lsr #32
    //     0x621d44: b.eq            #0x621d4c
    //     0x621d48: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x621d4c: b               #0x621d54
    // 0x621d50: mov             x3, x0
    // 0x621d54: r0 = LoadStaticField(0xa6c)
    //     0x621d54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x621d58: ldr             x0, [x0, #0x14d8]
    // 0x621d5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x621d60: cmp             w0, w16
    // 0x621d64: b.eq            #0x6222d0
    // 0x621d68: mov             x1, x0
    // 0x621d6c: r2 = "DisplayAchievementTokenDialog"
    //     0x621d6c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4e0] "DisplayAchievementTokenDialog"
    //     0x621d70: ldr             x2, [x2, #0x4e0]
    // 0x621d74: r0 = getBool()
    //     0x621d74: bl              #0x452868  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getBool
    // 0x621d78: cmp             w0, NULL
    // 0x621d7c: b.ne            #0x621d88
    // 0x621d80: ldur            x3, [fp, #-0x10]
    // 0x621d84: b               #0x621edc
    // 0x621d88: tbnz            w0, #4, #0x621ed8
    // 0x621d8c: ldur            x0, [fp, #-0x10]
    // 0x621d90: r1 = Null
    //     0x621d90: mov             x1, NULL
    // 0x621d94: r2 = 6
    //     0x621d94: movz            x2, #0x6
    // 0x621d98: r0 = AllocateArray()
    //     0x621d98: bl              #0x82746c  ; AllocateArrayStub
    // 0x621d9c: stur            x0, [fp, #-0x18]
    // 0x621da0: r16 = "Now upon completing a chapter it will reset and award you with a completion token. Completion tokens increase the yields of generators by "
    //     0x621da0: add             x16, PP, #0x25, lsl #12  ; [pp+0x258a8] "Now upon completing a chapter it will reset and award you with a completion token. Completion tokens increase the yields of generators by "
    //     0x621da4: ldr             x16, [x16, #0x8a8]
    // 0x621da8: StoreField: r0->field_f = r16
    //     0x621da8: stur            w16, [x0, #0xf]
    // 0x621dac: r0 = completionTokenPercent()
    //     0x621dac: bl              #0x59e4fc  ; [package:pretentious/widgets/CompleteChapterButtons.dart] ::completionTokenPercent
    // 0x621db0: ldur            x1, [fp, #-0x18]
    // 0x621db4: ArrayStore: r1[1] = r0  ; List_4
    //     0x621db4: add             x25, x1, #0x13
    //     0x621db8: str             w0, [x25]
    //     0x621dbc: tbz             w0, #0, #0x621dd8
    //     0x621dc0: ldurb           w16, [x1, #-1]
    //     0x621dc4: ldurb           w17, [x0, #-1]
    //     0x621dc8: and             x16, x17, x16, lsr #2
    //     0x621dcc: tst             x16, HEAP, lsr #32
    //     0x621dd0: b.eq            #0x621dd8
    //     0x621dd4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x621dd8: ldur            x0, [fp, #-0x18]
    // 0x621ddc: r16 = "."
    //     0x621ddc: ldr             x16, [PP, #0x108]  ; [pp+0x108] "."
    // 0x621de0: ArrayStore: r0[0] = r16  ; List_4
    //     0x621de0: stur            w16, [x0, #0x17]
    // 0x621de4: str             x0, [SP]
    // 0x621de8: r0 = _interpolate()
    //     0x621de8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x621dec: r1 = <String, String, String, (dynamic this, BuildContext) => Future<void?>>
    //     0x621dec: add             x1, PP, #0x25, lsl #12  ; [pp+0x258b0] TypeArguments: <String, String, String, (dynamic this, BuildContext) => Future<void?>>
    //     0x621df0: ldr             x1, [x1, #0x8b0]
    // 0x621df4: stur            x0, [fp, #-0x18]
    // 0x621df8: r0 = Tuple4()
    //     0x621df8: bl              #0x48f61c  ; AllocateTuple4Stub -> Tuple4<X0, X1, X2, X3> (size=0x1c)
    // 0x621dfc: mov             x3, x0
    // 0x621e00: r0 = "Achievement Tokens"
    //     0x621e00: add             x0, PP, #0x25, lsl #12  ; [pp+0x258b8] "Achievement Tokens"
    //     0x621e04: ldr             x0, [x0, #0x8b8]
    // 0x621e08: stur            x3, [fp, #-0x28]
    // 0x621e0c: StoreField: r3->field_b = r0
    //     0x621e0c: stur            w0, [x3, #0xb]
    // 0x621e10: ldur            x0, [fp, #-0x18]
    // 0x621e14: StoreField: r3->field_f = r0
    //     0x621e14: stur            w0, [x3, #0xf]
    // 0x621e18: r0 = "Dismiss"
    //     0x621e18: add             x0, PP, #0xf, lsl #12  ; [pp+0xfb88] "Dismiss"
    //     0x621e1c: ldr             x0, [x0, #0xb88]
    // 0x621e20: StoreField: r3->field_13 = r0
    //     0x621e20: stur            w0, [x3, #0x13]
    // 0x621e24: r1 = Function '<anonymous closure>':.
    //     0x621e24: add             x1, PP, #0x25, lsl #12  ; [pp+0x258c0] AnonymousClosure: (0x6228c4), in [package:pretentious/data/CoreData.dart] CoreData::getAdditionalDialogs (0x621c30)
    //     0x621e28: ldr             x1, [x1, #0x8c0]
    // 0x621e2c: r2 = Null
    //     0x621e2c: mov             x2, NULL
    // 0x621e30: r0 = AllocateClosure()
    //     0x621e30: bl              #0x826750  ; AllocateClosureStub
    // 0x621e34: ldur            x3, [fp, #-0x28]
    // 0x621e38: ArrayStore: r3[0] = r0  ; List_4
    //     0x621e38: stur            w0, [x3, #0x17]
    // 0x621e3c: mov             x0, x3
    // 0x621e40: r2 = Null
    //     0x621e40: mov             x2, NULL
    // 0x621e44: r1 = Null
    //     0x621e44: mov             x1, NULL
    // 0x621e48: r8 = Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x621e48: add             x8, PP, #0x25, lsl #12  ; [pp+0x25890] Type: Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x621e4c: ldr             x8, [x8, #0x890]
    // 0x621e50: r3 = Null
    //     0x621e50: add             x3, PP, #0x25, lsl #12  ; [pp+0x258c8] Null
    //     0x621e54: ldr             x3, [x3, #0x8c8]
    // 0x621e58: r0 = DefaultTypeTest()
    //     0x621e58: bl              #0x8252e8  ; DefaultTypeTestStub
    // 0x621e5c: ldur            x0, [fp, #-0x10]
    // 0x621e60: LoadField: r1 = r0->field_b
    //     0x621e60: ldur            w1, [x0, #0xb]
    // 0x621e64: LoadField: r2 = r0->field_f
    //     0x621e64: ldur            w2, [x0, #0xf]
    // 0x621e68: DecompressPointer r2
    //     0x621e68: add             x2, x2, HEAP, lsl #32
    // 0x621e6c: LoadField: r3 = r2->field_b
    //     0x621e6c: ldur            w3, [x2, #0xb]
    // 0x621e70: r2 = LoadInt32Instr(r1)
    //     0x621e70: sbfx            x2, x1, #1, #0x1f
    // 0x621e74: stur            x2, [fp, #-0x20]
    // 0x621e78: r1 = LoadInt32Instr(r3)
    //     0x621e78: sbfx            x1, x3, #1, #0x1f
    // 0x621e7c: cmp             x2, x1
    // 0x621e80: b.ne            #0x621e8c
    // 0x621e84: mov             x1, x0
    // 0x621e88: r0 = _growToNextCapacity()
    //     0x621e88: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x621e8c: ldur            x3, [fp, #-0x10]
    // 0x621e90: ldur            x2, [fp, #-0x20]
    // 0x621e94: add             x0, x2, #1
    // 0x621e98: lsl             x1, x0, #1
    // 0x621e9c: StoreField: r3->field_b = r1
    //     0x621e9c: stur            w1, [x3, #0xb]
    // 0x621ea0: LoadField: r1 = r3->field_f
    //     0x621ea0: ldur            w1, [x3, #0xf]
    // 0x621ea4: DecompressPointer r1
    //     0x621ea4: add             x1, x1, HEAP, lsl #32
    // 0x621ea8: ldur            x0, [fp, #-0x28]
    // 0x621eac: ArrayStore: r1[r2] = r0  ; List_4
    //     0x621eac: add             x25, x1, x2, lsl #2
    //     0x621eb0: add             x25, x25, #0xf
    //     0x621eb4: str             w0, [x25]
    //     0x621eb8: tbz             w0, #0, #0x621ed4
    //     0x621ebc: ldurb           w16, [x1, #-1]
    //     0x621ec0: ldurb           w17, [x0, #-1]
    //     0x621ec4: and             x16, x17, x16, lsr #2
    //     0x621ec8: tst             x16, HEAP, lsr #32
    //     0x621ecc: b.eq            #0x621ed4
    //     0x621ed0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x621ed4: b               #0x621edc
    // 0x621ed8: ldur            x3, [fp, #-0x10]
    // 0x621edc: ldur            x0, [fp, #-8]
    // 0x621ee0: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x621ee0: ldur            w4, [x0, #0x17]
    // 0x621ee4: DecompressPointer r4
    //     0x621ee4: add             x4, x4, HEAP, lsl #32
    // 0x621ee8: mov             x1, x4
    // 0x621eec: stur            x4, [fp, #-0x18]
    // 0x621ef0: r2 = "3"
    //     0x621ef0: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x621ef4: ldr             x2, [x2, #0x2f0]
    // 0x621ef8: r0 = containsKey()
    //     0x621ef8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x621efc: tbnz            w0, #4, #0x622010
    // 0x621f00: ldur            x0, [fp, #-8]
    // 0x621f04: LoadField: r1 = r0->field_13
    //     0x621f04: ldur            w1, [x0, #0x13]
    // 0x621f08: DecompressPointer r1
    //     0x621f08: add             x1, x1, HEAP, lsl #32
    // 0x621f0c: r2 = 10
    //     0x621f0c: movz            x2, #0xa
    // 0x621f10: r0 = containsKey()
    //     0x621f10: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x621f14: tbz             w0, #4, #0x622008
    // 0x621f18: ldur            x0, [fp, #-0x10]
    // 0x621f1c: r1 = <String, String, String, (dynamic this, BuildContext) => Future<void?>>
    //     0x621f1c: add             x1, PP, #0x25, lsl #12  ; [pp+0x258b0] TypeArguments: <String, String, String, (dynamic this, BuildContext) => Future<void?>>
    //     0x621f20: ldr             x1, [x1, #0x8b0]
    // 0x621f24: r0 = Tuple4()
    //     0x621f24: bl              #0x48f61c  ; AllocateTuple4Stub -> Tuple4<X0, X1, X2, X3> (size=0x1c)
    // 0x621f28: mov             x3, x0
    // 0x621f2c: r0 = "Skip To Chapter 4\?"
    //     0x621f2c: add             x0, PP, #0x25, lsl #12  ; [pp+0x258d8] "Skip To Chapter 4\?"
    //     0x621f30: ldr             x0, [x0, #0x8d8]
    // 0x621f34: stur            x3, [fp, #-0x28]
    // 0x621f38: StoreField: r3->field_b = r0
    //     0x621f38: stur            w0, [x3, #0xb]
    // 0x621f3c: r0 = "It looks like you\'ve completed chapter 3 but have not advanced to chapter 4 yet. Would you like to unlock it now\? Note that this will not automatically bring you to the new chapter, you will have to manually select it in the chapter select menu."
    //     0x621f3c: add             x0, PP, #0x25, lsl #12  ; [pp+0x258e0] "It looks like you\'ve completed chapter 3 but have not advanced to chapter 4 yet. Would you like to unlock it now\? Note that this will not automatically bring you to the new chapter, you will have to manually select it in the chapter select menu."
    //     0x621f40: ldr             x0, [x0, #0x8e0]
    // 0x621f44: StoreField: r3->field_f = r0
    //     0x621f44: stur            w0, [x3, #0xf]
    // 0x621f48: r0 = "DO IT"
    //     0x621f48: add             x0, PP, #0x25, lsl #12  ; [pp+0x258e8] "DO IT"
    //     0x621f4c: ldr             x0, [x0, #0x8e8]
    // 0x621f50: StoreField: r3->field_13 = r0
    //     0x621f50: stur            w0, [x3, #0x13]
    // 0x621f54: r1 = Function '<anonymous closure>':.
    //     0x621f54: add             x1, PP, #0x25, lsl #12  ; [pp+0x258f0] AnonymousClosure: (0x622824), in [package:pretentious/data/CoreData.dart] CoreData::getAdditionalDialogs (0x621c30)
    //     0x621f58: ldr             x1, [x1, #0x8f0]
    // 0x621f5c: r2 = Null
    //     0x621f5c: mov             x2, NULL
    // 0x621f60: r0 = AllocateClosure()
    //     0x621f60: bl              #0x826750  ; AllocateClosureStub
    // 0x621f64: ldur            x3, [fp, #-0x28]
    // 0x621f68: ArrayStore: r3[0] = r0  ; List_4
    //     0x621f68: stur            w0, [x3, #0x17]
    // 0x621f6c: mov             x0, x3
    // 0x621f70: r2 = Null
    //     0x621f70: mov             x2, NULL
    // 0x621f74: r1 = Null
    //     0x621f74: mov             x1, NULL
    // 0x621f78: r8 = Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x621f78: add             x8, PP, #0x25, lsl #12  ; [pp+0x25890] Type: Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x621f7c: ldr             x8, [x8, #0x890]
    // 0x621f80: r3 = Null
    //     0x621f80: add             x3, PP, #0x25, lsl #12  ; [pp+0x258f8] Null
    //     0x621f84: ldr             x3, [x3, #0x8f8]
    // 0x621f88: r0 = DefaultTypeTest()
    //     0x621f88: bl              #0x8252e8  ; DefaultTypeTestStub
    // 0x621f8c: ldur            x0, [fp, #-0x10]
    // 0x621f90: LoadField: r1 = r0->field_b
    //     0x621f90: ldur            w1, [x0, #0xb]
    // 0x621f94: LoadField: r2 = r0->field_f
    //     0x621f94: ldur            w2, [x0, #0xf]
    // 0x621f98: DecompressPointer r2
    //     0x621f98: add             x2, x2, HEAP, lsl #32
    // 0x621f9c: LoadField: r3 = r2->field_b
    //     0x621f9c: ldur            w3, [x2, #0xb]
    // 0x621fa0: r2 = LoadInt32Instr(r1)
    //     0x621fa0: sbfx            x2, x1, #1, #0x1f
    // 0x621fa4: stur            x2, [fp, #-0x20]
    // 0x621fa8: r1 = LoadInt32Instr(r3)
    //     0x621fa8: sbfx            x1, x3, #1, #0x1f
    // 0x621fac: cmp             x2, x1
    // 0x621fb0: b.ne            #0x621fbc
    // 0x621fb4: mov             x1, x0
    // 0x621fb8: r0 = _growToNextCapacity()
    //     0x621fb8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x621fbc: ldur            x3, [fp, #-0x10]
    // 0x621fc0: ldur            x2, [fp, #-0x20]
    // 0x621fc4: add             x0, x2, #1
    // 0x621fc8: lsl             x1, x0, #1
    // 0x621fcc: StoreField: r3->field_b = r1
    //     0x621fcc: stur            w1, [x3, #0xb]
    // 0x621fd0: LoadField: r1 = r3->field_f
    //     0x621fd0: ldur            w1, [x3, #0xf]
    // 0x621fd4: DecompressPointer r1
    //     0x621fd4: add             x1, x1, HEAP, lsl #32
    // 0x621fd8: ldur            x0, [fp, #-0x28]
    // 0x621fdc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x621fdc: add             x25, x1, x2, lsl #2
    //     0x621fe0: add             x25, x25, #0xf
    //     0x621fe4: str             w0, [x25]
    //     0x621fe8: tbz             w0, #0, #0x622004
    //     0x621fec: ldurb           w16, [x1, #-1]
    //     0x621ff0: ldurb           w17, [x0, #-1]
    //     0x621ff4: and             x16, x17, x16, lsr #2
    //     0x621ff8: tst             x16, HEAP, lsr #32
    //     0x621ffc: b.eq            #0x622004
    //     0x622000: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x622004: b               #0x622014
    // 0x622008: ldur            x3, [fp, #-0x10]
    // 0x62200c: b               #0x622014
    // 0x622010: ldur            x3, [fp, #-0x10]
    // 0x622014: ldur            x1, [fp, #-0x18]
    // 0x622018: r2 = "4"
    //     0x622018: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x62201c: ldr             x2, [x2, #0x2f8]
    // 0x622020: r0 = containsKey()
    //     0x622020: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x622024: tbnz            w0, #4, #0x622138
    // 0x622028: ldur            x0, [fp, #-8]
    // 0x62202c: LoadField: r1 = r0->field_13
    //     0x62202c: ldur            w1, [x0, #0x13]
    // 0x622030: DecompressPointer r1
    //     0x622030: add             x1, x1, HEAP, lsl #32
    // 0x622034: r2 = 16
    //     0x622034: movz            x2, #0x10
    // 0x622038: r0 = containsKey()
    //     0x622038: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x62203c: tbz             w0, #4, #0x622130
    // 0x622040: ldur            x0, [fp, #-0x10]
    // 0x622044: r1 = <String, String, String, (dynamic this, BuildContext) => Future<void?>>
    //     0x622044: add             x1, PP, #0x25, lsl #12  ; [pp+0x258b0] TypeArguments: <String, String, String, (dynamic this, BuildContext) => Future<void?>>
    //     0x622048: ldr             x1, [x1, #0x8b0]
    // 0x62204c: r0 = Tuple4()
    //     0x62204c: bl              #0x48f61c  ; AllocateTuple4Stub -> Tuple4<X0, X1, X2, X3> (size=0x1c)
    // 0x622050: mov             x3, x0
    // 0x622054: r0 = "Skip To Chapter 5\?"
    //     0x622054: add             x0, PP, #0x25, lsl #12  ; [pp+0x25908] "Skip To Chapter 5\?"
    //     0x622058: ldr             x0, [x0, #0x908]
    // 0x62205c: stur            x3, [fp, #-8]
    // 0x622060: StoreField: r3->field_b = r0
    //     0x622060: stur            w0, [x3, #0xb]
    // 0x622064: r0 = "It looks like you\'ve completed chapter 4 but have not advanced to chapter 5 yet. Would you like to unlock it now\? Note that this will not automatically bring you to the new chapter, you will have to manually select it in the chapter select menu."
    //     0x622064: add             x0, PP, #0x25, lsl #12  ; [pp+0x25910] "It looks like you\'ve completed chapter 4 but have not advanced to chapter 5 yet. Would you like to unlock it now\? Note that this will not automatically bring you to the new chapter, you will have to manually select it in the chapter select menu."
    //     0x622068: ldr             x0, [x0, #0x910]
    // 0x62206c: StoreField: r3->field_f = r0
    //     0x62206c: stur            w0, [x3, #0xf]
    // 0x622070: r0 = "DO IT"
    //     0x622070: add             x0, PP, #0x25, lsl #12  ; [pp+0x258e8] "DO IT"
    //     0x622074: ldr             x0, [x0, #0x8e8]
    // 0x622078: StoreField: r3->field_13 = r0
    //     0x622078: stur            w0, [x3, #0x13]
    // 0x62207c: r1 = Function '<anonymous closure>':.
    //     0x62207c: add             x1, PP, #0x25, lsl #12  ; [pp+0x25918] AnonymousClosure: (0x6222e0), in [package:pretentious/data/CoreData.dart] CoreData::getAdditionalDialogs (0x621c30)
    //     0x622080: ldr             x1, [x1, #0x918]
    // 0x622084: r2 = Null
    //     0x622084: mov             x2, NULL
    // 0x622088: r0 = AllocateClosure()
    //     0x622088: bl              #0x826750  ; AllocateClosureStub
    // 0x62208c: ldur            x3, [fp, #-8]
    // 0x622090: ArrayStore: r3[0] = r0  ; List_4
    //     0x622090: stur            w0, [x3, #0x17]
    // 0x622094: mov             x0, x3
    // 0x622098: r2 = Null
    //     0x622098: mov             x2, NULL
    // 0x62209c: r1 = Null
    //     0x62209c: mov             x1, NULL
    // 0x6220a0: r8 = Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x6220a0: add             x8, PP, #0x25, lsl #12  ; [pp+0x25890] Type: Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>
    //     0x6220a4: ldr             x8, [x8, #0x890]
    // 0x6220a8: r3 = Null
    //     0x6220a8: add             x3, PP, #0x25, lsl #12  ; [pp+0x25920] Null
    //     0x6220ac: ldr             x3, [x3, #0x920]
    // 0x6220b0: r0 = DefaultTypeTest()
    //     0x6220b0: bl              #0x8252e8  ; DefaultTypeTestStub
    // 0x6220b4: ldur            x0, [fp, #-0x10]
    // 0x6220b8: LoadField: r1 = r0->field_b
    //     0x6220b8: ldur            w1, [x0, #0xb]
    // 0x6220bc: LoadField: r2 = r0->field_f
    //     0x6220bc: ldur            w2, [x0, #0xf]
    // 0x6220c0: DecompressPointer r2
    //     0x6220c0: add             x2, x2, HEAP, lsl #32
    // 0x6220c4: LoadField: r3 = r2->field_b
    //     0x6220c4: ldur            w3, [x2, #0xb]
    // 0x6220c8: r2 = LoadInt32Instr(r1)
    //     0x6220c8: sbfx            x2, x1, #1, #0x1f
    // 0x6220cc: stur            x2, [fp, #-0x20]
    // 0x6220d0: r1 = LoadInt32Instr(r3)
    //     0x6220d0: sbfx            x1, x3, #1, #0x1f
    // 0x6220d4: cmp             x2, x1
    // 0x6220d8: b.ne            #0x6220e4
    // 0x6220dc: mov             x1, x0
    // 0x6220e0: r0 = _growToNextCapacity()
    //     0x6220e0: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6220e4: ldur            x2, [fp, #-0x10]
    // 0x6220e8: ldur            x3, [fp, #-0x20]
    // 0x6220ec: add             x0, x3, #1
    // 0x6220f0: lsl             x1, x0, #1
    // 0x6220f4: StoreField: r2->field_b = r1
    //     0x6220f4: stur            w1, [x2, #0xb]
    // 0x6220f8: LoadField: r1 = r2->field_f
    //     0x6220f8: ldur            w1, [x2, #0xf]
    // 0x6220fc: DecompressPointer r1
    //     0x6220fc: add             x1, x1, HEAP, lsl #32
    // 0x622100: ldur            x0, [fp, #-8]
    // 0x622104: ArrayStore: r1[r3] = r0  ; List_4
    //     0x622104: add             x25, x1, x3, lsl #2
    //     0x622108: add             x25, x25, #0xf
    //     0x62210c: str             w0, [x25]
    //     0x622110: tbz             w0, #0, #0x62212c
    //     0x622114: ldurb           w16, [x1, #-1]
    //     0x622118: ldurb           w17, [x0, #-1]
    //     0x62211c: and             x16, x17, x16, lsr #2
    //     0x622120: tst             x16, HEAP, lsr #32
    //     0x622124: b.eq            #0x62212c
    //     0x622128: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x62212c: b               #0x62213c
    // 0x622130: ldur            x2, [fp, #-0x10]
    // 0x622134: b               #0x62213c
    // 0x622138: ldur            x2, [fp, #-0x10]
    // 0x62213c: r0 = currentActiveState()
    //     0x62213c: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x622140: r1 = LoadClassIdInstr(r0)
    //     0x622140: ldur            x1, [x0, #-1]
    //     0x622144: ubfx            x1, x1, #0xc, #0x14
    // 0x622148: cmp             x1, #0x10c
    // 0x62214c: b.ne            #0x6222b8
    // 0x622150: r0 = currentActiveState()
    //     0x622150: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x622154: mov             x3, x0
    // 0x622158: r2 = Null
    //     0x622158: mov             x2, NULL
    // 0x62215c: r1 = Null
    //     0x62215c: mov             x1, NULL
    // 0x622160: stur            x3, [fp, #-8]
    // 0x622164: r4 = LoadClassIdInstr(r0)
    //     0x622164: ldur            x4, [x0, #-1]
    //     0x622168: ubfx            x4, x4, #0xc, #0x14
    // 0x62216c: cmp             x4, #0x10c
    // 0x622170: b.eq            #0x622188
    // 0x622174: r8 = CustomLevelGameState
    //     0x622174: add             x8, PP, #0x1f, lsl #12  ; [pp+0x1f268] Type: CustomLevelGameState
    //     0x622178: ldr             x8, [x8, #0x268]
    // 0x62217c: r3 = Null
    //     0x62217c: add             x3, PP, #0x25, lsl #12  ; [pp+0x25930] Null
    //     0x622180: ldr             x3, [x3, #0x930]
    // 0x622184: r0 = CustomLevelGameState()
    //     0x622184: bl              #0x372fbc  ; IsType_CustomLevelGameState_Stub
    // 0x622188: ldur            x0, [fp, #-8]
    // 0x62218c: LoadField: r1 = r0->field_8f
    //     0x62218c: ldur            w1, [x0, #0x8f]
    // 0x622190: DecompressPointer r1
    //     0x622190: add             x1, x1, HEAP, lsl #32
    // 0x622194: tbnz            w1, #4, #0x6222b0
    // 0x622198: r1 = LoadStaticField(0xf64)
    //     0x622198: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x62219c: ldr             x1, [x1, #0x1ec8]
    // 0x6221a0: cmp             w1, NULL
    // 0x6221a4: b.eq            #0x6222a8
    // 0x6221a8: LoadField: r2 = r1->field_37
    //     0x6221a8: ldur            w2, [x1, #0x37]
    // 0x6221ac: DecompressPointer r2
    //     0x6221ac: add             x2, x2, HEAP, lsl #32
    // 0x6221b0: LoadField: r1 = r2->field_7
    //     0x6221b0: ldur            w1, [x2, #7]
    // 0x6221b4: DecompressPointer r1
    //     0x6221b4: add             x1, x1, HEAP, lsl #32
    // 0x6221b8: LoadField: r2 = r0->field_8b
    //     0x6221b8: ldur            w2, [x0, #0x8b]
    // 0x6221bc: DecompressPointer r2
    //     0x6221bc: add             x2, x2, HEAP, lsl #32
    // 0x6221c0: stur            x2, [fp, #-0x18]
    // 0x6221c4: LoadField: r0 = r2->field_37
    //     0x6221c4: ldur            w0, [x2, #0x37]
    // 0x6221c8: DecompressPointer r0
    //     0x6221c8: add             x0, x0, HEAP, lsl #32
    // 0x6221cc: LoadField: r3 = r0->field_7
    //     0x6221cc: ldur            w3, [x0, #7]
    // 0x6221d0: DecompressPointer r3
    //     0x6221d0: add             x3, x3, HEAP, lsl #32
    // 0x6221d4: r0 = LoadClassIdInstr(r1)
    //     0x6221d4: ldur            x0, [x1, #-1]
    //     0x6221d8: ubfx            x0, x0, #0xc, #0x14
    // 0x6221dc: stp             x3, x1, [SP]
    // 0x6221e0: mov             lr, x0
    // 0x6221e4: ldr             lr, [x21, lr, lsl #3]
    // 0x6221e8: blr             lr
    // 0x6221ec: tbnz            w0, #4, #0x6222a0
    // 0x6221f0: ldur            x1, [fp, #-0x18]
    // 0x6221f4: r0 = levelDataHash()
    //     0x6221f4: bl              #0x606818  ; [package:pretentious/data/Chapters/LevelEditorGameState.dart] LevelEditorGameState::levelDataHash
    // 0x6221f8: stur            x0, [fp, #-8]
    // 0x6221fc: r1 = LoadStaticField(0xf64)
    //     0x6221fc: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x622200: ldr             x1, [x1, #0x1ec8]
    // 0x622204: cmp             w1, NULL
    // 0x622208: b.eq            #0x6222dc
    // 0x62220c: r0 = levelDataHash()
    //     0x62220c: bl              #0x606818  ; [package:pretentious/data/Chapters/LevelEditorGameState.dart] LevelEditorGameState::levelDataHash
    // 0x622210: mov             x1, x0
    // 0x622214: ldur            x0, [fp, #-8]
    // 0x622218: r2 = LoadClassIdInstr(r0)
    //     0x622218: ldur            x2, [x0, #-1]
    //     0x62221c: ubfx            x2, x2, #0xc, #0x14
    // 0x622220: stp             x1, x0, [SP]
    // 0x622224: mov             x0, x2
    // 0x622228: mov             lr, x0
    // 0x62222c: ldr             lr, [x21, lr, lsl #3]
    // 0x622230: blr             lr
    // 0x622234: tbz             w0, #4, #0x622298
    // 0x622238: ldur            x0, [fp, #-0x10]
    // 0x62223c: LoadField: r1 = r0->field_b
    //     0x62223c: ldur            w1, [x0, #0xb]
    // 0x622240: LoadField: r2 = r0->field_f
    //     0x622240: ldur            w2, [x0, #0xf]
    // 0x622244: DecompressPointer r2
    //     0x622244: add             x2, x2, HEAP, lsl #32
    // 0x622248: LoadField: r3 = r2->field_b
    //     0x622248: ldur            w3, [x2, #0xb]
    // 0x62224c: r2 = LoadInt32Instr(r1)
    //     0x62224c: sbfx            x2, x1, #1, #0x1f
    // 0x622250: stur            x2, [fp, #-0x20]
    // 0x622254: r1 = LoadInt32Instr(r3)
    //     0x622254: sbfx            x1, x3, #1, #0x1f
    // 0x622258: cmp             x2, x1
    // 0x62225c: b.ne            #0x622268
    // 0x622260: mov             x1, x0
    // 0x622264: r0 = _growToNextCapacity()
    //     0x622264: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x622268: ldur            x0, [fp, #-0x10]
    // 0x62226c: ldur            x1, [fp, #-0x20]
    // 0x622270: add             x2, x1, #1
    // 0x622274: lsl             x3, x2, #1
    // 0x622278: StoreField: r0->field_b = r3
    //     0x622278: stur            w3, [x0, #0xb]
    // 0x62227c: LoadField: r2 = r0->field_f
    //     0x62227c: ldur            w2, [x0, #0xf]
    // 0x622280: DecompressPointer r2
    //     0x622280: add             x2, x2, HEAP, lsl #32
    // 0x622284: add             x3, x2, x1, lsl #2
    // 0x622288: r16 = Instance_Tuple4
    //     0x622288: add             x16, PP, #0x25, lsl #12  ; [pp+0x25940] Obj!Tuple4<String, String, String?, ((dynamic this, BuildContext) => Future<void?>)?>@81f811
    //     0x62228c: ldr             x16, [x16, #0x940]
    // 0x622290: StoreField: r3->field_f = r16
    //     0x622290: stur            w16, [x3, #0xf]
    // 0x622294: b               #0x6222bc
    // 0x622298: ldur            x0, [fp, #-0x10]
    // 0x62229c: b               #0x6222bc
    // 0x6222a0: ldur            x0, [fp, #-0x10]
    // 0x6222a4: b               #0x6222bc
    // 0x6222a8: ldur            x0, [fp, #-0x10]
    // 0x6222ac: b               #0x6222bc
    // 0x6222b0: ldur            x0, [fp, #-0x10]
    // 0x6222b4: b               #0x6222bc
    // 0x6222b8: ldur            x0, [fp, #-0x10]
    // 0x6222bc: LeaveFrame
    //     0x6222bc: mov             SP, fp
    //     0x6222c0: ldp             fp, lr, [SP], #0x10
    // 0x6222c4: ret
    //     0x6222c4: ret             
    // 0x6222c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6222c8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6222cc: b               #0x621c50
    // 0x6222d0: r9 = prefs
    //     0x6222d0: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x6222d4: ldr             x9, [x9, #0xc00]
    // 0x6222d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6222d8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6222dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6222dc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6222e0, size: 0xa0
    // 0x6222e0: EnterFrame
    //     0x6222e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6222e4: mov             fp, SP
    // 0x6222e8: AllocStack(0x18)
    //     0x6222e8: sub             SP, SP, #0x18
    // 0x6222ec: SetupParameters(CoreData this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x6222ec: stur            NULL, [fp, #-8]
    //     0x6222f0: movz            x0, #0
    //     0x6222f4: add             x1, fp, w0, sxtw #2
    //     0x6222f8: ldr             x1, [x1, #0x18]
    //     0x6222fc: add             x2, fp, w0, sxtw #2
    //     0x622300: ldr             x2, [x2, #0x10]
    //     0x622304: stur            x2, [fp, #-0x18]
    //     0x622308: ldur            w3, [x1, #0x17]
    //     0x62230c: add             x3, x3, HEAP, lsl #32
    //     0x622310: stur            x3, [fp, #-0x10]
    // 0x622314: CheckStackOverflow
    //     0x622314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622318: cmp             SP, x16
    //     0x62231c: b.ls            #0x622378
    // 0x622320: InitAsync() -> Future<void?>
    //     0x622320: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x622324: bl              #0x34b9a0  ; InitAsyncStub
    // 0x622328: ldur            x1, [fp, #-0x18]
    // 0x62232c: r2 = 16
    //     0x62232c: movz            x2, #0x10
    // 0x622330: r3 = Null
    //     0x622330: mov             x3, NULL
    // 0x622334: r0 = displaySlackPageAndIncrementAct()
    //     0x622334: bl              #0x622380  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPageAndIncrementAct
    // 0x622338: mov             x1, x0
    // 0x62233c: stur            x1, [fp, #-0x18]
    // 0x622340: r0 = Await()
    //     0x622340: bl              #0x34b75c  ; AwaitStub
    // 0x622344: r0 = LoadStaticField(0xf20)
    //     0x622344: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x622348: ldr             x0, [x0, #0x1e40]
    // 0x62234c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x622350: cmp             w0, w16
    // 0x622354: b.ne            #0x622364
    // 0x622358: r2 = menuPopupStateGroup
    //     0x622358: add             x2, PP, #0xe, lsl #12  ; [pp+0xeba8] Field <::.menuPopupStateGroup>: static late (offset: 0xf20)
    //     0x62235c: ldr             x2, [x2, #0xba8]
    // 0x622360: r0 = InitLateStaticField()
    //     0x622360: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x622364: mov             x1, x0
    // 0x622368: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x622368: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x62236c: r0 = notifyAll()
    //     0x62236c: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x622370: r0 = Null
    //     0x622370: mov             x0, NULL
    // 0x622374: r0 = ReturnAsyncNotFuture()
    //     0x622374: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x622378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622378: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62237c: b               #0x622320
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x622824, size: 0xa0
    // 0x622824: EnterFrame
    //     0x622824: stp             fp, lr, [SP, #-0x10]!
    //     0x622828: mov             fp, SP
    // 0x62282c: AllocStack(0x18)
    //     0x62282c: sub             SP, SP, #0x18
    // 0x622830: SetupParameters(CoreData this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x622830: stur            NULL, [fp, #-8]
    //     0x622834: movz            x0, #0
    //     0x622838: add             x1, fp, w0, sxtw #2
    //     0x62283c: ldr             x1, [x1, #0x18]
    //     0x622840: add             x2, fp, w0, sxtw #2
    //     0x622844: ldr             x2, [x2, #0x10]
    //     0x622848: stur            x2, [fp, #-0x18]
    //     0x62284c: ldur            w3, [x1, #0x17]
    //     0x622850: add             x3, x3, HEAP, lsl #32
    //     0x622854: stur            x3, [fp, #-0x10]
    // 0x622858: CheckStackOverflow
    //     0x622858: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x62285c: cmp             SP, x16
    //     0x622860: b.ls            #0x6228bc
    // 0x622864: InitAsync() -> Future<void?>
    //     0x622864: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x622868: bl              #0x34b9a0  ; InitAsyncStub
    // 0x62286c: ldur            x1, [fp, #-0x18]
    // 0x622870: r2 = 10
    //     0x622870: movz            x2, #0xa
    // 0x622874: r3 = Null
    //     0x622874: mov             x3, NULL
    // 0x622878: r0 = displaySlackPageAndIncrementAct()
    //     0x622878: bl              #0x622380  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPageAndIncrementAct
    // 0x62287c: mov             x1, x0
    // 0x622880: stur            x1, [fp, #-0x18]
    // 0x622884: r0 = Await()
    //     0x622884: bl              #0x34b75c  ; AwaitStub
    // 0x622888: r0 = LoadStaticField(0xf20)
    //     0x622888: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x62288c: ldr             x0, [x0, #0x1e40]
    // 0x622890: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x622894: cmp             w0, w16
    // 0x622898: b.ne            #0x6228a8
    // 0x62289c: r2 = menuPopupStateGroup
    //     0x62289c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeba8] Field <::.menuPopupStateGroup>: static late (offset: 0xf20)
    //     0x6228a0: ldr             x2, [x2, #0xba8]
    // 0x6228a4: r0 = InitLateStaticField()
    //     0x6228a4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x6228a8: mov             x1, x0
    // 0x6228ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6228ac: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6228b0: r0 = notifyAll()
    //     0x6228b0: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x6228b4: r0 = Null
    //     0x6228b4: mov             x0, NULL
    // 0x6228b8: r0 = ReturnAsyncNotFuture()
    //     0x6228b8: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x6228bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6228bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6228c0: b               #0x622864
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6228c4, size: 0xac
    // 0x6228c4: EnterFrame
    //     0x6228c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6228c8: mov             fp, SP
    // 0x6228cc: AllocStack(0x10)
    //     0x6228cc: sub             SP, SP, #0x10
    // 0x6228d0: SetupParameters(CoreData this /* r1 */)
    //     0x6228d0: stur            NULL, [fp, #-8]
    //     0x6228d4: movz            x0, #0
    //     0x6228d8: add             x1, fp, w0, sxtw #2
    //     0x6228dc: ldr             x1, [x1, #0x18]
    //     0x6228e0: ldur            w2, [x1, #0x17]
    //     0x6228e4: add             x2, x2, HEAP, lsl #32
    //     0x6228e8: stur            x2, [fp, #-0x10]
    // 0x6228ec: CheckStackOverflow
    //     0x6228ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6228f0: cmp             SP, x16
    //     0x6228f4: b.ls            #0x62295c
    // 0x6228f8: InitAsync() -> Future<void?>
    //     0x6228f8: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6228fc: bl              #0x34b9a0  ; InitAsyncStub
    // 0x622900: r0 = LoadStaticField(0xa6c)
    //     0x622900: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x622904: ldr             x0, [x0, #0x14d8]
    // 0x622908: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x62290c: cmp             w0, w16
    // 0x622910: b.eq            #0x622964
    // 0x622914: mov             x1, x0
    // 0x622918: r2 = "DisplayAchievementTokenDialog"
    //     0x622918: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4e0] "DisplayAchievementTokenDialog"
    //     0x62291c: ldr             x2, [x2, #0x4e0]
    // 0x622920: r3 = false
    //     0x622920: add             x3, NULL, #0x30  ; false
    // 0x622924: r0 = setBool()
    //     0x622924: bl              #0x45282c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setBool
    // 0x622928: r0 = LoadStaticField(0xf20)
    //     0x622928: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x62292c: ldr             x0, [x0, #0x1e40]
    // 0x622930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x622934: cmp             w0, w16
    // 0x622938: b.ne            #0x622948
    // 0x62293c: r2 = menuPopupStateGroup
    //     0x62293c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeba8] Field <::.menuPopupStateGroup>: static late (offset: 0xf20)
    //     0x622940: ldr             x2, [x2, #0xba8]
    // 0x622944: r0 = InitLateStaticField()
    //     0x622944: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x622948: mov             x1, x0
    // 0x62294c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x62294c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x622950: r0 = notifyAll()
    //     0x622950: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x622954: r0 = Null
    //     0x622954: mov             x0, NULL
    // 0x622958: r0 = ReturnAsyncNotFuture()
    //     0x622958: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x62295c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62295c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622960: b               #0x6228f8
    // 0x622964: r9 = prefs
    //     0x622964: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x622968: ldr             x9, [x9, #0xc00]
    // 0x62296c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x62296c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x622970, size: 0x78
    // 0x622970: EnterFrame
    //     0x622970: stp             fp, lr, [SP, #-0x10]!
    //     0x622974: mov             fp, SP
    // 0x622978: AllocStack(0x10)
    //     0x622978: sub             SP, SP, #0x10
    // 0x62297c: SetupParameters(CoreData this /* r1 */)
    //     0x62297c: stur            NULL, [fp, #-8]
    //     0x622980: movz            x0, #0
    //     0x622984: add             x1, fp, w0, sxtw #2
    //     0x622988: ldr             x1, [x1, #0x18]
    //     0x62298c: ldur            w2, [x1, #0x17]
    //     0x622990: add             x2, x2, HEAP, lsl #32
    //     0x622994: stur            x2, [fp, #-0x10]
    // 0x622998: CheckStackOverflow
    //     0x622998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x62299c: cmp             SP, x16
    //     0x6229a0: b.ls            #0x6229e0
    // 0x6229a4: InitAsync() -> Future<void?>
    //     0x6229a4: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x6229a8: bl              #0x34b9a0  ; InitAsyncStub
    // 0x6229ac: r0 = LoadStaticField(0xf20)
    //     0x6229ac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6229b0: ldr             x0, [x0, #0x1e40]
    // 0x6229b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6229b8: cmp             w0, w16
    // 0x6229bc: b.ne            #0x6229cc
    // 0x6229c0: r2 = menuPopupStateGroup
    //     0x6229c0: add             x2, PP, #0xe, lsl #12  ; [pp+0xeba8] Field <::.menuPopupStateGroup>: static late (offset: 0xf20)
    //     0x6229c4: ldr             x2, [x2, #0xba8]
    // 0x6229c8: r0 = InitLateStaticField()
    //     0x6229c8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x6229cc: mov             x1, x0
    // 0x6229d0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6229d0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6229d4: r0 = notifyAll()
    //     0x6229d4: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x6229d8: r0 = Null
    //     0x6229d8: mov             x0, NULL
    // 0x6229dc: r0 = ReturnAsyncNotFuture()
    //     0x6229dc: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x6229e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6229e0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6229e4: b               #0x6229a4
  }
  _ clearAllDataAndSave(/* No info */) async {
    // ** addr: 0x633e28, size: 0x94
    // 0x633e28: EnterFrame
    //     0x633e28: stp             fp, lr, [SP, #-0x10]!
    //     0x633e2c: mov             fp, SP
    // 0x633e30: AllocStack(0x18)
    //     0x633e30: sub             SP, SP, #0x18
    // 0x633e34: SetupParameters(CoreData this /* r1 => r1, fp-0x10 */)
    //     0x633e34: stur            NULL, [fp, #-8]
    //     0x633e38: stur            x1, [fp, #-0x10]
    // 0x633e3c: CheckStackOverflow
    //     0x633e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x633e40: cmp             SP, x16
    //     0x633e44: b.ls            #0x633eb4
    // 0x633e48: InitAsync() -> Future<void?>
    //     0x633e48: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x633e4c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x633e50: ldur            x0, [fp, #-0x10]
    // 0x633e54: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x633e54: ldur            w3, [x0, #0x17]
    // 0x633e58: DecompressPointer r3
    //     0x633e58: add             x3, x3, HEAP, lsl #32
    // 0x633e5c: stur            x3, [fp, #-0x18]
    // 0x633e60: r1 = Function '<anonymous closure>':.
    //     0x633e60: add             x1, PP, #0x33, lsl #12  ; [pp+0x338c0] AnonymousClosure: (0x633ebc), in [package:pretentious/data/CoreData.dart] CoreData::clearAllDataAndSave (0x633e28)
    //     0x633e64: ldr             x1, [x1, #0x8c0]
    // 0x633e68: r2 = Null
    //     0x633e68: mov             x2, NULL
    // 0x633e6c: r0 = AllocateClosure()
    //     0x633e6c: bl              #0x826750  ; AllocateClosureStub
    // 0x633e70: ldur            x1, [fp, #-0x18]
    // 0x633e74: mov             x2, x0
    // 0x633e78: r0 = removeWhere()
    //     0x633e78: bl              #0x427f40  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::removeWhere
    // 0x633e7c: ldur            x0, [fp, #-0x10]
    // 0x633e80: LoadField: r1 = r0->field_13
    //     0x633e80: ldur            w1, [x0, #0x13]
    // 0x633e84: DecompressPointer r1
    //     0x633e84: add             x1, x1, HEAP, lsl #32
    // 0x633e88: r0 = clear()
    //     0x633e88: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x633e8c: ldur            x0, [fp, #-0x10]
    // 0x633e90: LoadField: r1 = r0->field_27
    //     0x633e90: ldur            w1, [x0, #0x27]
    // 0x633e94: DecompressPointer r1
    //     0x633e94: add             x1, x1, HEAP, lsl #32
    // 0x633e98: r0 = clear()
    //     0x633e98: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x633e9c: ldur            x0, [fp, #-0x10]
    // 0x633ea0: LoadField: r1 = r0->field_23
    //     0x633ea0: ldur            w1, [x0, #0x23]
    // 0x633ea4: DecompressPointer r1
    //     0x633ea4: add             x1, x1, HEAP, lsl #32
    // 0x633ea8: r0 = clear()
    //     0x633ea8: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x633eac: r0 = saveCoreData()
    //     0x633eac: bl              #0x452554  ; [package:pretentious/data/CoreData.dart] ::saveCoreData
    // 0x633eb0: r0 = ReturnAsync()
    //     0x633eb0: b               #0x353380  ; ReturnAsyncStub
    // 0x633eb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x633eb4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633eb8: b               #0x633e48
  }
  [closure] bool <anonymous closure>(dynamic, String, double) {
    // ** addr: 0x633ebc, size: 0x5c
    // 0x633ebc: EnterFrame
    //     0x633ebc: stp             fp, lr, [SP, #-0x10]!
    //     0x633ec0: mov             fp, SP
    // 0x633ec4: AllocStack(0x10)
    //     0x633ec4: sub             SP, SP, #0x10
    // 0x633ec8: CheckStackOverflow
    //     0x633ec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x633ecc: cmp             SP, x16
    //     0x633ed0: b.ls            #0x633f10
    // 0x633ed4: ldr             x0, [fp, #0x18]
    // 0x633ed8: r1 = LoadClassIdInstr(r0)
    //     0x633ed8: ldur            x1, [x0, #-1]
    //     0x633edc: ubfx            x1, x1, #0xc, #0x14
    // 0x633ee0: r16 = "Bonus"
    //     0x633ee0: add             x16, PP, #0xe, lsl #12  ; [pp+0xea68] "Bonus"
    //     0x633ee4: ldr             x16, [x16, #0xa68]
    // 0x633ee8: stp             x16, x0, [SP]
    // 0x633eec: mov             x0, x1
    // 0x633ef0: mov             lr, x0
    // 0x633ef4: ldr             lr, [x21, lr, lsl #3]
    // 0x633ef8: blr             lr
    // 0x633efc: eor             x1, x0, #0x10
    // 0x633f00: mov             x0, x1
    // 0x633f04: LeaveFrame
    //     0x633f04: mov             SP, fp
    //     0x633f08: ldp             fp, lr, [SP], #0x10
    // 0x633f0c: ret
    //     0x633f0c: ret             
    // 0x633f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x633f10: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633f14: b               #0x633ed4
  }
  _ addCompletionToken(/* No info */) async {
    // ** addr: 0x694e6c, size: 0x708
    // 0x694e6c: EnterFrame
    //     0x694e6c: stp             fp, lr, [SP, #-0x10]!
    //     0x694e70: mov             fp, SP
    // 0x694e74: AllocStack(0x60)
    //     0x694e74: sub             SP, SP, #0x60
    // 0x694e78: SetupParameters(CoreData this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */)
    //     0x694e78: stur            NULL, [fp, #-8]
    //     0x694e7c: stur            x1, [fp, #-0x10]
    //     0x694e80: stur            x2, [fp, #-0x18]
    //     0x694e84: stur            x3, [fp, #-0x20]
    //     0x694e88: stur            x5, [fp, #-0x28]
    // 0x694e8c: CheckStackOverflow
    //     0x694e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694e90: cmp             SP, x16
    //     0x694e94: b.ls            #0x695538
    // 0x694e98: InitAsync() -> Future<void?>
    //     0x694e98: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x694e9c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x694ea0: r0 = LoadStaticField(0xa78)
    //     0x694ea0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x694ea4: ldr             x0, [x0, #0x14f0]
    // 0x694ea8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x694eac: cmp             w0, w16
    // 0x694eb0: b.ne            #0x694ebc
    // 0x694eb4: r2 = firebaseEnabled
    //     0x694eb4: ldr             x2, [PP, #0x3268]  ; [pp+0x3268] Field <::.firebaseEnabled>: static late (offset: 0xa78)
    // 0x694eb8: r0 = InitLateStaticField()
    //     0x694eb8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x694ebc: ldur            x0, [fp, #-0x20]
    // 0x694ec0: cmp             w0, NULL
    // 0x694ec4: b.eq            #0x694ee0
    // 0x694ec8: ldur            x3, [fp, #-0x10]
    // 0x694ecc: LoadField: r1 = r3->field_b
    //     0x694ecc: ldur            w1, [x3, #0xb]
    // 0x694ed0: DecompressPointer r1
    //     0x694ed0: add             x1, x1, HEAP, lsl #32
    // 0x694ed4: ldur            x2, [fp, #-0x18]
    // 0x694ed8: r0 = contains()
    //     0x694ed8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x694edc: b               #0x694ee4
    // 0x694ee0: r0 = false
    //     0x694ee0: add             x0, NULL, #0x30  ; false
    // 0x694ee4: stur            x0, [fp, #-0x30]
    // 0x694ee8: tbnz            w0, #4, #0x694f78
    // 0x694eec: ldur            x3, [fp, #-0x10]
    // 0x694ef0: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x694ef0: ldur            w1, [x3, #0x17]
    // 0x694ef4: DecompressPointer r1
    //     0x694ef4: add             x1, x1, HEAP, lsl #32
    // 0x694ef8: ldur            x2, [fp, #-0x18]
    // 0x694efc: r0 = containsKey()
    //     0x694efc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x694f00: tbnz            w0, #4, #0x694f78
    // 0x694f04: ldur            x3, [fp, #-0x18]
    // 0x694f08: ldur            x0, [fp, #-0x20]
    // 0x694f0c: r1 = Null
    //     0x694f0c: mov             x1, NULL
    // 0x694f10: r2 = 4
    //     0x694f10: movz            x2, #0x4
    // 0x694f14: r0 = AllocateArray()
    //     0x694f14: bl              #0x82746c  ; AllocateArrayStub
    // 0x694f18: r16 = "initial_completion_"
    //     0x694f18: add             x16, PP, #0x26, lsl #12  ; [pp+0x26360] "initial_completion_"
    //     0x694f1c: ldr             x16, [x16, #0x360]
    // 0x694f20: StoreField: r0->field_f = r16
    //     0x694f20: stur            w16, [x0, #0xf]
    // 0x694f24: ldur            x2, [fp, #-0x18]
    // 0x694f28: StoreField: r0->field_13 = r2
    //     0x694f28: stur            w2, [x0, #0x13]
    // 0x694f2c: str             x0, [SP]
    // 0x694f30: r0 = _interpolate()
    //     0x694f30: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x694f34: r1 = Null
    //     0x694f34: mov             x1, NULL
    // 0x694f38: r2 = 4
    //     0x694f38: movz            x2, #0x4
    // 0x694f3c: stur            x0, [fp, #-0x38]
    // 0x694f40: r0 = AllocateArray()
    //     0x694f40: bl              #0x82746c  ; AllocateArrayStub
    // 0x694f44: r16 = "milliseconds"
    //     0x694f44: add             x16, PP, #0x26, lsl #12  ; [pp+0x26368] "milliseconds"
    //     0x694f48: ldr             x16, [x16, #0x368]
    // 0x694f4c: StoreField: r0->field_f = r16
    //     0x694f4c: stur            w16, [x0, #0xf]
    // 0x694f50: ldur            x1, [fp, #-0x20]
    // 0x694f54: StoreField: r0->field_13 = r1
    //     0x694f54: stur            w1, [x0, #0x13]
    // 0x694f58: r16 = <String, int>
    //     0x694f58: ldr             x16, [PP, #0x24a0]  ; [pp+0x24a0] TypeArguments: <String, int>
    // 0x694f5c: stp             x0, x16, [SP]
    // 0x694f60: r0 = Map._fromLiteral()
    //     0x694f60: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x694f64: str             x0, [SP]
    // 0x694f68: ldur            x1, [fp, #-0x38]
    // 0x694f6c: r4 = const [0, 0x2, 0x1, 0x1, parameters, 0x1, null]
    //     0x694f6c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26370] List(7) [0, 0x2, 0x1, 0x1, "parameters", 0x1, Null]
    //     0x694f70: ldr             x4, [x4, #0x370]
    // 0x694f74: r0 = analyticsLogEvent()
    //     0x694f74: bl              #0x486210  ; [package:custom_tools/BasicFunctions.dart] ::analyticsLogEvent
    // 0x694f78: ldur            x0, [fp, #-0x10]
    // 0x694f7c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x694f7c: ldur            w3, [x0, #0x17]
    // 0x694f80: DecompressPointer r3
    //     0x694f80: add             x3, x3, HEAP, lsl #32
    // 0x694f84: mov             x1, x3
    // 0x694f88: ldur            x2, [fp, #-0x18]
    // 0x694f8c: stur            x3, [fp, #-0x38]
    // 0x694f90: r0 = containsKey()
    //     0x694f90: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x694f94: tbnz            w0, #4, #0x69516c
    // 0x694f98: ldur            x0, [fp, #-0x38]
    // 0x694f9c: mov             x1, x0
    // 0x694fa0: ldur            x2, [fp, #-0x18]
    // 0x694fa4: r0 = _getValueOrData()
    //     0x694fa4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x694fa8: ldur            x2, [fp, #-0x38]
    // 0x694fac: LoadField: r1 = r2->field_f
    //     0x694fac: ldur            w1, [x2, #0xf]
    // 0x694fb0: DecompressPointer r1
    //     0x694fb0: add             x1, x1, HEAP, lsl #32
    // 0x694fb4: cmp             w1, w0
    // 0x694fb8: b.ne            #0x694fc4
    // 0x694fbc: r4 = Null
    //     0x694fbc: mov             x4, NULL
    // 0x694fc0: b               #0x694fc8
    // 0x694fc4: mov             x4, x0
    // 0x694fc8: ldur            x3, [fp, #-0x28]
    // 0x694fcc: d1 = 1.000000
    //     0x694fcc: fmov            d1, #1.00000000
    // 0x694fd0: d0 = 0.100000
    //     0x694fd0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x694fd4: ldr             d0, [x17, #0xc30]
    // 0x694fd8: stur            x4, [fp, #-0x40]
    // 0x694fdc: cmp             w4, NULL
    // 0x694fe0: b.eq            #0x695540
    // 0x694fe4: scvtf           d2, x3
    // 0x694fe8: fmul            d3, d2, d0
    // 0x694fec: fadd            d0, d3, d1
    // 0x694ff0: stur            d0, [fp, #-0x50]
    // 0x694ff4: r0 = BoxInt64Instr(r3)
    //     0x694ff4: sbfiz           x0, x3, #1, #0x1f
    //     0x694ff8: cmp             x3, x0, asr #1
    //     0x694ffc: b.eq            #0x695008
    //     0x695000: bl              #0x8277b0  ; AllocateMintSharedWithFPURegsStub
    //     0x695004: stur            x3, [x0, #7]
    // 0x695008: r1 = 60
    //     0x695008: movz            x1, #0x3c
    // 0x69500c: branchIfSmi(r0, 0x695018)
    //     0x69500c: tbz             w0, #0, #0x695018
    // 0x695010: r1 = LoadClassIdInstr(r0)
    //     0x695010: ldur            x1, [x0, #-1]
    //     0x695014: ubfx            x1, x1, #0xc, #0x14
    // 0x695018: str             x0, [SP]
    // 0x69501c: mov             x0, x1
    // 0x695020: r0 = GDT[cid_x0 + -0x1000]()
    //     0x695020: sub             lr, x0, #1, lsl #12
    //     0x695024: ldr             lr, [x21, lr, lsl #3]
    //     0x695028: blr             lr
    // 0x69502c: LoadField: d0 = r0->field_7
    //     0x69502c: ldur            d0, [x0, #7]
    // 0x695030: d1 = 1.500000
    //     0x695030: fmov            d1, #1.50000000
    // 0x695034: d30 = 0.000000
    //     0x695034: fmov            d30, d0
    // 0x695038: d0 = 1.000000
    //     0x695038: fmov            d0, #1.00000000
    // 0x69503c: fcmp            d1, #0.0
    // 0x695040: b.vs            #0x695084
    // 0x695044: b.eq            #0x69510c
    // 0x695048: fcmp            d1, d0
    // 0x69504c: b.eq            #0x695074
    // 0x695050: d31 = 2.000000
    //     0x695050: fmov            d31, #2.00000000
    // 0x695054: fcmp            d1, d31
    // 0x695058: b.eq            #0x69507c
    // 0x69505c: d31 = 3.000000
    //     0x69505c: fmov            d31, #3.00000000
    // 0x695060: fcmp            d1, d31
    // 0x695064: b.ne            #0x695084
    // 0x695068: fmul            d0, d30, d30
    // 0x69506c: fmul            d0, d0, d30
    // 0x695070: b               #0x69510c
    // 0x695074: d0 = 0.000000
    //     0x695074: fmov            d0, d30
    // 0x695078: b               #0x69510c
    // 0x69507c: fmul            d0, d30, d30
    // 0x695080: b               #0x69510c
    // 0x695084: fcmp            d30, d0
    // 0x695088: b.vs            #0x695098
    // 0x69508c: b.eq            #0x69510c
    // 0x695090: fcmp            d30, d1
    // 0x695094: b.vc            #0x6950a4
    // 0x695098: d0 = nan
    //     0x695098: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x69509c: ldr             d0, [x17, #0xe48]
    // 0x6950a0: b               #0x69510c
    // 0x6950a4: d0 = -inf
    //     0x6950a4: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x6950a8: fcmp            d30, d0
    // 0x6950ac: b.eq            #0x6950d4
    // 0x6950b0: d0 = 0.500000
    //     0x6950b0: fmov            d0, #0.50000000
    // 0x6950b4: fcmp            d1, d0
    // 0x6950b8: b.ne            #0x6950d4
    // 0x6950bc: fcmp            d30, #0.0
    // 0x6950c0: b.eq            #0x6950cc
    // 0x6950c4: fsqrt           d0, d30
    // 0x6950c8: b               #0x69510c
    // 0x6950cc: d0 = 0.000000
    //     0x6950cc: eor             v0.16b, v0.16b, v0.16b
    // 0x6950d0: b               #0x69510c
    // 0x6950d4: d0 = 0.000000
    //     0x6950d4: fmov            d0, d30
    // 0x6950d8: stp             fp, lr, [SP, #-0x10]!
    // 0x6950dc: mov             fp, SP
    // 0x6950e0: CallRuntime_LibcPow(double, double) -> double
    //     0x6950e0: and             SP, SP, #0xfffffffffffffff0
    //     0x6950e4: mov             sp, SP
    //     0x6950e8: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x6950ec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6950f0: blr             x16
    //     0x6950f4: movz            x16, #0x8
    //     0x6950f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6950fc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x695100: sub             sp, x16, #1, lsl #12
    //     0x695104: mov             SP, fp
    //     0x695108: ldp             fp, lr, [SP], #0x10
    // 0x69510c: mov             v1.16b, v0.16b
    // 0x695110: d0 = 0.012000
    //     0x695110: add             x17, PP, #0x26, lsl #12  ; [pp+0x26378] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0x695114: ldr             d0, [x17, #0x378]
    // 0x695118: fmul            d2, d1, d0
    // 0x69511c: ldur            d0, [fp, #-0x50]
    // 0x695120: fadd            d1, d0, d2
    // 0x695124: ldur            x0, [fp, #-0x40]
    // 0x695128: LoadField: d0 = r0->field_7
    //     0x695128: ldur            d0, [x0, #7]
    // 0x69512c: fadd            d2, d0, d1
    // 0x695130: r3 = inline_Allocate_Double()
    //     0x695130: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x695134: add             x3, x3, #0x10
    //     0x695138: cmp             x0, x3
    //     0x69513c: b.ls            #0x695544
    //     0x695140: str             x3, [THR, #0x60]  ; THR::top
    //     0x695144: sub             x3, x3, #0xf
    //     0x695148: movz            x0, #0xe19c
    //     0x69514c: movk            x0, #0x3, lsl #16
    //     0x695150: stur            x0, [x3, #-1]
    // 0x695154: dmb             ishst
    // 0x695158: StoreField: r3->field_7 = d2
    //     0x695158: stur            d2, [x3, #7]
    // 0x69515c: ldur            x1, [fp, #-0x38]
    // 0x695160: ldur            x2, [fp, #-0x18]
    // 0x695164: r0 = []=()
    //     0x695164: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x695168: b               #0x69517c
    // 0x69516c: ldur            x1, [fp, #-0x38]
    // 0x695170: ldur            x2, [fp, #-0x18]
    // 0x695174: r3 = 1.000000
    //     0x695174: ldr             x3, [PP, #0x6990]  ; [pp+0x6990] 1
    // 0x695178: r0 = []=()
    //     0x695178: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x69517c: r1 = Function 'getAndroidAchievementId':.
    //     0x69517c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26380] AnonymousClosure: (0x696018), in [package:pretentious/data/CoreData.dart] CoreData::addCompletionToken (0x694e6c)
    //     0x695180: ldr             x1, [x1, #0x380]
    // 0x695184: r2 = Null
    //     0x695184: mov             x2, NULL
    // 0x695188: r0 = AllocateClosure()
    //     0x695188: bl              #0x826750  ; AllocateClosureStub
    // 0x69518c: r1 = Function 'getAndroidLeaderboardId':.
    //     0x69518c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26388] AnonymousClosure: (0x695dd8), in [package:pretentious/data/CoreData.dart] CoreData::addCompletionToken (0x694e6c)
    //     0x695190: ldr             x1, [x1, #0x388]
    // 0x695194: r2 = Null
    //     0x695194: mov             x2, NULL
    // 0x695198: stur            x0, [fp, #-0x40]
    // 0x69519c: r0 = AllocateClosure()
    //     0x69519c: bl              #0x826750  ; AllocateClosureStub
    // 0x6951a0: ldur            x1, [fp, #-0x38]
    // 0x6951a4: ldur            x2, [fp, #-0x18]
    // 0x6951a8: stur            x0, [fp, #-0x48]
    // 0x6951ac: r0 = containsKey()
    //     0x6951ac: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6951b0: tbnz            w0, #4, #0x695364
    // 0x6951b4: ldur            x16, [fp, #-0x48]
    // 0x6951b8: ldur            lr, [fp, #-0x18]
    // 0x6951bc: stp             lr, x16, [SP]
    // 0x6951c0: ldur            x0, [fp, #-0x48]
    // 0x6951c4: ClosureCall
    //     0x6951c4: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6951c8: ldur            x2, [x0, #0x1f]
    //     0x6951cc: blr             x2
    // 0x6951d0: mov             x1, x0
    // 0x6951d4: stur            x1, [fp, #-0x48]
    // 0x6951d8: ldur            x16, [fp, #-0x40]
    // 0x6951dc: ldur            lr, [fp, #-0x18]
    // 0x6951e0: stp             lr, x16, [SP]
    // 0x6951e4: ldur            x0, [fp, #-0x40]
    // 0x6951e8: ClosureCall
    //     0x6951e8: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6951ec: ldur            x2, [x0, #0x1f]
    //     0x6951f0: blr             x2
    // 0x6951f4: stur            x0, [fp, #-0x40]
    // 0x6951f8: cmp             w0, NULL
    // 0x6951fc: b.eq            #0x695260
    // 0x695200: ldur            x3, [fp, #-0x18]
    // 0x695204: r1 = Null
    //     0x695204: mov             x1, NULL
    // 0x695208: r2 = 6
    //     0x695208: movz            x2, #0x6
    // 0x69520c: r0 = AllocateArray()
    //     0x69520c: bl              #0x82746c  ; AllocateArrayStub
    // 0x695210: r16 = "ch"
    //     0x695210: add             x16, PP, #0x26, lsl #12  ; [pp+0x26390] "ch"
    //     0x695214: ldr             x16, [x16, #0x390]
    // 0x695218: StoreField: r0->field_f = r16
    //     0x695218: stur            w16, [x0, #0xf]
    // 0x69521c: ldur            x2, [fp, #-0x18]
    // 0x695220: StoreField: r0->field_13 = r2
    //     0x695220: stur            w2, [x0, #0x13]
    // 0x695224: r16 = "_complete"
    //     0x695224: add             x16, PP, #0x26, lsl #12  ; [pp+0x26398] "_complete"
    //     0x695228: ldr             x16, [x16, #0x398]
    // 0x69522c: ArrayStore: r0[0] = r16  ; List_4
    //     0x69522c: stur            w16, [x0, #0x17]
    // 0x695230: str             x0, [SP]
    // 0x695234: r0 = _interpolate()
    //     0x695234: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x695238: r0 = Achievement()
    //     0x695238: bl              #0x695dcc  ; AllocateAchievementStub -> Achievement (size=0x18)
    // 0x69523c: mov             x1, x0
    // 0x695240: ldur            x0, [fp, #-0x40]
    // 0x695244: StoreField: r1->field_7 = r0
    //     0x695244: stur            w0, [x1, #7]
    // 0x695248: r0 = true
    //     0x695248: add             x0, NULL, #0x20  ; true
    // 0x69524c: StoreField: r1->field_b = r0
    //     0x69524c: stur            w0, [x1, #0xb]
    // 0x695250: d0 = 100.000000
    //     0x695250: add             x17, PP, #0xb, lsl #12  ; [pp+0xbe38] IMM: double(100) from 0x4059000000000000
    //     0x695254: ldr             d0, [x17, #0xe38]
    // 0x695258: StoreField: r1->field_f = d0
    //     0x695258: stur            d0, [x1, #0xf]
    // 0x69525c: r0 = unlock()
    //     0x69525c: bl              #0x695c34  ; [package:games_services/src/achievements.dart] Achievements::unlock
    // 0x695260: ldur            x0, [fp, #-0x48]
    // 0x695264: cmp             w0, NULL
    // 0x695268: b.eq            #0x695364
    // 0x69526c: ldur            x3, [fp, #-0x18]
    // 0x695270: ldur            x4, [fp, #-0x38]
    // 0x695274: r1 = Null
    //     0x695274: mov             x1, NULL
    // 0x695278: r2 = 6
    //     0x695278: movz            x2, #0x6
    // 0x69527c: r0 = AllocateArray()
    //     0x69527c: bl              #0x82746c  ; AllocateArrayStub
    // 0x695280: r16 = "ch"
    //     0x695280: add             x16, PP, #0x26, lsl #12  ; [pp+0x26390] "ch"
    //     0x695284: ldr             x16, [x16, #0x390]
    // 0x695288: StoreField: r0->field_f = r16
    //     0x695288: stur            w16, [x0, #0xf]
    // 0x69528c: ldur            x2, [fp, #-0x18]
    // 0x695290: StoreField: r0->field_13 = r2
    //     0x695290: stur            w2, [x0, #0x13]
    // 0x695294: r16 = "_tokens"
    //     0x695294: add             x16, PP, #0x26, lsl #12  ; [pp+0x263a0] "_tokens"
    //     0x695298: ldr             x16, [x16, #0x3a0]
    // 0x69529c: ArrayStore: r0[0] = r16  ; List_4
    //     0x69529c: stur            w16, [x0, #0x17]
    // 0x6952a0: str             x0, [SP]
    // 0x6952a4: r0 = _interpolate()
    //     0x6952a4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6952a8: ldur            x1, [fp, #-0x38]
    // 0x6952ac: ldur            x2, [fp, #-0x18]
    // 0x6952b0: r0 = _getValueOrData()
    //     0x6952b0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6952b4: mov             x1, x0
    // 0x6952b8: ldur            x0, [fp, #-0x38]
    // 0x6952bc: LoadField: r2 = r0->field_f
    //     0x6952bc: ldur            w2, [x0, #0xf]
    // 0x6952c0: DecompressPointer r2
    //     0x6952c0: add             x2, x2, HEAP, lsl #32
    // 0x6952c4: cmp             w2, w1
    // 0x6952c8: b.ne            #0x6952d4
    // 0x6952cc: r0 = Null
    //     0x6952cc: mov             x0, NULL
    // 0x6952d0: b               #0x6952d8
    // 0x6952d4: mov             x0, x1
    // 0x6952d8: cmp             w0, NULL
    // 0x6952dc: b.ne            #0x6952e8
    // 0x6952e0: r1 = Null
    //     0x6952e0: mov             x1, NULL
    // 0x6952e4: b               #0x695340
    // 0x6952e8: LoadField: d0 = r0->field_7
    //     0x6952e8: ldur            d0, [x0, #7]
    // 0x6952ec: stp             fp, lr, [SP, #-0x10]!
    // 0x6952f0: mov             fp, SP
    // 0x6952f4: CallRuntime_LibcRound(double) -> double
    //     0x6952f4: and             SP, SP, #0xfffffffffffffff0
    //     0x6952f8: mov             sp, SP
    //     0x6952fc: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x695300: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x695304: blr             x16
    //     0x695308: movz            x16, #0x8
    //     0x69530c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x695310: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x695314: sub             sp, x16, #1, lsl #12
    //     0x695318: mov             SP, fp
    //     0x69531c: ldp             fp, lr, [SP], #0x10
    // 0x695320: fcmp            d0, d0
    // 0x695324: b.vs            #0x695558
    // 0x695328: fcvtzs          x0, d0
    // 0x69532c: asr             x16, x0, #0x1e
    // 0x695330: cmp             x16, x0, asr #63
    // 0x695334: b.ne            #0x695558
    // 0x695338: lsl             x0, x0, #1
    // 0x69533c: mov             x1, x0
    // 0x695340: ldur            x0, [fp, #-0x48]
    // 0x695344: stur            x1, [fp, #-0x38]
    // 0x695348: r0 = Score()
    //     0x695348: bl              #0x695c28  ; AllocateScoreStub -> Score (size=0x14)
    // 0x69534c: mov             x1, x0
    // 0x695350: ldur            x0, [fp, #-0x48]
    // 0x695354: StoreField: r1->field_7 = r0
    //     0x695354: stur            w0, [x1, #7]
    // 0x695358: ldur            x0, [fp, #-0x38]
    // 0x69535c: StoreField: r1->field_b = r0
    //     0x69535c: stur            w0, [x1, #0xb]
    // 0x695360: r0 = submitScore()
    //     0x695360: bl              #0x695ad8  ; [package:games_services/src/leaderboards.dart] Leaderboards::submitScore
    // 0x695364: r0 = currentActiveState()
    //     0x695364: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x695368: r1 = LoadClassIdInstr(r0)
    //     0x695368: ldur            x1, [x0, #-1]
    //     0x69536c: ubfx            x1, x1, #0xc, #0x14
    // 0x695370: cmp             x1, #0x10c
    // 0x695374: b.ne            #0x6953b8
    // 0x695378: r0 = currentActiveState()
    //     0x695378: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x69537c: mov             x3, x0
    // 0x695380: r2 = Null
    //     0x695380: mov             x2, NULL
    // 0x695384: r1 = Null
    //     0x695384: mov             x1, NULL
    // 0x695388: stur            x3, [fp, #-0x38]
    // 0x69538c: r4 = LoadClassIdInstr(r0)
    //     0x69538c: ldur            x4, [x0, #-1]
    //     0x695390: ubfx            x4, x4, #0xc, #0x14
    // 0x695394: cmp             x4, #0x10c
    // 0x695398: b.eq            #0x6953b0
    // 0x69539c: r8 = CustomLevelGameState
    //     0x69539c: add             x8, PP, #0x1f, lsl #12  ; [pp+0x1f268] Type: CustomLevelGameState
    //     0x6953a0: ldr             x8, [x8, #0x268]
    // 0x6953a4: r3 = Null
    //     0x6953a4: add             x3, PP, #0x26, lsl #12  ; [pp+0x263a8] Null
    //     0x6953a8: ldr             x3, [x3, #0x3a8]
    // 0x6953ac: r0 = CustomLevelGameState()
    //     0x6953ac: bl              #0x372fbc  ; IsType_CustomLevelGameState_Stub
    // 0x6953b0: ldur            x0, [fp, #-0x38]
    // 0x6953b4: b               #0x6953bc
    // 0x6953b8: r0 = Null
    //     0x6953b8: mov             x0, NULL
    // 0x6953bc: cmp             w0, NULL
    // 0x6953c0: b.eq            #0x695488
    // 0x6953c4: LoadField: r1 = r0->field_8b
    //     0x6953c4: ldur            w1, [x0, #0x8b]
    // 0x6953c8: DecompressPointer r1
    //     0x6953c8: add             x1, x1, HEAP, lsl #32
    // 0x6953cc: LoadField: r0 = r1->field_37
    //     0x6953cc: ldur            w0, [x1, #0x37]
    // 0x6953d0: DecompressPointer r0
    //     0x6953d0: add             x0, x0, HEAP, lsl #32
    // 0x6953d4: LoadField: r1 = r0->field_13
    //     0x6953d4: ldur            w1, [x0, #0x13]
    // 0x6953d8: DecompressPointer r1
    //     0x6953d8: add             x1, x1, HEAP, lsl #32
    // 0x6953dc: stur            x1, [fp, #-0x38]
    // 0x6953e0: cmp             w1, NULL
    // 0x6953e4: b.eq            #0x695488
    // 0x6953e8: r4 = const [0, 0, 0, 0, null]
    //     0x6953e8: ldr             x4, [PP, #0x2958]  ; [pp+0x2958] List(5) [0, 0, 0, 0, Null]
    // 0x6953ec: r0 = app()
    //     0x6953ec: bl              #0x3548dc  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x6953f0: mov             x2, x0
    // 0x6953f4: r1 = Null
    //     0x6953f4: mov             x1, NULL
    // 0x6953f8: r0 = FirebaseAuth.instanceFor()
    //     0x6953f8: bl              #0x572894  ; [package:firebase_auth/firebase_auth.dart] FirebaseAuth::FirebaseAuth.instanceFor
    // 0x6953fc: mov             x1, x0
    // 0x695400: r0 = currentUser()
    //     0x695400: bl              #0x56eb08  ; [package:firebase_auth/firebase_auth.dart] FirebaseAuth::currentUser
    // 0x695404: cmp             w0, NULL
    // 0x695408: b.ne            #0x695414
    // 0x69540c: r1 = Null
    //     0x69540c: mov             x1, NULL
    // 0x695410: b               #0x695438
    // 0x695414: LoadField: r1 = r0->field_7
    //     0x695414: ldur            w1, [x0, #7]
    // 0x695418: DecompressPointer r1
    //     0x695418: add             x1, x1, HEAP, lsl #32
    // 0x69541c: LoadField: r0 = r1->field_f
    //     0x69541c: ldur            w0, [x1, #0xf]
    // 0x695420: DecompressPointer r0
    //     0x695420: add             x0, x0, HEAP, lsl #32
    // 0x695424: LoadField: r1 = r0->field_7
    //     0x695424: ldur            w1, [x0, #7]
    // 0x695428: DecompressPointer r1
    //     0x695428: add             x1, x1, HEAP, lsl #32
    // 0x69542c: LoadField: r0 = r1->field_7
    //     0x69542c: ldur            w0, [x1, #7]
    // 0x695430: DecompressPointer r0
    //     0x695430: add             x0, x0, HEAP, lsl #32
    // 0x695434: mov             x1, x0
    // 0x695438: ldur            x0, [fp, #-0x38]
    // 0x69543c: r2 = LoadClassIdInstr(r0)
    //     0x69543c: ldur            x2, [x0, #-1]
    //     0x695440: ubfx            x2, x2, #0xc, #0x14
    // 0x695444: stp             x1, x0, [SP]
    // 0x695448: mov             x0, x2
    // 0x69544c: mov             lr, x0
    // 0x695450: ldr             lr, [x21, lr, lsl #3]
    // 0x695454: blr             lr
    // 0x695458: tbz             w0, #4, #0x695488
    // 0x69545c: r0 = Achievement()
    //     0x69545c: bl              #0x695dcc  ; AllocateAchievementStub -> Achievement (size=0x18)
    // 0x695460: mov             x1, x0
    // 0x695464: r0 = "CgkIxsjH8ssQEAIQCw"
    //     0x695464: add             x0, PP, #0x26, lsl #12  ; [pp+0x263b8] "CgkIxsjH8ssQEAIQCw"
    //     0x695468: ldr             x0, [x0, #0x3b8]
    // 0x69546c: StoreField: r1->field_7 = r0
    //     0x69546c: stur            w0, [x1, #7]
    // 0x695470: r0 = true
    //     0x695470: add             x0, NULL, #0x20  ; true
    // 0x695474: StoreField: r1->field_b = r0
    //     0x695474: stur            w0, [x1, #0xb]
    // 0x695478: d0 = 100.000000
    //     0x695478: add             x17, PP, #0xb, lsl #12  ; [pp+0xbe38] IMM: double(100) from 0x4059000000000000
    //     0x69547c: ldr             d0, [x17, #0xe38]
    // 0x695480: StoreField: r1->field_f = d0
    //     0x695480: stur            d0, [x1, #0xf]
    // 0x695484: r0 = unlock()
    //     0x695484: bl              #0x695c34  ; [package:games_services/src/achievements.dart] Achievements::unlock
    // 0x695488: ldur            x0, [fp, #-0x30]
    // 0x69548c: ldur            x1, [fp, #-0x10]
    // 0x695490: r0 = recomputeTokenBoost()
    //     0x695490: bl              #0x4802e8  ; [package:pretentious/data/CoreData.dart] CoreData::recomputeTokenBoost
    // 0x695494: r0 = saveCoreData()
    //     0x695494: bl              #0x452554  ; [package:pretentious/data/CoreData.dart] ::saveCoreData
    // 0x695498: mov             x1, x0
    // 0x69549c: stur            x1, [fp, #-0x38]
    // 0x6954a0: r0 = Await()
    //     0x6954a0: bl              #0x34b75c  ; AwaitStub
    // 0x6954a4: ldur            x0, [fp, #-0x30]
    // 0x6954a8: tbnz            w0, #4, #0x695530
    // 0x6954ac: ldur            x0, [fp, #-0x20]
    // 0x6954b0: ldur            x1, [fp, #-0x10]
    // 0x6954b4: r2 = Instance_CustomNum
    //     0x6954b4: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6954b8: ldr             x2, [x2, #0xa70]
    // 0x6954bc: r3 = Null
    //     0x6954bc: mov             x3, NULL
    // 0x6954c0: r0 = cachedCompletionTokenBoost()
    //     0x6954c0: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x6954c4: LoadField: d0 = r0->field_7
    //     0x6954c4: ldur            d0, [x0, #7]
    // 0x6954c8: stp             fp, lr, [SP, #-0x10]!
    // 0x6954cc: mov             fp, SP
    // 0x6954d0: CallRuntime_LibcExp(double) -> double
    //     0x6954d0: and             SP, SP, #0xfffffffffffffff0
    //     0x6954d4: mov             sp, SP
    //     0x6954d8: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x6954dc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6954e0: blr             x16
    //     0x6954e4: movz            x16, #0x8
    //     0x6954e8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6954ec: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x6954f0: sub             sp, x16, #1, lsl #12
    //     0x6954f4: mov             SP, fp
    //     0x6954f8: ldp             fp, lr, [SP], #0x10
    // 0x6954fc: ldur            x0, [fp, #-0x20]
    // 0x695500: r3 = LoadInt32Instr(r0)
    //     0x695500: sbfx            x3, x0, #1, #0x1f
    //     0x695504: tbz             w0, #0, #0x69550c
    //     0x695508: ldur            x3, [x0, #7]
    // 0x69550c: ldur            x1, [fp, #-0x10]
    // 0x695510: ldur            x2, [fp, #-0x18]
    // 0x695514: r0 = getCompletionTokensLog()
    //     0x695514: bl              #0x695574  ; [package:pretentious/data/CoreData.dart] CoreData::getCompletionTokensLog
    // 0x695518: str             x0, [SP]
    // 0x69551c: r1 = "complete_chapter"
    //     0x69551c: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c0] "complete_chapter"
    //     0x695520: ldr             x1, [x1, #0x3c0]
    // 0x695524: r4 = const [0, 0x2, 0x1, 0x1, parameters, 0x1, null]
    //     0x695524: add             x4, PP, #0x26, lsl #12  ; [pp+0x26370] List(7) [0, 0x2, 0x1, 0x1, "parameters", 0x1, Null]
    //     0x695528: ldr             x4, [x4, #0x370]
    // 0x69552c: r0 = analyticsLogEvent()
    //     0x69552c: bl              #0x486210  ; [package:custom_tools/BasicFunctions.dart] ::analyticsLogEvent
    // 0x695530: r0 = Null
    //     0x695530: mov             x0, NULL
    // 0x695534: r0 = ReturnAsyncNotFuture()
    //     0x695534: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x695538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x695538: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69553c: b               #0x694e98
    // 0x695540: r0 = NullCastErrorSharedWithFPURegs()
    //     0x695540: bl              #0x827c54  ; NullCastErrorSharedWithFPURegsStub
    // 0x695544: SaveReg d2
    //     0x695544: str             q2, [SP, #-0x10]!
    // 0x695548: r0 = AllocateDouble()
    //     0x695548: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x69554c: mov             x3, x0
    // 0x695550: RestoreReg d2
    //     0x695550: ldr             q2, [SP], #0x10
    // 0x695554: b               #0x695158
    // 0x695558: SaveReg d0
    //     0x695558: str             q0, [SP, #-0x10]!
    // 0x69555c: r0 = 76
    //     0x69555c: movz            x0, #0x4c
    // 0x695560: r30 = DoubleToIntegerStub
    //     0x695560: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x695564: LoadField: r30 = r30->field_7
    //     0x695564: ldur            lr, [lr, #7]
    // 0x695568: blr             lr
    // 0x69556c: RestoreReg d0
    //     0x69556c: ldr             q0, [SP], #0x10
    // 0x695570: b               #0x69533c
  }
  _ getCompletionTokensLog(/* No info */) {
    // ** addr: 0x695574, size: 0x564
    // 0x695574: EnterFrame
    //     0x695574: stp             fp, lr, [SP, #-0x10]!
    //     0x695578: mov             fp, SP
    // 0x69557c: AllocStack(0x40)
    //     0x69557c: sub             SP, SP, #0x40
    // 0x695580: SetupParameters(CoreData this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x695580: mov             x4, x1
    //     0x695584: mov             x0, x2
    //     0x695588: stur            x1, [fp, #-8]
    //     0x69558c: stur            x2, [fp, #-0x10]
    //     0x695590: stur            x3, [fp, #-0x18]
    //     0x695594: stur            d0, [fp, #-0x30]
    // 0x695598: CheckStackOverflow
    //     0x695598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x69559c: cmp             SP, x16
    //     0x6955a0: b.ls            #0x695aa8
    // 0x6955a4: r1 = Null
    //     0x6955a4: mov             x1, NULL
    // 0x6955a8: r2 = 36
    //     0x6955a8: movz            x2, #0x24
    // 0x6955ac: r0 = AllocateArray()
    //     0x6955ac: bl              #0x82746c  ; AllocateArrayStub
    // 0x6955b0: stur            x0, [fp, #-0x20]
    // 0x6955b4: r16 = "current_chapter"
    //     0x6955b4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26488] "current_chapter"
    //     0x6955b8: ldr             x16, [x16, #0x488]
    // 0x6955bc: StoreField: r0->field_f = r16
    //     0x6955bc: stur            w16, [x0, #0xf]
    // 0x6955c0: ldur            x1, [fp, #-0x10]
    // 0x6955c4: StoreField: r0->field_13 = r1
    //     0x6955c4: stur            w1, [x0, #0x13]
    // 0x6955c8: r16 = "chapter_1_tokens"
    //     0x6955c8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26490] "chapter_1_tokens"
    //     0x6955cc: ldr             x16, [x16, #0x490]
    // 0x6955d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x6955d0: stur            w16, [x0, #0x17]
    // 0x6955d4: ldur            x1, [fp, #-8]
    // 0x6955d8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x6955d8: ldur            w3, [x1, #0x17]
    // 0x6955dc: DecompressPointer r3
    //     0x6955dc: add             x3, x3, HEAP, lsl #32
    // 0x6955e0: mov             x1, x3
    // 0x6955e4: stur            x3, [fp, #-0x10]
    // 0x6955e8: r2 = "1"
    //     0x6955e8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x6955ec: ldr             x2, [x2, #0x9c8]
    // 0x6955f0: r0 = _getValueOrData()
    //     0x6955f0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6955f4: ldur            x3, [fp, #-0x10]
    // 0x6955f8: LoadField: r1 = r3->field_f
    //     0x6955f8: ldur            w1, [x3, #0xf]
    // 0x6955fc: DecompressPointer r1
    //     0x6955fc: add             x1, x1, HEAP, lsl #32
    // 0x695600: cmp             w1, w0
    // 0x695604: b.ne            #0x69560c
    // 0x695608: r0 = Null
    //     0x695608: mov             x0, NULL
    // 0x69560c: cmp             w0, NULL
    // 0x695610: b.ne            #0x695618
    // 0x695614: r0 = 0
    //     0x695614: movz            x0, #0
    // 0x695618: ldur            x4, [fp, #-0x20]
    // 0x69561c: mov             x1, x4
    // 0x695620: ArrayStore: r1[3] = r0  ; List_4
    //     0x695620: add             x25, x1, #0x1b
    //     0x695624: str             w0, [x25]
    //     0x695628: tbz             w0, #0, #0x695644
    //     0x69562c: ldurb           w16, [x1, #-1]
    //     0x695630: ldurb           w17, [x0, #-1]
    //     0x695634: and             x16, x17, x16, lsr #2
    //     0x695638: tst             x16, HEAP, lsr #32
    //     0x69563c: b.eq            #0x695644
    //     0x695640: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x695644: r16 = "chapter_2_tokens"
    //     0x695644: add             x16, PP, #0x26, lsl #12  ; [pp+0x26498] "chapter_2_tokens"
    //     0x695648: ldr             x16, [x16, #0x498]
    // 0x69564c: StoreField: r4->field_1f = r16
    //     0x69564c: stur            w16, [x4, #0x1f]
    // 0x695650: mov             x1, x3
    // 0x695654: r2 = "2"
    //     0x695654: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x695658: ldr             x2, [x2, #0x2e0]
    // 0x69565c: r0 = _getValueOrData()
    //     0x69565c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x695660: ldur            x3, [fp, #-0x10]
    // 0x695664: LoadField: r1 = r3->field_f
    //     0x695664: ldur            w1, [x3, #0xf]
    // 0x695668: DecompressPointer r1
    //     0x695668: add             x1, x1, HEAP, lsl #32
    // 0x69566c: cmp             w1, w0
    // 0x695670: b.ne            #0x695678
    // 0x695674: r0 = Null
    //     0x695674: mov             x0, NULL
    // 0x695678: cmp             w0, NULL
    // 0x69567c: b.ne            #0x695684
    // 0x695680: r0 = 0
    //     0x695680: movz            x0, #0
    // 0x695684: ldur            x4, [fp, #-0x20]
    // 0x695688: mov             x1, x4
    // 0x69568c: ArrayStore: r1[5] = r0  ; List_4
    //     0x69568c: add             x25, x1, #0x23
    //     0x695690: str             w0, [x25]
    //     0x695694: tbz             w0, #0, #0x6956b0
    //     0x695698: ldurb           w16, [x1, #-1]
    //     0x69569c: ldurb           w17, [x0, #-1]
    //     0x6956a0: and             x16, x17, x16, lsr #2
    //     0x6956a4: tst             x16, HEAP, lsr #32
    //     0x6956a8: b.eq            #0x6956b0
    //     0x6956ac: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6956b0: r16 = "chapter_3_tokens"
    //     0x6956b0: add             x16, PP, #0x26, lsl #12  ; [pp+0x264a0] "chapter_3_tokens"
    //     0x6956b4: ldr             x16, [x16, #0x4a0]
    // 0x6956b8: StoreField: r4->field_27 = r16
    //     0x6956b8: stur            w16, [x4, #0x27]
    // 0x6956bc: mov             x1, x3
    // 0x6956c0: r2 = "3"
    //     0x6956c0: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x6956c4: ldr             x2, [x2, #0x2f0]
    // 0x6956c8: r0 = _getValueOrData()
    //     0x6956c8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6956cc: ldur            x3, [fp, #-0x10]
    // 0x6956d0: LoadField: r1 = r3->field_f
    //     0x6956d0: ldur            w1, [x3, #0xf]
    // 0x6956d4: DecompressPointer r1
    //     0x6956d4: add             x1, x1, HEAP, lsl #32
    // 0x6956d8: cmp             w1, w0
    // 0x6956dc: b.ne            #0x6956e4
    // 0x6956e0: r0 = Null
    //     0x6956e0: mov             x0, NULL
    // 0x6956e4: cmp             w0, NULL
    // 0x6956e8: b.ne            #0x6956f0
    // 0x6956ec: r0 = 0
    //     0x6956ec: movz            x0, #0
    // 0x6956f0: ldur            x4, [fp, #-0x20]
    // 0x6956f4: mov             x1, x4
    // 0x6956f8: ArrayStore: r1[7] = r0  ; List_4
    //     0x6956f8: add             x25, x1, #0x2b
    //     0x6956fc: str             w0, [x25]
    //     0x695700: tbz             w0, #0, #0x69571c
    //     0x695704: ldurb           w16, [x1, #-1]
    //     0x695708: ldurb           w17, [x0, #-1]
    //     0x69570c: and             x16, x17, x16, lsr #2
    //     0x695710: tst             x16, HEAP, lsr #32
    //     0x695714: b.eq            #0x69571c
    //     0x695718: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69571c: r16 = "chapter_4_tokens"
    //     0x69571c: add             x16, PP, #0x26, lsl #12  ; [pp+0x264a8] "chapter_4_tokens"
    //     0x695720: ldr             x16, [x16, #0x4a8]
    // 0x695724: StoreField: r4->field_2f = r16
    //     0x695724: stur            w16, [x4, #0x2f]
    // 0x695728: mov             x1, x3
    // 0x69572c: r2 = "4"
    //     0x69572c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x695730: ldr             x2, [x2, #0x2f8]
    // 0x695734: r0 = _getValueOrData()
    //     0x695734: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x695738: ldur            x3, [fp, #-0x10]
    // 0x69573c: LoadField: r1 = r3->field_f
    //     0x69573c: ldur            w1, [x3, #0xf]
    // 0x695740: DecompressPointer r1
    //     0x695740: add             x1, x1, HEAP, lsl #32
    // 0x695744: cmp             w1, w0
    // 0x695748: b.ne            #0x695750
    // 0x69574c: r0 = Null
    //     0x69574c: mov             x0, NULL
    // 0x695750: cmp             w0, NULL
    // 0x695754: b.ne            #0x69575c
    // 0x695758: r0 = 0
    //     0x695758: movz            x0, #0
    // 0x69575c: ldur            x4, [fp, #-0x20]
    // 0x695760: mov             x1, x4
    // 0x695764: ArrayStore: r1[9] = r0  ; List_4
    //     0x695764: add             x25, x1, #0x33
    //     0x695768: str             w0, [x25]
    //     0x69576c: tbz             w0, #0, #0x695788
    //     0x695770: ldurb           w16, [x1, #-1]
    //     0x695774: ldurb           w17, [x0, #-1]
    //     0x695778: and             x16, x17, x16, lsr #2
    //     0x69577c: tst             x16, HEAP, lsr #32
    //     0x695780: b.eq            #0x695788
    //     0x695784: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x695788: r16 = "chapter_5_tokens"
    //     0x695788: add             x16, PP, #0x26, lsl #12  ; [pp+0x264b0] "chapter_5_tokens"
    //     0x69578c: ldr             x16, [x16, #0x4b0]
    // 0x695790: StoreField: r4->field_37 = r16
    //     0x695790: stur            w16, [x4, #0x37]
    // 0x695794: mov             x1, x3
    // 0x695798: r2 = "5"
    //     0x695798: add             x2, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x69579c: ldr             x2, [x2, #0x300]
    // 0x6957a0: r0 = _getValueOrData()
    //     0x6957a0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6957a4: ldur            x3, [fp, #-0x10]
    // 0x6957a8: LoadField: r1 = r3->field_f
    //     0x6957a8: ldur            w1, [x3, #0xf]
    // 0x6957ac: DecompressPointer r1
    //     0x6957ac: add             x1, x1, HEAP, lsl #32
    // 0x6957b0: cmp             w1, w0
    // 0x6957b4: b.ne            #0x6957bc
    // 0x6957b8: r0 = Null
    //     0x6957b8: mov             x0, NULL
    // 0x6957bc: cmp             w0, NULL
    // 0x6957c0: b.ne            #0x6957c8
    // 0x6957c4: r0 = 0
    //     0x6957c4: movz            x0, #0
    // 0x6957c8: ldur            x4, [fp, #-0x20]
    // 0x6957cc: mov             x1, x4
    // 0x6957d0: ArrayStore: r1[11] = r0  ; List_4
    //     0x6957d0: add             x25, x1, #0x3b
    //     0x6957d4: str             w0, [x25]
    //     0x6957d8: tbz             w0, #0, #0x6957f4
    //     0x6957dc: ldurb           w16, [x1, #-1]
    //     0x6957e0: ldurb           w17, [x0, #-1]
    //     0x6957e4: and             x16, x17, x16, lsr #2
    //     0x6957e8: tst             x16, HEAP, lsr #32
    //     0x6957ec: b.eq            #0x6957f4
    //     0x6957f0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6957f4: r16 = "chapter_6_tokens"
    //     0x6957f4: add             x16, PP, #0x26, lsl #12  ; [pp+0x264b8] "chapter_6_tokens"
    //     0x6957f8: ldr             x16, [x16, #0x4b8]
    // 0x6957fc: StoreField: r4->field_3f = r16
    //     0x6957fc: stur            w16, [x4, #0x3f]
    // 0x695800: mov             x1, x3
    // 0x695804: r2 = "6"
    //     0x695804: add             x2, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x695808: ldr             x2, [x2, #0x308]
    // 0x69580c: r0 = _getValueOrData()
    //     0x69580c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x695810: ldur            x2, [fp, #-0x10]
    // 0x695814: LoadField: r1 = r2->field_f
    //     0x695814: ldur            w1, [x2, #0xf]
    // 0x695818: DecompressPointer r1
    //     0x695818: add             x1, x1, HEAP, lsl #32
    // 0x69581c: cmp             w1, w0
    // 0x695820: b.ne            #0x695828
    // 0x695824: r0 = Null
    //     0x695824: mov             x0, NULL
    // 0x695828: cmp             w0, NULL
    // 0x69582c: b.ne            #0x695834
    // 0x695830: r0 = 0
    //     0x695830: movz            x0, #0
    // 0x695834: ldur            d0, [fp, #-0x30]
    // 0x695838: ldur            x4, [fp, #-0x18]
    // 0x69583c: ldur            x3, [fp, #-0x20]
    // 0x695840: mov             x1, x3
    // 0x695844: ArrayStore: r1[13] = r0  ; List_4
    //     0x695844: add             x25, x1, #0x43
    //     0x695848: str             w0, [x25]
    //     0x69584c: tbz             w0, #0, #0x695868
    //     0x695850: ldurb           w16, [x1, #-1]
    //     0x695854: ldurb           w17, [x0, #-1]
    //     0x695858: and             x16, x17, x16, lsr #2
    //     0x69585c: tst             x16, HEAP, lsr #32
    //     0x695860: b.eq            #0x695868
    //     0x695864: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x695868: r16 = "current_boost"
    //     0x695868: add             x16, PP, #0x26, lsl #12  ; [pp+0x264c0] "current_boost"
    //     0x69586c: ldr             x16, [x16, #0x4c0]
    // 0x695870: StoreField: r3->field_47 = r16
    //     0x695870: stur            w16, [x3, #0x47]
    // 0x695874: r0 = inline_Allocate_Double()
    //     0x695874: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x695878: add             x0, x0, #0x10
    //     0x69587c: cmp             x1, x0
    //     0x695880: b.ls            #0x695ab0
    //     0x695884: str             x0, [THR, #0x60]  ; THR::top
    //     0x695888: sub             x0, x0, #0xf
    //     0x69588c: movz            x1, #0xe19c
    //     0x695890: movk            x1, #0x3, lsl #16
    //     0x695894: stur            x1, [x0, #-1]
    // 0x695898: dmb             ishst
    // 0x69589c: StoreField: r0->field_7 = d0
    //     0x69589c: stur            d0, [x0, #7]
    // 0x6958a0: mov             x1, x3
    // 0x6958a4: ArrayStore: r1[15] = r0  ; List_4
    //     0x6958a4: add             x25, x1, #0x4b
    //     0x6958a8: str             w0, [x25]
    //     0x6958ac: tbz             w0, #0, #0x6958c8
    //     0x6958b0: ldurb           w16, [x1, #-1]
    //     0x6958b4: ldurb           w17, [x0, #-1]
    //     0x6958b8: and             x16, x17, x16, lsr #2
    //     0x6958bc: tst             x16, HEAP, lsr #32
    //     0x6958c0: b.eq            #0x6958c8
    //     0x6958c4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6958c8: r16 = "milliseconds"
    //     0x6958c8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26368] "milliseconds"
    //     0x6958cc: ldr             x16, [x16, #0x368]
    // 0x6958d0: StoreField: r3->field_4f = r16
    //     0x6958d0: stur            w16, [x3, #0x4f]
    // 0x6958d4: r0 = BoxInt64Instr(r4)
    //     0x6958d4: sbfiz           x0, x4, #1, #0x1f
    //     0x6958d8: cmp             x4, x0, asr #1
    //     0x6958dc: b.eq            #0x6958e8
    //     0x6958e0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6958e4: stur            x4, [x0, #7]
    // 0x6958e8: mov             x1, x3
    // 0x6958ec: ArrayStore: r1[17] = r0  ; List_4
    //     0x6958ec: add             x25, x1, #0x53
    //     0x6958f0: str             w0, [x25]
    //     0x6958f4: tbz             w0, #0, #0x695910
    //     0x6958f8: ldurb           w16, [x1, #-1]
    //     0x6958fc: ldurb           w17, [x0, #-1]
    //     0x695900: and             x16, x17, x16, lsr #2
    //     0x695904: tst             x16, HEAP, lsr #32
    //     0x695908: b.eq            #0x695910
    //     0x69590c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x695910: r16 = <String, Object>
    //     0x695910: ldr             x16, [PP, #0x22f8]  ; [pp+0x22f8] TypeArguments: <String, Object>
    // 0x695914: stp             x3, x16, [SP]
    // 0x695918: r0 = Map._fromLiteral()
    //     0x695918: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x69591c: mov             x2, x0
    // 0x695920: stur            x2, [fp, #-0x20]
    // 0x695924: r4 = 5
    //     0x695924: movz            x4, #0x5
    // 0x695928: ldur            x3, [fp, #-0x10]
    // 0x69592c: stur            x4, [fp, #-0x18]
    // 0x695930: CheckStackOverflow
    //     0x695930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x695934: cmp             SP, x16
    //     0x695938: b.ls            #0x695ad0
    // 0x69593c: r0 = BoxInt64Instr(r4)
    //     0x69593c: sbfiz           x0, x4, #1, #0x1f
    //     0x695940: cmp             x4, x0, asr #1
    //     0x695944: b.eq            #0x695950
    //     0x695948: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x69594c: stur            x4, [x0, #7]
    // 0x695950: mov             x1, x0
    // 0x695954: stur            x1, [fp, #-8]
    // 0x695958: r0 = 60
    //     0x695958: movz            x0, #0x3c
    // 0x69595c: branchIfSmi(r1, 0x695968)
    //     0x69595c: tbz             w1, #0, #0x695968
    // 0x695960: r0 = LoadClassIdInstr(r1)
    //     0x695960: ldur            x0, [x1, #-1]
    //     0x695964: ubfx            x0, x0, #0xc, #0x14
    // 0x695968: str             x1, [SP]
    // 0x69596c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69596c: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x695970: r0 = GDT[cid_x0 + 0x3019]()
    //     0x695970: movz            x17, #0x3019
    //     0x695974: add             lr, x0, x17
    //     0x695978: ldr             lr, [x21, lr, lsl #3]
    //     0x69597c: blr             lr
    // 0x695980: mov             x1, x0
    // 0x695984: ldur            x0, [fp, #-0x10]
    // 0x695988: LoadField: r3 = r0->field_f
    //     0x695988: ldur            w3, [x0, #0xf]
    // 0x69598c: DecompressPointer r3
    //     0x69598c: add             x3, x3, HEAP, lsl #32
    // 0x695990: mov             x2, x1
    // 0x695994: mov             x1, x0
    // 0x695998: stur            x3, [fp, #-0x28]
    // 0x69599c: r0 = _getValueOrData()
    //     0x69599c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6959a0: mov             x1, x0
    // 0x6959a4: ldur            x0, [fp, #-0x28]
    // 0x6959a8: cmp             w0, w1
    // 0x6959ac: b.eq            #0x695a98
    // 0x6959b0: ldur            x0, [fp, #-0x10]
    // 0x6959b4: ldur            x3, [fp, #-8]
    // 0x6959b8: r1 = Null
    //     0x6959b8: mov             x1, NULL
    // 0x6959bc: r2 = 6
    //     0x6959bc: movz            x2, #0x6
    // 0x6959c0: r0 = AllocateArray()
    //     0x6959c0: bl              #0x82746c  ; AllocateArrayStub
    // 0x6959c4: r16 = "chapter_"
    //     0x6959c4: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ce8] "chapter_"
    //     0x6959c8: ldr             x16, [x16, #0xce8]
    // 0x6959cc: StoreField: r0->field_f = r16
    //     0x6959cc: stur            w16, [x0, #0xf]
    // 0x6959d0: ldur            x1, [fp, #-8]
    // 0x6959d4: StoreField: r0->field_13 = r1
    //     0x6959d4: stur            w1, [x0, #0x13]
    // 0x6959d8: r16 = "_tokens"
    //     0x6959d8: add             x16, PP, #0x26, lsl #12  ; [pp+0x263a0] "_tokens"
    //     0x6959dc: ldr             x16, [x16, #0x3a0]
    // 0x6959e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x6959e0: stur            w16, [x0, #0x17]
    // 0x6959e4: str             x0, [SP]
    // 0x6959e8: r0 = _interpolate()
    //     0x6959e8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x6959ec: mov             x1, x0
    // 0x6959f0: ldur            x0, [fp, #-8]
    // 0x6959f4: stur            x1, [fp, #-0x28]
    // 0x6959f8: r2 = 60
    //     0x6959f8: movz            x2, #0x3c
    // 0x6959fc: branchIfSmi(r0, 0x695a08)
    //     0x6959fc: tbz             w0, #0, #0x695a08
    // 0x695a00: r2 = LoadClassIdInstr(r0)
    //     0x695a00: ldur            x2, [x0, #-1]
    //     0x695a04: ubfx            x2, x2, #0xc, #0x14
    // 0x695a08: str             x0, [SP]
    // 0x695a0c: mov             x0, x2
    // 0x695a10: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x695a10: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x695a14: r0 = GDT[cid_x0 + 0x3019]()
    //     0x695a14: movz            x17, #0x3019
    //     0x695a18: add             lr, x0, x17
    //     0x695a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x695a20: blr             lr
    // 0x695a24: ldur            x1, [fp, #-0x10]
    // 0x695a28: mov             x2, x0
    // 0x695a2c: r0 = _getValueOrData()
    //     0x695a2c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x695a30: mov             x1, x0
    // 0x695a34: ldur            x0, [fp, #-0x10]
    // 0x695a38: LoadField: r2 = r0->field_f
    //     0x695a38: ldur            w2, [x0, #0xf]
    // 0x695a3c: DecompressPointer r2
    //     0x695a3c: add             x2, x2, HEAP, lsl #32
    // 0x695a40: cmp             w2, w1
    // 0x695a44: b.ne            #0x695a4c
    // 0x695a48: r1 = Null
    //     0x695a48: mov             x1, NULL
    // 0x695a4c: cmp             w1, NULL
    // 0x695a50: b.ne            #0x695a5c
    // 0x695a54: r4 = 0
    //     0x695a54: movz            x4, #0
    // 0x695a58: b               #0x695a60
    // 0x695a5c: mov             x4, x1
    // 0x695a60: ldur            x3, [fp, #-0x18]
    // 0x695a64: ldur            x1, [fp, #-0x20]
    // 0x695a68: ldur            x2, [fp, #-0x28]
    // 0x695a6c: stur            x4, [fp, #-8]
    // 0x695a70: r0 = _hashCode()
    //     0x695a70: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x695a74: ldur            x1, [fp, #-0x20]
    // 0x695a78: ldur            x2, [fp, #-0x28]
    // 0x695a7c: ldur            x3, [fp, #-8]
    // 0x695a80: mov             x5, x0
    // 0x695a84: r0 = _set()
    //     0x695a84: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x695a88: ldur            x1, [fp, #-0x18]
    // 0x695a8c: add             x4, x1, #1
    // 0x695a90: ldur            x2, [fp, #-0x20]
    // 0x695a94: b               #0x695928
    // 0x695a98: ldur            x0, [fp, #-0x20]
    // 0x695a9c: LeaveFrame
    //     0x695a9c: mov             SP, fp
    //     0x695aa0: ldp             fp, lr, [SP], #0x10
    // 0x695aa4: ret
    //     0x695aa4: ret             
    // 0x695aa8: r0 = StackOverflowSharedWithFPURegs()
    //     0x695aa8: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x695aac: b               #0x6955a4
    // 0x695ab0: SaveReg d0
    //     0x695ab0: str             q0, [SP, #-0x10]!
    // 0x695ab4: stp             x3, x4, [SP, #-0x10]!
    // 0x695ab8: SaveReg r2
    //     0x695ab8: str             x2, [SP, #-8]!
    // 0x695abc: r0 = AllocateDouble()
    //     0x695abc: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x695ac0: RestoreReg r2
    //     0x695ac0: ldr             x2, [SP], #8
    // 0x695ac4: ldp             x3, x4, [SP], #0x10
    // 0x695ac8: RestoreReg d0
    //     0x695ac8: ldr             q0, [SP], #0x10
    // 0x695acc: b               #0x69589c
    // 0x695ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x695ad0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x695ad4: b               #0x69593c
  }
  [closure] String? getAndroidLeaderboardId(dynamic, String) {
    // ** addr: 0x695dd8, size: 0x240
    // 0x695dd8: EnterFrame
    //     0x695dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x695ddc: mov             fp, SP
    // 0x695de0: AllocStack(0x10)
    //     0x695de0: sub             SP, SP, #0x10
    // 0x695de4: CheckStackOverflow
    //     0x695de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x695de8: cmp             SP, x16
    //     0x695dec: b.ls            #0x696010
    // 0x695df0: r16 = "1"
    //     0x695df0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x695df4: ldr             x16, [x16, #0x9c8]
    // 0x695df8: ldr             lr, [fp, #0x10]
    // 0x695dfc: stp             lr, x16, [SP]
    // 0x695e00: r0 = ==()
    //     0x695e00: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695e04: tbnz            w0, #4, #0x695e1c
    // 0x695e08: r0 = "CgkIxsjH8ssQEAIQDA"
    //     0x695e08: add             x0, PP, #0x26, lsl #12  ; [pp+0x263c8] "CgkIxsjH8ssQEAIQDA"
    //     0x695e0c: ldr             x0, [x0, #0x3c8]
    // 0x695e10: LeaveFrame
    //     0x695e10: mov             SP, fp
    //     0x695e14: ldp             fp, lr, [SP], #0x10
    // 0x695e18: ret
    //     0x695e18: ret             
    // 0x695e1c: r16 = "2"
    //     0x695e1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x695e20: ldr             x16, [x16, #0x2e0]
    // 0x695e24: ldr             lr, [fp, #0x10]
    // 0x695e28: stp             lr, x16, [SP]
    // 0x695e2c: r0 = ==()
    //     0x695e2c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695e30: tbnz            w0, #4, #0x695e48
    // 0x695e34: r0 = "CgkIxsjH8ssQEAIQDQ"
    //     0x695e34: add             x0, PP, #0x26, lsl #12  ; [pp+0x263d0] "CgkIxsjH8ssQEAIQDQ"
    //     0x695e38: ldr             x0, [x0, #0x3d0]
    // 0x695e3c: LeaveFrame
    //     0x695e3c: mov             SP, fp
    //     0x695e40: ldp             fp, lr, [SP], #0x10
    // 0x695e44: ret
    //     0x695e44: ret             
    // 0x695e48: r16 = "3"
    //     0x695e48: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x695e4c: ldr             x16, [x16, #0x2f0]
    // 0x695e50: ldr             lr, [fp, #0x10]
    // 0x695e54: stp             lr, x16, [SP]
    // 0x695e58: r0 = ==()
    //     0x695e58: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695e5c: tbnz            w0, #4, #0x695e74
    // 0x695e60: r0 = "CgkIxsjH8ssQEAIQDg"
    //     0x695e60: add             x0, PP, #0x26, lsl #12  ; [pp+0x263d8] "CgkIxsjH8ssQEAIQDg"
    //     0x695e64: ldr             x0, [x0, #0x3d8]
    // 0x695e68: LeaveFrame
    //     0x695e68: mov             SP, fp
    //     0x695e6c: ldp             fp, lr, [SP], #0x10
    // 0x695e70: ret
    //     0x695e70: ret             
    // 0x695e74: r16 = "4"
    //     0x695e74: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x695e78: ldr             x16, [x16, #0x2f8]
    // 0x695e7c: ldr             lr, [fp, #0x10]
    // 0x695e80: stp             lr, x16, [SP]
    // 0x695e84: r0 = ==()
    //     0x695e84: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695e88: tbnz            w0, #4, #0x695ea0
    // 0x695e8c: r0 = "CgkIxsjH8ssQEAIQDw"
    //     0x695e8c: add             x0, PP, #0x26, lsl #12  ; [pp+0x263e0] "CgkIxsjH8ssQEAIQDw"
    //     0x695e90: ldr             x0, [x0, #0x3e0]
    // 0x695e94: LeaveFrame
    //     0x695e94: mov             SP, fp
    //     0x695e98: ldp             fp, lr, [SP], #0x10
    // 0x695e9c: ret
    //     0x695e9c: ret             
    // 0x695ea0: r16 = "5"
    //     0x695ea0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x695ea4: ldr             x16, [x16, #0x300]
    // 0x695ea8: ldr             lr, [fp, #0x10]
    // 0x695eac: stp             lr, x16, [SP]
    // 0x695eb0: r0 = ==()
    //     0x695eb0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695eb4: tbnz            w0, #4, #0x695ecc
    // 0x695eb8: r0 = "CgkIxsjH8ssQEAIQEA"
    //     0x695eb8: add             x0, PP, #0x26, lsl #12  ; [pp+0x263e8] "CgkIxsjH8ssQEAIQEA"
    //     0x695ebc: ldr             x0, [x0, #0x3e8]
    // 0x695ec0: LeaveFrame
    //     0x695ec0: mov             SP, fp
    //     0x695ec4: ldp             fp, lr, [SP], #0x10
    // 0x695ec8: ret
    //     0x695ec8: ret             
    // 0x695ecc: r16 = "6"
    //     0x695ecc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x695ed0: ldr             x16, [x16, #0x308]
    // 0x695ed4: ldr             lr, [fp, #0x10]
    // 0x695ed8: stp             lr, x16, [SP]
    // 0x695edc: r0 = ==()
    //     0x695edc: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695ee0: tbnz            w0, #4, #0x695ef8
    // 0x695ee4: r0 = "CgkIxsjH8ssQEAIQEQ"
    //     0x695ee4: add             x0, PP, #0x26, lsl #12  ; [pp+0x263f0] "CgkIxsjH8ssQEAIQEQ"
    //     0x695ee8: ldr             x0, [x0, #0x3f0]
    // 0x695eec: LeaveFrame
    //     0x695eec: mov             SP, fp
    //     0x695ef0: ldp             fp, lr, [SP], #0x10
    // 0x695ef4: ret
    //     0x695ef4: ret             
    // 0x695ef8: r16 = "7"
    //     0x695ef8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x695efc: ldr             x16, [x16, #0x310]
    // 0x695f00: ldr             lr, [fp, #0x10]
    // 0x695f04: stp             lr, x16, [SP]
    // 0x695f08: r0 = ==()
    //     0x695f08: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695f0c: tbnz            w0, #4, #0x695f24
    // 0x695f10: r0 = "CgkIxsjH8ssQEAIQEg"
    //     0x695f10: add             x0, PP, #0x26, lsl #12  ; [pp+0x263f8] "CgkIxsjH8ssQEAIQEg"
    //     0x695f14: ldr             x0, [x0, #0x3f8]
    // 0x695f18: LeaveFrame
    //     0x695f18: mov             SP, fp
    //     0x695f1c: ldp             fp, lr, [SP], #0x10
    // 0x695f20: ret
    //     0x695f20: ret             
    // 0x695f24: r16 = "8"
    //     0x695f24: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x695f28: ldr             x16, [x16, #0x318]
    // 0x695f2c: ldr             lr, [fp, #0x10]
    // 0x695f30: stp             lr, x16, [SP]
    // 0x695f34: r0 = ==()
    //     0x695f34: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695f38: tbnz            w0, #4, #0x695f50
    // 0x695f3c: r0 = "CgkIxsjH8ssQEAIQEw"
    //     0x695f3c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26400] "CgkIxsjH8ssQEAIQEw"
    //     0x695f40: ldr             x0, [x0, #0x400]
    // 0x695f44: LeaveFrame
    //     0x695f44: mov             SP, fp
    //     0x695f48: ldp             fp, lr, [SP], #0x10
    // 0x695f4c: ret
    //     0x695f4c: ret             
    // 0x695f50: r16 = "9"
    //     0x695f50: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x695f54: ldr             x16, [x16, #0x320]
    // 0x695f58: ldr             lr, [fp, #0x10]
    // 0x695f5c: stp             lr, x16, [SP]
    // 0x695f60: r0 = ==()
    //     0x695f60: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695f64: tbnz            w0, #4, #0x695f7c
    // 0x695f68: r0 = "CgkIxsjH8ssQEAIQFA"
    //     0x695f68: add             x0, PP, #0x26, lsl #12  ; [pp+0x26408] "CgkIxsjH8ssQEAIQFA"
    //     0x695f6c: ldr             x0, [x0, #0x408]
    // 0x695f70: LeaveFrame
    //     0x695f70: mov             SP, fp
    //     0x695f74: ldp             fp, lr, [SP], #0x10
    // 0x695f78: ret
    //     0x695f78: ret             
    // 0x695f7c: r16 = "10"
    //     0x695f7c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x695f80: ldr             x16, [x16, #0x9d0]
    // 0x695f84: ldr             lr, [fp, #0x10]
    // 0x695f88: stp             lr, x16, [SP]
    // 0x695f8c: r0 = ==()
    //     0x695f8c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695f90: tbnz            w0, #4, #0x695fa8
    // 0x695f94: r0 = "CgkIxsjH8ssQEAIQFQ"
    //     0x695f94: add             x0, PP, #0x26, lsl #12  ; [pp+0x26410] "CgkIxsjH8ssQEAIQFQ"
    //     0x695f98: ldr             x0, [x0, #0x410]
    // 0x695f9c: LeaveFrame
    //     0x695f9c: mov             SP, fp
    //     0x695fa0: ldp             fp, lr, [SP], #0x10
    // 0x695fa4: ret
    //     0x695fa4: ret             
    // 0x695fa8: r16 = "11"
    //     0x695fa8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x695fac: ldr             x16, [x16, #0x328]
    // 0x695fb0: ldr             lr, [fp, #0x10]
    // 0x695fb4: stp             lr, x16, [SP]
    // 0x695fb8: r0 = ==()
    //     0x695fb8: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695fbc: tbnz            w0, #4, #0x695fd4
    // 0x695fc0: r0 = "CgkIxsjH8ssQEAIQFw"
    //     0x695fc0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26418] "CgkIxsjH8ssQEAIQFw"
    //     0x695fc4: ldr             x0, [x0, #0x418]
    // 0x695fc8: LeaveFrame
    //     0x695fc8: mov             SP, fp
    //     0x695fcc: ldp             fp, lr, [SP], #0x10
    // 0x695fd0: ret
    //     0x695fd0: ret             
    // 0x695fd4: r16 = "12"
    //     0x695fd4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x695fd8: ldr             x16, [x16, #0x330]
    // 0x695fdc: ldr             lr, [fp, #0x10]
    // 0x695fe0: stp             lr, x16, [SP]
    // 0x695fe4: r0 = ==()
    //     0x695fe4: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x695fe8: tbnz            w0, #4, #0x696000
    // 0x695fec: r0 = "CgkIxsjH8ssQEAIQGw"
    //     0x695fec: add             x0, PP, #0x26, lsl #12  ; [pp+0x26420] "CgkIxsjH8ssQEAIQGw"
    //     0x695ff0: ldr             x0, [x0, #0x420]
    // 0x695ff4: LeaveFrame
    //     0x695ff4: mov             SP, fp
    //     0x695ff8: ldp             fp, lr, [SP], #0x10
    // 0x695ffc: ret
    //     0x695ffc: ret             
    // 0x696000: r0 = Null
    //     0x696000: mov             x0, NULL
    // 0x696004: LeaveFrame
    //     0x696004: mov             SP, fp
    //     0x696008: ldp             fp, lr, [SP], #0x10
    // 0x69600c: ret
    //     0x69600c: ret             
    // 0x696010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x696010: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x696014: b               #0x695df0
  }
  [closure] String? getAndroidAchievementId(dynamic, String) {
    // ** addr: 0x696018, size: 0x240
    // 0x696018: EnterFrame
    //     0x696018: stp             fp, lr, [SP, #-0x10]!
    //     0x69601c: mov             fp, SP
    // 0x696020: AllocStack(0x10)
    //     0x696020: sub             SP, SP, #0x10
    // 0x696024: CheckStackOverflow
    //     0x696024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x696028: cmp             SP, x16
    //     0x69602c: b.ls            #0x696250
    // 0x696030: r16 = "1"
    //     0x696030: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x696034: ldr             x16, [x16, #0x9c8]
    // 0x696038: ldr             lr, [fp, #0x10]
    // 0x69603c: stp             lr, x16, [SP]
    // 0x696040: r0 = ==()
    //     0x696040: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x696044: tbnz            w0, #4, #0x69605c
    // 0x696048: r0 = "CgkIxsjH8ssQEAIQAQ"
    //     0x696048: add             x0, PP, #0x26, lsl #12  ; [pp+0x26428] "CgkIxsjH8ssQEAIQAQ"
    //     0x69604c: ldr             x0, [x0, #0x428]
    // 0x696050: LeaveFrame
    //     0x696050: mov             SP, fp
    //     0x696054: ldp             fp, lr, [SP], #0x10
    // 0x696058: ret
    //     0x696058: ret             
    // 0x69605c: r16 = "2"
    //     0x69605c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x696060: ldr             x16, [x16, #0x2e0]
    // 0x696064: ldr             lr, [fp, #0x10]
    // 0x696068: stp             lr, x16, [SP]
    // 0x69606c: r0 = ==()
    //     0x69606c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x696070: tbnz            w0, #4, #0x696088
    // 0x696074: r0 = "CgkIxsjH8ssQEAIQAg"
    //     0x696074: add             x0, PP, #0x26, lsl #12  ; [pp+0x26430] "CgkIxsjH8ssQEAIQAg"
    //     0x696078: ldr             x0, [x0, #0x430]
    // 0x69607c: LeaveFrame
    //     0x69607c: mov             SP, fp
    //     0x696080: ldp             fp, lr, [SP], #0x10
    // 0x696084: ret
    //     0x696084: ret             
    // 0x696088: r16 = "3"
    //     0x696088: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x69608c: ldr             x16, [x16, #0x2f0]
    // 0x696090: ldr             lr, [fp, #0x10]
    // 0x696094: stp             lr, x16, [SP]
    // 0x696098: r0 = ==()
    //     0x696098: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x69609c: tbnz            w0, #4, #0x6960b4
    // 0x6960a0: r0 = "CgkIxsjH8ssQEAIQAw"
    //     0x6960a0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26438] "CgkIxsjH8ssQEAIQAw"
    //     0x6960a4: ldr             x0, [x0, #0x438]
    // 0x6960a8: LeaveFrame
    //     0x6960a8: mov             SP, fp
    //     0x6960ac: ldp             fp, lr, [SP], #0x10
    // 0x6960b0: ret
    //     0x6960b0: ret             
    // 0x6960b4: r16 = "4"
    //     0x6960b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x6960b8: ldr             x16, [x16, #0x2f8]
    // 0x6960bc: ldr             lr, [fp, #0x10]
    // 0x6960c0: stp             lr, x16, [SP]
    // 0x6960c4: r0 = ==()
    //     0x6960c4: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6960c8: tbnz            w0, #4, #0x6960e0
    // 0x6960cc: r0 = "CgkIxsjH8ssQEAIQBA"
    //     0x6960cc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26440] "CgkIxsjH8ssQEAIQBA"
    //     0x6960d0: ldr             x0, [x0, #0x440]
    // 0x6960d4: LeaveFrame
    //     0x6960d4: mov             SP, fp
    //     0x6960d8: ldp             fp, lr, [SP], #0x10
    // 0x6960dc: ret
    //     0x6960dc: ret             
    // 0x6960e0: r16 = "5"
    //     0x6960e0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x6960e4: ldr             x16, [x16, #0x300]
    // 0x6960e8: ldr             lr, [fp, #0x10]
    // 0x6960ec: stp             lr, x16, [SP]
    // 0x6960f0: r0 = ==()
    //     0x6960f0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6960f4: tbnz            w0, #4, #0x69610c
    // 0x6960f8: r0 = "CgkIxsjH8ssQEAIQBQ"
    //     0x6960f8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26448] "CgkIxsjH8ssQEAIQBQ"
    //     0x6960fc: ldr             x0, [x0, #0x448]
    // 0x696100: LeaveFrame
    //     0x696100: mov             SP, fp
    //     0x696104: ldp             fp, lr, [SP], #0x10
    // 0x696108: ret
    //     0x696108: ret             
    // 0x69610c: r16 = "6"
    //     0x69610c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x696110: ldr             x16, [x16, #0x308]
    // 0x696114: ldr             lr, [fp, #0x10]
    // 0x696118: stp             lr, x16, [SP]
    // 0x69611c: r0 = ==()
    //     0x69611c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x696120: tbnz            w0, #4, #0x696138
    // 0x696124: r0 = "CgkIxsjH8ssQEAIQBg"
    //     0x696124: add             x0, PP, #0x26, lsl #12  ; [pp+0x26450] "CgkIxsjH8ssQEAIQBg"
    //     0x696128: ldr             x0, [x0, #0x450]
    // 0x69612c: LeaveFrame
    //     0x69612c: mov             SP, fp
    //     0x696130: ldp             fp, lr, [SP], #0x10
    // 0x696134: ret
    //     0x696134: ret             
    // 0x696138: r16 = "7"
    //     0x696138: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x69613c: ldr             x16, [x16, #0x310]
    // 0x696140: ldr             lr, [fp, #0x10]
    // 0x696144: stp             lr, x16, [SP]
    // 0x696148: r0 = ==()
    //     0x696148: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x69614c: tbnz            w0, #4, #0x696164
    // 0x696150: r0 = "CgkIxsjH8ssQEAIQBw"
    //     0x696150: add             x0, PP, #0x26, lsl #12  ; [pp+0x26458] "CgkIxsjH8ssQEAIQBw"
    //     0x696154: ldr             x0, [x0, #0x458]
    // 0x696158: LeaveFrame
    //     0x696158: mov             SP, fp
    //     0x69615c: ldp             fp, lr, [SP], #0x10
    // 0x696160: ret
    //     0x696160: ret             
    // 0x696164: r16 = "8"
    //     0x696164: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x696168: ldr             x16, [x16, #0x318]
    // 0x69616c: ldr             lr, [fp, #0x10]
    // 0x696170: stp             lr, x16, [SP]
    // 0x696174: r0 = ==()
    //     0x696174: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x696178: tbnz            w0, #4, #0x696190
    // 0x69617c: r0 = "CgkIxsjH8ssQEAIQCA"
    //     0x69617c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26460] "CgkIxsjH8ssQEAIQCA"
    //     0x696180: ldr             x0, [x0, #0x460]
    // 0x696184: LeaveFrame
    //     0x696184: mov             SP, fp
    //     0x696188: ldp             fp, lr, [SP], #0x10
    // 0x69618c: ret
    //     0x69618c: ret             
    // 0x696190: r16 = "9"
    //     0x696190: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x696194: ldr             x16, [x16, #0x320]
    // 0x696198: ldr             lr, [fp, #0x10]
    // 0x69619c: stp             lr, x16, [SP]
    // 0x6961a0: r0 = ==()
    //     0x6961a0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6961a4: tbnz            w0, #4, #0x6961bc
    // 0x6961a8: r0 = "CgkIxsjH8ssQEAIQCQ"
    //     0x6961a8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26468] "CgkIxsjH8ssQEAIQCQ"
    //     0x6961ac: ldr             x0, [x0, #0x468]
    // 0x6961b0: LeaveFrame
    //     0x6961b0: mov             SP, fp
    //     0x6961b4: ldp             fp, lr, [SP], #0x10
    // 0x6961b8: ret
    //     0x6961b8: ret             
    // 0x6961bc: r16 = "10"
    //     0x6961bc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x6961c0: ldr             x16, [x16, #0x9d0]
    // 0x6961c4: ldr             lr, [fp, #0x10]
    // 0x6961c8: stp             lr, x16, [SP]
    // 0x6961cc: r0 = ==()
    //     0x6961cc: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6961d0: tbnz            w0, #4, #0x6961e8
    // 0x6961d4: r0 = "CgkIxsjH8ssQEAIQCg"
    //     0x6961d4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26470] "CgkIxsjH8ssQEAIQCg"
    //     0x6961d8: ldr             x0, [x0, #0x470]
    // 0x6961dc: LeaveFrame
    //     0x6961dc: mov             SP, fp
    //     0x6961e0: ldp             fp, lr, [SP], #0x10
    // 0x6961e4: ret
    //     0x6961e4: ret             
    // 0x6961e8: r16 = "11"
    //     0x6961e8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x6961ec: ldr             x16, [x16, #0x328]
    // 0x6961f0: ldr             lr, [fp, #0x10]
    // 0x6961f4: stp             lr, x16, [SP]
    // 0x6961f8: r0 = ==()
    //     0x6961f8: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6961fc: tbnz            w0, #4, #0x696214
    // 0x696200: r0 = "CgkIxsjH8ssQEAIQFg"
    //     0x696200: add             x0, PP, #0x26, lsl #12  ; [pp+0x26478] "CgkIxsjH8ssQEAIQFg"
    //     0x696204: ldr             x0, [x0, #0x478]
    // 0x696208: LeaveFrame
    //     0x696208: mov             SP, fp
    //     0x69620c: ldp             fp, lr, [SP], #0x10
    // 0x696210: ret
    //     0x696210: ret             
    // 0x696214: r16 = "12"
    //     0x696214: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x696218: ldr             x16, [x16, #0x330]
    // 0x69621c: ldr             lr, [fp, #0x10]
    // 0x696220: stp             lr, x16, [SP]
    // 0x696224: r0 = ==()
    //     0x696224: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x696228: tbnz            w0, #4, #0x696240
    // 0x69622c: r0 = "CgkIxsjH8ssQEAIQGg"
    //     0x69622c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26480] "CgkIxsjH8ssQEAIQGg"
    //     0x696230: ldr             x0, [x0, #0x480]
    // 0x696234: LeaveFrame
    //     0x696234: mov             SP, fp
    //     0x696238: ldp             fp, lr, [SP], #0x10
    // 0x69623c: ret
    //     0x69623c: ret             
    // 0x696240: r0 = Null
    //     0x696240: mov             x0, NULL
    // 0x696244: LeaveFrame
    //     0x696244: mov             SP, fp
    //     0x696248: ldp             fp, lr, [SP], #0x10
    // 0x69624c: ret
    //     0x69624c: ret             
    // 0x696250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x696250: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x696254: b               #0x696030
  }
}
