// lib: , url: package:pretentious/data/QuestBlock.dart

// class id: 1049472, size: 0x8
class :: {
}

// class id: 260, size: 0x14, field offset: 0x8
class QuestBlock extends Object {

  factory _ QuestBlock.fromMap(/* No info */) {
    // ** addr: 0x460b28, size: 0x1a4
    // 0x460b28: EnterFrame
    //     0x460b28: stp             fp, lr, [SP, #-0x10]!
    //     0x460b2c: mov             fp, SP
    // 0x460b30: AllocStack(0x18)
    //     0x460b30: sub             SP, SP, #0x18
    // 0x460b34: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x460b34: mov             x3, x2
    //     0x460b38: stur            x2, [fp, #-8]
    // 0x460b3c: CheckStackOverflow
    //     0x460b3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x460b40: cmp             SP, x16
    //     0x460b44: b.ls            #0x460cc4
    // 0x460b48: r0 = LoadClassIdInstr(r3)
    //     0x460b48: ldur            x0, [x3, #-1]
    //     0x460b4c: ubfx            x0, x0, #0xc, #0x14
    // 0x460b50: mov             x1, x3
    // 0x460b54: r2 = 0
    //     0x460b54: movz            x2, #0
    // 0x460b58: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460b58: sub             lr, x0, #1, lsl #12
    //     0x460b5c: ldr             lr, [x21, lr, lsl #3]
    //     0x460b60: blr             lr
    // 0x460b64: mov             x3, x0
    // 0x460b68: r2 = Null
    //     0x460b68: mov             x2, NULL
    // 0x460b6c: r1 = Null
    //     0x460b6c: mov             x1, NULL
    // 0x460b70: stur            x3, [fp, #-0x10]
    // 0x460b74: branchIfSmi(r0, 0x460b9c)
    //     0x460b74: tbz             w0, #0, #0x460b9c
    // 0x460b78: r4 = LoadClassIdInstr(r0)
    //     0x460b78: ldur            x4, [x0, #-1]
    //     0x460b7c: ubfx            x4, x4, #0xc, #0x14
    // 0x460b80: sub             x4, x4, #0x3c
    // 0x460b84: cmp             x4, #1
    // 0x460b88: b.ls            #0x460b9c
    // 0x460b8c: r8 = int?
    //     0x460b8c: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x460b90: r3 = Null
    //     0x460b90: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c90] Null
    //     0x460b94: ldr             x3, [x3, #0xc90]
    // 0x460b98: r0 = int?()
    //     0x460b98: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x460b9c: ldur            x3, [fp, #-8]
    // 0x460ba0: r0 = LoadClassIdInstr(r3)
    //     0x460ba0: ldur            x0, [x3, #-1]
    //     0x460ba4: ubfx            x0, x0, #0xc, #0x14
    // 0x460ba8: mov             x1, x3
    // 0x460bac: r2 = 2
    //     0x460bac: movz            x2, #0x2
    // 0x460bb0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460bb0: sub             lr, x0, #1, lsl #12
    //     0x460bb4: ldr             lr, [x21, lr, lsl #3]
    //     0x460bb8: blr             lr
    // 0x460bbc: mov             x3, x0
    // 0x460bc0: r2 = Null
    //     0x460bc0: mov             x2, NULL
    // 0x460bc4: r1 = Null
    //     0x460bc4: mov             x1, NULL
    // 0x460bc8: stur            x3, [fp, #-0x18]
    // 0x460bcc: r8 = Map
    //     0x460bcc: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x460bd0: r3 = Null
    //     0x460bd0: add             x3, PP, #0x10, lsl #12  ; [pp+0x10ca0] Null
    //     0x460bd4: ldr             x3, [x3, #0xca0]
    // 0x460bd8: r0 = Map()
    //     0x460bd8: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x460bdc: ldur            x2, [fp, #-0x18]
    // 0x460be0: r1 = <int, int>
    //     0x460be0: ldr             x1, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x460be4: r0 = LinkedHashMap.from()
    //     0x460be4: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x460be8: mov             x4, x0
    // 0x460bec: ldur            x3, [fp, #-8]
    // 0x460bf0: stur            x4, [fp, #-0x18]
    // 0x460bf4: r0 = LoadClassIdInstr(r3)
    //     0x460bf4: ldur            x0, [x3, #-1]
    //     0x460bf8: ubfx            x0, x0, #0xc, #0x14
    // 0x460bfc: mov             x1, x3
    // 0x460c00: r2 = 4
    //     0x460c00: movz            x2, #0x4
    // 0x460c04: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460c04: sub             lr, x0, #1, lsl #12
    //     0x460c08: ldr             lr, [x21, lr, lsl #3]
    //     0x460c0c: blr             lr
    // 0x460c10: cmp             w0, NULL
    // 0x460c14: b.ne            #0x460c20
    // 0x460c18: r2 = Null
    //     0x460c18: mov             x2, NULL
    // 0x460c1c: b               #0x460c90
    // 0x460c20: ldur            x1, [fp, #-8]
    // 0x460c24: r0 = LoadClassIdInstr(r1)
    //     0x460c24: ldur            x0, [x1, #-1]
    //     0x460c28: ubfx            x0, x0, #0xc, #0x14
    // 0x460c2c: r2 = 4
    //     0x460c2c: movz            x2, #0x4
    // 0x460c30: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460c30: sub             lr, x0, #1, lsl #12
    //     0x460c34: ldr             lr, [x21, lr, lsl #3]
    //     0x460c38: blr             lr
    // 0x460c3c: mov             x3, x0
    // 0x460c40: r2 = Null
    //     0x460c40: mov             x2, NULL
    // 0x460c44: r1 = Null
    //     0x460c44: mov             x1, NULL
    // 0x460c48: stur            x3, [fp, #-8]
    // 0x460c4c: branchIfSmi(r0, 0x460c74)
    //     0x460c4c: tbz             w0, #0, #0x460c74
    // 0x460c50: r4 = LoadClassIdInstr(r0)
    //     0x460c50: ldur            x4, [x0, #-1]
    //     0x460c54: ubfx            x4, x4, #0xc, #0x14
    // 0x460c58: sub             x4, x4, #0x3c
    // 0x460c5c: cmp             x4, #1
    // 0x460c60: b.ls            #0x460c74
    // 0x460c64: r8 = int
    //     0x460c64: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x460c68: r3 = Null
    //     0x460c68: add             x3, PP, #0x10, lsl #12  ; [pp+0x10cb0] Null
    //     0x460c6c: ldr             x3, [x3, #0xcb0]
    // 0x460c70: r0 = int()
    //     0x460c70: bl              #0x82bb04  ; IsType_int_Stub
    // 0x460c74: r0 = DateTime()
    //     0x460c74: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x460c78: mov             x1, x0
    // 0x460c7c: ldur            x2, [fp, #-8]
    // 0x460c80: stur            x0, [fp, #-8]
    // 0x460c84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x460c84: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x460c88: r0 = DateTime.fromMillisecondsSinceEpoch()
    //     0x460c88: bl              #0x450518  ; [dart:core] DateTime::DateTime.fromMillisecondsSinceEpoch
    // 0x460c8c: ldur            x2, [fp, #-8]
    // 0x460c90: ldur            x1, [fp, #-0x10]
    // 0x460c94: ldur            x0, [fp, #-0x18]
    // 0x460c98: stur            x2, [fp, #-8]
    // 0x460c9c: r0 = QuestBlock()
    //     0x460c9c: bl              #0x462598  ; AllocateQuestBlockStub -> QuestBlock (size=0x14)
    // 0x460ca0: ldur            x1, [fp, #-0x10]
    // 0x460ca4: StoreField: r0->field_7 = r1
    //     0x460ca4: stur            w1, [x0, #7]
    // 0x460ca8: ldur            x1, [fp, #-0x18]
    // 0x460cac: StoreField: r0->field_b = r1
    //     0x460cac: stur            w1, [x0, #0xb]
    // 0x460cb0: ldur            x1, [fp, #-8]
    // 0x460cb4: StoreField: r0->field_f = r1
    //     0x460cb4: stur            w1, [x0, #0xf]
    // 0x460cb8: LeaveFrame
    //     0x460cb8: mov             SP, fp
    //     0x460cbc: ldp             fp, lr, [SP], #0x10
    // 0x460cc0: ret
    //     0x460cc0: ret             
    // 0x460cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460cc4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460cc8: b               #0x460b48
  }
  _ toMapFile(/* No info */) {
    // ** addr: 0x4e3cc4, size: 0xd4
    // 0x4e3cc4: EnterFrame
    //     0x4e3cc4: stp             fp, lr, [SP, #-0x10]!
    //     0x4e3cc8: mov             fp, SP
    // 0x4e3ccc: AllocStack(0x18)
    //     0x4e3ccc: sub             SP, SP, #0x18
    // 0x4e3cd0: SetupParameters(QuestBlock this /* r1 => r0, fp-0x8 */)
    //     0x4e3cd0: mov             x0, x1
    //     0x4e3cd4: stur            x1, [fp, #-8]
    // 0x4e3cd8: CheckStackOverflow
    //     0x4e3cd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e3cdc: cmp             SP, x16
    //     0x4e3ce0: b.ls            #0x4e3d90
    // 0x4e3ce4: r1 = Null
    //     0x4e3ce4: mov             x1, NULL
    // 0x4e3ce8: r2 = 12
    //     0x4e3ce8: movz            x2, #0xc
    // 0x4e3cec: r0 = AllocateArray()
    //     0x4e3cec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e3cf0: mov             x2, x0
    // 0x4e3cf4: StoreField: r2->field_f = rZR
    //     0x4e3cf4: stur            wzr, [x2, #0xf]
    // 0x4e3cf8: ldur            x0, [fp, #-8]
    // 0x4e3cfc: LoadField: r1 = r0->field_7
    //     0x4e3cfc: ldur            w1, [x0, #7]
    // 0x4e3d00: DecompressPointer r1
    //     0x4e3d00: add             x1, x1, HEAP, lsl #32
    // 0x4e3d04: StoreField: r2->field_13 = r1
    //     0x4e3d04: stur            w1, [x2, #0x13]
    // 0x4e3d08: r16 = 2
    //     0x4e3d08: movz            x16, #0x2
    // 0x4e3d0c: ArrayStore: r2[0] = r16  ; List_4
    //     0x4e3d0c: stur            w16, [x2, #0x17]
    // 0x4e3d10: LoadField: r1 = r0->field_b
    //     0x4e3d10: ldur            w1, [x0, #0xb]
    // 0x4e3d14: DecompressPointer r1
    //     0x4e3d14: add             x1, x1, HEAP, lsl #32
    // 0x4e3d18: StoreField: r2->field_1b = r1
    //     0x4e3d18: stur            w1, [x2, #0x1b]
    // 0x4e3d1c: r16 = 4
    //     0x4e3d1c: movz            x16, #0x4
    // 0x4e3d20: StoreField: r2->field_1f = r16
    //     0x4e3d20: stur            w16, [x2, #0x1f]
    // 0x4e3d24: LoadField: r1 = r0->field_f
    //     0x4e3d24: ldur            w1, [x0, #0xf]
    // 0x4e3d28: DecompressPointer r1
    //     0x4e3d28: add             x1, x1, HEAP, lsl #32
    // 0x4e3d2c: cmp             w1, NULL
    // 0x4e3d30: b.ne            #0x4e3d3c
    // 0x4e3d34: r0 = Null
    //     0x4e3d34: mov             x0, NULL
    // 0x4e3d38: b               #0x4e3d70
    // 0x4e3d3c: LoadField: r0 = r1->field_b
    //     0x4e3d3c: ldur            x0, [x1, #0xb]
    // 0x4e3d40: tbz             x0, #0x3f, #0x4e3d4c
    // 0x4e3d44: r3 = 999
    //     0x4e3d44: movz            x3, #0x3e7
    // 0x4e3d48: b               #0x4e3d50
    // 0x4e3d4c: r3 = 0
    //     0x4e3d4c: movz            x3, #0
    // 0x4e3d50: r1 = 1000
    //     0x4e3d50: movz            x1, #0x3e8
    // 0x4e3d54: sub             x4, x0, x3
    // 0x4e3d58: sdiv            x3, x4, x1
    // 0x4e3d5c: r0 = BoxInt64Instr(r3)
    //     0x4e3d5c: sbfiz           x0, x3, #1, #0x1f
    //     0x4e3d60: cmp             x3, x0, asr #1
    //     0x4e3d64: b.eq            #0x4e3d70
    //     0x4e3d68: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e3d6c: stur            x3, [x0, #7]
    // 0x4e3d70: StoreField: r2->field_23 = r0
    //     0x4e3d70: stur            w0, [x2, #0x23]
    // 0x4e3d74: r16 = <int, dynamic>
    //     0x4e3d74: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x4e3d78: ldr             x16, [x16, #0x4f0]
    // 0x4e3d7c: stp             x2, x16, [SP]
    // 0x4e3d80: r0 = Map._fromLiteral()
    //     0x4e3d80: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e3d84: LeaveFrame
    //     0x4e3d84: mov             SP, fp
    //     0x4e3d88: ldp             fp, lr, [SP], #0x10
    // 0x4e3d8c: ret
    //     0x4e3d8c: ret             
    // 0x4e3d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e3d90: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e3d94: b               #0x4e3ce4
  }
  _ reset(/* No info */) {
    // ** addr: 0x81b290, size: 0x50
    // 0x81b290: EnterFrame
    //     0x81b290: stp             fp, lr, [SP, #-0x10]!
    //     0x81b294: mov             fp, SP
    // 0x81b298: AllocStack(0x8)
    //     0x81b298: sub             SP, SP, #8
    // 0x81b29c: SetupParameters(QuestBlock this /* r1 => r0, fp-0x8 */)
    //     0x81b29c: mov             x0, x1
    //     0x81b2a0: stur            x1, [fp, #-8]
    // 0x81b2a4: CheckStackOverflow
    //     0x81b2a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x81b2a8: cmp             SP, x16
    //     0x81b2ac: b.ls            #0x81b2d8
    // 0x81b2b0: StoreField: r0->field_7 = rNULL
    //     0x81b2b0: stur            NULL, [x0, #7]
    // 0x81b2b4: LoadField: r1 = r0->field_b
    //     0x81b2b4: ldur            w1, [x0, #0xb]
    // 0x81b2b8: DecompressPointer r1
    //     0x81b2b8: add             x1, x1, HEAP, lsl #32
    // 0x81b2bc: r0 = clear()
    //     0x81b2bc: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b2c0: ldur            x1, [fp, #-8]
    // 0x81b2c4: StoreField: r1->field_f = rNULL
    //     0x81b2c4: stur            NULL, [x1, #0xf]
    // 0x81b2c8: r0 = Null
    //     0x81b2c8: mov             x0, NULL
    // 0x81b2cc: LeaveFrame
    //     0x81b2cc: mov             SP, fp
    //     0x81b2d0: ldp             fp, lr, [SP], #0x10
    // 0x81b2d4: ret
    //     0x81b2d4: ret             
    // 0x81b2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81b2d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81b2dc: b               #0x81b2b0
  }
}
