// lib: , url: package:pretentious/data/Chapters/GameStateManager.dart

// class id: 1049465, size: 0x8
class :: {

  static late Map<int, IPlayableGameState<dynamic>> gameStates; // offset: 0xf60
  static late Map<String, CustomLevelGameState> customLevels; // offset: 0xf5c

  static _ unauthenticatedName(/* No info */) {
    // ** addr: 0x370344, size: 0x60
    // 0x370344: EnterFrame
    //     0x370344: stp             fp, lr, [SP, #-0x10]!
    //     0x370348: mov             fp, SP
    // 0x37034c: AllocStack(0x10)
    //     0x37034c: sub             SP, SP, #0x10
    // 0x370350: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x370350: mov             x0, x1
    //     0x370354: stur            x1, [fp, #-8]
    // 0x370358: CheckStackOverflow
    //     0x370358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x37035c: cmp             SP, x16
    //     0x370360: b.ls            #0x37039c
    // 0x370364: r1 = Null
    //     0x370364: mov             x1, NULL
    // 0x370368: r2 = 4
    //     0x370368: movz            x2, #0x4
    // 0x37036c: r0 = AllocateArray()
    //     0x37036c: bl              #0x82746c  ; AllocateArrayStub
    // 0x370370: mov             x1, x0
    // 0x370374: ldur            x0, [fp, #-8]
    // 0x370378: StoreField: r1->field_f = r0
    //     0x370378: stur            w0, [x1, #0xf]
    // 0x37037c: r16 = "2"
    //     0x37037c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x370380: ldr             x16, [x16, #0x2e0]
    // 0x370384: StoreField: r1->field_13 = r16
    //     0x370384: stur            w16, [x1, #0x13]
    // 0x370388: str             x1, [SP]
    // 0x37038c: r0 = _interpolate()
    //     0x37038c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x370390: LeaveFrame
    //     0x370390: mov             SP, fp
    //     0x370394: ldp             fp, lr, [SP], #0x10
    // 0x370398: ret
    //     0x370398: ret             
    // 0x37039c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x37039c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3703a0: b               #0x370364
  }
  static _ authenticatedName(/* No info */) {
    // ** addr: 0x3703a4, size: 0x60
    // 0x3703a4: EnterFrame
    //     0x3703a4: stp             fp, lr, [SP, #-0x10]!
    //     0x3703a8: mov             fp, SP
    // 0x3703ac: AllocStack(0x10)
    //     0x3703ac: sub             SP, SP, #0x10
    // 0x3703b0: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x3703b0: mov             x0, x1
    //     0x3703b4: stur            x1, [fp, #-8]
    // 0x3703b8: CheckStackOverflow
    //     0x3703b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3703bc: cmp             SP, x16
    //     0x3703c0: b.ls            #0x3703fc
    // 0x3703c4: r1 = Null
    //     0x3703c4: mov             x1, NULL
    // 0x3703c8: r2 = 4
    //     0x3703c8: movz            x2, #0x4
    // 0x3703cc: r0 = AllocateArray()
    //     0x3703cc: bl              #0x82746c  ; AllocateArrayStub
    // 0x3703d0: mov             x1, x0
    // 0x3703d4: ldur            x0, [fp, #-8]
    // 0x3703d8: StoreField: r1->field_f = r0
    //     0x3703d8: stur            w0, [x1, #0xf]
    // 0x3703dc: r16 = "1"
    //     0x3703dc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x3703e0: ldr             x16, [x16, #0x9c8]
    // 0x3703e4: StoreField: r1->field_13 = r16
    //     0x3703e4: stur            w16, [x1, #0x13]
    // 0x3703e8: str             x1, [SP]
    // 0x3703ec: r0 = _interpolate()
    //     0x3703ec: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x3703f0: LeaveFrame
    //     0x3703f0: mov             SP, fp
    //     0x3703f4: ldp             fp, lr, [SP], #0x10
    // 0x3703f8: ret
    //     0x3703f8: ret             
    // 0x3703fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3703fc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x370400: b               #0x3703c4
  }
  get _ currentActiveState(/* No info */) {
    // ** addr: 0x372284, size: 0xb64
    // 0x372284: EnterFrame
    //     0x372284: stp             fp, lr, [SP, #-0x10]!
    //     0x372288: mov             fp, SP
    // 0x37228c: AllocStack(0x20)
    //     0x37228c: sub             SP, SP, #0x20
    // 0x372290: CheckStackOverflow
    //     0x372290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x372294: cmp             SP, x16
    //     0x372298: b.ls            #0x372d84
    // 0x37229c: r0 = currentChapterName()
    //     0x37229c: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x3722a0: stur            x0, [fp, #-8]
    // 0x3722a4: r16 = "1"
    //     0x3722a4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x3722a8: ldr             x16, [x16, #0x9c8]
    // 0x3722ac: stp             x0, x16, [SP]
    // 0x3722b0: r0 = ==()
    //     0x3722b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3722b4: tbnz            w0, #4, #0x372320
    // 0x3722b8: r0 = LoadStaticField(0xf60)
    //     0x3722b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3722bc: ldr             x0, [x0, #0x1ec0]
    // 0x3722c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3722c4: cmp             w0, w16
    // 0x3722c8: b.ne            #0x3722d8
    // 0x3722cc: r2 = gameStates
    //     0x3722cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3722d0: ldr             x2, [x2, #0x2e8]
    // 0x3722d4: r0 = InitLateStaticField()
    //     0x3722d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3722d8: mov             x1, x0
    // 0x3722dc: r2 = 2
    //     0x3722dc: movz            x2, #0x2
    // 0x3722e0: stur            x0, [fp, #-0x10]
    // 0x3722e4: r0 = _getValueOrData()
    //     0x3722e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3722e8: mov             x1, x0
    // 0x3722ec: ldur            x0, [fp, #-0x10]
    // 0x3722f0: LoadField: r2 = r0->field_f
    //     0x3722f0: ldur            w2, [x0, #0xf]
    // 0x3722f4: DecompressPointer r2
    //     0x3722f4: add             x2, x2, HEAP, lsl #32
    // 0x3722f8: cmp             w2, w1
    // 0x3722fc: b.ne            #0x372308
    // 0x372300: r0 = Null
    //     0x372300: mov             x0, NULL
    // 0x372304: b               #0x37230c
    // 0x372308: mov             x0, x1
    // 0x37230c: cmp             w0, NULL
    // 0x372310: b.eq            #0x372d8c
    // 0x372314: LeaveFrame
    //     0x372314: mov             SP, fp
    //     0x372318: ldp             fp, lr, [SP], #0x10
    // 0x37231c: ret
    //     0x37231c: ret             
    // 0x372320: r16 = "2"
    //     0x372320: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x372324: ldr             x16, [x16, #0x2e0]
    // 0x372328: ldur            lr, [fp, #-8]
    // 0x37232c: stp             lr, x16, [SP]
    // 0x372330: r0 = ==()
    //     0x372330: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372334: tbnz            w0, #4, #0x3723a0
    // 0x372338: r0 = LoadStaticField(0xf60)
    //     0x372338: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37233c: ldr             x0, [x0, #0x1ec0]
    // 0x372340: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372344: cmp             w0, w16
    // 0x372348: b.ne            #0x372358
    // 0x37234c: r2 = gameStates
    //     0x37234c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372350: ldr             x2, [x2, #0x2e8]
    // 0x372354: r0 = InitLateStaticField()
    //     0x372354: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372358: mov             x1, x0
    // 0x37235c: r2 = 4
    //     0x37235c: movz            x2, #0x4
    // 0x372360: stur            x0, [fp, #-0x10]
    // 0x372364: r0 = _getValueOrData()
    //     0x372364: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372368: mov             x1, x0
    // 0x37236c: ldur            x0, [fp, #-0x10]
    // 0x372370: LoadField: r2 = r0->field_f
    //     0x372370: ldur            w2, [x0, #0xf]
    // 0x372374: DecompressPointer r2
    //     0x372374: add             x2, x2, HEAP, lsl #32
    // 0x372378: cmp             w2, w1
    // 0x37237c: b.ne            #0x372388
    // 0x372380: r0 = Null
    //     0x372380: mov             x0, NULL
    // 0x372384: b               #0x37238c
    // 0x372388: mov             x0, x1
    // 0x37238c: cmp             w0, NULL
    // 0x372390: b.eq            #0x372d90
    // 0x372394: LeaveFrame
    //     0x372394: mov             SP, fp
    //     0x372398: ldp             fp, lr, [SP], #0x10
    // 0x37239c: ret
    //     0x37239c: ret             
    // 0x3723a0: r16 = "3"
    //     0x3723a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x3723a4: ldr             x16, [x16, #0x2f0]
    // 0x3723a8: ldur            lr, [fp, #-8]
    // 0x3723ac: stp             lr, x16, [SP]
    // 0x3723b0: r0 = ==()
    //     0x3723b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3723b4: tbnz            w0, #4, #0x372420
    // 0x3723b8: r0 = LoadStaticField(0xf60)
    //     0x3723b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3723bc: ldr             x0, [x0, #0x1ec0]
    // 0x3723c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3723c4: cmp             w0, w16
    // 0x3723c8: b.ne            #0x3723d8
    // 0x3723cc: r2 = gameStates
    //     0x3723cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3723d0: ldr             x2, [x2, #0x2e8]
    // 0x3723d4: r0 = InitLateStaticField()
    //     0x3723d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3723d8: mov             x1, x0
    // 0x3723dc: r2 = 6
    //     0x3723dc: movz            x2, #0x6
    // 0x3723e0: stur            x0, [fp, #-0x10]
    // 0x3723e4: r0 = _getValueOrData()
    //     0x3723e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3723e8: mov             x1, x0
    // 0x3723ec: ldur            x0, [fp, #-0x10]
    // 0x3723f0: LoadField: r2 = r0->field_f
    //     0x3723f0: ldur            w2, [x0, #0xf]
    // 0x3723f4: DecompressPointer r2
    //     0x3723f4: add             x2, x2, HEAP, lsl #32
    // 0x3723f8: cmp             w2, w1
    // 0x3723fc: b.ne            #0x372408
    // 0x372400: r0 = Null
    //     0x372400: mov             x0, NULL
    // 0x372404: b               #0x37240c
    // 0x372408: mov             x0, x1
    // 0x37240c: cmp             w0, NULL
    // 0x372410: b.eq            #0x372d94
    // 0x372414: LeaveFrame
    //     0x372414: mov             SP, fp
    //     0x372418: ldp             fp, lr, [SP], #0x10
    // 0x37241c: ret
    //     0x37241c: ret             
    // 0x372420: r16 = "4"
    //     0x372420: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x372424: ldr             x16, [x16, #0x2f8]
    // 0x372428: ldur            lr, [fp, #-8]
    // 0x37242c: stp             lr, x16, [SP]
    // 0x372430: r0 = ==()
    //     0x372430: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372434: tbnz            w0, #4, #0x3724a0
    // 0x372438: r0 = LoadStaticField(0xf60)
    //     0x372438: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37243c: ldr             x0, [x0, #0x1ec0]
    // 0x372440: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372444: cmp             w0, w16
    // 0x372448: b.ne            #0x372458
    // 0x37244c: r2 = gameStates
    //     0x37244c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372450: ldr             x2, [x2, #0x2e8]
    // 0x372454: r0 = InitLateStaticField()
    //     0x372454: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372458: mov             x1, x0
    // 0x37245c: r2 = 8
    //     0x37245c: movz            x2, #0x8
    // 0x372460: stur            x0, [fp, #-0x10]
    // 0x372464: r0 = _getValueOrData()
    //     0x372464: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372468: mov             x1, x0
    // 0x37246c: ldur            x0, [fp, #-0x10]
    // 0x372470: LoadField: r2 = r0->field_f
    //     0x372470: ldur            w2, [x0, #0xf]
    // 0x372474: DecompressPointer r2
    //     0x372474: add             x2, x2, HEAP, lsl #32
    // 0x372478: cmp             w2, w1
    // 0x37247c: b.ne            #0x372488
    // 0x372480: r0 = Null
    //     0x372480: mov             x0, NULL
    // 0x372484: b               #0x37248c
    // 0x372488: mov             x0, x1
    // 0x37248c: cmp             w0, NULL
    // 0x372490: b.eq            #0x372d98
    // 0x372494: LeaveFrame
    //     0x372494: mov             SP, fp
    //     0x372498: ldp             fp, lr, [SP], #0x10
    // 0x37249c: ret
    //     0x37249c: ret             
    // 0x3724a0: r16 = "5"
    //     0x3724a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x3724a4: ldr             x16, [x16, #0x300]
    // 0x3724a8: ldur            lr, [fp, #-8]
    // 0x3724ac: stp             lr, x16, [SP]
    // 0x3724b0: r0 = ==()
    //     0x3724b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3724b4: tbnz            w0, #4, #0x372520
    // 0x3724b8: r0 = LoadStaticField(0xf60)
    //     0x3724b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3724bc: ldr             x0, [x0, #0x1ec0]
    // 0x3724c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3724c4: cmp             w0, w16
    // 0x3724c8: b.ne            #0x3724d8
    // 0x3724cc: r2 = gameStates
    //     0x3724cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3724d0: ldr             x2, [x2, #0x2e8]
    // 0x3724d4: r0 = InitLateStaticField()
    //     0x3724d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3724d8: mov             x1, x0
    // 0x3724dc: r2 = 10
    //     0x3724dc: movz            x2, #0xa
    // 0x3724e0: stur            x0, [fp, #-0x10]
    // 0x3724e4: r0 = _getValueOrData()
    //     0x3724e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3724e8: mov             x1, x0
    // 0x3724ec: ldur            x0, [fp, #-0x10]
    // 0x3724f0: LoadField: r2 = r0->field_f
    //     0x3724f0: ldur            w2, [x0, #0xf]
    // 0x3724f4: DecompressPointer r2
    //     0x3724f4: add             x2, x2, HEAP, lsl #32
    // 0x3724f8: cmp             w2, w1
    // 0x3724fc: b.ne            #0x372508
    // 0x372500: r0 = Null
    //     0x372500: mov             x0, NULL
    // 0x372504: b               #0x37250c
    // 0x372508: mov             x0, x1
    // 0x37250c: cmp             w0, NULL
    // 0x372510: b.eq            #0x372d9c
    // 0x372514: LeaveFrame
    //     0x372514: mov             SP, fp
    //     0x372518: ldp             fp, lr, [SP], #0x10
    // 0x37251c: ret
    //     0x37251c: ret             
    // 0x372520: r16 = "6"
    //     0x372520: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x372524: ldr             x16, [x16, #0x308]
    // 0x372528: ldur            lr, [fp, #-8]
    // 0x37252c: stp             lr, x16, [SP]
    // 0x372530: r0 = ==()
    //     0x372530: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372534: tbnz            w0, #4, #0x3725a0
    // 0x372538: r0 = LoadStaticField(0xf60)
    //     0x372538: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37253c: ldr             x0, [x0, #0x1ec0]
    // 0x372540: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372544: cmp             w0, w16
    // 0x372548: b.ne            #0x372558
    // 0x37254c: r2 = gameStates
    //     0x37254c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372550: ldr             x2, [x2, #0x2e8]
    // 0x372554: r0 = InitLateStaticField()
    //     0x372554: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372558: mov             x1, x0
    // 0x37255c: r2 = 12
    //     0x37255c: movz            x2, #0xc
    // 0x372560: stur            x0, [fp, #-0x10]
    // 0x372564: r0 = _getValueOrData()
    //     0x372564: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372568: mov             x1, x0
    // 0x37256c: ldur            x0, [fp, #-0x10]
    // 0x372570: LoadField: r2 = r0->field_f
    //     0x372570: ldur            w2, [x0, #0xf]
    // 0x372574: DecompressPointer r2
    //     0x372574: add             x2, x2, HEAP, lsl #32
    // 0x372578: cmp             w2, w1
    // 0x37257c: b.ne            #0x372588
    // 0x372580: r0 = Null
    //     0x372580: mov             x0, NULL
    // 0x372584: b               #0x37258c
    // 0x372588: mov             x0, x1
    // 0x37258c: cmp             w0, NULL
    // 0x372590: b.eq            #0x372da0
    // 0x372594: LeaveFrame
    //     0x372594: mov             SP, fp
    //     0x372598: ldp             fp, lr, [SP], #0x10
    // 0x37259c: ret
    //     0x37259c: ret             
    // 0x3725a0: r16 = "7"
    //     0x3725a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x3725a4: ldr             x16, [x16, #0x310]
    // 0x3725a8: ldur            lr, [fp, #-8]
    // 0x3725ac: stp             lr, x16, [SP]
    // 0x3725b0: r0 = ==()
    //     0x3725b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3725b4: tbnz            w0, #4, #0x372620
    // 0x3725b8: r0 = LoadStaticField(0xf60)
    //     0x3725b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3725bc: ldr             x0, [x0, #0x1ec0]
    // 0x3725c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3725c4: cmp             w0, w16
    // 0x3725c8: b.ne            #0x3725d8
    // 0x3725cc: r2 = gameStates
    //     0x3725cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3725d0: ldr             x2, [x2, #0x2e8]
    // 0x3725d4: r0 = InitLateStaticField()
    //     0x3725d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3725d8: mov             x1, x0
    // 0x3725dc: r2 = 14
    //     0x3725dc: movz            x2, #0xe
    // 0x3725e0: stur            x0, [fp, #-0x10]
    // 0x3725e4: r0 = _getValueOrData()
    //     0x3725e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3725e8: mov             x1, x0
    // 0x3725ec: ldur            x0, [fp, #-0x10]
    // 0x3725f0: LoadField: r2 = r0->field_f
    //     0x3725f0: ldur            w2, [x0, #0xf]
    // 0x3725f4: DecompressPointer r2
    //     0x3725f4: add             x2, x2, HEAP, lsl #32
    // 0x3725f8: cmp             w2, w1
    // 0x3725fc: b.ne            #0x372608
    // 0x372600: r0 = Null
    //     0x372600: mov             x0, NULL
    // 0x372604: b               #0x37260c
    // 0x372608: mov             x0, x1
    // 0x37260c: cmp             w0, NULL
    // 0x372610: b.eq            #0x372da4
    // 0x372614: LeaveFrame
    //     0x372614: mov             SP, fp
    //     0x372618: ldp             fp, lr, [SP], #0x10
    // 0x37261c: ret
    //     0x37261c: ret             
    // 0x372620: r16 = "8"
    //     0x372620: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x372624: ldr             x16, [x16, #0x318]
    // 0x372628: ldur            lr, [fp, #-8]
    // 0x37262c: stp             lr, x16, [SP]
    // 0x372630: r0 = ==()
    //     0x372630: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372634: tbnz            w0, #4, #0x3726a0
    // 0x372638: r0 = LoadStaticField(0xf60)
    //     0x372638: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37263c: ldr             x0, [x0, #0x1ec0]
    // 0x372640: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372644: cmp             w0, w16
    // 0x372648: b.ne            #0x372658
    // 0x37264c: r2 = gameStates
    //     0x37264c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372650: ldr             x2, [x2, #0x2e8]
    // 0x372654: r0 = InitLateStaticField()
    //     0x372654: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372658: mov             x1, x0
    // 0x37265c: r2 = 16
    //     0x37265c: movz            x2, #0x10
    // 0x372660: stur            x0, [fp, #-0x10]
    // 0x372664: r0 = _getValueOrData()
    //     0x372664: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372668: mov             x1, x0
    // 0x37266c: ldur            x0, [fp, #-0x10]
    // 0x372670: LoadField: r2 = r0->field_f
    //     0x372670: ldur            w2, [x0, #0xf]
    // 0x372674: DecompressPointer r2
    //     0x372674: add             x2, x2, HEAP, lsl #32
    // 0x372678: cmp             w2, w1
    // 0x37267c: b.ne            #0x372688
    // 0x372680: r0 = Null
    //     0x372680: mov             x0, NULL
    // 0x372684: b               #0x37268c
    // 0x372688: mov             x0, x1
    // 0x37268c: cmp             w0, NULL
    // 0x372690: b.eq            #0x372da8
    // 0x372694: LeaveFrame
    //     0x372694: mov             SP, fp
    //     0x372698: ldp             fp, lr, [SP], #0x10
    // 0x37269c: ret
    //     0x37269c: ret             
    // 0x3726a0: r16 = "9"
    //     0x3726a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x3726a4: ldr             x16, [x16, #0x320]
    // 0x3726a8: ldur            lr, [fp, #-8]
    // 0x3726ac: stp             lr, x16, [SP]
    // 0x3726b0: r0 = ==()
    //     0x3726b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3726b4: tbnz            w0, #4, #0x372720
    // 0x3726b8: r0 = LoadStaticField(0xf60)
    //     0x3726b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3726bc: ldr             x0, [x0, #0x1ec0]
    // 0x3726c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3726c4: cmp             w0, w16
    // 0x3726c8: b.ne            #0x3726d8
    // 0x3726cc: r2 = gameStates
    //     0x3726cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3726d0: ldr             x2, [x2, #0x2e8]
    // 0x3726d4: r0 = InitLateStaticField()
    //     0x3726d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3726d8: mov             x1, x0
    // 0x3726dc: r2 = 18
    //     0x3726dc: movz            x2, #0x12
    // 0x3726e0: stur            x0, [fp, #-0x10]
    // 0x3726e4: r0 = _getValueOrData()
    //     0x3726e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3726e8: mov             x1, x0
    // 0x3726ec: ldur            x0, [fp, #-0x10]
    // 0x3726f0: LoadField: r2 = r0->field_f
    //     0x3726f0: ldur            w2, [x0, #0xf]
    // 0x3726f4: DecompressPointer r2
    //     0x3726f4: add             x2, x2, HEAP, lsl #32
    // 0x3726f8: cmp             w2, w1
    // 0x3726fc: b.ne            #0x372708
    // 0x372700: r0 = Null
    //     0x372700: mov             x0, NULL
    // 0x372704: b               #0x37270c
    // 0x372708: mov             x0, x1
    // 0x37270c: cmp             w0, NULL
    // 0x372710: b.eq            #0x372dac
    // 0x372714: LeaveFrame
    //     0x372714: mov             SP, fp
    //     0x372718: ldp             fp, lr, [SP], #0x10
    // 0x37271c: ret
    //     0x37271c: ret             
    // 0x372720: r16 = "10"
    //     0x372720: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x372724: ldr             x16, [x16, #0x9d0]
    // 0x372728: ldur            lr, [fp, #-8]
    // 0x37272c: stp             lr, x16, [SP]
    // 0x372730: r0 = ==()
    //     0x372730: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372734: tbnz            w0, #4, #0x3727a0
    // 0x372738: r0 = LoadStaticField(0xf60)
    //     0x372738: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37273c: ldr             x0, [x0, #0x1ec0]
    // 0x372740: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372744: cmp             w0, w16
    // 0x372748: b.ne            #0x372758
    // 0x37274c: r2 = gameStates
    //     0x37274c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372750: ldr             x2, [x2, #0x2e8]
    // 0x372754: r0 = InitLateStaticField()
    //     0x372754: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372758: mov             x1, x0
    // 0x37275c: r2 = 20
    //     0x37275c: movz            x2, #0x14
    // 0x372760: stur            x0, [fp, #-0x10]
    // 0x372764: r0 = _getValueOrData()
    //     0x372764: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372768: mov             x1, x0
    // 0x37276c: ldur            x0, [fp, #-0x10]
    // 0x372770: LoadField: r2 = r0->field_f
    //     0x372770: ldur            w2, [x0, #0xf]
    // 0x372774: DecompressPointer r2
    //     0x372774: add             x2, x2, HEAP, lsl #32
    // 0x372778: cmp             w2, w1
    // 0x37277c: b.ne            #0x372788
    // 0x372780: r0 = Null
    //     0x372780: mov             x0, NULL
    // 0x372784: b               #0x37278c
    // 0x372788: mov             x0, x1
    // 0x37278c: cmp             w0, NULL
    // 0x372790: b.eq            #0x372db0
    // 0x372794: LeaveFrame
    //     0x372794: mov             SP, fp
    //     0x372798: ldp             fp, lr, [SP], #0x10
    // 0x37279c: ret
    //     0x37279c: ret             
    // 0x3727a0: r16 = "11"
    //     0x3727a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x3727a4: ldr             x16, [x16, #0x328]
    // 0x3727a8: ldur            lr, [fp, #-8]
    // 0x3727ac: stp             lr, x16, [SP]
    // 0x3727b0: r0 = ==()
    //     0x3727b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3727b4: tbnz            w0, #4, #0x372820
    // 0x3727b8: r0 = LoadStaticField(0xf60)
    //     0x3727b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3727bc: ldr             x0, [x0, #0x1ec0]
    // 0x3727c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3727c4: cmp             w0, w16
    // 0x3727c8: b.ne            #0x3727d8
    // 0x3727cc: r2 = gameStates
    //     0x3727cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3727d0: ldr             x2, [x2, #0x2e8]
    // 0x3727d4: r0 = InitLateStaticField()
    //     0x3727d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3727d8: mov             x1, x0
    // 0x3727dc: r2 = 22
    //     0x3727dc: movz            x2, #0x16
    // 0x3727e0: stur            x0, [fp, #-0x10]
    // 0x3727e4: r0 = _getValueOrData()
    //     0x3727e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3727e8: mov             x1, x0
    // 0x3727ec: ldur            x0, [fp, #-0x10]
    // 0x3727f0: LoadField: r2 = r0->field_f
    //     0x3727f0: ldur            w2, [x0, #0xf]
    // 0x3727f4: DecompressPointer r2
    //     0x3727f4: add             x2, x2, HEAP, lsl #32
    // 0x3727f8: cmp             w2, w1
    // 0x3727fc: b.ne            #0x372808
    // 0x372800: r0 = Null
    //     0x372800: mov             x0, NULL
    // 0x372804: b               #0x37280c
    // 0x372808: mov             x0, x1
    // 0x37280c: cmp             w0, NULL
    // 0x372810: b.eq            #0x372db4
    // 0x372814: LeaveFrame
    //     0x372814: mov             SP, fp
    //     0x372818: ldp             fp, lr, [SP], #0x10
    // 0x37281c: ret
    //     0x37281c: ret             
    // 0x372820: r16 = "12"
    //     0x372820: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x372824: ldr             x16, [x16, #0x330]
    // 0x372828: ldur            lr, [fp, #-8]
    // 0x37282c: stp             lr, x16, [SP]
    // 0x372830: r0 = ==()
    //     0x372830: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372834: tbnz            w0, #4, #0x3728a0
    // 0x372838: r0 = LoadStaticField(0xf60)
    //     0x372838: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37283c: ldr             x0, [x0, #0x1ec0]
    // 0x372840: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372844: cmp             w0, w16
    // 0x372848: b.ne            #0x372858
    // 0x37284c: r2 = gameStates
    //     0x37284c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372850: ldr             x2, [x2, #0x2e8]
    // 0x372854: r0 = InitLateStaticField()
    //     0x372854: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372858: mov             x1, x0
    // 0x37285c: r2 = 24
    //     0x37285c: movz            x2, #0x18
    // 0x372860: stur            x0, [fp, #-0x10]
    // 0x372864: r0 = _getValueOrData()
    //     0x372864: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372868: mov             x1, x0
    // 0x37286c: ldur            x0, [fp, #-0x10]
    // 0x372870: LoadField: r2 = r0->field_f
    //     0x372870: ldur            w2, [x0, #0xf]
    // 0x372874: DecompressPointer r2
    //     0x372874: add             x2, x2, HEAP, lsl #32
    // 0x372878: cmp             w2, w1
    // 0x37287c: b.ne            #0x372888
    // 0x372880: r0 = Null
    //     0x372880: mov             x0, NULL
    // 0x372884: b               #0x37288c
    // 0x372888: mov             x0, x1
    // 0x37288c: cmp             w0, NULL
    // 0x372890: b.eq            #0x372db8
    // 0x372894: LeaveFrame
    //     0x372894: mov             SP, fp
    //     0x372898: ldp             fp, lr, [SP], #0x10
    // 0x37289c: ret
    //     0x37289c: ret             
    // 0x3728a0: r16 = "13"
    //     0x3728a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x3728a4: ldr             x16, [x16, #0x338]
    // 0x3728a8: ldur            lr, [fp, #-8]
    // 0x3728ac: stp             lr, x16, [SP]
    // 0x3728b0: r0 = ==()
    //     0x3728b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3728b4: tbnz            w0, #4, #0x372920
    // 0x3728b8: r0 = LoadStaticField(0xf60)
    //     0x3728b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3728bc: ldr             x0, [x0, #0x1ec0]
    // 0x3728c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3728c4: cmp             w0, w16
    // 0x3728c8: b.ne            #0x3728d8
    // 0x3728cc: r2 = gameStates
    //     0x3728cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3728d0: ldr             x2, [x2, #0x2e8]
    // 0x3728d4: r0 = InitLateStaticField()
    //     0x3728d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3728d8: mov             x1, x0
    // 0x3728dc: r2 = 26
    //     0x3728dc: movz            x2, #0x1a
    // 0x3728e0: stur            x0, [fp, #-0x10]
    // 0x3728e4: r0 = _getValueOrData()
    //     0x3728e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3728e8: mov             x1, x0
    // 0x3728ec: ldur            x0, [fp, #-0x10]
    // 0x3728f0: LoadField: r2 = r0->field_f
    //     0x3728f0: ldur            w2, [x0, #0xf]
    // 0x3728f4: DecompressPointer r2
    //     0x3728f4: add             x2, x2, HEAP, lsl #32
    // 0x3728f8: cmp             w2, w1
    // 0x3728fc: b.ne            #0x372908
    // 0x372900: r0 = Null
    //     0x372900: mov             x0, NULL
    // 0x372904: b               #0x37290c
    // 0x372908: mov             x0, x1
    // 0x37290c: cmp             w0, NULL
    // 0x372910: b.eq            #0x372dbc
    // 0x372914: LeaveFrame
    //     0x372914: mov             SP, fp
    //     0x372918: ldp             fp, lr, [SP], #0x10
    // 0x37291c: ret
    //     0x37291c: ret             
    // 0x372920: r16 = "14"
    //     0x372920: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x372924: ldr             x16, [x16, #0x340]
    // 0x372928: ldur            lr, [fp, #-8]
    // 0x37292c: stp             lr, x16, [SP]
    // 0x372930: r0 = ==()
    //     0x372930: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372934: tbnz            w0, #4, #0x3729a0
    // 0x372938: r0 = LoadStaticField(0xf60)
    //     0x372938: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x37293c: ldr             x0, [x0, #0x1ec0]
    // 0x372940: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372944: cmp             w0, w16
    // 0x372948: b.ne            #0x372958
    // 0x37294c: r2 = gameStates
    //     0x37294c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372950: ldr             x2, [x2, #0x2e8]
    // 0x372954: r0 = InitLateStaticField()
    //     0x372954: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372958: mov             x1, x0
    // 0x37295c: r2 = 28
    //     0x37295c: movz            x2, #0x1c
    // 0x372960: stur            x0, [fp, #-0x10]
    // 0x372964: r0 = _getValueOrData()
    //     0x372964: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372968: mov             x1, x0
    // 0x37296c: ldur            x0, [fp, #-0x10]
    // 0x372970: LoadField: r2 = r0->field_f
    //     0x372970: ldur            w2, [x0, #0xf]
    // 0x372974: DecompressPointer r2
    //     0x372974: add             x2, x2, HEAP, lsl #32
    // 0x372978: cmp             w2, w1
    // 0x37297c: b.ne            #0x372988
    // 0x372980: r0 = Null
    //     0x372980: mov             x0, NULL
    // 0x372984: b               #0x37298c
    // 0x372988: mov             x0, x1
    // 0x37298c: cmp             w0, NULL
    // 0x372990: b.eq            #0x372dc0
    // 0x372994: LeaveFrame
    //     0x372994: mov             SP, fp
    //     0x372998: ldp             fp, lr, [SP], #0x10
    // 0x37299c: ret
    //     0x37299c: ret             
    // 0x3729a0: r16 = "15"
    //     0x3729a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x3729a4: ldr             x16, [x16, #0x348]
    // 0x3729a8: ldur            lr, [fp, #-8]
    // 0x3729ac: stp             lr, x16, [SP]
    // 0x3729b0: r0 = ==()
    //     0x3729b0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x3729b4: tbnz            w0, #4, #0x372a20
    // 0x3729b8: r0 = LoadStaticField(0xf60)
    //     0x3729b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x3729bc: ldr             x0, [x0, #0x1ec0]
    // 0x3729c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x3729c4: cmp             w0, w16
    // 0x3729c8: b.ne            #0x3729d8
    // 0x3729cc: r2 = gameStates
    //     0x3729cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x3729d0: ldr             x2, [x2, #0x2e8]
    // 0x3729d4: r0 = InitLateStaticField()
    //     0x3729d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x3729d8: mov             x1, x0
    // 0x3729dc: r2 = 30
    //     0x3729dc: movz            x2, #0x1e
    // 0x3729e0: stur            x0, [fp, #-0x10]
    // 0x3729e4: r0 = _getValueOrData()
    //     0x3729e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x3729e8: mov             x1, x0
    // 0x3729ec: ldur            x0, [fp, #-0x10]
    // 0x3729f0: LoadField: r2 = r0->field_f
    //     0x3729f0: ldur            w2, [x0, #0xf]
    // 0x3729f4: DecompressPointer r2
    //     0x3729f4: add             x2, x2, HEAP, lsl #32
    // 0x3729f8: cmp             w2, w1
    // 0x3729fc: b.ne            #0x372a08
    // 0x372a00: r0 = Null
    //     0x372a00: mov             x0, NULL
    // 0x372a04: b               #0x372a0c
    // 0x372a08: mov             x0, x1
    // 0x372a0c: cmp             w0, NULL
    // 0x372a10: b.eq            #0x372dc4
    // 0x372a14: LeaveFrame
    //     0x372a14: mov             SP, fp
    //     0x372a18: ldp             fp, lr, [SP], #0x10
    // 0x372a1c: ret
    //     0x372a1c: ret             
    // 0x372a20: r16 = "16"
    //     0x372a20: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x372a24: ldr             x16, [x16, #0x350]
    // 0x372a28: ldur            lr, [fp, #-8]
    // 0x372a2c: stp             lr, x16, [SP]
    // 0x372a30: r0 = ==()
    //     0x372a30: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372a34: tbnz            w0, #4, #0x372aa0
    // 0x372a38: r0 = LoadStaticField(0xf60)
    //     0x372a38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372a3c: ldr             x0, [x0, #0x1ec0]
    // 0x372a40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372a44: cmp             w0, w16
    // 0x372a48: b.ne            #0x372a58
    // 0x372a4c: r2 = gameStates
    //     0x372a4c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372a50: ldr             x2, [x2, #0x2e8]
    // 0x372a54: r0 = InitLateStaticField()
    //     0x372a54: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372a58: mov             x1, x0
    // 0x372a5c: r2 = 32
    //     0x372a5c: movz            x2, #0x20
    // 0x372a60: stur            x0, [fp, #-0x10]
    // 0x372a64: r0 = _getValueOrData()
    //     0x372a64: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372a68: mov             x1, x0
    // 0x372a6c: ldur            x0, [fp, #-0x10]
    // 0x372a70: LoadField: r2 = r0->field_f
    //     0x372a70: ldur            w2, [x0, #0xf]
    // 0x372a74: DecompressPointer r2
    //     0x372a74: add             x2, x2, HEAP, lsl #32
    // 0x372a78: cmp             w2, w1
    // 0x372a7c: b.ne            #0x372a88
    // 0x372a80: r0 = Null
    //     0x372a80: mov             x0, NULL
    // 0x372a84: b               #0x372a8c
    // 0x372a88: mov             x0, x1
    // 0x372a8c: cmp             w0, NULL
    // 0x372a90: b.eq            #0x372dc8
    // 0x372a94: LeaveFrame
    //     0x372a94: mov             SP, fp
    //     0x372a98: ldp             fp, lr, [SP], #0x10
    // 0x372a9c: ret
    //     0x372a9c: ret             
    // 0x372aa0: r16 = "17"
    //     0x372aa0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x372aa4: ldr             x16, [x16, #0x358]
    // 0x372aa8: ldur            lr, [fp, #-8]
    // 0x372aac: stp             lr, x16, [SP]
    // 0x372ab0: r0 = ==()
    //     0x372ab0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372ab4: tbnz            w0, #4, #0x372b20
    // 0x372ab8: r0 = LoadStaticField(0xf60)
    //     0x372ab8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372abc: ldr             x0, [x0, #0x1ec0]
    // 0x372ac0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372ac4: cmp             w0, w16
    // 0x372ac8: b.ne            #0x372ad8
    // 0x372acc: r2 = gameStates
    //     0x372acc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372ad0: ldr             x2, [x2, #0x2e8]
    // 0x372ad4: r0 = InitLateStaticField()
    //     0x372ad4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372ad8: mov             x1, x0
    // 0x372adc: r2 = 34
    //     0x372adc: movz            x2, #0x22
    // 0x372ae0: stur            x0, [fp, #-0x10]
    // 0x372ae4: r0 = _getValueOrData()
    //     0x372ae4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372ae8: mov             x1, x0
    // 0x372aec: ldur            x0, [fp, #-0x10]
    // 0x372af0: LoadField: r2 = r0->field_f
    //     0x372af0: ldur            w2, [x0, #0xf]
    // 0x372af4: DecompressPointer r2
    //     0x372af4: add             x2, x2, HEAP, lsl #32
    // 0x372af8: cmp             w2, w1
    // 0x372afc: b.ne            #0x372b08
    // 0x372b00: r0 = Null
    //     0x372b00: mov             x0, NULL
    // 0x372b04: b               #0x372b0c
    // 0x372b08: mov             x0, x1
    // 0x372b0c: cmp             w0, NULL
    // 0x372b10: b.eq            #0x372dcc
    // 0x372b14: LeaveFrame
    //     0x372b14: mov             SP, fp
    //     0x372b18: ldp             fp, lr, [SP], #0x10
    // 0x372b1c: ret
    //     0x372b1c: ret             
    // 0x372b20: r16 = "Level Editor"
    //     0x372b20: add             x16, PP, #0xf, lsl #12  ; [pp+0xf360] "Level Editor"
    //     0x372b24: ldr             x16, [x16, #0x360]
    // 0x372b28: ldur            lr, [fp, #-8]
    // 0x372b2c: stp             lr, x16, [SP]
    // 0x372b30: r0 = ==()
    //     0x372b30: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x372b34: tbnz            w0, #4, #0x372bbc
    // 0x372b38: r0 = LoadStaticField(0xf64)
    //     0x372b38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372b3c: ldr             x0, [x0, #0x1ec8]
    // 0x372b40: cmp             w0, NULL
    // 0x372b44: b.ne            #0x372bb0
    // 0x372b48: r0 = LoadStaticField(0xf60)
    //     0x372b48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372b4c: ldr             x0, [x0, #0x1ec0]
    // 0x372b50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372b54: cmp             w0, w16
    // 0x372b58: b.ne            #0x372b68
    // 0x372b5c: r2 = gameStates
    //     0x372b5c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372b60: ldr             x2, [x2, #0x2e8]
    // 0x372b64: r0 = InitLateStaticField()
    //     0x372b64: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372b68: mov             x1, x0
    // 0x372b6c: r2 = 2
    //     0x372b6c: movz            x2, #0x2
    // 0x372b70: stur            x0, [fp, #-8]
    // 0x372b74: r0 = _getValueOrData()
    //     0x372b74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372b78: mov             x1, x0
    // 0x372b7c: ldur            x0, [fp, #-8]
    // 0x372b80: LoadField: r2 = r0->field_f
    //     0x372b80: ldur            w2, [x0, #0xf]
    // 0x372b84: DecompressPointer r2
    //     0x372b84: add             x2, x2, HEAP, lsl #32
    // 0x372b88: cmp             w2, w1
    // 0x372b8c: b.ne            #0x372b98
    // 0x372b90: r0 = Null
    //     0x372b90: mov             x0, NULL
    // 0x372b94: b               #0x372b9c
    // 0x372b98: mov             x0, x1
    // 0x372b9c: cmp             w0, NULL
    // 0x372ba0: b.eq            #0x372dd0
    // 0x372ba4: LeaveFrame
    //     0x372ba4: mov             SP, fp
    //     0x372ba8: ldp             fp, lr, [SP], #0x10
    // 0x372bac: ret
    //     0x372bac: ret             
    // 0x372bb0: LeaveFrame
    //     0x372bb0: mov             SP, fp
    //     0x372bb4: ldp             fp, lr, [SP], #0x10
    // 0x372bb8: ret
    //     0x372bb8: ret             
    // 0x372bbc: r0 = LoadStaticField(0xf5c)
    //     0x372bbc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372bc0: ldr             x0, [x0, #0x1eb8]
    // 0x372bc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372bc8: cmp             w0, w16
    // 0x372bcc: b.ne            #0x372bdc
    // 0x372bd0: r2 = customLevels
    //     0x372bd0: add             x2, PP, #0xf, lsl #12  ; [pp+0xf368] Field <::.customLevels>: static late (offset: 0xf5c)
    //     0x372bd4: ldr             x2, [x2, #0x368]
    // 0x372bd8: r0 = InitLateStaticField()
    //     0x372bd8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372bdc: stur            x0, [fp, #-8]
    // 0x372be0: r0 = currentChapterName()
    //     0x372be0: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x372be4: ldur            x1, [fp, #-8]
    // 0x372be8: mov             x2, x0
    // 0x372bec: r0 = containsKey()
    //     0x372bec: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x372bf0: tbnz            w0, #4, #0x372c48
    // 0x372bf4: r1 = LoadStaticField(0xf5c)
    //     0x372bf4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x372bf8: ldr             x1, [x1, #0x1eb8]
    // 0x372bfc: stur            x1, [fp, #-8]
    // 0x372c00: r0 = currentChapterName()
    //     0x372c00: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x372c04: ldur            x1, [fp, #-8]
    // 0x372c08: mov             x2, x0
    // 0x372c0c: r0 = _getValueOrData()
    //     0x372c0c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372c10: mov             x1, x0
    // 0x372c14: ldur            x0, [fp, #-8]
    // 0x372c18: LoadField: r2 = r0->field_f
    //     0x372c18: ldur            w2, [x0, #0xf]
    // 0x372c1c: DecompressPointer r2
    //     0x372c1c: add             x2, x2, HEAP, lsl #32
    // 0x372c20: cmp             w2, w1
    // 0x372c24: b.ne            #0x372c30
    // 0x372c28: r0 = Null
    //     0x372c28: mov             x0, NULL
    // 0x372c2c: b               #0x372c34
    // 0x372c30: mov             x0, x1
    // 0x372c34: cmp             w0, NULL
    // 0x372c38: b.eq            #0x372dd4
    // 0x372c3c: LeaveFrame
    //     0x372c3c: mov             SP, fp
    //     0x372c40: ldp             fp, lr, [SP], #0x10
    // 0x372c44: ret
    //     0x372c44: ret             
    // 0x372c48: r1 = Null
    //     0x372c48: mov             x1, NULL
    // 0x372c4c: r2 = 10
    //     0x372c4c: movz            x2, #0xa
    // 0x372c50: r0 = AllocateArray()
    //     0x372c50: bl              #0x82746c  ; AllocateArrayStub
    // 0x372c54: stur            x0, [fp, #-8]
    // 0x372c58: r16 = "Unknown chapter: "
    //     0x372c58: add             x16, PP, #0xf, lsl #12  ; [pp+0xf370] "Unknown chapter: "
    //     0x372c5c: ldr             x16, [x16, #0x370]
    // 0x372c60: StoreField: r0->field_f = r16
    //     0x372c60: stur            w16, [x0, #0xf]
    // 0x372c64: r0 = currentChapterName()
    //     0x372c64: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x372c68: ldur            x1, [fp, #-8]
    // 0x372c6c: ArrayStore: r1[1] = r0  ; List_4
    //     0x372c6c: add             x25, x1, #0x13
    //     0x372c70: str             w0, [x25]
    //     0x372c74: tbz             w0, #0, #0x372c90
    //     0x372c78: ldurb           w16, [x1, #-1]
    //     0x372c7c: ldurb           w17, [x0, #-1]
    //     0x372c80: and             x16, x17, x16, lsr #2
    //     0x372c84: tst             x16, HEAP, lsr #32
    //     0x372c88: b.eq            #0x372c90
    //     0x372c8c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x372c90: ldur            x1, [fp, #-8]
    // 0x372c94: r16 = " saved chapter: "
    //     0x372c94: add             x16, PP, #0xf, lsl #12  ; [pp+0xf378] " saved chapter: "
    //     0x372c98: ldr             x16, [x16, #0x378]
    // 0x372c9c: ArrayStore: r1[0] = r16  ; List_4
    //     0x372c9c: stur            w16, [x1, #0x17]
    // 0x372ca0: r0 = currentChapterName()
    //     0x372ca0: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x372ca4: ldur            x1, [fp, #-8]
    // 0x372ca8: ArrayStore: r1[3] = r0  ; List_4
    //     0x372ca8: add             x25, x1, #0x1b
    //     0x372cac: str             w0, [x25]
    //     0x372cb0: tbz             w0, #0, #0x372ccc
    //     0x372cb4: ldurb           w16, [x1, #-1]
    //     0x372cb8: ldurb           w17, [x0, #-1]
    //     0x372cbc: and             x16, x17, x16, lsr #2
    //     0x372cc0: tst             x16, HEAP, lsr #32
    //     0x372cc4: b.eq            #0x372ccc
    //     0x372cc8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x372ccc: ldur            x0, [fp, #-8]
    // 0x372cd0: r16 = ". This can happen if deleting a custom chapter."
    //     0x372cd0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf380] ". This can happen if deleting a custom chapter."
    //     0x372cd4: ldr             x16, [x16, #0x380]
    // 0x372cd8: StoreField: r0->field_1f = r16
    //     0x372cd8: stur            w16, [x0, #0x1f]
    // 0x372cdc: str             x0, [SP]
    // 0x372ce0: r0 = _interpolate()
    //     0x372ce0: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x372ce4: stur            x0, [fp, #-8]
    // 0x372ce8: r0 = current()
    //     0x372ce8: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x372cec: ldur            x1, [fp, #-8]
    // 0x372cf0: mov             x2, x0
    // 0x372cf4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x372cf4: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x372cf8: r0 = crashlyticsRecordError()
    //     0x372cf8: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x372cfc: r0 = LoadStaticField(0xa6c)
    //     0x372cfc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372d00: ldr             x0, [x0, #0x14d8]
    // 0x372d04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372d08: cmp             w0, w16
    // 0x372d0c: b.eq            #0x372dd8
    // 0x372d10: mov             x1, x0
    // 0x372d14: r2 = "ActNum"
    //     0x372d14: add             x2, PP, #0xe, lsl #12  ; [pp+0xeb38] "ActNum"
    //     0x372d18: ldr             x2, [x2, #0xb38]
    // 0x372d1c: r3 = "1"
    //     0x372d1c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x372d20: ldr             x3, [x3, #0x9c8]
    // 0x372d24: r0 = setString()
    //     0x372d24: bl              #0x372de8  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x372d28: r0 = LoadStaticField(0xf60)
    //     0x372d28: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372d2c: ldr             x0, [x0, #0x1ec0]
    // 0x372d30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372d34: cmp             w0, w16
    // 0x372d38: b.ne            #0x372d48
    // 0x372d3c: r2 = gameStates
    //     0x372d3c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x372d40: ldr             x2, [x2, #0x2e8]
    // 0x372d44: r0 = InitLateStaticField()
    //     0x372d44: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x372d48: mov             x1, x0
    // 0x372d4c: r2 = 2
    //     0x372d4c: movz            x2, #0x2
    // 0x372d50: stur            x0, [fp, #-8]
    // 0x372d54: r0 = _getValueOrData()
    //     0x372d54: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x372d58: ldur            x1, [fp, #-8]
    // 0x372d5c: LoadField: r2 = r1->field_f
    //     0x372d5c: ldur            w2, [x1, #0xf]
    // 0x372d60: DecompressPointer r2
    //     0x372d60: add             x2, x2, HEAP, lsl #32
    // 0x372d64: cmp             w2, w0
    // 0x372d68: b.ne            #0x372d70
    // 0x372d6c: r0 = Null
    //     0x372d6c: mov             x0, NULL
    // 0x372d70: cmp             w0, NULL
    // 0x372d74: b.eq            #0x372de4
    // 0x372d78: LeaveFrame
    //     0x372d78: mov             SP, fp
    //     0x372d7c: ldp             fp, lr, [SP], #0x10
    // 0x372d80: ret
    //     0x372d80: ret             
    // 0x372d84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x372d84: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x372d88: b               #0x37229c
    // 0x372d8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372d8c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372d90: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372d94: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372d98: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372d9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372d9c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372da0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372da4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372da8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dac: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372db0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372db0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372db4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372db4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372db8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372db8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dbc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dc0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dc4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dc8: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dcc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dd0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372dd4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x372dd8: r9 = prefs
    //     0x372dd8: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x372ddc: ldr             x9, [x9, #0xc00]
    // 0x372de0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x372de0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x372de4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x372de4: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  String currentChapterName() {
    // ** addr: 0x372e24, size: 0x100
    // 0x372e24: EnterFrame
    //     0x372e24: stp             fp, lr, [SP, #-0x10]!
    //     0x372e28: mov             fp, SP
    // 0x372e2c: AllocStack(0x10)
    //     0x372e2c: sub             SP, SP, #0x10
    // 0x372e30: CheckStackOverflow
    //     0x372e30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x372e34: cmp             SP, x16
    //     0x372e38: b.ls            #0x372f10
    // 0x372e3c: r0 = LoadStaticField(0xa6c)
    //     0x372e3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x372e40: ldr             x0, [x0, #0x14d8]
    // 0x372e44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x372e48: cmp             w0, w16
    // 0x372e4c: b.eq            #0x372f18
    // 0x372e50: mov             x1, x0
    // 0x372e54: r0 = get()
    //     0x372e54: bl              #0x372f24  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::get
    // 0x372e58: mov             x3, x0
    // 0x372e5c: stur            x3, [fp, #-8]
    // 0x372e60: r0 = 60
    //     0x372e60: movz            x0, #0x3c
    // 0x372e64: branchIfSmi(r3, 0x372e70)
    //     0x372e64: tbz             w3, #0, #0x372e70
    // 0x372e68: r0 = LoadClassIdInstr(r3)
    //     0x372e68: ldur            x0, [x3, #-1]
    //     0x372e6c: ubfx            x0, x0, #0xc, #0x14
    // 0x372e70: sub             x16, x0, #0x3c
    // 0x372e74: cmp             x16, #1
    // 0x372e78: b.hi            #0x372eb0
    // 0x372e7c: r0 = 60
    //     0x372e7c: movz            x0, #0x3c
    // 0x372e80: branchIfSmi(r3, 0x372e8c)
    //     0x372e80: tbz             w3, #0, #0x372e8c
    // 0x372e84: r0 = LoadClassIdInstr(r3)
    //     0x372e84: ldur            x0, [x3, #-1]
    //     0x372e88: ubfx            x0, x0, #0xc, #0x14
    // 0x372e8c: str             x3, [SP]
    // 0x372e90: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x372e90: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x372e94: r0 = GDT[cid_x0 + 0x3019]()
    //     0x372e94: movz            x17, #0x3019
    //     0x372e98: add             lr, x0, x17
    //     0x372e9c: ldr             lr, [x21, lr, lsl #3]
    //     0x372ea0: blr             lr
    // 0x372ea4: LeaveFrame
    //     0x372ea4: mov             SP, fp
    //     0x372ea8: ldp             fp, lr, [SP], #0x10
    // 0x372eac: ret
    //     0x372eac: ret             
    // 0x372eb0: mov             x0, x3
    // 0x372eb4: r2 = Null
    //     0x372eb4: mov             x2, NULL
    // 0x372eb8: r1 = Null
    //     0x372eb8: mov             x1, NULL
    // 0x372ebc: r4 = 60
    //     0x372ebc: movz            x4, #0x3c
    // 0x372ec0: branchIfSmi(r0, 0x372ecc)
    //     0x372ec0: tbz             w0, #0, #0x372ecc
    // 0x372ec4: r4 = LoadClassIdInstr(r0)
    //     0x372ec4: ldur            x4, [x0, #-1]
    //     0x372ec8: ubfx            x4, x4, #0xc, #0x14
    // 0x372ecc: sub             x4, x4, #0x5e
    // 0x372ed0: cmp             x4, #1
    // 0x372ed4: b.ls            #0x372ee8
    // 0x372ed8: r8 = String?
    //     0x372ed8: ldr             x8, [PP, #0xaf0]  ; [pp+0xaf0] Type: String?
    // 0x372edc: r3 = Null
    //     0x372edc: add             x3, PP, #0xf, lsl #12  ; [pp+0xf440] Null
    //     0x372ee0: ldr             x3, [x3, #0x440]
    // 0x372ee4: r0 = String?()
    //     0x372ee4: bl              #0x32906c  ; IsType_String?_Stub
    // 0x372ee8: ldur            x1, [fp, #-8]
    // 0x372eec: cmp             w1, NULL
    // 0x372ef0: b.ne            #0x372f00
    // 0x372ef4: r0 = "1"
    //     0x372ef4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x372ef8: ldr             x0, [x0, #0x9c8]
    // 0x372efc: b               #0x372f04
    // 0x372f00: mov             x0, x1
    // 0x372f04: LeaveFrame
    //     0x372f04: mov             SP, fp
    //     0x372f08: ldp             fp, lr, [SP], #0x10
    // 0x372f0c: ret
    //     0x372f0c: ret             
    // 0x372f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x372f10: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x372f14: b               #0x372e3c
    // 0x372f18: r9 = prefs
    //     0x372f18: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x372f1c: ldr             x9, [x9, #0xc00]
    // 0x372f20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x372f20: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static Map<String, CustomLevelGameState> customLevels() {
    // ** addr: 0x372f7c, size: 0x40
    // 0x372f7c: EnterFrame
    //     0x372f7c: stp             fp, lr, [SP, #-0x10]!
    //     0x372f80: mov             fp, SP
    // 0x372f84: AllocStack(0x10)
    //     0x372f84: sub             SP, SP, #0x10
    // 0x372f88: CheckStackOverflow
    //     0x372f88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x372f8c: cmp             SP, x16
    //     0x372f90: b.ls            #0x372fb4
    // 0x372f94: r16 = <String, CustomLevelGameState>
    //     0x372f94: add             x16, PP, #0xf, lsl #12  ; [pp+0xf388] TypeArguments: <String, CustomLevelGameState>
    //     0x372f98: ldr             x16, [x16, #0x388]
    // 0x372f9c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x372fa0: stp             lr, x16, [SP]
    // 0x372fa4: r0 = Map._fromLiteral()
    //     0x372fa4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x372fa8: LeaveFrame
    //     0x372fa8: mov             SP, fp
    //     0x372fac: ldp             fp, lr, [SP], #0x10
    // 0x372fb0: ret
    //     0x372fb0: ret             
    // 0x372fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x372fb4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x372fb8: b               #0x372f94
  }
  static Map<int, IPlayableGameState<dynamic>> gameStates() {
    // ** addr: 0x372fdc, size: 0x40
    // 0x372fdc: EnterFrame
    //     0x372fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x372fe0: mov             fp, SP
    // 0x372fe4: AllocStack(0x10)
    //     0x372fe4: sub             SP, SP, #0x10
    // 0x372fe8: CheckStackOverflow
    //     0x372fe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x372fec: cmp             SP, x16
    //     0x372ff0: b.ls            #0x373014
    // 0x372ff4: r16 = <int, IPlayableGameState>
    //     0x372ff4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf390] TypeArguments: <int, IPlayableGameState>
    //     0x372ff8: ldr             x16, [x16, #0x390]
    // 0x372ffc: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x373000: stp             lr, x16, [SP]
    // 0x373004: r0 = Map._fromLiteral()
    //     0x373004: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x373008: LeaveFrame
    //     0x373008: mov             SP, fp
    //     0x37300c: ldp             fp, lr, [SP], #0x10
    // 0x373010: ret
    //     0x373010: ret             
    // 0x373014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x373014: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x373018: b               #0x372ff4
  }
  static Future<void> initNewGame() async {
    // ** addr: 0x4528f8, size: 0x38e4
    // 0x4528f8: EnterFrame
    //     0x4528f8: stp             fp, lr, [SP, #-0x10]!
    //     0x4528fc: mov             fp, SP
    // 0x452900: AllocStack(0x150)
    //     0x452900: sub             SP, SP, #0x150
    // 0x452904: SetupParameters()
    //     0x452904: stur            NULL, [fp, #-8]
    // 0x452908: CheckStackOverflow
    //     0x452908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45290c: cmp             SP, x16
    //     0x452910: b.ls            #0x456170
    // 0x452914: InitAsync() -> Future<void?>
    //     0x452914: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x452918: bl              #0x34b9a0  ; InitAsyncStub
    // 0x45291c: r1 = <Tuple2<IPlayableGameState, int?>>
    //     0x45291c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfc98] TypeArguments: <Tuple2<IPlayableGameState, int?>>
    //     0x452920: ldr             x1, [x1, #0xc98]
    // 0x452924: r2 = 0
    //     0x452924: movz            x2, #0
    // 0x452928: r0 = _GrowableList()
    //     0x452928: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x45292c: r1 = Null
    //     0x45292c: mov             x1, NULL
    // 0x452930: r2 = 4
    //     0x452930: movz            x2, #0x4
    // 0x452934: r17 = -272
    //     0x452934: movn            x17, #0x10f
    // 0x452938: str             x0, [fp, x17]
    // 0x45293c: r0 = AllocateArray()
    //     0x45293c: bl              #0x82746c  ; AllocateArrayStub
    // 0x452940: r16 = "1"
    //     0x452940: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x452944: ldr             x16, [x16, #0x9c8]
    // 0x452948: StoreField: r0->field_f = r16
    //     0x452948: stur            w16, [x0, #0xf]
    // 0x45294c: r16 = "1"
    //     0x45294c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x452950: ldr             x16, [x16, #0x9c8]
    // 0x452954: StoreField: r0->field_13 = r16
    //     0x452954: stur            w16, [x0, #0x13]
    // 0x452958: r1 = Null
    //     0x452958: mov             x1, NULL
    // 0x45295c: r2 = 4
    //     0x45295c: movz            x2, #0x4
    // 0x452960: r0 = AllocateArray()
    //     0x452960: bl              #0x82746c  ; AllocateArrayStub
    // 0x452964: r16 = "1"
    //     0x452964: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x452968: ldr             x16, [x16, #0x9c8]
    // 0x45296c: StoreField: r0->field_f = r16
    //     0x45296c: stur            w16, [x0, #0xf]
    // 0x452970: r16 = "2"
    //     0x452970: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x452974: ldr             x16, [x16, #0x2e0]
    // 0x452978: StoreField: r0->field_13 = r16
    //     0x452978: stur            w16, [x0, #0x13]
    // 0x45297c: r1 = Null
    //     0x45297c: mov             x1, NULL
    // 0x452980: r2 = 4
    //     0x452980: movz            x2, #0x4
    // 0x452984: r0 = AllocateArray()
    //     0x452984: bl              #0x82746c  ; AllocateArrayStub
    // 0x452988: r16 = "1"
    //     0x452988: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x45298c: ldr             x16, [x16, #0x9c8]
    // 0x452990: StoreField: r0->field_f = r16
    //     0x452990: stur            w16, [x0, #0xf]
    // 0x452994: r16 = "3"
    //     0x452994: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x452998: ldr             x16, [x16, #0x2f0]
    // 0x45299c: StoreField: r0->field_13 = r16
    //     0x45299c: stur            w16, [x0, #0x13]
    // 0x4529a0: r1 = "11"
    //     0x4529a0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x4529a4: ldr             x1, [x1, #0x328]
    // 0x4529a8: r2 = "13"
    //     0x4529a8: add             x2, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x4529ac: ldr             x2, [x2, #0x338]
    // 0x4529b0: r3 = 2
    //     0x4529b0: movz            x3, #0x2
    // 0x4529b4: r5 = "12"
    //     0x4529b4: add             x5, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x4529b8: ldr             x5, [x5, #0x330]
    // 0x4529bc: r0 = readMostRecentValidSaveFile()
    //     0x4529bc: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4529c0: mov             x1, x0
    // 0x4529c4: r17 = -280
    //     0x4529c4: movn            x17, #0x117
    // 0x4529c8: str             x1, [fp, x17]
    // 0x4529cc: r0 = Await()
    //     0x4529cc: bl              #0x34b75c  ; AwaitStub
    // 0x4529d0: cmp             w0, NULL
    // 0x4529d4: b.eq            #0x452a98
    // 0x4529d8: LoadField: r2 = r0->field_f
    //     0x4529d8: ldur            w2, [x0, #0xf]
    // 0x4529dc: DecompressPointer r2
    //     0x4529dc: add             x2, x2, HEAP, lsl #32
    // 0x4529e0: r17 = -280
    //     0x4529e0: movn            x17, #0x117
    // 0x4529e4: str             x2, [fp, x17]
    // 0x4529e8: r1 = <Stat>
    //     0x4529e8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x4529ec: ldr             x1, [x1, #0xca0]
    // 0x4529f0: r0 = Chapter1GameState()
    //     0x4529f0: bl              #0x473040  ; AllocateChapter1GameStateStub -> Chapter1GameState (size=0xa8)
    // 0x4529f4: mov             x1, x0
    // 0x4529f8: r17 = -280
    //     0x4529f8: movn            x17, #0x117
    // 0x4529fc: ldr             x2, [fp, x17]
    // 0x452a00: r17 = -288
    //     0x452a00: movn            x17, #0x11f
    // 0x452a04: str             x0, [fp, x17]
    // 0x452a08: r0 = Chapter1GameState()
    //     0x452a08: bl              #0x472b54  ; [package:pretentious/data/Chapters/Chapter1GameState.dart] Chapter1GameState::Chapter1GameState
    // 0x452a0c: r17 = -280
    //     0x452a0c: movn            x17, #0x117
    // 0x452a10: ldr             x1, [fp, x17]
    // 0x452a14: r0 = LoadClassIdInstr(r1)
    //     0x452a14: ldur            x0, [x1, #-1]
    //     0x452a18: ubfx            x0, x0, #0xc, #0x14
    // 0x452a1c: r2 = 2
    //     0x452a1c: movz            x2, #0x2
    // 0x452a20: r0 = GDT[cid_x0 + -0x1000]()
    //     0x452a20: sub             lr, x0, #1, lsl #12
    //     0x452a24: ldr             lr, [x21, lr, lsl #3]
    //     0x452a28: blr             lr
    // 0x452a2c: mov             x3, x0
    // 0x452a30: r2 = Null
    //     0x452a30: mov             x2, NULL
    // 0x452a34: r1 = Null
    //     0x452a34: mov             x1, NULL
    // 0x452a38: r17 = -280
    //     0x452a38: movn            x17, #0x117
    // 0x452a3c: str             x3, [fp, x17]
    // 0x452a40: branchIfSmi(r0, 0x452a68)
    //     0x452a40: tbz             w0, #0, #0x452a68
    // 0x452a44: r4 = LoadClassIdInstr(r0)
    //     0x452a44: ldur            x4, [x0, #-1]
    //     0x452a48: ubfx            x4, x4, #0xc, #0x14
    // 0x452a4c: sub             x4, x4, #0x3c
    // 0x452a50: cmp             x4, #1
    // 0x452a54: b.ls            #0x452a68
    // 0x452a58: r8 = int?
    //     0x452a58: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x452a5c: r3 = Null
    //     0x452a5c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfca8] Null
    //     0x452a60: ldr             x3, [x3, #0xca8]
    // 0x452a64: r0 = int?()
    //     0x452a64: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x452a68: r1 = <Chapter1GameState, int?>
    //     0x452a68: add             x1, PP, #0xf, lsl #12  ; [pp+0xfcb8] TypeArguments: <Chapter1GameState, int?>
    //     0x452a6c: ldr             x1, [x1, #0xcb8]
    // 0x452a70: r0 = Tuple2()
    //     0x452a70: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x452a74: mov             x1, x0
    // 0x452a78: r17 = -288
    //     0x452a78: movn            x17, #0x11f
    // 0x452a7c: ldr             x0, [fp, x17]
    // 0x452a80: StoreField: r1->field_b = r0
    //     0x452a80: stur            w0, [x1, #0xb]
    // 0x452a84: r17 = -280
    //     0x452a84: movn            x17, #0x117
    // 0x452a88: ldr             x0, [fp, x17]
    // 0x452a8c: StoreField: r1->field_f = r0
    //     0x452a8c: stur            w0, [x1, #0xf]
    // 0x452a90: mov             x2, x1
    // 0x452a94: b               #0x452ad8
    // 0x452a98: r1 = <Stat>
    //     0x452a98: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x452a9c: ldr             x1, [x1, #0xca0]
    // 0x452aa0: r0 = Chapter1GameState()
    //     0x452aa0: bl              #0x473040  ; AllocateChapter1GameStateStub -> Chapter1GameState (size=0xa8)
    // 0x452aa4: mov             x1, x0
    // 0x452aa8: r2 = Null
    //     0x452aa8: mov             x2, NULL
    // 0x452aac: r17 = -280
    //     0x452aac: movn            x17, #0x117
    // 0x452ab0: str             x0, [fp, x17]
    // 0x452ab4: r0 = Chapter1GameState()
    //     0x452ab4: bl              #0x472b54  ; [package:pretentious/data/Chapters/Chapter1GameState.dart] Chapter1GameState::Chapter1GameState
    // 0x452ab8: r1 = <Chapter1GameState, int?>
    //     0x452ab8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfcb8] TypeArguments: <Chapter1GameState, int?>
    //     0x452abc: ldr             x1, [x1, #0xcb8]
    // 0x452ac0: r0 = Tuple2()
    //     0x452ac0: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x452ac4: mov             x1, x0
    // 0x452ac8: r17 = -280
    //     0x452ac8: movn            x17, #0x117
    // 0x452acc: ldr             x0, [fp, x17]
    // 0x452ad0: StoreField: r1->field_b = r0
    //     0x452ad0: stur            w0, [x1, #0xb]
    // 0x452ad4: mov             x2, x1
    // 0x452ad8: r17 = -272
    //     0x452ad8: movn            x17, #0x10f
    // 0x452adc: ldr             x0, [fp, x17]
    // 0x452ae0: r17 = -280
    //     0x452ae0: movn            x17, #0x117
    // 0x452ae4: str             x2, [fp, x17]
    // 0x452ae8: LoadField: r1 = r0->field_b
    //     0x452ae8: ldur            w1, [x0, #0xb]
    // 0x452aec: LoadField: r3 = r0->field_f
    //     0x452aec: ldur            w3, [x0, #0xf]
    // 0x452af0: DecompressPointer r3
    //     0x452af0: add             x3, x3, HEAP, lsl #32
    // 0x452af4: LoadField: r4 = r3->field_b
    //     0x452af4: ldur            w4, [x3, #0xb]
    // 0x452af8: r3 = LoadInt32Instr(r1)
    //     0x452af8: sbfx            x3, x1, #1, #0x1f
    // 0x452afc: r17 = -296
    //     0x452afc: movn            x17, #0x127
    // 0x452b00: str             x3, [fp, x17]
    // 0x452b04: r1 = LoadInt32Instr(r4)
    //     0x452b04: sbfx            x1, x4, #1, #0x1f
    // 0x452b08: cmp             x3, x1
    // 0x452b0c: b.ne            #0x452b18
    // 0x452b10: mov             x1, x0
    // 0x452b14: r0 = _growToNextCapacity()
    //     0x452b14: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x452b18: r17 = -272
    //     0x452b18: movn            x17, #0x10f
    // 0x452b1c: ldr             x2, [fp, x17]
    // 0x452b20: r17 = -296
    //     0x452b20: movn            x17, #0x127
    // 0x452b24: ldr             x3, [fp, x17]
    // 0x452b28: add             x0, x3, #1
    // 0x452b2c: lsl             x1, x0, #1
    // 0x452b30: StoreField: r2->field_b = r1
    //     0x452b30: stur            w1, [x2, #0xb]
    // 0x452b34: LoadField: r1 = r2->field_f
    //     0x452b34: ldur            w1, [x2, #0xf]
    // 0x452b38: DecompressPointer r1
    //     0x452b38: add             x1, x1, HEAP, lsl #32
    // 0x452b3c: r17 = -280
    //     0x452b3c: movn            x17, #0x117
    // 0x452b40: ldr             x0, [fp, x17]
    // 0x452b44: ArrayStore: r1[r3] = r0  ; List_4
    //     0x452b44: add             x25, x1, x3, lsl #2
    //     0x452b48: add             x25, x25, #0xf
    //     0x452b4c: str             w0, [x25]
    //     0x452b50: tbz             w0, #0, #0x452b6c
    //     0x452b54: ldurb           w16, [x1, #-1]
    //     0x452b58: ldurb           w17, [x0, #-1]
    //     0x452b5c: and             x16, x17, x16, lsr #2
    //     0x452b60: tst             x16, HEAP, lsr #32
    //     0x452b64: b.eq            #0x452b6c
    //     0x452b68: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x452b6c: mov             x1, x2
    // 0x452b70: r0 = last()
    //     0x452b70: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452b74: LoadField: r2 = r0->field_b
    //     0x452b74: ldur            w2, [x0, #0xb]
    // 0x452b78: DecompressPointer r2
    //     0x452b78: add             x2, x2, HEAP, lsl #32
    // 0x452b7c: r17 = -272
    //     0x452b7c: movn            x17, #0x10f
    // 0x452b80: ldr             x1, [fp, x17]
    // 0x452b84: r17 = -280
    //     0x452b84: movn            x17, #0x117
    // 0x452b88: str             x2, [fp, x17]
    // 0x452b8c: r0 = last()
    //     0x452b8c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452b90: LoadField: r1 = r0->field_f
    //     0x452b90: ldur            w1, [x0, #0xf]
    // 0x452b94: DecompressPointer r1
    //     0x452b94: add             x1, x1, HEAP, lsl #32
    // 0x452b98: r17 = -280
    //     0x452b98: movn            x17, #0x117
    // 0x452b9c: ldr             x2, [fp, x17]
    // 0x452ba0: cmp             w2, NULL
    // 0x452ba4: b.eq            #0x456178
    // 0x452ba8: mov             x0, x1
    // 0x452bac: StoreField: r2->field_b = r0
    //     0x452bac: stur            w0, [x2, #0xb]
    //     0x452bb0: tbz             w0, #0, #0x452bcc
    //     0x452bb4: ldurb           w16, [x2, #-1]
    //     0x452bb8: ldurb           w17, [x0, #-1]
    //     0x452bbc: and             x16, x17, x16, lsr #2
    //     0x452bc0: tst             x16, HEAP, lsr #32
    //     0x452bc4: b.eq            #0x452bcc
    //     0x452bc8: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x452bcc: r0 = LoadStaticField(0xf60)
    //     0x452bcc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x452bd0: ldr             x0, [x0, #0x1ec0]
    // 0x452bd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x452bd8: cmp             w0, w16
    // 0x452bdc: b.ne            #0x452bec
    // 0x452be0: r2 = gameStates
    //     0x452be0: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x452be4: ldr             x2, [x2, #0x2e8]
    // 0x452be8: r0 = InitLateStaticField()
    //     0x452be8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x452bec: r17 = -272
    //     0x452bec: movn            x17, #0x10f
    // 0x452bf0: ldr             x1, [fp, x17]
    // 0x452bf4: r17 = -280
    //     0x452bf4: movn            x17, #0x117
    // 0x452bf8: str             x0, [fp, x17]
    // 0x452bfc: r0 = last()
    //     0x452bfc: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452c00: LoadField: r3 = r0->field_b
    //     0x452c00: ldur            w3, [x0, #0xb]
    // 0x452c04: DecompressPointer r3
    //     0x452c04: add             x3, x3, HEAP, lsl #32
    // 0x452c08: r17 = -280
    //     0x452c08: movn            x17, #0x117
    // 0x452c0c: ldr             x1, [fp, x17]
    // 0x452c10: r2 = 2
    //     0x452c10: movz            x2, #0x2
    // 0x452c14: r0 = []=()
    //     0x452c14: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x452c18: r1 = Null
    //     0x452c18: mov             x1, NULL
    // 0x452c1c: r2 = 4
    //     0x452c1c: movz            x2, #0x4
    // 0x452c20: r0 = AllocateArray()
    //     0x452c20: bl              #0x82746c  ; AllocateArrayStub
    // 0x452c24: r16 = "2"
    //     0x452c24: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x452c28: ldr             x16, [x16, #0x2e0]
    // 0x452c2c: StoreField: r0->field_f = r16
    //     0x452c2c: stur            w16, [x0, #0xf]
    // 0x452c30: r16 = "1"
    //     0x452c30: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x452c34: ldr             x16, [x16, #0x9c8]
    // 0x452c38: StoreField: r0->field_13 = r16
    //     0x452c38: stur            w16, [x0, #0x13]
    // 0x452c3c: r1 = Null
    //     0x452c3c: mov             x1, NULL
    // 0x452c40: r2 = 4
    //     0x452c40: movz            x2, #0x4
    // 0x452c44: r0 = AllocateArray()
    //     0x452c44: bl              #0x82746c  ; AllocateArrayStub
    // 0x452c48: r16 = "2"
    //     0x452c48: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x452c4c: ldr             x16, [x16, #0x2e0]
    // 0x452c50: StoreField: r0->field_f = r16
    //     0x452c50: stur            w16, [x0, #0xf]
    // 0x452c54: r16 = "2"
    //     0x452c54: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x452c58: ldr             x16, [x16, #0x2e0]
    // 0x452c5c: StoreField: r0->field_13 = r16
    //     0x452c5c: stur            w16, [x0, #0x13]
    // 0x452c60: r1 = Null
    //     0x452c60: mov             x1, NULL
    // 0x452c64: r2 = 4
    //     0x452c64: movz            x2, #0x4
    // 0x452c68: r0 = AllocateArray()
    //     0x452c68: bl              #0x82746c  ; AllocateArrayStub
    // 0x452c6c: r16 = "2"
    //     0x452c6c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x452c70: ldr             x16, [x16, #0x2e0]
    // 0x452c74: StoreField: r0->field_f = r16
    //     0x452c74: stur            w16, [x0, #0xf]
    // 0x452c78: r16 = "3"
    //     0x452c78: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x452c7c: ldr             x16, [x16, #0x2f0]
    // 0x452c80: StoreField: r0->field_13 = r16
    //     0x452c80: stur            w16, [x0, #0x13]
    // 0x452c84: r1 = "21"
    //     0x452c84: add             x1, PP, #0xf, lsl #12  ; [pp+0xfcc0] "21"
    //     0x452c88: ldr             x1, [x1, #0xcc0]
    // 0x452c8c: r2 = "23"
    //     0x452c8c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfcc8] "23"
    //     0x452c90: ldr             x2, [x2, #0xcc8]
    // 0x452c94: r3 = 2
    //     0x452c94: movz            x3, #0x2
    // 0x452c98: r5 = "22"
    //     0x452c98: add             x5, PP, #0xf, lsl #12  ; [pp+0xfcd0] "22"
    //     0x452c9c: ldr             x5, [x5, #0xcd0]
    // 0x452ca0: r0 = readMostRecentValidSaveFile()
    //     0x452ca0: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x452ca4: mov             x1, x0
    // 0x452ca8: r17 = -280
    //     0x452ca8: movn            x17, #0x117
    // 0x452cac: str             x1, [fp, x17]
    // 0x452cb0: r0 = Await()
    //     0x452cb0: bl              #0x34b75c  ; AwaitStub
    // 0x452cb4: cmp             w0, NULL
    // 0x452cb8: b.eq            #0x452d7c
    // 0x452cbc: LoadField: r2 = r0->field_f
    //     0x452cbc: ldur            w2, [x0, #0xf]
    // 0x452cc0: DecompressPointer r2
    //     0x452cc0: add             x2, x2, HEAP, lsl #32
    // 0x452cc4: r17 = -280
    //     0x452cc4: movn            x17, #0x117
    // 0x452cc8: str             x2, [fp, x17]
    // 0x452ccc: r1 = <Stat>
    //     0x452ccc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x452cd0: ldr             x1, [x1, #0xca0]
    // 0x452cd4: r0 = Chapter2GameState()
    //     0x452cd4: bl              #0x472b48  ; AllocateChapter2GameStateStub -> Chapter2GameState (size=0x9c)
    // 0x452cd8: mov             x1, x0
    // 0x452cdc: r17 = -280
    //     0x452cdc: movn            x17, #0x117
    // 0x452ce0: ldr             x2, [fp, x17]
    // 0x452ce4: r17 = -288
    //     0x452ce4: movn            x17, #0x11f
    // 0x452ce8: str             x0, [fp, x17]
    // 0x452cec: r0 = Chapter2GameState()
    //     0x452cec: bl              #0x471788  ; [package:pretentious/data/Chapters/Chapter2GameState.dart] Chapter2GameState::Chapter2GameState
    // 0x452cf0: r17 = -280
    //     0x452cf0: movn            x17, #0x117
    // 0x452cf4: ldr             x1, [fp, x17]
    // 0x452cf8: r0 = LoadClassIdInstr(r1)
    //     0x452cf8: ldur            x0, [x1, #-1]
    //     0x452cfc: ubfx            x0, x0, #0xc, #0x14
    // 0x452d00: r2 = 2
    //     0x452d00: movz            x2, #0x2
    // 0x452d04: r0 = GDT[cid_x0 + -0x1000]()
    //     0x452d04: sub             lr, x0, #1, lsl #12
    //     0x452d08: ldr             lr, [x21, lr, lsl #3]
    //     0x452d0c: blr             lr
    // 0x452d10: mov             x3, x0
    // 0x452d14: r2 = Null
    //     0x452d14: mov             x2, NULL
    // 0x452d18: r1 = Null
    //     0x452d18: mov             x1, NULL
    // 0x452d1c: r17 = -280
    //     0x452d1c: movn            x17, #0x117
    // 0x452d20: str             x3, [fp, x17]
    // 0x452d24: branchIfSmi(r0, 0x452d4c)
    //     0x452d24: tbz             w0, #0, #0x452d4c
    // 0x452d28: r4 = LoadClassIdInstr(r0)
    //     0x452d28: ldur            x4, [x0, #-1]
    //     0x452d2c: ubfx            x4, x4, #0xc, #0x14
    // 0x452d30: sub             x4, x4, #0x3c
    // 0x452d34: cmp             x4, #1
    // 0x452d38: b.ls            #0x452d4c
    // 0x452d3c: r8 = int?
    //     0x452d3c: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x452d40: r3 = Null
    //     0x452d40: add             x3, PP, #0xf, lsl #12  ; [pp+0xfcd8] Null
    //     0x452d44: ldr             x3, [x3, #0xcd8]
    // 0x452d48: r0 = int?()
    //     0x452d48: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x452d4c: r1 = <Chapter2GameState, int?>
    //     0x452d4c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfce8] TypeArguments: <Chapter2GameState, int?>
    //     0x452d50: ldr             x1, [x1, #0xce8]
    // 0x452d54: r0 = Tuple2()
    //     0x452d54: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x452d58: mov             x1, x0
    // 0x452d5c: r17 = -288
    //     0x452d5c: movn            x17, #0x11f
    // 0x452d60: ldr             x0, [fp, x17]
    // 0x452d64: StoreField: r1->field_b = r0
    //     0x452d64: stur            w0, [x1, #0xb]
    // 0x452d68: r17 = -280
    //     0x452d68: movn            x17, #0x117
    // 0x452d6c: ldr             x0, [fp, x17]
    // 0x452d70: StoreField: r1->field_f = r0
    //     0x452d70: stur            w0, [x1, #0xf]
    // 0x452d74: mov             x2, x1
    // 0x452d78: b               #0x452dbc
    // 0x452d7c: r1 = <Stat>
    //     0x452d7c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x452d80: ldr             x1, [x1, #0xca0]
    // 0x452d84: r0 = Chapter2GameState()
    //     0x452d84: bl              #0x472b48  ; AllocateChapter2GameStateStub -> Chapter2GameState (size=0x9c)
    // 0x452d88: mov             x1, x0
    // 0x452d8c: r2 = Null
    //     0x452d8c: mov             x2, NULL
    // 0x452d90: r17 = -280
    //     0x452d90: movn            x17, #0x117
    // 0x452d94: str             x0, [fp, x17]
    // 0x452d98: r0 = Chapter2GameState()
    //     0x452d98: bl              #0x471788  ; [package:pretentious/data/Chapters/Chapter2GameState.dart] Chapter2GameState::Chapter2GameState
    // 0x452d9c: r1 = <Chapter2GameState, int?>
    //     0x452d9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfce8] TypeArguments: <Chapter2GameState, int?>
    //     0x452da0: ldr             x1, [x1, #0xce8]
    // 0x452da4: r0 = Tuple2()
    //     0x452da4: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x452da8: mov             x1, x0
    // 0x452dac: r17 = -280
    //     0x452dac: movn            x17, #0x117
    // 0x452db0: ldr             x0, [fp, x17]
    // 0x452db4: StoreField: r1->field_b = r0
    //     0x452db4: stur            w0, [x1, #0xb]
    // 0x452db8: mov             x2, x1
    // 0x452dbc: r17 = -272
    //     0x452dbc: movn            x17, #0x10f
    // 0x452dc0: ldr             x0, [fp, x17]
    // 0x452dc4: r17 = -280
    //     0x452dc4: movn            x17, #0x117
    // 0x452dc8: str             x2, [fp, x17]
    // 0x452dcc: LoadField: r1 = r0->field_b
    //     0x452dcc: ldur            w1, [x0, #0xb]
    // 0x452dd0: LoadField: r3 = r0->field_f
    //     0x452dd0: ldur            w3, [x0, #0xf]
    // 0x452dd4: DecompressPointer r3
    //     0x452dd4: add             x3, x3, HEAP, lsl #32
    // 0x452dd8: LoadField: r4 = r3->field_b
    //     0x452dd8: ldur            w4, [x3, #0xb]
    // 0x452ddc: r3 = LoadInt32Instr(r1)
    //     0x452ddc: sbfx            x3, x1, #1, #0x1f
    // 0x452de0: r17 = -296
    //     0x452de0: movn            x17, #0x127
    // 0x452de4: str             x3, [fp, x17]
    // 0x452de8: r1 = LoadInt32Instr(r4)
    //     0x452de8: sbfx            x1, x4, #1, #0x1f
    // 0x452dec: cmp             x3, x1
    // 0x452df0: b.ne            #0x452dfc
    // 0x452df4: mov             x1, x0
    // 0x452df8: r0 = _growToNextCapacity()
    //     0x452df8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x452dfc: r17 = -272
    //     0x452dfc: movn            x17, #0x10f
    // 0x452e00: ldr             x2, [fp, x17]
    // 0x452e04: r17 = -296
    //     0x452e04: movn            x17, #0x127
    // 0x452e08: ldr             x3, [fp, x17]
    // 0x452e0c: add             x0, x3, #1
    // 0x452e10: lsl             x1, x0, #1
    // 0x452e14: StoreField: r2->field_b = r1
    //     0x452e14: stur            w1, [x2, #0xb]
    // 0x452e18: LoadField: r1 = r2->field_f
    //     0x452e18: ldur            w1, [x2, #0xf]
    // 0x452e1c: DecompressPointer r1
    //     0x452e1c: add             x1, x1, HEAP, lsl #32
    // 0x452e20: r17 = -280
    //     0x452e20: movn            x17, #0x117
    // 0x452e24: ldr             x0, [fp, x17]
    // 0x452e28: ArrayStore: r1[r3] = r0  ; List_4
    //     0x452e28: add             x25, x1, x3, lsl #2
    //     0x452e2c: add             x25, x25, #0xf
    //     0x452e30: str             w0, [x25]
    //     0x452e34: tbz             w0, #0, #0x452e50
    //     0x452e38: ldurb           w16, [x1, #-1]
    //     0x452e3c: ldurb           w17, [x0, #-1]
    //     0x452e40: and             x16, x17, x16, lsr #2
    //     0x452e44: tst             x16, HEAP, lsr #32
    //     0x452e48: b.eq            #0x452e50
    //     0x452e4c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x452e50: mov             x1, x2
    // 0x452e54: r0 = last()
    //     0x452e54: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452e58: LoadField: r2 = r0->field_b
    //     0x452e58: ldur            w2, [x0, #0xb]
    // 0x452e5c: DecompressPointer r2
    //     0x452e5c: add             x2, x2, HEAP, lsl #32
    // 0x452e60: r17 = -272
    //     0x452e60: movn            x17, #0x10f
    // 0x452e64: ldr             x1, [fp, x17]
    // 0x452e68: r17 = -280
    //     0x452e68: movn            x17, #0x117
    // 0x452e6c: str             x2, [fp, x17]
    // 0x452e70: r0 = last()
    //     0x452e70: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452e74: LoadField: r1 = r0->field_f
    //     0x452e74: ldur            w1, [x0, #0xf]
    // 0x452e78: DecompressPointer r1
    //     0x452e78: add             x1, x1, HEAP, lsl #32
    // 0x452e7c: r17 = -280
    //     0x452e7c: movn            x17, #0x117
    // 0x452e80: ldr             x2, [fp, x17]
    // 0x452e84: cmp             w2, NULL
    // 0x452e88: b.eq            #0x45617c
    // 0x452e8c: mov             x0, x1
    // 0x452e90: StoreField: r2->field_b = r0
    //     0x452e90: stur            w0, [x2, #0xb]
    //     0x452e94: tbz             w0, #0, #0x452eb0
    //     0x452e98: ldurb           w16, [x2, #-1]
    //     0x452e9c: ldurb           w17, [x0, #-1]
    //     0x452ea0: and             x16, x17, x16, lsr #2
    //     0x452ea4: tst             x16, HEAP, lsr #32
    //     0x452ea8: b.eq            #0x452eb0
    //     0x452eac: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x452eb0: r0 = LoadStaticField(0xf60)
    //     0x452eb0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x452eb4: ldr             x0, [x0, #0x1ec0]
    // 0x452eb8: r17 = -272
    //     0x452eb8: movn            x17, #0x10f
    // 0x452ebc: ldr             x1, [fp, x17]
    // 0x452ec0: r17 = -280
    //     0x452ec0: movn            x17, #0x117
    // 0x452ec4: str             x0, [fp, x17]
    // 0x452ec8: r0 = last()
    //     0x452ec8: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452ecc: LoadField: r3 = r0->field_b
    //     0x452ecc: ldur            w3, [x0, #0xb]
    // 0x452ed0: DecompressPointer r3
    //     0x452ed0: add             x3, x3, HEAP, lsl #32
    // 0x452ed4: r17 = -280
    //     0x452ed4: movn            x17, #0x117
    // 0x452ed8: ldr             x1, [fp, x17]
    // 0x452edc: r2 = 4
    //     0x452edc: movz            x2, #0x4
    // 0x452ee0: r0 = []=()
    //     0x452ee0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x452ee4: r17 = -272
    //     0x452ee4: movn            x17, #0x10f
    // 0x452ee8: ldr             x1, [fp, x17]
    // 0x452eec: r0 = last()
    //     0x452eec: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x452ef0: LoadField: r3 = r0->field_b
    //     0x452ef0: ldur            w3, [x0, #0xb]
    // 0x452ef4: DecompressPointer r3
    //     0x452ef4: add             x3, x3, HEAP, lsl #32
    // 0x452ef8: r17 = -280
    //     0x452ef8: movn            x17, #0x117
    // 0x452efc: str             x3, [fp, x17]
    // 0x452f00: cmp             w3, NULL
    // 0x452f04: b.eq            #0x456180
    // 0x452f08: LoadField: r1 = r3->field_47
    //     0x452f08: ldur            w1, [x3, #0x47]
    // 0x452f0c: DecompressPointer r1
    //     0x452f0c: add             x1, x1, HEAP, lsl #32
    // 0x452f10: r2 = 2
    //     0x452f10: movz            x2, #0x2
    // 0x452f14: r0 = containsKey()
    //     0x452f14: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x452f18: tbnz            w0, #4, #0x452f94
    // 0x452f1c: r17 = -280
    //     0x452f1c: movn            x17, #0x117
    // 0x452f20: ldr             x0, [fp, x17]
    // 0x452f24: LoadField: r3 = r0->field_47
    //     0x452f24: ldur            w3, [x0, #0x47]
    // 0x452f28: DecompressPointer r3
    //     0x452f28: add             x3, x3, HEAP, lsl #32
    // 0x452f2c: mov             x1, x3
    // 0x452f30: r17 = -288
    //     0x452f30: movn            x17, #0x11f
    // 0x452f34: str             x3, [fp, x17]
    // 0x452f38: r2 = 2
    //     0x452f38: movz            x2, #0x2
    // 0x452f3c: r0 = _getValueOrData()
    //     0x452f3c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x452f40: r17 = -288
    //     0x452f40: movn            x17, #0x11f
    // 0x452f44: ldr             x1, [fp, x17]
    // 0x452f48: LoadField: r2 = r1->field_f
    //     0x452f48: ldur            w2, [x1, #0xf]
    // 0x452f4c: DecompressPointer r2
    //     0x452f4c: add             x2, x2, HEAP, lsl #32
    // 0x452f50: cmp             w2, w0
    // 0x452f54: b.ne            #0x452f60
    // 0x452f58: r3 = Null
    //     0x452f58: mov             x3, NULL
    // 0x452f5c: b               #0x452f64
    // 0x452f60: mov             x3, x0
    // 0x452f64: r17 = -280
    //     0x452f64: movn            x17, #0x117
    // 0x452f68: ldr             x0, [fp, x17]
    // 0x452f6c: cmp             w3, NULL
    // 0x452f70: b.eq            #0x456184
    // 0x452f74: r2 = 14
    //     0x452f74: movz            x2, #0xe
    // 0x452f78: r0 = []=()
    //     0x452f78: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x452f7c: r17 = -280
    //     0x452f7c: movn            x17, #0x117
    // 0x452f80: ldr             x0, [fp, x17]
    // 0x452f84: LoadField: r1 = r0->field_47
    //     0x452f84: ldur            w1, [x0, #0x47]
    // 0x452f88: DecompressPointer r1
    //     0x452f88: add             x1, x1, HEAP, lsl #32
    // 0x452f8c: r2 = 2
    //     0x452f8c: movz            x2, #0x2
    // 0x452f90: r0 = remove()
    //     0x452f90: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x452f94: r17 = -280
    //     0x452f94: movn            x17, #0x117
    // 0x452f98: ldr             x0, [fp, x17]
    // 0x452f9c: LoadField: r1 = r0->field_47
    //     0x452f9c: ldur            w1, [x0, #0x47]
    // 0x452fa0: DecompressPointer r1
    //     0x452fa0: add             x1, x1, HEAP, lsl #32
    // 0x452fa4: r2 = 4
    //     0x452fa4: movz            x2, #0x4
    // 0x452fa8: r0 = containsKey()
    //     0x452fa8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x452fac: tbnz            w0, #4, #0x453028
    // 0x452fb0: r17 = -280
    //     0x452fb0: movn            x17, #0x117
    // 0x452fb4: ldr             x0, [fp, x17]
    // 0x452fb8: LoadField: r3 = r0->field_47
    //     0x452fb8: ldur            w3, [x0, #0x47]
    // 0x452fbc: DecompressPointer r3
    //     0x452fbc: add             x3, x3, HEAP, lsl #32
    // 0x452fc0: mov             x1, x3
    // 0x452fc4: r17 = -288
    //     0x452fc4: movn            x17, #0x11f
    // 0x452fc8: str             x3, [fp, x17]
    // 0x452fcc: r2 = 4
    //     0x452fcc: movz            x2, #0x4
    // 0x452fd0: r0 = _getValueOrData()
    //     0x452fd0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x452fd4: r17 = -288
    //     0x452fd4: movn            x17, #0x11f
    // 0x452fd8: ldr             x1, [fp, x17]
    // 0x452fdc: LoadField: r2 = r1->field_f
    //     0x452fdc: ldur            w2, [x1, #0xf]
    // 0x452fe0: DecompressPointer r2
    //     0x452fe0: add             x2, x2, HEAP, lsl #32
    // 0x452fe4: cmp             w2, w0
    // 0x452fe8: b.ne            #0x452ff4
    // 0x452fec: r3 = Null
    //     0x452fec: mov             x3, NULL
    // 0x452ff0: b               #0x452ff8
    // 0x452ff4: mov             x3, x0
    // 0x452ff8: r17 = -280
    //     0x452ff8: movn            x17, #0x117
    // 0x452ffc: ldr             x0, [fp, x17]
    // 0x453000: cmp             w3, NULL
    // 0x453004: b.eq            #0x456188
    // 0x453008: r2 = 16
    //     0x453008: movz            x2, #0x10
    // 0x45300c: r0 = []=()
    //     0x45300c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x453010: r17 = -280
    //     0x453010: movn            x17, #0x117
    // 0x453014: ldr             x0, [fp, x17]
    // 0x453018: LoadField: r1 = r0->field_47
    //     0x453018: ldur            w1, [x0, #0x47]
    // 0x45301c: DecompressPointer r1
    //     0x45301c: add             x1, x1, HEAP, lsl #32
    // 0x453020: r2 = 4
    //     0x453020: movz            x2, #0x4
    // 0x453024: r0 = remove()
    //     0x453024: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x453028: r17 = -280
    //     0x453028: movn            x17, #0x117
    // 0x45302c: ldr             x0, [fp, x17]
    // 0x453030: LoadField: r1 = r0->field_47
    //     0x453030: ldur            w1, [x0, #0x47]
    // 0x453034: DecompressPointer r1
    //     0x453034: add             x1, x1, HEAP, lsl #32
    // 0x453038: r2 = 6
    //     0x453038: movz            x2, #0x6
    // 0x45303c: r0 = containsKey()
    //     0x45303c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x453040: tbnz            w0, #4, #0x4530bc
    // 0x453044: r17 = -280
    //     0x453044: movn            x17, #0x117
    // 0x453048: ldr             x0, [fp, x17]
    // 0x45304c: LoadField: r3 = r0->field_47
    //     0x45304c: ldur            w3, [x0, #0x47]
    // 0x453050: DecompressPointer r3
    //     0x453050: add             x3, x3, HEAP, lsl #32
    // 0x453054: mov             x1, x3
    // 0x453058: r17 = -288
    //     0x453058: movn            x17, #0x11f
    // 0x45305c: str             x3, [fp, x17]
    // 0x453060: r2 = 6
    //     0x453060: movz            x2, #0x6
    // 0x453064: r0 = _getValueOrData()
    //     0x453064: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x453068: r17 = -288
    //     0x453068: movn            x17, #0x11f
    // 0x45306c: ldr             x1, [fp, x17]
    // 0x453070: LoadField: r2 = r1->field_f
    //     0x453070: ldur            w2, [x1, #0xf]
    // 0x453074: DecompressPointer r2
    //     0x453074: add             x2, x2, HEAP, lsl #32
    // 0x453078: cmp             w2, w0
    // 0x45307c: b.ne            #0x453088
    // 0x453080: r3 = Null
    //     0x453080: mov             x3, NULL
    // 0x453084: b               #0x45308c
    // 0x453088: mov             x3, x0
    // 0x45308c: r17 = -280
    //     0x45308c: movn            x17, #0x117
    // 0x453090: ldr             x0, [fp, x17]
    // 0x453094: cmp             w3, NULL
    // 0x453098: b.eq            #0x45618c
    // 0x45309c: r2 = 18
    //     0x45309c: movz            x2, #0x12
    // 0x4530a0: r0 = []=()
    //     0x4530a0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4530a4: r17 = -280
    //     0x4530a4: movn            x17, #0x117
    // 0x4530a8: ldr             x0, [fp, x17]
    // 0x4530ac: LoadField: r1 = r0->field_47
    //     0x4530ac: ldur            w1, [x0, #0x47]
    // 0x4530b0: DecompressPointer r1
    //     0x4530b0: add             x1, x1, HEAP, lsl #32
    // 0x4530b4: r2 = 6
    //     0x4530b4: movz            x2, #0x6
    // 0x4530b8: r0 = remove()
    //     0x4530b8: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x4530bc: r1 = Null
    //     0x4530bc: mov             x1, NULL
    // 0x4530c0: r2 = 4
    //     0x4530c0: movz            x2, #0x4
    // 0x4530c4: r0 = AllocateArray()
    //     0x4530c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4530c8: r16 = "3"
    //     0x4530c8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4530cc: ldr             x16, [x16, #0x2f0]
    // 0x4530d0: StoreField: r0->field_f = r16
    //     0x4530d0: stur            w16, [x0, #0xf]
    // 0x4530d4: r16 = "1"
    //     0x4530d4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x4530d8: ldr             x16, [x16, #0x9c8]
    // 0x4530dc: StoreField: r0->field_13 = r16
    //     0x4530dc: stur            w16, [x0, #0x13]
    // 0x4530e0: r1 = Null
    //     0x4530e0: mov             x1, NULL
    // 0x4530e4: r2 = 4
    //     0x4530e4: movz            x2, #0x4
    // 0x4530e8: r0 = AllocateArray()
    //     0x4530e8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4530ec: r16 = "3"
    //     0x4530ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4530f0: ldr             x16, [x16, #0x2f0]
    // 0x4530f4: StoreField: r0->field_f = r16
    //     0x4530f4: stur            w16, [x0, #0xf]
    // 0x4530f8: r16 = "2"
    //     0x4530f8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x4530fc: ldr             x16, [x16, #0x2e0]
    // 0x453100: StoreField: r0->field_13 = r16
    //     0x453100: stur            w16, [x0, #0x13]
    // 0x453104: r1 = Null
    //     0x453104: mov             x1, NULL
    // 0x453108: r2 = 4
    //     0x453108: movz            x2, #0x4
    // 0x45310c: r0 = AllocateArray()
    //     0x45310c: bl              #0x82746c  ; AllocateArrayStub
    // 0x453110: r16 = "3"
    //     0x453110: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x453114: ldr             x16, [x16, #0x2f0]
    // 0x453118: StoreField: r0->field_f = r16
    //     0x453118: stur            w16, [x0, #0xf]
    // 0x45311c: r16 = "3"
    //     0x45311c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x453120: ldr             x16, [x16, #0x2f0]
    // 0x453124: StoreField: r0->field_13 = r16
    //     0x453124: stur            w16, [x0, #0x13]
    // 0x453128: r1 = "31"
    //     0x453128: add             x1, PP, #0xf, lsl #12  ; [pp+0xfcf0] "31"
    //     0x45312c: ldr             x1, [x1, #0xcf0]
    // 0x453130: r2 = "33"
    //     0x453130: add             x2, PP, #0xf, lsl #12  ; [pp+0xfcf8] "33"
    //     0x453134: ldr             x2, [x2, #0xcf8]
    // 0x453138: r3 = 2
    //     0x453138: movz            x3, #0x2
    // 0x45313c: r5 = "32"
    //     0x45313c: add             x5, PP, #0xf, lsl #12  ; [pp+0xfd00] "32"
    //     0x453140: ldr             x5, [x5, #0xd00]
    // 0x453144: r0 = readMostRecentValidSaveFile()
    //     0x453144: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x453148: mov             x1, x0
    // 0x45314c: r17 = -280
    //     0x45314c: movn            x17, #0x117
    // 0x453150: str             x1, [fp, x17]
    // 0x453154: r0 = Await()
    //     0x453154: bl              #0x34b75c  ; AwaitStub
    // 0x453158: cmp             w0, NULL
    // 0x45315c: b.eq            #0x453220
    // 0x453160: LoadField: r2 = r0->field_f
    //     0x453160: ldur            w2, [x0, #0xf]
    // 0x453164: DecompressPointer r2
    //     0x453164: add             x2, x2, HEAP, lsl #32
    // 0x453168: r17 = -280
    //     0x453168: movn            x17, #0x117
    // 0x45316c: str             x2, [fp, x17]
    // 0x453170: r1 = <Stat>
    //     0x453170: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x453174: ldr             x1, [x1, #0xca0]
    // 0x453178: r0 = Chapter3GameState()
    //     0x453178: bl              #0x47177c  ; AllocateChapter3GameStateStub -> Chapter3GameState (size=0x8c)
    // 0x45317c: mov             x1, x0
    // 0x453180: r17 = -280
    //     0x453180: movn            x17, #0x117
    // 0x453184: ldr             x2, [fp, x17]
    // 0x453188: r17 = -288
    //     0x453188: movn            x17, #0x11f
    // 0x45318c: str             x0, [fp, x17]
    // 0x453190: r0 = Chapter3GameState()
    //     0x453190: bl              #0x4714b8  ; [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::Chapter3GameState
    // 0x453194: r17 = -280
    //     0x453194: movn            x17, #0x117
    // 0x453198: ldr             x1, [fp, x17]
    // 0x45319c: r0 = LoadClassIdInstr(r1)
    //     0x45319c: ldur            x0, [x1, #-1]
    //     0x4531a0: ubfx            x0, x0, #0xc, #0x14
    // 0x4531a4: r2 = 2
    //     0x4531a4: movz            x2, #0x2
    // 0x4531a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4531a8: sub             lr, x0, #1, lsl #12
    //     0x4531ac: ldr             lr, [x21, lr, lsl #3]
    //     0x4531b0: blr             lr
    // 0x4531b4: mov             x3, x0
    // 0x4531b8: r2 = Null
    //     0x4531b8: mov             x2, NULL
    // 0x4531bc: r1 = Null
    //     0x4531bc: mov             x1, NULL
    // 0x4531c0: r17 = -280
    //     0x4531c0: movn            x17, #0x117
    // 0x4531c4: str             x3, [fp, x17]
    // 0x4531c8: branchIfSmi(r0, 0x4531f0)
    //     0x4531c8: tbz             w0, #0, #0x4531f0
    // 0x4531cc: r4 = LoadClassIdInstr(r0)
    //     0x4531cc: ldur            x4, [x0, #-1]
    //     0x4531d0: ubfx            x4, x4, #0xc, #0x14
    // 0x4531d4: sub             x4, x4, #0x3c
    // 0x4531d8: cmp             x4, #1
    // 0x4531dc: b.ls            #0x4531f0
    // 0x4531e0: r8 = int?
    //     0x4531e0: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x4531e4: r3 = Null
    //     0x4531e4: add             x3, PP, #0xf, lsl #12  ; [pp+0xfd08] Null
    //     0x4531e8: ldr             x3, [x3, #0xd08]
    // 0x4531ec: r0 = int?()
    //     0x4531ec: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x4531f0: r1 = <Chapter3GameState, int?>
    //     0x4531f0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd18] TypeArguments: <Chapter3GameState, int?>
    //     0x4531f4: ldr             x1, [x1, #0xd18]
    // 0x4531f8: r0 = Tuple2()
    //     0x4531f8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4531fc: mov             x1, x0
    // 0x453200: r17 = -288
    //     0x453200: movn            x17, #0x11f
    // 0x453204: ldr             x0, [fp, x17]
    // 0x453208: StoreField: r1->field_b = r0
    //     0x453208: stur            w0, [x1, #0xb]
    // 0x45320c: r17 = -280
    //     0x45320c: movn            x17, #0x117
    // 0x453210: ldr             x0, [fp, x17]
    // 0x453214: StoreField: r1->field_f = r0
    //     0x453214: stur            w0, [x1, #0xf]
    // 0x453218: mov             x2, x1
    // 0x45321c: b               #0x453260
    // 0x453220: r1 = <Stat>
    //     0x453220: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x453224: ldr             x1, [x1, #0xca0]
    // 0x453228: r0 = Chapter3GameState()
    //     0x453228: bl              #0x47177c  ; AllocateChapter3GameStateStub -> Chapter3GameState (size=0x8c)
    // 0x45322c: mov             x1, x0
    // 0x453230: r2 = Null
    //     0x453230: mov             x2, NULL
    // 0x453234: r17 = -280
    //     0x453234: movn            x17, #0x117
    // 0x453238: str             x0, [fp, x17]
    // 0x45323c: r0 = Chapter3GameState()
    //     0x45323c: bl              #0x4714b8  ; [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::Chapter3GameState
    // 0x453240: r1 = <Chapter3GameState, int?>
    //     0x453240: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd18] TypeArguments: <Chapter3GameState, int?>
    //     0x453244: ldr             x1, [x1, #0xd18]
    // 0x453248: r0 = Tuple2()
    //     0x453248: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x45324c: mov             x1, x0
    // 0x453250: r17 = -280
    //     0x453250: movn            x17, #0x117
    // 0x453254: ldr             x0, [fp, x17]
    // 0x453258: StoreField: r1->field_b = r0
    //     0x453258: stur            w0, [x1, #0xb]
    // 0x45325c: mov             x2, x1
    // 0x453260: r17 = -272
    //     0x453260: movn            x17, #0x10f
    // 0x453264: ldr             x0, [fp, x17]
    // 0x453268: r17 = -280
    //     0x453268: movn            x17, #0x117
    // 0x45326c: str             x2, [fp, x17]
    // 0x453270: LoadField: r1 = r0->field_b
    //     0x453270: ldur            w1, [x0, #0xb]
    // 0x453274: LoadField: r3 = r0->field_f
    //     0x453274: ldur            w3, [x0, #0xf]
    // 0x453278: DecompressPointer r3
    //     0x453278: add             x3, x3, HEAP, lsl #32
    // 0x45327c: LoadField: r4 = r3->field_b
    //     0x45327c: ldur            w4, [x3, #0xb]
    // 0x453280: r3 = LoadInt32Instr(r1)
    //     0x453280: sbfx            x3, x1, #1, #0x1f
    // 0x453284: r17 = -296
    //     0x453284: movn            x17, #0x127
    // 0x453288: str             x3, [fp, x17]
    // 0x45328c: r1 = LoadInt32Instr(r4)
    //     0x45328c: sbfx            x1, x4, #1, #0x1f
    // 0x453290: cmp             x3, x1
    // 0x453294: b.ne            #0x4532a0
    // 0x453298: mov             x1, x0
    // 0x45329c: r0 = _growToNextCapacity()
    //     0x45329c: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4532a0: r17 = -272
    //     0x4532a0: movn            x17, #0x10f
    // 0x4532a4: ldr             x2, [fp, x17]
    // 0x4532a8: r17 = -296
    //     0x4532a8: movn            x17, #0x127
    // 0x4532ac: ldr             x3, [fp, x17]
    // 0x4532b0: add             x0, x3, #1
    // 0x4532b4: lsl             x1, x0, #1
    // 0x4532b8: StoreField: r2->field_b = r1
    //     0x4532b8: stur            w1, [x2, #0xb]
    // 0x4532bc: LoadField: r1 = r2->field_f
    //     0x4532bc: ldur            w1, [x2, #0xf]
    // 0x4532c0: DecompressPointer r1
    //     0x4532c0: add             x1, x1, HEAP, lsl #32
    // 0x4532c4: r17 = -280
    //     0x4532c4: movn            x17, #0x117
    // 0x4532c8: ldr             x0, [fp, x17]
    // 0x4532cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x4532cc: add             x25, x1, x3, lsl #2
    //     0x4532d0: add             x25, x25, #0xf
    //     0x4532d4: str             w0, [x25]
    //     0x4532d8: tbz             w0, #0, #0x4532f4
    //     0x4532dc: ldurb           w16, [x1, #-1]
    //     0x4532e0: ldurb           w17, [x0, #-1]
    //     0x4532e4: and             x16, x17, x16, lsr #2
    //     0x4532e8: tst             x16, HEAP, lsr #32
    //     0x4532ec: b.eq            #0x4532f4
    //     0x4532f0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4532f4: mov             x1, x2
    // 0x4532f8: r0 = last()
    //     0x4532f8: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4532fc: LoadField: r2 = r0->field_b
    //     0x4532fc: ldur            w2, [x0, #0xb]
    // 0x453300: DecompressPointer r2
    //     0x453300: add             x2, x2, HEAP, lsl #32
    // 0x453304: r17 = -272
    //     0x453304: movn            x17, #0x10f
    // 0x453308: ldr             x1, [fp, x17]
    // 0x45330c: r17 = -280
    //     0x45330c: movn            x17, #0x117
    // 0x453310: str             x2, [fp, x17]
    // 0x453314: r0 = last()
    //     0x453314: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453318: LoadField: r1 = r0->field_f
    //     0x453318: ldur            w1, [x0, #0xf]
    // 0x45331c: DecompressPointer r1
    //     0x45331c: add             x1, x1, HEAP, lsl #32
    // 0x453320: r17 = -280
    //     0x453320: movn            x17, #0x117
    // 0x453324: ldr             x2, [fp, x17]
    // 0x453328: cmp             w2, NULL
    // 0x45332c: b.eq            #0x456190
    // 0x453330: mov             x0, x1
    // 0x453334: StoreField: r2->field_b = r0
    //     0x453334: stur            w0, [x2, #0xb]
    //     0x453338: tbz             w0, #0, #0x453354
    //     0x45333c: ldurb           w16, [x2, #-1]
    //     0x453340: ldurb           w17, [x0, #-1]
    //     0x453344: and             x16, x17, x16, lsr #2
    //     0x453348: tst             x16, HEAP, lsr #32
    //     0x45334c: b.eq            #0x453354
    //     0x453350: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x453354: r0 = LoadStaticField(0xf60)
    //     0x453354: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x453358: ldr             x0, [x0, #0x1ec0]
    // 0x45335c: r17 = -272
    //     0x45335c: movn            x17, #0x10f
    // 0x453360: ldr             x1, [fp, x17]
    // 0x453364: r17 = -280
    //     0x453364: movn            x17, #0x117
    // 0x453368: str             x0, [fp, x17]
    // 0x45336c: r0 = last()
    //     0x45336c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453370: LoadField: r3 = r0->field_b
    //     0x453370: ldur            w3, [x0, #0xb]
    // 0x453374: DecompressPointer r3
    //     0x453374: add             x3, x3, HEAP, lsl #32
    // 0x453378: r17 = -280
    //     0x453378: movn            x17, #0x117
    // 0x45337c: ldr             x1, [fp, x17]
    // 0x453380: r2 = 6
    //     0x453380: movz            x2, #0x6
    // 0x453384: r0 = []=()
    //     0x453384: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x453388: r1 = Null
    //     0x453388: mov             x1, NULL
    // 0x45338c: r2 = 4
    //     0x45338c: movz            x2, #0x4
    // 0x453390: r0 = AllocateArray()
    //     0x453390: bl              #0x82746c  ; AllocateArrayStub
    // 0x453394: r16 = "4"
    //     0x453394: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x453398: ldr             x16, [x16, #0x2f8]
    // 0x45339c: StoreField: r0->field_f = r16
    //     0x45339c: stur            w16, [x0, #0xf]
    // 0x4533a0: r16 = "1"
    //     0x4533a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x4533a4: ldr             x16, [x16, #0x9c8]
    // 0x4533a8: StoreField: r0->field_13 = r16
    //     0x4533a8: stur            w16, [x0, #0x13]
    // 0x4533ac: r1 = Null
    //     0x4533ac: mov             x1, NULL
    // 0x4533b0: r2 = 4
    //     0x4533b0: movz            x2, #0x4
    // 0x4533b4: r0 = AllocateArray()
    //     0x4533b4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4533b8: r16 = "4"
    //     0x4533b8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x4533bc: ldr             x16, [x16, #0x2f8]
    // 0x4533c0: StoreField: r0->field_f = r16
    //     0x4533c0: stur            w16, [x0, #0xf]
    // 0x4533c4: r16 = "2"
    //     0x4533c4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x4533c8: ldr             x16, [x16, #0x2e0]
    // 0x4533cc: StoreField: r0->field_13 = r16
    //     0x4533cc: stur            w16, [x0, #0x13]
    // 0x4533d0: r1 = Null
    //     0x4533d0: mov             x1, NULL
    // 0x4533d4: r2 = 4
    //     0x4533d4: movz            x2, #0x4
    // 0x4533d8: r0 = AllocateArray()
    //     0x4533d8: bl              #0x82746c  ; AllocateArrayStub
    // 0x4533dc: r16 = "4"
    //     0x4533dc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x4533e0: ldr             x16, [x16, #0x2f8]
    // 0x4533e4: StoreField: r0->field_f = r16
    //     0x4533e4: stur            w16, [x0, #0xf]
    // 0x4533e8: r16 = "3"
    //     0x4533e8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4533ec: ldr             x16, [x16, #0x2f0]
    // 0x4533f0: StoreField: r0->field_13 = r16
    //     0x4533f0: stur            w16, [x0, #0x13]
    // 0x4533f4: r1 = "41"
    //     0x4533f4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd20] "41"
    //     0x4533f8: ldr             x1, [x1, #0xd20]
    // 0x4533fc: r2 = "43"
    //     0x4533fc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfd28] "43"
    //     0x453400: ldr             x2, [x2, #0xd28]
    // 0x453404: r3 = 2
    //     0x453404: movz            x3, #0x2
    // 0x453408: r5 = "42"
    //     0x453408: add             x5, PP, #0xf, lsl #12  ; [pp+0xfd30] "42"
    //     0x45340c: ldr             x5, [x5, #0xd30]
    // 0x453410: r0 = readMostRecentValidSaveFile()
    //     0x453410: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x453414: mov             x1, x0
    // 0x453418: r17 = -280
    //     0x453418: movn            x17, #0x117
    // 0x45341c: str             x1, [fp, x17]
    // 0x453420: r0 = Await()
    //     0x453420: bl              #0x34b75c  ; AwaitStub
    // 0x453424: cmp             w0, NULL
    // 0x453428: b.eq            #0x4534ec
    // 0x45342c: LoadField: r2 = r0->field_f
    //     0x45342c: ldur            w2, [x0, #0xf]
    // 0x453430: DecompressPointer r2
    //     0x453430: add             x2, x2, HEAP, lsl #32
    // 0x453434: r17 = -280
    //     0x453434: movn            x17, #0x117
    // 0x453438: str             x2, [fp, x17]
    // 0x45343c: r1 = <Stat>
    //     0x45343c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x453440: ldr             x1, [x1, #0xca0]
    // 0x453444: r0 = Chapter4GameState()
    //     0x453444: bl              #0x4714ac  ; AllocateChapter4GameStateStub -> Chapter4GameState (size=0xac)
    // 0x453448: mov             x1, x0
    // 0x45344c: r17 = -280
    //     0x45344c: movn            x17, #0x117
    // 0x453450: ldr             x2, [fp, x17]
    // 0x453454: r17 = -288
    //     0x453454: movn            x17, #0x11f
    // 0x453458: str             x0, [fp, x17]
    // 0x45345c: r0 = Chapter4GameState()
    //     0x45345c: bl              #0x470ce0  ; [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::Chapter4GameState
    // 0x453460: r17 = -280
    //     0x453460: movn            x17, #0x117
    // 0x453464: ldr             x1, [fp, x17]
    // 0x453468: r0 = LoadClassIdInstr(r1)
    //     0x453468: ldur            x0, [x1, #-1]
    //     0x45346c: ubfx            x0, x0, #0xc, #0x14
    // 0x453470: r2 = 2
    //     0x453470: movz            x2, #0x2
    // 0x453474: r0 = GDT[cid_x0 + -0x1000]()
    //     0x453474: sub             lr, x0, #1, lsl #12
    //     0x453478: ldr             lr, [x21, lr, lsl #3]
    //     0x45347c: blr             lr
    // 0x453480: mov             x3, x0
    // 0x453484: r2 = Null
    //     0x453484: mov             x2, NULL
    // 0x453488: r1 = Null
    //     0x453488: mov             x1, NULL
    // 0x45348c: r17 = -280
    //     0x45348c: movn            x17, #0x117
    // 0x453490: str             x3, [fp, x17]
    // 0x453494: branchIfSmi(r0, 0x4534bc)
    //     0x453494: tbz             w0, #0, #0x4534bc
    // 0x453498: r4 = LoadClassIdInstr(r0)
    //     0x453498: ldur            x4, [x0, #-1]
    //     0x45349c: ubfx            x4, x4, #0xc, #0x14
    // 0x4534a0: sub             x4, x4, #0x3c
    // 0x4534a4: cmp             x4, #1
    // 0x4534a8: b.ls            #0x4534bc
    // 0x4534ac: r8 = int?
    //     0x4534ac: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x4534b0: r3 = Null
    //     0x4534b0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfd38] Null
    //     0x4534b4: ldr             x3, [x3, #0xd38]
    // 0x4534b8: r0 = int?()
    //     0x4534b8: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x4534bc: r1 = <Chapter4GameState, int?>
    //     0x4534bc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd48] TypeArguments: <Chapter4GameState, int?>
    //     0x4534c0: ldr             x1, [x1, #0xd48]
    // 0x4534c4: r0 = Tuple2()
    //     0x4534c4: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4534c8: mov             x1, x0
    // 0x4534cc: r17 = -288
    //     0x4534cc: movn            x17, #0x11f
    // 0x4534d0: ldr             x0, [fp, x17]
    // 0x4534d4: StoreField: r1->field_b = r0
    //     0x4534d4: stur            w0, [x1, #0xb]
    // 0x4534d8: r17 = -280
    //     0x4534d8: movn            x17, #0x117
    // 0x4534dc: ldr             x0, [fp, x17]
    // 0x4534e0: StoreField: r1->field_f = r0
    //     0x4534e0: stur            w0, [x1, #0xf]
    // 0x4534e4: mov             x2, x1
    // 0x4534e8: b               #0x45352c
    // 0x4534ec: r1 = <Stat>
    //     0x4534ec: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x4534f0: ldr             x1, [x1, #0xca0]
    // 0x4534f4: r0 = Chapter4GameState()
    //     0x4534f4: bl              #0x4714ac  ; AllocateChapter4GameStateStub -> Chapter4GameState (size=0xac)
    // 0x4534f8: mov             x1, x0
    // 0x4534fc: r2 = Null
    //     0x4534fc: mov             x2, NULL
    // 0x453500: r17 = -280
    //     0x453500: movn            x17, #0x117
    // 0x453504: str             x0, [fp, x17]
    // 0x453508: r0 = Chapter4GameState()
    //     0x453508: bl              #0x470ce0  ; [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::Chapter4GameState
    // 0x45350c: r1 = <Chapter4GameState, int?>
    //     0x45350c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd48] TypeArguments: <Chapter4GameState, int?>
    //     0x453510: ldr             x1, [x1, #0xd48]
    // 0x453514: r0 = Tuple2()
    //     0x453514: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453518: mov             x1, x0
    // 0x45351c: r17 = -280
    //     0x45351c: movn            x17, #0x117
    // 0x453520: ldr             x0, [fp, x17]
    // 0x453524: StoreField: r1->field_b = r0
    //     0x453524: stur            w0, [x1, #0xb]
    // 0x453528: mov             x2, x1
    // 0x45352c: r17 = -272
    //     0x45352c: movn            x17, #0x10f
    // 0x453530: ldr             x0, [fp, x17]
    // 0x453534: r17 = -280
    //     0x453534: movn            x17, #0x117
    // 0x453538: str             x2, [fp, x17]
    // 0x45353c: LoadField: r1 = r0->field_b
    //     0x45353c: ldur            w1, [x0, #0xb]
    // 0x453540: LoadField: r3 = r0->field_f
    //     0x453540: ldur            w3, [x0, #0xf]
    // 0x453544: DecompressPointer r3
    //     0x453544: add             x3, x3, HEAP, lsl #32
    // 0x453548: LoadField: r4 = r3->field_b
    //     0x453548: ldur            w4, [x3, #0xb]
    // 0x45354c: r3 = LoadInt32Instr(r1)
    //     0x45354c: sbfx            x3, x1, #1, #0x1f
    // 0x453550: r17 = -296
    //     0x453550: movn            x17, #0x127
    // 0x453554: str             x3, [fp, x17]
    // 0x453558: r1 = LoadInt32Instr(r4)
    //     0x453558: sbfx            x1, x4, #1, #0x1f
    // 0x45355c: cmp             x3, x1
    // 0x453560: b.ne            #0x45356c
    // 0x453564: mov             x1, x0
    // 0x453568: r0 = _growToNextCapacity()
    //     0x453568: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x45356c: r17 = -272
    //     0x45356c: movn            x17, #0x10f
    // 0x453570: ldr             x2, [fp, x17]
    // 0x453574: r17 = -296
    //     0x453574: movn            x17, #0x127
    // 0x453578: ldr             x3, [fp, x17]
    // 0x45357c: add             x0, x3, #1
    // 0x453580: lsl             x1, x0, #1
    // 0x453584: StoreField: r2->field_b = r1
    //     0x453584: stur            w1, [x2, #0xb]
    // 0x453588: LoadField: r1 = r2->field_f
    //     0x453588: ldur            w1, [x2, #0xf]
    // 0x45358c: DecompressPointer r1
    //     0x45358c: add             x1, x1, HEAP, lsl #32
    // 0x453590: r17 = -280
    //     0x453590: movn            x17, #0x117
    // 0x453594: ldr             x0, [fp, x17]
    // 0x453598: ArrayStore: r1[r3] = r0  ; List_4
    //     0x453598: add             x25, x1, x3, lsl #2
    //     0x45359c: add             x25, x25, #0xf
    //     0x4535a0: str             w0, [x25]
    //     0x4535a4: tbz             w0, #0, #0x4535c0
    //     0x4535a8: ldurb           w16, [x1, #-1]
    //     0x4535ac: ldurb           w17, [x0, #-1]
    //     0x4535b0: and             x16, x17, x16, lsr #2
    //     0x4535b4: tst             x16, HEAP, lsr #32
    //     0x4535b8: b.eq            #0x4535c0
    //     0x4535bc: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4535c0: mov             x1, x2
    // 0x4535c4: r0 = last()
    //     0x4535c4: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4535c8: LoadField: r2 = r0->field_b
    //     0x4535c8: ldur            w2, [x0, #0xb]
    // 0x4535cc: DecompressPointer r2
    //     0x4535cc: add             x2, x2, HEAP, lsl #32
    // 0x4535d0: r17 = -272
    //     0x4535d0: movn            x17, #0x10f
    // 0x4535d4: ldr             x1, [fp, x17]
    // 0x4535d8: r17 = -280
    //     0x4535d8: movn            x17, #0x117
    // 0x4535dc: str             x2, [fp, x17]
    // 0x4535e0: r0 = last()
    //     0x4535e0: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4535e4: LoadField: r1 = r0->field_f
    //     0x4535e4: ldur            w1, [x0, #0xf]
    // 0x4535e8: DecompressPointer r1
    //     0x4535e8: add             x1, x1, HEAP, lsl #32
    // 0x4535ec: r17 = -280
    //     0x4535ec: movn            x17, #0x117
    // 0x4535f0: ldr             x2, [fp, x17]
    // 0x4535f4: cmp             w2, NULL
    // 0x4535f8: b.eq            #0x456194
    // 0x4535fc: mov             x0, x1
    // 0x453600: StoreField: r2->field_b = r0
    //     0x453600: stur            w0, [x2, #0xb]
    //     0x453604: tbz             w0, #0, #0x453620
    //     0x453608: ldurb           w16, [x2, #-1]
    //     0x45360c: ldurb           w17, [x0, #-1]
    //     0x453610: and             x16, x17, x16, lsr #2
    //     0x453614: tst             x16, HEAP, lsr #32
    //     0x453618: b.eq            #0x453620
    //     0x45361c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x453620: r0 = LoadStaticField(0xf60)
    //     0x453620: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x453624: ldr             x0, [x0, #0x1ec0]
    // 0x453628: r17 = -272
    //     0x453628: movn            x17, #0x10f
    // 0x45362c: ldr             x1, [fp, x17]
    // 0x453630: r17 = -280
    //     0x453630: movn            x17, #0x117
    // 0x453634: str             x0, [fp, x17]
    // 0x453638: r0 = last()
    //     0x453638: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x45363c: LoadField: r3 = r0->field_b
    //     0x45363c: ldur            w3, [x0, #0xb]
    // 0x453640: DecompressPointer r3
    //     0x453640: add             x3, x3, HEAP, lsl #32
    // 0x453644: r17 = -280
    //     0x453644: movn            x17, #0x117
    // 0x453648: ldr             x1, [fp, x17]
    // 0x45364c: r2 = 8
    //     0x45364c: movz            x2, #0x8
    // 0x453650: r0 = []=()
    //     0x453650: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x453654: r1 = Null
    //     0x453654: mov             x1, NULL
    // 0x453658: r2 = 4
    //     0x453658: movz            x2, #0x4
    // 0x45365c: r0 = AllocateArray()
    //     0x45365c: bl              #0x82746c  ; AllocateArrayStub
    // 0x453660: r16 = "5"
    //     0x453660: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x453664: ldr             x16, [x16, #0x300]
    // 0x453668: StoreField: r0->field_f = r16
    //     0x453668: stur            w16, [x0, #0xf]
    // 0x45366c: r16 = "1"
    //     0x45366c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x453670: ldr             x16, [x16, #0x9c8]
    // 0x453674: StoreField: r0->field_13 = r16
    //     0x453674: stur            w16, [x0, #0x13]
    // 0x453678: r1 = Null
    //     0x453678: mov             x1, NULL
    // 0x45367c: r2 = 4
    //     0x45367c: movz            x2, #0x4
    // 0x453680: r0 = AllocateArray()
    //     0x453680: bl              #0x82746c  ; AllocateArrayStub
    // 0x453684: r16 = "5"
    //     0x453684: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x453688: ldr             x16, [x16, #0x300]
    // 0x45368c: StoreField: r0->field_f = r16
    //     0x45368c: stur            w16, [x0, #0xf]
    // 0x453690: r16 = "2"
    //     0x453690: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x453694: ldr             x16, [x16, #0x2e0]
    // 0x453698: StoreField: r0->field_13 = r16
    //     0x453698: stur            w16, [x0, #0x13]
    // 0x45369c: r1 = Null
    //     0x45369c: mov             x1, NULL
    // 0x4536a0: r2 = 4
    //     0x4536a0: movz            x2, #0x4
    // 0x4536a4: r0 = AllocateArray()
    //     0x4536a4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4536a8: r16 = "5"
    //     0x4536a8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x4536ac: ldr             x16, [x16, #0x300]
    // 0x4536b0: StoreField: r0->field_f = r16
    //     0x4536b0: stur            w16, [x0, #0xf]
    // 0x4536b4: r16 = "3"
    //     0x4536b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4536b8: ldr             x16, [x16, #0x2f0]
    // 0x4536bc: StoreField: r0->field_13 = r16
    //     0x4536bc: stur            w16, [x0, #0x13]
    // 0x4536c0: r1 = "51"
    //     0x4536c0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd50] "51"
    //     0x4536c4: ldr             x1, [x1, #0xd50]
    // 0x4536c8: r2 = "53"
    //     0x4536c8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfd58] "53"
    //     0x4536cc: ldr             x2, [x2, #0xd58]
    // 0x4536d0: r3 = 2
    //     0x4536d0: movz            x3, #0x2
    // 0x4536d4: r5 = "52"
    //     0x4536d4: add             x5, PP, #0xf, lsl #12  ; [pp+0xfd60] "52"
    //     0x4536d8: ldr             x5, [x5, #0xd60]
    // 0x4536dc: r0 = readMostRecentValidSaveFile()
    //     0x4536dc: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4536e0: mov             x1, x0
    // 0x4536e4: r17 = -280
    //     0x4536e4: movn            x17, #0x117
    // 0x4536e8: str             x1, [fp, x17]
    // 0x4536ec: r0 = Await()
    //     0x4536ec: bl              #0x34b75c  ; AwaitStub
    // 0x4536f0: cmp             w0, NULL
    // 0x4536f4: b.eq            #0x4537b8
    // 0x4536f8: LoadField: r2 = r0->field_f
    //     0x4536f8: ldur            w2, [x0, #0xf]
    // 0x4536fc: DecompressPointer r2
    //     0x4536fc: add             x2, x2, HEAP, lsl #32
    // 0x453700: r17 = -280
    //     0x453700: movn            x17, #0x117
    // 0x453704: str             x2, [fp, x17]
    // 0x453708: r1 = <Chapter5Stat>
    //     0x453708: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd68] TypeArguments: <Chapter5Stat>
    //     0x45370c: ldr             x1, [x1, #0xd68]
    // 0x453710: r0 = Chapter5GameState()
    //     0x453710: bl              #0x470cd4  ; AllocateChapter5GameStateStub -> Chapter5GameState (size=0x94)
    // 0x453714: mov             x1, x0
    // 0x453718: r17 = -280
    //     0x453718: movn            x17, #0x117
    // 0x45371c: ldr             x2, [fp, x17]
    // 0x453720: r17 = -288
    //     0x453720: movn            x17, #0x11f
    // 0x453724: str             x0, [fp, x17]
    // 0x453728: r0 = Chapter5GameState()
    //     0x453728: bl              #0x470344  ; [package:pretentious/data/Chapters/Chapter5GameState.dart] Chapter5GameState::Chapter5GameState
    // 0x45372c: r17 = -280
    //     0x45372c: movn            x17, #0x117
    // 0x453730: ldr             x1, [fp, x17]
    // 0x453734: r0 = LoadClassIdInstr(r1)
    //     0x453734: ldur            x0, [x1, #-1]
    //     0x453738: ubfx            x0, x0, #0xc, #0x14
    // 0x45373c: r2 = 2
    //     0x45373c: movz            x2, #0x2
    // 0x453740: r0 = GDT[cid_x0 + -0x1000]()
    //     0x453740: sub             lr, x0, #1, lsl #12
    //     0x453744: ldr             lr, [x21, lr, lsl #3]
    //     0x453748: blr             lr
    // 0x45374c: mov             x3, x0
    // 0x453750: r2 = Null
    //     0x453750: mov             x2, NULL
    // 0x453754: r1 = Null
    //     0x453754: mov             x1, NULL
    // 0x453758: r17 = -280
    //     0x453758: movn            x17, #0x117
    // 0x45375c: str             x3, [fp, x17]
    // 0x453760: branchIfSmi(r0, 0x453788)
    //     0x453760: tbz             w0, #0, #0x453788
    // 0x453764: r4 = LoadClassIdInstr(r0)
    //     0x453764: ldur            x4, [x0, #-1]
    //     0x453768: ubfx            x4, x4, #0xc, #0x14
    // 0x45376c: sub             x4, x4, #0x3c
    // 0x453770: cmp             x4, #1
    // 0x453774: b.ls            #0x453788
    // 0x453778: r8 = int?
    //     0x453778: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x45377c: r3 = Null
    //     0x45377c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfd70] Null
    //     0x453780: ldr             x3, [x3, #0xd70]
    // 0x453784: r0 = int?()
    //     0x453784: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x453788: r1 = <Chapter5GameState, int?>
    //     0x453788: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd80] TypeArguments: <Chapter5GameState, int?>
    //     0x45378c: ldr             x1, [x1, #0xd80]
    // 0x453790: r0 = Tuple2()
    //     0x453790: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453794: mov             x1, x0
    // 0x453798: r17 = -288
    //     0x453798: movn            x17, #0x11f
    // 0x45379c: ldr             x0, [fp, x17]
    // 0x4537a0: StoreField: r1->field_b = r0
    //     0x4537a0: stur            w0, [x1, #0xb]
    // 0x4537a4: r17 = -280
    //     0x4537a4: movn            x17, #0x117
    // 0x4537a8: ldr             x0, [fp, x17]
    // 0x4537ac: StoreField: r1->field_f = r0
    //     0x4537ac: stur            w0, [x1, #0xf]
    // 0x4537b0: mov             x2, x1
    // 0x4537b4: b               #0x4537f8
    // 0x4537b8: r1 = <Chapter5Stat>
    //     0x4537b8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd68] TypeArguments: <Chapter5Stat>
    //     0x4537bc: ldr             x1, [x1, #0xd68]
    // 0x4537c0: r0 = Chapter5GameState()
    //     0x4537c0: bl              #0x470cd4  ; AllocateChapter5GameStateStub -> Chapter5GameState (size=0x94)
    // 0x4537c4: mov             x1, x0
    // 0x4537c8: r2 = Null
    //     0x4537c8: mov             x2, NULL
    // 0x4537cc: r17 = -280
    //     0x4537cc: movn            x17, #0x117
    // 0x4537d0: str             x0, [fp, x17]
    // 0x4537d4: r0 = Chapter5GameState()
    //     0x4537d4: bl              #0x470344  ; [package:pretentious/data/Chapters/Chapter5GameState.dart] Chapter5GameState::Chapter5GameState
    // 0x4537d8: r1 = <Chapter5GameState, int?>
    //     0x4537d8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd80] TypeArguments: <Chapter5GameState, int?>
    //     0x4537dc: ldr             x1, [x1, #0xd80]
    // 0x4537e0: r0 = Tuple2()
    //     0x4537e0: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4537e4: mov             x1, x0
    // 0x4537e8: r17 = -280
    //     0x4537e8: movn            x17, #0x117
    // 0x4537ec: ldr             x0, [fp, x17]
    // 0x4537f0: StoreField: r1->field_b = r0
    //     0x4537f0: stur            w0, [x1, #0xb]
    // 0x4537f4: mov             x2, x1
    // 0x4537f8: r17 = -272
    //     0x4537f8: movn            x17, #0x10f
    // 0x4537fc: ldr             x0, [fp, x17]
    // 0x453800: r17 = -280
    //     0x453800: movn            x17, #0x117
    // 0x453804: str             x2, [fp, x17]
    // 0x453808: LoadField: r1 = r0->field_b
    //     0x453808: ldur            w1, [x0, #0xb]
    // 0x45380c: LoadField: r3 = r0->field_f
    //     0x45380c: ldur            w3, [x0, #0xf]
    // 0x453810: DecompressPointer r3
    //     0x453810: add             x3, x3, HEAP, lsl #32
    // 0x453814: LoadField: r4 = r3->field_b
    //     0x453814: ldur            w4, [x3, #0xb]
    // 0x453818: r3 = LoadInt32Instr(r1)
    //     0x453818: sbfx            x3, x1, #1, #0x1f
    // 0x45381c: r17 = -296
    //     0x45381c: movn            x17, #0x127
    // 0x453820: str             x3, [fp, x17]
    // 0x453824: r1 = LoadInt32Instr(r4)
    //     0x453824: sbfx            x1, x4, #1, #0x1f
    // 0x453828: cmp             x3, x1
    // 0x45382c: b.ne            #0x453838
    // 0x453830: mov             x1, x0
    // 0x453834: r0 = _growToNextCapacity()
    //     0x453834: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x453838: r17 = -272
    //     0x453838: movn            x17, #0x10f
    // 0x45383c: ldr             x2, [fp, x17]
    // 0x453840: r17 = -296
    //     0x453840: movn            x17, #0x127
    // 0x453844: ldr             x3, [fp, x17]
    // 0x453848: add             x0, x3, #1
    // 0x45384c: lsl             x1, x0, #1
    // 0x453850: StoreField: r2->field_b = r1
    //     0x453850: stur            w1, [x2, #0xb]
    // 0x453854: LoadField: r1 = r2->field_f
    //     0x453854: ldur            w1, [x2, #0xf]
    // 0x453858: DecompressPointer r1
    //     0x453858: add             x1, x1, HEAP, lsl #32
    // 0x45385c: r17 = -280
    //     0x45385c: movn            x17, #0x117
    // 0x453860: ldr             x0, [fp, x17]
    // 0x453864: ArrayStore: r1[r3] = r0  ; List_4
    //     0x453864: add             x25, x1, x3, lsl #2
    //     0x453868: add             x25, x25, #0xf
    //     0x45386c: str             w0, [x25]
    //     0x453870: tbz             w0, #0, #0x45388c
    //     0x453874: ldurb           w16, [x1, #-1]
    //     0x453878: ldurb           w17, [x0, #-1]
    //     0x45387c: and             x16, x17, x16, lsr #2
    //     0x453880: tst             x16, HEAP, lsr #32
    //     0x453884: b.eq            #0x45388c
    //     0x453888: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x45388c: mov             x1, x2
    // 0x453890: r0 = last()
    //     0x453890: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453894: LoadField: r2 = r0->field_b
    //     0x453894: ldur            w2, [x0, #0xb]
    // 0x453898: DecompressPointer r2
    //     0x453898: add             x2, x2, HEAP, lsl #32
    // 0x45389c: r17 = -272
    //     0x45389c: movn            x17, #0x10f
    // 0x4538a0: ldr             x1, [fp, x17]
    // 0x4538a4: r17 = -280
    //     0x4538a4: movn            x17, #0x117
    // 0x4538a8: str             x2, [fp, x17]
    // 0x4538ac: r0 = last()
    //     0x4538ac: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4538b0: LoadField: r1 = r0->field_f
    //     0x4538b0: ldur            w1, [x0, #0xf]
    // 0x4538b4: DecompressPointer r1
    //     0x4538b4: add             x1, x1, HEAP, lsl #32
    // 0x4538b8: r17 = -280
    //     0x4538b8: movn            x17, #0x117
    // 0x4538bc: ldr             x2, [fp, x17]
    // 0x4538c0: cmp             w2, NULL
    // 0x4538c4: b.eq            #0x456198
    // 0x4538c8: mov             x0, x1
    // 0x4538cc: StoreField: r2->field_b = r0
    //     0x4538cc: stur            w0, [x2, #0xb]
    //     0x4538d0: tbz             w0, #0, #0x4538ec
    //     0x4538d4: ldurb           w16, [x2, #-1]
    //     0x4538d8: ldurb           w17, [x0, #-1]
    //     0x4538dc: and             x16, x17, x16, lsr #2
    //     0x4538e0: tst             x16, HEAP, lsr #32
    //     0x4538e4: b.eq            #0x4538ec
    //     0x4538e8: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x4538ec: r0 = LoadStaticField(0xf60)
    //     0x4538ec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4538f0: ldr             x0, [x0, #0x1ec0]
    // 0x4538f4: r17 = -272
    //     0x4538f4: movn            x17, #0x10f
    // 0x4538f8: ldr             x1, [fp, x17]
    // 0x4538fc: r17 = -280
    //     0x4538fc: movn            x17, #0x117
    // 0x453900: str             x0, [fp, x17]
    // 0x453904: r0 = last()
    //     0x453904: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453908: LoadField: r3 = r0->field_b
    //     0x453908: ldur            w3, [x0, #0xb]
    // 0x45390c: DecompressPointer r3
    //     0x45390c: add             x3, x3, HEAP, lsl #32
    // 0x453910: r17 = -280
    //     0x453910: movn            x17, #0x117
    // 0x453914: ldr             x1, [fp, x17]
    // 0x453918: r2 = 10
    //     0x453918: movz            x2, #0xa
    // 0x45391c: r0 = []=()
    //     0x45391c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x453920: r1 = Null
    //     0x453920: mov             x1, NULL
    // 0x453924: r2 = 4
    //     0x453924: movz            x2, #0x4
    // 0x453928: r0 = AllocateArray()
    //     0x453928: bl              #0x82746c  ; AllocateArrayStub
    // 0x45392c: r16 = "6"
    //     0x45392c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x453930: ldr             x16, [x16, #0x308]
    // 0x453934: StoreField: r0->field_f = r16
    //     0x453934: stur            w16, [x0, #0xf]
    // 0x453938: r16 = "1"
    //     0x453938: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x45393c: ldr             x16, [x16, #0x9c8]
    // 0x453940: StoreField: r0->field_13 = r16
    //     0x453940: stur            w16, [x0, #0x13]
    // 0x453944: r1 = Null
    //     0x453944: mov             x1, NULL
    // 0x453948: r2 = 4
    //     0x453948: movz            x2, #0x4
    // 0x45394c: r0 = AllocateArray()
    //     0x45394c: bl              #0x82746c  ; AllocateArrayStub
    // 0x453950: r16 = "6"
    //     0x453950: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x453954: ldr             x16, [x16, #0x308]
    // 0x453958: StoreField: r0->field_f = r16
    //     0x453958: stur            w16, [x0, #0xf]
    // 0x45395c: r16 = "2"
    //     0x45395c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x453960: ldr             x16, [x16, #0x2e0]
    // 0x453964: StoreField: r0->field_13 = r16
    //     0x453964: stur            w16, [x0, #0x13]
    // 0x453968: r1 = Null
    //     0x453968: mov             x1, NULL
    // 0x45396c: r2 = 4
    //     0x45396c: movz            x2, #0x4
    // 0x453970: r0 = AllocateArray()
    //     0x453970: bl              #0x82746c  ; AllocateArrayStub
    // 0x453974: r16 = "6"
    //     0x453974: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x453978: ldr             x16, [x16, #0x308]
    // 0x45397c: StoreField: r0->field_f = r16
    //     0x45397c: stur            w16, [x0, #0xf]
    // 0x453980: r16 = "3"
    //     0x453980: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x453984: ldr             x16, [x16, #0x2f0]
    // 0x453988: StoreField: r0->field_13 = r16
    //     0x453988: stur            w16, [x0, #0x13]
    // 0x45398c: r1 = "61"
    //     0x45398c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd88] "61"
    //     0x453990: ldr             x1, [x1, #0xd88]
    // 0x453994: r2 = "63"
    //     0x453994: add             x2, PP, #0xf, lsl #12  ; [pp+0xfd90] "63"
    //     0x453998: ldr             x2, [x2, #0xd90]
    // 0x45399c: r3 = 2
    //     0x45399c: movz            x3, #0x2
    // 0x4539a0: r5 = "62"
    //     0x4539a0: add             x5, PP, #0xf, lsl #12  ; [pp+0xfd98] "62"
    //     0x4539a4: ldr             x5, [x5, #0xd98]
    // 0x4539a8: r0 = readMostRecentValidSaveFile()
    //     0x4539a8: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4539ac: mov             x1, x0
    // 0x4539b0: r17 = -280
    //     0x4539b0: movn            x17, #0x117
    // 0x4539b4: str             x1, [fp, x17]
    // 0x4539b8: r0 = Await()
    //     0x4539b8: bl              #0x34b75c  ; AwaitStub
    // 0x4539bc: cmp             w0, NULL
    // 0x4539c0: b.eq            #0x453a84
    // 0x4539c4: LoadField: r2 = r0->field_f
    //     0x4539c4: ldur            w2, [x0, #0xf]
    // 0x4539c8: DecompressPointer r2
    //     0x4539c8: add             x2, x2, HEAP, lsl #32
    // 0x4539cc: r17 = -280
    //     0x4539cc: movn            x17, #0x117
    // 0x4539d0: str             x2, [fp, x17]
    // 0x4539d4: r1 = <Chapter6Stat>
    //     0x4539d4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfda0] TypeArguments: <Chapter6Stat>
    //     0x4539d8: ldr             x1, [x1, #0xda0]
    // 0x4539dc: r0 = Chapter6GameState()
    //     0x4539dc: bl              #0x470338  ; AllocateChapter6GameStateStub -> Chapter6GameState (size=0xa0)
    // 0x4539e0: mov             x1, x0
    // 0x4539e4: r17 = -280
    //     0x4539e4: movn            x17, #0x117
    // 0x4539e8: ldr             x2, [fp, x17]
    // 0x4539ec: r17 = -288
    //     0x4539ec: movn            x17, #0x11f
    // 0x4539f0: str             x0, [fp, x17]
    // 0x4539f4: r0 = Chapter6GameState()
    //     0x4539f4: bl              #0x46ffac  ; [package:pretentious/data/Chapters/Chapter6GameState.dart] Chapter6GameState::Chapter6GameState
    // 0x4539f8: r17 = -280
    //     0x4539f8: movn            x17, #0x117
    // 0x4539fc: ldr             x1, [fp, x17]
    // 0x453a00: r0 = LoadClassIdInstr(r1)
    //     0x453a00: ldur            x0, [x1, #-1]
    //     0x453a04: ubfx            x0, x0, #0xc, #0x14
    // 0x453a08: r2 = 2
    //     0x453a08: movz            x2, #0x2
    // 0x453a0c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x453a0c: sub             lr, x0, #1, lsl #12
    //     0x453a10: ldr             lr, [x21, lr, lsl #3]
    //     0x453a14: blr             lr
    // 0x453a18: mov             x3, x0
    // 0x453a1c: r2 = Null
    //     0x453a1c: mov             x2, NULL
    // 0x453a20: r1 = Null
    //     0x453a20: mov             x1, NULL
    // 0x453a24: r17 = -280
    //     0x453a24: movn            x17, #0x117
    // 0x453a28: str             x3, [fp, x17]
    // 0x453a2c: branchIfSmi(r0, 0x453a54)
    //     0x453a2c: tbz             w0, #0, #0x453a54
    // 0x453a30: r4 = LoadClassIdInstr(r0)
    //     0x453a30: ldur            x4, [x0, #-1]
    //     0x453a34: ubfx            x4, x4, #0xc, #0x14
    // 0x453a38: sub             x4, x4, #0x3c
    // 0x453a3c: cmp             x4, #1
    // 0x453a40: b.ls            #0x453a54
    // 0x453a44: r8 = int?
    //     0x453a44: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x453a48: r3 = Null
    //     0x453a48: add             x3, PP, #0xf, lsl #12  ; [pp+0xfda8] Null
    //     0x453a4c: ldr             x3, [x3, #0xda8]
    // 0x453a50: r0 = int?()
    //     0x453a50: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x453a54: r1 = <Chapter6GameState, int?>
    //     0x453a54: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdb8] TypeArguments: <Chapter6GameState, int?>
    //     0x453a58: ldr             x1, [x1, #0xdb8]
    // 0x453a5c: r0 = Tuple2()
    //     0x453a5c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453a60: mov             x1, x0
    // 0x453a64: r17 = -288
    //     0x453a64: movn            x17, #0x11f
    // 0x453a68: ldr             x0, [fp, x17]
    // 0x453a6c: StoreField: r1->field_b = r0
    //     0x453a6c: stur            w0, [x1, #0xb]
    // 0x453a70: r17 = -280
    //     0x453a70: movn            x17, #0x117
    // 0x453a74: ldr             x0, [fp, x17]
    // 0x453a78: StoreField: r1->field_f = r0
    //     0x453a78: stur            w0, [x1, #0xf]
    // 0x453a7c: mov             x2, x1
    // 0x453a80: b               #0x453ac4
    // 0x453a84: r1 = <Chapter6Stat>
    //     0x453a84: add             x1, PP, #0xf, lsl #12  ; [pp+0xfda0] TypeArguments: <Chapter6Stat>
    //     0x453a88: ldr             x1, [x1, #0xda0]
    // 0x453a8c: r0 = Chapter6GameState()
    //     0x453a8c: bl              #0x470338  ; AllocateChapter6GameStateStub -> Chapter6GameState (size=0xa0)
    // 0x453a90: mov             x1, x0
    // 0x453a94: r2 = Null
    //     0x453a94: mov             x2, NULL
    // 0x453a98: r17 = -280
    //     0x453a98: movn            x17, #0x117
    // 0x453a9c: str             x0, [fp, x17]
    // 0x453aa0: r0 = Chapter6GameState()
    //     0x453aa0: bl              #0x46ffac  ; [package:pretentious/data/Chapters/Chapter6GameState.dart] Chapter6GameState::Chapter6GameState
    // 0x453aa4: r1 = <Chapter6GameState, int?>
    //     0x453aa4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdb8] TypeArguments: <Chapter6GameState, int?>
    //     0x453aa8: ldr             x1, [x1, #0xdb8]
    // 0x453aac: r0 = Tuple2()
    //     0x453aac: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453ab0: mov             x1, x0
    // 0x453ab4: r17 = -280
    //     0x453ab4: movn            x17, #0x117
    // 0x453ab8: ldr             x0, [fp, x17]
    // 0x453abc: StoreField: r1->field_b = r0
    //     0x453abc: stur            w0, [x1, #0xb]
    // 0x453ac0: mov             x2, x1
    // 0x453ac4: r17 = -272
    //     0x453ac4: movn            x17, #0x10f
    // 0x453ac8: ldr             x0, [fp, x17]
    // 0x453acc: r17 = -280
    //     0x453acc: movn            x17, #0x117
    // 0x453ad0: str             x2, [fp, x17]
    // 0x453ad4: LoadField: r1 = r0->field_b
    //     0x453ad4: ldur            w1, [x0, #0xb]
    // 0x453ad8: LoadField: r3 = r0->field_f
    //     0x453ad8: ldur            w3, [x0, #0xf]
    // 0x453adc: DecompressPointer r3
    //     0x453adc: add             x3, x3, HEAP, lsl #32
    // 0x453ae0: LoadField: r4 = r3->field_b
    //     0x453ae0: ldur            w4, [x3, #0xb]
    // 0x453ae4: r3 = LoadInt32Instr(r1)
    //     0x453ae4: sbfx            x3, x1, #1, #0x1f
    // 0x453ae8: r17 = -296
    //     0x453ae8: movn            x17, #0x127
    // 0x453aec: str             x3, [fp, x17]
    // 0x453af0: r1 = LoadInt32Instr(r4)
    //     0x453af0: sbfx            x1, x4, #1, #0x1f
    // 0x453af4: cmp             x3, x1
    // 0x453af8: b.ne            #0x453b04
    // 0x453afc: mov             x1, x0
    // 0x453b00: r0 = _growToNextCapacity()
    //     0x453b00: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x453b04: r17 = -272
    //     0x453b04: movn            x17, #0x10f
    // 0x453b08: ldr             x2, [fp, x17]
    // 0x453b0c: r17 = -296
    //     0x453b0c: movn            x17, #0x127
    // 0x453b10: ldr             x3, [fp, x17]
    // 0x453b14: add             x0, x3, #1
    // 0x453b18: lsl             x1, x0, #1
    // 0x453b1c: StoreField: r2->field_b = r1
    //     0x453b1c: stur            w1, [x2, #0xb]
    // 0x453b20: LoadField: r1 = r2->field_f
    //     0x453b20: ldur            w1, [x2, #0xf]
    // 0x453b24: DecompressPointer r1
    //     0x453b24: add             x1, x1, HEAP, lsl #32
    // 0x453b28: r17 = -280
    //     0x453b28: movn            x17, #0x117
    // 0x453b2c: ldr             x0, [fp, x17]
    // 0x453b30: ArrayStore: r1[r3] = r0  ; List_4
    //     0x453b30: add             x25, x1, x3, lsl #2
    //     0x453b34: add             x25, x25, #0xf
    //     0x453b38: str             w0, [x25]
    //     0x453b3c: tbz             w0, #0, #0x453b58
    //     0x453b40: ldurb           w16, [x1, #-1]
    //     0x453b44: ldurb           w17, [x0, #-1]
    //     0x453b48: and             x16, x17, x16, lsr #2
    //     0x453b4c: tst             x16, HEAP, lsr #32
    //     0x453b50: b.eq            #0x453b58
    //     0x453b54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x453b58: mov             x1, x2
    // 0x453b5c: r0 = last()
    //     0x453b5c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453b60: LoadField: r2 = r0->field_b
    //     0x453b60: ldur            w2, [x0, #0xb]
    // 0x453b64: DecompressPointer r2
    //     0x453b64: add             x2, x2, HEAP, lsl #32
    // 0x453b68: r17 = -272
    //     0x453b68: movn            x17, #0x10f
    // 0x453b6c: ldr             x1, [fp, x17]
    // 0x453b70: r17 = -280
    //     0x453b70: movn            x17, #0x117
    // 0x453b74: str             x2, [fp, x17]
    // 0x453b78: r0 = last()
    //     0x453b78: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453b7c: LoadField: r1 = r0->field_f
    //     0x453b7c: ldur            w1, [x0, #0xf]
    // 0x453b80: DecompressPointer r1
    //     0x453b80: add             x1, x1, HEAP, lsl #32
    // 0x453b84: r17 = -280
    //     0x453b84: movn            x17, #0x117
    // 0x453b88: ldr             x2, [fp, x17]
    // 0x453b8c: cmp             w2, NULL
    // 0x453b90: b.eq            #0x45619c
    // 0x453b94: mov             x0, x1
    // 0x453b98: StoreField: r2->field_b = r0
    //     0x453b98: stur            w0, [x2, #0xb]
    //     0x453b9c: tbz             w0, #0, #0x453bb8
    //     0x453ba0: ldurb           w16, [x2, #-1]
    //     0x453ba4: ldurb           w17, [x0, #-1]
    //     0x453ba8: and             x16, x17, x16, lsr #2
    //     0x453bac: tst             x16, HEAP, lsr #32
    //     0x453bb0: b.eq            #0x453bb8
    //     0x453bb4: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x453bb8: r0 = LoadStaticField(0xf60)
    //     0x453bb8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x453bbc: ldr             x0, [x0, #0x1ec0]
    // 0x453bc0: r17 = -272
    //     0x453bc0: movn            x17, #0x10f
    // 0x453bc4: ldr             x1, [fp, x17]
    // 0x453bc8: r17 = -280
    //     0x453bc8: movn            x17, #0x117
    // 0x453bcc: str             x0, [fp, x17]
    // 0x453bd0: r0 = last()
    //     0x453bd0: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453bd4: LoadField: r3 = r0->field_b
    //     0x453bd4: ldur            w3, [x0, #0xb]
    // 0x453bd8: DecompressPointer r3
    //     0x453bd8: add             x3, x3, HEAP, lsl #32
    // 0x453bdc: r17 = -280
    //     0x453bdc: movn            x17, #0x117
    // 0x453be0: ldr             x1, [fp, x17]
    // 0x453be4: r2 = 12
    //     0x453be4: movz            x2, #0xc
    // 0x453be8: r0 = []=()
    //     0x453be8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x453bec: r1 = Null
    //     0x453bec: mov             x1, NULL
    // 0x453bf0: r2 = 4
    //     0x453bf0: movz            x2, #0x4
    // 0x453bf4: r0 = AllocateArray()
    //     0x453bf4: bl              #0x82746c  ; AllocateArrayStub
    // 0x453bf8: r16 = "7"
    //     0x453bf8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x453bfc: ldr             x16, [x16, #0x310]
    // 0x453c00: StoreField: r0->field_f = r16
    //     0x453c00: stur            w16, [x0, #0xf]
    // 0x453c04: r16 = "1"
    //     0x453c04: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x453c08: ldr             x16, [x16, #0x9c8]
    // 0x453c0c: StoreField: r0->field_13 = r16
    //     0x453c0c: stur            w16, [x0, #0x13]
    // 0x453c10: r1 = Null
    //     0x453c10: mov             x1, NULL
    // 0x453c14: r2 = 4
    //     0x453c14: movz            x2, #0x4
    // 0x453c18: r0 = AllocateArray()
    //     0x453c18: bl              #0x82746c  ; AllocateArrayStub
    // 0x453c1c: r16 = "7"
    //     0x453c1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x453c20: ldr             x16, [x16, #0x310]
    // 0x453c24: StoreField: r0->field_f = r16
    //     0x453c24: stur            w16, [x0, #0xf]
    // 0x453c28: r16 = "2"
    //     0x453c28: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x453c2c: ldr             x16, [x16, #0x2e0]
    // 0x453c30: StoreField: r0->field_13 = r16
    //     0x453c30: stur            w16, [x0, #0x13]
    // 0x453c34: r1 = Null
    //     0x453c34: mov             x1, NULL
    // 0x453c38: r2 = 4
    //     0x453c38: movz            x2, #0x4
    // 0x453c3c: r0 = AllocateArray()
    //     0x453c3c: bl              #0x82746c  ; AllocateArrayStub
    // 0x453c40: r16 = "7"
    //     0x453c40: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x453c44: ldr             x16, [x16, #0x310]
    // 0x453c48: StoreField: r0->field_f = r16
    //     0x453c48: stur            w16, [x0, #0xf]
    // 0x453c4c: r16 = "3"
    //     0x453c4c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x453c50: ldr             x16, [x16, #0x2f0]
    // 0x453c54: StoreField: r0->field_13 = r16
    //     0x453c54: stur            w16, [x0, #0x13]
    // 0x453c58: r1 = "71"
    //     0x453c58: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdc0] "71"
    //     0x453c5c: ldr             x1, [x1, #0xdc0]
    // 0x453c60: r2 = "73"
    //     0x453c60: add             x2, PP, #0xf, lsl #12  ; [pp+0xfdc8] "73"
    //     0x453c64: ldr             x2, [x2, #0xdc8]
    // 0x453c68: r3 = 2
    //     0x453c68: movz            x3, #0x2
    // 0x453c6c: r5 = "72"
    //     0x453c6c: add             x5, PP, #0xf, lsl #12  ; [pp+0xfdd0] "72"
    //     0x453c70: ldr             x5, [x5, #0xdd0]
    // 0x453c74: r0 = readMostRecentValidSaveFile()
    //     0x453c74: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x453c78: mov             x1, x0
    // 0x453c7c: r17 = -280
    //     0x453c7c: movn            x17, #0x117
    // 0x453c80: str             x1, [fp, x17]
    // 0x453c84: r0 = Await()
    //     0x453c84: bl              #0x34b75c  ; AwaitStub
    // 0x453c88: cmp             w0, NULL
    // 0x453c8c: b.eq            #0x453d50
    // 0x453c90: LoadField: r2 = r0->field_f
    //     0x453c90: ldur            w2, [x0, #0xf]
    // 0x453c94: DecompressPointer r2
    //     0x453c94: add             x2, x2, HEAP, lsl #32
    // 0x453c98: r17 = -280
    //     0x453c98: movn            x17, #0x117
    // 0x453c9c: str             x2, [fp, x17]
    // 0x453ca0: r1 = <Chapter7Stat>
    //     0x453ca0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdd8] TypeArguments: <Chapter7Stat>
    //     0x453ca4: ldr             x1, [x1, #0xdd8]
    // 0x453ca8: r0 = Chapter7GameState()
    //     0x453ca8: bl              #0x46ffa0  ; AllocateChapter7GameStateStub -> Chapter7GameState (size=0x98)
    // 0x453cac: mov             x1, x0
    // 0x453cb0: r17 = -280
    //     0x453cb0: movn            x17, #0x117
    // 0x453cb4: ldr             x2, [fp, x17]
    // 0x453cb8: r17 = -288
    //     0x453cb8: movn            x17, #0x11f
    // 0x453cbc: str             x0, [fp, x17]
    // 0x453cc0: r0 = Chapter7GameState()
    //     0x453cc0: bl              #0x46fca8  ; [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::Chapter7GameState
    // 0x453cc4: r17 = -280
    //     0x453cc4: movn            x17, #0x117
    // 0x453cc8: ldr             x1, [fp, x17]
    // 0x453ccc: r0 = LoadClassIdInstr(r1)
    //     0x453ccc: ldur            x0, [x1, #-1]
    //     0x453cd0: ubfx            x0, x0, #0xc, #0x14
    // 0x453cd4: r2 = 2
    //     0x453cd4: movz            x2, #0x2
    // 0x453cd8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x453cd8: sub             lr, x0, #1, lsl #12
    //     0x453cdc: ldr             lr, [x21, lr, lsl #3]
    //     0x453ce0: blr             lr
    // 0x453ce4: mov             x3, x0
    // 0x453ce8: r2 = Null
    //     0x453ce8: mov             x2, NULL
    // 0x453cec: r1 = Null
    //     0x453cec: mov             x1, NULL
    // 0x453cf0: r17 = -280
    //     0x453cf0: movn            x17, #0x117
    // 0x453cf4: str             x3, [fp, x17]
    // 0x453cf8: branchIfSmi(r0, 0x453d20)
    //     0x453cf8: tbz             w0, #0, #0x453d20
    // 0x453cfc: r4 = LoadClassIdInstr(r0)
    //     0x453cfc: ldur            x4, [x0, #-1]
    //     0x453d00: ubfx            x4, x4, #0xc, #0x14
    // 0x453d04: sub             x4, x4, #0x3c
    // 0x453d08: cmp             x4, #1
    // 0x453d0c: b.ls            #0x453d20
    // 0x453d10: r8 = int?
    //     0x453d10: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x453d14: r3 = Null
    //     0x453d14: add             x3, PP, #0xf, lsl #12  ; [pp+0xfde0] Null
    //     0x453d18: ldr             x3, [x3, #0xde0]
    // 0x453d1c: r0 = int?()
    //     0x453d1c: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x453d20: r1 = <Chapter7GameState, int?>
    //     0x453d20: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdf0] TypeArguments: <Chapter7GameState, int?>
    //     0x453d24: ldr             x1, [x1, #0xdf0]
    // 0x453d28: r0 = Tuple2()
    //     0x453d28: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453d2c: mov             x1, x0
    // 0x453d30: r17 = -288
    //     0x453d30: movn            x17, #0x11f
    // 0x453d34: ldr             x0, [fp, x17]
    // 0x453d38: StoreField: r1->field_b = r0
    //     0x453d38: stur            w0, [x1, #0xb]
    // 0x453d3c: r17 = -280
    //     0x453d3c: movn            x17, #0x117
    // 0x453d40: ldr             x0, [fp, x17]
    // 0x453d44: StoreField: r1->field_f = r0
    //     0x453d44: stur            w0, [x1, #0xf]
    // 0x453d48: mov             x2, x1
    // 0x453d4c: b               #0x453d90
    // 0x453d50: r1 = <Chapter7Stat>
    //     0x453d50: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdd8] TypeArguments: <Chapter7Stat>
    //     0x453d54: ldr             x1, [x1, #0xdd8]
    // 0x453d58: r0 = Chapter7GameState()
    //     0x453d58: bl              #0x46ffa0  ; AllocateChapter7GameStateStub -> Chapter7GameState (size=0x98)
    // 0x453d5c: mov             x1, x0
    // 0x453d60: r2 = Null
    //     0x453d60: mov             x2, NULL
    // 0x453d64: r17 = -280
    //     0x453d64: movn            x17, #0x117
    // 0x453d68: str             x0, [fp, x17]
    // 0x453d6c: r0 = Chapter7GameState()
    //     0x453d6c: bl              #0x46fca8  ; [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::Chapter7GameState
    // 0x453d70: r1 = <Chapter7GameState, int?>
    //     0x453d70: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdf0] TypeArguments: <Chapter7GameState, int?>
    //     0x453d74: ldr             x1, [x1, #0xdf0]
    // 0x453d78: r0 = Tuple2()
    //     0x453d78: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453d7c: mov             x1, x0
    // 0x453d80: r17 = -280
    //     0x453d80: movn            x17, #0x117
    // 0x453d84: ldr             x0, [fp, x17]
    // 0x453d88: StoreField: r1->field_b = r0
    //     0x453d88: stur            w0, [x1, #0xb]
    // 0x453d8c: mov             x2, x1
    // 0x453d90: r17 = -272
    //     0x453d90: movn            x17, #0x10f
    // 0x453d94: ldr             x0, [fp, x17]
    // 0x453d98: r17 = -280
    //     0x453d98: movn            x17, #0x117
    // 0x453d9c: str             x2, [fp, x17]
    // 0x453da0: LoadField: r1 = r0->field_b
    //     0x453da0: ldur            w1, [x0, #0xb]
    // 0x453da4: LoadField: r3 = r0->field_f
    //     0x453da4: ldur            w3, [x0, #0xf]
    // 0x453da8: DecompressPointer r3
    //     0x453da8: add             x3, x3, HEAP, lsl #32
    // 0x453dac: LoadField: r4 = r3->field_b
    //     0x453dac: ldur            w4, [x3, #0xb]
    // 0x453db0: r3 = LoadInt32Instr(r1)
    //     0x453db0: sbfx            x3, x1, #1, #0x1f
    // 0x453db4: r17 = -296
    //     0x453db4: movn            x17, #0x127
    // 0x453db8: str             x3, [fp, x17]
    // 0x453dbc: r1 = LoadInt32Instr(r4)
    //     0x453dbc: sbfx            x1, x4, #1, #0x1f
    // 0x453dc0: cmp             x3, x1
    // 0x453dc4: b.ne            #0x453dd0
    // 0x453dc8: mov             x1, x0
    // 0x453dcc: r0 = _growToNextCapacity()
    //     0x453dcc: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x453dd0: r17 = -272
    //     0x453dd0: movn            x17, #0x10f
    // 0x453dd4: ldr             x2, [fp, x17]
    // 0x453dd8: r17 = -296
    //     0x453dd8: movn            x17, #0x127
    // 0x453ddc: ldr             x3, [fp, x17]
    // 0x453de0: add             x0, x3, #1
    // 0x453de4: lsl             x1, x0, #1
    // 0x453de8: StoreField: r2->field_b = r1
    //     0x453de8: stur            w1, [x2, #0xb]
    // 0x453dec: LoadField: r1 = r2->field_f
    //     0x453dec: ldur            w1, [x2, #0xf]
    // 0x453df0: DecompressPointer r1
    //     0x453df0: add             x1, x1, HEAP, lsl #32
    // 0x453df4: r17 = -280
    //     0x453df4: movn            x17, #0x117
    // 0x453df8: ldr             x0, [fp, x17]
    // 0x453dfc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x453dfc: add             x25, x1, x3, lsl #2
    //     0x453e00: add             x25, x25, #0xf
    //     0x453e04: str             w0, [x25]
    //     0x453e08: tbz             w0, #0, #0x453e24
    //     0x453e0c: ldurb           w16, [x1, #-1]
    //     0x453e10: ldurb           w17, [x0, #-1]
    //     0x453e14: and             x16, x17, x16, lsr #2
    //     0x453e18: tst             x16, HEAP, lsr #32
    //     0x453e1c: b.eq            #0x453e24
    //     0x453e20: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x453e24: mov             x1, x2
    // 0x453e28: r0 = last()
    //     0x453e28: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453e2c: LoadField: r2 = r0->field_b
    //     0x453e2c: ldur            w2, [x0, #0xb]
    // 0x453e30: DecompressPointer r2
    //     0x453e30: add             x2, x2, HEAP, lsl #32
    // 0x453e34: r17 = -272
    //     0x453e34: movn            x17, #0x10f
    // 0x453e38: ldr             x1, [fp, x17]
    // 0x453e3c: r17 = -280
    //     0x453e3c: movn            x17, #0x117
    // 0x453e40: str             x2, [fp, x17]
    // 0x453e44: r0 = last()
    //     0x453e44: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453e48: LoadField: r1 = r0->field_f
    //     0x453e48: ldur            w1, [x0, #0xf]
    // 0x453e4c: DecompressPointer r1
    //     0x453e4c: add             x1, x1, HEAP, lsl #32
    // 0x453e50: r17 = -280
    //     0x453e50: movn            x17, #0x117
    // 0x453e54: ldr             x2, [fp, x17]
    // 0x453e58: cmp             w2, NULL
    // 0x453e5c: b.eq            #0x4561a0
    // 0x453e60: mov             x0, x1
    // 0x453e64: StoreField: r2->field_b = r0
    //     0x453e64: stur            w0, [x2, #0xb]
    //     0x453e68: tbz             w0, #0, #0x453e84
    //     0x453e6c: ldurb           w16, [x2, #-1]
    //     0x453e70: ldurb           w17, [x0, #-1]
    //     0x453e74: and             x16, x17, x16, lsr #2
    //     0x453e78: tst             x16, HEAP, lsr #32
    //     0x453e7c: b.eq            #0x453e84
    //     0x453e80: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x453e84: r0 = LoadStaticField(0xf60)
    //     0x453e84: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x453e88: ldr             x0, [x0, #0x1ec0]
    // 0x453e8c: r17 = -272
    //     0x453e8c: movn            x17, #0x10f
    // 0x453e90: ldr             x1, [fp, x17]
    // 0x453e94: r17 = -280
    //     0x453e94: movn            x17, #0x117
    // 0x453e98: str             x0, [fp, x17]
    // 0x453e9c: r0 = last()
    //     0x453e9c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x453ea0: LoadField: r3 = r0->field_b
    //     0x453ea0: ldur            w3, [x0, #0xb]
    // 0x453ea4: DecompressPointer r3
    //     0x453ea4: add             x3, x3, HEAP, lsl #32
    // 0x453ea8: r17 = -280
    //     0x453ea8: movn            x17, #0x117
    // 0x453eac: ldr             x1, [fp, x17]
    // 0x453eb0: r2 = 14
    //     0x453eb0: movz            x2, #0xe
    // 0x453eb4: r0 = []=()
    //     0x453eb4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x453eb8: r1 = Null
    //     0x453eb8: mov             x1, NULL
    // 0x453ebc: r2 = 4
    //     0x453ebc: movz            x2, #0x4
    // 0x453ec0: r0 = AllocateArray()
    //     0x453ec0: bl              #0x82746c  ; AllocateArrayStub
    // 0x453ec4: r16 = "8"
    //     0x453ec4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x453ec8: ldr             x16, [x16, #0x318]
    // 0x453ecc: StoreField: r0->field_f = r16
    //     0x453ecc: stur            w16, [x0, #0xf]
    // 0x453ed0: r16 = "1"
    //     0x453ed0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x453ed4: ldr             x16, [x16, #0x9c8]
    // 0x453ed8: StoreField: r0->field_13 = r16
    //     0x453ed8: stur            w16, [x0, #0x13]
    // 0x453edc: r1 = Null
    //     0x453edc: mov             x1, NULL
    // 0x453ee0: r2 = 4
    //     0x453ee0: movz            x2, #0x4
    // 0x453ee4: r0 = AllocateArray()
    //     0x453ee4: bl              #0x82746c  ; AllocateArrayStub
    // 0x453ee8: r16 = "8"
    //     0x453ee8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x453eec: ldr             x16, [x16, #0x318]
    // 0x453ef0: StoreField: r0->field_f = r16
    //     0x453ef0: stur            w16, [x0, #0xf]
    // 0x453ef4: r16 = "2"
    //     0x453ef4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x453ef8: ldr             x16, [x16, #0x2e0]
    // 0x453efc: StoreField: r0->field_13 = r16
    //     0x453efc: stur            w16, [x0, #0x13]
    // 0x453f00: r1 = Null
    //     0x453f00: mov             x1, NULL
    // 0x453f04: r2 = 4
    //     0x453f04: movz            x2, #0x4
    // 0x453f08: r0 = AllocateArray()
    //     0x453f08: bl              #0x82746c  ; AllocateArrayStub
    // 0x453f0c: r16 = "8"
    //     0x453f0c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x453f10: ldr             x16, [x16, #0x318]
    // 0x453f14: StoreField: r0->field_f = r16
    //     0x453f14: stur            w16, [x0, #0xf]
    // 0x453f18: r16 = "3"
    //     0x453f18: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x453f1c: ldr             x16, [x16, #0x2f0]
    // 0x453f20: StoreField: r0->field_13 = r16
    //     0x453f20: stur            w16, [x0, #0x13]
    // 0x453f24: r1 = "81"
    //     0x453f24: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdf8] "81"
    //     0x453f28: ldr             x1, [x1, #0xdf8]
    // 0x453f2c: r2 = "83"
    //     0x453f2c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfe00] "83"
    //     0x453f30: ldr             x2, [x2, #0xe00]
    // 0x453f34: r3 = 2
    //     0x453f34: movz            x3, #0x2
    // 0x453f38: r5 = "82"
    //     0x453f38: add             x5, PP, #0xf, lsl #12  ; [pp+0xfe08] "82"
    //     0x453f3c: ldr             x5, [x5, #0xe08]
    // 0x453f40: r0 = readMostRecentValidSaveFile()
    //     0x453f40: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x453f44: mov             x1, x0
    // 0x453f48: r17 = -280
    //     0x453f48: movn            x17, #0x117
    // 0x453f4c: str             x1, [fp, x17]
    // 0x453f50: r0 = Await()
    //     0x453f50: bl              #0x34b75c  ; AwaitStub
    // 0x453f54: cmp             w0, NULL
    // 0x453f58: b.eq            #0x45401c
    // 0x453f5c: LoadField: r2 = r0->field_f
    //     0x453f5c: ldur            w2, [x0, #0xf]
    // 0x453f60: DecompressPointer r2
    //     0x453f60: add             x2, x2, HEAP, lsl #32
    // 0x453f64: r17 = -280
    //     0x453f64: movn            x17, #0x117
    // 0x453f68: str             x2, [fp, x17]
    // 0x453f6c: r1 = <Chapter8Stat>
    //     0x453f6c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe10] TypeArguments: <Chapter8Stat>
    //     0x453f70: ldr             x1, [x1, #0xe10]
    // 0x453f74: r0 = Chapter8GameState()
    //     0x453f74: bl              #0x46fc9c  ; AllocateChapter8GameStateStub -> Chapter8GameState (size=0xa8)
    // 0x453f78: mov             x1, x0
    // 0x453f7c: r17 = -280
    //     0x453f7c: movn            x17, #0x117
    // 0x453f80: ldr             x2, [fp, x17]
    // 0x453f84: r17 = -288
    //     0x453f84: movn            x17, #0x11f
    // 0x453f88: str             x0, [fp, x17]
    // 0x453f8c: r0 = Chapter8GameState()
    //     0x453f8c: bl              #0x46e9e8  ; [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::Chapter8GameState
    // 0x453f90: r17 = -280
    //     0x453f90: movn            x17, #0x117
    // 0x453f94: ldr             x1, [fp, x17]
    // 0x453f98: r0 = LoadClassIdInstr(r1)
    //     0x453f98: ldur            x0, [x1, #-1]
    //     0x453f9c: ubfx            x0, x0, #0xc, #0x14
    // 0x453fa0: r2 = 2
    //     0x453fa0: movz            x2, #0x2
    // 0x453fa4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x453fa4: sub             lr, x0, #1, lsl #12
    //     0x453fa8: ldr             lr, [x21, lr, lsl #3]
    //     0x453fac: blr             lr
    // 0x453fb0: mov             x3, x0
    // 0x453fb4: r2 = Null
    //     0x453fb4: mov             x2, NULL
    // 0x453fb8: r1 = Null
    //     0x453fb8: mov             x1, NULL
    // 0x453fbc: r17 = -280
    //     0x453fbc: movn            x17, #0x117
    // 0x453fc0: str             x3, [fp, x17]
    // 0x453fc4: branchIfSmi(r0, 0x453fec)
    //     0x453fc4: tbz             w0, #0, #0x453fec
    // 0x453fc8: r4 = LoadClassIdInstr(r0)
    //     0x453fc8: ldur            x4, [x0, #-1]
    //     0x453fcc: ubfx            x4, x4, #0xc, #0x14
    // 0x453fd0: sub             x4, x4, #0x3c
    // 0x453fd4: cmp             x4, #1
    // 0x453fd8: b.ls            #0x453fec
    // 0x453fdc: r8 = int?
    //     0x453fdc: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x453fe0: r3 = Null
    //     0x453fe0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfe18] Null
    //     0x453fe4: ldr             x3, [x3, #0xe18]
    // 0x453fe8: r0 = int?()
    //     0x453fe8: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x453fec: r1 = <Chapter8GameState, int?>
    //     0x453fec: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe28] TypeArguments: <Chapter8GameState, int?>
    //     0x453ff0: ldr             x1, [x1, #0xe28]
    // 0x453ff4: r0 = Tuple2()
    //     0x453ff4: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x453ff8: mov             x1, x0
    // 0x453ffc: r17 = -288
    //     0x453ffc: movn            x17, #0x11f
    // 0x454000: ldr             x0, [fp, x17]
    // 0x454004: StoreField: r1->field_b = r0
    //     0x454004: stur            w0, [x1, #0xb]
    // 0x454008: r17 = -280
    //     0x454008: movn            x17, #0x117
    // 0x45400c: ldr             x0, [fp, x17]
    // 0x454010: StoreField: r1->field_f = r0
    //     0x454010: stur            w0, [x1, #0xf]
    // 0x454014: mov             x2, x1
    // 0x454018: b               #0x45405c
    // 0x45401c: r1 = <Chapter8Stat>
    //     0x45401c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe10] TypeArguments: <Chapter8Stat>
    //     0x454020: ldr             x1, [x1, #0xe10]
    // 0x454024: r0 = Chapter8GameState()
    //     0x454024: bl              #0x46fc9c  ; AllocateChapter8GameStateStub -> Chapter8GameState (size=0xa8)
    // 0x454028: mov             x1, x0
    // 0x45402c: r2 = Null
    //     0x45402c: mov             x2, NULL
    // 0x454030: r17 = -280
    //     0x454030: movn            x17, #0x117
    // 0x454034: str             x0, [fp, x17]
    // 0x454038: r0 = Chapter8GameState()
    //     0x454038: bl              #0x46e9e8  ; [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::Chapter8GameState
    // 0x45403c: r1 = <Chapter8GameState, int?>
    //     0x45403c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe28] TypeArguments: <Chapter8GameState, int?>
    //     0x454040: ldr             x1, [x1, #0xe28]
    // 0x454044: r0 = Tuple2()
    //     0x454044: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454048: mov             x1, x0
    // 0x45404c: r17 = -280
    //     0x45404c: movn            x17, #0x117
    // 0x454050: ldr             x0, [fp, x17]
    // 0x454054: StoreField: r1->field_b = r0
    //     0x454054: stur            w0, [x1, #0xb]
    // 0x454058: mov             x2, x1
    // 0x45405c: r17 = -272
    //     0x45405c: movn            x17, #0x10f
    // 0x454060: ldr             x0, [fp, x17]
    // 0x454064: r17 = -280
    //     0x454064: movn            x17, #0x117
    // 0x454068: str             x2, [fp, x17]
    // 0x45406c: LoadField: r1 = r0->field_b
    //     0x45406c: ldur            w1, [x0, #0xb]
    // 0x454070: LoadField: r3 = r0->field_f
    //     0x454070: ldur            w3, [x0, #0xf]
    // 0x454074: DecompressPointer r3
    //     0x454074: add             x3, x3, HEAP, lsl #32
    // 0x454078: LoadField: r4 = r3->field_b
    //     0x454078: ldur            w4, [x3, #0xb]
    // 0x45407c: r3 = LoadInt32Instr(r1)
    //     0x45407c: sbfx            x3, x1, #1, #0x1f
    // 0x454080: r17 = -296
    //     0x454080: movn            x17, #0x127
    // 0x454084: str             x3, [fp, x17]
    // 0x454088: r1 = LoadInt32Instr(r4)
    //     0x454088: sbfx            x1, x4, #1, #0x1f
    // 0x45408c: cmp             x3, x1
    // 0x454090: b.ne            #0x45409c
    // 0x454094: mov             x1, x0
    // 0x454098: r0 = _growToNextCapacity()
    //     0x454098: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x45409c: r17 = -272
    //     0x45409c: movn            x17, #0x10f
    // 0x4540a0: ldr             x2, [fp, x17]
    // 0x4540a4: r17 = -296
    //     0x4540a4: movn            x17, #0x127
    // 0x4540a8: ldr             x3, [fp, x17]
    // 0x4540ac: add             x0, x3, #1
    // 0x4540b0: lsl             x1, x0, #1
    // 0x4540b4: StoreField: r2->field_b = r1
    //     0x4540b4: stur            w1, [x2, #0xb]
    // 0x4540b8: LoadField: r1 = r2->field_f
    //     0x4540b8: ldur            w1, [x2, #0xf]
    // 0x4540bc: DecompressPointer r1
    //     0x4540bc: add             x1, x1, HEAP, lsl #32
    // 0x4540c0: r17 = -280
    //     0x4540c0: movn            x17, #0x117
    // 0x4540c4: ldr             x0, [fp, x17]
    // 0x4540c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x4540c8: add             x25, x1, x3, lsl #2
    //     0x4540cc: add             x25, x25, #0xf
    //     0x4540d0: str             w0, [x25]
    //     0x4540d4: tbz             w0, #0, #0x4540f0
    //     0x4540d8: ldurb           w16, [x1, #-1]
    //     0x4540dc: ldurb           w17, [x0, #-1]
    //     0x4540e0: and             x16, x17, x16, lsr #2
    //     0x4540e4: tst             x16, HEAP, lsr #32
    //     0x4540e8: b.eq            #0x4540f0
    //     0x4540ec: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4540f0: mov             x1, x2
    // 0x4540f4: r0 = last()
    //     0x4540f4: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4540f8: LoadField: r2 = r0->field_b
    //     0x4540f8: ldur            w2, [x0, #0xb]
    // 0x4540fc: DecompressPointer r2
    //     0x4540fc: add             x2, x2, HEAP, lsl #32
    // 0x454100: r17 = -272
    //     0x454100: movn            x17, #0x10f
    // 0x454104: ldr             x1, [fp, x17]
    // 0x454108: r17 = -280
    //     0x454108: movn            x17, #0x117
    // 0x45410c: str             x2, [fp, x17]
    // 0x454110: r0 = last()
    //     0x454110: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454114: LoadField: r1 = r0->field_f
    //     0x454114: ldur            w1, [x0, #0xf]
    // 0x454118: DecompressPointer r1
    //     0x454118: add             x1, x1, HEAP, lsl #32
    // 0x45411c: r17 = -280
    //     0x45411c: movn            x17, #0x117
    // 0x454120: ldr             x2, [fp, x17]
    // 0x454124: cmp             w2, NULL
    // 0x454128: b.eq            #0x4561a4
    // 0x45412c: mov             x0, x1
    // 0x454130: StoreField: r2->field_b = r0
    //     0x454130: stur            w0, [x2, #0xb]
    //     0x454134: tbz             w0, #0, #0x454150
    //     0x454138: ldurb           w16, [x2, #-1]
    //     0x45413c: ldurb           w17, [x0, #-1]
    //     0x454140: and             x16, x17, x16, lsr #2
    //     0x454144: tst             x16, HEAP, lsr #32
    //     0x454148: b.eq            #0x454150
    //     0x45414c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x454150: r0 = LoadStaticField(0xf60)
    //     0x454150: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x454154: ldr             x0, [x0, #0x1ec0]
    // 0x454158: r17 = -272
    //     0x454158: movn            x17, #0x10f
    // 0x45415c: ldr             x1, [fp, x17]
    // 0x454160: r17 = -280
    //     0x454160: movn            x17, #0x117
    // 0x454164: str             x0, [fp, x17]
    // 0x454168: r0 = last()
    //     0x454168: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x45416c: LoadField: r3 = r0->field_b
    //     0x45416c: ldur            w3, [x0, #0xb]
    // 0x454170: DecompressPointer r3
    //     0x454170: add             x3, x3, HEAP, lsl #32
    // 0x454174: r17 = -280
    //     0x454174: movn            x17, #0x117
    // 0x454178: ldr             x1, [fp, x17]
    // 0x45417c: r2 = 16
    //     0x45417c: movz            x2, #0x10
    // 0x454180: r0 = []=()
    //     0x454180: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x454184: r1 = Null
    //     0x454184: mov             x1, NULL
    // 0x454188: r2 = 4
    //     0x454188: movz            x2, #0x4
    // 0x45418c: r0 = AllocateArray()
    //     0x45418c: bl              #0x82746c  ; AllocateArrayStub
    // 0x454190: r16 = "9"
    //     0x454190: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x454194: ldr             x16, [x16, #0x320]
    // 0x454198: StoreField: r0->field_f = r16
    //     0x454198: stur            w16, [x0, #0xf]
    // 0x45419c: r16 = "1"
    //     0x45419c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x4541a0: ldr             x16, [x16, #0x9c8]
    // 0x4541a4: StoreField: r0->field_13 = r16
    //     0x4541a4: stur            w16, [x0, #0x13]
    // 0x4541a8: r1 = Null
    //     0x4541a8: mov             x1, NULL
    // 0x4541ac: r2 = 4
    //     0x4541ac: movz            x2, #0x4
    // 0x4541b0: r0 = AllocateArray()
    //     0x4541b0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4541b4: r16 = "9"
    //     0x4541b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x4541b8: ldr             x16, [x16, #0x320]
    // 0x4541bc: StoreField: r0->field_f = r16
    //     0x4541bc: stur            w16, [x0, #0xf]
    // 0x4541c0: r16 = "2"
    //     0x4541c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x4541c4: ldr             x16, [x16, #0x2e0]
    // 0x4541c8: StoreField: r0->field_13 = r16
    //     0x4541c8: stur            w16, [x0, #0x13]
    // 0x4541cc: r1 = Null
    //     0x4541cc: mov             x1, NULL
    // 0x4541d0: r2 = 4
    //     0x4541d0: movz            x2, #0x4
    // 0x4541d4: r0 = AllocateArray()
    //     0x4541d4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4541d8: r16 = "9"
    //     0x4541d8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x4541dc: ldr             x16, [x16, #0x320]
    // 0x4541e0: StoreField: r0->field_f = r16
    //     0x4541e0: stur            w16, [x0, #0xf]
    // 0x4541e4: r16 = "3"
    //     0x4541e4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4541e8: ldr             x16, [x16, #0x2f0]
    // 0x4541ec: StoreField: r0->field_13 = r16
    //     0x4541ec: stur            w16, [x0, #0x13]
    // 0x4541f0: r1 = "91"
    //     0x4541f0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe30] "91"
    //     0x4541f4: ldr             x1, [x1, #0xe30]
    // 0x4541f8: r2 = "93"
    //     0x4541f8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfe38] "93"
    //     0x4541fc: ldr             x2, [x2, #0xe38]
    // 0x454200: r3 = 2
    //     0x454200: movz            x3, #0x2
    // 0x454204: r5 = "92"
    //     0x454204: add             x5, PP, #0xf, lsl #12  ; [pp+0xfe40] "92"
    //     0x454208: ldr             x5, [x5, #0xe40]
    // 0x45420c: r0 = readMostRecentValidSaveFile()
    //     0x45420c: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x454210: mov             x1, x0
    // 0x454214: r17 = -280
    //     0x454214: movn            x17, #0x117
    // 0x454218: str             x1, [fp, x17]
    // 0x45421c: r0 = Await()
    //     0x45421c: bl              #0x34b75c  ; AwaitStub
    // 0x454220: cmp             w0, NULL
    // 0x454224: b.eq            #0x4542e8
    // 0x454228: LoadField: r2 = r0->field_f
    //     0x454228: ldur            w2, [x0, #0xf]
    // 0x45422c: DecompressPointer r2
    //     0x45422c: add             x2, x2, HEAP, lsl #32
    // 0x454230: r17 = -280
    //     0x454230: movn            x17, #0x117
    // 0x454234: str             x2, [fp, x17]
    // 0x454238: r1 = <Chapter9Stat>
    //     0x454238: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x45423c: ldr             x1, [x1, #0xe48]
    // 0x454240: r0 = Chapter9GameState()
    //     0x454240: bl              #0x46e9dc  ; AllocateChapter9GameStateStub -> Chapter9GameState (size=0x98)
    // 0x454244: mov             x1, x0
    // 0x454248: r17 = -280
    //     0x454248: movn            x17, #0x117
    // 0x45424c: ldr             x2, [fp, x17]
    // 0x454250: r17 = -288
    //     0x454250: movn            x17, #0x11f
    // 0x454254: str             x0, [fp, x17]
    // 0x454258: r0 = Chapter9GameState()
    //     0x454258: bl              #0x46e464  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState
    // 0x45425c: r17 = -280
    //     0x45425c: movn            x17, #0x117
    // 0x454260: ldr             x1, [fp, x17]
    // 0x454264: r0 = LoadClassIdInstr(r1)
    //     0x454264: ldur            x0, [x1, #-1]
    //     0x454268: ubfx            x0, x0, #0xc, #0x14
    // 0x45426c: r2 = 2
    //     0x45426c: movz            x2, #0x2
    // 0x454270: r0 = GDT[cid_x0 + -0x1000]()
    //     0x454270: sub             lr, x0, #1, lsl #12
    //     0x454274: ldr             lr, [x21, lr, lsl #3]
    //     0x454278: blr             lr
    // 0x45427c: mov             x3, x0
    // 0x454280: r2 = Null
    //     0x454280: mov             x2, NULL
    // 0x454284: r1 = Null
    //     0x454284: mov             x1, NULL
    // 0x454288: r17 = -280
    //     0x454288: movn            x17, #0x117
    // 0x45428c: str             x3, [fp, x17]
    // 0x454290: branchIfSmi(r0, 0x4542b8)
    //     0x454290: tbz             w0, #0, #0x4542b8
    // 0x454294: r4 = LoadClassIdInstr(r0)
    //     0x454294: ldur            x4, [x0, #-1]
    //     0x454298: ubfx            x4, x4, #0xc, #0x14
    // 0x45429c: sub             x4, x4, #0x3c
    // 0x4542a0: cmp             x4, #1
    // 0x4542a4: b.ls            #0x4542b8
    // 0x4542a8: r8 = int?
    //     0x4542a8: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x4542ac: r3 = Null
    //     0x4542ac: add             x3, PP, #0xf, lsl #12  ; [pp+0xfe50] Null
    //     0x4542b0: ldr             x3, [x3, #0xe50]
    // 0x4542b4: r0 = int?()
    //     0x4542b4: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x4542b8: r1 = <Chapter9GameState, int?>
    //     0x4542b8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe60] TypeArguments: <Chapter9GameState, int?>
    //     0x4542bc: ldr             x1, [x1, #0xe60]
    // 0x4542c0: r0 = Tuple2()
    //     0x4542c0: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4542c4: mov             x1, x0
    // 0x4542c8: r17 = -288
    //     0x4542c8: movn            x17, #0x11f
    // 0x4542cc: ldr             x0, [fp, x17]
    // 0x4542d0: StoreField: r1->field_b = r0
    //     0x4542d0: stur            w0, [x1, #0xb]
    // 0x4542d4: r17 = -280
    //     0x4542d4: movn            x17, #0x117
    // 0x4542d8: ldr             x0, [fp, x17]
    // 0x4542dc: StoreField: r1->field_f = r0
    //     0x4542dc: stur            w0, [x1, #0xf]
    // 0x4542e0: mov             x2, x1
    // 0x4542e4: b               #0x454328
    // 0x4542e8: r1 = <Chapter9Stat>
    //     0x4542e8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x4542ec: ldr             x1, [x1, #0xe48]
    // 0x4542f0: r0 = Chapter9GameState()
    //     0x4542f0: bl              #0x46e9dc  ; AllocateChapter9GameStateStub -> Chapter9GameState (size=0x98)
    // 0x4542f4: mov             x1, x0
    // 0x4542f8: r2 = Null
    //     0x4542f8: mov             x2, NULL
    // 0x4542fc: r17 = -280
    //     0x4542fc: movn            x17, #0x117
    // 0x454300: str             x0, [fp, x17]
    // 0x454304: r0 = Chapter9GameState()
    //     0x454304: bl              #0x46e464  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState
    // 0x454308: r1 = <Chapter9GameState, int?>
    //     0x454308: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe60] TypeArguments: <Chapter9GameState, int?>
    //     0x45430c: ldr             x1, [x1, #0xe60]
    // 0x454310: r0 = Tuple2()
    //     0x454310: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454314: mov             x1, x0
    // 0x454318: r17 = -280
    //     0x454318: movn            x17, #0x117
    // 0x45431c: ldr             x0, [fp, x17]
    // 0x454320: StoreField: r1->field_b = r0
    //     0x454320: stur            w0, [x1, #0xb]
    // 0x454324: mov             x2, x1
    // 0x454328: r17 = -272
    //     0x454328: movn            x17, #0x10f
    // 0x45432c: ldr             x0, [fp, x17]
    // 0x454330: r17 = -280
    //     0x454330: movn            x17, #0x117
    // 0x454334: str             x2, [fp, x17]
    // 0x454338: LoadField: r1 = r0->field_b
    //     0x454338: ldur            w1, [x0, #0xb]
    // 0x45433c: LoadField: r3 = r0->field_f
    //     0x45433c: ldur            w3, [x0, #0xf]
    // 0x454340: DecompressPointer r3
    //     0x454340: add             x3, x3, HEAP, lsl #32
    // 0x454344: LoadField: r4 = r3->field_b
    //     0x454344: ldur            w4, [x3, #0xb]
    // 0x454348: r3 = LoadInt32Instr(r1)
    //     0x454348: sbfx            x3, x1, #1, #0x1f
    // 0x45434c: r17 = -296
    //     0x45434c: movn            x17, #0x127
    // 0x454350: str             x3, [fp, x17]
    // 0x454354: r1 = LoadInt32Instr(r4)
    //     0x454354: sbfx            x1, x4, #1, #0x1f
    // 0x454358: cmp             x3, x1
    // 0x45435c: b.ne            #0x454368
    // 0x454360: mov             x1, x0
    // 0x454364: r0 = _growToNextCapacity()
    //     0x454364: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x454368: r17 = -272
    //     0x454368: movn            x17, #0x10f
    // 0x45436c: ldr             x2, [fp, x17]
    // 0x454370: r17 = -296
    //     0x454370: movn            x17, #0x127
    // 0x454374: ldr             x3, [fp, x17]
    // 0x454378: add             x0, x3, #1
    // 0x45437c: lsl             x1, x0, #1
    // 0x454380: StoreField: r2->field_b = r1
    //     0x454380: stur            w1, [x2, #0xb]
    // 0x454384: LoadField: r1 = r2->field_f
    //     0x454384: ldur            w1, [x2, #0xf]
    // 0x454388: DecompressPointer r1
    //     0x454388: add             x1, x1, HEAP, lsl #32
    // 0x45438c: r17 = -280
    //     0x45438c: movn            x17, #0x117
    // 0x454390: ldr             x0, [fp, x17]
    // 0x454394: ArrayStore: r1[r3] = r0  ; List_4
    //     0x454394: add             x25, x1, x3, lsl #2
    //     0x454398: add             x25, x25, #0xf
    //     0x45439c: str             w0, [x25]
    //     0x4543a0: tbz             w0, #0, #0x4543bc
    //     0x4543a4: ldurb           w16, [x1, #-1]
    //     0x4543a8: ldurb           w17, [x0, #-1]
    //     0x4543ac: and             x16, x17, x16, lsr #2
    //     0x4543b0: tst             x16, HEAP, lsr #32
    //     0x4543b4: b.eq            #0x4543bc
    //     0x4543b8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4543bc: mov             x1, x2
    // 0x4543c0: r0 = last()
    //     0x4543c0: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4543c4: LoadField: r2 = r0->field_b
    //     0x4543c4: ldur            w2, [x0, #0xb]
    // 0x4543c8: DecompressPointer r2
    //     0x4543c8: add             x2, x2, HEAP, lsl #32
    // 0x4543cc: r17 = -272
    //     0x4543cc: movn            x17, #0x10f
    // 0x4543d0: ldr             x1, [fp, x17]
    // 0x4543d4: r17 = -280
    //     0x4543d4: movn            x17, #0x117
    // 0x4543d8: str             x2, [fp, x17]
    // 0x4543dc: r0 = last()
    //     0x4543dc: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4543e0: LoadField: r1 = r0->field_f
    //     0x4543e0: ldur            w1, [x0, #0xf]
    // 0x4543e4: DecompressPointer r1
    //     0x4543e4: add             x1, x1, HEAP, lsl #32
    // 0x4543e8: r17 = -280
    //     0x4543e8: movn            x17, #0x117
    // 0x4543ec: ldr             x2, [fp, x17]
    // 0x4543f0: cmp             w2, NULL
    // 0x4543f4: b.eq            #0x4561a8
    // 0x4543f8: mov             x0, x1
    // 0x4543fc: StoreField: r2->field_b = r0
    //     0x4543fc: stur            w0, [x2, #0xb]
    //     0x454400: tbz             w0, #0, #0x45441c
    //     0x454404: ldurb           w16, [x2, #-1]
    //     0x454408: ldurb           w17, [x0, #-1]
    //     0x45440c: and             x16, x17, x16, lsr #2
    //     0x454410: tst             x16, HEAP, lsr #32
    //     0x454414: b.eq            #0x45441c
    //     0x454418: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45441c: r0 = LoadStaticField(0xf60)
    //     0x45441c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x454420: ldr             x0, [x0, #0x1ec0]
    // 0x454424: r17 = -272
    //     0x454424: movn            x17, #0x10f
    // 0x454428: ldr             x1, [fp, x17]
    // 0x45442c: r17 = -280
    //     0x45442c: movn            x17, #0x117
    // 0x454430: str             x0, [fp, x17]
    // 0x454434: r0 = last()
    //     0x454434: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454438: LoadField: r3 = r0->field_b
    //     0x454438: ldur            w3, [x0, #0xb]
    // 0x45443c: DecompressPointer r3
    //     0x45443c: add             x3, x3, HEAP, lsl #32
    // 0x454440: r17 = -280
    //     0x454440: movn            x17, #0x117
    // 0x454444: ldr             x1, [fp, x17]
    // 0x454448: r2 = 18
    //     0x454448: movz            x2, #0x12
    // 0x45444c: r0 = []=()
    //     0x45444c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x454450: r1 = Null
    //     0x454450: mov             x1, NULL
    // 0x454454: r2 = 4
    //     0x454454: movz            x2, #0x4
    // 0x454458: r0 = AllocateArray()
    //     0x454458: bl              #0x82746c  ; AllocateArrayStub
    // 0x45445c: r16 = "10"
    //     0x45445c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x454460: ldr             x16, [x16, #0x9d0]
    // 0x454464: StoreField: r0->field_f = r16
    //     0x454464: stur            w16, [x0, #0xf]
    // 0x454468: r16 = "1"
    //     0x454468: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x45446c: ldr             x16, [x16, #0x9c8]
    // 0x454470: StoreField: r0->field_13 = r16
    //     0x454470: stur            w16, [x0, #0x13]
    // 0x454474: r1 = Null
    //     0x454474: mov             x1, NULL
    // 0x454478: r2 = 4
    //     0x454478: movz            x2, #0x4
    // 0x45447c: r0 = AllocateArray()
    //     0x45447c: bl              #0x82746c  ; AllocateArrayStub
    // 0x454480: r16 = "10"
    //     0x454480: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x454484: ldr             x16, [x16, #0x9d0]
    // 0x454488: StoreField: r0->field_f = r16
    //     0x454488: stur            w16, [x0, #0xf]
    // 0x45448c: r16 = "2"
    //     0x45448c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x454490: ldr             x16, [x16, #0x2e0]
    // 0x454494: StoreField: r0->field_13 = r16
    //     0x454494: stur            w16, [x0, #0x13]
    // 0x454498: r1 = Null
    //     0x454498: mov             x1, NULL
    // 0x45449c: r2 = 4
    //     0x45449c: movz            x2, #0x4
    // 0x4544a0: r0 = AllocateArray()
    //     0x4544a0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4544a4: r16 = "10"
    //     0x4544a4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x4544a8: ldr             x16, [x16, #0x9d0]
    // 0x4544ac: StoreField: r0->field_f = r16
    //     0x4544ac: stur            w16, [x0, #0xf]
    // 0x4544b0: r16 = "3"
    //     0x4544b0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4544b4: ldr             x16, [x16, #0x2f0]
    // 0x4544b8: StoreField: r0->field_13 = r16
    //     0x4544b8: stur            w16, [x0, #0x13]
    // 0x4544bc: r1 = "101"
    //     0x4544bc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe68] "101"
    //     0x4544c0: ldr             x1, [x1, #0xe68]
    // 0x4544c4: r2 = "103"
    //     0x4544c4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfe70] "103"
    //     0x4544c8: ldr             x2, [x2, #0xe70]
    // 0x4544cc: r3 = 2
    //     0x4544cc: movz            x3, #0x2
    // 0x4544d0: r5 = "102"
    //     0x4544d0: add             x5, PP, #0xf, lsl #12  ; [pp+0xfe78] "102"
    //     0x4544d4: ldr             x5, [x5, #0xe78]
    // 0x4544d8: r0 = readMostRecentValidSaveFile()
    //     0x4544d8: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4544dc: mov             x1, x0
    // 0x4544e0: r17 = -280
    //     0x4544e0: movn            x17, #0x117
    // 0x4544e4: str             x1, [fp, x17]
    // 0x4544e8: r0 = Await()
    //     0x4544e8: bl              #0x34b75c  ; AwaitStub
    // 0x4544ec: cmp             w0, NULL
    // 0x4544f0: b.eq            #0x4545b4
    // 0x4544f4: LoadField: r2 = r0->field_f
    //     0x4544f4: ldur            w2, [x0, #0xf]
    // 0x4544f8: DecompressPointer r2
    //     0x4544f8: add             x2, x2, HEAP, lsl #32
    // 0x4544fc: r17 = -280
    //     0x4544fc: movn            x17, #0x117
    // 0x454500: str             x2, [fp, x17]
    // 0x454504: r1 = <Chapter10Stat>
    //     0x454504: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x454508: ldr             x1, [x1, #0xe80]
    // 0x45450c: r0 = Chapter10GameState()
    //     0x45450c: bl              #0x46e458  ; AllocateChapter10GameStateStub -> Chapter10GameState (size=0xa4)
    // 0x454510: mov             x1, x0
    // 0x454514: r17 = -280
    //     0x454514: movn            x17, #0x117
    // 0x454518: ldr             x2, [fp, x17]
    // 0x45451c: r17 = -288
    //     0x45451c: movn            x17, #0x11f
    // 0x454520: str             x0, [fp, x17]
    // 0x454524: r0 = Chapter10GameState()
    //     0x454524: bl              #0x46db78  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState
    // 0x454528: r17 = -280
    //     0x454528: movn            x17, #0x117
    // 0x45452c: ldr             x1, [fp, x17]
    // 0x454530: r0 = LoadClassIdInstr(r1)
    //     0x454530: ldur            x0, [x1, #-1]
    //     0x454534: ubfx            x0, x0, #0xc, #0x14
    // 0x454538: r2 = 2
    //     0x454538: movz            x2, #0x2
    // 0x45453c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45453c: sub             lr, x0, #1, lsl #12
    //     0x454540: ldr             lr, [x21, lr, lsl #3]
    //     0x454544: blr             lr
    // 0x454548: mov             x3, x0
    // 0x45454c: r2 = Null
    //     0x45454c: mov             x2, NULL
    // 0x454550: r1 = Null
    //     0x454550: mov             x1, NULL
    // 0x454554: r17 = -280
    //     0x454554: movn            x17, #0x117
    // 0x454558: str             x3, [fp, x17]
    // 0x45455c: branchIfSmi(r0, 0x454584)
    //     0x45455c: tbz             w0, #0, #0x454584
    // 0x454560: r4 = LoadClassIdInstr(r0)
    //     0x454560: ldur            x4, [x0, #-1]
    //     0x454564: ubfx            x4, x4, #0xc, #0x14
    // 0x454568: sub             x4, x4, #0x3c
    // 0x45456c: cmp             x4, #1
    // 0x454570: b.ls            #0x454584
    // 0x454574: r8 = int?
    //     0x454574: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x454578: r3 = Null
    //     0x454578: add             x3, PP, #0xf, lsl #12  ; [pp+0xfe88] Null
    //     0x45457c: ldr             x3, [x3, #0xe88]
    // 0x454580: r0 = int?()
    //     0x454580: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x454584: r1 = <Chapter10GameState, int?>
    //     0x454584: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe98] TypeArguments: <Chapter10GameState, int?>
    //     0x454588: ldr             x1, [x1, #0xe98]
    // 0x45458c: r0 = Tuple2()
    //     0x45458c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454590: mov             x1, x0
    // 0x454594: r17 = -288
    //     0x454594: movn            x17, #0x11f
    // 0x454598: ldr             x0, [fp, x17]
    // 0x45459c: StoreField: r1->field_b = r0
    //     0x45459c: stur            w0, [x1, #0xb]
    // 0x4545a0: r17 = -280
    //     0x4545a0: movn            x17, #0x117
    // 0x4545a4: ldr             x0, [fp, x17]
    // 0x4545a8: StoreField: r1->field_f = r0
    //     0x4545a8: stur            w0, [x1, #0xf]
    // 0x4545ac: mov             x2, x1
    // 0x4545b0: b               #0x4545f4
    // 0x4545b4: r1 = <Chapter10Stat>
    //     0x4545b4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x4545b8: ldr             x1, [x1, #0xe80]
    // 0x4545bc: r0 = Chapter10GameState()
    //     0x4545bc: bl              #0x46e458  ; AllocateChapter10GameStateStub -> Chapter10GameState (size=0xa4)
    // 0x4545c0: mov             x1, x0
    // 0x4545c4: r2 = Null
    //     0x4545c4: mov             x2, NULL
    // 0x4545c8: r17 = -280
    //     0x4545c8: movn            x17, #0x117
    // 0x4545cc: str             x0, [fp, x17]
    // 0x4545d0: r0 = Chapter10GameState()
    //     0x4545d0: bl              #0x46db78  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState
    // 0x4545d4: r1 = <Chapter10GameState, int?>
    //     0x4545d4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe98] TypeArguments: <Chapter10GameState, int?>
    //     0x4545d8: ldr             x1, [x1, #0xe98]
    // 0x4545dc: r0 = Tuple2()
    //     0x4545dc: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4545e0: mov             x1, x0
    // 0x4545e4: r17 = -280
    //     0x4545e4: movn            x17, #0x117
    // 0x4545e8: ldr             x0, [fp, x17]
    // 0x4545ec: StoreField: r1->field_b = r0
    //     0x4545ec: stur            w0, [x1, #0xb]
    // 0x4545f0: mov             x2, x1
    // 0x4545f4: r17 = -272
    //     0x4545f4: movn            x17, #0x10f
    // 0x4545f8: ldr             x0, [fp, x17]
    // 0x4545fc: r17 = -280
    //     0x4545fc: movn            x17, #0x117
    // 0x454600: str             x2, [fp, x17]
    // 0x454604: LoadField: r1 = r0->field_b
    //     0x454604: ldur            w1, [x0, #0xb]
    // 0x454608: LoadField: r3 = r0->field_f
    //     0x454608: ldur            w3, [x0, #0xf]
    // 0x45460c: DecompressPointer r3
    //     0x45460c: add             x3, x3, HEAP, lsl #32
    // 0x454610: LoadField: r4 = r3->field_b
    //     0x454610: ldur            w4, [x3, #0xb]
    // 0x454614: r3 = LoadInt32Instr(r1)
    //     0x454614: sbfx            x3, x1, #1, #0x1f
    // 0x454618: r17 = -296
    //     0x454618: movn            x17, #0x127
    // 0x45461c: str             x3, [fp, x17]
    // 0x454620: r1 = LoadInt32Instr(r4)
    //     0x454620: sbfx            x1, x4, #1, #0x1f
    // 0x454624: cmp             x3, x1
    // 0x454628: b.ne            #0x454634
    // 0x45462c: mov             x1, x0
    // 0x454630: r0 = _growToNextCapacity()
    //     0x454630: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x454634: r17 = -272
    //     0x454634: movn            x17, #0x10f
    // 0x454638: ldr             x2, [fp, x17]
    // 0x45463c: r17 = -296
    //     0x45463c: movn            x17, #0x127
    // 0x454640: ldr             x3, [fp, x17]
    // 0x454644: add             x0, x3, #1
    // 0x454648: lsl             x1, x0, #1
    // 0x45464c: StoreField: r2->field_b = r1
    //     0x45464c: stur            w1, [x2, #0xb]
    // 0x454650: LoadField: r1 = r2->field_f
    //     0x454650: ldur            w1, [x2, #0xf]
    // 0x454654: DecompressPointer r1
    //     0x454654: add             x1, x1, HEAP, lsl #32
    // 0x454658: r17 = -280
    //     0x454658: movn            x17, #0x117
    // 0x45465c: ldr             x0, [fp, x17]
    // 0x454660: ArrayStore: r1[r3] = r0  ; List_4
    //     0x454660: add             x25, x1, x3, lsl #2
    //     0x454664: add             x25, x25, #0xf
    //     0x454668: str             w0, [x25]
    //     0x45466c: tbz             w0, #0, #0x454688
    //     0x454670: ldurb           w16, [x1, #-1]
    //     0x454674: ldurb           w17, [x0, #-1]
    //     0x454678: and             x16, x17, x16, lsr #2
    //     0x45467c: tst             x16, HEAP, lsr #32
    //     0x454680: b.eq            #0x454688
    //     0x454684: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x454688: mov             x1, x2
    // 0x45468c: r0 = last()
    //     0x45468c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454690: LoadField: r2 = r0->field_b
    //     0x454690: ldur            w2, [x0, #0xb]
    // 0x454694: DecompressPointer r2
    //     0x454694: add             x2, x2, HEAP, lsl #32
    // 0x454698: r17 = -272
    //     0x454698: movn            x17, #0x10f
    // 0x45469c: ldr             x1, [fp, x17]
    // 0x4546a0: r17 = -280
    //     0x4546a0: movn            x17, #0x117
    // 0x4546a4: str             x2, [fp, x17]
    // 0x4546a8: r0 = last()
    //     0x4546a8: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4546ac: LoadField: r1 = r0->field_f
    //     0x4546ac: ldur            w1, [x0, #0xf]
    // 0x4546b0: DecompressPointer r1
    //     0x4546b0: add             x1, x1, HEAP, lsl #32
    // 0x4546b4: r17 = -280
    //     0x4546b4: movn            x17, #0x117
    // 0x4546b8: ldr             x2, [fp, x17]
    // 0x4546bc: cmp             w2, NULL
    // 0x4546c0: b.eq            #0x4561ac
    // 0x4546c4: mov             x0, x1
    // 0x4546c8: StoreField: r2->field_b = r0
    //     0x4546c8: stur            w0, [x2, #0xb]
    //     0x4546cc: tbz             w0, #0, #0x4546e8
    //     0x4546d0: ldurb           w16, [x2, #-1]
    //     0x4546d4: ldurb           w17, [x0, #-1]
    //     0x4546d8: and             x16, x17, x16, lsr #2
    //     0x4546dc: tst             x16, HEAP, lsr #32
    //     0x4546e0: b.eq            #0x4546e8
    //     0x4546e4: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x4546e8: r0 = LoadStaticField(0xf60)
    //     0x4546e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4546ec: ldr             x0, [x0, #0x1ec0]
    // 0x4546f0: r17 = -272
    //     0x4546f0: movn            x17, #0x10f
    // 0x4546f4: ldr             x1, [fp, x17]
    // 0x4546f8: r17 = -280
    //     0x4546f8: movn            x17, #0x117
    // 0x4546fc: str             x0, [fp, x17]
    // 0x454700: r0 = last()
    //     0x454700: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454704: LoadField: r3 = r0->field_b
    //     0x454704: ldur            w3, [x0, #0xb]
    // 0x454708: DecompressPointer r3
    //     0x454708: add             x3, x3, HEAP, lsl #32
    // 0x45470c: r17 = -280
    //     0x45470c: movn            x17, #0x117
    // 0x454710: ldr             x1, [fp, x17]
    // 0x454714: r2 = 20
    //     0x454714: movz            x2, #0x14
    // 0x454718: r0 = []=()
    //     0x454718: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x45471c: r1 = Null
    //     0x45471c: mov             x1, NULL
    // 0x454720: r2 = 4
    //     0x454720: movz            x2, #0x4
    // 0x454724: r0 = AllocateArray()
    //     0x454724: bl              #0x82746c  ; AllocateArrayStub
    // 0x454728: r16 = "11"
    //     0x454728: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x45472c: ldr             x16, [x16, #0x328]
    // 0x454730: StoreField: r0->field_f = r16
    //     0x454730: stur            w16, [x0, #0xf]
    // 0x454734: r16 = "1"
    //     0x454734: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x454738: ldr             x16, [x16, #0x9c8]
    // 0x45473c: StoreField: r0->field_13 = r16
    //     0x45473c: stur            w16, [x0, #0x13]
    // 0x454740: r1 = Null
    //     0x454740: mov             x1, NULL
    // 0x454744: r2 = 4
    //     0x454744: movz            x2, #0x4
    // 0x454748: r0 = AllocateArray()
    //     0x454748: bl              #0x82746c  ; AllocateArrayStub
    // 0x45474c: r16 = "11"
    //     0x45474c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x454750: ldr             x16, [x16, #0x328]
    // 0x454754: StoreField: r0->field_f = r16
    //     0x454754: stur            w16, [x0, #0xf]
    // 0x454758: r16 = "2"
    //     0x454758: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x45475c: ldr             x16, [x16, #0x2e0]
    // 0x454760: StoreField: r0->field_13 = r16
    //     0x454760: stur            w16, [x0, #0x13]
    // 0x454764: r1 = Null
    //     0x454764: mov             x1, NULL
    // 0x454768: r2 = 4
    //     0x454768: movz            x2, #0x4
    // 0x45476c: r0 = AllocateArray()
    //     0x45476c: bl              #0x82746c  ; AllocateArrayStub
    // 0x454770: r16 = "11"
    //     0x454770: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x454774: ldr             x16, [x16, #0x328]
    // 0x454778: StoreField: r0->field_f = r16
    //     0x454778: stur            w16, [x0, #0xf]
    // 0x45477c: r16 = "3"
    //     0x45477c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x454780: ldr             x16, [x16, #0x2f0]
    // 0x454784: StoreField: r0->field_13 = r16
    //     0x454784: stur            w16, [x0, #0x13]
    // 0x454788: r1 = "111"
    //     0x454788: add             x1, PP, #0xf, lsl #12  ; [pp+0xfea0] "111"
    //     0x45478c: ldr             x1, [x1, #0xea0]
    // 0x454790: r2 = "113"
    //     0x454790: add             x2, PP, #0xf, lsl #12  ; [pp+0xfea8] "113"
    //     0x454794: ldr             x2, [x2, #0xea8]
    // 0x454798: r3 = 2
    //     0x454798: movz            x3, #0x2
    // 0x45479c: r5 = "112"
    //     0x45479c: add             x5, PP, #0xf, lsl #12  ; [pp+0xfeb0] "112"
    //     0x4547a0: ldr             x5, [x5, #0xeb0]
    // 0x4547a4: r0 = readMostRecentValidSaveFile()
    //     0x4547a4: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4547a8: mov             x1, x0
    // 0x4547ac: r17 = -280
    //     0x4547ac: movn            x17, #0x117
    // 0x4547b0: str             x1, [fp, x17]
    // 0x4547b4: r0 = Await()
    //     0x4547b4: bl              #0x34b75c  ; AwaitStub
    // 0x4547b8: cmp             w0, NULL
    // 0x4547bc: b.eq            #0x454880
    // 0x4547c0: LoadField: r2 = r0->field_f
    //     0x4547c0: ldur            w2, [x0, #0xf]
    // 0x4547c4: DecompressPointer r2
    //     0x4547c4: add             x2, x2, HEAP, lsl #32
    // 0x4547c8: r17 = -280
    //     0x4547c8: movn            x17, #0x117
    // 0x4547cc: str             x2, [fp, x17]
    // 0x4547d0: r1 = <Chapter11Stat>
    //     0x4547d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x4547d4: ldr             x1, [x1, #0xeb8]
    // 0x4547d8: r0 = Chapter11GameState()
    //     0x4547d8: bl              #0x46db6c  ; AllocateChapter11GameStateStub -> Chapter11GameState (size=0x98)
    // 0x4547dc: mov             x1, x0
    // 0x4547e0: r17 = -280
    //     0x4547e0: movn            x17, #0x117
    // 0x4547e4: ldr             x2, [fp, x17]
    // 0x4547e8: r17 = -288
    //     0x4547e8: movn            x17, #0x11f
    // 0x4547ec: str             x0, [fp, x17]
    // 0x4547f0: r0 = Chapter11GameState()
    //     0x4547f0: bl              #0x46d784  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState
    // 0x4547f4: r17 = -280
    //     0x4547f4: movn            x17, #0x117
    // 0x4547f8: ldr             x1, [fp, x17]
    // 0x4547fc: r0 = LoadClassIdInstr(r1)
    //     0x4547fc: ldur            x0, [x1, #-1]
    //     0x454800: ubfx            x0, x0, #0xc, #0x14
    // 0x454804: r2 = 2
    //     0x454804: movz            x2, #0x2
    // 0x454808: r0 = GDT[cid_x0 + -0x1000]()
    //     0x454808: sub             lr, x0, #1, lsl #12
    //     0x45480c: ldr             lr, [x21, lr, lsl #3]
    //     0x454810: blr             lr
    // 0x454814: mov             x3, x0
    // 0x454818: r2 = Null
    //     0x454818: mov             x2, NULL
    // 0x45481c: r1 = Null
    //     0x45481c: mov             x1, NULL
    // 0x454820: r17 = -280
    //     0x454820: movn            x17, #0x117
    // 0x454824: str             x3, [fp, x17]
    // 0x454828: branchIfSmi(r0, 0x454850)
    //     0x454828: tbz             w0, #0, #0x454850
    // 0x45482c: r4 = LoadClassIdInstr(r0)
    //     0x45482c: ldur            x4, [x0, #-1]
    //     0x454830: ubfx            x4, x4, #0xc, #0x14
    // 0x454834: sub             x4, x4, #0x3c
    // 0x454838: cmp             x4, #1
    // 0x45483c: b.ls            #0x454850
    // 0x454840: r8 = int?
    //     0x454840: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x454844: r3 = Null
    //     0x454844: add             x3, PP, #0xf, lsl #12  ; [pp+0xfec0] Null
    //     0x454848: ldr             x3, [x3, #0xec0]
    // 0x45484c: r0 = int?()
    //     0x45484c: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x454850: r1 = <Chapter11GameState, int?>
    //     0x454850: add             x1, PP, #0xf, lsl #12  ; [pp+0xfed0] TypeArguments: <Chapter11GameState, int?>
    //     0x454854: ldr             x1, [x1, #0xed0]
    // 0x454858: r0 = Tuple2()
    //     0x454858: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x45485c: mov             x1, x0
    // 0x454860: r17 = -288
    //     0x454860: movn            x17, #0x11f
    // 0x454864: ldr             x0, [fp, x17]
    // 0x454868: StoreField: r1->field_b = r0
    //     0x454868: stur            w0, [x1, #0xb]
    // 0x45486c: r17 = -280
    //     0x45486c: movn            x17, #0x117
    // 0x454870: ldr             x0, [fp, x17]
    // 0x454874: StoreField: r1->field_f = r0
    //     0x454874: stur            w0, [x1, #0xf]
    // 0x454878: mov             x2, x1
    // 0x45487c: b               #0x4548c0
    // 0x454880: r1 = <Chapter11Stat>
    //     0x454880: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x454884: ldr             x1, [x1, #0xeb8]
    // 0x454888: r0 = Chapter11GameState()
    //     0x454888: bl              #0x46db6c  ; AllocateChapter11GameStateStub -> Chapter11GameState (size=0x98)
    // 0x45488c: mov             x1, x0
    // 0x454890: r2 = Null
    //     0x454890: mov             x2, NULL
    // 0x454894: r17 = -280
    //     0x454894: movn            x17, #0x117
    // 0x454898: str             x0, [fp, x17]
    // 0x45489c: r0 = Chapter11GameState()
    //     0x45489c: bl              #0x46d784  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState
    // 0x4548a0: r1 = <Chapter11GameState, int?>
    //     0x4548a0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfed0] TypeArguments: <Chapter11GameState, int?>
    //     0x4548a4: ldr             x1, [x1, #0xed0]
    // 0x4548a8: r0 = Tuple2()
    //     0x4548a8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4548ac: mov             x1, x0
    // 0x4548b0: r17 = -280
    //     0x4548b0: movn            x17, #0x117
    // 0x4548b4: ldr             x0, [fp, x17]
    // 0x4548b8: StoreField: r1->field_b = r0
    //     0x4548b8: stur            w0, [x1, #0xb]
    // 0x4548bc: mov             x2, x1
    // 0x4548c0: r17 = -272
    //     0x4548c0: movn            x17, #0x10f
    // 0x4548c4: ldr             x0, [fp, x17]
    // 0x4548c8: r17 = -280
    //     0x4548c8: movn            x17, #0x117
    // 0x4548cc: str             x2, [fp, x17]
    // 0x4548d0: LoadField: r1 = r0->field_b
    //     0x4548d0: ldur            w1, [x0, #0xb]
    // 0x4548d4: LoadField: r3 = r0->field_f
    //     0x4548d4: ldur            w3, [x0, #0xf]
    // 0x4548d8: DecompressPointer r3
    //     0x4548d8: add             x3, x3, HEAP, lsl #32
    // 0x4548dc: LoadField: r4 = r3->field_b
    //     0x4548dc: ldur            w4, [x3, #0xb]
    // 0x4548e0: r3 = LoadInt32Instr(r1)
    //     0x4548e0: sbfx            x3, x1, #1, #0x1f
    // 0x4548e4: r17 = -296
    //     0x4548e4: movn            x17, #0x127
    // 0x4548e8: str             x3, [fp, x17]
    // 0x4548ec: r1 = LoadInt32Instr(r4)
    //     0x4548ec: sbfx            x1, x4, #1, #0x1f
    // 0x4548f0: cmp             x3, x1
    // 0x4548f4: b.ne            #0x454900
    // 0x4548f8: mov             x1, x0
    // 0x4548fc: r0 = _growToNextCapacity()
    //     0x4548fc: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x454900: r17 = -272
    //     0x454900: movn            x17, #0x10f
    // 0x454904: ldr             x2, [fp, x17]
    // 0x454908: r17 = -296
    //     0x454908: movn            x17, #0x127
    // 0x45490c: ldr             x3, [fp, x17]
    // 0x454910: add             x0, x3, #1
    // 0x454914: lsl             x1, x0, #1
    // 0x454918: StoreField: r2->field_b = r1
    //     0x454918: stur            w1, [x2, #0xb]
    // 0x45491c: LoadField: r1 = r2->field_f
    //     0x45491c: ldur            w1, [x2, #0xf]
    // 0x454920: DecompressPointer r1
    //     0x454920: add             x1, x1, HEAP, lsl #32
    // 0x454924: r17 = -280
    //     0x454924: movn            x17, #0x117
    // 0x454928: ldr             x0, [fp, x17]
    // 0x45492c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x45492c: add             x25, x1, x3, lsl #2
    //     0x454930: add             x25, x25, #0xf
    //     0x454934: str             w0, [x25]
    //     0x454938: tbz             w0, #0, #0x454954
    //     0x45493c: ldurb           w16, [x1, #-1]
    //     0x454940: ldurb           w17, [x0, #-1]
    //     0x454944: and             x16, x17, x16, lsr #2
    //     0x454948: tst             x16, HEAP, lsr #32
    //     0x45494c: b.eq            #0x454954
    //     0x454950: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x454954: mov             x1, x2
    // 0x454958: r0 = last()
    //     0x454958: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x45495c: LoadField: r2 = r0->field_b
    //     0x45495c: ldur            w2, [x0, #0xb]
    // 0x454960: DecompressPointer r2
    //     0x454960: add             x2, x2, HEAP, lsl #32
    // 0x454964: r17 = -272
    //     0x454964: movn            x17, #0x10f
    // 0x454968: ldr             x1, [fp, x17]
    // 0x45496c: r17 = -280
    //     0x45496c: movn            x17, #0x117
    // 0x454970: str             x2, [fp, x17]
    // 0x454974: r0 = last()
    //     0x454974: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454978: LoadField: r1 = r0->field_f
    //     0x454978: ldur            w1, [x0, #0xf]
    // 0x45497c: DecompressPointer r1
    //     0x45497c: add             x1, x1, HEAP, lsl #32
    // 0x454980: r17 = -280
    //     0x454980: movn            x17, #0x117
    // 0x454984: ldr             x2, [fp, x17]
    // 0x454988: cmp             w2, NULL
    // 0x45498c: b.eq            #0x4561b0
    // 0x454990: mov             x0, x1
    // 0x454994: StoreField: r2->field_b = r0
    //     0x454994: stur            w0, [x2, #0xb]
    //     0x454998: tbz             w0, #0, #0x4549b4
    //     0x45499c: ldurb           w16, [x2, #-1]
    //     0x4549a0: ldurb           w17, [x0, #-1]
    //     0x4549a4: and             x16, x17, x16, lsr #2
    //     0x4549a8: tst             x16, HEAP, lsr #32
    //     0x4549ac: b.eq            #0x4549b4
    //     0x4549b0: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x4549b4: r0 = LoadStaticField(0xf60)
    //     0x4549b4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4549b8: ldr             x0, [x0, #0x1ec0]
    // 0x4549bc: r17 = -272
    //     0x4549bc: movn            x17, #0x10f
    // 0x4549c0: ldr             x1, [fp, x17]
    // 0x4549c4: r17 = -280
    //     0x4549c4: movn            x17, #0x117
    // 0x4549c8: str             x0, [fp, x17]
    // 0x4549cc: r0 = last()
    //     0x4549cc: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4549d0: LoadField: r3 = r0->field_b
    //     0x4549d0: ldur            w3, [x0, #0xb]
    // 0x4549d4: DecompressPointer r3
    //     0x4549d4: add             x3, x3, HEAP, lsl #32
    // 0x4549d8: r17 = -280
    //     0x4549d8: movn            x17, #0x117
    // 0x4549dc: ldr             x1, [fp, x17]
    // 0x4549e0: r2 = 22
    //     0x4549e0: movz            x2, #0x16
    // 0x4549e4: r0 = []=()
    //     0x4549e4: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4549e8: r1 = Null
    //     0x4549e8: mov             x1, NULL
    // 0x4549ec: r2 = 4
    //     0x4549ec: movz            x2, #0x4
    // 0x4549f0: r0 = AllocateArray()
    //     0x4549f0: bl              #0x82746c  ; AllocateArrayStub
    // 0x4549f4: r16 = "12"
    //     0x4549f4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x4549f8: ldr             x16, [x16, #0x330]
    // 0x4549fc: StoreField: r0->field_f = r16
    //     0x4549fc: stur            w16, [x0, #0xf]
    // 0x454a00: r16 = "1"
    //     0x454a00: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x454a04: ldr             x16, [x16, #0x9c8]
    // 0x454a08: StoreField: r0->field_13 = r16
    //     0x454a08: stur            w16, [x0, #0x13]
    // 0x454a0c: r1 = Null
    //     0x454a0c: mov             x1, NULL
    // 0x454a10: r2 = 4
    //     0x454a10: movz            x2, #0x4
    // 0x454a14: r0 = AllocateArray()
    //     0x454a14: bl              #0x82746c  ; AllocateArrayStub
    // 0x454a18: r16 = "12"
    //     0x454a18: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x454a1c: ldr             x16, [x16, #0x330]
    // 0x454a20: StoreField: r0->field_f = r16
    //     0x454a20: stur            w16, [x0, #0xf]
    // 0x454a24: r16 = "2"
    //     0x454a24: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x454a28: ldr             x16, [x16, #0x2e0]
    // 0x454a2c: StoreField: r0->field_13 = r16
    //     0x454a2c: stur            w16, [x0, #0x13]
    // 0x454a30: r1 = Null
    //     0x454a30: mov             x1, NULL
    // 0x454a34: r2 = 4
    //     0x454a34: movz            x2, #0x4
    // 0x454a38: r0 = AllocateArray()
    //     0x454a38: bl              #0x82746c  ; AllocateArrayStub
    // 0x454a3c: r16 = "12"
    //     0x454a3c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x454a40: ldr             x16, [x16, #0x330]
    // 0x454a44: StoreField: r0->field_f = r16
    //     0x454a44: stur            w16, [x0, #0xf]
    // 0x454a48: r16 = "3"
    //     0x454a48: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x454a4c: ldr             x16, [x16, #0x2f0]
    // 0x454a50: StoreField: r0->field_13 = r16
    //     0x454a50: stur            w16, [x0, #0x13]
    // 0x454a54: r1 = "121"
    //     0x454a54: add             x1, PP, #0xf, lsl #12  ; [pp+0xfed8] "121"
    //     0x454a58: ldr             x1, [x1, #0xed8]
    // 0x454a5c: r2 = "123"
    //     0x454a5c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfee0] "123"
    //     0x454a60: ldr             x2, [x2, #0xee0]
    // 0x454a64: r3 = 2
    //     0x454a64: movz            x3, #0x2
    // 0x454a68: r5 = "122"
    //     0x454a68: add             x5, PP, #0xf, lsl #12  ; [pp+0xfee8] "122"
    //     0x454a6c: ldr             x5, [x5, #0xee8]
    // 0x454a70: r0 = readMostRecentValidSaveFile()
    //     0x454a70: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x454a74: mov             x1, x0
    // 0x454a78: r17 = -280
    //     0x454a78: movn            x17, #0x117
    // 0x454a7c: str             x1, [fp, x17]
    // 0x454a80: r0 = Await()
    //     0x454a80: bl              #0x34b75c  ; AwaitStub
    // 0x454a84: cmp             w0, NULL
    // 0x454a88: b.eq            #0x454b4c
    // 0x454a8c: LoadField: r2 = r0->field_f
    //     0x454a8c: ldur            w2, [x0, #0xf]
    // 0x454a90: DecompressPointer r2
    //     0x454a90: add             x2, x2, HEAP, lsl #32
    // 0x454a94: r17 = -280
    //     0x454a94: movn            x17, #0x117
    // 0x454a98: str             x2, [fp, x17]
    // 0x454a9c: r1 = <Chapter12Stat>
    //     0x454a9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x454aa0: ldr             x1, [x1, #0xef0]
    // 0x454aa4: r0 = Chapter12GameState()
    //     0x454aa4: bl              #0x46d778  ; AllocateChapter12GameStateStub -> Chapter12GameState (size=0xa0)
    // 0x454aa8: mov             x1, x0
    // 0x454aac: r17 = -280
    //     0x454aac: movn            x17, #0x117
    // 0x454ab0: ldr             x2, [fp, x17]
    // 0x454ab4: r17 = -288
    //     0x454ab4: movn            x17, #0x11f
    // 0x454ab8: str             x0, [fp, x17]
    // 0x454abc: r0 = Chapter12GameState()
    //     0x454abc: bl              #0x46d16c  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState
    // 0x454ac0: r17 = -280
    //     0x454ac0: movn            x17, #0x117
    // 0x454ac4: ldr             x1, [fp, x17]
    // 0x454ac8: r0 = LoadClassIdInstr(r1)
    //     0x454ac8: ldur            x0, [x1, #-1]
    //     0x454acc: ubfx            x0, x0, #0xc, #0x14
    // 0x454ad0: r2 = 2
    //     0x454ad0: movz            x2, #0x2
    // 0x454ad4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x454ad4: sub             lr, x0, #1, lsl #12
    //     0x454ad8: ldr             lr, [x21, lr, lsl #3]
    //     0x454adc: blr             lr
    // 0x454ae0: mov             x3, x0
    // 0x454ae4: r2 = Null
    //     0x454ae4: mov             x2, NULL
    // 0x454ae8: r1 = Null
    //     0x454ae8: mov             x1, NULL
    // 0x454aec: r17 = -280
    //     0x454aec: movn            x17, #0x117
    // 0x454af0: str             x3, [fp, x17]
    // 0x454af4: branchIfSmi(r0, 0x454b1c)
    //     0x454af4: tbz             w0, #0, #0x454b1c
    // 0x454af8: r4 = LoadClassIdInstr(r0)
    //     0x454af8: ldur            x4, [x0, #-1]
    //     0x454afc: ubfx            x4, x4, #0xc, #0x14
    // 0x454b00: sub             x4, x4, #0x3c
    // 0x454b04: cmp             x4, #1
    // 0x454b08: b.ls            #0x454b1c
    // 0x454b0c: r8 = int?
    //     0x454b0c: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x454b10: r3 = Null
    //     0x454b10: add             x3, PP, #0xf, lsl #12  ; [pp+0xfef8] Null
    //     0x454b14: ldr             x3, [x3, #0xef8]
    // 0x454b18: r0 = int?()
    //     0x454b18: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x454b1c: r1 = <Chapter12GameState, int?>
    //     0x454b1c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff08] TypeArguments: <Chapter12GameState, int?>
    //     0x454b20: ldr             x1, [x1, #0xf08]
    // 0x454b24: r0 = Tuple2()
    //     0x454b24: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454b28: mov             x1, x0
    // 0x454b2c: r17 = -288
    //     0x454b2c: movn            x17, #0x11f
    // 0x454b30: ldr             x0, [fp, x17]
    // 0x454b34: StoreField: r1->field_b = r0
    //     0x454b34: stur            w0, [x1, #0xb]
    // 0x454b38: r17 = -280
    //     0x454b38: movn            x17, #0x117
    // 0x454b3c: ldr             x0, [fp, x17]
    // 0x454b40: StoreField: r1->field_f = r0
    //     0x454b40: stur            w0, [x1, #0xf]
    // 0x454b44: mov             x2, x1
    // 0x454b48: b               #0x454b8c
    // 0x454b4c: r1 = <Chapter12Stat>
    //     0x454b4c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x454b50: ldr             x1, [x1, #0xef0]
    // 0x454b54: r0 = Chapter12GameState()
    //     0x454b54: bl              #0x46d778  ; AllocateChapter12GameStateStub -> Chapter12GameState (size=0xa0)
    // 0x454b58: mov             x1, x0
    // 0x454b5c: r2 = Null
    //     0x454b5c: mov             x2, NULL
    // 0x454b60: r17 = -280
    //     0x454b60: movn            x17, #0x117
    // 0x454b64: str             x0, [fp, x17]
    // 0x454b68: r0 = Chapter12GameState()
    //     0x454b68: bl              #0x46d16c  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState
    // 0x454b6c: r1 = <Chapter12GameState, int?>
    //     0x454b6c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff08] TypeArguments: <Chapter12GameState, int?>
    //     0x454b70: ldr             x1, [x1, #0xf08]
    // 0x454b74: r0 = Tuple2()
    //     0x454b74: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454b78: mov             x1, x0
    // 0x454b7c: r17 = -280
    //     0x454b7c: movn            x17, #0x117
    // 0x454b80: ldr             x0, [fp, x17]
    // 0x454b84: StoreField: r1->field_b = r0
    //     0x454b84: stur            w0, [x1, #0xb]
    // 0x454b88: mov             x2, x1
    // 0x454b8c: r17 = -272
    //     0x454b8c: movn            x17, #0x10f
    // 0x454b90: ldr             x0, [fp, x17]
    // 0x454b94: r17 = -280
    //     0x454b94: movn            x17, #0x117
    // 0x454b98: str             x2, [fp, x17]
    // 0x454b9c: LoadField: r1 = r0->field_b
    //     0x454b9c: ldur            w1, [x0, #0xb]
    // 0x454ba0: LoadField: r3 = r0->field_f
    //     0x454ba0: ldur            w3, [x0, #0xf]
    // 0x454ba4: DecompressPointer r3
    //     0x454ba4: add             x3, x3, HEAP, lsl #32
    // 0x454ba8: LoadField: r4 = r3->field_b
    //     0x454ba8: ldur            w4, [x3, #0xb]
    // 0x454bac: r3 = LoadInt32Instr(r1)
    //     0x454bac: sbfx            x3, x1, #1, #0x1f
    // 0x454bb0: r17 = -296
    //     0x454bb0: movn            x17, #0x127
    // 0x454bb4: str             x3, [fp, x17]
    // 0x454bb8: r1 = LoadInt32Instr(r4)
    //     0x454bb8: sbfx            x1, x4, #1, #0x1f
    // 0x454bbc: cmp             x3, x1
    // 0x454bc0: b.ne            #0x454bcc
    // 0x454bc4: mov             x1, x0
    // 0x454bc8: r0 = _growToNextCapacity()
    //     0x454bc8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x454bcc: r17 = -272
    //     0x454bcc: movn            x17, #0x10f
    // 0x454bd0: ldr             x2, [fp, x17]
    // 0x454bd4: r17 = -296
    //     0x454bd4: movn            x17, #0x127
    // 0x454bd8: ldr             x3, [fp, x17]
    // 0x454bdc: add             x0, x3, #1
    // 0x454be0: lsl             x1, x0, #1
    // 0x454be4: StoreField: r2->field_b = r1
    //     0x454be4: stur            w1, [x2, #0xb]
    // 0x454be8: LoadField: r1 = r2->field_f
    //     0x454be8: ldur            w1, [x2, #0xf]
    // 0x454bec: DecompressPointer r1
    //     0x454bec: add             x1, x1, HEAP, lsl #32
    // 0x454bf0: r17 = -280
    //     0x454bf0: movn            x17, #0x117
    // 0x454bf4: ldr             x0, [fp, x17]
    // 0x454bf8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x454bf8: add             x25, x1, x3, lsl #2
    //     0x454bfc: add             x25, x25, #0xf
    //     0x454c00: str             w0, [x25]
    //     0x454c04: tbz             w0, #0, #0x454c20
    //     0x454c08: ldurb           w16, [x1, #-1]
    //     0x454c0c: ldurb           w17, [x0, #-1]
    //     0x454c10: and             x16, x17, x16, lsr #2
    //     0x454c14: tst             x16, HEAP, lsr #32
    //     0x454c18: b.eq            #0x454c20
    //     0x454c1c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x454c20: mov             x1, x2
    // 0x454c24: r0 = last()
    //     0x454c24: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454c28: LoadField: r2 = r0->field_b
    //     0x454c28: ldur            w2, [x0, #0xb]
    // 0x454c2c: DecompressPointer r2
    //     0x454c2c: add             x2, x2, HEAP, lsl #32
    // 0x454c30: r17 = -272
    //     0x454c30: movn            x17, #0x10f
    // 0x454c34: ldr             x1, [fp, x17]
    // 0x454c38: r17 = -280
    //     0x454c38: movn            x17, #0x117
    // 0x454c3c: str             x2, [fp, x17]
    // 0x454c40: r0 = last()
    //     0x454c40: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454c44: LoadField: r1 = r0->field_f
    //     0x454c44: ldur            w1, [x0, #0xf]
    // 0x454c48: DecompressPointer r1
    //     0x454c48: add             x1, x1, HEAP, lsl #32
    // 0x454c4c: r17 = -280
    //     0x454c4c: movn            x17, #0x117
    // 0x454c50: ldr             x2, [fp, x17]
    // 0x454c54: cmp             w2, NULL
    // 0x454c58: b.eq            #0x4561b4
    // 0x454c5c: mov             x0, x1
    // 0x454c60: StoreField: r2->field_b = r0
    //     0x454c60: stur            w0, [x2, #0xb]
    //     0x454c64: tbz             w0, #0, #0x454c80
    //     0x454c68: ldurb           w16, [x2, #-1]
    //     0x454c6c: ldurb           w17, [x0, #-1]
    //     0x454c70: and             x16, x17, x16, lsr #2
    //     0x454c74: tst             x16, HEAP, lsr #32
    //     0x454c78: b.eq            #0x454c80
    //     0x454c7c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x454c80: r0 = LoadStaticField(0xf60)
    //     0x454c80: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x454c84: ldr             x0, [x0, #0x1ec0]
    // 0x454c88: r17 = -272
    //     0x454c88: movn            x17, #0x10f
    // 0x454c8c: ldr             x1, [fp, x17]
    // 0x454c90: r17 = -280
    //     0x454c90: movn            x17, #0x117
    // 0x454c94: str             x0, [fp, x17]
    // 0x454c98: r0 = last()
    //     0x454c98: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454c9c: LoadField: r3 = r0->field_b
    //     0x454c9c: ldur            w3, [x0, #0xb]
    // 0x454ca0: DecompressPointer r3
    //     0x454ca0: add             x3, x3, HEAP, lsl #32
    // 0x454ca4: r17 = -280
    //     0x454ca4: movn            x17, #0x117
    // 0x454ca8: ldr             x1, [fp, x17]
    // 0x454cac: r2 = 24
    //     0x454cac: movz            x2, #0x18
    // 0x454cb0: r0 = []=()
    //     0x454cb0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x454cb4: r1 = Null
    //     0x454cb4: mov             x1, NULL
    // 0x454cb8: r2 = 4
    //     0x454cb8: movz            x2, #0x4
    // 0x454cbc: r0 = AllocateArray()
    //     0x454cbc: bl              #0x82746c  ; AllocateArrayStub
    // 0x454cc0: r16 = "13"
    //     0x454cc0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x454cc4: ldr             x16, [x16, #0x338]
    // 0x454cc8: StoreField: r0->field_f = r16
    //     0x454cc8: stur            w16, [x0, #0xf]
    // 0x454ccc: r16 = "1"
    //     0x454ccc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x454cd0: ldr             x16, [x16, #0x9c8]
    // 0x454cd4: StoreField: r0->field_13 = r16
    //     0x454cd4: stur            w16, [x0, #0x13]
    // 0x454cd8: r1 = Null
    //     0x454cd8: mov             x1, NULL
    // 0x454cdc: r2 = 4
    //     0x454cdc: movz            x2, #0x4
    // 0x454ce0: r0 = AllocateArray()
    //     0x454ce0: bl              #0x82746c  ; AllocateArrayStub
    // 0x454ce4: r16 = "13"
    //     0x454ce4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x454ce8: ldr             x16, [x16, #0x338]
    // 0x454cec: StoreField: r0->field_f = r16
    //     0x454cec: stur            w16, [x0, #0xf]
    // 0x454cf0: r16 = "2"
    //     0x454cf0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x454cf4: ldr             x16, [x16, #0x2e0]
    // 0x454cf8: StoreField: r0->field_13 = r16
    //     0x454cf8: stur            w16, [x0, #0x13]
    // 0x454cfc: r1 = Null
    //     0x454cfc: mov             x1, NULL
    // 0x454d00: r2 = 4
    //     0x454d00: movz            x2, #0x4
    // 0x454d04: r0 = AllocateArray()
    //     0x454d04: bl              #0x82746c  ; AllocateArrayStub
    // 0x454d08: r16 = "13"
    //     0x454d08: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x454d0c: ldr             x16, [x16, #0x338]
    // 0x454d10: StoreField: r0->field_f = r16
    //     0x454d10: stur            w16, [x0, #0xf]
    // 0x454d14: r16 = "3"
    //     0x454d14: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x454d18: ldr             x16, [x16, #0x2f0]
    // 0x454d1c: StoreField: r0->field_13 = r16
    //     0x454d1c: stur            w16, [x0, #0x13]
    // 0x454d20: r1 = "131"
    //     0x454d20: add             x1, PP, #0xf, lsl #12  ; [pp+0xff10] "131"
    //     0x454d24: ldr             x1, [x1, #0xf10]
    // 0x454d28: r2 = "133"
    //     0x454d28: add             x2, PP, #0xf, lsl #12  ; [pp+0xff18] "133"
    //     0x454d2c: ldr             x2, [x2, #0xf18]
    // 0x454d30: r3 = 2
    //     0x454d30: movz            x3, #0x2
    // 0x454d34: r5 = "132"
    //     0x454d34: add             x5, PP, #0xf, lsl #12  ; [pp+0xff20] "132"
    //     0x454d38: ldr             x5, [x5, #0xf20]
    // 0x454d3c: r0 = readMostRecentValidSaveFile()
    //     0x454d3c: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x454d40: mov             x1, x0
    // 0x454d44: r17 = -280
    //     0x454d44: movn            x17, #0x117
    // 0x454d48: str             x1, [fp, x17]
    // 0x454d4c: r0 = Await()
    //     0x454d4c: bl              #0x34b75c  ; AwaitStub
    // 0x454d50: cmp             w0, NULL
    // 0x454d54: b.eq            #0x454e18
    // 0x454d58: LoadField: r2 = r0->field_f
    //     0x454d58: ldur            w2, [x0, #0xf]
    // 0x454d5c: DecompressPointer r2
    //     0x454d5c: add             x2, x2, HEAP, lsl #32
    // 0x454d60: r17 = -280
    //     0x454d60: movn            x17, #0x117
    // 0x454d64: str             x2, [fp, x17]
    // 0x454d68: r1 = <Chapter13Stat>
    //     0x454d68: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x454d6c: ldr             x1, [x1, #0xf28]
    // 0x454d70: r0 = Chapter13GameState()
    //     0x454d70: bl              #0x46d160  ; AllocateChapter13GameStateStub -> Chapter13GameState (size=0xa4)
    // 0x454d74: mov             x1, x0
    // 0x454d78: r17 = -280
    //     0x454d78: movn            x17, #0x117
    // 0x454d7c: ldr             x2, [fp, x17]
    // 0x454d80: r17 = -288
    //     0x454d80: movn            x17, #0x11f
    // 0x454d84: str             x0, [fp, x17]
    // 0x454d88: r0 = Chapter13GameState()
    //     0x454d88: bl              #0x46c900  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState
    // 0x454d8c: r17 = -280
    //     0x454d8c: movn            x17, #0x117
    // 0x454d90: ldr             x1, [fp, x17]
    // 0x454d94: r0 = LoadClassIdInstr(r1)
    //     0x454d94: ldur            x0, [x1, #-1]
    //     0x454d98: ubfx            x0, x0, #0xc, #0x14
    // 0x454d9c: r2 = 2
    //     0x454d9c: movz            x2, #0x2
    // 0x454da0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x454da0: sub             lr, x0, #1, lsl #12
    //     0x454da4: ldr             lr, [x21, lr, lsl #3]
    //     0x454da8: blr             lr
    // 0x454dac: mov             x3, x0
    // 0x454db0: r2 = Null
    //     0x454db0: mov             x2, NULL
    // 0x454db4: r1 = Null
    //     0x454db4: mov             x1, NULL
    // 0x454db8: r17 = -280
    //     0x454db8: movn            x17, #0x117
    // 0x454dbc: str             x3, [fp, x17]
    // 0x454dc0: branchIfSmi(r0, 0x454de8)
    //     0x454dc0: tbz             w0, #0, #0x454de8
    // 0x454dc4: r4 = LoadClassIdInstr(r0)
    //     0x454dc4: ldur            x4, [x0, #-1]
    //     0x454dc8: ubfx            x4, x4, #0xc, #0x14
    // 0x454dcc: sub             x4, x4, #0x3c
    // 0x454dd0: cmp             x4, #1
    // 0x454dd4: b.ls            #0x454de8
    // 0x454dd8: r8 = int?
    //     0x454dd8: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x454ddc: r3 = Null
    //     0x454ddc: add             x3, PP, #0xf, lsl #12  ; [pp+0xff30] Null
    //     0x454de0: ldr             x3, [x3, #0xf30]
    // 0x454de4: r0 = int?()
    //     0x454de4: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x454de8: r1 = <Chapter13GameState, int?>
    //     0x454de8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff40] TypeArguments: <Chapter13GameState, int?>
    //     0x454dec: ldr             x1, [x1, #0xf40]
    // 0x454df0: r0 = Tuple2()
    //     0x454df0: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454df4: mov             x1, x0
    // 0x454df8: r17 = -288
    //     0x454df8: movn            x17, #0x11f
    // 0x454dfc: ldr             x0, [fp, x17]
    // 0x454e00: StoreField: r1->field_b = r0
    //     0x454e00: stur            w0, [x1, #0xb]
    // 0x454e04: r17 = -280
    //     0x454e04: movn            x17, #0x117
    // 0x454e08: ldr             x0, [fp, x17]
    // 0x454e0c: StoreField: r1->field_f = r0
    //     0x454e0c: stur            w0, [x1, #0xf]
    // 0x454e10: mov             x2, x1
    // 0x454e14: b               #0x454e58
    // 0x454e18: r1 = <Chapter13Stat>
    //     0x454e18: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x454e1c: ldr             x1, [x1, #0xf28]
    // 0x454e20: r0 = Chapter13GameState()
    //     0x454e20: bl              #0x46d160  ; AllocateChapter13GameStateStub -> Chapter13GameState (size=0xa4)
    // 0x454e24: mov             x1, x0
    // 0x454e28: r2 = Null
    //     0x454e28: mov             x2, NULL
    // 0x454e2c: r17 = -280
    //     0x454e2c: movn            x17, #0x117
    // 0x454e30: str             x0, [fp, x17]
    // 0x454e34: r0 = Chapter13GameState()
    //     0x454e34: bl              #0x46c900  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState
    // 0x454e38: r1 = <Chapter13GameState, int?>
    //     0x454e38: add             x1, PP, #0xf, lsl #12  ; [pp+0xff40] TypeArguments: <Chapter13GameState, int?>
    //     0x454e3c: ldr             x1, [x1, #0xf40]
    // 0x454e40: r0 = Tuple2()
    //     0x454e40: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x454e44: mov             x1, x0
    // 0x454e48: r17 = -280
    //     0x454e48: movn            x17, #0x117
    // 0x454e4c: ldr             x0, [fp, x17]
    // 0x454e50: StoreField: r1->field_b = r0
    //     0x454e50: stur            w0, [x1, #0xb]
    // 0x454e54: mov             x2, x1
    // 0x454e58: r17 = -272
    //     0x454e58: movn            x17, #0x10f
    // 0x454e5c: ldr             x0, [fp, x17]
    // 0x454e60: r17 = -280
    //     0x454e60: movn            x17, #0x117
    // 0x454e64: str             x2, [fp, x17]
    // 0x454e68: LoadField: r1 = r0->field_b
    //     0x454e68: ldur            w1, [x0, #0xb]
    // 0x454e6c: LoadField: r3 = r0->field_f
    //     0x454e6c: ldur            w3, [x0, #0xf]
    // 0x454e70: DecompressPointer r3
    //     0x454e70: add             x3, x3, HEAP, lsl #32
    // 0x454e74: LoadField: r4 = r3->field_b
    //     0x454e74: ldur            w4, [x3, #0xb]
    // 0x454e78: r3 = LoadInt32Instr(r1)
    //     0x454e78: sbfx            x3, x1, #1, #0x1f
    // 0x454e7c: r17 = -296
    //     0x454e7c: movn            x17, #0x127
    // 0x454e80: str             x3, [fp, x17]
    // 0x454e84: r1 = LoadInt32Instr(r4)
    //     0x454e84: sbfx            x1, x4, #1, #0x1f
    // 0x454e88: cmp             x3, x1
    // 0x454e8c: b.ne            #0x454e98
    // 0x454e90: mov             x1, x0
    // 0x454e94: r0 = _growToNextCapacity()
    //     0x454e94: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x454e98: r17 = -272
    //     0x454e98: movn            x17, #0x10f
    // 0x454e9c: ldr             x2, [fp, x17]
    // 0x454ea0: r17 = -296
    //     0x454ea0: movn            x17, #0x127
    // 0x454ea4: ldr             x3, [fp, x17]
    // 0x454ea8: add             x0, x3, #1
    // 0x454eac: lsl             x1, x0, #1
    // 0x454eb0: StoreField: r2->field_b = r1
    //     0x454eb0: stur            w1, [x2, #0xb]
    // 0x454eb4: LoadField: r1 = r2->field_f
    //     0x454eb4: ldur            w1, [x2, #0xf]
    // 0x454eb8: DecompressPointer r1
    //     0x454eb8: add             x1, x1, HEAP, lsl #32
    // 0x454ebc: r17 = -280
    //     0x454ebc: movn            x17, #0x117
    // 0x454ec0: ldr             x0, [fp, x17]
    // 0x454ec4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x454ec4: add             x25, x1, x3, lsl #2
    //     0x454ec8: add             x25, x25, #0xf
    //     0x454ecc: str             w0, [x25]
    //     0x454ed0: tbz             w0, #0, #0x454eec
    //     0x454ed4: ldurb           w16, [x1, #-1]
    //     0x454ed8: ldurb           w17, [x0, #-1]
    //     0x454edc: and             x16, x17, x16, lsr #2
    //     0x454ee0: tst             x16, HEAP, lsr #32
    //     0x454ee4: b.eq            #0x454eec
    //     0x454ee8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x454eec: mov             x1, x2
    // 0x454ef0: r0 = last()
    //     0x454ef0: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454ef4: LoadField: r2 = r0->field_b
    //     0x454ef4: ldur            w2, [x0, #0xb]
    // 0x454ef8: DecompressPointer r2
    //     0x454ef8: add             x2, x2, HEAP, lsl #32
    // 0x454efc: r17 = -272
    //     0x454efc: movn            x17, #0x10f
    // 0x454f00: ldr             x1, [fp, x17]
    // 0x454f04: r17 = -280
    //     0x454f04: movn            x17, #0x117
    // 0x454f08: str             x2, [fp, x17]
    // 0x454f0c: r0 = last()
    //     0x454f0c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454f10: LoadField: r1 = r0->field_f
    //     0x454f10: ldur            w1, [x0, #0xf]
    // 0x454f14: DecompressPointer r1
    //     0x454f14: add             x1, x1, HEAP, lsl #32
    // 0x454f18: r17 = -280
    //     0x454f18: movn            x17, #0x117
    // 0x454f1c: ldr             x2, [fp, x17]
    // 0x454f20: cmp             w2, NULL
    // 0x454f24: b.eq            #0x4561b8
    // 0x454f28: mov             x0, x1
    // 0x454f2c: StoreField: r2->field_b = r0
    //     0x454f2c: stur            w0, [x2, #0xb]
    //     0x454f30: tbz             w0, #0, #0x454f4c
    //     0x454f34: ldurb           w16, [x2, #-1]
    //     0x454f38: ldurb           w17, [x0, #-1]
    //     0x454f3c: and             x16, x17, x16, lsr #2
    //     0x454f40: tst             x16, HEAP, lsr #32
    //     0x454f44: b.eq            #0x454f4c
    //     0x454f48: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x454f4c: r0 = LoadStaticField(0xf60)
    //     0x454f4c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x454f50: ldr             x0, [x0, #0x1ec0]
    // 0x454f54: r17 = -272
    //     0x454f54: movn            x17, #0x10f
    // 0x454f58: ldr             x1, [fp, x17]
    // 0x454f5c: r17 = -280
    //     0x454f5c: movn            x17, #0x117
    // 0x454f60: str             x0, [fp, x17]
    // 0x454f64: r0 = last()
    //     0x454f64: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x454f68: LoadField: r3 = r0->field_b
    //     0x454f68: ldur            w3, [x0, #0xb]
    // 0x454f6c: DecompressPointer r3
    //     0x454f6c: add             x3, x3, HEAP, lsl #32
    // 0x454f70: r17 = -280
    //     0x454f70: movn            x17, #0x117
    // 0x454f74: ldr             x1, [fp, x17]
    // 0x454f78: r2 = 26
    //     0x454f78: movz            x2, #0x1a
    // 0x454f7c: r0 = []=()
    //     0x454f7c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x454f80: r1 = Null
    //     0x454f80: mov             x1, NULL
    // 0x454f84: r2 = 4
    //     0x454f84: movz            x2, #0x4
    // 0x454f88: r0 = AllocateArray()
    //     0x454f88: bl              #0x82746c  ; AllocateArrayStub
    // 0x454f8c: r16 = "14"
    //     0x454f8c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x454f90: ldr             x16, [x16, #0x340]
    // 0x454f94: StoreField: r0->field_f = r16
    //     0x454f94: stur            w16, [x0, #0xf]
    // 0x454f98: r16 = "1"
    //     0x454f98: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x454f9c: ldr             x16, [x16, #0x9c8]
    // 0x454fa0: StoreField: r0->field_13 = r16
    //     0x454fa0: stur            w16, [x0, #0x13]
    // 0x454fa4: r1 = Null
    //     0x454fa4: mov             x1, NULL
    // 0x454fa8: r2 = 4
    //     0x454fa8: movz            x2, #0x4
    // 0x454fac: r0 = AllocateArray()
    //     0x454fac: bl              #0x82746c  ; AllocateArrayStub
    // 0x454fb0: r16 = "14"
    //     0x454fb0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x454fb4: ldr             x16, [x16, #0x340]
    // 0x454fb8: StoreField: r0->field_f = r16
    //     0x454fb8: stur            w16, [x0, #0xf]
    // 0x454fbc: r16 = "2"
    //     0x454fbc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x454fc0: ldr             x16, [x16, #0x2e0]
    // 0x454fc4: StoreField: r0->field_13 = r16
    //     0x454fc4: stur            w16, [x0, #0x13]
    // 0x454fc8: r1 = Null
    //     0x454fc8: mov             x1, NULL
    // 0x454fcc: r2 = 4
    //     0x454fcc: movz            x2, #0x4
    // 0x454fd0: r0 = AllocateArray()
    //     0x454fd0: bl              #0x82746c  ; AllocateArrayStub
    // 0x454fd4: r16 = "14"
    //     0x454fd4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x454fd8: ldr             x16, [x16, #0x340]
    // 0x454fdc: StoreField: r0->field_f = r16
    //     0x454fdc: stur            w16, [x0, #0xf]
    // 0x454fe0: r16 = "3"
    //     0x454fe0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x454fe4: ldr             x16, [x16, #0x2f0]
    // 0x454fe8: StoreField: r0->field_13 = r16
    //     0x454fe8: stur            w16, [x0, #0x13]
    // 0x454fec: r1 = "141"
    //     0x454fec: add             x1, PP, #0xf, lsl #12  ; [pp+0xff48] "141"
    //     0x454ff0: ldr             x1, [x1, #0xf48]
    // 0x454ff4: r2 = "143"
    //     0x454ff4: add             x2, PP, #0xf, lsl #12  ; [pp+0xff50] "143"
    //     0x454ff8: ldr             x2, [x2, #0xf50]
    // 0x454ffc: r3 = 2
    //     0x454ffc: movz            x3, #0x2
    // 0x455000: r5 = "142"
    //     0x455000: add             x5, PP, #0xf, lsl #12  ; [pp+0xff58] "142"
    //     0x455004: ldr             x5, [x5, #0xf58]
    // 0x455008: r0 = readMostRecentValidSaveFile()
    //     0x455008: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x45500c: mov             x1, x0
    // 0x455010: r17 = -280
    //     0x455010: movn            x17, #0x117
    // 0x455014: str             x1, [fp, x17]
    // 0x455018: r0 = Await()
    //     0x455018: bl              #0x34b75c  ; AwaitStub
    // 0x45501c: cmp             w0, NULL
    // 0x455020: b.eq            #0x4550e4
    // 0x455024: LoadField: r2 = r0->field_f
    //     0x455024: ldur            w2, [x0, #0xf]
    // 0x455028: DecompressPointer r2
    //     0x455028: add             x2, x2, HEAP, lsl #32
    // 0x45502c: r17 = -280
    //     0x45502c: movn            x17, #0x117
    // 0x455030: str             x2, [fp, x17]
    // 0x455034: r1 = <Chapter14Stat>
    //     0x455034: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x455038: ldr             x1, [x1, #0xf60]
    // 0x45503c: r0 = Chapter14GameState()
    //     0x45503c: bl              #0x46c8f4  ; AllocateChapter14GameStateStub -> Chapter14GameState (size=0x98)
    // 0x455040: mov             x1, x0
    // 0x455044: r17 = -280
    //     0x455044: movn            x17, #0x117
    // 0x455048: ldr             x2, [fp, x17]
    // 0x45504c: r17 = -288
    //     0x45504c: movn            x17, #0x11f
    // 0x455050: str             x0, [fp, x17]
    // 0x455054: r0 = Chapter14GameState()
    //     0x455054: bl              #0x46c318  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState
    // 0x455058: r17 = -280
    //     0x455058: movn            x17, #0x117
    // 0x45505c: ldr             x1, [fp, x17]
    // 0x455060: r0 = LoadClassIdInstr(r1)
    //     0x455060: ldur            x0, [x1, #-1]
    //     0x455064: ubfx            x0, x0, #0xc, #0x14
    // 0x455068: r2 = 2
    //     0x455068: movz            x2, #0x2
    // 0x45506c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45506c: sub             lr, x0, #1, lsl #12
    //     0x455070: ldr             lr, [x21, lr, lsl #3]
    //     0x455074: blr             lr
    // 0x455078: mov             x3, x0
    // 0x45507c: r2 = Null
    //     0x45507c: mov             x2, NULL
    // 0x455080: r1 = Null
    //     0x455080: mov             x1, NULL
    // 0x455084: r17 = -280
    //     0x455084: movn            x17, #0x117
    // 0x455088: str             x3, [fp, x17]
    // 0x45508c: branchIfSmi(r0, 0x4550b4)
    //     0x45508c: tbz             w0, #0, #0x4550b4
    // 0x455090: r4 = LoadClassIdInstr(r0)
    //     0x455090: ldur            x4, [x0, #-1]
    //     0x455094: ubfx            x4, x4, #0xc, #0x14
    // 0x455098: sub             x4, x4, #0x3c
    // 0x45509c: cmp             x4, #1
    // 0x4550a0: b.ls            #0x4550b4
    // 0x4550a4: r8 = int?
    //     0x4550a4: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x4550a8: r3 = Null
    //     0x4550a8: add             x3, PP, #0xf, lsl #12  ; [pp+0xff68] Null
    //     0x4550ac: ldr             x3, [x3, #0xf68]
    // 0x4550b0: r0 = int?()
    //     0x4550b0: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x4550b4: r1 = <Chapter14GameState, int?>
    //     0x4550b4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff78] TypeArguments: <Chapter14GameState, int?>
    //     0x4550b8: ldr             x1, [x1, #0xf78]
    // 0x4550bc: r0 = Tuple2()
    //     0x4550bc: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4550c0: mov             x1, x0
    // 0x4550c4: r17 = -288
    //     0x4550c4: movn            x17, #0x11f
    // 0x4550c8: ldr             x0, [fp, x17]
    // 0x4550cc: StoreField: r1->field_b = r0
    //     0x4550cc: stur            w0, [x1, #0xb]
    // 0x4550d0: r17 = -280
    //     0x4550d0: movn            x17, #0x117
    // 0x4550d4: ldr             x0, [fp, x17]
    // 0x4550d8: StoreField: r1->field_f = r0
    //     0x4550d8: stur            w0, [x1, #0xf]
    // 0x4550dc: mov             x2, x1
    // 0x4550e0: b               #0x455124
    // 0x4550e4: r1 = <Chapter14Stat>
    //     0x4550e4: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x4550e8: ldr             x1, [x1, #0xf60]
    // 0x4550ec: r0 = Chapter14GameState()
    //     0x4550ec: bl              #0x46c8f4  ; AllocateChapter14GameStateStub -> Chapter14GameState (size=0x98)
    // 0x4550f0: mov             x1, x0
    // 0x4550f4: r2 = Null
    //     0x4550f4: mov             x2, NULL
    // 0x4550f8: r17 = -280
    //     0x4550f8: movn            x17, #0x117
    // 0x4550fc: str             x0, [fp, x17]
    // 0x455100: r0 = Chapter14GameState()
    //     0x455100: bl              #0x46c318  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState
    // 0x455104: r1 = <Chapter14GameState, int?>
    //     0x455104: add             x1, PP, #0xf, lsl #12  ; [pp+0xff78] TypeArguments: <Chapter14GameState, int?>
    //     0x455108: ldr             x1, [x1, #0xf78]
    // 0x45510c: r0 = Tuple2()
    //     0x45510c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x455110: mov             x1, x0
    // 0x455114: r17 = -280
    //     0x455114: movn            x17, #0x117
    // 0x455118: ldr             x0, [fp, x17]
    // 0x45511c: StoreField: r1->field_b = r0
    //     0x45511c: stur            w0, [x1, #0xb]
    // 0x455120: mov             x2, x1
    // 0x455124: r17 = -272
    //     0x455124: movn            x17, #0x10f
    // 0x455128: ldr             x0, [fp, x17]
    // 0x45512c: r17 = -280
    //     0x45512c: movn            x17, #0x117
    // 0x455130: str             x2, [fp, x17]
    // 0x455134: LoadField: r1 = r0->field_b
    //     0x455134: ldur            w1, [x0, #0xb]
    // 0x455138: LoadField: r3 = r0->field_f
    //     0x455138: ldur            w3, [x0, #0xf]
    // 0x45513c: DecompressPointer r3
    //     0x45513c: add             x3, x3, HEAP, lsl #32
    // 0x455140: LoadField: r4 = r3->field_b
    //     0x455140: ldur            w4, [x3, #0xb]
    // 0x455144: r3 = LoadInt32Instr(r1)
    //     0x455144: sbfx            x3, x1, #1, #0x1f
    // 0x455148: r17 = -296
    //     0x455148: movn            x17, #0x127
    // 0x45514c: str             x3, [fp, x17]
    // 0x455150: r1 = LoadInt32Instr(r4)
    //     0x455150: sbfx            x1, x4, #1, #0x1f
    // 0x455154: cmp             x3, x1
    // 0x455158: b.ne            #0x455164
    // 0x45515c: mov             x1, x0
    // 0x455160: r0 = _growToNextCapacity()
    //     0x455160: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x455164: r17 = -272
    //     0x455164: movn            x17, #0x10f
    // 0x455168: ldr             x2, [fp, x17]
    // 0x45516c: r17 = -296
    //     0x45516c: movn            x17, #0x127
    // 0x455170: ldr             x3, [fp, x17]
    // 0x455174: add             x0, x3, #1
    // 0x455178: lsl             x1, x0, #1
    // 0x45517c: StoreField: r2->field_b = r1
    //     0x45517c: stur            w1, [x2, #0xb]
    // 0x455180: LoadField: r1 = r2->field_f
    //     0x455180: ldur            w1, [x2, #0xf]
    // 0x455184: DecompressPointer r1
    //     0x455184: add             x1, x1, HEAP, lsl #32
    // 0x455188: r17 = -280
    //     0x455188: movn            x17, #0x117
    // 0x45518c: ldr             x0, [fp, x17]
    // 0x455190: ArrayStore: r1[r3] = r0  ; List_4
    //     0x455190: add             x25, x1, x3, lsl #2
    //     0x455194: add             x25, x25, #0xf
    //     0x455198: str             w0, [x25]
    //     0x45519c: tbz             w0, #0, #0x4551b8
    //     0x4551a0: ldurb           w16, [x1, #-1]
    //     0x4551a4: ldurb           w17, [x0, #-1]
    //     0x4551a8: and             x16, x17, x16, lsr #2
    //     0x4551ac: tst             x16, HEAP, lsr #32
    //     0x4551b0: b.eq            #0x4551b8
    //     0x4551b4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4551b8: mov             x1, x2
    // 0x4551bc: r0 = last()
    //     0x4551bc: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4551c0: LoadField: r2 = r0->field_b
    //     0x4551c0: ldur            w2, [x0, #0xb]
    // 0x4551c4: DecompressPointer r2
    //     0x4551c4: add             x2, x2, HEAP, lsl #32
    // 0x4551c8: r17 = -272
    //     0x4551c8: movn            x17, #0x10f
    // 0x4551cc: ldr             x1, [fp, x17]
    // 0x4551d0: r17 = -280
    //     0x4551d0: movn            x17, #0x117
    // 0x4551d4: str             x2, [fp, x17]
    // 0x4551d8: r0 = last()
    //     0x4551d8: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4551dc: LoadField: r1 = r0->field_f
    //     0x4551dc: ldur            w1, [x0, #0xf]
    // 0x4551e0: DecompressPointer r1
    //     0x4551e0: add             x1, x1, HEAP, lsl #32
    // 0x4551e4: r17 = -280
    //     0x4551e4: movn            x17, #0x117
    // 0x4551e8: ldr             x2, [fp, x17]
    // 0x4551ec: cmp             w2, NULL
    // 0x4551f0: b.eq            #0x4561bc
    // 0x4551f4: mov             x0, x1
    // 0x4551f8: StoreField: r2->field_b = r0
    //     0x4551f8: stur            w0, [x2, #0xb]
    //     0x4551fc: tbz             w0, #0, #0x455218
    //     0x455200: ldurb           w16, [x2, #-1]
    //     0x455204: ldurb           w17, [x0, #-1]
    //     0x455208: and             x16, x17, x16, lsr #2
    //     0x45520c: tst             x16, HEAP, lsr #32
    //     0x455210: b.eq            #0x455218
    //     0x455214: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x455218: r0 = LoadStaticField(0xf60)
    //     0x455218: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45521c: ldr             x0, [x0, #0x1ec0]
    // 0x455220: r17 = -272
    //     0x455220: movn            x17, #0x10f
    // 0x455224: ldr             x1, [fp, x17]
    // 0x455228: r17 = -280
    //     0x455228: movn            x17, #0x117
    // 0x45522c: str             x0, [fp, x17]
    // 0x455230: r0 = last()
    //     0x455230: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455234: LoadField: r3 = r0->field_b
    //     0x455234: ldur            w3, [x0, #0xb]
    // 0x455238: DecompressPointer r3
    //     0x455238: add             x3, x3, HEAP, lsl #32
    // 0x45523c: r17 = -280
    //     0x45523c: movn            x17, #0x117
    // 0x455240: ldr             x1, [fp, x17]
    // 0x455244: r2 = 28
    //     0x455244: movz            x2, #0x1c
    // 0x455248: r0 = []=()
    //     0x455248: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x45524c: r1 = Null
    //     0x45524c: mov             x1, NULL
    // 0x455250: r2 = 4
    //     0x455250: movz            x2, #0x4
    // 0x455254: r0 = AllocateArray()
    //     0x455254: bl              #0x82746c  ; AllocateArrayStub
    // 0x455258: r16 = "15"
    //     0x455258: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x45525c: ldr             x16, [x16, #0x348]
    // 0x455260: StoreField: r0->field_f = r16
    //     0x455260: stur            w16, [x0, #0xf]
    // 0x455264: r16 = "1"
    //     0x455264: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x455268: ldr             x16, [x16, #0x9c8]
    // 0x45526c: StoreField: r0->field_13 = r16
    //     0x45526c: stur            w16, [x0, #0x13]
    // 0x455270: r1 = Null
    //     0x455270: mov             x1, NULL
    // 0x455274: r2 = 4
    //     0x455274: movz            x2, #0x4
    // 0x455278: r0 = AllocateArray()
    //     0x455278: bl              #0x82746c  ; AllocateArrayStub
    // 0x45527c: r16 = "15"
    //     0x45527c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x455280: ldr             x16, [x16, #0x348]
    // 0x455284: StoreField: r0->field_f = r16
    //     0x455284: stur            w16, [x0, #0xf]
    // 0x455288: r16 = "2"
    //     0x455288: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x45528c: ldr             x16, [x16, #0x2e0]
    // 0x455290: StoreField: r0->field_13 = r16
    //     0x455290: stur            w16, [x0, #0x13]
    // 0x455294: r1 = Null
    //     0x455294: mov             x1, NULL
    // 0x455298: r2 = 4
    //     0x455298: movz            x2, #0x4
    // 0x45529c: r0 = AllocateArray()
    //     0x45529c: bl              #0x82746c  ; AllocateArrayStub
    // 0x4552a0: r16 = "15"
    //     0x4552a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x4552a4: ldr             x16, [x16, #0x348]
    // 0x4552a8: StoreField: r0->field_f = r16
    //     0x4552a8: stur            w16, [x0, #0xf]
    // 0x4552ac: r16 = "3"
    //     0x4552ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x4552b0: ldr             x16, [x16, #0x2f0]
    // 0x4552b4: StoreField: r0->field_13 = r16
    //     0x4552b4: stur            w16, [x0, #0x13]
    // 0x4552b8: r1 = "151"
    //     0x4552b8: add             x1, PP, #0xf, lsl #12  ; [pp+0xff80] "151"
    //     0x4552bc: ldr             x1, [x1, #0xf80]
    // 0x4552c0: r2 = "153"
    //     0x4552c0: add             x2, PP, #0xf, lsl #12  ; [pp+0xff88] "153"
    //     0x4552c4: ldr             x2, [x2, #0xf88]
    // 0x4552c8: r3 = 2
    //     0x4552c8: movz            x3, #0x2
    // 0x4552cc: r5 = "152"
    //     0x4552cc: add             x5, PP, #0xf, lsl #12  ; [pp+0xff90] "152"
    //     0x4552d0: ldr             x5, [x5, #0xf90]
    // 0x4552d4: r0 = readMostRecentValidSaveFile()
    //     0x4552d4: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4552d8: mov             x1, x0
    // 0x4552dc: r17 = -280
    //     0x4552dc: movn            x17, #0x117
    // 0x4552e0: str             x1, [fp, x17]
    // 0x4552e4: r0 = Await()
    //     0x4552e4: bl              #0x34b75c  ; AwaitStub
    // 0x4552e8: cmp             w0, NULL
    // 0x4552ec: b.eq            #0x4553b0
    // 0x4552f0: LoadField: r2 = r0->field_f
    //     0x4552f0: ldur            w2, [x0, #0xf]
    // 0x4552f4: DecompressPointer r2
    //     0x4552f4: add             x2, x2, HEAP, lsl #32
    // 0x4552f8: r17 = -280
    //     0x4552f8: movn            x17, #0x117
    // 0x4552fc: str             x2, [fp, x17]
    // 0x455300: r1 = <Chapter15Stat>
    //     0x455300: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x455304: ldr             x1, [x1, #0xf98]
    // 0x455308: r0 = Chapter15GameState()
    //     0x455308: bl              #0x46c30c  ; AllocateChapter15GameStateStub -> Chapter15GameState (size=0xac)
    // 0x45530c: mov             x1, x0
    // 0x455310: r17 = -280
    //     0x455310: movn            x17, #0x117
    // 0x455314: ldr             x2, [fp, x17]
    // 0x455318: r17 = -288
    //     0x455318: movn            x17, #0x11f
    // 0x45531c: str             x0, [fp, x17]
    // 0x455320: r0 = Chapter15GameState()
    //     0x455320: bl              #0x46b010  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState
    // 0x455324: r17 = -280
    //     0x455324: movn            x17, #0x117
    // 0x455328: ldr             x1, [fp, x17]
    // 0x45532c: r0 = LoadClassIdInstr(r1)
    //     0x45532c: ldur            x0, [x1, #-1]
    //     0x455330: ubfx            x0, x0, #0xc, #0x14
    // 0x455334: r2 = 2
    //     0x455334: movz            x2, #0x2
    // 0x455338: r0 = GDT[cid_x0 + -0x1000]()
    //     0x455338: sub             lr, x0, #1, lsl #12
    //     0x45533c: ldr             lr, [x21, lr, lsl #3]
    //     0x455340: blr             lr
    // 0x455344: mov             x3, x0
    // 0x455348: r2 = Null
    //     0x455348: mov             x2, NULL
    // 0x45534c: r1 = Null
    //     0x45534c: mov             x1, NULL
    // 0x455350: r17 = -280
    //     0x455350: movn            x17, #0x117
    // 0x455354: str             x3, [fp, x17]
    // 0x455358: branchIfSmi(r0, 0x455380)
    //     0x455358: tbz             w0, #0, #0x455380
    // 0x45535c: r4 = LoadClassIdInstr(r0)
    //     0x45535c: ldur            x4, [x0, #-1]
    //     0x455360: ubfx            x4, x4, #0xc, #0x14
    // 0x455364: sub             x4, x4, #0x3c
    // 0x455368: cmp             x4, #1
    // 0x45536c: b.ls            #0x455380
    // 0x455370: r8 = int?
    //     0x455370: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x455374: r3 = Null
    //     0x455374: add             x3, PP, #0xf, lsl #12  ; [pp+0xffa0] Null
    //     0x455378: ldr             x3, [x3, #0xfa0]
    // 0x45537c: r0 = int?()
    //     0x45537c: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x455380: r1 = <Chapter15GameState, int?>
    //     0x455380: add             x1, PP, #0xf, lsl #12  ; [pp+0xffb0] TypeArguments: <Chapter15GameState, int?>
    //     0x455384: ldr             x1, [x1, #0xfb0]
    // 0x455388: r0 = Tuple2()
    //     0x455388: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x45538c: mov             x1, x0
    // 0x455390: r17 = -288
    //     0x455390: movn            x17, #0x11f
    // 0x455394: ldr             x0, [fp, x17]
    // 0x455398: StoreField: r1->field_b = r0
    //     0x455398: stur            w0, [x1, #0xb]
    // 0x45539c: r17 = -280
    //     0x45539c: movn            x17, #0x117
    // 0x4553a0: ldr             x0, [fp, x17]
    // 0x4553a4: StoreField: r1->field_f = r0
    //     0x4553a4: stur            w0, [x1, #0xf]
    // 0x4553a8: mov             x2, x1
    // 0x4553ac: b               #0x4553f0
    // 0x4553b0: r1 = <Chapter15Stat>
    //     0x4553b0: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x4553b4: ldr             x1, [x1, #0xf98]
    // 0x4553b8: r0 = Chapter15GameState()
    //     0x4553b8: bl              #0x46c30c  ; AllocateChapter15GameStateStub -> Chapter15GameState (size=0xac)
    // 0x4553bc: mov             x1, x0
    // 0x4553c0: r2 = Null
    //     0x4553c0: mov             x2, NULL
    // 0x4553c4: r17 = -280
    //     0x4553c4: movn            x17, #0x117
    // 0x4553c8: str             x0, [fp, x17]
    // 0x4553cc: r0 = Chapter15GameState()
    //     0x4553cc: bl              #0x46b010  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState
    // 0x4553d0: r1 = <Chapter15GameState, int?>
    //     0x4553d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xffb0] TypeArguments: <Chapter15GameState, int?>
    //     0x4553d4: ldr             x1, [x1, #0xfb0]
    // 0x4553d8: r0 = Tuple2()
    //     0x4553d8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4553dc: mov             x1, x0
    // 0x4553e0: r17 = -280
    //     0x4553e0: movn            x17, #0x117
    // 0x4553e4: ldr             x0, [fp, x17]
    // 0x4553e8: StoreField: r1->field_b = r0
    //     0x4553e8: stur            w0, [x1, #0xb]
    // 0x4553ec: mov             x2, x1
    // 0x4553f0: r17 = -272
    //     0x4553f0: movn            x17, #0x10f
    // 0x4553f4: ldr             x0, [fp, x17]
    // 0x4553f8: r17 = -280
    //     0x4553f8: movn            x17, #0x117
    // 0x4553fc: str             x2, [fp, x17]
    // 0x455400: LoadField: r1 = r0->field_b
    //     0x455400: ldur            w1, [x0, #0xb]
    // 0x455404: LoadField: r3 = r0->field_f
    //     0x455404: ldur            w3, [x0, #0xf]
    // 0x455408: DecompressPointer r3
    //     0x455408: add             x3, x3, HEAP, lsl #32
    // 0x45540c: LoadField: r4 = r3->field_b
    //     0x45540c: ldur            w4, [x3, #0xb]
    // 0x455410: r3 = LoadInt32Instr(r1)
    //     0x455410: sbfx            x3, x1, #1, #0x1f
    // 0x455414: r17 = -296
    //     0x455414: movn            x17, #0x127
    // 0x455418: str             x3, [fp, x17]
    // 0x45541c: r1 = LoadInt32Instr(r4)
    //     0x45541c: sbfx            x1, x4, #1, #0x1f
    // 0x455420: cmp             x3, x1
    // 0x455424: b.ne            #0x455430
    // 0x455428: mov             x1, x0
    // 0x45542c: r0 = _growToNextCapacity()
    //     0x45542c: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x455430: r17 = -272
    //     0x455430: movn            x17, #0x10f
    // 0x455434: ldr             x2, [fp, x17]
    // 0x455438: r17 = -296
    //     0x455438: movn            x17, #0x127
    // 0x45543c: ldr             x3, [fp, x17]
    // 0x455440: add             x0, x3, #1
    // 0x455444: lsl             x1, x0, #1
    // 0x455448: StoreField: r2->field_b = r1
    //     0x455448: stur            w1, [x2, #0xb]
    // 0x45544c: LoadField: r1 = r2->field_f
    //     0x45544c: ldur            w1, [x2, #0xf]
    // 0x455450: DecompressPointer r1
    //     0x455450: add             x1, x1, HEAP, lsl #32
    // 0x455454: r17 = -280
    //     0x455454: movn            x17, #0x117
    // 0x455458: ldr             x0, [fp, x17]
    // 0x45545c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x45545c: add             x25, x1, x3, lsl #2
    //     0x455460: add             x25, x25, #0xf
    //     0x455464: str             w0, [x25]
    //     0x455468: tbz             w0, #0, #0x455484
    //     0x45546c: ldurb           w16, [x1, #-1]
    //     0x455470: ldurb           w17, [x0, #-1]
    //     0x455474: and             x16, x17, x16, lsr #2
    //     0x455478: tst             x16, HEAP, lsr #32
    //     0x45547c: b.eq            #0x455484
    //     0x455480: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x455484: mov             x1, x2
    // 0x455488: r0 = last()
    //     0x455488: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x45548c: LoadField: r2 = r0->field_b
    //     0x45548c: ldur            w2, [x0, #0xb]
    // 0x455490: DecompressPointer r2
    //     0x455490: add             x2, x2, HEAP, lsl #32
    // 0x455494: r17 = -272
    //     0x455494: movn            x17, #0x10f
    // 0x455498: ldr             x1, [fp, x17]
    // 0x45549c: r17 = -280
    //     0x45549c: movn            x17, #0x117
    // 0x4554a0: str             x2, [fp, x17]
    // 0x4554a4: r0 = last()
    //     0x4554a4: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4554a8: LoadField: r1 = r0->field_f
    //     0x4554a8: ldur            w1, [x0, #0xf]
    // 0x4554ac: DecompressPointer r1
    //     0x4554ac: add             x1, x1, HEAP, lsl #32
    // 0x4554b0: r17 = -280
    //     0x4554b0: movn            x17, #0x117
    // 0x4554b4: ldr             x2, [fp, x17]
    // 0x4554b8: cmp             w2, NULL
    // 0x4554bc: b.eq            #0x4561c0
    // 0x4554c0: mov             x0, x1
    // 0x4554c4: StoreField: r2->field_b = r0
    //     0x4554c4: stur            w0, [x2, #0xb]
    //     0x4554c8: tbz             w0, #0, #0x4554e4
    //     0x4554cc: ldurb           w16, [x2, #-1]
    //     0x4554d0: ldurb           w17, [x0, #-1]
    //     0x4554d4: and             x16, x17, x16, lsr #2
    //     0x4554d8: tst             x16, HEAP, lsr #32
    //     0x4554dc: b.eq            #0x4554e4
    //     0x4554e0: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x4554e4: r0 = LoadStaticField(0xf60)
    //     0x4554e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4554e8: ldr             x0, [x0, #0x1ec0]
    // 0x4554ec: r17 = -272
    //     0x4554ec: movn            x17, #0x10f
    // 0x4554f0: ldr             x1, [fp, x17]
    // 0x4554f4: r17 = -280
    //     0x4554f4: movn            x17, #0x117
    // 0x4554f8: str             x0, [fp, x17]
    // 0x4554fc: r0 = last()
    //     0x4554fc: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455500: LoadField: r3 = r0->field_b
    //     0x455500: ldur            w3, [x0, #0xb]
    // 0x455504: DecompressPointer r3
    //     0x455504: add             x3, x3, HEAP, lsl #32
    // 0x455508: r17 = -280
    //     0x455508: movn            x17, #0x117
    // 0x45550c: ldr             x1, [fp, x17]
    // 0x455510: r2 = 30
    //     0x455510: movz            x2, #0x1e
    // 0x455514: r0 = []=()
    //     0x455514: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x455518: r1 = Null
    //     0x455518: mov             x1, NULL
    // 0x45551c: r2 = 4
    //     0x45551c: movz            x2, #0x4
    // 0x455520: r0 = AllocateArray()
    //     0x455520: bl              #0x82746c  ; AllocateArrayStub
    // 0x455524: r16 = "16"
    //     0x455524: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x455528: ldr             x16, [x16, #0x350]
    // 0x45552c: StoreField: r0->field_f = r16
    //     0x45552c: stur            w16, [x0, #0xf]
    // 0x455530: r16 = "1"
    //     0x455530: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x455534: ldr             x16, [x16, #0x9c8]
    // 0x455538: StoreField: r0->field_13 = r16
    //     0x455538: stur            w16, [x0, #0x13]
    // 0x45553c: r1 = Null
    //     0x45553c: mov             x1, NULL
    // 0x455540: r2 = 4
    //     0x455540: movz            x2, #0x4
    // 0x455544: r0 = AllocateArray()
    //     0x455544: bl              #0x82746c  ; AllocateArrayStub
    // 0x455548: r16 = "16"
    //     0x455548: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x45554c: ldr             x16, [x16, #0x350]
    // 0x455550: StoreField: r0->field_f = r16
    //     0x455550: stur            w16, [x0, #0xf]
    // 0x455554: r16 = "2"
    //     0x455554: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x455558: ldr             x16, [x16, #0x2e0]
    // 0x45555c: StoreField: r0->field_13 = r16
    //     0x45555c: stur            w16, [x0, #0x13]
    // 0x455560: r1 = Null
    //     0x455560: mov             x1, NULL
    // 0x455564: r2 = 4
    //     0x455564: movz            x2, #0x4
    // 0x455568: r0 = AllocateArray()
    //     0x455568: bl              #0x82746c  ; AllocateArrayStub
    // 0x45556c: r16 = "16"
    //     0x45556c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x455570: ldr             x16, [x16, #0x350]
    // 0x455574: StoreField: r0->field_f = r16
    //     0x455574: stur            w16, [x0, #0xf]
    // 0x455578: r16 = "3"
    //     0x455578: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x45557c: ldr             x16, [x16, #0x2f0]
    // 0x455580: StoreField: r0->field_13 = r16
    //     0x455580: stur            w16, [x0, #0x13]
    // 0x455584: r1 = "161"
    //     0x455584: add             x1, PP, #0xf, lsl #12  ; [pp+0xffb8] "161"
    //     0x455588: ldr             x1, [x1, #0xfb8]
    // 0x45558c: r2 = "163"
    //     0x45558c: add             x2, PP, #0xf, lsl #12  ; [pp+0xffc0] "163"
    //     0x455590: ldr             x2, [x2, #0xfc0]
    // 0x455594: r3 = 2
    //     0x455594: movz            x3, #0x2
    // 0x455598: r5 = "162"
    //     0x455598: add             x5, PP, #0xf, lsl #12  ; [pp+0xffc8] "162"
    //     0x45559c: ldr             x5, [x5, #0xfc8]
    // 0x4555a0: r0 = readMostRecentValidSaveFile()
    //     0x4555a0: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x4555a4: mov             x1, x0
    // 0x4555a8: r17 = -280
    //     0x4555a8: movn            x17, #0x117
    // 0x4555ac: str             x1, [fp, x17]
    // 0x4555b0: r0 = Await()
    //     0x4555b0: bl              #0x34b75c  ; AwaitStub
    // 0x4555b4: cmp             w0, NULL
    // 0x4555b8: b.eq            #0x45567c
    // 0x4555bc: LoadField: r2 = r0->field_f
    //     0x4555bc: ldur            w2, [x0, #0xf]
    // 0x4555c0: DecompressPointer r2
    //     0x4555c0: add             x2, x2, HEAP, lsl #32
    // 0x4555c4: r17 = -280
    //     0x4555c4: movn            x17, #0x117
    // 0x4555c8: str             x2, [fp, x17]
    // 0x4555cc: r1 = <Chapter16Stat>
    //     0x4555cc: add             x1, PP, #0xf, lsl #12  ; [pp+0xffd0] TypeArguments: <Chapter16Stat>
    //     0x4555d0: ldr             x1, [x1, #0xfd0]
    // 0x4555d4: r0 = Chapter16GameState()
    //     0x4555d4: bl              #0x46b004  ; AllocateChapter16GameStateStub -> Chapter16GameState (size=0x90)
    // 0x4555d8: mov             x1, x0
    // 0x4555dc: r17 = -280
    //     0x4555dc: movn            x17, #0x117
    // 0x4555e0: ldr             x2, [fp, x17]
    // 0x4555e4: r17 = -288
    //     0x4555e4: movn            x17, #0x11f
    // 0x4555e8: str             x0, [fp, x17]
    // 0x4555ec: r0 = Chapter16GameState()
    //     0x4555ec: bl              #0x46ae7c  ; [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::Chapter16GameState
    // 0x4555f0: r17 = -280
    //     0x4555f0: movn            x17, #0x117
    // 0x4555f4: ldr             x1, [fp, x17]
    // 0x4555f8: r0 = LoadClassIdInstr(r1)
    //     0x4555f8: ldur            x0, [x1, #-1]
    //     0x4555fc: ubfx            x0, x0, #0xc, #0x14
    // 0x455600: r2 = 2
    //     0x455600: movz            x2, #0x2
    // 0x455604: r0 = GDT[cid_x0 + -0x1000]()
    //     0x455604: sub             lr, x0, #1, lsl #12
    //     0x455608: ldr             lr, [x21, lr, lsl #3]
    //     0x45560c: blr             lr
    // 0x455610: mov             x3, x0
    // 0x455614: r2 = Null
    //     0x455614: mov             x2, NULL
    // 0x455618: r1 = Null
    //     0x455618: mov             x1, NULL
    // 0x45561c: r17 = -280
    //     0x45561c: movn            x17, #0x117
    // 0x455620: str             x3, [fp, x17]
    // 0x455624: branchIfSmi(r0, 0x45564c)
    //     0x455624: tbz             w0, #0, #0x45564c
    // 0x455628: r4 = LoadClassIdInstr(r0)
    //     0x455628: ldur            x4, [x0, #-1]
    //     0x45562c: ubfx            x4, x4, #0xc, #0x14
    // 0x455630: sub             x4, x4, #0x3c
    // 0x455634: cmp             x4, #1
    // 0x455638: b.ls            #0x45564c
    // 0x45563c: r8 = int?
    //     0x45563c: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x455640: r3 = Null
    //     0x455640: add             x3, PP, #0xf, lsl #12  ; [pp+0xffd8] Null
    //     0x455644: ldr             x3, [x3, #0xfd8]
    // 0x455648: r0 = int?()
    //     0x455648: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x45564c: r1 = <Chapter16GameState, int?>
    //     0x45564c: add             x1, PP, #0xf, lsl #12  ; [pp+0xffe8] TypeArguments: <Chapter16GameState, int?>
    //     0x455650: ldr             x1, [x1, #0xfe8]
    // 0x455654: r0 = Tuple2()
    //     0x455654: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x455658: mov             x1, x0
    // 0x45565c: r17 = -288
    //     0x45565c: movn            x17, #0x11f
    // 0x455660: ldr             x0, [fp, x17]
    // 0x455664: StoreField: r1->field_b = r0
    //     0x455664: stur            w0, [x1, #0xb]
    // 0x455668: r17 = -280
    //     0x455668: movn            x17, #0x117
    // 0x45566c: ldr             x0, [fp, x17]
    // 0x455670: StoreField: r1->field_f = r0
    //     0x455670: stur            w0, [x1, #0xf]
    // 0x455674: mov             x2, x1
    // 0x455678: b               #0x4556bc
    // 0x45567c: r1 = <Chapter16Stat>
    //     0x45567c: add             x1, PP, #0xf, lsl #12  ; [pp+0xffd0] TypeArguments: <Chapter16Stat>
    //     0x455680: ldr             x1, [x1, #0xfd0]
    // 0x455684: r0 = Chapter16GameState()
    //     0x455684: bl              #0x46b004  ; AllocateChapter16GameStateStub -> Chapter16GameState (size=0x90)
    // 0x455688: mov             x1, x0
    // 0x45568c: r2 = Null
    //     0x45568c: mov             x2, NULL
    // 0x455690: r17 = -280
    //     0x455690: movn            x17, #0x117
    // 0x455694: str             x0, [fp, x17]
    // 0x455698: r0 = Chapter16GameState()
    //     0x455698: bl              #0x46ae7c  ; [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::Chapter16GameState
    // 0x45569c: r1 = <Chapter16GameState, int?>
    //     0x45569c: add             x1, PP, #0xf, lsl #12  ; [pp+0xffe8] TypeArguments: <Chapter16GameState, int?>
    //     0x4556a0: ldr             x1, [x1, #0xfe8]
    // 0x4556a4: r0 = Tuple2()
    //     0x4556a4: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x4556a8: mov             x1, x0
    // 0x4556ac: r17 = -280
    //     0x4556ac: movn            x17, #0x117
    // 0x4556b0: ldr             x0, [fp, x17]
    // 0x4556b4: StoreField: r1->field_b = r0
    //     0x4556b4: stur            w0, [x1, #0xb]
    // 0x4556b8: mov             x2, x1
    // 0x4556bc: r17 = -272
    //     0x4556bc: movn            x17, #0x10f
    // 0x4556c0: ldr             x0, [fp, x17]
    // 0x4556c4: r17 = -280
    //     0x4556c4: movn            x17, #0x117
    // 0x4556c8: str             x2, [fp, x17]
    // 0x4556cc: LoadField: r1 = r0->field_b
    //     0x4556cc: ldur            w1, [x0, #0xb]
    // 0x4556d0: LoadField: r3 = r0->field_f
    //     0x4556d0: ldur            w3, [x0, #0xf]
    // 0x4556d4: DecompressPointer r3
    //     0x4556d4: add             x3, x3, HEAP, lsl #32
    // 0x4556d8: LoadField: r4 = r3->field_b
    //     0x4556d8: ldur            w4, [x3, #0xb]
    // 0x4556dc: r3 = LoadInt32Instr(r1)
    //     0x4556dc: sbfx            x3, x1, #1, #0x1f
    // 0x4556e0: r17 = -296
    //     0x4556e0: movn            x17, #0x127
    // 0x4556e4: str             x3, [fp, x17]
    // 0x4556e8: r1 = LoadInt32Instr(r4)
    //     0x4556e8: sbfx            x1, x4, #1, #0x1f
    // 0x4556ec: cmp             x3, x1
    // 0x4556f0: b.ne            #0x4556fc
    // 0x4556f4: mov             x1, x0
    // 0x4556f8: r0 = _growToNextCapacity()
    //     0x4556f8: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4556fc: r17 = -272
    //     0x4556fc: movn            x17, #0x10f
    // 0x455700: ldr             x2, [fp, x17]
    // 0x455704: r17 = -296
    //     0x455704: movn            x17, #0x127
    // 0x455708: ldr             x3, [fp, x17]
    // 0x45570c: add             x0, x3, #1
    // 0x455710: lsl             x1, x0, #1
    // 0x455714: StoreField: r2->field_b = r1
    //     0x455714: stur            w1, [x2, #0xb]
    // 0x455718: LoadField: r1 = r2->field_f
    //     0x455718: ldur            w1, [x2, #0xf]
    // 0x45571c: DecompressPointer r1
    //     0x45571c: add             x1, x1, HEAP, lsl #32
    // 0x455720: r17 = -280
    //     0x455720: movn            x17, #0x117
    // 0x455724: ldr             x0, [fp, x17]
    // 0x455728: ArrayStore: r1[r3] = r0  ; List_4
    //     0x455728: add             x25, x1, x3, lsl #2
    //     0x45572c: add             x25, x25, #0xf
    //     0x455730: str             w0, [x25]
    //     0x455734: tbz             w0, #0, #0x455750
    //     0x455738: ldurb           w16, [x1, #-1]
    //     0x45573c: ldurb           w17, [x0, #-1]
    //     0x455740: and             x16, x17, x16, lsr #2
    //     0x455744: tst             x16, HEAP, lsr #32
    //     0x455748: b.eq            #0x455750
    //     0x45574c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x455750: mov             x1, x2
    // 0x455754: r0 = last()
    //     0x455754: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455758: LoadField: r2 = r0->field_b
    //     0x455758: ldur            w2, [x0, #0xb]
    // 0x45575c: DecompressPointer r2
    //     0x45575c: add             x2, x2, HEAP, lsl #32
    // 0x455760: r17 = -272
    //     0x455760: movn            x17, #0x10f
    // 0x455764: ldr             x1, [fp, x17]
    // 0x455768: r17 = -280
    //     0x455768: movn            x17, #0x117
    // 0x45576c: str             x2, [fp, x17]
    // 0x455770: r0 = last()
    //     0x455770: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455774: LoadField: r1 = r0->field_f
    //     0x455774: ldur            w1, [x0, #0xf]
    // 0x455778: DecompressPointer r1
    //     0x455778: add             x1, x1, HEAP, lsl #32
    // 0x45577c: r17 = -280
    //     0x45577c: movn            x17, #0x117
    // 0x455780: ldr             x2, [fp, x17]
    // 0x455784: cmp             w2, NULL
    // 0x455788: b.eq            #0x4561c4
    // 0x45578c: mov             x0, x1
    // 0x455790: StoreField: r2->field_b = r0
    //     0x455790: stur            w0, [x2, #0xb]
    //     0x455794: tbz             w0, #0, #0x4557b0
    //     0x455798: ldurb           w16, [x2, #-1]
    //     0x45579c: ldurb           w17, [x0, #-1]
    //     0x4557a0: and             x16, x17, x16, lsr #2
    //     0x4557a4: tst             x16, HEAP, lsr #32
    //     0x4557a8: b.eq            #0x4557b0
    //     0x4557ac: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x4557b0: r0 = LoadStaticField(0xf60)
    //     0x4557b0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4557b4: ldr             x0, [x0, #0x1ec0]
    // 0x4557b8: r17 = -272
    //     0x4557b8: movn            x17, #0x10f
    // 0x4557bc: ldr             x1, [fp, x17]
    // 0x4557c0: r17 = -280
    //     0x4557c0: movn            x17, #0x117
    // 0x4557c4: str             x0, [fp, x17]
    // 0x4557c8: r0 = last()
    //     0x4557c8: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x4557cc: LoadField: r3 = r0->field_b
    //     0x4557cc: ldur            w3, [x0, #0xb]
    // 0x4557d0: DecompressPointer r3
    //     0x4557d0: add             x3, x3, HEAP, lsl #32
    // 0x4557d4: r17 = -280
    //     0x4557d4: movn            x17, #0x117
    // 0x4557d8: ldr             x1, [fp, x17]
    // 0x4557dc: r2 = 32
    //     0x4557dc: movz            x2, #0x20
    // 0x4557e0: r0 = []=()
    //     0x4557e0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x4557e4: r1 = Null
    //     0x4557e4: mov             x1, NULL
    // 0x4557e8: r2 = 4
    //     0x4557e8: movz            x2, #0x4
    // 0x4557ec: r0 = AllocateArray()
    //     0x4557ec: bl              #0x82746c  ; AllocateArrayStub
    // 0x4557f0: r16 = "17"
    //     0x4557f0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x4557f4: ldr             x16, [x16, #0x358]
    // 0x4557f8: StoreField: r0->field_f = r16
    //     0x4557f8: stur            w16, [x0, #0xf]
    // 0x4557fc: r16 = "1"
    //     0x4557fc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x455800: ldr             x16, [x16, #0x9c8]
    // 0x455804: StoreField: r0->field_13 = r16
    //     0x455804: stur            w16, [x0, #0x13]
    // 0x455808: r1 = Null
    //     0x455808: mov             x1, NULL
    // 0x45580c: r2 = 4
    //     0x45580c: movz            x2, #0x4
    // 0x455810: r0 = AllocateArray()
    //     0x455810: bl              #0x82746c  ; AllocateArrayStub
    // 0x455814: r16 = "17"
    //     0x455814: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x455818: ldr             x16, [x16, #0x358]
    // 0x45581c: StoreField: r0->field_f = r16
    //     0x45581c: stur            w16, [x0, #0xf]
    // 0x455820: r16 = "2"
    //     0x455820: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x455824: ldr             x16, [x16, #0x2e0]
    // 0x455828: StoreField: r0->field_13 = r16
    //     0x455828: stur            w16, [x0, #0x13]
    // 0x45582c: r1 = Null
    //     0x45582c: mov             x1, NULL
    // 0x455830: r2 = 4
    //     0x455830: movz            x2, #0x4
    // 0x455834: r0 = AllocateArray()
    //     0x455834: bl              #0x82746c  ; AllocateArrayStub
    // 0x455838: r16 = "17"
    //     0x455838: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x45583c: ldr             x16, [x16, #0x358]
    // 0x455840: StoreField: r0->field_f = r16
    //     0x455840: stur            w16, [x0, #0xf]
    // 0x455844: r16 = "3"
    //     0x455844: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x455848: ldr             x16, [x16, #0x2f0]
    // 0x45584c: StoreField: r0->field_13 = r16
    //     0x45584c: stur            w16, [x0, #0x13]
    // 0x455850: r1 = "171"
    //     0x455850: add             x1, PP, #0xf, lsl #12  ; [pp+0xfff0] "171"
    //     0x455854: ldr             x1, [x1, #0xff0]
    // 0x455858: r2 = "173"
    //     0x455858: add             x2, PP, #0xf, lsl #12  ; [pp+0xfff8] "173"
    //     0x45585c: ldr             x2, [x2, #0xff8]
    // 0x455860: r3 = 2
    //     0x455860: movz            x3, #0x2
    // 0x455864: r5 = "172"
    //     0x455864: add             x5, PP, #0x10, lsl #12  ; [pp+0x10000] "172"
    //     0x455868: ldr             x5, [x5]
    // 0x45586c: r0 = readMostRecentValidSaveFile()
    //     0x45586c: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x455870: mov             x1, x0
    // 0x455874: r17 = -280
    //     0x455874: movn            x17, #0x117
    // 0x455878: str             x1, [fp, x17]
    // 0x45587c: r0 = Await()
    //     0x45587c: bl              #0x34b75c  ; AwaitStub
    // 0x455880: cmp             w0, NULL
    // 0x455884: b.eq            #0x455948
    // 0x455888: LoadField: r2 = r0->field_f
    //     0x455888: ldur            w2, [x0, #0xf]
    // 0x45588c: DecompressPointer r2
    //     0x45588c: add             x2, x2, HEAP, lsl #32
    // 0x455890: r17 = -280
    //     0x455890: movn            x17, #0x117
    // 0x455894: str             x2, [fp, x17]
    // 0x455898: r1 = <Chapter17Stat>
    //     0x455898: add             x1, PP, #0x10, lsl #12  ; [pp+0x10008] TypeArguments: <Chapter17Stat>
    //     0x45589c: ldr             x1, [x1, #8]
    // 0x4558a0: r0 = Chapter17GameState()
    //     0x4558a0: bl              #0x46ae70  ; AllocateChapter17GameStateStub -> Chapter17GameState (size=0x90)
    // 0x4558a4: mov             x1, x0
    // 0x4558a8: r17 = -280
    //     0x4558a8: movn            x17, #0x117
    // 0x4558ac: ldr             x2, [fp, x17]
    // 0x4558b0: r17 = -288
    //     0x4558b0: movn            x17, #0x11f
    // 0x4558b4: str             x0, [fp, x17]
    // 0x4558b8: r0 = Chapter17GameState()
    //     0x4558b8: bl              #0x46ace8  ; [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::Chapter17GameState
    // 0x4558bc: r17 = -280
    //     0x4558bc: movn            x17, #0x117
    // 0x4558c0: ldr             x1, [fp, x17]
    // 0x4558c4: r0 = LoadClassIdInstr(r1)
    //     0x4558c4: ldur            x0, [x1, #-1]
    //     0x4558c8: ubfx            x0, x0, #0xc, #0x14
    // 0x4558cc: r2 = 2
    //     0x4558cc: movz            x2, #0x2
    // 0x4558d0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4558d0: sub             lr, x0, #1, lsl #12
    //     0x4558d4: ldr             lr, [x21, lr, lsl #3]
    //     0x4558d8: blr             lr
    // 0x4558dc: mov             x3, x0
    // 0x4558e0: r2 = Null
    //     0x4558e0: mov             x2, NULL
    // 0x4558e4: r1 = Null
    //     0x4558e4: mov             x1, NULL
    // 0x4558e8: r17 = -280
    //     0x4558e8: movn            x17, #0x117
    // 0x4558ec: str             x3, [fp, x17]
    // 0x4558f0: branchIfSmi(r0, 0x455918)
    //     0x4558f0: tbz             w0, #0, #0x455918
    // 0x4558f4: r4 = LoadClassIdInstr(r0)
    //     0x4558f4: ldur            x4, [x0, #-1]
    //     0x4558f8: ubfx            x4, x4, #0xc, #0x14
    // 0x4558fc: sub             x4, x4, #0x3c
    // 0x455900: cmp             x4, #1
    // 0x455904: b.ls            #0x455918
    // 0x455908: r8 = int?
    //     0x455908: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x45590c: r3 = Null
    //     0x45590c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10010] Null
    //     0x455910: ldr             x3, [x3, #0x10]
    // 0x455914: r0 = int?()
    //     0x455914: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x455918: r1 = <Chapter17GameState, int?>
    //     0x455918: add             x1, PP, #0x10, lsl #12  ; [pp+0x10020] TypeArguments: <Chapter17GameState, int?>
    //     0x45591c: ldr             x1, [x1, #0x20]
    // 0x455920: r0 = Tuple2()
    //     0x455920: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x455924: mov             x1, x0
    // 0x455928: r17 = -288
    //     0x455928: movn            x17, #0x11f
    // 0x45592c: ldr             x0, [fp, x17]
    // 0x455930: StoreField: r1->field_b = r0
    //     0x455930: stur            w0, [x1, #0xb]
    // 0x455934: r17 = -280
    //     0x455934: movn            x17, #0x117
    // 0x455938: ldr             x0, [fp, x17]
    // 0x45593c: StoreField: r1->field_f = r0
    //     0x45593c: stur            w0, [x1, #0xf]
    // 0x455940: mov             x2, x1
    // 0x455944: b               #0x455988
    // 0x455948: r1 = <Chapter17Stat>
    //     0x455948: add             x1, PP, #0x10, lsl #12  ; [pp+0x10008] TypeArguments: <Chapter17Stat>
    //     0x45594c: ldr             x1, [x1, #8]
    // 0x455950: r0 = Chapter17GameState()
    //     0x455950: bl              #0x46ae70  ; AllocateChapter17GameStateStub -> Chapter17GameState (size=0x90)
    // 0x455954: mov             x1, x0
    // 0x455958: r2 = Null
    //     0x455958: mov             x2, NULL
    // 0x45595c: r17 = -280
    //     0x45595c: movn            x17, #0x117
    // 0x455960: str             x0, [fp, x17]
    // 0x455964: r0 = Chapter17GameState()
    //     0x455964: bl              #0x46ace8  ; [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::Chapter17GameState
    // 0x455968: r1 = <Chapter17GameState, int?>
    //     0x455968: add             x1, PP, #0x10, lsl #12  ; [pp+0x10020] TypeArguments: <Chapter17GameState, int?>
    //     0x45596c: ldr             x1, [x1, #0x20]
    // 0x455970: r0 = Tuple2()
    //     0x455970: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x455974: mov             x1, x0
    // 0x455978: r17 = -280
    //     0x455978: movn            x17, #0x117
    // 0x45597c: ldr             x0, [fp, x17]
    // 0x455980: StoreField: r1->field_b = r0
    //     0x455980: stur            w0, [x1, #0xb]
    // 0x455984: mov             x2, x1
    // 0x455988: r17 = -272
    //     0x455988: movn            x17, #0x10f
    // 0x45598c: ldr             x0, [fp, x17]
    // 0x455990: r17 = -280
    //     0x455990: movn            x17, #0x117
    // 0x455994: str             x2, [fp, x17]
    // 0x455998: LoadField: r1 = r0->field_b
    //     0x455998: ldur            w1, [x0, #0xb]
    // 0x45599c: LoadField: r3 = r0->field_f
    //     0x45599c: ldur            w3, [x0, #0xf]
    // 0x4559a0: DecompressPointer r3
    //     0x4559a0: add             x3, x3, HEAP, lsl #32
    // 0x4559a4: LoadField: r4 = r3->field_b
    //     0x4559a4: ldur            w4, [x3, #0xb]
    // 0x4559a8: r3 = LoadInt32Instr(r1)
    //     0x4559a8: sbfx            x3, x1, #1, #0x1f
    // 0x4559ac: r17 = -296
    //     0x4559ac: movn            x17, #0x127
    // 0x4559b0: str             x3, [fp, x17]
    // 0x4559b4: r1 = LoadInt32Instr(r4)
    //     0x4559b4: sbfx            x1, x4, #1, #0x1f
    // 0x4559b8: cmp             x3, x1
    // 0x4559bc: b.ne            #0x4559c8
    // 0x4559c0: mov             x1, x0
    // 0x4559c4: r0 = _growToNextCapacity()
    //     0x4559c4: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4559c8: r17 = -272
    //     0x4559c8: movn            x17, #0x10f
    // 0x4559cc: ldr             x2, [fp, x17]
    // 0x4559d0: r17 = -296
    //     0x4559d0: movn            x17, #0x127
    // 0x4559d4: ldr             x3, [fp, x17]
    // 0x4559d8: add             x0, x3, #1
    // 0x4559dc: lsl             x1, x0, #1
    // 0x4559e0: StoreField: r2->field_b = r1
    //     0x4559e0: stur            w1, [x2, #0xb]
    // 0x4559e4: LoadField: r1 = r2->field_f
    //     0x4559e4: ldur            w1, [x2, #0xf]
    // 0x4559e8: DecompressPointer r1
    //     0x4559e8: add             x1, x1, HEAP, lsl #32
    // 0x4559ec: r17 = -280
    //     0x4559ec: movn            x17, #0x117
    // 0x4559f0: ldr             x0, [fp, x17]
    // 0x4559f4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x4559f4: add             x25, x1, x3, lsl #2
    //     0x4559f8: add             x25, x25, #0xf
    //     0x4559fc: str             w0, [x25]
    //     0x455a00: tbz             w0, #0, #0x455a1c
    //     0x455a04: ldurb           w16, [x1, #-1]
    //     0x455a08: ldurb           w17, [x0, #-1]
    //     0x455a0c: and             x16, x17, x16, lsr #2
    //     0x455a10: tst             x16, HEAP, lsr #32
    //     0x455a14: b.eq            #0x455a1c
    //     0x455a18: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x455a1c: mov             x1, x2
    // 0x455a20: r0 = last()
    //     0x455a20: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455a24: LoadField: r2 = r0->field_b
    //     0x455a24: ldur            w2, [x0, #0xb]
    // 0x455a28: DecompressPointer r2
    //     0x455a28: add             x2, x2, HEAP, lsl #32
    // 0x455a2c: r17 = -272
    //     0x455a2c: movn            x17, #0x10f
    // 0x455a30: ldr             x1, [fp, x17]
    // 0x455a34: r17 = -280
    //     0x455a34: movn            x17, #0x117
    // 0x455a38: str             x2, [fp, x17]
    // 0x455a3c: r0 = last()
    //     0x455a3c: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455a40: LoadField: r1 = r0->field_f
    //     0x455a40: ldur            w1, [x0, #0xf]
    // 0x455a44: DecompressPointer r1
    //     0x455a44: add             x1, x1, HEAP, lsl #32
    // 0x455a48: r17 = -280
    //     0x455a48: movn            x17, #0x117
    // 0x455a4c: ldr             x2, [fp, x17]
    // 0x455a50: cmp             w2, NULL
    // 0x455a54: b.eq            #0x4561c8
    // 0x455a58: mov             x0, x1
    // 0x455a5c: StoreField: r2->field_b = r0
    //     0x455a5c: stur            w0, [x2, #0xb]
    //     0x455a60: tbz             w0, #0, #0x455a7c
    //     0x455a64: ldurb           w16, [x2, #-1]
    //     0x455a68: ldurb           w17, [x0, #-1]
    //     0x455a6c: and             x16, x17, x16, lsr #2
    //     0x455a70: tst             x16, HEAP, lsr #32
    //     0x455a74: b.eq            #0x455a7c
    //     0x455a78: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x455a7c: r0 = LoadStaticField(0xf60)
    //     0x455a7c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x455a80: ldr             x0, [x0, #0x1ec0]
    // 0x455a84: r17 = -272
    //     0x455a84: movn            x17, #0x10f
    // 0x455a88: ldr             x1, [fp, x17]
    // 0x455a8c: r17 = -280
    //     0x455a8c: movn            x17, #0x117
    // 0x455a90: str             x0, [fp, x17]
    // 0x455a94: r0 = last()
    //     0x455a94: bl              #0x51d724  ; [dart:core] _GrowableList::last
    // 0x455a98: LoadField: r3 = r0->field_b
    //     0x455a98: ldur            w3, [x0, #0xb]
    // 0x455a9c: DecompressPointer r3
    //     0x455a9c: add             x3, x3, HEAP, lsl #32
    // 0x455aa0: r17 = -280
    //     0x455aa0: movn            x17, #0x117
    // 0x455aa4: ldr             x1, [fp, x17]
    // 0x455aa8: r2 = 34
    //     0x455aa8: movz            x2, #0x22
    // 0x455aac: r0 = []=()
    //     0x455aac: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x455ab0: r4 = const [0, 0, 0, 0, null]
    //     0x455ab0: ldr             x4, [PP, #0x2958]  ; [pp+0x2958] List(5) [0, 0, 0, 0, Null]
    // 0x455ab4: r0 = loadCustomLevels()
    //     0x455ab4: bl              #0x45e7d4  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::loadCustomLevels
    // 0x455ab8: mov             x1, x0
    // 0x455abc: r17 = -272
    //     0x455abc: movn            x17, #0x10f
    // 0x455ac0: str             x1, [fp, x17]
    // 0x455ac4: r0 = Await()
    //     0x455ac4: bl              #0x34b75c  ; AwaitStub
    // 0x455ac8: r2 = Null
    //     0x455ac8: mov             x2, NULL
    // 0x455acc: r0 = Null
    //     0x455acc: mov             x0, NULL
    // 0x455ad0: b               #0x455b40
    // 0x455ad4: sub             SP, fp, #0x150
    // 0x455ad8: mov             x3, x0
    // 0x455adc: r17 = -272
    //     0x455adc: movn            x17, #0x10f
    // 0x455ae0: str             x0, [fp, x17]
    // 0x455ae4: mov             x0, x1
    // 0x455ae8: r17 = -280
    //     0x455ae8: movn            x17, #0x117
    // 0x455aec: str             x1, [fp, x17]
    // 0x455af0: r1 = Null
    //     0x455af0: mov             x1, NULL
    // 0x455af4: r2 = 4
    //     0x455af4: movz            x2, #0x4
    // 0x455af8: r0 = AllocateArray()
    //     0x455af8: bl              #0x82746c  ; AllocateArrayStub
    // 0x455afc: r16 = "Error loading custom levels: "
    //     0x455afc: add             x16, PP, #0x10, lsl #12  ; [pp+0x10028] "Error loading custom levels: "
    //     0x455b00: ldr             x16, [x16, #0x28]
    // 0x455b04: StoreField: r0->field_f = r16
    //     0x455b04: stur            w16, [x0, #0xf]
    // 0x455b08: r17 = -272
    //     0x455b08: movn            x17, #0x10f
    // 0x455b0c: ldr             x1, [fp, x17]
    // 0x455b10: StoreField: r0->field_13 = r1
    //     0x455b10: stur            w1, [x0, #0x13]
    // 0x455b14: str             x0, [SP]
    // 0x455b18: r0 = _interpolate()
    //     0x455b18: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x455b1c: mov             x1, x0
    // 0x455b20: r17 = -280
    //     0x455b20: movn            x17, #0x117
    // 0x455b24: ldr             x2, [fp, x17]
    // 0x455b28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x455b28: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x455b2c: r0 = crashlyticsRecordError()
    //     0x455b2c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x455b30: r17 = -280
    //     0x455b30: movn            x17, #0x117
    // 0x455b34: ldr             x2, [fp, x17]
    // 0x455b38: r17 = -272
    //     0x455b38: movn            x17, #0x10f
    // 0x455b3c: ldr             x0, [fp, x17]
    // 0x455b40: r17 = -272
    //     0x455b40: movn            x17, #0x10f
    // 0x455b44: str             x2, [fp, x17]
    // 0x455b48: r17 = -280
    //     0x455b48: movn            x17, #0x117
    // 0x455b4c: str             x0, [fp, x17]
    // 0x455b50: r1 = "LastOpenLevelEditor"
    //     0x455b50: add             x1, PP, #0x10, lsl #12  ; [pp+0x10030] "LastOpenLevelEditor"
    //     0x455b54: ldr             x1, [x1, #0x30]
    // 0x455b58: r0 = prefsGetString()
    //     0x455b58: bl              #0x45e6ec  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetString
    // 0x455b5c: r17 = -288
    //     0x455b5c: movn            x17, #0x11f
    // 0x455b60: str             x0, [fp, x17]
    // 0x455b64: cmp             w0, NULL
    // 0x455b68: b.eq            #0x455cc4
    // 0x455b6c: mov             x1, x0
    // 0x455b70: r0 = unauthenticatedName()
    //     0x455b70: bl              #0x370344  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::unauthenticatedName
    // 0x455b74: r17 = -288
    //     0x455b74: movn            x17, #0x11f
    // 0x455b78: ldr             x1, [fp, x17]
    // 0x455b7c: r17 = -304
    //     0x455b7c: movn            x17, #0x12f
    // 0x455b80: str             x0, [fp, x17]
    // 0x455b84: r0 = backupName()
    //     0x455b84: bl              #0x45e68c  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::backupName
    // 0x455b88: mov             x1, x0
    // 0x455b8c: r17 = -304
    //     0x455b8c: movn            x17, #0x12f
    // 0x455b90: ldr             x2, [fp, x17]
    // 0x455b94: r0 = readMostRecentValidSaveFileBasic()
    //     0x455b94: bl              #0x45c480  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFileBasic
    // 0x455b98: mov             x1, x0
    // 0x455b9c: r17 = -304
    //     0x455b9c: movn            x17, #0x12f
    // 0x455ba0: str             x1, [fp, x17]
    // 0x455ba4: r0 = Await()
    //     0x455ba4: bl              #0x34b75c  ; AwaitStub
    // 0x455ba8: r17 = -304
    //     0x455ba8: movn            x17, #0x12f
    // 0x455bac: str             x0, [fp, x17]
    // 0x455bb0: cmp             w0, NULL
    // 0x455bb4: b.eq            #0x455cac
    // 0x455bb8: r1 = <int>
    //     0x455bb8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x455bbc: r0 = LevelEditorGameState()
    //     0x455bbc: bl              #0x45c474  ; AllocateLevelEditorGameStateStub -> LevelEditorGameState (size=0x58)
    // 0x455bc0: mov             x3, x0
    // 0x455bc4: r17 = -304
    //     0x455bc4: movn            x17, #0x12f
    // 0x455bc8: ldr             x0, [fp, x17]
    // 0x455bcc: r2 = Null
    //     0x455bcc: mov             x2, NULL
    // 0x455bd0: r1 = Null
    //     0x455bd0: mov             x1, NULL
    // 0x455bd4: r17 = -312
    //     0x455bd4: movn            x17, #0x137
    // 0x455bd8: str             x3, [fp, x17]
    // 0x455bdc: r8 = Map?
    //     0x455bdc: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x455be0: ldr             x8, [x8, #0x38]
    // 0x455be4: r3 = Null
    //     0x455be4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10040] Null
    //     0x455be8: ldr             x3, [x3, #0x40]
    // 0x455bec: r0 = Map?()
    //     0x455bec: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x455bf0: r17 = -312
    //     0x455bf0: movn            x17, #0x137
    // 0x455bf4: ldr             x1, [fp, x17]
    // 0x455bf8: r17 = -288
    //     0x455bf8: movn            x17, #0x11f
    // 0x455bfc: ldr             x2, [fp, x17]
    // 0x455c00: r17 = -304
    //     0x455c00: movn            x17, #0x12f
    // 0x455c04: ldr             x5, [fp, x17]
    // 0x455c08: r3 = Instance_EditorCreationMethod
    //     0x455c08: add             x3, PP, #0x10, lsl #12  ; [pp+0x10050] Obj!EditorCreationMethod@85ed21
    //     0x455c0c: ldr             x3, [x3, #0x50]
    // 0x455c10: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x455c10: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x455c14: r0 = LevelEditorGameState()
    //     0x455c14: bl              #0x456e2c  ; [package:pretentious/data/Chapters/LevelEditorGameState.dart] LevelEditorGameState::LevelEditorGameState
    // 0x455c18: r17 = -312
    //     0x455c18: movn            x17, #0x137
    // 0x455c1c: ldr             x2, [fp, x17]
    // 0x455c20: StoreStaticField(0xf64, r2)
    //     0x455c20: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x455c24: str             x2, [x0, #0x1ec8]
    // 0x455c28: r17 = -272
    //     0x455c28: movn            x17, #0x10f
    // 0x455c2c: ldr             x1, [fp, x17]
    // 0x455c30: r17 = -280
    //     0x455c30: movn            x17, #0x117
    // 0x455c34: ldr             x0, [fp, x17]
    // 0x455c38: b               #0x455cbc
    // 0x455c3c: sub             SP, fp, #0x150
    // 0x455c40: mov             x3, x0
    // 0x455c44: r17 = -288
    //     0x455c44: movn            x17, #0x11f
    // 0x455c48: str             x0, [fp, x17]
    // 0x455c4c: mov             x0, x1
    // 0x455c50: r17 = -304
    //     0x455c50: movn            x17, #0x12f
    // 0x455c54: str             x1, [fp, x17]
    // 0x455c58: r1 = Null
    //     0x455c58: mov             x1, NULL
    // 0x455c5c: r2 = 4
    //     0x455c5c: movz            x2, #0x4
    // 0x455c60: r0 = AllocateArray()
    //     0x455c60: bl              #0x82746c  ; AllocateArrayStub
    // 0x455c64: r16 = "Encountered error when loading level editor: "
    //     0x455c64: add             x16, PP, #0x10, lsl #12  ; [pp+0x10058] "Encountered error when loading level editor: "
    //     0x455c68: ldr             x16, [x16, #0x58]
    // 0x455c6c: StoreField: r0->field_f = r16
    //     0x455c6c: stur            w16, [x0, #0xf]
    // 0x455c70: r17 = -288
    //     0x455c70: movn            x17, #0x11f
    // 0x455c74: ldr             x1, [fp, x17]
    // 0x455c78: StoreField: r0->field_13 = r1
    //     0x455c78: stur            w1, [x0, #0x13]
    // 0x455c7c: str             x0, [SP]
    // 0x455c80: r0 = _interpolate()
    //     0x455c80: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x455c84: mov             x1, x0
    // 0x455c88: r17 = -304
    //     0x455c88: movn            x17, #0x12f
    // 0x455c8c: ldr             x2, [fp, x17]
    // 0x455c90: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x455c90: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x455c94: r0 = crashlyticsRecordError()
    //     0x455c94: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x455c98: r17 = -304
    //     0x455c98: movn            x17, #0x12f
    // 0x455c9c: ldr             x1, [fp, x17]
    // 0x455ca0: r17 = -288
    //     0x455ca0: movn            x17, #0x11f
    // 0x455ca4: ldr             x0, [fp, x17]
    // 0x455ca8: b               #0x455cbc
    // 0x455cac: r17 = -272
    //     0x455cac: movn            x17, #0x10f
    // 0x455cb0: ldr             x1, [fp, x17]
    // 0x455cb4: r17 = -280
    //     0x455cb4: movn            x17, #0x117
    // 0x455cb8: ldr             x0, [fp, x17]
    // 0x455cbc: mov             x3, x1
    // 0x455cc0: b               #0x455cd4
    // 0x455cc4: r17 = -272
    //     0x455cc4: movn            x17, #0x10f
    // 0x455cc8: ldr             x3, [fp, x17]
    // 0x455ccc: r17 = -280
    //     0x455ccc: movn            x17, #0x117
    // 0x455cd0: ldr             x0, [fp, x17]
    // 0x455cd4: r17 = -272
    //     0x455cd4: movn            x17, #0x10f
    // 0x455cd8: str             x3, [fp, x17]
    // 0x455cdc: r17 = -280
    //     0x455cdc: movn            x17, #0x117
    // 0x455ce0: str             x0, [fp, x17]
    // 0x455ce4: r1 = Null
    //     0x455ce4: mov             x1, NULL
    // 0x455ce8: r2 = 4
    //     0x455ce8: movz            x2, #0x4
    // 0x455cec: r0 = AllocateArray()
    //     0x455cec: bl              #0x82746c  ; AllocateArrayStub
    // 0x455cf0: r16 = "Editor"
    //     0x455cf0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10060] "Editor"
    //     0x455cf4: ldr             x16, [x16, #0x60]
    // 0x455cf8: StoreField: r0->field_f = r16
    //     0x455cf8: stur            w16, [x0, #0xf]
    // 0x455cfc: r16 = "2"
    //     0x455cfc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x455d00: ldr             x16, [x16, #0x2e0]
    // 0x455d04: StoreField: r0->field_13 = r16
    //     0x455d04: stur            w16, [x0, #0x13]
    // 0x455d08: r1 = Null
    //     0x455d08: mov             x1, NULL
    // 0x455d0c: r2 = 4
    //     0x455d0c: movz            x2, #0x4
    // 0x455d10: r0 = AllocateArray()
    //     0x455d10: bl              #0x82746c  ; AllocateArrayStub
    // 0x455d14: r16 = "Editor"
    //     0x455d14: add             x16, PP, #0x10, lsl #12  ; [pp+0x10060] "Editor"
    //     0x455d18: ldr             x16, [x16, #0x60]
    // 0x455d1c: StoreField: r0->field_f = r16
    //     0x455d1c: stur            w16, [x0, #0xf]
    // 0x455d20: r16 = "3"
    //     0x455d20: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x455d24: ldr             x16, [x16, #0x2f0]
    // 0x455d28: StoreField: r0->field_13 = r16
    //     0x455d28: stur            w16, [x0, #0x13]
    // 0x455d2c: r1 = "Editor3"
    //     0x455d2c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10068] "Editor3"
    //     0x455d30: ldr             x1, [x1, #0x68]
    // 0x455d34: r2 = "Editor2"
    //     0x455d34: add             x2, PP, #0x10, lsl #12  ; [pp+0x10070] "Editor2"
    //     0x455d38: ldr             x2, [x2, #0x70]
    // 0x455d3c: r0 = readMostRecentValidSaveFileBasic()
    //     0x455d3c: bl              #0x45c480  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFileBasic
    // 0x455d40: mov             x1, x0
    // 0x455d44: r17 = -288
    //     0x455d44: movn            x17, #0x11f
    // 0x455d48: str             x1, [fp, x17]
    // 0x455d4c: r0 = Await()
    //     0x455d4c: bl              #0x34b75c  ; AwaitStub
    // 0x455d50: r17 = -288
    //     0x455d50: movn            x17, #0x11f
    // 0x455d54: str             x0, [fp, x17]
    // 0x455d58: cmp             w0, NULL
    // 0x455d5c: b.eq            #0x4560c4
    // 0x455d60: r1 = <int>
    //     0x455d60: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x455d64: r0 = LevelEditorGameState()
    //     0x455d64: bl              #0x45c474  ; AllocateLevelEditorGameStateStub -> LevelEditorGameState (size=0x58)
    // 0x455d68: mov             x3, x0
    // 0x455d6c: r17 = -288
    //     0x455d6c: movn            x17, #0x11f
    // 0x455d70: ldr             x0, [fp, x17]
    // 0x455d74: r2 = Null
    //     0x455d74: mov             x2, NULL
    // 0x455d78: r1 = Null
    //     0x455d78: mov             x1, NULL
    // 0x455d7c: r17 = -304
    //     0x455d7c: movn            x17, #0x12f
    // 0x455d80: str             x3, [fp, x17]
    // 0x455d84: r8 = Map?
    //     0x455d84: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x455d88: ldr             x8, [x8, #0x38]
    // 0x455d8c: r3 = Null
    //     0x455d8c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10078] Null
    //     0x455d90: ldr             x3, [x3, #0x78]
    // 0x455d94: r0 = Map?()
    //     0x455d94: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x455d98: r17 = -304
    //     0x455d98: movn            x17, #0x12f
    // 0x455d9c: ldr             x1, [fp, x17]
    // 0x455da0: r17 = -288
    //     0x455da0: movn            x17, #0x11f
    // 0x455da4: ldr             x5, [fp, x17]
    // 0x455da8: r2 = "Editor"
    //     0x455da8: add             x2, PP, #0x10, lsl #12  ; [pp+0x10060] "Editor"
    //     0x455dac: ldr             x2, [x2, #0x60]
    // 0x455db0: r3 = Instance_EditorCreationMethod
    //     0x455db0: add             x3, PP, #0x10, lsl #12  ; [pp+0x10050] Obj!EditorCreationMethod@85ed21
    //     0x455db4: ldr             x3, [x3, #0x50]
    // 0x455db8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x455db8: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x455dbc: r0 = LevelEditorGameState()
    //     0x455dbc: bl              #0x456e2c  ; [package:pretentious/data/Chapters/LevelEditorGameState.dart] LevelEditorGameState::LevelEditorGameState
    // 0x455dc0: r1 = Null
    //     0x455dc0: mov             x1, NULL
    // 0x455dc4: r2 = 6
    //     0x455dc4: movz            x2, #0x6
    // 0x455dc8: r0 = AllocateArray()
    //     0x455dc8: bl              #0x82746c  ; AllocateArrayStub
    // 0x455dcc: r17 = -312
    //     0x455dcc: movn            x17, #0x137
    // 0x455dd0: str             x0, [fp, x17]
    // 0x455dd4: r0 = getApplicationDocumentsDirectory()
    //     0x455dd4: bl              #0x36ffd4  ; [package:path_provider/path_provider.dart] ::getApplicationDocumentsDirectory
    // 0x455dd8: mov             x1, x0
    // 0x455ddc: r17 = -320
    //     0x455ddc: movn            x17, #0x13f
    // 0x455de0: str             x1, [fp, x17]
    // 0x455de4: r0 = Await()
    //     0x455de4: bl              #0x34b75c  ; AwaitStub
    // 0x455de8: LoadField: r1 = r0->field_7
    //     0x455de8: ldur            w1, [x0, #7]
    // 0x455dec: DecompressPointer r1
    //     0x455dec: add             x1, x1, HEAP, lsl #32
    // 0x455df0: mov             x0, x1
    // 0x455df4: r17 = -312
    //     0x455df4: movn            x17, #0x137
    // 0x455df8: ldr             x1, [fp, x17]
    // 0x455dfc: ArrayStore: r1[0] = r0  ; List_4
    //     0x455dfc: add             x25, x1, #0xf
    //     0x455e00: str             w0, [x25]
    //     0x455e04: tbz             w0, #0, #0x455e20
    //     0x455e08: ldurb           w16, [x1, #-1]
    //     0x455e0c: ldurb           w17, [x0, #-1]
    //     0x455e10: and             x16, x17, x16, lsr #2
    //     0x455e14: tst             x16, HEAP, lsr #32
    //     0x455e18: b.eq            #0x455e20
    //     0x455e1c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x455e20: r17 = -312
    //     0x455e20: movn            x17, #0x137
    // 0x455e24: ldr             x0, [fp, x17]
    // 0x455e28: r16 = "/"
    //     0x455e28: ldr             x16, [PP, #0xe58]  ; [pp+0xe58] "/"
    // 0x455e2c: StoreField: r0->field_13 = r16
    //     0x455e2c: stur            w16, [x0, #0x13]
    // 0x455e30: r16 = "LevelEditors"
    //     0x455e30: add             x16, PP, #0x10, lsl #12  ; [pp+0x10088] "LevelEditors"
    //     0x455e34: ldr             x16, [x16, #0x88]
    // 0x455e38: ArrayStore: r0[0] = r16  ; List_4
    //     0x455e38: stur            w16, [x0, #0x17]
    // 0x455e3c: str             x0, [SP]
    // 0x455e40: r0 = _interpolate()
    //     0x455e40: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x455e44: r17 = -312
    //     0x455e44: movn            x17, #0x137
    // 0x455e48: str             x0, [fp, x17]
    // 0x455e4c: r0 = current()
    //     0x455e4c: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x455e50: r0 = _Directory()
    //     0x455e50: bl              #0x3422d0  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0x455e54: mov             x2, x0
    // 0x455e58: r17 = -312
    //     0x455e58: movn            x17, #0x137
    // 0x455e5c: ldr             x0, [fp, x17]
    // 0x455e60: r17 = -320
    //     0x455e60: movn            x17, #0x13f
    // 0x455e64: str             x2, [fp, x17]
    // 0x455e68: StoreField: r2->field_7 = r0
    //     0x455e68: stur            w0, [x2, #7]
    // 0x455e6c: mov             x1, x0
    // 0x455e70: r0 = _toUtf8Array()
    //     0x455e70: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x455e74: r17 = -320
    //     0x455e74: movn            x17, #0x13f
    // 0x455e78: ldr             x2, [fp, x17]
    // 0x455e7c: StoreField: r2->field_b = r0
    //     0x455e7c: stur            w0, [x2, #0xb]
    //     0x455e80: ldurb           w16, [x2, #-1]
    //     0x455e84: ldurb           w17, [x0, #-1]
    //     0x455e88: and             x16, x17, x16, lsr #2
    //     0x455e8c: tst             x16, HEAP, lsr #32
    //     0x455e90: b.eq            #0x455e98
    //     0x455e94: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x455e98: mov             x1, x2
    // 0x455e9c: r0 = existsSync()
    //     0x455e9c: bl              #0x36fe80  ; [dart:io] _Directory::existsSync
    // 0x455ea0: tbz             w0, #4, #0x455eb4
    // 0x455ea4: r17 = -320
    //     0x455ea4: movn            x17, #0x13f
    // 0x455ea8: ldr             x1, [fp, x17]
    // 0x455eac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x455eac: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x455eb0: r0 = createSync()
    //     0x455eb0: bl              #0x36fac4  ; [dart:io] _Directory::createSync
    // 0x455eb4: r17 = -304
    //     0x455eb4: movn            x17, #0x12f
    // 0x455eb8: ldr             x3, [fp, x17]
    // 0x455ebc: r17 = -312
    //     0x455ebc: movn            x17, #0x137
    // 0x455ec0: ldr             x0, [fp, x17]
    // 0x455ec4: LoadField: r1 = r3->field_37
    //     0x455ec4: ldur            w1, [x3, #0x37]
    // 0x455ec8: DecompressPointer r1
    //     0x455ec8: add             x1, x1, HEAP, lsl #32
    // 0x455ecc: LoadField: r4 = r1->field_7
    //     0x455ecc: ldur            w4, [x1, #7]
    // 0x455ed0: DecompressPointer r4
    //     0x455ed0: add             x4, x4, HEAP, lsl #32
    // 0x455ed4: r17 = -288
    //     0x455ed4: movn            x17, #0x11f
    // 0x455ed8: str             x4, [fp, x17]
    // 0x455edc: r1 = Null
    //     0x455edc: mov             x1, NULL
    // 0x455ee0: r2 = 4
    //     0x455ee0: movz            x2, #0x4
    // 0x455ee4: r0 = AllocateArray()
    //     0x455ee4: bl              #0x82746c  ; AllocateArrayStub
    // 0x455ee8: r16 = "CachedNames_"
    //     0x455ee8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10090] "CachedNames_"
    //     0x455eec: ldr             x16, [x16, #0x90]
    // 0x455ef0: StoreField: r0->field_f = r16
    //     0x455ef0: stur            w16, [x0, #0xf]
    // 0x455ef4: r17 = -288
    //     0x455ef4: movn            x17, #0x11f
    // 0x455ef8: ldr             x1, [fp, x17]
    // 0x455efc: StoreField: r0->field_13 = r1
    //     0x455efc: stur            w1, [x0, #0x13]
    // 0x455f00: str             x0, [SP]
    // 0x455f04: r0 = _interpolate()
    //     0x455f04: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x455f08: mov             x1, x0
    // 0x455f0c: r17 = -304
    //     0x455f0c: movn            x17, #0x12f
    // 0x455f10: ldr             x0, [fp, x17]
    // 0x455f14: LoadField: r2 = r0->field_37
    //     0x455f14: ldur            w2, [x0, #0x37]
    // 0x455f18: DecompressPointer r2
    //     0x455f18: add             x2, x2, HEAP, lsl #32
    // 0x455f1c: LoadField: r3 = r2->field_f
    //     0x455f1c: ldur            w3, [x2, #0xf]
    // 0x455f20: DecompressPointer r3
    //     0x455f20: add             x3, x3, HEAP, lsl #32
    // 0x455f24: mov             x2, x3
    // 0x455f28: r0 = prefsSetString()
    //     0x455f28: bl              #0x456dd0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetString
    // 0x455f2c: r1 = Null
    //     0x455f2c: mov             x1, NULL
    // 0x455f30: r2 = 6
    //     0x455f30: movz            x2, #0x6
    // 0x455f34: r0 = AllocateArray()
    //     0x455f34: bl              #0x82746c  ; AllocateArrayStub
    // 0x455f38: mov             x1, x0
    // 0x455f3c: r17 = -312
    //     0x455f3c: movn            x17, #0x137
    // 0x455f40: ldr             x0, [fp, x17]
    // 0x455f44: StoreField: r1->field_f = r0
    //     0x455f44: stur            w0, [x1, #0xf]
    // 0x455f48: r16 = "/"
    //     0x455f48: ldr             x16, [PP, #0xe58]  ; [pp+0xe58] "/"
    // 0x455f4c: StoreField: r1->field_13 = r16
    //     0x455f4c: stur            w16, [x1, #0x13]
    // 0x455f50: r17 = -288
    //     0x455f50: movn            x17, #0x11f
    // 0x455f54: ldr             x0, [fp, x17]
    // 0x455f58: ArrayStore: r1[0] = r0  ; List_4
    //     0x455f58: stur            w0, [x1, #0x17]
    // 0x455f5c: str             x1, [SP]
    // 0x455f60: r0 = _interpolate()
    //     0x455f60: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x455f64: r17 = -312
    //     0x455f64: movn            x17, #0x137
    // 0x455f68: str             x0, [fp, x17]
    // 0x455f6c: r0 = current()
    //     0x455f6c: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x455f70: r0 = _Directory()
    //     0x455f70: bl              #0x3422d0  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0x455f74: r17 = -312
    //     0x455f74: movn            x17, #0x137
    // 0x455f78: ldr             x1, [fp, x17]
    // 0x455f7c: r17 = -328
    //     0x455f7c: movn            x17, #0x147
    // 0x455f80: str             x0, [fp, x17]
    // 0x455f84: StoreField: r0->field_7 = r1
    //     0x455f84: stur            w1, [x0, #7]
    // 0x455f88: r0 = _toUtf8Array()
    //     0x455f88: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x455f8c: r17 = -328
    //     0x455f8c: movn            x17, #0x147
    // 0x455f90: ldr             x2, [fp, x17]
    // 0x455f94: StoreField: r2->field_b = r0
    //     0x455f94: stur            w0, [x2, #0xb]
    //     0x455f98: ldurb           w16, [x2, #-1]
    //     0x455f9c: ldurb           w17, [x0, #-1]
    //     0x455fa0: and             x16, x17, x16, lsr #2
    //     0x455fa4: tst             x16, HEAP, lsr #32
    //     0x455fa8: b.eq            #0x455fb0
    //     0x455fac: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x455fb0: mov             x1, x2
    // 0x455fb4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x455fb4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x455fb8: r0 = createSync()
    //     0x455fb8: bl              #0x36fac4  ; [dart:io] _Directory::createSync
    // 0x455fbc: r1 = Null
    //     0x455fbc: mov             x1, NULL
    // 0x455fc0: r2 = 8
    //     0x455fc0: movz            x2, #0x8
    // 0x455fc4: r0 = AllocateArray()
    //     0x455fc4: bl              #0x82746c  ; AllocateArrayStub
    // 0x455fc8: r16 = "LevelEditors"
    //     0x455fc8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10088] "LevelEditors"
    //     0x455fcc: ldr             x16, [x16, #0x88]
    // 0x455fd0: StoreField: r0->field_f = r16
    //     0x455fd0: stur            w16, [x0, #0xf]
    // 0x455fd4: r16 = "/"
    //     0x455fd4: ldr             x16, [PP, #0xe58]  ; [pp+0xe58] "/"
    // 0x455fd8: StoreField: r0->field_13 = r16
    //     0x455fd8: stur            w16, [x0, #0x13]
    // 0x455fdc: r17 = -288
    //     0x455fdc: movn            x17, #0x11f
    // 0x455fe0: ldr             x1, [fp, x17]
    // 0x455fe4: ArrayStore: r0[0] = r1  ; List_4
    //     0x455fe4: stur            w1, [x0, #0x17]
    // 0x455fe8: r16 = "/data"
    //     0x455fe8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10098] "/data"
    //     0x455fec: ldr             x16, [x16, #0x98]
    // 0x455ff0: StoreField: r0->field_1b = r16
    //     0x455ff0: stur            w16, [x0, #0x1b]
    // 0x455ff4: str             x0, [SP]
    // 0x455ff8: r0 = _interpolate()
    //     0x455ff8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x455ffc: r17 = -304
    //     0x455ffc: movn            x17, #0x12f
    // 0x456000: ldr             x2, [fp, x17]
    // 0x456004: StoreField: r2->field_53 = r0
    //     0x456004: stur            w0, [x2, #0x53]
    //     0x456008: ldurb           w16, [x2, #-1]
    //     0x45600c: ldurb           w17, [x0, #-1]
    //     0x456010: and             x16, x17, x16, lsr #2
    //     0x456014: tst             x16, HEAP, lsr #32
    //     0x456018: b.eq            #0x456020
    //     0x45601c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x456020: mov             x1, x2
    // 0x456024: r0 = saveImmediately()
    //     0x456024: bl              #0x353020  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveImmediately
    // 0x456028: mov             x1, x0
    // 0x45602c: r17 = -312
    //     0x45602c: movn            x17, #0x137
    // 0x456030: str             x1, [fp, x17]
    // 0x456034: r0 = Await()
    //     0x456034: bl              #0x34b75c  ; AwaitStub
    // 0x456038: r17 = -304
    //     0x456038: movn            x17, #0x12f
    // 0x45603c: ldr             x0, [fp, x17]
    // 0x456040: r1 = "Editor"
    //     0x456040: add             x1, PP, #0x10, lsl #12  ; [pp+0x10060] "Editor"
    //     0x456044: ldr             x1, [x1, #0x60]
    // 0x456048: StoreField: r0->field_53 = r1
    //     0x456048: stur            w1, [x0, #0x53]
    // 0x45604c: mov             x1, x0
    // 0x456050: r0 = deleteSaveFiles()
    //     0x456050: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x456054: mov             x1, x0
    // 0x456058: r17 = -312
    //     0x456058: movn            x17, #0x137
    // 0x45605c: str             x1, [fp, x17]
    // 0x456060: r0 = Await()
    //     0x456060: bl              #0x34b75c  ; AwaitStub
    // 0x456064: b               #0x4560c4
    // 0x456068: sub             SP, fp, #0x150
    // 0x45606c: mov             x3, x0
    // 0x456070: r17 = -272
    //     0x456070: movn            x17, #0x10f
    // 0x456074: str             x0, [fp, x17]
    // 0x456078: mov             x0, x1
    // 0x45607c: r17 = -280
    //     0x45607c: movn            x17, #0x117
    // 0x456080: str             x1, [fp, x17]
    // 0x456084: r1 = Null
    //     0x456084: mov             x1, NULL
    // 0x456088: r2 = 4
    //     0x456088: movz            x2, #0x4
    // 0x45608c: r0 = AllocateArray()
    //     0x45608c: bl              #0x82746c  ; AllocateArrayStub
    // 0x456090: r16 = "Encountered error when loading level editor: "
    //     0x456090: add             x16, PP, #0x10, lsl #12  ; [pp+0x10058] "Encountered error when loading level editor: "
    //     0x456094: ldr             x16, [x16, #0x58]
    // 0x456098: StoreField: r0->field_f = r16
    //     0x456098: stur            w16, [x0, #0xf]
    // 0x45609c: r17 = -272
    //     0x45609c: movn            x17, #0x10f
    // 0x4560a0: ldr             x1, [fp, x17]
    // 0x4560a4: StoreField: r0->field_13 = r1
    //     0x4560a4: stur            w1, [x0, #0x13]
    // 0x4560a8: str             x0, [SP]
    // 0x4560ac: r0 = _interpolate()
    //     0x4560ac: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4560b0: mov             x1, x0
    // 0x4560b4: r17 = -280
    //     0x4560b4: movn            x17, #0x117
    // 0x4560b8: ldr             x2, [fp, x17]
    // 0x4560bc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4560bc: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4560c0: r0 = crashlyticsRecordError()
    //     0x4560c0: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x4560c4: r0 = LoadStaticField(0xf60)
    //     0x4560c4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4560c8: ldr             x0, [x0, #0x1ec0]
    // 0x4560cc: mov             x1, x0
    // 0x4560d0: r17 = -272
    //     0x4560d0: movn            x17, #0x10f
    // 0x4560d4: str             x0, [fp, x17]
    // 0x4560d8: r2 = 2
    //     0x4560d8: movz            x2, #0x2
    // 0x4560dc: r0 = _getValueOrData()
    //     0x4560dc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4560e0: mov             x1, x0
    // 0x4560e4: r17 = -272
    //     0x4560e4: movn            x17, #0x10f
    // 0x4560e8: ldr             x0, [fp, x17]
    // 0x4560ec: LoadField: r2 = r0->field_f
    //     0x4560ec: ldur            w2, [x0, #0xf]
    // 0x4560f0: DecompressPointer r2
    //     0x4560f0: add             x2, x2, HEAP, lsl #32
    // 0x4560f4: cmp             w2, w1
    // 0x4560f8: b.ne            #0x456104
    // 0x4560fc: r3 = Null
    //     0x4560fc: mov             x3, NULL
    // 0x456100: b               #0x456108
    // 0x456104: mov             x3, x1
    // 0x456108: r17 = -272
    //     0x456108: movn            x17, #0x10f
    // 0x45610c: str             x3, [fp, x17]
    // 0x456110: cmp             w3, NULL
    // 0x456114: b.eq            #0x4561cc
    // 0x456118: r0 = LoadStaticField(0xa6c)
    //     0x456118: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45611c: ldr             x0, [x0, #0x14d8]
    // 0x456120: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x456124: cmp             w0, w16
    // 0x456128: b.eq            #0x4561d0
    // 0x45612c: mov             x1, x0
    // 0x456130: r2 = "DisplayProgress"
    //     0x456130: add             x2, PP, #0x10, lsl #12  ; [pp+0x100a0] "DisplayProgress"
    //     0x456134: ldr             x2, [x2, #0xa0]
    // 0x456138: r0 = getInt()
    //     0x456138: bl              #0x36dcc8  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInt
    // 0x45613c: cmp             w0, NULL
    // 0x456140: b.ne            #0x45614c
    // 0x456144: r2 = 0
    //     0x456144: movz            x2, #0
    // 0x456148: b               #0x45615c
    // 0x45614c: r1 = LoadInt32Instr(r0)
    //     0x45614c: sbfx            x1, x0, #1, #0x1f
    //     0x456150: tbz             w0, #0, #0x456158
    //     0x456154: ldur            x1, [x0, #7]
    // 0x456158: mov             x2, x1
    // 0x45615c: r17 = -272
    //     0x45615c: movn            x17, #0x10f
    // 0x456160: ldr             x1, [fp, x17]
    // 0x456164: r0 = _setCurrentDisplayProgress()
    //     0x456164: bl              #0x4561dc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::_setCurrentDisplayProgress
    // 0x456168: r0 = Null
    //     0x456168: mov             x0, NULL
    // 0x45616c: r0 = ReturnAsyncNotFuture()
    //     0x45616c: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x456170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x456170: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x456174: b               #0x452914
    // 0x456178: r0 = NullErrorSharedWithoutFPURegs()
    //     0x456178: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x45617c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x45617c: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x456180: r0 = NullErrorSharedWithoutFPURegs()
    //     0x456180: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x456184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x456184: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x456188: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x456188: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x45618c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x45618c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x456190: r0 = NullErrorSharedWithoutFPURegs()
    //     0x456190: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x456194: r0 = NullErrorSharedWithoutFPURegs()
    //     0x456194: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x456198: r0 = NullErrorSharedWithoutFPURegs()
    //     0x456198: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x45619c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x45619c: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561a0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561a0: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561a4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561a4: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561a8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561a8: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561ac: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561ac: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561b0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561b0: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561b4: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561b8: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561bc: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561c0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561c0: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561c4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561c4: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561c8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4561c8: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4561cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4561cc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4561d0: r9 = prefs
    //     0x4561d0: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x4561d4: ldr             x9, [x9, #0xc00]
    // 0x4561d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x4561d8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ backupName(/* No info */) {
    // ** addr: 0x45e68c, size: 0x60
    // 0x45e68c: EnterFrame
    //     0x45e68c: stp             fp, lr, [SP, #-0x10]!
    //     0x45e690: mov             fp, SP
    // 0x45e694: AllocStack(0x10)
    //     0x45e694: sub             SP, SP, #0x10
    // 0x45e698: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x45e698: mov             x0, x1
    //     0x45e69c: stur            x1, [fp, #-8]
    // 0x45e6a0: CheckStackOverflow
    //     0x45e6a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45e6a4: cmp             SP, x16
    //     0x45e6a8: b.ls            #0x45e6e4
    // 0x45e6ac: r1 = Null
    //     0x45e6ac: mov             x1, NULL
    // 0x45e6b0: r2 = 4
    //     0x45e6b0: movz            x2, #0x4
    // 0x45e6b4: r0 = AllocateArray()
    //     0x45e6b4: bl              #0x82746c  ; AllocateArrayStub
    // 0x45e6b8: mov             x1, x0
    // 0x45e6bc: ldur            x0, [fp, #-8]
    // 0x45e6c0: StoreField: r1->field_f = r0
    //     0x45e6c0: stur            w0, [x1, #0xf]
    // 0x45e6c4: r16 = "3"
    //     0x45e6c4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x45e6c8: ldr             x16, [x16, #0x2f0]
    // 0x45e6cc: StoreField: r1->field_13 = r16
    //     0x45e6cc: stur            w16, [x1, #0x13]
    // 0x45e6d0: str             x1, [SP]
    // 0x45e6d4: r0 = _interpolate()
    //     0x45e6d4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x45e6d8: LeaveFrame
    //     0x45e6d8: mov             SP, fp
    //     0x45e6dc: ldp             fp, lr, [SP], #0x10
    // 0x45e6e0: ret
    //     0x45e6e0: ret             
    // 0x45e6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x45e6e4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x45e6e8: b               #0x45e6ac
  }
  static _ loadCustomLevels(/* No info */) async {
    // ** addr: 0x45e7d4, size: 0xb10
    // 0x45e7d4: EnterFrame
    //     0x45e7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x45e7d8: mov             fp, SP
    // 0x45e7dc: AllocStack(0x150)
    //     0x45e7dc: sub             SP, SP, #0x150
    // 0x45e7e0: SetupParameters({dynamic onlyLoadThisLevel = Null /* r1, fp-0xb8 */})
    //     0x45e7e0: stur            NULL, [fp, #-8]
    //     0x45e7e4: ldur            w0, [x4, #0x13]
    //     0x45e7e8: ldur            w1, [x4, #0x1f]
    //     0x45e7ec: add             x1, x1, HEAP, lsl #32
    //     0x45e7f0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10a18] "onlyLoadThisLevel"
    //     0x45e7f4: ldr             x16, [x16, #0xa18]
    //     0x45e7f8: cmp             w1, w16
    //     0x45e7fc: b.ne            #0x45e81c
    //     0x45e800: ldur            w1, [x4, #0x23]
    //     0x45e804: add             x1, x1, HEAP, lsl #32
    //     0x45e808: sub             w2, w0, w1
    //     0x45e80c: add             x0, fp, w2, sxtw #2
    //     0x45e810: ldr             x0, [x0, #8]
    //     0x45e814: mov             x1, x0
    //     0x45e818: b               #0x45e820
    //     0x45e81c: mov             x1, NULL
    //     0x45e820: stur            x1, [fp, #-0xb8]
    // 0x45e824: CheckStackOverflow
    //     0x45e824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45e828: cmp             SP, x16
    //     0x45e82c: b.ls            #0x45f2c4
    // 0x45e830: InitAsync() -> Future<void?>
    //     0x45e830: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x45e834: bl              #0x34b9a0  ; InitAsyncStub
    // 0x45e838: r0 = customLevelsDirectory()
    //     0x45e838: bl              #0x4643d8  ; [package:pretentious/main.dart] ::customLevelsDirectory
    // 0x45e83c: stur            x0, [fp, #-0xc0]
    // 0x45e840: r0 = current()
    //     0x45e840: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x45e844: r0 = _Directory()
    //     0x45e844: bl              #0x3422d0  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0x45e848: ldur            x1, [fp, #-0xc0]
    // 0x45e84c: stur            x0, [fp, #-0xc8]
    // 0x45e850: StoreField: r0->field_7 = r1
    //     0x45e850: stur            w1, [x0, #7]
    // 0x45e854: r0 = _toUtf8Array()
    //     0x45e854: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x45e858: ldur            x2, [fp, #-0xc8]
    // 0x45e85c: StoreField: r2->field_b = r0
    //     0x45e85c: stur            w0, [x2, #0xb]
    //     0x45e860: ldurb           w16, [x2, #-1]
    //     0x45e864: ldurb           w17, [x0, #-1]
    //     0x45e868: and             x16, x17, x16, lsr #2
    //     0x45e86c: tst             x16, HEAP, lsr #32
    //     0x45e870: b.eq            #0x45e878
    //     0x45e874: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45e878: mov             x1, x2
    // 0x45e87c: r0 = existsSync()
    //     0x45e87c: bl              #0x36fe80  ; [dart:io] _Directory::existsSync
    // 0x45e880: tbz             w0, #4, #0x45e8a8
    // 0x45e884: r16 = true
    //     0x45e884: add             x16, NULL, #0x20  ; true
    // 0x45e888: str             x16, [SP]
    // 0x45e88c: ldur            x1, [fp, #-0xc8]
    // 0x45e890: r4 = const [0, 0x2, 0x1, 0x1, recursive, 0x1, null]
    //     0x45e890: add             x4, PP, #0xe, lsl #12  ; [pp+0xee08] List(7) [0, 0x2, 0x1, 0x1, "recursive", 0x1, Null]
    //     0x45e894: ldr             x4, [x4, #0xe08]
    // 0x45e898: r0 = create()
    //     0x45e898: bl              #0x463f80  ; [dart:io] _Directory::create
    // 0x45e89c: mov             x1, x0
    // 0x45e8a0: stur            x1, [fp, #-0xc0]
    // 0x45e8a4: r0 = Await()
    //     0x45e8a4: bl              #0x34b75c  ; AwaitStub
    // 0x45e8a8: ldur            x1, [fp, #-0xc8]
    // 0x45e8ac: r0 = list()
    //     0x45e8ac: bl              #0x462a74  ; [dart:io] _Directory::list
    // 0x45e8b0: mov             x1, x0
    // 0x45e8b4: r0 = toList()
    //     0x45e8b4: bl              #0x4627bc  ; [dart:async] Stream::toList
    // 0x45e8b8: mov             x1, x0
    // 0x45e8bc: stur            x1, [fp, #-0xc0]
    // 0x45e8c0: r0 = Await()
    //     0x45e8c0: bl              #0x34b75c  ; AwaitStub
    // 0x45e8c4: mov             x2, x0
    // 0x45e8c8: r1 = Instance_BinaryCodec
    //     0x45e8c8: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb80] Obj!BinaryCodec@85e381
    //     0x45e8cc: ldr             x1, [x1, #0xb80]
    // 0x45e8d0: stur            x2, [fp, #-0xe0]
    // 0x45e8d4: LoadField: r3 = r1->field_7
    //     0x45e8d4: ldur            w3, [x1, #7]
    // 0x45e8d8: DecompressPointer r3
    //     0x45e8d8: add             x3, x3, HEAP, lsl #32
    // 0x45e8dc: stur            x3, [fp, #-0xd8]
    // 0x45e8e0: r7 = 0
    //     0x45e8e0: movz            x7, #0
    // 0x45e8e4: r6 = Null
    //     0x45e8e4: mov             x6, NULL
    // 0x45e8e8: r5 = Null
    //     0x45e8e8: mov             x5, NULL
    // 0x45e8ec: ldur            x4, [fp, #-0xb8]
    // 0x45e8f0: stur            x7, [fp, #-0xd0]
    // 0x45e8f4: stur            x6, [fp, #-0xc0]
    // 0x45e8f8: stur            x5, [fp, #-0xc8]
    // 0x45e8fc: CheckStackOverflow
    //     0x45e8fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45e900: cmp             SP, x16
    //     0x45e904: b.ls            #0x45f2cc
    // 0x45e908: r0 = LoadClassIdInstr(r2)
    //     0x45e908: ldur            x0, [x2, #-1]
    //     0x45e90c: ubfx            x0, x0, #0xc, #0x14
    // 0x45e910: str             x2, [SP]
    // 0x45e914: r0 = GDT[cid_x0 + 0x79d0]()
    //     0x45e914: movz            x17, #0x79d0
    //     0x45e918: add             lr, x0, x17
    //     0x45e91c: ldr             lr, [x21, lr, lsl #3]
    //     0x45e920: blr             lr
    // 0x45e924: r1 = LoadInt32Instr(r0)
    //     0x45e924: sbfx            x1, x0, #1, #0x1f
    // 0x45e928: ldur            x2, [fp, #-0xd0]
    // 0x45e92c: cmp             x2, x1
    // 0x45e930: b.ge            #0x45f28c
    // 0x45e934: ldur            x3, [fp, #-0xe0]
    // 0x45e938: r0 = BoxInt64Instr(r2)
    //     0x45e938: sbfiz           x0, x2, #1, #0x1f
    //     0x45e93c: cmp             x2, x0, asr #1
    //     0x45e940: b.eq            #0x45e94c
    //     0x45e944: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x45e948: stur            x2, [x0, #7]
    // 0x45e94c: mov             x1, x0
    // 0x45e950: stur            x1, [fp, #-0xe8]
    // 0x45e954: r0 = LoadClassIdInstr(r3)
    //     0x45e954: ldur            x0, [x3, #-1]
    //     0x45e958: ubfx            x0, x0, #0xc, #0x14
    // 0x45e95c: stp             x1, x3, [SP]
    // 0x45e960: r0 = GDT[cid_x0 + -0xfff]()
    //     0x45e960: sub             lr, x0, #0xfff
    //     0x45e964: ldr             lr, [x21, lr, lsl #3]
    //     0x45e968: blr             lr
    // 0x45e96c: r1 = LoadClassIdInstr(r0)
    //     0x45e96c: ldur            x1, [x0, #-1]
    //     0x45e970: ubfx            x1, x1, #0xc, #0x14
    // 0x45e974: mov             x16, x0
    // 0x45e978: mov             x0, x1
    // 0x45e97c: mov             x1, x16
    // 0x45e980: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45e980: sub             lr, x0, #1, lsl #12
    //     0x45e984: ldr             lr, [x21, lr, lsl #3]
    //     0x45e988: blr             lr
    // 0x45e98c: mov             x2, x0
    // 0x45e990: ldur            x1, [fp, #-0xe0]
    // 0x45e994: stur            x2, [fp, #-0xf0]
    // 0x45e998: r0 = LoadClassIdInstr(r1)
    //     0x45e998: ldur            x0, [x1, #-1]
    //     0x45e99c: ubfx            x0, x0, #0xc, #0x14
    // 0x45e9a0: ldur            x16, [fp, #-0xe8]
    // 0x45e9a4: stp             x16, x1, [SP]
    // 0x45e9a8: r0 = GDT[cid_x0 + -0xfff]()
    //     0x45e9a8: sub             lr, x0, #0xfff
    //     0x45e9ac: ldr             lr, [x21, lr, lsl #3]
    //     0x45e9b0: blr             lr
    // 0x45e9b4: r1 = 60
    //     0x45e9b4: movz            x1, #0x3c
    // 0x45e9b8: branchIfSmi(r0, 0x45e9c4)
    //     0x45e9b8: tbz             w0, #0, #0x45e9c4
    // 0x45e9bc: r1 = LoadClassIdInstr(r0)
    //     0x45e9bc: ldur            x1, [x0, #-1]
    //     0x45e9c0: ubfx            x1, x1, #0xc, #0x14
    // 0x45e9c4: cmp             x1, #0xe1d
    // 0x45e9c8: b.ne            #0x45e9d8
    // 0x45e9cc: LoadField: r1 = r0->field_7
    //     0x45e9cc: ldur            w1, [x0, #7]
    // 0x45e9d0: DecompressPointer r1
    //     0x45e9d0: add             x1, x1, HEAP, lsl #32
    // 0x45e9d4: b               #0x45e9f4
    // 0x45e9d8: cmp             x1, #0xe1e
    // 0x45e9dc: b.ne            #0x45e9ec
    // 0x45e9e0: LoadField: r1 = r0->field_7
    //     0x45e9e0: ldur            w1, [x0, #7]
    // 0x45e9e4: DecompressPointer r1
    //     0x45e9e4: add             x1, x1, HEAP, lsl #32
    // 0x45e9e8: b               #0x45e9f4
    // 0x45e9ec: LoadField: r1 = r0->field_7
    //     0x45e9ec: ldur            w1, [x0, #7]
    // 0x45e9f0: DecompressPointer r1
    //     0x45e9f0: add             x1, x1, HEAP, lsl #32
    // 0x45e9f4: ldur            x2, [fp, #-0xb8]
    // 0x45e9f8: ldur            x0, [fp, #-0xf0]
    // 0x45e9fc: r0 = parentOf()
    //     0x45e9fc: bl              #0x36fd24  ; [dart:io] FileSystemEntity::parentOf
    // 0x45ea00: stur            x0, [fp, #-0xf8]
    // 0x45ea04: r0 = current()
    //     0x45ea04: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x45ea08: r0 = _Directory()
    //     0x45ea08: bl              #0x3422d0  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0x45ea0c: mov             x2, x0
    // 0x45ea10: ldur            x0, [fp, #-0xf8]
    // 0x45ea14: stur            x2, [fp, #-0x100]
    // 0x45ea18: StoreField: r2->field_7 = r0
    //     0x45ea18: stur            w0, [x2, #7]
    // 0x45ea1c: mov             x1, x0
    // 0x45ea20: r0 = _toUtf8Array()
    //     0x45ea20: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x45ea24: ldur            x1, [fp, #-0x100]
    // 0x45ea28: StoreField: r1->field_b = r0
    //     0x45ea28: stur            w0, [x1, #0xb]
    //     0x45ea2c: ldurb           w16, [x1, #-1]
    //     0x45ea30: ldurb           w17, [x0, #-1]
    //     0x45ea34: and             x16, x17, x16, lsr #2
    //     0x45ea38: tst             x16, HEAP, lsr #32
    //     0x45ea3c: b.eq            #0x45ea44
    //     0x45ea40: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45ea44: ldur            x0, [fp, #-0xf8]
    // 0x45ea48: LoadField: r1 = r0->field_7
    //     0x45ea48: ldur            w1, [x0, #7]
    // 0x45ea4c: r0 = LoadInt32Instr(r1)
    //     0x45ea4c: sbfx            x0, x1, #1, #0x1f
    // 0x45ea50: add             x4, x0, #1
    // 0x45ea54: ldur            x0, [fp, #-0xf0]
    // 0x45ea58: r17 = -264
    //     0x45ea58: movn            x17, #0x107
    // 0x45ea5c: str             x4, [fp, x17]
    // 0x45ea60: LoadField: r1 = r0->field_7
    //     0x45ea60: ldur            w1, [x0, #7]
    // 0x45ea64: r3 = LoadInt32Instr(r1)
    //     0x45ea64: sbfx            x3, x1, #1, #0x1f
    // 0x45ea68: mov             x1, x4
    // 0x45ea6c: r2 = Null
    //     0x45ea6c: mov             x2, NULL
    // 0x45ea70: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x45ea70: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x45ea74: r0 = checkValidRange()
    //     0x45ea74: bl              #0x328dc4  ; [dart:core] RangeError::checkValidRange
    // 0x45ea78: ldur            x1, [fp, #-0xf0]
    // 0x45ea7c: r17 = -264
    //     0x45ea7c: movn            x17, #0x107
    // 0x45ea80: ldr             x2, [fp, x17]
    // 0x45ea84: mov             x3, x0
    // 0x45ea88: r0 = _substringUnchecked()
    //     0x45ea88: bl              #0x334bb4  ; [dart:core] _StringBase::_substringUnchecked
    // 0x45ea8c: mov             x2, x0
    // 0x45ea90: ldur            x1, [fp, #-0xb8]
    // 0x45ea94: stur            x2, [fp, #-0xf0]
    // 0x45ea98: cmp             w1, NULL
    // 0x45ea9c: b.eq            #0x45eac8
    // 0x45eaa0: r0 = LoadClassIdInstr(r2)
    //     0x45eaa0: ldur            x0, [x2, #-1]
    //     0x45eaa4: ubfx            x0, x0, #0xc, #0x14
    // 0x45eaa8: stp             x1, x2, [SP]
    // 0x45eaac: mov             lr, x0
    // 0x45eab0: ldr             lr, [x21, lr, lsl #3]
    // 0x45eab4: blr             lr
    // 0x45eab8: tbz             w0, #4, #0x45eac8
    // 0x45eabc: ldur            x5, [fp, #-0xc8]
    // 0x45eac0: ldur            x6, [fp, #-0xc0]
    // 0x45eac4: b               #0x45f270
    // 0x45eac8: ldur            x1, [fp, #-0xf0]
    // 0x45eacc: LoadField: r0 = r1->field_7
    //     0x45eacc: ldur            w0, [x1, #7]
    // 0x45ead0: r17 = -304
    //     0x45ead0: movn            x17, #0x12f
    // 0x45ead4: str             x0, [fp, x17]
    // 0x45ead8: r3 = LoadInt32Instr(r0)
    //     0x45ead8: sbfx            x3, x0, #1, #0x1f
    // 0x45eadc: r17 = -264
    //     0x45eadc: movn            x17, #0x107
    // 0x45eae0: str             x3, [fp, x17]
    // 0x45eae4: tbnz            x3, #0x3f, #0x45f294
    // 0x45eae8: stp             xzr, x1, [SP, #8]
    // 0x45eaec: r16 = "Local-"
    //     0x45eaec: add             x16, PP, #0x10, lsl #12  ; [pp+0x10a20] "Local-"
    //     0x45eaf0: ldr             x16, [x16, #0xa20]
    // 0x45eaf4: str             x16, [SP]
    // 0x45eaf8: r0 = _substringMatches()
    //     0x45eaf8: bl              #0x333a18  ; [dart:core] _StringBase::_substringMatches
    // 0x45eafc: r1 = <int>
    //     0x45eafc: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x45eb00: stur            x0, [fp, #-0xf8]
    // 0x45eb04: r0 = LevelEditorGameState()
    //     0x45eb04: bl              #0x45c474  ; AllocateLevelEditorGameStateStub -> LevelEditorGameState (size=0x58)
    // 0x45eb08: mov             x2, x0
    // 0x45eb0c: ldur            x1, [fp, #-0xf8]
    // 0x45eb10: r17 = -272
    //     0x45eb10: movn            x17, #0x10f
    // 0x45eb14: str             x2, [fp, x17]
    // 0x45eb18: tbnz            w1, #4, #0x45eb28
    // 0x45eb1c: r4 = Instance_EditorCreationMethod
    //     0x45eb1c: add             x4, PP, #0x10, lsl #12  ; [pp+0x10a28] Obj!EditorCreationMethod@85ed01
    //     0x45eb20: ldr             x4, [x4, #0xa28]
    // 0x45eb24: b               #0x45eb30
    // 0x45eb28: r4 = Instance_EditorCreationMethod
    //     0x45eb28: add             x4, PP, #0x10, lsl #12  ; [pp+0x10a30] Obj!EditorCreationMethod@85ece1
    //     0x45eb2c: ldr             x4, [x4, #0xa30]
    // 0x45eb30: ldur            x3, [fp, #-0xe0]
    // 0x45eb34: stur            x4, [fp, #-0x100]
    // 0x45eb38: r0 = LoadClassIdInstr(r3)
    //     0x45eb38: ldur            x0, [x3, #-1]
    //     0x45eb3c: ubfx            x0, x0, #0xc, #0x14
    // 0x45eb40: ldur            x16, [fp, #-0xe8]
    // 0x45eb44: stp             x16, x3, [SP]
    // 0x45eb48: r0 = GDT[cid_x0 + -0xfff]()
    //     0x45eb48: sub             lr, x0, #0xfff
    //     0x45eb4c: ldr             lr, [x21, lr, lsl #3]
    //     0x45eb50: blr             lr
    // 0x45eb54: r1 = LoadClassIdInstr(r0)
    //     0x45eb54: ldur            x1, [x0, #-1]
    //     0x45eb58: ubfx            x1, x1, #0xc, #0x14
    // 0x45eb5c: mov             x16, x0
    // 0x45eb60: mov             x0, x1
    // 0x45eb64: mov             x1, x16
    // 0x45eb68: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45eb68: sub             lr, x0, #1, lsl #12
    //     0x45eb6c: ldr             lr, [x21, lr, lsl #3]
    //     0x45eb70: blr             lr
    // 0x45eb74: r17 = -280
    //     0x45eb74: movn            x17, #0x117
    // 0x45eb78: str             x0, [fp, x17]
    // 0x45eb7c: r0 = current()
    //     0x45eb7c: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x45eb80: r0 = _File()
    //     0x45eb80: bl              #0x342dfc  ; Allocate_FileStub -> _File (size=0x10)
    // 0x45eb84: r17 = -280
    //     0x45eb84: movn            x17, #0x117
    // 0x45eb88: ldr             x1, [fp, x17]
    // 0x45eb8c: r17 = -288
    //     0x45eb8c: movn            x17, #0x11f
    // 0x45eb90: str             x0, [fp, x17]
    // 0x45eb94: StoreField: r0->field_7 = r1
    //     0x45eb94: stur            w1, [x0, #7]
    // 0x45eb98: r0 = _toUtf8Array()
    //     0x45eb98: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x45eb9c: r17 = -288
    //     0x45eb9c: movn            x17, #0x11f
    // 0x45eba0: ldr             x1, [fp, x17]
    // 0x45eba4: StoreField: r1->field_b = r0
    //     0x45eba4: stur            w0, [x1, #0xb]
    //     0x45eba8: ldurb           w16, [x1, #-1]
    //     0x45ebac: ldurb           w17, [x0, #-1]
    //     0x45ebb0: and             x16, x17, x16, lsr #2
    //     0x45ebb4: tst             x16, HEAP, lsr #32
    //     0x45ebb8: b.eq            #0x45ebc0
    //     0x45ebbc: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45ebc0: r1 = 2
    //     0x45ebc0: movz            x1, #0x2
    // 0x45ebc4: r0 = AllocateContext()
    //     0x45ebc4: bl              #0x82637c  ; AllocateContextStub
    // 0x45ebc8: r1 = Function 'readUnsized':.
    //     0x45ebc8: add             x1, PP, #0x10, lsl #12  ; [pp+0x10930] AnonymousClosure: (0x45e234), in [dart:io] _File::readAsBytes (0x45c8b0)
    //     0x45ebcc: ldr             x1, [x1, #0x930]
    // 0x45ebd0: r2 = Null
    //     0x45ebd0: mov             x2, NULL
    // 0x45ebd4: r17 = -280
    //     0x45ebd4: movn            x17, #0x117
    // 0x45ebd8: str             x0, [fp, x17]
    // 0x45ebdc: r0 = AllocateClosure()
    //     0x45ebdc: bl              #0x826750  ; AllocateClosureStub
    // 0x45ebe0: mov             x1, x0
    // 0x45ebe4: r17 = -280
    //     0x45ebe4: movn            x17, #0x117
    // 0x45ebe8: ldr             x0, [fp, x17]
    // 0x45ebec: StoreField: r0->field_f = r1
    //     0x45ebec: stur            w1, [x0, #0xf]
    // 0x45ebf0: r1 = Function 'readSized':.
    //     0x45ebf0: add             x1, PP, #0x10, lsl #12  ; [pp+0x10938] AnonymousClosure: (0x45e08c), in [dart:io] _File::readAsBytes (0x45c8b0)
    //     0x45ebf4: ldr             x1, [x1, #0x938]
    // 0x45ebf8: r2 = Null
    //     0x45ebf8: mov             x2, NULL
    // 0x45ebfc: r0 = AllocateClosure()
    //     0x45ebfc: bl              #0x826750  ; AllocateClosureStub
    // 0x45ec00: r17 = -280
    //     0x45ec00: movn            x17, #0x117
    // 0x45ec04: ldr             x2, [fp, x17]
    // 0x45ec08: StoreField: r2->field_13 = r0
    //     0x45ec08: stur            w0, [x2, #0x13]
    // 0x45ec0c: r17 = -288
    //     0x45ec0c: movn            x17, #0x11f
    // 0x45ec10: ldr             x1, [fp, x17]
    // 0x45ec14: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x45ec14: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x45ec18: r0 = open()
    //     0x45ec18: bl              #0x36e2c0  ; [dart:io] _File::open
    // 0x45ec1c: r17 = -280
    //     0x45ec1c: movn            x17, #0x117
    // 0x45ec20: ldr             x2, [fp, x17]
    // 0x45ec24: r1 = Function '<anonymous closure>':.
    //     0x45ec24: add             x1, PP, #0x10, lsl #12  ; [pp+0x10940] AnonymousClosure: (0x45c95c), in [dart:io] _File::readAsBytes (0x45c8b0)
    //     0x45ec28: ldr             x1, [x1, #0x940]
    // 0x45ec2c: r17 = -288
    //     0x45ec2c: movn            x17, #0x11f
    // 0x45ec30: str             x0, [fp, x17]
    // 0x45ec34: r0 = AllocateClosure()
    //     0x45ec34: bl              #0x826750  ; AllocateClosureStub
    // 0x45ec38: r16 = <Uint8List>
    //     0x45ec38: add             x16, PP, #0xa, lsl #12  ; [pp+0xaa90] TypeArguments: <Uint8List>
    //     0x45ec3c: ldr             x16, [x16, #0xa90]
    // 0x45ec40: r17 = -288
    //     0x45ec40: movn            x17, #0x11f
    // 0x45ec44: ldr             lr, [fp, x17]
    // 0x45ec48: stp             lr, x16, [SP, #8]
    // 0x45ec4c: str             x0, [SP]
    // 0x45ec50: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x45ec50: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x45ec54: r0 = then()
    //     0x45ec54: bl              #0x7cc9a0  ; [dart:async] _Future::then
    // 0x45ec58: mov             x1, x0
    // 0x45ec5c: r17 = -280
    //     0x45ec5c: movn            x17, #0x117
    // 0x45ec60: str             x1, [fp, x17]
    // 0x45ec64: r0 = Await()
    //     0x45ec64: bl              #0x34b75c  ; AwaitStub
    // 0x45ec68: ldur            x2, [fp, #-0xd8]
    // 0x45ec6c: mov             x3, x0
    // 0x45ec70: r1 = Null
    //     0x45ec70: mov             x1, NULL
    // 0x45ec74: r17 = -280
    //     0x45ec74: movn            x17, #0x117
    // 0x45ec78: str             x3, [fp, x17]
    // 0x45ec7c: cmp             w2, NULL
    // 0x45ec80: b.eq            #0x45eca0
    // 0x45ec84: LoadField: r4 = r2->field_1b
    //     0x45ec84: ldur            w4, [x2, #0x1b]
    // 0x45ec88: DecompressPointer r4
    //     0x45ec88: add             x4, x4, HEAP, lsl #32
    // 0x45ec8c: r8 = X1
    //     0x45ec8c: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x45ec90: LoadField: r9 = r4->field_7
    //     0x45ec90: ldur            x9, [x4, #7]
    // 0x45ec94: r3 = Null
    //     0x45ec94: add             x3, PP, #0x10, lsl #12  ; [pp+0x10a38] Null
    //     0x45ec98: ldr             x3, [x3, #0xa38]
    // 0x45ec9c: blr             x9
    // 0x45eca0: r1 = Instance_BinaryCodec
    //     0x45eca0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb80] Obj!BinaryCodec@85e381
    //     0x45eca4: ldr             x1, [x1, #0xb80]
    // 0x45eca8: r0 = decoder()
    //     0x45eca8: bl              #0x76a684  ; [package:binary_codec/src/binary_codec.dart] BinaryCodec::decoder
    // 0x45ecac: r1 = LoadClassIdInstr(r0)
    //     0x45ecac: ldur            x1, [x0, #-1]
    //     0x45ecb0: ubfx            x1, x1, #0xc, #0x14
    // 0x45ecb4: mov             x16, x0
    // 0x45ecb8: mov             x0, x1
    // 0x45ecbc: mov             x1, x16
    // 0x45ecc0: r17 = -280
    //     0x45ecc0: movn            x17, #0x117
    // 0x45ecc4: ldr             x2, [fp, x17]
    // 0x45ecc8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x45ecc8: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x45eccc: r0 = GDT[cid_x0 + 0xa1d]()
    //     0x45eccc: add             lr, x0, #0xa1d
    //     0x45ecd0: ldr             lr, [x21, lr, lsl #3]
    //     0x45ecd4: blr             lr
    // 0x45ecd8: mov             x3, x0
    // 0x45ecdc: r2 = Null
    //     0x45ecdc: mov             x2, NULL
    // 0x45ece0: r1 = Null
    //     0x45ece0: mov             x1, NULL
    // 0x45ece4: r17 = -280
    //     0x45ece4: movn            x17, #0x117
    // 0x45ece8: str             x3, [fp, x17]
    // 0x45ecec: r8 = Map?
    //     0x45ecec: add             x8, PP, #0x10, lsl #12  ; [pp+0x10038] Type: Map?
    //     0x45ecf0: ldr             x8, [x8, #0x38]
    // 0x45ecf4: r3 = Null
    //     0x45ecf4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10a48] Null
    //     0x45ecf8: ldr             x3, [x3, #0xa48]
    // 0x45ecfc: r0 = Map?()
    //     0x45ecfc: bl              #0x473b48  ; IsType_Map?_Stub
    // 0x45ed00: r17 = -272
    //     0x45ed00: movn            x17, #0x10f
    // 0x45ed04: ldr             x1, [fp, x17]
    // 0x45ed08: ldur            x3, [fp, #-0x100]
    // 0x45ed0c: r17 = -280
    //     0x45ed0c: movn            x17, #0x117
    // 0x45ed10: ldr             x5, [fp, x17]
    // 0x45ed14: r2 = "Editor"
    //     0x45ed14: add             x2, PP, #0x10, lsl #12  ; [pp+0x10060] "Editor"
    //     0x45ed18: ldr             x2, [x2, #0x60]
    // 0x45ed1c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x45ed1c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x45ed20: r0 = LevelEditorGameState()
    //     0x45ed20: bl              #0x456e2c  ; [package:pretentious/data/Chapters/LevelEditorGameState.dart] LevelEditorGameState::LevelEditorGameState
    // 0x45ed24: ldur            x0, [fp, #-0xf8]
    // 0x45ed28: tbnz            w0, #4, #0x45ed5c
    // 0x45ed2c: r17 = -264
    //     0x45ed2c: movn            x17, #0x107
    // 0x45ed30: ldr             x3, [fp, x17]
    // 0x45ed34: r1 = 6
    //     0x45ed34: movz            x1, #0x6
    // 0x45ed38: r2 = Null
    //     0x45ed38: mov             x2, NULL
    // 0x45ed3c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x45ed3c: ldr             x4, [PP, #0x330]  ; [pp+0x330] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x45ed40: r0 = checkValidRange()
    //     0x45ed40: bl              #0x328dc4  ; [dart:core] RangeError::checkValidRange
    // 0x45ed44: ldur            x1, [fp, #-0xf0]
    // 0x45ed48: mov             x3, x0
    // 0x45ed4c: r2 = 6
    //     0x45ed4c: movz            x2, #0x6
    // 0x45ed50: r0 = _substringUnchecked()
    //     0x45ed50: bl              #0x334bb4  ; [dart:core] _StringBase::_substringUnchecked
    // 0x45ed54: mov             x3, x0
    // 0x45ed58: b               #0x45ed60
    // 0x45ed5c: ldur            x3, [fp, #-0xf0]
    // 0x45ed60: r17 = -280
    //     0x45ed60: movn            x17, #0x117
    // 0x45ed64: str             x3, [fp, x17]
    // 0x45ed68: r0 = LoadStaticField(0xf7c)
    //     0x45ed68: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45ed6c: ldr             x0, [x0, #0x1ef8]
    // 0x45ed70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x45ed74: cmp             w0, w16
    // 0x45ed78: b.eq            #0x45f2d4
    // 0x45ed7c: LoadField: r4 = r0->field_1b
    //     0x45ed7c: ldur            w4, [x0, #0x1b]
    // 0x45ed80: DecompressPointer r4
    //     0x45ed80: add             x4, x4, HEAP, lsl #32
    // 0x45ed84: mov             x1, x4
    // 0x45ed88: mov             x2, x3
    // 0x45ed8c: stur            x4, [fp, #-0x100]
    // 0x45ed90: r0 = _getValueOrData()
    //     0x45ed90: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x45ed94: mov             x1, x0
    // 0x45ed98: ldur            x0, [fp, #-0x100]
    // 0x45ed9c: LoadField: r2 = r0->field_f
    //     0x45ed9c: ldur            w2, [x0, #0xf]
    // 0x45eda0: DecompressPointer r2
    //     0x45eda0: add             x2, x2, HEAP, lsl #32
    // 0x45eda4: cmp             w2, w1
    // 0x45eda8: b.ne            #0x45edb4
    // 0x45edac: r0 = Null
    //     0x45edac: mov             x0, NULL
    // 0x45edb0: b               #0x45edb8
    // 0x45edb4: mov             x0, x1
    // 0x45edb8: r17 = -272
    //     0x45edb8: movn            x17, #0x10f
    // 0x45edbc: ldr             x3, [fp, x17]
    // 0x45edc0: LoadField: r1 = r3->field_37
    //     0x45edc0: ldur            w1, [x3, #0x37]
    // 0x45edc4: DecompressPointer r1
    //     0x45edc4: add             x1, x1, HEAP, lsl #32
    // 0x45edc8: LoadField: r2 = r1->field_f
    //     0x45edc8: ldur            w2, [x1, #0xf]
    // 0x45edcc: DecompressPointer r2
    //     0x45edcc: add             x2, x2, HEAP, lsl #32
    // 0x45edd0: r1 = LoadClassIdInstr(r0)
    //     0x45edd0: ldur            x1, [x0, #-1]
    //     0x45edd4: ubfx            x1, x1, #0xc, #0x14
    // 0x45edd8: stp             x2, x0, [SP]
    // 0x45eddc: mov             x0, x1
    // 0x45ede0: mov             lr, x0
    // 0x45ede4: ldr             lr, [x21, lr, lsl #3]
    // 0x45ede8: blr             lr
    // 0x45edec: tbz             w0, #4, #0x45eed4
    // 0x45edf0: r17 = -272
    //     0x45edf0: movn            x17, #0x10f
    // 0x45edf4: ldr             x3, [fp, x17]
    // 0x45edf8: r0 = LoadStaticField(0xf7c)
    //     0x45edf8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45edfc: ldr             x0, [x0, #0x1ef8]
    // 0x45ee00: LoadField: r4 = r0->field_1b
    //     0x45ee00: ldur            w4, [x0, #0x1b]
    // 0x45ee04: DecompressPointer r4
    //     0x45ee04: add             x4, x4, HEAP, lsl #32
    // 0x45ee08: r17 = -296
    //     0x45ee08: movn            x17, #0x127
    // 0x45ee0c: str             x4, [fp, x17]
    // 0x45ee10: LoadField: r0 = r3->field_37
    //     0x45ee10: ldur            w0, [x3, #0x37]
    // 0x45ee14: DecompressPointer r0
    //     0x45ee14: add             x0, x0, HEAP, lsl #32
    // 0x45ee18: LoadField: r5 = r0->field_f
    //     0x45ee18: ldur            w5, [x0, #0xf]
    // 0x45ee1c: DecompressPointer r5
    //     0x45ee1c: add             x5, x5, HEAP, lsl #32
    // 0x45ee20: r17 = -288
    //     0x45ee20: movn            x17, #0x11f
    // 0x45ee24: str             x5, [fp, x17]
    // 0x45ee28: LoadField: r6 = r4->field_7
    //     0x45ee28: ldur            w6, [x4, #7]
    // 0x45ee2c: DecompressPointer r6
    //     0x45ee2c: add             x6, x6, HEAP, lsl #32
    // 0x45ee30: r17 = -280
    //     0x45ee30: movn            x17, #0x117
    // 0x45ee34: ldr             x0, [fp, x17]
    // 0x45ee38: mov             x2, x6
    // 0x45ee3c: stur            x6, [fp, #-0x100]
    // 0x45ee40: r1 = Null
    //     0x45ee40: mov             x1, NULL
    // 0x45ee44: cmp             w2, NULL
    // 0x45ee48: b.eq            #0x45ee68
    // 0x45ee4c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x45ee4c: ldur            w4, [x2, #0x17]
    // 0x45ee50: DecompressPointer r4
    //     0x45ee50: add             x4, x4, HEAP, lsl #32
    // 0x45ee54: r8 = X0
    //     0x45ee54: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x45ee58: LoadField: r9 = r4->field_7
    //     0x45ee58: ldur            x9, [x4, #7]
    // 0x45ee5c: r3 = Null
    //     0x45ee5c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10a58] Null
    //     0x45ee60: ldr             x3, [x3, #0xa58]
    // 0x45ee64: blr             x9
    // 0x45ee68: r17 = -288
    //     0x45ee68: movn            x17, #0x11f
    // 0x45ee6c: ldr             x0, [fp, x17]
    // 0x45ee70: ldur            x2, [fp, #-0x100]
    // 0x45ee74: r1 = Null
    //     0x45ee74: mov             x1, NULL
    // 0x45ee78: cmp             w2, NULL
    // 0x45ee7c: b.eq            #0x45ee9c
    // 0x45ee80: LoadField: r4 = r2->field_1b
    //     0x45ee80: ldur            w4, [x2, #0x1b]
    // 0x45ee84: DecompressPointer r4
    //     0x45ee84: add             x4, x4, HEAP, lsl #32
    // 0x45ee88: r8 = X1
    //     0x45ee88: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x45ee8c: LoadField: r9 = r4->field_7
    //     0x45ee8c: ldur            x9, [x4, #7]
    // 0x45ee90: r3 = Null
    //     0x45ee90: add             x3, PP, #0x10, lsl #12  ; [pp+0x10a68] Null
    //     0x45ee94: ldr             x3, [x3, #0xa68]
    // 0x45ee98: blr             x9
    // 0x45ee9c: r17 = -296
    //     0x45ee9c: movn            x17, #0x127
    // 0x45eea0: ldr             x1, [fp, x17]
    // 0x45eea4: r17 = -280
    //     0x45eea4: movn            x17, #0x117
    // 0x45eea8: ldr             x2, [fp, x17]
    // 0x45eeac: r0 = _hashCode()
    //     0x45eeac: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x45eeb0: r17 = -296
    //     0x45eeb0: movn            x17, #0x127
    // 0x45eeb4: ldr             x1, [fp, x17]
    // 0x45eeb8: r17 = -280
    //     0x45eeb8: movn            x17, #0x117
    // 0x45eebc: ldr             x2, [fp, x17]
    // 0x45eec0: r17 = -288
    //     0x45eec0: movn            x17, #0x11f
    // 0x45eec4: ldr             x3, [fp, x17]
    // 0x45eec8: mov             x5, x0
    // 0x45eecc: r0 = _set()
    //     0x45eecc: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x45eed0: r0 = deferredSaveCoreData()
    //     0x45eed0: bl              #0x46268c  ; [package:pretentious/data/CoreData.dart] ::deferredSaveCoreData
    // 0x45eed4: ldur            x0, [fp, #-0xf8]
    // 0x45eed8: ldur            x3, [fp, #-0xf0]
    // 0x45eedc: r1 = Null
    //     0x45eedc: mov             x1, NULL
    // 0x45eee0: r2 = 4
    //     0x45eee0: movz            x2, #0x4
    // 0x45eee4: r0 = AllocateArray()
    //     0x45eee4: bl              #0x82746c  ; AllocateArrayStub
    // 0x45eee8: ldur            x2, [fp, #-0xf0]
    // 0x45eeec: StoreField: r0->field_f = r2
    //     0x45eeec: stur            w2, [x0, #0xf]
    // 0x45eef0: r16 = "1"
    //     0x45eef0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x45eef4: ldr             x16, [x16, #0x9c8]
    // 0x45eef8: StoreField: r0->field_13 = r16
    //     0x45eef8: stur            w16, [x0, #0x13]
    // 0x45eefc: str             x0, [SP]
    // 0x45ef00: r0 = _interpolate()
    //     0x45ef00: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x45ef04: r1 = Null
    //     0x45ef04: mov             x1, NULL
    // 0x45ef08: r2 = 4
    //     0x45ef08: movz            x2, #0x4
    // 0x45ef0c: stur            x0, [fp, #-0x100]
    // 0x45ef10: r0 = AllocateArray()
    //     0x45ef10: bl              #0x82746c  ; AllocateArrayStub
    // 0x45ef14: ldur            x2, [fp, #-0xf0]
    // 0x45ef18: StoreField: r0->field_f = r2
    //     0x45ef18: stur            w2, [x0, #0xf]
    // 0x45ef1c: r16 = "2"
    //     0x45ef1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x45ef20: ldr             x16, [x16, #0x2e0]
    // 0x45ef24: StoreField: r0->field_13 = r16
    //     0x45ef24: stur            w16, [x0, #0x13]
    // 0x45ef28: str             x0, [SP]
    // 0x45ef2c: r0 = _interpolate()
    //     0x45ef2c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x45ef30: r1 = Null
    //     0x45ef30: mov             x1, NULL
    // 0x45ef34: r2 = 4
    //     0x45ef34: movz            x2, #0x4
    // 0x45ef38: r17 = -280
    //     0x45ef38: movn            x17, #0x117
    // 0x45ef3c: str             x0, [fp, x17]
    // 0x45ef40: r0 = AllocateArray()
    //     0x45ef40: bl              #0x82746c  ; AllocateArrayStub
    // 0x45ef44: ldur            x2, [fp, #-0xf0]
    // 0x45ef48: StoreField: r0->field_f = r2
    //     0x45ef48: stur            w2, [x0, #0xf]
    // 0x45ef4c: r16 = "3"
    //     0x45ef4c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x45ef50: ldr             x16, [x16, #0x2f0]
    // 0x45ef54: StoreField: r0->field_13 = r16
    //     0x45ef54: stur            w16, [x0, #0x13]
    // 0x45ef58: str             x0, [SP]
    // 0x45ef5c: r0 = _interpolate()
    //     0x45ef5c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x45ef60: ldur            x1, [fp, #-0x100]
    // 0x45ef64: mov             x2, x0
    // 0x45ef68: r17 = -280
    //     0x45ef68: movn            x17, #0x117
    // 0x45ef6c: ldr             x5, [fp, x17]
    // 0x45ef70: r3 = 2
    //     0x45ef70: movz            x3, #0x2
    // 0x45ef74: r17 = -288
    //     0x45ef74: movn            x17, #0x11f
    // 0x45ef78: str             x0, [fp, x17]
    // 0x45ef7c: r0 = readMostRecentValidSaveFile()
    //     0x45ef7c: bl              #0x47304c  ; [package:custom_tools/SaveLoadManager.dart] ::readMostRecentValidSaveFile
    // 0x45ef80: mov             x1, x0
    // 0x45ef84: r17 = -296
    //     0x45ef84: movn            x17, #0x127
    // 0x45ef88: str             x1, [fp, x17]
    // 0x45ef8c: r0 = Await()
    //     0x45ef8c: bl              #0x34b75c  ; AwaitStub
    // 0x45ef90: mov             x1, x0
    // 0x45ef94: ldur            x0, [fp, #-0xf8]
    // 0x45ef98: stur            x1, [fp, #-0x100]
    // 0x45ef9c: tbnz            w0, #4, #0x45f040
    // 0x45efa0: r0 = LoadStaticField(0xf5c)
    //     0x45efa0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45efa4: ldr             x0, [x0, #0x1eb8]
    // 0x45efa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x45efac: cmp             w0, w16
    // 0x45efb0: b.ne            #0x45efc0
    // 0x45efb4: r2 = customLevels
    //     0x45efb4: add             x2, PP, #0xf, lsl #12  ; [pp+0xf368] Field <::.customLevels>: static late (offset: 0xf5c)
    //     0x45efb8: ldr             x2, [x2, #0x368]
    // 0x45efbc: r0 = InitLateStaticField()
    //     0x45efbc: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x45efc0: r1 = <int>
    //     0x45efc0: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x45efc4: stur            x0, [fp, #-0xf8]
    // 0x45efc8: r0 = CustomLevelGameState()
    //     0x45efc8: bl              #0x462680  ; AllocateCustomLevelGameStateStub -> CustomLevelGameState (size=0x98)
    // 0x45efcc: mov             x4, x0
    // 0x45efd0: ldur            x0, [fp, #-0x100]
    // 0x45efd4: r17 = -288
    //     0x45efd4: movn            x17, #0x11f
    // 0x45efd8: str             x4, [fp, x17]
    // 0x45efdc: cmp             w0, NULL
    // 0x45efe0: b.ne            #0x45efec
    // 0x45efe4: r6 = Null
    //     0x45efe4: mov             x6, NULL
    // 0x45efe8: b               #0x45eff8
    // 0x45efec: LoadField: r1 = r0->field_f
    //     0x45efec: ldur            w1, [x0, #0xf]
    // 0x45eff0: DecompressPointer r1
    //     0x45eff0: add             x1, x1, HEAP, lsl #32
    // 0x45eff4: mov             x6, x1
    // 0x45eff8: mov             x1, x4
    // 0x45effc: r17 = -272
    //     0x45effc: movn            x17, #0x10f
    // 0x45f000: ldr             x3, [fp, x17]
    // 0x45f004: mov             x5, x6
    // 0x45f008: r17 = -280
    //     0x45f008: movn            x17, #0x117
    // 0x45f00c: str             x6, [fp, x17]
    // 0x45f010: r2 = true
    //     0x45f010: add             x2, NULL, #0x20  ; true
    // 0x45f014: r0 = CustomLevelGameState()
    //     0x45f014: bl              #0x45f2e4  ; [package:pretentious/data/Chapters/CustomLevelGameState.dart] CustomLevelGameState::CustomLevelGameState
    // 0x45f018: ldur            x1, [fp, #-0xf8]
    // 0x45f01c: ldur            x2, [fp, #-0xf0]
    // 0x45f020: r0 = _hashCode()
    //     0x45f020: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x45f024: ldur            x1, [fp, #-0xf8]
    // 0x45f028: ldur            x2, [fp, #-0xf0]
    // 0x45f02c: r17 = -288
    //     0x45f02c: movn            x17, #0x11f
    // 0x45f030: ldr             x3, [fp, x17]
    // 0x45f034: mov             x5, x0
    // 0x45f038: r0 = _set()
    //     0x45f038: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x45f03c: b               #0x45f0e0
    // 0x45f040: mov             x0, x1
    // 0x45f044: r0 = LoadStaticField(0xf5c)
    //     0x45f044: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45f048: ldr             x0, [x0, #0x1eb8]
    // 0x45f04c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x45f050: cmp             w0, w16
    // 0x45f054: b.ne            #0x45f064
    // 0x45f058: r2 = customLevels
    //     0x45f058: add             x2, PP, #0xf, lsl #12  ; [pp+0xf368] Field <::.customLevels>: static late (offset: 0xf5c)
    //     0x45f05c: ldr             x2, [x2, #0x368]
    // 0x45f060: r0 = InitLateStaticField()
    //     0x45f060: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x45f064: r1 = <int>
    //     0x45f064: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x45f068: stur            x0, [fp, #-0xf8]
    // 0x45f06c: r0 = CustomLevelGameState()
    //     0x45f06c: bl              #0x462680  ; AllocateCustomLevelGameStateStub -> CustomLevelGameState (size=0x98)
    // 0x45f070: mov             x4, x0
    // 0x45f074: ldur            x0, [fp, #-0x100]
    // 0x45f078: r17 = -288
    //     0x45f078: movn            x17, #0x11f
    // 0x45f07c: str             x4, [fp, x17]
    // 0x45f080: cmp             w0, NULL
    // 0x45f084: b.ne            #0x45f090
    // 0x45f088: r6 = Null
    //     0x45f088: mov             x6, NULL
    // 0x45f08c: b               #0x45f09c
    // 0x45f090: LoadField: r1 = r0->field_f
    //     0x45f090: ldur            w1, [x0, #0xf]
    // 0x45f094: DecompressPointer r1
    //     0x45f094: add             x1, x1, HEAP, lsl #32
    // 0x45f098: mov             x6, x1
    // 0x45f09c: mov             x1, x4
    // 0x45f0a0: r17 = -272
    //     0x45f0a0: movn            x17, #0x10f
    // 0x45f0a4: ldr             x3, [fp, x17]
    // 0x45f0a8: mov             x5, x6
    // 0x45f0ac: r17 = -280
    //     0x45f0ac: movn            x17, #0x117
    // 0x45f0b0: str             x6, [fp, x17]
    // 0x45f0b4: r2 = false
    //     0x45f0b4: add             x2, NULL, #0x30  ; false
    // 0x45f0b8: r0 = CustomLevelGameState()
    //     0x45f0b8: bl              #0x45f2e4  ; [package:pretentious/data/Chapters/CustomLevelGameState.dart] CustomLevelGameState::CustomLevelGameState
    // 0x45f0bc: ldur            x1, [fp, #-0xf8]
    // 0x45f0c0: ldur            x2, [fp, #-0xf0]
    // 0x45f0c4: r0 = _hashCode()
    //     0x45f0c4: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x45f0c8: ldur            x1, [fp, #-0xf8]
    // 0x45f0cc: ldur            x2, [fp, #-0xf0]
    // 0x45f0d0: r17 = -288
    //     0x45f0d0: movn            x17, #0x11f
    // 0x45f0d4: ldr             x3, [fp, x17]
    // 0x45f0d8: mov             x5, x0
    // 0x45f0dc: r0 = _set()
    //     0x45f0dc: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x45f0e0: r0 = LoadStaticField(0xf5c)
    //     0x45f0e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45f0e4: ldr             x0, [x0, #0x1eb8]
    // 0x45f0e8: mov             x1, x0
    // 0x45f0ec: ldur            x2, [fp, #-0xf0]
    // 0x45f0f0: stur            x0, [fp, #-0xf8]
    // 0x45f0f4: r0 = _getValueOrData()
    //     0x45f0f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x45f0f8: mov             x1, x0
    // 0x45f0fc: ldur            x0, [fp, #-0xf8]
    // 0x45f100: LoadField: r2 = r0->field_f
    //     0x45f100: ldur            w2, [x0, #0xf]
    // 0x45f104: DecompressPointer r2
    //     0x45f104: add             x2, x2, HEAP, lsl #32
    // 0x45f108: cmp             w2, w1
    // 0x45f10c: b.ne            #0x45f118
    // 0x45f110: r4 = Null
    //     0x45f110: mov             x4, NULL
    // 0x45f114: b               #0x45f11c
    // 0x45f118: mov             x4, x1
    // 0x45f11c: ldur            x3, [fp, #-0x100]
    // 0x45f120: stur            x4, [fp, #-0xf8]
    // 0x45f124: cmp             w4, NULL
    // 0x45f128: b.eq            #0x45f2e0
    // 0x45f12c: cmp             w3, NULL
    // 0x45f130: b.ne            #0x45f140
    // 0x45f134: mov             x3, x4
    // 0x45f138: r4 = Null
    //     0x45f138: mov             x4, NULL
    // 0x45f13c: b               #0x45f168
    // 0x45f140: LoadField: r1 = r3->field_f
    //     0x45f140: ldur            w1, [x3, #0xf]
    // 0x45f144: DecompressPointer r1
    //     0x45f144: add             x1, x1, HEAP, lsl #32
    // 0x45f148: r0 = LoadClassIdInstr(r1)
    //     0x45f148: ldur            x0, [x1, #-1]
    //     0x45f14c: ubfx            x0, x0, #0xc, #0x14
    // 0x45f150: r2 = 2
    //     0x45f150: movz            x2, #0x2
    // 0x45f154: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45f154: sub             lr, x0, #1, lsl #12
    //     0x45f158: ldr             lr, [x21, lr, lsl #3]
    //     0x45f15c: blr             lr
    // 0x45f160: mov             x4, x0
    // 0x45f164: ldur            x3, [fp, #-0xf8]
    // 0x45f168: mov             x0, x4
    // 0x45f16c: stur            x4, [fp, #-0x100]
    // 0x45f170: r2 = Null
    //     0x45f170: mov             x2, NULL
    // 0x45f174: r1 = Null
    //     0x45f174: mov             x1, NULL
    // 0x45f178: branchIfSmi(r0, 0x45f1a0)
    //     0x45f178: tbz             w0, #0, #0x45f1a0
    // 0x45f17c: r4 = LoadClassIdInstr(r0)
    //     0x45f17c: ldur            x4, [x0, #-1]
    //     0x45f180: ubfx            x4, x4, #0xc, #0x14
    // 0x45f184: sub             x4, x4, #0x3c
    // 0x45f188: cmp             x4, #1
    // 0x45f18c: b.ls            #0x45f1a0
    // 0x45f190: r8 = int?
    //     0x45f190: ldr             x8, [PP, #0xb08]  ; [pp+0xb08] Type: int?
    // 0x45f194: r3 = Null
    //     0x45f194: add             x3, PP, #0x10, lsl #12  ; [pp+0x10a78] Null
    //     0x45f198: ldr             x3, [x3, #0xa78]
    // 0x45f19c: r0 = int?()
    //     0x45f19c: bl              #0x82bac8  ; IsType_int?_Stub
    // 0x45f1a0: ldur            x0, [fp, #-0x100]
    // 0x45f1a4: ldur            x1, [fp, #-0xf8]
    // 0x45f1a8: StoreField: r1->field_b = r0
    //     0x45f1a8: stur            w0, [x1, #0xb]
    //     0x45f1ac: tbz             w0, #0, #0x45f1c8
    //     0x45f1b0: ldurb           w16, [x1, #-1]
    //     0x45f1b4: ldurb           w17, [x0, #-1]
    //     0x45f1b8: and             x16, x17, x16, lsr #2
    //     0x45f1bc: tst             x16, HEAP, lsr #32
    //     0x45f1c0: b.eq            #0x45f1c8
    //     0x45f1c4: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f1c8: ldur            x1, [fp, #-0xc8]
    // 0x45f1cc: ldur            x0, [fp, #-0xc0]
    // 0x45f1d0: b               #0x45f268
    // 0x45f1d4: sub             SP, fp, #0x150
    // 0x45f1d8: ldur            x3, [fp, #-0xe0]
    // 0x45f1dc: ldur            x2, [fp, #-0xf0]
    // 0x45f1e0: mov             x4, x0
    // 0x45f1e4: stur            x0, [fp, #-0xf8]
    // 0x45f1e8: stur            x1, [fp, #-0x100]
    // 0x45f1ec: r0 = LoadClassIdInstr(r3)
    //     0x45f1ec: ldur            x0, [x3, #-1]
    //     0x45f1f0: ubfx            x0, x0, #0xc, #0x14
    // 0x45f1f4: ldur            x16, [fp, #-0xe8]
    // 0x45f1f8: stp             x16, x3, [SP]
    // 0x45f1fc: r0 = GDT[cid_x0 + -0xfff]()
    //     0x45f1fc: sub             lr, x0, #0xfff
    //     0x45f200: ldr             lr, [x21, lr, lsl #3]
    //     0x45f204: blr             lr
    // 0x45f208: mov             x1, x0
    // 0x45f20c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x45f20c: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x45f210: r0 = deleteSync()
    //     0x45f210: bl              #0x456830  ; [dart:io] FileSystemEntity::deleteSync
    // 0x45f214: r1 = Null
    //     0x45f214: mov             x1, NULL
    // 0x45f218: r2 = 8
    //     0x45f218: movz            x2, #0x8
    // 0x45f21c: r0 = AllocateArray()
    //     0x45f21c: bl              #0x82746c  ; AllocateArrayStub
    // 0x45f220: r16 = "Unable to load "
    //     0x45f220: add             x16, PP, #0x10, lsl #12  ; [pp+0x10a88] "Unable to load "
    //     0x45f224: ldr             x16, [x16, #0xa88]
    // 0x45f228: StoreField: r0->field_f = r16
    //     0x45f228: stur            w16, [x0, #0xf]
    // 0x45f22c: ldur            x1, [fp, #-0xf0]
    // 0x45f230: StoreField: r0->field_13 = r1
    //     0x45f230: stur            w1, [x0, #0x13]
    // 0x45f234: r16 = " due to "
    //     0x45f234: add             x16, PP, #0x10, lsl #12  ; [pp+0x10a90] " due to "
    //     0x45f238: ldr             x16, [x16, #0xa90]
    // 0x45f23c: ArrayStore: r0[0] = r16  ; List_4
    //     0x45f23c: stur            w16, [x0, #0x17]
    // 0x45f240: ldur            x1, [fp, #-0xf8]
    // 0x45f244: StoreField: r0->field_1b = r1
    //     0x45f244: stur            w1, [x0, #0x1b]
    // 0x45f248: str             x0, [SP]
    // 0x45f24c: r0 = _interpolate()
    //     0x45f24c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x45f250: mov             x1, x0
    // 0x45f254: ldur            x2, [fp, #-0x100]
    // 0x45f258: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x45f258: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x45f25c: r0 = crashlyticsRecordError()
    //     0x45f25c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x45f260: ldur            x1, [fp, #-0x100]
    // 0x45f264: ldur            x0, [fp, #-0xf8]
    // 0x45f268: mov             x5, x1
    // 0x45f26c: mov             x6, x0
    // 0x45f270: ldur            x2, [fp, #-0xd0]
    // 0x45f274: add             x7, x2, #1
    // 0x45f278: ldur            x2, [fp, #-0xe0]
    // 0x45f27c: ldur            x3, [fp, #-0xd8]
    // 0x45f280: r1 = Instance_BinaryCodec
    //     0x45f280: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb80] Obj!BinaryCodec@85e381
    //     0x45f284: ldr             x1, [x1, #0xb80]
    // 0x45f288: b               #0x45e8ec
    // 0x45f28c: r0 = Null
    //     0x45f28c: mov             x0, NULL
    // 0x45f290: r0 = ReturnAsyncNotFuture()
    //     0x45f290: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x45f294: ldur            x2, [fp, #-0xd0]
    // 0x45f298: r0 = RangeError()
    //     0x45f298: bl              #0x3292cc  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x45f29c: stur            x0, [fp, #-0xf8]
    // 0x45f2a0: stp             xzr, x0, [SP, #0x10]
    // 0x45f2a4: r17 = -304
    //     0x45f2a4: movn            x17, #0x12f
    // 0x45f2a8: ldr             x16, [fp, x17]
    // 0x45f2ac: stp             x16, xzr, [SP]
    // 0x45f2b0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x45f2b0: ldr             x4, [PP, #0x618]  ; [pp+0x618] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x45f2b4: r0 = RangeError.range()
    //     0x45f2b4: bl              #0x32914c  ; [dart:core] RangeError::RangeError.range
    // 0x45f2b8: ldur            x0, [fp, #-0xf8]
    // 0x45f2bc: r0 = Throw()
    //     0x45f2bc: bl              #0x825670  ; ThrowStub
    // 0x45f2c0: brk             #0
    // 0x45f2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x45f2c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x45f2c8: b               #0x45e830
    // 0x45f2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x45f2cc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x45f2d0: b               #0x45e908
    // 0x45f2d4: r9 = coreData
    //     0x45f2d4: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x45f2d8: ldr             x9, [x9, #0x530]
    // 0x45f2dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x45f2dc: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x45f2e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x45f2e0: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set void currentChapterName=(String) {
    // ** addr: 0x48fdfc, size: 0xcc
    // 0x48fdfc: EnterFrame
    //     0x48fdfc: stp             fp, lr, [SP, #-0x10]!
    //     0x48fe00: mov             fp, SP
    // 0x48fe04: AllocStack(0x10)
    //     0x48fe04: sub             SP, SP, #0x10
    // 0x48fe08: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x48fe08: mov             x2, x1
    //     0x48fe0c: stur            x1, [fp, #-8]
    // 0x48fe10: CheckStackOverflow
    //     0x48fe10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x48fe14: cmp             SP, x16
    //     0x48fe18: b.ls            #0x48fec0
    // 0x48fe1c: r0 = currentActiveState()
    //     0x48fe1c: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x48fe20: stur            x0, [fp, #-0x10]
    // 0x48fe24: r0 = _getCurrentMicros()
    //     0x48fe24: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x48fe28: r1 = LoadInt32Instr(r0)
    //     0x48fe28: sbfx            x1, x0, #1, #0x1f
    //     0x48fe2c: tbz             w0, #0, #0x48fe34
    //     0x48fe30: ldur            x1, [x0, #7]
    // 0x48fe34: tbz             x1, #0x3f, #0x48fe40
    // 0x48fe38: r3 = 999
    //     0x48fe38: movz            x3, #0x3e7
    // 0x48fe3c: b               #0x48fe44
    // 0x48fe40: r3 = 0
    //     0x48fe40: movz            x3, #0
    // 0x48fe44: ldur            x2, [fp, #-0x10]
    // 0x48fe48: r0 = 1000
    //     0x48fe48: movz            x0, #0x3e8
    // 0x48fe4c: sub             x4, x1, x3
    // 0x48fe50: sdiv            x3, x4, x0
    // 0x48fe54: r0 = BoxInt64Instr(r3)
    //     0x48fe54: sbfiz           x0, x3, #1, #0x1f
    //     0x48fe58: cmp             x3, x0, asr #1
    //     0x48fe5c: b.eq            #0x48fe68
    //     0x48fe60: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x48fe64: stur            x3, [x0, #7]
    // 0x48fe68: StoreField: r2->field_b = r0
    //     0x48fe68: stur            w0, [x2, #0xb]
    //     0x48fe6c: tbz             w0, #0, #0x48fe88
    //     0x48fe70: ldurb           w16, [x2, #-1]
    //     0x48fe74: ldurb           w17, [x0, #-1]
    //     0x48fe78: and             x16, x17, x16, lsr #2
    //     0x48fe7c: tst             x16, HEAP, lsr #32
    //     0x48fe80: b.eq            #0x48fe88
    //     0x48fe84: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x48fe88: r0 = currentActiveState()
    //     0x48fe88: bl              #0x372284  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentActiveState
    // 0x48fe8c: mov             x1, x0
    // 0x48fe90: r0 = saveImmediately()
    //     0x48fe90: bl              #0x353020  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveImmediately
    // 0x48fe94: r2 = Null
    //     0x48fe94: mov             x2, NULL
    // 0x48fe98: StoreStaticField(0x105c, r2)
    //     0x48fe98: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x48fe9c: str             x2, [x0, #0x20b8]
    // 0x48fea0: ldur            x2, [fp, #-8]
    // 0x48fea4: r1 = "ActNum"
    //     0x48fea4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb38] "ActNum"
    //     0x48fea8: ldr             x1, [x1, #0xb38]
    // 0x48feac: r0 = prefsSetString()
    //     0x48feac: bl              #0x456dd0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsSetString
    // 0x48feb0: r0 = Null
    //     0x48feb0: mov             x0, NULL
    // 0x48feb4: LeaveFrame
    //     0x48feb4: mov             SP, fp
    //     0x48feb8: ldp             fp, lr, [SP], #0x10
    // 0x48febc: ret
    //     0x48febc: ret             
    // 0x48fec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x48fec0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x48fec4: b               #0x48fe1c
  }
  static bool chapterUnlocked(int) {
    // ** addr: 0x5949ec, size: 0x470
    // 0x5949ec: EnterFrame
    //     0x5949ec: stp             fp, lr, [SP, #-0x10]!
    //     0x5949f0: mov             fp, SP
    // 0x5949f4: AllocStack(0x18)
    //     0x5949f4: sub             SP, SP, #0x18
    // 0x5949f8: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x5949f8: mov             x3, x1
    //     0x5949fc: stur            x1, [fp, #-8]
    // 0x594a00: CheckStackOverflow
    //     0x594a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x594a04: cmp             SP, x16
    //     0x594a08: b.ls            #0x594da0
    // 0x594a0c: tbnz            x3, #0x3f, #0x594d38
    // 0x594a10: cmp             x3, #0x11
    // 0x594a14: b.gt            #0x594d38
    // 0x594a18: r0 = BoxInt64Instr(r3)
    //     0x594a18: sbfiz           x0, x3, #1, #0x1f
    //     0x594a1c: cmp             x3, x0, asr #1
    //     0x594a20: b.eq            #0x594a2c
    //     0x594a24: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x594a28: stur            x3, [x0, #7]
    // 0x594a2c: r1 = _Int32List
    //     0x594a2c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2a590] _Int32List(18) [0x34c, 0x5c, 0x6c, 0x9c, 0xcc, 0xfc, 0x12c, 0x15c, 0x18c, 0x1bc, 0x1ec, 0x21c, 0x24c, 0x27c, 0x2ac, 0x2dc, 0x30c, 0x33c]
    //     0x594a30: ldr             x1, [x1, #0x590]
    // 0x594a34: ArrayLoad: r1 = r1[r0]  ; TypedSigned_4
    //     0x594a34: add             x16, x1, w0, sxtw #1
    //     0x594a38: ldursw          x1, [x16, #0x17]
    // 0x594a3c: adr             x2, #0x5949ec
    // 0x594a40: add             x2, x2, x1
    // 0x594a44: br              x2
    // 0x594a48: r0 = true
    //     0x594a48: add             x0, NULL, #0x20  ; true
    // 0x594a4c: LeaveFrame
    //     0x594a4c: mov             SP, fp
    //     0x594a50: ldp             fp, lr, [SP], #0x10
    // 0x594a54: ret
    //     0x594a54: ret             
    // 0x594a58: r0 = LoadStaticField(0xf7c)
    //     0x594a58: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594a5c: ldr             x0, [x0, #0x1ef8]
    // 0x594a60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594a64: cmp             w0, w16
    // 0x594a68: b.eq            #0x594da8
    // 0x594a6c: LoadField: r1 = r0->field_13
    //     0x594a6c: ldur            w1, [x0, #0x13]
    // 0x594a70: DecompressPointer r1
    //     0x594a70: add             x1, x1, HEAP, lsl #32
    // 0x594a74: r2 = 2
    //     0x594a74: movz            x2, #0x2
    // 0x594a78: r0 = containsKey()
    //     0x594a78: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594a7c: LeaveFrame
    //     0x594a7c: mov             SP, fp
    //     0x594a80: ldp             fp, lr, [SP], #0x10
    // 0x594a84: ret
    //     0x594a84: ret             
    // 0x594a88: r0 = LoadStaticField(0xf7c)
    //     0x594a88: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594a8c: ldr             x0, [x0, #0x1ef8]
    // 0x594a90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594a94: cmp             w0, w16
    // 0x594a98: b.eq            #0x594db4
    // 0x594a9c: LoadField: r1 = r0->field_13
    //     0x594a9c: ldur            w1, [x0, #0x13]
    // 0x594aa0: DecompressPointer r1
    //     0x594aa0: add             x1, x1, HEAP, lsl #32
    // 0x594aa4: r2 = 6
    //     0x594aa4: movz            x2, #0x6
    // 0x594aa8: r0 = containsKey()
    //     0x594aa8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594aac: LeaveFrame
    //     0x594aac: mov             SP, fp
    //     0x594ab0: ldp             fp, lr, [SP], #0x10
    // 0x594ab4: ret
    //     0x594ab4: ret             
    // 0x594ab8: r0 = LoadStaticField(0xf7c)
    //     0x594ab8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594abc: ldr             x0, [x0, #0x1ef8]
    // 0x594ac0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594ac4: cmp             w0, w16
    // 0x594ac8: b.eq            #0x594dc0
    // 0x594acc: LoadField: r1 = r0->field_13
    //     0x594acc: ldur            w1, [x0, #0x13]
    // 0x594ad0: DecompressPointer r1
    //     0x594ad0: add             x1, x1, HEAP, lsl #32
    // 0x594ad4: r2 = 10
    //     0x594ad4: movz            x2, #0xa
    // 0x594ad8: r0 = containsKey()
    //     0x594ad8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594adc: LeaveFrame
    //     0x594adc: mov             SP, fp
    //     0x594ae0: ldp             fp, lr, [SP], #0x10
    // 0x594ae4: ret
    //     0x594ae4: ret             
    // 0x594ae8: r0 = LoadStaticField(0xf7c)
    //     0x594ae8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594aec: ldr             x0, [x0, #0x1ef8]
    // 0x594af0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594af4: cmp             w0, w16
    // 0x594af8: b.eq            #0x594dcc
    // 0x594afc: LoadField: r1 = r0->field_13
    //     0x594afc: ldur            w1, [x0, #0x13]
    // 0x594b00: DecompressPointer r1
    //     0x594b00: add             x1, x1, HEAP, lsl #32
    // 0x594b04: r2 = 16
    //     0x594b04: movz            x2, #0x10
    // 0x594b08: r0 = containsKey()
    //     0x594b08: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594b0c: LeaveFrame
    //     0x594b0c: mov             SP, fp
    //     0x594b10: ldp             fp, lr, [SP], #0x10
    // 0x594b14: ret
    //     0x594b14: ret             
    // 0x594b18: r0 = LoadStaticField(0xf7c)
    //     0x594b18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594b1c: ldr             x0, [x0, #0x1ef8]
    // 0x594b20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594b24: cmp             w0, w16
    // 0x594b28: b.eq            #0x594dd8
    // 0x594b2c: LoadField: r1 = r0->field_13
    //     0x594b2c: ldur            w1, [x0, #0x13]
    // 0x594b30: DecompressPointer r1
    //     0x594b30: add             x1, x1, HEAP, lsl #32
    // 0x594b34: r2 = 20
    //     0x594b34: movz            x2, #0x14
    // 0x594b38: r0 = containsKey()
    //     0x594b38: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594b3c: LeaveFrame
    //     0x594b3c: mov             SP, fp
    //     0x594b40: ldp             fp, lr, [SP], #0x10
    // 0x594b44: ret
    //     0x594b44: ret             
    // 0x594b48: r0 = LoadStaticField(0xf7c)
    //     0x594b48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594b4c: ldr             x0, [x0, #0x1ef8]
    // 0x594b50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594b54: cmp             w0, w16
    // 0x594b58: b.eq            #0x594de4
    // 0x594b5c: LoadField: r1 = r0->field_13
    //     0x594b5c: ldur            w1, [x0, #0x13]
    // 0x594b60: DecompressPointer r1
    //     0x594b60: add             x1, x1, HEAP, lsl #32
    // 0x594b64: r2 = 24
    //     0x594b64: movz            x2, #0x18
    // 0x594b68: r0 = containsKey()
    //     0x594b68: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594b6c: LeaveFrame
    //     0x594b6c: mov             SP, fp
    //     0x594b70: ldp             fp, lr, [SP], #0x10
    // 0x594b74: ret
    //     0x594b74: ret             
    // 0x594b78: r0 = LoadStaticField(0xf7c)
    //     0x594b78: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594b7c: ldr             x0, [x0, #0x1ef8]
    // 0x594b80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594b84: cmp             w0, w16
    // 0x594b88: b.eq            #0x594df0
    // 0x594b8c: LoadField: r1 = r0->field_13
    //     0x594b8c: ldur            w1, [x0, #0x13]
    // 0x594b90: DecompressPointer r1
    //     0x594b90: add             x1, x1, HEAP, lsl #32
    // 0x594b94: r2 = 30
    //     0x594b94: movz            x2, #0x1e
    // 0x594b98: r0 = containsKey()
    //     0x594b98: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594b9c: LeaveFrame
    //     0x594b9c: mov             SP, fp
    //     0x594ba0: ldp             fp, lr, [SP], #0x10
    // 0x594ba4: ret
    //     0x594ba4: ret             
    // 0x594ba8: r0 = LoadStaticField(0xf7c)
    //     0x594ba8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594bac: ldr             x0, [x0, #0x1ef8]
    // 0x594bb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594bb4: cmp             w0, w16
    // 0x594bb8: b.eq            #0x594dfc
    // 0x594bbc: LoadField: r1 = r0->field_13
    //     0x594bbc: ldur            w1, [x0, #0x13]
    // 0x594bc0: DecompressPointer r1
    //     0x594bc0: add             x1, x1, HEAP, lsl #32
    // 0x594bc4: r2 = 36
    //     0x594bc4: movz            x2, #0x24
    // 0x594bc8: r0 = containsKey()
    //     0x594bc8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594bcc: LeaveFrame
    //     0x594bcc: mov             SP, fp
    //     0x594bd0: ldp             fp, lr, [SP], #0x10
    // 0x594bd4: ret
    //     0x594bd4: ret             
    // 0x594bd8: r0 = LoadStaticField(0xf7c)
    //     0x594bd8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594bdc: ldr             x0, [x0, #0x1ef8]
    // 0x594be0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594be4: cmp             w0, w16
    // 0x594be8: b.eq            #0x594e08
    // 0x594bec: LoadField: r1 = r0->field_13
    //     0x594bec: ldur            w1, [x0, #0x13]
    // 0x594bf0: DecompressPointer r1
    //     0x594bf0: add             x1, x1, HEAP, lsl #32
    // 0x594bf4: r2 = 40
    //     0x594bf4: movz            x2, #0x28
    // 0x594bf8: r0 = containsKey()
    //     0x594bf8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594bfc: LeaveFrame
    //     0x594bfc: mov             SP, fp
    //     0x594c00: ldp             fp, lr, [SP], #0x10
    // 0x594c04: ret
    //     0x594c04: ret             
    // 0x594c08: r0 = LoadStaticField(0xf7c)
    //     0x594c08: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594c0c: ldr             x0, [x0, #0x1ef8]
    // 0x594c10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594c14: cmp             w0, w16
    // 0x594c18: b.eq            #0x594e14
    // 0x594c1c: LoadField: r1 = r0->field_13
    //     0x594c1c: ldur            w1, [x0, #0x13]
    // 0x594c20: DecompressPointer r1
    //     0x594c20: add             x1, x1, HEAP, lsl #32
    // 0x594c24: r2 = 44
    //     0x594c24: movz            x2, #0x2c
    // 0x594c28: r0 = containsKey()
    //     0x594c28: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594c2c: LeaveFrame
    //     0x594c2c: mov             SP, fp
    //     0x594c30: ldp             fp, lr, [SP], #0x10
    // 0x594c34: ret
    //     0x594c34: ret             
    // 0x594c38: r0 = LoadStaticField(0xf7c)
    //     0x594c38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594c3c: ldr             x0, [x0, #0x1ef8]
    // 0x594c40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594c44: cmp             w0, w16
    // 0x594c48: b.eq            #0x594e20
    // 0x594c4c: LoadField: r1 = r0->field_13
    //     0x594c4c: ldur            w1, [x0, #0x13]
    // 0x594c50: DecompressPointer r1
    //     0x594c50: add             x1, x1, HEAP, lsl #32
    // 0x594c54: r2 = 48
    //     0x594c54: movz            x2, #0x30
    // 0x594c58: r0 = containsKey()
    //     0x594c58: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594c5c: LeaveFrame
    //     0x594c5c: mov             SP, fp
    //     0x594c60: ldp             fp, lr, [SP], #0x10
    // 0x594c64: ret
    //     0x594c64: ret             
    // 0x594c68: r0 = LoadStaticField(0xf7c)
    //     0x594c68: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594c6c: ldr             x0, [x0, #0x1ef8]
    // 0x594c70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594c74: cmp             w0, w16
    // 0x594c78: b.eq            #0x594e2c
    // 0x594c7c: LoadField: r1 = r0->field_13
    //     0x594c7c: ldur            w1, [x0, #0x13]
    // 0x594c80: DecompressPointer r1
    //     0x594c80: add             x1, x1, HEAP, lsl #32
    // 0x594c84: r2 = 52
    //     0x594c84: movz            x2, #0x34
    // 0x594c88: r0 = containsKey()
    //     0x594c88: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594c8c: LeaveFrame
    //     0x594c8c: mov             SP, fp
    //     0x594c90: ldp             fp, lr, [SP], #0x10
    // 0x594c94: ret
    //     0x594c94: ret             
    // 0x594c98: r0 = LoadStaticField(0xf7c)
    //     0x594c98: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594c9c: ldr             x0, [x0, #0x1ef8]
    // 0x594ca0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594ca4: cmp             w0, w16
    // 0x594ca8: b.eq            #0x594e38
    // 0x594cac: LoadField: r1 = r0->field_13
    //     0x594cac: ldur            w1, [x0, #0x13]
    // 0x594cb0: DecompressPointer r1
    //     0x594cb0: add             x1, x1, HEAP, lsl #32
    // 0x594cb4: r2 = 58
    //     0x594cb4: movz            x2, #0x3a
    // 0x594cb8: r0 = containsKey()
    //     0x594cb8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594cbc: LeaveFrame
    //     0x594cbc: mov             SP, fp
    //     0x594cc0: ldp             fp, lr, [SP], #0x10
    // 0x594cc4: ret
    //     0x594cc4: ret             
    // 0x594cc8: r0 = LoadStaticField(0xf7c)
    //     0x594cc8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594ccc: ldr             x0, [x0, #0x1ef8]
    // 0x594cd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594cd4: cmp             w0, w16
    // 0x594cd8: b.eq            #0x594e44
    // 0x594cdc: LoadField: r1 = r0->field_13
    //     0x594cdc: ldur            w1, [x0, #0x13]
    // 0x594ce0: DecompressPointer r1
    //     0x594ce0: add             x1, x1, HEAP, lsl #32
    // 0x594ce4: r2 = 64
    //     0x594ce4: movz            x2, #0x40
    // 0x594ce8: r0 = containsKey()
    //     0x594ce8: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594cec: LeaveFrame
    //     0x594cec: mov             SP, fp
    //     0x594cf0: ldp             fp, lr, [SP], #0x10
    // 0x594cf4: ret
    //     0x594cf4: ret             
    // 0x594cf8: r0 = LoadStaticField(0xf7c)
    //     0x594cf8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x594cfc: ldr             x0, [x0, #0x1ef8]
    // 0x594d00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x594d04: cmp             w0, w16
    // 0x594d08: b.eq            #0x594e50
    // 0x594d0c: LoadField: r1 = r0->field_13
    //     0x594d0c: ldur            w1, [x0, #0x13]
    // 0x594d10: DecompressPointer r1
    //     0x594d10: add             x1, x1, HEAP, lsl #32
    // 0x594d14: r2 = 68
    //     0x594d14: movz            x2, #0x44
    // 0x594d18: r0 = containsKey()
    //     0x594d18: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x594d1c: LeaveFrame
    //     0x594d1c: mov             SP, fp
    //     0x594d20: ldp             fp, lr, [SP], #0x10
    // 0x594d24: ret
    //     0x594d24: ret             
    // 0x594d28: r0 = false
    //     0x594d28: add             x0, NULL, #0x30  ; false
    // 0x594d2c: LeaveFrame
    //     0x594d2c: mov             SP, fp
    //     0x594d30: ldp             fp, lr, [SP], #0x10
    // 0x594d34: ret
    //     0x594d34: ret             
    // 0x594d38: r1 = Null
    //     0x594d38: mov             x1, NULL
    // 0x594d3c: r2 = 4
    //     0x594d3c: movz            x2, #0x4
    // 0x594d40: r0 = AllocateArray()
    //     0x594d40: bl              #0x82746c  ; AllocateArrayStub
    // 0x594d44: mov             x2, x0
    // 0x594d48: r16 = "Unknown act num: "
    //     0x594d48: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a1b8] "Unknown act num: "
    //     0x594d4c: ldr             x16, [x16, #0x1b8]
    // 0x594d50: StoreField: r2->field_f = r16
    //     0x594d50: stur            w16, [x2, #0xf]
    // 0x594d54: ldur            x3, [fp, #-8]
    // 0x594d58: r0 = BoxInt64Instr(r3)
    //     0x594d58: sbfiz           x0, x3, #1, #0x1f
    //     0x594d5c: cmp             x3, x0, asr #1
    //     0x594d60: b.eq            #0x594d6c
    //     0x594d64: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x594d68: stur            x3, [x0, #7]
    // 0x594d6c: StoreField: r2->field_13 = r0
    //     0x594d6c: stur            w0, [x2, #0x13]
    // 0x594d70: str             x2, [SP]
    // 0x594d74: r0 = _interpolate()
    //     0x594d74: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x594d78: stur            x0, [fp, #-0x10]
    // 0x594d7c: r0 = current()
    //     0x594d7c: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x594d80: ldur            x1, [fp, #-0x10]
    // 0x594d84: mov             x2, x0
    // 0x594d88: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x594d88: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x594d8c: r0 = crashlyticsRecordError()
    //     0x594d8c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x594d90: r0 = false
    //     0x594d90: add             x0, NULL, #0x30  ; false
    // 0x594d94: LeaveFrame
    //     0x594d94: mov             SP, fp
    //     0x594d98: ldp             fp, lr, [SP], #0x10
    // 0x594d9c: ret
    //     0x594d9c: ret             
    // 0x594da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x594da0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x594da4: b               #0x594a0c
    // 0x594da8: r9 = coreData
    //     0x594da8: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594dac: ldr             x9, [x9, #0x530]
    // 0x594db0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594db0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594db4: r9 = coreData
    //     0x594db4: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594db8: ldr             x9, [x9, #0x530]
    // 0x594dbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594dbc: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594dc0: r9 = coreData
    //     0x594dc0: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594dc4: ldr             x9, [x9, #0x530]
    // 0x594dc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594dc8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594dcc: r9 = coreData
    //     0x594dcc: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594dd0: ldr             x9, [x9, #0x530]
    // 0x594dd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594dd4: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594dd8: r9 = coreData
    //     0x594dd8: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594ddc: ldr             x9, [x9, #0x530]
    // 0x594de0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594de0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594de4: r9 = coreData
    //     0x594de4: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594de8: ldr             x9, [x9, #0x530]
    // 0x594dec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594dec: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594df0: r9 = coreData
    //     0x594df0: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594df4: ldr             x9, [x9, #0x530]
    // 0x594df8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594df8: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594dfc: r9 = coreData
    //     0x594dfc: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e00: ldr             x9, [x9, #0x530]
    // 0x594e04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e04: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e08: r9 = coreData
    //     0x594e08: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e0c: ldr             x9, [x9, #0x530]
    // 0x594e10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e10: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e14: r9 = coreData
    //     0x594e14: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e18: ldr             x9, [x9, #0x530]
    // 0x594e1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e1c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e20: r9 = coreData
    //     0x594e20: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e24: ldr             x9, [x9, #0x530]
    // 0x594e28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e28: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e2c: r9 = coreData
    //     0x594e2c: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e30: ldr             x9, [x9, #0x530]
    // 0x594e34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e34: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e38: r9 = coreData
    //     0x594e38: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e3c: ldr             x9, [x9, #0x530]
    // 0x594e40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e40: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e44: r9 = coreData
    //     0x594e44: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e48: ldr             x9, [x9, #0x530]
    // 0x594e4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e4c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x594e50: r9 = coreData
    //     0x594e50: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x594e54: ldr             x9, [x9, #0x530]
    // 0x594e58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x594e58: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<void> resetCurrentChapterAndUpdateUI(dynamic) {
    // ** addr: 0x5a207c, size: 0x2c
    // 0x5a207c: EnterFrame
    //     0x5a207c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a2080: mov             fp, SP
    // 0x5a2084: CheckStackOverflow
    //     0x5a2084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a2088: cmp             SP, x16
    //     0x5a208c: b.ls            #0x5a20a0
    // 0x5a2090: r0 = resetCurrentChapterAndUpdateUI()
    //     0x5a2090: bl              #0x5a20a8  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::resetCurrentChapterAndUpdateUI
    // 0x5a2094: LeaveFrame
    //     0x5a2094: mov             SP, fp
    //     0x5a2098: ldp             fp, lr, [SP], #0x10
    // 0x5a209c: ret
    //     0x5a209c: ret             
    // 0x5a20a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a20a0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a20a4: b               #0x5a2090
  }
  static Future<void> resetCurrentChapterAndUpdateUI() async {
    // ** addr: 0x5a20a8, size: 0x64
    // 0x5a20a8: EnterFrame
    //     0x5a20a8: stp             fp, lr, [SP, #-0x10]!
    //     0x5a20ac: mov             fp, SP
    // 0x5a20b0: AllocStack(0x18)
    //     0x5a20b0: sub             SP, SP, #0x18
    // 0x5a20b4: SetupParameters()
    //     0x5a20b4: stur            NULL, [fp, #-8]
    // 0x5a20b8: CheckStackOverflow
    //     0x5a20b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a20bc: cmp             SP, x16
    //     0x5a20c0: b.ls            #0x5a2104
    // 0x5a20c4: InitAsync() -> Future<void?>
    //     0x5a20c4: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x5a20c8: bl              #0x34b9a0  ; InitAsyncStub
    // 0x5a20cc: r0 = currentChapterName()
    //     0x5a20cc: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x5a20d0: mov             x1, x0
    // 0x5a20d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5a20d4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5a20d8: r0 = resetGivenChapter()
    //     0x5a20d8: bl              #0x5a210c  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::resetGivenChapter
    // 0x5a20dc: mov             x1, x0
    // 0x5a20e0: stur            x1, [fp, #-0x10]
    // 0x5a20e4: r0 = Await()
    //     0x5a20e4: bl              #0x34b75c  ; AwaitStub
    // 0x5a20e8: r16 = <ChapterViewportState>
    //     0x5a20e8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9e0] TypeArguments: <ChapterViewportState>
    //     0x5a20ec: ldr             x16, [x16, #0x9e0]
    // 0x5a20f0: str             x16, [SP]
    // 0x5a20f4: r4 = const [0x1, 0, 0, 0, null]
    //     0x5a20f4: ldr             x4, [PP, #0x48]  ; [pp+0x48] List(5) [0x1, 0, 0, 0, Null]
    // 0x5a20f8: r0 = updateAll()
    //     0x5a20f8: bl              #0x4589c0  ; [package:state_groups/src/sync_state.dart] ::updateAll
    // 0x5a20fc: r0 = Null
    //     0x5a20fc: mov             x0, NULL
    // 0x5a2100: r0 = ReturnAsyncNotFuture()
    //     0x5a2100: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x5a2104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a2104: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a2108: b               #0x5a20c4
  }
  static _ resetGivenChapter(/* No info */) async {
    // ** addr: 0x5a210c, size: 0x1068
    // 0x5a210c: EnterFrame
    //     0x5a210c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a2110: mov             fp, SP
    // 0x5a2114: AllocStack(0x38)
    //     0x5a2114: sub             SP, SP, #0x38
    // 0x5a2118: SetupParameters(dynamic _ /* r1 => r1, fp-0x18 */, {dynamic ignoreError = false /* r2, fp-0x10 */})
    //     0x5a2118: stur            NULL, [fp, #-8]
    //     0x5a211c: stur            x1, [fp, #-0x18]
    //     0x5a2120: ldur            w0, [x4, #0x13]
    //     0x5a2124: ldur            w2, [x4, #0x1f]
    //     0x5a2128: add             x2, x2, HEAP, lsl #32
    //     0x5a212c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f2b0] "ignoreError"
    //     0x5a2130: ldr             x16, [x16, #0x2b0]
    //     0x5a2134: cmp             w2, w16
    //     0x5a2138: b.ne            #0x5a2158
    //     0x5a213c: ldur            w2, [x4, #0x23]
    //     0x5a2140: add             x2, x2, HEAP, lsl #32
    //     0x5a2144: sub             w3, w0, w2
    //     0x5a2148: add             x0, fp, w3, sxtw #2
    //     0x5a214c: ldr             x0, [x0, #8]
    //     0x5a2150: mov             x2, x0
    //     0x5a2154: b               #0x5a215c
    //     0x5a2158: add             x2, NULL, #0x30  ; false
    //     0x5a215c: stur            x2, [fp, #-0x10]
    // 0x5a2160: CheckStackOverflow
    //     0x5a2160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5a2164: cmp             SP, x16
    //     0x5a2168: b.ls            #0x5a3168
    // 0x5a216c: InitAsync() -> Future<void?>
    //     0x5a216c: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x5a2170: bl              #0x34b9a0  ; InitAsyncStub
    // 0x5a2174: r16 = "1"
    //     0x5a2174: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x5a2178: ldr             x16, [x16, #0x9c8]
    // 0x5a217c: ldur            lr, [fp, #-0x18]
    // 0x5a2180: stp             lr, x16, [SP]
    // 0x5a2184: r0 = ==()
    //     0x5a2184: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2188: tbnz            w0, #4, #0x5a224c
    // 0x5a218c: r1 = <Stat>
    //     0x5a218c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x5a2190: ldr             x1, [x1, #0xca0]
    // 0x5a2194: r0 = Chapter1GameState()
    //     0x5a2194: bl              #0x473040  ; AllocateChapter1GameStateStub -> Chapter1GameState (size=0xa8)
    // 0x5a2198: mov             x1, x0
    // 0x5a219c: r2 = Null
    //     0x5a219c: mov             x2, NULL
    // 0x5a21a0: stur            x0, [fp, #-0x20]
    // 0x5a21a4: r0 = Chapter1GameState()
    //     0x5a21a4: bl              #0x472b54  ; [package:pretentious/data/Chapters/Chapter1GameState.dart] Chapter1GameState::Chapter1GameState
    // 0x5a21a8: r0 = LoadStaticField(0xf60)
    //     0x5a21a8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a21ac: ldr             x0, [x0, #0x1ec0]
    // 0x5a21b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a21b4: cmp             w0, w16
    // 0x5a21b8: b.ne            #0x5a21c8
    // 0x5a21bc: r2 = gameStates
    //     0x5a21bc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a21c0: ldr             x2, [x2, #0x2e8]
    // 0x5a21c4: r0 = InitLateStaticField()
    //     0x5a21c4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a21c8: mov             x1, x0
    // 0x5a21cc: r2 = 2
    //     0x5a21cc: movz            x2, #0x2
    // 0x5a21d0: stur            x0, [fp, #-0x28]
    // 0x5a21d4: r0 = _getValueOrData()
    //     0x5a21d4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a21d8: mov             x1, x0
    // 0x5a21dc: ldur            x0, [fp, #-0x28]
    // 0x5a21e0: LoadField: r2 = r0->field_f
    //     0x5a21e0: ldur            w2, [x0, #0xf]
    // 0x5a21e4: DecompressPointer r2
    //     0x5a21e4: add             x2, x2, HEAP, lsl #32
    // 0x5a21e8: cmp             w2, w1
    // 0x5a21ec: b.ne            #0x5a21f4
    // 0x5a21f0: r1 = Null
    //     0x5a21f0: mov             x1, NULL
    // 0x5a21f4: cmp             w1, NULL
    // 0x5a21f8: b.eq            #0x5a2220
    // 0x5a21fc: r0 = LoadClassIdInstr(r1)
    //     0x5a21fc: ldur            x0, [x1, #-1]
    //     0x5a2200: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2204: r16 = false
    //     0x5a2204: add             x16, NULL, #0x30  ; false
    // 0x5a2208: str             x16, [SP]
    // 0x5a220c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a220c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2210: ldr             x4, [x4, #0x2b8]
    // 0x5a2214: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2214: sub             lr, x0, #0xe63
    //     0x5a2218: ldr             lr, [x21, lr, lsl #3]
    //     0x5a221c: blr             lr
    // 0x5a2220: r1 = LoadStaticField(0xf60)
    //     0x5a2220: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2224: ldr             x1, [x1, #0x1ec0]
    // 0x5a2228: ldur            x3, [fp, #-0x20]
    // 0x5a222c: r2 = 2
    //     0x5a222c: movz            x2, #0x2
    // 0x5a2230: r0 = []=()
    //     0x5a2230: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2234: ldur            x1, [fp, #-0x20]
    // 0x5a2238: r0 = deleteSaveFiles()
    //     0x5a2238: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a223c: mov             x1, x0
    // 0x5a2240: stur            x1, [fp, #-0x20]
    // 0x5a2244: r0 = Await()
    //     0x5a2244: bl              #0x34b75c  ; AwaitStub
    // 0x5a2248: b               #0x5a3160
    // 0x5a224c: r16 = "2"
    //     0x5a224c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x5a2250: ldr             x16, [x16, #0x2e0]
    // 0x5a2254: ldur            lr, [fp, #-0x18]
    // 0x5a2258: stp             lr, x16, [SP]
    // 0x5a225c: r0 = ==()
    //     0x5a225c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2260: tbnz            w0, #4, #0x5a2324
    // 0x5a2264: r1 = <Stat>
    //     0x5a2264: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x5a2268: ldr             x1, [x1, #0xca0]
    // 0x5a226c: r0 = Chapter2GameState()
    //     0x5a226c: bl              #0x472b48  ; AllocateChapter2GameStateStub -> Chapter2GameState (size=0x9c)
    // 0x5a2270: mov             x1, x0
    // 0x5a2274: r2 = Null
    //     0x5a2274: mov             x2, NULL
    // 0x5a2278: stur            x0, [fp, #-0x20]
    // 0x5a227c: r0 = Chapter2GameState()
    //     0x5a227c: bl              #0x471788  ; [package:pretentious/data/Chapters/Chapter2GameState.dart] Chapter2GameState::Chapter2GameState
    // 0x5a2280: r0 = LoadStaticField(0xf60)
    //     0x5a2280: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2284: ldr             x0, [x0, #0x1ec0]
    // 0x5a2288: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a228c: cmp             w0, w16
    // 0x5a2290: b.ne            #0x5a22a0
    // 0x5a2294: r2 = gameStates
    //     0x5a2294: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2298: ldr             x2, [x2, #0x2e8]
    // 0x5a229c: r0 = InitLateStaticField()
    //     0x5a229c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a22a0: mov             x1, x0
    // 0x5a22a4: r2 = 4
    //     0x5a22a4: movz            x2, #0x4
    // 0x5a22a8: stur            x0, [fp, #-0x28]
    // 0x5a22ac: r0 = _getValueOrData()
    //     0x5a22ac: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a22b0: mov             x1, x0
    // 0x5a22b4: ldur            x0, [fp, #-0x28]
    // 0x5a22b8: LoadField: r2 = r0->field_f
    //     0x5a22b8: ldur            w2, [x0, #0xf]
    // 0x5a22bc: DecompressPointer r2
    //     0x5a22bc: add             x2, x2, HEAP, lsl #32
    // 0x5a22c0: cmp             w2, w1
    // 0x5a22c4: b.ne            #0x5a22cc
    // 0x5a22c8: r1 = Null
    //     0x5a22c8: mov             x1, NULL
    // 0x5a22cc: cmp             w1, NULL
    // 0x5a22d0: b.eq            #0x5a22f8
    // 0x5a22d4: r0 = LoadClassIdInstr(r1)
    //     0x5a22d4: ldur            x0, [x1, #-1]
    //     0x5a22d8: ubfx            x0, x0, #0xc, #0x14
    // 0x5a22dc: r16 = false
    //     0x5a22dc: add             x16, NULL, #0x30  ; false
    // 0x5a22e0: str             x16, [SP]
    // 0x5a22e4: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a22e4: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a22e8: ldr             x4, [x4, #0x2b8]
    // 0x5a22ec: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a22ec: sub             lr, x0, #0xe63
    //     0x5a22f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5a22f4: blr             lr
    // 0x5a22f8: r1 = LoadStaticField(0xf60)
    //     0x5a22f8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a22fc: ldr             x1, [x1, #0x1ec0]
    // 0x5a2300: ldur            x3, [fp, #-0x20]
    // 0x5a2304: r2 = 4
    //     0x5a2304: movz            x2, #0x4
    // 0x5a2308: r0 = []=()
    //     0x5a2308: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a230c: ldur            x1, [fp, #-0x20]
    // 0x5a2310: r0 = deleteSaveFiles()
    //     0x5a2310: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2314: mov             x1, x0
    // 0x5a2318: stur            x1, [fp, #-0x20]
    // 0x5a231c: r0 = Await()
    //     0x5a231c: bl              #0x34b75c  ; AwaitStub
    // 0x5a2320: b               #0x5a3160
    // 0x5a2324: r16 = "3"
    //     0x5a2324: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x5a2328: ldr             x16, [x16, #0x2f0]
    // 0x5a232c: ldur            lr, [fp, #-0x18]
    // 0x5a2330: stp             lr, x16, [SP]
    // 0x5a2334: r0 = ==()
    //     0x5a2334: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2338: tbnz            w0, #4, #0x5a23fc
    // 0x5a233c: r1 = <Stat>
    //     0x5a233c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x5a2340: ldr             x1, [x1, #0xca0]
    // 0x5a2344: r0 = Chapter3GameState()
    //     0x5a2344: bl              #0x47177c  ; AllocateChapter3GameStateStub -> Chapter3GameState (size=0x8c)
    // 0x5a2348: mov             x1, x0
    // 0x5a234c: r2 = Null
    //     0x5a234c: mov             x2, NULL
    // 0x5a2350: stur            x0, [fp, #-0x20]
    // 0x5a2354: r0 = Chapter3GameState()
    //     0x5a2354: bl              #0x4714b8  ; [package:pretentious/data/Chapters/Chapter3GameState.dart] Chapter3GameState::Chapter3GameState
    // 0x5a2358: r0 = LoadStaticField(0xf60)
    //     0x5a2358: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a235c: ldr             x0, [x0, #0x1ec0]
    // 0x5a2360: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2364: cmp             w0, w16
    // 0x5a2368: b.ne            #0x5a2378
    // 0x5a236c: r2 = gameStates
    //     0x5a236c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2370: ldr             x2, [x2, #0x2e8]
    // 0x5a2374: r0 = InitLateStaticField()
    //     0x5a2374: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2378: mov             x1, x0
    // 0x5a237c: r2 = 6
    //     0x5a237c: movz            x2, #0x6
    // 0x5a2380: stur            x0, [fp, #-0x28]
    // 0x5a2384: r0 = _getValueOrData()
    //     0x5a2384: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2388: mov             x1, x0
    // 0x5a238c: ldur            x0, [fp, #-0x28]
    // 0x5a2390: LoadField: r2 = r0->field_f
    //     0x5a2390: ldur            w2, [x0, #0xf]
    // 0x5a2394: DecompressPointer r2
    //     0x5a2394: add             x2, x2, HEAP, lsl #32
    // 0x5a2398: cmp             w2, w1
    // 0x5a239c: b.ne            #0x5a23a4
    // 0x5a23a0: r1 = Null
    //     0x5a23a0: mov             x1, NULL
    // 0x5a23a4: cmp             w1, NULL
    // 0x5a23a8: b.eq            #0x5a23d0
    // 0x5a23ac: r0 = LoadClassIdInstr(r1)
    //     0x5a23ac: ldur            x0, [x1, #-1]
    //     0x5a23b0: ubfx            x0, x0, #0xc, #0x14
    // 0x5a23b4: r16 = false
    //     0x5a23b4: add             x16, NULL, #0x30  ; false
    // 0x5a23b8: str             x16, [SP]
    // 0x5a23bc: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a23bc: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a23c0: ldr             x4, [x4, #0x2b8]
    // 0x5a23c4: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a23c4: sub             lr, x0, #0xe63
    //     0x5a23c8: ldr             lr, [x21, lr, lsl #3]
    //     0x5a23cc: blr             lr
    // 0x5a23d0: r1 = LoadStaticField(0xf60)
    //     0x5a23d0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a23d4: ldr             x1, [x1, #0x1ec0]
    // 0x5a23d8: ldur            x3, [fp, #-0x20]
    // 0x5a23dc: r2 = 6
    //     0x5a23dc: movz            x2, #0x6
    // 0x5a23e0: r0 = []=()
    //     0x5a23e0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a23e4: ldur            x1, [fp, #-0x20]
    // 0x5a23e8: r0 = deleteSaveFiles()
    //     0x5a23e8: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a23ec: mov             x1, x0
    // 0x5a23f0: stur            x1, [fp, #-0x20]
    // 0x5a23f4: r0 = Await()
    //     0x5a23f4: bl              #0x34b75c  ; AwaitStub
    // 0x5a23f8: b               #0x5a3160
    // 0x5a23fc: r16 = "4"
    //     0x5a23fc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x5a2400: ldr             x16, [x16, #0x2f8]
    // 0x5a2404: ldur            lr, [fp, #-0x18]
    // 0x5a2408: stp             lr, x16, [SP]
    // 0x5a240c: r0 = ==()
    //     0x5a240c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2410: tbnz            w0, #4, #0x5a24d4
    // 0x5a2414: r1 = <Stat>
    //     0x5a2414: add             x1, PP, #0xf, lsl #12  ; [pp+0xfca0] TypeArguments: <Stat>
    //     0x5a2418: ldr             x1, [x1, #0xca0]
    // 0x5a241c: r0 = Chapter4GameState()
    //     0x5a241c: bl              #0x4714ac  ; AllocateChapter4GameStateStub -> Chapter4GameState (size=0xac)
    // 0x5a2420: mov             x1, x0
    // 0x5a2424: r2 = Null
    //     0x5a2424: mov             x2, NULL
    // 0x5a2428: stur            x0, [fp, #-0x20]
    // 0x5a242c: r0 = Chapter4GameState()
    //     0x5a242c: bl              #0x470ce0  ; [package:pretentious/data/Chapters/Chapter4GameState.dart] Chapter4GameState::Chapter4GameState
    // 0x5a2430: r0 = LoadStaticField(0xf60)
    //     0x5a2430: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2434: ldr             x0, [x0, #0x1ec0]
    // 0x5a2438: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a243c: cmp             w0, w16
    // 0x5a2440: b.ne            #0x5a2450
    // 0x5a2444: r2 = gameStates
    //     0x5a2444: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2448: ldr             x2, [x2, #0x2e8]
    // 0x5a244c: r0 = InitLateStaticField()
    //     0x5a244c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2450: mov             x1, x0
    // 0x5a2454: r2 = 8
    //     0x5a2454: movz            x2, #0x8
    // 0x5a2458: stur            x0, [fp, #-0x28]
    // 0x5a245c: r0 = _getValueOrData()
    //     0x5a245c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2460: mov             x1, x0
    // 0x5a2464: ldur            x0, [fp, #-0x28]
    // 0x5a2468: LoadField: r2 = r0->field_f
    //     0x5a2468: ldur            w2, [x0, #0xf]
    // 0x5a246c: DecompressPointer r2
    //     0x5a246c: add             x2, x2, HEAP, lsl #32
    // 0x5a2470: cmp             w2, w1
    // 0x5a2474: b.ne            #0x5a247c
    // 0x5a2478: r1 = Null
    //     0x5a2478: mov             x1, NULL
    // 0x5a247c: cmp             w1, NULL
    // 0x5a2480: b.eq            #0x5a24a8
    // 0x5a2484: r0 = LoadClassIdInstr(r1)
    //     0x5a2484: ldur            x0, [x1, #-1]
    //     0x5a2488: ubfx            x0, x0, #0xc, #0x14
    // 0x5a248c: r16 = false
    //     0x5a248c: add             x16, NULL, #0x30  ; false
    // 0x5a2490: str             x16, [SP]
    // 0x5a2494: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2494: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2498: ldr             x4, [x4, #0x2b8]
    // 0x5a249c: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a249c: sub             lr, x0, #0xe63
    //     0x5a24a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5a24a4: blr             lr
    // 0x5a24a8: r1 = LoadStaticField(0xf60)
    //     0x5a24a8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a24ac: ldr             x1, [x1, #0x1ec0]
    // 0x5a24b0: ldur            x3, [fp, #-0x20]
    // 0x5a24b4: r2 = 8
    //     0x5a24b4: movz            x2, #0x8
    // 0x5a24b8: r0 = []=()
    //     0x5a24b8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a24bc: ldur            x1, [fp, #-0x20]
    // 0x5a24c0: r0 = deleteSaveFiles()
    //     0x5a24c0: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a24c4: mov             x1, x0
    // 0x5a24c8: stur            x1, [fp, #-0x20]
    // 0x5a24cc: r0 = Await()
    //     0x5a24cc: bl              #0x34b75c  ; AwaitStub
    // 0x5a24d0: b               #0x5a3160
    // 0x5a24d4: r16 = "5"
    //     0x5a24d4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x5a24d8: ldr             x16, [x16, #0x300]
    // 0x5a24dc: ldur            lr, [fp, #-0x18]
    // 0x5a24e0: stp             lr, x16, [SP]
    // 0x5a24e4: r0 = ==()
    //     0x5a24e4: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a24e8: tbnz            w0, #4, #0x5a25ac
    // 0x5a24ec: r1 = <Chapter5Stat>
    //     0x5a24ec: add             x1, PP, #0xf, lsl #12  ; [pp+0xfd68] TypeArguments: <Chapter5Stat>
    //     0x5a24f0: ldr             x1, [x1, #0xd68]
    // 0x5a24f4: r0 = Chapter5GameState()
    //     0x5a24f4: bl              #0x470cd4  ; AllocateChapter5GameStateStub -> Chapter5GameState (size=0x94)
    // 0x5a24f8: mov             x1, x0
    // 0x5a24fc: r2 = Null
    //     0x5a24fc: mov             x2, NULL
    // 0x5a2500: stur            x0, [fp, #-0x20]
    // 0x5a2504: r0 = Chapter5GameState()
    //     0x5a2504: bl              #0x470344  ; [package:pretentious/data/Chapters/Chapter5GameState.dart] Chapter5GameState::Chapter5GameState
    // 0x5a2508: r0 = LoadStaticField(0xf60)
    //     0x5a2508: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a250c: ldr             x0, [x0, #0x1ec0]
    // 0x5a2510: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2514: cmp             w0, w16
    // 0x5a2518: b.ne            #0x5a2528
    // 0x5a251c: r2 = gameStates
    //     0x5a251c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2520: ldr             x2, [x2, #0x2e8]
    // 0x5a2524: r0 = InitLateStaticField()
    //     0x5a2524: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2528: mov             x1, x0
    // 0x5a252c: r2 = 10
    //     0x5a252c: movz            x2, #0xa
    // 0x5a2530: stur            x0, [fp, #-0x28]
    // 0x5a2534: r0 = _getValueOrData()
    //     0x5a2534: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2538: mov             x1, x0
    // 0x5a253c: ldur            x0, [fp, #-0x28]
    // 0x5a2540: LoadField: r2 = r0->field_f
    //     0x5a2540: ldur            w2, [x0, #0xf]
    // 0x5a2544: DecompressPointer r2
    //     0x5a2544: add             x2, x2, HEAP, lsl #32
    // 0x5a2548: cmp             w2, w1
    // 0x5a254c: b.ne            #0x5a2554
    // 0x5a2550: r1 = Null
    //     0x5a2550: mov             x1, NULL
    // 0x5a2554: cmp             w1, NULL
    // 0x5a2558: b.eq            #0x5a2580
    // 0x5a255c: r0 = LoadClassIdInstr(r1)
    //     0x5a255c: ldur            x0, [x1, #-1]
    //     0x5a2560: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2564: r16 = false
    //     0x5a2564: add             x16, NULL, #0x30  ; false
    // 0x5a2568: str             x16, [SP]
    // 0x5a256c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a256c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2570: ldr             x4, [x4, #0x2b8]
    // 0x5a2574: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2574: sub             lr, x0, #0xe63
    //     0x5a2578: ldr             lr, [x21, lr, lsl #3]
    //     0x5a257c: blr             lr
    // 0x5a2580: r1 = LoadStaticField(0xf60)
    //     0x5a2580: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2584: ldr             x1, [x1, #0x1ec0]
    // 0x5a2588: ldur            x3, [fp, #-0x20]
    // 0x5a258c: r2 = 10
    //     0x5a258c: movz            x2, #0xa
    // 0x5a2590: r0 = []=()
    //     0x5a2590: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2594: ldur            x1, [fp, #-0x20]
    // 0x5a2598: r0 = deleteSaveFiles()
    //     0x5a2598: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a259c: mov             x1, x0
    // 0x5a25a0: stur            x1, [fp, #-0x20]
    // 0x5a25a4: r0 = Await()
    //     0x5a25a4: bl              #0x34b75c  ; AwaitStub
    // 0x5a25a8: b               #0x5a3160
    // 0x5a25ac: r16 = "6"
    //     0x5a25ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x5a25b0: ldr             x16, [x16, #0x308]
    // 0x5a25b4: ldur            lr, [fp, #-0x18]
    // 0x5a25b8: stp             lr, x16, [SP]
    // 0x5a25bc: r0 = ==()
    //     0x5a25bc: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a25c0: tbnz            w0, #4, #0x5a2684
    // 0x5a25c4: r1 = <Chapter6Stat>
    //     0x5a25c4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfda0] TypeArguments: <Chapter6Stat>
    //     0x5a25c8: ldr             x1, [x1, #0xda0]
    // 0x5a25cc: r0 = Chapter6GameState()
    //     0x5a25cc: bl              #0x470338  ; AllocateChapter6GameStateStub -> Chapter6GameState (size=0xa0)
    // 0x5a25d0: mov             x1, x0
    // 0x5a25d4: r2 = Null
    //     0x5a25d4: mov             x2, NULL
    // 0x5a25d8: stur            x0, [fp, #-0x20]
    // 0x5a25dc: r0 = Chapter6GameState()
    //     0x5a25dc: bl              #0x46ffac  ; [package:pretentious/data/Chapters/Chapter6GameState.dart] Chapter6GameState::Chapter6GameState
    // 0x5a25e0: r0 = LoadStaticField(0xf60)
    //     0x5a25e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a25e4: ldr             x0, [x0, #0x1ec0]
    // 0x5a25e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a25ec: cmp             w0, w16
    // 0x5a25f0: b.ne            #0x5a2600
    // 0x5a25f4: r2 = gameStates
    //     0x5a25f4: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a25f8: ldr             x2, [x2, #0x2e8]
    // 0x5a25fc: r0 = InitLateStaticField()
    //     0x5a25fc: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2600: mov             x1, x0
    // 0x5a2604: r2 = 12
    //     0x5a2604: movz            x2, #0xc
    // 0x5a2608: stur            x0, [fp, #-0x28]
    // 0x5a260c: r0 = _getValueOrData()
    //     0x5a260c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2610: mov             x1, x0
    // 0x5a2614: ldur            x0, [fp, #-0x28]
    // 0x5a2618: LoadField: r2 = r0->field_f
    //     0x5a2618: ldur            w2, [x0, #0xf]
    // 0x5a261c: DecompressPointer r2
    //     0x5a261c: add             x2, x2, HEAP, lsl #32
    // 0x5a2620: cmp             w2, w1
    // 0x5a2624: b.ne            #0x5a262c
    // 0x5a2628: r1 = Null
    //     0x5a2628: mov             x1, NULL
    // 0x5a262c: cmp             w1, NULL
    // 0x5a2630: b.eq            #0x5a2658
    // 0x5a2634: r0 = LoadClassIdInstr(r1)
    //     0x5a2634: ldur            x0, [x1, #-1]
    //     0x5a2638: ubfx            x0, x0, #0xc, #0x14
    // 0x5a263c: r16 = false
    //     0x5a263c: add             x16, NULL, #0x30  ; false
    // 0x5a2640: str             x16, [SP]
    // 0x5a2644: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2644: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2648: ldr             x4, [x4, #0x2b8]
    // 0x5a264c: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a264c: sub             lr, x0, #0xe63
    //     0x5a2650: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2654: blr             lr
    // 0x5a2658: r1 = LoadStaticField(0xf60)
    //     0x5a2658: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a265c: ldr             x1, [x1, #0x1ec0]
    // 0x5a2660: ldur            x3, [fp, #-0x20]
    // 0x5a2664: r2 = 12
    //     0x5a2664: movz            x2, #0xc
    // 0x5a2668: r0 = []=()
    //     0x5a2668: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a266c: ldur            x1, [fp, #-0x20]
    // 0x5a2670: r0 = deleteSaveFiles()
    //     0x5a2670: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2674: mov             x1, x0
    // 0x5a2678: stur            x1, [fp, #-0x20]
    // 0x5a267c: r0 = Await()
    //     0x5a267c: bl              #0x34b75c  ; AwaitStub
    // 0x5a2680: b               #0x5a3160
    // 0x5a2684: r16 = "7"
    //     0x5a2684: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x5a2688: ldr             x16, [x16, #0x310]
    // 0x5a268c: ldur            lr, [fp, #-0x18]
    // 0x5a2690: stp             lr, x16, [SP]
    // 0x5a2694: r0 = ==()
    //     0x5a2694: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2698: tbnz            w0, #4, #0x5a275c
    // 0x5a269c: r1 = <Chapter7Stat>
    //     0x5a269c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdd8] TypeArguments: <Chapter7Stat>
    //     0x5a26a0: ldr             x1, [x1, #0xdd8]
    // 0x5a26a4: r0 = Chapter7GameState()
    //     0x5a26a4: bl              #0x46ffa0  ; AllocateChapter7GameStateStub -> Chapter7GameState (size=0x98)
    // 0x5a26a8: mov             x1, x0
    // 0x5a26ac: r2 = Null
    //     0x5a26ac: mov             x2, NULL
    // 0x5a26b0: stur            x0, [fp, #-0x20]
    // 0x5a26b4: r0 = Chapter7GameState()
    //     0x5a26b4: bl              #0x46fca8  ; [package:pretentious/data/Chapters/Chapter7GameState.dart] Chapter7GameState::Chapter7GameState
    // 0x5a26b8: r0 = LoadStaticField(0xf60)
    //     0x5a26b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a26bc: ldr             x0, [x0, #0x1ec0]
    // 0x5a26c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a26c4: cmp             w0, w16
    // 0x5a26c8: b.ne            #0x5a26d8
    // 0x5a26cc: r2 = gameStates
    //     0x5a26cc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a26d0: ldr             x2, [x2, #0x2e8]
    // 0x5a26d4: r0 = InitLateStaticField()
    //     0x5a26d4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a26d8: mov             x1, x0
    // 0x5a26dc: r2 = 14
    //     0x5a26dc: movz            x2, #0xe
    // 0x5a26e0: stur            x0, [fp, #-0x28]
    // 0x5a26e4: r0 = _getValueOrData()
    //     0x5a26e4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a26e8: mov             x1, x0
    // 0x5a26ec: ldur            x0, [fp, #-0x28]
    // 0x5a26f0: LoadField: r2 = r0->field_f
    //     0x5a26f0: ldur            w2, [x0, #0xf]
    // 0x5a26f4: DecompressPointer r2
    //     0x5a26f4: add             x2, x2, HEAP, lsl #32
    // 0x5a26f8: cmp             w2, w1
    // 0x5a26fc: b.ne            #0x5a2704
    // 0x5a2700: r1 = Null
    //     0x5a2700: mov             x1, NULL
    // 0x5a2704: cmp             w1, NULL
    // 0x5a2708: b.eq            #0x5a2730
    // 0x5a270c: r0 = LoadClassIdInstr(r1)
    //     0x5a270c: ldur            x0, [x1, #-1]
    //     0x5a2710: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2714: r16 = false
    //     0x5a2714: add             x16, NULL, #0x30  ; false
    // 0x5a2718: str             x16, [SP]
    // 0x5a271c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a271c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2720: ldr             x4, [x4, #0x2b8]
    // 0x5a2724: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2724: sub             lr, x0, #0xe63
    //     0x5a2728: ldr             lr, [x21, lr, lsl #3]
    //     0x5a272c: blr             lr
    // 0x5a2730: r1 = LoadStaticField(0xf60)
    //     0x5a2730: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2734: ldr             x1, [x1, #0x1ec0]
    // 0x5a2738: ldur            x3, [fp, #-0x20]
    // 0x5a273c: r2 = 14
    //     0x5a273c: movz            x2, #0xe
    // 0x5a2740: r0 = []=()
    //     0x5a2740: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2744: ldur            x1, [fp, #-0x20]
    // 0x5a2748: r0 = deleteSaveFiles()
    //     0x5a2748: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a274c: mov             x1, x0
    // 0x5a2750: stur            x1, [fp, #-0x20]
    // 0x5a2754: r0 = Await()
    //     0x5a2754: bl              #0x34b75c  ; AwaitStub
    // 0x5a2758: b               #0x5a3160
    // 0x5a275c: r16 = "8"
    //     0x5a275c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x5a2760: ldr             x16, [x16, #0x318]
    // 0x5a2764: ldur            lr, [fp, #-0x18]
    // 0x5a2768: stp             lr, x16, [SP]
    // 0x5a276c: r0 = ==()
    //     0x5a276c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2770: tbnz            w0, #4, #0x5a2834
    // 0x5a2774: r1 = <Chapter8Stat>
    //     0x5a2774: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe10] TypeArguments: <Chapter8Stat>
    //     0x5a2778: ldr             x1, [x1, #0xe10]
    // 0x5a277c: r0 = Chapter8GameState()
    //     0x5a277c: bl              #0x46fc9c  ; AllocateChapter8GameStateStub -> Chapter8GameState (size=0xa8)
    // 0x5a2780: mov             x1, x0
    // 0x5a2784: r2 = Null
    //     0x5a2784: mov             x2, NULL
    // 0x5a2788: stur            x0, [fp, #-0x20]
    // 0x5a278c: r0 = Chapter8GameState()
    //     0x5a278c: bl              #0x46e9e8  ; [package:pretentious/data/Chapters/Chapter8GameState.dart] Chapter8GameState::Chapter8GameState
    // 0x5a2790: r0 = LoadStaticField(0xf60)
    //     0x5a2790: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2794: ldr             x0, [x0, #0x1ec0]
    // 0x5a2798: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a279c: cmp             w0, w16
    // 0x5a27a0: b.ne            #0x5a27b0
    // 0x5a27a4: r2 = gameStates
    //     0x5a27a4: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a27a8: ldr             x2, [x2, #0x2e8]
    // 0x5a27ac: r0 = InitLateStaticField()
    //     0x5a27ac: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a27b0: mov             x1, x0
    // 0x5a27b4: r2 = 16
    //     0x5a27b4: movz            x2, #0x10
    // 0x5a27b8: stur            x0, [fp, #-0x28]
    // 0x5a27bc: r0 = _getValueOrData()
    //     0x5a27bc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a27c0: mov             x1, x0
    // 0x5a27c4: ldur            x0, [fp, #-0x28]
    // 0x5a27c8: LoadField: r2 = r0->field_f
    //     0x5a27c8: ldur            w2, [x0, #0xf]
    // 0x5a27cc: DecompressPointer r2
    //     0x5a27cc: add             x2, x2, HEAP, lsl #32
    // 0x5a27d0: cmp             w2, w1
    // 0x5a27d4: b.ne            #0x5a27dc
    // 0x5a27d8: r1 = Null
    //     0x5a27d8: mov             x1, NULL
    // 0x5a27dc: cmp             w1, NULL
    // 0x5a27e0: b.eq            #0x5a2808
    // 0x5a27e4: r0 = LoadClassIdInstr(r1)
    //     0x5a27e4: ldur            x0, [x1, #-1]
    //     0x5a27e8: ubfx            x0, x0, #0xc, #0x14
    // 0x5a27ec: r16 = false
    //     0x5a27ec: add             x16, NULL, #0x30  ; false
    // 0x5a27f0: str             x16, [SP]
    // 0x5a27f4: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a27f4: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a27f8: ldr             x4, [x4, #0x2b8]
    // 0x5a27fc: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a27fc: sub             lr, x0, #0xe63
    //     0x5a2800: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2804: blr             lr
    // 0x5a2808: r1 = LoadStaticField(0xf60)
    //     0x5a2808: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a280c: ldr             x1, [x1, #0x1ec0]
    // 0x5a2810: ldur            x3, [fp, #-0x20]
    // 0x5a2814: r2 = 16
    //     0x5a2814: movz            x2, #0x10
    // 0x5a2818: r0 = []=()
    //     0x5a2818: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a281c: ldur            x1, [fp, #-0x20]
    // 0x5a2820: r0 = deleteSaveFiles()
    //     0x5a2820: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2824: mov             x1, x0
    // 0x5a2828: stur            x1, [fp, #-0x20]
    // 0x5a282c: r0 = Await()
    //     0x5a282c: bl              #0x34b75c  ; AwaitStub
    // 0x5a2830: b               #0x5a3160
    // 0x5a2834: r16 = "9"
    //     0x5a2834: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x5a2838: ldr             x16, [x16, #0x320]
    // 0x5a283c: ldur            lr, [fp, #-0x18]
    // 0x5a2840: stp             lr, x16, [SP]
    // 0x5a2844: r0 = ==()
    //     0x5a2844: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2848: tbnz            w0, #4, #0x5a290c
    // 0x5a284c: r1 = <Chapter9Stat>
    //     0x5a284c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe48] TypeArguments: <Chapter9Stat>
    //     0x5a2850: ldr             x1, [x1, #0xe48]
    // 0x5a2854: r0 = Chapter9GameState()
    //     0x5a2854: bl              #0x46e9dc  ; AllocateChapter9GameStateStub -> Chapter9GameState (size=0x98)
    // 0x5a2858: mov             x1, x0
    // 0x5a285c: r2 = Null
    //     0x5a285c: mov             x2, NULL
    // 0x5a2860: stur            x0, [fp, #-0x20]
    // 0x5a2864: r0 = Chapter9GameState()
    //     0x5a2864: bl              #0x46e464  ; [package:pretentious/data/Chapters/Chapter9GameState.dart] Chapter9GameState::Chapter9GameState
    // 0x5a2868: r0 = LoadStaticField(0xf60)
    //     0x5a2868: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a286c: ldr             x0, [x0, #0x1ec0]
    // 0x5a2870: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2874: cmp             w0, w16
    // 0x5a2878: b.ne            #0x5a2888
    // 0x5a287c: r2 = gameStates
    //     0x5a287c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2880: ldr             x2, [x2, #0x2e8]
    // 0x5a2884: r0 = InitLateStaticField()
    //     0x5a2884: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2888: mov             x1, x0
    // 0x5a288c: r2 = 18
    //     0x5a288c: movz            x2, #0x12
    // 0x5a2890: stur            x0, [fp, #-0x28]
    // 0x5a2894: r0 = _getValueOrData()
    //     0x5a2894: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2898: mov             x1, x0
    // 0x5a289c: ldur            x0, [fp, #-0x28]
    // 0x5a28a0: LoadField: r2 = r0->field_f
    //     0x5a28a0: ldur            w2, [x0, #0xf]
    // 0x5a28a4: DecompressPointer r2
    //     0x5a28a4: add             x2, x2, HEAP, lsl #32
    // 0x5a28a8: cmp             w2, w1
    // 0x5a28ac: b.ne            #0x5a28b4
    // 0x5a28b0: r1 = Null
    //     0x5a28b0: mov             x1, NULL
    // 0x5a28b4: cmp             w1, NULL
    // 0x5a28b8: b.eq            #0x5a28e0
    // 0x5a28bc: r0 = LoadClassIdInstr(r1)
    //     0x5a28bc: ldur            x0, [x1, #-1]
    //     0x5a28c0: ubfx            x0, x0, #0xc, #0x14
    // 0x5a28c4: r16 = false
    //     0x5a28c4: add             x16, NULL, #0x30  ; false
    // 0x5a28c8: str             x16, [SP]
    // 0x5a28cc: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a28cc: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a28d0: ldr             x4, [x4, #0x2b8]
    // 0x5a28d4: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a28d4: sub             lr, x0, #0xe63
    //     0x5a28d8: ldr             lr, [x21, lr, lsl #3]
    //     0x5a28dc: blr             lr
    // 0x5a28e0: r1 = LoadStaticField(0xf60)
    //     0x5a28e0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a28e4: ldr             x1, [x1, #0x1ec0]
    // 0x5a28e8: ldur            x3, [fp, #-0x20]
    // 0x5a28ec: r2 = 18
    //     0x5a28ec: movz            x2, #0x12
    // 0x5a28f0: r0 = []=()
    //     0x5a28f0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a28f4: ldur            x1, [fp, #-0x20]
    // 0x5a28f8: r0 = deleteSaveFiles()
    //     0x5a28f8: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a28fc: mov             x1, x0
    // 0x5a2900: stur            x1, [fp, #-0x20]
    // 0x5a2904: r0 = Await()
    //     0x5a2904: bl              #0x34b75c  ; AwaitStub
    // 0x5a2908: b               #0x5a3160
    // 0x5a290c: r16 = "10"
    //     0x5a290c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x5a2910: ldr             x16, [x16, #0x9d0]
    // 0x5a2914: ldur            lr, [fp, #-0x18]
    // 0x5a2918: stp             lr, x16, [SP]
    // 0x5a291c: r0 = ==()
    //     0x5a291c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2920: tbnz            w0, #4, #0x5a29e4
    // 0x5a2924: r1 = <Chapter10Stat>
    //     0x5a2924: add             x1, PP, #0xf, lsl #12  ; [pp+0xfe80] TypeArguments: <Chapter10Stat>
    //     0x5a2928: ldr             x1, [x1, #0xe80]
    // 0x5a292c: r0 = Chapter10GameState()
    //     0x5a292c: bl              #0x46e458  ; AllocateChapter10GameStateStub -> Chapter10GameState (size=0xa4)
    // 0x5a2930: mov             x1, x0
    // 0x5a2934: r2 = Null
    //     0x5a2934: mov             x2, NULL
    // 0x5a2938: stur            x0, [fp, #-0x20]
    // 0x5a293c: r0 = Chapter10GameState()
    //     0x5a293c: bl              #0x46db78  ; [package:pretentious/data/Chapters/Chapter10GameState.dart] Chapter10GameState::Chapter10GameState
    // 0x5a2940: r0 = LoadStaticField(0xf60)
    //     0x5a2940: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2944: ldr             x0, [x0, #0x1ec0]
    // 0x5a2948: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a294c: cmp             w0, w16
    // 0x5a2950: b.ne            #0x5a2960
    // 0x5a2954: r2 = gameStates
    //     0x5a2954: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2958: ldr             x2, [x2, #0x2e8]
    // 0x5a295c: r0 = InitLateStaticField()
    //     0x5a295c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2960: mov             x1, x0
    // 0x5a2964: r2 = 20
    //     0x5a2964: movz            x2, #0x14
    // 0x5a2968: stur            x0, [fp, #-0x28]
    // 0x5a296c: r0 = _getValueOrData()
    //     0x5a296c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2970: mov             x1, x0
    // 0x5a2974: ldur            x0, [fp, #-0x28]
    // 0x5a2978: LoadField: r2 = r0->field_f
    //     0x5a2978: ldur            w2, [x0, #0xf]
    // 0x5a297c: DecompressPointer r2
    //     0x5a297c: add             x2, x2, HEAP, lsl #32
    // 0x5a2980: cmp             w2, w1
    // 0x5a2984: b.ne            #0x5a298c
    // 0x5a2988: r1 = Null
    //     0x5a2988: mov             x1, NULL
    // 0x5a298c: cmp             w1, NULL
    // 0x5a2990: b.eq            #0x5a29b8
    // 0x5a2994: r0 = LoadClassIdInstr(r1)
    //     0x5a2994: ldur            x0, [x1, #-1]
    //     0x5a2998: ubfx            x0, x0, #0xc, #0x14
    // 0x5a299c: r16 = false
    //     0x5a299c: add             x16, NULL, #0x30  ; false
    // 0x5a29a0: str             x16, [SP]
    // 0x5a29a4: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a29a4: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a29a8: ldr             x4, [x4, #0x2b8]
    // 0x5a29ac: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a29ac: sub             lr, x0, #0xe63
    //     0x5a29b0: ldr             lr, [x21, lr, lsl #3]
    //     0x5a29b4: blr             lr
    // 0x5a29b8: r1 = LoadStaticField(0xf60)
    //     0x5a29b8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a29bc: ldr             x1, [x1, #0x1ec0]
    // 0x5a29c0: ldur            x3, [fp, #-0x20]
    // 0x5a29c4: r2 = 20
    //     0x5a29c4: movz            x2, #0x14
    // 0x5a29c8: r0 = []=()
    //     0x5a29c8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a29cc: ldur            x1, [fp, #-0x20]
    // 0x5a29d0: r0 = deleteSaveFiles()
    //     0x5a29d0: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a29d4: mov             x1, x0
    // 0x5a29d8: stur            x1, [fp, #-0x20]
    // 0x5a29dc: r0 = Await()
    //     0x5a29dc: bl              #0x34b75c  ; AwaitStub
    // 0x5a29e0: b               #0x5a3160
    // 0x5a29e4: r16 = "11"
    //     0x5a29e4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x5a29e8: ldr             x16, [x16, #0x328]
    // 0x5a29ec: ldur            lr, [fp, #-0x18]
    // 0x5a29f0: stp             lr, x16, [SP]
    // 0x5a29f4: r0 = ==()
    //     0x5a29f4: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a29f8: tbnz            w0, #4, #0x5a2abc
    // 0x5a29fc: r1 = <Chapter11Stat>
    //     0x5a29fc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfeb8] TypeArguments: <Chapter11Stat>
    //     0x5a2a00: ldr             x1, [x1, #0xeb8]
    // 0x5a2a04: r0 = Chapter11GameState()
    //     0x5a2a04: bl              #0x46db6c  ; AllocateChapter11GameStateStub -> Chapter11GameState (size=0x98)
    // 0x5a2a08: mov             x1, x0
    // 0x5a2a0c: r2 = Null
    //     0x5a2a0c: mov             x2, NULL
    // 0x5a2a10: stur            x0, [fp, #-0x20]
    // 0x5a2a14: r0 = Chapter11GameState()
    //     0x5a2a14: bl              #0x46d784  ; [package:pretentious/data/Chapters/Chapter11GameState.dart] Chapter11GameState::Chapter11GameState
    // 0x5a2a18: r0 = LoadStaticField(0xf60)
    //     0x5a2a18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2a1c: ldr             x0, [x0, #0x1ec0]
    // 0x5a2a20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2a24: cmp             w0, w16
    // 0x5a2a28: b.ne            #0x5a2a38
    // 0x5a2a2c: r2 = gameStates
    //     0x5a2a2c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2a30: ldr             x2, [x2, #0x2e8]
    // 0x5a2a34: r0 = InitLateStaticField()
    //     0x5a2a34: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2a38: mov             x1, x0
    // 0x5a2a3c: r2 = 22
    //     0x5a2a3c: movz            x2, #0x16
    // 0x5a2a40: stur            x0, [fp, #-0x28]
    // 0x5a2a44: r0 = _getValueOrData()
    //     0x5a2a44: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2a48: mov             x1, x0
    // 0x5a2a4c: ldur            x0, [fp, #-0x28]
    // 0x5a2a50: LoadField: r2 = r0->field_f
    //     0x5a2a50: ldur            w2, [x0, #0xf]
    // 0x5a2a54: DecompressPointer r2
    //     0x5a2a54: add             x2, x2, HEAP, lsl #32
    // 0x5a2a58: cmp             w2, w1
    // 0x5a2a5c: b.ne            #0x5a2a64
    // 0x5a2a60: r1 = Null
    //     0x5a2a60: mov             x1, NULL
    // 0x5a2a64: cmp             w1, NULL
    // 0x5a2a68: b.eq            #0x5a2a90
    // 0x5a2a6c: r0 = LoadClassIdInstr(r1)
    //     0x5a2a6c: ldur            x0, [x1, #-1]
    //     0x5a2a70: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2a74: r16 = false
    //     0x5a2a74: add             x16, NULL, #0x30  ; false
    // 0x5a2a78: str             x16, [SP]
    // 0x5a2a7c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2a7c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2a80: ldr             x4, [x4, #0x2b8]
    // 0x5a2a84: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2a84: sub             lr, x0, #0xe63
    //     0x5a2a88: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2a8c: blr             lr
    // 0x5a2a90: r1 = LoadStaticField(0xf60)
    //     0x5a2a90: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2a94: ldr             x1, [x1, #0x1ec0]
    // 0x5a2a98: ldur            x3, [fp, #-0x20]
    // 0x5a2a9c: r2 = 22
    //     0x5a2a9c: movz            x2, #0x16
    // 0x5a2aa0: r0 = []=()
    //     0x5a2aa0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2aa4: ldur            x1, [fp, #-0x20]
    // 0x5a2aa8: r0 = deleteSaveFiles()
    //     0x5a2aa8: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2aac: mov             x1, x0
    // 0x5a2ab0: stur            x1, [fp, #-0x20]
    // 0x5a2ab4: r0 = Await()
    //     0x5a2ab4: bl              #0x34b75c  ; AwaitStub
    // 0x5a2ab8: b               #0x5a3160
    // 0x5a2abc: r16 = "12"
    //     0x5a2abc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x5a2ac0: ldr             x16, [x16, #0x330]
    // 0x5a2ac4: ldur            lr, [fp, #-0x18]
    // 0x5a2ac8: stp             lr, x16, [SP]
    // 0x5a2acc: r0 = ==()
    //     0x5a2acc: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2ad0: tbnz            w0, #4, #0x5a2b94
    // 0x5a2ad4: r1 = <Chapter12Stat>
    //     0x5a2ad4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfef0] TypeArguments: <Chapter12Stat>
    //     0x5a2ad8: ldr             x1, [x1, #0xef0]
    // 0x5a2adc: r0 = Chapter12GameState()
    //     0x5a2adc: bl              #0x46d778  ; AllocateChapter12GameStateStub -> Chapter12GameState (size=0xa0)
    // 0x5a2ae0: mov             x1, x0
    // 0x5a2ae4: r2 = Null
    //     0x5a2ae4: mov             x2, NULL
    // 0x5a2ae8: stur            x0, [fp, #-0x20]
    // 0x5a2aec: r0 = Chapter12GameState()
    //     0x5a2aec: bl              #0x46d16c  ; [package:pretentious/data/Chapters/Chapter12GameState.dart] Chapter12GameState::Chapter12GameState
    // 0x5a2af0: r0 = LoadStaticField(0xf60)
    //     0x5a2af0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2af4: ldr             x0, [x0, #0x1ec0]
    // 0x5a2af8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2afc: cmp             w0, w16
    // 0x5a2b00: b.ne            #0x5a2b10
    // 0x5a2b04: r2 = gameStates
    //     0x5a2b04: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2b08: ldr             x2, [x2, #0x2e8]
    // 0x5a2b0c: r0 = InitLateStaticField()
    //     0x5a2b0c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2b10: mov             x1, x0
    // 0x5a2b14: r2 = 24
    //     0x5a2b14: movz            x2, #0x18
    // 0x5a2b18: stur            x0, [fp, #-0x28]
    // 0x5a2b1c: r0 = _getValueOrData()
    //     0x5a2b1c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2b20: mov             x1, x0
    // 0x5a2b24: ldur            x0, [fp, #-0x28]
    // 0x5a2b28: LoadField: r2 = r0->field_f
    //     0x5a2b28: ldur            w2, [x0, #0xf]
    // 0x5a2b2c: DecompressPointer r2
    //     0x5a2b2c: add             x2, x2, HEAP, lsl #32
    // 0x5a2b30: cmp             w2, w1
    // 0x5a2b34: b.ne            #0x5a2b3c
    // 0x5a2b38: r1 = Null
    //     0x5a2b38: mov             x1, NULL
    // 0x5a2b3c: cmp             w1, NULL
    // 0x5a2b40: b.eq            #0x5a2b68
    // 0x5a2b44: r0 = LoadClassIdInstr(r1)
    //     0x5a2b44: ldur            x0, [x1, #-1]
    //     0x5a2b48: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2b4c: r16 = false
    //     0x5a2b4c: add             x16, NULL, #0x30  ; false
    // 0x5a2b50: str             x16, [SP]
    // 0x5a2b54: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2b54: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2b58: ldr             x4, [x4, #0x2b8]
    // 0x5a2b5c: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2b5c: sub             lr, x0, #0xe63
    //     0x5a2b60: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2b64: blr             lr
    // 0x5a2b68: r1 = LoadStaticField(0xf60)
    //     0x5a2b68: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2b6c: ldr             x1, [x1, #0x1ec0]
    // 0x5a2b70: ldur            x3, [fp, #-0x20]
    // 0x5a2b74: r2 = 24
    //     0x5a2b74: movz            x2, #0x18
    // 0x5a2b78: r0 = []=()
    //     0x5a2b78: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2b7c: ldur            x1, [fp, #-0x20]
    // 0x5a2b80: r0 = deleteSaveFiles()
    //     0x5a2b80: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2b84: mov             x1, x0
    // 0x5a2b88: stur            x1, [fp, #-0x20]
    // 0x5a2b8c: r0 = Await()
    //     0x5a2b8c: bl              #0x34b75c  ; AwaitStub
    // 0x5a2b90: b               #0x5a3160
    // 0x5a2b94: r16 = "13"
    //     0x5a2b94: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x5a2b98: ldr             x16, [x16, #0x338]
    // 0x5a2b9c: ldur            lr, [fp, #-0x18]
    // 0x5a2ba0: stp             lr, x16, [SP]
    // 0x5a2ba4: r0 = ==()
    //     0x5a2ba4: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2ba8: tbnz            w0, #4, #0x5a2c6c
    // 0x5a2bac: r1 = <Chapter13Stat>
    //     0x5a2bac: add             x1, PP, #0xf, lsl #12  ; [pp+0xff28] TypeArguments: <Chapter13Stat>
    //     0x5a2bb0: ldr             x1, [x1, #0xf28]
    // 0x5a2bb4: r0 = Chapter13GameState()
    //     0x5a2bb4: bl              #0x46d160  ; AllocateChapter13GameStateStub -> Chapter13GameState (size=0xa4)
    // 0x5a2bb8: mov             x1, x0
    // 0x5a2bbc: r2 = Null
    //     0x5a2bbc: mov             x2, NULL
    // 0x5a2bc0: stur            x0, [fp, #-0x20]
    // 0x5a2bc4: r0 = Chapter13GameState()
    //     0x5a2bc4: bl              #0x46c900  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::Chapter13GameState
    // 0x5a2bc8: r0 = LoadStaticField(0xf60)
    //     0x5a2bc8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2bcc: ldr             x0, [x0, #0x1ec0]
    // 0x5a2bd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2bd4: cmp             w0, w16
    // 0x5a2bd8: b.ne            #0x5a2be8
    // 0x5a2bdc: r2 = gameStates
    //     0x5a2bdc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2be0: ldr             x2, [x2, #0x2e8]
    // 0x5a2be4: r0 = InitLateStaticField()
    //     0x5a2be4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2be8: mov             x1, x0
    // 0x5a2bec: r2 = 26
    //     0x5a2bec: movz            x2, #0x1a
    // 0x5a2bf0: stur            x0, [fp, #-0x28]
    // 0x5a2bf4: r0 = _getValueOrData()
    //     0x5a2bf4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2bf8: mov             x1, x0
    // 0x5a2bfc: ldur            x0, [fp, #-0x28]
    // 0x5a2c00: LoadField: r2 = r0->field_f
    //     0x5a2c00: ldur            w2, [x0, #0xf]
    // 0x5a2c04: DecompressPointer r2
    //     0x5a2c04: add             x2, x2, HEAP, lsl #32
    // 0x5a2c08: cmp             w2, w1
    // 0x5a2c0c: b.ne            #0x5a2c14
    // 0x5a2c10: r1 = Null
    //     0x5a2c10: mov             x1, NULL
    // 0x5a2c14: cmp             w1, NULL
    // 0x5a2c18: b.eq            #0x5a2c40
    // 0x5a2c1c: r0 = LoadClassIdInstr(r1)
    //     0x5a2c1c: ldur            x0, [x1, #-1]
    //     0x5a2c20: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2c24: r16 = false
    //     0x5a2c24: add             x16, NULL, #0x30  ; false
    // 0x5a2c28: str             x16, [SP]
    // 0x5a2c2c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2c2c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2c30: ldr             x4, [x4, #0x2b8]
    // 0x5a2c34: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2c34: sub             lr, x0, #0xe63
    //     0x5a2c38: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2c3c: blr             lr
    // 0x5a2c40: r1 = LoadStaticField(0xf60)
    //     0x5a2c40: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2c44: ldr             x1, [x1, #0x1ec0]
    // 0x5a2c48: ldur            x3, [fp, #-0x20]
    // 0x5a2c4c: r2 = 26
    //     0x5a2c4c: movz            x2, #0x1a
    // 0x5a2c50: r0 = []=()
    //     0x5a2c50: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2c54: ldur            x1, [fp, #-0x20]
    // 0x5a2c58: r0 = deleteSaveFiles()
    //     0x5a2c58: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2c5c: mov             x1, x0
    // 0x5a2c60: stur            x1, [fp, #-0x20]
    // 0x5a2c64: r0 = Await()
    //     0x5a2c64: bl              #0x34b75c  ; AwaitStub
    // 0x5a2c68: b               #0x5a3160
    // 0x5a2c6c: r16 = "14"
    //     0x5a2c6c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x5a2c70: ldr             x16, [x16, #0x340]
    // 0x5a2c74: ldur            lr, [fp, #-0x18]
    // 0x5a2c78: stp             lr, x16, [SP]
    // 0x5a2c7c: r0 = ==()
    //     0x5a2c7c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2c80: tbnz            w0, #4, #0x5a2d44
    // 0x5a2c84: r1 = <Chapter14Stat>
    //     0x5a2c84: add             x1, PP, #0xf, lsl #12  ; [pp+0xff60] TypeArguments: <Chapter14Stat>
    //     0x5a2c88: ldr             x1, [x1, #0xf60]
    // 0x5a2c8c: r0 = Chapter14GameState()
    //     0x5a2c8c: bl              #0x46c8f4  ; AllocateChapter14GameStateStub -> Chapter14GameState (size=0x98)
    // 0x5a2c90: mov             x1, x0
    // 0x5a2c94: r2 = Null
    //     0x5a2c94: mov             x2, NULL
    // 0x5a2c98: stur            x0, [fp, #-0x20]
    // 0x5a2c9c: r0 = Chapter14GameState()
    //     0x5a2c9c: bl              #0x46c318  ; [package:pretentious/data/Chapters/Chapter14GameState.dart] Chapter14GameState::Chapter14GameState
    // 0x5a2ca0: r0 = LoadStaticField(0xf60)
    //     0x5a2ca0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2ca4: ldr             x0, [x0, #0x1ec0]
    // 0x5a2ca8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2cac: cmp             w0, w16
    // 0x5a2cb0: b.ne            #0x5a2cc0
    // 0x5a2cb4: r2 = gameStates
    //     0x5a2cb4: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2cb8: ldr             x2, [x2, #0x2e8]
    // 0x5a2cbc: r0 = InitLateStaticField()
    //     0x5a2cbc: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2cc0: mov             x1, x0
    // 0x5a2cc4: r2 = 28
    //     0x5a2cc4: movz            x2, #0x1c
    // 0x5a2cc8: stur            x0, [fp, #-0x28]
    // 0x5a2ccc: r0 = _getValueOrData()
    //     0x5a2ccc: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2cd0: mov             x1, x0
    // 0x5a2cd4: ldur            x0, [fp, #-0x28]
    // 0x5a2cd8: LoadField: r2 = r0->field_f
    //     0x5a2cd8: ldur            w2, [x0, #0xf]
    // 0x5a2cdc: DecompressPointer r2
    //     0x5a2cdc: add             x2, x2, HEAP, lsl #32
    // 0x5a2ce0: cmp             w2, w1
    // 0x5a2ce4: b.ne            #0x5a2cec
    // 0x5a2ce8: r1 = Null
    //     0x5a2ce8: mov             x1, NULL
    // 0x5a2cec: cmp             w1, NULL
    // 0x5a2cf0: b.eq            #0x5a2d18
    // 0x5a2cf4: r0 = LoadClassIdInstr(r1)
    //     0x5a2cf4: ldur            x0, [x1, #-1]
    //     0x5a2cf8: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2cfc: r16 = false
    //     0x5a2cfc: add             x16, NULL, #0x30  ; false
    // 0x5a2d00: str             x16, [SP]
    // 0x5a2d04: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2d04: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2d08: ldr             x4, [x4, #0x2b8]
    // 0x5a2d0c: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2d0c: sub             lr, x0, #0xe63
    //     0x5a2d10: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2d14: blr             lr
    // 0x5a2d18: r1 = LoadStaticField(0xf60)
    //     0x5a2d18: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2d1c: ldr             x1, [x1, #0x1ec0]
    // 0x5a2d20: ldur            x3, [fp, #-0x20]
    // 0x5a2d24: r2 = 28
    //     0x5a2d24: movz            x2, #0x1c
    // 0x5a2d28: r0 = []=()
    //     0x5a2d28: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2d2c: ldur            x1, [fp, #-0x20]
    // 0x5a2d30: r0 = deleteSaveFiles()
    //     0x5a2d30: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2d34: mov             x1, x0
    // 0x5a2d38: stur            x1, [fp, #-0x20]
    // 0x5a2d3c: r0 = Await()
    //     0x5a2d3c: bl              #0x34b75c  ; AwaitStub
    // 0x5a2d40: b               #0x5a3160
    // 0x5a2d44: r16 = "15"
    //     0x5a2d44: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x5a2d48: ldr             x16, [x16, #0x348]
    // 0x5a2d4c: ldur            lr, [fp, #-0x18]
    // 0x5a2d50: stp             lr, x16, [SP]
    // 0x5a2d54: r0 = ==()
    //     0x5a2d54: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2d58: tbnz            w0, #4, #0x5a2e1c
    // 0x5a2d5c: r1 = <Chapter15Stat>
    //     0x5a2d5c: add             x1, PP, #0xf, lsl #12  ; [pp+0xff98] TypeArguments: <Chapter15Stat>
    //     0x5a2d60: ldr             x1, [x1, #0xf98]
    // 0x5a2d64: r0 = Chapter15GameState()
    //     0x5a2d64: bl              #0x46c30c  ; AllocateChapter15GameStateStub -> Chapter15GameState (size=0xac)
    // 0x5a2d68: mov             x1, x0
    // 0x5a2d6c: r2 = Null
    //     0x5a2d6c: mov             x2, NULL
    // 0x5a2d70: stur            x0, [fp, #-0x20]
    // 0x5a2d74: r0 = Chapter15GameState()
    //     0x5a2d74: bl              #0x46b010  ; [package:pretentious/data/Chapters/Chapter15GameState.dart] Chapter15GameState::Chapter15GameState
    // 0x5a2d78: r0 = LoadStaticField(0xf60)
    //     0x5a2d78: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2d7c: ldr             x0, [x0, #0x1ec0]
    // 0x5a2d80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2d84: cmp             w0, w16
    // 0x5a2d88: b.ne            #0x5a2d98
    // 0x5a2d8c: r2 = gameStates
    //     0x5a2d8c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2d90: ldr             x2, [x2, #0x2e8]
    // 0x5a2d94: r0 = InitLateStaticField()
    //     0x5a2d94: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2d98: mov             x1, x0
    // 0x5a2d9c: r2 = 30
    //     0x5a2d9c: movz            x2, #0x1e
    // 0x5a2da0: stur            x0, [fp, #-0x28]
    // 0x5a2da4: r0 = _getValueOrData()
    //     0x5a2da4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2da8: mov             x1, x0
    // 0x5a2dac: ldur            x0, [fp, #-0x28]
    // 0x5a2db0: LoadField: r2 = r0->field_f
    //     0x5a2db0: ldur            w2, [x0, #0xf]
    // 0x5a2db4: DecompressPointer r2
    //     0x5a2db4: add             x2, x2, HEAP, lsl #32
    // 0x5a2db8: cmp             w2, w1
    // 0x5a2dbc: b.ne            #0x5a2dc4
    // 0x5a2dc0: r1 = Null
    //     0x5a2dc0: mov             x1, NULL
    // 0x5a2dc4: cmp             w1, NULL
    // 0x5a2dc8: b.eq            #0x5a2df0
    // 0x5a2dcc: r0 = LoadClassIdInstr(r1)
    //     0x5a2dcc: ldur            x0, [x1, #-1]
    //     0x5a2dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2dd4: r16 = false
    //     0x5a2dd4: add             x16, NULL, #0x30  ; false
    // 0x5a2dd8: str             x16, [SP]
    // 0x5a2ddc: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2ddc: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2de0: ldr             x4, [x4, #0x2b8]
    // 0x5a2de4: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2de4: sub             lr, x0, #0xe63
    //     0x5a2de8: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2dec: blr             lr
    // 0x5a2df0: r1 = LoadStaticField(0xf60)
    //     0x5a2df0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2df4: ldr             x1, [x1, #0x1ec0]
    // 0x5a2df8: ldur            x3, [fp, #-0x20]
    // 0x5a2dfc: r2 = 30
    //     0x5a2dfc: movz            x2, #0x1e
    // 0x5a2e00: r0 = []=()
    //     0x5a2e00: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2e04: ldur            x1, [fp, #-0x20]
    // 0x5a2e08: r0 = deleteSaveFiles()
    //     0x5a2e08: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2e0c: mov             x1, x0
    // 0x5a2e10: stur            x1, [fp, #-0x20]
    // 0x5a2e14: r0 = Await()
    //     0x5a2e14: bl              #0x34b75c  ; AwaitStub
    // 0x5a2e18: b               #0x5a3160
    // 0x5a2e1c: r16 = "16"
    //     0x5a2e1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x5a2e20: ldr             x16, [x16, #0x350]
    // 0x5a2e24: ldur            lr, [fp, #-0x18]
    // 0x5a2e28: stp             lr, x16, [SP]
    // 0x5a2e2c: r0 = ==()
    //     0x5a2e2c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2e30: tbnz            w0, #4, #0x5a2ef4
    // 0x5a2e34: r1 = <Chapter16Stat>
    //     0x5a2e34: add             x1, PP, #0xf, lsl #12  ; [pp+0xffd0] TypeArguments: <Chapter16Stat>
    //     0x5a2e38: ldr             x1, [x1, #0xfd0]
    // 0x5a2e3c: r0 = Chapter16GameState()
    //     0x5a2e3c: bl              #0x46b004  ; AllocateChapter16GameStateStub -> Chapter16GameState (size=0x90)
    // 0x5a2e40: mov             x1, x0
    // 0x5a2e44: r2 = Null
    //     0x5a2e44: mov             x2, NULL
    // 0x5a2e48: stur            x0, [fp, #-0x20]
    // 0x5a2e4c: r0 = Chapter16GameState()
    //     0x5a2e4c: bl              #0x46ae7c  ; [package:pretentious/data/Chapters/Chapter16GameState.dart] Chapter16GameState::Chapter16GameState
    // 0x5a2e50: r0 = LoadStaticField(0xf60)
    //     0x5a2e50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2e54: ldr             x0, [x0, #0x1ec0]
    // 0x5a2e58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2e5c: cmp             w0, w16
    // 0x5a2e60: b.ne            #0x5a2e70
    // 0x5a2e64: r2 = gameStates
    //     0x5a2e64: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2e68: ldr             x2, [x2, #0x2e8]
    // 0x5a2e6c: r0 = InitLateStaticField()
    //     0x5a2e6c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2e70: mov             x1, x0
    // 0x5a2e74: r2 = 32
    //     0x5a2e74: movz            x2, #0x20
    // 0x5a2e78: stur            x0, [fp, #-0x28]
    // 0x5a2e7c: r0 = _getValueOrData()
    //     0x5a2e7c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2e80: mov             x1, x0
    // 0x5a2e84: ldur            x0, [fp, #-0x28]
    // 0x5a2e88: LoadField: r2 = r0->field_f
    //     0x5a2e88: ldur            w2, [x0, #0xf]
    // 0x5a2e8c: DecompressPointer r2
    //     0x5a2e8c: add             x2, x2, HEAP, lsl #32
    // 0x5a2e90: cmp             w2, w1
    // 0x5a2e94: b.ne            #0x5a2e9c
    // 0x5a2e98: r1 = Null
    //     0x5a2e98: mov             x1, NULL
    // 0x5a2e9c: cmp             w1, NULL
    // 0x5a2ea0: b.eq            #0x5a2ec8
    // 0x5a2ea4: r0 = LoadClassIdInstr(r1)
    //     0x5a2ea4: ldur            x0, [x1, #-1]
    //     0x5a2ea8: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2eac: r16 = false
    //     0x5a2eac: add             x16, NULL, #0x30  ; false
    // 0x5a2eb0: str             x16, [SP]
    // 0x5a2eb4: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2eb4: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2eb8: ldr             x4, [x4, #0x2b8]
    // 0x5a2ebc: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2ebc: sub             lr, x0, #0xe63
    //     0x5a2ec0: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2ec4: blr             lr
    // 0x5a2ec8: r1 = LoadStaticField(0xf60)
    //     0x5a2ec8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2ecc: ldr             x1, [x1, #0x1ec0]
    // 0x5a2ed0: ldur            x3, [fp, #-0x20]
    // 0x5a2ed4: r2 = 32
    //     0x5a2ed4: movz            x2, #0x20
    // 0x5a2ed8: r0 = []=()
    //     0x5a2ed8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2edc: ldur            x1, [fp, #-0x20]
    // 0x5a2ee0: r0 = deleteSaveFiles()
    //     0x5a2ee0: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2ee4: mov             x1, x0
    // 0x5a2ee8: stur            x1, [fp, #-0x20]
    // 0x5a2eec: r0 = Await()
    //     0x5a2eec: bl              #0x34b75c  ; AwaitStub
    // 0x5a2ef0: b               #0x5a3160
    // 0x5a2ef4: r16 = "17"
    //     0x5a2ef4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x5a2ef8: ldr             x16, [x16, #0x358]
    // 0x5a2efc: ldur            lr, [fp, #-0x18]
    // 0x5a2f00: stp             lr, x16, [SP]
    // 0x5a2f04: r0 = ==()
    //     0x5a2f04: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x5a2f08: tbnz            w0, #4, #0x5a2fcc
    // 0x5a2f0c: r1 = <Chapter17Stat>
    //     0x5a2f0c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10008] TypeArguments: <Chapter17Stat>
    //     0x5a2f10: ldr             x1, [x1, #8]
    // 0x5a2f14: r0 = Chapter17GameState()
    //     0x5a2f14: bl              #0x46ae70  ; AllocateChapter17GameStateStub -> Chapter17GameState (size=0x90)
    // 0x5a2f18: mov             x1, x0
    // 0x5a2f1c: r2 = Null
    //     0x5a2f1c: mov             x2, NULL
    // 0x5a2f20: stur            x0, [fp, #-0x18]
    // 0x5a2f24: r0 = Chapter17GameState()
    //     0x5a2f24: bl              #0x46ace8  ; [package:pretentious/data/Chapters/Chapter17GameState.dart] Chapter17GameState::Chapter17GameState
    // 0x5a2f28: r0 = LoadStaticField(0xf60)
    //     0x5a2f28: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2f2c: ldr             x0, [x0, #0x1ec0]
    // 0x5a2f30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2f34: cmp             w0, w16
    // 0x5a2f38: b.ne            #0x5a2f48
    // 0x5a2f3c: r2 = gameStates
    //     0x5a2f3c: add             x2, PP, #0xf, lsl #12  ; [pp+0xf2e8] Field <::.gameStates>: static late (offset: 0xf60)
    //     0x5a2f40: ldr             x2, [x2, #0x2e8]
    // 0x5a2f44: r0 = InitLateStaticField()
    //     0x5a2f44: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2f48: mov             x1, x0
    // 0x5a2f4c: r2 = 34
    //     0x5a2f4c: movz            x2, #0x22
    // 0x5a2f50: stur            x0, [fp, #-0x20]
    // 0x5a2f54: r0 = _getValueOrData()
    //     0x5a2f54: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a2f58: mov             x1, x0
    // 0x5a2f5c: ldur            x0, [fp, #-0x20]
    // 0x5a2f60: LoadField: r2 = r0->field_f
    //     0x5a2f60: ldur            w2, [x0, #0xf]
    // 0x5a2f64: DecompressPointer r2
    //     0x5a2f64: add             x2, x2, HEAP, lsl #32
    // 0x5a2f68: cmp             w2, w1
    // 0x5a2f6c: b.ne            #0x5a2f74
    // 0x5a2f70: r1 = Null
    //     0x5a2f70: mov             x1, NULL
    // 0x5a2f74: cmp             w1, NULL
    // 0x5a2f78: b.eq            #0x5a2fa0
    // 0x5a2f7c: r0 = LoadClassIdInstr(r1)
    //     0x5a2f7c: ldur            x0, [x1, #-1]
    //     0x5a2f80: ubfx            x0, x0, #0xc, #0x14
    // 0x5a2f84: r16 = false
    //     0x5a2f84: add             x16, NULL, #0x30  ; false
    // 0x5a2f88: str             x16, [SP]
    // 0x5a2f8c: r4 = const [0, 0x2, 0x1, 0x1, save, 0x1, null]
    //     0x5a2f8c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f2b8] List(7) [0, 0x2, 0x1, 0x1, "save", 0x1, Null]
    //     0x5a2f90: ldr             x4, [x4, #0x2b8]
    // 0x5a2f94: r0 = GDT[cid_x0 + -0xe63]()
    //     0x5a2f94: sub             lr, x0, #0xe63
    //     0x5a2f98: ldr             lr, [x21, lr, lsl #3]
    //     0x5a2f9c: blr             lr
    // 0x5a2fa0: r1 = LoadStaticField(0xf60)
    //     0x5a2fa0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2fa4: ldr             x1, [x1, #0x1ec0]
    // 0x5a2fa8: ldur            x3, [fp, #-0x18]
    // 0x5a2fac: r2 = 34
    //     0x5a2fac: movz            x2, #0x22
    // 0x5a2fb0: r0 = []=()
    //     0x5a2fb0: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5a2fb4: ldur            x1, [fp, #-0x18]
    // 0x5a2fb8: r0 = deleteSaveFiles()
    //     0x5a2fb8: bl              #0x456244  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::deleteSaveFiles
    // 0x5a2fbc: mov             x1, x0
    // 0x5a2fc0: stur            x1, [fp, #-0x18]
    // 0x5a2fc4: r0 = Await()
    //     0x5a2fc4: bl              #0x34b75c  ; AwaitStub
    // 0x5a2fc8: b               #0x5a3160
    // 0x5a2fcc: r0 = LoadStaticField(0xf5c)
    //     0x5a2fcc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5a2fd0: ldr             x0, [x0, #0x1eb8]
    // 0x5a2fd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5a2fd8: cmp             w0, w16
    // 0x5a2fdc: b.ne            #0x5a2fec
    // 0x5a2fe0: r2 = customLevels
    //     0x5a2fe0: add             x2, PP, #0xf, lsl #12  ; [pp+0xf368] Field <::.customLevels>: static late (offset: 0xf5c)
    //     0x5a2fe4: ldr             x2, [x2, #0x368]
    // 0x5a2fe8: r0 = InitLateStaticField()
    //     0x5a2fe8: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x5a2fec: stur            x0, [fp, #-0x18]
    // 0x5a2ff0: r0 = currentChapterName()
    //     0x5a2ff0: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x5a2ff4: ldur            x1, [fp, #-0x18]
    // 0x5a2ff8: mov             x2, x0
    // 0x5a2ffc: r0 = containsKey()
    //     0x5a2ffc: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x5a3000: tbnz            w0, #4, #0x5a3050
    // 0x5a3004: r1 = LoadStaticField(0xf5c)
    //     0x5a3004: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x5a3008: ldr             x1, [x1, #0x1eb8]
    // 0x5a300c: stur            x1, [fp, #-0x18]
    // 0x5a3010: r0 = currentChapterName()
    //     0x5a3010: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x5a3014: ldur            x1, [fp, #-0x18]
    // 0x5a3018: mov             x2, x0
    // 0x5a301c: r0 = _getValueOrData()
    //     0x5a301c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5a3020: mov             x1, x0
    // 0x5a3024: ldur            x0, [fp, #-0x18]
    // 0x5a3028: LoadField: r2 = r0->field_f
    //     0x5a3028: ldur            w2, [x0, #0xf]
    // 0x5a302c: DecompressPointer r2
    //     0x5a302c: add             x2, x2, HEAP, lsl #32
    // 0x5a3030: cmp             w2, w1
    // 0x5a3034: b.ne            #0x5a303c
    // 0x5a3038: r1 = Null
    //     0x5a3038: mov             x1, NULL
    // 0x5a303c: cmp             w1, NULL
    // 0x5a3040: b.eq            #0x5a3170
    // 0x5a3044: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5a3044: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5a3048: r0 = reset()
    //     0x5a3048: bl              #0x81b0a0  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::reset
    // 0x5a304c: b               #0x5a3160
    // 0x5a3050: ldur            x0, [fp, #-0x10]
    // 0x5a3054: tbz             w0, #4, #0x5a3160
    // 0x5a3058: r1 = Null
    //     0x5a3058: mov             x1, NULL
    // 0x5a305c: r2 = 12
    //     0x5a305c: movz            x2, #0xc
    // 0x5a3060: r0 = AllocateArray()
    //     0x5a3060: bl              #0x82746c  ; AllocateArrayStub
    // 0x5a3064: stur            x0, [fp, #-0x10]
    // 0x5a3068: r16 = "Unknown act in resetAct(): "
    //     0x5a3068: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f2c0] "Unknown act in resetAct(): "
    //     0x5a306c: ldr             x16, [x16, #0x2c0]
    // 0x5a3070: StoreField: r0->field_f = r16
    //     0x5a3070: stur            w16, [x0, #0xf]
    // 0x5a3074: r0 = currentChapterName()
    //     0x5a3074: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x5a3078: ldur            x1, [fp, #-0x10]
    // 0x5a307c: ArrayStore: r1[1] = r0  ; List_4
    //     0x5a307c: add             x25, x1, #0x13
    //     0x5a3080: str             w0, [x25]
    //     0x5a3084: tbz             w0, #0, #0x5a30a0
    //     0x5a3088: ldurb           w16, [x1, #-1]
    //     0x5a308c: ldurb           w17, [x0, #-1]
    //     0x5a3090: and             x16, x17, x16, lsr #2
    //     0x5a3094: tst             x16, HEAP, lsr #32
    //     0x5a3098: b.eq            #0x5a30a0
    //     0x5a309c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a30a0: ldur            x1, [fp, #-0x10]
    // 0x5a30a4: r16 = " saved act: "
    //     0x5a30a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f2c8] " saved act: "
    //     0x5a30a8: ldr             x16, [x16, #0x2c8]
    // 0x5a30ac: ArrayStore: r1[0] = r16  ; List_4
    //     0x5a30ac: stur            w16, [x1, #0x17]
    // 0x5a30b0: r0 = currentChapterName()
    //     0x5a30b0: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x5a30b4: ldur            x1, [fp, #-0x10]
    // 0x5a30b8: ArrayStore: r1[3] = r0  ; List_4
    //     0x5a30b8: add             x25, x1, #0x1b
    //     0x5a30bc: str             w0, [x25]
    //     0x5a30c0: tbz             w0, #0, #0x5a30dc
    //     0x5a30c4: ldurb           w16, [x1, #-1]
    //     0x5a30c8: ldurb           w17, [x0, #-1]
    //     0x5a30cc: and             x16, x17, x16, lsr #2
    //     0x5a30d0: tst             x16, HEAP, lsr #32
    //     0x5a30d4: b.eq            #0x5a30dc
    //     0x5a30d8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a30dc: ldur            x0, [fp, #-0x10]
    // 0x5a30e0: r16 = ". Custom levels: "
    //     0x5a30e0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f2d0] ". Custom levels: "
    //     0x5a30e4: ldr             x16, [x16, #0x2d0]
    // 0x5a30e8: StoreField: r0->field_1f = r16
    //     0x5a30e8: stur            w16, [x0, #0x1f]
    // 0x5a30ec: r2 = LoadStaticField(0xf5c)
    //     0x5a30ec: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x5a30f0: ldr             x2, [x2, #0x1eb8]
    // 0x5a30f4: stur            x2, [fp, #-0x18]
    // 0x5a30f8: r1 = <String, CustomLevelGameState>
    //     0x5a30f8: add             x1, PP, #0xf, lsl #12  ; [pp+0xf388] TypeArguments: <String, CustomLevelGameState>
    //     0x5a30fc: ldr             x1, [x1, #0x388]
    // 0x5a3100: r0 = _CompactKeysIterable()
    //     0x5a3100: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x5a3104: mov             x1, x0
    // 0x5a3108: ldur            x0, [fp, #-0x18]
    // 0x5a310c: StoreField: r1->field_b = r0
    //     0x5a310c: stur            w0, [x1, #0xb]
    // 0x5a3110: mov             x0, x1
    // 0x5a3114: ldur            x1, [fp, #-0x10]
    // 0x5a3118: ArrayStore: r1[5] = r0  ; List_4
    //     0x5a3118: add             x25, x1, #0x23
    //     0x5a311c: str             w0, [x25]
    //     0x5a3120: tbz             w0, #0, #0x5a313c
    //     0x5a3124: ldurb           w16, [x1, #-1]
    //     0x5a3128: ldurb           w17, [x0, #-1]
    //     0x5a312c: and             x16, x17, x16, lsr #2
    //     0x5a3130: tst             x16, HEAP, lsr #32
    //     0x5a3134: b.eq            #0x5a313c
    //     0x5a3138: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5a313c: ldur            x16, [fp, #-0x10]
    // 0x5a3140: str             x16, [SP]
    // 0x5a3144: r0 = _interpolate()
    //     0x5a3144: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x5a3148: stur            x0, [fp, #-0x10]
    // 0x5a314c: r0 = current()
    //     0x5a314c: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x5a3150: ldur            x1, [fp, #-0x10]
    // 0x5a3154: mov             x2, x0
    // 0x5a3158: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x5a3158: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x5a315c: r0 = crashlyticsRecordError()
    //     0x5a315c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x5a3160: r0 = Null
    //     0x5a3160: mov             x0, NULL
    // 0x5a3164: r0 = ReturnAsyncNotFuture()
    //     0x5a3164: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x5a3168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a3168: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a316c: b               #0x5a216c
    // 0x5a3170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a3170: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ getChapterName(/* No info */) {
    // ** addr: 0x6053e4, size: 0x364
    // 0x6053e4: EnterFrame
    //     0x6053e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6053e8: mov             fp, SP
    // 0x6053ec: AllocStack(0x18)
    //     0x6053ec: sub             SP, SP, #0x18
    // 0x6053f0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x6053f0: stur            x1, [fp, #-8]
    // 0x6053f4: CheckStackOverflow
    //     0x6053f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6053f8: cmp             SP, x16
    //     0x6053fc: b.ls            #0x605740
    // 0x605400: r16 = "1"
    //     0x605400: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x605404: ldr             x16, [x16, #0x9c8]
    // 0x605408: stp             x1, x16, [SP]
    // 0x60540c: r0 = ==()
    //     0x60540c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605410: tbnz            w0, #4, #0x605428
    // 0x605414: r0 = "Library Of Stacklandia"
    //     0x605414: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a130] "Library Of Stacklandia"
    //     0x605418: ldr             x0, [x0, #0x130]
    // 0x60541c: LeaveFrame
    //     0x60541c: mov             SP, fp
    //     0x605420: ldp             fp, lr, [SP], #0x10
    // 0x605424: ret
    //     0x605424: ret             
    // 0x605428: r16 = "2"
    //     0x605428: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x60542c: ldr             x16, [x16, #0x2e0]
    // 0x605430: ldur            lr, [fp, #-8]
    // 0x605434: stp             lr, x16, [SP]
    // 0x605438: r0 = ==()
    //     0x605438: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x60543c: tbnz            w0, #4, #0x605454
    // 0x605440: r0 = "Calling Yourself Agile Over Being Agile"
    //     0x605440: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a138] "Calling Yourself Agile Over Being Agile"
    //     0x605444: ldr             x0, [x0, #0x138]
    // 0x605448: LeaveFrame
    //     0x605448: mov             SP, fp
    //     0x60544c: ldp             fp, lr, [SP], #0x10
    // 0x605450: ret
    //     0x605450: ret             
    // 0x605454: r16 = "3"
    //     0x605454: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x605458: ldr             x16, [x16, #0x2f0]
    // 0x60545c: ldur            lr, [fp, #-8]
    // 0x605460: stp             lr, x16, [SP]
    // 0x605464: r0 = ==()
    //     0x605464: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605468: tbnz            w0, #4, #0x605480
    // 0x60546c: r0 = "Embrace The Yak Shave"
    //     0x60546c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a140] "Embrace The Yak Shave"
    //     0x605470: ldr             x0, [x0, #0x140]
    // 0x605474: LeaveFrame
    //     0x605474: mov             SP, fp
    //     0x605478: ldp             fp, lr, [SP], #0x10
    // 0x60547c: ret
    //     0x60547c: ret             
    // 0x605480: r16 = "4"
    //     0x605480: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f8] "4"
    //     0x605484: ldr             x16, [x16, #0x2f8]
    // 0x605488: ldur            lr, [fp, #-8]
    // 0x60548c: stp             lr, x16, [SP]
    // 0x605490: r0 = ==()
    //     0x605490: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605494: tbnz            w0, #4, #0x6054ac
    // 0x605498: r0 = "Unicorns Don\'t Exist"
    //     0x605498: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a148] "Unicorns Don\'t Exist"
    //     0x60549c: ldr             x0, [x0, #0x148]
    // 0x6054a0: LeaveFrame
    //     0x6054a0: mov             SP, fp
    //     0x6054a4: ldp             fp, lr, [SP], #0x10
    // 0x6054a8: ret
    //     0x6054a8: ret             
    // 0x6054ac: r16 = "5"
    //     0x6054ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf300] "5"
    //     0x6054b0: ldr             x16, [x16, #0x300]
    // 0x6054b4: ldur            lr, [fp, #-8]
    // 0x6054b8: stp             lr, x16, [SP]
    // 0x6054bc: r0 = ==()
    //     0x6054bc: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6054c0: tbnz            w0, #4, #0x6054d8
    // 0x6054c4: r0 = "Recurse, Recurse, Recurse"
    //     0x6054c4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a150] "Recurse, Recurse, Recurse"
    //     0x6054c8: ldr             x0, [x0, #0x150]
    // 0x6054cc: LeaveFrame
    //     0x6054cc: mov             SP, fp
    //     0x6054d0: ldp             fp, lr, [SP], #0x10
    // 0x6054d4: ret
    //     0x6054d4: ret             
    // 0x6054d8: r16 = "6"
    //     0x6054d8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf308] "6"
    //     0x6054dc: ldr             x16, [x16, #0x308]
    // 0x6054e0: ldur            lr, [fp, #-8]
    // 0x6054e4: stp             lr, x16, [SP]
    // 0x6054e8: r0 = ==()
    //     0x6054e8: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6054ec: tbnz            w0, #4, #0x605504
    // 0x6054f0: r0 = "Free As In Beer"
    //     0x6054f0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a158] "Free As In Beer"
    //     0x6054f4: ldr             x0, [x0, #0x158]
    // 0x6054f8: LeaveFrame
    //     0x6054f8: mov             SP, fp
    //     0x6054fc: ldp             fp, lr, [SP], #0x10
    // 0x605500: ret
    //     0x605500: ret             
    // 0x605504: r16 = "7"
    //     0x605504: add             x16, PP, #0xf, lsl #12  ; [pp+0xf310] "7"
    //     0x605508: ldr             x16, [x16, #0x310]
    // 0x60550c: ldur            lr, [fp, #-8]
    // 0x605510: stp             lr, x16, [SP]
    // 0x605514: r0 = ==()
    //     0x605514: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605518: tbnz            w0, #4, #0x605530
    // 0x60551c: r0 = "TL;DR"
    //     0x60551c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a160] "TL;DR"
    //     0x605520: ldr             x0, [x0, #0x160]
    // 0x605524: LeaveFrame
    //     0x605524: mov             SP, fp
    //     0x605528: ldp             fp, lr, [SP], #0x10
    // 0x60552c: ret
    //     0x60552c: ret             
    // 0x605530: r16 = "8"
    //     0x605530: add             x16, PP, #0xf, lsl #12  ; [pp+0xf318] "8"
    //     0x605534: ldr             x16, [x16, #0x318]
    // 0x605538: ldur            lr, [fp, #-8]
    // 0x60553c: stp             lr, x16, [SP]
    // 0x605540: r0 = ==()
    //     0x605540: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605544: tbnz            w0, #4, #0x60555c
    // 0x605548: r0 = "Glory To The Coming Age Of Free Software"
    //     0x605548: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a168] "Glory To The Coming Age Of Free Software"
    //     0x60554c: ldr             x0, [x0, #0x168]
    // 0x605550: LeaveFrame
    //     0x605550: mov             SP, fp
    //     0x605554: ldp             fp, lr, [SP], #0x10
    // 0x605558: ret
    //     0x605558: ret             
    // 0x60555c: r16 = "9"
    //     0x60555c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf320] "9"
    //     0x605560: ldr             x16, [x16, #0x320]
    // 0x605564: ldur            lr, [fp, #-8]
    // 0x605568: stp             lr, x16, [SP]
    // 0x60556c: r0 = ==()
    //     0x60556c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605570: tbnz            w0, #4, #0x605588
    // 0x605574: r0 = "Tivoization"
    //     0x605574: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a170] "Tivoization"
    //     0x605578: ldr             x0, [x0, #0x170]
    // 0x60557c: LeaveFrame
    //     0x60557c: mov             SP, fp
    //     0x605580: ldp             fp, lr, [SP], #0x10
    // 0x605584: ret
    //     0x605584: ret             
    // 0x605588: r16 = "10"
    //     0x605588: add             x16, PP, #0xe, lsl #12  ; [pp+0xe9d0] "10"
    //     0x60558c: ldr             x16, [x16, #0x9d0]
    // 0x605590: ldur            lr, [fp, #-8]
    // 0x605594: stp             lr, x16, [SP]
    // 0x605598: r0 = ==()
    //     0x605598: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x60559c: tbnz            w0, #4, #0x6055b4
    // 0x6055a0: r0 = "LNU/Leinix"
    //     0x6055a0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a178] "LNU/Leinix"
    //     0x6055a4: ldr             x0, [x0, #0x178]
    // 0x6055a8: LeaveFrame
    //     0x6055a8: mov             SP, fp
    //     0x6055ac: ldp             fp, lr, [SP], #0x10
    // 0x6055b0: ret
    //     0x6055b0: ret             
    // 0x6055b4: r16 = "11"
    //     0x6055b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf328] "11"
    //     0x6055b8: ldr             x16, [x16, #0x328]
    // 0x6055bc: ldur            lr, [fp, #-8]
    // 0x6055c0: stp             lr, x16, [SP]
    // 0x6055c4: r0 = ==()
    //     0x6055c4: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6055c8: tbnz            w0, #4, #0x6055e0
    // 0x6055cc: r0 = "Or Any Later Version"
    //     0x6055cc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a180] "Or Any Later Version"
    //     0x6055d0: ldr             x0, [x0, #0x180]
    // 0x6055d4: LeaveFrame
    //     0x6055d4: mov             SP, fp
    //     0x6055d8: ldp             fp, lr, [SP], #0x10
    // 0x6055dc: ret
    //     0x6055dc: ret             
    // 0x6055e0: r16 = "12"
    //     0x6055e0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf330] "12"
    //     0x6055e4: ldr             x16, [x16, #0x330]
    // 0x6055e8: ldur            lr, [fp, #-8]
    // 0x6055ec: stp             lr, x16, [SP]
    // 0x6055f0: r0 = ==()
    //     0x6055f0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6055f4: tbnz            w0, #4, #0x60560c
    // 0x6055f8: r0 = "The Great Reset"
    //     0x6055f8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a188] "The Great Reset"
    //     0x6055fc: ldr             x0, [x0, #0x188]
    // 0x605600: LeaveFrame
    //     0x605600: mov             SP, fp
    //     0x605604: ldp             fp, lr, [SP], #0x10
    // 0x605608: ret
    //     0x605608: ret             
    // 0x60560c: r16 = "13"
    //     0x60560c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf338] "13"
    //     0x605610: ldr             x16, [x16, #0x338]
    // 0x605614: ldur            lr, [fp, #-8]
    // 0x605618: stp             lr, x16, [SP]
    // 0x60561c: r0 = ==()
    //     0x60561c: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605620: tbnz            w0, #4, #0x605638
    // 0x605624: r0 = "Free As In Anarchy"
    //     0x605624: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a190] "Free As In Anarchy"
    //     0x605628: ldr             x0, [x0, #0x190]
    // 0x60562c: LeaveFrame
    //     0x60562c: mov             SP, fp
    //     0x605630: ldp             fp, lr, [SP], #0x10
    // 0x605634: ret
    //     0x605634: ret             
    // 0x605638: r16 = "14"
    //     0x605638: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x60563c: ldr             x16, [x16, #0x340]
    // 0x605640: ldur            lr, [fp, #-8]
    // 0x605644: stp             lr, x16, [SP]
    // 0x605648: r0 = ==()
    //     0x605648: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x60564c: tbnz            w0, #4, #0x605664
    // 0x605650: r0 = "Return Of The Mach"
    //     0x605650: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a198] "Return Of The Mach"
    //     0x605654: ldr             x0, [x0, #0x198]
    // 0x605658: LeaveFrame
    //     0x605658: mov             SP, fp
    //     0x60565c: ldp             fp, lr, [SP], #0x10
    // 0x605660: ret
    //     0x605660: ret             
    // 0x605664: r16 = "15"
    //     0x605664: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x605668: ldr             x16, [x16, #0x348]
    // 0x60566c: ldur            lr, [fp, #-8]
    // 0x605670: stp             lr, x16, [SP]
    // 0x605674: r0 = ==()
    //     0x605674: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x605678: tbnz            w0, #4, #0x605690
    // 0x60567c: r0 = "We Don\'t Break User Space"
    //     0x60567c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a1a0] "We Don\'t Break User Space"
    //     0x605680: ldr             x0, [x0, #0x1a0]
    // 0x605684: LeaveFrame
    //     0x605684: mov             SP, fp
    //     0x605688: ldp             fp, lr, [SP], #0x10
    // 0x60568c: ret
    //     0x60568c: ret             
    // 0x605690: r16 = "16"
    //     0x605690: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x605694: ldr             x16, [x16, #0x350]
    // 0x605698: ldur            lr, [fp, #-8]
    // 0x60569c: stp             lr, x16, [SP]
    // 0x6056a0: r0 = ==()
    //     0x6056a0: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6056a4: tbnz            w0, #4, #0x6056bc
    // 0x6056a8: r0 = "You\'ll Own Nothing And You\'ll Be Happy"
    //     0x6056a8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a1a8] "You\'ll Own Nothing And You\'ll Be Happy"
    //     0x6056ac: ldr             x0, [x0, #0x1a8]
    // 0x6056b0: LeaveFrame
    //     0x6056b0: mov             SP, fp
    //     0x6056b4: ldp             fp, lr, [SP], #0x10
    // 0x6056b8: ret
    //     0x6056b8: ret             
    // 0x6056bc: r16 = "17"
    //     0x6056bc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x6056c0: ldr             x16, [x16, #0x358]
    // 0x6056c4: ldur            lr, [fp, #-8]
    // 0x6056c8: stp             lr, x16, [SP]
    // 0x6056cc: r0 = ==()
    //     0x6056cc: bl              #0x7c87d4  ; [dart:core] _OneByteString::==
    // 0x6056d0: tbnz            w0, #4, #0x6056e8
    // 0x6056d4: r0 = "Year Of Leinix On The Desktop"
    //     0x6056d4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a1b0] "Year Of Leinix On The Desktop"
    //     0x6056d8: ldr             x0, [x0, #0x1b0]
    // 0x6056dc: LeaveFrame
    //     0x6056dc: mov             SP, fp
    //     0x6056e0: ldp             fp, lr, [SP], #0x10
    // 0x6056e4: ret
    //     0x6056e4: ret             
    // 0x6056e8: ldur            x0, [fp, #-8]
    // 0x6056ec: r1 = Null
    //     0x6056ec: mov             x1, NULL
    // 0x6056f0: r2 = 4
    //     0x6056f0: movz            x2, #0x4
    // 0x6056f4: r0 = AllocateArray()
    //     0x6056f4: bl              #0x82746c  ; AllocateArrayStub
    // 0x6056f8: r16 = "Unknown act num: "
    //     0x6056f8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a1b8] "Unknown act num: "
    //     0x6056fc: ldr             x16, [x16, #0x1b8]
    // 0x605700: StoreField: r0->field_f = r16
    //     0x605700: stur            w16, [x0, #0xf]
    // 0x605704: ldur            x1, [fp, #-8]
    // 0x605708: StoreField: r0->field_13 = r1
    //     0x605708: stur            w1, [x0, #0x13]
    // 0x60570c: str             x0, [SP]
    // 0x605710: r0 = _interpolate()
    //     0x605710: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x605714: stur            x0, [fp, #-8]
    // 0x605718: r0 = current()
    //     0x605718: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x60571c: ldur            x1, [fp, #-8]
    // 0x605720: mov             x2, x0
    // 0x605724: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x605724: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x605728: r0 = crashlyticsRecordError()
    //     0x605728: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x60572c: r0 = "\?\?\?"
    //     0x60572c: add             x0, PP, #0x10, lsl #12  ; [pp+0x10af0] "\?\?\?"
    //     0x605730: ldr             x0, [x0, #0xaf0]
    // 0x605734: LeaveFrame
    //     0x605734: mov             SP, fp
    //     0x605738: ldp             fp, lr, [SP], #0x10
    // 0x60573c: ret
    //     0x60573c: ret             
    // 0x605740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x605740: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x605744: b               #0x605400
  }
  static void deleteCustomLevel(String) {
    // ** addr: 0x6070a0, size: 0x148
    // 0x6070a0: EnterFrame
    //     0x6070a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6070a4: mov             fp, SP
    // 0x6070a8: AllocStack(0x28)
    //     0x6070a8: sub             SP, SP, #0x28
    // 0x6070ac: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x6070ac: mov             x2, x1
    //     0x6070b0: stur            x1, [fp, #-8]
    // 0x6070b4: CheckStackOverflow
    //     0x6070b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6070b8: cmp             SP, x16
    //     0x6070bc: b.ls            #0x6071e0
    // 0x6070c0: r0 = currentChapterName()
    //     0x6070c0: bl              #0x372e24  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::currentChapterName
    // 0x6070c4: r1 = LoadClassIdInstr(r0)
    //     0x6070c4: ldur            x1, [x0, #-1]
    //     0x6070c8: ubfx            x1, x1, #0xc, #0x14
    // 0x6070cc: ldur            x16, [fp, #-8]
    // 0x6070d0: stp             x16, x0, [SP]
    // 0x6070d4: mov             x0, x1
    // 0x6070d8: mov             lr, x0
    // 0x6070dc: ldr             lr, [x21, lr, lsl #3]
    // 0x6070e0: blr             lr
    // 0x6070e4: tbnz            w0, #4, #0x6070f4
    // 0x6070e8: r1 = "1"
    //     0x6070e8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x6070ec: ldr             x1, [x1, #0x9c8]
    // 0x6070f0: r0 = changeChapter()
    //     0x6070f0: bl              #0x48fd08  ; [package:pretentious/Popups/ChaptersDisplay.dart] ::changeChapter
    // 0x6070f4: r0 = LoadStaticField(0xf5c)
    //     0x6070f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6070f8: ldr             x0, [x0, #0x1eb8]
    // 0x6070fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x607100: cmp             w0, w16
    // 0x607104: b.ne            #0x607114
    // 0x607108: r2 = customLevels
    //     0x607108: add             x2, PP, #0xf, lsl #12  ; [pp+0xf368] Field <::.customLevels>: static late (offset: 0xf5c)
    //     0x60710c: ldr             x2, [x2, #0x368]
    // 0x607110: r0 = InitLateStaticField()
    //     0x607110: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x607114: mov             x1, x0
    // 0x607118: ldur            x2, [fp, #-8]
    // 0x60711c: r0 = remove()
    //     0x60711c: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x607120: r0 = customLevelsDirectory()
    //     0x607120: bl              #0x4643d8  ; [package:pretentious/main.dart] ::customLevelsDirectory
    // 0x607124: stur            x0, [fp, #-0x10]
    // 0x607128: r0 = current()
    //     0x607128: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x60712c: r0 = _Directory()
    //     0x60712c: bl              #0x3422d0  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0x607130: mov             x2, x0
    // 0x607134: ldur            x0, [fp, #-0x10]
    // 0x607138: stur            x2, [fp, #-0x18]
    // 0x60713c: StoreField: r2->field_7 = r0
    //     0x60713c: stur            w0, [x2, #7]
    // 0x607140: mov             x1, x0
    // 0x607144: r0 = _toUtf8Array()
    //     0x607144: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x607148: ldur            x2, [fp, #-0x18]
    // 0x60714c: StoreField: r2->field_b = r0
    //     0x60714c: stur            w0, [x2, #0xb]
    //     0x607150: ldurb           w16, [x2, #-1]
    //     0x607154: ldurb           w17, [x0, #-1]
    //     0x607158: and             x16, x17, x16, lsr #2
    //     0x60715c: tst             x16, HEAP, lsr #32
    //     0x607160: b.eq            #0x607168
    //     0x607164: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x607168: mov             x1, x2
    // 0x60716c: r0 = existsSync()
    //     0x60716c: bl              #0x36fe80  ; [dart:io] _Directory::existsSync
    // 0x607170: tbz             w0, #4, #0x607180
    // 0x607174: ldur            x1, [fp, #-0x18]
    // 0x607178: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x607178: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x60717c: r0 = createSync()
    //     0x60717c: bl              #0x36fac4  ; [dart:io] _Directory::createSync
    // 0x607180: ldur            x1, [fp, #-0x10]
    // 0x607184: ldur            x2, [fp, #-8]
    // 0x607188: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x607188: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x60718c: r0 = join()
    //     0x60718c: bl              #0x36fa2c  ; [package:path/path.dart] ::join
    // 0x607190: stur            x0, [fp, #-8]
    // 0x607194: r0 = current()
    //     0x607194: bl              #0x3426e0  ; [dart:io] IOOverrides::current
    // 0x607198: r0 = _File()
    //     0x607198: bl              #0x342dfc  ; Allocate_FileStub -> _File (size=0x10)
    // 0x60719c: ldur            x1, [fp, #-8]
    // 0x6071a0: stur            x0, [fp, #-0x10]
    // 0x6071a4: StoreField: r0->field_7 = r1
    //     0x6071a4: stur            w1, [x0, #7]
    // 0x6071a8: r0 = _toUtf8Array()
    //     0x6071a8: bl              #0x3425b0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x6071ac: ldur            x1, [fp, #-0x10]
    // 0x6071b0: StoreField: r1->field_b = r0
    //     0x6071b0: stur            w0, [x1, #0xb]
    //     0x6071b4: ldurb           w16, [x1, #-1]
    //     0x6071b8: ldurb           w17, [x0, #-1]
    //     0x6071bc: and             x16, x17, x16, lsr #2
    //     0x6071c0: tst             x16, HEAP, lsr #32
    //     0x6071c4: b.eq            #0x6071cc
    //     0x6071c8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x6071cc: r0 = delete()
    //     0x6071cc: bl              #0x59ca04  ; [dart:io] FileSystemEntity::delete
    // 0x6071d0: r0 = Null
    //     0x6071d0: mov             x0, NULL
    // 0x6071d4: LeaveFrame
    //     0x6071d4: mov             SP, fp
    //     0x6071d8: ldp             fp, lr, [SP], #0x10
    // 0x6071dc: ret
    //     0x6071dc: ret             
    // 0x6071e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6071e0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6071e4: b               #0x6070c0
  }
  static Future<void> resetAllProgress() async {
    // ** addr: 0x633c34, size: 0x19c
    // 0x633c34: EnterFrame
    //     0x633c34: stp             fp, lr, [SP, #-0x10]!
    //     0x633c38: mov             fp, SP
    // 0x633c3c: AllocStack(0x20)
    //     0x633c3c: sub             SP, SP, #0x20
    // 0x633c40: SetupParameters()
    //     0x633c40: stur            NULL, [fp, #-8]
    // 0x633c44: CheckStackOverflow
    //     0x633c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x633c48: cmp             SP, x16
    //     0x633c4c: b.ls            #0x633da8
    // 0x633c50: InitAsync() -> Future<void?>
    //     0x633c50: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x633c54: bl              #0x34b9a0  ; InitAsyncStub
    // 0x633c58: r0 = 1
    //     0x633c58: movz            x0, #0x1
    // 0x633c5c: stur            x0, [fp, #-0x10]
    // 0x633c60: CheckStackOverflow
    //     0x633c60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x633c64: cmp             SP, x16
    //     0x633c68: b.ls            #0x633db0
    // 0x633c6c: cmp             x0, #0x11
    // 0x633c70: b.gt            #0x633d40
    // 0x633c74: r1 = Null
    //     0x633c74: mov             x1, NULL
    // 0x633c78: r2 = 4
    //     0x633c78: movz            x2, #0x4
    // 0x633c7c: r0 = AllocateArray()
    //     0x633c7c: bl              #0x82746c  ; AllocateArrayStub
    // 0x633c80: mov             x2, x0
    // 0x633c84: r16 = "difficulty_index_"
    //     0x633c84: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cd0] "difficulty_index_"
    //     0x633c88: ldr             x16, [x16, #0xcd0]
    // 0x633c8c: StoreField: r2->field_f = r16
    //     0x633c8c: stur            w16, [x2, #0xf]
    // 0x633c90: ldur            x3, [fp, #-0x10]
    // 0x633c94: r0 = BoxInt64Instr(r3)
    //     0x633c94: sbfiz           x0, x3, #1, #0x1f
    //     0x633c98: cmp             x3, x0, asr #1
    //     0x633c9c: b.eq            #0x633ca8
    //     0x633ca0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x633ca4: stur            x3, [x0, #7]
    // 0x633ca8: stur            x0, [fp, #-0x18]
    // 0x633cac: StoreField: r2->field_13 = r0
    //     0x633cac: stur            w0, [x2, #0x13]
    // 0x633cb0: str             x2, [SP]
    // 0x633cb4: r0 = _interpolate()
    //     0x633cb4: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x633cb8: mov             x1, x0
    // 0x633cbc: r0 = LoadStaticField(0xa6c)
    //     0x633cbc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x633cc0: ldr             x0, [x0, #0x14d8]
    // 0x633cc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x633cc8: cmp             w0, w16
    // 0x633ccc: b.eq            #0x633db8
    // 0x633cd0: mov             x2, x1
    // 0x633cd4: mov             x1, x0
    // 0x633cd8: r0 = remove()
    //     0x633cd8: bl              #0x46f904  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::remove
    // 0x633cdc: ldur            x0, [fp, #-0x18]
    // 0x633ce0: r1 = 60
    //     0x633ce0: movz            x1, #0x3c
    // 0x633ce4: branchIfSmi(r0, 0x633cf0)
    //     0x633ce4: tbz             w0, #0, #0x633cf0
    // 0x633ce8: r1 = LoadClassIdInstr(r0)
    //     0x633ce8: ldur            x1, [x0, #-1]
    //     0x633cec: ubfx            x1, x1, #0xc, #0x14
    // 0x633cf0: str             x0, [SP]
    // 0x633cf4: mov             x0, x1
    // 0x633cf8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x633cf8: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x633cfc: r0 = GDT[cid_x0 + 0x3019]()
    //     0x633cfc: movz            x17, #0x3019
    //     0x633d00: add             lr, x0, x17
    //     0x633d04: ldr             lr, [x21, lr, lsl #3]
    //     0x633d08: blr             lr
    // 0x633d0c: r16 = true
    //     0x633d0c: add             x16, NULL, #0x20  ; true
    // 0x633d10: str             x16, [SP]
    // 0x633d14: mov             x1, x0
    // 0x633d18: r4 = const [0, 0x2, 0x1, 0x1, ignoreError, 0x1, null]
    //     0x633d18: add             x4, PP, #0x33, lsl #12  ; [pp+0x338b0] List(7) [0, 0x2, 0x1, 0x1, "ignoreError", 0x1, Null]
    //     0x633d1c: ldr             x4, [x4, #0x8b0]
    // 0x633d20: r0 = resetGivenChapter()
    //     0x633d20: bl              #0x5a210c  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::resetGivenChapter
    // 0x633d24: mov             x1, x0
    // 0x633d28: stur            x1, [fp, #-0x18]
    // 0x633d2c: r0 = Await()
    //     0x633d2c: bl              #0x34b75c  ; AwaitStub
    // 0x633d30: ldur            x0, [fp, #-0x10]
    // 0x633d34: add             x1, x0, #1
    // 0x633d38: mov             x0, x1
    // 0x633d3c: b               #0x633c5c
    // 0x633d40: r1 = "1"
    //     0x633d40: add             x1, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x633d44: ldr             x1, [x1, #0x9c8]
    // 0x633d48: r0 = changeChapter()
    //     0x633d48: bl              #0x48fd08  ; [package:pretentious/Popups/ChaptersDisplay.dart] ::changeChapter
    // 0x633d4c: r0 = LoadStaticField(0xf7c)
    //     0x633d4c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x633d50: ldr             x0, [x0, #0x1ef8]
    // 0x633d54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x633d58: cmp             w0, w16
    // 0x633d5c: b.eq            #0x633dc4
    // 0x633d60: mov             x1, x0
    // 0x633d64: r0 = clearAllDataAndSave()
    //     0x633d64: bl              #0x633e28  ; [package:pretentious/data/CoreData.dart] CoreData::clearAllDataAndSave
    // 0x633d68: mov             x1, x0
    // 0x633d6c: stur            x1, [fp, #-0x18]
    // 0x633d70: r0 = Await()
    //     0x633d70: bl              #0x34b75c  ; AwaitStub
    // 0x633d74: r1 = LoadStaticField(0xf7c)
    //     0x633d74: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x633d78: ldr             x1, [x1, #0x1ef8]
    // 0x633d7c: r0 = recomputeTokenBoost()
    //     0x633d7c: bl              #0x4802e8  ; [package:pretentious/data/CoreData.dart] CoreData::recomputeTokenBoost
    // 0x633d80: r1 = LoadStaticField(0xf9c)
    //     0x633d80: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x633d84: ldr             x1, [x1, #0x1f38]
    // 0x633d88: cmp             w1, NULL
    // 0x633d8c: b.eq            #0x633da0
    // 0x633d90: r2 = "DELETE FROM completion_times"
    //     0x633d90: add             x2, PP, #0x33, lsl #12  ; [pp+0x338b8] "DELETE FROM completion_times"
    //     0x633d94: ldr             x2, [x2, #0x8b8]
    // 0x633d98: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x633d98: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x633d9c: r0 = execute()
    //     0x633d9c: bl              #0x473ec4  ; [package:sql_with_isolates/src/db_isolate.dart] DbIsolate::execute
    // 0x633da0: r0 = Null
    //     0x633da0: mov             x0, NULL
    // 0x633da4: r0 = ReturnAsyncNotFuture()
    //     0x633da4: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x633da8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x633da8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633dac: b               #0x633c50
    // 0x633db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x633db0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633db4: b               #0x633c6c
    // 0x633db8: r9 = prefs
    //     0x633db8: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x633dbc: ldr             x9, [x9, #0xc00]
    // 0x633dc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x633dc0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x633dc4: r9 = coreData
    //     0x633dc4: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x633dc8: ldr             x9, [x9, #0x530]
    // 0x633dcc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x633dcc: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
