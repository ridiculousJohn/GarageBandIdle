// lib: , url: package:pretentious/data/Chapters/IPlayableGameState.dart

// class id: 1049467, size: 0x8
class :: {

  static _ sanitizeLoadedData(/* No info */) {
    // ** addr: 0x460ccc, size: 0x100
    // 0x460ccc: EnterFrame
    //     0x460ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x460cd0: mov             fp, SP
    // 0x460cd4: AllocStack(0x18)
    //     0x460cd4: sub             SP, SP, #0x18
    // 0x460cd8: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x460cd8: mov             x0, x1
    //     0x460cdc: stur            x1, [fp, #-8]
    // 0x460ce0: CheckStackOverflow
    //     0x460ce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x460ce4: cmp             SP, x16
    //     0x460ce8: b.ls            #0x460dc4
    // 0x460cec: LoadField: d0 = r2->field_7
    //     0x460cec: ldur            d0, [x2, #7]
    // 0x460cf0: fcmp            d0, d0
    // 0x460cf4: b.vc            #0x460d4c
    // 0x460cf8: r1 = Null
    //     0x460cf8: mov             x1, NULL
    // 0x460cfc: r2 = 4
    //     0x460cfc: movz            x2, #0x4
    // 0x460d00: r0 = AllocateArray()
    //     0x460d00: bl              #0x82746c  ; AllocateArrayStub
    // 0x460d04: r16 = "Found NaN value in stat: "
    //     0x460d04: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cc0] "Found NaN value in stat: "
    //     0x460d08: ldr             x16, [x16, #0xcc0]
    // 0x460d0c: StoreField: r0->field_f = r16
    //     0x460d0c: stur            w16, [x0, #0xf]
    // 0x460d10: ldur            x3, [fp, #-8]
    // 0x460d14: StoreField: r0->field_13 = r3
    //     0x460d14: stur            w3, [x0, #0x13]
    // 0x460d18: str             x0, [SP]
    // 0x460d1c: r0 = _interpolate()
    //     0x460d1c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x460d20: stur            x0, [fp, #-0x10]
    // 0x460d24: r0 = current()
    //     0x460d24: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x460d28: ldur            x1, [fp, #-0x10]
    // 0x460d2c: mov             x2, x0
    // 0x460d30: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x460d30: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x460d34: r0 = crashlyticsRecordError()
    //     0x460d34: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x460d38: r0 = Instance_CustomNum
    //     0x460d38: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x460d3c: ldr             x0, [x0, #0xaf8]
    // 0x460d40: LeaveFrame
    //     0x460d40: mov             SP, fp
    //     0x460d44: ldp             fp, lr, [SP], #0x10
    // 0x460d48: ret
    //     0x460d48: ret             
    // 0x460d4c: mov             x3, x0
    // 0x460d50: d1 = inf
    //     0x460d50: ldr             d1, [PP, #0xba8]  ; [pp+0xba8] IMM: double(inf) from 0x7ff0000000000000
    // 0x460d54: fcmp            d0, d1
    // 0x460d58: b.ne            #0x460db0
    // 0x460d5c: r1 = Null
    //     0x460d5c: mov             x1, NULL
    // 0x460d60: r2 = 4
    //     0x460d60: movz            x2, #0x4
    // 0x460d64: r0 = AllocateArray()
    //     0x460d64: bl              #0x82746c  ; AllocateArrayStub
    // 0x460d68: r16 = "Found infinite value in stat: "
    //     0x460d68: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cc8] "Found infinite value in stat: "
    //     0x460d6c: ldr             x16, [x16, #0xcc8]
    // 0x460d70: StoreField: r0->field_f = r16
    //     0x460d70: stur            w16, [x0, #0xf]
    // 0x460d74: ldur            x1, [fp, #-8]
    // 0x460d78: StoreField: r0->field_13 = r1
    //     0x460d78: stur            w1, [x0, #0x13]
    // 0x460d7c: str             x0, [SP]
    // 0x460d80: r0 = _interpolate()
    //     0x460d80: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x460d84: stur            x0, [fp, #-8]
    // 0x460d88: r0 = current()
    //     0x460d88: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x460d8c: ldur            x1, [fp, #-8]
    // 0x460d90: mov             x2, x0
    // 0x460d94: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x460d94: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x460d98: r0 = crashlyticsRecordError()
    //     0x460d98: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x460d9c: r0 = Instance_CustomNum
    //     0x460d9c: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x460da0: ldr             x0, [x0, #0xaf8]
    // 0x460da4: LeaveFrame
    //     0x460da4: mov             SP, fp
    //     0x460da8: ldp             fp, lr, [SP], #0x10
    // 0x460dac: ret
    //     0x460dac: ret             
    // 0x460db0: r1 = Null
    //     0x460db0: mov             x1, NULL
    // 0x460db4: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x460db4: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x460db8: LeaveFrame
    //     0x460db8: mov             SP, fp
    //     0x460dbc: ldp             fp, lr, [SP], #0x10
    // 0x460dc0: ret
    //     0x460dc0: ret             
    // 0x460dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460dc4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460dc8: b               #0x460cec
  }
  static _ getDifficultyIndex(/* No info */) {
    // ** addr: 0x460dcc, size: 0x1b4
    // 0x460dcc: EnterFrame
    //     0x460dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x460dd0: mov             fp, SP
    // 0x460dd4: AllocStack(0x20)
    //     0x460dd4: sub             SP, SP, #0x20
    // 0x460dd8: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x460dd8: mov             x0, x1
    //     0x460ddc: stur            x1, [fp, #-8]
    // 0x460de0: CheckStackOverflow
    //     0x460de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x460de4: cmp             SP, x16
    //     0x460de8: b.ls            #0x460f54
    // 0x460dec: mov             x1, x0
    // 0x460df0: r0 = allowDifficultyChoosing()
    //     0x460df0: bl              #0x4619e8  ; [package:pretentious/widgets/difficulty_indicator.dart] ::allowDifficultyChoosing
    // 0x460df4: tbz             w0, #4, #0x460e08
    // 0x460df8: r0 = 0
    //     0x460df8: movz            x0, #0
    // 0x460dfc: LeaveFrame
    //     0x460dfc: mov             SP, fp
    //     0x460e00: ldp             fp, lr, [SP], #0x10
    // 0x460e04: ret
    //     0x460e04: ret             
    // 0x460e08: ldur            x0, [fp, #-8]
    // 0x460e0c: r1 = Null
    //     0x460e0c: mov             x1, NULL
    // 0x460e10: r2 = 4
    //     0x460e10: movz            x2, #0x4
    // 0x460e14: r0 = AllocateArray()
    //     0x460e14: bl              #0x82746c  ; AllocateArrayStub
    // 0x460e18: r16 = "difficulty_index_"
    //     0x460e18: add             x16, PP, #0x10, lsl #12  ; [pp+0x10cd0] "difficulty_index_"
    //     0x460e1c: ldr             x16, [x16, #0xcd0]
    // 0x460e20: StoreField: r0->field_f = r16
    //     0x460e20: stur            w16, [x0, #0xf]
    // 0x460e24: ldur            x1, [fp, #-8]
    // 0x460e28: StoreField: r0->field_13 = r1
    //     0x460e28: stur            w1, [x0, #0x13]
    // 0x460e2c: str             x0, [SP]
    // 0x460e30: r0 = _interpolate()
    //     0x460e30: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x460e34: mov             x1, x0
    // 0x460e38: r0 = prefsGetInt()
    //     0x460e38: bl              #0x36dc74  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetInt
    // 0x460e3c: cmp             w0, NULL
    // 0x460e40: b.eq            #0x460e60
    // 0x460e44: r1 = LoadInt32Instr(r0)
    //     0x460e44: sbfx            x1, x0, #1, #0x1f
    //     0x460e48: tbz             w0, #0, #0x460e50
    //     0x460e4c: ldur            x1, [x0, #7]
    // 0x460e50: mov             x0, x1
    // 0x460e54: LeaveFrame
    //     0x460e54: mov             SP, fp
    //     0x460e58: ldp             fp, lr, [SP], #0x10
    // 0x460e5c: ret
    //     0x460e5c: ret             
    // 0x460e60: ldur            x1, [fp, #-8]
    // 0x460e64: r0 = getReferenceMultiplier()
    //     0x460e64: bl              #0x460fc0  ; [package:pretentious/widgets/difficulty_indicator.dart] ::getReferenceMultiplier
    // 0x460e68: cmp             w0, NULL
    // 0x460e6c: b.ne            #0x460e80
    // 0x460e70: r0 = 0
    //     0x460e70: movz            x0, #0
    // 0x460e74: LeaveFrame
    //     0x460e74: mov             SP, fp
    //     0x460e78: ldp             fp, lr, [SP], #0x10
    // 0x460e7c: ret
    //     0x460e7c: ret             
    // 0x460e80: mov             x1, x0
    // 0x460e84: r2 = Instance_CustomNum
    //     0x460e84: add             x2, PP, #0x10, lsl #12  ; [pp+0x10448] Obj!CustomNum@828c41
    //     0x460e88: ldr             x2, [x2, #0x448]
    // 0x460e8c: r0 = div()
    //     0x460e8c: bl              #0x460f80  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::div
    // 0x460e90: LoadField: d0 = r0->field_7
    //     0x460e90: ldur            d0, [x0, #7]
    // 0x460e94: stur            d0, [fp, #-0x10]
    // 0x460e98: mov             x0, v0.d[0]
    // 0x460e9c: and             x0, x0, #0x7fffffffffffffff
    // 0x460ea0: r17 = 9218868437227405312
    //     0x460ea0: orr             x17, xzr, #0x7ff0000000000000
    // 0x460ea4: cmp             x0, x17
    // 0x460ea8: b.ne            #0x460ebc
    // 0x460eac: r0 = 0
    //     0x460eac: movz            x0, #0
    // 0x460eb0: LeaveFrame
    //     0x460eb0: mov             SP, fp
    //     0x460eb4: ldp             fp, lr, [SP], #0x10
    // 0x460eb8: ret
    //     0x460eb8: ret             
    // 0x460ebc: r16 = 4
    //     0x460ebc: movz            x16, #0x4
    // 0x460ec0: stp             x16, NULL, [SP]
    // 0x460ec4: r0 = _Double.fromInteger()
    //     0x460ec4: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x460ec8: LoadField: d0 = r0->field_7
    //     0x460ec8: ldur            d0, [x0, #7]
    // 0x460ecc: stp             fp, lr, [SP, #-0x10]!
    // 0x460ed0: mov             fp, SP
    // 0x460ed4: CallRuntime_LibcLog(double) -> double
    //     0x460ed4: and             SP, SP, #0xfffffffffffffff0
    //     0x460ed8: mov             sp, SP
    //     0x460edc: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x460ee0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x460ee4: blr             x16
    //     0x460ee8: movz            x16, #0x8
    //     0x460eec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x460ef0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x460ef4: sub             sp, x16, #1, lsl #12
    //     0x460ef8: mov             SP, fp
    //     0x460efc: ldp             fp, lr, [SP], #0x10
    // 0x460f00: mov             v1.16b, v0.16b
    // 0x460f04: ldur            d0, [fp, #-0x10]
    // 0x460f08: fdiv            d2, d0, d1
    // 0x460f0c: fcmp            d2, d2
    // 0x460f10: b.vs            #0x460f5c
    // 0x460f14: fcvtms          x1, d2
    // 0x460f18: asr             x16, x1, #0x1e
    // 0x460f1c: cmp             x16, x1, asr #63
    // 0x460f20: b.ne            #0x460f5c
    // 0x460f24: lsl             x1, x1, #1
    // 0x460f28: r0 = LoadInt32Instr(r1)
    //     0x460f28: sbfx            x0, x1, #1, #0x1f
    //     0x460f2c: tbz             w1, #0, #0x460f34
    //     0x460f30: ldur            x0, [x1, #7]
    // 0x460f34: tbz             x0, #0x3f, #0x460f48
    // 0x460f38: r0 = 0
    //     0x460f38: movz            x0, #0
    // 0x460f3c: LeaveFrame
    //     0x460f3c: mov             SP, fp
    //     0x460f40: ldp             fp, lr, [SP], #0x10
    // 0x460f44: ret
    //     0x460f44: ret             
    // 0x460f48: LeaveFrame
    //     0x460f48: mov             SP, fp
    //     0x460f4c: ldp             fp, lr, [SP], #0x10
    // 0x460f50: ret
    //     0x460f50: ret             
    // 0x460f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460f54: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460f58: b               #0x460dec
    // 0x460f5c: SaveReg d2
    //     0x460f5c: str             q2, [SP, #-0x10]!
    // 0x460f60: d0 = 0.000000
    //     0x460f60: fmov            d0, d2
    // 0x460f64: r0 = 70
    //     0x460f64: movz            x0, #0x46
    // 0x460f68: r30 = DoubleToIntegerStub
    //     0x460f68: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x460f6c: LoadField: r30 = r30->field_7
    //     0x460f6c: ldur            lr, [lr, #7]
    // 0x460f70: blr             lr
    // 0x460f74: mov             x1, x0
    // 0x460f78: RestoreReg d2
    //     0x460f78: ldr             q2, [SP], #0x10
    // 0x460f7c: b               #0x460f28
  }
}

// class id: 267, size: 0x8c, field offset: 0x38
abstract class IPlayableGameState<X0> extends IGameState<X0> {

  late int startMillisecondsSinceEpoch; // offset: 0x74

  _ _setCurrentDisplayProgress(/* No info */) {
    // ** addr: 0x4561dc, size: 0x68
    // 0x4561dc: EnterFrame
    //     0x4561dc: stp             fp, lr, [SP, #-0x10]!
    //     0x4561e0: mov             fp, SP
    // 0x4561e4: CheckStackOverflow
    //     0x4561e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4561e8: cmp             SP, x16
    //     0x4561ec: b.ls            #0x45623c
    // 0x4561f0: LoadField: r0 = r1->field_6b
    //     0x4561f0: ldur            x0, [x1, #0x6b]
    // 0x4561f4: cmp             x2, x0
    // 0x4561f8: b.lt            #0x45622c
    // 0x4561fc: StoreField: r1->field_6b = r2
    //     0x4561fc: stur            x2, [x1, #0x6b]
    // 0x456200: r0 = LoadStaticField(0x1040)
    //     0x456200: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x456204: ldr             x0, [x0, #0x2080]
    // 0x456208: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x45620c: cmp             w0, w16
    // 0x456210: b.ne            #0x456220
    // 0x456214: r2 = fragments
    //     0x456214: add             x2, PP, #0x10, lsl #12  ; [pp+0x100b8] Field <::.fragments>: static late (offset: 0x1040)
    //     0x456218: ldr             x2, [x2, #0xb8]
    // 0x45621c: r0 = InitLateStaticField()
    //     0x45621c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x456220: mov             x1, x0
    // 0x456224: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x456224: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x456228: r0 = notifyAll()
    //     0x456228: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x45622c: r0 = Null
    //     0x45622c: mov             x0, NULL
    // 0x456230: LeaveFrame
    //     0x456230: mov             SP, fp
    //     0x456234: ldp             fp, lr, [SP], #0x10
    // 0x456238: ret
    //     0x456238: ret             
    // 0x45623c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x45623c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x456240: b               #0x4561f0
  }
  _ IPlayableGameState(/* No info */) {
    // ** addr: 0x45f64c, size: 0x14bc
    // 0x45f64c: EnterFrame
    //     0x45f64c: stp             fp, lr, [SP, #-0x10]!
    //     0x45f650: mov             fp, SP
    // 0x45f654: AllocStack(0xc8)
    //     0x45f654: sub             SP, SP, #0xc8
    // 0x45f658: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x45f65c: mov             x9, x1
    // 0x45f660: mov             x8, x2
    // 0x45f664: mov             x4, x7
    // 0x45f668: stur            x7, [fp, #-0x98]
    // 0x45f66c: mov             x7, x3
    // 0x45f670: stur            x5, [fp, #-0x88]
    // 0x45f674: mov             x16, x6
    // 0x45f678: mov             x6, x5
    // 0x45f67c: mov             x5, x16
    // 0x45f680: stur            x1, [fp, #-0x70]
    // 0x45f684: stur            x2, [fp, #-0x78]
    // 0x45f688: stur            x3, [fp, #-0x80]
    // 0x45f68c: stur            x5, [fp, #-0x90]
    // 0x45f690: CheckStackOverflow
    //     0x45f690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45f694: cmp             SP, x16
    //     0x45f698: b.ls            #0x460af0
    // 0x45f69c: StoreField: r9->field_6b = rZR
    //     0x45f69c: stur            xzr, [x9, #0x6b]
    // 0x45f6a0: StoreField: r9->field_73 = r0
    //     0x45f6a0: stur            w0, [x9, #0x73]
    // 0x45f6a4: StoreField: r9->field_83 = rZR
    //     0x45f6a4: stur            xzr, [x9, #0x83]
    // 0x45f6a8: LoadField: r0 = r9->field_7
    //     0x45f6a8: ldur            w0, [x9, #7]
    // 0x45f6ac: DecompressPointer r0
    //     0x45f6ac: add             x0, x0, HEAP, lsl #32
    // 0x45f6b0: mov             x2, x0
    // 0x45f6b4: stur            x0, [fp, #-0x68]
    // 0x45f6b8: r1 = Null
    //     0x45f6b8: mov             x1, NULL
    // 0x45f6bc: r3 = <X0, CustomNum>
    //     0x45f6bc: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x45f6c0: ldr             x3, [x3, #0xb10]
    // 0x45f6c4: r30 = InstantiateTypeArgumentsStub
    //     0x45f6c4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x45f6c8: LoadField: r30 = r30->field_7
    //     0x45f6c8: ldur            lr, [lr, #7]
    // 0x45f6cc: blr             lr
    // 0x45f6d0: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x45f6d4: stp             x16, x0, [SP]
    // 0x45f6d8: r0 = Map._fromLiteral()
    //     0x45f6d8: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f6dc: ldur            x4, [fp, #-0x70]
    // 0x45f6e0: StoreField: r4->field_37 = r0
    //     0x45f6e0: stur            w0, [x4, #0x37]
    //     0x45f6e4: ldurb           w16, [x4, #-1]
    //     0x45f6e8: ldurb           w17, [x0, #-1]
    //     0x45f6ec: and             x16, x17, x16, lsr #2
    //     0x45f6f0: tst             x16, HEAP, lsr #32
    //     0x45f6f4: b.eq            #0x45f6fc
    //     0x45f6f8: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x45f6fc: ldur            x2, [fp, #-0x68]
    // 0x45f700: r1 = Null
    //     0x45f700: mov             x1, NULL
    // 0x45f704: r3 = <X0, CustomNum>
    //     0x45f704: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x45f708: ldr             x3, [x3, #0xb10]
    // 0x45f70c: r30 = InstantiateTypeArgumentsStub
    //     0x45f70c: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x45f710: LoadField: r30 = r30->field_7
    //     0x45f710: ldur            lr, [lr, #7]
    // 0x45f714: blr             lr
    // 0x45f718: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x45f71c: stp             x16, x0, [SP]
    // 0x45f720: r0 = Map._fromLiteral()
    //     0x45f720: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f724: ldur            x1, [fp, #-0x70]
    // 0x45f728: StoreField: r1->field_3b = r0
    //     0x45f728: stur            w0, [x1, #0x3b]
    //     0x45f72c: ldurb           w16, [x1, #-1]
    //     0x45f730: ldurb           w17, [x0, #-1]
    //     0x45f734: and             x16, x17, x16, lsr #2
    //     0x45f738: tst             x16, HEAP, lsr #32
    //     0x45f73c: b.eq            #0x45f744
    //     0x45f740: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f744: r16 = <int, int>
    //     0x45f744: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x45f748: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x45f74c: stp             lr, x16, [SP]
    // 0x45f750: r0 = Map._fromLiteral()
    //     0x45f750: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f754: stur            x0, [fp, #-0xa0]
    // 0x45f758: r0 = QuestBlock()
    //     0x45f758: bl              #0x462598  ; AllocateQuestBlockStub -> QuestBlock (size=0x14)
    // 0x45f75c: mov             x1, x0
    // 0x45f760: ldur            x0, [fp, #-0xa0]
    // 0x45f764: StoreField: r1->field_b = r0
    //     0x45f764: stur            w0, [x1, #0xb]
    // 0x45f768: mov             x0, x1
    // 0x45f76c: ldur            x1, [fp, #-0x70]
    // 0x45f770: StoreField: r1->field_3f = r0
    //     0x45f770: stur            w0, [x1, #0x3f]
    //     0x45f774: ldurb           w16, [x1, #-1]
    //     0x45f778: ldurb           w17, [x0, #-1]
    //     0x45f77c: and             x16, x17, x16, lsr #2
    //     0x45f780: tst             x16, HEAP, lsr #32
    //     0x45f784: b.eq            #0x45f78c
    //     0x45f788: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f78c: r16 = <int, int>
    //     0x45f78c: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x45f790: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x45f794: stp             lr, x16, [SP]
    // 0x45f798: r0 = Map._fromLiteral()
    //     0x45f798: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f79c: ldur            x1, [fp, #-0x70]
    // 0x45f7a0: StoreField: r1->field_43 = r0
    //     0x45f7a0: stur            w0, [x1, #0x43]
    //     0x45f7a4: ldurb           w16, [x1, #-1]
    //     0x45f7a8: ldurb           w17, [x0, #-1]
    //     0x45f7ac: and             x16, x17, x16, lsr #2
    //     0x45f7b0: tst             x16, HEAP, lsr #32
    //     0x45f7b4: b.eq            #0x45f7bc
    //     0x45f7b8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f7bc: r16 = <int, double>
    //     0x45f7bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x45f7c0: ldr             x16, [x16, #0x100]
    // 0x45f7c4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x45f7c8: stp             lr, x16, [SP]
    // 0x45f7cc: r0 = Map._fromLiteral()
    //     0x45f7cc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f7d0: ldur            x1, [fp, #-0x70]
    // 0x45f7d4: StoreField: r1->field_47 = r0
    //     0x45f7d4: stur            w0, [x1, #0x47]
    //     0x45f7d8: ldurb           w16, [x1, #-1]
    //     0x45f7dc: ldurb           w17, [x0, #-1]
    //     0x45f7e0: and             x16, x17, x16, lsr #2
    //     0x45f7e4: tst             x16, HEAP, lsr #32
    //     0x45f7e8: b.eq            #0x45f7f0
    //     0x45f7ec: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f7f0: r16 = <int, double>
    //     0x45f7f0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x45f7f4: ldr             x16, [x16, #0x100]
    // 0x45f7f8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x45f7fc: stp             lr, x16, [SP]
    // 0x45f800: r0 = Map._fromLiteral()
    //     0x45f800: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f804: ldur            x1, [fp, #-0x70]
    // 0x45f808: StoreField: r1->field_4b = r0
    //     0x45f808: stur            w0, [x1, #0x4b]
    //     0x45f80c: ldurb           w16, [x1, #-1]
    //     0x45f810: ldurb           w17, [x0, #-1]
    //     0x45f814: and             x16, x17, x16, lsr #2
    //     0x45f818: tst             x16, HEAP, lsr #32
    //     0x45f81c: b.eq            #0x45f824
    //     0x45f820: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f824: r16 = <int, double>
    //     0x45f824: add             x16, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x45f828: ldr             x16, [x16, #0x100]
    // 0x45f82c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x45f830: stp             lr, x16, [SP]
    // 0x45f834: r0 = Map._fromLiteral()
    //     0x45f834: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f838: ldur            x2, [fp, #-0x70]
    // 0x45f83c: StoreField: r2->field_4f = r0
    //     0x45f83c: stur            w0, [x2, #0x4f]
    //     0x45f840: ldurb           w16, [x2, #-1]
    //     0x45f844: ldurb           w17, [x0, #-1]
    //     0x45f848: and             x16, x17, x16, lsr #2
    //     0x45f84c: tst             x16, HEAP, lsr #32
    //     0x45f850: b.eq            #0x45f858
    //     0x45f854: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45f858: r1 = <int>
    //     0x45f858: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x45f85c: r0 = _Set()
    //     0x45f85c: bl              #0x339a6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x45f860: mov             x1, x0
    // 0x45f864: r0 = _Uint32List
    //     0x45f864: ldr             x0, [PP, #0xc08]  ; [pp+0xc08] _Uint32List(1) [0x0]
    // 0x45f868: StoreField: r1->field_1b = r0
    //     0x45f868: stur            w0, [x1, #0x1b]
    // 0x45f86c: StoreField: r1->field_b = rZR
    //     0x45f86c: stur            wzr, [x1, #0xb]
    // 0x45f870: r0 = const []
    //     0x45f870: ldr             x0, [PP, #0xc10]  ; [pp+0xc10] List(0) []
    // 0x45f874: StoreField: r1->field_f = r0
    //     0x45f874: stur            w0, [x1, #0xf]
    // 0x45f878: StoreField: r1->field_13 = rZR
    //     0x45f878: stur            wzr, [x1, #0x13]
    // 0x45f87c: ArrayStore: r1[0] = rZR  ; List_4
    //     0x45f87c: stur            wzr, [x1, #0x17]
    // 0x45f880: mov             x0, x1
    // 0x45f884: ldur            x4, [fp, #-0x70]
    // 0x45f888: StoreField: r4->field_53 = r0
    //     0x45f888: stur            w0, [x4, #0x53]
    //     0x45f88c: ldurb           w16, [x4, #-1]
    //     0x45f890: ldurb           w17, [x0, #-1]
    //     0x45f894: and             x16, x17, x16, lsr #2
    //     0x45f898: tst             x16, HEAP, lsr #32
    //     0x45f89c: b.eq            #0x45f8a4
    //     0x45f8a0: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x45f8a4: ldur            x2, [fp, #-0x68]
    // 0x45f8a8: r1 = Null
    //     0x45f8a8: mov             x1, NULL
    // 0x45f8ac: r3 = <X0, CustomNum>
    //     0x45f8ac: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x45f8b0: ldr             x3, [x3, #0xb10]
    // 0x45f8b4: r30 = InstantiateTypeArgumentsStub
    //     0x45f8b4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x45f8b8: LoadField: r30 = r30->field_7
    //     0x45f8b8: ldur            lr, [lr, #7]
    // 0x45f8bc: blr             lr
    // 0x45f8c0: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x45f8c4: stp             x16, x0, [SP]
    // 0x45f8c8: r0 = Map._fromLiteral()
    //     0x45f8c8: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f8cc: ldur            x1, [fp, #-0x70]
    // 0x45f8d0: StoreField: r1->field_57 = r0
    //     0x45f8d0: stur            w0, [x1, #0x57]
    //     0x45f8d4: ldurb           w16, [x1, #-1]
    //     0x45f8d8: ldurb           w17, [x0, #-1]
    //     0x45f8dc: and             x16, x17, x16, lsr #2
    //     0x45f8e0: tst             x16, HEAP, lsr #32
    //     0x45f8e4: b.eq            #0x45f8ec
    //     0x45f8e8: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x45f8ec: r16 = <int, DateTime>
    //     0x45f8ec: add             x16, PP, #0x10, lsl #12  ; [pp+0x10b18] TypeArguments: <int, DateTime>
    //     0x45f8f0: ldr             x16, [x16, #0xb18]
    // 0x45f8f4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x45f8f8: stp             lr, x16, [SP]
    // 0x45f8fc: r0 = Map._fromLiteral()
    //     0x45f8fc: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f900: ldur            x4, [fp, #-0x70]
    // 0x45f904: StoreField: r4->field_77 = r0
    //     0x45f904: stur            w0, [x4, #0x77]
    //     0x45f908: ldurb           w16, [x4, #-1]
    //     0x45f90c: ldurb           w17, [x0, #-1]
    //     0x45f910: and             x16, x17, x16, lsr #2
    //     0x45f914: tst             x16, HEAP, lsr #32
    //     0x45f918: b.eq            #0x45f920
    //     0x45f91c: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x45f920: ldur            x2, [fp, #-0x68]
    // 0x45f924: r1 = Null
    //     0x45f924: mov             x1, NULL
    // 0x45f928: r3 = <int, X0>
    //     0x45f928: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b20] TypeArguments: <int, X0>
    //     0x45f92c: ldr             x3, [x3, #0xb20]
    // 0x45f930: r30 = InstantiateTypeArgumentsStub
    //     0x45f930: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x45f934: LoadField: r30 = r30->field_7
    //     0x45f934: ldur            lr, [lr, #7]
    // 0x45f938: blr             lr
    // 0x45f93c: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x45f940: stp             x16, x0, [SP]
    // 0x45f944: r0 = Map._fromLiteral()
    //     0x45f944: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x45f948: ldur            x2, [fp, #-0x70]
    // 0x45f94c: StoreField: r2->field_7b = r0
    //     0x45f94c: stur            w0, [x2, #0x7b]
    //     0x45f950: ldurb           w16, [x2, #-1]
    //     0x45f954: ldurb           w17, [x0, #-1]
    //     0x45f958: and             x16, x17, x16, lsr #2
    //     0x45f95c: tst             x16, HEAP, lsr #32
    //     0x45f960: b.eq            #0x45f968
    //     0x45f964: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45f968: ldur            x0, [fp, #-0x88]
    // 0x45f96c: StoreField: r2->field_5b = r0
    //     0x45f96c: stur            w0, [x2, #0x5b]
    //     0x45f970: ldurb           w16, [x2, #-1]
    //     0x45f974: ldurb           w17, [x0, #-1]
    //     0x45f978: and             x16, x17, x16, lsr #2
    //     0x45f97c: tst             x16, HEAP, lsr #32
    //     0x45f980: b.eq            #0x45f988
    //     0x45f984: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45f988: ldur            x0, [fp, #-0x90]
    // 0x45f98c: StoreField: r2->field_5f = r0
    //     0x45f98c: stur            w0, [x2, #0x5f]
    //     0x45f990: ldurb           w16, [x2, #-1]
    //     0x45f994: ldurb           w17, [x0, #-1]
    //     0x45f998: and             x16, x17, x16, lsr #2
    //     0x45f99c: tst             x16, HEAP, lsr #32
    //     0x45f9a0: b.eq            #0x45f9a8
    //     0x45f9a4: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45f9a8: ldur            x0, [fp, #-0x98]
    // 0x45f9ac: StoreField: r2->field_63 = r0
    //     0x45f9ac: stur            w0, [x2, #0x63]
    //     0x45f9b0: ldurb           w16, [x2, #-1]
    //     0x45f9b4: ldurb           w17, [x0, #-1]
    //     0x45f9b8: and             x16, x17, x16, lsr #2
    //     0x45f9bc: tst             x16, HEAP, lsr #32
    //     0x45f9c0: b.eq            #0x45f9c8
    //     0x45f9c4: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x45f9c8: mov             x1, x2
    // 0x45f9cc: r0 = IGameState()
    //     0x45f9cc: bl              #0x45bbd0  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::IGameState
    // 0x45f9d0: ldur            x2, [fp, #-0x70]
    // 0x45f9d4: r0 = LoadClassIdInstr(r2)
    //     0x45f9d4: ldur            x0, [x2, #-1]
    //     0x45f9d8: ubfx            x0, x0, #0xc, #0x14
    // 0x45f9dc: mov             x1, x2
    // 0x45f9e0: r0 = GDT[cid_x0 + 0x973c]()
    //     0x45f9e0: movz            x17, #0x973c
    //     0x45f9e4: add             lr, x0, x17
    //     0x45f9e8: ldr             lr, [x21, lr, lsl #3]
    //     0x45f9ec: blr             lr
    // 0x45f9f0: ldur            x3, [fp, #-0x78]
    // 0x45f9f4: cmp             w3, NULL
    // 0x45f9f8: b.ne            #0x45fb68
    // 0x45f9fc: ldur            x2, [fp, #-0x70]
    // 0x45fa00: r0 = LoadClassIdInstr(r2)
    //     0x45fa00: ldur            x0, [x2, #-1]
    //     0x45fa04: ubfx            x0, x0, #0xc, #0x14
    // 0x45fa08: mov             x1, x2
    // 0x45fa0c: r0 = GDT[cid_x0 + 0x864e]()
    //     0x45fa0c: movz            x17, #0x864e
    //     0x45fa10: add             lr, x0, x17
    //     0x45fa14: ldr             lr, [x21, lr, lsl #3]
    //     0x45fa18: blr             lr
    // 0x45fa1c: r0 = LoadStaticField(0xa80)
    //     0x45fa1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x45fa20: ldr             x0, [x0, #0x1500]
    // 0x45fa24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x45fa28: cmp             w0, w16
    // 0x45fa2c: b.ne            #0x45fa3c
    // 0x45fa30: r2 = firebaseAnalyticsEnabled
    //     0x45fa30: add             x2, PP, #0x10, lsl #12  ; [pp+0x10b28] Field <::.firebaseAnalyticsEnabled>: static late (offset: 0xa80)
    //     0x45fa34: ldr             x2, [x2, #0xb28]
    // 0x45fa38: r0 = InitLateStaticField()
    //     0x45fa38: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x45fa3c: r4 = const [0, 0, 0, 0, null]
    //     0x45fa3c: ldr             x4, [PP, #0x2958]  ; [pp+0x2958] List(5) [0, 0, 0, 0, Null]
    // 0x45fa40: r0 = app()
    //     0x45fa40: bl              #0x3548dc  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x45fa44: mov             x2, x0
    // 0x45fa48: r1 = Null
    //     0x45fa48: mov             x1, NULL
    // 0x45fa4c: r0 = FirebaseAnalytics.instanceFor()
    //     0x45fa4c: bl              #0x4623c4  ; [package:firebase_analytics/firebase_analytics.dart] FirebaseAnalytics::FirebaseAnalytics.instanceFor
    // 0x45fa50: mov             x3, x0
    // 0x45fa54: ldur            x2, [fp, #-0x70]
    // 0x45fa58: stur            x3, [fp, #-0x68]
    // 0x45fa5c: r0 = LoadClassIdInstr(r2)
    //     0x45fa5c: ldur            x0, [x2, #-1]
    //     0x45fa60: ubfx            x0, x0, #0xc, #0x14
    // 0x45fa64: mov             x1, x2
    // 0x45fa68: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x45fa68: sub             lr, x0, #0xf3f
    //     0x45fa6c: ldr             lr, [x21, lr, lsl #3]
    //     0x45fa70: blr             lr
    // 0x45fa74: ldur            x1, [fp, #-0x68]
    // 0x45fa78: mov             x2, x0
    // 0x45fa7c: r0 = logLevelStart()
    //     0x45fa7c: bl              #0x461b20  ; [package:firebase_analytics/firebase_analytics.dart] FirebaseAnalytics::logLevelStart
    // 0x45fa80: ldur            x2, [fp, #-0x70]
    // 0x45fa84: r0 = LoadClassIdInstr(r2)
    //     0x45fa84: ldur            x0, [x2, #-1]
    //     0x45fa88: ubfx            x0, x0, #0xc, #0x14
    // 0x45fa8c: mov             x1, x2
    // 0x45fa90: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x45fa90: sub             lr, x0, #0xf3f
    //     0x45fa94: ldr             lr, [x21, lr, lsl #3]
    //     0x45fa98: blr             lr
    // 0x45fa9c: mov             x1, x0
    // 0x45faa0: r0 = allowDifficultyChoosing()
    //     0x45faa0: bl              #0x4619e8  ; [package:pretentious/widgets/difficulty_indicator.dart] ::allowDifficultyChoosing
    // 0x45faa4: tbnz            w0, #4, #0x45fad8
    // 0x45faa8: ldur            x2, [fp, #-0x70]
    // 0x45faac: r0 = LoadClassIdInstr(r2)
    //     0x45faac: ldur            x0, [x2, #-1]
    //     0x45fab0: ubfx            x0, x0, #0xc, #0x14
    // 0x45fab4: mov             x1, x2
    // 0x45fab8: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x45fab8: sub             lr, x0, #0xf3f
    //     0x45fabc: ldr             lr, [x21, lr, lsl #3]
    //     0x45fac0: blr             lr
    // 0x45fac4: mov             x1, x0
    // 0x45fac8: r0 = getDifficultyIndex()
    //     0x45fac8: bl              #0x460dcc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::getDifficultyIndex
    // 0x45facc: ldur            x1, [fp, #-0x70]
    // 0x45fad0: StoreField: r1->field_23 = r0
    //     0x45fad0: stur            x0, [x1, #0x23]
    // 0x45fad4: b               #0x45fadc
    // 0x45fad8: ldur            x1, [fp, #-0x70]
    // 0x45fadc: r0 = DateTime()
    //     0x45fadc: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x45fae0: r4 = false
    //     0x45fae0: add             x4, NULL, #0x30  ; false
    // 0x45fae4: stur            x0, [fp, #-0x68]
    // 0x45fae8: StoreField: r0->field_7 = r4
    //     0x45fae8: stur            w4, [x0, #7]
    // 0x45faec: r0 = _getCurrentMicros()
    //     0x45faec: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x45faf0: r1 = LoadInt32Instr(r0)
    //     0x45faf0: sbfx            x1, x0, #1, #0x1f
    //     0x45faf4: tbz             w0, #0, #0x45fafc
    //     0x45faf8: ldur            x1, [x0, #7]
    // 0x45fafc: ldur            x0, [fp, #-0x68]
    // 0x45fb00: StoreField: r0->field_b = r1
    //     0x45fb00: stur            x1, [x0, #0xb]
    // 0x45fb04: tbz             x1, #0x3f, #0x45fb10
    // 0x45fb08: r0 = 999
    //     0x45fb08: movz            x0, #0x3e7
    // 0x45fb0c: b               #0x45fb14
    // 0x45fb10: r0 = 0
    //     0x45fb10: movz            x0, #0
    // 0x45fb14: ldur            x5, [fp, #-0x70]
    // 0x45fb18: r6 = 1000
    //     0x45fb18: movz            x6, #0x3e8
    // 0x45fb1c: sub             x2, x1, x0
    // 0x45fb20: sdiv            x3, x2, x6
    // 0x45fb24: r0 = BoxInt64Instr(r3)
    //     0x45fb24: sbfiz           x0, x3, #1, #0x1f
    //     0x45fb28: cmp             x3, x0, asr #1
    //     0x45fb2c: b.eq            #0x45fb38
    //     0x45fb30: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x45fb34: stur            x3, [x0, #7]
    // 0x45fb38: StoreField: r5->field_73 = r0
    //     0x45fb38: stur            w0, [x5, #0x73]
    //     0x45fb3c: tbz             w0, #0, #0x45fb58
    //     0x45fb40: ldurb           w16, [x5, #-1]
    //     0x45fb44: ldurb           w17, [x0, #-1]
    //     0x45fb48: and             x16, x17, x16, lsr #2
    //     0x45fb4c: tst             x16, HEAP, lsr #32
    //     0x45fb50: b.eq            #0x45fb58
    //     0x45fb54: bl              #0x825b58  ; WriteBarrierWrappersStub
    // 0x45fb58: r0 = Null
    //     0x45fb58: mov             x0, NULL
    // 0x45fb5c: LeaveFrame
    //     0x45fb5c: mov             SP, fp
    //     0x45fb60: ldp             fp, lr, [SP], #0x10
    // 0x45fb64: ret
    //     0x45fb64: ret             
    // 0x45fb68: ldur            x5, [fp, #-0x70]
    // 0x45fb6c: r4 = false
    //     0x45fb6c: add             x4, NULL, #0x30  ; false
    // 0x45fb70: r6 = 1000
    //     0x45fb70: movz            x6, #0x3e8
    // 0x45fb74: r0 = LoadClassIdInstr(r3)
    //     0x45fb74: ldur            x0, [x3, #-1]
    //     0x45fb78: ubfx            x0, x0, #0xc, #0x14
    // 0x45fb7c: mov             x1, x3
    // 0x45fb80: r2 = 4
    //     0x45fb80: movz            x2, #0x4
    // 0x45fb84: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45fb84: sub             lr, x0, #1, lsl #12
    //     0x45fb88: ldr             lr, [x21, lr, lsl #3]
    //     0x45fb8c: blr             lr
    // 0x45fb90: mov             x3, x0
    // 0x45fb94: r2 = Null
    //     0x45fb94: mov             x2, NULL
    // 0x45fb98: r1 = Null
    //     0x45fb98: mov             x1, NULL
    // 0x45fb9c: stur            x3, [fp, #-0x68]
    // 0x45fba0: r8 = Map
    //     0x45fba0: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x45fba4: r3 = Null
    //     0x45fba4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b30] Null
    //     0x45fba8: ldr             x3, [x3, #0xb30]
    // 0x45fbac: r0 = Map()
    //     0x45fbac: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x45fbb0: ldur            x2, [fp, #-0x68]
    // 0x45fbb4: r1 = <int, double>
    //     0x45fbb4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x45fbb8: ldr             x1, [x1, #0x100]
    // 0x45fbbc: r0 = LinkedHashMap.from()
    //     0x45fbbc: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x45fbc0: stur            x0, [fp, #-0x68]
    // 0x45fbc4: LoadField: r2 = r0->field_7
    //     0x45fbc4: ldur            w2, [x0, #7]
    // 0x45fbc8: DecompressPointer r2
    //     0x45fbc8: add             x2, x2, HEAP, lsl #32
    // 0x45fbcc: r1 = Null
    //     0x45fbcc: mov             x1, NULL
    // 0x45fbd0: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x45fbd0: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x45fbd4: r30 = InstantiateTypeArgumentsStub
    //     0x45fbd4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x45fbd8: LoadField: r30 = r30->field_7
    //     0x45fbd8: ldur            lr, [lr, #7]
    // 0x45fbdc: blr             lr
    // 0x45fbe0: mov             x1, x0
    // 0x45fbe4: r0 = _CompactEntriesIterable()
    //     0x45fbe4: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x45fbe8: mov             x1, x0
    // 0x45fbec: ldur            x0, [fp, #-0x68]
    // 0x45fbf0: StoreField: r1->field_b = r0
    //     0x45fbf0: stur            w0, [x1, #0xb]
    // 0x45fbf4: r0 = iterator()
    //     0x45fbf4: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x45fbf8: stur            x0, [fp, #-0x90]
    // 0x45fbfc: r4 = Null
    //     0x45fbfc: mov             x4, NULL
    // 0x45fc00: r3 = Null
    //     0x45fc00: mov             x3, NULL
    // 0x45fc04: ldur            x2, [fp, #-0x70]
    // 0x45fc08: stur            x4, [fp, #-0x68]
    // 0x45fc0c: stur            x3, [fp, #-0x88]
    // 0x45fc10: CheckStackOverflow
    //     0x45fc10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45fc14: cmp             SP, x16
    //     0x45fc18: b.ls            #0x460af8
    // 0x45fc1c: mov             x1, x0
    // 0x45fc20: r0 = moveNext()
    //     0x45fc20: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x45fc24: tbnz            w0, #4, #0x45fd88
    // 0x45fc28: ldur            x1, [fp, #-0x90]
    // 0x45fc2c: LoadField: r2 = r1->field_2b
    //     0x45fc2c: ldur            w2, [x1, #0x2b]
    // 0x45fc30: DecompressPointer r2
    //     0x45fc30: add             x2, x2, HEAP, lsl #32
    // 0x45fc34: stur            x2, [fp, #-0xa8]
    // 0x45fc38: cmp             w2, NULL
    // 0x45fc3c: b.eq            #0x460ad8
    // 0x45fc40: ldur            x3, [fp, #-0x70]
    // 0x45fc44: LoadField: r4 = r3->field_37
    //     0x45fc44: ldur            w4, [x3, #0x37]
    // 0x45fc48: DecompressPointer r4
    //     0x45fc48: add             x4, x4, HEAP, lsl #32
    // 0x45fc4c: stur            x4, [fp, #-0xa0]
    // 0x45fc50: LoadField: r5 = r2->field_b
    //     0x45fc50: ldur            w5, [x2, #0xb]
    // 0x45fc54: DecompressPointer r5
    //     0x45fc54: add             x5, x5, HEAP, lsl #32
    // 0x45fc58: stur            x5, [fp, #-0x98]
    // 0x45fc5c: ldur            x16, [fp, #-0x80]
    // 0x45fc60: stp             x5, x16, [SP]
    // 0x45fc64: ldur            x0, [fp, #-0x80]
    // 0x45fc68: ClosureCall
    //     0x45fc68: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x45fc6c: ldur            x2, [x0, #0x1f]
    //     0x45fc70: blr             x2
    // 0x45fc74: mov             x1, x0
    // 0x45fc78: stur            x1, [fp, #-0xb0]
    // 0x45fc7c: ldur            x16, [fp, #-0x80]
    // 0x45fc80: ldur            lr, [fp, #-0x98]
    // 0x45fc84: stp             lr, x16, [SP]
    // 0x45fc88: ldur            x0, [fp, #-0x80]
    // 0x45fc8c: ClosureCall
    //     0x45fc8c: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x45fc90: ldur            x2, [x0, #0x1f]
    //     0x45fc94: blr             x2
    // 0x45fc98: mov             x1, x0
    // 0x45fc9c: ldur            x0, [fp, #-0xa8]
    // 0x45fca0: LoadField: r2 = r0->field_f
    //     0x45fca0: ldur            w2, [x0, #0xf]
    // 0x45fca4: DecompressPointer r2
    //     0x45fca4: add             x2, x2, HEAP, lsl #32
    // 0x45fca8: r0 = sanitizeLoadedData()
    //     0x45fca8: bl              #0x460ccc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::sanitizeLoadedData
    // 0x45fcac: mov             x4, x0
    // 0x45fcb0: ldur            x3, [fp, #-0xa0]
    // 0x45fcb4: stur            x4, [fp, #-0xb8]
    // 0x45fcb8: LoadField: r5 = r3->field_7
    //     0x45fcb8: ldur            w5, [x3, #7]
    // 0x45fcbc: DecompressPointer r5
    //     0x45fcbc: add             x5, x5, HEAP, lsl #32
    // 0x45fcc0: ldur            x0, [fp, #-0xb0]
    // 0x45fcc4: mov             x2, x5
    // 0x45fcc8: stur            x5, [fp, #-0x98]
    // 0x45fccc: r1 = Null
    //     0x45fccc: mov             x1, NULL
    // 0x45fcd0: cmp             w2, NULL
    // 0x45fcd4: b.eq            #0x45fcf4
    // 0x45fcd8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x45fcd8: ldur            w4, [x2, #0x17]
    // 0x45fcdc: DecompressPointer r4
    //     0x45fcdc: add             x4, x4, HEAP, lsl #32
    // 0x45fce0: r8 = X0
    //     0x45fce0: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x45fce4: LoadField: r9 = r4->field_7
    //     0x45fce4: ldur            x9, [x4, #7]
    // 0x45fce8: r3 = Null
    //     0x45fce8: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b40] Null
    //     0x45fcec: ldr             x3, [x3, #0xb40]
    // 0x45fcf0: blr             x9
    // 0x45fcf4: ldur            x0, [fp, #-0xb8]
    // 0x45fcf8: ldur            x2, [fp, #-0x98]
    // 0x45fcfc: r1 = Null
    //     0x45fcfc: mov             x1, NULL
    // 0x45fd00: cmp             w2, NULL
    // 0x45fd04: b.eq            #0x45fd24
    // 0x45fd08: LoadField: r4 = r2->field_1b
    //     0x45fd08: ldur            w4, [x2, #0x1b]
    // 0x45fd0c: DecompressPointer r4
    //     0x45fd0c: add             x4, x4, HEAP, lsl #32
    // 0x45fd10: r8 = X1
    //     0x45fd10: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x45fd14: LoadField: r9 = r4->field_7
    //     0x45fd14: ldur            x9, [x4, #7]
    // 0x45fd18: r3 = Null
    //     0x45fd18: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b50] Null
    //     0x45fd1c: ldr             x3, [x3, #0xb50]
    // 0x45fd20: blr             x9
    // 0x45fd24: ldur            x1, [fp, #-0xa0]
    // 0x45fd28: ldur            x2, [fp, #-0xb0]
    // 0x45fd2c: r0 = _hashCode()
    //     0x45fd2c: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x45fd30: ldur            x1, [fp, #-0xa0]
    // 0x45fd34: ldur            x2, [fp, #-0xb0]
    // 0x45fd38: ldur            x3, [fp, #-0xb8]
    // 0x45fd3c: mov             x5, x0
    // 0x45fd40: r0 = _set()
    //     0x45fd40: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x45fd44: ldur            x4, [fp, #-0x68]
    // 0x45fd48: ldur            x3, [fp, #-0x88]
    // 0x45fd4c: b               #0x45fd80
    // 0x45fd50: sub             SP, fp, #0xc8
    // 0x45fd54: mov             x2, x1
    // 0x45fd58: mov             x3, x0
    // 0x45fd5c: stur            x0, [fp, #-0x98]
    // 0x45fd60: mov             x16, x1
    // 0x45fd64: mov             x1, x0
    // 0x45fd68: mov             x0, x16
    // 0x45fd6c: stur            x0, [fp, #-0xa0]
    // 0x45fd70: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x45fd70: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x45fd74: r0 = crashlyticsRecordError()
    //     0x45fd74: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x45fd78: ldur            x4, [fp, #-0xa0]
    // 0x45fd7c: ldur            x3, [fp, #-0x98]
    // 0x45fd80: ldur            x0, [fp, #-0x90]
    // 0x45fd84: b               #0x45fc04
    // 0x45fd88: ldur            x3, [fp, #-0x78]
    // 0x45fd8c: r0 = LoadClassIdInstr(r3)
    //     0x45fd8c: ldur            x0, [x3, #-1]
    //     0x45fd90: ubfx            x0, x0, #0xc, #0x14
    // 0x45fd94: mov             x1, x3
    // 0x45fd98: r2 = 14
    //     0x45fd98: movz            x2, #0xe
    // 0x45fd9c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45fd9c: sub             lr, x0, #1, lsl #12
    //     0x45fda0: ldr             lr, [x21, lr, lsl #3]
    //     0x45fda4: blr             lr
    // 0x45fda8: mov             x3, x0
    // 0x45fdac: r2 = Null
    //     0x45fdac: mov             x2, NULL
    // 0x45fdb0: r1 = Null
    //     0x45fdb0: mov             x1, NULL
    // 0x45fdb4: stur            x3, [fp, #-0x90]
    // 0x45fdb8: r8 = Map
    //     0x45fdb8: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x45fdbc: r3 = Null
    //     0x45fdbc: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b60] Null
    //     0x45fdc0: ldr             x3, [x3, #0xb60]
    // 0x45fdc4: r0 = Map()
    //     0x45fdc4: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x45fdc8: ldur            x2, [fp, #-0x90]
    // 0x45fdcc: r1 = <int, double>
    //     0x45fdcc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x45fdd0: ldr             x1, [x1, #0x100]
    // 0x45fdd4: r0 = LinkedHashMap.from()
    //     0x45fdd4: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x45fdd8: stur            x0, [fp, #-0x90]
    // 0x45fddc: LoadField: r2 = r0->field_7
    //     0x45fddc: ldur            w2, [x0, #7]
    // 0x45fde0: DecompressPointer r2
    //     0x45fde0: add             x2, x2, HEAP, lsl #32
    // 0x45fde4: r1 = Null
    //     0x45fde4: mov             x1, NULL
    // 0x45fde8: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x45fde8: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x45fdec: r30 = InstantiateTypeArgumentsStub
    //     0x45fdec: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x45fdf0: LoadField: r30 = r30->field_7
    //     0x45fdf0: ldur            lr, [lr, #7]
    // 0x45fdf4: blr             lr
    // 0x45fdf8: mov             x1, x0
    // 0x45fdfc: r0 = _CompactEntriesIterable()
    //     0x45fdfc: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x45fe00: mov             x1, x0
    // 0x45fe04: ldur            x0, [fp, #-0x90]
    // 0x45fe08: StoreField: r1->field_b = r0
    //     0x45fe08: stur            w0, [x1, #0xb]
    // 0x45fe0c: r0 = iterator()
    //     0x45fe0c: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x45fe10: stur            x0, [fp, #-0x90]
    // 0x45fe14: ldur            x4, [fp, #-0x68]
    // 0x45fe18: ldur            x3, [fp, #-0x88]
    // 0x45fe1c: ldur            x2, [fp, #-0x70]
    // 0x45fe20: stur            x4, [fp, #-0x68]
    // 0x45fe24: stur            x3, [fp, #-0x88]
    // 0x45fe28: CheckStackOverflow
    //     0x45fe28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x45fe2c: cmp             SP, x16
    //     0x45fe30: b.ls            #0x460b00
    // 0x45fe34: mov             x1, x0
    // 0x45fe38: r0 = moveNext()
    //     0x45fe38: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x45fe3c: tbnz            w0, #4, #0x45ffa0
    // 0x45fe40: ldur            x1, [fp, #-0x90]
    // 0x45fe44: LoadField: r2 = r1->field_2b
    //     0x45fe44: ldur            w2, [x1, #0x2b]
    // 0x45fe48: DecompressPointer r2
    //     0x45fe48: add             x2, x2, HEAP, lsl #32
    // 0x45fe4c: stur            x2, [fp, #-0xa8]
    // 0x45fe50: cmp             w2, NULL
    // 0x45fe54: b.eq            #0x460ae4
    // 0x45fe58: ldur            x3, [fp, #-0x70]
    // 0x45fe5c: LoadField: r4 = r3->field_3b
    //     0x45fe5c: ldur            w4, [x3, #0x3b]
    // 0x45fe60: DecompressPointer r4
    //     0x45fe60: add             x4, x4, HEAP, lsl #32
    // 0x45fe64: stur            x4, [fp, #-0xa0]
    // 0x45fe68: LoadField: r5 = r2->field_b
    //     0x45fe68: ldur            w5, [x2, #0xb]
    // 0x45fe6c: DecompressPointer r5
    //     0x45fe6c: add             x5, x5, HEAP, lsl #32
    // 0x45fe70: stur            x5, [fp, #-0x98]
    // 0x45fe74: ldur            x16, [fp, #-0x80]
    // 0x45fe78: stp             x5, x16, [SP]
    // 0x45fe7c: ldur            x0, [fp, #-0x80]
    // 0x45fe80: ClosureCall
    //     0x45fe80: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x45fe84: ldur            x2, [x0, #0x1f]
    //     0x45fe88: blr             x2
    // 0x45fe8c: mov             x1, x0
    // 0x45fe90: stur            x1, [fp, #-0xb0]
    // 0x45fe94: ldur            x16, [fp, #-0x80]
    // 0x45fe98: ldur            lr, [fp, #-0x98]
    // 0x45fe9c: stp             lr, x16, [SP]
    // 0x45fea0: ldur            x0, [fp, #-0x80]
    // 0x45fea4: ClosureCall
    //     0x45fea4: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x45fea8: ldur            x2, [x0, #0x1f]
    //     0x45feac: blr             x2
    // 0x45feb0: mov             x1, x0
    // 0x45feb4: ldur            x0, [fp, #-0xa8]
    // 0x45feb8: LoadField: r2 = r0->field_f
    //     0x45feb8: ldur            w2, [x0, #0xf]
    // 0x45febc: DecompressPointer r2
    //     0x45febc: add             x2, x2, HEAP, lsl #32
    // 0x45fec0: r0 = sanitizeLoadedData()
    //     0x45fec0: bl              #0x460ccc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::sanitizeLoadedData
    // 0x45fec4: mov             x4, x0
    // 0x45fec8: ldur            x3, [fp, #-0xa0]
    // 0x45fecc: stur            x4, [fp, #-0xb8]
    // 0x45fed0: LoadField: r5 = r3->field_7
    //     0x45fed0: ldur            w5, [x3, #7]
    // 0x45fed4: DecompressPointer r5
    //     0x45fed4: add             x5, x5, HEAP, lsl #32
    // 0x45fed8: ldur            x0, [fp, #-0xb0]
    // 0x45fedc: mov             x2, x5
    // 0x45fee0: stur            x5, [fp, #-0x98]
    // 0x45fee4: r1 = Null
    //     0x45fee4: mov             x1, NULL
    // 0x45fee8: cmp             w2, NULL
    // 0x45feec: b.eq            #0x45ff0c
    // 0x45fef0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x45fef0: ldur            w4, [x2, #0x17]
    // 0x45fef4: DecompressPointer r4
    //     0x45fef4: add             x4, x4, HEAP, lsl #32
    // 0x45fef8: r8 = X0
    //     0x45fef8: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x45fefc: LoadField: r9 = r4->field_7
    //     0x45fefc: ldur            x9, [x4, #7]
    // 0x45ff00: r3 = Null
    //     0x45ff00: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b70] Null
    //     0x45ff04: ldr             x3, [x3, #0xb70]
    // 0x45ff08: blr             x9
    // 0x45ff0c: ldur            x0, [fp, #-0xb8]
    // 0x45ff10: ldur            x2, [fp, #-0x98]
    // 0x45ff14: r1 = Null
    //     0x45ff14: mov             x1, NULL
    // 0x45ff18: cmp             w2, NULL
    // 0x45ff1c: b.eq            #0x45ff3c
    // 0x45ff20: LoadField: r4 = r2->field_1b
    //     0x45ff20: ldur            w4, [x2, #0x1b]
    // 0x45ff24: DecompressPointer r4
    //     0x45ff24: add             x4, x4, HEAP, lsl #32
    // 0x45ff28: r8 = X1
    //     0x45ff28: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x45ff2c: LoadField: r9 = r4->field_7
    //     0x45ff2c: ldur            x9, [x4, #7]
    // 0x45ff30: r3 = Null
    //     0x45ff30: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b80] Null
    //     0x45ff34: ldr             x3, [x3, #0xb80]
    // 0x45ff38: blr             x9
    // 0x45ff3c: ldur            x1, [fp, #-0xa0]
    // 0x45ff40: ldur            x2, [fp, #-0xb0]
    // 0x45ff44: r0 = _hashCode()
    //     0x45ff44: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x45ff48: ldur            x1, [fp, #-0xa0]
    // 0x45ff4c: ldur            x2, [fp, #-0xb0]
    // 0x45ff50: ldur            x3, [fp, #-0xb8]
    // 0x45ff54: mov             x5, x0
    // 0x45ff58: r0 = _set()
    //     0x45ff58: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x45ff5c: ldur            x4, [fp, #-0x68]
    // 0x45ff60: ldur            x3, [fp, #-0x88]
    // 0x45ff64: b               #0x45ff98
    // 0x45ff68: sub             SP, fp, #0xc8
    // 0x45ff6c: mov             x2, x1
    // 0x45ff70: mov             x3, x0
    // 0x45ff74: stur            x0, [fp, #-0x98]
    // 0x45ff78: mov             x16, x1
    // 0x45ff7c: mov             x1, x0
    // 0x45ff80: mov             x0, x16
    // 0x45ff84: stur            x0, [fp, #-0xa0]
    // 0x45ff88: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x45ff88: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x45ff8c: r0 = crashlyticsRecordError()
    //     0x45ff8c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x45ff90: ldur            x4, [fp, #-0xa0]
    // 0x45ff94: ldur            x3, [fp, #-0x98]
    // 0x45ff98: ldur            x0, [fp, #-0x90]
    // 0x45ff9c: b               #0x45fe1c
    // 0x45ffa0: ldur            x3, [fp, #-0x70]
    // 0x45ffa4: ldur            x4, [fp, #-0x78]
    // 0x45ffa8: r0 = LoadClassIdInstr(r4)
    //     0x45ffa8: ldur            x0, [x4, #-1]
    //     0x45ffac: ubfx            x0, x0, #0xc, #0x14
    // 0x45ffb0: mov             x1, x4
    // 0x45ffb4: r2 = 6
    //     0x45ffb4: movz            x2, #0x6
    // 0x45ffb8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x45ffb8: sub             lr, x0, #1, lsl #12
    //     0x45ffbc: ldr             lr, [x21, lr, lsl #3]
    //     0x45ffc0: blr             lr
    // 0x45ffc4: mov             x3, x0
    // 0x45ffc8: r2 = Null
    //     0x45ffc8: mov             x2, NULL
    // 0x45ffcc: r1 = Null
    //     0x45ffcc: mov             x1, NULL
    // 0x45ffd0: stur            x3, [fp, #-0x80]
    // 0x45ffd4: r8 = Map
    //     0x45ffd4: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x45ffd8: r3 = Null
    //     0x45ffd8: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b90] Null
    //     0x45ffdc: ldr             x3, [x3, #0xb90]
    // 0x45ffe0: r0 = Map()
    //     0x45ffe0: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x45ffe4: ldur            x2, [fp, #-0x80]
    // 0x45ffe8: r1 = Null
    //     0x45ffe8: mov             x1, NULL
    // 0x45ffec: r0 = QuestBlock.fromMap()
    //     0x45ffec: bl              #0x460b28  ; [package:pretentious/data/QuestBlock.dart] QuestBlock::QuestBlock.fromMap
    // 0x45fff0: ldur            x3, [fp, #-0x70]
    // 0x45fff4: StoreField: r3->field_3f = r0
    //     0x45fff4: stur            w0, [x3, #0x3f]
    //     0x45fff8: ldurb           w16, [x3, #-1]
    //     0x45fffc: ldurb           w17, [x0, #-1]
    //     0x460000: and             x16, x17, x16, lsr #2
    //     0x460004: tst             x16, HEAP, lsr #32
    //     0x460008: b.eq            #0x460010
    //     0x46000c: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x460010: ldur            x4, [fp, #-0x78]
    // 0x460014: r0 = LoadClassIdInstr(r4)
    //     0x460014: ldur            x0, [x4, #-1]
    //     0x460018: ubfx            x0, x0, #0xc, #0x14
    // 0x46001c: mov             x1, x4
    // 0x460020: r2 = 8
    //     0x460020: movz            x2, #0x8
    // 0x460024: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460024: sub             lr, x0, #1, lsl #12
    //     0x460028: ldr             lr, [x21, lr, lsl #3]
    //     0x46002c: blr             lr
    // 0x460030: mov             x3, x0
    // 0x460034: r2 = Null
    //     0x460034: mov             x2, NULL
    // 0x460038: r1 = Null
    //     0x460038: mov             x1, NULL
    // 0x46003c: stur            x3, [fp, #-0x80]
    // 0x460040: r8 = Map
    //     0x460040: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x460044: r3 = Null
    //     0x460044: add             x3, PP, #0x10, lsl #12  ; [pp+0x10ba0] Null
    //     0x460048: ldr             x3, [x3, #0xba0]
    // 0x46004c: r0 = Map()
    //     0x46004c: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x460050: ldur            x2, [fp, #-0x80]
    // 0x460054: r1 = <int, int>
    //     0x460054: ldr             x1, [PP, #0x4ac8]  ; [pp+0x4ac8] TypeArguments: <int, int>
    // 0x460058: r0 = LinkedHashMap.from()
    //     0x460058: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x46005c: ldur            x3, [fp, #-0x70]
    // 0x460060: StoreField: r3->field_43 = r0
    //     0x460060: stur            w0, [x3, #0x43]
    //     0x460064: ldurb           w16, [x3, #-1]
    //     0x460068: ldurb           w17, [x0, #-1]
    //     0x46006c: and             x16, x17, x16, lsr #2
    //     0x460070: tst             x16, HEAP, lsr #32
    //     0x460074: b.eq            #0x46007c
    //     0x460078: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46007c: ldur            x4, [fp, #-0x78]
    // 0x460080: r0 = LoadClassIdInstr(r4)
    //     0x460080: ldur            x0, [x4, #-1]
    //     0x460084: ubfx            x0, x0, #0xc, #0x14
    // 0x460088: mov             x1, x4
    // 0x46008c: r2 = 10
    //     0x46008c: movz            x2, #0xa
    // 0x460090: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460090: sub             lr, x0, #1, lsl #12
    //     0x460094: ldr             lr, [x21, lr, lsl #3]
    //     0x460098: blr             lr
    // 0x46009c: mov             x3, x0
    // 0x4600a0: r2 = Null
    //     0x4600a0: mov             x2, NULL
    // 0x4600a4: r1 = Null
    //     0x4600a4: mov             x1, NULL
    // 0x4600a8: stur            x3, [fp, #-0x80]
    // 0x4600ac: r8 = Map
    //     0x4600ac: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x4600b0: r3 = Null
    //     0x4600b0: add             x3, PP, #0x10, lsl #12  ; [pp+0x10bb0] Null
    //     0x4600b4: ldr             x3, [x3, #0xbb0]
    // 0x4600b8: r0 = Map()
    //     0x4600b8: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x4600bc: ldur            x2, [fp, #-0x80]
    // 0x4600c0: r1 = <int, double>
    //     0x4600c0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x4600c4: ldr             x1, [x1, #0x100]
    // 0x4600c8: r0 = LinkedHashMap.from()
    //     0x4600c8: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x4600cc: ldur            x3, [fp, #-0x70]
    // 0x4600d0: StoreField: r3->field_47 = r0
    //     0x4600d0: stur            w0, [x3, #0x47]
    //     0x4600d4: ldurb           w16, [x3, #-1]
    //     0x4600d8: ldurb           w17, [x0, #-1]
    //     0x4600dc: and             x16, x17, x16, lsr #2
    //     0x4600e0: tst             x16, HEAP, lsr #32
    //     0x4600e4: b.eq            #0x4600ec
    //     0x4600e8: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4600ec: ldur            x4, [fp, #-0x78]
    // 0x4600f0: r0 = LoadClassIdInstr(r4)
    //     0x4600f0: ldur            x0, [x4, #-1]
    //     0x4600f4: ubfx            x0, x0, #0xc, #0x14
    // 0x4600f8: mov             x1, x4
    // 0x4600fc: r2 = 16
    //     0x4600fc: movz            x2, #0x10
    // 0x460100: r0 = GDT[cid_x0 + -0xf99]()
    //     0x460100: sub             lr, x0, #0xf99
    //     0x460104: ldr             lr, [x21, lr, lsl #3]
    //     0x460108: blr             lr
    // 0x46010c: tbnz            w0, #4, #0x4601d0
    // 0x460110: ldur            x1, [fp, #-0x70]
    // 0x460114: ldur            x0, [fp, #-0x78]
    // 0x460118: r0 = DateTime()
    //     0x460118: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x46011c: mov             x4, x0
    // 0x460120: ldur            x3, [fp, #-0x78]
    // 0x460124: stur            x4, [fp, #-0x80]
    // 0x460128: r0 = LoadClassIdInstr(r3)
    //     0x460128: ldur            x0, [x3, #-1]
    //     0x46012c: ubfx            x0, x0, #0xc, #0x14
    // 0x460130: mov             x1, x3
    // 0x460134: r2 = 16
    //     0x460134: movz            x2, #0x10
    // 0x460138: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460138: sub             lr, x0, #1, lsl #12
    //     0x46013c: ldr             lr, [x21, lr, lsl #3]
    //     0x460140: blr             lr
    // 0x460144: mov             x3, x0
    // 0x460148: r2 = Null
    //     0x460148: mov             x2, NULL
    // 0x46014c: r1 = Null
    //     0x46014c: mov             x1, NULL
    // 0x460150: stur            x3, [fp, #-0x90]
    // 0x460154: branchIfSmi(r0, 0x46017c)
    //     0x460154: tbz             w0, #0, #0x46017c
    // 0x460158: r4 = LoadClassIdInstr(r0)
    //     0x460158: ldur            x4, [x0, #-1]
    //     0x46015c: ubfx            x4, x4, #0xc, #0x14
    // 0x460160: sub             x4, x4, #0x3c
    // 0x460164: cmp             x4, #1
    // 0x460168: b.ls            #0x46017c
    // 0x46016c: r8 = int
    //     0x46016c: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x460170: r3 = Null
    //     0x460170: add             x3, PP, #0x10, lsl #12  ; [pp+0x10bc0] Null
    //     0x460174: ldr             x3, [x3, #0xbc0]
    // 0x460178: r0 = int()
    //     0x460178: bl              #0x82bb04  ; IsType_int_Stub
    // 0x46017c: ldur            x1, [fp, #-0x80]
    // 0x460180: ldur            x2, [fp, #-0x90]
    // 0x460184: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x460184: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x460188: r0 = DateTime.fromMillisecondsSinceEpoch()
    //     0x460188: bl              #0x450518  ; [dart:core] DateTime::DateTime.fromMillisecondsSinceEpoch
    // 0x46018c: ldur            x0, [fp, #-0x80]
    // 0x460190: ldur            x3, [fp, #-0x70]
    // 0x460194: StoreField: r3->field_67 = r0
    //     0x460194: stur            w0, [x3, #0x67]
    //     0x460198: ldurb           w16, [x3, #-1]
    //     0x46019c: ldurb           w17, [x0, #-1]
    //     0x4601a0: and             x16, x17, x16, lsr #2
    //     0x4601a4: tst             x16, HEAP, lsr #32
    //     0x4601a8: b.eq            #0x4601b0
    //     0x4601ac: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4601b0: ldur            x1, [fp, #-0x68]
    // 0x4601b4: ldur            x0, [fp, #-0x88]
    // 0x4601b8: b               #0x4601c4
    // 0x4601bc: sub             SP, fp, #0xc8
    // 0x4601c0: ldur            x3, [fp, #-0x70]
    // 0x4601c4: mov             x6, x1
    // 0x4601c8: mov             x5, x0
    // 0x4601cc: b               #0x4601dc
    // 0x4601d0: ldur            x3, [fp, #-0x70]
    // 0x4601d4: ldur            x6, [fp, #-0x68]
    // 0x4601d8: ldur            x5, [fp, #-0x88]
    // 0x4601dc: ldur            x4, [fp, #-0x78]
    // 0x4601e0: stur            x6, [fp, #-0x68]
    // 0x4601e4: stur            x5, [fp, #-0x80]
    // 0x4601e8: r0 = LoadClassIdInstr(r4)
    //     0x4601e8: ldur            x0, [x4, #-1]
    //     0x4601ec: ubfx            x0, x0, #0xc, #0x14
    // 0x4601f0: mov             x1, x4
    // 0x4601f4: r2 = 18
    //     0x4601f4: movz            x2, #0x12
    // 0x4601f8: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4601f8: sub             lr, x0, #0xf99
    //     0x4601fc: ldr             lr, [x21, lr, lsl #3]
    //     0x460200: blr             lr
    // 0x460204: tbnz            w0, #4, #0x4602c8
    // 0x460208: ldur            x3, [fp, #-0x70]
    // 0x46020c: ldur            x4, [fp, #-0x78]
    // 0x460210: r0 = LoadClassIdInstr(r4)
    //     0x460210: ldur            x0, [x4, #-1]
    //     0x460214: ubfx            x0, x0, #0xc, #0x14
    // 0x460218: mov             x1, x4
    // 0x46021c: r2 = 18
    //     0x46021c: movz            x2, #0x12
    // 0x460220: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460220: sub             lr, x0, #1, lsl #12
    //     0x460224: ldr             lr, [x21, lr, lsl #3]
    //     0x460228: blr             lr
    // 0x46022c: mov             x3, x0
    // 0x460230: r2 = Null
    //     0x460230: mov             x2, NULL
    // 0x460234: r1 = Null
    //     0x460234: mov             x1, NULL
    // 0x460238: stur            x3, [fp, #-0x88]
    // 0x46023c: r8 = Map
    //     0x46023c: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x460240: r3 = Null
    //     0x460240: add             x3, PP, #0x10, lsl #12  ; [pp+0x10bd0] Null
    //     0x460244: ldr             x3, [x3, #0xbd0]
    // 0x460248: r0 = Map()
    //     0x460248: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x46024c: ldur            x2, [fp, #-0x88]
    // 0x460250: r1 = <int, double>
    //     0x460250: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x460254: ldr             x1, [x1, #0x100]
    // 0x460258: r0 = LinkedHashMap.from()
    //     0x460258: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x46025c: ldur            x3, [fp, #-0x70]
    // 0x460260: StoreField: r3->field_4b = r0
    //     0x460260: stur            w0, [x3, #0x4b]
    //     0x460264: ldurb           w16, [x3, #-1]
    //     0x460268: ldurb           w17, [x0, #-1]
    //     0x46026c: and             x16, x17, x16, lsr #2
    //     0x460270: tst             x16, HEAP, lsr #32
    //     0x460274: b.eq            #0x46027c
    //     0x460278: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46027c: ldur            x1, [fp, #-0x68]
    // 0x460280: ldur            x0, [fp, #-0x80]
    // 0x460284: b               #0x4602bc
    // 0x460288: sub             SP, fp, #0xc8
    // 0x46028c: ldur            x3, [fp, #-0x70]
    // 0x460290: mov             x2, x1
    // 0x460294: mov             x4, x0
    // 0x460298: stur            x0, [fp, #-0x88]
    // 0x46029c: mov             x16, x1
    // 0x4602a0: mov             x1, x0
    // 0x4602a4: mov             x0, x16
    // 0x4602a8: stur            x0, [fp, #-0x90]
    // 0x4602ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4602ac: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4602b0: r0 = crashlyticsRecordError()
    //     0x4602b0: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x4602b4: ldur            x1, [fp, #-0x90]
    // 0x4602b8: ldur            x0, [fp, #-0x88]
    // 0x4602bc: mov             x5, x1
    // 0x4602c0: mov             x4, x0
    // 0x4602c4: b               #0x4602d0
    // 0x4602c8: ldur            x5, [fp, #-0x68]
    // 0x4602cc: ldur            x4, [fp, #-0x80]
    // 0x4602d0: ldur            x3, [fp, #-0x78]
    // 0x4602d4: stur            x5, [fp, #-0x68]
    // 0x4602d8: stur            x4, [fp, #-0x80]
    // 0x4602dc: r0 = LoadClassIdInstr(r3)
    //     0x4602dc: ldur            x0, [x3, #-1]
    //     0x4602e0: ubfx            x0, x0, #0xc, #0x14
    // 0x4602e4: mov             x1, x3
    // 0x4602e8: r2 = 20
    //     0x4602e8: movz            x2, #0x14
    // 0x4602ec: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4602ec: sub             lr, x0, #0xf99
    //     0x4602f0: ldr             lr, [x21, lr, lsl #3]
    //     0x4602f4: blr             lr
    // 0x4602f8: tbnz            w0, #4, #0x4603bc
    // 0x4602fc: ldur            x4, [fp, #-0x70]
    // 0x460300: ldur            x3, [fp, #-0x78]
    // 0x460304: r0 = LoadClassIdInstr(r3)
    //     0x460304: ldur            x0, [x3, #-1]
    //     0x460308: ubfx            x0, x0, #0xc, #0x14
    // 0x46030c: mov             x1, x3
    // 0x460310: r2 = 20
    //     0x460310: movz            x2, #0x14
    // 0x460314: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460314: sub             lr, x0, #1, lsl #12
    //     0x460318: ldr             lr, [x21, lr, lsl #3]
    //     0x46031c: blr             lr
    // 0x460320: mov             x3, x0
    // 0x460324: r2 = Null
    //     0x460324: mov             x2, NULL
    // 0x460328: r1 = Null
    //     0x460328: mov             x1, NULL
    // 0x46032c: stur            x3, [fp, #-0x88]
    // 0x460330: r8 = Map
    //     0x460330: ldr             x8, [PP, #0x29d8]  ; [pp+0x29d8] Type: Map
    // 0x460334: r3 = Null
    //     0x460334: add             x3, PP, #0x10, lsl #12  ; [pp+0x10be0] Null
    //     0x460338: ldr             x3, [x3, #0xbe0]
    // 0x46033c: r0 = Map()
    //     0x46033c: bl              #0x82cb74  ; IsType_Map_Stub
    // 0x460340: ldur            x2, [fp, #-0x88]
    // 0x460344: r1 = <int, double>
    //     0x460344: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x460348: ldr             x1, [x1, #0x100]
    // 0x46034c: r0 = LinkedHashMap.from()
    //     0x46034c: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x460350: ldur            x3, [fp, #-0x70]
    // 0x460354: StoreField: r3->field_4f = r0
    //     0x460354: stur            w0, [x3, #0x4f]
    //     0x460358: ldurb           w16, [x3, #-1]
    //     0x46035c: ldurb           w17, [x0, #-1]
    //     0x460360: and             x16, x17, x16, lsr #2
    //     0x460364: tst             x16, HEAP, lsr #32
    //     0x460368: b.eq            #0x460370
    //     0x46036c: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x460370: ldur            x1, [fp, #-0x68]
    // 0x460374: ldur            x0, [fp, #-0x80]
    // 0x460378: b               #0x4603b0
    // 0x46037c: sub             SP, fp, #0xc8
    // 0x460380: ldur            x3, [fp, #-0x70]
    // 0x460384: mov             x2, x1
    // 0x460388: mov             x4, x0
    // 0x46038c: stur            x0, [fp, #-0x88]
    // 0x460390: mov             x16, x1
    // 0x460394: mov             x1, x0
    // 0x460398: mov             x0, x16
    // 0x46039c: stur            x0, [fp, #-0x90]
    // 0x4603a0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4603a0: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4603a4: r0 = crashlyticsRecordError()
    //     0x4603a4: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x4603a8: ldur            x1, [fp, #-0x90]
    // 0x4603ac: ldur            x0, [fp, #-0x88]
    // 0x4603b0: mov             x5, x1
    // 0x4603b4: mov             x4, x0
    // 0x4603b8: b               #0x4603c4
    // 0x4603bc: ldur            x5, [fp, #-0x68]
    // 0x4603c0: ldur            x4, [fp, #-0x80]
    // 0x4603c4: ldur            x3, [fp, #-0x78]
    // 0x4603c8: stur            x5, [fp, #-0x68]
    // 0x4603cc: stur            x4, [fp, #-0x80]
    // 0x4603d0: r0 = LoadClassIdInstr(r3)
    //     0x4603d0: ldur            x0, [x3, #-1]
    //     0x4603d4: ubfx            x0, x0, #0xc, #0x14
    // 0x4603d8: mov             x1, x3
    // 0x4603dc: r2 = 22
    //     0x4603dc: movz            x2, #0x16
    // 0x4603e0: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4603e0: sub             lr, x0, #0xf99
    //     0x4603e4: ldr             lr, [x21, lr, lsl #3]
    //     0x4603e8: blr             lr
    // 0x4603ec: tbnz            w0, #4, #0x4604b0
    // 0x4603f0: ldur            x4, [fp, #-0x70]
    // 0x4603f4: ldur            x3, [fp, #-0x78]
    // 0x4603f8: r0 = LoadClassIdInstr(r3)
    //     0x4603f8: ldur            x0, [x3, #-1]
    //     0x4603fc: ubfx            x0, x0, #0xc, #0x14
    // 0x460400: mov             x1, x3
    // 0x460404: r2 = 22
    //     0x460404: movz            x2, #0x16
    // 0x460408: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460408: sub             lr, x0, #1, lsl #12
    //     0x46040c: ldr             lr, [x21, lr, lsl #3]
    //     0x460410: blr             lr
    // 0x460414: mov             x3, x0
    // 0x460418: r2 = Null
    //     0x460418: mov             x2, NULL
    // 0x46041c: r1 = Null
    //     0x46041c: mov             x1, NULL
    // 0x460420: stur            x3, [fp, #-0x88]
    // 0x460424: branchIfSmi(r0, 0x46044c)
    //     0x460424: tbz             w0, #0, #0x46044c
    // 0x460428: r4 = LoadClassIdInstr(r0)
    //     0x460428: ldur            x4, [x0, #-1]
    //     0x46042c: ubfx            x4, x4, #0xc, #0x14
    // 0x460430: sub             x4, x4, #0x3c
    // 0x460434: cmp             x4, #1
    // 0x460438: b.ls            #0x46044c
    // 0x46043c: r8 = int
    //     0x46043c: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x460440: r3 = Null
    //     0x460440: add             x3, PP, #0x10, lsl #12  ; [pp+0x10bf0] Null
    //     0x460444: ldr             x3, [x3, #0xbf0]
    // 0x460448: r0 = int()
    //     0x460448: bl              #0x82bb04  ; IsType_int_Stub
    // 0x46044c: ldur            x0, [fp, #-0x88]
    // 0x460450: r1 = LoadInt32Instr(r0)
    //     0x460450: sbfx            x1, x0, #1, #0x1f
    //     0x460454: tbz             w0, #0, #0x46045c
    //     0x460458: ldur            x1, [x0, #7]
    // 0x46045c: ldur            x3, [fp, #-0x70]
    // 0x460460: StoreField: r3->field_6b = r1
    //     0x460460: stur            x1, [x3, #0x6b]
    // 0x460464: ldur            x1, [fp, #-0x68]
    // 0x460468: ldur            x0, [fp, #-0x80]
    // 0x46046c: b               #0x4604a4
    // 0x460470: sub             SP, fp, #0xc8
    // 0x460474: ldur            x3, [fp, #-0x70]
    // 0x460478: mov             x2, x1
    // 0x46047c: mov             x4, x0
    // 0x460480: stur            x0, [fp, #-0x88]
    // 0x460484: mov             x16, x1
    // 0x460488: mov             x1, x0
    // 0x46048c: mov             x0, x16
    // 0x460490: stur            x0, [fp, #-0x90]
    // 0x460494: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x460494: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x460498: r0 = crashlyticsRecordError()
    //     0x460498: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x46049c: ldur            x1, [fp, #-0x90]
    // 0x4604a0: ldur            x0, [fp, #-0x88]
    // 0x4604a4: mov             x5, x1
    // 0x4604a8: mov             x4, x0
    // 0x4604ac: b               #0x4604b8
    // 0x4604b0: ldur            x5, [fp, #-0x68]
    // 0x4604b4: ldur            x4, [fp, #-0x80]
    // 0x4604b8: ldur            x3, [fp, #-0x78]
    // 0x4604bc: stur            x5, [fp, #-0x68]
    // 0x4604c0: stur            x4, [fp, #-0x80]
    // 0x4604c4: r0 = LoadClassIdInstr(r3)
    //     0x4604c4: ldur            x0, [x3, #-1]
    //     0x4604c8: ubfx            x0, x0, #0xc, #0x14
    // 0x4604cc: mov             x1, x3
    // 0x4604d0: r2 = 24
    //     0x4604d0: movz            x2, #0x18
    // 0x4604d4: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4604d4: sub             lr, x0, #0xf99
    //     0x4604d8: ldr             lr, [x21, lr, lsl #3]
    //     0x4604dc: blr             lr
    // 0x4604e0: tbnz            w0, #4, #0x460570
    // 0x4604e4: ldur            x4, [fp, #-0x70]
    // 0x4604e8: ldur            x3, [fp, #-0x78]
    // 0x4604ec: r0 = LoadClassIdInstr(r3)
    //     0x4604ec: ldur            x0, [x3, #-1]
    //     0x4604f0: ubfx            x0, x0, #0xc, #0x14
    // 0x4604f4: mov             x1, x3
    // 0x4604f8: r2 = 24
    //     0x4604f8: movz            x2, #0x18
    // 0x4604fc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4604fc: sub             lr, x0, #1, lsl #12
    //     0x460500: ldr             lr, [x21, lr, lsl #3]
    //     0x460504: blr             lr
    // 0x460508: mov             x3, x0
    // 0x46050c: r2 = Null
    //     0x46050c: mov             x2, NULL
    // 0x460510: r1 = Null
    //     0x460510: mov             x1, NULL
    // 0x460514: stur            x3, [fp, #-0x88]
    // 0x460518: r8 = Iterable
    //     0x460518: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x46051c: r3 = Null
    //     0x46051c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c00] Null
    //     0x460520: ldr             x3, [x3, #0xc00]
    // 0x460524: r0 = Iterable()
    //     0x460524: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x460528: ldur            x2, [fp, #-0x88]
    // 0x46052c: r1 = <int>
    //     0x46052c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x460530: r0 = LinkedHashSet.from()
    //     0x460530: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x460534: ldur            x3, [fp, #-0x70]
    // 0x460538: StoreField: r3->field_53 = r0
    //     0x460538: stur            w0, [x3, #0x53]
    //     0x46053c: ldurb           w16, [x3, #-1]
    //     0x460540: ldurb           w17, [x0, #-1]
    //     0x460544: and             x16, x17, x16, lsr #2
    //     0x460548: tst             x16, HEAP, lsr #32
    //     0x46054c: b.eq            #0x460554
    //     0x460550: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x460554: b               #0x460570
    // 0x460558: sub             SP, fp, #0xc8
    // 0x46055c: ldur            x3, [fp, #-0x70]
    // 0x460560: mov             x2, x1
    // 0x460564: mov             x1, x0
    // 0x460568: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x460568: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x46056c: r0 = crashlyticsRecordError()
    //     0x46056c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x460570: ldur            x3, [fp, #-0x78]
    // 0x460574: r0 = LoadClassIdInstr(r3)
    //     0x460574: ldur            x0, [x3, #-1]
    //     0x460578: ubfx            x0, x0, #0xc, #0x14
    // 0x46057c: mov             x1, x3
    // 0x460580: r2 = 26
    //     0x460580: movz            x2, #0x1a
    // 0x460584: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460584: sub             lr, x0, #1, lsl #12
    //     0x460588: ldr             lr, [x21, lr, lsl #3]
    //     0x46058c: blr             lr
    // 0x460590: cmp             w0, NULL
    // 0x460594: b.ne            #0x4605fc
    // 0x460598: r0 = DateTime()
    //     0x460598: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x46059c: mov             x1, x0
    // 0x4605a0: r0 = false
    //     0x4605a0: add             x0, NULL, #0x30  ; false
    // 0x4605a4: stur            x1, [fp, #-0x68]
    // 0x4605a8: StoreField: r1->field_7 = r0
    //     0x4605a8: stur            w0, [x1, #7]
    // 0x4605ac: r0 = _getCurrentMicros()
    //     0x4605ac: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x4605b0: r1 = LoadInt32Instr(r0)
    //     0x4605b0: sbfx            x1, x0, #1, #0x1f
    //     0x4605b4: tbz             w0, #0, #0x4605bc
    //     0x4605b8: ldur            x1, [x0, #7]
    // 0x4605bc: ldur            x0, [fp, #-0x68]
    // 0x4605c0: StoreField: r0->field_b = r1
    //     0x4605c0: stur            x1, [x0, #0xb]
    // 0x4605c4: tbz             x1, #0x3f, #0x4605d0
    // 0x4605c8: r2 = 999
    //     0x4605c8: movz            x2, #0x3e7
    // 0x4605cc: b               #0x4605d4
    // 0x4605d0: r2 = 0
    //     0x4605d0: movz            x2, #0
    // 0x4605d4: r0 = 1000
    //     0x4605d4: movz            x0, #0x3e8
    // 0x4605d8: sub             x3, x1, x2
    // 0x4605dc: sdiv            x2, x3, x0
    // 0x4605e0: r0 = BoxInt64Instr(r2)
    //     0x4605e0: sbfiz           x0, x2, #1, #0x1f
    //     0x4605e4: cmp             x2, x0, asr #1
    //     0x4605e8: b.eq            #0x4605f4
    //     0x4605ec: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4605f0: stur            x2, [x0, #7]
    // 0x4605f4: mov             x5, x0
    // 0x4605f8: b               #0x460600
    // 0x4605fc: mov             x5, x0
    // 0x460600: ldur            x4, [fp, #-0x70]
    // 0x460604: ldur            x3, [fp, #-0x78]
    // 0x460608: mov             x0, x5
    // 0x46060c: stur            x5, [fp, #-0x68]
    // 0x460610: r2 = Null
    //     0x460610: mov             x2, NULL
    // 0x460614: r1 = Null
    //     0x460614: mov             x1, NULL
    // 0x460618: branchIfSmi(r0, 0x460640)
    //     0x460618: tbz             w0, #0, #0x460640
    // 0x46061c: r4 = LoadClassIdInstr(r0)
    //     0x46061c: ldur            x4, [x0, #-1]
    //     0x460620: ubfx            x4, x4, #0xc, #0x14
    // 0x460624: sub             x4, x4, #0x3c
    // 0x460628: cmp             x4, #1
    // 0x46062c: b.ls            #0x460640
    // 0x460630: r8 = int
    //     0x460630: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x460634: r3 = Null
    //     0x460634: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c10] Null
    //     0x460638: ldr             x3, [x3, #0xc10]
    // 0x46063c: r0 = int()
    //     0x46063c: bl              #0x82bb04  ; IsType_int_Stub
    // 0x460640: ldur            x0, [fp, #-0x68]
    // 0x460644: ldur            x3, [fp, #-0x70]
    // 0x460648: StoreField: r3->field_73 = r0
    //     0x460648: stur            w0, [x3, #0x73]
    //     0x46064c: tbz             w0, #0, #0x460668
    //     0x460650: ldurb           w16, [x3, #-1]
    //     0x460654: ldurb           w17, [x0, #-1]
    //     0x460658: and             x16, x17, x16, lsr #2
    //     0x46065c: tst             x16, HEAP, lsr #32
    //     0x460660: b.eq            #0x460668
    //     0x460664: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x460668: ldur            x4, [fp, #-0x78]
    // 0x46066c: r0 = LoadClassIdInstr(r4)
    //     0x46066c: ldur            x0, [x4, #-1]
    //     0x460670: ubfx            x0, x0, #0xc, #0x14
    // 0x460674: mov             x1, x4
    // 0x460678: r2 = 28
    //     0x460678: movz            x2, #0x1c
    // 0x46067c: r0 = GDT[cid_x0 + -0xf99]()
    //     0x46067c: sub             lr, x0, #0xf99
    //     0x460680: ldr             lr, [x21, lr, lsl #3]
    //     0x460684: blr             lr
    // 0x460688: tbnz            w0, #4, #0x460700
    // 0x46068c: ldur            x3, [fp, #-0x70]
    // 0x460690: ldur            x4, [fp, #-0x78]
    // 0x460694: r0 = LoadClassIdInstr(r4)
    //     0x460694: ldur            x0, [x4, #-1]
    //     0x460698: ubfx            x0, x0, #0xc, #0x14
    // 0x46069c: mov             x1, x4
    // 0x4606a0: r2 = 28
    //     0x4606a0: movz            x2, #0x1c
    // 0x4606a4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4606a4: sub             lr, x0, #1, lsl #12
    //     0x4606a8: ldr             lr, [x21, lr, lsl #3]
    //     0x4606ac: blr             lr
    // 0x4606b0: mov             x3, x0
    // 0x4606b4: r2 = Null
    //     0x4606b4: mov             x2, NULL
    // 0x4606b8: r1 = Null
    //     0x4606b8: mov             x1, NULL
    // 0x4606bc: stur            x3, [fp, #-0x68]
    // 0x4606c0: r8 = Iterable
    //     0x4606c0: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x4606c4: r3 = Null
    //     0x4606c4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c20] Null
    //     0x4606c8: ldr             x3, [x3, #0xc20]
    // 0x4606cc: r0 = Iterable()
    //     0x4606cc: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x4606d0: ldur            x2, [fp, #-0x68]
    // 0x4606d4: r1 = <int>
    //     0x4606d4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4606d8: r0 = LinkedHashSet.from()
    //     0x4606d8: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x4606dc: ldur            x3, [fp, #-0x70]
    // 0x4606e0: StoreField: r3->field_13 = r0
    //     0x4606e0: stur            w0, [x3, #0x13]
    //     0x4606e4: ldurb           w16, [x3, #-1]
    //     0x4606e8: ldurb           w17, [x0, #-1]
    //     0x4606ec: and             x16, x17, x16, lsr #2
    //     0x4606f0: tst             x16, HEAP, lsr #32
    //     0x4606f4: b.eq            #0x4606fc
    //     0x4606f8: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4606fc: b               #0x460704
    // 0x460700: ldur            x3, [fp, #-0x70]
    // 0x460704: ldur            x4, [fp, #-0x78]
    // 0x460708: r0 = LoadClassIdInstr(r4)
    //     0x460708: ldur            x0, [x4, #-1]
    //     0x46070c: ubfx            x0, x0, #0xc, #0x14
    // 0x460710: mov             x1, x4
    // 0x460714: r2 = 30
    //     0x460714: movz            x2, #0x1e
    // 0x460718: r0 = GDT[cid_x0 + -0xf99]()
    //     0x460718: sub             lr, x0, #0xf99
    //     0x46071c: ldr             lr, [x21, lr, lsl #3]
    //     0x460720: blr             lr
    // 0x460724: tbnz            w0, #4, #0x46079c
    // 0x460728: ldur            x3, [fp, #-0x70]
    // 0x46072c: ldur            x4, [fp, #-0x78]
    // 0x460730: r0 = LoadClassIdInstr(r4)
    //     0x460730: ldur            x0, [x4, #-1]
    //     0x460734: ubfx            x0, x0, #0xc, #0x14
    // 0x460738: mov             x1, x4
    // 0x46073c: r2 = 30
    //     0x46073c: movz            x2, #0x1e
    // 0x460740: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460740: sub             lr, x0, #1, lsl #12
    //     0x460744: ldr             lr, [x21, lr, lsl #3]
    //     0x460748: blr             lr
    // 0x46074c: mov             x3, x0
    // 0x460750: r2 = Null
    //     0x460750: mov             x2, NULL
    // 0x460754: r1 = Null
    //     0x460754: mov             x1, NULL
    // 0x460758: stur            x3, [fp, #-0x68]
    // 0x46075c: r8 = Iterable
    //     0x46075c: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x460760: r3 = Null
    //     0x460760: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c30] Null
    //     0x460764: ldr             x3, [x3, #0xc30]
    // 0x460768: r0 = Iterable()
    //     0x460768: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x46076c: ldur            x2, [fp, #-0x68]
    // 0x460770: r1 = <int>
    //     0x460770: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x460774: r0 = LinkedHashSet.from()
    //     0x460774: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x460778: ldur            x3, [fp, #-0x70]
    // 0x46077c: ArrayStore: r3[0] = r0  ; List_4
    //     0x46077c: stur            w0, [x3, #0x17]
    //     0x460780: ldurb           w16, [x3, #-1]
    //     0x460784: ldurb           w17, [x0, #-1]
    //     0x460788: and             x16, x17, x16, lsr #2
    //     0x46078c: tst             x16, HEAP, lsr #32
    //     0x460790: b.eq            #0x460798
    //     0x460794: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x460798: b               #0x4607a0
    // 0x46079c: ldur            x3, [fp, #-0x70]
    // 0x4607a0: ldur            x4, [fp, #-0x78]
    // 0x4607a4: r0 = LoadClassIdInstr(r4)
    //     0x4607a4: ldur            x0, [x4, #-1]
    //     0x4607a8: ubfx            x0, x0, #0xc, #0x14
    // 0x4607ac: mov             x1, x4
    // 0x4607b0: r2 = 32
    //     0x4607b0: movz            x2, #0x20
    // 0x4607b4: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4607b4: sub             lr, x0, #0xf99
    //     0x4607b8: ldr             lr, [x21, lr, lsl #3]
    //     0x4607bc: blr             lr
    // 0x4607c0: tbnz            w0, #4, #0x460838
    // 0x4607c4: ldur            x3, [fp, #-0x70]
    // 0x4607c8: ldur            x4, [fp, #-0x78]
    // 0x4607cc: r0 = LoadClassIdInstr(r4)
    //     0x4607cc: ldur            x0, [x4, #-1]
    //     0x4607d0: ubfx            x0, x0, #0xc, #0x14
    // 0x4607d4: mov             x1, x4
    // 0x4607d8: r2 = 32
    //     0x4607d8: movz            x2, #0x20
    // 0x4607dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4607dc: sub             lr, x0, #1, lsl #12
    //     0x4607e0: ldr             lr, [x21, lr, lsl #3]
    //     0x4607e4: blr             lr
    // 0x4607e8: mov             x3, x0
    // 0x4607ec: r2 = Null
    //     0x4607ec: mov             x2, NULL
    // 0x4607f0: r1 = Null
    //     0x4607f0: mov             x1, NULL
    // 0x4607f4: stur            x3, [fp, #-0x68]
    // 0x4607f8: r8 = Iterable
    //     0x4607f8: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x4607fc: r3 = Null
    //     0x4607fc: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c40] Null
    //     0x460800: ldr             x3, [x3, #0xc40]
    // 0x460804: r0 = Iterable()
    //     0x460804: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x460808: ldur            x2, [fp, #-0x68]
    // 0x46080c: r1 = <int>
    //     0x46080c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x460810: r0 = LinkedHashSet.from()
    //     0x460810: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x460814: ldur            x3, [fp, #-0x70]
    // 0x460818: StoreField: r3->field_1b = r0
    //     0x460818: stur            w0, [x3, #0x1b]
    //     0x46081c: ldurb           w16, [x3, #-1]
    //     0x460820: ldurb           w17, [x0, #-1]
    //     0x460824: and             x16, x17, x16, lsr #2
    //     0x460828: tst             x16, HEAP, lsr #32
    //     0x46082c: b.eq            #0x460834
    //     0x460830: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x460834: b               #0x46083c
    // 0x460838: ldur            x3, [fp, #-0x70]
    // 0x46083c: ldur            x4, [fp, #-0x78]
    // 0x460840: r0 = LoadClassIdInstr(r4)
    //     0x460840: ldur            x0, [x4, #-1]
    //     0x460844: ubfx            x0, x0, #0xc, #0x14
    // 0x460848: mov             x1, x4
    // 0x46084c: r2 = 34
    //     0x46084c: movz            x2, #0x22
    // 0x460850: r0 = GDT[cid_x0 + -0xf99]()
    //     0x460850: sub             lr, x0, #0xf99
    //     0x460854: ldr             lr, [x21, lr, lsl #3]
    //     0x460858: blr             lr
    // 0x46085c: tbnz            w0, #4, #0x4608d4
    // 0x460860: ldur            x3, [fp, #-0x70]
    // 0x460864: ldur            x4, [fp, #-0x78]
    // 0x460868: r0 = LoadClassIdInstr(r4)
    //     0x460868: ldur            x0, [x4, #-1]
    //     0x46086c: ubfx            x0, x0, #0xc, #0x14
    // 0x460870: mov             x1, x4
    // 0x460874: r2 = 34
    //     0x460874: movz            x2, #0x22
    // 0x460878: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460878: sub             lr, x0, #1, lsl #12
    //     0x46087c: ldr             lr, [x21, lr, lsl #3]
    //     0x460880: blr             lr
    // 0x460884: mov             x3, x0
    // 0x460888: r2 = Null
    //     0x460888: mov             x2, NULL
    // 0x46088c: r1 = Null
    //     0x46088c: mov             x1, NULL
    // 0x460890: stur            x3, [fp, #-0x68]
    // 0x460894: r8 = Iterable
    //     0x460894: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x460898: r3 = Null
    //     0x460898: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c50] Null
    //     0x46089c: ldr             x3, [x3, #0xc50]
    // 0x4608a0: r0 = Iterable()
    //     0x4608a0: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x4608a4: ldur            x2, [fp, #-0x68]
    // 0x4608a8: r1 = <int>
    //     0x4608a8: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4608ac: r0 = LinkedHashSet.from()
    //     0x4608ac: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x4608b0: ldur            x3, [fp, #-0x70]
    // 0x4608b4: StoreField: r3->field_f = r0
    //     0x4608b4: stur            w0, [x3, #0xf]
    //     0x4608b8: ldurb           w16, [x3, #-1]
    //     0x4608bc: ldurb           w17, [x0, #-1]
    //     0x4608c0: and             x16, x17, x16, lsr #2
    //     0x4608c4: tst             x16, HEAP, lsr #32
    //     0x4608c8: b.eq            #0x4608d0
    //     0x4608cc: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x4608d0: b               #0x4608d8
    // 0x4608d4: ldur            x3, [fp, #-0x70]
    // 0x4608d8: ldur            x4, [fp, #-0x78]
    // 0x4608dc: r0 = LoadClassIdInstr(r4)
    //     0x4608dc: ldur            x0, [x4, #-1]
    //     0x4608e0: ubfx            x0, x0, #0xc, #0x14
    // 0x4608e4: mov             x1, x4
    // 0x4608e8: r2 = 36
    //     0x4608e8: movz            x2, #0x24
    // 0x4608ec: r0 = GDT[cid_x0 + -0xf99]()
    //     0x4608ec: sub             lr, x0, #0xf99
    //     0x4608f0: ldr             lr, [x21, lr, lsl #3]
    //     0x4608f4: blr             lr
    // 0x4608f8: tbnz            w0, #4, #0x460970
    // 0x4608fc: ldur            x3, [fp, #-0x70]
    // 0x460900: ldur            x4, [fp, #-0x78]
    // 0x460904: r0 = LoadClassIdInstr(r4)
    //     0x460904: ldur            x0, [x4, #-1]
    //     0x460908: ubfx            x0, x0, #0xc, #0x14
    // 0x46090c: mov             x1, x4
    // 0x460910: r2 = 36
    //     0x460910: movz            x2, #0x24
    // 0x460914: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460914: sub             lr, x0, #1, lsl #12
    //     0x460918: ldr             lr, [x21, lr, lsl #3]
    //     0x46091c: blr             lr
    // 0x460920: mov             x3, x0
    // 0x460924: r2 = Null
    //     0x460924: mov             x2, NULL
    // 0x460928: r1 = Null
    //     0x460928: mov             x1, NULL
    // 0x46092c: stur            x3, [fp, #-0x68]
    // 0x460930: r8 = Iterable
    //     0x460930: ldr             x8, [PP, #0xf90]  ; [pp+0xf90] Type: Iterable
    // 0x460934: r3 = Null
    //     0x460934: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c60] Null
    //     0x460938: ldr             x3, [x3, #0xc60]
    // 0x46093c: r0 = Iterable()
    //     0x46093c: bl              #0x33d9f4  ; IsType_Iterable_Stub
    // 0x460940: ldur            x2, [fp, #-0x68]
    // 0x460944: r1 = <int>
    //     0x460944: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x460948: r0 = LinkedHashSet.from()
    //     0x460948: bl              #0x45ba90  ; [dart:collection] LinkedHashSet::LinkedHashSet.from
    // 0x46094c: ldur            x3, [fp, #-0x70]
    // 0x460950: StoreField: r3->field_1f = r0
    //     0x460950: stur            w0, [x3, #0x1f]
    //     0x460954: ldurb           w16, [x3, #-1]
    //     0x460958: ldurb           w17, [x0, #-1]
    //     0x46095c: and             x16, x17, x16, lsr #2
    //     0x460960: tst             x16, HEAP, lsr #32
    //     0x460964: b.eq            #0x46096c
    //     0x460968: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x46096c: b               #0x460974
    // 0x460970: ldur            x3, [fp, #-0x70]
    // 0x460974: ldur            x4, [fp, #-0x78]
    // 0x460978: r0 = LoadClassIdInstr(r4)
    //     0x460978: ldur            x0, [x4, #-1]
    //     0x46097c: ubfx            x0, x0, #0xc, #0x14
    // 0x460980: mov             x1, x4
    // 0x460984: r2 = 40
    //     0x460984: movz            x2, #0x28
    // 0x460988: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460988: sub             lr, x0, #1, lsl #12
    //     0x46098c: ldr             lr, [x21, lr, lsl #3]
    //     0x460990: blr             lr
    // 0x460994: cmp             w0, NULL
    // 0x460998: b.ne            #0x4609e0
    // 0x46099c: ldur            x2, [fp, #-0x70]
    // 0x4609a0: r0 = LoadClassIdInstr(r2)
    //     0x4609a0: ldur            x0, [x2, #-1]
    //     0x4609a4: ubfx            x0, x0, #0xc, #0x14
    // 0x4609a8: mov             x1, x2
    // 0x4609ac: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x4609ac: sub             lr, x0, #0xf3f
    //     0x4609b0: ldr             lr, [x21, lr, lsl #3]
    //     0x4609b4: blr             lr
    // 0x4609b8: mov             x1, x0
    // 0x4609bc: r0 = getDifficultyIndex()
    //     0x4609bc: bl              #0x460dcc  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] ::getDifficultyIndex
    // 0x4609c0: mov             x2, x0
    // 0x4609c4: r0 = BoxInt64Instr(r2)
    //     0x4609c4: sbfiz           x0, x2, #1, #0x1f
    //     0x4609c8: cmp             x2, x0, asr #1
    //     0x4609cc: b.eq            #0x4609d8
    //     0x4609d0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4609d4: stur            x2, [x0, #7]
    // 0x4609d8: mov             x5, x0
    // 0x4609dc: b               #0x4609e4
    // 0x4609e0: mov             x5, x0
    // 0x4609e4: ldur            x3, [fp, #-0x70]
    // 0x4609e8: ldur            x4, [fp, #-0x78]
    // 0x4609ec: mov             x0, x5
    // 0x4609f0: stur            x5, [fp, #-0x68]
    // 0x4609f4: r2 = Null
    //     0x4609f4: mov             x2, NULL
    // 0x4609f8: r1 = Null
    //     0x4609f8: mov             x1, NULL
    // 0x4609fc: branchIfSmi(r0, 0x460a24)
    //     0x4609fc: tbz             w0, #0, #0x460a24
    // 0x460a00: r4 = LoadClassIdInstr(r0)
    //     0x460a00: ldur            x4, [x0, #-1]
    //     0x460a04: ubfx            x4, x4, #0xc, #0x14
    // 0x460a08: sub             x4, x4, #0x3c
    // 0x460a0c: cmp             x4, #1
    // 0x460a10: b.ls            #0x460a24
    // 0x460a14: r8 = int
    //     0x460a14: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x460a18: r3 = Null
    //     0x460a18: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c70] Null
    //     0x460a1c: ldr             x3, [x3, #0xc70]
    // 0x460a20: r0 = int()
    //     0x460a20: bl              #0x82bb04  ; IsType_int_Stub
    // 0x460a24: ldur            x0, [fp, #-0x68]
    // 0x460a28: r1 = LoadInt32Instr(r0)
    //     0x460a28: sbfx            x1, x0, #1, #0x1f
    //     0x460a2c: tbz             w0, #0, #0x460a34
    //     0x460a30: ldur            x1, [x0, #7]
    // 0x460a34: ldur            x3, [fp, #-0x70]
    // 0x460a38: StoreField: r3->field_23 = r1
    //     0x460a38: stur            x1, [x3, #0x23]
    // 0x460a3c: ldur            x1, [fp, #-0x78]
    // 0x460a40: r0 = LoadClassIdInstr(r1)
    //     0x460a40: ldur            x0, [x1, #-1]
    //     0x460a44: ubfx            x0, x0, #0xc, #0x14
    // 0x460a48: r2 = 46
    //     0x460a48: movz            x2, #0x2e
    // 0x460a4c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x460a4c: sub             lr, x0, #1, lsl #12
    //     0x460a50: ldr             lr, [x21, lr, lsl #3]
    //     0x460a54: blr             lr
    // 0x460a58: cmp             w0, NULL
    // 0x460a5c: b.ne            #0x460a68
    // 0x460a60: r4 = 0
    //     0x460a60: movz            x4, #0
    // 0x460a64: b               #0x460a6c
    // 0x460a68: mov             x4, x0
    // 0x460a6c: ldur            x3, [fp, #-0x70]
    // 0x460a70: mov             x0, x4
    // 0x460a74: stur            x4, [fp, #-0x68]
    // 0x460a78: r2 = Null
    //     0x460a78: mov             x2, NULL
    // 0x460a7c: r1 = Null
    //     0x460a7c: mov             x1, NULL
    // 0x460a80: branchIfSmi(r0, 0x460aa8)
    //     0x460a80: tbz             w0, #0, #0x460aa8
    // 0x460a84: r4 = LoadClassIdInstr(r0)
    //     0x460a84: ldur            x4, [x0, #-1]
    //     0x460a88: ubfx            x4, x4, #0xc, #0x14
    // 0x460a8c: sub             x4, x4, #0x3c
    // 0x460a90: cmp             x4, #1
    // 0x460a94: b.ls            #0x460aa8
    // 0x460a98: r8 = int
    //     0x460a98: ldr             x8, [PP, #0x1a0]  ; [pp+0x1a0] Type: int
    // 0x460a9c: r3 = Null
    //     0x460a9c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10c80] Null
    //     0x460aa0: ldr             x3, [x3, #0xc80]
    // 0x460aa4: r0 = int()
    //     0x460aa4: bl              #0x82bb04  ; IsType_int_Stub
    // 0x460aa8: ldur            x0, [fp, #-0x68]
    // 0x460aac: r1 = LoadInt32Instr(r0)
    //     0x460aac: sbfx            x1, x0, #1, #0x1f
    //     0x460ab0: tbz             w0, #0, #0x460ab8
    //     0x460ab4: ldur            x1, [x0, #7]
    // 0x460ab8: ldur            x0, [fp, #-0x70]
    // 0x460abc: StoreField: r0->field_83 = r1
    //     0x460abc: stur            x1, [x0, #0x83]
    // 0x460ac0: mov             x1, x0
    // 0x460ac4: r0 = resetAndRecomputeBoosts()
    //     0x460ac4: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x460ac8: r0 = Null
    //     0x460ac8: mov             x0, NULL
    // 0x460acc: LeaveFrame
    //     0x460acc: mov             SP, fp
    //     0x460ad0: ldp             fp, lr, [SP], #0x10
    // 0x460ad4: ret
    //     0x460ad4: ret             
    // 0x460ad8: r0 = noElement()
    //     0x460ad8: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x460adc: r0 = Throw()
    //     0x460adc: bl              #0x825670  ; ThrowStub
    // 0x460ae0: brk             #0
    // 0x460ae4: r0 = noElement()
    //     0x460ae4: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x460ae8: r0 = Throw()
    //     0x460ae8: bl              #0x825670  ; ThrowStub
    // 0x460aec: brk             #0
    // 0x460af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460af0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460af4: b               #0x45f69c
    // 0x460af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460af8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460afc: b               #0x45fc1c
    // 0x460b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460b00: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460b04: b               #0x45fe34
  }
  _ toMapFile(/* No info */) {
    // ** addr: 0x4e365c, size: 0x668
    // 0x4e365c: EnterFrame
    //     0x4e365c: stp             fp, lr, [SP, #-0x10]!
    //     0x4e3660: mov             fp, SP
    // 0x4e3664: AllocStack(0x28)
    //     0x4e3664: sub             SP, SP, #0x28
    // 0x4e3668: SetupParameters(IPlayableGameState<X0> this /* r1 => r0, fp-0x10 */, {dynamic zeroOutIdleTime = false /* r3, fp-0x8 */})
    //     0x4e3668: mov             x0, x1
    //     0x4e366c: stur            x1, [fp, #-0x10]
    //     0x4e3670: ldur            w1, [x4, #0x13]
    //     0x4e3674: ldur            w2, [x4, #0x1f]
    //     0x4e3678: add             x2, x2, HEAP, lsl #32
    //     0x4e367c: add             x16, PP, #0x14, lsl #12  ; [pp+0x143e8] "zeroOutIdleTime"
    //     0x4e3680: ldr             x16, [x16, #0x3e8]
    //     0x4e3684: cmp             w2, w16
    //     0x4e3688: b.ne            #0x4e36a8
    //     0x4e368c: ldur            w2, [x4, #0x23]
    //     0x4e3690: add             x2, x2, HEAP, lsl #32
    //     0x4e3694: sub             w3, w1, w2
    //     0x4e3698: add             x1, fp, w3, sxtw #2
    //     0x4e369c: ldr             x1, [x1, #8]
    //     0x4e36a0: mov             x3, x1
    //     0x4e36a4: b               #0x4e36ac
    //     0x4e36a8: add             x3, NULL, #0x30  ; false
    //     0x4e36ac: stur            x3, [fp, #-8]
    // 0x4e36b0: CheckStackOverflow
    //     0x4e36b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e36b4: cmp             SP, x16
    //     0x4e36b8: b.ls            #0x4e3cb0
    // 0x4e36bc: r1 = Null
    //     0x4e36bc: mov             x1, NULL
    // 0x4e36c0: r2 = 80
    //     0x4e36c0: movz            x2, #0x50
    // 0x4e36c4: r0 = AllocateArray()
    //     0x4e36c4: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e36c8: stur            x0, [fp, #-0x18]
    // 0x4e36cc: StoreField: r0->field_f = rZR
    //     0x4e36cc: stur            wzr, [x0, #0xf]
    // 0x4e36d0: StoreField: r0->field_13 = rZR
    //     0x4e36d0: stur            wzr, [x0, #0x13]
    // 0x4e36d4: r16 = 2
    //     0x4e36d4: movz            x16, #0x2
    // 0x4e36d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4e36d8: stur            w16, [x0, #0x17]
    // 0x4e36dc: ldur            x1, [fp, #-8]
    // 0x4e36e0: tbnz            w1, #4, #0x4e36f4
    // 0x4e36e4: mov             x4, x0
    // 0x4e36e8: r0 = Null
    //     0x4e36e8: mov             x0, NULL
    // 0x4e36ec: r3 = 1000
    //     0x4e36ec: movz            x3, #0x3e8
    // 0x4e36f0: b               #0x4e3738
    // 0x4e36f4: r0 = _getCurrentMicros()
    //     0x4e36f4: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x4e36f8: r1 = LoadInt32Instr(r0)
    //     0x4e36f8: sbfx            x1, x0, #1, #0x1f
    //     0x4e36fc: tbz             w0, #0, #0x4e3704
    //     0x4e3700: ldur            x1, [x0, #7]
    // 0x4e3704: tbz             x1, #0x3f, #0x4e3710
    // 0x4e3708: r0 = 999
    //     0x4e3708: movz            x0, #0x3e7
    // 0x4e370c: b               #0x4e3714
    // 0x4e3710: r0 = 0
    //     0x4e3710: movz            x0, #0
    // 0x4e3714: r3 = 1000
    //     0x4e3714: movz            x3, #0x3e8
    // 0x4e3718: sub             x2, x1, x0
    // 0x4e371c: sdiv            x4, x2, x3
    // 0x4e3720: r0 = BoxInt64Instr(r4)
    //     0x4e3720: sbfiz           x0, x4, #1, #0x1f
    //     0x4e3724: cmp             x4, x0, asr #1
    //     0x4e3728: b.eq            #0x4e3734
    //     0x4e372c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e3730: stur            x4, [x0, #7]
    // 0x4e3734: ldur            x4, [fp, #-0x18]
    // 0x4e3738: ldur            x5, [fp, #-0x10]
    // 0x4e373c: mov             x1, x4
    // 0x4e3740: ArrayStore: r1[3] = r0  ; List_4
    //     0x4e3740: add             x25, x1, #0x1b
    //     0x4e3744: str             w0, [x25]
    //     0x4e3748: tbz             w0, #0, #0x4e3764
    //     0x4e374c: ldurb           w16, [x1, #-1]
    //     0x4e3750: ldurb           w17, [x0, #-1]
    //     0x4e3754: and             x16, x17, x16, lsr #2
    //     0x4e3758: tst             x16, HEAP, lsr #32
    //     0x4e375c: b.eq            #0x4e3764
    //     0x4e3760: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3764: r16 = 4
    //     0x4e3764: movz            x16, #0x4
    // 0x4e3768: StoreField: r4->field_1f = r16
    //     0x4e3768: stur            w16, [x4, #0x1f]
    // 0x4e376c: LoadField: r2 = r5->field_37
    //     0x4e376c: ldur            w2, [x5, #0x37]
    // 0x4e3770: DecompressPointer r2
    //     0x4e3770: add             x2, x2, HEAP, lsl #32
    // 0x4e3774: mov             x1, x5
    // 0x4e3778: r0 = statMapToFile()
    //     0x4e3778: bl              #0x4e3d98  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::statMapToFile
    // 0x4e377c: ldur            x1, [fp, #-0x18]
    // 0x4e3780: ArrayStore: r1[5] = r0  ; List_4
    //     0x4e3780: add             x25, x1, #0x23
    //     0x4e3784: str             w0, [x25]
    //     0x4e3788: tbz             w0, #0, #0x4e37a4
    //     0x4e378c: ldurb           w16, [x1, #-1]
    //     0x4e3790: ldurb           w17, [x0, #-1]
    //     0x4e3794: and             x16, x17, x16, lsr #2
    //     0x4e3798: tst             x16, HEAP, lsr #32
    //     0x4e379c: b.eq            #0x4e37a4
    //     0x4e37a0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e37a4: ldur            x0, [fp, #-0x18]
    // 0x4e37a8: r16 = 14
    //     0x4e37a8: movz            x16, #0xe
    // 0x4e37ac: StoreField: r0->field_27 = r16
    //     0x4e37ac: stur            w16, [x0, #0x27]
    // 0x4e37b0: ldur            x3, [fp, #-0x10]
    // 0x4e37b4: LoadField: r2 = r3->field_3b
    //     0x4e37b4: ldur            w2, [x3, #0x3b]
    // 0x4e37b8: DecompressPointer r2
    //     0x4e37b8: add             x2, x2, HEAP, lsl #32
    // 0x4e37bc: mov             x1, x3
    // 0x4e37c0: r0 = statMapToFile()
    //     0x4e37c0: bl              #0x4e3d98  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::statMapToFile
    // 0x4e37c4: ldur            x1, [fp, #-0x18]
    // 0x4e37c8: ArrayStore: r1[7] = r0  ; List_4
    //     0x4e37c8: add             x25, x1, #0x2b
    //     0x4e37cc: str             w0, [x25]
    //     0x4e37d0: tbz             w0, #0, #0x4e37ec
    //     0x4e37d4: ldurb           w16, [x1, #-1]
    //     0x4e37d8: ldurb           w17, [x0, #-1]
    //     0x4e37dc: and             x16, x17, x16, lsr #2
    //     0x4e37e0: tst             x16, HEAP, lsr #32
    //     0x4e37e4: b.eq            #0x4e37ec
    //     0x4e37e8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e37ec: ldur            x0, [fp, #-0x18]
    // 0x4e37f0: r16 = 6
    //     0x4e37f0: movz            x16, #0x6
    // 0x4e37f4: StoreField: r0->field_2f = r16
    //     0x4e37f4: stur            w16, [x0, #0x2f]
    // 0x4e37f8: ldur            x2, [fp, #-0x10]
    // 0x4e37fc: LoadField: r1 = r2->field_3f
    //     0x4e37fc: ldur            w1, [x2, #0x3f]
    // 0x4e3800: DecompressPointer r1
    //     0x4e3800: add             x1, x1, HEAP, lsl #32
    // 0x4e3804: r0 = toMapFile()
    //     0x4e3804: bl              #0x4e3cc4  ; [package:pretentious/data/QuestBlock.dart] QuestBlock::toMapFile
    // 0x4e3808: ldur            x1, [fp, #-0x18]
    // 0x4e380c: ArrayStore: r1[9] = r0  ; List_4
    //     0x4e380c: add             x25, x1, #0x33
    //     0x4e3810: str             w0, [x25]
    //     0x4e3814: tbz             w0, #0, #0x4e3830
    //     0x4e3818: ldurb           w16, [x1, #-1]
    //     0x4e381c: ldurb           w17, [x0, #-1]
    //     0x4e3820: and             x16, x17, x16, lsr #2
    //     0x4e3824: tst             x16, HEAP, lsr #32
    //     0x4e3828: b.eq            #0x4e3830
    //     0x4e382c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3830: ldur            x3, [fp, #-0x18]
    // 0x4e3834: r16 = 8
    //     0x4e3834: movz            x16, #0x8
    // 0x4e3838: StoreField: r3->field_37 = r16
    //     0x4e3838: stur            w16, [x3, #0x37]
    // 0x4e383c: ldur            x4, [fp, #-0x10]
    // 0x4e3840: LoadField: r0 = r4->field_43
    //     0x4e3840: ldur            w0, [x4, #0x43]
    // 0x4e3844: DecompressPointer r0
    //     0x4e3844: add             x0, x0, HEAP, lsl #32
    // 0x4e3848: mov             x1, x3
    // 0x4e384c: ArrayStore: r1[11] = r0  ; List_4
    //     0x4e384c: add             x25, x1, #0x3b
    //     0x4e3850: str             w0, [x25]
    //     0x4e3854: tbz             w0, #0, #0x4e3870
    //     0x4e3858: ldurb           w16, [x1, #-1]
    //     0x4e385c: ldurb           w17, [x0, #-1]
    //     0x4e3860: and             x16, x17, x16, lsr #2
    //     0x4e3864: tst             x16, HEAP, lsr #32
    //     0x4e3868: b.eq            #0x4e3870
    //     0x4e386c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3870: r16 = 10
    //     0x4e3870: movz            x16, #0xa
    // 0x4e3874: StoreField: r3->field_3f = r16
    //     0x4e3874: stur            w16, [x3, #0x3f]
    // 0x4e3878: LoadField: r0 = r4->field_47
    //     0x4e3878: ldur            w0, [x4, #0x47]
    // 0x4e387c: DecompressPointer r0
    //     0x4e387c: add             x0, x0, HEAP, lsl #32
    // 0x4e3880: mov             x1, x3
    // 0x4e3884: ArrayStore: r1[13] = r0  ; List_4
    //     0x4e3884: add             x25, x1, #0x43
    //     0x4e3888: str             w0, [x25]
    //     0x4e388c: tbz             w0, #0, #0x4e38a8
    //     0x4e3890: ldurb           w16, [x1, #-1]
    //     0x4e3894: ldurb           w17, [x0, #-1]
    //     0x4e3898: and             x16, x17, x16, lsr #2
    //     0x4e389c: tst             x16, HEAP, lsr #32
    //     0x4e38a0: b.eq            #0x4e38a8
    //     0x4e38a4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e38a8: r16 = 16
    //     0x4e38a8: movz            x16, #0x10
    // 0x4e38ac: StoreField: r3->field_47 = r16
    //     0x4e38ac: stur            w16, [x3, #0x47]
    // 0x4e38b0: LoadField: r0 = r4->field_67
    //     0x4e38b0: ldur            w0, [x4, #0x67]
    // 0x4e38b4: DecompressPointer r0
    //     0x4e38b4: add             x0, x0, HEAP, lsl #32
    // 0x4e38b8: cmp             w0, NULL
    // 0x4e38bc: b.ne            #0x4e38c8
    // 0x4e38c0: r0 = Null
    //     0x4e38c0: mov             x0, NULL
    // 0x4e38c4: b               #0x4e38fc
    // 0x4e38c8: LoadField: r1 = r0->field_b
    //     0x4e38c8: ldur            x1, [x0, #0xb]
    // 0x4e38cc: tbz             x1, #0x3f, #0x4e38d8
    // 0x4e38d0: r2 = 999
    //     0x4e38d0: movz            x2, #0x3e7
    // 0x4e38d4: b               #0x4e38dc
    // 0x4e38d8: r2 = 0
    //     0x4e38d8: movz            x2, #0
    // 0x4e38dc: r0 = 1000
    //     0x4e38dc: movz            x0, #0x3e8
    // 0x4e38e0: sub             x5, x1, x2
    // 0x4e38e4: sdiv            x2, x5, x0
    // 0x4e38e8: r0 = BoxInt64Instr(r2)
    //     0x4e38e8: sbfiz           x0, x2, #1, #0x1f
    //     0x4e38ec: cmp             x2, x0, asr #1
    //     0x4e38f0: b.eq            #0x4e38fc
    //     0x4e38f4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e38f8: stur            x2, [x0, #7]
    // 0x4e38fc: cmp             w0, NULL
    // 0x4e3900: b.ne            #0x4e390c
    // 0x4e3904: r2 = 0
    //     0x4e3904: movz            x2, #0
    // 0x4e3908: b               #0x4e391c
    // 0x4e390c: r1 = LoadInt32Instr(r0)
    //     0x4e390c: sbfx            x1, x0, #1, #0x1f
    //     0x4e3910: tbz             w0, #0, #0x4e3918
    //     0x4e3914: ldur            x1, [x0, #7]
    // 0x4e3918: mov             x2, x1
    // 0x4e391c: r0 = BoxInt64Instr(r2)
    //     0x4e391c: sbfiz           x0, x2, #1, #0x1f
    //     0x4e3920: cmp             x2, x0, asr #1
    //     0x4e3924: b.eq            #0x4e3930
    //     0x4e3928: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e392c: stur            x2, [x0, #7]
    // 0x4e3930: mov             x1, x3
    // 0x4e3934: ArrayStore: r1[15] = r0  ; List_4
    //     0x4e3934: add             x25, x1, #0x4b
    //     0x4e3938: str             w0, [x25]
    //     0x4e393c: tbz             w0, #0, #0x4e3958
    //     0x4e3940: ldurb           w16, [x1, #-1]
    //     0x4e3944: ldurb           w17, [x0, #-1]
    //     0x4e3948: and             x16, x17, x16, lsr #2
    //     0x4e394c: tst             x16, HEAP, lsr #32
    //     0x4e3950: b.eq            #0x4e3958
    //     0x4e3954: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3958: r16 = 18
    //     0x4e3958: movz            x16, #0x12
    // 0x4e395c: StoreField: r3->field_4f = r16
    //     0x4e395c: stur            w16, [x3, #0x4f]
    // 0x4e3960: LoadField: r0 = r4->field_4b
    //     0x4e3960: ldur            w0, [x4, #0x4b]
    // 0x4e3964: DecompressPointer r0
    //     0x4e3964: add             x0, x0, HEAP, lsl #32
    // 0x4e3968: mov             x1, x3
    // 0x4e396c: ArrayStore: r1[17] = r0  ; List_4
    //     0x4e396c: add             x25, x1, #0x53
    //     0x4e3970: str             w0, [x25]
    //     0x4e3974: tbz             w0, #0, #0x4e3990
    //     0x4e3978: ldurb           w16, [x1, #-1]
    //     0x4e397c: ldurb           w17, [x0, #-1]
    //     0x4e3980: and             x16, x17, x16, lsr #2
    //     0x4e3984: tst             x16, HEAP, lsr #32
    //     0x4e3988: b.eq            #0x4e3990
    //     0x4e398c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3990: r16 = 20
    //     0x4e3990: movz            x16, #0x14
    // 0x4e3994: StoreField: r3->field_57 = r16
    //     0x4e3994: stur            w16, [x3, #0x57]
    // 0x4e3998: LoadField: r0 = r4->field_4f
    //     0x4e3998: ldur            w0, [x4, #0x4f]
    // 0x4e399c: DecompressPointer r0
    //     0x4e399c: add             x0, x0, HEAP, lsl #32
    // 0x4e39a0: mov             x1, x3
    // 0x4e39a4: ArrayStore: r1[19] = r0  ; List_4
    //     0x4e39a4: add             x25, x1, #0x5b
    //     0x4e39a8: str             w0, [x25]
    //     0x4e39ac: tbz             w0, #0, #0x4e39c8
    //     0x4e39b0: ldurb           w16, [x1, #-1]
    //     0x4e39b4: ldurb           w17, [x0, #-1]
    //     0x4e39b8: and             x16, x17, x16, lsr #2
    //     0x4e39bc: tst             x16, HEAP, lsr #32
    //     0x4e39c0: b.eq            #0x4e39c8
    //     0x4e39c4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e39c8: r16 = 22
    //     0x4e39c8: movz            x16, #0x16
    // 0x4e39cc: StoreField: r3->field_5f = r16
    //     0x4e39cc: stur            w16, [x3, #0x5f]
    // 0x4e39d0: LoadField: r2 = r4->field_6b
    //     0x4e39d0: ldur            x2, [x4, #0x6b]
    // 0x4e39d4: r0 = BoxInt64Instr(r2)
    //     0x4e39d4: sbfiz           x0, x2, #1, #0x1f
    //     0x4e39d8: cmp             x2, x0, asr #1
    //     0x4e39dc: b.eq            #0x4e39e8
    //     0x4e39e0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e39e4: stur            x2, [x0, #7]
    // 0x4e39e8: mov             x1, x3
    // 0x4e39ec: ArrayStore: r1[21] = r0  ; List_4
    //     0x4e39ec: add             x25, x1, #0x63
    //     0x4e39f0: str             w0, [x25]
    //     0x4e39f4: tbz             w0, #0, #0x4e3a10
    //     0x4e39f8: ldurb           w16, [x1, #-1]
    //     0x4e39fc: ldurb           w17, [x0, #-1]
    //     0x4e3a00: and             x16, x17, x16, lsr #2
    //     0x4e3a04: tst             x16, HEAP, lsr #32
    //     0x4e3a08: b.eq            #0x4e3a10
    //     0x4e3a0c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3a10: r16 = 24
    //     0x4e3a10: movz            x16, #0x18
    // 0x4e3a14: StoreField: r3->field_67 = r16
    //     0x4e3a14: stur            w16, [x3, #0x67]
    // 0x4e3a18: LoadField: r2 = r4->field_53
    //     0x4e3a18: ldur            w2, [x4, #0x53]
    // 0x4e3a1c: DecompressPointer r2
    //     0x4e3a1c: add             x2, x2, HEAP, lsl #32
    // 0x4e3a20: r1 = <int>
    //     0x4e3a20: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3a24: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3a24: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3a28: ldur            x1, [fp, #-0x18]
    // 0x4e3a2c: ArrayStore: r1[23] = r0  ; List_4
    //     0x4e3a2c: add             x25, x1, #0x6b
    //     0x4e3a30: str             w0, [x25]
    //     0x4e3a34: tbz             w0, #0, #0x4e3a50
    //     0x4e3a38: ldurb           w16, [x1, #-1]
    //     0x4e3a3c: ldurb           w17, [x0, #-1]
    //     0x4e3a40: and             x16, x17, x16, lsr #2
    //     0x4e3a44: tst             x16, HEAP, lsr #32
    //     0x4e3a48: b.eq            #0x4e3a50
    //     0x4e3a4c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3a50: ldur            x3, [fp, #-0x18]
    // 0x4e3a54: r16 = 26
    //     0x4e3a54: movz            x16, #0x1a
    // 0x4e3a58: StoreField: r3->field_6f = r16
    //     0x4e3a58: stur            w16, [x3, #0x6f]
    // 0x4e3a5c: ldur            x4, [fp, #-0x10]
    // 0x4e3a60: LoadField: r0 = r4->field_73
    //     0x4e3a60: ldur            w0, [x4, #0x73]
    // 0x4e3a64: DecompressPointer r0
    //     0x4e3a64: add             x0, x0, HEAP, lsl #32
    // 0x4e3a68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4e3a6c: cmp             w0, w16
    // 0x4e3a70: b.eq            #0x4e3cb8
    // 0x4e3a74: mov             x1, x3
    // 0x4e3a78: ArrayStore: r1[25] = r0  ; List_4
    //     0x4e3a78: add             x25, x1, #0x73
    //     0x4e3a7c: str             w0, [x25]
    //     0x4e3a80: tbz             w0, #0, #0x4e3a9c
    //     0x4e3a84: ldurb           w16, [x1, #-1]
    //     0x4e3a88: ldurb           w17, [x0, #-1]
    //     0x4e3a8c: and             x16, x17, x16, lsr #2
    //     0x4e3a90: tst             x16, HEAP, lsr #32
    //     0x4e3a94: b.eq            #0x4e3a9c
    //     0x4e3a98: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3a9c: r16 = 28
    //     0x4e3a9c: movz            x16, #0x1c
    // 0x4e3aa0: StoreField: r3->field_77 = r16
    //     0x4e3aa0: stur            w16, [x3, #0x77]
    // 0x4e3aa4: LoadField: r2 = r4->field_13
    //     0x4e3aa4: ldur            w2, [x4, #0x13]
    // 0x4e3aa8: DecompressPointer r2
    //     0x4e3aa8: add             x2, x2, HEAP, lsl #32
    // 0x4e3aac: r1 = <int>
    //     0x4e3aac: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3ab0: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3ab0: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3ab4: ldur            x1, [fp, #-0x18]
    // 0x4e3ab8: ArrayStore: r1[27] = r0  ; List_4
    //     0x4e3ab8: add             x25, x1, #0x7b
    //     0x4e3abc: str             w0, [x25]
    //     0x4e3ac0: tbz             w0, #0, #0x4e3adc
    //     0x4e3ac4: ldurb           w16, [x1, #-1]
    //     0x4e3ac8: ldurb           w17, [x0, #-1]
    //     0x4e3acc: and             x16, x17, x16, lsr #2
    //     0x4e3ad0: tst             x16, HEAP, lsr #32
    //     0x4e3ad4: b.eq            #0x4e3adc
    //     0x4e3ad8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3adc: ldur            x0, [fp, #-0x18]
    // 0x4e3ae0: r16 = 30
    //     0x4e3ae0: movz            x16, #0x1e
    // 0x4e3ae4: StoreField: r0->field_7f = r16
    //     0x4e3ae4: stur            w16, [x0, #0x7f]
    // 0x4e3ae8: ldur            x3, [fp, #-0x10]
    // 0x4e3aec: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x4e3aec: ldur            w2, [x3, #0x17]
    // 0x4e3af0: DecompressPointer r2
    //     0x4e3af0: add             x2, x2, HEAP, lsl #32
    // 0x4e3af4: r1 = <int>
    //     0x4e3af4: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3af8: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3af8: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3afc: ldur            x1, [fp, #-0x18]
    // 0x4e3b00: ArrayStore: r1[29] = r0  ; List_4
    //     0x4e3b00: add             x25, x1, #0x83
    //     0x4e3b04: str             w0, [x25]
    //     0x4e3b08: tbz             w0, #0, #0x4e3b24
    //     0x4e3b0c: ldurb           w16, [x1, #-1]
    //     0x4e3b10: ldurb           w17, [x0, #-1]
    //     0x4e3b14: and             x16, x17, x16, lsr #2
    //     0x4e3b18: tst             x16, HEAP, lsr #32
    //     0x4e3b1c: b.eq            #0x4e3b24
    //     0x4e3b20: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3b24: ldur            x0, [fp, #-0x18]
    // 0x4e3b28: r16 = 32
    //     0x4e3b28: movz            x16, #0x20
    // 0x4e3b2c: StoreField: r0->field_87 = r16
    //     0x4e3b2c: stur            w16, [x0, #0x87]
    // 0x4e3b30: ldur            x3, [fp, #-0x10]
    // 0x4e3b34: LoadField: r2 = r3->field_1b
    //     0x4e3b34: ldur            w2, [x3, #0x1b]
    // 0x4e3b38: DecompressPointer r2
    //     0x4e3b38: add             x2, x2, HEAP, lsl #32
    // 0x4e3b3c: r1 = <int>
    //     0x4e3b3c: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3b40: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3b40: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3b44: ldur            x1, [fp, #-0x18]
    // 0x4e3b48: ArrayStore: r1[31] = r0  ; List_4
    //     0x4e3b48: add             x25, x1, #0x8b
    //     0x4e3b4c: str             w0, [x25]
    //     0x4e3b50: tbz             w0, #0, #0x4e3b6c
    //     0x4e3b54: ldurb           w16, [x1, #-1]
    //     0x4e3b58: ldurb           w17, [x0, #-1]
    //     0x4e3b5c: and             x16, x17, x16, lsr #2
    //     0x4e3b60: tst             x16, HEAP, lsr #32
    //     0x4e3b64: b.eq            #0x4e3b6c
    //     0x4e3b68: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3b6c: ldur            x0, [fp, #-0x18]
    // 0x4e3b70: r16 = 34
    //     0x4e3b70: movz            x16, #0x22
    // 0x4e3b74: StoreField: r0->field_8f = r16
    //     0x4e3b74: stur            w16, [x0, #0x8f]
    // 0x4e3b78: ldur            x3, [fp, #-0x10]
    // 0x4e3b7c: LoadField: r2 = r3->field_f
    //     0x4e3b7c: ldur            w2, [x3, #0xf]
    // 0x4e3b80: DecompressPointer r2
    //     0x4e3b80: add             x2, x2, HEAP, lsl #32
    // 0x4e3b84: r1 = <int>
    //     0x4e3b84: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3b88: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3b88: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3b8c: ldur            x1, [fp, #-0x18]
    // 0x4e3b90: ArrayStore: r1[33] = r0  ; List_4
    //     0x4e3b90: add             x25, x1, #0x93
    //     0x4e3b94: str             w0, [x25]
    //     0x4e3b98: tbz             w0, #0, #0x4e3bb4
    //     0x4e3b9c: ldurb           w16, [x1, #-1]
    //     0x4e3ba0: ldurb           w17, [x0, #-1]
    //     0x4e3ba4: and             x16, x17, x16, lsr #2
    //     0x4e3ba8: tst             x16, HEAP, lsr #32
    //     0x4e3bac: b.eq            #0x4e3bb4
    //     0x4e3bb0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3bb4: ldur            x0, [fp, #-0x18]
    // 0x4e3bb8: r16 = 36
    //     0x4e3bb8: movz            x16, #0x24
    // 0x4e3bbc: StoreField: r0->field_97 = r16
    //     0x4e3bbc: stur            w16, [x0, #0x97]
    // 0x4e3bc0: ldur            x3, [fp, #-0x10]
    // 0x4e3bc4: LoadField: r2 = r3->field_1f
    //     0x4e3bc4: ldur            w2, [x3, #0x1f]
    // 0x4e3bc8: DecompressPointer r2
    //     0x4e3bc8: add             x2, x2, HEAP, lsl #32
    // 0x4e3bcc: r1 = <int>
    //     0x4e3bcc: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x4e3bd0: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x4e3bd0: bl              #0x327a3c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x4e3bd4: ldur            x1, [fp, #-0x18]
    // 0x4e3bd8: ArrayStore: r1[35] = r0  ; List_4
    //     0x4e3bd8: add             x25, x1, #0x9b
    //     0x4e3bdc: str             w0, [x25]
    //     0x4e3be0: tbz             w0, #0, #0x4e3bfc
    //     0x4e3be4: ldurb           w16, [x1, #-1]
    //     0x4e3be8: ldurb           w17, [x0, #-1]
    //     0x4e3bec: and             x16, x17, x16, lsr #2
    //     0x4e3bf0: tst             x16, HEAP, lsr #32
    //     0x4e3bf4: b.eq            #0x4e3bfc
    //     0x4e3bf8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3bfc: ldur            x2, [fp, #-0x18]
    // 0x4e3c00: r16 = 40
    //     0x4e3c00: movz            x16, #0x28
    // 0x4e3c04: StoreField: r2->field_9f = r16
    //     0x4e3c04: stur            w16, [x2, #0x9f]
    // 0x4e3c08: ldur            x3, [fp, #-0x10]
    // 0x4e3c0c: LoadField: r4 = r3->field_23
    //     0x4e3c0c: ldur            x4, [x3, #0x23]
    // 0x4e3c10: r0 = BoxInt64Instr(r4)
    //     0x4e3c10: sbfiz           x0, x4, #1, #0x1f
    //     0x4e3c14: cmp             x4, x0, asr #1
    //     0x4e3c18: b.eq            #0x4e3c24
    //     0x4e3c1c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e3c20: stur            x4, [x0, #7]
    // 0x4e3c24: mov             x1, x2
    // 0x4e3c28: ArrayStore: r1[37] = r0  ; List_4
    //     0x4e3c28: add             x25, x1, #0xa3
    //     0x4e3c2c: str             w0, [x25]
    //     0x4e3c30: tbz             w0, #0, #0x4e3c4c
    //     0x4e3c34: ldurb           w16, [x1, #-1]
    //     0x4e3c38: ldurb           w17, [x0, #-1]
    //     0x4e3c3c: and             x16, x17, x16, lsr #2
    //     0x4e3c40: tst             x16, HEAP, lsr #32
    //     0x4e3c44: b.eq            #0x4e3c4c
    //     0x4e3c48: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3c4c: r16 = 46
    //     0x4e3c4c: movz            x16, #0x2e
    // 0x4e3c50: StoreField: r2->field_a7 = r16
    //     0x4e3c50: stur            w16, [x2, #0xa7]
    // 0x4e3c54: LoadField: r4 = r3->field_83
    //     0x4e3c54: ldur            x4, [x3, #0x83]
    // 0x4e3c58: r0 = BoxInt64Instr(r4)
    //     0x4e3c58: sbfiz           x0, x4, #1, #0x1f
    //     0x4e3c5c: cmp             x4, x0, asr #1
    //     0x4e3c60: b.eq            #0x4e3c6c
    //     0x4e3c64: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e3c68: stur            x4, [x0, #7]
    // 0x4e3c6c: mov             x1, x2
    // 0x4e3c70: ArrayStore: r1[39] = r0  ; List_4
    //     0x4e3c70: add             x25, x1, #0xab
    //     0x4e3c74: str             w0, [x25]
    //     0x4e3c78: tbz             w0, #0, #0x4e3c94
    //     0x4e3c7c: ldurb           w16, [x1, #-1]
    //     0x4e3c80: ldurb           w17, [x0, #-1]
    //     0x4e3c84: and             x16, x17, x16, lsr #2
    //     0x4e3c88: tst             x16, HEAP, lsr #32
    //     0x4e3c8c: b.eq            #0x4e3c94
    //     0x4e3c90: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e3c94: r16 = <int, dynamic>
    //     0x4e3c94: add             x16, PP, #0xf, lsl #12  ; [pp+0xf4f0] TypeArguments: <int, dynamic>
    //     0x4e3c98: ldr             x16, [x16, #0x4f0]
    // 0x4e3c9c: stp             x2, x16, [SP]
    // 0x4e3ca0: r0 = Map._fromLiteral()
    //     0x4e3ca0: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e3ca4: LeaveFrame
    //     0x4e3ca4: mov             SP, fp
    //     0x4e3ca8: ldp             fp, lr, [SP], #0x10
    // 0x4e3cac: ret
    //     0x4e3cac: ret             
    // 0x4e3cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e3cb0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e3cb4: b               #0x4e36bc
    // 0x4e3cb8: r9 = startMillisecondsSinceEpoch
    //     0x4e3cb8: add             x9, PP, #0x16, lsl #12  ; [pp+0x16c10] Field <IPlayableGameState.startMillisecondsSinceEpoch>: late (offset: 0x74)
    //     0x4e3cbc: ldr             x9, [x9, #0xc10]
    // 0x4e3cc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x4e3cc0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ statMapToFile(/* No info */) {
    // ** addr: 0x4e3d98, size: 0x198
    // 0x4e3d98: EnterFrame
    //     0x4e3d98: stp             fp, lr, [SP, #-0x10]!
    //     0x4e3d9c: mov             fp, SP
    // 0x4e3da0: AllocStack(0x40)
    //     0x4e3da0: sub             SP, SP, #0x40
    // 0x4e3da4: SetupParameters(IPlayableGameState<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x4e3da4: stur            x1, [fp, #-8]
    //     0x4e3da8: stur            x2, [fp, #-0x10]
    // 0x4e3dac: CheckStackOverflow
    //     0x4e3dac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e3db0: cmp             SP, x16
    //     0x4e3db4: b.ls            #0x4e3f00
    // 0x4e3db8: r16 = <int, double>
    //     0x4e3db8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd100] TypeArguments: <int, double>
    //     0x4e3dbc: ldr             x16, [x16, #0x100]
    // 0x4e3dc0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4e3dc4: stp             lr, x16, [SP]
    // 0x4e3dc8: r0 = Map._fromLiteral()
    //     0x4e3dc8: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x4e3dcc: mov             x4, x0
    // 0x4e3dd0: ldur            x0, [fp, #-0x10]
    // 0x4e3dd4: stur            x4, [fp, #-0x18]
    // 0x4e3dd8: LoadField: r2 = r0->field_7
    //     0x4e3dd8: ldur            w2, [x0, #7]
    // 0x4e3ddc: DecompressPointer r2
    //     0x4e3ddc: add             x2, x2, HEAP, lsl #32
    // 0x4e3de0: r1 = Null
    //     0x4e3de0: mov             x1, NULL
    // 0x4e3de4: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x4e3de4: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x4e3de8: r30 = InstantiateTypeArgumentsStub
    //     0x4e3de8: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x4e3dec: LoadField: r30 = r30->field_7
    //     0x4e3dec: ldur            lr, [lr, #7]
    // 0x4e3df0: blr             lr
    // 0x4e3df4: mov             x1, x0
    // 0x4e3df8: r0 = _CompactEntriesIterable()
    //     0x4e3df8: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x4e3dfc: mov             x1, x0
    // 0x4e3e00: ldur            x0, [fp, #-0x10]
    // 0x4e3e04: StoreField: r1->field_b = r0
    //     0x4e3e04: stur            w0, [x1, #0xb]
    // 0x4e3e08: r0 = iterator()
    //     0x4e3e08: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x4e3e0c: stur            x0, [fp, #-0x10]
    // 0x4e3e10: ldur            x2, [fp, #-8]
    // 0x4e3e14: CheckStackOverflow
    //     0x4e3e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e3e18: cmp             SP, x16
    //     0x4e3e1c: b.ls            #0x4e3f08
    // 0x4e3e20: mov             x1, x0
    // 0x4e3e24: r0 = moveNext()
    //     0x4e3e24: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x4e3e28: tbnz            w0, #4, #0x4e3ee4
    // 0x4e3e2c: ldur            x1, [fp, #-0x10]
    // 0x4e3e30: LoadField: r2 = r1->field_2b
    //     0x4e3e30: ldur            w2, [x1, #0x2b]
    // 0x4e3e34: DecompressPointer r2
    //     0x4e3e34: add             x2, x2, HEAP, lsl #32
    // 0x4e3e38: stur            x2, [fp, #-0x20]
    // 0x4e3e3c: cmp             w2, NULL
    // 0x4e3e40: b.eq            #0x4e3ef4
    // 0x4e3e44: ldur            x3, [fp, #-8]
    // 0x4e3e48: LoadField: r0 = r2->field_b
    //     0x4e3e48: ldur            w0, [x2, #0xb]
    // 0x4e3e4c: DecompressPointer r0
    //     0x4e3e4c: add             x0, x0, HEAP, lsl #32
    // 0x4e3e50: LoadField: r4 = r3->field_63
    //     0x4e3e50: ldur            w4, [x3, #0x63]
    // 0x4e3e54: DecompressPointer r4
    //     0x4e3e54: add             x4, x4, HEAP, lsl #32
    // 0x4e3e58: stp             x0, x4, [SP]
    // 0x4e3e5c: mov             x0, x4
    // 0x4e3e60: ClosureCall
    //     0x4e3e60: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4e3e64: ldur            x2, [x0, #0x1f]
    //     0x4e3e68: blr             x2
    // 0x4e3e6c: mov             x3, x0
    // 0x4e3e70: ldur            x0, [fp, #-0x20]
    // 0x4e3e74: stur            x3, [fp, #-0x28]
    // 0x4e3e78: LoadField: r1 = r0->field_f
    //     0x4e3e78: ldur            w1, [x0, #0xf]
    // 0x4e3e7c: DecompressPointer r1
    //     0x4e3e7c: add             x1, x1, HEAP, lsl #32
    // 0x4e3e80: cmp             w1, NULL
    // 0x4e3e84: b.eq            #0x4e3f10
    // 0x4e3e88: LoadField: d0 = r1->field_7
    //     0x4e3e88: ldur            d0, [x1, #7]
    // 0x4e3e8c: ldur            x1, [fp, #-0x18]
    // 0x4e3e90: mov             x2, x3
    // 0x4e3e94: stur            d0, [fp, #-0x30]
    // 0x4e3e98: r0 = _hashCode()
    //     0x4e3e98: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x4e3e9c: ldur            d0, [fp, #-0x30]
    // 0x4e3ea0: r3 = inline_Allocate_Double()
    //     0x4e3ea0: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x4e3ea4: add             x3, x3, #0x10
    //     0x4e3ea8: cmp             x1, x3
    //     0x4e3eac: b.ls            #0x4e3f14
    //     0x4e3eb0: str             x3, [THR, #0x60]  ; THR::top
    //     0x4e3eb4: sub             x3, x3, #0xf
    //     0x4e3eb8: movz            x1, #0xe19c
    //     0x4e3ebc: movk            x1, #0x3, lsl #16
    //     0x4e3ec0: stur            x1, [x3, #-1]
    // 0x4e3ec4: dmb             ishst
    // 0x4e3ec8: StoreField: r3->field_7 = d0
    //     0x4e3ec8: stur            d0, [x3, #7]
    // 0x4e3ecc: ldur            x1, [fp, #-0x18]
    // 0x4e3ed0: ldur            x2, [fp, #-0x28]
    // 0x4e3ed4: mov             x5, x0
    // 0x4e3ed8: r0 = _set()
    //     0x4e3ed8: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x4e3edc: ldur            x0, [fp, #-0x10]
    // 0x4e3ee0: b               #0x4e3e10
    // 0x4e3ee4: ldur            x0, [fp, #-0x18]
    // 0x4e3ee8: LeaveFrame
    //     0x4e3ee8: mov             SP, fp
    //     0x4e3eec: ldp             fp, lr, [SP], #0x10
    // 0x4e3ef0: ret
    //     0x4e3ef0: ret             
    // 0x4e3ef4: r0 = noElement()
    //     0x4e3ef4: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x4e3ef8: r0 = Throw()
    //     0x4e3ef8: bl              #0x825670  ; ThrowStub
    // 0x4e3efc: brk             #0
    // 0x4e3f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e3f00: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e3f04: b               #0x4e3db8
    // 0x4e3f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e3f08: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e3f0c: b               #0x4e3e20
    // 0x4e3f10: r0 = NullErrorSharedWithoutFPURegs()
    //     0x4e3f10: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x4e3f14: SaveReg d0
    //     0x4e3f14: str             q0, [SP, #-0x10]!
    // 0x4e3f18: SaveReg r0
    //     0x4e3f18: str             x0, [SP, #-8]!
    // 0x4e3f1c: r0 = AllocateDouble()
    //     0x4e3f1c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x4e3f20: mov             x3, x0
    // 0x4e3f24: RestoreReg r0
    //     0x4e3f24: ldr             x0, [SP], #8
    // 0x4e3f28: RestoreReg d0
    //     0x4e3f28: ldr             q0, [SP], #0x10
    // 0x4e3f2c: b               #0x4e3ec8
  }
  _ notifyFocusLost(/* No info */) {
    // ** addr: 0x534464, size: 0xb8
    // 0x534464: EnterFrame
    //     0x534464: stp             fp, lr, [SP, #-0x10]!
    //     0x534468: mov             fp, SP
    // 0x53446c: AllocStack(0x18)
    //     0x53446c: sub             SP, SP, #0x18
    // 0x534470: SetupParameters(IPlayableGameState<X0> this /* r1 => r1, fp-0x10 */)
    //     0x534470: stur            x1, [fp, #-0x10]
    // 0x534474: CheckStackOverflow
    //     0x534474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x534478: cmp             SP, x16
    //     0x53447c: b.ls            #0x534510
    // 0x534480: LoadField: r0 = r1->field_7f
    //     0x534480: ldur            w0, [x1, #0x7f]
    // 0x534484: DecompressPointer r0
    //     0x534484: add             x0, x0, HEAP, lsl #32
    // 0x534488: cmp             w0, NULL
    // 0x53448c: b.eq            #0x534500
    // 0x534490: LoadField: r0 = r1->field_83
    //     0x534490: ldur            x0, [x1, #0x83]
    // 0x534494: stur            x0, [fp, #-8]
    // 0x534498: r0 = DateTime()
    //     0x534498: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x53449c: mov             x1, x0
    // 0x5344a0: r0 = false
    //     0x5344a0: add             x0, NULL, #0x30  ; false
    // 0x5344a4: stur            x1, [fp, #-0x18]
    // 0x5344a8: StoreField: r1->field_7 = r0
    //     0x5344a8: stur            w0, [x1, #7]
    // 0x5344ac: r0 = _getCurrentMicros()
    //     0x5344ac: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x5344b0: r1 = LoadInt32Instr(r0)
    //     0x5344b0: sbfx            x1, x0, #1, #0x1f
    //     0x5344b4: tbz             w0, #0, #0x5344bc
    //     0x5344b8: ldur            x1, [x0, #7]
    // 0x5344bc: ldur            x0, [fp, #-0x18]
    // 0x5344c0: StoreField: r0->field_b = r1
    //     0x5344c0: stur            x1, [x0, #0xb]
    // 0x5344c4: ldur            x3, [fp, #-0x10]
    // 0x5344c8: LoadField: r2 = r3->field_7f
    //     0x5344c8: ldur            w2, [x3, #0x7f]
    // 0x5344cc: DecompressPointer r2
    //     0x5344cc: add             x2, x2, HEAP, lsl #32
    // 0x5344d0: cmp             w2, NULL
    // 0x5344d4: b.eq            #0x534518
    // 0x5344d8: mov             x1, x0
    // 0x5344dc: r0 = difference()
    //     0x5344dc: bl              #0x36dbb8  ; [dart:core] DateTime::difference
    // 0x5344e0: LoadField: r1 = r0->field_7
    //     0x5344e0: ldur            x1, [x0, #7]
    // 0x5344e4: r2 = 1000
    //     0x5344e4: movz            x2, #0x3e8
    // 0x5344e8: sdiv            x3, x1, x2
    // 0x5344ec: ldur            x1, [fp, #-8]
    // 0x5344f0: add             x2, x1, x3
    // 0x5344f4: ldur            x1, [fp, #-0x10]
    // 0x5344f8: StoreField: r1->field_83 = r2
    //     0x5344f8: stur            x2, [x1, #0x83]
    // 0x5344fc: StoreField: r1->field_7f = rNULL
    //     0x5344fc: stur            NULL, [x1, #0x7f]
    // 0x534500: r0 = Null
    //     0x534500: mov             x0, NULL
    // 0x534504: LeaveFrame
    //     0x534504: mov             SP, fp
    //     0x534508: ldp             fp, lr, [SP], #0x10
    // 0x53450c: ret
    //     0x53450c: ret             
    // 0x534510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x534510: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x534514: b               #0x534480
    // 0x534518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x534518: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ update(/* No info */) {
    // ** addr: 0x537a04, size: 0x118
    // 0x537a04: EnterFrame
    //     0x537a04: stp             fp, lr, [SP, #-0x10]!
    //     0x537a08: mov             fp, SP
    // 0x537a0c: AllocStack(0x18)
    //     0x537a0c: sub             SP, SP, #0x18
    // 0x537a10: SetupParameters(IPlayableGameState<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x537a10: stur            x1, [fp, #-8]
    //     0x537a14: stur            x2, [fp, #-0x10]
    // 0x537a18: CheckStackOverflow
    //     0x537a18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x537a1c: cmp             SP, x16
    //     0x537a20: b.ls            #0x537b10
    // 0x537a24: LoadField: r0 = r1->field_7f
    //     0x537a24: ldur            w0, [x1, #0x7f]
    // 0x537a28: DecompressPointer r0
    //     0x537a28: add             x0, x0, HEAP, lsl #32
    // 0x537a2c: cmp             w0, NULL
    // 0x537a30: b.ne            #0x537ab8
    // 0x537a34: r0 = LoadStaticField(0x444)
    //     0x537a34: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x537a38: ldr             x0, [x0, #0x888]
    // 0x537a3c: cmp             w0, NULL
    // 0x537a40: b.eq            #0x537b18
    // 0x537a44: LoadField: r3 = r0->field_2f
    //     0x537a44: ldur            w3, [x0, #0x2f]
    // 0x537a48: DecompressPointer r3
    //     0x537a48: add             x3, x3, HEAP, lsl #32
    // 0x537a4c: cmp             w3, NULL
    // 0x537a50: b.eq            #0x537a60
    // 0x537a54: r16 = Instance_AppLifecycleState
    //     0x537a54: ldr             x16, [PP, #0x45f0]  ; [pp+0x45f0] Obj!AppLifecycleState@865c41
    // 0x537a58: cmp             w3, w16
    // 0x537a5c: b.ne            #0x537ab0
    // 0x537a60: r0 = DateTime()
    //     0x537a60: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x537a64: mov             x1, x0
    // 0x537a68: r0 = false
    //     0x537a68: add             x0, NULL, #0x30  ; false
    // 0x537a6c: stur            x1, [fp, #-0x18]
    // 0x537a70: StoreField: r1->field_7 = r0
    //     0x537a70: stur            w0, [x1, #7]
    // 0x537a74: r0 = _getCurrentMicros()
    //     0x537a74: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x537a78: r1 = LoadInt32Instr(r0)
    //     0x537a78: sbfx            x1, x0, #1, #0x1f
    //     0x537a7c: tbz             w0, #0, #0x537a84
    //     0x537a80: ldur            x1, [x0, #7]
    // 0x537a84: ldur            x0, [fp, #-0x18]
    // 0x537a88: StoreField: r0->field_b = r1
    //     0x537a88: stur            x1, [x0, #0xb]
    // 0x537a8c: ldur            x4, [fp, #-8]
    // 0x537a90: StoreField: r4->field_7f = r0
    //     0x537a90: stur            w0, [x4, #0x7f]
    //     0x537a94: ldurb           w16, [x4, #-1]
    //     0x537a98: ldurb           w17, [x0, #-1]
    //     0x537a9c: and             x16, x17, x16, lsr #2
    //     0x537aa0: tst             x16, HEAP, lsr #32
    //     0x537aa4: b.eq            #0x537aac
    //     0x537aa8: bl              #0x825b38  ; WriteBarrierWrappersStub
    // 0x537aac: b               #0x537abc
    // 0x537ab0: mov             x4, x1
    // 0x537ab4: b               #0x537abc
    // 0x537ab8: mov             x4, x1
    // 0x537abc: LoadField: r3 = r4->field_3b
    //     0x537abc: ldur            w3, [x4, #0x3b]
    // 0x537ac0: DecompressPointer r3
    //     0x537ac0: add             x3, x3, HEAP, lsl #32
    // 0x537ac4: LoadField: r5 = r4->field_37
    //     0x537ac4: ldur            w5, [x4, #0x37]
    // 0x537ac8: DecompressPointer r5
    //     0x537ac8: add             x5, x5, HEAP, lsl #32
    // 0x537acc: mov             x1, x4
    // 0x537ad0: ldur            x2, [fp, #-0x10]
    // 0x537ad4: r0 = computeAndApplyIncome()
    //     0x537ad4: bl              #0x537b1c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::computeAndApplyIncome
    // 0x537ad8: ldur            x1, [fp, #-8]
    // 0x537adc: LoadField: r3 = r1->field_57
    //     0x537adc: ldur            w3, [x1, #0x57]
    // 0x537ae0: DecompressPointer r3
    //     0x537ae0: add             x3, x3, HEAP, lsl #32
    // 0x537ae4: r0 = LoadClassIdInstr(r1)
    //     0x537ae4: ldur            x0, [x1, #-1]
    //     0x537ae8: ubfx            x0, x0, #0xc, #0x14
    // 0x537aec: ldur            x2, [fp, #-0x10]
    // 0x537af0: r0 = GDT[cid_x0 + 0x8a4e]()
    //     0x537af0: movz            x17, #0x8a4e
    //     0x537af4: add             lr, x0, x17
    //     0x537af8: ldr             lr, [x21, lr, lsl #3]
    //     0x537afc: blr             lr
    // 0x537b00: r0 = Null
    //     0x537b00: mov             x0, NULL
    // 0x537b04: LeaveFrame
    //     0x537b04: mov             SP, fp
    //     0x537b08: ldp             fp, lr, [SP], #0x10
    // 0x537b0c: ret
    //     0x537b0c: ret             
    // 0x537b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x537b10: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x537b14: b               #0x537a24
    // 0x537b18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x537b18: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeAndApplyIncome(/* No info */) {
    // ** addr: 0x537b1c, size: 0x680
    // 0x537b1c: EnterFrame
    //     0x537b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x537b20: mov             fp, SP
    // 0x537b24: AllocStack(0x78)
    //     0x537b24: sub             SP, SP, #0x78
    // 0x537b28: SetupParameters(IPlayableGameState<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x537b28: mov             x4, x1
    //     0x537b2c: stur            x1, [fp, #-8]
    //     0x537b30: stur            x2, [fp, #-0x10]
    // 0x537b34: CheckStackOverflow
    //     0x537b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x537b38: cmp             SP, x16
    //     0x537b3c: b.ls            #0x53814c
    // 0x537b40: r0 = LoadClassIdInstr(r4)
    //     0x537b40: ldur            x0, [x4, #-1]
    //     0x537b44: ubfx            x0, x0, #0xc, #0x14
    // 0x537b48: mov             x1, x4
    // 0x537b4c: r0 = GDT[cid_x0 + 0x7d47]()
    //     0x537b4c: movz            x17, #0x7d47
    //     0x537b50: add             lr, x0, x17
    //     0x537b54: ldr             lr, [x21, lr, lsl #3]
    //     0x537b58: blr             lr
    // 0x537b5c: ldur            x0, [fp, #-0x10]
    // 0x537b60: tbz             x0, #0x3f, #0x537bdc
    // 0x537b64: ldur            x1, [fp, #-8]
    // 0x537b68: LoadField: r0 = r1->field_7
    //     0x537b68: ldur            w0, [x1, #7]
    // 0x537b6c: DecompressPointer r0
    //     0x537b6c: add             x0, x0, HEAP, lsl #32
    // 0x537b70: mov             x2, x0
    // 0x537b74: stur            x0, [fp, #-0x18]
    // 0x537b78: r1 = Null
    //     0x537b78: mov             x1, NULL
    // 0x537b7c: r3 = <X0, CustomNum>
    //     0x537b7c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x537b80: ldr             x3, [x3, #0xb10]
    // 0x537b84: r30 = InstantiateTypeArgumentsStub
    //     0x537b84: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x537b88: LoadField: r30 = r30->field_7
    //     0x537b88: ldur            lr, [lr, #7]
    // 0x537b8c: blr             lr
    // 0x537b90: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x537b94: stp             x16, x0, [SP]
    // 0x537b98: r0 = Map._fromLiteral()
    //     0x537b98: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x537b9c: ldur            x2, [fp, #-0x18]
    // 0x537ba0: r1 = Null
    //     0x537ba0: mov             x1, NULL
    // 0x537ba4: r3 = <X0, CustomNum>
    //     0x537ba4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x537ba8: ldr             x3, [x3, #0xb10]
    // 0x537bac: stur            x0, [fp, #-0x18]
    // 0x537bb0: r30 = InstantiateTypeArgumentsStub
    //     0x537bb0: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x537bb4: LoadField: r30 = r30->field_7
    //     0x537bb4: ldur            lr, [lr, #7]
    // 0x537bb8: blr             lr
    // 0x537bbc: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x537bc0: stp             x16, x0, [SP]
    // 0x537bc4: r0 = Map._fromLiteral()
    //     0x537bc4: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x537bc8: mov             x1, x0
    // 0x537bcc: ldur            x0, [fp, #-0x18]
    // 0x537bd0: LeaveFrame
    //     0x537bd0: mov             SP, fp
    //     0x537bd4: ldp             fp, lr, [SP], #0x10
    // 0x537bd8: ret
    //     0x537bd8: ret             
    // 0x537bdc: ldur            x1, [fp, #-8]
    // 0x537be0: r2 = 604800000
    //     0x537be0: movz            x2, #0x8400
    //     0x537be4: movk            x2, #0x240c, lsl #16
    // 0x537be8: cmp             x0, x2
    // 0x537bec: csel            x3, x2, x0, gt
    // 0x537bf0: r17 = 30000
    //     0x537bf0: movz            x17, #0x7530
    // 0x537bf4: cmp             x3, x17
    // 0x537bf8: b.lt            #0x537c34
    // 0x537bfc: d0 = 0.500000
    //     0x537bfc: fmov            d0, #0.50000000
    // 0x537c00: scvtf           d1, x3
    // 0x537c04: fmul            d2, d1, d0
    // 0x537c08: fcmp            d2, d2
    // 0x537c0c: b.vs            #0x538154
    // 0x537c10: fcvtms          x0, d2
    // 0x537c14: asr             x16, x0, #0x1e
    // 0x537c18: cmp             x16, x0, asr #63
    // 0x537c1c: b.ne            #0x538154
    // 0x537c20: lsl             x0, x0, #1
    // 0x537c24: r2 = LoadInt32Instr(r0)
    //     0x537c24: sbfx            x2, x0, #1, #0x1f
    //     0x537c28: tbz             w0, #0, #0x537c30
    //     0x537c2c: ldur            x2, [x0, #7]
    // 0x537c30: b               #0x537c38
    // 0x537c34: mov             x2, x3
    // 0x537c38: stur            x2, [fp, #-0x20]
    // 0x537c3c: r0 = LoadStaticField(0xfd0)
    //     0x537c3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x537c40: ldr             x0, [x0, #0x1fa0]
    // 0x537c44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x537c48: cmp             w0, w16
    // 0x537c4c: b.eq            #0x53817c
    // 0x537c50: LoadField: r3 = r0->field_13
    //     0x537c50: ldur            w3, [x0, #0x13]
    // 0x537c54: DecompressPointer r3
    //     0x537c54: add             x3, x3, HEAP, lsl #32
    // 0x537c58: tbz             w3, #4, #0x537cfc
    // 0x537c5c: r0 = LoadStaticField(0xfd4)
    //     0x537c5c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x537c60: ldr             x0, [x0, #0x1fa8]
    // 0x537c64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x537c68: cmp             w0, w16
    // 0x537c6c: b.eq            #0x538188
    // 0x537c70: LoadField: r3 = r0->field_b
    //     0x537c70: ldur            x3, [x0, #0xb]
    // 0x537c74: tbz             x3, #0x3f, #0x537c80
    // 0x537c78: r4 = 999
    //     0x537c78: movz            x4, #0x3e7
    // 0x537c7c: b               #0x537c84
    // 0x537c80: r4 = 0
    //     0x537c80: movz            x4, #0
    // 0x537c84: r0 = 1000
    //     0x537c84: movz            x0, #0x3e8
    // 0x537c88: sub             x5, x3, x4
    // 0x537c8c: sdiv            x3, x5, x0
    // 0x537c90: stur            x3, [fp, #-0x10]
    // 0x537c94: r0 = _getCurrentMicros()
    //     0x537c94: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x537c98: r1 = LoadInt32Instr(r0)
    //     0x537c98: sbfx            x1, x0, #1, #0x1f
    //     0x537c9c: tbz             w0, #0, #0x537ca4
    //     0x537ca0: ldur            x1, [x0, #7]
    // 0x537ca4: tbz             x1, #0x3f, #0x537cb0
    // 0x537ca8: r3 = 999
    //     0x537ca8: movz            x3, #0x3e7
    // 0x537cac: b               #0x537cb4
    // 0x537cb0: r3 = 0
    //     0x537cb0: movz            x3, #0
    // 0x537cb4: ldur            x2, [fp, #-0x10]
    // 0x537cb8: r0 = 1000
    //     0x537cb8: movz            x0, #0x3e8
    // 0x537cbc: sub             x4, x1, x3
    // 0x537cc0: sdiv            x1, x4, x0
    // 0x537cc4: sub             x0, x2, x1
    // 0x537cc8: cmp             x0, #0
    // 0x537ccc: b.le            #0x537cd8
    // 0x537cd0: ldur            x0, [fp, #-0x20]
    // 0x537cd4: b               #0x537cf4
    // 0x537cd8: ldur            x1, [fp, #-0x20]
    // 0x537cdc: add             x2, x1, x0
    // 0x537ce0: cmp             x2, #0
    // 0x537ce4: b.le            #0x537cf0
    // 0x537ce8: add             x0, x1, x2
    // 0x537cec: b               #0x537cf4
    // 0x537cf0: mov             x0, x1
    // 0x537cf4: mov             x4, x0
    // 0x537cf8: b               #0x537d04
    // 0x537cfc: mov             x1, x2
    // 0x537d00: mov             x4, x1
    // 0x537d04: ldur            x0, [fp, #-8]
    // 0x537d08: stur            x4, [fp, #-0x10]
    // 0x537d0c: LoadField: r5 = r0->field_7
    //     0x537d0c: ldur            w5, [x0, #7]
    // 0x537d10: DecompressPointer r5
    //     0x537d10: add             x5, x5, HEAP, lsl #32
    // 0x537d14: mov             x2, x5
    // 0x537d18: stur            x5, [fp, #-0x18]
    // 0x537d1c: r1 = Null
    //     0x537d1c: mov             x1, NULL
    // 0x537d20: r3 = <X0, CustomNum>
    //     0x537d20: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x537d24: ldr             x3, [x3, #0xb10]
    // 0x537d28: r30 = InstantiateTypeArgumentsStub
    //     0x537d28: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x537d2c: LoadField: r30 = r30->field_7
    //     0x537d2c: ldur            lr, [lr, #7]
    // 0x537d30: blr             lr
    // 0x537d34: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x537d38: stp             x16, x0, [SP]
    // 0x537d3c: r0 = Map._fromLiteral()
    //     0x537d3c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x537d40: ldur            x2, [fp, #-0x18]
    // 0x537d44: r1 = Null
    //     0x537d44: mov             x1, NULL
    // 0x537d48: r3 = <X0, CustomNum>
    //     0x537d48: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x537d4c: ldr             x3, [x3, #0xb10]
    // 0x537d50: stur            x0, [fp, #-0x28]
    // 0x537d54: r30 = InstantiateTypeArgumentsStub
    //     0x537d54: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x537d58: LoadField: r30 = r30->field_7
    //     0x537d58: ldur            lr, [lr, #7]
    // 0x537d5c: blr             lr
    // 0x537d60: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x537d64: stp             x16, x0, [SP]
    // 0x537d68: r0 = Map._fromLiteral()
    //     0x537d68: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x537d6c: mov             x4, x0
    // 0x537d70: ldur            x0, [fp, #-0x10]
    // 0x537d74: stur            x4, [fp, #-0x50]
    // 0x537d78: r17 = 86400000
    //     0x537d78: movz            x17, #0x5c00
    //     0x537d7c: movk            x17, #0x526, lsl #16
    // 0x537d80: cmp             x0, x17
    // 0x537d84: b.ge            #0x537d94
    // 0x537d88: r6 = 1800000
    //     0x537d88: movz            x6, #0x7740
    //     0x537d8c: movk            x6, #0x1b, lsl #16
    // 0x537d90: b               #0x537dbc
    // 0x537d94: r17 = 172800000
    //     0x537d94: movz            x17, #0xb800
    //     0x537d98: movk            x17, #0xa4c, lsl #16
    // 0x537d9c: cmp             x0, x17
    // 0x537da0: b.ge            #0x537db0
    // 0x537da4: r1 = 3600000
    //     0x537da4: movz            x1, #0xee80
    //     0x537da8: movk            x1, #0x36, lsl #16
    // 0x537dac: b               #0x537db8
    // 0x537db0: r1 = 14400000
    //     0x537db0: movz            x1, #0xba00
    //     0x537db4: movk            x1, #0xdb, lsl #16
    // 0x537db8: mov             x6, x1
    // 0x537dbc: stur            x6, [fp, #-0x48]
    // 0x537dc0: r2 = 10000
    //     0x537dc0: movz            x2, #0x2710
    // 0x537dc4: r9 = 0
    //     0x537dc4: movz            x9, #0
    // 0x537dc8: r8 = 0
    //     0x537dc8: movz            x8, #0
    // 0x537dcc: r1 = 200
    //     0x537dcc: movz            x1, #0xc8
    // 0x537dd0: ldur            x7, [fp, #-8]
    // 0x537dd4: stur            x9, [fp, #-0x38]
    // 0x537dd8: stur            x8, [fp, #-0x40]
    // 0x537ddc: CheckStackOverflow
    //     0x537ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x537de0: cmp             SP, x16
    //     0x537de4: b.ls            #0x538194
    // 0x537de8: cmp             x8, x0
    // 0x537dec: b.ge            #0x537fa4
    // 0x537df0: sub             x10, x1, #1
    // 0x537df4: stur            x10, [fp, #-0x30]
    // 0x537df8: cmp             x10, #0
    // 0x537dfc: b.le            #0x53812c
    // 0x537e00: add             x1, x2, x8
    // 0x537e04: cmp             x1, x0
    // 0x537e08: b.le            #0x537e18
    // 0x537e0c: sub             x3, x0, x8
    // 0x537e10: mov             x11, x3
    // 0x537e14: b               #0x537e30
    // 0x537e18: cmp             x2, x6
    // 0x537e1c: b.le            #0x537e28
    // 0x537e20: mov             x3, x6
    // 0x537e24: b               #0x537e2c
    // 0x537e28: mov             x3, x2
    // 0x537e2c: mov             x11, x3
    // 0x537e30: stur            x11, [fp, #-0x20]
    // 0x537e34: LoadField: r3 = r7->field_3b
    //     0x537e34: ldur            w3, [x7, #0x3b]
    // 0x537e38: DecompressPointer r3
    //     0x537e38: add             x3, x3, HEAP, lsl #32
    // 0x537e3c: LoadField: r5 = r7->field_37
    //     0x537e3c: ldur            w5, [x7, #0x37]
    // 0x537e40: DecompressPointer r5
    //     0x537e40: add             x5, x5, HEAP, lsl #32
    // 0x537e44: mov             x1, x7
    // 0x537e48: mov             x2, x11
    // 0x537e4c: r0 = applyTimeSlice()
    //     0x537e4c: bl              #0x538318  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::applyTimeSlice
    // 0x537e50: mov             x3, x0
    // 0x537e54: stur            x3, [fp, #-0x60]
    // 0x537e58: mov             x4, x1
    // 0x537e5c: mov             x0, x3
    // 0x537e60: ldur            x2, [fp, #-0x18]
    // 0x537e64: stur            x4, [fp, #-0x58]
    // 0x537e68: r1 = Null
    //     0x537e68: mov             x1, NULL
    // 0x537e6c: cmp             w0, NULL
    // 0x537e70: b.eq            #0x537ebc
    // 0x537e74: branchIfSmi(r0, 0x537ebc)
    //     0x537e74: tbz             w0, #0, #0x537ebc
    // 0x537e78: r3 = SubtypeTestCache
    //     0x537e78: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e68] SubtypeTestCache
    //     0x537e7c: ldr             x3, [x3, #0xe68]
    // 0x537e80: r30 = Subtype3TestCacheStub
    //     0x537e80: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x322c74)
    // 0x537e84: LoadField: r30 = r30->field_7
    //     0x537e84: ldur            lr, [lr, #7]
    // 0x537e88: blr             lr
    // 0x537e8c: cmp             w7, NULL
    // 0x537e90: b.eq            #0x537e9c
    // 0x537e94: tbnz            w7, #4, #0x537ebc
    // 0x537e98: b               #0x537ec4
    // 0x537e9c: r8 = Map<X0, CustomNum>
    //     0x537e9c: add             x8, PP, #0x16, lsl #12  ; [pp+0x16e70] Type: Map<X0, CustomNum>
    //     0x537ea0: ldr             x8, [x8, #0xe70]
    // 0x537ea4: r3 = SubtypeTestCache
    //     0x537ea4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e78] SubtypeTestCache
    //     0x537ea8: ldr             x3, [x3, #0xe78]
    // 0x537eac: r30 = InstanceOfStub
    //     0x537eac: ldr             lr, [PP, #0x3e8]  ; [pp+0x3e8] Stub: InstanceOf (0x3112f4)
    // 0x537eb0: LoadField: r30 = r30->field_7
    //     0x537eb0: ldur            lr, [lr, #7]
    // 0x537eb4: blr             lr
    // 0x537eb8: b               #0x537ec8
    // 0x537ebc: r0 = false
    //     0x537ebc: add             x0, NULL, #0x30  ; false
    // 0x537ec0: b               #0x537ec8
    // 0x537ec4: r0 = true
    //     0x537ec4: add             x0, NULL, #0x20  ; true
    // 0x537ec8: tbnz            w0, #4, #0x53810c
    // 0x537ecc: ldur            x0, [fp, #-0x58]
    // 0x537ed0: ldur            x2, [fp, #-0x18]
    // 0x537ed4: r1 = Null
    //     0x537ed4: mov             x1, NULL
    // 0x537ed8: cmp             w0, NULL
    // 0x537edc: b.eq            #0x537f28
    // 0x537ee0: branchIfSmi(r0, 0x537f28)
    //     0x537ee0: tbz             w0, #0, #0x537f28
    // 0x537ee4: r3 = SubtypeTestCache
    //     0x537ee4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e80] SubtypeTestCache
    //     0x537ee8: ldr             x3, [x3, #0xe80]
    // 0x537eec: r30 = Subtype3TestCacheStub
    //     0x537eec: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x322c74)
    // 0x537ef0: LoadField: r30 = r30->field_7
    //     0x537ef0: ldur            lr, [lr, #7]
    // 0x537ef4: blr             lr
    // 0x537ef8: cmp             w7, NULL
    // 0x537efc: b.eq            #0x537f08
    // 0x537f00: tbnz            w7, #4, #0x537f28
    // 0x537f04: b               #0x537f30
    // 0x537f08: r8 = Map<X0, CustomNum>
    //     0x537f08: add             x8, PP, #0x16, lsl #12  ; [pp+0x16e88] Type: Map<X0, CustomNum>
    //     0x537f0c: ldr             x8, [x8, #0xe88]
    // 0x537f10: r3 = SubtypeTestCache
    //     0x537f10: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e90] SubtypeTestCache
    //     0x537f14: ldr             x3, [x3, #0xe90]
    // 0x537f18: r30 = InstanceOfStub
    //     0x537f18: ldr             lr, [PP, #0x3e8]  ; [pp+0x3e8] Stub: InstanceOf (0x3112f4)
    // 0x537f1c: LoadField: r30 = r30->field_7
    //     0x537f1c: ldur            lr, [lr, #7]
    // 0x537f20: blr             lr
    // 0x537f24: b               #0x537f34
    // 0x537f28: r0 = false
    //     0x537f28: add             x0, NULL, #0x30  ; false
    // 0x537f2c: b               #0x537f34
    // 0x537f30: r0 = true
    //     0x537f30: add             x0, NULL, #0x20  ; true
    // 0x537f34: tbnz            w0, #4, #0x53810c
    // 0x537f38: ldur            x1, [fp, #-0x38]
    // 0x537f3c: ldur            x0, [fp, #-0x40]
    // 0x537f40: ldur            x9, [fp, #-0x20]
    // 0x537f44: ldur            x16, [fp, #-0x18]
    // 0x537f48: ldur            lr, [fp, #-0x28]
    // 0x537f4c: stp             lr, x16, [SP, #8]
    // 0x537f50: ldur            x16, [fp, #-0x60]
    // 0x537f54: str             x16, [SP]
    // 0x537f58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x537f58: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x537f5c: r0 = MapOperations.merge()
    //     0x537f5c: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x537f60: ldur            x16, [fp, #-0x18]
    // 0x537f64: ldur            lr, [fp, #-0x50]
    // 0x537f68: stp             lr, x16, [SP, #8]
    // 0x537f6c: ldur            x16, [fp, #-0x58]
    // 0x537f70: str             x16, [SP]
    // 0x537f74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x537f74: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x537f78: r0 = MapOperations.merge()
    //     0x537f78: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x537f7c: ldur            x0, [fp, #-0x40]
    // 0x537f80: ldur            x9, [fp, #-0x20]
    // 0x537f84: add             x8, x0, x9
    // 0x537f88: ldur            x0, [fp, #-0x38]
    // 0x537f8c: add             x2, x9, x0
    // 0x537f90: ldur            x1, [fp, #-0x30]
    // 0x537f94: ldur            x0, [fp, #-0x10]
    // 0x537f98: ldur            x4, [fp, #-0x50]
    // 0x537f9c: ldur            x6, [fp, #-0x48]
    // 0x537fa0: b               #0x537dd0
    // 0x537fa4: r17 = 30000
    //     0x537fa4: movz            x17, #0x7530
    // 0x537fa8: cmp             x0, x17
    // 0x537fac: b.lt            #0x5380bc
    // 0x537fb0: ldur            x4, [fp, #-8]
    // 0x537fb4: ldur            x2, [fp, #-0x18]
    // 0x537fb8: r1 = Null
    //     0x537fb8: mov             x1, NULL
    // 0x537fbc: r3 = <X0, CustomNum>
    //     0x537fbc: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x537fc0: ldr             x3, [x3, #0xb10]
    // 0x537fc4: r30 = InstantiateTypeArgumentsStub
    //     0x537fc4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x537fc8: LoadField: r30 = r30->field_7
    //     0x537fc8: ldur            lr, [lr, #7]
    // 0x537fcc: blr             lr
    // 0x537fd0: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x537fd4: stp             x16, x0, [SP]
    // 0x537fd8: r0 = Map._fromLiteral()
    //     0x537fd8: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x537fdc: ldur            x2, [fp, #-0x18]
    // 0x537fe0: r1 = Null
    //     0x537fe0: mov             x1, NULL
    // 0x537fe4: r3 = <X0, CustomNum>
    //     0x537fe4: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x537fe8: ldr             x3, [x3, #0xb10]
    // 0x537fec: stur            x0, [fp, #-0x58]
    // 0x537ff0: r30 = InstantiateTypeArgumentsStub
    //     0x537ff0: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x537ff4: LoadField: r30 = r30->field_7
    //     0x537ff4: ldur            lr, [lr, #7]
    // 0x537ff8: blr             lr
    // 0x537ffc: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x538000: stp             x16, x0, [SP]
    // 0x538004: r0 = Map._fromLiteral()
    //     0x538004: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x538008: mov             x6, x0
    // 0x53800c: ldur            x4, [fp, #-8]
    // 0x538010: stur            x6, [fp, #-0x60]
    // 0x538014: r0 = LoadClassIdInstr(r4)
    //     0x538014: ldur            x0, [x4, #-1]
    //     0x538018: ubfx            x0, x0, #0xc, #0x14
    // 0x53801c: mov             x1, x4
    // 0x538020: ldur            x2, [fp, #-0x10]
    // 0x538024: ldur            x3, [fp, #-0x58]
    // 0x538028: mov             x5, x6
    // 0x53802c: r0 = GDT[cid_x0 + 0x85fa]()
    //     0x53802c: movz            x17, #0x85fa
    //     0x538030: add             lr, x0, x17
    //     0x538034: ldr             lr, [x21, lr, lsl #3]
    //     0x538038: blr             lr
    // 0x53803c: ldur            x2, [fp, #-8]
    // 0x538040: LoadField: r0 = r2->field_3b
    //     0x538040: ldur            w0, [x2, #0x3b]
    // 0x538044: DecompressPointer r0
    //     0x538044: add             x0, x0, HEAP, lsl #32
    // 0x538048: ldur            x16, [fp, #-0x18]
    // 0x53804c: stp             x0, x16, [SP, #8]
    // 0x538050: ldur            x16, [fp, #-0x58]
    // 0x538054: str             x16, [SP]
    // 0x538058: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x538058: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53805c: r0 = MapOperations.merge()
    //     0x53805c: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x538060: ldur            x2, [fp, #-8]
    // 0x538064: LoadField: r0 = r2->field_37
    //     0x538064: ldur            w0, [x2, #0x37]
    // 0x538068: DecompressPointer r0
    //     0x538068: add             x0, x0, HEAP, lsl #32
    // 0x53806c: ldur            x16, [fp, #-0x18]
    // 0x538070: stp             x0, x16, [SP, #8]
    // 0x538074: ldur            x16, [fp, #-0x60]
    // 0x538078: str             x16, [SP]
    // 0x53807c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53807c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538080: r0 = MapOperations.merge()
    //     0x538080: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x538084: ldur            x16, [fp, #-0x18]
    // 0x538088: ldur            lr, [fp, #-0x28]
    // 0x53808c: stp             lr, x16, [SP, #8]
    // 0x538090: ldur            x16, [fp, #-0x58]
    // 0x538094: str             x16, [SP]
    // 0x538098: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x538098: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53809c: r0 = MapOperations.merge()
    //     0x53809c: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x5380a0: ldur            x16, [fp, #-0x18]
    // 0x5380a4: ldur            lr, [fp, #-0x50]
    // 0x5380a8: stp             lr, x16, [SP, #8]
    // 0x5380ac: ldur            x16, [fp, #-0x60]
    // 0x5380b0: str             x16, [SP]
    // 0x5380b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5380b4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5380b8: r0 = MapOperations.merge()
    //     0x5380b8: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x5380bc: ldur            x0, [fp, #-0x28]
    // 0x5380c0: LoadField: r1 = r0->field_7
    //     0x5380c0: ldur            w1, [x0, #7]
    // 0x5380c4: DecompressPointer r1
    //     0x5380c4: add             x1, x1, HEAP, lsl #32
    // 0x5380c8: r0 = _CompactKeysIterable()
    //     0x5380c8: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x5380cc: mov             x3, x0
    // 0x5380d0: ldur            x0, [fp, #-0x28]
    // 0x5380d4: stur            x3, [fp, #-0x18]
    // 0x5380d8: StoreField: r3->field_b = r0
    //     0x5380d8: stur            w0, [x3, #0xb]
    // 0x5380dc: ldur            x2, [fp, #-8]
    // 0x5380e0: r1 = Function 'notifyStatGained':.
    //     0x5380e0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16e98] AnonymousClosure: (0x53c450), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained (0x53c48c)
    //     0x5380e4: ldr             x1, [x1, #0xe98]
    // 0x5380e8: r0 = AllocateClosure()
    //     0x5380e8: bl              #0x826750  ; AllocateClosureStub
    // 0x5380ec: ldur            x1, [fp, #-0x18]
    // 0x5380f0: mov             x2, x0
    // 0x5380f4: r0 = forEach()
    //     0x5380f4: bl              #0x4e2d6c  ; [dart:core] Iterable::forEach
    // 0x5380f8: ldur            x0, [fp, #-0x28]
    // 0x5380fc: ldur            x1, [fp, #-0x50]
    // 0x538100: LeaveFrame
    //     0x538100: mov             SP, fp
    //     0x538104: ldp             fp, lr, [SP], #0x10
    // 0x538108: ret
    //     0x538108: ret             
    // 0x53810c: r0 = StateError()
    //     0x53810c: bl              #0x329468  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x538110: mov             x1, x0
    // 0x538114: r0 = "Pattern matching error"
    //     0x538114: add             x0, PP, #0x16, lsl #12  ; [pp+0x16ea0] "Pattern matching error"
    //     0x538118: ldr             x0, [x0, #0xea0]
    // 0x53811c: StoreField: r1->field_b = r0
    //     0x53811c: stur            w0, [x1, #0xb]
    // 0x538120: mov             x0, x1
    // 0x538124: r0 = Throw()
    //     0x538124: bl              #0x825670  ; ThrowStub
    // 0x538128: brk             #0
    // 0x53812c: r0 = _Exception()
    //     0x53812c: bl              #0x32f5fc  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x538130: mov             x1, x0
    // 0x538134: r0 = "Infinite loop detected in slice computation!"
    //     0x538134: add             x0, PP, #0x16, lsl #12  ; [pp+0x16ea8] "Infinite loop detected in slice computation!"
    //     0x538138: ldr             x0, [x0, #0xea8]
    // 0x53813c: StoreField: r1->field_7 = r0
    //     0x53813c: stur            w0, [x1, #7]
    // 0x538140: mov             x0, x1
    // 0x538144: r0 = Throw()
    //     0x538144: bl              #0x825670  ; ThrowStub
    // 0x538148: brk             #0
    // 0x53814c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53814c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538150: b               #0x537b40
    // 0x538154: SaveReg d2
    //     0x538154: str             q2, [SP, #-0x10]!
    // 0x538158: SaveReg r1
    //     0x538158: str             x1, [SP, #-8]!
    // 0x53815c: d0 = 0.000000
    //     0x53815c: fmov            d0, d2
    // 0x538160: r0 = 70
    //     0x538160: movz            x0, #0x46
    // 0x538164: r30 = DoubleToIntegerStub
    //     0x538164: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x538168: LoadField: r30 = r30->field_7
    //     0x538168: ldur            lr, [lr, #7]
    // 0x53816c: blr             lr
    // 0x538170: RestoreReg r1
    //     0x538170: ldr             x1, [SP], #8
    // 0x538174: RestoreReg d2
    //     0x538174: ldr             q2, [SP], #0x10
    // 0x538178: b               #0x537c24
    // 0x53817c: r9 = paymentManager
    //     0x53817c: add             x9, PP, #0xf, lsl #12  ; [pp+0xf4c0] Field <::.paymentManager>: static late (offset: 0xfd0)
    //     0x538180: ldr             x9, [x9, #0x4c0]
    // 0x538184: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x538184: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x538188: r9 = overclockEndTime
    //     0x538188: add             x9, PP, #0x15, lsl #12  ; [pp+0x15218] Field <::.overclockEndTime>: static late (offset: 0xfd4)
    //     0x53818c: ldr             x9, [x9, #0x218]
    // 0x538190: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x538190: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x538194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x538194: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538198: b               #0x537de8
  }
  _ applyTimeSlice(/* No info */) {
    // ** addr: 0x538318, size: 0x828
    // 0x538318: EnterFrame
    //     0x538318: stp             fp, lr, [SP, #-0x10]!
    //     0x53831c: mov             fp, SP
    // 0x538320: AllocStack(0x70)
    //     0x538320: sub             SP, SP, #0x70
    // 0x538324: SetupParameters(IPlayableGameState<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x538324: mov             x0, x2
    //     0x538328: stur            x1, [fp, #-8]
    //     0x53832c: stur            x2, [fp, #-0x10]
    // 0x538330: CheckStackOverflow
    //     0x538330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x538334: cmp             SP, x16
    //     0x538338: b.ls            #0x538aec
    // 0x53833c: r1 = 1
    //     0x53833c: movz            x1, #0x1
    // 0x538340: r0 = AllocateContext()
    //     0x538340: bl              #0x82637c  ; AllocateContextStub
    // 0x538344: mov             x3, x0
    // 0x538348: ldur            x0, [fp, #-8]
    // 0x53834c: stur            x3, [fp, #-0x18]
    // 0x538350: StoreField: r3->field_f = r0
    //     0x538350: stur            w0, [x3, #0xf]
    // 0x538354: ldur            x4, [fp, #-0x10]
    // 0x538358: scvtf           d0, x4
    // 0x53835c: d1 = 1000.000000
    //     0x53835c: add             x17, PP, #0xe, lsl #12  ; [pp+0xefb8] IMM: double(1000) from 0x408f400000000000
    //     0x538360: ldr             d1, [x17, #0xfb8]
    // 0x538364: fdiv            d2, d0, d1
    // 0x538368: r2 = inline_Allocate_Double()
    //     0x538368: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x53836c: add             x2, x2, #0x10
    //     0x538370: cmp             x1, x2
    //     0x538374: b.ls            #0x538af4
    //     0x538378: str             x2, [THR, #0x60]  ; THR::top
    //     0x53837c: sub             x2, x2, #0xf
    //     0x538380: movz            x1, #0xe19c
    //     0x538384: movk            x1, #0x3, lsl #16
    //     0x538388: stur            x1, [x2, #-1]
    // 0x53838c: dmb             ishst
    // 0x538390: StoreField: r2->field_7 = d2
    //     0x538390: stur            d2, [x2, #7]
    // 0x538394: r1 = Null
    //     0x538394: mov             x1, NULL
    // 0x538398: r0 = CustomNum()
    //     0x538398: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x53839c: mov             x4, x0
    // 0x5383a0: ldur            x0, [fp, #-8]
    // 0x5383a4: stur            x4, [fp, #-0x28]
    // 0x5383a8: LoadField: r5 = r0->field_7
    //     0x5383a8: ldur            w5, [x0, #7]
    // 0x5383ac: DecompressPointer r5
    //     0x5383ac: add             x5, x5, HEAP, lsl #32
    // 0x5383b0: ldur            x2, [fp, #-0x18]
    // 0x5383b4: mov             x3, x5
    // 0x5383b8: stur            x5, [fp, #-0x20]
    // 0x5383bc: r1 = Function 'computeUnboostedIncomePerSecond':.
    //     0x5383bc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16ec0] AnonymousClosure: (0x53b0c0), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::applyTimeSlice (0x538318)
    //     0x5383c0: ldr             x1, [x1, #0xec0]
    // 0x5383c4: r0 = AllocateClosureTA()
    //     0x5383c4: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x5383c8: str             x0, [SP]
    // 0x5383cc: ClosureCall
    //     0x5383cc: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5383d0: ldur            x2, [x0, #0x1f]
    //     0x5383d4: blr             x2
    // 0x5383d8: mov             x3, x0
    // 0x5383dc: ldur            x2, [fp, #-8]
    // 0x5383e0: stur            x3, [fp, #-0x18]
    // 0x5383e4: r0 = LoadClassIdInstr(r2)
    //     0x5383e4: ldur            x0, [x2, #-1]
    //     0x5383e8: ubfx            x0, x0, #0xc, #0x14
    // 0x5383ec: mov             x1, x2
    // 0x5383f0: r0 = GDT[cid_x0 + 0x86a2]()
    //     0x5383f0: movz            x17, #0x86a2
    //     0x5383f4: add             lr, x0, x17
    //     0x5383f8: ldr             lr, [x21, lr, lsl #3]
    //     0x5383fc: blr             lr
    // 0x538400: stur            x0, [fp, #-0x30]
    // 0x538404: ldur            x16, [fp, #-0x20]
    // 0x538408: ldur            lr, [fp, #-0x18]
    // 0x53840c: stp             lr, x16, [SP, #8]
    // 0x538410: str             x0, [SP]
    // 0x538414: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x538414: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538418: r0 = MapOperations.multiplyNonMutating()
    //     0x538418: bl              #0x53addc  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyNonMutating
    // 0x53841c: mov             x2, x0
    // 0x538420: ldur            x1, [fp, #-8]
    // 0x538424: StoreField: r1->field_57 = r0
    //     0x538424: stur            w0, [x1, #0x57]
    //     0x538428: ldurb           w16, [x1, #-1]
    //     0x53842c: ldurb           w17, [x0, #-1]
    //     0x538430: and             x16, x17, x16, lsr #2
    //     0x538434: tst             x16, HEAP, lsr #32
    //     0x538438: b.eq            #0x538440
    //     0x53843c: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x538440: LoadField: r0 = r1->field_2b
    //     0x538440: ldur            w0, [x1, #0x2b]
    // 0x538444: DecompressPointer r0
    //     0x538444: add             x0, x0, HEAP, lsl #32
    // 0x538448: LoadField: r3 = r0->field_f
    //     0x538448: ldur            w3, [x0, #0xf]
    // 0x53844c: DecompressPointer r3
    //     0x53844c: add             x3, x3, HEAP, lsl #32
    // 0x538450: ldur            x16, [fp, #-0x20]
    // 0x538454: stp             x2, x16, [SP, #8]
    // 0x538458: str             x3, [SP]
    // 0x53845c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53845c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538460: r0 = MapOperations.multiplyScaler()
    //     0x538460: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x538464: ldur            x0, [fp, #-8]
    // 0x538468: LoadField: r4 = r0->field_2f
    //     0x538468: ldur            w4, [x0, #0x2f]
    // 0x53846c: DecompressPointer r4
    //     0x53846c: add             x4, x4, HEAP, lsl #32
    // 0x538470: stur            x4, [fp, #-0x38]
    // 0x538474: LoadField: r2 = r4->field_7
    //     0x538474: ldur            w2, [x4, #7]
    // 0x538478: DecompressPointer r2
    //     0x538478: add             x2, x2, HEAP, lsl #32
    // 0x53847c: r1 = Null
    //     0x53847c: mov             x1, NULL
    // 0x538480: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x538480: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x538484: r30 = InstantiateTypeArgumentsStub
    //     0x538484: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x538488: LoadField: r30 = r30->field_7
    //     0x538488: ldur            lr, [lr, #7]
    // 0x53848c: blr             lr
    // 0x538490: mov             x1, x0
    // 0x538494: r0 = _CompactEntriesIterable()
    //     0x538494: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x538498: mov             x1, x0
    // 0x53849c: ldur            x0, [fp, #-0x38]
    // 0x5384a0: StoreField: r1->field_b = r0
    //     0x5384a0: stur            w0, [x1, #0xb]
    // 0x5384a4: r0 = iterator()
    //     0x5384a4: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x5384a8: stur            x0, [fp, #-0x38]
    // 0x5384ac: ldur            x2, [fp, #-8]
    // 0x5384b0: CheckStackOverflow
    //     0x5384b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5384b4: cmp             SP, x16
    //     0x5384b8: b.ls            #0x538b18
    // 0x5384bc: mov             x1, x0
    // 0x5384c0: r0 = moveNext()
    //     0x5384c0: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x5384c4: tbnz            w0, #4, #0x538640
    // 0x5384c8: ldur            x0, [fp, #-0x38]
    // 0x5384cc: LoadField: r3 = r0->field_2b
    //     0x5384cc: ldur            w3, [x0, #0x2b]
    // 0x5384d0: DecompressPointer r3
    //     0x5384d0: add             x3, x3, HEAP, lsl #32
    // 0x5384d4: stur            x3, [fp, #-0x50]
    // 0x5384d8: cmp             w3, NULL
    // 0x5384dc: b.eq            #0x538ad4
    // 0x5384e0: ldur            x4, [fp, #-8]
    // 0x5384e4: LoadField: r1 = r4->field_57
    //     0x5384e4: ldur            w1, [x4, #0x57]
    // 0x5384e8: DecompressPointer r1
    //     0x5384e8: add             x1, x1, HEAP, lsl #32
    // 0x5384ec: LoadField: r5 = r3->field_b
    //     0x5384ec: ldur            w5, [x3, #0xb]
    // 0x5384f0: DecompressPointer r5
    //     0x5384f0: add             x5, x5, HEAP, lsl #32
    // 0x5384f4: stur            x5, [fp, #-0x48]
    // 0x5384f8: LoadField: r6 = r1->field_f
    //     0x5384f8: ldur            w6, [x1, #0xf]
    // 0x5384fc: DecompressPointer r6
    //     0x5384fc: add             x6, x6, HEAP, lsl #32
    // 0x538500: mov             x2, x5
    // 0x538504: stur            x6, [fp, #-0x40]
    // 0x538508: r0 = _getValueOrData()
    //     0x538508: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53850c: mov             x1, x0
    // 0x538510: ldur            x0, [fp, #-0x40]
    // 0x538514: cmp             w0, w1
    // 0x538518: b.eq            #0x538638
    // 0x53851c: ldur            x3, [fp, #-8]
    // 0x538520: ldur            x0, [fp, #-0x50]
    // 0x538524: LoadField: r4 = r3->field_57
    //     0x538524: ldur            w4, [x3, #0x57]
    // 0x538528: DecompressPointer r4
    //     0x538528: add             x4, x4, HEAP, lsl #32
    // 0x53852c: stur            x4, [fp, #-0x58]
    // 0x538530: LoadField: r1 = r0->field_f
    //     0x538530: ldur            w1, [x0, #0xf]
    // 0x538534: DecompressPointer r1
    //     0x538534: add             x1, x1, HEAP, lsl #32
    // 0x538538: cmp             w1, NULL
    // 0x53853c: b.eq            #0x538b20
    // 0x538540: LoadField: r0 = r1->field_f
    //     0x538540: ldur            w0, [x1, #0xf]
    // 0x538544: DecompressPointer r0
    //     0x538544: add             x0, x0, HEAP, lsl #32
    // 0x538548: mov             x1, x4
    // 0x53854c: ldur            x2, [fp, #-0x48]
    // 0x538550: stur            x0, [fp, #-0x40]
    // 0x538554: r0 = _getValueOrData()
    //     0x538554: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538558: mov             x1, x0
    // 0x53855c: ldur            x0, [fp, #-0x58]
    // 0x538560: LoadField: r2 = r0->field_f
    //     0x538560: ldur            w2, [x0, #0xf]
    // 0x538564: DecompressPointer r2
    //     0x538564: add             x2, x2, HEAP, lsl #32
    // 0x538568: cmp             w2, w1
    // 0x53856c: b.ne            #0x538578
    // 0x538570: r2 = Null
    //     0x538570: mov             x2, NULL
    // 0x538574: b               #0x53857c
    // 0x538578: mov             x2, x1
    // 0x53857c: ldur            x1, [fp, #-0x40]
    // 0x538580: cmp             w2, NULL
    // 0x538584: b.eq            #0x538b24
    // 0x538588: LoadField: d0 = r1->field_7
    //     0x538588: ldur            d0, [x1, #7]
    // 0x53858c: LoadField: d1 = r2->field_7
    //     0x53858c: ldur            d1, [x2, #7]
    // 0x538590: fadd            d2, d0, d1
    // 0x538594: mov             v0.16b, v2.16b
    // 0x538598: r1 = Null
    //     0x538598: mov             x1, NULL
    // 0x53859c: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53859c: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x5385a0: mov             x4, x0
    // 0x5385a4: ldur            x3, [fp, #-0x58]
    // 0x5385a8: stur            x4, [fp, #-0x50]
    // 0x5385ac: LoadField: r5 = r3->field_7
    //     0x5385ac: ldur            w5, [x3, #7]
    // 0x5385b0: DecompressPointer r5
    //     0x5385b0: add             x5, x5, HEAP, lsl #32
    // 0x5385b4: ldur            x0, [fp, #-0x48]
    // 0x5385b8: mov             x2, x5
    // 0x5385bc: stur            x5, [fp, #-0x40]
    // 0x5385c0: r1 = Null
    //     0x5385c0: mov             x1, NULL
    // 0x5385c4: cmp             w2, NULL
    // 0x5385c8: b.eq            #0x5385e8
    // 0x5385cc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x5385cc: ldur            w4, [x2, #0x17]
    // 0x5385d0: DecompressPointer r4
    //     0x5385d0: add             x4, x4, HEAP, lsl #32
    // 0x5385d4: r8 = X0
    //     0x5385d4: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x5385d8: LoadField: r9 = r4->field_7
    //     0x5385d8: ldur            x9, [x4, #7]
    // 0x5385dc: r3 = Null
    //     0x5385dc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16ec8] Null
    //     0x5385e0: ldr             x3, [x3, #0xec8]
    // 0x5385e4: blr             x9
    // 0x5385e8: ldur            x0, [fp, #-0x50]
    // 0x5385ec: ldur            x2, [fp, #-0x40]
    // 0x5385f0: r1 = Null
    //     0x5385f0: mov             x1, NULL
    // 0x5385f4: cmp             w2, NULL
    // 0x5385f8: b.eq            #0x538618
    // 0x5385fc: LoadField: r4 = r2->field_1b
    //     0x5385fc: ldur            w4, [x2, #0x1b]
    // 0x538600: DecompressPointer r4
    //     0x538600: add             x4, x4, HEAP, lsl #32
    // 0x538604: r8 = X1
    //     0x538604: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x538608: LoadField: r9 = r4->field_7
    //     0x538608: ldur            x9, [x4, #7]
    // 0x53860c: r3 = Null
    //     0x53860c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16ed8] Null
    //     0x538610: ldr             x3, [x3, #0xed8]
    // 0x538614: blr             x9
    // 0x538618: ldur            x1, [fp, #-0x58]
    // 0x53861c: ldur            x2, [fp, #-0x48]
    // 0x538620: r0 = _hashCode()
    //     0x538620: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x538624: ldur            x1, [fp, #-0x58]
    // 0x538628: ldur            x2, [fp, #-0x48]
    // 0x53862c: ldur            x3, [fp, #-0x50]
    // 0x538630: mov             x5, x0
    // 0x538634: r0 = _set()
    //     0x538634: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x538638: ldur            x0, [fp, #-0x38]
    // 0x53863c: b               #0x5384ac
    // 0x538640: ldur            x1, [fp, #-8]
    // 0x538644: LoadField: r0 = r1->field_57
    //     0x538644: ldur            w0, [x1, #0x57]
    // 0x538648: DecompressPointer r0
    //     0x538648: add             x0, x0, HEAP, lsl #32
    // 0x53864c: ldur            x16, [fp, #-0x20]
    // 0x538650: stp             x0, x16, [SP, #8]
    // 0x538654: ldur            x16, [fp, #-0x28]
    // 0x538658: str             x16, [SP]
    // 0x53865c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53865c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538660: r0 = MapOperations.multiplyScalerNonMutating()
    //     0x538660: bl              #0x53aa60  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScalerNonMutating
    // 0x538664: stur            x0, [fp, #-0x38]
    // 0x538668: ldur            x16, [fp, #-0x20]
    // 0x53866c: ldur            lr, [fp, #-0x18]
    // 0x538670: stp             lr, x16, [SP, #8]
    // 0x538674: ldur            x16, [fp, #-0x28]
    // 0x538678: str             x16, [SP]
    // 0x53867c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53867c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538680: r0 = MapOperations.multiplyScaler()
    //     0x538680: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x538684: ldur            x0, [fp, #-8]
    // 0x538688: LoadField: r2 = r0->field_4f
    //     0x538688: ldur            w2, [x0, #0x4f]
    // 0x53868c: DecompressPointer r2
    //     0x53868c: add             x2, x2, HEAP, lsl #32
    // 0x538690: stur            x2, [fp, #-0x28]
    // 0x538694: LoadField: r1 = r2->field_7
    //     0x538694: ldur            w1, [x2, #7]
    // 0x538698: DecompressPointer r1
    //     0x538698: add             x1, x1, HEAP, lsl #32
    // 0x53869c: r0 = _CompactKeysIterable()
    //     0x53869c: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x5386a0: mov             x1, x0
    // 0x5386a4: ldur            x0, [fp, #-0x28]
    // 0x5386a8: StoreField: r1->field_b = r0
    //     0x5386a8: stur            w0, [x1, #0xb]
    // 0x5386ac: r0 = iterator()
    //     0x5386ac: bl              #0x53647c  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0x5386b0: stur            x0, [fp, #-0x40]
    // 0x5386b4: LoadField: r2 = r0->field_7
    //     0x5386b4: ldur            w2, [x0, #7]
    // 0x5386b8: DecompressPointer r2
    //     0x5386b8: add             x2, x2, HEAP, lsl #32
    // 0x5386bc: stur            x2, [fp, #-0x28]
    // 0x5386c0: ldur            x3, [fp, #-8]
    // 0x5386c4: CheckStackOverflow
    //     0x5386c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5386c8: cmp             SP, x16
    //     0x5386cc: b.ls            #0x538b28
    // 0x5386d0: mov             x1, x0
    // 0x5386d4: r0 = moveNext()
    //     0x5386d4: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x5386d8: tbnz            w0, #4, #0x538790
    // 0x5386dc: ldur            x3, [fp, #-0x40]
    // 0x5386e0: LoadField: r4 = r3->field_33
    //     0x5386e0: ldur            w4, [x3, #0x33]
    // 0x5386e4: DecompressPointer r4
    //     0x5386e4: add             x4, x4, HEAP, lsl #32
    // 0x5386e8: stur            x4, [fp, #-0x48]
    // 0x5386ec: cmp             w4, NULL
    // 0x5386f0: b.ne            #0x538724
    // 0x5386f4: mov             x0, x4
    // 0x5386f8: ldur            x2, [fp, #-0x28]
    // 0x5386fc: r1 = Null
    //     0x5386fc: mov             x1, NULL
    // 0x538700: cmp             w2, NULL
    // 0x538704: b.eq            #0x538724
    // 0x538708: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x538708: ldur            w4, [x2, #0x17]
    // 0x53870c: DecompressPointer r4
    //     0x53870c: add             x4, x4, HEAP, lsl #32
    // 0x538710: r8 = X0
    //     0x538710: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x538714: LoadField: r9 = r4->field_7
    //     0x538714: ldur            x9, [x4, #7]
    // 0x538718: r3 = Null
    //     0x538718: add             x3, PP, #0x16, lsl #12  ; [pp+0x16ee8] Null
    //     0x53871c: ldr             x3, [x3, #0xee8]
    // 0x538720: blr             x9
    // 0x538724: ldur            x3, [fp, #-8]
    // 0x538728: r0 = LoadClassIdInstr(r3)
    //     0x538728: ldur            x0, [x3, #-1]
    //     0x53872c: ubfx            x0, x0, #0xc, #0x14
    // 0x538730: mov             x1, x3
    // 0x538734: ldur            x2, [fp, #-0x48]
    // 0x538738: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x538738: sub             lr, x0, #0xcb6
    //     0x53873c: ldr             lr, [x21, lr, lsl #3]
    //     0x538740: blr             lr
    // 0x538744: LoadField: r1 = r0->field_1f
    //     0x538744: ldur            w1, [x0, #0x1f]
    // 0x538748: DecompressPointer r1
    //     0x538748: add             x1, x1, HEAP, lsl #32
    // 0x53874c: cmp             w1, NULL
    // 0x538750: b.eq            #0x538784
    // 0x538754: ldur            x1, [fp, #-0x48]
    // 0x538758: r2 = LoadInt32Instr(r1)
    //     0x538758: sbfx            x2, x1, #1, #0x1f
    //     0x53875c: tbz             w1, #0, #0x538764
    //     0x538760: ldur            x2, [x1, #7]
    // 0x538764: ldur            x16, [fp, #-0x38]
    // 0x538768: str             x16, [SP]
    // 0x53876c: ldur            x1, [fp, #-8]
    // 0x538770: ldur            x3, [fp, #-0x10]
    // 0x538774: mov             x5, x0
    // 0x538778: ldur            x6, [fp, #-0x30]
    // 0x53877c: ldur            x7, [fp, #-0x18]
    // 0x538780: r0 = tryIncrementProgress()
    //     0x538780: bl              #0x538b40  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::tryIncrementProgress
    // 0x538784: ldur            x0, [fp, #-0x40]
    // 0x538788: ldur            x2, [fp, #-0x28]
    // 0x53878c: b               #0x5386c0
    // 0x538790: ldur            x2, [fp, #-8]
    // 0x538794: r0 = LoadClassIdInstr(r2)
    //     0x538794: ldur            x0, [x2, #-1]
    //     0x538798: ubfx            x0, x0, #0xc, #0x14
    // 0x53879c: mov             x1, x2
    // 0x5387a0: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x5387a0: sub             lr, x0, #0xf3f
    //     0x5387a4: ldr             lr, [x21, lr, lsl #3]
    //     0x5387a8: blr             lr
    // 0x5387ac: r1 = LoadClassIdInstr(r0)
    //     0x5387ac: ldur            x1, [x0, #-1]
    //     0x5387b0: ubfx            x1, x1, #0xc, #0x14
    // 0x5387b4: r16 = "2"
    //     0x5387b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2e0] "2"
    //     0x5387b8: ldr             x16, [x16, #0x2e0]
    // 0x5387bc: stp             x16, x0, [SP]
    // 0x5387c0: mov             x0, x1
    // 0x5387c4: mov             lr, x0
    // 0x5387c8: ldr             lr, [x21, lr, lsl #3]
    // 0x5387cc: blr             lr
    // 0x5387d0: tbz             w0, #4, #0x538a78
    // 0x5387d4: ldur            x2, [fp, #-8]
    // 0x5387d8: r0 = LoadClassIdInstr(r2)
    //     0x5387d8: ldur            x0, [x2, #-1]
    //     0x5387dc: ubfx            x0, x0, #0xc, #0x14
    // 0x5387e0: mov             x1, x2
    // 0x5387e4: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x5387e4: sub             lr, x0, #0xf3f
    //     0x5387e8: ldr             lr, [x21, lr, lsl #3]
    //     0x5387ec: blr             lr
    // 0x5387f0: r1 = LoadClassIdInstr(r0)
    //     0x5387f0: ldur            x1, [x0, #-1]
    //     0x5387f4: ubfx            x1, x1, #0xc, #0x14
    // 0x5387f8: r16 = "3"
    //     0x5387f8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf2f0] "3"
    //     0x5387fc: ldr             x16, [x16, #0x2f0]
    // 0x538800: stp             x16, x0, [SP]
    // 0x538804: mov             x0, x1
    // 0x538808: mov             lr, x0
    // 0x53880c: ldr             lr, [x21, lr, lsl #3]
    // 0x538810: blr             lr
    // 0x538814: tbz             w0, #4, #0x538a78
    // 0x538818: ldur            x0, [fp, #-8]
    // 0x53881c: LoadField: r2 = r0->field_47
    //     0x53881c: ldur            w2, [x0, #0x47]
    // 0x538820: DecompressPointer r2
    //     0x538820: add             x2, x2, HEAP, lsl #32
    // 0x538824: stur            x2, [fp, #-0x28]
    // 0x538828: LoadField: r1 = r2->field_7
    //     0x538828: ldur            w1, [x2, #7]
    // 0x53882c: DecompressPointer r1
    //     0x53882c: add             x1, x1, HEAP, lsl #32
    // 0x538830: r0 = _CompactKeysIterable()
    //     0x538830: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x538834: mov             x1, x0
    // 0x538838: ldur            x0, [fp, #-0x28]
    // 0x53883c: StoreField: r1->field_b = r0
    //     0x53883c: stur            w0, [x1, #0xb]
    // 0x538840: r0 = toSet()
    //     0x538840: bl              #0x3de23c  ; [dart:core] _GrowableList::toSet
    // 0x538844: mov             x3, x0
    // 0x538848: ldur            x2, [fp, #-8]
    // 0x53884c: stur            x3, [fp, #-0x28]
    // 0x538850: r0 = LoadClassIdInstr(r2)
    //     0x538850: ldur            x0, [x2, #-1]
    //     0x538854: ubfx            x0, x0, #0xc, #0x14
    // 0x538858: mov             x1, x2
    // 0x53885c: r0 = GDT[cid_x0 + 0x8702]()
    //     0x53885c: movz            x17, #0x8702
    //     0x538860: add             lr, x0, x17
    //     0x538864: ldr             lr, [x21, lr, lsl #3]
    //     0x538868: blr             lr
    // 0x53886c: stur            x0, [fp, #-0x40]
    // 0x538870: LoadField: r2 = r0->field_7
    //     0x538870: ldur            w2, [x0, #7]
    // 0x538874: DecompressPointer r2
    //     0x538874: add             x2, x2, HEAP, lsl #32
    // 0x538878: r1 = Null
    //     0x538878: mov             x1, NULL
    // 0x53887c: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53887c: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x538880: r30 = InstantiateTypeArgumentsStub
    //     0x538880: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x538884: LoadField: r30 = r30->field_7
    //     0x538884: ldur            lr, [lr, #7]
    // 0x538888: blr             lr
    // 0x53888c: mov             x1, x0
    // 0x538890: r0 = _CompactEntriesIterable()
    //     0x538890: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x538894: mov             x1, x0
    // 0x538898: ldur            x0, [fp, #-0x40]
    // 0x53889c: StoreField: r1->field_b = r0
    //     0x53889c: stur            w0, [x1, #0xb]
    // 0x5388a0: r0 = iterator()
    //     0x5388a0: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x5388a4: mov             x2, x0
    // 0x5388a8: ldur            x0, [fp, #-0x28]
    // 0x5388ac: stur            x2, [fp, #-0x48]
    // 0x5388b0: LoadField: r3 = r0->field_7
    //     0x5388b0: ldur            w3, [x0, #7]
    // 0x5388b4: DecompressPointer r3
    //     0x5388b4: add             x3, x3, HEAP, lsl #32
    // 0x5388b8: stur            x3, [fp, #-0x40]
    // 0x5388bc: ldur            x4, [fp, #-8]
    // 0x5388c0: CheckStackOverflow
    //     0x5388c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5388c4: cmp             SP, x16
    //     0x5388c8: b.ls            #0x538b30
    // 0x5388cc: mov             x1, x2
    // 0x5388d0: r0 = moveNext()
    //     0x5388d0: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x5388d4: tbnz            w0, #4, #0x538990
    // 0x5388d8: ldur            x0, [fp, #-0x48]
    // 0x5388dc: LoadField: r3 = r0->field_2b
    //     0x5388dc: ldur            w3, [x0, #0x2b]
    // 0x5388e0: DecompressPointer r3
    //     0x5388e0: add             x3, x3, HEAP, lsl #32
    // 0x5388e4: stur            x3, [fp, #-0x58]
    // 0x5388e8: cmp             w3, NULL
    // 0x5388ec: b.eq            #0x538ae0
    // 0x5388f0: ldur            x4, [fp, #-8]
    // 0x5388f4: LoadField: r1 = r4->field_37
    //     0x5388f4: ldur            w1, [x4, #0x37]
    // 0x5388f8: DecompressPointer r1
    //     0x5388f8: add             x1, x1, HEAP, lsl #32
    // 0x5388fc: LoadField: r2 = r3->field_f
    //     0x5388fc: ldur            w2, [x3, #0xf]
    // 0x538900: DecompressPointer r2
    //     0x538900: add             x2, x2, HEAP, lsl #32
    // 0x538904: LoadField: r5 = r1->field_f
    //     0x538904: ldur            w5, [x1, #0xf]
    // 0x538908: DecompressPointer r5
    //     0x538908: add             x5, x5, HEAP, lsl #32
    // 0x53890c: stur            x5, [fp, #-0x50]
    // 0x538910: r0 = _getValueOrData()
    //     0x538910: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538914: mov             x1, x0
    // 0x538918: ldur            x0, [fp, #-0x50]
    // 0x53891c: cmp             w0, w1
    // 0x538920: b.eq            #0x538980
    // 0x538924: ldur            x0, [fp, #-0x58]
    // 0x538928: LoadField: r3 = r0->field_b
    //     0x538928: ldur            w3, [x0, #0xb]
    // 0x53892c: DecompressPointer r3
    //     0x53892c: add             x3, x3, HEAP, lsl #32
    // 0x538930: mov             x0, x3
    // 0x538934: ldur            x2, [fp, #-0x40]
    // 0x538938: stur            x3, [fp, #-0x50]
    // 0x53893c: r1 = Null
    //     0x53893c: mov             x1, NULL
    // 0x538940: cmp             w2, NULL
    // 0x538944: b.eq            #0x538964
    // 0x538948: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x538948: ldur            w4, [x2, #0x17]
    // 0x53894c: DecompressPointer r4
    //     0x53894c: add             x4, x4, HEAP, lsl #32
    // 0x538950: r8 = X0
    //     0x538950: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x538954: LoadField: r9 = r4->field_7
    //     0x538954: ldur            x9, [x4, #7]
    // 0x538958: r3 = Null
    //     0x538958: add             x3, PP, #0x16, lsl #12  ; [pp+0x16ef8] Null
    //     0x53895c: ldr             x3, [x3, #0xef8]
    // 0x538960: blr             x9
    // 0x538964: ldur            x1, [fp, #-0x28]
    // 0x538968: ldur            x2, [fp, #-0x50]
    // 0x53896c: r0 = _hashCode()
    //     0x53896c: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x538970: ldur            x1, [fp, #-0x28]
    // 0x538974: ldur            x2, [fp, #-0x50]
    // 0x538978: mov             x3, x0
    // 0x53897c: r0 = _add()
    //     0x53897c: bl              #0x396d5c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x538980: ldur            x0, [fp, #-0x28]
    // 0x538984: ldur            x2, [fp, #-0x48]
    // 0x538988: ldur            x3, [fp, #-0x40]
    // 0x53898c: b               #0x5388bc
    // 0x538990: ldur            x1, [fp, #-0x28]
    // 0x538994: r0 = iterator()
    //     0x538994: bl              #0x6530c0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x538998: stur            x0, [fp, #-0x40]
    // 0x53899c: LoadField: r2 = r0->field_7
    //     0x53899c: ldur            w2, [x0, #7]
    // 0x5389a0: DecompressPointer r2
    //     0x5389a0: add             x2, x2, HEAP, lsl #32
    // 0x5389a4: stur            x2, [fp, #-0x28]
    // 0x5389a8: ldur            x3, [fp, #-8]
    // 0x5389ac: CheckStackOverflow
    //     0x5389ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5389b0: cmp             SP, x16
    //     0x5389b4: b.ls            #0x538b38
    // 0x5389b8: mov             x1, x0
    // 0x5389bc: r0 = moveNext()
    //     0x5389bc: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x5389c0: tbnz            w0, #4, #0x538a78
    // 0x5389c4: ldur            x3, [fp, #-0x40]
    // 0x5389c8: LoadField: r4 = r3->field_33
    //     0x5389c8: ldur            w4, [x3, #0x33]
    // 0x5389cc: DecompressPointer r4
    //     0x5389cc: add             x4, x4, HEAP, lsl #32
    // 0x5389d0: stur            x4, [fp, #-0x48]
    // 0x5389d4: cmp             w4, NULL
    // 0x5389d8: b.ne            #0x538a0c
    // 0x5389dc: mov             x0, x4
    // 0x5389e0: ldur            x2, [fp, #-0x28]
    // 0x5389e4: r1 = Null
    //     0x5389e4: mov             x1, NULL
    // 0x5389e8: cmp             w2, NULL
    // 0x5389ec: b.eq            #0x538a0c
    // 0x5389f0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x5389f0: ldur            w4, [x2, #0x17]
    // 0x5389f4: DecompressPointer r4
    //     0x5389f4: add             x4, x4, HEAP, lsl #32
    // 0x5389f8: r8 = X0
    //     0x5389f8: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x5389fc: LoadField: r9 = r4->field_7
    //     0x5389fc: ldur            x9, [x4, #7]
    // 0x538a00: r3 = Null
    //     0x538a00: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f08] Null
    //     0x538a04: ldr             x3, [x3, #0xf08]
    // 0x538a08: blr             x9
    // 0x538a0c: ldur            x3, [fp, #-8]
    // 0x538a10: r0 = LoadClassIdInstr(r3)
    //     0x538a10: ldur            x0, [x3, #-1]
    //     0x538a14: ubfx            x0, x0, #0xc, #0x14
    // 0x538a18: mov             x1, x3
    // 0x538a1c: ldur            x2, [fp, #-0x48]
    // 0x538a20: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x538a20: sub             lr, x0, #0xcb6
    //     0x538a24: ldr             lr, [x21, lr, lsl #3]
    //     0x538a28: blr             lr
    // 0x538a2c: LoadField: r1 = r0->field_1f
    //     0x538a2c: ldur            w1, [x0, #0x1f]
    // 0x538a30: DecompressPointer r1
    //     0x538a30: add             x1, x1, HEAP, lsl #32
    // 0x538a34: cmp             w1, NULL
    // 0x538a38: b.eq            #0x538a6c
    // 0x538a3c: ldur            x1, [fp, #-0x48]
    // 0x538a40: r2 = LoadInt32Instr(r1)
    //     0x538a40: sbfx            x2, x1, #1, #0x1f
    //     0x538a44: tbz             w1, #0, #0x538a4c
    //     0x538a48: ldur            x2, [x1, #7]
    // 0x538a4c: ldur            x16, [fp, #-0x38]
    // 0x538a50: str             x16, [SP]
    // 0x538a54: ldur            x1, [fp, #-8]
    // 0x538a58: ldur            x3, [fp, #-0x10]
    // 0x538a5c: mov             x5, x0
    // 0x538a60: ldur            x6, [fp, #-0x30]
    // 0x538a64: ldur            x7, [fp, #-0x18]
    // 0x538a68: r0 = tryIncrementProgress()
    //     0x538a68: bl              #0x538b40  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::tryIncrementProgress
    // 0x538a6c: ldur            x0, [fp, #-0x40]
    // 0x538a70: ldur            x2, [fp, #-0x28]
    // 0x538a74: b               #0x5389a8
    // 0x538a78: ldur            x0, [fp, #-8]
    // 0x538a7c: LoadField: r1 = r0->field_3b
    //     0x538a7c: ldur            w1, [x0, #0x3b]
    // 0x538a80: DecompressPointer r1
    //     0x538a80: add             x1, x1, HEAP, lsl #32
    // 0x538a84: ldur            x16, [fp, #-0x20]
    // 0x538a88: stp             x1, x16, [SP, #8]
    // 0x538a8c: ldur            x16, [fp, #-0x18]
    // 0x538a90: str             x16, [SP]
    // 0x538a94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x538a94: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538a98: r0 = MapOperations.merge()
    //     0x538a98: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x538a9c: ldur            x0, [fp, #-8]
    // 0x538aa0: LoadField: r1 = r0->field_37
    //     0x538aa0: ldur            w1, [x0, #0x37]
    // 0x538aa4: DecompressPointer r1
    //     0x538aa4: add             x1, x1, HEAP, lsl #32
    // 0x538aa8: ldur            x16, [fp, #-0x20]
    // 0x538aac: stp             x1, x16, [SP, #8]
    // 0x538ab0: ldur            x16, [fp, #-0x38]
    // 0x538ab4: str             x16, [SP]
    // 0x538ab8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x538ab8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538abc: r0 = MapOperations.merge()
    //     0x538abc: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x538ac0: ldur            x0, [fp, #-0x18]
    // 0x538ac4: ldur            x1, [fp, #-0x38]
    // 0x538ac8: LeaveFrame
    //     0x538ac8: mov             SP, fp
    //     0x538acc: ldp             fp, lr, [SP], #0x10
    // 0x538ad0: ret
    //     0x538ad0: ret             
    // 0x538ad4: r0 = noElement()
    //     0x538ad4: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x538ad8: r0 = Throw()
    //     0x538ad8: bl              #0x825670  ; ThrowStub
    // 0x538adc: brk             #0
    // 0x538ae0: r0 = noElement()
    //     0x538ae0: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x538ae4: r0 = Throw()
    //     0x538ae4: bl              #0x825670  ; ThrowStub
    // 0x538ae8: brk             #0
    // 0x538aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x538aec: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538af0: b               #0x53833c
    // 0x538af4: SaveReg d2
    //     0x538af4: str             q2, [SP, #-0x10]!
    // 0x538af8: stp             x3, x4, [SP, #-0x10]!
    // 0x538afc: SaveReg r0
    //     0x538afc: str             x0, [SP, #-8]!
    // 0x538b00: r0 = AllocateDouble()
    //     0x538b00: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x538b04: mov             x2, x0
    // 0x538b08: RestoreReg r0
    //     0x538b08: ldr             x0, [SP], #8
    // 0x538b0c: ldp             x3, x4, [SP], #0x10
    // 0x538b10: RestoreReg d2
    //     0x538b10: ldr             q2, [SP], #0x10
    // 0x538b14: b               #0x538390
    // 0x538b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x538b18: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538b1c: b               #0x5384bc
    // 0x538b20: r0 = NullErrorSharedWithoutFPURegs()
    //     0x538b20: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x538b24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x538b24: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x538b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x538b28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538b2c: b               #0x5386d0
    // 0x538b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x538b30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538b34: b               #0x5388cc
    // 0x538b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x538b38: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x538b3c: b               #0x5389b8
  }
  _ tryIncrementProgress(/* No info */) {
    // ** addr: 0x538b40, size: 0xec0
    // 0x538b40: EnterFrame
    //     0x538b40: stp             fp, lr, [SP, #-0x10]!
    //     0x538b44: mov             fp, SP
    // 0x538b48: AllocStack(0x98)
    //     0x538b48: sub             SP, SP, #0x98
    // 0x538b4c: SetupParameters(IPlayableGameState<X0> this /* r1 => r8, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x18 */, dynamic _ /* r3 => r4, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */, dynamic _ /* r6 => r6, fp-0x30 */, dynamic _ /* r7 => r7, fp-0x38 */)
    //     0x538b4c: mov             x8, x1
    //     0x538b50: mov             x4, x3
    //     0x538b54: stur            x3, [fp, #-0x20]
    //     0x538b58: mov             x3, x5
    //     0x538b5c: stur            x5, [fp, #-0x28]
    //     0x538b60: mov             x5, x2
    //     0x538b64: stur            x1, [fp, #-0x10]
    //     0x538b68: stur            x2, [fp, #-0x18]
    //     0x538b6c: stur            x6, [fp, #-0x30]
    //     0x538b70: stur            x7, [fp, #-0x38]
    // 0x538b74: CheckStackOverflow
    //     0x538b74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x538b78: cmp             SP, x16
    //     0x538b7c: b.ls            #0x539938
    // 0x538b80: LoadField: r2 = r8->field_53
    //     0x538b80: ldur            w2, [x8, #0x53]
    // 0x538b84: DecompressPointer r2
    //     0x538b84: add             x2, x2, HEAP, lsl #32
    // 0x538b88: r0 = BoxInt64Instr(r5)
    //     0x538b88: sbfiz           x0, x5, #1, #0x1f
    //     0x538b8c: cmp             x5, x0, asr #1
    //     0x538b90: b.eq            #0x538b9c
    //     0x538b94: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x538b98: stur            x5, [x0, #7]
    // 0x538b9c: mov             x1, x2
    // 0x538ba0: mov             x2, x0
    // 0x538ba4: stur            x0, [fp, #-8]
    // 0x538ba8: r0 = contains()
    //     0x538ba8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x538bac: tbnz            w0, #4, #0x538bb8
    // 0x538bb0: r3 = true
    //     0x538bb0: add             x3, NULL, #0x20  ; true
    // 0x538bb4: b               #0x538be4
    // 0x538bb8: ldur            x3, [fp, #-0x10]
    // 0x538bbc: r0 = LoadClassIdInstr(r3)
    //     0x538bbc: ldur            x0, [x3, #-1]
    //     0x538bc0: ubfx            x0, x0, #0xc, #0x14
    // 0x538bc4: mov             x1, x3
    // 0x538bc8: ldur            x2, [fp, #-8]
    // 0x538bcc: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x538bcc: sub             lr, x0, #0xcb6
    //     0x538bd0: ldr             lr, [x21, lr, lsl #3]
    //     0x538bd4: blr             lr
    // 0x538bd8: LoadField: r1 = r0->field_13
    //     0x538bd8: ldur            w1, [x0, #0x13]
    // 0x538bdc: DecompressPointer r1
    //     0x538bdc: add             x1, x1, HEAP, lsl #32
    // 0x538be0: mov             x3, x1
    // 0x538be4: ldur            x0, [fp, #-0x10]
    // 0x538be8: stur            x3, [fp, #-0x48]
    // 0x538bec: LoadField: r4 = r0->field_33
    //     0x538bec: ldur            w4, [x0, #0x33]
    // 0x538bf0: DecompressPointer r4
    //     0x538bf0: add             x4, x4, HEAP, lsl #32
    // 0x538bf4: mov             x1, x4
    // 0x538bf8: ldur            x2, [fp, #-8]
    // 0x538bfc: stur            x4, [fp, #-0x40]
    // 0x538c00: r0 = _getValueOrData()
    //     0x538c00: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538c04: ldur            x5, [fp, #-0x40]
    // 0x538c08: LoadField: r1 = r5->field_f
    //     0x538c08: ldur            w1, [x5, #0xf]
    // 0x538c0c: DecompressPointer r1
    //     0x538c0c: add             x1, x1, HEAP, lsl #32
    // 0x538c10: cmp             w1, w0
    // 0x538c14: b.ne            #0x538c1c
    // 0x538c18: r0 = Null
    //     0x538c18: mov             x0, NULL
    // 0x538c1c: cmp             w0, NULL
    // 0x538c20: b.ne            #0x538c2c
    // 0x538c24: r0 = Null
    //     0x538c24: mov             x0, NULL
    // 0x538c28: b               #0x538c38
    // 0x538c2c: LoadField: r1 = r0->field_f
    //     0x538c2c: ldur            w1, [x0, #0xf]
    // 0x538c30: DecompressPointer r1
    //     0x538c30: add             x1, x1, HEAP, lsl #32
    // 0x538c34: mov             x0, x1
    // 0x538c38: cmp             w0, NULL
    // 0x538c3c: b.ne            #0x538c4c
    // 0x538c40: r3 = Instance_CustomNum
    //     0x538c40: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x538c44: ldr             x3, [x3, #0xa70]
    // 0x538c48: b               #0x538c50
    // 0x538c4c: mov             x3, x0
    // 0x538c50: ldur            x0, [fp, #-0x10]
    // 0x538c54: mov             x1, x0
    // 0x538c58: ldur            x2, [fp, #-0x18]
    // 0x538c5c: stur            x3, [fp, #-0x50]
    // 0x538c60: r0 = getCostToStart()
    //     0x538c60: bl              #0x53a78c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getCostToStart
    // 0x538c64: mov             x3, x0
    // 0x538c68: ldur            x0, [fp, #-0x10]
    // 0x538c6c: stur            x3, [fp, #-0x58]
    // 0x538c70: LoadField: r1 = r0->field_4b
    //     0x538c70: ldur            w1, [x0, #0x4b]
    // 0x538c74: DecompressPointer r1
    //     0x538c74: add             x1, x1, HEAP, lsl #32
    // 0x538c78: ldur            x2, [fp, #-8]
    // 0x538c7c: r0 = containsKey()
    //     0x538c7c: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x538c80: tbz             w0, #4, #0x538dec
    // 0x538c84: ldur            x0, [fp, #-0x48]
    // 0x538c88: tbz             w0, #4, #0x538c9c
    // 0x538c8c: r0 = Null
    //     0x538c8c: mov             x0, NULL
    // 0x538c90: LeaveFrame
    //     0x538c90: mov             SP, fp
    //     0x538c94: ldp             fp, lr, [SP], #0x10
    // 0x538c98: ret
    //     0x538c98: ret             
    // 0x538c9c: ldur            x3, [fp, #-0x58]
    // 0x538ca0: cmp             w3, NULL
    // 0x538ca4: b.eq            #0x538dec
    // 0x538ca8: ldur            x4, [fp, #-0x20]
    // 0x538cac: r17 = 30000
    //     0x538cac: movz            x17, #0x7530
    // 0x538cb0: cmp             x4, x17
    // 0x538cb4: b.ge            #0x538d00
    // 0x538cb8: ldur            x5, [fp, #-0x10]
    // 0x538cbc: LoadField: r6 = r5->field_77
    //     0x538cbc: ldur            w6, [x5, #0x77]
    // 0x538cc0: DecompressPointer r6
    //     0x538cc0: add             x6, x6, HEAP, lsl #32
    // 0x538cc4: mov             x1, x6
    // 0x538cc8: ldur            x2, [fp, #-8]
    // 0x538ccc: stur            x6, [fp, #-0x60]
    // 0x538cd0: r0 = _getValueOrData()
    //     0x538cd0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538cd4: mov             x1, x0
    // 0x538cd8: ldur            x0, [fp, #-0x60]
    // 0x538cdc: LoadField: r2 = r0->field_f
    //     0x538cdc: ldur            w2, [x0, #0xf]
    // 0x538ce0: DecompressPointer r2
    //     0x538ce0: add             x2, x2, HEAP, lsl #32
    // 0x538ce4: cmp             w2, w1
    // 0x538ce8: b.ne            #0x538cf4
    // 0x538cec: r0 = Null
    //     0x538cec: mov             x0, NULL
    // 0x538cf0: b               #0x538cf8
    // 0x538cf4: mov             x0, x1
    // 0x538cf8: mov             x1, x0
    // 0x538cfc: b               #0x538d04
    // 0x538d00: r1 = Null
    //     0x538d00: mov             x1, NULL
    // 0x538d04: stur            x1, [fp, #-0x60]
    // 0x538d08: cmp             w1, NULL
    // 0x538d0c: b.eq            #0x538d58
    // 0x538d10: r0 = DateTime()
    //     0x538d10: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x538d14: mov             x1, x0
    // 0x538d18: r0 = false
    //     0x538d18: add             x0, NULL, #0x30  ; false
    // 0x538d1c: stur            x1, [fp, #-0x68]
    // 0x538d20: StoreField: r1->field_7 = r0
    //     0x538d20: stur            w0, [x1, #7]
    // 0x538d24: r0 = _getCurrentMicros()
    //     0x538d24: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x538d28: r1 = LoadInt32Instr(r0)
    //     0x538d28: sbfx            x1, x0, #1, #0x1f
    //     0x538d2c: tbz             w0, #0, #0x538d34
    //     0x538d30: ldur            x1, [x0, #7]
    // 0x538d34: ldur            x2, [fp, #-0x68]
    // 0x538d38: StoreField: r2->field_b = r1
    //     0x538d38: stur            x1, [x2, #0xb]
    // 0x538d3c: ldur            x1, [fp, #-0x60]
    // 0x538d40: r0 = isAfter()
    //     0x538d40: bl              #0x451928  ; [dart:core] DateTime::isAfter
    // 0x538d44: tbnz            w0, #4, #0x538d58
    // 0x538d48: r0 = Null
    //     0x538d48: mov             x0, NULL
    // 0x538d4c: LeaveFrame
    //     0x538d4c: mov             SP, fp
    //     0x538d50: ldp             fp, lr, [SP], #0x10
    // 0x538d54: ret
    //     0x538d54: ret             
    // 0x538d58: ldur            x1, [fp, #-0x10]
    // 0x538d5c: LoadField: r0 = r1->field_7
    //     0x538d5c: ldur            w0, [x1, #7]
    // 0x538d60: DecompressPointer r0
    //     0x538d60: add             x0, x0, HEAP, lsl #32
    // 0x538d64: LoadField: r2 = r1->field_37
    //     0x538d64: ldur            w2, [x1, #0x37]
    // 0x538d68: DecompressPointer r2
    //     0x538d68: add             x2, x2, HEAP, lsl #32
    // 0x538d6c: stp             x2, x0, [SP, #8]
    // 0x538d70: ldur            x16, [fp, #-0x58]
    // 0x538d74: str             x16, [SP]
    // 0x538d78: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x538d78: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x538d7c: r0 = MapOperations.trySubtractTupleIgnoreFloatingPointError()
    //     0x538d7c: bl              #0x53a65c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.trySubtractTupleIgnoreFloatingPointError
    // 0x538d80: tbz             w0, #4, #0x538d94
    // 0x538d84: r0 = Null
    //     0x538d84: mov             x0, NULL
    // 0x538d88: LeaveFrame
    //     0x538d88: mov             SP, fp
    //     0x538d8c: ldp             fp, lr, [SP], #0x10
    // 0x538d90: ret
    //     0x538d90: ret             
    // 0x538d94: ldur            x1, [fp, #-0x10]
    // 0x538d98: LoadField: r0 = r1->field_77
    //     0x538d98: ldur            w0, [x1, #0x77]
    // 0x538d9c: DecompressPointer r0
    //     0x538d9c: add             x0, x0, HEAP, lsl #32
    // 0x538da0: stur            x0, [fp, #-0x60]
    // 0x538da4: r0 = DateTime()
    //     0x538da4: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x538da8: mov             x1, x0
    // 0x538dac: r0 = false
    //     0x538dac: add             x0, NULL, #0x30  ; false
    // 0x538db0: stur            x1, [fp, #-0x68]
    // 0x538db4: StoreField: r1->field_7 = r0
    //     0x538db4: stur            w0, [x1, #7]
    // 0x538db8: r0 = _getCurrentMicros()
    //     0x538db8: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x538dbc: r1 = LoadInt32Instr(r0)
    //     0x538dbc: sbfx            x1, x0, #1, #0x1f
    //     0x538dc0: tbz             w0, #0, #0x538dc8
    //     0x538dc4: ldur            x1, [x0, #7]
    // 0x538dc8: ldur            x0, [fp, #-0x68]
    // 0x538dcc: StoreField: r0->field_b = r1
    //     0x538dcc: stur            x1, [x0, #0xb]
    // 0x538dd0: mov             x1, x0
    // 0x538dd4: r2 = Instance_Duration
    //     0x538dd4: ldr             x2, [PP, #0x2ce0]  ; [pp+0x2ce0] Obj!Duration@866101
    // 0x538dd8: r0 = add()
    //     0x538dd8: bl              #0x360130  ; [dart:core] DateTime::add
    // 0x538ddc: ldur            x1, [fp, #-0x60]
    // 0x538de0: ldur            x2, [fp, #-8]
    // 0x538de4: mov             x3, x0
    // 0x538de8: r0 = []=()
    //     0x538de8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x538dec: ldur            x0, [fp, #-0x48]
    // 0x538df0: tbz             w0, #4, #0x538e1c
    // 0x538df4: ldur            x3, [fp, #-0x10]
    // 0x538df8: LoadField: r1 = r3->field_4b
    //     0x538df8: ldur            w1, [x3, #0x4b]
    // 0x538dfc: DecompressPointer r1
    //     0x538dfc: add             x1, x1, HEAP, lsl #32
    // 0x538e00: ldur            x2, [fp, #-8]
    // 0x538e04: r0 = containsKey()
    //     0x538e04: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x538e08: tbz             w0, #4, #0x538e1c
    // 0x538e0c: r0 = Null
    //     0x538e0c: mov             x0, NULL
    // 0x538e10: LeaveFrame
    //     0x538e10: mov             SP, fp
    //     0x538e14: ldp             fp, lr, [SP], #0x10
    // 0x538e18: ret
    //     0x538e18: ret             
    // 0x538e1c: ldur            x0, [fp, #-0x10]
    // 0x538e20: LoadField: r3 = r0->field_4b
    //     0x538e20: ldur            w3, [x0, #0x4b]
    // 0x538e24: DecompressPointer r3
    //     0x538e24: add             x3, x3, HEAP, lsl #32
    // 0x538e28: mov             x1, x3
    // 0x538e2c: ldur            x2, [fp, #-8]
    // 0x538e30: stur            x3, [fp, #-0x60]
    // 0x538e34: r0 = _getValueOrData()
    //     0x538e34: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538e38: ldur            x3, [fp, #-0x60]
    // 0x538e3c: LoadField: r1 = r3->field_f
    //     0x538e3c: ldur            w1, [x3, #0xf]
    // 0x538e40: DecompressPointer r1
    //     0x538e40: add             x1, x1, HEAP, lsl #32
    // 0x538e44: cmp             w1, w0
    // 0x538e48: b.ne            #0x538e50
    // 0x538e4c: r0 = Null
    //     0x538e4c: mov             x0, NULL
    // 0x538e50: cmp             w0, NULL
    // 0x538e54: b.ne            #0x538e60
    // 0x538e58: d0 = 0.000000
    //     0x538e58: eor             v0.16b, v0.16b, v0.16b
    // 0x538e5c: b               #0x538e64
    // 0x538e60: LoadField: d0 = r0->field_7
    //     0x538e60: ldur            d0, [x0, #7]
    // 0x538e64: ldur            x4, [fp, #-0x10]
    // 0x538e68: ldur            x2, [fp, #-0x20]
    // 0x538e6c: stur            d0, [fp, #-0x70]
    // 0x538e70: r0 = BoxInt64Instr(r2)
    //     0x538e70: sbfiz           x0, x2, #1, #0x1f
    //     0x538e74: cmp             x2, x0, asr #1
    //     0x538e78: b.eq            #0x538e84
    //     0x538e7c: bl              #0x8277b0  ; AllocateMintSharedWithFPURegsStub
    //     0x538e80: stur            x2, [x0, #7]
    // 0x538e84: mov             x2, x0
    // 0x538e88: r1 = Null
    //     0x538e88: mov             x1, NULL
    // 0x538e8c: r0 = CustomNum()
    //     0x538e8c: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x538e90: mov             x4, x0
    // 0x538e94: ldur            x3, [fp, #-0x10]
    // 0x538e98: stur            x4, [fp, #-0x68]
    // 0x538e9c: r0 = LoadClassIdInstr(r3)
    //     0x538e9c: ldur            x0, [x3, #-1]
    //     0x538ea0: ubfx            x0, x0, #0xc, #0x14
    // 0x538ea4: mov             x1, x3
    // 0x538ea8: ldur            x2, [fp, #-8]
    // 0x538eac: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x538eac: sub             lr, x0, #0xcb6
    //     0x538eb0: ldr             lr, [x21, lr, lsl #3]
    //     0x538eb4: blr             lr
    // 0x538eb8: mov             x1, x0
    // 0x538ebc: ldur            x0, [fp, #-0x10]
    // 0x538ec0: LoadField: r6 = r0->field_2f
    //     0x538ec0: ldur            w6, [x0, #0x2f]
    // 0x538ec4: DecompressPointer r6
    //     0x538ec4: add             x6, x6, HEAP, lsl #32
    // 0x538ec8: LoadField: r7 = r0->field_2b
    //     0x538ec8: ldur            w7, [x0, #0x2b]
    // 0x538ecc: DecompressPointer r7
    //     0x538ecc: add             x7, x7, HEAP, lsl #32
    // 0x538ed0: ldur            x2, [fp, #-0x18]
    // 0x538ed4: ldur            x3, [fp, #-0x28]
    // 0x538ed8: ldur            x5, [fp, #-0x40]
    // 0x538edc: r0 = effectiveSecondsToComplete()
    //     0x538edc: bl              #0x53a284  ; [package:pretentious/data/FragmentInfo/GeneratorInfo.dart] GeneratorInfo::effectiveSecondsToComplete
    // 0x538ee0: mov             x1, x0
    // 0x538ee4: r2 = Instance_CustomNum
    //     0x538ee4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e30] Obj!CustomNum@828de1
    //     0x538ee8: ldr             x2, [x2, #0xe30]
    // 0x538eec: r0 = mult2()
    //     0x538eec: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x538ef0: mov             x1, x0
    // 0x538ef4: r0 = invert()
    //     0x538ef4: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x538ef8: ldur            x1, [fp, #-0x68]
    // 0x538efc: mov             x2, x0
    // 0x538f00: r0 = mult2()
    //     0x538f00: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x538f04: LoadField: d0 = r0->field_7
    //     0x538f04: ldur            d0, [x0, #7]
    // 0x538f08: stp             fp, lr, [SP, #-0x10]!
    // 0x538f0c: mov             fp, SP
    // 0x538f10: CallRuntime_LibcExp(double) -> double
    //     0x538f10: and             SP, SP, #0xfffffffffffffff0
    //     0x538f14: mov             sp, SP
    //     0x538f18: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x538f1c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x538f20: blr             x16
    //     0x538f24: movz            x16, #0x8
    //     0x538f28: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x538f2c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x538f30: sub             sp, x16, #1, lsl #12
    //     0x538f34: mov             SP, fp
    //     0x538f38: ldp             fp, lr, [SP], #0x10
    // 0x538f3c: mov             v1.16b, v0.16b
    // 0x538f40: ldur            d0, [fp, #-0x70]
    // 0x538f44: fadd            d2, d0, d1
    // 0x538f48: r3 = inline_Allocate_Double()
    //     0x538f48: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x538f4c: add             x3, x3, #0x10
    //     0x538f50: cmp             x0, x3
    //     0x538f54: b.ls            #0x539940
    //     0x538f58: str             x3, [THR, #0x60]  ; THR::top
    //     0x538f5c: sub             x3, x3, #0xf
    //     0x538f60: movz            x0, #0xe19c
    //     0x538f64: movk            x0, #0x3, lsl #16
    //     0x538f68: stur            x0, [x3, #-1]
    // 0x538f6c: dmb             ishst
    // 0x538f70: StoreField: r3->field_7 = d2
    //     0x538f70: stur            d2, [x3, #7]
    // 0x538f74: ldur            x1, [fp, #-0x60]
    // 0x538f78: ldur            x2, [fp, #-8]
    // 0x538f7c: r0 = []=()
    //     0x538f7c: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x538f80: ldur            x0, [fp, #-0x10]
    // 0x538f84: LoadField: r3 = r0->field_4b
    //     0x538f84: ldur            w3, [x0, #0x4b]
    // 0x538f88: DecompressPointer r3
    //     0x538f88: add             x3, x3, HEAP, lsl #32
    // 0x538f8c: mov             x1, x3
    // 0x538f90: ldur            x2, [fp, #-8]
    // 0x538f94: stur            x3, [fp, #-0x28]
    // 0x538f98: r0 = _getValueOrData()
    //     0x538f98: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538f9c: mov             x1, x0
    // 0x538fa0: ldur            x0, [fp, #-0x28]
    // 0x538fa4: LoadField: r2 = r0->field_f
    //     0x538fa4: ldur            w2, [x0, #0xf]
    // 0x538fa8: DecompressPointer r2
    //     0x538fa8: add             x2, x2, HEAP, lsl #32
    // 0x538fac: cmp             w2, w1
    // 0x538fb0: b.ne            #0x538fbc
    // 0x538fb4: r0 = Null
    //     0x538fb4: mov             x0, NULL
    // 0x538fb8: b               #0x538fc0
    // 0x538fbc: mov             x0, x1
    // 0x538fc0: d0 = 1.000000
    //     0x538fc0: fmov            d0, #1.00000000
    // 0x538fc4: cmp             w0, NULL
    // 0x538fc8: b.eq            #0x539954
    // 0x538fcc: LoadField: d1 = r0->field_7
    //     0x538fcc: ldur            d1, [x0, #7]
    // 0x538fd0: fcmp            d1, d0
    // 0x538fd4: b.le            #0x539928
    // 0x538fd8: ldur            x0, [fp, #-0x48]
    // 0x538fdc: tbnz            w0, #4, #0x5395d4
    // 0x538fe0: ldur            x0, [fp, #-0x10]
    // 0x538fe4: LoadField: r3 = r0->field_4b
    //     0x538fe4: ldur            w3, [x0, #0x4b]
    // 0x538fe8: DecompressPointer r3
    //     0x538fe8: add             x3, x3, HEAP, lsl #32
    // 0x538fec: mov             x1, x3
    // 0x538ff0: ldur            x2, [fp, #-8]
    // 0x538ff4: stur            x3, [fp, #-0x28]
    // 0x538ff8: r0 = _getValueOrData()
    //     0x538ff8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x538ffc: mov             x1, x0
    // 0x539000: ldur            x0, [fp, #-0x28]
    // 0x539004: LoadField: r2 = r0->field_f
    //     0x539004: ldur            w2, [x0, #0xf]
    // 0x539008: DecompressPointer r2
    //     0x539008: add             x2, x2, HEAP, lsl #32
    // 0x53900c: cmp             w2, w1
    // 0x539010: b.ne            #0x53901c
    // 0x539014: r0 = Null
    //     0x539014: mov             x0, NULL
    // 0x539018: b               #0x539020
    // 0x53901c: mov             x0, x1
    // 0x539020: cmp             w0, NULL
    // 0x539024: b.eq            #0x539958
    // 0x539028: LoadField: d0 = r0->field_7
    //     0x539028: ldur            d0, [x0, #7]
    // 0x53902c: mov             x0, v0.d[0]
    // 0x539030: and             x0, x0, #0x7fffffffffffffff
    // 0x539034: r17 = 9218868437227405312
    //     0x539034: orr             x17, xzr, #0x7ff0000000000000
    // 0x539038: cmp             x0, x17
    // 0x53903c: b.eq            #0x539094
    // 0x539040: ldur            x0, [fp, #-0x10]
    // 0x539044: LoadField: r3 = r0->field_4b
    //     0x539044: ldur            w3, [x0, #0x4b]
    // 0x539048: DecompressPointer r3
    //     0x539048: add             x3, x3, HEAP, lsl #32
    // 0x53904c: mov             x1, x3
    // 0x539050: ldur            x2, [fp, #-8]
    // 0x539054: stur            x3, [fp, #-0x28]
    // 0x539058: r0 = _getValueOrData()
    //     0x539058: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53905c: mov             x1, x0
    // 0x539060: ldur            x0, [fp, #-0x28]
    // 0x539064: LoadField: r2 = r0->field_f
    //     0x539064: ldur            w2, [x0, #0xf]
    // 0x539068: DecompressPointer r2
    //     0x539068: add             x2, x2, HEAP, lsl #32
    // 0x53906c: cmp             w2, w1
    // 0x539070: b.ne            #0x53907c
    // 0x539074: r0 = Null
    //     0x539074: mov             x0, NULL
    // 0x539078: b               #0x539080
    // 0x53907c: mov             x0, x1
    // 0x539080: cmp             w0, NULL
    // 0x539084: b.eq            #0x53995c
    // 0x539088: LoadField: d0 = r0->field_7
    //     0x539088: ldur            d0, [x0, #7]
    // 0x53908c: fcmp            d0, d0
    // 0x539090: b.vc            #0x5390ac
    // 0x539094: ldur            x0, [fp, #-0x10]
    // 0x539098: LoadField: r1 = r0->field_4b
    //     0x539098: ldur            w1, [x0, #0x4b]
    // 0x53909c: DecompressPointer r1
    //     0x53909c: add             x1, x1, HEAP, lsl #32
    // 0x5390a0: ldur            x2, [fp, #-8]
    // 0x5390a4: r3 = 1.000000
    //     0x5390a4: ldr             x3, [PP, #0x6990]  ; [pp+0x6990] 1
    // 0x5390a8: r0 = []=()
    //     0x5390a8: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5390ac: ldur            x0, [fp, #-0x10]
    // 0x5390b0: LoadField: r3 = r0->field_4b
    //     0x5390b0: ldur            w3, [x0, #0x4b]
    // 0x5390b4: DecompressPointer r3
    //     0x5390b4: add             x3, x3, HEAP, lsl #32
    // 0x5390b8: mov             x1, x3
    // 0x5390bc: ldur            x2, [fp, #-8]
    // 0x5390c0: stur            x3, [fp, #-0x28]
    // 0x5390c4: r0 = _getValueOrData()
    //     0x5390c4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5390c8: mov             x1, x0
    // 0x5390cc: ldur            x0, [fp, #-0x28]
    // 0x5390d0: LoadField: r2 = r0->field_f
    //     0x5390d0: ldur            w2, [x0, #0xf]
    // 0x5390d4: DecompressPointer r2
    //     0x5390d4: add             x2, x2, HEAP, lsl #32
    // 0x5390d8: cmp             w2, w1
    // 0x5390dc: b.ne            #0x5390e8
    // 0x5390e0: r0 = Null
    //     0x5390e0: mov             x0, NULL
    // 0x5390e4: b               #0x5390ec
    // 0x5390e8: mov             x0, x1
    // 0x5390ec: ldur            x19, [fp, #-0x10]
    // 0x5390f0: cmp             w0, NULL
    // 0x5390f4: b.eq            #0x539960
    // 0x5390f8: LoadField: d0 = r0->field_7
    //     0x5390f8: ldur            d0, [x0, #7]
    // 0x5390fc: stp             fp, lr, [SP, #-0x10]!
    // 0x539100: mov             fp, SP
    // 0x539104: CallRuntime_LibcFloor(double) -> double
    //     0x539104: and             SP, SP, #0xfffffffffffffff0
    //     0x539108: mov             sp, SP
    //     0x53910c: ldr             x16, [THR, #0x758]  ; THR::LibcFloor
    //     0x539110: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x539114: blr             x16
    //     0x539118: movz            x16, #0x8
    //     0x53911c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x539120: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x539124: sub             sp, x16, #1, lsl #12
    //     0x539128: mov             SP, fp
    //     0x53912c: ldp             fp, lr, [SP], #0x10
    // 0x539130: stur            d0, [fp, #-0x70]
    // 0x539134: LoadField: r0 = r19->field_4b
    //     0x539134: ldur            w0, [x19, #0x4b]
    // 0x539138: DecompressPointer r0
    //     0x539138: add             x0, x0, HEAP, lsl #32
    // 0x53913c: mov             x1, x0
    // 0x539140: ldur            x2, [fp, #-8]
    // 0x539144: stur            x0, [fp, #-0x28]
    // 0x539148: r0 = _getValueOrData()
    //     0x539148: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53914c: ldur            x1, [fp, #-0x28]
    // 0x539150: LoadField: r2 = r1->field_f
    //     0x539150: ldur            w2, [x1, #0xf]
    // 0x539154: DecompressPointer r2
    //     0x539154: add             x2, x2, HEAP, lsl #32
    // 0x539158: cmp             w2, w0
    // 0x53915c: b.ne            #0x539168
    // 0x539160: r2 = Null
    //     0x539160: mov             x2, NULL
    // 0x539164: b               #0x53916c
    // 0x539168: mov             x2, x0
    // 0x53916c: ldur            x0, [fp, #-0x58]
    // 0x539170: stur            x2, [fp, #-0x40]
    // 0x539174: cmp             w2, NULL
    // 0x539178: b.eq            #0x539964
    // 0x53917c: r16 = 2
    //     0x53917c: movz            x16, #0x2
    // 0x539180: stp             x16, NULL, [SP]
    // 0x539184: r0 = _Double.fromInteger()
    //     0x539184: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x539188: mov             x1, x0
    // 0x53918c: ldur            x0, [fp, #-0x40]
    // 0x539190: LoadField: d0 = r0->field_7
    //     0x539190: ldur            d0, [x0, #7]
    // 0x539194: LoadField: d1 = r1->field_7
    //     0x539194: ldur            d1, [x1, #7]
    // 0x539198: stp             fp, lr, [SP, #-0x10]!
    // 0x53919c: mov             fp, SP
    // 0x5391a0: CallRuntime_DartModulo(double, double) -> double
    //     0x5391a0: and             SP, SP, #0xfffffffffffffff0
    //     0x5391a4: mov             sp, SP
    //     0x5391a8: ldr             x16, [THR, #0x748]  ; THR::DartModulo
    //     0x5391ac: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5391b0: blr             x16
    //     0x5391b4: movz            x16, #0x8
    //     0x5391b8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5391bc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5391c0: sub             sp, x16, #1, lsl #12
    //     0x5391c4: mov             SP, fp
    //     0x5391c8: ldp             fp, lr, [SP], #0x10
    // 0x5391cc: r3 = inline_Allocate_Double()
    //     0x5391cc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x5391d0: add             x3, x3, #0x10
    //     0x5391d4: cmp             x0, x3
    //     0x5391d8: b.ls            #0x539968
    //     0x5391dc: str             x3, [THR, #0x60]  ; THR::top
    //     0x5391e0: sub             x3, x3, #0xf
    //     0x5391e4: movz            x0, #0xe19c
    //     0x5391e8: movk            x0, #0x3, lsl #16
    //     0x5391ec: stur            x0, [x3, #-1]
    // 0x5391f0: dmb             ishst
    // 0x5391f4: StoreField: r3->field_7 = d0
    //     0x5391f4: stur            d0, [x3, #7]
    // 0x5391f8: ldur            x1, [fp, #-0x28]
    // 0x5391fc: ldur            x2, [fp, #-8]
    // 0x539200: r0 = []=()
    //     0x539200: bl              #0x823e3c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x539204: ldur            x0, [fp, #-0x58]
    // 0x539208: cmp             w0, NULL
    // 0x53920c: b.eq            #0x5395c8
    // 0x539210: d0 = -inf
    //     0x539210: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x539214: LoadField: r3 = r0->field_f
    //     0x539214: ldur            w3, [x0, #0xf]
    // 0x539218: DecompressPointer r3
    //     0x539218: add             x3, x3, HEAP, lsl #32
    // 0x53921c: stur            x3, [fp, #-0x48]
    // 0x539220: cmp             w3, NULL
    // 0x539224: b.eq            #0x53997c
    // 0x539228: LoadField: d1 = r3->field_7
    //     0x539228: ldur            d1, [x3, #7]
    // 0x53922c: stur            d1, [fp, #-0x78]
    // 0x539230: fcmp            d1, d0
    // 0x539234: b.eq            #0x5395c0
    // 0x539238: ldur            x4, [fp, #-0x10]
    // 0x53923c: LoadField: r5 = r4->field_37
    //     0x53923c: ldur            w5, [x4, #0x37]
    // 0x539240: DecompressPointer r5
    //     0x539240: add             x5, x5, HEAP, lsl #32
    // 0x539244: stur            x5, [fp, #-0x40]
    // 0x539248: LoadField: r6 = r0->field_b
    //     0x539248: ldur            w6, [x0, #0xb]
    // 0x53924c: DecompressPointer r6
    //     0x53924c: add             x6, x6, HEAP, lsl #32
    // 0x539250: mov             x1, x5
    // 0x539254: mov             x2, x6
    // 0x539258: stur            x6, [fp, #-0x28]
    // 0x53925c: r0 = _getValueOrData()
    //     0x53925c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x539260: mov             x1, x0
    // 0x539264: ldur            x0, [fp, #-0x40]
    // 0x539268: LoadField: r2 = r0->field_f
    //     0x539268: ldur            w2, [x0, #0xf]
    // 0x53926c: DecompressPointer r2
    //     0x53926c: add             x2, x2, HEAP, lsl #32
    // 0x539270: cmp             w2, w1
    // 0x539274: b.ne            #0x539280
    // 0x539278: r0 = Null
    //     0x539278: mov             x0, NULL
    // 0x53927c: b               #0x539284
    // 0x539280: mov             x0, x1
    // 0x539284: cmp             w0, NULL
    // 0x539288: b.ne            #0x539294
    // 0x53928c: r0 = Null
    //     0x53928c: mov             x0, NULL
    // 0x539290: b               #0x5392f8
    // 0x539294: LoadField: d0 = r0->field_7
    //     0x539294: ldur            d0, [x0, #7]
    // 0x539298: stp             fp, lr, [SP, #-0x10]!
    // 0x53929c: mov             fp, SP
    // 0x5392a0: CallRuntime_LibcExp(double) -> double
    //     0x5392a0: and             SP, SP, #0xfffffffffffffff0
    //     0x5392a4: mov             sp, SP
    //     0x5392a8: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x5392ac: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5392b0: blr             x16
    //     0x5392b4: movz            x16, #0x8
    //     0x5392b8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5392bc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5392c0: sub             sp, x16, #1, lsl #12
    //     0x5392c4: mov             SP, fp
    //     0x5392c8: ldp             fp, lr, [SP], #0x10
    // 0x5392cc: r0 = inline_Allocate_Double()
    //     0x5392cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5392d0: add             x0, x0, #0x10
    //     0x5392d4: cmp             x1, x0
    //     0x5392d8: b.ls            #0x539980
    //     0x5392dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x5392e0: sub             x0, x0, #0xf
    //     0x5392e4: movz            x1, #0xe19c
    //     0x5392e8: movk            x1, #0x3, lsl #16
    //     0x5392ec: stur            x1, [x0, #-1]
    // 0x5392f0: dmb             ishst
    // 0x5392f4: StoreField: r0->field_7 = d0
    //     0x5392f4: stur            d0, [x0, #7]
    // 0x5392f8: cmp             w0, NULL
    // 0x5392fc: b.ne            #0x539308
    // 0x539300: d1 = 0.000000
    //     0x539300: eor             v1.16b, v1.16b, v1.16b
    // 0x539304: b               #0x539310
    // 0x539308: LoadField: d0 = r0->field_7
    //     0x539308: ldur            d0, [x0, #7]
    // 0x53930c: mov             v1.16b, v0.16b
    // 0x539310: ldur            d0, [fp, #-0x78]
    // 0x539314: stur            d1, [fp, #-0x80]
    // 0x539318: stp             fp, lr, [SP, #-0x10]!
    // 0x53931c: mov             fp, SP
    // 0x539320: CallRuntime_LibcExp(double) -> double
    //     0x539320: and             SP, SP, #0xfffffffffffffff0
    //     0x539324: mov             sp, SP
    //     0x539328: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x53932c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x539330: blr             x16
    //     0x539334: movz            x16, #0x8
    //     0x539338: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x53933c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x539340: sub             sp, x16, #1, lsl #12
    //     0x539344: mov             SP, fp
    //     0x539348: ldp             fp, lr, [SP], #0x10
    // 0x53934c: mov             v1.16b, v0.16b
    // 0x539350: ldur            d0, [fp, #-0x80]
    // 0x539354: r0 = inline_Allocate_Double()
    //     0x539354: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x539358: add             x0, x0, #0x10
    //     0x53935c: cmp             x1, x0
    //     0x539360: b.ls            #0x539990
    //     0x539364: str             x0, [THR, #0x60]  ; THR::top
    //     0x539368: sub             x0, x0, #0xf
    //     0x53936c: movz            x1, #0xe19c
    //     0x539370: movk            x1, #0x3, lsl #16
    //     0x539374: stur            x1, [x0, #-1]
    // 0x539378: dmb             ishst
    // 0x53937c: StoreField: r0->field_7 = d0
    //     0x53937c: stur            d0, [x0, #7]
    // 0x539380: r1 = inline_Allocate_Double()
    //     0x539380: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x539384: add             x1, x1, #0x10
    //     0x539388: cmp             x2, x1
    //     0x53938c: b.ls            #0x5399a0
    //     0x539390: str             x1, [THR, #0x60]  ; THR::top
    //     0x539394: sub             x1, x1, #0xf
    //     0x539398: movz            x2, #0xe19c
    //     0x53939c: movk            x2, #0x3, lsl #16
    //     0x5393a0: stur            x2, [x1, #-1]
    // 0x5393a4: dmb             ishst
    // 0x5393a8: StoreField: r1->field_7 = d1
    //     0x5393a8: stur            d1, [x1, #7]
    // 0x5393ac: stp             x1, x0, [SP]
    // 0x5393b0: r0 = ~/()
    //     0x5393b0: bl              #0x4a753c  ; [dart:core] _Double::~/
    // 0x5393b4: r1 = LoadInt32Instr(r0)
    //     0x5393b4: sbfx            x1, x0, #1, #0x1f
    //     0x5393b8: tbz             w0, #0, #0x5393c0
    //     0x5393bc: ldur            x1, [x0, #7]
    // 0x5393c0: add             x0, x1, #1
    // 0x5393c4: tbz             x0, #0x3f, #0x539498
    // 0x5393c8: ldur            x0, [fp, #-0x10]
    // 0x5393cc: LoadField: r3 = r0->field_37
    //     0x5393cc: ldur            w3, [x0, #0x37]
    // 0x5393d0: DecompressPointer r3
    //     0x5393d0: add             x3, x3, HEAP, lsl #32
    // 0x5393d4: mov             x1, x3
    // 0x5393d8: ldur            x2, [fp, #-0x28]
    // 0x5393dc: stur            x3, [fp, #-0x40]
    // 0x5393e0: r0 = _getValueOrData()
    //     0x5393e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5393e4: mov             x1, x0
    // 0x5393e8: ldur            x0, [fp, #-0x40]
    // 0x5393ec: LoadField: r2 = r0->field_f
    //     0x5393ec: ldur            w2, [x0, #0xf]
    // 0x5393f0: DecompressPointer r2
    //     0x5393f0: add             x2, x2, HEAP, lsl #32
    // 0x5393f4: cmp             w2, w1
    // 0x5393f8: b.ne            #0x539404
    // 0x5393fc: r0 = Null
    //     0x5393fc: mov             x0, NULL
    // 0x539400: b               #0x539408
    // 0x539404: mov             x0, x1
    // 0x539408: cmp             w0, NULL
    // 0x53940c: b.ne            #0x539418
    // 0x539410: r0 = Instance_CustomNum
    //     0x539410: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x539414: ldr             x0, [x0, #0xaf8]
    // 0x539418: ldur            x1, [fp, #-0x48]
    // 0x53941c: stur            x0, [fp, #-0x40]
    // 0x539420: r0 = invert()
    //     0x539420: bl              #0x46124c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::invert
    // 0x539424: ldur            x1, [fp, #-0x40]
    // 0x539428: mov             x2, x0
    // 0x53942c: r0 = mult2()
    //     0x53942c: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x539430: LoadField: d0 = r0->field_7
    //     0x539430: ldur            d0, [x0, #7]
    // 0x539434: stp             fp, lr, [SP, #-0x10]!
    // 0x539438: mov             fp, SP
    // 0x53943c: CallRuntime_LibcExp(double) -> double
    //     0x53943c: and             SP, SP, #0xfffffffffffffff0
    //     0x539440: mov             sp, SP
    //     0x539444: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x539448: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x53944c: blr             x16
    //     0x539450: movz            x16, #0x8
    //     0x539454: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x539458: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x53945c: sub             sp, x16, #1, lsl #12
    //     0x539460: mov             SP, fp
    //     0x539464: ldp             fp, lr, [SP], #0x10
    // 0x539468: fcmp            d0, d0
    // 0x53946c: b.vs            #0x5399bc
    // 0x539470: fcvtms          x0, d0
    // 0x539474: asr             x16, x0, #0x1e
    // 0x539478: cmp             x16, x0, asr #63
    // 0x53947c: b.ne            #0x5399bc
    // 0x539480: lsl             x0, x0, #1
    // 0x539484: r1 = LoadInt32Instr(r0)
    //     0x539484: sbfx            x1, x0, #1, #0x1f
    //     0x539488: tbz             w0, #0, #0x539490
    //     0x53948c: ldur            x1, [x0, #7]
    // 0x539490: mov             x3, x1
    // 0x539494: b               #0x53949c
    // 0x539498: mov             x3, x0
    // 0x53949c: ldur            x2, [fp, #-0x10]
    // 0x5394a0: ldur            d0, [fp, #-0x70]
    // 0x5394a4: r0 = BoxInt64Instr(r3)
    //     0x5394a4: sbfiz           x0, x3, #1, #0x1f
    //     0x5394a8: cmp             x3, x0, asr #1
    //     0x5394ac: b.eq            #0x5394b8
    //     0x5394b0: bl              #0x8277b0  ; AllocateMintSharedWithFPURegsStub
    //     0x5394b4: stur            x3, [x0, #7]
    // 0x5394b8: stp             x0, NULL, [SP]
    // 0x5394bc: r0 = _Double.fromInteger()
    //     0x5394bc: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x5394c0: LoadField: d0 = r0->field_7
    //     0x5394c0: ldur            d0, [x0, #7]
    // 0x5394c4: ldur            d1, [fp, #-0x70]
    // 0x5394c8: fmin            v2.2d, v0.2d, v1.2d
    // 0x5394cc: stur            d2, [fp, #-0x80]
    // 0x5394d0: d0 = 1.000000
    //     0x5394d0: fmov            d0, #1.00000000
    // 0x5394d4: fsub            d1, d2, d0
    // 0x5394d8: ldur            x0, [fp, #-0x10]
    // 0x5394dc: stur            d1, [fp, #-0x78]
    // 0x5394e0: LoadField: r1 = r0->field_37
    //     0x5394e0: ldur            w1, [x0, #0x37]
    // 0x5394e4: DecompressPointer r1
    //     0x5394e4: add             x1, x1, HEAP, lsl #32
    // 0x5394e8: ldur            x2, [fp, #-0x28]
    // 0x5394ec: r0 = containsKey()
    //     0x5394ec: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x5394f0: tbnz            w0, #4, #0x539578
    // 0x5394f4: ldur            d0, [fp, #-0x78]
    // 0x5394f8: d1 = 0.000000
    //     0x5394f8: eor             v1.16b, v1.16b, v1.16b
    // 0x5394fc: fcmp            d0, d1
    // 0x539500: b.le            #0x539578
    // 0x539504: ldur            x1, [fp, #-0x10]
    // 0x539508: LoadField: r0 = r1->field_7
    //     0x539508: ldur            w0, [x1, #7]
    // 0x53950c: DecompressPointer r0
    //     0x53950c: add             x0, x0, HEAP, lsl #32
    // 0x539510: stur            x0, [fp, #-0x40]
    // 0x539514: LoadField: r2 = r1->field_37
    //     0x539514: ldur            w2, [x1, #0x37]
    // 0x539518: DecompressPointer r2
    //     0x539518: add             x2, x2, HEAP, lsl #32
    // 0x53951c: stur            x2, [fp, #-0x28]
    // 0x539520: r3 = inline_Allocate_Double()
    //     0x539520: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x539524: add             x3, x3, #0x10
    //     0x539528: cmp             x4, x3
    //     0x53952c: b.ls            #0x5399d8
    //     0x539530: str             x3, [THR, #0x60]  ; THR::top
    //     0x539534: sub             x3, x3, #0xf
    //     0x539538: movz            x4, #0xe19c
    //     0x53953c: movk            x4, #0x3, lsl #16
    //     0x539540: stur            x4, [x3, #-1]
    // 0x539544: dmb             ishst
    // 0x539548: StoreField: r3->field_7 = d0
    //     0x539548: stur            d0, [x3, #7]
    // 0x53954c: ldur            x16, [fp, #-0x58]
    // 0x539550: stp             x16, x0, [SP, #8]
    // 0x539554: str             x3, [SP]
    // 0x539558: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x539558: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53955c: r0 = TupleOperations.multiply()
    //     0x53955c: bl              #0x53a1dc  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::TupleOperations.multiply
    // 0x539560: ldur            x16, [fp, #-0x40]
    // 0x539564: ldur            lr, [fp, #-0x28]
    // 0x539568: stp             lr, x16, [SP, #8]
    // 0x53956c: str             x0, [SP]
    // 0x539570: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x539570: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x539574: r0 = MapOperations.subtractTuple()
    //     0x539574: bl              #0x539e38  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.subtractTuple
    // 0x539578: ldur            x1, [fp, #-0x10]
    // 0x53957c: LoadField: r0 = r1->field_7
    //     0x53957c: ldur            w0, [x1, #7]
    // 0x539580: DecompressPointer r0
    //     0x539580: add             x0, x0, HEAP, lsl #32
    // 0x539584: LoadField: r2 = r1->field_37
    //     0x539584: ldur            w2, [x1, #0x37]
    // 0x539588: DecompressPointer r2
    //     0x539588: add             x2, x2, HEAP, lsl #32
    // 0x53958c: stp             x2, x0, [SP, #8]
    // 0x539590: ldur            x16, [fp, #-0x58]
    // 0x539594: str             x16, [SP]
    // 0x539598: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x539598: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53959c: r0 = MapOperations.trySubtractTupleIgnoreFloatingPointError()
    //     0x53959c: bl              #0x53a65c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.trySubtractTupleIgnoreFloatingPointError
    // 0x5395a0: tbz             w0, #4, #0x5395b8
    // 0x5395a4: ldur            x0, [fp, #-0x10]
    // 0x5395a8: LoadField: r1 = r0->field_4b
    //     0x5395a8: ldur            w1, [x0, #0x4b]
    // 0x5395ac: DecompressPointer r1
    //     0x5395ac: add             x1, x1, HEAP, lsl #32
    // 0x5395b0: ldur            x2, [fp, #-8]
    // 0x5395b4: r0 = remove()
    //     0x5395b4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x5395b8: ldur            d0, [fp, #-0x80]
    // 0x5395bc: b               #0x5395ec
    // 0x5395c0: ldur            d1, [fp, #-0x70]
    // 0x5395c4: b               #0x5395cc
    // 0x5395c8: ldur            d1, [fp, #-0x70]
    // 0x5395cc: mov             v0.16b, v1.16b
    // 0x5395d0: b               #0x5395ec
    // 0x5395d4: ldur            x0, [fp, #-0x10]
    // 0x5395d8: LoadField: r1 = r0->field_4b
    //     0x5395d8: ldur            w1, [x0, #0x4b]
    // 0x5395dc: DecompressPointer r1
    //     0x5395dc: add             x1, x1, HEAP, lsl #32
    // 0x5395e0: ldur            x2, [fp, #-8]
    // 0x5395e4: r0 = remove()
    //     0x5395e4: bl              #0x7ba5d0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x5395e8: d0 = 1.000000
    //     0x5395e8: fmov            d0, #1.00000000
    // 0x5395ec: ldur            x0, [fp, #-0x10]
    // 0x5395f0: stur            d0, [fp, #-0x70]
    // 0x5395f4: LoadField: r4 = r0->field_7
    //     0x5395f4: ldur            w4, [x0, #7]
    // 0x5395f8: DecompressPointer r4
    //     0x5395f8: add             x4, x4, HEAP, lsl #32
    // 0x5395fc: mov             x2, x4
    // 0x539600: stur            x4, [fp, #-0x28]
    // 0x539604: r1 = Null
    //     0x539604: mov             x1, NULL
    // 0x539608: r3 = <X0, CustomNum>
    //     0x539608: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x53960c: ldr             x3, [x3, #0xb10]
    // 0x539610: r30 = InstantiateTypeArgumentsStub
    //     0x539610: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x539614: LoadField: r30 = r30->field_7
    //     0x539614: ldur            lr, [lr, #7]
    // 0x539618: blr             lr
    // 0x53961c: mov             x3, x0
    // 0x539620: ldur            x0, [fp, #-0x10]
    // 0x539624: stur            x3, [fp, #-0x48]
    // 0x539628: LoadField: r4 = r0->field_47
    //     0x539628: ldur            w4, [x0, #0x47]
    // 0x53962c: DecompressPointer r4
    //     0x53962c: add             x4, x4, HEAP, lsl #32
    // 0x539630: mov             x1, x4
    // 0x539634: ldur            x2, [fp, #-8]
    // 0x539638: stur            x4, [fp, #-0x40]
    // 0x53963c: r0 = _getValueOrData()
    //     0x53963c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x539640: mov             x1, x0
    // 0x539644: ldur            x0, [fp, #-0x40]
    // 0x539648: LoadField: r2 = r0->field_f
    //     0x539648: ldur            w2, [x0, #0xf]
    // 0x53964c: DecompressPointer r2
    //     0x53964c: add             x2, x2, HEAP, lsl #32
    // 0x539650: cmp             w2, w1
    // 0x539654: b.ne            #0x539660
    // 0x539658: r0 = Null
    //     0x539658: mov             x0, NULL
    // 0x53965c: b               #0x539664
    // 0x539660: mov             x0, x1
    // 0x539664: cmp             w0, NULL
    // 0x539668: b.ne            #0x539674
    // 0x53966c: r3 = 0
    //     0x53966c: movz            x3, #0
    // 0x539670: b               #0x539678
    // 0x539674: mov             x3, x0
    // 0x539678: ldur            x4, [fp, #-0x10]
    // 0x53967c: r0 = LoadClassIdInstr(r4)
    //     0x53967c: ldur            x0, [x4, #-1]
    //     0x539680: ubfx            x0, x0, #0xc, #0x14
    // 0x539684: mov             x1, x4
    // 0x539688: ldur            x2, [fp, #-0x18]
    // 0x53968c: r0 = GDT[cid_x0 + 0x88f2]()
    //     0x53968c: movz            x17, #0x88f2
    //     0x539690: add             lr, x0, x17
    //     0x539694: ldr             lr, [x21, lr, lsl #3]
    //     0x539698: blr             lr
    // 0x53969c: ldur            x1, [fp, #-0x48]
    // 0x5396a0: mov             x2, x0
    // 0x5396a4: r0 = LinkedHashMap.from()
    //     0x5396a4: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x5396a8: mov             x3, x0
    // 0x5396ac: ldur            x0, [fp, #-0x10]
    // 0x5396b0: stur            x3, [fp, #-0x40]
    // 0x5396b4: LoadField: r1 = r0->field_4f
    //     0x5396b4: ldur            w1, [x0, #0x4f]
    // 0x5396b8: DecompressPointer r1
    //     0x5396b8: add             x1, x1, HEAP, lsl #32
    // 0x5396bc: ldur            x2, [fp, #-8]
    // 0x5396c0: r0 = containsKey()
    //     0x5396c0: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x5396c4: tbnz            w0, #4, #0x539730
    // 0x5396c8: ldur            x2, [fp, #-0x10]
    // 0x5396cc: LoadField: r0 = r2->field_4f
    //     0x5396cc: ldur            w0, [x2, #0x4f]
    // 0x5396d0: DecompressPointer r0
    //     0x5396d0: add             x0, x0, HEAP, lsl #32
    // 0x5396d4: mov             x1, x0
    // 0x5396d8: ldur            x2, [fp, #-8]
    // 0x5396dc: stur            x0, [fp, #-0x48]
    // 0x5396e0: r0 = _getValueOrData()
    //     0x5396e0: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5396e4: mov             x1, x0
    // 0x5396e8: ldur            x0, [fp, #-0x48]
    // 0x5396ec: LoadField: r2 = r0->field_f
    //     0x5396ec: ldur            w2, [x0, #0xf]
    // 0x5396f0: DecompressPointer r2
    //     0x5396f0: add             x2, x2, HEAP, lsl #32
    // 0x5396f4: cmp             w2, w1
    // 0x5396f8: b.ne            #0x539704
    // 0x5396fc: r0 = Null
    //     0x5396fc: mov             x0, NULL
    // 0x539700: b               #0x539708
    // 0x539704: mov             x0, x1
    // 0x539708: cmp             w0, NULL
    // 0x53970c: b.eq            #0x5399fc
    // 0x539710: LoadField: d0 = r0->field_7
    //     0x539710: ldur            d0, [x0, #7]
    // 0x539714: ldur            x16, [fp, #-0x28]
    // 0x539718: ldur            lr, [fp, #-0x40]
    // 0x53971c: stp             lr, x16, [SP, #8]
    // 0x539720: str             d0, [SP]
    // 0x539724: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x539724: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x539728: r0 = MapOperations.multiplyScalerNum()
    //     0x539728: bl              #0x539b4c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScalerNum
    // 0x53972c: b               #0x53985c
    // 0x539730: ldur            x2, [fp, #-0x10]
    // 0x539734: LoadField: r3 = r2->field_37
    //     0x539734: ldur            w3, [x2, #0x37]
    // 0x539738: DecompressPointer r3
    //     0x539738: add             x3, x3, HEAP, lsl #32
    // 0x53973c: stur            x3, [fp, #-0x48]
    // 0x539740: r0 = LoadClassIdInstr(r2)
    //     0x539740: ldur            x0, [x2, #-1]
    //     0x539744: ubfx            x0, x0, #0xc, #0x14
    // 0x539748: mov             x1, x2
    // 0x53974c: r0 = GDT[cid_x0 + 0x8702]()
    //     0x53974c: movz            x17, #0x8702
    //     0x539750: add             lr, x0, x17
    //     0x539754: ldr             lr, [x21, lr, lsl #3]
    //     0x539758: blr             lr
    // 0x53975c: mov             x1, x0
    // 0x539760: ldur            x2, [fp, #-8]
    // 0x539764: stur            x0, [fp, #-0x58]
    // 0x539768: r0 = _getValueOrData()
    //     0x539768: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53976c: mov             x1, x0
    // 0x539770: ldur            x0, [fp, #-0x58]
    // 0x539774: LoadField: r2 = r0->field_f
    //     0x539774: ldur            w2, [x0, #0xf]
    // 0x539778: DecompressPointer r2
    //     0x539778: add             x2, x2, HEAP, lsl #32
    // 0x53977c: cmp             w2, w1
    // 0x539780: b.ne            #0x53978c
    // 0x539784: r2 = Null
    //     0x539784: mov             x2, NULL
    // 0x539788: b               #0x539790
    // 0x53978c: mov             x2, x1
    // 0x539790: ldur            x0, [fp, #-0x48]
    // 0x539794: mov             x1, x0
    // 0x539798: r0 = _getValueOrData()
    //     0x539798: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53979c: mov             x1, x0
    // 0x5397a0: ldur            x0, [fp, #-0x48]
    // 0x5397a4: LoadField: r2 = r0->field_f
    //     0x5397a4: ldur            w2, [x0, #0xf]
    // 0x5397a8: DecompressPointer r2
    //     0x5397a8: add             x2, x2, HEAP, lsl #32
    // 0x5397ac: cmp             w2, w1
    // 0x5397b0: b.ne            #0x5397bc
    // 0x5397b4: r0 = Null
    //     0x5397b4: mov             x0, NULL
    // 0x5397b8: b               #0x5397c0
    // 0x5397bc: mov             x0, x1
    // 0x5397c0: cmp             w0, NULL
    // 0x5397c4: b.ne            #0x5397d4
    // 0x5397c8: r3 = Instance_CustomNum
    //     0x5397c8: add             x3, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x5397cc: ldr             x3, [x3, #0xaf8]
    // 0x5397d0: b               #0x5397d8
    // 0x5397d4: mov             x3, x0
    // 0x5397d8: ldur            x0, [fp, #-0x10]
    // 0x5397dc: stur            x3, [fp, #-0x58]
    // 0x5397e0: LoadField: r4 = r0->field_47
    //     0x5397e0: ldur            w4, [x0, #0x47]
    // 0x5397e4: DecompressPointer r4
    //     0x5397e4: add             x4, x4, HEAP, lsl #32
    // 0x5397e8: mov             x1, x4
    // 0x5397ec: ldur            x2, [fp, #-8]
    // 0x5397f0: stur            x4, [fp, #-0x48]
    // 0x5397f4: r0 = _getValueOrData()
    //     0x5397f4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5397f8: mov             x1, x0
    // 0x5397fc: ldur            x0, [fp, #-0x48]
    // 0x539800: LoadField: r2 = r0->field_f
    //     0x539800: ldur            w2, [x0, #0xf]
    // 0x539804: DecompressPointer r2
    //     0x539804: add             x2, x2, HEAP, lsl #32
    // 0x539808: cmp             w2, w1
    // 0x53980c: b.ne            #0x539818
    // 0x539810: r0 = Null
    //     0x539810: mov             x0, NULL
    // 0x539814: b               #0x53981c
    // 0x539818: mov             x0, x1
    // 0x53981c: cmp             w0, NULL
    // 0x539820: b.ne            #0x53982c
    // 0x539824: r2 = 0
    //     0x539824: movz            x2, #0
    // 0x539828: b               #0x539830
    // 0x53982c: mov             x2, x0
    // 0x539830: r1 = Null
    //     0x539830: mov             x1, NULL
    // 0x539834: r0 = CustomNum()
    //     0x539834: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x539838: ldur            x1, [fp, #-0x58]
    // 0x53983c: mov             x2, x0
    // 0x539840: r0 = add()
    //     0x539840: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x539844: ldur            x16, [fp, #-0x28]
    // 0x539848: ldur            lr, [fp, #-0x40]
    // 0x53984c: stp             lr, x16, [SP, #8]
    // 0x539850: str             x0, [SP]
    // 0x539854: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x539854: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x539858: r0 = MapOperations.multiplyScaler()
    //     0x539858: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x53985c: ldur            d0, [fp, #-0x70]
    // 0x539860: ldur            x16, [fp, #-0x28]
    // 0x539864: ldur            lr, [fp, #-0x40]
    // 0x539868: stp             lr, x16, [SP, #8]
    // 0x53986c: str             d0, [SP]
    // 0x539870: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x539870: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x539874: r0 = MapOperations.multiplyScalerNum()
    //     0x539874: bl              #0x539b4c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScalerNum
    // 0x539878: ldur            x16, [fp, #-0x28]
    // 0x53987c: ldur            lr, [fp, #-0x40]
    // 0x539880: stp             lr, x16, [SP, #8]
    // 0x539884: ldur            x16, [fp, #-0x50]
    // 0x539888: str             x16, [SP]
    // 0x53988c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53988c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x539890: r0 = MapOperations.multiplyScaler()
    //     0x539890: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x539894: ldur            x16, [fp, #-0x28]
    // 0x539898: ldur            lr, [fp, #-0x38]
    // 0x53989c: stp             lr, x16, [SP, #8]
    // 0x5398a0: ldur            x16, [fp, #-0x40]
    // 0x5398a4: str             x16, [SP]
    // 0x5398a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5398a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5398ac: r0 = MapOperations.merge()
    //     0x5398ac: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x5398b0: ldur            x16, [fp, #-0x28]
    // 0x5398b4: ldur            lr, [fp, #-0x40]
    // 0x5398b8: stp             lr, x16, [SP, #8]
    // 0x5398bc: ldur            x16, [fp, #-0x30]
    // 0x5398c0: str             x16, [SP]
    // 0x5398c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5398c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5398c8: r0 = MapOperations.getBoostFromCustomNum()
    //     0x5398c8: bl              #0x539a00  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.getBoostFromCustomNum
    // 0x5398cc: ldur            x16, [fp, #-0x28]
    // 0x5398d0: ldur            lr, [fp, #-0x40]
    // 0x5398d4: stp             lr, x16, [SP, #8]
    // 0x5398d8: str             x0, [SP]
    // 0x5398dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5398dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5398e0: r0 = MapOperations.multiplyScaler()
    //     0x5398e0: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x5398e4: ldur            x16, [fp, #-0x28]
    // 0x5398e8: ldr             lr, [fp, #0x10]
    // 0x5398ec: stp             lr, x16, [SP, #8]
    // 0x5398f0: str             x0, [SP]
    // 0x5398f4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5398f4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5398f8: r0 = MapOperations.merge()
    //     0x5398f8: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x5398fc: r0 = LoadStaticField(0x1030)
    //     0x5398fc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x539900: ldr             x0, [x0, #0x2060]
    // 0x539904: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x539908: cmp             w0, w16
    // 0x53990c: b.ne            #0x53991c
    // 0x539910: r2 = currencyCounterGroup
    //     0x539910: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc28] Field <::.currencyCounterGroup>: static late (offset: 0x1030)
    //     0x539914: ldr             x2, [x2, #0xc28]
    // 0x539918: r0 = InitLateStaticField()
    //     0x539918: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x53991c: mov             x1, x0
    // 0x539920: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x539920: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x539924: r0 = notifyAll()
    //     0x539924: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x539928: r0 = Null
    //     0x539928: mov             x0, NULL
    // 0x53992c: LeaveFrame
    //     0x53992c: mov             SP, fp
    //     0x539930: ldp             fp, lr, [SP], #0x10
    // 0x539934: ret
    //     0x539934: ret             
    // 0x539938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x539938: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53993c: b               #0x538b80
    // 0x539940: SaveReg d2
    //     0x539940: str             q2, [SP, #-0x10]!
    // 0x539944: r0 = AllocateDouble()
    //     0x539944: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x539948: mov             x3, x0
    // 0x53994c: RestoreReg d2
    //     0x53994c: ldr             q2, [SP], #0x10
    // 0x539950: b               #0x538f70
    // 0x539954: r0 = NullCastErrorSharedWithFPURegs()
    //     0x539954: bl              #0x827c54  ; NullCastErrorSharedWithFPURegsStub
    // 0x539958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x539958: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x53995c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x53995c: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x539960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x539960: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x539964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x539964: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x539968: SaveReg d0
    //     0x539968: str             q0, [SP, #-0x10]!
    // 0x53996c: r0 = AllocateDouble()
    //     0x53996c: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x539970: mov             x3, x0
    // 0x539974: RestoreReg d0
    //     0x539974: ldr             q0, [SP], #0x10
    // 0x539978: b               #0x5391f4
    // 0x53997c: r0 = NullErrorSharedWithFPURegs()
    //     0x53997c: bl              #0x827e04  ; NullErrorSharedWithFPURegsStub
    // 0x539980: SaveReg d0
    //     0x539980: str             q0, [SP, #-0x10]!
    // 0x539984: r0 = AllocateDouble()
    //     0x539984: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x539988: RestoreReg d0
    //     0x539988: ldr             q0, [SP], #0x10
    // 0x53998c: b               #0x5392f4
    // 0x539990: stp             q0, q1, [SP, #-0x20]!
    // 0x539994: r0 = AllocateDouble()
    //     0x539994: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x539998: ldp             q0, q1, [SP], #0x20
    // 0x53999c: b               #0x53937c
    // 0x5399a0: SaveReg d1
    //     0x5399a0: str             q1, [SP, #-0x10]!
    // 0x5399a4: SaveReg r0
    //     0x5399a4: str             x0, [SP, #-8]!
    // 0x5399a8: r0 = AllocateDouble()
    //     0x5399a8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5399ac: mov             x1, x0
    // 0x5399b0: RestoreReg r0
    //     0x5399b0: ldr             x0, [SP], #8
    // 0x5399b4: RestoreReg d1
    //     0x5399b4: ldr             q1, [SP], #0x10
    // 0x5399b8: b               #0x5393a8
    // 0x5399bc: SaveReg d0
    //     0x5399bc: str             q0, [SP, #-0x10]!
    // 0x5399c0: r0 = 70
    //     0x5399c0: movz            x0, #0x46
    // 0x5399c4: r30 = DoubleToIntegerStub
    //     0x5399c4: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x5399c8: LoadField: r30 = r30->field_7
    //     0x5399c8: ldur            lr, [lr, #7]
    // 0x5399cc: blr             lr
    // 0x5399d0: RestoreReg d0
    //     0x5399d0: ldr             q0, [SP], #0x10
    // 0x5399d4: b               #0x539484
    // 0x5399d8: SaveReg d0
    //     0x5399d8: str             q0, [SP, #-0x10]!
    // 0x5399dc: stp             x1, x2, [SP, #-0x10]!
    // 0x5399e0: SaveReg r0
    //     0x5399e0: str             x0, [SP, #-8]!
    // 0x5399e4: r0 = AllocateDouble()
    //     0x5399e4: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x5399e8: mov             x3, x0
    // 0x5399ec: RestoreReg r0
    //     0x5399ec: ldr             x0, [SP], #8
    // 0x5399f0: ldp             x1, x2, [SP], #0x10
    // 0x5399f4: RestoreReg d0
    //     0x5399f4: ldr             q0, [SP], #0x10
    // 0x5399f8: b               #0x539548
    // 0x5399fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5399fc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getCostToStart(/* No info */) {
    // ** addr: 0x53a78c, size: 0x22c
    // 0x53a78c: EnterFrame
    //     0x53a78c: stp             fp, lr, [SP, #-0x10]!
    //     0x53a790: mov             fp, SP
    // 0x53a794: AllocStack(0x48)
    //     0x53a794: sub             SP, SP, #0x48
    // 0x53a798: SetupParameters(IPlayableGameState<X0> this /* r1 => r3, fp-0x10 */)
    //     0x53a798: mov             x3, x1
    //     0x53a79c: stur            x1, [fp, #-0x10]
    // 0x53a7a0: CheckStackOverflow
    //     0x53a7a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53a7a4: cmp             SP, x16
    //     0x53a7a8: b.ls            #0x53a9a4
    // 0x53a7ac: r0 = BoxInt64Instr(r2)
    //     0x53a7ac: sbfiz           x0, x2, #1, #0x1f
    //     0x53a7b0: cmp             x2, x0, asr #1
    //     0x53a7b4: b.eq            #0x53a7c0
    //     0x53a7b8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x53a7bc: stur            x2, [x0, #7]
    // 0x53a7c0: mov             x4, x0
    // 0x53a7c4: stur            x4, [fp, #-8]
    // 0x53a7c8: r0 = LoadClassIdInstr(r3)
    //     0x53a7c8: ldur            x0, [x3, #-1]
    //     0x53a7cc: ubfx            x0, x0, #0xc, #0x14
    // 0x53a7d0: mov             x1, x3
    // 0x53a7d4: mov             x2, x4
    // 0x53a7d8: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x53a7d8: sub             lr, x0, #0xcb6
    //     0x53a7dc: ldr             lr, [x21, lr, lsl #3]
    //     0x53a7e0: blr             lr
    // 0x53a7e4: LoadField: r3 = r0->field_2f
    //     0x53a7e4: ldur            w3, [x0, #0x2f]
    // 0x53a7e8: DecompressPointer r3
    //     0x53a7e8: add             x3, x3, HEAP, lsl #32
    // 0x53a7ec: stur            x3, [fp, #-0x20]
    // 0x53a7f0: cmp             w3, NULL
    // 0x53a7f4: b.ne            #0x53a808
    // 0x53a7f8: r0 = Null
    //     0x53a7f8: mov             x0, NULL
    // 0x53a7fc: LeaveFrame
    //     0x53a7fc: mov             SP, fp
    //     0x53a800: ldp             fp, lr, [SP], #0x10
    // 0x53a804: ret
    //     0x53a804: ret             
    // 0x53a808: ldur            x0, [fp, #-0x10]
    // 0x53a80c: LoadField: r4 = r0->field_33
    //     0x53a80c: ldur            w4, [x0, #0x33]
    // 0x53a810: DecompressPointer r4
    //     0x53a810: add             x4, x4, HEAP, lsl #32
    // 0x53a814: mov             x1, x4
    // 0x53a818: ldur            x2, [fp, #-8]
    // 0x53a81c: stur            x4, [fp, #-0x18]
    // 0x53a820: r0 = _getValueOrData()
    //     0x53a820: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53a824: mov             x1, x0
    // 0x53a828: ldur            x0, [fp, #-0x18]
    // 0x53a82c: LoadField: r2 = r0->field_f
    //     0x53a82c: ldur            w2, [x0, #0xf]
    // 0x53a830: DecompressPointer r2
    //     0x53a830: add             x2, x2, HEAP, lsl #32
    // 0x53a834: cmp             w2, w1
    // 0x53a838: b.ne            #0x53a840
    // 0x53a83c: r1 = Null
    //     0x53a83c: mov             x1, NULL
    // 0x53a840: cmp             w1, NULL
    // 0x53a844: b.ne            #0x53a850
    // 0x53a848: r1 = Null
    //     0x53a848: mov             x1, NULL
    // 0x53a84c: b               #0x53a85c
    // 0x53a850: LoadField: r2 = r1->field_f
    //     0x53a850: ldur            w2, [x1, #0xf]
    // 0x53a854: DecompressPointer r2
    //     0x53a854: add             x2, x2, HEAP, lsl #32
    // 0x53a858: mov             x1, x2
    // 0x53a85c: cmp             w1, NULL
    // 0x53a860: b.ne            #0x53a870
    // 0x53a864: r3 = Instance_CustomNum
    //     0x53a864: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x53a868: ldr             x3, [x3, #0xa70]
    // 0x53a86c: b               #0x53a874
    // 0x53a870: mov             x3, x1
    // 0x53a874: mov             x1, x0
    // 0x53a878: ldur            x2, [fp, #-8]
    // 0x53a87c: stur            x3, [fp, #-0x28]
    // 0x53a880: r0 = _getValueOrData()
    //     0x53a880: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53a884: mov             x1, x0
    // 0x53a888: ldur            x0, [fp, #-0x18]
    // 0x53a88c: LoadField: r2 = r0->field_f
    //     0x53a88c: ldur            w2, [x0, #0xf]
    // 0x53a890: DecompressPointer r2
    //     0x53a890: add             x2, x2, HEAP, lsl #32
    // 0x53a894: cmp             w2, w1
    // 0x53a898: b.ne            #0x53a8a4
    // 0x53a89c: r0 = Null
    //     0x53a89c: mov             x0, NULL
    // 0x53a8a0: b               #0x53a8a8
    // 0x53a8a4: mov             x0, x1
    // 0x53a8a8: cmp             w0, NULL
    // 0x53a8ac: b.ne            #0x53a8b8
    // 0x53a8b0: r0 = Null
    //     0x53a8b0: mov             x0, NULL
    // 0x53a8b4: b               #0x53a8c4
    // 0x53a8b8: LoadField: r1 = r0->field_13
    //     0x53a8b8: ldur            w1, [x0, #0x13]
    // 0x53a8bc: DecompressPointer r1
    //     0x53a8bc: add             x1, x1, HEAP, lsl #32
    // 0x53a8c0: mov             x0, x1
    // 0x53a8c4: cmp             w0, NULL
    // 0x53a8c8: b.ne            #0x53a8d8
    // 0x53a8cc: r3 = Instance_CustomNum
    //     0x53a8cc: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x53a8d0: ldr             x3, [x3, #0xa70]
    // 0x53a8d4: b               #0x53a8dc
    // 0x53a8d8: mov             x3, x0
    // 0x53a8dc: ldur            x2, [fp, #-0x10]
    // 0x53a8e0: stur            x3, [fp, #-0x18]
    // 0x53a8e4: r0 = LoadStaticField(0xf7c)
    //     0x53a8e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x53a8e8: ldr             x0, [x0, #0x1ef8]
    // 0x53a8ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x53a8f0: cmp             w0, w16
    // 0x53a8f4: b.eq            #0x53a9ac
    // 0x53a8f8: stur            x0, [fp, #-8]
    // 0x53a8fc: LoadField: r1 = r2->field_23
    //     0x53a8fc: ldur            x1, [x2, #0x23]
    // 0x53a900: r0 = difficultyMultiplier()
    //     0x53a900: bl              #0x4e9a04  ; [package:pretentious/widgets/difficulty_indicator.dart] ::difficultyMultiplier
    // 0x53a904: mov             x3, x0
    // 0x53a908: ldur            x2, [fp, #-0x10]
    // 0x53a90c: stur            x3, [fp, #-0x30]
    // 0x53a910: r0 = LoadClassIdInstr(r2)
    //     0x53a910: ldur            x0, [x2, #-1]
    //     0x53a914: ubfx            x0, x0, #0xc, #0x14
    // 0x53a918: mov             x1, x2
    // 0x53a91c: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x53a91c: sub             lr, x0, #0xf3f
    //     0x53a920: ldr             lr, [x21, lr, lsl #3]
    //     0x53a924: blr             lr
    // 0x53a928: ldur            x1, [fp, #-8]
    // 0x53a92c: ldur            x2, [fp, #-0x30]
    // 0x53a930: mov             x3, x0
    // 0x53a934: r0 = cachedCompletionTokenBoost()
    //     0x53a934: bl              #0x46109c  ; [package:pretentious/data/CoreData.dart] CoreData::cachedCompletionTokenBoost
    // 0x53a938: mov             x1, x0
    // 0x53a93c: ldur            x0, [fp, #-0x10]
    // 0x53a940: stur            x1, [fp, #-0x30]
    // 0x53a944: LoadField: r2 = r0->field_7
    //     0x53a944: ldur            w2, [x0, #7]
    // 0x53a948: DecompressPointer r2
    //     0x53a948: add             x2, x2, HEAP, lsl #32
    // 0x53a94c: stur            x2, [fp, #-8]
    // 0x53a950: ldur            x16, [fp, #-0x20]
    // 0x53a954: stp             x16, x2, [SP, #8]
    // 0x53a958: ldur            x16, [fp, #-0x28]
    // 0x53a95c: str             x16, [SP]
    // 0x53a960: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53a960: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53a964: r0 = TupleOperations.multiplyCustomNum()
    //     0x53a964: bl              #0x53a9b8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::TupleOperations.multiplyCustomNum
    // 0x53a968: ldur            x16, [fp, #-8]
    // 0x53a96c: stp             x0, x16, [SP, #8]
    // 0x53a970: ldur            x16, [fp, #-0x18]
    // 0x53a974: str             x16, [SP]
    // 0x53a978: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53a978: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53a97c: r0 = TupleOperations.multiplyCustomNum()
    //     0x53a97c: bl              #0x53a9b8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::TupleOperations.multiplyCustomNum
    // 0x53a980: ldur            x16, [fp, #-8]
    // 0x53a984: stp             x0, x16, [SP, #8]
    // 0x53a988: ldur            x16, [fp, #-0x30]
    // 0x53a98c: str             x16, [SP]
    // 0x53a990: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53a990: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53a994: r0 = TupleOperations.multiplyCustomNum()
    //     0x53a994: bl              #0x53a9b8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::TupleOperations.multiplyCustomNum
    // 0x53a998: LeaveFrame
    //     0x53a998: mov             SP, fp
    //     0x53a99c: ldp             fp, lr, [SP], #0x10
    // 0x53a9a0: ret
    //     0x53a9a0: ret             
    // 0x53a9a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53a9a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53a9a8: b               #0x53a7ac
    // 0x53a9ac: r9 = coreData
    //     0x53a9ac: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x53a9b0: ldr             x9, [x9, #0x530]
    // 0x53a9b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x53a9b4: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Map<X0, CustomNum> computeUnboostedIncomePerSecond(dynamic) {
    // ** addr: 0x53b0c0, size: 0x12e4
    // 0x53b0c0: EnterFrame
    //     0x53b0c0: stp             fp, lr, [SP, #-0x10]!
    //     0x53b0c4: mov             fp, SP
    // 0x53b0c8: AllocStack(0x80)
    //     0x53b0c8: sub             SP, SP, #0x80
    // 0x53b0cc: SetupParameters([dynamic _ /* r0 */])
    //     0x53b0cc: ldr             x0, [fp, #0x10]
    //     0x53b0d0: ldur            w4, [x0, #0x17]
    //     0x53b0d4: add             x4, x4, HEAP, lsl #32
    //     0x53b0d8: stur            x4, [fp, #-8]
    // 0x53b0dc: CheckStackOverflow
    //     0x53b0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53b0e0: cmp             SP, x16
    //     0x53b0e4: b.ls            #0x53c34c
    // 0x53b0e8: LoadField: r0 = r4->field_f
    //     0x53b0e8: ldur            w0, [x4, #0xf]
    // 0x53b0ec: DecompressPointer r0
    //     0x53b0ec: add             x0, x0, HEAP, lsl #32
    // 0x53b0f0: LoadField: r2 = r0->field_7
    //     0x53b0f0: ldur            w2, [x0, #7]
    // 0x53b0f4: DecompressPointer r2
    //     0x53b0f4: add             x2, x2, HEAP, lsl #32
    // 0x53b0f8: r1 = Null
    //     0x53b0f8: mov             x1, NULL
    // 0x53b0fc: r3 = <X0, CustomNum>
    //     0x53b0fc: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x53b100: ldr             x3, [x3, #0xb10]
    // 0x53b104: r30 = InstantiateTypeArgumentsStub
    //     0x53b104: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53b108: LoadField: r30 = r30->field_7
    //     0x53b108: ldur            lr, [lr, #7]
    // 0x53b10c: blr             lr
    // 0x53b110: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x53b114: stp             x16, x0, [SP]
    // 0x53b118: r0 = Map._fromLiteral()
    //     0x53b118: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x53b11c: ldur            x2, [fp, #-8]
    // 0x53b120: stur            x0, [fp, #-0x18]
    // 0x53b124: LoadField: r1 = r2->field_f
    //     0x53b124: ldur            w1, [x2, #0xf]
    // 0x53b128: DecompressPointer r1
    //     0x53b128: add             x1, x1, HEAP, lsl #32
    // 0x53b12c: LoadField: r3 = r1->field_47
    //     0x53b12c: ldur            w3, [x1, #0x47]
    // 0x53b130: DecompressPointer r3
    //     0x53b130: add             x3, x3, HEAP, lsl #32
    // 0x53b134: stur            x3, [fp, #-0x10]
    // 0x53b138: LoadField: r1 = r3->field_7
    //     0x53b138: ldur            w1, [x3, #7]
    // 0x53b13c: DecompressPointer r1
    //     0x53b13c: add             x1, x1, HEAP, lsl #32
    // 0x53b140: r0 = _CompactKeysIterable()
    //     0x53b140: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x53b144: mov             x1, x0
    // 0x53b148: ldur            x0, [fp, #-0x10]
    // 0x53b14c: StoreField: r1->field_b = r0
    //     0x53b14c: stur            w0, [x1, #0xb]
    // 0x53b150: r0 = toSet()
    //     0x53b150: bl              #0x3de23c  ; [dart:core] _GrowableList::toSet
    // 0x53b154: mov             x3, x0
    // 0x53b158: ldur            x2, [fp, #-8]
    // 0x53b15c: stur            x3, [fp, #-0x10]
    // 0x53b160: LoadField: r1 = r2->field_f
    //     0x53b160: ldur            w1, [x2, #0xf]
    // 0x53b164: DecompressPointer r1
    //     0x53b164: add             x1, x1, HEAP, lsl #32
    // 0x53b168: r0 = LoadClassIdInstr(r1)
    //     0x53b168: ldur            x0, [x1, #-1]
    //     0x53b16c: ubfx            x0, x0, #0xc, #0x14
    // 0x53b170: r0 = GDT[cid_x0 + 0x8702]()
    //     0x53b170: movz            x17, #0x8702
    //     0x53b174: add             lr, x0, x17
    //     0x53b178: ldr             lr, [x21, lr, lsl #3]
    //     0x53b17c: blr             lr
    // 0x53b180: stur            x0, [fp, #-0x20]
    // 0x53b184: LoadField: r1 = r0->field_7
    //     0x53b184: ldur            w1, [x0, #7]
    // 0x53b188: DecompressPointer r1
    //     0x53b188: add             x1, x1, HEAP, lsl #32
    // 0x53b18c: r0 = _CompactKeysIterable()
    //     0x53b18c: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x53b190: mov             x3, x0
    // 0x53b194: ldur            x0, [fp, #-0x20]
    // 0x53b198: stur            x3, [fp, #-0x28]
    // 0x53b19c: StoreField: r3->field_b = r0
    //     0x53b19c: stur            w0, [x3, #0xb]
    // 0x53b1a0: ldur            x2, [fp, #-8]
    // 0x53b1a4: r1 = Function '<anonymous closure>':.
    //     0x53b1a4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16f20] AnonymousClosure: (0x53c3a4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::applyTimeSlice (0x538318)
    //     0x53b1a8: ldr             x1, [x1, #0xf20]
    // 0x53b1ac: r0 = AllocateClosure()
    //     0x53b1ac: bl              #0x826750  ; AllocateClosureStub
    // 0x53b1b0: ldur            x1, [fp, #-0x28]
    // 0x53b1b4: mov             x2, x0
    // 0x53b1b8: r0 = where()
    //     0x53b1b8: bl              #0x54f694  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x53b1bc: ldur            x1, [fp, #-0x10]
    // 0x53b1c0: mov             x2, x0
    // 0x53b1c4: r0 = addAll()
    //     0x53b1c4: bl              #0x7ad7e0  ; [dart:_compact_hash] _Set::addAll
    // 0x53b1c8: ldur            x1, [fp, #-0x10]
    // 0x53b1cc: r0 = iterator()
    //     0x53b1cc: bl              #0x6530c0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x53b1d0: stur            x0, [fp, #-0x20]
    // 0x53b1d4: LoadField: r2 = r0->field_7
    //     0x53b1d4: ldur            w2, [x0, #7]
    // 0x53b1d8: DecompressPointer r2
    //     0x53b1d8: add             x2, x2, HEAP, lsl #32
    // 0x53b1dc: stur            x2, [fp, #-0x10]
    // 0x53b1e0: ldur            x3, [fp, #-8]
    // 0x53b1e4: CheckStackOverflow
    //     0x53b1e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53b1e8: cmp             SP, x16
    //     0x53b1ec: b.ls            #0x53c354
    // 0x53b1f0: mov             x1, x0
    // 0x53b1f4: r0 = moveNext()
    //     0x53b1f4: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x53b1f8: tbnz            w0, #4, #0x53be20
    // 0x53b1fc: ldur            x3, [fp, #-0x20]
    // 0x53b200: LoadField: r4 = r3->field_33
    //     0x53b200: ldur            w4, [x3, #0x33]
    // 0x53b204: DecompressPointer r4
    //     0x53b204: add             x4, x4, HEAP, lsl #32
    // 0x53b208: stur            x4, [fp, #-0x28]
    // 0x53b20c: cmp             w4, NULL
    // 0x53b210: b.ne            #0x53b244
    // 0x53b214: mov             x0, x4
    // 0x53b218: ldur            x2, [fp, #-0x10]
    // 0x53b21c: r1 = Null
    //     0x53b21c: mov             x1, NULL
    // 0x53b220: cmp             w2, NULL
    // 0x53b224: b.eq            #0x53b244
    // 0x53b228: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53b228: ldur            w4, [x2, #0x17]
    // 0x53b22c: DecompressPointer r4
    //     0x53b22c: add             x4, x4, HEAP, lsl #32
    // 0x53b230: r8 = X0
    //     0x53b230: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53b234: LoadField: r9 = r4->field_7
    //     0x53b234: ldur            x9, [x4, #7]
    // 0x53b238: r3 = Null
    //     0x53b238: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f28] Null
    //     0x53b23c: ldr             x3, [x3, #0xf28]
    // 0x53b240: blr             x9
    // 0x53b244: ldur            x3, [fp, #-8]
    // 0x53b248: LoadField: r1 = r3->field_f
    //     0x53b248: ldur            w1, [x3, #0xf]
    // 0x53b24c: DecompressPointer r1
    //     0x53b24c: add             x1, x1, HEAP, lsl #32
    // 0x53b250: r0 = LoadClassIdInstr(r1)
    //     0x53b250: ldur            x0, [x1, #-1]
    //     0x53b254: ubfx            x0, x0, #0xc, #0x14
    // 0x53b258: ldur            x2, [fp, #-0x28]
    // 0x53b25c: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x53b25c: sub             lr, x0, #0xcb6
    //     0x53b260: ldr             lr, [x21, lr, lsl #3]
    //     0x53b264: blr             lr
    // 0x53b268: LoadField: r1 = r0->field_1f
    //     0x53b268: ldur            w1, [x0, #0x1f]
    // 0x53b26c: DecompressPointer r1
    //     0x53b26c: add             x1, x1, HEAP, lsl #32
    // 0x53b270: cmp             w1, NULL
    // 0x53b274: b.ne            #0x53be14
    // 0x53b278: ldur            x0, [fp, #-8]
    // 0x53b27c: LoadField: r1 = r0->field_f
    //     0x53b27c: ldur            w1, [x0, #0xf]
    // 0x53b280: DecompressPointer r1
    //     0x53b280: add             x1, x1, HEAP, lsl #32
    // 0x53b284: LoadField: r3 = r1->field_47
    //     0x53b284: ldur            w3, [x1, #0x47]
    // 0x53b288: DecompressPointer r3
    //     0x53b288: add             x3, x3, HEAP, lsl #32
    // 0x53b28c: mov             x1, x3
    // 0x53b290: ldur            x2, [fp, #-0x28]
    // 0x53b294: stur            x3, [fp, #-0x30]
    // 0x53b298: r0 = _getValueOrData()
    //     0x53b298: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53b29c: mov             x1, x0
    // 0x53b2a0: ldur            x0, [fp, #-0x30]
    // 0x53b2a4: LoadField: r2 = r0->field_f
    //     0x53b2a4: ldur            w2, [x0, #0xf]
    // 0x53b2a8: DecompressPointer r2
    //     0x53b2a8: add             x2, x2, HEAP, lsl #32
    // 0x53b2ac: cmp             w2, w1
    // 0x53b2b0: b.ne            #0x53b2bc
    // 0x53b2b4: r0 = Null
    //     0x53b2b4: mov             x0, NULL
    // 0x53b2b8: b               #0x53b2c0
    // 0x53b2bc: mov             x0, x1
    // 0x53b2c0: cmp             w0, NULL
    // 0x53b2c4: b.ne            #0x53b2d0
    // 0x53b2c8: r2 = 0
    //     0x53b2c8: movz            x2, #0
    // 0x53b2cc: b               #0x53b2d4
    // 0x53b2d0: mov             x2, x0
    // 0x53b2d4: ldur            x0, [fp, #-8]
    // 0x53b2d8: r1 = Null
    //     0x53b2d8: mov             x1, NULL
    // 0x53b2dc: r0 = CustomNum()
    //     0x53b2dc: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x53b2e0: mov             x3, x0
    // 0x53b2e4: ldur            x2, [fp, #-8]
    // 0x53b2e8: stur            x3, [fp, #-0x38]
    // 0x53b2ec: LoadField: r1 = r2->field_f
    //     0x53b2ec: ldur            w1, [x2, #0xf]
    // 0x53b2f0: DecompressPointer r1
    //     0x53b2f0: add             x1, x1, HEAP, lsl #32
    // 0x53b2f4: LoadField: r4 = r1->field_37
    //     0x53b2f4: ldur            w4, [x1, #0x37]
    // 0x53b2f8: DecompressPointer r4
    //     0x53b2f8: add             x4, x4, HEAP, lsl #32
    // 0x53b2fc: stur            x4, [fp, #-0x30]
    // 0x53b300: r0 = LoadClassIdInstr(r1)
    //     0x53b300: ldur            x0, [x1, #-1]
    //     0x53b304: ubfx            x0, x0, #0xc, #0x14
    // 0x53b308: r0 = GDT[cid_x0 + 0x8702]()
    //     0x53b308: movz            x17, #0x8702
    //     0x53b30c: add             lr, x0, x17
    //     0x53b310: ldr             lr, [x21, lr, lsl #3]
    //     0x53b314: blr             lr
    // 0x53b318: mov             x1, x0
    // 0x53b31c: ldur            x2, [fp, #-0x28]
    // 0x53b320: stur            x0, [fp, #-0x40]
    // 0x53b324: r0 = _getValueOrData()
    //     0x53b324: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53b328: mov             x1, x0
    // 0x53b32c: ldur            x0, [fp, #-0x40]
    // 0x53b330: LoadField: r2 = r0->field_f
    //     0x53b330: ldur            w2, [x0, #0xf]
    // 0x53b334: DecompressPointer r2
    //     0x53b334: add             x2, x2, HEAP, lsl #32
    // 0x53b338: cmp             w2, w1
    // 0x53b33c: b.ne            #0x53b348
    // 0x53b340: r2 = Null
    //     0x53b340: mov             x2, NULL
    // 0x53b344: b               #0x53b34c
    // 0x53b348: mov             x2, x1
    // 0x53b34c: ldur            x0, [fp, #-0x30]
    // 0x53b350: mov             x1, x0
    // 0x53b354: r0 = _getValueOrData()
    //     0x53b354: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53b358: mov             x1, x0
    // 0x53b35c: ldur            x0, [fp, #-0x30]
    // 0x53b360: LoadField: r2 = r0->field_f
    //     0x53b360: ldur            w2, [x0, #0xf]
    // 0x53b364: DecompressPointer r2
    //     0x53b364: add             x2, x2, HEAP, lsl #32
    // 0x53b368: cmp             w2, w1
    // 0x53b36c: b.ne            #0x53b378
    // 0x53b370: r0 = Null
    //     0x53b370: mov             x0, NULL
    // 0x53b374: b               #0x53b37c
    // 0x53b378: mov             x0, x1
    // 0x53b37c: cmp             w0, NULL
    // 0x53b380: b.ne            #0x53b390
    // 0x53b384: r2 = Instance_CustomNum
    //     0x53b384: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x53b388: ldr             x2, [x2, #0xaf8]
    // 0x53b38c: b               #0x53b394
    // 0x53b390: mov             x2, x0
    // 0x53b394: ldur            x1, [fp, #-0x38]
    // 0x53b398: r0 = add()
    //     0x53b398: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x53b39c: mov             x2, x0
    // 0x53b3a0: stur            x2, [fp, #-0x30]
    // 0x53b3a4: r0 = LoadStaticField(0xa6c)
    //     0x53b3a4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x53b3a8: ldr             x0, [x0, #0x14d8]
    // 0x53b3ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x53b3b0: cmp             w0, w16
    // 0x53b3b4: b.eq            #0x53c35c
    // 0x53b3b8: mov             x1, x0
    // 0x53b3bc: r0 = get()
    //     0x53b3bc: bl              #0x372f24  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::get
    // 0x53b3c0: mov             x3, x0
    // 0x53b3c4: stur            x3, [fp, #-0x38]
    // 0x53b3c8: r0 = 60
    //     0x53b3c8: movz            x0, #0x3c
    // 0x53b3cc: branchIfSmi(r3, 0x53b3d8)
    //     0x53b3cc: tbz             w3, #0, #0x53b3d8
    // 0x53b3d0: r0 = LoadClassIdInstr(r3)
    //     0x53b3d0: ldur            x0, [x3, #-1]
    //     0x53b3d4: ubfx            x0, x0, #0xc, #0x14
    // 0x53b3d8: sub             x16, x0, #0x3c
    // 0x53b3dc: cmp             x16, #1
    // 0x53b3e0: b.hi            #0x53b410
    // 0x53b3e4: r0 = 60
    //     0x53b3e4: movz            x0, #0x3c
    // 0x53b3e8: branchIfSmi(r3, 0x53b3f4)
    //     0x53b3e8: tbz             w3, #0, #0x53b3f4
    // 0x53b3ec: r0 = LoadClassIdInstr(r3)
    //     0x53b3ec: ldur            x0, [x3, #-1]
    //     0x53b3f0: ubfx            x0, x0, #0xc, #0x14
    // 0x53b3f4: str             x3, [SP]
    // 0x53b3f8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x53b3f8: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x53b3fc: r0 = GDT[cid_x0 + 0x3019]()
    //     0x53b3fc: movz            x17, #0x3019
    //     0x53b400: add             lr, x0, x17
    //     0x53b404: ldr             lr, [x21, lr, lsl #3]
    //     0x53b408: blr             lr
    // 0x53b40c: b               #0x53b45c
    // 0x53b410: mov             x0, x3
    // 0x53b414: r2 = Null
    //     0x53b414: mov             x2, NULL
    // 0x53b418: r1 = Null
    //     0x53b418: mov             x1, NULL
    // 0x53b41c: r4 = 60
    //     0x53b41c: movz            x4, #0x3c
    // 0x53b420: branchIfSmi(r0, 0x53b42c)
    //     0x53b420: tbz             w0, #0, #0x53b42c
    // 0x53b424: r4 = LoadClassIdInstr(r0)
    //     0x53b424: ldur            x4, [x0, #-1]
    //     0x53b428: ubfx            x4, x4, #0xc, #0x14
    // 0x53b42c: sub             x4, x4, #0x5e
    // 0x53b430: cmp             x4, #1
    // 0x53b434: b.ls            #0x53b448
    // 0x53b438: r8 = String?
    //     0x53b438: ldr             x8, [PP, #0xaf0]  ; [pp+0xaf0] Type: String?
    // 0x53b43c: r3 = Null
    //     0x53b43c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f38] Null
    //     0x53b440: ldr             x3, [x3, #0xf38]
    // 0x53b444: r0 = String?()
    //     0x53b444: bl              #0x32906c  ; IsType_String?_Stub
    // 0x53b448: ldur            x0, [fp, #-0x38]
    // 0x53b44c: cmp             w0, NULL
    // 0x53b450: b.ne            #0x53b45c
    // 0x53b454: r0 = "1"
    //     0x53b454: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x53b458: ldr             x0, [x0, #0x9c8]
    // 0x53b45c: r1 = LoadClassIdInstr(r0)
    //     0x53b45c: ldur            x1, [x0, #-1]
    //     0x53b460: ubfx            x1, x1, #0xc, #0x14
    // 0x53b464: r16 = "14"
    //     0x53b464: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] "14"
    //     0x53b468: ldr             x16, [x16, #0x340]
    // 0x53b46c: stp             x16, x0, [SP]
    // 0x53b470: mov             x0, x1
    // 0x53b474: mov             lr, x0
    // 0x53b478: ldr             lr, [x21, lr, lsl #3]
    // 0x53b47c: blr             lr
    // 0x53b480: tbz             w0, #4, #0x53b6f4
    // 0x53b484: r1 = LoadStaticField(0xa6c)
    //     0x53b484: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x53b488: ldr             x1, [x1, #0x14d8]
    // 0x53b48c: r0 = get()
    //     0x53b48c: bl              #0x372f24  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::get
    // 0x53b490: mov             x3, x0
    // 0x53b494: stur            x3, [fp, #-0x38]
    // 0x53b498: r0 = 60
    //     0x53b498: movz            x0, #0x3c
    // 0x53b49c: branchIfSmi(r3, 0x53b4a8)
    //     0x53b49c: tbz             w3, #0, #0x53b4a8
    // 0x53b4a0: r0 = LoadClassIdInstr(r3)
    //     0x53b4a0: ldur            x0, [x3, #-1]
    //     0x53b4a4: ubfx            x0, x0, #0xc, #0x14
    // 0x53b4a8: sub             x16, x0, #0x3c
    // 0x53b4ac: cmp             x16, #1
    // 0x53b4b0: b.hi            #0x53b4e0
    // 0x53b4b4: r0 = 60
    //     0x53b4b4: movz            x0, #0x3c
    // 0x53b4b8: branchIfSmi(r3, 0x53b4c4)
    //     0x53b4b8: tbz             w3, #0, #0x53b4c4
    // 0x53b4bc: r0 = LoadClassIdInstr(r3)
    //     0x53b4bc: ldur            x0, [x3, #-1]
    //     0x53b4c0: ubfx            x0, x0, #0xc, #0x14
    // 0x53b4c4: str             x3, [SP]
    // 0x53b4c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x53b4c8: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x53b4cc: r0 = GDT[cid_x0 + 0x3019]()
    //     0x53b4cc: movz            x17, #0x3019
    //     0x53b4d0: add             lr, x0, x17
    //     0x53b4d4: ldr             lr, [x21, lr, lsl #3]
    //     0x53b4d8: blr             lr
    // 0x53b4dc: b               #0x53b52c
    // 0x53b4e0: mov             x0, x3
    // 0x53b4e4: r2 = Null
    //     0x53b4e4: mov             x2, NULL
    // 0x53b4e8: r1 = Null
    //     0x53b4e8: mov             x1, NULL
    // 0x53b4ec: r4 = 60
    //     0x53b4ec: movz            x4, #0x3c
    // 0x53b4f0: branchIfSmi(r0, 0x53b4fc)
    //     0x53b4f0: tbz             w0, #0, #0x53b4fc
    // 0x53b4f4: r4 = LoadClassIdInstr(r0)
    //     0x53b4f4: ldur            x4, [x0, #-1]
    //     0x53b4f8: ubfx            x4, x4, #0xc, #0x14
    // 0x53b4fc: sub             x4, x4, #0x5e
    // 0x53b500: cmp             x4, #1
    // 0x53b504: b.ls            #0x53b518
    // 0x53b508: r8 = String?
    //     0x53b508: ldr             x8, [PP, #0xaf0]  ; [pp+0xaf0] Type: String?
    // 0x53b50c: r3 = Null
    //     0x53b50c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f48] Null
    //     0x53b510: ldr             x3, [x3, #0xf48]
    // 0x53b514: r0 = String?()
    //     0x53b514: bl              #0x32906c  ; IsType_String?_Stub
    // 0x53b518: ldur            x0, [fp, #-0x38]
    // 0x53b51c: cmp             w0, NULL
    // 0x53b520: b.ne            #0x53b52c
    // 0x53b524: r0 = "1"
    //     0x53b524: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x53b528: ldr             x0, [x0, #0x9c8]
    // 0x53b52c: r1 = LoadClassIdInstr(r0)
    //     0x53b52c: ldur            x1, [x0, #-1]
    //     0x53b530: ubfx            x1, x1, #0xc, #0x14
    // 0x53b534: r16 = "15"
    //     0x53b534: add             x16, PP, #0xf, lsl #12  ; [pp+0xf348] "15"
    //     0x53b538: ldr             x16, [x16, #0x348]
    // 0x53b53c: stp             x16, x0, [SP]
    // 0x53b540: mov             x0, x1
    // 0x53b544: mov             lr, x0
    // 0x53b548: ldr             lr, [x21, lr, lsl #3]
    // 0x53b54c: blr             lr
    // 0x53b550: tbz             w0, #4, #0x53b6f4
    // 0x53b554: r1 = LoadStaticField(0xa6c)
    //     0x53b554: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x53b558: ldr             x1, [x1, #0x14d8]
    // 0x53b55c: r0 = get()
    //     0x53b55c: bl              #0x372f24  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::get
    // 0x53b560: mov             x3, x0
    // 0x53b564: stur            x3, [fp, #-0x38]
    // 0x53b568: r0 = 60
    //     0x53b568: movz            x0, #0x3c
    // 0x53b56c: branchIfSmi(r3, 0x53b578)
    //     0x53b56c: tbz             w3, #0, #0x53b578
    // 0x53b570: r0 = LoadClassIdInstr(r3)
    //     0x53b570: ldur            x0, [x3, #-1]
    //     0x53b574: ubfx            x0, x0, #0xc, #0x14
    // 0x53b578: sub             x16, x0, #0x3c
    // 0x53b57c: cmp             x16, #1
    // 0x53b580: b.hi            #0x53b5b0
    // 0x53b584: r0 = 60
    //     0x53b584: movz            x0, #0x3c
    // 0x53b588: branchIfSmi(r3, 0x53b594)
    //     0x53b588: tbz             w3, #0, #0x53b594
    // 0x53b58c: r0 = LoadClassIdInstr(r3)
    //     0x53b58c: ldur            x0, [x3, #-1]
    //     0x53b590: ubfx            x0, x0, #0xc, #0x14
    // 0x53b594: str             x3, [SP]
    // 0x53b598: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x53b598: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x53b59c: r0 = GDT[cid_x0 + 0x3019]()
    //     0x53b59c: movz            x17, #0x3019
    //     0x53b5a0: add             lr, x0, x17
    //     0x53b5a4: ldr             lr, [x21, lr, lsl #3]
    //     0x53b5a8: blr             lr
    // 0x53b5ac: b               #0x53b5fc
    // 0x53b5b0: mov             x0, x3
    // 0x53b5b4: r2 = Null
    //     0x53b5b4: mov             x2, NULL
    // 0x53b5b8: r1 = Null
    //     0x53b5b8: mov             x1, NULL
    // 0x53b5bc: r4 = 60
    //     0x53b5bc: movz            x4, #0x3c
    // 0x53b5c0: branchIfSmi(r0, 0x53b5cc)
    //     0x53b5c0: tbz             w0, #0, #0x53b5cc
    // 0x53b5c4: r4 = LoadClassIdInstr(r0)
    //     0x53b5c4: ldur            x4, [x0, #-1]
    //     0x53b5c8: ubfx            x4, x4, #0xc, #0x14
    // 0x53b5cc: sub             x4, x4, #0x5e
    // 0x53b5d0: cmp             x4, #1
    // 0x53b5d4: b.ls            #0x53b5e8
    // 0x53b5d8: r8 = String?
    //     0x53b5d8: ldr             x8, [PP, #0xaf0]  ; [pp+0xaf0] Type: String?
    // 0x53b5dc: r3 = Null
    //     0x53b5dc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f58] Null
    //     0x53b5e0: ldr             x3, [x3, #0xf58]
    // 0x53b5e4: r0 = String?()
    //     0x53b5e4: bl              #0x32906c  ; IsType_String?_Stub
    // 0x53b5e8: ldur            x0, [fp, #-0x38]
    // 0x53b5ec: cmp             w0, NULL
    // 0x53b5f0: b.ne            #0x53b5fc
    // 0x53b5f4: r0 = "1"
    //     0x53b5f4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x53b5f8: ldr             x0, [x0, #0x9c8]
    // 0x53b5fc: r1 = LoadClassIdInstr(r0)
    //     0x53b5fc: ldur            x1, [x0, #-1]
    //     0x53b600: ubfx            x1, x1, #0xc, #0x14
    // 0x53b604: r16 = "16"
    //     0x53b604: add             x16, PP, #0xf, lsl #12  ; [pp+0xf350] "16"
    //     0x53b608: ldr             x16, [x16, #0x350]
    // 0x53b60c: stp             x16, x0, [SP]
    // 0x53b610: mov             x0, x1
    // 0x53b614: mov             lr, x0
    // 0x53b618: ldr             lr, [x21, lr, lsl #3]
    // 0x53b61c: blr             lr
    // 0x53b620: tbz             w0, #4, #0x53b6f4
    // 0x53b624: r1 = LoadStaticField(0xa6c)
    //     0x53b624: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x53b628: ldr             x1, [x1, #0x14d8]
    // 0x53b62c: r0 = get()
    //     0x53b62c: bl              #0x372f24  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::get
    // 0x53b630: mov             x3, x0
    // 0x53b634: stur            x3, [fp, #-0x38]
    // 0x53b638: r0 = 60
    //     0x53b638: movz            x0, #0x3c
    // 0x53b63c: branchIfSmi(r3, 0x53b648)
    //     0x53b63c: tbz             w3, #0, #0x53b648
    // 0x53b640: r0 = LoadClassIdInstr(r3)
    //     0x53b640: ldur            x0, [x3, #-1]
    //     0x53b644: ubfx            x0, x0, #0xc, #0x14
    // 0x53b648: sub             x16, x0, #0x3c
    // 0x53b64c: cmp             x16, #1
    // 0x53b650: b.hi            #0x53b680
    // 0x53b654: r0 = 60
    //     0x53b654: movz            x0, #0x3c
    // 0x53b658: branchIfSmi(r3, 0x53b664)
    //     0x53b658: tbz             w3, #0, #0x53b664
    // 0x53b65c: r0 = LoadClassIdInstr(r3)
    //     0x53b65c: ldur            x0, [x3, #-1]
    //     0x53b660: ubfx            x0, x0, #0xc, #0x14
    // 0x53b664: str             x3, [SP]
    // 0x53b668: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x53b668: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x53b66c: r0 = GDT[cid_x0 + 0x3019]()
    //     0x53b66c: movz            x17, #0x3019
    //     0x53b670: add             lr, x0, x17
    //     0x53b674: ldr             lr, [x21, lr, lsl #3]
    //     0x53b678: blr             lr
    // 0x53b67c: b               #0x53b6cc
    // 0x53b680: mov             x0, x3
    // 0x53b684: r2 = Null
    //     0x53b684: mov             x2, NULL
    // 0x53b688: r1 = Null
    //     0x53b688: mov             x1, NULL
    // 0x53b68c: r4 = 60
    //     0x53b68c: movz            x4, #0x3c
    // 0x53b690: branchIfSmi(r0, 0x53b69c)
    //     0x53b690: tbz             w0, #0, #0x53b69c
    // 0x53b694: r4 = LoadClassIdInstr(r0)
    //     0x53b694: ldur            x4, [x0, #-1]
    //     0x53b698: ubfx            x4, x4, #0xc, #0x14
    // 0x53b69c: sub             x4, x4, #0x5e
    // 0x53b6a0: cmp             x4, #1
    // 0x53b6a4: b.ls            #0x53b6b8
    // 0x53b6a8: r8 = String?
    //     0x53b6a8: ldr             x8, [PP, #0xaf0]  ; [pp+0xaf0] Type: String?
    // 0x53b6ac: r3 = Null
    //     0x53b6ac: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f68] Null
    //     0x53b6b0: ldr             x3, [x3, #0xf68]
    // 0x53b6b4: r0 = String?()
    //     0x53b6b4: bl              #0x32906c  ; IsType_String?_Stub
    // 0x53b6b8: ldur            x0, [fp, #-0x38]
    // 0x53b6bc: cmp             w0, NULL
    // 0x53b6c0: b.ne            #0x53b6cc
    // 0x53b6c4: r0 = "1"
    //     0x53b6c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe9c8] "1"
    //     0x53b6c8: ldr             x0, [x0, #0x9c8]
    // 0x53b6cc: r1 = LoadClassIdInstr(r0)
    //     0x53b6cc: ldur            x1, [x0, #-1]
    //     0x53b6d0: ubfx            x1, x1, #0xc, #0x14
    // 0x53b6d4: r16 = "17"
    //     0x53b6d4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf358] "17"
    //     0x53b6d8: ldr             x16, [x16, #0x358]
    // 0x53b6dc: stp             x16, x0, [SP]
    // 0x53b6e0: mov             x0, x1
    // 0x53b6e4: mov             lr, x0
    // 0x53b6e8: ldr             lr, [x21, lr, lsl #3]
    // 0x53b6ec: blr             lr
    // 0x53b6f0: tbnz            w0, #4, #0x53babc
    // 0x53b6f4: ldur            x0, [fp, #-8]
    // 0x53b6f8: LoadField: r3 = r0->field_f
    //     0x53b6f8: ldur            w3, [x0, #0xf]
    // 0x53b6fc: DecompressPointer r3
    //     0x53b6fc: add             x3, x3, HEAP, lsl #32
    // 0x53b700: stur            x3, [fp, #-0x48]
    // 0x53b704: LoadField: r4 = r3->field_7
    //     0x53b704: ldur            w4, [x3, #7]
    // 0x53b708: DecompressPointer r4
    //     0x53b708: add             x4, x4, HEAP, lsl #32
    // 0x53b70c: stur            x4, [fp, #-0x40]
    // 0x53b710: LoadField: r5 = r3->field_47
    //     0x53b710: ldur            w5, [x3, #0x47]
    // 0x53b714: DecompressPointer r5
    //     0x53b714: add             x5, x5, HEAP, lsl #32
    // 0x53b718: mov             x1, x5
    // 0x53b71c: ldur            x2, [fp, #-0x28]
    // 0x53b720: stur            x5, [fp, #-0x38]
    // 0x53b724: r0 = _getValueOrData()
    //     0x53b724: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53b728: mov             x1, x0
    // 0x53b72c: ldur            x0, [fp, #-0x38]
    // 0x53b730: LoadField: r2 = r0->field_f
    //     0x53b730: ldur            w2, [x0, #0xf]
    // 0x53b734: DecompressPointer r2
    //     0x53b734: add             x2, x2, HEAP, lsl #32
    // 0x53b738: cmp             w2, w1
    // 0x53b73c: b.ne            #0x53b748
    // 0x53b740: r0 = Null
    //     0x53b740: mov             x0, NULL
    // 0x53b744: b               #0x53b74c
    // 0x53b748: mov             x0, x1
    // 0x53b74c: cmp             w0, NULL
    // 0x53b750: b.ne            #0x53b75c
    // 0x53b754: r2 = 0
    //     0x53b754: movz            x2, #0
    // 0x53b758: b               #0x53b760
    // 0x53b75c: mov             x2, x0
    // 0x53b760: ldur            x3, [fp, #-0x30]
    // 0x53b764: ldur            x0, [fp, #-0x48]
    // 0x53b768: ldur            x4, [fp, #-0x28]
    // 0x53b76c: r1 = Null
    //     0x53b76c: mov             x1, NULL
    // 0x53b770: r0 = CustomNum()
    //     0x53b770: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x53b774: ldur            x4, [fp, #-0x28]
    // 0x53b778: r2 = LoadInt32Instr(r4)
    //     0x53b778: sbfx            x2, x4, #1, #0x1f
    //     0x53b77c: tbz             w4, #0, #0x53b784
    //     0x53b780: ldur            x2, [x4, #7]
    // 0x53b784: ldur            x1, [fp, #-0x48]
    // 0x53b788: r3 = LoadClassIdInstr(r1)
    //     0x53b788: ldur            x3, [x1, #-1]
    //     0x53b78c: ubfx            x3, x3, #0xc, #0x14
    // 0x53b790: mov             x16, x0
    // 0x53b794: mov             x0, x3
    // 0x53b798: mov             x3, x16
    // 0x53b79c: r0 = GDT[cid_x0 + 0x8756]()
    //     0x53b79c: movz            x17, #0x8756
    //     0x53b7a0: add             lr, x0, x17
    //     0x53b7a4: ldr             lr, [x21, lr, lsl #3]
    //     0x53b7a8: blr             lr
    // 0x53b7ac: stur            x0, [fp, #-0x48]
    // 0x53b7b0: LoadField: r4 = r0->field_7
    //     0x53b7b0: ldur            w4, [x0, #7]
    // 0x53b7b4: DecompressPointer r4
    //     0x53b7b4: add             x4, x4, HEAP, lsl #32
    // 0x53b7b8: mov             x2, x4
    // 0x53b7bc: stur            x4, [fp, #-0x38]
    // 0x53b7c0: r1 = Null
    //     0x53b7c0: mov             x1, NULL
    // 0x53b7c4: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53b7c4: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x53b7c8: r30 = InstantiateTypeArgumentsStub
    //     0x53b7c8: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53b7cc: LoadField: r30 = r30->field_7
    //     0x53b7cc: ldur            lr, [lr, #7]
    // 0x53b7d0: blr             lr
    // 0x53b7d4: mov             x1, x0
    // 0x53b7d8: r0 = _CompactEntriesIterable()
    //     0x53b7d8: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x53b7dc: mov             x1, x0
    // 0x53b7e0: ldur            x0, [fp, #-0x48]
    // 0x53b7e4: StoreField: r1->field_b = r0
    //     0x53b7e4: stur            w0, [x1, #0xb]
    // 0x53b7e8: r0 = iterator()
    //     0x53b7e8: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x53b7ec: ldur            x4, [fp, #-0x30]
    // 0x53b7f0: stur            x0, [fp, #-0x50]
    // 0x53b7f4: LoadField: d0 = r4->field_7
    //     0x53b7f4: ldur            d0, [x4, #7]
    // 0x53b7f8: stur            d0, [fp, #-0x68]
    // 0x53b7fc: CheckStackOverflow
    //     0x53b7fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53b800: cmp             SP, x16
    //     0x53b804: b.ls            #0x53c368
    // 0x53b808: mov             x1, x0
    // 0x53b80c: r0 = moveNext()
    //     0x53b80c: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x53b810: tbnz            w0, #4, #0x53b8e8
    // 0x53b814: ldur            x0, [fp, #-0x50]
    // 0x53b818: LoadField: r1 = r0->field_2b
    //     0x53b818: ldur            w1, [x0, #0x2b]
    // 0x53b81c: DecompressPointer r1
    //     0x53b81c: add             x1, x1, HEAP, lsl #32
    // 0x53b820: cmp             w1, NULL
    // 0x53b824: b.eq            #0x53c304
    // 0x53b828: ldur            d1, [fp, #-0x68]
    // 0x53b82c: LoadField: r2 = r1->field_b
    //     0x53b82c: ldur            w2, [x1, #0xb]
    // 0x53b830: DecompressPointer r2
    //     0x53b830: add             x2, x2, HEAP, lsl #32
    // 0x53b834: stur            x2, [fp, #-0x58]
    // 0x53b838: LoadField: r3 = r1->field_f
    //     0x53b838: ldur            w3, [x1, #0xf]
    // 0x53b83c: DecompressPointer r3
    //     0x53b83c: add             x3, x3, HEAP, lsl #32
    // 0x53b840: LoadField: d0 = r3->field_7
    //     0x53b840: ldur            d0, [x3, #7]
    // 0x53b844: fadd            d2, d0, d1
    // 0x53b848: mov             v0.16b, v2.16b
    // 0x53b84c: r1 = Null
    //     0x53b84c: mov             x1, NULL
    // 0x53b850: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53b850: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53b854: mov             x3, x0
    // 0x53b858: ldur            x0, [fp, #-0x58]
    // 0x53b85c: ldur            x2, [fp, #-0x38]
    // 0x53b860: r1 = Null
    //     0x53b860: mov             x1, NULL
    // 0x53b864: stur            x3, [fp, #-0x60]
    // 0x53b868: cmp             w2, NULL
    // 0x53b86c: b.eq            #0x53b88c
    // 0x53b870: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53b870: ldur            w4, [x2, #0x17]
    // 0x53b874: DecompressPointer r4
    //     0x53b874: add             x4, x4, HEAP, lsl #32
    // 0x53b878: r8 = X0
    //     0x53b878: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53b87c: LoadField: r9 = r4->field_7
    //     0x53b87c: ldur            x9, [x4, #7]
    // 0x53b880: r3 = Null
    //     0x53b880: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f78] Null
    //     0x53b884: ldr             x3, [x3, #0xf78]
    // 0x53b888: blr             x9
    // 0x53b88c: ldur            x0, [fp, #-0x60]
    // 0x53b890: ldur            x2, [fp, #-0x38]
    // 0x53b894: r1 = Null
    //     0x53b894: mov             x1, NULL
    // 0x53b898: cmp             w2, NULL
    // 0x53b89c: b.eq            #0x53b8bc
    // 0x53b8a0: LoadField: r4 = r2->field_1b
    //     0x53b8a0: ldur            w4, [x2, #0x1b]
    // 0x53b8a4: DecompressPointer r4
    //     0x53b8a4: add             x4, x4, HEAP, lsl #32
    // 0x53b8a8: r8 = X1
    //     0x53b8a8: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x53b8ac: LoadField: r9 = r4->field_7
    //     0x53b8ac: ldur            x9, [x4, #7]
    // 0x53b8b0: r3 = Null
    //     0x53b8b0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f88] Null
    //     0x53b8b4: ldr             x3, [x3, #0xf88]
    // 0x53b8b8: blr             x9
    // 0x53b8bc: ldur            x1, [fp, #-0x48]
    // 0x53b8c0: ldur            x2, [fp, #-0x58]
    // 0x53b8c4: r0 = _hashCode()
    //     0x53b8c4: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x53b8c8: ldur            x1, [fp, #-0x48]
    // 0x53b8cc: ldur            x2, [fp, #-0x58]
    // 0x53b8d0: ldur            x3, [fp, #-0x60]
    // 0x53b8d4: mov             x5, x0
    // 0x53b8d8: r0 = _set()
    //     0x53b8d8: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x53b8dc: ldur            x0, [fp, #-0x50]
    // 0x53b8e0: ldur            d0, [fp, #-0x68]
    // 0x53b8e4: b               #0x53b7fc
    // 0x53b8e8: ldur            x0, [fp, #-8]
    // 0x53b8ec: LoadField: r1 = r0->field_f
    //     0x53b8ec: ldur            w1, [x0, #0xf]
    // 0x53b8f0: DecompressPointer r1
    //     0x53b8f0: add             x1, x1, HEAP, lsl #32
    // 0x53b8f4: LoadField: r3 = r1->field_33
    //     0x53b8f4: ldur            w3, [x1, #0x33]
    // 0x53b8f8: DecompressPointer r3
    //     0x53b8f8: add             x3, x3, HEAP, lsl #32
    // 0x53b8fc: mov             x1, x3
    // 0x53b900: ldur            x2, [fp, #-0x28]
    // 0x53b904: stur            x3, [fp, #-0x50]
    // 0x53b908: r0 = _getValueOrData()
    //     0x53b908: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53b90c: mov             x1, x0
    // 0x53b910: ldur            x0, [fp, #-0x50]
    // 0x53b914: LoadField: r2 = r0->field_f
    //     0x53b914: ldur            w2, [x0, #0xf]
    // 0x53b918: DecompressPointer r2
    //     0x53b918: add             x2, x2, HEAP, lsl #32
    // 0x53b91c: cmp             w2, w1
    // 0x53b920: b.ne            #0x53b92c
    // 0x53b924: r0 = Null
    //     0x53b924: mov             x0, NULL
    // 0x53b928: b               #0x53b930
    // 0x53b92c: mov             x0, x1
    // 0x53b930: cmp             w0, NULL
    // 0x53b934: b.ne            #0x53b940
    // 0x53b938: r0 = Null
    //     0x53b938: mov             x0, NULL
    // 0x53b93c: b               #0x53b94c
    // 0x53b940: LoadField: r1 = r0->field_f
    //     0x53b940: ldur            w1, [x0, #0xf]
    // 0x53b944: DecompressPointer r1
    //     0x53b944: add             x1, x1, HEAP, lsl #32
    // 0x53b948: mov             x0, x1
    // 0x53b94c: cmp             w0, NULL
    // 0x53b950: b.ne            #0x53b960
    // 0x53b954: r4 = Instance_CustomNum
    //     0x53b954: add             x4, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x53b958: ldr             x4, [x4, #0xa70]
    // 0x53b95c: b               #0x53b964
    // 0x53b960: mov             x4, x0
    // 0x53b964: ldur            x0, [fp, #-0x48]
    // 0x53b968: ldur            x2, [fp, #-0x38]
    // 0x53b96c: stur            x4, [fp, #-0x50]
    // 0x53b970: r1 = Null
    //     0x53b970: mov             x1, NULL
    // 0x53b974: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53b974: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x53b978: r30 = InstantiateTypeArgumentsStub
    //     0x53b978: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53b97c: LoadField: r30 = r30->field_7
    //     0x53b97c: ldur            lr, [lr, #7]
    // 0x53b980: blr             lr
    // 0x53b984: mov             x1, x0
    // 0x53b988: r0 = _CompactEntriesIterable()
    //     0x53b988: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x53b98c: mov             x1, x0
    // 0x53b990: ldur            x0, [fp, #-0x48]
    // 0x53b994: StoreField: r1->field_b = r0
    //     0x53b994: stur            w0, [x1, #0xb]
    // 0x53b998: r0 = iterator()
    //     0x53b998: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x53b99c: mov             x2, x0
    // 0x53b9a0: ldur            x0, [fp, #-0x50]
    // 0x53b9a4: stur            x2, [fp, #-0x58]
    // 0x53b9a8: LoadField: d0 = r0->field_7
    //     0x53b9a8: ldur            d0, [x0, #7]
    // 0x53b9ac: stur            d0, [fp, #-0x68]
    // 0x53b9b0: CheckStackOverflow
    //     0x53b9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53b9b4: cmp             SP, x16
    //     0x53b9b8: b.ls            #0x53c370
    // 0x53b9bc: mov             x1, x2
    // 0x53b9c0: r0 = moveNext()
    //     0x53b9c0: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x53b9c4: tbnz            w0, #4, #0x53ba9c
    // 0x53b9c8: ldur            x0, [fp, #-0x58]
    // 0x53b9cc: LoadField: r1 = r0->field_2b
    //     0x53b9cc: ldur            w1, [x0, #0x2b]
    // 0x53b9d0: DecompressPointer r1
    //     0x53b9d0: add             x1, x1, HEAP, lsl #32
    // 0x53b9d4: cmp             w1, NULL
    // 0x53b9d8: b.eq            #0x53c310
    // 0x53b9dc: ldur            d1, [fp, #-0x68]
    // 0x53b9e0: LoadField: r2 = r1->field_b
    //     0x53b9e0: ldur            w2, [x1, #0xb]
    // 0x53b9e4: DecompressPointer r2
    //     0x53b9e4: add             x2, x2, HEAP, lsl #32
    // 0x53b9e8: stur            x2, [fp, #-0x50]
    // 0x53b9ec: LoadField: r3 = r1->field_f
    //     0x53b9ec: ldur            w3, [x1, #0xf]
    // 0x53b9f0: DecompressPointer r3
    //     0x53b9f0: add             x3, x3, HEAP, lsl #32
    // 0x53b9f4: LoadField: d0 = r3->field_7
    //     0x53b9f4: ldur            d0, [x3, #7]
    // 0x53b9f8: fadd            d2, d0, d1
    // 0x53b9fc: mov             v0.16b, v2.16b
    // 0x53ba00: r1 = Null
    //     0x53ba00: mov             x1, NULL
    // 0x53ba04: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53ba04: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53ba08: mov             x3, x0
    // 0x53ba0c: ldur            x0, [fp, #-0x50]
    // 0x53ba10: ldur            x2, [fp, #-0x38]
    // 0x53ba14: r1 = Null
    //     0x53ba14: mov             x1, NULL
    // 0x53ba18: stur            x3, [fp, #-0x60]
    // 0x53ba1c: cmp             w2, NULL
    // 0x53ba20: b.eq            #0x53ba40
    // 0x53ba24: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53ba24: ldur            w4, [x2, #0x17]
    // 0x53ba28: DecompressPointer r4
    //     0x53ba28: add             x4, x4, HEAP, lsl #32
    // 0x53ba2c: r8 = X0
    //     0x53ba2c: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53ba30: LoadField: r9 = r4->field_7
    //     0x53ba30: ldur            x9, [x4, #7]
    // 0x53ba34: r3 = Null
    //     0x53ba34: add             x3, PP, #0x16, lsl #12  ; [pp+0x16f98] Null
    //     0x53ba38: ldr             x3, [x3, #0xf98]
    // 0x53ba3c: blr             x9
    // 0x53ba40: ldur            x0, [fp, #-0x60]
    // 0x53ba44: ldur            x2, [fp, #-0x38]
    // 0x53ba48: r1 = Null
    //     0x53ba48: mov             x1, NULL
    // 0x53ba4c: cmp             w2, NULL
    // 0x53ba50: b.eq            #0x53ba70
    // 0x53ba54: LoadField: r4 = r2->field_1b
    //     0x53ba54: ldur            w4, [x2, #0x1b]
    // 0x53ba58: DecompressPointer r4
    //     0x53ba58: add             x4, x4, HEAP, lsl #32
    // 0x53ba5c: r8 = X1
    //     0x53ba5c: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x53ba60: LoadField: r9 = r4->field_7
    //     0x53ba60: ldur            x9, [x4, #7]
    // 0x53ba64: r3 = Null
    //     0x53ba64: add             x3, PP, #0x16, lsl #12  ; [pp+0x16fa8] Null
    //     0x53ba68: ldr             x3, [x3, #0xfa8]
    // 0x53ba6c: blr             x9
    // 0x53ba70: ldur            x1, [fp, #-0x48]
    // 0x53ba74: ldur            x2, [fp, #-0x50]
    // 0x53ba78: r0 = _hashCode()
    //     0x53ba78: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x53ba7c: ldur            x1, [fp, #-0x48]
    // 0x53ba80: ldur            x2, [fp, #-0x50]
    // 0x53ba84: ldur            x3, [fp, #-0x60]
    // 0x53ba88: mov             x5, x0
    // 0x53ba8c: r0 = _set()
    //     0x53ba8c: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x53ba90: ldur            x2, [fp, #-0x58]
    // 0x53ba94: ldur            d0, [fp, #-0x68]
    // 0x53ba98: b               #0x53b9b0
    // 0x53ba9c: ldur            x16, [fp, #-0x40]
    // 0x53baa0: ldur            lr, [fp, #-0x18]
    // 0x53baa4: stp             lr, x16, [SP, #8]
    // 0x53baa8: ldur            x16, [fp, #-0x48]
    // 0x53baac: str             x16, [SP]
    // 0x53bab0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53bab0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53bab4: r0 = MapOperations.merge()
    //     0x53bab4: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x53bab8: b               #0x53be14
    // 0x53babc: ldur            x5, [fp, #-8]
    // 0x53bac0: ldur            x4, [fp, #-0x30]
    // 0x53bac4: ldur            x6, [fp, #-0x28]
    // 0x53bac8: LoadField: r1 = r5->field_f
    //     0x53bac8: ldur            w1, [x5, #0xf]
    // 0x53bacc: DecompressPointer r1
    //     0x53bacc: add             x1, x1, HEAP, lsl #32
    // 0x53bad0: LoadField: r7 = r1->field_7
    //     0x53bad0: ldur            w7, [x1, #7]
    // 0x53bad4: DecompressPointer r7
    //     0x53bad4: add             x7, x7, HEAP, lsl #32
    // 0x53bad8: stur            x7, [fp, #-0x38]
    // 0x53badc: r2 = LoadInt32Instr(r6)
    //     0x53badc: sbfx            x2, x6, #1, #0x1f
    //     0x53bae0: tbz             w6, #0, #0x53bae8
    //     0x53bae4: ldur            x2, [x6, #7]
    // 0x53bae8: r0 = LoadClassIdInstr(r1)
    //     0x53bae8: ldur            x0, [x1, #-1]
    //     0x53baec: ubfx            x0, x0, #0xc, #0x14
    // 0x53baf0: mov             x3, x4
    // 0x53baf4: r0 = GDT[cid_x0 + 0x8756]()
    //     0x53baf4: movz            x17, #0x8756
    //     0x53baf8: add             lr, x0, x17
    //     0x53bafc: ldr             lr, [x21, lr, lsl #3]
    //     0x53bb00: blr             lr
    // 0x53bb04: stur            x0, [fp, #-0x48]
    // 0x53bb08: LoadField: r4 = r0->field_7
    //     0x53bb08: ldur            w4, [x0, #7]
    // 0x53bb0c: DecompressPointer r4
    //     0x53bb0c: add             x4, x4, HEAP, lsl #32
    // 0x53bb10: mov             x2, x4
    // 0x53bb14: stur            x4, [fp, #-0x40]
    // 0x53bb18: r1 = Null
    //     0x53bb18: mov             x1, NULL
    // 0x53bb1c: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53bb1c: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x53bb20: r30 = InstantiateTypeArgumentsStub
    //     0x53bb20: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53bb24: LoadField: r30 = r30->field_7
    //     0x53bb24: ldur            lr, [lr, #7]
    // 0x53bb28: blr             lr
    // 0x53bb2c: mov             x1, x0
    // 0x53bb30: r0 = _CompactEntriesIterable()
    //     0x53bb30: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x53bb34: mov             x1, x0
    // 0x53bb38: ldur            x0, [fp, #-0x48]
    // 0x53bb3c: StoreField: r1->field_b = r0
    //     0x53bb3c: stur            w0, [x1, #0xb]
    // 0x53bb40: r0 = iterator()
    //     0x53bb40: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x53bb44: mov             x2, x0
    // 0x53bb48: ldur            x0, [fp, #-0x30]
    // 0x53bb4c: stur            x2, [fp, #-0x50]
    // 0x53bb50: LoadField: d0 = r0->field_7
    //     0x53bb50: ldur            d0, [x0, #7]
    // 0x53bb54: stur            d0, [fp, #-0x68]
    // 0x53bb58: CheckStackOverflow
    //     0x53bb58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53bb5c: cmp             SP, x16
    //     0x53bb60: b.ls            #0x53c378
    // 0x53bb64: mov             x1, x2
    // 0x53bb68: r0 = moveNext()
    //     0x53bb68: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x53bb6c: tbnz            w0, #4, #0x53bc44
    // 0x53bb70: ldur            x0, [fp, #-0x50]
    // 0x53bb74: LoadField: r1 = r0->field_2b
    //     0x53bb74: ldur            w1, [x0, #0x2b]
    // 0x53bb78: DecompressPointer r1
    //     0x53bb78: add             x1, x1, HEAP, lsl #32
    // 0x53bb7c: cmp             w1, NULL
    // 0x53bb80: b.eq            #0x53c31c
    // 0x53bb84: ldur            d1, [fp, #-0x68]
    // 0x53bb88: LoadField: r2 = r1->field_b
    //     0x53bb88: ldur            w2, [x1, #0xb]
    // 0x53bb8c: DecompressPointer r2
    //     0x53bb8c: add             x2, x2, HEAP, lsl #32
    // 0x53bb90: stur            x2, [fp, #-0x30]
    // 0x53bb94: LoadField: r3 = r1->field_f
    //     0x53bb94: ldur            w3, [x1, #0xf]
    // 0x53bb98: DecompressPointer r3
    //     0x53bb98: add             x3, x3, HEAP, lsl #32
    // 0x53bb9c: LoadField: d0 = r3->field_7
    //     0x53bb9c: ldur            d0, [x3, #7]
    // 0x53bba0: fadd            d2, d0, d1
    // 0x53bba4: mov             v0.16b, v2.16b
    // 0x53bba8: r1 = Null
    //     0x53bba8: mov             x1, NULL
    // 0x53bbac: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53bbac: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53bbb0: mov             x3, x0
    // 0x53bbb4: ldur            x0, [fp, #-0x30]
    // 0x53bbb8: ldur            x2, [fp, #-0x40]
    // 0x53bbbc: r1 = Null
    //     0x53bbbc: mov             x1, NULL
    // 0x53bbc0: stur            x3, [fp, #-0x58]
    // 0x53bbc4: cmp             w2, NULL
    // 0x53bbc8: b.eq            #0x53bbe8
    // 0x53bbcc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53bbcc: ldur            w4, [x2, #0x17]
    // 0x53bbd0: DecompressPointer r4
    //     0x53bbd0: add             x4, x4, HEAP, lsl #32
    // 0x53bbd4: r8 = X0
    //     0x53bbd4: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53bbd8: LoadField: r9 = r4->field_7
    //     0x53bbd8: ldur            x9, [x4, #7]
    // 0x53bbdc: r3 = Null
    //     0x53bbdc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16fb8] Null
    //     0x53bbe0: ldr             x3, [x3, #0xfb8]
    // 0x53bbe4: blr             x9
    // 0x53bbe8: ldur            x0, [fp, #-0x58]
    // 0x53bbec: ldur            x2, [fp, #-0x40]
    // 0x53bbf0: r1 = Null
    //     0x53bbf0: mov             x1, NULL
    // 0x53bbf4: cmp             w2, NULL
    // 0x53bbf8: b.eq            #0x53bc18
    // 0x53bbfc: LoadField: r4 = r2->field_1b
    //     0x53bbfc: ldur            w4, [x2, #0x1b]
    // 0x53bc00: DecompressPointer r4
    //     0x53bc00: add             x4, x4, HEAP, lsl #32
    // 0x53bc04: r8 = X1
    //     0x53bc04: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x53bc08: LoadField: r9 = r4->field_7
    //     0x53bc08: ldur            x9, [x4, #7]
    // 0x53bc0c: r3 = Null
    //     0x53bc0c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16fc8] Null
    //     0x53bc10: ldr             x3, [x3, #0xfc8]
    // 0x53bc14: blr             x9
    // 0x53bc18: ldur            x1, [fp, #-0x48]
    // 0x53bc1c: ldur            x2, [fp, #-0x30]
    // 0x53bc20: r0 = _hashCode()
    //     0x53bc20: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x53bc24: ldur            x1, [fp, #-0x48]
    // 0x53bc28: ldur            x2, [fp, #-0x30]
    // 0x53bc2c: ldur            x3, [fp, #-0x58]
    // 0x53bc30: mov             x5, x0
    // 0x53bc34: r0 = _set()
    //     0x53bc34: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x53bc38: ldur            x2, [fp, #-0x50]
    // 0x53bc3c: ldur            d0, [fp, #-0x68]
    // 0x53bc40: b               #0x53bb58
    // 0x53bc44: ldur            x0, [fp, #-8]
    // 0x53bc48: LoadField: r1 = r0->field_f
    //     0x53bc48: ldur            w1, [x0, #0xf]
    // 0x53bc4c: DecompressPointer r1
    //     0x53bc4c: add             x1, x1, HEAP, lsl #32
    // 0x53bc50: LoadField: r3 = r1->field_33
    //     0x53bc50: ldur            w3, [x1, #0x33]
    // 0x53bc54: DecompressPointer r3
    //     0x53bc54: add             x3, x3, HEAP, lsl #32
    // 0x53bc58: mov             x1, x3
    // 0x53bc5c: ldur            x2, [fp, #-0x28]
    // 0x53bc60: stur            x3, [fp, #-0x30]
    // 0x53bc64: r0 = _getValueOrData()
    //     0x53bc64: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53bc68: mov             x1, x0
    // 0x53bc6c: ldur            x0, [fp, #-0x30]
    // 0x53bc70: LoadField: r2 = r0->field_f
    //     0x53bc70: ldur            w2, [x0, #0xf]
    // 0x53bc74: DecompressPointer r2
    //     0x53bc74: add             x2, x2, HEAP, lsl #32
    // 0x53bc78: cmp             w2, w1
    // 0x53bc7c: b.ne            #0x53bc88
    // 0x53bc80: r0 = Null
    //     0x53bc80: mov             x0, NULL
    // 0x53bc84: b               #0x53bc8c
    // 0x53bc88: mov             x0, x1
    // 0x53bc8c: cmp             w0, NULL
    // 0x53bc90: b.ne            #0x53bc9c
    // 0x53bc94: r0 = Null
    //     0x53bc94: mov             x0, NULL
    // 0x53bc98: b               #0x53bca8
    // 0x53bc9c: LoadField: r1 = r0->field_f
    //     0x53bc9c: ldur            w1, [x0, #0xf]
    // 0x53bca0: DecompressPointer r1
    //     0x53bca0: add             x1, x1, HEAP, lsl #32
    // 0x53bca4: mov             x0, x1
    // 0x53bca8: cmp             w0, NULL
    // 0x53bcac: b.ne            #0x53bcbc
    // 0x53bcb0: r4 = Instance_CustomNum
    //     0x53bcb0: add             x4, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x53bcb4: ldr             x4, [x4, #0xa70]
    // 0x53bcb8: b               #0x53bcc0
    // 0x53bcbc: mov             x4, x0
    // 0x53bcc0: ldur            x0, [fp, #-0x48]
    // 0x53bcc4: ldur            x2, [fp, #-0x40]
    // 0x53bcc8: stur            x4, [fp, #-0x28]
    // 0x53bccc: r1 = Null
    //     0x53bccc: mov             x1, NULL
    // 0x53bcd0: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53bcd0: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x53bcd4: r30 = InstantiateTypeArgumentsStub
    //     0x53bcd4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53bcd8: LoadField: r30 = r30->field_7
    //     0x53bcd8: ldur            lr, [lr, #7]
    // 0x53bcdc: blr             lr
    // 0x53bce0: mov             x1, x0
    // 0x53bce4: r0 = _CompactEntriesIterable()
    //     0x53bce4: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x53bce8: mov             x1, x0
    // 0x53bcec: ldur            x0, [fp, #-0x48]
    // 0x53bcf0: StoreField: r1->field_b = r0
    //     0x53bcf0: stur            w0, [x1, #0xb]
    // 0x53bcf4: r0 = iterator()
    //     0x53bcf4: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x53bcf8: mov             x2, x0
    // 0x53bcfc: ldur            x0, [fp, #-0x28]
    // 0x53bd00: stur            x2, [fp, #-0x30]
    // 0x53bd04: LoadField: d0 = r0->field_7
    //     0x53bd04: ldur            d0, [x0, #7]
    // 0x53bd08: stur            d0, [fp, #-0x68]
    // 0x53bd0c: CheckStackOverflow
    //     0x53bd0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53bd10: cmp             SP, x16
    //     0x53bd14: b.ls            #0x53c380
    // 0x53bd18: mov             x1, x2
    // 0x53bd1c: r0 = moveNext()
    //     0x53bd1c: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x53bd20: tbnz            w0, #4, #0x53bdf8
    // 0x53bd24: ldur            x0, [fp, #-0x30]
    // 0x53bd28: LoadField: r1 = r0->field_2b
    //     0x53bd28: ldur            w1, [x0, #0x2b]
    // 0x53bd2c: DecompressPointer r1
    //     0x53bd2c: add             x1, x1, HEAP, lsl #32
    // 0x53bd30: cmp             w1, NULL
    // 0x53bd34: b.eq            #0x53c328
    // 0x53bd38: ldur            d1, [fp, #-0x68]
    // 0x53bd3c: LoadField: r2 = r1->field_b
    //     0x53bd3c: ldur            w2, [x1, #0xb]
    // 0x53bd40: DecompressPointer r2
    //     0x53bd40: add             x2, x2, HEAP, lsl #32
    // 0x53bd44: stur            x2, [fp, #-0x28]
    // 0x53bd48: LoadField: r3 = r1->field_f
    //     0x53bd48: ldur            w3, [x1, #0xf]
    // 0x53bd4c: DecompressPointer r3
    //     0x53bd4c: add             x3, x3, HEAP, lsl #32
    // 0x53bd50: LoadField: d0 = r3->field_7
    //     0x53bd50: ldur            d0, [x3, #7]
    // 0x53bd54: fadd            d2, d0, d1
    // 0x53bd58: mov             v0.16b, v2.16b
    // 0x53bd5c: r1 = Null
    //     0x53bd5c: mov             x1, NULL
    // 0x53bd60: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53bd60: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53bd64: mov             x3, x0
    // 0x53bd68: ldur            x0, [fp, #-0x28]
    // 0x53bd6c: ldur            x2, [fp, #-0x40]
    // 0x53bd70: r1 = Null
    //     0x53bd70: mov             x1, NULL
    // 0x53bd74: stur            x3, [fp, #-0x50]
    // 0x53bd78: cmp             w2, NULL
    // 0x53bd7c: b.eq            #0x53bd9c
    // 0x53bd80: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53bd80: ldur            w4, [x2, #0x17]
    // 0x53bd84: DecompressPointer r4
    //     0x53bd84: add             x4, x4, HEAP, lsl #32
    // 0x53bd88: r8 = X0
    //     0x53bd88: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53bd8c: LoadField: r9 = r4->field_7
    //     0x53bd8c: ldur            x9, [x4, #7]
    // 0x53bd90: r3 = Null
    //     0x53bd90: add             x3, PP, #0x16, lsl #12  ; [pp+0x16fd8] Null
    //     0x53bd94: ldr             x3, [x3, #0xfd8]
    // 0x53bd98: blr             x9
    // 0x53bd9c: ldur            x0, [fp, #-0x50]
    // 0x53bda0: ldur            x2, [fp, #-0x40]
    // 0x53bda4: r1 = Null
    //     0x53bda4: mov             x1, NULL
    // 0x53bda8: cmp             w2, NULL
    // 0x53bdac: b.eq            #0x53bdcc
    // 0x53bdb0: LoadField: r4 = r2->field_1b
    //     0x53bdb0: ldur            w4, [x2, #0x1b]
    // 0x53bdb4: DecompressPointer r4
    //     0x53bdb4: add             x4, x4, HEAP, lsl #32
    // 0x53bdb8: r8 = X1
    //     0x53bdb8: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x53bdbc: LoadField: r9 = r4->field_7
    //     0x53bdbc: ldur            x9, [x4, #7]
    // 0x53bdc0: r3 = Null
    //     0x53bdc0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16fe8] Null
    //     0x53bdc4: ldr             x3, [x3, #0xfe8]
    // 0x53bdc8: blr             x9
    // 0x53bdcc: ldur            x1, [fp, #-0x48]
    // 0x53bdd0: ldur            x2, [fp, #-0x28]
    // 0x53bdd4: r0 = _hashCode()
    //     0x53bdd4: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x53bdd8: ldur            x1, [fp, #-0x48]
    // 0x53bddc: ldur            x2, [fp, #-0x28]
    // 0x53bde0: ldur            x3, [fp, #-0x50]
    // 0x53bde4: mov             x5, x0
    // 0x53bde8: r0 = _set()
    //     0x53bde8: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x53bdec: ldur            x2, [fp, #-0x30]
    // 0x53bdf0: ldur            d0, [fp, #-0x68]
    // 0x53bdf4: b               #0x53bd0c
    // 0x53bdf8: ldur            x16, [fp, #-0x38]
    // 0x53bdfc: ldur            lr, [fp, #-0x18]
    // 0x53be00: stp             lr, x16, [SP, #8]
    // 0x53be04: ldur            x16, [fp, #-0x48]
    // 0x53be08: str             x16, [SP]
    // 0x53be0c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53be0c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53be10: r0 = MapOperations.merge()
    //     0x53be10: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x53be14: ldur            x0, [fp, #-0x20]
    // 0x53be18: ldur            x2, [fp, #-0x10]
    // 0x53be1c: b               #0x53b1e0
    // 0x53be20: ldur            x0, [fp, #-8]
    // 0x53be24: LoadField: r1 = r0->field_f
    //     0x53be24: ldur            w1, [x0, #0xf]
    // 0x53be28: DecompressPointer r1
    //     0x53be28: add             x1, x1, HEAP, lsl #32
    // 0x53be2c: LoadField: r2 = r1->field_4f
    //     0x53be2c: ldur            w2, [x1, #0x4f]
    // 0x53be30: DecompressPointer r2
    //     0x53be30: add             x2, x2, HEAP, lsl #32
    // 0x53be34: stur            x2, [fp, #-0x10]
    // 0x53be38: LoadField: r1 = r2->field_7
    //     0x53be38: ldur            w1, [x2, #7]
    // 0x53be3c: DecompressPointer r1
    //     0x53be3c: add             x1, x1, HEAP, lsl #32
    // 0x53be40: r0 = _CompactKeysIterable()
    //     0x53be40: bl              #0x379c0c  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x53be44: mov             x1, x0
    // 0x53be48: ldur            x0, [fp, #-0x10]
    // 0x53be4c: StoreField: r1->field_b = r0
    //     0x53be4c: stur            w0, [x1, #0xb]
    // 0x53be50: r0 = iterator()
    //     0x53be50: bl              #0x53647c  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0x53be54: stur            x0, [fp, #-0x20]
    // 0x53be58: LoadField: r2 = r0->field_7
    //     0x53be58: ldur            w2, [x0, #7]
    // 0x53be5c: DecompressPointer r2
    //     0x53be5c: add             x2, x2, HEAP, lsl #32
    // 0x53be60: stur            x2, [fp, #-0x10]
    // 0x53be64: ldur            x3, [fp, #-8]
    // 0x53be68: CheckStackOverflow
    //     0x53be68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53be6c: cmp             SP, x16
    //     0x53be70: b.ls            #0x53c388
    // 0x53be74: mov             x1, x0
    // 0x53be78: r0 = moveNext()
    //     0x53be78: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x53be7c: tbnz            w0, #4, #0x53c2c4
    // 0x53be80: ldur            x3, [fp, #-0x20]
    // 0x53be84: LoadField: r4 = r3->field_33
    //     0x53be84: ldur            w4, [x3, #0x33]
    // 0x53be88: DecompressPointer r4
    //     0x53be88: add             x4, x4, HEAP, lsl #32
    // 0x53be8c: stur            x4, [fp, #-0x28]
    // 0x53be90: cmp             w4, NULL
    // 0x53be94: b.ne            #0x53bec8
    // 0x53be98: mov             x0, x4
    // 0x53be9c: ldur            x2, [fp, #-0x10]
    // 0x53bea0: r1 = Null
    //     0x53bea0: mov             x1, NULL
    // 0x53bea4: cmp             w2, NULL
    // 0x53bea8: b.eq            #0x53bec8
    // 0x53beac: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53beac: ldur            w4, [x2, #0x17]
    // 0x53beb0: DecompressPointer r4
    //     0x53beb0: add             x4, x4, HEAP, lsl #32
    // 0x53beb4: r8 = X0
    //     0x53beb4: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53beb8: LoadField: r9 = r4->field_7
    //     0x53beb8: ldur            x9, [x4, #7]
    // 0x53bebc: r3 = Null
    //     0x53bebc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16ff8] Null
    //     0x53bec0: ldr             x3, [x3, #0xff8]
    // 0x53bec4: blr             x9
    // 0x53bec8: ldur            x3, [fp, #-8]
    // 0x53becc: LoadField: r1 = r3->field_f
    //     0x53becc: ldur            w1, [x3, #0xf]
    // 0x53bed0: DecompressPointer r1
    //     0x53bed0: add             x1, x1, HEAP, lsl #32
    // 0x53bed4: r0 = LoadClassIdInstr(r1)
    //     0x53bed4: ldur            x0, [x1, #-1]
    //     0x53bed8: ubfx            x0, x0, #0xc, #0x14
    // 0x53bedc: ldur            x2, [fp, #-0x28]
    // 0x53bee0: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x53bee0: sub             lr, x0, #0xcb6
    //     0x53bee4: ldr             lr, [x21, lr, lsl #3]
    //     0x53bee8: blr             lr
    // 0x53beec: LoadField: r1 = r0->field_1f
    //     0x53beec: ldur            w1, [x0, #0x1f]
    // 0x53bef0: DecompressPointer r1
    //     0x53bef0: add             x1, x1, HEAP, lsl #32
    // 0x53bef4: cmp             w1, NULL
    // 0x53bef8: b.ne            #0x53c2b8
    // 0x53befc: ldur            x0, [fp, #-8]
    // 0x53bf00: LoadField: r1 = r0->field_f
    //     0x53bf00: ldur            w1, [x0, #0xf]
    // 0x53bf04: DecompressPointer r1
    //     0x53bf04: add             x1, x1, HEAP, lsl #32
    // 0x53bf08: LoadField: r3 = r1->field_4f
    //     0x53bf08: ldur            w3, [x1, #0x4f]
    // 0x53bf0c: DecompressPointer r3
    //     0x53bf0c: add             x3, x3, HEAP, lsl #32
    // 0x53bf10: mov             x1, x3
    // 0x53bf14: ldur            x2, [fp, #-0x28]
    // 0x53bf18: stur            x3, [fp, #-0x30]
    // 0x53bf1c: r0 = _getValueOrData()
    //     0x53bf1c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53bf20: mov             x1, x0
    // 0x53bf24: ldur            x0, [fp, #-0x30]
    // 0x53bf28: LoadField: r2 = r0->field_f
    //     0x53bf28: ldur            w2, [x0, #0xf]
    // 0x53bf2c: DecompressPointer r2
    //     0x53bf2c: add             x2, x2, HEAP, lsl #32
    // 0x53bf30: cmp             w2, w1
    // 0x53bf34: b.ne            #0x53bf40
    // 0x53bf38: r2 = Null
    //     0x53bf38: mov             x2, NULL
    // 0x53bf3c: b               #0x53bf44
    // 0x53bf40: mov             x2, x1
    // 0x53bf44: ldur            x0, [fp, #-8]
    // 0x53bf48: ldur            x3, [fp, #-0x28]
    // 0x53bf4c: cmp             w2, NULL
    // 0x53bf50: b.eq            #0x53c390
    // 0x53bf54: r1 = Null
    //     0x53bf54: mov             x1, NULL
    // 0x53bf58: r0 = CustomNum()
    //     0x53bf58: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x53bf5c: mov             x5, x0
    // 0x53bf60: ldur            x4, [fp, #-8]
    // 0x53bf64: stur            x5, [fp, #-0x38]
    // 0x53bf68: LoadField: r1 = r4->field_f
    //     0x53bf68: ldur            w1, [x4, #0xf]
    // 0x53bf6c: DecompressPointer r1
    //     0x53bf6c: add             x1, x1, HEAP, lsl #32
    // 0x53bf70: LoadField: r6 = r1->field_7
    //     0x53bf70: ldur            w6, [x1, #7]
    // 0x53bf74: DecompressPointer r6
    //     0x53bf74: add             x6, x6, HEAP, lsl #32
    // 0x53bf78: ldur            x7, [fp, #-0x28]
    // 0x53bf7c: stur            x6, [fp, #-0x30]
    // 0x53bf80: r2 = LoadInt32Instr(r7)
    //     0x53bf80: sbfx            x2, x7, #1, #0x1f
    //     0x53bf84: tbz             w7, #0, #0x53bf8c
    //     0x53bf88: ldur            x2, [x7, #7]
    // 0x53bf8c: r0 = LoadClassIdInstr(r1)
    //     0x53bf8c: ldur            x0, [x1, #-1]
    //     0x53bf90: ubfx            x0, x0, #0xc, #0x14
    // 0x53bf94: mov             x3, x5
    // 0x53bf98: r0 = GDT[cid_x0 + 0x8756]()
    //     0x53bf98: movz            x17, #0x8756
    //     0x53bf9c: add             lr, x0, x17
    //     0x53bfa0: ldr             lr, [x21, lr, lsl #3]
    //     0x53bfa4: blr             lr
    // 0x53bfa8: stur            x0, [fp, #-0x48]
    // 0x53bfac: LoadField: r4 = r0->field_7
    //     0x53bfac: ldur            w4, [x0, #7]
    // 0x53bfb0: DecompressPointer r4
    //     0x53bfb0: add             x4, x4, HEAP, lsl #32
    // 0x53bfb4: mov             x2, x4
    // 0x53bfb8: stur            x4, [fp, #-0x40]
    // 0x53bfbc: r1 = Null
    //     0x53bfbc: mov             x1, NULL
    // 0x53bfc0: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53bfc0: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x53bfc4: r30 = InstantiateTypeArgumentsStub
    //     0x53bfc4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53bfc8: LoadField: r30 = r30->field_7
    //     0x53bfc8: ldur            lr, [lr, #7]
    // 0x53bfcc: blr             lr
    // 0x53bfd0: mov             x1, x0
    // 0x53bfd4: r0 = _CompactEntriesIterable()
    //     0x53bfd4: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x53bfd8: mov             x1, x0
    // 0x53bfdc: ldur            x0, [fp, #-0x48]
    // 0x53bfe0: StoreField: r1->field_b = r0
    //     0x53bfe0: stur            w0, [x1, #0xb]
    // 0x53bfe4: r0 = iterator()
    //     0x53bfe4: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x53bfe8: mov             x2, x0
    // 0x53bfec: ldur            x0, [fp, #-0x38]
    // 0x53bff0: stur            x2, [fp, #-0x50]
    // 0x53bff4: LoadField: d0 = r0->field_7
    //     0x53bff4: ldur            d0, [x0, #7]
    // 0x53bff8: stur            d0, [fp, #-0x68]
    // 0x53bffc: CheckStackOverflow
    //     0x53bffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53c000: cmp             SP, x16
    //     0x53c004: b.ls            #0x53c394
    // 0x53c008: mov             x1, x2
    // 0x53c00c: r0 = moveNext()
    //     0x53c00c: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x53c010: tbnz            w0, #4, #0x53c0e8
    // 0x53c014: ldur            x0, [fp, #-0x50]
    // 0x53c018: LoadField: r1 = r0->field_2b
    //     0x53c018: ldur            w1, [x0, #0x2b]
    // 0x53c01c: DecompressPointer r1
    //     0x53c01c: add             x1, x1, HEAP, lsl #32
    // 0x53c020: cmp             w1, NULL
    // 0x53c024: b.eq            #0x53c334
    // 0x53c028: ldur            d1, [fp, #-0x68]
    // 0x53c02c: LoadField: r2 = r1->field_b
    //     0x53c02c: ldur            w2, [x1, #0xb]
    // 0x53c030: DecompressPointer r2
    //     0x53c030: add             x2, x2, HEAP, lsl #32
    // 0x53c034: stur            x2, [fp, #-0x38]
    // 0x53c038: LoadField: r3 = r1->field_f
    //     0x53c038: ldur            w3, [x1, #0xf]
    // 0x53c03c: DecompressPointer r3
    //     0x53c03c: add             x3, x3, HEAP, lsl #32
    // 0x53c040: LoadField: d0 = r3->field_7
    //     0x53c040: ldur            d0, [x3, #7]
    // 0x53c044: fadd            d2, d0, d1
    // 0x53c048: mov             v0.16b, v2.16b
    // 0x53c04c: r1 = Null
    //     0x53c04c: mov             x1, NULL
    // 0x53c050: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53c050: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53c054: mov             x3, x0
    // 0x53c058: ldur            x0, [fp, #-0x38]
    // 0x53c05c: ldur            x2, [fp, #-0x40]
    // 0x53c060: r1 = Null
    //     0x53c060: mov             x1, NULL
    // 0x53c064: stur            x3, [fp, #-0x58]
    // 0x53c068: cmp             w2, NULL
    // 0x53c06c: b.eq            #0x53c08c
    // 0x53c070: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53c070: ldur            w4, [x2, #0x17]
    // 0x53c074: DecompressPointer r4
    //     0x53c074: add             x4, x4, HEAP, lsl #32
    // 0x53c078: r8 = X0
    //     0x53c078: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53c07c: LoadField: r9 = r4->field_7
    //     0x53c07c: ldur            x9, [x4, #7]
    // 0x53c080: r3 = Null
    //     0x53c080: add             x3, PP, #0x17, lsl #12  ; [pp+0x17008] Null
    //     0x53c084: ldr             x3, [x3, #8]
    // 0x53c088: blr             x9
    // 0x53c08c: ldur            x0, [fp, #-0x58]
    // 0x53c090: ldur            x2, [fp, #-0x40]
    // 0x53c094: r1 = Null
    //     0x53c094: mov             x1, NULL
    // 0x53c098: cmp             w2, NULL
    // 0x53c09c: b.eq            #0x53c0bc
    // 0x53c0a0: LoadField: r4 = r2->field_1b
    //     0x53c0a0: ldur            w4, [x2, #0x1b]
    // 0x53c0a4: DecompressPointer r4
    //     0x53c0a4: add             x4, x4, HEAP, lsl #32
    // 0x53c0a8: r8 = X1
    //     0x53c0a8: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x53c0ac: LoadField: r9 = r4->field_7
    //     0x53c0ac: ldur            x9, [x4, #7]
    // 0x53c0b0: r3 = Null
    //     0x53c0b0: add             x3, PP, #0x17, lsl #12  ; [pp+0x17018] Null
    //     0x53c0b4: ldr             x3, [x3, #0x18]
    // 0x53c0b8: blr             x9
    // 0x53c0bc: ldur            x1, [fp, #-0x48]
    // 0x53c0c0: ldur            x2, [fp, #-0x38]
    // 0x53c0c4: r0 = _hashCode()
    //     0x53c0c4: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x53c0c8: ldur            x1, [fp, #-0x48]
    // 0x53c0cc: ldur            x2, [fp, #-0x38]
    // 0x53c0d0: ldur            x3, [fp, #-0x58]
    // 0x53c0d4: mov             x5, x0
    // 0x53c0d8: r0 = _set()
    //     0x53c0d8: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x53c0dc: ldur            x2, [fp, #-0x50]
    // 0x53c0e0: ldur            d0, [fp, #-0x68]
    // 0x53c0e4: b               #0x53bffc
    // 0x53c0e8: ldur            x0, [fp, #-8]
    // 0x53c0ec: LoadField: r1 = r0->field_f
    //     0x53c0ec: ldur            w1, [x0, #0xf]
    // 0x53c0f0: DecompressPointer r1
    //     0x53c0f0: add             x1, x1, HEAP, lsl #32
    // 0x53c0f4: LoadField: r3 = r1->field_33
    //     0x53c0f4: ldur            w3, [x1, #0x33]
    // 0x53c0f8: DecompressPointer r3
    //     0x53c0f8: add             x3, x3, HEAP, lsl #32
    // 0x53c0fc: mov             x1, x3
    // 0x53c100: ldur            x2, [fp, #-0x28]
    // 0x53c104: stur            x3, [fp, #-0x38]
    // 0x53c108: r0 = _getValueOrData()
    //     0x53c108: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53c10c: mov             x1, x0
    // 0x53c110: ldur            x0, [fp, #-0x38]
    // 0x53c114: LoadField: r2 = r0->field_f
    //     0x53c114: ldur            w2, [x0, #0xf]
    // 0x53c118: DecompressPointer r2
    //     0x53c118: add             x2, x2, HEAP, lsl #32
    // 0x53c11c: cmp             w2, w1
    // 0x53c120: b.ne            #0x53c12c
    // 0x53c124: r0 = Null
    //     0x53c124: mov             x0, NULL
    // 0x53c128: b               #0x53c130
    // 0x53c12c: mov             x0, x1
    // 0x53c130: cmp             w0, NULL
    // 0x53c134: b.ne            #0x53c140
    // 0x53c138: r0 = Null
    //     0x53c138: mov             x0, NULL
    // 0x53c13c: b               #0x53c14c
    // 0x53c140: LoadField: r1 = r0->field_f
    //     0x53c140: ldur            w1, [x0, #0xf]
    // 0x53c144: DecompressPointer r1
    //     0x53c144: add             x1, x1, HEAP, lsl #32
    // 0x53c148: mov             x0, x1
    // 0x53c14c: cmp             w0, NULL
    // 0x53c150: b.ne            #0x53c160
    // 0x53c154: r4 = Instance_CustomNum
    //     0x53c154: add             x4, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x53c158: ldr             x4, [x4, #0xa70]
    // 0x53c15c: b               #0x53c164
    // 0x53c160: mov             x4, x0
    // 0x53c164: ldur            x0, [fp, #-0x48]
    // 0x53c168: ldur            x2, [fp, #-0x40]
    // 0x53c16c: stur            x4, [fp, #-0x28]
    // 0x53c170: r1 = Null
    //     0x53c170: mov             x1, NULL
    // 0x53c174: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x53c174: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x53c178: r30 = InstantiateTypeArgumentsStub
    //     0x53c178: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x53c17c: LoadField: r30 = r30->field_7
    //     0x53c17c: ldur            lr, [lr, #7]
    // 0x53c180: blr             lr
    // 0x53c184: mov             x1, x0
    // 0x53c188: r0 = _CompactEntriesIterable()
    //     0x53c188: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x53c18c: mov             x1, x0
    // 0x53c190: ldur            x0, [fp, #-0x48]
    // 0x53c194: StoreField: r1->field_b = r0
    //     0x53c194: stur            w0, [x1, #0xb]
    // 0x53c198: r0 = iterator()
    //     0x53c198: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x53c19c: mov             x2, x0
    // 0x53c1a0: ldur            x0, [fp, #-0x28]
    // 0x53c1a4: stur            x2, [fp, #-0x38]
    // 0x53c1a8: LoadField: d0 = r0->field_7
    //     0x53c1a8: ldur            d0, [x0, #7]
    // 0x53c1ac: stur            d0, [fp, #-0x68]
    // 0x53c1b0: CheckStackOverflow
    //     0x53c1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53c1b4: cmp             SP, x16
    //     0x53c1b8: b.ls            #0x53c39c
    // 0x53c1bc: mov             x1, x2
    // 0x53c1c0: r0 = moveNext()
    //     0x53c1c0: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x53c1c4: tbnz            w0, #4, #0x53c29c
    // 0x53c1c8: ldur            x0, [fp, #-0x38]
    // 0x53c1cc: LoadField: r1 = r0->field_2b
    //     0x53c1cc: ldur            w1, [x0, #0x2b]
    // 0x53c1d0: DecompressPointer r1
    //     0x53c1d0: add             x1, x1, HEAP, lsl #32
    // 0x53c1d4: cmp             w1, NULL
    // 0x53c1d8: b.eq            #0x53c340
    // 0x53c1dc: ldur            d1, [fp, #-0x68]
    // 0x53c1e0: LoadField: r2 = r1->field_b
    //     0x53c1e0: ldur            w2, [x1, #0xb]
    // 0x53c1e4: DecompressPointer r2
    //     0x53c1e4: add             x2, x2, HEAP, lsl #32
    // 0x53c1e8: stur            x2, [fp, #-0x28]
    // 0x53c1ec: LoadField: r3 = r1->field_f
    //     0x53c1ec: ldur            w3, [x1, #0xf]
    // 0x53c1f0: DecompressPointer r3
    //     0x53c1f0: add             x3, x3, HEAP, lsl #32
    // 0x53c1f4: LoadField: d0 = r3->field_7
    //     0x53c1f4: ldur            d0, [x3, #7]
    // 0x53c1f8: fadd            d2, d0, d1
    // 0x53c1fc: mov             v0.16b, v2.16b
    // 0x53c200: r1 = Null
    //     0x53c200: mov             x1, NULL
    // 0x53c204: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53c204: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53c208: mov             x3, x0
    // 0x53c20c: ldur            x0, [fp, #-0x28]
    // 0x53c210: ldur            x2, [fp, #-0x40]
    // 0x53c214: r1 = Null
    //     0x53c214: mov             x1, NULL
    // 0x53c218: stur            x3, [fp, #-0x50]
    // 0x53c21c: cmp             w2, NULL
    // 0x53c220: b.eq            #0x53c240
    // 0x53c224: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53c224: ldur            w4, [x2, #0x17]
    // 0x53c228: DecompressPointer r4
    //     0x53c228: add             x4, x4, HEAP, lsl #32
    // 0x53c22c: r8 = X0
    //     0x53c22c: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53c230: LoadField: r9 = r4->field_7
    //     0x53c230: ldur            x9, [x4, #7]
    // 0x53c234: r3 = Null
    //     0x53c234: add             x3, PP, #0x17, lsl #12  ; [pp+0x17028] Null
    //     0x53c238: ldr             x3, [x3, #0x28]
    // 0x53c23c: blr             x9
    // 0x53c240: ldur            x0, [fp, #-0x50]
    // 0x53c244: ldur            x2, [fp, #-0x40]
    // 0x53c248: r1 = Null
    //     0x53c248: mov             x1, NULL
    // 0x53c24c: cmp             w2, NULL
    // 0x53c250: b.eq            #0x53c270
    // 0x53c254: LoadField: r4 = r2->field_1b
    //     0x53c254: ldur            w4, [x2, #0x1b]
    // 0x53c258: DecompressPointer r4
    //     0x53c258: add             x4, x4, HEAP, lsl #32
    // 0x53c25c: r8 = X1
    //     0x53c25c: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x53c260: LoadField: r9 = r4->field_7
    //     0x53c260: ldur            x9, [x4, #7]
    // 0x53c264: r3 = Null
    //     0x53c264: add             x3, PP, #0x17, lsl #12  ; [pp+0x17038] Null
    //     0x53c268: ldr             x3, [x3, #0x38]
    // 0x53c26c: blr             x9
    // 0x53c270: ldur            x1, [fp, #-0x48]
    // 0x53c274: ldur            x2, [fp, #-0x28]
    // 0x53c278: r0 = _hashCode()
    //     0x53c278: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x53c27c: ldur            x1, [fp, #-0x48]
    // 0x53c280: ldur            x2, [fp, #-0x28]
    // 0x53c284: ldur            x3, [fp, #-0x50]
    // 0x53c288: mov             x5, x0
    // 0x53c28c: r0 = _set()
    //     0x53c28c: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x53c290: ldur            x2, [fp, #-0x38]
    // 0x53c294: ldur            d0, [fp, #-0x68]
    // 0x53c298: b               #0x53c1b0
    // 0x53c29c: ldur            x16, [fp, #-0x30]
    // 0x53c2a0: ldur            lr, [fp, #-0x18]
    // 0x53c2a4: stp             lr, x16, [SP, #8]
    // 0x53c2a8: ldur            x16, [fp, #-0x48]
    // 0x53c2ac: str             x16, [SP]
    // 0x53c2b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x53c2b0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x53c2b4: r0 = MapOperations.merge()
    //     0x53c2b4: bl              #0x53819c  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.merge
    // 0x53c2b8: ldur            x0, [fp, #-0x20]
    // 0x53c2bc: ldur            x2, [fp, #-0x10]
    // 0x53c2c0: b               #0x53be64
    // 0x53c2c4: ldur            x0, [fp, #-8]
    // 0x53c2c8: LoadField: r1 = r0->field_f
    //     0x53c2c8: ldur            w1, [x0, #0xf]
    // 0x53c2cc: DecompressPointer r1
    //     0x53c2cc: add             x1, x1, HEAP, lsl #32
    // 0x53c2d0: r0 = LoadClassIdInstr(r1)
    //     0x53c2d0: ldur            x0, [x1, #-1]
    //     0x53c2d4: ubfx            x0, x0, #0xc, #0x14
    // 0x53c2d8: r0 = GDT[cid_x0 + 0x89fa]()
    //     0x53c2d8: movz            x17, #0x89fa
    //     0x53c2dc: add             lr, x0, x17
    //     0x53c2e0: ldr             lr, [x21, lr, lsl #3]
    //     0x53c2e4: blr             lr
    // 0x53c2e8: ldur            x1, [fp, #-0x18]
    // 0x53c2ec: mov             x2, x0
    // 0x53c2f0: r0 = addAll()
    //     0x53c2f0: bl              #0x3858b0  ; [dart:_compact_hash] _Map::addAll
    // 0x53c2f4: ldur            x0, [fp, #-0x18]
    // 0x53c2f8: LeaveFrame
    //     0x53c2f8: mov             SP, fp
    //     0x53c2fc: ldp             fp, lr, [SP], #0x10
    // 0x53c300: ret
    //     0x53c300: ret             
    // 0x53c304: r0 = noElement()
    //     0x53c304: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x53c308: r0 = Throw()
    //     0x53c308: bl              #0x825670  ; ThrowStub
    // 0x53c30c: brk             #0
    // 0x53c310: r0 = noElement()
    //     0x53c310: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x53c314: r0 = Throw()
    //     0x53c314: bl              #0x825670  ; ThrowStub
    // 0x53c318: brk             #0
    // 0x53c31c: r0 = noElement()
    //     0x53c31c: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x53c320: r0 = Throw()
    //     0x53c320: bl              #0x825670  ; ThrowStub
    // 0x53c324: brk             #0
    // 0x53c328: r0 = noElement()
    //     0x53c328: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x53c32c: r0 = Throw()
    //     0x53c32c: bl              #0x825670  ; ThrowStub
    // 0x53c330: brk             #0
    // 0x53c334: r0 = noElement()
    //     0x53c334: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x53c338: r0 = Throw()
    //     0x53c338: bl              #0x825670  ; ThrowStub
    // 0x53c33c: brk             #0
    // 0x53c340: r0 = noElement()
    //     0x53c340: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x53c344: r0 = Throw()
    //     0x53c344: bl              #0x825670  ; ThrowStub
    // 0x53c348: brk             #0
    // 0x53c34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53c34c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53c350: b               #0x53b0e8
    // 0x53c354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53c354: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53c358: b               #0x53b1f0
    // 0x53c35c: r9 = prefs
    //     0x53c35c: add             x9, PP, #0xb, lsl #12  ; [pp+0xbc00] Field <::.prefs>: static late (offset: 0xa6c)
    //     0x53c360: ldr             x9, [x9, #0xc00]
    // 0x53c364: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x53c364: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x53c368: r0 = StackOverflowSharedWithFPURegs()
    //     0x53c368: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53c36c: b               #0x53b808
    // 0x53c370: r0 = StackOverflowSharedWithFPURegs()
    //     0x53c370: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53c374: b               #0x53b9bc
    // 0x53c378: r0 = StackOverflowSharedWithFPURegs()
    //     0x53c378: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53c37c: b               #0x53bb64
    // 0x53c380: r0 = StackOverflowSharedWithFPURegs()
    //     0x53c380: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53c384: b               #0x53bd18
    // 0x53c388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53c388: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53c38c: b               #0x53be74
    // 0x53c390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x53c390: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x53c394: r0 = StackOverflowSharedWithFPURegs()
    //     0x53c394: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53c398: b               #0x53c008
    // 0x53c39c: r0 = StackOverflowSharedWithFPURegs()
    //     0x53c39c: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53c3a0: b               #0x53c1bc
  }
  [closure] bool <anonymous closure>(dynamic, int) {
    // ** addr: 0x53c3a4, size: 0xac
    // 0x53c3a4: EnterFrame
    //     0x53c3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x53c3a8: mov             fp, SP
    // 0x53c3ac: AllocStack(0x10)
    //     0x53c3ac: sub             SP, SP, #0x10
    // 0x53c3b0: SetupParameters([dynamic _ /* r0 */])
    //     0x53c3b0: ldr             x0, [fp, #0x18]
    //     0x53c3b4: ldur            w1, [x0, #0x17]
    //     0x53c3b8: add             x1, x1, HEAP, lsl #32
    // 0x53c3bc: CheckStackOverflow
    //     0x53c3bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53c3c0: cmp             SP, x16
    //     0x53c3c4: b.ls            #0x53c448
    // 0x53c3c8: LoadField: r0 = r1->field_f
    //     0x53c3c8: ldur            w0, [x1, #0xf]
    // 0x53c3cc: DecompressPointer r0
    //     0x53c3cc: add             x0, x0, HEAP, lsl #32
    // 0x53c3d0: LoadField: r2 = r0->field_37
    //     0x53c3d0: ldur            w2, [x0, #0x37]
    // 0x53c3d4: DecompressPointer r2
    //     0x53c3d4: add             x2, x2, HEAP, lsl #32
    // 0x53c3d8: stur            x2, [fp, #-8]
    // 0x53c3dc: r1 = LoadClassIdInstr(r0)
    //     0x53c3dc: ldur            x1, [x0, #-1]
    //     0x53c3e0: ubfx            x1, x1, #0xc, #0x14
    // 0x53c3e4: mov             x16, x0
    // 0x53c3e8: mov             x0, x1
    // 0x53c3ec: mov             x1, x16
    // 0x53c3f0: r0 = GDT[cid_x0 + 0x8702]()
    //     0x53c3f0: movz            x17, #0x8702
    //     0x53c3f4: add             lr, x0, x17
    //     0x53c3f8: ldr             lr, [x21, lr, lsl #3]
    //     0x53c3fc: blr             lr
    // 0x53c400: mov             x1, x0
    // 0x53c404: ldr             x2, [fp, #0x10]
    // 0x53c408: stur            x0, [fp, #-0x10]
    // 0x53c40c: r0 = _getValueOrData()
    //     0x53c40c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x53c410: mov             x1, x0
    // 0x53c414: ldur            x0, [fp, #-0x10]
    // 0x53c418: LoadField: r2 = r0->field_f
    //     0x53c418: ldur            w2, [x0, #0xf]
    // 0x53c41c: DecompressPointer r2
    //     0x53c41c: add             x2, x2, HEAP, lsl #32
    // 0x53c420: cmp             w2, w1
    // 0x53c424: b.ne            #0x53c430
    // 0x53c428: r2 = Null
    //     0x53c428: mov             x2, NULL
    // 0x53c42c: b               #0x53c434
    // 0x53c430: mov             x2, x1
    // 0x53c434: ldur            x1, [fp, #-8]
    // 0x53c438: r0 = containsKey()
    //     0x53c438: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x53c43c: LeaveFrame
    //     0x53c43c: mov             SP, fp
    //     0x53c440: ldp             fp, lr, [SP], #0x10
    // 0x53c444: ret
    //     0x53c444: ret             
    // 0x53c448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53c448: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53c44c: b               #0x53c3c8
  }
  [closure] void notifyStatGained(dynamic, Object?) {
    // ** addr: 0x53c450, size: 0x3c
    // 0x53c450: EnterFrame
    //     0x53c450: stp             fp, lr, [SP, #-0x10]!
    //     0x53c454: mov             fp, SP
    // 0x53c458: ldr             x0, [fp, #0x18]
    // 0x53c45c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x53c45c: ldur            w1, [x0, #0x17]
    // 0x53c460: DecompressPointer r1
    //     0x53c460: add             x1, x1, HEAP, lsl #32
    // 0x53c464: CheckStackOverflow
    //     0x53c464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53c468: cmp             SP, x16
    //     0x53c46c: b.ls            #0x53c484
    // 0x53c470: ldr             x2, [fp, #0x10]
    // 0x53c474: r0 = notifyStatGained()
    //     0x53c474: bl              #0x53c48c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyStatGained
    // 0x53c478: LeaveFrame
    //     0x53c478: mov             SP, fp
    //     0x53c47c: ldp             fp, lr, [SP], #0x10
    // 0x53c480: ret
    //     0x53c480: ret             
    // 0x53c484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53c484: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53c488: b               #0x53c470
  }
  _ notifyStatGained(/* No info */) {
    // ** addr: 0x53c48c, size: 0x118
    // 0x53c48c: EnterFrame
    //     0x53c48c: stp             fp, lr, [SP, #-0x10]!
    //     0x53c490: mov             fp, SP
    // 0x53c494: AllocStack(0x28)
    //     0x53c494: sub             SP, SP, #0x28
    // 0x53c498: SetupParameters(IPlayableGameState<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x53c498: mov             x4, x1
    //     0x53c49c: mov             x3, x2
    //     0x53c4a0: stur            x1, [fp, #-8]
    //     0x53c4a4: stur            x2, [fp, #-0x10]
    // 0x53c4a8: CheckStackOverflow
    //     0x53c4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x53c4ac: cmp             SP, x16
    //     0x53c4b0: b.ls            #0x53c59c
    // 0x53c4b4: LoadField: r2 = r4->field_7
    //     0x53c4b4: ldur            w2, [x4, #7]
    // 0x53c4b8: DecompressPointer r2
    //     0x53c4b8: add             x2, x2, HEAP, lsl #32
    // 0x53c4bc: mov             x0, x3
    // 0x53c4c0: r1 = Null
    //     0x53c4c0: mov             x1, NULL
    // 0x53c4c4: cmp             w2, NULL
    // 0x53c4c8: b.eq            #0x53c4e8
    // 0x53c4cc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x53c4cc: ldur            w4, [x2, #0x17]
    // 0x53c4d0: DecompressPointer r4
    //     0x53c4d0: add             x4, x4, HEAP, lsl #32
    // 0x53c4d4: r8 = X0
    //     0x53c4d4: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x53c4d8: LoadField: r9 = r4->field_7
    //     0x53c4d8: ldur            x9, [x4, #7]
    // 0x53c4dc: r3 = Null
    //     0x53c4dc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16eb0] Null
    //     0x53c4e0: ldr             x3, [x3, #0xeb0]
    // 0x53c4e4: blr             x9
    // 0x53c4e8: ldur            x1, [fp, #-8]
    // 0x53c4ec: LoadField: r2 = r1->field_13
    //     0x53c4ec: ldur            w2, [x1, #0x13]
    // 0x53c4f0: DecompressPointer r2
    //     0x53c4f0: add             x2, x2, HEAP, lsl #32
    // 0x53c4f4: stur            x2, [fp, #-0x18]
    // 0x53c4f8: LoadField: r0 = r1->field_63
    //     0x53c4f8: ldur            w0, [x1, #0x63]
    // 0x53c4fc: DecompressPointer r0
    //     0x53c4fc: add             x0, x0, HEAP, lsl #32
    // 0x53c500: ldur            x16, [fp, #-0x10]
    // 0x53c504: stp             x16, x0, [SP]
    // 0x53c508: ClosureCall
    //     0x53c508: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x53c50c: ldur            x2, [x0, #0x1f]
    //     0x53c510: blr             x2
    // 0x53c514: ldur            x1, [fp, #-0x18]
    // 0x53c518: mov             x2, x0
    // 0x53c51c: r0 = contains()
    //     0x53c51c: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x53c520: tbz             w0, #4, #0x53c58c
    // 0x53c524: ldur            x0, [fp, #-8]
    // 0x53c528: LoadField: r1 = r0->field_13
    //     0x53c528: ldur            w1, [x0, #0x13]
    // 0x53c52c: DecompressPointer r1
    //     0x53c52c: add             x1, x1, HEAP, lsl #32
    // 0x53c530: stur            x1, [fp, #-0x18]
    // 0x53c534: LoadField: r2 = r0->field_63
    //     0x53c534: ldur            w2, [x0, #0x63]
    // 0x53c538: DecompressPointer r2
    //     0x53c538: add             x2, x2, HEAP, lsl #32
    // 0x53c53c: ldur            x16, [fp, #-0x10]
    // 0x53c540: stp             x16, x2, [SP]
    // 0x53c544: mov             x0, x2
    // 0x53c548: ClosureCall
    //     0x53c548: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x53c54c: ldur            x2, [x0, #0x1f]
    //     0x53c550: blr             x2
    // 0x53c554: ldur            x1, [fp, #-0x18]
    // 0x53c558: mov             x2, x0
    // 0x53c55c: r0 = add()
    //     0x53c55c: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x53c560: r0 = LoadStaticField(0x1040)
    //     0x53c560: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x53c564: ldr             x0, [x0, #0x2080]
    // 0x53c568: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x53c56c: cmp             w0, w16
    // 0x53c570: b.ne            #0x53c580
    // 0x53c574: r2 = fragments
    //     0x53c574: add             x2, PP, #0x10, lsl #12  ; [pp+0x100b8] Field <::.fragments>: static late (offset: 0x1040)
    //     0x53c578: ldr             x2, [x2, #0xb8]
    // 0x53c57c: r0 = InitLateStaticField()
    //     0x53c57c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x53c580: mov             x1, x0
    // 0x53c584: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x53c584: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x53c588: r0 = notifyAll()
    //     0x53c588: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x53c58c: r0 = Null
    //     0x53c58c: mov             x0, NULL
    // 0x53c590: LeaveFrame
    //     0x53c590: mov             SP, fp
    //     0x53c594: ldp             fp, lr, [SP], #0x10
    // 0x53c598: ret
    //     0x53c598: ret             
    // 0x53c59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x53c59c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x53c5a0: b               #0x53c4b4
  }
  _ buyAll(/* No info */) {
    // ** addr: 0x544a08, size: 0x794
    // 0x544a08: EnterFrame
    //     0x544a08: stp             fp, lr, [SP, #-0x10]!
    //     0x544a0c: mov             fp, SP
    // 0x544a10: AllocStack(0x70)
    //     0x544a10: sub             SP, SP, #0x70
    // 0x544a14: SetupParameters(IPlayableGameState<X0> this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r5, fp-0x18 */, {int maxBuy = 50 /* r2, fp-0x8 */})
    //     0x544a14: mov             x0, x1
    //     0x544a18: stur            x1, [fp, #-0x10]
    //     0x544a1c: mov             x1, x2
    //     0x544a20: mov             x5, x3
    //     0x544a24: stur            x3, [fp, #-0x18]
    //     0x544a28: ldur            w2, [x4, #0x13]
    //     0x544a2c: ldur            w3, [x4, #0x1f]
    //     0x544a30: add             x3, x3, HEAP, lsl #32
    //     0x544a34: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a1d0] "maxBuy"
    //     0x544a38: ldr             x16, [x16, #0x1d0]
    //     0x544a3c: cmp             w3, w16
    //     0x544a40: b.ne            #0x544a6c
    //     0x544a44: ldur            w3, [x4, #0x23]
    //     0x544a48: add             x3, x3, HEAP, lsl #32
    //     0x544a4c: sub             w4, w2, w3
    //     0x544a50: add             x2, fp, w4, sxtw #2
    //     0x544a54: ldr             x2, [x2, #8]
    //     0x544a58: sbfx            x3, x2, #1, #0x1f
    //     0x544a5c: tbz             w2, #0, #0x544a64
    //     0x544a60: ldur            x3, [x2, #7]
    //     0x544a64: mov             x2, x3
    //     0x544a68: b               #0x544a70
    //     0x544a6c: movz            x2, #0x32
    //     0x544a70: stur            x2, [fp, #-8]
    // 0x544a74: CheckStackOverflow
    //     0x544a74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x544a78: cmp             SP, x16
    //     0x544a7c: b.ls            #0x545170
    // 0x544a80: LoadField: r3 = r1->field_b
    //     0x544a80: ldur            w3, [x1, #0xb]
    // 0x544a84: r4 = LoadInt32Instr(r3)
    //     0x544a84: sbfx            x4, x3, #1, #0x1f
    // 0x544a88: cmp             x4, #0xa
    // 0x544a8c: b.le            #0x544ac4
    // 0x544a90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x544a90: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x544a94: r0 = toList()
    //     0x544a94: bl              #0x55df34  ; [dart:core] _GrowableList::toList
    // 0x544a98: mov             x1, x0
    // 0x544a9c: stur            x0, [fp, #-0x20]
    // 0x544aa0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x544aa0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x544aa4: r0 = shuffle()
    //     0x544aa4: bl              #0x546cac  ; [dart:collection] ListBase::shuffle
    // 0x544aa8: ldur            x1, [fp, #-0x20]
    // 0x544aac: r2 = 10
    //     0x544aac: movz            x2, #0xa
    // 0x544ab0: r0 = take()
    //     0x544ab0: bl              #0x35ab20  ; [dart:collection] ListBase::take
    // 0x544ab4: mov             x1, x0
    // 0x544ab8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x544ab8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x544abc: r0 = toList()
    //     0x544abc: bl              #0x516344  ; [dart:_internal] SubListIterable::toList
    // 0x544ac0: b               #0x544ac8
    // 0x544ac4: mov             x0, x1
    // 0x544ac8: stur            x0, [fp, #-0x20]
    // 0x544acc: LoadField: r1 = r0->field_b
    //     0x544acc: ldur            w1, [x0, #0xb]
    // 0x544ad0: cbnz            w1, #0x544ae4
    // 0x544ad4: r0 = 0
    //     0x544ad4: movz            x0, #0
    // 0x544ad8: LeaveFrame
    //     0x544ad8: mov             SP, fp
    //     0x544adc: ldp             fp, lr, [SP], #0x10
    // 0x544ae0: ret
    //     0x544ae0: ret             
    // 0x544ae4: ldur            x2, [fp, #-0x10]
    // 0x544ae8: mov             x1, x0
    // 0x544aec: r0 = first()
    //     0x544aec: bl              #0x53dec0  ; [dart:core] _GrowableList::first
    // 0x544af0: mov             x4, x0
    // 0x544af4: ldur            x3, [fp, #-0x10]
    // 0x544af8: stur            x4, [fp, #-0x28]
    // 0x544afc: r0 = LoadClassIdInstr(r3)
    //     0x544afc: ldur            x0, [x3, #-1]
    //     0x544b00: ubfx            x0, x0, #0xc, #0x14
    // 0x544b04: mov             x1, x3
    // 0x544b08: mov             x2, x4
    // 0x544b0c: r0 = GDT[cid_x0 + 0x888f]()
    //     0x544b0c: movz            x17, #0x888f
    //     0x544b10: add             lr, x0, x17
    //     0x544b14: ldr             lr, [x21, lr, lsl #3]
    //     0x544b18: blr             lr
    // 0x544b1c: mov             x4, x0
    // 0x544b20: ldur            x3, [fp, #-0x10]
    // 0x544b24: stur            x4, [fp, #-0x30]
    // 0x544b28: r0 = LoadClassIdInstr(r3)
    //     0x544b28: ldur            x0, [x3, #-1]
    //     0x544b2c: ubfx            x0, x0, #0xc, #0x14
    // 0x544b30: mov             x1, x3
    // 0x544b34: ldur            x2, [fp, #-0x28]
    // 0x544b38: r0 = GDT[cid_x0 + 0x728f]()
    //     0x544b38: movz            x17, #0x728f
    //     0x544b3c: add             lr, x0, x17
    //     0x544b40: ldr             lr, [x21, lr, lsl #3]
    //     0x544b44: blr             lr
    // 0x544b48: ldur            x0, [fp, #-0x30]
    // 0x544b4c: cmp             w0, NULL
    // 0x544b50: b.eq            #0x544e5c
    // 0x544b54: ldur            x0, [fp, #-0x10]
    // 0x544b58: ldur            x4, [fp, #-0x20]
    // 0x544b5c: LoadField: r2 = r0->field_7
    //     0x544b5c: ldur            w2, [x0, #7]
    // 0x544b60: DecompressPointer r2
    //     0x544b60: add             x2, x2, HEAP, lsl #32
    // 0x544b64: r1 = Null
    //     0x544b64: mov             x1, NULL
    // 0x544b68: r3 = <X0, List<int>>
    //     0x544b68: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a1d8] TypeArguments: <X0, List<int>>
    //     0x544b6c: ldr             x3, [x3, #0x1d8]
    // 0x544b70: r30 = InstantiateTypeArgumentsStub
    //     0x544b70: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x544b74: LoadField: r30 = r30->field_7
    //     0x544b74: ldur            lr, [lr, #7]
    // 0x544b78: blr             lr
    // 0x544b7c: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x544b80: stp             x16, x0, [SP]
    // 0x544b84: r0 = Map._fromLiteral()
    //     0x544b84: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x544b88: mov             x4, x0
    // 0x544b8c: ldur            x3, [fp, #-0x20]
    // 0x544b90: stur            x4, [fp, #-0x50]
    // 0x544b94: LoadField: r5 = r3->field_7
    //     0x544b94: ldur            w5, [x3, #7]
    // 0x544b98: DecompressPointer r5
    //     0x544b98: add             x5, x5, HEAP, lsl #32
    // 0x544b9c: stur            x5, [fp, #-0x48]
    // 0x544ba0: LoadField: r0 = r3->field_b
    //     0x544ba0: ldur            w0, [x3, #0xb]
    // 0x544ba4: r6 = LoadInt32Instr(r0)
    //     0x544ba4: sbfx            x6, x0, #1, #0x1f
    // 0x544ba8: ldur            x7, [fp, #-0x10]
    // 0x544bac: stur            x6, [fp, #-0x40]
    // 0x544bb0: LoadField: r8 = r7->field_33
    //     0x544bb0: ldur            w8, [x7, #0x33]
    // 0x544bb4: DecompressPointer r8
    //     0x544bb4: add             x8, x8, HEAP, lsl #32
    // 0x544bb8: stur            x8, [fp, #-0x30]
    // 0x544bbc: r0 = 0
    //     0x544bbc: movz            x0, #0
    // 0x544bc0: CheckStackOverflow
    //     0x544bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x544bc4: cmp             SP, x16
    //     0x544bc8: b.ls            #0x545178
    // 0x544bcc: LoadField: r1 = r3->field_b
    //     0x544bcc: ldur            w1, [x3, #0xb]
    // 0x544bd0: r2 = LoadInt32Instr(r1)
    //     0x544bd0: sbfx            x2, x1, #1, #0x1f
    // 0x544bd4: cmp             x6, x2
    // 0x544bd8: b.ne            #0x545130
    // 0x544bdc: cmp             x0, x2
    // 0x544be0: b.ge            #0x544d44
    // 0x544be4: LoadField: r1 = r3->field_f
    //     0x544be4: ldur            w1, [x3, #0xf]
    // 0x544be8: DecompressPointer r1
    //     0x544be8: add             x1, x1, HEAP, lsl #32
    // 0x544bec: ArrayLoad: r9 = r1[r0]  ; Unknown_4
    //     0x544bec: add             x16, x1, x0, lsl #2
    //     0x544bf0: ldur            w9, [x16, #0xf]
    // 0x544bf4: DecompressPointer r9
    //     0x544bf4: add             x9, x9, HEAP, lsl #32
    // 0x544bf8: stur            x9, [fp, #-0x28]
    // 0x544bfc: add             x10, x0, #1
    // 0x544c00: stur            x10, [fp, #-0x38]
    // 0x544c04: cmp             w9, NULL
    // 0x544c08: b.ne            #0x544c3c
    // 0x544c0c: mov             x0, x9
    // 0x544c10: mov             x2, x5
    // 0x544c14: r1 = Null
    //     0x544c14: mov             x1, NULL
    // 0x544c18: cmp             w2, NULL
    // 0x544c1c: b.eq            #0x544c3c
    // 0x544c20: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x544c20: ldur            w4, [x2, #0x17]
    // 0x544c24: DecompressPointer r4
    //     0x544c24: add             x4, x4, HEAP, lsl #32
    // 0x544c28: r8 = X0
    //     0x544c28: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x544c2c: LoadField: r9 = r4->field_7
    //     0x544c2c: ldur            x9, [x4, #7]
    // 0x544c30: r3 = Null
    //     0x544c30: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a1e0] Null
    //     0x544c34: ldr             x3, [x3, #0x1e0]
    // 0x544c38: blr             x9
    // 0x544c3c: ldur            x0, [fp, #-0x30]
    // 0x544c40: ldur            x1, [fp, #-0x10]
    // 0x544c44: ldur            x2, [fp, #-0x28]
    // 0x544c48: r0 = getGeneratorInfo()
    //     0x544c48: bl              #0x80d28c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorInfo
    // 0x544c4c: LoadField: r3 = r0->field_27
    //     0x544c4c: ldur            w3, [x0, #0x27]
    // 0x544c50: DecompressPointer r3
    //     0x544c50: add             x3, x3, HEAP, lsl #32
    // 0x544c54: stur            x3, [fp, #-0x60]
    // 0x544c58: cmp             w3, NULL
    // 0x544c5c: b.eq            #0x545180
    // 0x544c60: LoadField: r0 = r3->field_b
    //     0x544c60: ldur            w0, [x3, #0xb]
    // 0x544c64: DecompressPointer r0
    //     0x544c64: add             x0, x0, HEAP, lsl #32
    // 0x544c68: ldur            x1, [fp, #-0x30]
    // 0x544c6c: ldur            x2, [fp, #-0x28]
    // 0x544c70: stur            x0, [fp, #-0x58]
    // 0x544c74: r0 = _getValueOrData()
    //     0x544c74: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x544c78: mov             x1, x0
    // 0x544c7c: ldur            x0, [fp, #-0x30]
    // 0x544c80: LoadField: r2 = r0->field_f
    //     0x544c80: ldur            w2, [x0, #0xf]
    // 0x544c84: DecompressPointer r2
    //     0x544c84: add             x2, x2, HEAP, lsl #32
    // 0x544c88: cmp             w2, w1
    // 0x544c8c: b.ne            #0x544c94
    // 0x544c90: r1 = Null
    //     0x544c90: mov             x1, NULL
    // 0x544c94: cmp             w1, NULL
    // 0x544c98: b.ne            #0x544ca4
    // 0x544c9c: r1 = Null
    //     0x544c9c: mov             x1, NULL
    // 0x544ca0: b               #0x544cb0
    // 0x544ca4: LoadField: r2 = r1->field_b
    //     0x544ca4: ldur            w2, [x1, #0xb]
    // 0x544ca8: DecompressPointer r2
    //     0x544ca8: add             x2, x2, HEAP, lsl #32
    // 0x544cac: mov             x1, x2
    // 0x544cb0: cmp             w1, NULL
    // 0x544cb4: b.ne            #0x544cc4
    // 0x544cb8: r2 = Instance_CustomNum
    //     0x544cb8: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x544cbc: ldr             x2, [x2, #0xa70]
    // 0x544cc0: b               #0x544cc8
    // 0x544cc4: mov             x2, x1
    // 0x544cc8: ldur            x1, [fp, #-0x60]
    // 0x544ccc: LoadField: r3 = r1->field_f
    //     0x544ccc: ldur            w3, [x1, #0xf]
    // 0x544cd0: DecompressPointer r3
    //     0x544cd0: add             x3, x3, HEAP, lsl #32
    // 0x544cd4: mov             x1, x2
    // 0x544cd8: mov             x2, x3
    // 0x544cdc: r0 = mult2()
    //     0x544cdc: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x544ce0: r1 = Function '<anonymous closure>':.
    //     0x544ce0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a1f0] AnonymousClosure: (0x546f54), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll (0x544a08)
    //     0x544ce4: ldr             x1, [x1, #0x1f0]
    // 0x544ce8: r2 = Null
    //     0x544ce8: mov             x2, NULL
    // 0x544cec: r0 = AllocateClosure()
    //     0x544cec: bl              #0x826750  ; AllocateClosureStub
    // 0x544cf0: ldur            x1, [fp, #-0x50]
    // 0x544cf4: ldur            x2, [fp, #-0x58]
    // 0x544cf8: mov             x3, x0
    // 0x544cfc: r0 = putIfAbsent()
    //     0x544cfc: bl              #0x7a3b78  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x544d00: r1 = LoadClassIdInstr(r0)
    //     0x544d00: ldur            x1, [x0, #-1]
    //     0x544d04: ubfx            x1, x1, #0xc, #0x14
    // 0x544d08: ldur            x16, [fp, #-0x28]
    // 0x544d0c: stp             x16, x0, [SP]
    // 0x544d10: mov             x0, x1
    // 0x544d14: r0 = GDT[cid_x0 + 0x95b4]()
    //     0x544d14: movz            x17, #0x95b4
    //     0x544d18: add             lr, x0, x17
    //     0x544d1c: ldr             lr, [x21, lr, lsl #3]
    //     0x544d20: blr             lr
    // 0x544d24: ldur            x0, [fp, #-0x38]
    // 0x544d28: ldur            x7, [fp, #-0x10]
    // 0x544d2c: ldur            x3, [fp, #-0x20]
    // 0x544d30: ldur            x4, [fp, #-0x50]
    // 0x544d34: ldur            x8, [fp, #-0x30]
    // 0x544d38: ldur            x5, [fp, #-0x48]
    // 0x544d3c: ldur            x6, [fp, #-0x40]
    // 0x544d40: b               #0x544bc0
    // 0x544d44: mov             x0, x4
    // 0x544d48: LoadField: r2 = r0->field_7
    //     0x544d48: ldur            w2, [x0, #7]
    // 0x544d4c: DecompressPointer r2
    //     0x544d4c: add             x2, x2, HEAP, lsl #32
    // 0x544d50: r1 = Null
    //     0x544d50: mov             x1, NULL
    // 0x544d54: r3 = <X1>
    //     0x544d54: ldr             x3, [PP, #0x1fb8]  ; [pp+0x1fb8] TypeArguments: <X1>
    // 0x544d58: r0 = Null
    //     0x544d58: mov             x0, NULL
    // 0x544d5c: cmp             x2, x0
    // 0x544d60: b.eq            #0x544d70
    // 0x544d64: r30 = InstantiateTypeArgumentsStub
    //     0x544d64: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x544d68: LoadField: r30 = r30->field_7
    //     0x544d68: ldur            lr, [lr, #7]
    // 0x544d6c: blr             lr
    // 0x544d70: mov             x1, x0
    // 0x544d74: r0 = _CompactValuesIterable()
    //     0x544d74: bl              #0x358260  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x544d78: mov             x1, x0
    // 0x544d7c: ldur            x0, [fp, #-0x50]
    // 0x544d80: StoreField: r1->field_b = r0
    //     0x544d80: stur            w0, [x1, #0xb]
    // 0x544d84: r0 = iterator()
    //     0x544d84: bl              #0x536500  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x544d88: stur            x0, [fp, #-0x30]
    // 0x544d8c: LoadField: r2 = r0->field_7
    //     0x544d8c: ldur            w2, [x0, #7]
    // 0x544d90: DecompressPointer r2
    //     0x544d90: add             x2, x2, HEAP, lsl #32
    // 0x544d94: stur            x2, [fp, #-0x28]
    // 0x544d98: ldur            x3, [fp, #-8]
    // 0x544d9c: r4 = 0
    //     0x544d9c: movz            x4, #0
    // 0x544da0: stur            x4, [fp, #-0x38]
    // 0x544da4: CheckStackOverflow
    //     0x544da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x544da8: cmp             SP, x16
    //     0x544dac: b.ls            #0x545184
    // 0x544db0: mov             x1, x0
    // 0x544db4: r0 = moveNext()
    //     0x544db4: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x544db8: tbnz            w0, #4, #0x544e4c
    // 0x544dbc: ldur            x3, [fp, #-0x30]
    // 0x544dc0: LoadField: r4 = r3->field_33
    //     0x544dc0: ldur            w4, [x3, #0x33]
    // 0x544dc4: DecompressPointer r4
    //     0x544dc4: add             x4, x4, HEAP, lsl #32
    // 0x544dc8: stur            x4, [fp, #-0x48]
    // 0x544dcc: cmp             w4, NULL
    // 0x544dd0: b.ne            #0x544e04
    // 0x544dd4: mov             x0, x4
    // 0x544dd8: ldur            x2, [fp, #-0x28]
    // 0x544ddc: r1 = Null
    //     0x544ddc: mov             x1, NULL
    // 0x544de0: cmp             w2, NULL
    // 0x544de4: b.eq            #0x544e04
    // 0x544de8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x544de8: ldur            w4, [x2, #0x17]
    // 0x544dec: DecompressPointer r4
    //     0x544dec: add             x4, x4, HEAP, lsl #32
    // 0x544df0: r8 = X0
    //     0x544df0: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x544df4: LoadField: r9 = r4->field_7
    //     0x544df4: ldur            x9, [x4, #7]
    // 0x544df8: r3 = Null
    //     0x544df8: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a1f8] Null
    //     0x544dfc: ldr             x3, [x3, #0x1f8]
    // 0x544e00: blr             x9
    // 0x544e04: ldur            x0, [fp, #-8]
    // 0x544e08: ldur            x4, [fp, #-0x38]
    // 0x544e0c: sub             x3, x0, x4
    // 0x544e10: ldur            x1, [fp, #-0x10]
    // 0x544e14: ldur            x2, [fp, #-0x48]
    // 0x544e18: r0 = _buyAllForGroupNewSystem()
    //     0x544e18: bl              #0x5463d4  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::_buyAllForGroupNewSystem
    // 0x544e1c: mov             x1, x0
    // 0x544e20: ldur            x0, [fp, #-0x38]
    // 0x544e24: add             x4, x0, x1
    // 0x544e28: ldur            x0, [fp, #-8]
    // 0x544e2c: cmp             x4, x0
    // 0x544e30: b.ge            #0x544e44
    // 0x544e34: mov             x3, x0
    // 0x544e38: ldur            x0, [fp, #-0x30]
    // 0x544e3c: ldur            x2, [fp, #-0x28]
    // 0x544e40: b               #0x544da0
    // 0x544e44: mov             x0, x4
    // 0x544e48: b               #0x544e50
    // 0x544e4c: ldur            x0, [fp, #-0x38]
    // 0x544e50: LeaveFrame
    //     0x544e50: mov             SP, fp
    //     0x544e54: ldp             fp, lr, [SP], #0x10
    // 0x544e58: ret
    //     0x544e58: ret             
    // 0x544e5c: ldur            x5, [fp, #-0x10]
    // 0x544e60: ldur            x0, [fp, #-8]
    // 0x544e64: ldur            x4, [fp, #-0x20]
    // 0x544e68: LoadField: r2 = r5->field_7
    //     0x544e68: ldur            w2, [x5, #7]
    // 0x544e6c: DecompressPointer r2
    //     0x544e6c: add             x2, x2, HEAP, lsl #32
    // 0x544e70: r1 = Null
    //     0x544e70: mov             x1, NULL
    // 0x544e74: r3 = <X0, List<int>>
    //     0x544e74: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a1d8] TypeArguments: <X0, List<int>>
    //     0x544e78: ldr             x3, [x3, #0x1d8]
    // 0x544e7c: r30 = InstantiateTypeArgumentsStub
    //     0x544e7c: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x544e80: LoadField: r30 = r30->field_7
    //     0x544e80: ldur            lr, [lr, #7]
    // 0x544e84: blr             lr
    // 0x544e88: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x544e8c: stp             x16, x0, [SP]
    // 0x544e90: r0 = Map._fromLiteral()
    //     0x544e90: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x544e94: mov             x4, x0
    // 0x544e98: ldur            x3, [fp, #-0x20]
    // 0x544e9c: stur            x4, [fp, #-0x48]
    // 0x544ea0: LoadField: r5 = r3->field_7
    //     0x544ea0: ldur            w5, [x3, #7]
    // 0x544ea4: DecompressPointer r5
    //     0x544ea4: add             x5, x5, HEAP, lsl #32
    // 0x544ea8: stur            x5, [fp, #-0x30]
    // 0x544eac: LoadField: r0 = r3->field_b
    //     0x544eac: ldur            w0, [x3, #0xb]
    // 0x544eb0: r6 = LoadInt32Instr(r0)
    //     0x544eb0: sbfx            x6, x0, #1, #0x1f
    // 0x544eb4: stur            x6, [fp, #-0x40]
    // 0x544eb8: r0 = 0
    //     0x544eb8: movz            x0, #0
    // 0x544ebc: ldur            x7, [fp, #-0x10]
    // 0x544ec0: CheckStackOverflow
    //     0x544ec0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x544ec4: cmp             SP, x16
    //     0x544ec8: b.ls            #0x54518c
    // 0x544ecc: LoadField: r1 = r3->field_b
    //     0x544ecc: ldur            w1, [x3, #0xb]
    // 0x544ed0: r2 = LoadInt32Instr(r1)
    //     0x544ed0: sbfx            x2, x1, #1, #0x1f
    // 0x544ed4: cmp             x6, x2
    // 0x544ed8: b.ne            #0x545150
    // 0x544edc: cmp             x0, x2
    // 0x544ee0: b.ge            #0x545014
    // 0x544ee4: LoadField: r1 = r3->field_f
    //     0x544ee4: ldur            w1, [x3, #0xf]
    // 0x544ee8: DecompressPointer r1
    //     0x544ee8: add             x1, x1, HEAP, lsl #32
    // 0x544eec: ArrayLoad: r8 = r1[r0]  ; Unknown_4
    //     0x544eec: add             x16, x1, x0, lsl #2
    //     0x544ef0: ldur            w8, [x16, #0xf]
    // 0x544ef4: DecompressPointer r8
    //     0x544ef4: add             x8, x8, HEAP, lsl #32
    // 0x544ef8: stur            x8, [fp, #-0x28]
    // 0x544efc: add             x9, x0, #1
    // 0x544f00: stur            x9, [fp, #-0x38]
    // 0x544f04: cmp             w8, NULL
    // 0x544f08: b.ne            #0x544f3c
    // 0x544f0c: mov             x0, x8
    // 0x544f10: mov             x2, x5
    // 0x544f14: r1 = Null
    //     0x544f14: mov             x1, NULL
    // 0x544f18: cmp             w2, NULL
    // 0x544f1c: b.eq            #0x544f3c
    // 0x544f20: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x544f20: ldur            w4, [x2, #0x17]
    // 0x544f24: DecompressPointer r4
    //     0x544f24: add             x4, x4, HEAP, lsl #32
    // 0x544f28: r8 = X0
    //     0x544f28: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x544f2c: LoadField: r9 = r4->field_7
    //     0x544f2c: ldur            x9, [x4, #7]
    // 0x544f30: r3 = Null
    //     0x544f30: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a208] Null
    //     0x544f34: ldr             x3, [x3, #0x208]
    // 0x544f38: blr             x9
    // 0x544f3c: ldur            x0, [fp, #-0x10]
    // 0x544f40: LoadField: r3 = r0->field_47
    //     0x544f40: ldur            w3, [x0, #0x47]
    // 0x544f44: DecompressPointer r3
    //     0x544f44: add             x3, x3, HEAP, lsl #32
    // 0x544f48: mov             x1, x3
    // 0x544f4c: ldur            x2, [fp, #-0x28]
    // 0x544f50: stur            x3, [fp, #-0x50]
    // 0x544f54: r0 = _getValueOrData()
    //     0x544f54: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x544f58: mov             x1, x0
    // 0x544f5c: ldur            x0, [fp, #-0x50]
    // 0x544f60: LoadField: r2 = r0->field_f
    //     0x544f60: ldur            w2, [x0, #0xf]
    // 0x544f64: DecompressPointer r2
    //     0x544f64: add             x2, x2, HEAP, lsl #32
    // 0x544f68: cmp             w2, w1
    // 0x544f6c: b.ne            #0x544f74
    // 0x544f70: r1 = Null
    //     0x544f70: mov             x1, NULL
    // 0x544f74: cmp             w1, NULL
    // 0x544f78: b.ne            #0x544f84
    // 0x544f7c: r3 = 0
    //     0x544f7c: movz            x3, #0
    // 0x544f80: b               #0x544f88
    // 0x544f84: mov             x3, x1
    // 0x544f88: ldur            x4, [fp, #-0x10]
    // 0x544f8c: r0 = LoadClassIdInstr(r4)
    //     0x544f8c: ldur            x0, [x4, #-1]
    //     0x544f90: ubfx            x0, x0, #0xc, #0x14
    // 0x544f94: mov             x1, x4
    // 0x544f98: ldur            x2, [fp, #-0x28]
    // 0x544f9c: r0 = GDT[cid_x0 + 0xad4d]()
    //     0x544f9c: movz            x17, #0xad4d
    //     0x544fa0: add             lr, x0, x17
    //     0x544fa4: ldr             lr, [x21, lr, lsl #3]
    //     0x544fa8: blr             lr
    // 0x544fac: LoadField: r3 = r0->field_b
    //     0x544fac: ldur            w3, [x0, #0xb]
    // 0x544fb0: DecompressPointer r3
    //     0x544fb0: add             x3, x3, HEAP, lsl #32
    // 0x544fb4: stur            x3, [fp, #-0x50]
    // 0x544fb8: r1 = Function '<anonymous closure>':.
    //     0x544fb8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a218] AnonymousClosure: (0x546f54), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyAll (0x544a08)
    //     0x544fbc: ldr             x1, [x1, #0x218]
    // 0x544fc0: r2 = Null
    //     0x544fc0: mov             x2, NULL
    // 0x544fc4: r0 = AllocateClosure()
    //     0x544fc4: bl              #0x826750  ; AllocateClosureStub
    // 0x544fc8: ldur            x1, [fp, #-0x48]
    // 0x544fcc: ldur            x2, [fp, #-0x50]
    // 0x544fd0: mov             x3, x0
    // 0x544fd4: r0 = putIfAbsent()
    //     0x544fd4: bl              #0x7a3b78  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x544fd8: r1 = LoadClassIdInstr(r0)
    //     0x544fd8: ldur            x1, [x0, #-1]
    //     0x544fdc: ubfx            x1, x1, #0xc, #0x14
    // 0x544fe0: ldur            x16, [fp, #-0x28]
    // 0x544fe4: stp             x16, x0, [SP]
    // 0x544fe8: mov             x0, x1
    // 0x544fec: r0 = GDT[cid_x0 + 0x95b4]()
    //     0x544fec: movz            x17, #0x95b4
    //     0x544ff0: add             lr, x0, x17
    //     0x544ff4: ldr             lr, [x21, lr, lsl #3]
    //     0x544ff8: blr             lr
    // 0x544ffc: ldur            x0, [fp, #-0x38]
    // 0x545000: ldur            x3, [fp, #-0x20]
    // 0x545004: ldur            x4, [fp, #-0x48]
    // 0x545008: ldur            x5, [fp, #-0x30]
    // 0x54500c: ldur            x6, [fp, #-0x40]
    // 0x545010: b               #0x544ebc
    // 0x545014: mov             x0, x4
    // 0x545018: LoadField: r2 = r0->field_7
    //     0x545018: ldur            w2, [x0, #7]
    // 0x54501c: DecompressPointer r2
    //     0x54501c: add             x2, x2, HEAP, lsl #32
    // 0x545020: r1 = Null
    //     0x545020: mov             x1, NULL
    // 0x545024: r3 = <X1>
    //     0x545024: ldr             x3, [PP, #0x1fb8]  ; [pp+0x1fb8] TypeArguments: <X1>
    // 0x545028: r0 = Null
    //     0x545028: mov             x0, NULL
    // 0x54502c: cmp             x2, x0
    // 0x545030: b.eq            #0x545040
    // 0x545034: r30 = InstantiateTypeArgumentsStub
    //     0x545034: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x545038: LoadField: r30 = r30->field_7
    //     0x545038: ldur            lr, [lr, #7]
    // 0x54503c: blr             lr
    // 0x545040: mov             x1, x0
    // 0x545044: r0 = _CompactValuesIterable()
    //     0x545044: bl              #0x358260  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x545048: mov             x1, x0
    // 0x54504c: ldur            x0, [fp, #-0x48]
    // 0x545050: StoreField: r1->field_b = r0
    //     0x545050: stur            w0, [x1, #0xb]
    // 0x545054: r0 = iterator()
    //     0x545054: bl              #0x536500  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x545058: stur            x0, [fp, #-0x30]
    // 0x54505c: LoadField: r2 = r0->field_7
    //     0x54505c: ldur            w2, [x0, #7]
    // 0x545060: DecompressPointer r2
    //     0x545060: add             x2, x2, HEAP, lsl #32
    // 0x545064: stur            x2, [fp, #-0x28]
    // 0x545068: ldur            x3, [fp, #-8]
    // 0x54506c: r4 = 0
    //     0x54506c: movz            x4, #0
    // 0x545070: stur            x4, [fp, #-0x38]
    // 0x545074: CheckStackOverflow
    //     0x545074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x545078: cmp             SP, x16
    //     0x54507c: b.ls            #0x545194
    // 0x545080: mov             x1, x0
    // 0x545084: r0 = moveNext()
    //     0x545084: bl              #0x7ce7dc  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x545088: tbnz            w0, #4, #0x545120
    // 0x54508c: ldur            x3, [fp, #-0x30]
    // 0x545090: LoadField: r4 = r3->field_33
    //     0x545090: ldur            w4, [x3, #0x33]
    // 0x545094: DecompressPointer r4
    //     0x545094: add             x4, x4, HEAP, lsl #32
    // 0x545098: stur            x4, [fp, #-0x48]
    // 0x54509c: cmp             w4, NULL
    // 0x5450a0: b.ne            #0x5450d4
    // 0x5450a4: mov             x0, x4
    // 0x5450a8: ldur            x2, [fp, #-0x28]
    // 0x5450ac: r1 = Null
    //     0x5450ac: mov             x1, NULL
    // 0x5450b0: cmp             w2, NULL
    // 0x5450b4: b.eq            #0x5450d4
    // 0x5450b8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x5450b8: ldur            w4, [x2, #0x17]
    // 0x5450bc: DecompressPointer r4
    //     0x5450bc: add             x4, x4, HEAP, lsl #32
    // 0x5450c0: r8 = X0
    //     0x5450c0: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x5450c4: LoadField: r9 = r4->field_7
    //     0x5450c4: ldur            x9, [x4, #7]
    // 0x5450c8: r3 = Null
    //     0x5450c8: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a220] Null
    //     0x5450cc: ldr             x3, [x3, #0x220]
    // 0x5450d0: blr             x9
    // 0x5450d4: ldur            x0, [fp, #-8]
    // 0x5450d8: ldur            x4, [fp, #-0x38]
    // 0x5450dc: sub             x3, x0, x4
    // 0x5450e0: ldur            x1, [fp, #-0x10]
    // 0x5450e4: ldur            x2, [fp, #-0x48]
    // 0x5450e8: ldur            x5, [fp, #-0x18]
    // 0x5450ec: r0 = _buyAllForGroup()
    //     0x5450ec: bl              #0x5451d8  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::_buyAllForGroup
    // 0x5450f0: mov             x1, x0
    // 0x5450f4: ldur            x0, [fp, #-0x38]
    // 0x5450f8: add             x4, x0, x1
    // 0x5450fc: ldur            x0, [fp, #-8]
    // 0x545100: cmp             x4, x0
    // 0x545104: b.ge            #0x545118
    // 0x545108: mov             x3, x0
    // 0x54510c: ldur            x0, [fp, #-0x30]
    // 0x545110: ldur            x2, [fp, #-0x28]
    // 0x545114: b               #0x545070
    // 0x545118: mov             x0, x4
    // 0x54511c: b               #0x545124
    // 0x545120: ldur            x0, [fp, #-0x38]
    // 0x545124: LeaveFrame
    //     0x545124: mov             SP, fp
    //     0x545128: ldp             fp, lr, [SP], #0x10
    // 0x54512c: ret
    //     0x54512c: ret             
    // 0x545130: mov             x0, x3
    // 0x545134: r0 = ConcurrentModificationError()
    //     0x545134: bl              #0x327c48  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x545138: mov             x1, x0
    // 0x54513c: ldur            x0, [fp, #-0x20]
    // 0x545140: StoreField: r1->field_b = r0
    //     0x545140: stur            w0, [x1, #0xb]
    // 0x545144: mov             x0, x1
    // 0x545148: r0 = Throw()
    //     0x545148: bl              #0x825670  ; ThrowStub
    // 0x54514c: brk             #0
    // 0x545150: mov             x0, x3
    // 0x545154: r0 = ConcurrentModificationError()
    //     0x545154: bl              #0x327c48  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x545158: mov             x1, x0
    // 0x54515c: ldur            x0, [fp, #-0x20]
    // 0x545160: StoreField: r1->field_b = r0
    //     0x545160: stur            w0, [x1, #0xb]
    // 0x545164: mov             x0, x1
    // 0x545168: r0 = Throw()
    //     0x545168: bl              #0x825670  ; ThrowStub
    // 0x54516c: brk             #0
    // 0x545170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545170: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545174: b               #0x544a80
    // 0x545178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545178: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54517c: b               #0x544bcc
    // 0x545180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x545180: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x545184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545184: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545188: b               #0x544db0
    // 0x54518c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54518c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545190: b               #0x544ecc
    // 0x545194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545194: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545198: b               #0x545080
  }
  _ _buyAllForGroup(/* No info */) {
    // ** addr: 0x5451d8, size: 0x5b8
    // 0x5451d8: EnterFrame
    //     0x5451d8: stp             fp, lr, [SP, #-0x10]!
    //     0x5451dc: mov             fp, SP
    // 0x5451e0: AllocStack(0x90)
    //     0x5451e0: sub             SP, SP, #0x90
    // 0x5451e4: SetupParameters(IPlayableGameState<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x5451e4: mov             x0, x1
    //     0x5451e8: stur            x1, [fp, #-8]
    //     0x5451ec: mov             x1, x2
    //     0x5451f0: stur            x2, [fp, #-0x10]
    //     0x5451f4: stur            x3, [fp, #-0x18]
    //     0x5451f8: stur            x5, [fp, #-0x20]
    // 0x5451fc: CheckStackOverflow
    //     0x5451fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x545200: cmp             SP, x16
    //     0x545204: b.ls            #0x545768
    // 0x545208: r1 = 1
    //     0x545208: movz            x1, #0x1
    // 0x54520c: r0 = AllocateContext()
    //     0x54520c: bl              #0x82637c  ; AllocateContextStub
    // 0x545210: mov             x3, x0
    // 0x545214: ldur            x2, [fp, #-8]
    // 0x545218: stur            x3, [fp, #-0x28]
    // 0x54521c: StoreField: r3->field_f = r2
    //     0x54521c: stur            w2, [x3, #0xf]
    // 0x545220: ldur            x4, [fp, #-0x10]
    // 0x545224: r0 = LoadClassIdInstr(r4)
    //     0x545224: ldur            x0, [x4, #-1]
    //     0x545228: ubfx            x0, x0, #0xc, #0x14
    // 0x54522c: mov             x1, x4
    // 0x545230: r0 = GDT[cid_x0 + 0x8bb1]()
    //     0x545230: movz            x17, #0x8bb1
    //     0x545234: add             lr, x0, x17
    //     0x545238: ldr             lr, [x21, lr, lsl #3]
    //     0x54523c: blr             lr
    // 0x545240: tbnz            w0, #4, #0x545254
    // 0x545244: r0 = 0
    //     0x545244: movz            x0, #0
    // 0x545248: LeaveFrame
    //     0x545248: mov             SP, fp
    //     0x54524c: ldp             fp, lr, [SP], #0x10
    // 0x545250: ret
    //     0x545250: ret             
    // 0x545254: ldur            x2, [fp, #-8]
    // 0x545258: ldur            x1, [fp, #-0x10]
    // 0x54525c: r0 = LoadClassIdInstr(r1)
    //     0x54525c: ldur            x0, [x1, #-1]
    //     0x545260: ubfx            x0, x0, #0xc, #0x14
    // 0x545264: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x545264: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x545268: r0 = GDT[cid_x0 + 0x8751]()
    //     0x545268: movz            x17, #0x8751
    //     0x54526c: add             lr, x0, x17
    //     0x545270: ldr             lr, [x21, lr, lsl #3]
    //     0x545274: blr             lr
    // 0x545278: ldur            x2, [fp, #-0x28]
    // 0x54527c: r1 = Function '<anonymous closure>':.
    //     0x54527c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a230] AnonymousClosure: (0x546314), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::_buyAllForGroup (0x5451d8)
    //     0x545280: ldr             x1, [x1, #0x230]
    // 0x545284: stur            x0, [fp, #-0x10]
    // 0x545288: r0 = AllocateClosure()
    //     0x545288: bl              #0x826750  ; AllocateClosureStub
    // 0x54528c: r16 = <CustomNum>
    //     0x54528c: add             x16, PP, #0x15, lsl #12  ; [pp+0x158f8] TypeArguments: <CustomNum>
    //     0x545290: ldr             x16, [x16, #0x8f8]
    // 0x545294: ldur            lr, [fp, #-0x10]
    // 0x545298: stp             lr, x16, [SP, #8]
    // 0x54529c: str             x0, [SP]
    // 0x5452a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5452a0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5452a4: r0 = map()
    //     0x5452a4: bl              #0x55b6f4  ; [dart:collection] ListBase::map
    // 0x5452a8: mov             x1, x0
    // 0x5452ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5452ac: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5452b0: r0 = toList()
    //     0x5452b0: bl              #0x55e44c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::toList
    // 0x5452b4: mov             x4, x0
    // 0x5452b8: ldur            x3, [fp, #-0x10]
    // 0x5452bc: stur            x4, [fp, #-0x38]
    // 0x5452c0: LoadField: r0 = r3->field_b
    //     0x5452c0: ldur            w0, [x3, #0xb]
    // 0x5452c4: r1 = LoadInt32Instr(r0)
    //     0x5452c4: sbfx            x1, x0, #1, #0x1f
    // 0x5452c8: mov             x0, x1
    // 0x5452cc: r1 = 0
    //     0x5452cc: movz            x1, #0
    // 0x5452d0: cmp             x1, x0
    // 0x5452d4: b.hs            #0x545770
    // 0x5452d8: LoadField: r0 = r3->field_f
    //     0x5452d8: ldur            w0, [x3, #0xf]
    // 0x5452dc: DecompressPointer r0
    //     0x5452dc: add             x0, x0, HEAP, lsl #32
    // 0x5452e0: LoadField: r5 = r0->field_f
    //     0x5452e0: ldur            w5, [x0, #0xf]
    // 0x5452e4: DecompressPointer r5
    //     0x5452e4: add             x5, x5, HEAP, lsl #32
    // 0x5452e8: ldur            x0, [fp, #-8]
    // 0x5452ec: stur            x5, [fp, #-0x30]
    // 0x5452f0: LoadField: r6 = r0->field_47
    //     0x5452f0: ldur            w6, [x0, #0x47]
    // 0x5452f4: DecompressPointer r6
    //     0x5452f4: add             x6, x6, HEAP, lsl #32
    // 0x5452f8: mov             x1, x6
    // 0x5452fc: mov             x2, x5
    // 0x545300: stur            x6, [fp, #-0x28]
    // 0x545304: r0 = _getValueOrData()
    //     0x545304: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x545308: mov             x1, x0
    // 0x54530c: ldur            x0, [fp, #-0x28]
    // 0x545310: LoadField: r2 = r0->field_f
    //     0x545310: ldur            w2, [x0, #0xf]
    // 0x545314: DecompressPointer r2
    //     0x545314: add             x2, x2, HEAP, lsl #32
    // 0x545318: cmp             w2, w1
    // 0x54531c: b.ne            #0x545328
    // 0x545320: r0 = Null
    //     0x545320: mov             x0, NULL
    // 0x545324: b               #0x54532c
    // 0x545328: mov             x0, x1
    // 0x54532c: cmp             w0, NULL
    // 0x545330: b.ne            #0x54533c
    // 0x545334: r3 = 0
    //     0x545334: movz            x3, #0
    // 0x545338: b               #0x545340
    // 0x54533c: mov             x3, x0
    // 0x545340: ldur            x5, [fp, #-8]
    // 0x545344: ldur            x4, [fp, #-0x38]
    // 0x545348: r0 = LoadClassIdInstr(r5)
    //     0x545348: ldur            x0, [x5, #-1]
    //     0x54534c: ubfx            x0, x0, #0xc, #0x14
    // 0x545350: mov             x1, x5
    // 0x545354: ldur            x2, [fp, #-0x30]
    // 0x545358: r0 = GDT[cid_x0 + 0xad4d]()
    //     0x545358: movz            x17, #0xad4d
    //     0x54535c: add             lr, x0, x17
    //     0x545360: ldr             lr, [x21, lr, lsl #3]
    //     0x545364: blr             lr
    // 0x545368: LoadField: r4 = r0->field_b
    //     0x545368: ldur            w4, [x0, #0xb]
    // 0x54536c: DecompressPointer r4
    //     0x54536c: add             x4, x4, HEAP, lsl #32
    // 0x545370: ldur            x5, [fp, #-8]
    // 0x545374: stur            x4, [fp, #-0x78]
    // 0x545378: LoadField: r6 = r5->field_7
    //     0x545378: ldur            w6, [x5, #7]
    // 0x54537c: DecompressPointer r6
    //     0x54537c: add             x6, x6, HEAP, lsl #32
    // 0x545380: ldur            x7, [fp, #-0x38]
    // 0x545384: stur            x6, [fp, #-0x70]
    // 0x545388: LoadField: r8 = r7->field_7
    //     0x545388: ldur            w8, [x7, #7]
    // 0x54538c: DecompressPointer r8
    //     0x54538c: add             x8, x8, HEAP, lsl #32
    // 0x545390: stur            x8, [fp, #-0x68]
    // 0x545394: r12 = 0
    //     0x545394: movz            x12, #0
    // 0x545398: r11 = 0
    //     0x545398: movz            x11, #0
    // 0x54539c: ldur            x10, [fp, #-0x18]
    // 0x5453a0: ldur            x9, [fp, #-0x10]
    // 0x5453a4: stur            x12, [fp, #-0x58]
    // 0x5453a8: stur            x11, [fp, #-0x60]
    // 0x5453ac: CheckStackOverflow
    //     0x5453ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5453b0: cmp             SP, x16
    //     0x5453b4: b.ls            #0x545774
    // 0x5453b8: cmp             x11, x10
    // 0x5453bc: b.ge            #0x5456e0
    // 0x5453c0: r19 = -1
    //     0x5453c0: movn            x19, #0
    // 0x5453c4: r14 = Null
    //     0x5453c4: mov             x14, NULL
    // 0x5453c8: r13 = 0
    //     0x5453c8: movz            x13, #0
    // 0x5453cc: stur            x19, [fp, #-0x40]
    // 0x5453d0: stur            x14, [fp, #-0x48]
    // 0x5453d4: stur            x13, [fp, #-0x50]
    // 0x5453d8: CheckStackOverflow
    //     0x5453d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5453dc: cmp             SP, x16
    //     0x5453e0: b.ls            #0x54577c
    // 0x5453e4: LoadField: r0 = r9->field_b
    //     0x5453e4: ldur            w0, [x9, #0xb]
    // 0x5453e8: r1 = LoadInt32Instr(r0)
    //     0x5453e8: sbfx            x1, x0, #1, #0x1f
    // 0x5453ec: cmp             x13, x1
    // 0x5453f0: b.ge            #0x545504
    // 0x5453f4: LoadField: r0 = r7->field_b
    //     0x5453f4: ldur            w0, [x7, #0xb]
    // 0x5453f8: r1 = LoadInt32Instr(r0)
    //     0x5453f8: sbfx            x1, x0, #1, #0x1f
    // 0x5453fc: mov             x0, x1
    // 0x545400: mov             x1, x13
    // 0x545404: cmp             x1, x0
    // 0x545408: b.hs            #0x545784
    // 0x54540c: LoadField: r0 = r7->field_f
    //     0x54540c: ldur            w0, [x7, #0xf]
    // 0x545410: DecompressPointer r0
    //     0x545410: add             x0, x0, HEAP, lsl #32
    // 0x545414: ArrayLoad: r20 = r0[r13]  ; Unknown_4
    //     0x545414: add             x16, x0, x13, lsl #2
    //     0x545418: ldur            w20, [x16, #0xf]
    // 0x54541c: DecompressPointer r20
    //     0x54541c: add             x20, x20, HEAP, lsl #32
    // 0x545420: stur            x20, [fp, #-0x30]
    // 0x545424: LoadField: r0 = r5->field_37
    //     0x545424: ldur            w0, [x5, #0x37]
    // 0x545428: DecompressPointer r0
    //     0x545428: add             x0, x0, HEAP, lsl #32
    // 0x54542c: mov             x2, x6
    // 0x545430: stur            x0, [fp, #-0x28]
    // 0x545434: r1 = Null
    //     0x545434: mov             x1, NULL
    // 0x545438: r3 = <X0, CustomNum>
    //     0x545438: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x54543c: ldr             x3, [x3, #0xb10]
    // 0x545440: r30 = InstantiateTypeArgumentsStub
    //     0x545440: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x545444: LoadField: r30 = r30->field_7
    //     0x545444: ldur            lr, [lr, #7]
    // 0x545448: blr             lr
    // 0x54544c: mov             x1, x0
    // 0x545450: r0 = Tuple2()
    //     0x545450: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x545454: mov             x1, x0
    // 0x545458: ldur            x0, [fp, #-0x78]
    // 0x54545c: StoreField: r1->field_b = r0
    //     0x54545c: stur            w0, [x1, #0xb]
    // 0x545460: ldur            x2, [fp, #-0x30]
    // 0x545464: StoreField: r1->field_f = r2
    //     0x545464: stur            w2, [x1, #0xf]
    // 0x545468: ldur            x16, [fp, #-0x70]
    // 0x54546c: ldur            lr, [fp, #-0x28]
    // 0x545470: stp             lr, x16, [SP, #8]
    // 0x545474: str             x1, [SP]
    // 0x545478: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x545478: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x54547c: r0 = MapOperations.isSupersetOfTuple()
    //     0x54547c: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x545480: tbnz            w0, #4, #0x5454c8
    // 0x545484: ldur            x0, [fp, #-0x48]
    // 0x545488: cmp             w0, NULL
    // 0x54548c: b.ne            #0x545498
    // 0x545490: ldur            x1, [fp, #-0x30]
    // 0x545494: b               #0x5454ac
    // 0x545498: ldur            x1, [fp, #-0x30]
    // 0x54549c: LoadField: d0 = r1->field_7
    //     0x54549c: ldur            d0, [x1, #7]
    // 0x5454a0: LoadField: d1 = r0->field_7
    //     0x5454a0: ldur            d1, [x0, #7]
    // 0x5454a4: fcmp            d1, d0
    // 0x5454a8: b.le            #0x5454b8
    // 0x5454ac: mov             x0, x1
    // 0x5454b0: ldur            x1, [fp, #-0x50]
    // 0x5454b4: b               #0x5454bc
    // 0x5454b8: ldur            x1, [fp, #-0x40]
    // 0x5454bc: mov             x19, x1
    // 0x5454c0: mov             x14, x0
    // 0x5454c4: b               #0x5454d4
    // 0x5454c8: ldur            x0, [fp, #-0x48]
    // 0x5454cc: ldur            x19, [fp, #-0x40]
    // 0x5454d0: mov             x14, x0
    // 0x5454d4: ldur            x0, [fp, #-0x50]
    // 0x5454d8: add             x13, x0, #1
    // 0x5454dc: ldur            x5, [fp, #-8]
    // 0x5454e0: ldur            x10, [fp, #-0x18]
    // 0x5454e4: ldur            x9, [fp, #-0x10]
    // 0x5454e8: ldur            x7, [fp, #-0x38]
    // 0x5454ec: ldur            x4, [fp, #-0x78]
    // 0x5454f0: ldur            x12, [fp, #-0x58]
    // 0x5454f4: ldur            x11, [fp, #-0x60]
    // 0x5454f8: ldur            x6, [fp, #-0x70]
    // 0x5454fc: ldur            x8, [fp, #-0x68]
    // 0x545500: b               #0x5453cc
    // 0x545504: mov             x2, x19
    // 0x545508: cmn             x2, #1
    // 0x54550c: b.eq            #0x5456d8
    // 0x545510: ldur            x3, [fp, #-8]
    // 0x545514: ldur            x4, [fp, #-0x10]
    // 0x545518: ldur            x5, [fp, #-0x58]
    // 0x54551c: mov             x0, x1
    // 0x545520: mov             x1, x2
    // 0x545524: cmp             x1, x0
    // 0x545528: b.hs            #0x545788
    // 0x54552c: LoadField: r0 = r4->field_f
    //     0x54552c: ldur            w0, [x4, #0xf]
    // 0x545530: DecompressPointer r0
    //     0x545530: add             x0, x0, HEAP, lsl #32
    // 0x545534: ArrayLoad: r6 = r0[r2]  ; Unknown_4
    //     0x545534: add             x16, x0, x2, lsl #2
    //     0x545538: ldur            w6, [x16, #0xf]
    // 0x54553c: DecompressPointer r6
    //     0x54553c: add             x6, x6, HEAP, lsl #32
    // 0x545540: stur            x6, [fp, #-0x30]
    // 0x545544: LoadField: r1 = r3->field_47
    //     0x545544: ldur            w1, [x3, #0x47]
    // 0x545548: DecompressPointer r1
    //     0x545548: add             x1, x1, HEAP, lsl #32
    // 0x54554c: stur            x1, [fp, #-0x28]
    // 0x545550: r0 = LoadClassIdInstr(r3)
    //     0x545550: ldur            x0, [x3, #-1]
    //     0x545554: ubfx            x0, x0, #0xc, #0x14
    // 0x545558: str             x3, [SP]
    // 0x54555c: r0 = GDT[cid_x0 + -0xff5]()
    //     0x54555c: sub             lr, x0, #0xff5
    //     0x545560: ldr             lr, [x21, lr, lsl #3]
    //     0x545564: blr             lr
    // 0x545568: r16 = false
    //     0x545568: add             x16, NULL, #0x30  ; false
    // 0x54556c: r30 = false
    //     0x54556c: add             lr, NULL, #0x30  ; false
    // 0x545570: stp             lr, x16, [SP]
    // 0x545574: ldur            x1, [fp, #-8]
    // 0x545578: ldur            x2, [fp, #-0x28]
    // 0x54557c: mov             x3, x0
    // 0x545580: ldur            x6, [fp, #-0x30]
    // 0x545584: r5 = 2
    //     0x545584: movz            x5, #0x2
    // 0x545588: r4 = const [0, 0x7, 0x2, 0x5, allowSave, 0x5, notify, 0x6, null]
    //     0x545588: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a238] List(9) [0, 0x7, 0x2, 0x5, "allowSave", 0x5, "notify", 0x6, Null]
    //     0x54558c: ldr             x4, [x4, #0x238]
    // 0x545590: r0 = buyGenerator()
    //     0x545590: bl              #0x545790  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator
    // 0x545594: ldur            x0, [fp, #-0x58]
    // 0x545598: add             x12, x0, #1
    // 0x54559c: ldur            x0, [fp, #-8]
    // 0x5455a0: stur            x12, [fp, #-0x50]
    // 0x5455a4: LoadField: r3 = r0->field_47
    //     0x5455a4: ldur            w3, [x0, #0x47]
    // 0x5455a8: DecompressPointer r3
    //     0x5455a8: add             x3, x3, HEAP, lsl #32
    // 0x5455ac: mov             x1, x3
    // 0x5455b0: ldur            x2, [fp, #-0x30]
    // 0x5455b4: stur            x3, [fp, #-0x28]
    // 0x5455b8: r0 = _getValueOrData()
    //     0x5455b8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5455bc: mov             x1, x0
    // 0x5455c0: ldur            x0, [fp, #-0x28]
    // 0x5455c4: LoadField: r2 = r0->field_f
    //     0x5455c4: ldur            w2, [x0, #0xf]
    // 0x5455c8: DecompressPointer r2
    //     0x5455c8: add             x2, x2, HEAP, lsl #32
    // 0x5455cc: cmp             w2, w1
    // 0x5455d0: b.ne            #0x5455dc
    // 0x5455d4: r0 = Null
    //     0x5455d4: mov             x0, NULL
    // 0x5455d8: b               #0x5455e0
    // 0x5455dc: mov             x0, x1
    // 0x5455e0: cmp             w0, NULL
    // 0x5455e4: b.ne            #0x5455f0
    // 0x5455e8: r3 = 0
    //     0x5455e8: movz            x3, #0
    // 0x5455ec: b               #0x5455f4
    // 0x5455f0: mov             x3, x0
    // 0x5455f4: ldur            x4, [fp, #-8]
    // 0x5455f8: ldur            x6, [fp, #-0x38]
    // 0x5455fc: ldur            x7, [fp, #-0x60]
    // 0x545600: ldur            x5, [fp, #-0x40]
    // 0x545604: r0 = LoadClassIdInstr(r4)
    //     0x545604: ldur            x0, [x4, #-1]
    //     0x545608: ubfx            x0, x0, #0xc, #0x14
    // 0x54560c: mov             x1, x4
    // 0x545610: ldur            x2, [fp, #-0x30]
    // 0x545614: r0 = GDT[cid_x0 + 0xad4d]()
    //     0x545614: movz            x17, #0xad4d
    //     0x545618: add             lr, x0, x17
    //     0x54561c: ldr             lr, [x21, lr, lsl #3]
    //     0x545620: blr             lr
    // 0x545624: LoadField: r3 = r0->field_f
    //     0x545624: ldur            w3, [x0, #0xf]
    // 0x545628: DecompressPointer r3
    //     0x545628: add             x3, x3, HEAP, lsl #32
    // 0x54562c: mov             x0, x3
    // 0x545630: ldur            x2, [fp, #-0x68]
    // 0x545634: stur            x3, [fp, #-0x28]
    // 0x545638: r1 = Null
    //     0x545638: mov             x1, NULL
    // 0x54563c: cmp             w2, NULL
    // 0x545640: b.eq            #0x545660
    // 0x545644: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x545644: ldur            w4, [x2, #0x17]
    // 0x545648: DecompressPointer r4
    //     0x545648: add             x4, x4, HEAP, lsl #32
    // 0x54564c: r8 = X0
    //     0x54564c: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x545650: LoadField: r9 = r4->field_7
    //     0x545650: ldur            x9, [x4, #7]
    // 0x545654: r3 = Null
    //     0x545654: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a240] Null
    //     0x545658: ldr             x3, [x3, #0x240]
    // 0x54565c: blr             x9
    // 0x545660: ldur            x2, [fp, #-0x38]
    // 0x545664: LoadField: r0 = r2->field_b
    //     0x545664: ldur            w0, [x2, #0xb]
    // 0x545668: r1 = LoadInt32Instr(r0)
    //     0x545668: sbfx            x1, x0, #1, #0x1f
    // 0x54566c: mov             x0, x1
    // 0x545670: ldur            x1, [fp, #-0x40]
    // 0x545674: cmp             x1, x0
    // 0x545678: b.hs            #0x54578c
    // 0x54567c: LoadField: r1 = r2->field_f
    //     0x54567c: ldur            w1, [x2, #0xf]
    // 0x545680: DecompressPointer r1
    //     0x545680: add             x1, x1, HEAP, lsl #32
    // 0x545684: ldur            x0, [fp, #-0x28]
    // 0x545688: ldur            x3, [fp, #-0x40]
    // 0x54568c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x54568c: add             x25, x1, x3, lsl #2
    //     0x545690: add             x25, x25, #0xf
    //     0x545694: str             w0, [x25]
    //     0x545698: tbz             w0, #0, #0x5456b4
    //     0x54569c: ldurb           w16, [x1, #-1]
    //     0x5456a0: ldurb           w17, [x0, #-1]
    //     0x5456a4: and             x16, x17, x16, lsr #2
    //     0x5456a8: tst             x16, HEAP, lsr #32
    //     0x5456ac: b.eq            #0x5456b4
    //     0x5456b0: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x5456b4: ldur            x0, [fp, #-0x60]
    // 0x5456b8: add             x11, x0, #1
    // 0x5456bc: ldur            x12, [fp, #-0x50]
    // 0x5456c0: ldur            x5, [fp, #-8]
    // 0x5456c4: mov             x7, x2
    // 0x5456c8: ldur            x4, [fp, #-0x78]
    // 0x5456cc: ldur            x6, [fp, #-0x70]
    // 0x5456d0: ldur            x8, [fp, #-0x68]
    // 0x5456d4: b               #0x54539c
    // 0x5456d8: ldur            x0, [fp, #-0x58]
    // 0x5456dc: b               #0x5456e4
    // 0x5456e0: mov             x0, x12
    // 0x5456e4: cmp             x0, #0
    // 0x5456e8: b.le            #0x545758
    // 0x5456ec: ldur            x1, [fp, #-0x20]
    // 0x5456f0: r0 = LoadStaticField(0x1030)
    //     0x5456f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x5456f4: ldr             x0, [x0, #0x2060]
    // 0x5456f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x5456fc: cmp             w0, w16
    // 0x545700: b.ne            #0x545710
    // 0x545704: r2 = currencyCounterGroup
    //     0x545704: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc28] Field <::.currencyCounterGroup>: static late (offset: 0x1030)
    //     0x545708: ldr             x2, [x2, #0xc28]
    // 0x54570c: r0 = InitLateStaticField()
    //     0x54570c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x545710: mov             x1, x0
    // 0x545714: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x545714: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x545718: r0 = notifyAll()
    //     0x545718: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x54571c: r0 = LoadStaticField(0xfc0)
    //     0x54571c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x545720: ldr             x0, [x0, #0x1f80]
    // 0x545724: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x545728: cmp             w0, w16
    // 0x54572c: b.ne            #0x54573c
    // 0x545730: r2 = buyableTileStates
    //     0x545730: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc50] Field <::.buyableTileStates>: static late (offset: 0xfc0)
    //     0x545734: ldr             x2, [x2, #0xc50]
    // 0x545738: r0 = InitLateStaticField()
    //     0x545738: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x54573c: mov             x1, x0
    // 0x545740: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x545740: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x545744: r0 = notifyAll()
    //     0x545744: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x545748: ldur            x0, [fp, #-0x20]
    // 0x54574c: tbnz            w0, #4, #0x545758
    // 0x545750: ldur            x1, [fp, #-8]
    // 0x545754: r0 = saveDeferred()
    //     0x545754: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x545758: ldur            x0, [fp, #-0x58]
    // 0x54575c: LeaveFrame
    //     0x54575c: mov             SP, fp
    //     0x545760: ldp             fp, lr, [SP], #0x10
    // 0x545764: ret
    //     0x545764: ret             
    // 0x545768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545768: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54576c: b               #0x545208
    // 0x545770: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x545770: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x545774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545774: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545778: b               #0x5453b8
    // 0x54577c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54577c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545780: b               #0x5453e4
    // 0x545784: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x545784: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x545788: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x545788: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x54578c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x54578c: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ buyGenerator(/* No info */) {
    // ** addr: 0x545790, size: 0x734
    // 0x545790: EnterFrame
    //     0x545790: stp             fp, lr, [SP, #-0x10]!
    //     0x545794: mov             fp, SP
    // 0x545798: AllocStack(0x88)
    //     0x545798: sub             SP, SP, #0x88
    // 0x54579c: SetupParameters(IPlayableGameState<X0> this /* r1 => r8, fp-0x28 */, dynamic _ /* r2 => r7, fp-0x30 */, dynamic _ /* r3 => r6, fp-0x40 */, dynamic _ /* r6 => r3, fp-0x48 */)
    //     0x54579c: mov             x8, x1
    //     0x5457a0: mov             x7, x2
    //     0x5457a4: stur            x3, [fp, #-0x38]
    //     0x5457a8: mov             x16, x6
    //     0x5457ac: mov             x6, x3
    //     0x5457b0: mov             x3, x16
    //     0x5457b4: stur            x1, [fp, #-0x28]
    //     0x5457b8: stur            x2, [fp, #-0x30]
    //     0x5457bc: stur            x5, [fp, #-0x40]
    //     0x5457c0: stur            x3, [fp, #-0x48]
    // 0x5457c4: LoadField: r0 = r4->field_13
    //     0x5457c4: ldur            w0, [x4, #0x13]
    // 0x5457c8: LoadField: r1 = r4->field_1f
    //     0x5457c8: ldur            w1, [x4, #0x1f]
    // 0x5457cc: DecompressPointer r1
    //     0x5457cc: add             x1, x1, HEAP, lsl #32
    // 0x5457d0: r16 = "allowSave"
    //     0x5457d0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a268] "allowSave"
    //     0x5457d4: ldr             x16, [x16, #0x268]
    // 0x5457d8: cmp             w1, w16
    // 0x5457dc: b.ne            #0x545800
    // 0x5457e0: LoadField: r1 = r4->field_23
    //     0x5457e0: ldur            w1, [x4, #0x23]
    // 0x5457e4: DecompressPointer r1
    //     0x5457e4: add             x1, x1, HEAP, lsl #32
    // 0x5457e8: sub             w2, w0, w1
    // 0x5457ec: add             x1, fp, w2, sxtw #2
    // 0x5457f0: ldr             x1, [x1, #8]
    // 0x5457f4: mov             x9, x1
    // 0x5457f8: r1 = 1
    //     0x5457f8: movz            x1, #0x1
    // 0x5457fc: b               #0x545808
    // 0x545800: r9 = true
    //     0x545800: add             x9, NULL, #0x20  ; true
    // 0x545804: r1 = 0
    //     0x545804: movz            x1, #0
    // 0x545808: stur            x9, [fp, #-0x20]
    // 0x54580c: lsl             x2, x1, #1
    // 0x545810: lsl             w10, w2, #1
    // 0x545814: add             w11, w10, #8
    // 0x545818: ArrayLoad: r12 = r4[r11]  ; Unknown_4
    //     0x545818: add             x16, x4, w11, sxtw #1
    //     0x54581c: ldur            w12, [x16, #0xf]
    // 0x545820: DecompressPointer r12
    //     0x545820: add             x12, x12, HEAP, lsl #32
    // 0x545824: r16 = "notify"
    //     0x545824: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a270] "notify"
    //     0x545828: ldr             x16, [x16, #0x270]
    // 0x54582c: cmp             w12, w16
    // 0x545830: b.ne            #0x545860
    // 0x545834: add             w1, w10, #0xa
    // 0x545838: ArrayLoad: r10 = r4[r1]  ; Unknown_4
    //     0x545838: add             x16, x4, w1, sxtw #1
    //     0x54583c: ldur            w10, [x16, #0xf]
    // 0x545840: DecompressPointer r10
    //     0x545840: add             x10, x10, HEAP, lsl #32
    // 0x545844: sub             w1, w0, w10
    // 0x545848: add             x10, fp, w1, sxtw #2
    // 0x54584c: ldr             x10, [x10, #8]
    // 0x545850: add             w1, w2, #2
    // 0x545854: r2 = LoadInt32Instr(r1)
    //     0x545854: sbfx            x2, x1, #1, #0x1f
    // 0x545858: mov             x1, x2
    // 0x54585c: b               #0x545864
    // 0x545860: r10 = true
    //     0x545860: add             x10, NULL, #0x20  ; true
    // 0x545864: stur            x10, [fp, #-0x18]
    // 0x545868: lsl             x2, x1, #1
    // 0x54586c: lsl             w1, w2, #1
    // 0x545870: add             w2, w1, #8
    // 0x545874: ArrayLoad: r11 = r4[r2]  ; Unknown_4
    //     0x545874: add             x16, x4, w2, sxtw #1
    //     0x545878: ldur            w11, [x16, #0xf]
    // 0x54587c: DecompressPointer r11
    //     0x54587c: add             x11, x11, HEAP, lsl #32
    // 0x545880: r16 = "test"
    //     0x545880: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a278] "test"
    //     0x545884: ldr             x16, [x16, #0x278]
    // 0x545888: cmp             w11, w16
    // 0x54588c: b.ne            #0x5458b4
    // 0x545890: add             w2, w1, #0xa
    // 0x545894: ArrayLoad: r1 = r4[r2]  ; Unknown_4
    //     0x545894: add             x16, x4, w2, sxtw #1
    //     0x545898: ldur            w1, [x16, #0xf]
    // 0x54589c: DecompressPointer r1
    //     0x54589c: add             x1, x1, HEAP, lsl #32
    // 0x5458a0: sub             w2, w0, w1
    // 0x5458a4: add             x0, fp, w2, sxtw #2
    // 0x5458a8: ldr             x0, [x0, #8]
    // 0x5458ac: mov             x4, x0
    // 0x5458b0: b               #0x5458b8
    // 0x5458b4: r4 = false
    //     0x5458b4: add             x4, NULL, #0x30  ; false
    // 0x5458b8: stur            x4, [fp, #-0x10]
    // 0x5458bc: CheckStackOverflow
    //     0x5458bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5458c0: cmp             SP, x16
    //     0x5458c4: b.ls            #0x545e28
    // 0x5458c8: LoadField: r11 = r8->field_7
    //     0x5458c8: ldur            w11, [x8, #7]
    // 0x5458cc: DecompressPointer r11
    //     0x5458cc: add             x11, x11, HEAP, lsl #32
    // 0x5458d0: mov             x0, x6
    // 0x5458d4: mov             x2, x11
    // 0x5458d8: stur            x11, [fp, #-8]
    // 0x5458dc: r1 = Null
    //     0x5458dc: mov             x1, NULL
    // 0x5458e0: r8 = ((dynamic this, int, num) => Tuple2<X0, CustomNum>)?
    //     0x5458e0: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a280] FunctionType: ((dynamic this, int, num) => Tuple2<X0, CustomNum>)?
    //     0x5458e4: ldr             x8, [x8, #0x280]
    // 0x5458e8: LoadField: r9 = r8->field_7
    //     0x5458e8: ldur            x9, [x8, #7]
    // 0x5458ec: r3 = Null
    //     0x5458ec: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a288] Null
    //     0x5458f0: ldr             x3, [x3, #0x288]
    // 0x5458f4: blr             x9
    // 0x5458f8: ldur            x3, [fp, #-0x30]
    // 0x5458fc: r0 = LoadClassIdInstr(r3)
    //     0x5458fc: ldur            x0, [x3, #-1]
    //     0x545900: ubfx            x0, x0, #0xc, #0x14
    // 0x545904: mov             x1, x3
    // 0x545908: ldur            x2, [fp, #-0x48]
    // 0x54590c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x54590c: sub             lr, x0, #1, lsl #12
    //     0x545910: ldr             lr, [x21, lr, lsl #3]
    //     0x545914: blr             lr
    // 0x545918: cmp             w0, NULL
    // 0x54591c: b.ne            #0x545928
    // 0x545920: d0 = 0.000000
    //     0x545920: eor             v0.16b, v0.16b, v0.16b
    // 0x545924: b               #0x54592c
    // 0x545928: LoadField: d0 = r0->field_7
    //     0x545928: ldur            d0, [x0, #7]
    // 0x54592c: ldur            x0, [fp, #-0x40]
    // 0x545930: stur            d0, [fp, #-0x68]
    // 0x545934: r3 = LoadInt32Instr(r0)
    //     0x545934: sbfx            x3, x0, #1, #0x1f
    //     0x545938: tbz             w0, #0, #0x545940
    //     0x54593c: ldur            x3, [x0, #7]
    // 0x545940: stur            x3, [fp, #-0x50]
    // 0x545944: tbz             x3, #0x3f, #0x54599c
    // 0x545948: r0 = current()
    //     0x545948: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x54594c: mov             x2, x0
    // 0x545950: r1 = "Trying to buy negative nodes!"
    //     0x545950: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a298] "Trying to buy negative nodes!"
    //     0x545954: ldr             x1, [x1, #0x298]
    // 0x545958: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x545958: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x54595c: r0 = crashlyticsRecordError()
    //     0x54595c: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x545960: ldur            d0, [fp, #-0x68]
    // 0x545964: r0 = inline_Allocate_Double()
    //     0x545964: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x545968: add             x0, x0, #0x10
    //     0x54596c: cmp             x1, x0
    //     0x545970: b.ls            #0x545e30
    //     0x545974: str             x0, [THR, #0x60]  ; THR::top
    //     0x545978: sub             x0, x0, #0xf
    //     0x54597c: movz            x1, #0xe19c
    //     0x545980: movk            x1, #0x3, lsl #16
    //     0x545984: stur            x1, [x0, #-1]
    // 0x545988: dmb             ishst
    // 0x54598c: StoreField: r0->field_7 = d0
    //     0x54598c: stur            d0, [x0, #7]
    // 0x545990: LeaveFrame
    //     0x545990: mov             SP, fp
    //     0x545994: ldp             fp, lr, [SP], #0x10
    // 0x545998: ret
    //     0x545998: ret             
    // 0x54599c: cbnz            x3, #0x5459e8
    // 0x5459a0: r1 = "Trying to buy 0!"
    //     0x5459a0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2a0] "Trying to buy 0!"
    //     0x5459a4: ldr             x1, [x1, #0x2a0]
    // 0x5459a8: r0 = crashlyticsLogEvent()
    //     0x5459a8: bl              #0x48467c  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsLogEvent
    // 0x5459ac: ldur            d0, [fp, #-0x68]
    // 0x5459b0: r0 = inline_Allocate_Double()
    //     0x5459b0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5459b4: add             x0, x0, #0x10
    //     0x5459b8: cmp             x1, x0
    //     0x5459bc: b.ls            #0x545e40
    //     0x5459c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x5459c4: sub             x0, x0, #0xf
    //     0x5459c8: movz            x1, #0xe19c
    //     0x5459cc: movk            x1, #0x3, lsl #16
    //     0x5459d0: stur            x1, [x0, #-1]
    // 0x5459d4: dmb             ishst
    // 0x5459d8: StoreField: r0->field_7 = d0
    //     0x5459d8: stur            d0, [x0, #7]
    // 0x5459dc: LeaveFrame
    //     0x5459dc: mov             SP, fp
    //     0x5459e0: ldp             fp, lr, [SP], #0x10
    // 0x5459e4: ret
    //     0x5459e4: ret             
    // 0x5459e8: ldur            x0, [fp, #-0x28]
    // 0x5459ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x5459ec: ldur            w1, [x0, #0x17]
    // 0x5459f0: DecompressPointer r1
    //     0x5459f0: add             x1, x1, HEAP, lsl #32
    // 0x5459f4: ldur            x2, [fp, #-0x48]
    // 0x5459f8: r0 = contains()
    //     0x5459f8: bl              #0x551aa0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x5459fc: tbz             w0, #4, #0x545a40
    // 0x545a00: ldur            x0, [fp, #-0x28]
    // 0x545a04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x545a04: ldur            w1, [x0, #0x17]
    // 0x545a08: DecompressPointer r1
    //     0x545a08: add             x1, x1, HEAP, lsl #32
    // 0x545a0c: ldur            x2, [fp, #-0x48]
    // 0x545a10: r0 = add()
    //     0x545a10: bl              #0x816e58  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x545a14: r0 = LoadStaticField(0x1040)
    //     0x545a14: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x545a18: ldr             x0, [x0, #0x2080]
    // 0x545a1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x545a20: cmp             w0, w16
    // 0x545a24: b.ne            #0x545a34
    // 0x545a28: r2 = fragments
    //     0x545a28: add             x2, PP, #0x10, lsl #12  ; [pp+0x100b8] Field <::.fragments>: static late (offset: 0x1040)
    //     0x545a2c: ldr             x2, [x2, #0xb8]
    // 0x545a30: r0 = InitLateStaticField()
    //     0x545a30: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x545a34: mov             x1, x0
    // 0x545a38: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x545a38: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x545a3c: r0 = notifyAll()
    //     0x545a3c: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x545a40: ldur            x1, [fp, #-0x28]
    // 0x545a44: ldur            x0, [fp, #-0x38]
    // 0x545a48: r0 = DateTime()
    //     0x545a48: bl              #0x36dbec  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x545a4c: mov             x1, x0
    // 0x545a50: r0 = false
    //     0x545a50: add             x0, NULL, #0x30  ; false
    // 0x545a54: stur            x1, [fp, #-0x40]
    // 0x545a58: StoreField: r1->field_7 = r0
    //     0x545a58: stur            w0, [x1, #7]
    // 0x545a5c: r0 = _getCurrentMicros()
    //     0x545a5c: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x545a60: r1 = LoadInt32Instr(r0)
    //     0x545a60: sbfx            x1, x0, #1, #0x1f
    //     0x545a64: tbz             w0, #0, #0x545a6c
    //     0x545a68: ldur            x1, [x0, #7]
    // 0x545a6c: ldur            x0, [fp, #-0x40]
    // 0x545a70: StoreField: r0->field_b = r1
    //     0x545a70: stur            x1, [x0, #0xb]
    // 0x545a74: ldur            x1, [fp, #-0x28]
    // 0x545a78: StoreField: r1->field_67 = r0
    //     0x545a78: stur            w0, [x1, #0x67]
    //     0x545a7c: ldurb           w16, [x1, #-1]
    //     0x545a80: ldurb           w17, [x0, #-1]
    //     0x545a84: and             x16, x17, x16, lsr #2
    //     0x545a88: tst             x16, HEAP, lsr #32
    //     0x545a8c: b.eq            #0x545a94
    //     0x545a90: bl              #0x825ad8  ; WriteBarrierWrappersStub
    // 0x545a94: ldur            x2, [fp, #-0x38]
    // 0x545a98: cmp             w2, NULL
    // 0x545a9c: b.eq            #0x545cac
    // 0x545aa0: ldur            d0, [fp, #-0x68]
    // 0x545aa4: r3 = inline_Allocate_Double()
    //     0x545aa4: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x545aa8: add             x3, x3, #0x10
    //     0x545aac: cmp             x0, x3
    //     0x545ab0: b.ls            #0x545e50
    //     0x545ab4: str             x3, [THR, #0x60]  ; THR::top
    //     0x545ab8: sub             x3, x3, #0xf
    //     0x545abc: movz            x0, #0xe19c
    //     0x545ac0: movk            x0, #0x3, lsl #16
    //     0x545ac4: stur            x0, [x3, #-1]
    // 0x545ac8: dmb             ishst
    // 0x545acc: StoreField: r3->field_7 = d0
    //     0x545acc: stur            d0, [x3, #7]
    // 0x545ad0: stur            x3, [fp, #-0x40]
    // 0x545ad4: ldur            x16, [fp, #-0x48]
    // 0x545ad8: stp             x16, x2, [SP, #8]
    // 0x545adc: str             x3, [SP]
    // 0x545ae0: mov             x0, x2
    // 0x545ae4: ClosureCall
    //     0x545ae4: ldr             x4, [PP, #0x3c8]  ; [pp+0x3c8] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x545ae8: ldur            x2, [x0, #0x1f]
    //     0x545aec: blr             x2
    // 0x545af0: LoadField: r1 = r0->field_f
    //     0x545af0: ldur            w1, [x0, #0xf]
    // 0x545af4: DecompressPointer r1
    //     0x545af4: add             x1, x1, HEAP, lsl #32
    // 0x545af8: cmp             w1, NULL
    // 0x545afc: b.eq            #0x545e6c
    // 0x545b00: LoadField: d0 = r1->field_7
    //     0x545b00: ldur            d0, [x1, #7]
    // 0x545b04: d1 = -inf
    //     0x545b04: ldr             d1, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x545b08: fcmp            d0, d1
    // 0x545b0c: b.eq            #0x545cac
    // 0x545b10: mov             x2, x0
    // 0x545b14: r1 = 1
    //     0x545b14: movz            x1, #0x1
    // 0x545b18: ldur            d0, [fp, #-0x68]
    // 0x545b1c: ldur            x3, [fp, #-0x50]
    // 0x545b20: stur            x2, [fp, #-0x58]
    // 0x545b24: stur            x1, [fp, #-0x60]
    // 0x545b28: CheckStackOverflow
    //     0x545b28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x545b2c: cmp             SP, x16
    //     0x545b30: b.ls            #0x545e70
    // 0x545b34: cmp             x1, x3
    // 0x545b38: b.ge            #0x545bb8
    // 0x545b3c: scvtf           d1, x1
    // 0x545b40: fadd            d2, d1, d0
    // 0x545b44: r0 = inline_Allocate_Double()
    //     0x545b44: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x545b48: add             x0, x0, #0x10
    //     0x545b4c: cmp             x4, x0
    //     0x545b50: b.ls            #0x545e78
    //     0x545b54: str             x0, [THR, #0x60]  ; THR::top
    //     0x545b58: sub             x0, x0, #0xf
    //     0x545b5c: movz            x4, #0xe19c
    //     0x545b60: movk            x4, #0x3, lsl #16
    //     0x545b64: stur            x4, [x0, #-1]
    // 0x545b68: dmb             ishst
    // 0x545b6c: StoreField: r0->field_7 = d2
    //     0x545b6c: stur            d2, [x0, #7]
    // 0x545b70: ldur            x16, [fp, #-0x38]
    // 0x545b74: ldur            lr, [fp, #-0x48]
    // 0x545b78: stp             lr, x16, [SP, #8]
    // 0x545b7c: str             x0, [SP]
    // 0x545b80: ldur            x0, [fp, #-0x38]
    // 0x545b84: ClosureCall
    //     0x545b84: ldr             x4, [PP, #0x3c8]  ; [pp+0x3c8] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x545b88: ldur            x2, [x0, #0x1f]
    //     0x545b8c: blr             x2
    // 0x545b90: ldur            x16, [fp, #-8]
    // 0x545b94: ldur            lr, [fp, #-0x58]
    // 0x545b98: stp             lr, x16, [SP, #8]
    // 0x545b9c: str             x0, [SP]
    // 0x545ba0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x545ba0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x545ba4: r0 = merge()
    //     0x545ba4: bl              #0x546034  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::merge
    // 0x545ba8: mov             x2, x0
    // 0x545bac: ldur            x0, [fp, #-0x60]
    // 0x545bb0: add             x1, x0, #1
    // 0x545bb4: b               #0x545b18
    // 0x545bb8: ldur            x1, [fp, #-0x28]
    // 0x545bbc: LoadField: r0 = r1->field_37
    //     0x545bbc: ldur            w0, [x1, #0x37]
    // 0x545bc0: DecompressPointer r0
    //     0x545bc0: add             x0, x0, HEAP, lsl #32
    // 0x545bc4: ldur            x16, [fp, #-8]
    // 0x545bc8: stp             x0, x16, [SP, #0x10]
    // 0x545bcc: ldur            x16, [fp, #-0x58]
    // 0x545bd0: r30 = true
    //     0x545bd0: add             lr, NULL, #0x20  ; true
    // 0x545bd4: stp             lr, x16, [SP]
    // 0x545bd8: r4 = const [0x1, 0x3, 0x3, 0x2, catchFloatingPointError, 0x2, null]
    //     0x545bd8: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a2a8] List(7) [0x1, 0x3, 0x3, 0x2, "catchFloatingPointError", 0x2, Null]
    //     0x545bdc: ldr             x4, [x4, #0x2a8]
    // 0x545be0: r0 = MapOperations.isSupersetOfTuple()
    //     0x545be0: bl              #0x5461a4  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.isSupersetOfTuple
    // 0x545be4: tbz             w0, #4, #0x545c84
    // 0x545be8: ldur            x0, [fp, #-0x10]
    // 0x545bec: tbz             w0, #4, #0x545bfc
    // 0x545bf0: r1 = "Buying more stuff than we can afford! Usually due to trying to buy multiple things on the same frame."
    //     0x545bf0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a2b0] "Buying more stuff than we can afford! Usually due to trying to buy multiple things on the same frame."
    //     0x545bf4: ldr             x1, [x1, #0x2b0]
    // 0x545bf8: r0 = crashlyticsLogEvent()
    //     0x545bf8: bl              #0x48467c  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsLogEvent
    // 0x545bfc: ldur            x1, [fp, #-0x28]
    // 0x545c00: ldur            x0, [fp, #-0x58]
    // 0x545c04: r0 = LoadStaticField(0x750)
    //     0x545c04: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x545c08: ldr             x0, [x0, #0xea0]
    // 0x545c0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x545c10: cmp             w0, w16
    // 0x545c14: b.ne            #0x545c20
    // 0x545c18: r2 = debugPrint
    //     0x545c18: ldr             x2, [PP, #0x2240]  ; [pp+0x2240] Field <::.debugPrint>: static late (offset: 0x750)
    // 0x545c1c: r0 = InitLateStaticField()
    //     0x545c1c: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x545c20: r1 = Null
    //     0x545c20: mov             x1, NULL
    // 0x545c24: r2 = 8
    //     0x545c24: movz            x2, #0x8
    // 0x545c28: r0 = AllocateArray()
    //     0x545c28: bl              #0x82746c  ; AllocateArrayStub
    // 0x545c2c: r16 = "Buying more stuff than we can afford! Cost: "
    //     0x545c2c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a2b8] "Buying more stuff than we can afford! Cost: "
    //     0x545c30: ldr             x16, [x16, #0x2b8]
    // 0x545c34: StoreField: r0->field_f = r16
    //     0x545c34: stur            w16, [x0, #0xf]
    // 0x545c38: ldur            x1, [fp, #-0x58]
    // 0x545c3c: StoreField: r0->field_13 = r1
    //     0x545c3c: stur            w1, [x0, #0x13]
    // 0x545c40: r16 = ", stats: "
    //     0x545c40: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a2c0] ", stats: "
    //     0x545c44: ldr             x16, [x16, #0x2c0]
    // 0x545c48: ArrayStore: r0[0] = r16  ; List_4
    //     0x545c48: stur            w16, [x0, #0x17]
    // 0x545c4c: ldur            x2, [fp, #-0x28]
    // 0x545c50: LoadField: r1 = r2->field_37
    //     0x545c50: ldur            w1, [x2, #0x37]
    // 0x545c54: DecompressPointer r1
    //     0x545c54: add             x1, x1, HEAP, lsl #32
    // 0x545c58: StoreField: r0->field_1b = r1
    //     0x545c58: stur            w1, [x0, #0x1b]
    // 0x545c5c: str             x0, [SP]
    // 0x545c60: r0 = _interpolate()
    //     0x545c60: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x545c64: str             NULL, [SP]
    // 0x545c68: mov             x1, x0
    // 0x545c6c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x545c6c: ldr             x4, [PP, #0x2260]  ; [pp+0x2260] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x545c70: r0 = debugPrintThrottled()
    //     0x545c70: bl              #0x370404  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x545c74: ldur            x0, [fp, #-0x40]
    // 0x545c78: LeaveFrame
    //     0x545c78: mov             SP, fp
    //     0x545c7c: ldp             fp, lr, [SP], #0x10
    // 0x545c80: ret
    //     0x545c80: ret             
    // 0x545c84: ldur            x2, [fp, #-0x28]
    // 0x545c88: ldur            x0, [fp, #-0x10]
    // 0x545c8c: ldur            x1, [fp, #-0x58]
    // 0x545c90: LoadField: r3 = r2->field_37
    //     0x545c90: ldur            w3, [x2, #0x37]
    // 0x545c94: DecompressPointer r3
    //     0x545c94: add             x3, x3, HEAP, lsl #32
    // 0x545c98: ldur            x16, [fp, #-8]
    // 0x545c9c: stp             x3, x16, [SP, #8]
    // 0x545ca0: str             x1, [SP]
    // 0x545ca4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x545ca4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x545ca8: r0 = MapOperations.subtractTuple()
    //     0x545ca8: bl              #0x539e38  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.subtractTuple
    // 0x545cac: ldur            x3, [fp, #-0x30]
    // 0x545cb0: r0 = LoadClassIdInstr(r3)
    //     0x545cb0: ldur            x0, [x3, #-1]
    //     0x545cb4: ubfx            x0, x0, #0xc, #0x14
    // 0x545cb8: mov             x1, x3
    // 0x545cbc: ldur            x2, [fp, #-0x48]
    // 0x545cc0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x545cc0: sub             lr, x0, #1, lsl #12
    //     0x545cc4: ldr             lr, [x21, lr, lsl #3]
    //     0x545cc8: blr             lr
    // 0x545ccc: cmp             w0, NULL
    // 0x545cd0: b.ne            #0x545cdc
    // 0x545cd4: d0 = 0.000000
    //     0x545cd4: eor             v0.16b, v0.16b, v0.16b
    // 0x545cd8: b               #0x545ce0
    // 0x545cdc: LoadField: d0 = r0->field_7
    //     0x545cdc: ldur            d0, [x0, #7]
    // 0x545ce0: ldur            x5, [fp, #-0x28]
    // 0x545ce4: ldur            x4, [fp, #-0x30]
    // 0x545ce8: ldur            x7, [fp, #-0x48]
    // 0x545cec: ldur            x8, [fp, #-0x18]
    // 0x545cf0: ldur            x6, [fp, #-0x50]
    // 0x545cf4: scvtf           d1, x6
    // 0x545cf8: fadd            d2, d0, d1
    // 0x545cfc: r3 = inline_Allocate_Double()
    //     0x545cfc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x545d00: add             x3, x3, #0x10
    //     0x545d04: cmp             x0, x3
    //     0x545d08: b.ls            #0x545e98
    //     0x545d0c: str             x3, [THR, #0x60]  ; THR::top
    //     0x545d10: sub             x3, x3, #0xf
    //     0x545d14: movz            x0, #0xe19c
    //     0x545d18: movk            x0, #0x3, lsl #16
    //     0x545d1c: stur            x0, [x3, #-1]
    // 0x545d20: dmb             ishst
    // 0x545d24: StoreField: r3->field_7 = d2
    //     0x545d24: stur            d2, [x3, #7]
    // 0x545d28: r0 = LoadClassIdInstr(r4)
    //     0x545d28: ldur            x0, [x4, #-1]
    //     0x545d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x545d30: mov             x1, x4
    // 0x545d34: mov             x2, x7
    // 0x545d38: r0 = GDT[cid_x0 + -0xff4]()
    //     0x545d38: sub             lr, x0, #0xff4
    //     0x545d3c: ldr             lr, [x21, lr, lsl #3]
    //     0x545d40: blr             lr
    // 0x545d44: ldur            x4, [fp, #-0x48]
    // 0x545d48: r2 = LoadInt32Instr(r4)
    //     0x545d48: sbfx            x2, x4, #1, #0x1f
    //     0x545d4c: tbz             w4, #0, #0x545d54
    //     0x545d50: ldur            x2, [x4, #7]
    // 0x545d54: ldur            x5, [fp, #-0x28]
    // 0x545d58: r0 = LoadClassIdInstr(r5)
    //     0x545d58: ldur            x0, [x5, #-1]
    //     0x545d5c: ubfx            x0, x0, #0xc, #0x14
    // 0x545d60: mov             x1, x5
    // 0x545d64: ldur            x3, [fp, #-0x50]
    // 0x545d68: r0 = GDT[cid_x0 + 0x899a]()
    //     0x545d68: movz            x17, #0x899a
    //     0x545d6c: add             lr, x0, x17
    //     0x545d70: ldr             lr, [x21, lr, lsl #3]
    //     0x545d74: blr             lr
    // 0x545d78: ldur            x0, [fp, #-0x18]
    // 0x545d7c: tbnz            w0, #4, #0x545df4
    // 0x545d80: ldur            x0, [fp, #-0x10]
    // 0x545d84: r0 = LoadStaticField(0x1030)
    //     0x545d84: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x545d88: ldr             x0, [x0, #0x2060]
    // 0x545d8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x545d90: cmp             w0, w16
    // 0x545d94: b.ne            #0x545da4
    // 0x545d98: r2 = currencyCounterGroup
    //     0x545d98: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc28] Field <::.currencyCounterGroup>: static late (offset: 0x1030)
    //     0x545d9c: ldr             x2, [x2, #0xc28]
    // 0x545da0: r0 = InitLateStaticField()
    //     0x545da0: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x545da4: mov             x1, x0
    // 0x545da8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x545da8: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x545dac: r0 = notifyAll()
    //     0x545dac: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x545db0: r0 = LoadStaticField(0xfc0)
    //     0x545db0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x545db4: ldr             x0, [x0, #0x1f80]
    // 0x545db8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x545dbc: cmp             w0, w16
    // 0x545dc0: b.ne            #0x545dd0
    // 0x545dc4: r2 = buyableTileStates
    //     0x545dc4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc50] Field <::.buyableTileStates>: static late (offset: 0xfc0)
    //     0x545dc8: ldr             x2, [x2, #0xc50]
    // 0x545dcc: r0 = InitLateStaticField()
    //     0x545dcc: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x545dd0: mov             x1, x0
    // 0x545dd4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x545dd4: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x545dd8: r0 = notifyAll()
    //     0x545dd8: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x545ddc: ldur            x0, [fp, #-0x10]
    // 0x545de0: tbz             w0, #4, #0x545df4
    // 0x545de4: ldur            x0, [fp, #-0x20]
    // 0x545de8: tbnz            w0, #4, #0x545df4
    // 0x545dec: ldur            x1, [fp, #-0x28]
    // 0x545df0: r0 = saveDeferred()
    //     0x545df0: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x545df4: ldur            x1, [fp, #-0x30]
    // 0x545df8: r0 = LoadClassIdInstr(r1)
    //     0x545df8: ldur            x0, [x1, #-1]
    //     0x545dfc: ubfx            x0, x0, #0xc, #0x14
    // 0x545e00: ldur            x2, [fp, #-0x48]
    // 0x545e04: r0 = GDT[cid_x0 + -0x1000]()
    //     0x545e04: sub             lr, x0, #1, lsl #12
    //     0x545e08: ldr             lr, [x21, lr, lsl #3]
    //     0x545e0c: blr             lr
    // 0x545e10: cmp             w0, NULL
    // 0x545e14: b.ne            #0x545e1c
    // 0x545e18: r0 = 0
    //     0x545e18: movz            x0, #0
    // 0x545e1c: LeaveFrame
    //     0x545e1c: mov             SP, fp
    //     0x545e20: ldp             fp, lr, [SP], #0x10
    // 0x545e24: ret
    //     0x545e24: ret             
    // 0x545e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x545e28: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x545e2c: b               #0x5458c8
    // 0x545e30: SaveReg d0
    //     0x545e30: str             q0, [SP, #-0x10]!
    // 0x545e34: r0 = AllocateDouble()
    //     0x545e34: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x545e38: RestoreReg d0
    //     0x545e38: ldr             q0, [SP], #0x10
    // 0x545e3c: b               #0x54598c
    // 0x545e40: SaveReg d0
    //     0x545e40: str             q0, [SP, #-0x10]!
    // 0x545e44: r0 = AllocateDouble()
    //     0x545e44: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x545e48: RestoreReg d0
    //     0x545e48: ldr             q0, [SP], #0x10
    // 0x545e4c: b               #0x5459d8
    // 0x545e50: SaveReg d0
    //     0x545e50: str             q0, [SP, #-0x10]!
    // 0x545e54: stp             x1, x2, [SP, #-0x10]!
    // 0x545e58: r0 = AllocateDouble()
    //     0x545e58: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x545e5c: mov             x3, x0
    // 0x545e60: ldp             x1, x2, [SP], #0x10
    // 0x545e64: RestoreReg d0
    //     0x545e64: ldr             q0, [SP], #0x10
    // 0x545e68: b               #0x545acc
    // 0x545e6c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x545e6c: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x545e70: r0 = StackOverflowSharedWithFPURegs()
    //     0x545e70: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x545e74: b               #0x545b34
    // 0x545e78: stp             q0, q2, [SP, #-0x20]!
    // 0x545e7c: stp             x2, x3, [SP, #-0x10]!
    // 0x545e80: SaveReg r1
    //     0x545e80: str             x1, [SP, #-8]!
    // 0x545e84: r0 = AllocateDouble()
    //     0x545e84: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x545e88: RestoreReg r1
    //     0x545e88: ldr             x1, [SP], #8
    // 0x545e8c: ldp             x2, x3, [SP], #0x10
    // 0x545e90: ldp             q0, q2, [SP], #0x20
    // 0x545e94: b               #0x545b6c
    // 0x545e98: SaveReg d2
    //     0x545e98: str             q2, [SP, #-0x10]!
    // 0x545e9c: stp             x7, x8, [SP, #-0x10]!
    // 0x545ea0: stp             x5, x6, [SP, #-0x10]!
    // 0x545ea4: SaveReg r4
    //     0x545ea4: str             x4, [SP, #-8]!
    // 0x545ea8: r0 = AllocateDouble()
    //     0x545ea8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x545eac: mov             x3, x0
    // 0x545eb0: RestoreReg r4
    //     0x545eb0: ldr             x4, [SP], #8
    // 0x545eb4: ldp             x5, x6, [SP], #0x10
    // 0x545eb8: ldp             x7, x8, [SP], #0x10
    // 0x545ebc: RestoreReg d2
    //     0x545ebc: ldr             q2, [SP], #0x10
    // 0x545ec0: b               #0x545d24
  }
  [closure] num buyGenerator(dynamic, Map<int, double>, Object?, int, int, {bool test, bool allowSave, bool notify}) {
    // ** addr: 0x545ec4, size: 0x170
    // 0x545ec4: EnterFrame
    //     0x545ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x545ec8: mov             fp, SP
    // 0x545ecc: AllocStack(0x18)
    //     0x545ecc: sub             SP, SP, #0x18
    // 0x545ed0: SetupParameters(IPlayableGameState<X0> this /* r2 */, dynamic _ /* r3 */, dynamic _ /* r5 */, dynamic _ /* r6 */, dynamic _ /* r7 */, {dynamic allowSave = true /* r8 */, dynamic notify = true /* r9 */, dynamic test = false /* r0 */})
    //     0x545ed0: ldur            w0, [x4, #0x13]
    //     0x545ed4: sub             x1, x0, #0xa
    //     0x545ed8: add             x2, fp, w1, sxtw #2
    //     0x545edc: ldr             x2, [x2, #0x30]
    //     0x545ee0: add             x3, fp, w1, sxtw #2
    //     0x545ee4: ldr             x3, [x3, #0x28]
    //     0x545ee8: add             x5, fp, w1, sxtw #2
    //     0x545eec: ldr             x5, [x5, #0x20]
    //     0x545ef0: add             x6, fp, w1, sxtw #2
    //     0x545ef4: ldr             x6, [x6, #0x18]
    //     0x545ef8: add             x7, fp, w1, sxtw #2
    //     0x545efc: ldr             x7, [x7, #0x10]
    //     0x545f00: ldur            w1, [x4, #0x1f]
    //     0x545f04: add             x1, x1, HEAP, lsl #32
    //     0x545f08: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a268] "allowSave"
    //     0x545f0c: ldr             x16, [x16, #0x268]
    //     0x545f10: cmp             w1, w16
    //     0x545f14: b.ne            #0x545f38
    //     0x545f18: ldur            w1, [x4, #0x23]
    //     0x545f1c: add             x1, x1, HEAP, lsl #32
    //     0x545f20: sub             w8, w0, w1
    //     0x545f24: add             x1, fp, w8, sxtw #2
    //     0x545f28: ldr             x1, [x1, #8]
    //     0x545f2c: mov             x8, x1
    //     0x545f30: movz            x1, #0x1
    //     0x545f34: b               #0x545f40
    //     0x545f38: add             x8, NULL, #0x20  ; true
    //     0x545f3c: movz            x1, #0
    //     0x545f40: lsl             x9, x1, #1
    //     0x545f44: lsl             w10, w9, #1
    //     0x545f48: add             w11, w10, #8
    //     0x545f4c: add             x16, x4, w11, sxtw #1
    //     0x545f50: ldur            w12, [x16, #0xf]
    //     0x545f54: add             x12, x12, HEAP, lsl #32
    //     0x545f58: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a270] "notify"
    //     0x545f5c: ldr             x16, [x16, #0x270]
    //     0x545f60: cmp             w12, w16
    //     0x545f64: b.ne            #0x545f98
    //     0x545f68: add             w1, w10, #0xa
    //     0x545f6c: add             x16, x4, w1, sxtw #1
    //     0x545f70: ldur            w10, [x16, #0xf]
    //     0x545f74: add             x10, x10, HEAP, lsl #32
    //     0x545f78: sub             w1, w0, w10
    //     0x545f7c: add             x10, fp, w1, sxtw #2
    //     0x545f80: ldr             x10, [x10, #8]
    //     0x545f84: add             w1, w9, #2
    //     0x545f88: sbfx            x9, x1, #1, #0x1f
    //     0x545f8c: mov             x1, x9
    //     0x545f90: mov             x9, x10
    //     0x545f94: b               #0x545f9c
    //     0x545f98: add             x9, NULL, #0x20  ; true
    //     0x545f9c: lsl             x10, x1, #1
    //     0x545fa0: lsl             w1, w10, #1
    //     0x545fa4: add             w10, w1, #8
    //     0x545fa8: add             x16, x4, w10, sxtw #1
    //     0x545fac: ldur            w11, [x16, #0xf]
    //     0x545fb0: add             x11, x11, HEAP, lsl #32
    //     0x545fb4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a278] "test"
    //     0x545fb8: ldr             x16, [x16, #0x278]
    //     0x545fbc: cmp             w11, w16
    //     0x545fc0: b.ne            #0x545fe4
    //     0x545fc4: add             w10, w1, #0xa
    //     0x545fc8: add             x16, x4, w10, sxtw #1
    //     0x545fcc: ldur            w1, [x16, #0xf]
    //     0x545fd0: add             x1, x1, HEAP, lsl #32
    //     0x545fd4: sub             w4, w0, w1
    //     0x545fd8: add             x0, fp, w4, sxtw #2
    //     0x545fdc: ldr             x0, [x0, #8]
    //     0x545fe0: b               #0x545fe8
    //     0x545fe4: add             x0, NULL, #0x30  ; false
    //     0x545fe8: ldur            w1, [x2, #0x17]
    //     0x545fec: add             x1, x1, HEAP, lsl #32
    // 0x545ff0: CheckStackOverflow
    //     0x545ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x545ff4: cmp             SP, x16
    //     0x545ff8: b.ls            #0x54602c
    // 0x545ffc: stp             x8, x0, [SP, #8]
    // 0x546000: str             x9, [SP]
    // 0x546004: mov             x2, x3
    // 0x546008: mov             x3, x5
    // 0x54600c: mov             x5, x6
    // 0x546010: mov             x6, x7
    // 0x546014: r4 = const [0, 0x8, 0x3, 0x5, allowSave, 0x6, notify, 0x7, test, 0x5, null]
    //     0x546014: add             x4, PP, #0x26, lsl #12  ; [pp+0x265b8] List(11) [0, 0x8, 0x3, 0x5, "allowSave", 0x6, "notify", 0x7, "test", 0x5, Null]
    //     0x546018: ldr             x4, [x4, #0x5b8]
    // 0x54601c: r0 = buyGenerator()
    //     0x54601c: bl              #0x545790  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator
    // 0x546020: LeaveFrame
    //     0x546020: mov             SP, fp
    //     0x546024: ldp             fp, lr, [SP], #0x10
    // 0x546028: ret
    //     0x546028: ret             
    // 0x54602c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54602c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x546030: b               #0x545ffc
  }
  [closure] CustomNum <anonymous closure>(dynamic, int) {
    // ** addr: 0x546314, size: 0xc0
    // 0x546314: EnterFrame
    //     0x546314: stp             fp, lr, [SP, #-0x10]!
    //     0x546318: mov             fp, SP
    // 0x54631c: AllocStack(0x10)
    //     0x54631c: sub             SP, SP, #0x10
    // 0x546320: SetupParameters([dynamic _ /* r0 */])
    //     0x546320: ldr             x0, [fp, #0x18]
    //     0x546324: ldur            w1, [x0, #0x17]
    //     0x546328: add             x1, x1, HEAP, lsl #32
    // 0x54632c: CheckStackOverflow
    //     0x54632c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x546330: cmp             SP, x16
    //     0x546334: b.ls            #0x5463cc
    // 0x546338: LoadField: r0 = r1->field_f
    //     0x546338: ldur            w0, [x1, #0xf]
    // 0x54633c: DecompressPointer r0
    //     0x54633c: add             x0, x0, HEAP, lsl #32
    // 0x546340: stur            x0, [fp, #-0x10]
    // 0x546344: LoadField: r3 = r0->field_47
    //     0x546344: ldur            w3, [x0, #0x47]
    // 0x546348: DecompressPointer r3
    //     0x546348: add             x3, x3, HEAP, lsl #32
    // 0x54634c: mov             x1, x3
    // 0x546350: ldr             x2, [fp, #0x10]
    // 0x546354: stur            x3, [fp, #-8]
    // 0x546358: r0 = _getValueOrData()
    //     0x546358: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54635c: mov             x1, x0
    // 0x546360: ldur            x0, [fp, #-8]
    // 0x546364: LoadField: r2 = r0->field_f
    //     0x546364: ldur            w2, [x0, #0xf]
    // 0x546368: DecompressPointer r2
    //     0x546368: add             x2, x2, HEAP, lsl #32
    // 0x54636c: cmp             w2, w1
    // 0x546370: b.ne            #0x54637c
    // 0x546374: r0 = Null
    //     0x546374: mov             x0, NULL
    // 0x546378: b               #0x546380
    // 0x54637c: mov             x0, x1
    // 0x546380: cmp             w0, NULL
    // 0x546384: b.ne            #0x546390
    // 0x546388: r3 = 0
    //     0x546388: movz            x3, #0
    // 0x54638c: b               #0x546394
    // 0x546390: mov             x3, x0
    // 0x546394: ldur            x1, [fp, #-0x10]
    // 0x546398: r0 = LoadClassIdInstr(r1)
    //     0x546398: ldur            x0, [x1, #-1]
    //     0x54639c: ubfx            x0, x0, #0xc, #0x14
    // 0x5463a0: ldr             x2, [fp, #0x10]
    // 0x5463a4: r0 = GDT[cid_x0 + 0xad4d]()
    //     0x5463a4: movz            x17, #0xad4d
    //     0x5463a8: add             lr, x0, x17
    //     0x5463ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5463b0: blr             lr
    // 0x5463b4: LoadField: r1 = r0->field_f
    //     0x5463b4: ldur            w1, [x0, #0xf]
    // 0x5463b8: DecompressPointer r1
    //     0x5463b8: add             x1, x1, HEAP, lsl #32
    // 0x5463bc: mov             x0, x1
    // 0x5463c0: LeaveFrame
    //     0x5463c0: mov             SP, fp
    //     0x5463c4: ldp             fp, lr, [SP], #0x10
    // 0x5463c8: ret
    //     0x5463c8: ret             
    // 0x5463cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5463cc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5463d0: b               #0x546338
  }
  _ _buyAllForGroupNewSystem(/* No info */) {
    // ** addr: 0x5463d4, size: 0x7d0
    // 0x5463d4: EnterFrame
    //     0x5463d4: stp             fp, lr, [SP, #-0x10]!
    //     0x5463d8: mov             fp, SP
    // 0x5463dc: AllocStack(0x98)
    //     0x5463dc: sub             SP, SP, #0x98
    // 0x5463e0: SetupParameters(IPlayableGameState<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x5463e0: mov             x0, x1
    //     0x5463e4: stur            x1, [fp, #-8]
    //     0x5463e8: mov             x1, x2
    //     0x5463ec: stur            x2, [fp, #-0x10]
    //     0x5463f0: stur            x3, [fp, #-0x18]
    // 0x5463f4: CheckStackOverflow
    //     0x5463f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5463f8: cmp             SP, x16
    //     0x5463fc: b.ls            #0x546b30
    // 0x546400: r1 = 2
    //     0x546400: movz            x1, #0x2
    // 0x546404: r0 = AllocateContext()
    //     0x546404: bl              #0x82637c  ; AllocateContextStub
    // 0x546408: mov             x3, x0
    // 0x54640c: ldur            x2, [fp, #-8]
    // 0x546410: stur            x3, [fp, #-0x20]
    // 0x546414: StoreField: r3->field_f = r2
    //     0x546414: stur            w2, [x3, #0xf]
    // 0x546418: ldur            x4, [fp, #-0x10]
    // 0x54641c: r0 = LoadClassIdInstr(r4)
    //     0x54641c: ldur            x0, [x4, #-1]
    //     0x546420: ubfx            x0, x0, #0xc, #0x14
    // 0x546424: mov             x1, x4
    // 0x546428: r0 = GDT[cid_x0 + 0x8bb1]()
    //     0x546428: movz            x17, #0x8bb1
    //     0x54642c: add             lr, x0, x17
    //     0x546430: ldr             lr, [x21, lr, lsl #3]
    //     0x546434: blr             lr
    // 0x546438: tbnz            w0, #4, #0x54644c
    // 0x54643c: r0 = 0
    //     0x54643c: movz            x0, #0
    // 0x546440: LeaveFrame
    //     0x546440: mov             SP, fp
    //     0x546444: ldp             fp, lr, [SP], #0x10
    // 0x546448: ret
    //     0x546448: ret             
    // 0x54644c: ldur            x1, [fp, #-8]
    // 0x546450: ldur            x3, [fp, #-0x10]
    // 0x546454: ldur            x2, [fp, #-0x20]
    // 0x546458: r0 = LoadClassIdInstr(r3)
    //     0x546458: ldur            x0, [x3, #-1]
    //     0x54645c: ubfx            x0, x0, #0xc, #0x14
    // 0x546460: stp             xzr, x3, [SP]
    // 0x546464: r0 = GDT[cid_x0 + -0xfff]()
    //     0x546464: sub             lr, x0, #0xfff
    //     0x546468: ldr             lr, [x21, lr, lsl #3]
    //     0x54646c: blr             lr
    // 0x546470: ldur            x1, [fp, #-8]
    // 0x546474: mov             x2, x0
    // 0x546478: r0 = getGeneratorBaseCost()
    //     0x546478: bl              #0x5560d0  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorBaseCost
    // 0x54647c: LoadField: r2 = r0->field_f
    //     0x54647c: ldur            w2, [x0, #0xf]
    // 0x546480: DecompressPointer r2
    //     0x546480: add             x2, x2, HEAP, lsl #32
    // 0x546484: mov             x0, x2
    // 0x546488: ldur            x3, [fp, #-0x20]
    // 0x54648c: stur            x2, [fp, #-0x28]
    // 0x546490: StoreField: r3->field_13 = r0
    //     0x546490: stur            w0, [x3, #0x13]
    //     0x546494: ldurb           w16, [x3, #-1]
    //     0x546498: ldurb           w17, [x0, #-1]
    //     0x54649c: and             x16, x17, x16, lsr #2
    //     0x5464a0: tst             x16, HEAP, lsr #32
    //     0x5464a4: b.eq            #0x5464ac
    //     0x5464a8: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x5464ac: ldur            x1, [fp, #-0x10]
    // 0x5464b0: r0 = LoadClassIdInstr(r1)
    //     0x5464b0: ldur            x0, [x1, #-1]
    //     0x5464b4: ubfx            x0, x0, #0xc, #0x14
    // 0x5464b8: r0 = GDT[cid_x0 + 0x7df6]()
    //     0x5464b8: movz            x17, #0x7df6
    //     0x5464bc: add             lr, x0, x17
    //     0x5464c0: ldr             lr, [x21, lr, lsl #3]
    //     0x5464c4: blr             lr
    // 0x5464c8: mov             x20, x0
    // 0x5464cc: ldur            x19, [fp, #-8]
    // 0x5464d0: stur            x20, [fp, #-0x48]
    // 0x5464d4: LoadField: r23 = r19->field_33
    //     0x5464d4: ldur            w23, [x19, #0x33]
    // 0x5464d8: DecompressPointer r23
    //     0x5464d8: add             x23, x23, HEAP, lsl #32
    // 0x5464dc: stur            x23, [fp, #-0x40]
    // 0x5464e0: r24 = Instance_CustomNum
    //     0x5464e0: add             x24, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x5464e4: ldr             x24, [x24, #0x2f0]
    // 0x5464e8: LoadField: d1 = r24->field_7
    //     0x5464e8: ldur            d1, [x24, #7]
    // 0x5464ec: stur            d1, [fp, #-0x78]
    // 0x5464f0: r25 = inline_Allocate_Double()
    //     0x5464f0: ldp             x25, x0, [THR, #0x60]  ; THR::top
    //     0x5464f4: add             x25, x25, #0x10
    //     0x5464f8: cmp             x0, x25
    //     0x5464fc: b.ls            #0x546b38
    //     0x546500: str             x25, [THR, #0x60]  ; THR::top
    //     0x546504: sub             x25, x25, #0xf
    //     0x546508: movz            x0, #0xe19c
    //     0x54650c: movk            x0, #0x3, lsl #16
    //     0x546510: stur            x0, [x25, #-1]
    // 0x546514: dmb             ishst
    // 0x546518: StoreField: r25->field_7 = d1
    //     0x546518: stur            d1, [x25, #7]
    // 0x54651c: mov             v0.16b, v1.16b
    // 0x546520: stur            x25, [fp, #-0x38]
    // 0x546524: stp             fp, lr, [SP, #-0x10]!
    // 0x546528: mov             fp, SP
    // 0x54652c: CallRuntime_LibcExp(double) -> double
    //     0x54652c: and             SP, SP, #0xfffffffffffffff0
    //     0x546530: mov             sp, SP
    //     0x546534: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x546538: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x54653c: blr             x16
    //     0x546540: movz            x16, #0x8
    //     0x546544: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x546548: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x54654c: sub             sp, x16, #1, lsl #12
    //     0x546550: mov             SP, fp
    //     0x546554: ldp             fp, lr, [SP], #0x10
    // 0x546558: mov             v1.16b, v0.16b
    // 0x54655c: d0 = 1.000000
    //     0x54655c: fmov            d0, #1.00000000
    // 0x546560: fsub            d2, d1, d0
    // 0x546564: stur            d2, [fp, #-0x88]
    // 0x546568: LoadField: r3 = r19->field_7
    //     0x546568: ldur            w3, [x19, #7]
    // 0x54656c: DecompressPointer r3
    //     0x54656c: add             x3, x3, HEAP, lsl #32
    // 0x546570: stur            x3, [fp, #-0x10]
    // 0x546574: fneg            d1, d2
    // 0x546578: stur            d1, [fp, #-0x80]
    // 0x54657c: ldur            x4, [fp, #-0x18]
    // 0x546580: r5 = 0
    //     0x546580: movz            x5, #0
    // 0x546584: ldur            x2, [fp, #-0x20]
    // 0x546588: ldur            d3, [fp, #-0x78]
    // 0x54658c: stur            x5, [fp, #-0x30]
    // 0x546590: CheckStackOverflow
    //     0x546590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x546594: cmp             SP, x16
    //     0x546598: b.ls            #0x546b5c
    // 0x54659c: r0 = LoadClassIdInstr(r20)
    //     0x54659c: ldur            x0, [x20, #-1]
    //     0x5465a0: ubfx            x0, x0, #0xc, #0x14
    // 0x5465a4: mov             x1, x20
    // 0x5465a8: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x5465a8: sub             lr, x0, #0xfc4
    //     0x5465ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5465b0: blr             lr
    // 0x5465b4: tbnz            w0, #4, #0x546ab8
    // 0x5465b8: ldur            x4, [fp, #-0x20]
    // 0x5465bc: ldur            x2, [fp, #-0x48]
    // 0x5465c0: ldur            x3, [fp, #-0x40]
    // 0x5465c4: r0 = LoadClassIdInstr(r2)
    //     0x5465c4: ldur            x0, [x2, #-1]
    //     0x5465c8: ubfx            x0, x0, #0xc, #0x14
    // 0x5465cc: mov             x1, x2
    // 0x5465d0: r0 = GDT[cid_x0 + -0xfb6]()
    //     0x5465d0: sub             lr, x0, #0xfb6
    //     0x5465d4: ldr             lr, [x21, lr, lsl #3]
    //     0x5465d8: blr             lr
    // 0x5465dc: stur            x0, [fp, #-0x50]
    // 0x5465e0: r1 = 3
    //     0x5465e0: movz            x1, #0x3
    // 0x5465e4: r0 = AllocateContext()
    //     0x5465e4: bl              #0x82637c  ; AllocateContextStub
    // 0x5465e8: mov             x3, x0
    // 0x5465ec: ldur            x0, [fp, #-0x20]
    // 0x5465f0: stur            x3, [fp, #-0x58]
    // 0x5465f4: StoreField: r3->field_b = r0
    //     0x5465f4: stur            w0, [x3, #0xb]
    // 0x5465f8: ldur            x1, [fp, #-8]
    // 0x5465fc: ldur            x2, [fp, #-0x50]
    // 0x546600: r0 = getGeneratorInfo()
    //     0x546600: bl              #0x80d28c  ; [package:pretentious/data/Chapters/Chapter13GameState.dart] Chapter13GameState::getGeneratorInfo
    // 0x546604: LoadField: r3 = r0->field_27
    //     0x546604: ldur            w3, [x0, #0x27]
    // 0x546608: DecompressPointer r3
    //     0x546608: add             x3, x3, HEAP, lsl #32
    // 0x54660c: stur            x3, [fp, #-0x60]
    // 0x546610: cmp             w3, NULL
    // 0x546614: b.eq            #0x546b64
    // 0x546618: ldur            x1, [fp, #-0x40]
    // 0x54661c: ldur            x2, [fp, #-0x50]
    // 0x546620: r0 = _getValueOrData()
    //     0x546620: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x546624: mov             x1, x0
    // 0x546628: ldur            x0, [fp, #-0x40]
    // 0x54662c: LoadField: r2 = r0->field_f
    //     0x54662c: ldur            w2, [x0, #0xf]
    // 0x546630: DecompressPointer r2
    //     0x546630: add             x2, x2, HEAP, lsl #32
    // 0x546634: cmp             w2, w1
    // 0x546638: b.ne            #0x546640
    // 0x54663c: r1 = Null
    //     0x54663c: mov             x1, NULL
    // 0x546640: cmp             w1, NULL
    // 0x546644: b.ne            #0x546650
    // 0x546648: r1 = Null
    //     0x546648: mov             x1, NULL
    // 0x54664c: b               #0x54665c
    // 0x546650: LoadField: r2 = r1->field_b
    //     0x546650: ldur            w2, [x1, #0xb]
    // 0x546654: DecompressPointer r2
    //     0x546654: add             x2, x2, HEAP, lsl #32
    // 0x546658: mov             x1, x2
    // 0x54665c: cmp             w1, NULL
    // 0x546660: b.ne            #0x546670
    // 0x546664: r2 = Instance_CustomNum
    //     0x546664: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x546668: ldr             x2, [x2, #0xa70]
    // 0x54666c: b               #0x546674
    // 0x546670: mov             x2, x1
    // 0x546674: ldur            x4, [fp, #-8]
    // 0x546678: ldur            x3, [fp, #-0x58]
    // 0x54667c: ldur            x1, [fp, #-0x60]
    // 0x546680: LoadField: r5 = r1->field_f
    //     0x546680: ldur            w5, [x1, #0xf]
    // 0x546684: DecompressPointer r5
    //     0x546684: add             x5, x5, HEAP, lsl #32
    // 0x546688: mov             x1, x2
    // 0x54668c: mov             x2, x5
    // 0x546690: r0 = mult2()
    //     0x546690: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x546694: mov             x4, x0
    // 0x546698: ldur            x0, [fp, #-0x58]
    // 0x54669c: r3 = Instance_CustomNum
    //     0x54669c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x5466a0: ldr             x3, [x3, #0x2f0]
    // 0x5466a4: stur            x4, [fp, #-0x68]
    // 0x5466a8: StoreField: r0->field_f = r3
    //     0x5466a8: stur            w3, [x0, #0xf]
    // 0x5466ac: ldur            x5, [fp, #-8]
    // 0x5466b0: LoadField: r6 = r5->field_47
    //     0x5466b0: ldur            w6, [x5, #0x47]
    // 0x5466b4: DecompressPointer r6
    //     0x5466b4: add             x6, x6, HEAP, lsl #32
    // 0x5466b8: mov             x1, x6
    // 0x5466bc: ldur            x2, [fp, #-0x50]
    // 0x5466c0: stur            x6, [fp, #-0x60]
    // 0x5466c4: r0 = _getValueOrData()
    //     0x5466c4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5466c8: mov             x1, x0
    // 0x5466cc: ldur            x0, [fp, #-0x60]
    // 0x5466d0: LoadField: r2 = r0->field_f
    //     0x5466d0: ldur            w2, [x0, #0xf]
    // 0x5466d4: DecompressPointer r2
    //     0x5466d4: add             x2, x2, HEAP, lsl #32
    // 0x5466d8: cmp             w2, w1
    // 0x5466dc: b.ne            #0x5466e8
    // 0x5466e0: r0 = Null
    //     0x5466e0: mov             x0, NULL
    // 0x5466e4: b               #0x5466ec
    // 0x5466e8: mov             x0, x1
    // 0x5466ec: cmp             w0, NULL
    // 0x5466f0: b.ne            #0x5466fc
    // 0x5466f4: r1 = 0
    //     0x5466f4: movz            x1, #0
    // 0x5466f8: b               #0x546700
    // 0x5466fc: mov             x1, x0
    // 0x546700: ldur            x2, [fp, #-0x58]
    // 0x546704: ldur            d0, [fp, #-0x78]
    // 0x546708: d1 = -inf
    //     0x546708: ldr             d1, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x54670c: mov             x0, x1
    // 0x546710: StoreField: r2->field_13 = r0
    //     0x546710: stur            w0, [x2, #0x13]
    //     0x546714: tbz             w0, #0, #0x546730
    //     0x546718: ldurb           w16, [x2, #-1]
    //     0x54671c: ldurb           w17, [x0, #-1]
    //     0x546720: and             x16, x17, x16, lsr #2
    //     0x546724: tst             x16, HEAP, lsr #32
    //     0x546728: b.eq            #0x546730
    //     0x54672c: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x546730: fcmp            d0, d1
    // 0x546734: b.ne            #0x546748
    // 0x546738: mov             x0, x2
    // 0x54673c: r2 = Instance_CustomNum
    //     0x54673c: add             x2, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x546740: ldr             x2, [x2, #0xaf8]
    // 0x546744: b               #0x546768
    // 0x546748: ldur            x16, [fp, #-0x38]
    // 0x54674c: stp             x1, x16, [SP]
    // 0x546750: r0 = *()
    //     0x546750: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x546754: LoadField: d0 = r0->field_7
    //     0x546754: ldur            d0, [x0, #7]
    // 0x546758: r1 = Null
    //     0x546758: mov             x1, NULL
    // 0x54675c: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x54675c: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x546760: mov             x2, x0
    // 0x546764: ldur            x0, [fp, #-0x58]
    // 0x546768: ldur            x3, [fp, #-8]
    // 0x54676c: ldur            x1, [fp, #-0x68]
    // 0x546770: r0 = mult2()
    //     0x546770: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x546774: mov             x4, x0
    // 0x546778: ldur            x3, [fp, #-0x58]
    // 0x54677c: stur            x4, [fp, #-0x68]
    // 0x546780: ArrayStore: r3[0] = r0  ; List_4
    //     0x546780: stur            w0, [x3, #0x17]
    //     0x546784: ldurb           w16, [x3, #-1]
    //     0x546788: ldurb           w17, [x0, #-1]
    //     0x54678c: and             x16, x17, x16, lsr #2
    //     0x546790: tst             x16, HEAP, lsr #32
    //     0x546794: b.eq            #0x54679c
    //     0x546798: bl              #0x825b18  ; WriteBarrierWrappersStub
    // 0x54679c: ldur            x0, [fp, #-8]
    // 0x5467a0: LoadField: r5 = r0->field_37
    //     0x5467a0: ldur            w5, [x0, #0x37]
    // 0x5467a4: DecompressPointer r5
    //     0x5467a4: add             x5, x5, HEAP, lsl #32
    // 0x5467a8: mov             x1, x5
    // 0x5467ac: ldur            x2, [fp, #-0x28]
    // 0x5467b0: stur            x5, [fp, #-0x60]
    // 0x5467b4: r0 = _getValueOrData()
    //     0x5467b4: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5467b8: mov             x1, x0
    // 0x5467bc: ldur            x0, [fp, #-0x60]
    // 0x5467c0: LoadField: r2 = r0->field_f
    //     0x5467c0: ldur            w2, [x0, #0xf]
    // 0x5467c4: DecompressPointer r2
    //     0x5467c4: add             x2, x2, HEAP, lsl #32
    // 0x5467c8: cmp             w2, w1
    // 0x5467cc: b.ne            #0x5467d8
    // 0x5467d0: r0 = Null
    //     0x5467d0: mov             x0, NULL
    // 0x5467d4: b               #0x5467dc
    // 0x5467d8: mov             x0, x1
    // 0x5467dc: cmp             w0, NULL
    // 0x5467e0: b.ne            #0x5467f0
    // 0x5467e4: r1 = Instance_CustomNum
    //     0x5467e4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x5467e8: ldr             x1, [x1, #0xaf8]
    // 0x5467ec: b               #0x5467f4
    // 0x5467f0: mov             x1, x0
    // 0x5467f4: ldur            x0, [fp, #-0x68]
    // 0x5467f8: LoadField: d0 = r0->field_7
    //     0x5467f8: ldur            d0, [x0, #7]
    // 0x5467fc: LoadField: d1 = r1->field_7
    //     0x5467fc: ldur            d1, [x1, #7]
    // 0x546800: fcmp            d0, d1
    // 0x546804: b.le            #0x546814
    // 0x546808: ldur            x5, [fp, #-0x30]
    // 0x54680c: ldur            x0, [fp, #-0x18]
    // 0x546810: b               #0x546a80
    // 0x546814: ldur            d2, [fp, #-0x88]
    // 0x546818: d3 = 0.000000
    //     0x546818: eor             v3.16b, v3.16b, v3.16b
    // 0x54681c: fcmp            d2, d3
    // 0x546820: b.ne            #0x54683c
    // 0x546824: d4 = 0.000000
    //     0x546824: add             x17, PP, #0x1a, lsl #12  ; [pp+0x1a2f8] IMM: double(1e-09) from 0x3e112e0be826d695
    //     0x546828: ldr             d4, [x17, #0x2f8]
    // 0x54682c: fcmp            d4, d3
    // 0x546830: b.le            #0x5468e8
    // 0x546834: ldur            d5, [fp, #-0x80]
    // 0x546838: b               #0x546868
    // 0x54683c: d4 = 0.000000
    //     0x54683c: add             x17, PP, #0x1a, lsl #12  ; [pp+0x1a2f8] IMM: double(1e-09) from 0x3e112e0be826d695
    //     0x546840: ldr             d4, [x17, #0x2f8]
    // 0x546844: fcmp            d3, d2
    // 0x546848: b.le            #0x54685c
    // 0x54684c: ldur            d5, [fp, #-0x80]
    // 0x546850: fcmp            d4, d5
    // 0x546854: b.le            #0x5468e4
    // 0x546858: b               #0x546868
    // 0x54685c: ldur            d5, [fp, #-0x80]
    // 0x546860: fcmp            d4, d2
    // 0x546864: b.le            #0x5468e4
    // 0x546868: fsub            d6, d1, d0
    // 0x54686c: mov             v0.16b, v6.16b
    // 0x546870: r1 = Null
    //     0x546870: mov             x1, NULL
    // 0x546874: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x546874: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x546878: LoadField: d0 = r0->field_7
    //     0x546878: ldur            d0, [x0, #7]
    // 0x54687c: stp             fp, lr, [SP, #-0x10]!
    // 0x546880: mov             fp, SP
    // 0x546884: CallRuntime_LibcExp(double) -> double
    //     0x546884: and             SP, SP, #0xfffffffffffffff0
    //     0x546888: mov             sp, SP
    //     0x54688c: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x546890: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x546894: blr             x16
    //     0x546898: movz            x16, #0x8
    //     0x54689c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5468a0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5468a4: sub             sp, x16, #1, lsl #12
    //     0x5468a8: mov             SP, fp
    //     0x5468ac: ldp             fp, lr, [SP], #0x10
    // 0x5468b0: fcmp            d0, d0
    // 0x5468b4: b.vs            #0x546b68
    // 0x5468b8: fcvtms          x0, d0
    // 0x5468bc: asr             x16, x0, #0x1e
    // 0x5468c0: cmp             x16, x0, asr #63
    // 0x5468c4: b.ne            #0x546b68
    // 0x5468c8: lsl             x0, x0, #1
    // 0x5468cc: r1 = LoadInt32Instr(r0)
    //     0x5468cc: sbfx            x1, x0, #1, #0x1f
    //     0x5468d0: tbz             w0, #0, #0x5468d8
    //     0x5468d4: ldur            x1, [x0, #7]
    // 0x5468d8: mov             x0, x1
    // 0x5468dc: ldur            d0, [fp, #-0x78]
    // 0x5468e0: b               #0x5469c8
    // 0x5468e4: ldur            d2, [fp, #-0x88]
    // 0x5468e8: fsub            d3, d1, d0
    // 0x5468ec: mov             v0.16b, v3.16b
    // 0x5468f0: r1 = Null
    //     0x5468f0: mov             x1, NULL
    // 0x5468f4: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x5468f4: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x5468f8: LoadField: d0 = r0->field_7
    //     0x5468f8: ldur            d0, [x0, #7]
    // 0x5468fc: stp             fp, lr, [SP, #-0x10]!
    // 0x546900: mov             fp, SP
    // 0x546904: CallRuntime_LibcExp(double) -> double
    //     0x546904: and             SP, SP, #0xfffffffffffffff0
    //     0x546908: mov             sp, SP
    //     0x54690c: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x546910: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x546914: blr             x16
    //     0x546918: movz            x16, #0x8
    //     0x54691c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x546920: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x546924: sub             sp, x16, #1, lsl #12
    //     0x546928: mov             SP, fp
    //     0x54692c: ldp             fp, lr, [SP], #0x10
    // 0x546930: ldur            d1, [fp, #-0x88]
    // 0x546934: fmul            d2, d0, d1
    // 0x546938: d3 = 1.000000
    //     0x546938: fmov            d3, #1.00000000
    // 0x54693c: fadd            d0, d2, d3
    // 0x546940: d2 = 0.000000
    //     0x546940: eor             v2.16b, v2.16b, v2.16b
    // 0x546944: fcmp            d2, d0
    // 0x546948: b.lt            #0x546958
    // 0x54694c: ldur            d0, [fp, #-0x78]
    // 0x546950: r0 = 0
    //     0x546950: movz            x0, #0
    // 0x546954: b               #0x5469c8
    // 0x546958: ldur            d4, [fp, #-0x78]
    // 0x54695c: stp             fp, lr, [SP, #-0x10]!
    // 0x546960: mov             fp, SP
    // 0x546964: CallRuntime_LibcLog(double) -> double
    //     0x546964: and             SP, SP, #0xfffffffffffffff0
    //     0x546968: mov             sp, SP
    //     0x54696c: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x546970: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x546974: blr             x16
    //     0x546978: movz            x16, #0x8
    //     0x54697c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x546980: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x546984: sub             sp, x16, #1, lsl #12
    //     0x546988: mov             SP, fp
    //     0x54698c: ldp             fp, lr, [SP], #0x10
    // 0x546990: mov             v1.16b, v0.16b
    // 0x546994: ldur            d0, [fp, #-0x78]
    // 0x546998: fdiv            d2, d1, d0
    // 0x54699c: fcmp            d2, d2
    // 0x5469a0: b.vs            #0x546b84
    // 0x5469a4: fcvtms          x0, d2
    // 0x5469a8: asr             x16, x0, #0x1e
    // 0x5469ac: cmp             x16, x0, asr #63
    // 0x5469b0: b.ne            #0x546b84
    // 0x5469b4: lsl             x0, x0, #1
    // 0x5469b8: r1 = LoadInt32Instr(r0)
    //     0x5469b8: sbfx            x1, x0, #1, #0x1f
    //     0x5469bc: tbz             w0, #0, #0x5469c4
    //     0x5469c0: ldur            x1, [x0, #7]
    // 0x5469c4: mov             x0, x1
    // 0x5469c8: ldur            x4, [fp, #-0x18]
    // 0x5469cc: ldur            x5, [fp, #-0x30]
    // 0x5469d0: sub             x1, x4, x5
    // 0x5469d4: cmp             x0, x1
    // 0x5469d8: b.le            #0x5469e4
    // 0x5469dc: mov             x6, x1
    // 0x5469e0: b               #0x5469e8
    // 0x5469e4: mov             x6, x0
    // 0x5469e8: stur            x6, [fp, #-0x70]
    // 0x5469ec: cmp             x6, #0
    // 0x5469f0: b.gt            #0x5469fc
    // 0x5469f4: mov             x0, x4
    // 0x5469f8: b               #0x546a80
    // 0x5469fc: ldur            x7, [fp, #-8]
    // 0x546a00: LoadField: r8 = r7->field_47
    //     0x546a00: ldur            w8, [x7, #0x47]
    // 0x546a04: DecompressPointer r8
    //     0x546a04: add             x8, x8, HEAP, lsl #32
    // 0x546a08: stur            x8, [fp, #-0x60]
    // 0x546a0c: r0 = BoxInt64Instr(r6)
    //     0x546a0c: sbfiz           x0, x6, #1, #0x1f
    //     0x546a10: cmp             x6, x0, asr #1
    //     0x546a14: b.eq            #0x546a20
    //     0x546a18: bl              #0x8277b0  ; AllocateMintSharedWithFPURegsStub
    //     0x546a1c: stur            x6, [x0, #7]
    // 0x546a20: ldur            x2, [fp, #-0x58]
    // 0x546a24: ldur            x3, [fp, #-0x10]
    // 0x546a28: r1 = Function 'localCostFn':.
    //     0x546a28: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a300] AnonymousClosure: (0x546ba4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::_buyAllForGroupNewSystem (0x5463d4)
    //     0x546a2c: ldr             x1, [x1, #0x300]
    // 0x546a30: stur            x0, [fp, #-0x58]
    // 0x546a34: r0 = AllocateClosureTA()
    //     0x546a34: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x546a38: r16 = false
    //     0x546a38: add             x16, NULL, #0x30  ; false
    // 0x546a3c: r30 = false
    //     0x546a3c: add             lr, NULL, #0x30  ; false
    // 0x546a40: stp             lr, x16, [SP]
    // 0x546a44: ldur            x1, [fp, #-8]
    // 0x546a48: ldur            x2, [fp, #-0x60]
    // 0x546a4c: mov             x3, x0
    // 0x546a50: ldur            x5, [fp, #-0x58]
    // 0x546a54: ldur            x6, [fp, #-0x50]
    // 0x546a58: r4 = const [0, 0x7, 0x2, 0x5, allowSave, 0x5, notify, 0x6, null]
    //     0x546a58: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a238] List(9) [0, 0x7, 0x2, 0x5, "allowSave", 0x5, "notify", 0x6, Null]
    //     0x546a5c: ldr             x4, [x4, #0x238]
    // 0x546a60: r0 = buyGenerator()
    //     0x546a60: bl              #0x545790  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::buyGenerator
    // 0x546a64: ldur            x0, [fp, #-0x30]
    // 0x546a68: ldur            x1, [fp, #-0x70]
    // 0x546a6c: add             x2, x0, x1
    // 0x546a70: ldur            x0, [fp, #-0x18]
    // 0x546a74: cmp             x2, x0
    // 0x546a78: b.ge            #0x546ab0
    // 0x546a7c: mov             x5, x2
    // 0x546a80: ldur            x19, [fp, #-8]
    // 0x546a84: mov             x4, x0
    // 0x546a88: ldur            x20, [fp, #-0x48]
    // 0x546a8c: ldur            d2, [fp, #-0x88]
    // 0x546a90: ldur            x3, [fp, #-0x10]
    // 0x546a94: ldur            d1, [fp, #-0x80]
    // 0x546a98: ldur            x23, [fp, #-0x40]
    // 0x546a9c: ldur            x25, [fp, #-0x38]
    // 0x546aa0: r24 = Instance_CustomNum
    //     0x546aa0: add             x24, PP, #0x1a, lsl #12  ; [pp+0x1a2f0] Obj!CustomNum@828b01
    //     0x546aa4: ldr             x24, [x24, #0x2f0]
    // 0x546aa8: d0 = 1.000000
    //     0x546aa8: fmov            d0, #1.00000000
    // 0x546aac: b               #0x546584
    // 0x546ab0: mov             x0, x2
    // 0x546ab4: b               #0x546abc
    // 0x546ab8: ldur            x0, [fp, #-0x30]
    // 0x546abc: stur            x0, [fp, #-0x18]
    // 0x546ac0: cmp             x0, #0
    // 0x546ac4: b.le            #0x546b20
    // 0x546ac8: r0 = LoadStaticField(0x1030)
    //     0x546ac8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x546acc: ldr             x0, [x0, #0x2060]
    // 0x546ad0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x546ad4: cmp             w0, w16
    // 0x546ad8: b.ne            #0x546ae8
    // 0x546adc: r2 = currencyCounterGroup
    //     0x546adc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc28] Field <::.currencyCounterGroup>: static late (offset: 0x1030)
    //     0x546ae0: ldr             x2, [x2, #0xc28]
    // 0x546ae4: r0 = InitLateStaticField()
    //     0x546ae4: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x546ae8: mov             x1, x0
    // 0x546aec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x546aec: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x546af0: r0 = notifyAll()
    //     0x546af0: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x546af4: r0 = LoadStaticField(0xfc0)
    //     0x546af4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x546af8: ldr             x0, [x0, #0x1f80]
    // 0x546afc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x546b00: cmp             w0, w16
    // 0x546b04: b.ne            #0x546b14
    // 0x546b08: r2 = buyableTileStates
    //     0x546b08: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc50] Field <::.buyableTileStates>: static late (offset: 0xfc0)
    //     0x546b0c: ldr             x2, [x2, #0xc50]
    // 0x546b10: r0 = InitLateStaticField()
    //     0x546b10: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x546b14: mov             x1, x0
    // 0x546b18: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x546b18: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x546b1c: r0 = notifyAll()
    //     0x546b1c: bl              #0x371e0c  ; [package:state_groups/src/sync_state.dart] StateGroup::notifyAll
    // 0x546b20: ldur            x0, [fp, #-0x18]
    // 0x546b24: LeaveFrame
    //     0x546b24: mov             SP, fp
    //     0x546b28: ldp             fp, lr, [SP], #0x10
    // 0x546b2c: ret
    //     0x546b2c: ret             
    // 0x546b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x546b30: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x546b34: b               #0x546400
    // 0x546b38: SaveReg d1
    //     0x546b38: str             q1, [SP, #-0x10]!
    // 0x546b3c: stp             x23, x24, [SP, #-0x10]!
    // 0x546b40: stp             x19, x20, [SP, #-0x10]!
    // 0x546b44: r0 = AllocateDouble()
    //     0x546b44: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x546b48: mov             x25, x0
    // 0x546b4c: ldp             x19, x20, [SP], #0x10
    // 0x546b50: ldp             x23, x24, [SP], #0x10
    // 0x546b54: RestoreReg d1
    //     0x546b54: ldr             q1, [SP], #0x10
    // 0x546b58: b               #0x546518
    // 0x546b5c: r0 = StackOverflowSharedWithFPURegs()
    //     0x546b5c: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x546b60: b               #0x54659c
    // 0x546b64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x546b64: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x546b68: SaveReg d0
    //     0x546b68: str             q0, [SP, #-0x10]!
    // 0x546b6c: r0 = 70
    //     0x546b6c: movz            x0, #0x46
    // 0x546b70: r30 = DoubleToIntegerStub
    //     0x546b70: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x546b74: LoadField: r30 = r30->field_7
    //     0x546b74: ldur            lr, [lr, #7]
    // 0x546b78: blr             lr
    // 0x546b7c: RestoreReg d0
    //     0x546b7c: ldr             q0, [SP], #0x10
    // 0x546b80: b               #0x5468cc
    // 0x546b84: stp             q0, q2, [SP, #-0x20]!
    // 0x546b88: d0 = 0.000000
    //     0x546b88: fmov            d0, d2
    // 0x546b8c: r0 = 70
    //     0x546b8c: movz            x0, #0x46
    // 0x546b90: r30 = DoubleToIntegerStub
    //     0x546b90: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x546b94: LoadField: r30 = r30->field_7
    //     0x546b94: ldur            lr, [lr, #7]
    // 0x546b98: blr             lr
    // 0x546b9c: ldp             q0, q2, [SP], #0x20
    // 0x546ba0: b               #0x5469b8
  }
  [closure] Tuple2<X0, CustomNum> localCostFn(dynamic, int, num) {
    // ** addr: 0x546ba4, size: 0x108
    // 0x546ba4: EnterFrame
    //     0x546ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x546ba8: mov             fp, SP
    // 0x546bac: AllocStack(0x38)
    //     0x546bac: sub             SP, SP, #0x38
    // 0x546bb0: SetupParameters([dynamic _ /* r0 */])
    //     0x546bb0: ldr             x0, [fp, #0x20]
    //     0x546bb4: ldur            w4, [x0, #0x17]
    //     0x546bb8: add             x4, x4, HEAP, lsl #32
    //     0x546bbc: stur            x4, [fp, #-0x10]
    // 0x546bc0: CheckStackOverflow
    //     0x546bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x546bc4: cmp             SP, x16
    //     0x546bc8: b.ls            #0x546ca4
    // 0x546bcc: LoadField: r0 = r4->field_b
    //     0x546bcc: ldur            w0, [x4, #0xb]
    // 0x546bd0: DecompressPointer r0
    //     0x546bd0: add             x0, x0, HEAP, lsl #32
    // 0x546bd4: stur            x0, [fp, #-8]
    // 0x546bd8: LoadField: r1 = r0->field_f
    //     0x546bd8: ldur            w1, [x0, #0xf]
    // 0x546bdc: DecompressPointer r1
    //     0x546bdc: add             x1, x1, HEAP, lsl #32
    // 0x546be0: LoadField: r2 = r1->field_7
    //     0x546be0: ldur            w2, [x1, #7]
    // 0x546be4: DecompressPointer r2
    //     0x546be4: add             x2, x2, HEAP, lsl #32
    // 0x546be8: r1 = Null
    //     0x546be8: mov             x1, NULL
    // 0x546bec: r3 = <X0, CustomNum>
    //     0x546bec: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x546bf0: ldr             x3, [x3, #0xb10]
    // 0x546bf4: r30 = InstantiateTypeArgumentsStub
    //     0x546bf4: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x546bf8: LoadField: r30 = r30->field_7
    //     0x546bf8: ldur            lr, [lr, #7]
    // 0x546bfc: blr             lr
    // 0x546c00: mov             x1, x0
    // 0x546c04: ldur            x0, [fp, #-8]
    // 0x546c08: stur            x1, [fp, #-0x28]
    // 0x546c0c: LoadField: r2 = r0->field_13
    //     0x546c0c: ldur            w2, [x0, #0x13]
    // 0x546c10: DecompressPointer r2
    //     0x546c10: add             x2, x2, HEAP, lsl #32
    // 0x546c14: ldur            x0, [fp, #-0x10]
    // 0x546c18: stur            x2, [fp, #-0x20]
    // 0x546c1c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x546c1c: ldur            w3, [x0, #0x17]
    // 0x546c20: DecompressPointer r3
    //     0x546c20: add             x3, x3, HEAP, lsl #32
    // 0x546c24: stur            x3, [fp, #-0x18]
    // 0x546c28: LoadField: r4 = r0->field_f
    //     0x546c28: ldur            w4, [x0, #0xf]
    // 0x546c2c: DecompressPointer r4
    //     0x546c2c: add             x4, x4, HEAP, lsl #32
    // 0x546c30: stur            x4, [fp, #-8]
    // 0x546c34: LoadField: r5 = r0->field_13
    //     0x546c34: ldur            w5, [x0, #0x13]
    // 0x546c38: DecompressPointer r5
    //     0x546c38: add             x5, x5, HEAP, lsl #32
    // 0x546c3c: ldr             x0, [fp, #0x10]
    // 0x546c40: r6 = 60
    //     0x546c40: movz            x6, #0x3c
    // 0x546c44: branchIfSmi(r0, 0x546c50)
    //     0x546c44: tbz             w0, #0, #0x546c50
    // 0x546c48: r6 = LoadClassIdInstr(r0)
    //     0x546c48: ldur            x6, [x0, #-1]
    //     0x546c4c: ubfx            x6, x6, #0xc, #0x14
    // 0x546c50: stp             x5, x0, [SP]
    // 0x546c54: mov             x0, x6
    // 0x546c58: r0 = GDT[cid_x0 + -0xdbc]()
    //     0x546c58: sub             lr, x0, #0xdbc
    //     0x546c5c: ldr             lr, [x21, lr, lsl #3]
    //     0x546c60: blr             lr
    // 0x546c64: ldur            x1, [fp, #-8]
    // 0x546c68: mov             x2, x0
    // 0x546c6c: r0 = pow()
    //     0x546c6c: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x546c70: ldur            x1, [fp, #-0x18]
    // 0x546c74: mov             x2, x0
    // 0x546c78: r0 = mult2()
    //     0x546c78: bl              #0x3dc66c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult2
    // 0x546c7c: ldur            x1, [fp, #-0x28]
    // 0x546c80: stur            x0, [fp, #-8]
    // 0x546c84: r0 = Tuple2()
    //     0x546c84: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x546c88: ldur            x1, [fp, #-0x20]
    // 0x546c8c: StoreField: r0->field_b = r1
    //     0x546c8c: stur            w1, [x0, #0xb]
    // 0x546c90: ldur            x1, [fp, #-8]
    // 0x546c94: StoreField: r0->field_f = r1
    //     0x546c94: stur            w1, [x0, #0xf]
    // 0x546c98: LeaveFrame
    //     0x546c98: mov             SP, fp
    //     0x546c9c: ldp             fp, lr, [SP], #0x10
    // 0x546ca0: ret
    //     0x546ca0: ret             
    // 0x546ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x546ca4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x546ca8: b               #0x546bcc
  }
  [closure] List<int> <anonymous closure>(dynamic) {
    // ** addr: 0x546f54, size: 0x34
    // 0x546f54: EnterFrame
    //     0x546f54: stp             fp, lr, [SP, #-0x10]!
    //     0x546f58: mov             fp, SP
    // 0x546f5c: CheckStackOverflow
    //     0x546f5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x546f60: cmp             SP, x16
    //     0x546f64: b.ls            #0x546f80
    // 0x546f68: r1 = <int>
    //     0x546f68: ldr             x1, [PP, #0x920]  ; [pp+0x920] TypeArguments: <int>
    // 0x546f6c: r2 = 0
    //     0x546f6c: movz            x2, #0
    // 0x546f70: r0 = _GrowableList()
    //     0x546f70: bl              #0x3279b4  ; [dart:core] _GrowableList::_GrowableList
    // 0x546f74: LeaveFrame
    //     0x546f74: mov             SP, fp
    //     0x546f78: ldp             fp, lr, [SP], #0x10
    // 0x546f7c: ret
    //     0x546f7c: ret             
    // 0x546f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x546f80: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x546f84: b               #0x546f68
  }
  _ getGeneratorSingleYieldsBoosted(/* No info */) {
    // ** addr: 0x54a520, size: 0x200
    // 0x54a520: EnterFrame
    //     0x54a520: stp             fp, lr, [SP, #-0x10]!
    //     0x54a524: mov             fp, SP
    // 0x54a528: AllocStack(0x50)
    //     0x54a528: sub             SP, SP, #0x50
    // 0x54a52c: SetupParameters(IPlayableGameState<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r2 */)
    //     0x54a52c: mov             x0, x1
    //     0x54a530: mov             x5, x2
    //     0x54a534: stur            x2, [fp, #-0x10]
    //     0x54a538: mov             x2, x3
    //     0x54a53c: stur            x1, [fp, #-8]
    // 0x54a540: CheckStackOverflow
    //     0x54a540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54a544: cmp             SP, x16
    //     0x54a548: b.ls            #0x54a710
    // 0x54a54c: r1 = Null
    //     0x54a54c: mov             x1, NULL
    // 0x54a550: r0 = CustomNum()
    //     0x54a550: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x54a554: ldur            x5, [fp, #-0x10]
    // 0x54a558: r2 = LoadInt32Instr(r5)
    //     0x54a558: sbfx            x2, x5, #1, #0x1f
    //     0x54a55c: tbz             w5, #0, #0x54a564
    //     0x54a560: ldur            x2, [x5, #7]
    // 0x54a564: ldur            x4, [fp, #-8]
    // 0x54a568: r1 = LoadClassIdInstr(r4)
    //     0x54a568: ldur            x1, [x4, #-1]
    //     0x54a56c: ubfx            x1, x1, #0xc, #0x14
    // 0x54a570: mov             x3, x0
    // 0x54a574: mov             x0, x1
    // 0x54a578: mov             x1, x4
    // 0x54a57c: r0 = GDT[cid_x0 + 0x87fa]()
    //     0x54a57c: movz            x17, #0x87fa
    //     0x54a580: add             lr, x0, x17
    //     0x54a584: ldr             lr, [x21, lr, lsl #3]
    //     0x54a588: blr             lr
    // 0x54a58c: stur            x0, [fp, #-0x20]
    // 0x54a590: LoadField: r4 = r0->field_7
    //     0x54a590: ldur            w4, [x0, #7]
    // 0x54a594: DecompressPointer r4
    //     0x54a594: add             x4, x4, HEAP, lsl #32
    // 0x54a598: mov             x2, x4
    // 0x54a59c: stur            x4, [fp, #-0x18]
    // 0x54a5a0: r1 = Null
    //     0x54a5a0: mov             x1, NULL
    // 0x54a5a4: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x54a5a4: ldr             x3, [PP, #0x2528]  ; [pp+0x2528] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x54a5a8: r30 = InstantiateTypeArgumentsStub
    //     0x54a5a8: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x54a5ac: LoadField: r30 = r30->field_7
    //     0x54a5ac: ldur            lr, [lr, #7]
    // 0x54a5b0: blr             lr
    // 0x54a5b4: mov             x1, x0
    // 0x54a5b8: r0 = _CompactEntriesIterable()
    //     0x54a5b8: bl              #0x368b40  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x54a5bc: mov             x1, x0
    // 0x54a5c0: ldur            x0, [fp, #-0x20]
    // 0x54a5c4: StoreField: r1->field_b = r0
    //     0x54a5c4: stur            w0, [x1, #0xb]
    // 0x54a5c8: r0 = iterator()
    //     0x54a5c8: bl              #0x536584  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x54a5cc: stur            x0, [fp, #-0x28]
    // 0x54a5d0: CheckStackOverflow
    //     0x54a5d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54a5d4: cmp             SP, x16
    //     0x54a5d8: b.ls            #0x54a718
    // 0x54a5dc: mov             x1, x0
    // 0x54a5e0: r0 = moveNext()
    //     0x54a5e0: bl              #0x7ce934  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x54a5e4: tbnz            w0, #4, #0x54a6b4
    // 0x54a5e8: ldur            x0, [fp, #-0x28]
    // 0x54a5ec: LoadField: r1 = r0->field_2b
    //     0x54a5ec: ldur            w1, [x0, #0x2b]
    // 0x54a5f0: DecompressPointer r1
    //     0x54a5f0: add             x1, x1, HEAP, lsl #32
    // 0x54a5f4: cmp             w1, NULL
    // 0x54a5f8: b.eq            #0x54a704
    // 0x54a5fc: LoadField: r4 = r1->field_b
    //     0x54a5fc: ldur            w4, [x1, #0xb]
    // 0x54a600: DecompressPointer r4
    //     0x54a600: add             x4, x4, HEAP, lsl #32
    // 0x54a604: stur            x4, [fp, #-0x30]
    // 0x54a608: LoadField: r2 = r1->field_f
    //     0x54a608: ldur            w2, [x1, #0xf]
    // 0x54a60c: DecompressPointer r2
    //     0x54a60c: add             x2, x2, HEAP, lsl #32
    // 0x54a610: ldur            x1, [fp, #-8]
    // 0x54a614: mov             x3, x4
    // 0x54a618: ldur            x5, [fp, #-0x10]
    // 0x54a61c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x54a61c: ldr             x4, [PP, #0x12f8]  ; [pp+0x12f8] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x54a620: r0 = applyAllBoostsToYields()
    //     0x54a620: bl              #0x54a950  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::applyAllBoostsToYields
    // 0x54a624: mov             x3, x0
    // 0x54a628: ldur            x0, [fp, #-0x30]
    // 0x54a62c: ldur            x2, [fp, #-0x18]
    // 0x54a630: r1 = Null
    //     0x54a630: mov             x1, NULL
    // 0x54a634: stur            x3, [fp, #-0x38]
    // 0x54a638: cmp             w2, NULL
    // 0x54a63c: b.eq            #0x54a65c
    // 0x54a640: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x54a640: ldur            w4, [x2, #0x17]
    // 0x54a644: DecompressPointer r4
    //     0x54a644: add             x4, x4, HEAP, lsl #32
    // 0x54a648: r8 = X0
    //     0x54a648: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x54a64c: LoadField: r9 = r4->field_7
    //     0x54a64c: ldur            x9, [x4, #7]
    // 0x54a650: r3 = Null
    //     0x54a650: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a370] Null
    //     0x54a654: ldr             x3, [x3, #0x370]
    // 0x54a658: blr             x9
    // 0x54a65c: ldur            x0, [fp, #-0x38]
    // 0x54a660: ldur            x2, [fp, #-0x18]
    // 0x54a664: r1 = Null
    //     0x54a664: mov             x1, NULL
    // 0x54a668: cmp             w2, NULL
    // 0x54a66c: b.eq            #0x54a68c
    // 0x54a670: LoadField: r4 = r2->field_1b
    //     0x54a670: ldur            w4, [x2, #0x1b]
    // 0x54a674: DecompressPointer r4
    //     0x54a674: add             x4, x4, HEAP, lsl #32
    // 0x54a678: r8 = X1
    //     0x54a678: ldr             x8, [PP, #0x688]  ; [pp+0x688] TypeParameter: X1
    // 0x54a67c: LoadField: r9 = r4->field_7
    //     0x54a67c: ldur            x9, [x4, #7]
    // 0x54a680: r3 = Null
    //     0x54a680: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a380] Null
    //     0x54a684: ldr             x3, [x3, #0x380]
    // 0x54a688: blr             x9
    // 0x54a68c: ldur            x1, [fp, #-0x20]
    // 0x54a690: ldur            x2, [fp, #-0x30]
    // 0x54a694: r0 = _hashCode()
    //     0x54a694: bl              #0x8232f4  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x54a698: ldur            x1, [fp, #-0x20]
    // 0x54a69c: ldur            x2, [fp, #-0x30]
    // 0x54a6a0: ldur            x3, [fp, #-0x38]
    // 0x54a6a4: mov             x5, x0
    // 0x54a6a8: r0 = _set()
    //     0x54a6a8: bl              #0x32ac24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x54a6ac: ldur            x0, [fp, #-0x28]
    // 0x54a6b0: b               #0x54a5d0
    // 0x54a6b4: ldur            x1, [fp, #-8]
    // 0x54a6b8: LoadField: r2 = r1->field_7
    //     0x54a6b8: ldur            w2, [x1, #7]
    // 0x54a6bc: DecompressPointer r2
    //     0x54a6bc: add             x2, x2, HEAP, lsl #32
    // 0x54a6c0: stur            x2, [fp, #-0x10]
    // 0x54a6c4: r0 = LoadClassIdInstr(r1)
    //     0x54a6c4: ldur            x0, [x1, #-1]
    //     0x54a6c8: ubfx            x0, x0, #0xc, #0x14
    // 0x54a6cc: r0 = GDT[cid_x0 + 0x86a2]()
    //     0x54a6cc: movz            x17, #0x86a2
    //     0x54a6d0: add             lr, x0, x17
    //     0x54a6d4: ldr             lr, [x21, lr, lsl #3]
    //     0x54a6d8: blr             lr
    // 0x54a6dc: ldur            x16, [fp, #-0x10]
    // 0x54a6e0: ldur            lr, [fp, #-0x20]
    // 0x54a6e4: stp             lr, x16, [SP, #8]
    // 0x54a6e8: str             x0, [SP]
    // 0x54a6ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x54a6ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x54a6f0: r0 = MapOperations.multiply()
    //     0x54a6f0: bl              #0x54a760  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiply
    // 0x54a6f4: ldur            x0, [fp, #-0x20]
    // 0x54a6f8: LeaveFrame
    //     0x54a6f8: mov             SP, fp
    //     0x54a6fc: ldp             fp, lr, [SP], #0x10
    // 0x54a700: ret
    //     0x54a700: ret             
    // 0x54a704: r0 = noElement()
    //     0x54a704: bl              #0x3294c8  ; [dart:_internal] IterableElementError::noElement
    // 0x54a708: r0 = Throw()
    //     0x54a708: bl              #0x825670  ; ThrowStub
    // 0x54a70c: brk             #0
    // 0x54a710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54a710: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54a714: b               #0x54a54c
    // 0x54a718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54a718: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54a71c: b               #0x54a5dc
  }
  [closure] Map<X0, CustomNum> getGeneratorSingleYieldsBoosted(dynamic, int, num) {
    // ** addr: 0x54a720, size: 0x40
    // 0x54a720: EnterFrame
    //     0x54a720: stp             fp, lr, [SP, #-0x10]!
    //     0x54a724: mov             fp, SP
    // 0x54a728: ldr             x0, [fp, #0x20]
    // 0x54a72c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x54a72c: ldur            w1, [x0, #0x17]
    // 0x54a730: DecompressPointer r1
    //     0x54a730: add             x1, x1, HEAP, lsl #32
    // 0x54a734: CheckStackOverflow
    //     0x54a734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54a738: cmp             SP, x16
    //     0x54a73c: b.ls            #0x54a758
    // 0x54a740: ldr             x2, [fp, #0x18]
    // 0x54a744: ldr             x3, [fp, #0x10]
    // 0x54a748: r0 = getGeneratorSingleYieldsBoosted()
    //     0x54a748: bl              #0x54a520  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted
    // 0x54a74c: LeaveFrame
    //     0x54a74c: mov             SP, fp
    //     0x54a750: ldp             fp, lr, [SP], #0x10
    // 0x54a754: ret
    //     0x54a754: ret             
    // 0x54a758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54a758: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54a75c: b               #0x54a740
  }
  _ applyAllBoostsToYields(/* No info */) {
    // ** addr: 0x54a950, size: 0x34c
    // 0x54a950: EnterFrame
    //     0x54a950: stp             fp, lr, [SP, #-0x10]!
    //     0x54a954: mov             fp, SP
    // 0x54a958: AllocStack(0x48)
    //     0x54a958: sub             SP, SP, #0x48
    // 0x54a95c: SetupParameters(IPlayableGameState<X0> this /* r1 => r7, fp-0x10 */, dynamic _ /* r2 => r6, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */)
    //     0x54a95c: mov             x7, x1
    //     0x54a960: mov             x6, x2
    //     0x54a964: stur            x3, [fp, #-0x20]
    //     0x54a968: mov             x16, x5
    //     0x54a96c: mov             x5, x3
    //     0x54a970: mov             x3, x16
    //     0x54a974: stur            x1, [fp, #-0x10]
    //     0x54a978: stur            x2, [fp, #-0x18]
    //     0x54a97c: stur            x3, [fp, #-0x28]
    // 0x54a980: LoadField: r0 = r4->field_13
    //     0x54a980: ldur            w0, [x4, #0x13]
    // 0x54a984: LoadField: r1 = r4->field_1f
    //     0x54a984: ldur            w1, [x4, #0x1f]
    // 0x54a988: DecompressPointer r1
    //     0x54a988: add             x1, x1, HEAP, lsl #32
    // 0x54a98c: r16 = "metaBoostPow"
    //     0x54a98c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a3b0] "metaBoostPow"
    //     0x54a990: ldr             x16, [x16, #0x3b0]
    // 0x54a994: cmp             w1, w16
    // 0x54a998: b.ne            #0x54a9b8
    // 0x54a99c: LoadField: r1 = r4->field_23
    //     0x54a99c: ldur            w1, [x4, #0x23]
    // 0x54a9a0: DecompressPointer r1
    //     0x54a9a0: add             x1, x1, HEAP, lsl #32
    // 0x54a9a4: sub             w2, w0, w1
    // 0x54a9a8: add             x0, fp, w2, sxtw #2
    // 0x54a9ac: ldr             x0, [x0, #8]
    // 0x54a9b0: mov             x4, x0
    // 0x54a9b4: b               #0x54a9bc
    // 0x54a9b8: r4 = Null
    //     0x54a9b8: mov             x4, NULL
    // 0x54a9bc: stur            x4, [fp, #-8]
    // 0x54a9c0: CheckStackOverflow
    //     0x54a9c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54a9c4: cmp             SP, x16
    //     0x54a9c8: b.ls            #0x54ac94
    // 0x54a9cc: LoadField: r2 = r7->field_7
    //     0x54a9cc: ldur            w2, [x7, #7]
    // 0x54a9d0: DecompressPointer r2
    //     0x54a9d0: add             x2, x2, HEAP, lsl #32
    // 0x54a9d4: mov             x0, x5
    // 0x54a9d8: r1 = Null
    //     0x54a9d8: mov             x1, NULL
    // 0x54a9dc: cmp             w2, NULL
    // 0x54a9e0: b.eq            #0x54aa00
    // 0x54a9e4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x54a9e4: ldur            w4, [x2, #0x17]
    // 0x54a9e8: DecompressPointer r4
    //     0x54a9e8: add             x4, x4, HEAP, lsl #32
    // 0x54a9ec: r8 = X0
    //     0x54a9ec: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x54a9f0: LoadField: r9 = r4->field_7
    //     0x54a9f0: ldur            x9, [x4, #7]
    // 0x54a9f4: r3 = Null
    //     0x54a9f4: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a3b8] Null
    //     0x54a9f8: ldr             x3, [x3, #0x3b8]
    // 0x54a9fc: blr             x9
    // 0x54aa00: ldur            x2, [fp, #-8]
    // 0x54aa04: cmp             w2, NULL
    // 0x54aa08: b.ne            #0x54ab54
    // 0x54aa0c: ldur            x2, [fp, #-0x10]
    // 0x54aa10: r0 = LoadClassIdInstr(r2)
    //     0x54aa10: ldur            x0, [x2, #-1]
    //     0x54aa14: ubfx            x0, x0, #0xc, #0x14
    // 0x54aa18: mov             x1, x2
    // 0x54aa1c: r0 = GDT[cid_x0 + 0x99b3]()
    //     0x54aa1c: movz            x17, #0x99b3
    //     0x54aa20: add             lr, x0, x17
    //     0x54aa24: ldr             lr, [x21, lr, lsl #3]
    //     0x54aa28: blr             lr
    // 0x54aa2c: mov             x3, x0
    // 0x54aa30: ldur            x0, [fp, #-0x10]
    // 0x54aa34: stur            x3, [fp, #-0x38]
    // 0x54aa38: LoadField: r4 = r0->field_2f
    //     0x54aa38: ldur            w4, [x0, #0x2f]
    // 0x54aa3c: DecompressPointer r4
    //     0x54aa3c: add             x4, x4, HEAP, lsl #32
    // 0x54aa40: mov             x1, x4
    // 0x54aa44: ldur            x2, [fp, #-0x20]
    // 0x54aa48: stur            x4, [fp, #-0x30]
    // 0x54aa4c: r0 = _getValueOrData()
    //     0x54aa4c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54aa50: mov             x1, x0
    // 0x54aa54: ldur            x0, [fp, #-0x30]
    // 0x54aa58: LoadField: r2 = r0->field_f
    //     0x54aa58: ldur            w2, [x0, #0xf]
    // 0x54aa5c: DecompressPointer r2
    //     0x54aa5c: add             x2, x2, HEAP, lsl #32
    // 0x54aa60: cmp             w2, w1
    // 0x54aa64: b.ne            #0x54aa70
    // 0x54aa68: r0 = Null
    //     0x54aa68: mov             x0, NULL
    // 0x54aa6c: b               #0x54aa74
    // 0x54aa70: mov             x0, x1
    // 0x54aa74: cmp             w0, NULL
    // 0x54aa78: b.ne            #0x54aa84
    // 0x54aa7c: r0 = Null
    //     0x54aa7c: mov             x0, NULL
    // 0x54aa80: b               #0x54aa90
    // 0x54aa84: LoadField: r1 = r0->field_f
    //     0x54aa84: ldur            w1, [x0, #0xf]
    // 0x54aa88: DecompressPointer r1
    //     0x54aa88: add             x1, x1, HEAP, lsl #32
    // 0x54aa8c: mov             x0, x1
    // 0x54aa90: cmp             w0, NULL
    // 0x54aa94: b.ne            #0x54aaa4
    // 0x54aa98: r3 = Instance_CustomNum
    //     0x54aa98: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54aa9c: ldr             x3, [x3, #0xa70]
    // 0x54aaa0: b               #0x54aaa8
    // 0x54aaa4: mov             x3, x0
    // 0x54aaa8: ldur            x0, [fp, #-0x10]
    // 0x54aaac: stur            x3, [fp, #-0x48]
    // 0x54aab0: LoadField: r1 = r0->field_2b
    //     0x54aab0: ldur            w1, [x0, #0x2b]
    // 0x54aab4: DecompressPointer r1
    //     0x54aab4: add             x1, x1, HEAP, lsl #32
    // 0x54aab8: LoadField: r5 = r1->field_f
    //     0x54aab8: ldur            w5, [x1, #0xf]
    // 0x54aabc: DecompressPointer r5
    //     0x54aabc: add             x5, x5, HEAP, lsl #32
    // 0x54aac0: stur            x5, [fp, #-0x40]
    // 0x54aac4: LoadField: r4 = r0->field_33
    //     0x54aac4: ldur            w4, [x0, #0x33]
    // 0x54aac8: DecompressPointer r4
    //     0x54aac8: add             x4, x4, HEAP, lsl #32
    // 0x54aacc: mov             x1, x4
    // 0x54aad0: ldur            x2, [fp, #-0x28]
    // 0x54aad4: stur            x4, [fp, #-0x30]
    // 0x54aad8: r0 = _getValueOrData()
    //     0x54aad8: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54aadc: mov             x1, x0
    // 0x54aae0: ldur            x0, [fp, #-0x30]
    // 0x54aae4: LoadField: r2 = r0->field_f
    //     0x54aae4: ldur            w2, [x0, #0xf]
    // 0x54aae8: DecompressPointer r2
    //     0x54aae8: add             x2, x2, HEAP, lsl #32
    // 0x54aaec: cmp             w2, w1
    // 0x54aaf0: b.ne            #0x54aafc
    // 0x54aaf4: r0 = Null
    //     0x54aaf4: mov             x0, NULL
    // 0x54aaf8: b               #0x54ab00
    // 0x54aafc: mov             x0, x1
    // 0x54ab00: cmp             w0, NULL
    // 0x54ab04: b.ne            #0x54ab10
    // 0x54ab08: r0 = Null
    //     0x54ab08: mov             x0, NULL
    // 0x54ab0c: b               #0x54ab1c
    // 0x54ab10: LoadField: r1 = r0->field_f
    //     0x54ab10: ldur            w1, [x0, #0xf]
    // 0x54ab14: DecompressPointer r1
    //     0x54ab14: add             x1, x1, HEAP, lsl #32
    // 0x54ab18: mov             x0, x1
    // 0x54ab1c: cmp             w0, NULL
    // 0x54ab20: b.ne            #0x54ab30
    // 0x54ab24: r6 = Instance_CustomNum
    //     0x54ab24: add             x6, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54ab28: ldr             x6, [x6, #0xa70]
    // 0x54ab2c: b               #0x54ab34
    // 0x54ab30: mov             x6, x0
    // 0x54ab34: ldur            x1, [fp, #-0x18]
    // 0x54ab38: ldur            x2, [fp, #-0x38]
    // 0x54ab3c: ldur            x3, [fp, #-0x48]
    // 0x54ab40: ldur            x5, [fp, #-0x40]
    // 0x54ab44: r0 = mult5()
    //     0x54ab44: bl              #0x3db218  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult5
    // 0x54ab48: LeaveFrame
    //     0x54ab48: mov             SP, fp
    //     0x54ab4c: ldp             fp, lr, [SP], #0x10
    // 0x54ab50: ret
    //     0x54ab50: ret             
    // 0x54ab54: ldur            x0, [fp, #-0x10]
    // 0x54ab58: mov             x1, x0
    // 0x54ab5c: r0 = getCurrentMetaBoost()
    //     0x54ab5c: bl              #0x4e9864  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::getCurrentMetaBoost
    // 0x54ab60: mov             x1, x0
    // 0x54ab64: ldur            x2, [fp, #-8]
    // 0x54ab68: r0 = pow()
    //     0x54ab68: bl              #0x3da330  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::pow
    // 0x54ab6c: mov             x3, x0
    // 0x54ab70: ldur            x0, [fp, #-0x10]
    // 0x54ab74: stur            x3, [fp, #-0x30]
    // 0x54ab78: LoadField: r4 = r0->field_2f
    //     0x54ab78: ldur            w4, [x0, #0x2f]
    // 0x54ab7c: DecompressPointer r4
    //     0x54ab7c: add             x4, x4, HEAP, lsl #32
    // 0x54ab80: mov             x1, x4
    // 0x54ab84: ldur            x2, [fp, #-0x20]
    // 0x54ab88: stur            x4, [fp, #-8]
    // 0x54ab8c: r0 = _getValueOrData()
    //     0x54ab8c: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54ab90: mov             x1, x0
    // 0x54ab94: ldur            x0, [fp, #-8]
    // 0x54ab98: LoadField: r2 = r0->field_f
    //     0x54ab98: ldur            w2, [x0, #0xf]
    // 0x54ab9c: DecompressPointer r2
    //     0x54ab9c: add             x2, x2, HEAP, lsl #32
    // 0x54aba0: cmp             w2, w1
    // 0x54aba4: b.ne            #0x54abb0
    // 0x54aba8: r0 = Null
    //     0x54aba8: mov             x0, NULL
    // 0x54abac: b               #0x54abb4
    // 0x54abb0: mov             x0, x1
    // 0x54abb4: cmp             w0, NULL
    // 0x54abb8: b.ne            #0x54abc4
    // 0x54abbc: r0 = Null
    //     0x54abbc: mov             x0, NULL
    // 0x54abc0: b               #0x54abd0
    // 0x54abc4: LoadField: r1 = r0->field_f
    //     0x54abc4: ldur            w1, [x0, #0xf]
    // 0x54abc8: DecompressPointer r1
    //     0x54abc8: add             x1, x1, HEAP, lsl #32
    // 0x54abcc: mov             x0, x1
    // 0x54abd0: cmp             w0, NULL
    // 0x54abd4: b.ne            #0x54abe4
    // 0x54abd8: r3 = Instance_CustomNum
    //     0x54abd8: add             x3, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54abdc: ldr             x3, [x3, #0xa70]
    // 0x54abe0: b               #0x54abe8
    // 0x54abe4: mov             x3, x0
    // 0x54abe8: ldur            x0, [fp, #-0x10]
    // 0x54abec: stur            x3, [fp, #-0x38]
    // 0x54abf0: LoadField: r1 = r0->field_2b
    //     0x54abf0: ldur            w1, [x0, #0x2b]
    // 0x54abf4: DecompressPointer r1
    //     0x54abf4: add             x1, x1, HEAP, lsl #32
    // 0x54abf8: LoadField: r5 = r1->field_f
    //     0x54abf8: ldur            w5, [x1, #0xf]
    // 0x54abfc: DecompressPointer r5
    //     0x54abfc: add             x5, x5, HEAP, lsl #32
    // 0x54ac00: stur            x5, [fp, #-0x20]
    // 0x54ac04: LoadField: r4 = r0->field_33
    //     0x54ac04: ldur            w4, [x0, #0x33]
    // 0x54ac08: DecompressPointer r4
    //     0x54ac08: add             x4, x4, HEAP, lsl #32
    // 0x54ac0c: mov             x1, x4
    // 0x54ac10: ldur            x2, [fp, #-0x28]
    // 0x54ac14: stur            x4, [fp, #-8]
    // 0x54ac18: r0 = _getValueOrData()
    //     0x54ac18: bl              #0x32a84c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x54ac1c: mov             x1, x0
    // 0x54ac20: ldur            x0, [fp, #-8]
    // 0x54ac24: LoadField: r2 = r0->field_f
    //     0x54ac24: ldur            w2, [x0, #0xf]
    // 0x54ac28: DecompressPointer r2
    //     0x54ac28: add             x2, x2, HEAP, lsl #32
    // 0x54ac2c: cmp             w2, w1
    // 0x54ac30: b.ne            #0x54ac3c
    // 0x54ac34: r0 = Null
    //     0x54ac34: mov             x0, NULL
    // 0x54ac38: b               #0x54ac40
    // 0x54ac3c: mov             x0, x1
    // 0x54ac40: cmp             w0, NULL
    // 0x54ac44: b.ne            #0x54ac50
    // 0x54ac48: r0 = Null
    //     0x54ac48: mov             x0, NULL
    // 0x54ac4c: b               #0x54ac5c
    // 0x54ac50: LoadField: r1 = r0->field_f
    //     0x54ac50: ldur            w1, [x0, #0xf]
    // 0x54ac54: DecompressPointer r1
    //     0x54ac54: add             x1, x1, HEAP, lsl #32
    // 0x54ac58: mov             x0, x1
    // 0x54ac5c: cmp             w0, NULL
    // 0x54ac60: b.ne            #0x54ac70
    // 0x54ac64: r6 = Instance_CustomNum
    //     0x54ac64: add             x6, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x54ac68: ldr             x6, [x6, #0xa70]
    // 0x54ac6c: b               #0x54ac74
    // 0x54ac70: mov             x6, x0
    // 0x54ac74: ldur            x1, [fp, #-0x18]
    // 0x54ac78: ldur            x2, [fp, #-0x30]
    // 0x54ac7c: ldur            x3, [fp, #-0x38]
    // 0x54ac80: ldur            x5, [fp, #-0x20]
    // 0x54ac84: r0 = mult5()
    //     0x54ac84: bl              #0x3db218  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::mult5
    // 0x54ac88: LeaveFrame
    //     0x54ac88: mov             SP, fp
    //     0x54ac8c: ldp             fp, lr, [SP], #0x10
    // 0x54ac90: ret
    //     0x54ac90: ret             
    // 0x54ac94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54ac94: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54ac98: b               #0x54a9cc
  }
  _ getNonGeneratorStatsPerSecond(/* No info */) {
    // ** addr: 0x54f63c, size: 0x58
    // 0x54f63c: EnterFrame
    //     0x54f63c: stp             fp, lr, [SP, #-0x10]!
    //     0x54f640: mov             fp, SP
    // 0x54f644: AllocStack(0x10)
    //     0x54f644: sub             SP, SP, #0x10
    // 0x54f648: CheckStackOverflow
    //     0x54f648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54f64c: cmp             SP, x16
    //     0x54f650: b.ls            #0x54f68c
    // 0x54f654: LoadField: r2 = r1->field_7
    //     0x54f654: ldur            w2, [x1, #7]
    // 0x54f658: DecompressPointer r2
    //     0x54f658: add             x2, x2, HEAP, lsl #32
    // 0x54f65c: r1 = Null
    //     0x54f65c: mov             x1, NULL
    // 0x54f660: r3 = <X0, CustomNum>
    //     0x54f660: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x54f664: ldr             x3, [x3, #0xb10]
    // 0x54f668: r30 = InstantiateTypeArgumentsStub
    //     0x54f668: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x54f66c: LoadField: r30 = r30->field_7
    //     0x54f66c: ldur            lr, [lr, #7]
    // 0x54f670: blr             lr
    // 0x54f674: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x54f678: stp             x16, x0, [SP]
    // 0x54f67c: r0 = Map._fromLiteral()
    //     0x54f67c: bl              #0x32a640  ; [dart:core] Map::Map._fromLiteral
    // 0x54f680: LeaveFrame
    //     0x54f680: mov             SP, fp
    //     0x54f684: ldp             fp, lr, [SP], #0x10
    // 0x54f688: ret
    //     0x54f688: ret             
    // 0x54f68c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54f68c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54f690: b               #0x54f654
  }
  _ getGeneratorSingleYieldsBoostedForLegacyProgressBars(/* No info */) {
    // ** addr: 0x551cc8, size: 0x4c
    // 0x551cc8: EnterFrame
    //     0x551cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x551ccc: mov             fp, SP
    // 0x551cd0: mov             x4, x1
    // 0x551cd4: CheckStackOverflow
    //     0x551cd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x551cd8: cmp             SP, x16
    //     0x551cdc: b.ls            #0x551d0c
    // 0x551ce0: r0 = BoxInt64Instr(r2)
    //     0x551ce0: sbfiz           x0, x2, #1, #0x1f
    //     0x551ce4: cmp             x2, x0, asr #1
    //     0x551ce8: b.eq            #0x551cf4
    //     0x551cec: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x551cf0: stur            x2, [x0, #7]
    // 0x551cf4: mov             x1, x4
    // 0x551cf8: mov             x2, x0
    // 0x551cfc: r0 = getGeneratorSingleYieldsBoosted()
    //     0x551cfc: bl              #0x54a520  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::getGeneratorSingleYieldsBoosted
    // 0x551d00: LeaveFrame
    //     0x551d00: mov             SP, fp
    //     0x551d04: ldp             fp, lr, [SP], #0x10
    // 0x551d08: ret
    //     0x551d08: ret             
    // 0x551d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x551d0c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x551d10: b               #0x551ce0
  }
  _ notifyResumed(/* No info */) {
    // ** addr: 0x55291c, size: 0x170
    // 0x55291c: EnterFrame
    //     0x55291c: stp             fp, lr, [SP, #-0x10]!
    //     0x552920: mov             fp, SP
    // 0x552924: AllocStack(0x18)
    //     0x552924: sub             SP, SP, #0x18
    // 0x552928: SetupParameters(IPlayableGameState<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x552928: stur            x1, [fp, #-8]
    //     0x55292c: stur            x2, [fp, #-0x10]
    //     0x552930: stur            x3, [fp, #-0x18]
    // 0x552934: CheckStackOverflow
    //     0x552934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x552938: cmp             SP, x16
    //     0x55293c: b.ls            #0x552a7c
    // 0x552940: r1 = 3
    //     0x552940: movz            x1, #0x3
    // 0x552944: r0 = AllocateContext()
    //     0x552944: bl              #0x82637c  ; AllocateContextStub
    // 0x552948: mov             x2, x0
    // 0x55294c: ldur            x0, [fp, #-8]
    // 0x552950: StoreField: r2->field_f = r0
    //     0x552950: stur            w0, [x2, #0xf]
    // 0x552954: ldur            x0, [fp, #-0x10]
    // 0x552958: StoreField: r2->field_13 = r0
    //     0x552958: stur            w0, [x2, #0x13]
    // 0x55295c: ldur            x3, [fp, #-0x18]
    // 0x552960: r0 = BoxInt64Instr(r3)
    //     0x552960: sbfiz           x0, x3, #1, #0x1f
    //     0x552964: cmp             x3, x0, asr #1
    //     0x552968: b.eq            #0x552974
    //     0x55296c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x552970: stur            x3, [x0, #7]
    // 0x552974: ArrayStore: r2[0] = r0  ; List_4
    //     0x552974: stur            w0, [x2, #0x17]
    // 0x552978: r0 = LoadStaticField(0x444)
    //     0x552978: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x55297c: ldr             x0, [x0, #0x888]
    // 0x552980: cmp             w0, NULL
    // 0x552984: b.eq            #0x552a84
    // 0x552988: LoadField: r3 = r0->field_53
    //     0x552988: ldur            w3, [x0, #0x53]
    // 0x55298c: DecompressPointer r3
    //     0x55298c: add             x3, x3, HEAP, lsl #32
    // 0x552990: stur            x3, [fp, #-0x10]
    // 0x552994: LoadField: r0 = r3->field_7
    //     0x552994: ldur            w0, [x3, #7]
    // 0x552998: DecompressPointer r0
    //     0x552998: add             x0, x0, HEAP, lsl #32
    // 0x55299c: stur            x0, [fp, #-8]
    // 0x5529a0: r1 = Function '<anonymous closure>':.
    //     0x5529a0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16c20] AnonymousClosure: (0x552a8c), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyResumed (0x55291c)
    //     0x5529a4: ldr             x1, [x1, #0xc20]
    // 0x5529a8: r0 = AllocateClosure()
    //     0x5529a8: bl              #0x826750  ; AllocateClosureStub
    // 0x5529ac: ldur            x2, [fp, #-8]
    // 0x5529b0: mov             x3, x0
    // 0x5529b4: r1 = Null
    //     0x5529b4: mov             x1, NULL
    // 0x5529b8: stur            x3, [fp, #-8]
    // 0x5529bc: cmp             w2, NULL
    // 0x5529c0: b.eq            #0x5529e0
    // 0x5529c4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x5529c4: ldur            w4, [x2, #0x17]
    // 0x5529c8: DecompressPointer r4
    //     0x5529c8: add             x4, x4, HEAP, lsl #32
    // 0x5529cc: r8 = X0
    //     0x5529cc: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x5529d0: LoadField: r9 = r4->field_7
    //     0x5529d0: ldur            x9, [x4, #7]
    // 0x5529d4: r3 = Null
    //     0x5529d4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16c28] Null
    //     0x5529d8: ldr             x3, [x3, #0xc28]
    // 0x5529dc: blr             x9
    // 0x5529e0: ldur            x0, [fp, #-0x10]
    // 0x5529e4: LoadField: r1 = r0->field_b
    //     0x5529e4: ldur            w1, [x0, #0xb]
    // 0x5529e8: LoadField: r2 = r0->field_f
    //     0x5529e8: ldur            w2, [x0, #0xf]
    // 0x5529ec: DecompressPointer r2
    //     0x5529ec: add             x2, x2, HEAP, lsl #32
    // 0x5529f0: LoadField: r3 = r2->field_b
    //     0x5529f0: ldur            w3, [x2, #0xb]
    // 0x5529f4: r2 = LoadInt32Instr(r1)
    //     0x5529f4: sbfx            x2, x1, #1, #0x1f
    // 0x5529f8: stur            x2, [fp, #-0x18]
    // 0x5529fc: r1 = LoadInt32Instr(r3)
    //     0x5529fc: sbfx            x1, x3, #1, #0x1f
    // 0x552a00: cmp             x2, x1
    // 0x552a04: b.ne            #0x552a10
    // 0x552a08: mov             x1, x0
    // 0x552a0c: r0 = _growToNextCapacity()
    //     0x552a0c: bl              #0x3277ac  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x552a10: ldur            x0, [fp, #-0x10]
    // 0x552a14: ldur            x2, [fp, #-0x18]
    // 0x552a18: add             x1, x2, #1
    // 0x552a1c: lsl             x3, x1, #1
    // 0x552a20: StoreField: r0->field_b = r3
    //     0x552a20: stur            w3, [x0, #0xb]
    // 0x552a24: LoadField: r1 = r0->field_f
    //     0x552a24: ldur            w1, [x0, #0xf]
    // 0x552a28: DecompressPointer r1
    //     0x552a28: add             x1, x1, HEAP, lsl #32
    // 0x552a2c: ldur            x0, [fp, #-8]
    // 0x552a30: ArrayStore: r1[r2] = r0  ; List_4
    //     0x552a30: add             x25, x1, x2, lsl #2
    //     0x552a34: add             x25, x25, #0xf
    //     0x552a38: str             w0, [x25]
    //     0x552a3c: tbz             w0, #0, #0x552a58
    //     0x552a40: ldurb           w16, [x1, #-1]
    //     0x552a44: ldurb           w17, [x0, #-1]
    //     0x552a48: and             x16, x17, x16, lsr #2
    //     0x552a4c: tst             x16, HEAP, lsr #32
    //     0x552a50: b.eq            #0x552a58
    //     0x552a54: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x552a58: r1 = LoadStaticField(0x444)
    //     0x552a58: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x552a5c: ldr             x1, [x1, #0x888]
    // 0x552a60: cmp             w1, NULL
    // 0x552a64: b.eq            #0x552a88
    // 0x552a68: r0 = scheduleFrame()
    //     0x552a68: bl              #0x37cb7c  ; [dart:mixin_deduplication] _MixinApplication136&BindingBase&GestureBinding&SchedulerBinding::scheduleFrame
    // 0x552a6c: r0 = Null
    //     0x552a6c: mov             x0, NULL
    // 0x552a70: LeaveFrame
    //     0x552a70: mov             SP, fp
    //     0x552a74: ldp             fp, lr, [SP], #0x10
    // 0x552a78: ret
    //     0x552a78: ret             
    // 0x552a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x552a7c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x552a80: b               #0x552940
    // 0x552a84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x552a84: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x552a88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x552a88: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x552a8c, size: 0x198
    // 0x552a8c: EnterFrame
    //     0x552a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x552a90: mov             fp, SP
    // 0x552a94: AllocStack(0xb0)
    //     0x552a94: sub             SP, SP, #0xb0
    // 0x552a98: SetupParameters([dynamic _ /* r0 */])
    //     0x552a98: ldr             x0, [fp, #0x18]
    //     0x552a9c: ldur            w6, [x0, #0x17]
    //     0x552aa0: add             x6, x6, HEAP, lsl #32
    //     0x552aa4: stur            x6, [fp, #-0x38]
    // 0x552aa8: CheckStackOverflow
    //     0x552aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x552aac: cmp             SP, x16
    //     0x552ab0: b.ls            #0x552c10
    // 0x552ab4: ArrayLoad: r1 = r6[0]  ; List_4
    //     0x552ab4: ldur            w1, [x6, #0x17]
    // 0x552ab8: DecompressPointer r1
    //     0x552ab8: add             x1, x1, HEAP, lsl #32
    // 0x552abc: LoadField: r7 = r6->field_13
    //     0x552abc: ldur            w7, [x6, #0x13]
    // 0x552ac0: DecompressPointer r7
    //     0x552ac0: add             x7, x7, HEAP, lsl #32
    // 0x552ac4: stur            x7, [fp, #-0x30]
    // 0x552ac8: r0 = LoadStaticField(0xfd0)
    //     0x552ac8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x552acc: ldr             x0, [x0, #0x1fa0]
    // 0x552ad0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x552ad4: cmp             w0, w16
    // 0x552ad8: b.eq            #0x552c18
    // 0x552adc: LoadField: r4 = r0->field_13
    //     0x552adc: ldur            w4, [x0, #0x13]
    // 0x552ae0: DecompressPointer r4
    //     0x552ae0: add             x4, x4, HEAP, lsl #32
    // 0x552ae4: stur            x4, [fp, #-0x28]
    // 0x552ae8: LoadField: r0 = r6->field_f
    //     0x552ae8: ldur            w0, [x6, #0xf]
    // 0x552aec: DecompressPointer r0
    //     0x552aec: add             x0, x0, HEAP, lsl #32
    // 0x552af0: stur            x0, [fp, #-0x20]
    // 0x552af4: LoadField: r8 = r0->field_37
    //     0x552af4: ldur            w8, [x0, #0x37]
    // 0x552af8: DecompressPointer r8
    //     0x552af8: add             x8, x8, HEAP, lsl #32
    // 0x552afc: stur            x8, [fp, #-0x18]
    // 0x552b00: LoadField: r9 = r0->field_3b
    //     0x552b00: ldur            w9, [x0, #0x3b]
    // 0x552b04: DecompressPointer r9
    //     0x552b04: add             x9, x9, HEAP, lsl #32
    // 0x552b08: stur            x9, [fp, #-0x10]
    // 0x552b0c: r10 = LoadInt32Instr(r1)
    //     0x552b0c: sbfx            x10, x1, #1, #0x1f
    //     0x552b10: tbz             w1, #0, #0x552b18
    //     0x552b14: ldur            x10, [x1, #7]
    // 0x552b18: mov             x1, x0
    // 0x552b1c: mov             x2, x10
    // 0x552b20: mov             x3, x9
    // 0x552b24: mov             x5, x8
    // 0x552b28: stur            x10, [fp, #-8]
    // 0x552b2c: r0 = computeAndApplyIncome()
    //     0x552b2c: bl              #0x537b1c  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::computeAndApplyIncome
    // 0x552b30: mov             x3, x0
    // 0x552b34: stur            x3, [fp, #-0x50]
    // 0x552b38: mov             x4, x1
    // 0x552b3c: ldur            x0, [fp, #-0x38]
    // 0x552b40: stur            x4, [fp, #-0x48]
    // 0x552b44: LoadField: r1 = r0->field_f
    //     0x552b44: ldur            w1, [x0, #0xf]
    // 0x552b48: DecompressPointer r1
    //     0x552b48: add             x1, x1, HEAP, lsl #32
    // 0x552b4c: LoadField: r5 = r1->field_7
    //     0x552b4c: ldur            w5, [x1, #7]
    // 0x552b50: DecompressPointer r5
    //     0x552b50: add             x5, x5, HEAP, lsl #32
    // 0x552b54: stur            x5, [fp, #-0x40]
    // 0x552b58: r1 = Function '<anonymous closure>':.
    //     0x552b58: add             x1, PP, #0x16, lsl #12  ; [pp+0x16c38] AnonymousClosure: (0x5555c8), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyResumed (0x55291c)
    //     0x552b5c: ldr             x1, [x1, #0xc38]
    // 0x552b60: r2 = Null
    //     0x552b60: mov             x2, NULL
    // 0x552b64: r0 = AllocateClosure()
    //     0x552b64: bl              #0x826750  ; AllocateClosureStub
    // 0x552b68: r1 = Function '<anonymous closure>':.
    //     0x552b68: add             x1, PP, #0x16, lsl #12  ; [pp+0x16c40] AnonymousClosure: (0x554af0), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyResumed (0x55291c)
    //     0x552b6c: ldr             x1, [x1, #0xc40]
    // 0x552b70: r2 = Null
    //     0x552b70: mov             x2, NULL
    // 0x552b74: stur            x0, [fp, #-0x58]
    // 0x552b78: r0 = AllocateClosure()
    //     0x552b78: bl              #0x826750  ; AllocateClosureStub
    // 0x552b7c: ldur            x2, [fp, #-0x20]
    // 0x552b80: r1 = Function 'statsToString':.
    //     0x552b80: add             x1, PP, #0x16, lsl #12  ; [pp+0x16c48] AnonymousClosure: (0x5545d4), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::statsToString (0x554610)
    //     0x552b84: ldr             x1, [x1, #0xc48]
    // 0x552b88: stur            x0, [fp, #-0x20]
    // 0x552b8c: r0 = AllocateClosure()
    //     0x552b8c: bl              #0x826750  ; AllocateClosureStub
    // 0x552b90: ldur            x2, [fp, #-0x50]
    // 0x552b94: ldur            x3, [fp, #-0x48]
    // 0x552b98: stur            x0, [fp, #-0x48]
    // 0x552b9c: r0 = AllocateRecord2()
    //     0x552b9c: bl              #0x8260bc  ; AllocateRecord2Stub
    // 0x552ba0: ldur            x2, [fp, #-0x38]
    // 0x552ba4: r1 = Function '<anonymous closure>':.
    //     0x552ba4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16c50] AnonymousClosure: (0x554548), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyResumed (0x55291c)
    //     0x552ba8: ldr             x1, [x1, #0xc50]
    // 0x552bac: stur            x0, [fp, #-0x38]
    // 0x552bb0: r0 = AllocateClosure()
    //     0x552bb0: bl              #0x826750  ; AllocateClosureStub
    // 0x552bb4: ldur            x16, [fp, #-0x40]
    // 0x552bb8: str             x16, [SP, #0x50]
    // 0x552bbc: ldur            x1, [fp, #-8]
    // 0x552bc0: ldur            x16, [fp, #-0x30]
    // 0x552bc4: stp             x16, x1, [SP, #0x40]
    // 0x552bc8: ldur            x16, [fp, #-0x20]
    // 0x552bcc: ldur            lr, [fp, #-0x58]
    // 0x552bd0: stp             lr, x16, [SP, #0x30]
    // 0x552bd4: ldur            x16, [fp, #-0x28]
    // 0x552bd8: ldur            lr, [fp, #-0x48]
    // 0x552bdc: stp             lr, x16, [SP, #0x20]
    // 0x552be0: ldur            x16, [fp, #-0x18]
    // 0x552be4: stp             x16, x0, [SP, #0x10]
    // 0x552be8: ldur            x16, [fp, #-0x10]
    // 0x552bec: ldur            lr, [fp, #-0x38]
    // 0x552bf0: stp             lr, x16, [SP]
    // 0x552bf4: r4 = const [0x1, 0xa, 0xa, 0xa, null]
    //     0x552bf4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16c58] List(5) [0x1, 0xa, 0xa, 0xa, Null]
    //     0x552bf8: ldr             x4, [x4, #0xc58]
    // 0x552bfc: r0 = displayIdleDialogAndApplyIncome()
    //     0x552bfc: bl              #0x552c24  ; [package:pretentious/IdleResumeManager.dart] ::displayIdleDialogAndApplyIncome
    // 0x552c00: r0 = Null
    //     0x552c00: mov             x0, NULL
    // 0x552c04: LeaveFrame
    //     0x552c04: mov             SP, fp
    //     0x552c08: ldp             fp, lr, [SP], #0x10
    // 0x552c0c: ret
    //     0x552c0c: ret             
    // 0x552c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x552c10: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x552c14: b               #0x552ab4
    // 0x552c18: r9 = paymentManager
    //     0x552c18: add             x9, PP, #0xf, lsl #12  ; [pp+0xf4c0] Field <::.paymentManager>: static late (offset: 0xfd0)
    //     0x552c1c: ldr             x9, [x9, #0x4c0]
    // 0x552c20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x552c20: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x554548, size: 0x8c
    // 0x554548: EnterFrame
    //     0x554548: stp             fp, lr, [SP, #-0x10]!
    //     0x55454c: mov             fp, SP
    // 0x554550: ldr             x0, [fp, #0x10]
    // 0x554554: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x554554: ldur            w1, [x0, #0x17]
    // 0x554558: DecompressPointer r1
    //     0x554558: add             x1, x1, HEAP, lsl #32
    // 0x55455c: CheckStackOverflow
    //     0x55455c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x554560: cmp             SP, x16
    //     0x554564: b.ls            #0x5545cc
    // 0x554568: LoadField: r0 = r1->field_f
    //     0x554568: ldur            w0, [x1, #0xf]
    // 0x55456c: DecompressPointer r0
    //     0x55456c: add             x0, x0, HEAP, lsl #32
    // 0x554570: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x554570: ldur            w2, [x1, #0x17]
    // 0x554574: DecompressPointer r2
    //     0x554574: add             x2, x2, HEAP, lsl #32
    // 0x554578: LoadField: r3 = r0->field_57
    //     0x554578: ldur            w3, [x0, #0x57]
    // 0x55457c: DecompressPointer r3
    //     0x55457c: add             x3, x3, HEAP, lsl #32
    // 0x554580: r1 = LoadInt32Instr(r2)
    //     0x554580: sbfx            x1, x2, #1, #0x1f
    //     0x554584: tbz             w2, #0, #0x55458c
    //     0x554588: ldur            x1, [x2, #7]
    // 0x55458c: r2 = LoadClassIdInstr(r0)
    //     0x55458c: ldur            x2, [x0, #-1]
    //     0x554590: ubfx            x2, x2, #0xc, #0x14
    // 0x554594: mov             x16, x1
    // 0x554598: mov             x1, x2
    // 0x55459c: mov             x2, x16
    // 0x5545a0: mov             x16, x0
    // 0x5545a4: mov             x0, x1
    // 0x5545a8: mov             x1, x16
    // 0x5545ac: r0 = GDT[cid_x0 + 0x8a4e]()
    //     0x5545ac: movz            x17, #0x8a4e
    //     0x5545b0: add             lr, x0, x17
    //     0x5545b4: ldr             lr, [x21, lr, lsl #3]
    //     0x5545b8: blr             lr
    // 0x5545bc: r0 = Null
    //     0x5545bc: mov             x0, NULL
    // 0x5545c0: LeaveFrame
    //     0x5545c0: mov             SP, fp
    //     0x5545c4: ldp             fp, lr, [SP], #0x10
    // 0x5545c8: ret
    //     0x5545c8: ret             
    // 0x5545cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5545cc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5545d0: b               #0x554568
  }
  [closure] String statsToString(dynamic, Object?) {
    // ** addr: 0x5545d4, size: 0x3c
    // 0x5545d4: EnterFrame
    //     0x5545d4: stp             fp, lr, [SP, #-0x10]!
    //     0x5545d8: mov             fp, SP
    // 0x5545dc: ldr             x0, [fp, #0x18]
    // 0x5545e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x5545e0: ldur            w1, [x0, #0x17]
    // 0x5545e4: DecompressPointer r1
    //     0x5545e4: add             x1, x1, HEAP, lsl #32
    // 0x5545e8: CheckStackOverflow
    //     0x5545e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x5545ec: cmp             SP, x16
    //     0x5545f0: b.ls            #0x554608
    // 0x5545f4: ldr             x2, [fp, #0x10]
    // 0x5545f8: r0 = statsToString()
    //     0x5545f8: bl              #0x554610  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::statsToString
    // 0x5545fc: LeaveFrame
    //     0x5545fc: mov             SP, fp
    //     0x554600: ldp             fp, lr, [SP], #0x10
    // 0x554604: ret
    //     0x554604: ret             
    // 0x554608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x554608: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55460c: b               #0x5545f4
  }
  _ statsToString(/* No info */) {
    // ** addr: 0x554610, size: 0x2bc
    // 0x554610: EnterFrame
    //     0x554610: stp             fp, lr, [SP, #-0x10]!
    //     0x554614: mov             fp, SP
    // 0x554618: AllocStack(0x48)
    //     0x554618: sub             SP, SP, #0x48
    // 0x55461c: SetupParameters(IPlayableGameState<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x55461c: mov             x0, x2
    //     0x554620: stur            x1, [fp, #-8]
    //     0x554624: stur            x2, [fp, #-0x10]
    // 0x554628: CheckStackOverflow
    //     0x554628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55462c: cmp             SP, x16
    //     0x554630: b.ls            #0x5548bc
    // 0x554634: r1 = 1
    //     0x554634: movz            x1, #0x1
    // 0x554638: r0 = AllocateContext()
    //     0x554638: bl              #0x82637c  ; AllocateContextStub
    // 0x55463c: mov             x4, x0
    // 0x554640: ldur            x3, [fp, #-8]
    // 0x554644: stur            x4, [fp, #-0x20]
    // 0x554648: StoreField: r4->field_f = r3
    //     0x554648: stur            w3, [x4, #0xf]
    // 0x55464c: LoadField: r5 = r3->field_7
    //     0x55464c: ldur            w5, [x3, #7]
    // 0x554650: DecompressPointer r5
    //     0x554650: add             x5, x5, HEAP, lsl #32
    // 0x554654: ldur            x0, [fp, #-0x10]
    // 0x554658: mov             x2, x5
    // 0x55465c: stur            x5, [fp, #-0x18]
    // 0x554660: r1 = Null
    //     0x554660: mov             x1, NULL
    // 0x554664: r8 = Map<X0, CustomNum>
    //     0x554664: add             x8, PP, #0x16, lsl #12  ; [pp+0x16c60] Type: Map<X0, CustomNum>
    //     0x554668: ldr             x8, [x8, #0xc60]
    // 0x55466c: LoadField: r9 = r8->field_7
    //     0x55466c: ldur            x9, [x8, #7]
    // 0x554670: r3 = Null
    //     0x554670: add             x3, PP, #0x16, lsl #12  ; [pp+0x16c68] Null
    //     0x554674: ldr             x3, [x3, #0xc68]
    // 0x554678: blr             x9
    // 0x55467c: r0 = StringBuffer()
    //     0x55467c: bl              #0x338ef0  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x554680: mov             x1, x0
    // 0x554684: stur            x0, [fp, #-0x28]
    // 0x554688: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x554688: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x55468c: r0 = StringBuffer()
    //     0x55468c: bl              #0x338e88  ; [dart:core] StringBuffer::StringBuffer
    // 0x554690: ldur            x1, [fp, #-0x10]
    // 0x554694: r0 = LoadClassIdInstr(r1)
    //     0x554694: ldur            x0, [x1, #-1]
    //     0x554698: ubfx            x0, x0, #0xc, #0x14
    // 0x55469c: r0 = GDT[cid_x0 + -0xfa3]()
    //     0x55469c: sub             lr, x0, #0xfa3
    //     0x5546a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5546a4: blr             lr
    // 0x5546a8: r1 = LoadClassIdInstr(r0)
    //     0x5546a8: ldur            x1, [x0, #-1]
    //     0x5546ac: ubfx            x1, x1, #0xc, #0x14
    // 0x5546b0: mov             x16, x0
    // 0x5546b4: mov             x0, x1
    // 0x5546b8: mov             x1, x16
    // 0x5546bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x5546bc: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x5546c0: r0 = GDT[cid_x0 + 0x8751]()
    //     0x5546c0: movz            x17, #0x8751
    //     0x5546c4: add             lr, x0, x17
    //     0x5546c8: ldr             lr, [x21, lr, lsl #3]
    //     0x5546cc: blr             lr
    // 0x5546d0: ldur            x2, [fp, #-0x20]
    // 0x5546d4: ldur            x3, [fp, #-0x18]
    // 0x5546d8: r1 = Function '<anonymous closure>':.
    //     0x5546d8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16c78] AnonymousClosure: (0x554a70), in [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::statsToString (0x554610)
    //     0x5546dc: ldr             x1, [x1, #0xc78]
    // 0x5546e0: stur            x0, [fp, #-0x10]
    // 0x5546e4: r0 = AllocateClosureTA()
    //     0x5546e4: bl              #0x82658c  ; AllocateClosureTAStub
    // 0x5546e8: str             x0, [SP]
    // 0x5546ec: ldur            x1, [fp, #-0x10]
    // 0x5546f0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x5546f0: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x5546f4: r0 = sort()
    //     0x5546f4: bl              #0x3666a4  ; [dart:collection] ListBase::sort
    // 0x5546f8: ldur            x3, [fp, #-0x10]
    // 0x5546fc: LoadField: r4 = r3->field_7
    //     0x5546fc: ldur            w4, [x3, #7]
    // 0x554700: DecompressPointer r4
    //     0x554700: add             x4, x4, HEAP, lsl #32
    // 0x554704: stur            x4, [fp, #-0x20]
    // 0x554708: LoadField: r0 = r3->field_b
    //     0x554708: ldur            w0, [x3, #0xb]
    // 0x55470c: r5 = LoadInt32Instr(r0)
    //     0x55470c: sbfx            x5, x0, #1, #0x1f
    // 0x554710: stur            x5, [fp, #-0x38]
    // 0x554714: r0 = 0
    //     0x554714: movz            x0, #0
    // 0x554718: ldur            x6, [fp, #-8]
    // 0x55471c: CheckStackOverflow
    //     0x55471c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x554720: cmp             SP, x16
    //     0x554724: b.ls            #0x5548c4
    // 0x554728: LoadField: r1 = r3->field_b
    //     0x554728: ldur            w1, [x3, #0xb]
    // 0x55472c: r2 = LoadInt32Instr(r1)
    //     0x55472c: sbfx            x2, x1, #1, #0x1f
    // 0x554730: cmp             x5, x2
    // 0x554734: b.ne            #0x55489c
    // 0x554738: cmp             x0, x2
    // 0x55473c: b.ge            #0x554884
    // 0x554740: LoadField: r1 = r3->field_f
    //     0x554740: ldur            w1, [x3, #0xf]
    // 0x554744: DecompressPointer r1
    //     0x554744: add             x1, x1, HEAP, lsl #32
    // 0x554748: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x554748: add             x16, x1, x0, lsl #2
    //     0x55474c: ldur            w7, [x16, #0xf]
    // 0x554750: DecompressPointer r7
    //     0x554750: add             x7, x7, HEAP, lsl #32
    // 0x554754: stur            x7, [fp, #-0x18]
    // 0x554758: add             x8, x0, #1
    // 0x55475c: stur            x8, [fp, #-0x30]
    // 0x554760: cmp             w7, NULL
    // 0x554764: b.ne            #0x554798
    // 0x554768: mov             x0, x7
    // 0x55476c: mov             x2, x4
    // 0x554770: r1 = Null
    //     0x554770: mov             x1, NULL
    // 0x554774: cmp             w2, NULL
    // 0x554778: b.eq            #0x554798
    // 0x55477c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x55477c: ldur            w4, [x2, #0x17]
    // 0x554780: DecompressPointer r4
    //     0x554780: add             x4, x4, HEAP, lsl #32
    // 0x554784: r8 = X0
    //     0x554784: ldr             x8, [PP, #0x1e0]  ; [pp+0x1e0] TypeParameter: X0
    // 0x554788: LoadField: r9 = r4->field_7
    //     0x554788: ldur            x9, [x4, #7]
    // 0x55478c: r3 = Null
    //     0x55478c: add             x3, PP, #0x16, lsl #12  ; [pp+0x16c80] Null
    //     0x554790: ldr             x3, [x3, #0xc80]
    // 0x554794: blr             x9
    // 0x554798: ldur            x0, [fp, #-8]
    // 0x55479c: ldur            x3, [fp, #-0x18]
    // 0x5547a0: ldur            x1, [fp, #-0x28]
    // 0x5547a4: r2 = "\n"
    //     0x5547a4: ldr             x2, [PP, #0x2298]  ; [pp+0x2298] "\n"
    // 0x5547a8: r0 = _writeString()
    //     0x5547a8: bl              #0x338c84  ; [dart:core] StringBuffer::_writeString
    // 0x5547ac: ldur            x1, [fp, #-0x18]
    // 0x5547b0: LoadField: r0 = r1->field_b
    //     0x5547b0: ldur            w0, [x1, #0xb]
    // 0x5547b4: DecompressPointer r0
    //     0x5547b4: add             x0, x0, HEAP, lsl #32
    // 0x5547b8: ldur            x2, [fp, #-8]
    // 0x5547bc: LoadField: r3 = r2->field_5f
    //     0x5547bc: ldur            w3, [x2, #0x5f]
    // 0x5547c0: DecompressPointer r3
    //     0x5547c0: add             x3, x3, HEAP, lsl #32
    // 0x5547c4: stp             x0, x3, [SP]
    // 0x5547c8: mov             x0, x3
    // 0x5547cc: ClosureCall
    //     0x5547cc: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5547d0: ldur            x2, [x0, #0x1f]
    //     0x5547d4: blr             x2
    // 0x5547d8: mov             x1, x0
    // 0x5547dc: r0 = Capitalization.convertToTitleCase()
    //     0x5547dc: bl              #0x5548cc  ; [package:custom_tools/BasicExtensions.dart] ::Capitalization.convertToTitleCase
    // 0x5547e0: r1 = LoadClassIdInstr(r0)
    //     0x5547e0: ldur            x1, [x0, #-1]
    //     0x5547e4: ubfx            x1, x1, #0xc, #0x14
    // 0x5547e8: str             x0, [SP]
    // 0x5547ec: mov             x0, x1
    // 0x5547f0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5547f0: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5547f4: r0 = GDT[cid_x0 + 0x3019]()
    //     0x5547f4: movz            x17, #0x3019
    //     0x5547f8: add             lr, x0, x17
    //     0x5547fc: ldr             lr, [x21, lr, lsl #3]
    //     0x554800: blr             lr
    // 0x554804: LoadField: r1 = r0->field_7
    //     0x554804: ldur            w1, [x0, #7]
    // 0x554808: cbz             w1, #0x554818
    // 0x55480c: ldur            x1, [fp, #-0x28]
    // 0x554810: mov             x2, x0
    // 0x554814: r0 = _writeString()
    //     0x554814: bl              #0x338c84  ; [dart:core] StringBuffer::_writeString
    // 0x554818: ldur            x0, [fp, #-0x18]
    // 0x55481c: ldur            x1, [fp, #-0x28]
    // 0x554820: r2 = ": "
    //     0x554820: ldr             x2, [PP, #0x2250]  ; [pp+0x2250] ": "
    // 0x554824: r0 = _writeString()
    //     0x554824: bl              #0x338c84  ; [dart:core] StringBuffer::_writeString
    // 0x554828: ldur            x0, [fp, #-0x18]
    // 0x55482c: LoadField: r1 = r0->field_f
    //     0x55482c: ldur            w1, [x0, #0xf]
    // 0x554830: DecompressPointer r1
    //     0x554830: add             x1, x1, HEAP, lsl #32
    // 0x554834: r0 = 60
    //     0x554834: movz            x0, #0x3c
    // 0x554838: branchIfSmi(r1, 0x554844)
    //     0x554838: tbz             w1, #0, #0x554844
    // 0x55483c: r0 = LoadClassIdInstr(r1)
    //     0x55483c: ldur            x0, [x1, #-1]
    //     0x554840: ubfx            x0, x0, #0xc, #0x14
    // 0x554844: str             x1, [SP]
    // 0x554848: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x554848: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x55484c: r0 = GDT[cid_x0 + 0x3019]()
    //     0x55484c: movz            x17, #0x3019
    //     0x554850: add             lr, x0, x17
    //     0x554854: ldr             lr, [x21, lr, lsl #3]
    //     0x554858: blr             lr
    // 0x55485c: LoadField: r1 = r0->field_7
    //     0x55485c: ldur            w1, [x0, #7]
    // 0x554860: cbz             w1, #0x554870
    // 0x554864: ldur            x1, [fp, #-0x28]
    // 0x554868: mov             x2, x0
    // 0x55486c: r0 = _writeString()
    //     0x55486c: bl              #0x338c84  ; [dart:core] StringBuffer::_writeString
    // 0x554870: ldur            x0, [fp, #-0x30]
    // 0x554874: ldur            x3, [fp, #-0x10]
    // 0x554878: ldur            x4, [fp, #-0x20]
    // 0x55487c: ldur            x5, [fp, #-0x38]
    // 0x554880: b               #0x554718
    // 0x554884: ldur            x16, [fp, #-0x28]
    // 0x554888: str             x16, [SP]
    // 0x55488c: r0 = toString()
    //     0x55488c: bl              #0x6ef574  ; [dart:core] StringBuffer::toString
    // 0x554890: LeaveFrame
    //     0x554890: mov             SP, fp
    //     0x554894: ldp             fp, lr, [SP], #0x10
    // 0x554898: ret
    //     0x554898: ret             
    // 0x55489c: mov             x0, x3
    // 0x5548a0: r0 = ConcurrentModificationError()
    //     0x5548a0: bl              #0x327c48  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x5548a4: mov             x1, x0
    // 0x5548a8: ldur            x0, [fp, #-0x10]
    // 0x5548ac: StoreField: r1->field_b = r0
    //     0x5548ac: stur            w0, [x1, #0xb]
    // 0x5548b0: mov             x0, x1
    // 0x5548b4: r0 = Throw()
    //     0x5548b4: bl              #0x825670  ; ThrowStub
    // 0x5548b8: brk             #0
    // 0x5548bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5548bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5548c0: b               #0x554634
    // 0x5548c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5548c4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5548c8: b               #0x554728
  }
  [closure] int <anonymous closure>(dynamic, MapEntry<X0, CustomNum>, MapEntry<X0, CustomNum>) {
    // ** addr: 0x554a70, size: 0x80
    // 0x554a70: EnterFrame
    //     0x554a70: stp             fp, lr, [SP, #-0x10]!
    //     0x554a74: mov             fp, SP
    // 0x554a78: ldr             x1, [fp, #0x18]
    // 0x554a7c: LoadField: r2 = r1->field_f
    //     0x554a7c: ldur            w2, [x1, #0xf]
    // 0x554a80: DecompressPointer r2
    //     0x554a80: add             x2, x2, HEAP, lsl #32
    // 0x554a84: cmp             w2, NULL
    // 0x554a88: b.eq            #0x554ae8
    // 0x554a8c: LoadField: d0 = r2->field_7
    //     0x554a8c: ldur            d0, [x2, #7]
    // 0x554a90: ldr             x1, [fp, #0x10]
    // 0x554a94: LoadField: r2 = r1->field_f
    //     0x554a94: ldur            w2, [x1, #0xf]
    // 0x554a98: DecompressPointer r2
    //     0x554a98: add             x2, x2, HEAP, lsl #32
    // 0x554a9c: cmp             w2, NULL
    // 0x554aa0: b.eq            #0x554aec
    // 0x554aa4: LoadField: d1 = r2->field_7
    //     0x554aa4: ldur            d1, [x2, #7]
    // 0x554aa8: fcmp            d0, d1
    // 0x554aac: b.le            #0x554ac0
    // 0x554ab0: r0 = -2
    //     0x554ab0: orr             x0, xzr, #0xfffffffffffffffe
    // 0x554ab4: LeaveFrame
    //     0x554ab4: mov             SP, fp
    //     0x554ab8: ldp             fp, lr, [SP], #0x10
    // 0x554abc: ret
    //     0x554abc: ret             
    // 0x554ac0: fcmp            d0, d1
    // 0x554ac4: b.ne            #0x554ad8
    // 0x554ac8: r0 = 0
    //     0x554ac8: movz            x0, #0
    // 0x554acc: LeaveFrame
    //     0x554acc: mov             SP, fp
    //     0x554ad0: ldp             fp, lr, [SP], #0x10
    // 0x554ad4: ret
    //     0x554ad4: ret             
    // 0x554ad8: r0 = 2
    //     0x554ad8: movz            x0, #0x2
    // 0x554adc: LeaveFrame
    //     0x554adc: mov             SP, fp
    //     0x554ae0: ldp             fp, lr, [SP], #0x10
    // 0x554ae4: ret
    //     0x554ae4: ret             
    // 0x554ae8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x554ae8: bl              #0x827db8  ; NullErrorSharedWithoutFPURegsStub
    // 0x554aec: r0 = NullErrorSharedWithFPURegs()
    //     0x554aec: bl              #0x827e04  ; NullErrorSharedWithFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x554af0, size: 0xd4
    // 0x554af0: EnterFrame
    //     0x554af0: stp             fp, lr, [SP, #-0x10]!
    //     0x554af4: mov             fp, SP
    // 0x554af8: AllocStack(0x20)
    //     0x554af8: sub             SP, SP, #0x20
    // 0x554afc: SetupParameters(IPlayableGameState<X0> this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x554afc: stur            NULL, [fp, #-8]
    //     0x554b00: movz            x0, #0
    //     0x554b04: add             x1, fp, w0, sxtw #2
    //     0x554b08: ldr             x1, [x1, #0x18]
    //     0x554b0c: add             x2, fp, w0, sxtw #2
    //     0x554b10: ldr             x2, [x2, #0x10]
    //     0x554b14: stur            x2, [fp, #-0x18]
    //     0x554b18: ldur            w3, [x1, #0x17]
    //     0x554b1c: add             x3, x3, HEAP, lsl #32
    //     0x554b20: stur            x3, [fp, #-0x10]
    // 0x554b24: CheckStackOverflow
    //     0x554b24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x554b28: cmp             SP, x16
    //     0x554b2c: b.ls            #0x554bb0
    // 0x554b30: InitAsync() -> Future<void?>
    //     0x554b30: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x554b34: bl              #0x34b9a0  ; InitAsyncStub
    // 0x554b38: r0 = LoadStaticField(0xfd0)
    //     0x554b38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x554b3c: ldr             x0, [x0, #0x1fa0]
    // 0x554b40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x554b44: cmp             w0, w16
    // 0x554b48: b.eq            #0x554bb8
    // 0x554b4c: r1 = "use_alt_unlock"
    //     0x554b4c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12988] "use_alt_unlock"
    //     0x554b50: ldr             x1, [x1, #0x988]
    // 0x554b54: stur            x0, [fp, #-0x10]
    // 0x554b58: r0 = remoteConfigGetBool()
    //     0x554b58: bl              #0x44fab4  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetBool
    // 0x554b5c: cmp             w0, NULL
    // 0x554b60: b.eq            #0x554b74
    // 0x554b64: tbnz            w0, #4, #0x554b74
    // 0x554b68: r3 = "pro_unlock_pretentious_alt"
    //     0x554b68: add             x3, PP, #0xe, lsl #12  ; [pp+0xe4b0] "pro_unlock_pretentious_alt"
    //     0x554b6c: ldr             x3, [x3, #0x4b0]
    // 0x554b70: b               #0x554b7c
    // 0x554b74: r3 = "pro_unlock_pretentious"
    //     0x554b74: add             x3, PP, #0xe, lsl #12  ; [pp+0xe4a8] "pro_unlock_pretentious"
    //     0x554b78: ldr             x3, [x3, #0x4a8]
    // 0x554b7c: stur            x3, [fp, #-0x20]
    // 0x554b80: r4 = const [0, 0, 0, 0, null]
    //     0x554b80: ldr             x4, [PP, #0x2958]  ; [pp+0x2958] List(5) [0, 0, 0, 0, Null]
    // 0x554b84: r0 = app()
    //     0x554b84: bl              #0x3548dc  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x554b88: mov             x1, x0
    // 0x554b8c: r0 = instanceFor()
    //     0x554b8c: bl              #0x4509c4  ; [package:firebase_remote_config/firebase_remote_config.dart] FirebaseRemoteConfig::instanceFor
    // 0x554b90: mov             x1, x0
    // 0x554b94: r0 = getBool()
    //     0x554b94: bl              #0x5553e4  ; [package:firebase_remote_config/firebase_remote_config.dart] FirebaseRemoteConfig::getBool
    // 0x554b98: ldur            x1, [fp, #-0x10]
    // 0x554b9c: ldur            x2, [fp, #-0x18]
    // 0x554ba0: ldur            x3, [fp, #-0x20]
    // 0x554ba4: mov             x5, x0
    // 0x554ba8: r0 = displayPurchase()
    //     0x554ba8: bl              #0x554bc4  ; [package:pretentious/fragment/lib/PaymentManager.dart] PaymentManager::displayPurchase
    // 0x554bac: r0 = ReturnAsync()
    //     0x554bac: b               #0x353380  ; ReturnAsyncStub
    // 0x554bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x554bb0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x554bb4: b               #0x554b30
    // 0x554bb8: r9 = paymentManager
    //     0x554bb8: add             x9, PP, #0xf, lsl #12  ; [pp+0xf4c0] Field <::.paymentManager>: static late (offset: 0xfd0)
    //     0x554bbc: ldr             x9, [x9, #0x4c0]
    // 0x554bc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x554bc0: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, (dynamic) => void) async {
    // ** addr: 0x5555c8, size: 0x90
    // 0x5555c8: EnterFrame
    //     0x5555c8: stp             fp, lr, [SP, #-0x10]!
    //     0x5555cc: mov             fp, SP
    // 0x5555d0: AllocStack(0x18)
    //     0x5555d0: sub             SP, SP, #0x18
    // 0x5555d4: SetupParameters(IPlayableGameState<X0> this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x5555d4: stur            NULL, [fp, #-8]
    //     0x5555d8: movz            x0, #0
    //     0x5555dc: add             x1, fp, w0, sxtw #2
    //     0x5555e0: ldr             x1, [x1, #0x18]
    //     0x5555e4: add             x2, fp, w0, sxtw #2
    //     0x5555e8: ldr             x2, [x2, #0x10]
    //     0x5555ec: stur            x2, [fp, #-0x18]
    //     0x5555f0: ldur            w3, [x1, #0x17]
    //     0x5555f4: add             x3, x3, HEAP, lsl #32
    //     0x5555f8: stur            x3, [fp, #-0x10]
    // 0x5555fc: CheckStackOverflow
    //     0x5555fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x555600: cmp             SP, x16
    //     0x555604: b.ls            #0x555650
    // 0x555608: InitAsync() -> Future<void?>
    //     0x555608: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x55560c: bl              #0x34b9a0  ; InitAsyncStub
    // 0x555610: r1 = "ShowAtt"
    //     0x555610: add             x1, PP, #0x12, lsl #12  ; [pp+0x12950] "ShowAtt"
    //     0x555614: ldr             x1, [x1, #0x950]
    // 0x555618: r0 = remoteConfigGetBool()
    //     0x555618: bl              #0x44fab4  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetBool
    // 0x55561c: cmp             w0, NULL
    // 0x555620: b.ne            #0x555630
    // 0x555624: r1 = "show_att"
    //     0x555624: add             x1, PP, #0x12, lsl #12  ; [pp+0x12990] "show_att"
    //     0x555628: ldr             x1, [x1, #0x990]
    // 0x55562c: r0 = remoteConfigGetBool()
    //     0x55562c: bl              #0x44fab4  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetBool
    // 0x555630: cmp             w0, NULL
    // 0x555634: b.ne            #0x555640
    // 0x555638: r2 = false
    //     0x555638: add             x2, NULL, #0x30  ; false
    // 0x55563c: b               #0x555644
    // 0x555640: mov             x2, x0
    // 0x555644: ldur            x1, [fp, #-0x18]
    // 0x555648: r0 = displayRewardAd()
    //     0x555648: bl              #0x555658  ; [package:ad_manager/AdManager.dart] ::displayRewardAd
    // 0x55564c: r0 = ReturnAsync()
    //     0x55564c: b               #0x353380  ; ReturnAsyncStub
    // 0x555650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x555650: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x555654: b               #0x555608
  }
  _ getGeneratorSingleYieldsRawPreMetaBoosts(/* No info */) {
    // ** addr: 0x55b23c, size: 0xb0
    // 0x55b23c: EnterFrame
    //     0x55b23c: stp             fp, lr, [SP, #-0x10]!
    //     0x55b240: mov             fp, SP
    // 0x55b244: AllocStack(0x18)
    //     0x55b244: sub             SP, SP, #0x18
    // 0x55b248: SetupParameters(IPlayableGameState<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x55b248: mov             x4, x1
    //     0x55b24c: mov             x0, x2
    //     0x55b250: stur            x1, [fp, #-8]
    //     0x55b254: stur            x2, [fp, #-0x10]
    // 0x55b258: CheckStackOverflow
    //     0x55b258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55b25c: cmp             SP, x16
    //     0x55b260: b.ls            #0x55b2e4
    // 0x55b264: LoadField: r2 = r4->field_7
    //     0x55b264: ldur            w2, [x4, #7]
    // 0x55b268: DecompressPointer r2
    //     0x55b268: add             x2, x2, HEAP, lsl #32
    // 0x55b26c: r1 = Null
    //     0x55b26c: mov             x1, NULL
    // 0x55b270: r3 = <X0, CustomNum>
    //     0x55b270: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x55b274: ldr             x3, [x3, #0xb10]
    // 0x55b278: r30 = InstantiateTypeArgumentsStub
    //     0x55b278: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x55b27c: LoadField: r30 = r30->field_7
    //     0x55b27c: ldur            lr, [lr, #7]
    // 0x55b280: blr             lr
    // 0x55b284: mov             x3, x0
    // 0x55b288: ldur            x2, [fp, #-0x10]
    // 0x55b28c: stur            x3, [fp, #-0x18]
    // 0x55b290: r0 = BoxInt64Instr(r2)
    //     0x55b290: sbfiz           x0, x2, #1, #0x1f
    //     0x55b294: cmp             x2, x0, asr #1
    //     0x55b298: b.eq            #0x55b2a4
    //     0x55b29c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x55b2a0: stur            x2, [x0, #7]
    // 0x55b2a4: ldur            x1, [fp, #-8]
    // 0x55b2a8: r2 = LoadClassIdInstr(r1)
    //     0x55b2a8: ldur            x2, [x1, #-1]
    //     0x55b2ac: ubfx            x2, x2, #0xc, #0x14
    // 0x55b2b0: mov             x16, x0
    // 0x55b2b4: mov             x0, x2
    // 0x55b2b8: mov             x2, x16
    // 0x55b2bc: r0 = GDT[cid_x0 + -0xcb6]()
    //     0x55b2bc: sub             lr, x0, #0xcb6
    //     0x55b2c0: ldr             lr, [x21, lr, lsl #3]
    //     0x55b2c4: blr             lr
    // 0x55b2c8: LoadField: r2 = r0->field_23
    //     0x55b2c8: ldur            w2, [x0, #0x23]
    // 0x55b2cc: DecompressPointer r2
    //     0x55b2cc: add             x2, x2, HEAP, lsl #32
    // 0x55b2d0: ldur            x1, [fp, #-0x18]
    // 0x55b2d4: r0 = LinkedHashMap.from()
    //     0x55b2d4: bl              #0x354518  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x55b2d8: LeaveFrame
    //     0x55b2d8: mov             SP, fp
    //     0x55b2dc: ldp             fp, lr, [SP], #0x10
    // 0x55b2e0: ret
    //     0x55b2e0: ret             
    // 0x55b2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55b2e4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55b2e8: b               #0x55b264
  }
  _ getGeneratorSingleYieldsRawPostMetaBoosts(/* No info */) {
    // ** addr: 0x55c148, size: 0x98
    // 0x55c148: EnterFrame
    //     0x55c148: stp             fp, lr, [SP, #-0x10]!
    //     0x55c14c: mov             fp, SP
    // 0x55c150: AllocStack(0x30)
    //     0x55c150: sub             SP, SP, #0x30
    // 0x55c154: SetupParameters(IPlayableGameState<X0> this /* r1 => r4, fp-0x10 */)
    //     0x55c154: mov             x4, x1
    //     0x55c158: stur            x1, [fp, #-0x10]
    // 0x55c15c: CheckStackOverflow
    //     0x55c15c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55c160: cmp             SP, x16
    //     0x55c164: b.ls            #0x55c1d8
    // 0x55c168: LoadField: r5 = r4->field_7
    //     0x55c168: ldur            w5, [x4, #7]
    // 0x55c16c: DecompressPointer r5
    //     0x55c16c: add             x5, x5, HEAP, lsl #32
    // 0x55c170: stur            x5, [fp, #-8]
    // 0x55c174: r0 = LoadClassIdInstr(r4)
    //     0x55c174: ldur            x0, [x4, #-1]
    //     0x55c178: ubfx            x0, x0, #0xc, #0x14
    // 0x55c17c: mov             x1, x4
    // 0x55c180: r0 = GDT[cid_x0 + 0x87fa]()
    //     0x55c180: movz            x17, #0x87fa
    //     0x55c184: add             lr, x0, x17
    //     0x55c188: ldr             lr, [x21, lr, lsl #3]
    //     0x55c18c: blr             lr
    // 0x55c190: mov             x2, x0
    // 0x55c194: ldur            x1, [fp, #-0x10]
    // 0x55c198: stur            x2, [fp, #-0x18]
    // 0x55c19c: r0 = LoadClassIdInstr(r1)
    //     0x55c19c: ldur            x0, [x1, #-1]
    //     0x55c1a0: ubfx            x0, x0, #0xc, #0x14
    // 0x55c1a4: r0 = GDT[cid_x0 + 0x99b3]()
    //     0x55c1a4: movz            x17, #0x99b3
    //     0x55c1a8: add             lr, x0, x17
    //     0x55c1ac: ldr             lr, [x21, lr, lsl #3]
    //     0x55c1b0: blr             lr
    // 0x55c1b4: ldur            x16, [fp, #-8]
    // 0x55c1b8: ldur            lr, [fp, #-0x18]
    // 0x55c1bc: stp             lr, x16, [SP, #8]
    // 0x55c1c0: str             x0, [SP]
    // 0x55c1c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x55c1c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x55c1c8: r0 = MapOperations.multiplyScaler()
    //     0x55c1c8: bl              #0x53ac58  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::MapOperations.multiplyScaler
    // 0x55c1cc: LeaveFrame
    //     0x55c1cc: mov             SP, fp
    //     0x55c1d0: ldp             fp, lr, [SP], #0x10
    // 0x55c1d4: ret
    //     0x55c1d4: ret             
    // 0x55c1d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c1d8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c1dc: b               #0x55c168
  }
  get _ bonusGeneratorMapping(/* No info */) {
    // ** addr: 0x55c2d0, size: 0xc
    // 0x55c2d0: LoadField: r0 = r1->field_7b
    //     0x55c2d0: ldur            w0, [x1, #0x7b]
    // 0x55c2d4: DecompressPointer r0
    //     0x55c2d4: add             x0, x0, HEAP, lsl #32
    // 0x55c2d8: ret
    //     0x55c2d8: ret             
  }
  _ completeChapter(/* No info */) async {
    // ** addr: 0x694ac8, size: 0x3a4
    // 0x694ac8: EnterFrame
    //     0x694ac8: stp             fp, lr, [SP, #-0x10]!
    //     0x694acc: mov             fp, SP
    // 0x694ad0: AllocStack(0x60)
    //     0x694ad0: sub             SP, SP, #0x60
    // 0x694ad4: SetupParameters(IPlayableGameState<X0> this /* r1 => r2, fp-0x20 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x694ad4: stur            NULL, [fp, #-8]
    //     0x694ad8: stur            x1, [fp, #-0x10]
    //     0x694adc: mov             x16, x2
    //     0x694ae0: mov             x2, x1
    //     0x694ae4: mov             x1, x16
    //     0x694ae8: stur            x1, [fp, #-0x18]
    //     0x694aec: stur            x3, [fp, #-0x20]
    // 0x694af0: CheckStackOverflow
    //     0x694af0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x694af4: cmp             SP, x16
    //     0x694af8: b.ls            #0x694e40
    // 0x694afc: InitAsync() -> Future<void?>
    //     0x694afc: ldr             x0, [PP, #0x1600]  ; [pp+0x1600] TypeArguments: <void?>
    //     0x694b00: bl              #0x34b9a0  ; InitAsyncStub
    // 0x694b04: r0 = LoadStaticField(0xa80)
    //     0x694b04: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x694b08: ldr             x0, [x0, #0x1500]
    // 0x694b0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x694b10: cmp             w0, w16
    // 0x694b14: b.ne            #0x694b24
    // 0x694b18: r2 = firebaseAnalyticsEnabled
    //     0x694b18: add             x2, PP, #0x10, lsl #12  ; [pp+0x10b28] Field <::.firebaseAnalyticsEnabled>: static late (offset: 0xa80)
    //     0x694b1c: ldr             x2, [x2, #0xb28]
    // 0x694b20: r0 = InitLateStaticField()
    //     0x694b20: bl              #0x825598  ; InitLateStaticFieldStub
    // 0x694b24: r4 = const [0, 0, 0, 0, null]
    //     0x694b24: ldr             x4, [PP, #0x2958]  ; [pp+0x2958] List(5) [0, 0, 0, 0, Null]
    // 0x694b28: r0 = app()
    //     0x694b28: bl              #0x3548dc  ; [package:firebase_core/firebase_core.dart] Firebase::app
    // 0x694b2c: mov             x2, x0
    // 0x694b30: r1 = Null
    //     0x694b30: mov             x1, NULL
    // 0x694b34: r0 = FirebaseAnalytics.instanceFor()
    //     0x694b34: bl              #0x4623c4  ; [package:firebase_analytics/firebase_analytics.dart] FirebaseAnalytics::FirebaseAnalytics.instanceFor
    // 0x694b38: mov             x3, x0
    // 0x694b3c: ldur            x2, [fp, #-0x10]
    // 0x694b40: stur            x3, [fp, #-0x28]
    // 0x694b44: r0 = LoadClassIdInstr(r2)
    //     0x694b44: ldur            x0, [x2, #-1]
    //     0x694b48: ubfx            x0, x0, #0xc, #0x14
    // 0x694b4c: mov             x1, x2
    // 0x694b50: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x694b50: sub             lr, x0, #0xf3f
    //     0x694b54: ldr             lr, [x21, lr, lsl #3]
    //     0x694b58: blr             lr
    // 0x694b5c: ldur            x1, [fp, #-0x28]
    // 0x694b60: mov             x2, x0
    // 0x694b64: r0 = logLevelEnd()
    //     0x694b64: bl              #0x696258  ; [package:firebase_analytics/firebase_analytics.dart] FirebaseAnalytics::logLevelEnd
    // 0x694b68: ldur            x1, [fp, #-0x10]
    // 0x694b6c: r0 = notifyFocusLost()
    //     0x694b6c: bl              #0x534464  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::notifyFocusLost
    // 0x694b70: r2 = LoadStaticField(0xf9c)
    //     0x694b70: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x694b74: ldr             x2, [x2, #0x1f38]
    // 0x694b78: stur            x2, [fp, #-0x28]
    // 0x694b7c: cmp             w2, NULL
    // 0x694b80: b.eq            #0x694d14
    // 0x694b84: ldur            x3, [fp, #-0x10]
    // 0x694b88: r0 = LoadClassIdInstr(r3)
    //     0x694b88: ldur            x0, [x3, #-1]
    //     0x694b8c: ubfx            x0, x0, #0xc, #0x14
    // 0x694b90: mov             x1, x3
    // 0x694b94: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x694b94: sub             lr, x0, #0xf3f
    //     0x694b98: ldr             lr, [x21, lr, lsl #3]
    //     0x694b9c: blr             lr
    // 0x694ba0: stur            x0, [fp, #-0x30]
    // 0x694ba4: r0 = _getCurrentMicros()
    //     0x694ba4: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x694ba8: r1 = LoadInt32Instr(r0)
    //     0x694ba8: sbfx            x1, x0, #1, #0x1f
    //     0x694bac: tbz             w0, #0, #0x694bb4
    //     0x694bb0: ldur            x1, [x0, #7]
    // 0x694bb4: tbz             x1, #0x3f, #0x694bc0
    // 0x694bb8: r3 = 999
    //     0x694bb8: movz            x3, #0x3e7
    // 0x694bbc: b               #0x694bc4
    // 0x694bc0: r3 = 0
    //     0x694bc0: movz            x3, #0
    // 0x694bc4: ldur            x0, [fp, #-0x10]
    // 0x694bc8: r2 = 1000
    //     0x694bc8: movz            x2, #0x3e8
    // 0x694bcc: sub             x4, x1, x3
    // 0x694bd0: sdiv            x1, x4, x2
    // 0x694bd4: LoadField: r3 = r0->field_73
    //     0x694bd4: ldur            w3, [x0, #0x73]
    // 0x694bd8: DecompressPointer r3
    //     0x694bd8: add             x3, x3, HEAP, lsl #32
    // 0x694bdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x694be0: cmp             w3, w16
    // 0x694be4: b.eq            #0x694e48
    // 0x694be8: r4 = LoadInt32Instr(r3)
    //     0x694be8: sbfx            x4, x3, #1, #0x1f
    //     0x694bec: tbz             w3, #0, #0x694bf4
    //     0x694bf0: ldur            x4, [x3, #7]
    // 0x694bf4: sub             x3, x1, x4
    // 0x694bf8: stur            x3, [fp, #-0x48]
    // 0x694bfc: LoadField: r1 = r0->field_83
    //     0x694bfc: ldur            x1, [x0, #0x83]
    // 0x694c00: stur            x1, [fp, #-0x40]
    // 0x694c04: LoadField: r4 = r0->field_23
    //     0x694c04: ldur            x4, [x0, #0x23]
    // 0x694c08: stur            x4, [fp, #-0x38]
    // 0x694c0c: r0 = _getCurrentMicros()
    //     0x694c0c: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x694c10: r1 = LoadInt32Instr(r0)
    //     0x694c10: sbfx            x1, x0, #1, #0x1f
    //     0x694c14: tbz             w0, #0, #0x694c1c
    //     0x694c18: ldur            x1, [x0, #7]
    // 0x694c1c: tbz             x1, #0x3f, #0x694c28
    // 0x694c20: r2 = 999
    //     0x694c20: movz            x2, #0x3e7
    // 0x694c24: b               #0x694c2c
    // 0x694c28: r2 = 0
    //     0x694c28: movz            x2, #0
    // 0x694c2c: ldur            x6, [fp, #-0x30]
    // 0x694c30: ldur            x3, [fp, #-0x48]
    // 0x694c34: ldur            x4, [fp, #-0x40]
    // 0x694c38: ldur            x5, [fp, #-0x38]
    // 0x694c3c: r7 = 10
    //     0x694c3c: movz            x7, #0xa
    // 0x694c40: r0 = 1000
    //     0x694c40: movz            x0, #0x3e8
    // 0x694c44: sub             x8, x1, x2
    // 0x694c48: sdiv            x9, x8, x0
    // 0x694c4c: mov             x2, x7
    // 0x694c50: stur            x9, [fp, #-0x50]
    // 0x694c54: r1 = Null
    //     0x694c54: mov             x1, NULL
    // 0x694c58: r0 = AllocateArray()
    //     0x694c58: bl              #0x82746c  ; AllocateArrayStub
    // 0x694c5c: mov             x2, x0
    // 0x694c60: ldur            x0, [fp, #-0x30]
    // 0x694c64: stur            x2, [fp, #-0x58]
    // 0x694c68: StoreField: r2->field_f = r0
    //     0x694c68: stur            w0, [x2, #0xf]
    // 0x694c6c: ldur            x3, [fp, #-0x48]
    // 0x694c70: r0 = BoxInt64Instr(r3)
    //     0x694c70: sbfiz           x0, x3, #1, #0x1f
    //     0x694c74: cmp             x3, x0, asr #1
    //     0x694c78: b.eq            #0x694c84
    //     0x694c7c: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694c80: stur            x3, [x0, #7]
    // 0x694c84: StoreField: r2->field_13 = r0
    //     0x694c84: stur            w0, [x2, #0x13]
    // 0x694c88: ldur            x3, [fp, #-0x40]
    // 0x694c8c: r0 = BoxInt64Instr(r3)
    //     0x694c8c: sbfiz           x0, x3, #1, #0x1f
    //     0x694c90: cmp             x3, x0, asr #1
    //     0x694c94: b.eq            #0x694ca0
    //     0x694c98: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694c9c: stur            x3, [x0, #7]
    // 0x694ca0: ArrayStore: r2[0] = r0  ; List_4
    //     0x694ca0: stur            w0, [x2, #0x17]
    // 0x694ca4: ldur            x3, [fp, #-0x38]
    // 0x694ca8: r0 = BoxInt64Instr(r3)
    //     0x694ca8: sbfiz           x0, x3, #1, #0x1f
    //     0x694cac: cmp             x3, x0, asr #1
    //     0x694cb0: b.eq            #0x694cbc
    //     0x694cb4: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694cb8: stur            x3, [x0, #7]
    // 0x694cbc: StoreField: r2->field_1b = r0
    //     0x694cbc: stur            w0, [x2, #0x1b]
    // 0x694cc0: ldur            x3, [fp, #-0x50]
    // 0x694cc4: r0 = BoxInt64Instr(r3)
    //     0x694cc4: sbfiz           x0, x3, #1, #0x1f
    //     0x694cc8: cmp             x3, x0, asr #1
    //     0x694ccc: b.eq            #0x694cd8
    //     0x694cd0: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694cd4: stur            x3, [x0, #7]
    // 0x694cd8: StoreField: r2->field_1f = r0
    //     0x694cd8: stur            w0, [x2, #0x1f]
    // 0x694cdc: r1 = Null
    //     0x694cdc: mov             x1, NULL
    // 0x694ce0: r0 = AllocateGrowableArray()
    //     0x694ce0: bl              #0x82633c  ; AllocateGrowableArrayStub
    // 0x694ce4: mov             x1, x0
    // 0x694ce8: ldur            x0, [fp, #-0x58]
    // 0x694cec: StoreField: r1->field_f = r0
    //     0x694cec: stur            w0, [x1, #0xf]
    // 0x694cf0: r0 = 10
    //     0x694cf0: movz            x0, #0xa
    // 0x694cf4: StoreField: r1->field_b = r0
    //     0x694cf4: stur            w0, [x1, #0xb]
    // 0x694cf8: str             x1, [SP]
    // 0x694cfc: ldur            x1, [fp, #-0x28]
    // 0x694d00: r2 = "INSERT INTO completion_times (chapter_name, idle_time_ms, active_time_ms, difficulty, created) VALUES (\?, \?, \?, \?, \?)"
    //     0x694d00: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] "INSERT INTO completion_times (chapter_name, idle_time_ms, active_time_ms, difficulty, created) VALUES (\?, \?, \?, \?, \?)"
    //     0x694d04: ldr             x2, [x2, #0x358]
    // 0x694d08: r4 = const [0, 0x3, 0x1, 0x2, params, 0x2, null]
    //     0x694d08: add             x4, PP, #0x12, lsl #12  ; [pp+0x12030] List(7) [0, 0x3, 0x1, 0x2, "params", 0x2, Null]
    //     0x694d0c: ldr             x4, [x4, #0x30]
    // 0x694d10: r0 = execute()
    //     0x694d10: bl              #0x473ec4  ; [package:sql_with_isolates/src/db_isolate.dart] DbIsolate::execute
    // 0x694d14: ldur            x3, [fp, #-0x20]
    // 0x694d18: r0 = LoadStaticField(0xf7c)
    //     0x694d18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x694d1c: ldr             x0, [x0, #0x1ef8]
    // 0x694d20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x694d24: cmp             w0, w16
    // 0x694d28: b.eq            #0x694e54
    // 0x694d2c: LoadField: r1 = r0->field_13
    //     0x694d2c: ldur            w1, [x0, #0x13]
    // 0x694d30: DecompressPointer r1
    //     0x694d30: add             x1, x1, HEAP, lsl #32
    // 0x694d34: LoadField: r0 = r3->field_b
    //     0x694d34: ldur            w0, [x3, #0xb]
    // 0x694d38: DecompressPointer r0
    //     0x694d38: add             x0, x0, HEAP, lsl #32
    // 0x694d3c: mov             x2, x0
    // 0x694d40: stur            x0, [fp, #-0x28]
    // 0x694d44: r0 = containsKey()
    //     0x694d44: bl              #0x82224c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x694d48: tbz             w0, #4, #0x694d70
    // 0x694d4c: ldur            x0, [fp, #-0x20]
    // 0x694d50: LoadField: r3 = r0->field_f
    //     0x694d50: ldur            w3, [x0, #0xf]
    // 0x694d54: DecompressPointer r3
    //     0x694d54: add             x3, x3, HEAP, lsl #32
    // 0x694d58: ldur            x1, [fp, #-0x18]
    // 0x694d5c: ldur            x2, [fp, #-0x28]
    // 0x694d60: r0 = displaySlackPageAndIncrementAct()
    //     0x694d60: bl              #0x622380  ; [package:pretentious/data/StoryPointManager.dart] ::displaySlackPageAndIncrementAct
    // 0x694d64: mov             x1, x0
    // 0x694d68: stur            x1, [fp, #-0x18]
    // 0x694d6c: r0 = Await()
    //     0x694d6c: bl              #0x34b75c  ; AwaitStub
    // 0x694d70: ldur            x1, [fp, #-0x10]
    // 0x694d74: r0 = resetCurrentChapterAndUpdateUI()
    //     0x694d74: bl              #0x5a20a8  ; [package:pretentious/data/Chapters/GameStateManager.dart] ::resetCurrentChapterAndUpdateUI
    // 0x694d78: mov             x1, x0
    // 0x694d7c: stur            x1, [fp, #-0x18]
    // 0x694d80: r0 = Await()
    //     0x694d80: bl              #0x34b75c  ; AwaitStub
    // 0x694d84: r2 = LoadStaticField(0xf7c)
    //     0x694d84: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x694d88: ldr             x2, [x2, #0x1ef8]
    // 0x694d8c: ldur            x3, [fp, #-0x10]
    // 0x694d90: stur            x2, [fp, #-0x18]
    // 0x694d94: r0 = LoadClassIdInstr(r3)
    //     0x694d94: ldur            x0, [x3, #-1]
    //     0x694d98: ubfx            x0, x0, #0xc, #0x14
    // 0x694d9c: mov             x1, x3
    // 0x694da0: r0 = GDT[cid_x0 + -0xf3f]()
    //     0x694da0: sub             lr, x0, #0xf3f
    //     0x694da4: ldr             lr, [x21, lr, lsl #3]
    //     0x694da8: blr             lr
    // 0x694dac: stur            x0, [fp, #-0x20]
    // 0x694db0: r0 = _getCurrentMicros()
    //     0x694db0: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x694db4: r1 = LoadInt32Instr(r0)
    //     0x694db4: sbfx            x1, x0, #1, #0x1f
    //     0x694db8: tbz             w0, #0, #0x694dc0
    //     0x694dbc: ldur            x1, [x0, #7]
    // 0x694dc0: tbz             x1, #0x3f, #0x694dcc
    // 0x694dc4: r3 = 999
    //     0x694dc4: movz            x3, #0x3e7
    // 0x694dc8: b               #0x694dd0
    // 0x694dcc: r3 = 0
    //     0x694dcc: movz            x3, #0
    // 0x694dd0: ldur            x0, [fp, #-0x10]
    // 0x694dd4: r2 = 1000
    //     0x694dd4: movz            x2, #0x3e8
    // 0x694dd8: sub             x4, x1, x3
    // 0x694ddc: sdiv            x1, x4, x2
    // 0x694de0: LoadField: r2 = r0->field_73
    //     0x694de0: ldur            w2, [x0, #0x73]
    // 0x694de4: DecompressPointer r2
    //     0x694de4: add             x2, x2, HEAP, lsl #32
    // 0x694de8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x694dec: cmp             w2, w16
    // 0x694df0: b.eq            #0x694e60
    // 0x694df4: r3 = LoadInt32Instr(r2)
    //     0x694df4: sbfx            x3, x2, #1, #0x1f
    //     0x694df8: tbz             w2, #0, #0x694e00
    //     0x694dfc: ldur            x3, [x2, #7]
    // 0x694e00: sub             x2, x1, x3
    // 0x694e04: LoadField: r5 = r0->field_23
    //     0x694e04: ldur            x5, [x0, #0x23]
    // 0x694e08: r0 = BoxInt64Instr(r2)
    //     0x694e08: sbfiz           x0, x2, #1, #0x1f
    //     0x694e0c: cmp             x2, x0, asr #1
    //     0x694e10: b.eq            #0x694e1c
    //     0x694e14: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x694e18: stur            x2, [x0, #7]
    // 0x694e1c: ldur            x1, [fp, #-0x18]
    // 0x694e20: ldur            x2, [fp, #-0x20]
    // 0x694e24: mov             x3, x0
    // 0x694e28: r0 = addCompletionToken()
    //     0x694e28: bl              #0x694e6c  ; [package:pretentious/data/CoreData.dart] CoreData::addCompletionToken
    // 0x694e2c: mov             x1, x0
    // 0x694e30: stur            x1, [fp, #-0x10]
    // 0x694e34: r0 = Await()
    //     0x694e34: bl              #0x34b75c  ; AwaitStub
    // 0x694e38: r0 = Null
    //     0x694e38: mov             x0, NULL
    // 0x694e3c: r0 = ReturnAsyncNotFuture()
    //     0x694e3c: b               #0x34b288  ; ReturnAsyncNotFutureStub
    // 0x694e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694e40: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694e44: b               #0x694afc
    // 0x694e48: r9 = startMillisecondsSinceEpoch
    //     0x694e48: add             x9, PP, #0x16, lsl #12  ; [pp+0x16c10] Field <IPlayableGameState.startMillisecondsSinceEpoch>: late (offset: 0x74)
    //     0x694e4c: ldr             x9, [x9, #0xc10]
    // 0x694e50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x694e50: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x694e54: r9 = coreData
    //     0x694e54: add             x9, PP, #0xe, lsl #12  ; [pp+0xe530] Field <::.coreData>: static late (offset: 0xf7c)
    //     0x694e58: ldr             x9, [x9, #0x530]
    // 0x694e5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x694e5c: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x694e60: r9 = startMillisecondsSinceEpoch
    //     0x694e60: add             x9, PP, #0x16, lsl #12  ; [pp+0x16c10] Field <IPlayableGameState.startMillisecondsSinceEpoch>: late (offset: 0x74)
    //     0x694e64: ldr             x9, [x9, #0xc10]
    // 0x694e68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x694e68: bl              #0x827e90  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Tuple2<String, String?> makeGeneratorSubtitleText(dynamic, Object?, Object?, num, CustomNum?) {
    // ** addr: 0x69637c, size: 0x48
    // 0x69637c: EnterFrame
    //     0x69637c: stp             fp, lr, [SP, #-0x10]!
    //     0x696380: mov             fp, SP
    // 0x696384: ldr             x0, [fp, #0x30]
    // 0x696388: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x696388: ldur            w1, [x0, #0x17]
    // 0x69638c: DecompressPointer r1
    //     0x69638c: add             x1, x1, HEAP, lsl #32
    // 0x696390: CheckStackOverflow
    //     0x696390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x696394: cmp             SP, x16
    //     0x696398: b.ls            #0x6963bc
    // 0x69639c: ldr             x2, [fp, #0x28]
    // 0x6963a0: ldr             x3, [fp, #0x20]
    // 0x6963a4: ldr             x5, [fp, #0x18]
    // 0x6963a8: ldr             x6, [fp, #0x10]
    // 0x6963ac: r0 = makeGeneratorSubtitleText()
    //     0x6963ac: bl              #0x6963c4  ; [package:pretentious/data/Chapters/IPlayableGameState.dart] IPlayableGameState::makeGeneratorSubtitleText
    // 0x6963b0: LeaveFrame
    //     0x6963b0: mov             SP, fp
    //     0x6963b4: ldp             fp, lr, [SP], #0x10
    // 0x6963b8: ret
    //     0x6963b8: ret             
    // 0x6963bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6963bc: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6963c0: b               #0x69639c
  }
  _ makeGeneratorSubtitleText(/* No info */) {
    // ** addr: 0x6963c4, size: 0x60c
    // 0x6963c4: EnterFrame
    //     0x6963c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6963c8: mov             fp, SP
    // 0x6963cc: AllocStack(0x58)
    //     0x6963cc: sub             SP, SP, #0x58
    // 0x6963d0: SetupParameters(IPlayableGameState<X0> this /* r1 => r7, fp-0x10 */, dynamic _ /* r2 => r6, fp-0x18 */, dynamic _ /* r3 => r4, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */, dynamic _ /* r6 => r3, fp-0x30 */)
    //     0x6963d0: mov             x7, x1
    //     0x6963d4: mov             x4, x3
    //     0x6963d8: stur            x3, [fp, #-0x20]
    //     0x6963dc: mov             x3, x6
    //     0x6963e0: stur            x6, [fp, #-0x30]
    //     0x6963e4: mov             x6, x2
    //     0x6963e8: stur            x1, [fp, #-0x10]
    //     0x6963ec: stur            x2, [fp, #-0x18]
    //     0x6963f0: stur            x5, [fp, #-0x28]
    // 0x6963f4: CheckStackOverflow
    //     0x6963f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6963f8: cmp             SP, x16
    //     0x6963fc: b.ls            #0x69699c
    // 0x696400: LoadField: r8 = r7->field_7
    //     0x696400: ldur            w8, [x7, #7]
    // 0x696404: DecompressPointer r8
    //     0x696404: add             x8, x8, HEAP, lsl #32
    // 0x696408: mov             x0, x6
    // 0x69640c: mov             x2, x8
    // 0x696410: stur            x8, [fp, #-8]
    // 0x696414: r1 = Null
    //     0x696414: mov             x1, NULL
    // 0x696418: r8 = Tuple2<X0, CustomNum>
    //     0x696418: add             x8, PP, #0x26, lsl #12  ; [pp+0x26560] Type: Tuple2<X0, CustomNum>
    //     0x69641c: ldr             x8, [x8, #0x560]
    // 0x696420: LoadField: r9 = r8->field_7
    //     0x696420: ldur            x9, [x8, #7]
    // 0x696424: r3 = Null
    //     0x696424: add             x3, PP, #0x26, lsl #12  ; [pp+0x26568] Null
    //     0x696428: ldr             x3, [x3, #0x568]
    // 0x69642c: blr             x9
    // 0x696430: ldur            x0, [fp, #-0x20]
    // 0x696434: ldur            x2, [fp, #-8]
    // 0x696438: r1 = Null
    //     0x696438: mov             x1, NULL
    // 0x69643c: r8 = Map<X0, CustomNum>
    //     0x69643c: add             x8, PP, #0x16, lsl #12  ; [pp+0x16c60] Type: Map<X0, CustomNum>
    //     0x696440: ldr             x8, [x8, #0xc60]
    // 0x696444: LoadField: r9 = r8->field_7
    //     0x696444: ldur            x9, [x8, #7]
    // 0x696448: r3 = Null
    //     0x696448: add             x3, PP, #0x26, lsl #12  ; [pp+0x26578] Null
    //     0x69644c: ldr             x3, [x3, #0x578]
    // 0x696450: blr             x9
    // 0x696454: ldur            x2, [fp, #-0x20]
    // 0x696458: r0 = LoadClassIdInstr(r2)
    //     0x696458: ldur            x0, [x2, #-1]
    //     0x69645c: ubfx            x0, x0, #0xc, #0x14
    // 0x696460: mov             x1, x2
    // 0x696464: r0 = GDT[cid_x0 + -0xb1d]()
    //     0x696464: sub             lr, x0, #0xb1d
    //     0x696468: ldr             lr, [x21, lr, lsl #3]
    //     0x69646c: blr             lr
    // 0x696470: tbnz            w0, #4, #0x6964a0
    // 0x696474: r0 = current()
    //     0x696474: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x696478: mov             x2, x0
    // 0x69647c: r1 = "Yields is empty!"
    //     0x69647c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26588] "Yields is empty!"
    //     0x696480: ldr             x1, [x1, #0x588]
    // 0x696484: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x696484: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x696488: r0 = crashlyticsRecordError()
    //     0x696488: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x69648c: r0 = Instance_Tuple2
    //     0x69648c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26590] Obj!Tuple2<String, String>@826491
    //     0x696490: ldr             x0, [x0, #0x590]
    // 0x696494: LeaveFrame
    //     0x696494: mov             SP, fp
    //     0x696498: ldp             fp, lr, [SP], #0x10
    // 0x69649c: ret
    //     0x69649c: ret             
    // 0x6964a0: ldur            x2, [fp, #-0x20]
    // 0x6964a4: r0 = LoadClassIdInstr(r2)
    //     0x6964a4: ldur            x0, [x2, #-1]
    //     0x6964a8: ubfx            x0, x0, #0xc, #0x14
    // 0x6964ac: mov             x1, x2
    // 0x6964b0: r0 = GDT[cid_x0 + -0xcb]()
    //     0x6964b0: sub             lr, x0, #0xcb
    //     0x6964b4: ldr             lr, [x21, lr, lsl #3]
    //     0x6964b8: blr             lr
    // 0x6964bc: r1 = LoadClassIdInstr(r0)
    //     0x6964bc: ldur            x1, [x0, #-1]
    //     0x6964c0: ubfx            x1, x1, #0xc, #0x14
    // 0x6964c4: mov             x16, x0
    // 0x6964c8: mov             x0, x1
    // 0x6964cc: mov             x1, x16
    // 0x6964d0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6964d0: ldr             x4, [PP, #0x528]  ; [pp+0x528] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6964d4: r0 = GDT[cid_x0 + 0x8751]()
    //     0x6964d4: movz            x17, #0x8751
    //     0x6964d8: add             lr, x0, x17
    //     0x6964dc: ldr             lr, [x21, lr, lsl #3]
    //     0x6964e0: blr             lr
    // 0x6964e4: stur            x0, [fp, #-0x38]
    // 0x6964e8: r0 = _getCurrentMicros()
    //     0x6964e8: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x6964ec: r1 = LoadInt32Instr(r0)
    //     0x6964ec: sbfx            x1, x0, #1, #0x1f
    //     0x6964f0: tbz             w0, #0, #0x6964f8
    //     0x6964f4: ldur            x1, [x0, #7]
    // 0x6964f8: tbz             x1, #0x3f, #0x696504
    // 0x6964fc: r5 = 999
    //     0x6964fc: movz            x5, #0x3e7
    // 0x696500: b               #0x696508
    // 0x696504: r5 = 0
    //     0x696504: movz            x5, #0
    // 0x696508: ldur            x4, [fp, #-0x20]
    // 0x69650c: ldur            x2, [fp, #-0x38]
    // 0x696510: r3 = 1000
    //     0x696510: movz            x3, #0x3e8
    // 0x696514: r0 = 2000
    //     0x696514: movz            x0, #0x7d0
    // 0x696518: sub             x6, x1, x5
    // 0x69651c: sdiv            x1, x6, x3
    // 0x696520: sdiv            x3, x1, x0
    // 0x696524: LoadField: r0 = r2->field_b
    //     0x696524: ldur            w0, [x2, #0xb]
    // 0x696528: r1 = LoadInt32Instr(r0)
    //     0x696528: sbfx            x1, x0, #1, #0x1f
    // 0x69652c: cbz             x1, #0x6969a4
    // 0x696530: sdiv            x0, x3, x1
    // 0x696534: msub            x5, x0, x1, x3
    // 0x696538: cmp             x5, xzr
    // 0x69653c: b.lt            #0x6969c0
    // 0x696540: mov             x0, x1
    // 0x696544: mov             x1, x5
    // 0x696548: cmp             x1, x0
    // 0x69654c: b.hs            #0x6969c8
    // 0x696550: LoadField: r0 = r2->field_f
    //     0x696550: ldur            w0, [x2, #0xf]
    // 0x696554: DecompressPointer r0
    //     0x696554: add             x0, x0, HEAP, lsl #32
    // 0x696558: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x696558: add             x16, x0, x5, lsl #2
    //     0x69655c: ldur            w6, [x16, #0xf]
    // 0x696560: DecompressPointer r6
    //     0x696560: add             x6, x6, HEAP, lsl #32
    // 0x696564: ldur            x2, [fp, #-8]
    // 0x696568: stur            x6, [fp, #-0x38]
    // 0x69656c: r1 = Null
    //     0x69656c: mov             x1, NULL
    // 0x696570: r3 = <X0, CustomNum>
    //     0x696570: add             x3, PP, #0x10, lsl #12  ; [pp+0x10b10] TypeArguments: <X0, CustomNum>
    //     0x696574: ldr             x3, [x3, #0xb10]
    // 0x696578: r30 = InstantiateTypeArgumentsStub
    //     0x696578: ldr             lr, [PP, #0x398]  ; [pp+0x398] Stub: InstantiateTypeArguments (0x310fc4)
    // 0x69657c: LoadField: r30 = r30->field_7
    //     0x69657c: ldur            lr, [lr, #7]
    // 0x696580: blr             lr
    // 0x696584: mov             x3, x0
    // 0x696588: ldur            x1, [fp, #-0x20]
    // 0x69658c: stur            x3, [fp, #-0x40]
    // 0x696590: r0 = LoadClassIdInstr(r1)
    //     0x696590: ldur            x0, [x1, #-1]
    //     0x696594: ubfx            x0, x0, #0xc, #0x14
    // 0x696598: ldur            x2, [fp, #-0x38]
    // 0x69659c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x69659c: sub             lr, x0, #1, lsl #12
    //     0x6965a0: ldr             lr, [x21, lr, lsl #3]
    //     0x6965a4: blr             lr
    // 0x6965a8: stur            x0, [fp, #-0x20]
    // 0x6965ac: cmp             w0, NULL
    // 0x6965b0: b.eq            #0x6969cc
    // 0x6965b4: ldur            x1, [fp, #-0x40]
    // 0x6965b8: r0 = Tuple2()
    //     0x6965b8: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x6965bc: mov             x2, x0
    // 0x6965c0: ldur            x0, [fp, #-0x38]
    // 0x6965c4: stur            x2, [fp, #-0x40]
    // 0x6965c8: StoreField: r2->field_b = r0
    //     0x6965c8: stur            w0, [x2, #0xb]
    // 0x6965cc: ldur            x0, [fp, #-0x20]
    // 0x6965d0: StoreField: r2->field_f = r0
    //     0x6965d0: stur            w0, [x2, #0xf]
    // 0x6965d4: r1 = "Show All Yields"
    //     0x6965d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26598] "Show All Yields"
    //     0x6965d8: ldr             x1, [x1, #0x598]
    // 0x6965dc: r0 = prefsGetBool()
    //     0x6965dc: bl              #0x4864a0  ; [package:custom_tools/SharedPrefsWrapper.dart] ::prefsGetBool
    // 0x6965e0: cmp             w0, NULL
    // 0x6965e4: b.ne            #0x6965f4
    // 0x6965e8: r1 = "default_show_all_yields"
    //     0x6965e8: add             x1, PP, #0x12, lsl #12  ; [pp+0x129b0] "default_show_all_yields"
    //     0x6965ec: ldr             x1, [x1, #0x9b0]
    // 0x6965f0: r0 = remoteConfigGetBool()
    //     0x6965f0: bl              #0x44fab4  ; [package:custom_tools/RemoteConfigWrapper.dart] ::remoteConfigGetBool
    // 0x6965f4: cmp             w0, NULL
    // 0x6965f8: b.eq            #0x696600
    // 0x6965fc: tbnz            w0, #4, #0x696708
    // 0x696600: ldur            x0, [fp, #-0x30]
    // 0x696604: cmp             w0, NULL
    // 0x696608: b.ne            #0x6966bc
    // 0x69660c: r16 = 2
    //     0x69660c: movz            x16, #0x2
    // 0x696610: ldur            lr, [fp, #-0x28]
    // 0x696614: stp             lr, x16, [SP]
    // 0x696618: r0 = >()
    //     0x696618: bl              #0x824e2c  ; [dart:core] _IntegerImplementation::>
    // 0x69661c: tbnz            w0, #4, #0x696628
    // 0x696620: r0 = 2
    //     0x696620: movz            x0, #0x2
    // 0x696624: b               #0x6966a0
    // 0x696628: r16 = 2
    //     0x696628: movz            x16, #0x2
    // 0x69662c: ldur            lr, [fp, #-0x28]
    // 0x696630: stp             lr, x16, [SP]
    // 0x696634: r0 = <()
    //     0x696634: bl              #0x81d338  ; [dart:core] _IntegerImplementation::<
    // 0x696638: tbnz            w0, #4, #0x696644
    // 0x69663c: ldur            x0, [fp, #-0x28]
    // 0x696640: b               #0x6966a0
    // 0x696644: ldur            x1, [fp, #-0x28]
    // 0x696648: r0 = 60
    //     0x696648: movz            x0, #0x3c
    // 0x69664c: branchIfSmi(r1, 0x696658)
    //     0x69664c: tbz             w1, #0, #0x696658
    // 0x696650: r0 = LoadClassIdInstr(r1)
    //     0x696650: ldur            x0, [x1, #-1]
    //     0x696654: ubfx            x0, x0, #0xc, #0x14
    // 0x696658: cmp             x0, #0x3e
    // 0x69665c: b.ne            #0x69667c
    // 0x696660: LoadField: d0 = r1->field_7
    //     0x696660: ldur            d0, [x1, #7]
    // 0x696664: fcmp            d0, d0
    // 0x696668: b.vc            #0x696674
    // 0x69666c: mov             x0, x1
    // 0x696670: b               #0x6966a0
    // 0x696674: r0 = 2
    //     0x696674: movz            x0, #0x2
    // 0x696678: b               #0x6966a0
    // 0x69667c: r0 = 60
    //     0x69667c: movz            x0, #0x3c
    // 0x696680: branchIfSmi(r1, 0x69668c)
    //     0x696680: tbz             w1, #0, #0x69668c
    // 0x696684: r0 = LoadClassIdInstr(r1)
    //     0x696684: ldur            x0, [x1, #-1]
    //     0x696688: ubfx            x0, x0, #0xc, #0x14
    // 0x69668c: stp             xzr, x1, [SP]
    // 0x696690: mov             lr, x0
    // 0x696694: ldr             lr, [x21, lr, lsl #3]
    // 0x696698: blr             lr
    // 0x69669c: r0 = 2
    //     0x69669c: movz            x0, #0x2
    // 0x6966a0: ldur            x16, [fp, #-8]
    // 0x6966a4: ldur            lr, [fp, #-0x40]
    // 0x6966a8: stp             lr, x16, [SP, #8]
    // 0x6966ac: str             x0, [SP]
    // 0x6966b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6966b0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6966b4: r0 = TupleOperations.multiply()
    //     0x6966b4: bl              #0x53a1dc  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::TupleOperations.multiply
    // 0x6966b8: b               #0x696700
    // 0x6966bc: ldur            x1, [fp, #-0x28]
    // 0x6966c0: mov             x2, x1
    // 0x6966c4: r1 = Null
    //     0x6966c4: mov             x1, NULL
    // 0x6966c8: r0 = CustomNum()
    //     0x6966c8: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6966cc: ldur            x1, [fp, #-0x30]
    // 0x6966d0: mov             x2, x0
    // 0x6966d4: r0 = add()
    //     0x6966d4: bl              #0x4f974c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::add
    // 0x6966d8: mov             x1, x0
    // 0x6966dc: r2 = Instance_CustomNum
    //     0x6966dc: add             x2, PP, #0xe, lsl #12  ; [pp+0xea70] Obj!CustomNum@828b11
    //     0x6966e0: ldr             x2, [x2, #0xa70]
    // 0x6966e4: r0 = max()
    //     0x6966e4: bl              #0x54f61c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::max
    // 0x6966e8: ldur            x16, [fp, #-8]
    // 0x6966ec: ldur            lr, [fp, #-0x40]
    // 0x6966f0: stp             lr, x16, [SP, #8]
    // 0x6966f4: str             x0, [SP]
    // 0x6966f8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6966f8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6966fc: r0 = TupleOperations.multiplyCustomNum()
    //     0x6966fc: bl              #0x53a9b8  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::TupleOperations.multiplyCustomNum
    // 0x696700: mov             x4, x0
    // 0x696704: b               #0x69670c
    // 0x696708: ldur            x4, [fp, #-0x40]
    // 0x69670c: ldur            x3, [fp, #-0x10]
    // 0x696710: ldur            x0, [fp, #-0x18]
    // 0x696714: stur            x4, [fp, #-0x20]
    // 0x696718: LoadField: r5 = r0->field_f
    //     0x696718: ldur            w5, [x0, #0xf]
    // 0x69671c: DecompressPointer r5
    //     0x69671c: add             x5, x5, HEAP, lsl #32
    // 0x696720: stur            x5, [fp, #-8]
    // 0x696724: r1 = Null
    //     0x696724: mov             x1, NULL
    // 0x696728: r2 = 18
    //     0x696728: movz            x2, #0x12
    // 0x69672c: r0 = AllocateArray()
    //     0x69672c: bl              #0x82746c  ; AllocateArrayStub
    // 0x696730: mov             x2, x0
    // 0x696734: ldur            x1, [fp, #-8]
    // 0x696738: stur            x2, [fp, #-0x30]
    // 0x69673c: StoreField: r2->field_f = r1
    //     0x69673c: stur            w1, [x2, #0xf]
    // 0x696740: r16 = " "
    //     0x696740: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x696744: StoreField: r2->field_13 = r16
    //     0x696744: stur            w16, [x2, #0x13]
    // 0x696748: ldur            x0, [fp, #-0x18]
    // 0x69674c: LoadField: r3 = r0->field_b
    //     0x69674c: ldur            w3, [x0, #0xb]
    // 0x696750: DecompressPointer r3
    //     0x696750: add             x3, x3, HEAP, lsl #32
    // 0x696754: ldur            x4, [fp, #-0x10]
    // 0x696758: stur            x3, [fp, #-0x28]
    // 0x69675c: LoadField: r0 = r4->field_5b
    //     0x69675c: ldur            w0, [x4, #0x5b]
    // 0x696760: DecompressPointer r0
    //     0x696760: add             x0, x0, HEAP, lsl #32
    // 0x696764: stp             x3, x0, [SP]
    // 0x696768: ClosureCall
    //     0x696768: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x69676c: ldur            x2, [x0, #0x1f]
    //     0x696770: blr             x2
    // 0x696774: ldur            x1, [fp, #-0x30]
    // 0x696778: ArrayStore: r1[2] = r0  ; List_4
    //     0x696778: add             x25, x1, #0x17
    //     0x69677c: str             w0, [x25]
    //     0x696780: tbz             w0, #0, #0x69679c
    //     0x696784: ldurb           w16, [x1, #-1]
    //     0x696788: ldurb           w17, [x0, #-1]
    //     0x69678c: and             x16, x17, x16, lsr #2
    //     0x696790: tst             x16, HEAP, lsr #32
    //     0x696794: b.eq            #0x69679c
    //     0x696798: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69679c: ldur            x2, [fp, #-0x30]
    // 0x6967a0: r16 = " "
    //     0x6967a0: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x6967a4: StoreField: r2->field_1b = r16
    //     0x6967a4: stur            w16, [x2, #0x1b]
    // 0x6967a8: r16 = "∝"
    //     0x6967a8: add             x16, PP, #0x26, lsl #12  ; [pp+0x265a0] "∝"
    //     0x6967ac: ldr             x16, [x16, #0x5a0]
    // 0x6967b0: StoreField: r2->field_1f = r16
    //     0x6967b0: stur            w16, [x2, #0x1f]
    // 0x6967b4: r16 = " "
    //     0x6967b4: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x6967b8: StoreField: r2->field_23 = r16
    //     0x6967b8: stur            w16, [x2, #0x23]
    // 0x6967bc: ldur            x3, [fp, #-0x20]
    // 0x6967c0: LoadField: r4 = r3->field_f
    //     0x6967c0: ldur            w4, [x3, #0xf]
    // 0x6967c4: DecompressPointer r4
    //     0x6967c4: add             x4, x4, HEAP, lsl #32
    // 0x6967c8: mov             x1, x2
    // 0x6967cc: mov             x0, x4
    // 0x6967d0: stur            x4, [fp, #-0x38]
    // 0x6967d4: ArrayStore: r1[6] = r0  ; List_4
    //     0x6967d4: add             x25, x1, #0x27
    //     0x6967d8: str             w0, [x25]
    //     0x6967dc: tbz             w0, #0, #0x6967f8
    //     0x6967e0: ldurb           w16, [x1, #-1]
    //     0x6967e4: ldurb           w17, [x0, #-1]
    //     0x6967e8: and             x16, x17, x16, lsr #2
    //     0x6967ec: tst             x16, HEAP, lsr #32
    //     0x6967f0: b.eq            #0x6967f8
    //     0x6967f4: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6967f8: r16 = " "
    //     0x6967f8: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x6967fc: StoreField: r2->field_2b = r16
    //     0x6967fc: stur            w16, [x2, #0x2b]
    // 0x696800: LoadField: r1 = r3->field_b
    //     0x696800: ldur            w1, [x3, #0xb]
    // 0x696804: DecompressPointer r1
    //     0x696804: add             x1, x1, HEAP, lsl #32
    // 0x696808: ldur            x3, [fp, #-0x10]
    // 0x69680c: stur            x1, [fp, #-0x18]
    // 0x696810: LoadField: r0 = r3->field_5b
    //     0x696810: ldur            w0, [x3, #0x5b]
    // 0x696814: DecompressPointer r0
    //     0x696814: add             x0, x0, HEAP, lsl #32
    // 0x696818: stp             x1, x0, [SP]
    // 0x69681c: ClosureCall
    //     0x69681c: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x696820: ldur            x2, [x0, #0x1f]
    //     0x696824: blr             x2
    // 0x696828: ldur            x1, [fp, #-0x30]
    // 0x69682c: ArrayStore: r1[8] = r0  ; List_4
    //     0x69682c: add             x25, x1, #0x2f
    //     0x696830: str             w0, [x25]
    //     0x696834: tbz             w0, #0, #0x696850
    //     0x696838: ldurb           w16, [x1, #-1]
    //     0x69683c: ldurb           w17, [x0, #-1]
    //     0x696840: and             x16, x17, x16, lsr #2
    //     0x696844: tst             x16, HEAP, lsr #32
    //     0x696848: b.eq            #0x696850
    //     0x69684c: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x696850: ldur            x16, [fp, #-0x30]
    // 0x696854: str             x16, [SP]
    // 0x696858: r0 = _interpolate()
    //     0x696858: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x69685c: r1 = Null
    //     0x69685c: mov             x1, NULL
    // 0x696860: r2 = 16
    //     0x696860: movz            x2, #0x10
    // 0x696864: stur            x0, [fp, #-0x20]
    // 0x696868: r0 = AllocateArray()
    //     0x696868: bl              #0x82746c  ; AllocateArrayStub
    // 0x69686c: mov             x1, x0
    // 0x696870: ldur            x0, [fp, #-8]
    // 0x696874: stur            x1, [fp, #-0x30]
    // 0x696878: StoreField: r1->field_f = r0
    //     0x696878: stur            w0, [x1, #0xf]
    // 0x69687c: r16 = " "
    //     0x69687c: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x696880: StoreField: r1->field_13 = r16
    //     0x696880: stur            w16, [x1, #0x13]
    // 0x696884: ldur            x2, [fp, #-0x10]
    // 0x696888: LoadField: r0 = r2->field_5b
    //     0x696888: ldur            w0, [x2, #0x5b]
    // 0x69688c: DecompressPointer r0
    //     0x69688c: add             x0, x0, HEAP, lsl #32
    // 0x696890: ldur            x16, [fp, #-0x28]
    // 0x696894: stp             x16, x0, [SP]
    // 0x696898: ClosureCall
    //     0x696898: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x69689c: ldur            x2, [x0, #0x1f]
    //     0x6968a0: blr             x2
    // 0x6968a4: ldur            x1, [fp, #-0x30]
    // 0x6968a8: ArrayStore: r1[2] = r0  ; List_4
    //     0x6968a8: add             x25, x1, #0x17
    //     0x6968ac: str             w0, [x25]
    //     0x6968b0: tbz             w0, #0, #0x6968cc
    //     0x6968b4: ldurb           w16, [x1, #-1]
    //     0x6968b8: ldurb           w17, [x0, #-1]
    //     0x6968bc: and             x16, x17, x16, lsr #2
    //     0x6968c0: tst             x16, HEAP, lsr #32
    //     0x6968c4: b.eq            #0x6968cc
    //     0x6968c8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x6968cc: ldur            x2, [fp, #-0x30]
    // 0x6968d0: r16 = " cost, "
    //     0x6968d0: add             x16, PP, #0x26, lsl #12  ; [pp+0x265a8] " cost, "
    //     0x6968d4: ldr             x16, [x16, #0x5a8]
    // 0x6968d8: StoreField: r2->field_1b = r16
    //     0x6968d8: stur            w16, [x2, #0x1b]
    // 0x6968dc: mov             x1, x2
    // 0x6968e0: ldur            x0, [fp, #-0x38]
    // 0x6968e4: ArrayStore: r1[4] = r0  ; List_4
    //     0x6968e4: add             x25, x1, #0x1f
    //     0x6968e8: str             w0, [x25]
    //     0x6968ec: tbz             w0, #0, #0x696908
    //     0x6968f0: ldurb           w16, [x1, #-1]
    //     0x6968f4: ldurb           w17, [x0, #-1]
    //     0x6968f8: and             x16, x17, x16, lsr #2
    //     0x6968fc: tst             x16, HEAP, lsr #32
    //     0x696900: b.eq            #0x696908
    //     0x696904: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x696908: r16 = " "
    //     0x696908: ldr             x16, [PP, #0x1ab0]  ; [pp+0x1ab0] " "
    // 0x69690c: StoreField: r2->field_23 = r16
    //     0x69690c: stur            w16, [x2, #0x23]
    // 0x696910: ldur            x0, [fp, #-0x10]
    // 0x696914: LoadField: r1 = r0->field_5b
    //     0x696914: ldur            w1, [x0, #0x5b]
    // 0x696918: DecompressPointer r1
    //     0x696918: add             x1, x1, HEAP, lsl #32
    // 0x69691c: ldur            x16, [fp, #-0x18]
    // 0x696920: stp             x16, x1, [SP]
    // 0x696924: mov             x0, x1
    // 0x696928: ClosureCall
    //     0x696928: ldr             x4, [PP, #0x130]  ; [pp+0x130] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x69692c: ldur            x2, [x0, #0x1f]
    //     0x696930: blr             x2
    // 0x696934: ldur            x1, [fp, #-0x30]
    // 0x696938: ArrayStore: r1[6] = r0  ; List_4
    //     0x696938: add             x25, x1, #0x27
    //     0x69693c: str             w0, [x25]
    //     0x696940: tbz             w0, #0, #0x69695c
    //     0x696944: ldurb           w16, [x1, #-1]
    //     0x696948: ldurb           w17, [x0, #-1]
    //     0x69694c: and             x16, x17, x16, lsr #2
    //     0x696950: tst             x16, HEAP, lsr #32
    //     0x696954: b.eq            #0x69695c
    //     0x696958: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x69695c: ldur            x0, [fp, #-0x30]
    // 0x696960: r16 = " per second yields"
    //     0x696960: add             x16, PP, #0x26, lsl #12  ; [pp+0x265b0] " per second yields"
    //     0x696964: ldr             x16, [x16, #0x5b0]
    // 0x696968: StoreField: r0->field_2b = r16
    //     0x696968: stur            w16, [x0, #0x2b]
    // 0x69696c: str             x0, [SP]
    // 0x696970: r0 = _interpolate()
    //     0x696970: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x696974: r1 = <String, String>
    //     0x696974: ldr             x1, [PP, #0x2c48]  ; [pp+0x2c48] TypeArguments: <String, String>
    // 0x696978: stur            x0, [fp, #-8]
    // 0x69697c: r0 = Tuple2()
    //     0x69697c: bl              #0x3da10c  ; AllocateTuple2Stub -> Tuple2<X0, X1> (size=0x14)
    // 0x696980: ldur            x1, [fp, #-0x20]
    // 0x696984: StoreField: r0->field_b = r1
    //     0x696984: stur            w1, [x0, #0xb]
    // 0x696988: ldur            x1, [fp, #-8]
    // 0x69698c: StoreField: r0->field_f = r1
    //     0x69698c: stur            w1, [x0, #0xf]
    // 0x696990: LeaveFrame
    //     0x696990: mov             SP, fp
    //     0x696994: ldp             fp, lr, [SP], #0x10
    // 0x696998: ret
    //     0x696998: ret             
    // 0x69699c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69699c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6969a0: b               #0x696400
    // 0x6969a4: stp             x3, x4, [SP, #-0x10]!
    // 0x6969a8: stp             x1, x2, [SP, #-0x10]!
    // 0x6969ac: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x6969b0: r4 = 0
    //     0x6969b0: movz            x4, #0
    // 0x6969b4: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x6969b8: blr             lr
    // 0x6969bc: brk             #0
    // 0x6969c0: add             x5, x5, x1
    // 0x6969c4: b               #0x696540
    // 0x6969c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6969c8: bl              #0x827aa8  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6969cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6969cc: bl              #0x827c08  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ reset(/* No info */) {
    // ** addr: 0x81b0a0, size: 0x1f0
    // 0x81b0a0: EnterFrame
    //     0x81b0a0: stp             fp, lr, [SP, #-0x10]!
    //     0x81b0a4: mov             fp, SP
    // 0x81b0a8: AllocStack(0x10)
    //     0x81b0a8: sub             SP, SP, #0x10
    // 0x81b0ac: SetupParameters(IPlayableGameState<X0> this /* r1 => r0, fp-0x10 */, {dynamic save = true /* r2, fp-0x8 */})
    //     0x81b0ac: mov             x0, x1
    //     0x81b0b0: stur            x1, [fp, #-0x10]
    //     0x81b0b4: ldur            w1, [x4, #0x13]
    //     0x81b0b8: ldur            w2, [x4, #0x1f]
    //     0x81b0bc: add             x2, x2, HEAP, lsl #32
    //     0x81b0c0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f2d8] "save"
    //     0x81b0c4: ldr             x16, [x16, #0x2d8]
    //     0x81b0c8: cmp             w2, w16
    //     0x81b0cc: b.ne            #0x81b0ec
    //     0x81b0d0: ldur            w2, [x4, #0x23]
    //     0x81b0d4: add             x2, x2, HEAP, lsl #32
    //     0x81b0d8: sub             w3, w1, w2
    //     0x81b0dc: add             x1, fp, w3, sxtw #2
    //     0x81b0e0: ldr             x1, [x1, #8]
    //     0x81b0e4: mov             x2, x1
    //     0x81b0e8: b               #0x81b0f0
    //     0x81b0ec: add             x2, NULL, #0x20  ; true
    //     0x81b0f0: stur            x2, [fp, #-8]
    // 0x81b0f4: CheckStackOverflow
    //     0x81b0f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x81b0f8: cmp             SP, x16
    //     0x81b0fc: b.ls            #0x81b288
    // 0x81b100: LoadField: r1 = r0->field_37
    //     0x81b100: ldur            w1, [x0, #0x37]
    // 0x81b104: DecompressPointer r1
    //     0x81b104: add             x1, x1, HEAP, lsl #32
    // 0x81b108: r0 = clear()
    //     0x81b108: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b10c: ldur            x0, [fp, #-0x10]
    // 0x81b110: LoadField: r1 = r0->field_43
    //     0x81b110: ldur            w1, [x0, #0x43]
    // 0x81b114: DecompressPointer r1
    //     0x81b114: add             x1, x1, HEAP, lsl #32
    // 0x81b118: r0 = clear()
    //     0x81b118: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b11c: ldur            x0, [fp, #-0x10]
    // 0x81b120: LoadField: r1 = r0->field_3f
    //     0x81b120: ldur            w1, [x0, #0x3f]
    // 0x81b124: DecompressPointer r1
    //     0x81b124: add             x1, x1, HEAP, lsl #32
    // 0x81b128: r0 = reset()
    //     0x81b128: bl              #0x81b290  ; [package:pretentious/data/QuestBlock.dart] QuestBlock::reset
    // 0x81b12c: ldur            x0, [fp, #-0x10]
    // 0x81b130: LoadField: r1 = r0->field_4b
    //     0x81b130: ldur            w1, [x0, #0x4b]
    // 0x81b134: DecompressPointer r1
    //     0x81b134: add             x1, x1, HEAP, lsl #32
    // 0x81b138: r0 = clear()
    //     0x81b138: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b13c: ldur            x0, [fp, #-0x10]
    // 0x81b140: LoadField: r1 = r0->field_53
    //     0x81b140: ldur            w1, [x0, #0x53]
    // 0x81b144: DecompressPointer r1
    //     0x81b144: add             x1, x1, HEAP, lsl #32
    // 0x81b148: r0 = clear()
    //     0x81b148: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x81b14c: ldur            x0, [fp, #-0x10]
    // 0x81b150: LoadField: r1 = r0->field_4f
    //     0x81b150: ldur            w1, [x0, #0x4f]
    // 0x81b154: DecompressPointer r1
    //     0x81b154: add             x1, x1, HEAP, lsl #32
    // 0x81b158: r0 = clear()
    //     0x81b158: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b15c: ldur            x0, [fp, #-0x10]
    // 0x81b160: LoadField: r1 = r0->field_47
    //     0x81b160: ldur            w1, [x0, #0x47]
    // 0x81b164: DecompressPointer r1
    //     0x81b164: add             x1, x1, HEAP, lsl #32
    // 0x81b168: r0 = clear()
    //     0x81b168: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b16c: ldur            x1, [fp, #-0x10]
    // 0x81b170: r0 = resetAndRecomputeBoosts()
    //     0x81b170: bl              #0x458b30  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::resetAndRecomputeBoosts
    // 0x81b174: ldur            x0, [fp, #-0x10]
    // 0x81b178: LoadField: r1 = r0->field_3b
    //     0x81b178: ldur            w1, [x0, #0x3b]
    // 0x81b17c: DecompressPointer r1
    //     0x81b17c: add             x1, x1, HEAP, lsl #32
    // 0x81b180: r0 = clear()
    //     0x81b180: bl              #0x33a64c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x81b184: ldur            x1, [fp, #-0x10]
    // 0x81b188: StoreField: r1->field_6b = rZR
    //     0x81b188: stur            xzr, [x1, #0x6b]
    // 0x81b18c: r0 = _getCurrentMicros()
    //     0x81b18c: bl              #0x36dbf8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x81b190: r1 = LoadInt32Instr(r0)
    //     0x81b190: sbfx            x1, x0, #1, #0x1f
    //     0x81b194: tbz             w0, #0, #0x81b19c
    //     0x81b198: ldur            x1, [x0, #7]
    // 0x81b19c: tbz             x1, #0x3f, #0x81b1a8
    // 0x81b1a0: r4 = 999
    //     0x81b1a0: movz            x4, #0x3e7
    // 0x81b1a4: b               #0x81b1ac
    // 0x81b1a8: r4 = 0
    //     0x81b1a8: movz            x4, #0
    // 0x81b1ac: ldur            x2, [fp, #-0x10]
    // 0x81b1b0: ldur            x3, [fp, #-8]
    // 0x81b1b4: r0 = 1000
    //     0x81b1b4: movz            x0, #0x3e8
    // 0x81b1b8: sub             x5, x1, x4
    // 0x81b1bc: sdiv            x4, x5, x0
    // 0x81b1c0: r0 = BoxInt64Instr(r4)
    //     0x81b1c0: sbfiz           x0, x4, #1, #0x1f
    //     0x81b1c4: cmp             x4, x0, asr #1
    //     0x81b1c8: b.eq            #0x81b1d4
    //     0x81b1cc: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x81b1d0: stur            x4, [x0, #7]
    // 0x81b1d4: StoreField: r2->field_73 = r0
    //     0x81b1d4: stur            w0, [x2, #0x73]
    //     0x81b1d8: tbz             w0, #0, #0x81b1f4
    //     0x81b1dc: ldurb           w16, [x2, #-1]
    //     0x81b1e0: ldurb           w17, [x0, #-1]
    //     0x81b1e4: and             x16, x17, x16, lsr #2
    //     0x81b1e8: tst             x16, HEAP, lsr #32
    //     0x81b1ec: b.eq            #0x81b1f4
    //     0x81b1f0: bl              #0x825af8  ; WriteBarrierWrappersStub
    // 0x81b1f4: LoadField: r1 = r2->field_13
    //     0x81b1f4: ldur            w1, [x2, #0x13]
    // 0x81b1f8: DecompressPointer r1
    //     0x81b1f8: add             x1, x1, HEAP, lsl #32
    // 0x81b1fc: r0 = clear()
    //     0x81b1fc: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x81b200: ldur            x0, [fp, #-0x10]
    // 0x81b204: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x81b204: ldur            w1, [x0, #0x17]
    // 0x81b208: DecompressPointer r1
    //     0x81b208: add             x1, x1, HEAP, lsl #32
    // 0x81b20c: r0 = clear()
    //     0x81b20c: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x81b210: ldur            x0, [fp, #-0x10]
    // 0x81b214: LoadField: r1 = r0->field_1b
    //     0x81b214: ldur            w1, [x0, #0x1b]
    // 0x81b218: DecompressPointer r1
    //     0x81b218: add             x1, x1, HEAP, lsl #32
    // 0x81b21c: r0 = clear()
    //     0x81b21c: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x81b220: ldur            x0, [fp, #-0x10]
    // 0x81b224: LoadField: r1 = r0->field_1f
    //     0x81b224: ldur            w1, [x0, #0x1f]
    // 0x81b228: DecompressPointer r1
    //     0x81b228: add             x1, x1, HEAP, lsl #32
    // 0x81b22c: r0 = clear()
    //     0x81b22c: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x81b230: ldur            x0, [fp, #-0x10]
    // 0x81b234: LoadField: r1 = r0->field_f
    //     0x81b234: ldur            w1, [x0, #0xf]
    // 0x81b238: DecompressPointer r1
    //     0x81b238: add             x1, x1, HEAP, lsl #32
    // 0x81b23c: r0 = clear()
    //     0x81b23c: bl              #0x382b7c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x81b240: ldur            x2, [fp, #-0x10]
    // 0x81b244: StoreField: r2->field_83 = rZR
    //     0x81b244: stur            xzr, [x2, #0x83]
    // 0x81b248: StoreField: r2->field_7f = rNULL
    //     0x81b248: stur            NULL, [x2, #0x7f]
    // 0x81b24c: r0 = LoadClassIdInstr(r2)
    //     0x81b24c: ldur            x0, [x2, #-1]
    //     0x81b250: ubfx            x0, x0, #0xc, #0x14
    // 0x81b254: mov             x1, x2
    // 0x81b258: r0 = GDT[cid_x0 + 0x864e]()
    //     0x81b258: movz            x17, #0x864e
    //     0x81b25c: add             lr, x0, x17
    //     0x81b260: ldr             lr, [x21, lr, lsl #3]
    //     0x81b264: blr             lr
    // 0x81b268: ldur            x0, [fp, #-8]
    // 0x81b26c: tbnz            w0, #4, #0x81b278
    // 0x81b270: ldur            x1, [fp, #-0x10]
    // 0x81b274: r0 = saveDeferred()
    //     0x81b274: bl              #0x4e8f9c  ; [package:pretentious/data/Chapters/IGameState.dart] IGameState::saveDeferred
    // 0x81b278: r0 = Null
    //     0x81b278: mov             x0, NULL
    // 0x81b27c: LeaveFrame
    //     0x81b27c: mov             SP, fp
    //     0x81b280: ldp             fp, lr, [SP], #0x10
    // 0x81b284: ret
    //     0x81b284: ret             
    // 0x81b288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81b288: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81b28c: b               #0x81b100
  }
}

// class id: 4174, size: 0x14, field offset: 0x14
enum Stat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x724d30, size: 0x64
    // 0x724d30: EnterFrame
    //     0x724d30: stp             fp, lr, [SP, #-0x10]!
    //     0x724d34: mov             fp, SP
    // 0x724d38: AllocStack(0x10)
    //     0x724d38: sub             SP, SP, #0x10
    // 0x724d3c: SetupParameters(Stat this /* r1 => r0, fp-0x8 */)
    //     0x724d3c: mov             x0, x1
    //     0x724d40: stur            x1, [fp, #-8]
    // 0x724d44: CheckStackOverflow
    //     0x724d44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724d48: cmp             SP, x16
    //     0x724d4c: b.ls            #0x724d8c
    // 0x724d50: r1 = Null
    //     0x724d50: mov             x1, NULL
    // 0x724d54: r2 = 4
    //     0x724d54: movz            x2, #0x4
    // 0x724d58: r0 = AllocateArray()
    //     0x724d58: bl              #0x82746c  ; AllocateArrayStub
    // 0x724d5c: r16 = "Stat."
    //     0x724d5c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16c08] "Stat."
    //     0x724d60: ldr             x16, [x16, #0xc08]
    // 0x724d64: StoreField: r0->field_f = r16
    //     0x724d64: stur            w16, [x0, #0xf]
    // 0x724d68: ldur            x1, [fp, #-8]
    // 0x724d6c: LoadField: r2 = r1->field_f
    //     0x724d6c: ldur            w2, [x1, #0xf]
    // 0x724d70: DecompressPointer r2
    //     0x724d70: add             x2, x2, HEAP, lsl #32
    // 0x724d74: StoreField: r0->field_13 = r2
    //     0x724d74: stur            w2, [x0, #0x13]
    // 0x724d78: str             x0, [SP]
    // 0x724d7c: r0 = _interpolate()
    //     0x724d7c: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x724d80: LeaveFrame
    //     0x724d80: mov             SP, fp
    //     0x724d84: ldp             fp, lr, [SP], #0x10
    // 0x724d88: ret
    //     0x724d88: ret             
    // 0x724d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724d8c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724d90: b               #0x724d50
  }
}
