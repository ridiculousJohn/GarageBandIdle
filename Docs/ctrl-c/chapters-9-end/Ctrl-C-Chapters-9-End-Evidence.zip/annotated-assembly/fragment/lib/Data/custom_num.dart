// lib: , url: package:pretentious/fragment/lib/Data/custom_num.dart

// class id: 1049480, size: 0x8
class :: {
}

// class id: 251, size: 0x10, field offset: 0x8
//   const constructor, 
class CustomNum extends Object {

  _Mint field_8;

  static _ mult3(/* No info */) {
    // ** addr: 0x3da118, size: 0x48
    // 0x3da118: EnterFrame
    //     0x3da118: stp             fp, lr, [SP, #-0x10]!
    //     0x3da11c: mov             fp, SP
    // 0x3da120: CheckStackOverflow
    //     0x3da120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da124: cmp             SP, x16
    //     0x3da128: b.ls            #0x3da158
    // 0x3da12c: LoadField: d0 = r1->field_7
    //     0x3da12c: ldur            d0, [x1, #7]
    // 0x3da130: LoadField: d1 = r2->field_7
    //     0x3da130: ldur            d1, [x2, #7]
    // 0x3da134: fadd            d2, d0, d1
    // 0x3da138: LoadField: d0 = r3->field_7
    //     0x3da138: ldur            d0, [x3, #7]
    // 0x3da13c: fadd            d1, d2, d0
    // 0x3da140: mov             v0.16b, v1.16b
    // 0x3da144: r1 = Null
    //     0x3da144: mov             x1, NULL
    // 0x3da148: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x3da148: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x3da14c: LeaveFrame
    //     0x3da14c: mov             SP, fp
    //     0x3da150: ldp             fp, lr, [SP], #0x10
    // 0x3da154: ret
    //     0x3da154: ret             
    // 0x3da158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3da158: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3da15c: b               #0x3da12c
  }
  bool >=(CustomNum, CustomNum) {
    // ** addr: 0x3da178, size: 0x90
    // 0x3da178: EnterFrame
    //     0x3da178: stp             fp, lr, [SP, #-0x10]!
    //     0x3da17c: mov             fp, SP
    // 0x3da180: ldr             x0, [fp, #0x10]
    // 0x3da184: r2 = Null
    //     0x3da184: mov             x2, NULL
    // 0x3da188: r1 = Null
    //     0x3da188: mov             x1, NULL
    // 0x3da18c: r4 = 60
    //     0x3da18c: movz            x4, #0x3c
    // 0x3da190: branchIfSmi(r0, 0x3da19c)
    //     0x3da190: tbz             w0, #0, #0x3da19c
    // 0x3da194: r4 = LoadClassIdInstr(r0)
    //     0x3da194: ldur            x4, [x0, #-1]
    //     0x3da198: ubfx            x4, x4, #0xc, #0x14
    // 0x3da19c: cmp             x4, #0xfb
    // 0x3da1a0: b.eq            #0x3da1b8
    // 0x3da1a4: r8 = CustomNum
    //     0x3da1a4: add             x8, PP, #0x16, lsl #12  ; [pp+0x16be0] Type: CustomNum
    //     0x3da1a8: ldr             x8, [x8, #0xbe0]
    // 0x3da1ac: r3 = Null
    //     0x3da1ac: add             x3, PP, #0x16, lsl #12  ; [pp+0x16be8] Null
    //     0x3da1b0: ldr             x3, [x3, #0xbe8]
    // 0x3da1b4: r0 = CustomNum()
    //     0x3da1b4: bl              #0x3da294  ; IsType_CustomNum_Stub
    // 0x3da1b8: ldr             x1, [fp, #0x10]
    // 0x3da1bc: LoadField: d0 = r1->field_7
    //     0x3da1bc: ldur            d0, [x1, #7]
    // 0x3da1c0: ldr             x1, [fp, #0x18]
    // 0x3da1c4: LoadField: d1 = r1->field_7
    //     0x3da1c4: ldur            d1, [x1, #7]
    // 0x3da1c8: d2 = 0.000000
    //     0x3da1c8: add             x17, PP, #0x10, lsl #12  ; [pp+0x10d38] IMM: double(1e-14) from 0x3d06849b86a12b9b
    //     0x3da1cc: ldr             d2, [x17, #0xd38]
    // 0x3da1d0: fadd            d3, d1, d2
    // 0x3da1d4: fcmp            d3, d0
    // 0x3da1d8: r16 = true
    //     0x3da1d8: add             x16, NULL, #0x20  ; true
    // 0x3da1dc: r17 = false
    //     0x3da1dc: add             x17, NULL, #0x30  ; false
    // 0x3da1e0: csel            x0, x16, x17, ge
    // 0x3da1e4: LeaveFrame
    //     0x3da1e4: mov             SP, fp
    //     0x3da1e8: ldp             fp, lr, [SP], #0x10
    // 0x3da1ec: ret
    //     0x3da1ec: ret             
  }
  double dyn:get:toDouble(CustomNum) {
    // ** addr: 0x3da208, size: 0xa4
    // 0x3da208: EnterFrame
    //     0x3da208: stp             fp, lr, [SP, #-0x10]!
    //     0x3da20c: mov             fp, SP
    // 0x3da210: ldr             x19, [fp, #0x10]
    // 0x3da214: LoadField: d0 = r19->field_7
    //     0x3da214: ldur            d0, [x19, #7]
    // 0x3da218: stp             fp, lr, [SP, #-0x10]!
    // 0x3da21c: mov             fp, SP
    // 0x3da220: CallRuntime_LibcExp(double) -> double
    //     0x3da220: and             SP, SP, #0xfffffffffffffff0
    //     0x3da224: mov             sp, SP
    //     0x3da228: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x3da22c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x3da230: blr             x16
    //     0x3da234: movz            x16, #0x8
    //     0x3da238: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x3da23c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x3da240: sub             sp, x16, #1, lsl #12
    //     0x3da244: mov             SP, fp
    //     0x3da248: ldp             fp, lr, [SP], #0x10
    // 0x3da24c: r0 = inline_Allocate_Double()
    //     0x3da24c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x3da250: add             x0, x0, #0x10
    //     0x3da254: cmp             x1, x0
    //     0x3da258: b.ls            #0x3da284
    //     0x3da25c: str             x0, [THR, #0x60]  ; THR::top
    //     0x3da260: sub             x0, x0, #0xf
    //     0x3da264: movz            x1, #0xe19c
    //     0x3da268: movk            x1, #0x3, lsl #16
    //     0x3da26c: stur            x1, [x0, #-1]
    // 0x3da270: dmb             ishst
    // 0x3da274: StoreField: r0->field_7 = d0
    //     0x3da274: stur            d0, [x0, #7]
    // 0x3da278: LeaveFrame
    //     0x3da278: mov             SP, fp
    //     0x3da27c: ldp             fp, lr, [SP], #0x10
    // 0x3da280: ret
    //     0x3da280: ret             
    // 0x3da284: SaveReg d0
    //     0x3da284: str             q0, [SP, #-0x10]!
    // 0x3da288: r0 = AllocateDouble()
    //     0x3da288: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x3da28c: RestoreReg d0
    //     0x3da28c: ldr             q0, [SP], #0x10
    // 0x3da290: b               #0x3da274
  }
  factory _ CustomNum.fromExponentWithErrorChecking(/* No info */) {
    // ** addr: 0x3da2b4, size: 0x70
    // 0x3da2b4: EnterFrame
    //     0x3da2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x3da2b8: mov             fp, SP
    // 0x3da2bc: AllocStack(0x8)
    //     0x3da2bc: sub             SP, SP, #8
    // 0x3da2c0: SetupParameters(dynamic _ /* d0 => d0, fp-0x8 */)
    //     0x3da2c0: stur            d0, [fp, #-8]
    // 0x3da2c4: CheckStackOverflow
    //     0x3da2c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da2c8: cmp             SP, x16
    //     0x3da2cc: b.ls            #0x3da31c
    // 0x3da2d0: fcmp            d0, d0
    // 0x3da2d4: b.vc            #0x3da304
    // 0x3da2d8: r0 = current()
    //     0x3da2d8: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x3da2dc: mov             x2, x0
    // 0x3da2e0: r1 = "Exponent is NaN!"
    //     0x3da2e0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeb40] "Exponent is NaN!"
    //     0x3da2e4: ldr             x1, [x1, #0xb40]
    // 0x3da2e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x3da2e8: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x3da2ec: r0 = crashlyticsRecordError()
    //     0x3da2ec: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x3da2f0: r0 = Instance_CustomNum
    //     0x3da2f0: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x3da2f4: ldr             x0, [x0, #0xaf8]
    // 0x3da2f8: LeaveFrame
    //     0x3da2f8: mov             SP, fp
    //     0x3da2fc: ldp             fp, lr, [SP], #0x10
    // 0x3da300: ret
    //     0x3da300: ret             
    // 0x3da304: r0 = CustomNum()
    //     0x3da304: bl              #0x3da324  ; AllocateCustomNumStub -> CustomNum (size=0x10)
    // 0x3da308: ldur            d0, [fp, #-8]
    // 0x3da30c: StoreField: r0->field_7 = d0
    //     0x3da30c: stur            d0, [x0, #7]
    // 0x3da310: LeaveFrame
    //     0x3da310: mov             SP, fp
    //     0x3da314: ldp             fp, lr, [SP], #0x10
    // 0x3da318: ret
    //     0x3da318: ret             
    // 0x3da31c: r0 = StackOverflowSharedWithFPURegs()
    //     0x3da31c: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x3da320: b               #0x3da2d0
  }
  static _ pow(/* No info */) {
    // ** addr: 0x3da330, size: 0xa8
    // 0x3da330: EnterFrame
    //     0x3da330: stp             fp, lr, [SP, #-0x10]!
    //     0x3da334: mov             fp, SP
    // 0x3da338: AllocStack(0x10)
    //     0x3da338: sub             SP, SP, #0x10
    // 0x3da33c: d0 = -inf
    //     0x3da33c: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x3da340: CheckStackOverflow
    //     0x3da340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3da344: cmp             SP, x16
    //     0x3da348: b.ls            #0x3da3b8
    // 0x3da34c: LoadField: d1 = r1->field_7
    //     0x3da34c: ldur            d1, [x1, #7]
    // 0x3da350: fcmp            d1, d0
    // 0x3da354: b.ne            #0x3da36c
    // 0x3da358: r0 = Instance_CustomNum
    //     0x3da358: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x3da35c: ldr             x0, [x0, #0xaf8]
    // 0x3da360: LeaveFrame
    //     0x3da360: mov             SP, fp
    //     0x3da364: ldp             fp, lr, [SP], #0x10
    // 0x3da368: ret
    //     0x3da368: ret             
    // 0x3da36c: r0 = inline_Allocate_Double()
    //     0x3da36c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x3da370: add             x0, x0, #0x10
    //     0x3da374: cmp             x1, x0
    //     0x3da378: b.ls            #0x3da3c0
    //     0x3da37c: str             x0, [THR, #0x60]  ; THR::top
    //     0x3da380: sub             x0, x0, #0xf
    //     0x3da384: movz            x1, #0xe19c
    //     0x3da388: movk            x1, #0x3, lsl #16
    //     0x3da38c: stur            x1, [x0, #-1]
    // 0x3da390: dmb             ishst
    // 0x3da394: StoreField: r0->field_7 = d1
    //     0x3da394: stur            d1, [x0, #7]
    // 0x3da398: stp             x2, x0, [SP]
    // 0x3da39c: r0 = *()
    //     0x3da39c: bl              #0x824ea8  ; [dart:core] _Double::*
    // 0x3da3a0: LoadField: d0 = r0->field_7
    //     0x3da3a0: ldur            d0, [x0, #7]
    // 0x3da3a4: r1 = Null
    //     0x3da3a4: mov             x1, NULL
    // 0x3da3a8: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x3da3a8: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x3da3ac: LeaveFrame
    //     0x3da3ac: mov             SP, fp
    //     0x3da3b0: ldp             fp, lr, [SP], #0x10
    // 0x3da3b4: ret
    //     0x3da3b4: ret             
    // 0x3da3b8: r0 = StackOverflowSharedWithFPURegs()
    //     0x3da3b8: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x3da3bc: b               #0x3da34c
    // 0x3da3c0: SaveReg d1
    //     0x3da3c0: str             q1, [SP, #-0x10]!
    // 0x3da3c4: SaveReg r2
    //     0x3da3c4: str             x2, [SP, #-8]!
    // 0x3da3c8: r0 = AllocateDouble()
    //     0x3da3c8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x3da3cc: RestoreReg r2
    //     0x3da3cc: ldr             x2, [SP], #8
    // 0x3da3d0: RestoreReg d1
    //     0x3da3d0: ldr             q1, [SP], #0x10
    // 0x3da3d4: b               #0x3da394
  }
  static _ mult5(/* No info */) {
    // ** addr: 0x3db218, size: 0x58
    // 0x3db218: EnterFrame
    //     0x3db218: stp             fp, lr, [SP, #-0x10]!
    //     0x3db21c: mov             fp, SP
    // 0x3db220: CheckStackOverflow
    //     0x3db220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3db224: cmp             SP, x16
    //     0x3db228: b.ls            #0x3db268
    // 0x3db22c: LoadField: d0 = r1->field_7
    //     0x3db22c: ldur            d0, [x1, #7]
    // 0x3db230: LoadField: d1 = r2->field_7
    //     0x3db230: ldur            d1, [x2, #7]
    // 0x3db234: fadd            d2, d0, d1
    // 0x3db238: LoadField: d0 = r3->field_7
    //     0x3db238: ldur            d0, [x3, #7]
    // 0x3db23c: fadd            d1, d2, d0
    // 0x3db240: LoadField: d0 = r5->field_7
    //     0x3db240: ldur            d0, [x5, #7]
    // 0x3db244: fadd            d2, d1, d0
    // 0x3db248: LoadField: d0 = r6->field_7
    //     0x3db248: ldur            d0, [x6, #7]
    // 0x3db24c: fadd            d1, d2, d0
    // 0x3db250: mov             v0.16b, v1.16b
    // 0x3db254: r1 = Null
    //     0x3db254: mov             x1, NULL
    // 0x3db258: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x3db258: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x3db25c: LeaveFrame
    //     0x3db25c: mov             SP, fp
    //     0x3db260: ldp             fp, lr, [SP], #0x10
    // 0x3db264: ret
    //     0x3db264: ret             
    // 0x3db268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3db268: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3db26c: b               #0x3db22c
  }
  factory _ CustomNum(/* No info */) {
    // ** addr: 0x3dc21c, size: 0x18c
    // 0x3dc21c: EnterFrame
    //     0x3dc21c: stp             fp, lr, [SP, #-0x10]!
    //     0x3dc220: mov             fp, SP
    // 0x3dc224: AllocStack(0x20)
    //     0x3dc224: sub             SP, SP, #0x20
    // 0x3dc228: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x3dc228: stur            x2, [fp, #-8]
    // 0x3dc22c: CheckStackOverflow
    //     0x3dc22c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dc230: cmp             SP, x16
    //     0x3dc234: b.ls            #0x3dc3a0
    // 0x3dc238: r0 = 60
    //     0x3dc238: movz            x0, #0x3c
    // 0x3dc23c: branchIfSmi(r2, 0x3dc248)
    //     0x3dc23c: tbz             w2, #0, #0x3dc248
    // 0x3dc240: r0 = LoadClassIdInstr(r2)
    //     0x3dc240: ldur            x0, [x2, #-1]
    //     0x3dc244: ubfx            x0, x0, #0xc, #0x14
    // 0x3dc248: str             x2, [SP]
    // 0x3dc24c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x3dc24c: sub             lr, x0, #1, lsl #12
    //     0x3dc250: ldr             lr, [x21, lr, lsl #3]
    //     0x3dc254: blr             lr
    // 0x3dc258: LoadField: d0 = r0->field_7
    //     0x3dc258: ldur            d0, [x0, #7]
    // 0x3dc25c: stp             fp, lr, [SP, #-0x10]!
    // 0x3dc260: mov             fp, SP
    // 0x3dc264: CallRuntime_LibcLog(double) -> double
    //     0x3dc264: and             SP, SP, #0xfffffffffffffff0
    //     0x3dc268: mov             sp, SP
    //     0x3dc26c: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x3dc270: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x3dc274: blr             x16
    //     0x3dc278: movz            x16, #0x8
    //     0x3dc27c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x3dc280: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x3dc284: sub             sp, x16, #1, lsl #12
    //     0x3dc288: mov             SP, fp
    //     0x3dc28c: ldp             fp, lr, [SP], #0x10
    // 0x3dc290: ldur            x1, [fp, #-8]
    // 0x3dc294: stur            d0, [fp, #-0x18]
    // 0x3dc298: r0 = 60
    //     0x3dc298: movz            x0, #0x3c
    // 0x3dc29c: branchIfSmi(r1, 0x3dc2a8)
    //     0x3dc29c: tbz             w1, #0, #0x3dc2a8
    // 0x3dc2a0: r0 = LoadClassIdInstr(r1)
    //     0x3dc2a0: ldur            x0, [x1, #-1]
    //     0x3dc2a4: ubfx            x0, x0, #0xc, #0x14
    // 0x3dc2a8: str             x1, [SP]
    // 0x3dc2ac: r0 = GDT[cid_x0 + -0xf76]()
    //     0x3dc2ac: sub             lr, x0, #0xf76
    //     0x3dc2b0: ldr             lr, [x21, lr, lsl #3]
    //     0x3dc2b4: blr             lr
    // 0x3dc2b8: tbnz            w0, #4, #0x3dc318
    // 0x3dc2bc: ldur            x0, [fp, #-8]
    // 0x3dc2c0: r1 = Null
    //     0x3dc2c0: mov             x1, NULL
    // 0x3dc2c4: r2 = 4
    //     0x3dc2c4: movz            x2, #0x4
    // 0x3dc2c8: r0 = AllocateArray()
    //     0x3dc2c8: bl              #0x82746c  ; AllocateArrayStub
    // 0x3dc2cc: mov             x1, x0
    // 0x3dc2d0: ldur            x0, [fp, #-8]
    // 0x3dc2d4: StoreField: r1->field_f = r0
    //     0x3dc2d4: stur            w0, [x1, #0xf]
    // 0x3dc2d8: r16 = " is NaN!"
    //     0x3dc2d8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeb18] " is NaN!"
    //     0x3dc2dc: ldr             x16, [x16, #0xb18]
    // 0x3dc2e0: StoreField: r1->field_13 = r16
    //     0x3dc2e0: stur            w16, [x1, #0x13]
    // 0x3dc2e4: str             x1, [SP]
    // 0x3dc2e8: r0 = _interpolate()
    //     0x3dc2e8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x3dc2ec: stur            x0, [fp, #-0x10]
    // 0x3dc2f0: r0 = current()
    //     0x3dc2f0: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x3dc2f4: ldur            x1, [fp, #-0x10]
    // 0x3dc2f8: mov             x2, x0
    // 0x3dc2fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x3dc2fc: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x3dc300: r0 = crashlyticsRecordError()
    //     0x3dc300: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x3dc304: r0 = Instance_CustomNum
    //     0x3dc304: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x3dc308: ldr             x0, [x0, #0xaf8]
    // 0x3dc30c: LeaveFrame
    //     0x3dc30c: mov             SP, fp
    //     0x3dc310: ldp             fp, lr, [SP], #0x10
    // 0x3dc314: ret
    //     0x3dc314: ret             
    // 0x3dc318: ldur            x0, [fp, #-8]
    // 0x3dc31c: ldur            d0, [fp, #-0x18]
    // 0x3dc320: fcmp            d0, d0
    // 0x3dc324: b.vc            #0x3dc388
    // 0x3dc328: r1 = Null
    //     0x3dc328: mov             x1, NULL
    // 0x3dc32c: r2 = 6
    //     0x3dc32c: movz            x2, #0x6
    // 0x3dc330: r0 = AllocateArray()
    //     0x3dc330: bl              #0x82746c  ; AllocateArrayStub
    // 0x3dc334: r16 = "Exponent is "
    //     0x3dc334: add             x16, PP, #0xe, lsl #12  ; [pp+0xeb20] "Exponent is "
    //     0x3dc338: ldr             x16, [x16, #0xb20]
    // 0x3dc33c: StoreField: r0->field_f = r16
    //     0x3dc33c: stur            w16, [x0, #0xf]
    // 0x3dc340: ldur            x1, [fp, #-8]
    // 0x3dc344: StoreField: r0->field_13 = r1
    //     0x3dc344: stur            w1, [x0, #0x13]
    // 0x3dc348: r16 = " resulting in NaN!"
    //     0x3dc348: add             x16, PP, #0xe, lsl #12  ; [pp+0xeb28] " resulting in NaN!"
    //     0x3dc34c: ldr             x16, [x16, #0xb28]
    // 0x3dc350: ArrayStore: r0[0] = r16  ; List_4
    //     0x3dc350: stur            w16, [x0, #0x17]
    // 0x3dc354: str             x0, [SP]
    // 0x3dc358: r0 = _interpolate()
    //     0x3dc358: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x3dc35c: stur            x0, [fp, #-8]
    // 0x3dc360: r0 = current()
    //     0x3dc360: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x3dc364: ldur            x1, [fp, #-8]
    // 0x3dc368: mov             x2, x0
    // 0x3dc36c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x3dc36c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x3dc370: r0 = crashlyticsRecordError()
    //     0x3dc370: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x3dc374: r0 = Instance_CustomNum
    //     0x3dc374: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x3dc378: ldr             x0, [x0, #0xaf8]
    // 0x3dc37c: LeaveFrame
    //     0x3dc37c: mov             SP, fp
    //     0x3dc380: ldp             fp, lr, [SP], #0x10
    // 0x3dc384: ret
    //     0x3dc384: ret             
    // 0x3dc388: r0 = CustomNum()
    //     0x3dc388: bl              #0x3da324  ; AllocateCustomNumStub -> CustomNum (size=0x10)
    // 0x3dc38c: ldur            d0, [fp, #-0x18]
    // 0x3dc390: StoreField: r0->field_7 = d0
    //     0x3dc390: stur            d0, [x0, #7]
    // 0x3dc394: LeaveFrame
    //     0x3dc394: mov             SP, fp
    //     0x3dc398: ldp             fp, lr, [SP], #0x10
    // 0x3dc39c: ret
    //     0x3dc39c: ret             
    // 0x3dc3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dc3a0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dc3a4: b               #0x3dc238
  }
  static _ mult2(/* No info */) {
    // ** addr: 0x3dc66c, size: 0x40
    // 0x3dc66c: EnterFrame
    //     0x3dc66c: stp             fp, lr, [SP, #-0x10]!
    //     0x3dc670: mov             fp, SP
    // 0x3dc674: CheckStackOverflow
    //     0x3dc674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dc678: cmp             SP, x16
    //     0x3dc67c: b.ls            #0x3dc6a4
    // 0x3dc680: LoadField: d0 = r1->field_7
    //     0x3dc680: ldur            d0, [x1, #7]
    // 0x3dc684: LoadField: d1 = r2->field_7
    //     0x3dc684: ldur            d1, [x2, #7]
    // 0x3dc688: fadd            d2, d0, d1
    // 0x3dc68c: mov             v0.16b, v2.16b
    // 0x3dc690: r1 = Null
    //     0x3dc690: mov             x1, NULL
    // 0x3dc694: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x3dc694: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x3dc698: LeaveFrame
    //     0x3dc698: mov             SP, fp
    //     0x3dc69c: ldp             fp, lr, [SP], #0x10
    // 0x3dc6a0: ret
    //     0x3dc6a0: ret             
    // 0x3dc6a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dc6a4: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dc6a8: b               #0x3dc680
  }
  static _ mult4(/* No info */) {
    // ** addr: 0x3dda04, size: 0x50
    // 0x3dda04: EnterFrame
    //     0x3dda04: stp             fp, lr, [SP, #-0x10]!
    //     0x3dda08: mov             fp, SP
    // 0x3dda0c: CheckStackOverflow
    //     0x3dda0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x3dda10: cmp             SP, x16
    //     0x3dda14: b.ls            #0x3dda4c
    // 0x3dda18: LoadField: d0 = r1->field_7
    //     0x3dda18: ldur            d0, [x1, #7]
    // 0x3dda1c: LoadField: d1 = r2->field_7
    //     0x3dda1c: ldur            d1, [x2, #7]
    // 0x3dda20: fadd            d2, d0, d1
    // 0x3dda24: LoadField: d0 = r3->field_7
    //     0x3dda24: ldur            d0, [x3, #7]
    // 0x3dda28: fadd            d1, d2, d0
    // 0x3dda2c: LoadField: d0 = r5->field_7
    //     0x3dda2c: ldur            d0, [x5, #7]
    // 0x3dda30: fadd            d2, d1, d0
    // 0x3dda34: mov             v0.16b, v2.16b
    // 0x3dda38: r1 = Null
    //     0x3dda38: mov             x1, NULL
    // 0x3dda3c: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x3dda3c: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x3dda40: LeaveFrame
    //     0x3dda40: mov             SP, fp
    //     0x3dda44: ldp             fp, lr, [SP], #0x10
    // 0x3dda48: ret
    //     0x3dda48: ret             
    // 0x3dda4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x3dda4c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x3dda50: b               #0x3dda18
  }
  static _ div(/* No info */) {
    // ** addr: 0x460f80, size: 0x40
    // 0x460f80: EnterFrame
    //     0x460f80: stp             fp, lr, [SP, #-0x10]!
    //     0x460f84: mov             fp, SP
    // 0x460f88: CheckStackOverflow
    //     0x460f88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x460f8c: cmp             SP, x16
    //     0x460f90: b.ls            #0x460fb8
    // 0x460f94: LoadField: d0 = r1->field_7
    //     0x460f94: ldur            d0, [x1, #7]
    // 0x460f98: LoadField: d1 = r2->field_7
    //     0x460f98: ldur            d1, [x2, #7]
    // 0x460f9c: fsub            d2, d0, d1
    // 0x460fa0: mov             v0.16b, v2.16b
    // 0x460fa4: r1 = Null
    //     0x460fa4: mov             x1, NULL
    // 0x460fa8: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x460fa8: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x460fac: LeaveFrame
    //     0x460fac: mov             SP, fp
    //     0x460fb0: ldp             fp, lr, [SP], #0x10
    // 0x460fb4: ret
    //     0x460fb4: ret             
    // 0x460fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x460fb8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x460fbc: b               #0x460f94
  }
  _ invert(/* No info */) {
    // ** addr: 0x46124c, size: 0x30
    // 0x46124c: EnterFrame
    //     0x46124c: stp             fp, lr, [SP, #-0x10]!
    //     0x461250: mov             fp, SP
    // 0x461254: AllocStack(0x8)
    //     0x461254: sub             SP, SP, #8
    // 0x461258: LoadField: d0 = r1->field_7
    //     0x461258: ldur            d0, [x1, #7]
    // 0x46125c: fneg            d1, d0
    // 0x461260: stur            d1, [fp, #-8]
    // 0x461264: r0 = CustomNum()
    //     0x461264: bl              #0x3da324  ; AllocateCustomNumStub -> CustomNum (size=0x10)
    // 0x461268: ldur            d0, [fp, #-8]
    // 0x46126c: StoreField: r0->field_7 = d0
    //     0x46126c: stur            d0, [x0, #7]
    // 0x461270: LeaveFrame
    //     0x461270: mov             SP, fp
    //     0x461274: ldp             fp, lr, [SP], #0x10
    // 0x461278: ret
    //     0x461278: ret             
  }
  static _ mult2Num(/* No info */) {
    // ** addr: 0x480f0c, size: 0x124
    // 0x480f0c: EnterFrame
    //     0x480f0c: stp             fp, lr, [SP, #-0x10]!
    //     0x480f10: mov             fp, SP
    // 0x480f14: AllocStack(0x28)
    //     0x480f14: sub             SP, SP, #0x28
    // 0x480f18: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x480f18: stur            x1, [fp, #-8]
    //     0x480f1c: stur            x2, [fp, #-0x10]
    // 0x480f20: CheckStackOverflow
    //     0x480f20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x480f24: cmp             SP, x16
    //     0x480f28: b.ls            #0x481028
    // 0x480f2c: r0 = 60
    //     0x480f2c: movz            x0, #0x3c
    // 0x480f30: branchIfSmi(r2, 0x480f3c)
    //     0x480f30: tbz             w2, #0, #0x480f3c
    // 0x480f34: r0 = LoadClassIdInstr(r2)
    //     0x480f34: ldur            x0, [x2, #-1]
    //     0x480f38: ubfx            x0, x0, #0xc, #0x14
    // 0x480f3c: str             x2, [SP]
    // 0x480f40: r0 = GDT[cid_x0 + -0xdbf]()
    //     0x480f40: sub             lr, x0, #0xdbf
    //     0x480f44: ldr             lr, [x21, lr, lsl #3]
    //     0x480f48: blr             lr
    // 0x480f4c: tbnz            w0, #4, #0x480f9c
    // 0x480f50: ldur            x0, [fp, #-0x10]
    // 0x480f54: r1 = Null
    //     0x480f54: mov             x1, NULL
    // 0x480f58: r2 = 4
    //     0x480f58: movz            x2, #0x4
    // 0x480f5c: r0 = AllocateArray()
    //     0x480f5c: bl              #0x82746c  ; AllocateArrayStub
    // 0x480f60: r16 = "Negative value: "
    //     0x480f60: add             x16, PP, #0xe, lsl #12  ; [pp+0xeab8] "Negative value: "
    //     0x480f64: ldr             x16, [x16, #0xab8]
    // 0x480f68: StoreField: r0->field_f = r16
    //     0x480f68: stur            w16, [x0, #0xf]
    // 0x480f6c: ldur            x1, [fp, #-0x10]
    // 0x480f70: StoreField: r0->field_13 = r1
    //     0x480f70: stur            w1, [x0, #0x13]
    // 0x480f74: str             x0, [SP]
    // 0x480f78: r0 = _interpolate()
    //     0x480f78: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x480f7c: stur            x0, [fp, #-0x18]
    // 0x480f80: r0 = current()
    //     0x480f80: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x480f84: ldur            x1, [fp, #-0x18]
    // 0x480f88: mov             x2, x0
    // 0x480f8c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x480f8c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x480f90: r0 = crashlyticsRecordError()
    //     0x480f90: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x480f94: r1 = 0
    //     0x480f94: movz            x1, #0
    // 0x480f98: b               #0x480fa0
    // 0x480f9c: ldur            x1, [fp, #-0x10]
    // 0x480fa0: ldur            x0, [fp, #-8]
    // 0x480fa4: LoadField: d0 = r0->field_7
    //     0x480fa4: ldur            d0, [x0, #7]
    // 0x480fa8: stur            d0, [fp, #-0x20]
    // 0x480fac: r0 = 60
    //     0x480fac: movz            x0, #0x3c
    // 0x480fb0: branchIfSmi(r1, 0x480fbc)
    //     0x480fb0: tbz             w1, #0, #0x480fbc
    // 0x480fb4: r0 = LoadClassIdInstr(r1)
    //     0x480fb4: ldur            x0, [x1, #-1]
    //     0x480fb8: ubfx            x0, x0, #0xc, #0x14
    // 0x480fbc: str             x1, [SP]
    // 0x480fc0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x480fc0: sub             lr, x0, #1, lsl #12
    //     0x480fc4: ldr             lr, [x21, lr, lsl #3]
    //     0x480fc8: blr             lr
    // 0x480fcc: LoadField: d0 = r0->field_7
    //     0x480fcc: ldur            d0, [x0, #7]
    // 0x480fd0: stp             fp, lr, [SP, #-0x10]!
    // 0x480fd4: mov             fp, SP
    // 0x480fd8: CallRuntime_LibcLog(double) -> double
    //     0x480fd8: and             SP, SP, #0xfffffffffffffff0
    //     0x480fdc: mov             sp, SP
    //     0x480fe0: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x480fe4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x480fe8: blr             x16
    //     0x480fec: movz            x16, #0x8
    //     0x480ff0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x480ff4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x480ff8: sub             sp, x16, #1, lsl #12
    //     0x480ffc: mov             SP, fp
    //     0x481000: ldp             fp, lr, [SP], #0x10
    // 0x481004: mov             v1.16b, v0.16b
    // 0x481008: ldur            d0, [fp, #-0x20]
    // 0x48100c: fadd            d2, d0, d1
    // 0x481010: mov             v0.16b, v2.16b
    // 0x481014: r1 = Null
    //     0x481014: mov             x1, NULL
    // 0x481018: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x481018: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x48101c: LeaveFrame
    //     0x48101c: mov             SP, fp
    //     0x481020: ldp             fp, lr, [SP], #0x10
    // 0x481024: ret
    //     0x481024: ret             
    // 0x481028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x481028: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x48102c: b               #0x480f2c
  }
  _ toStringConsistentDecimalPlaces(/* No info */) {
    // ** addr: 0x4e5f30, size: 0x2f8
    // 0x4e5f30: EnterFrame
    //     0x4e5f30: stp             fp, lr, [SP, #-0x10]!
    //     0x4e5f34: mov             fp, SP
    // 0x4e5f38: AllocStack(0x30)
    //     0x4e5f38: sub             SP, SP, #0x30
    // 0x4e5f3c: SetupParameters(CustomNum this /* r1 => r1, fp-0x28 */, {dynamic allowNegativeExponents = true /* r3, fp-0x20 */, int numDecimalPlaces = 2 /* r2, fp-0x18 */, dynamic trimDecimalPlacesOnZero = false /* r6, fp-0x10 */, dynamic trimExtraZeros = false /* r0, fp-0x8 */})
    //     0x4e5f3c: stur            x1, [fp, #-0x28]
    //     0x4e5f40: ldur            w0, [x4, #0x13]
    //     0x4e5f44: ldur            w2, [x4, #0x1f]
    //     0x4e5f48: add             x2, x2, HEAP, lsl #32
    //     0x4e5f4c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16998] "allowNegativeExponents"
    //     0x4e5f50: ldr             x16, [x16, #0x998]
    //     0x4e5f54: cmp             w2, w16
    //     0x4e5f58: b.ne            #0x4e5f7c
    //     0x4e5f5c: ldur            w2, [x4, #0x23]
    //     0x4e5f60: add             x2, x2, HEAP, lsl #32
    //     0x4e5f64: sub             w3, w0, w2
    //     0x4e5f68: add             x2, fp, w3, sxtw #2
    //     0x4e5f6c: ldr             x2, [x2, #8]
    //     0x4e5f70: mov             x3, x2
    //     0x4e5f74: movz            x2, #0x1
    //     0x4e5f78: b               #0x4e5f84
    //     0x4e5f7c: add             x3, NULL, #0x20  ; true
    //     0x4e5f80: movz            x2, #0
    //     0x4e5f84: stur            x3, [fp, #-0x20]
    //     0x4e5f88: lsl             x5, x2, #1
    //     0x4e5f8c: lsl             w6, w5, #1
    //     0x4e5f90: add             w7, w6, #8
    //     0x4e5f94: add             x16, x4, w7, sxtw #1
    //     0x4e5f98: ldur            w8, [x16, #0xf]
    //     0x4e5f9c: add             x8, x8, HEAP, lsl #32
    //     0x4e5fa0: add             x16, PP, #0x16, lsl #12  ; [pp+0x169a0] "numDecimalPlaces"
    //     0x4e5fa4: ldr             x16, [x16, #0x9a0]
    //     0x4e5fa8: cmp             w8, w16
    //     0x4e5fac: b.ne            #0x4e5fec
    //     0x4e5fb0: add             w2, w6, #0xa
    //     0x4e5fb4: add             x16, x4, w2, sxtw #1
    //     0x4e5fb8: ldur            w6, [x16, #0xf]
    //     0x4e5fbc: add             x6, x6, HEAP, lsl #32
    //     0x4e5fc0: sub             w2, w0, w6
    //     0x4e5fc4: add             x6, fp, w2, sxtw #2
    //     0x4e5fc8: ldr             x6, [x6, #8]
    //     0x4e5fcc: add             w2, w5, #2
    //     0x4e5fd0: sbfx            x5, x6, #1, #0x1f
    //     0x4e5fd4: tbz             w6, #0, #0x4e5fdc
    //     0x4e5fd8: ldur            x5, [x6, #7]
    //     0x4e5fdc: sbfx            x6, x2, #1, #0x1f
    //     0x4e5fe0: mov             x2, x5
    //     0x4e5fe4: mov             x5, x6
    //     0x4e5fe8: b               #0x4e5ff4
    //     0x4e5fec: mov             x5, x2
    //     0x4e5ff0: movz            x2, #0x2
    //     0x4e5ff4: stur            x2, [fp, #-0x18]
    //     0x4e5ff8: lsl             x6, x5, #1
    //     0x4e5ffc: lsl             w7, w6, #1
    //     0x4e6000: add             w8, w7, #8
    //     0x4e6004: add             x16, x4, w8, sxtw #1
    //     0x4e6008: ldur            w9, [x16, #0xf]
    //     0x4e600c: add             x9, x9, HEAP, lsl #32
    //     0x4e6010: add             x16, PP, #0x16, lsl #12  ; [pp+0x169a8] "trimDecimalPlacesOnZero"
    //     0x4e6014: ldr             x16, [x16, #0x9a8]
    //     0x4e6018: cmp             w9, w16
    //     0x4e601c: b.ne            #0x4e6050
    //     0x4e6020: add             w5, w7, #0xa
    //     0x4e6024: add             x16, x4, w5, sxtw #1
    //     0x4e6028: ldur            w7, [x16, #0xf]
    //     0x4e602c: add             x7, x7, HEAP, lsl #32
    //     0x4e6030: sub             w5, w0, w7
    //     0x4e6034: add             x7, fp, w5, sxtw #2
    //     0x4e6038: ldr             x7, [x7, #8]
    //     0x4e603c: add             w5, w6, #2
    //     0x4e6040: sbfx            x6, x5, #1, #0x1f
    //     0x4e6044: mov             x5, x6
    //     0x4e6048: mov             x6, x7
    //     0x4e604c: b               #0x4e6054
    //     0x4e6050: add             x6, NULL, #0x30  ; false
    //     0x4e6054: stur            x6, [fp, #-0x10]
    //     0x4e6058: lsl             x7, x5, #1
    //     0x4e605c: lsl             w5, w7, #1
    //     0x4e6060: add             w7, w5, #8
    //     0x4e6064: add             x16, x4, w7, sxtw #1
    //     0x4e6068: ldur            w8, [x16, #0xf]
    //     0x4e606c: add             x8, x8, HEAP, lsl #32
    //     0x4e6070: add             x16, PP, #0x16, lsl #12  ; [pp+0x169b0] "trimExtraZeros"
    //     0x4e6074: ldr             x16, [x16, #0x9b0]
    //     0x4e6078: cmp             w8, w16
    //     0x4e607c: b.ne            #0x4e60a0
    //     0x4e6080: add             w7, w5, #0xa
    //     0x4e6084: add             x16, x4, w7, sxtw #1
    //     0x4e6088: ldur            w5, [x16, #0xf]
    //     0x4e608c: add             x5, x5, HEAP, lsl #32
    //     0x4e6090: sub             w4, w0, w5
    //     0x4e6094: add             x0, fp, w4, sxtw #2
    //     0x4e6098: ldr             x0, [x0, #8]
    //     0x4e609c: b               #0x4e60a4
    //     0x4e60a0: add             x0, NULL, #0x30  ; false
    //     0x4e60a4: stur            x0, [fp, #-8]
    // 0x4e60a8: CheckStackOverflow
    //     0x4e60a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e60ac: cmp             SP, x16
    //     0x4e60b0: b.ls            #0x4e6220
    // 0x4e60b4: r1 = 2
    //     0x4e60b4: movz            x1, #0x2
    // 0x4e60b8: r0 = AllocateContext()
    //     0x4e60b8: bl              #0x82637c  ; AllocateContextStub
    // 0x4e60bc: mov             x2, x0
    // 0x4e60c0: ldur            x3, [fp, #-0x28]
    // 0x4e60c4: StoreField: r2->field_f = r3
    //     0x4e60c4: stur            w3, [x2, #0xf]
    // 0x4e60c8: ldur            x4, [fp, #-0x18]
    // 0x4e60cc: r0 = BoxInt64Instr(r4)
    //     0x4e60cc: sbfiz           x0, x4, #1, #0x1f
    //     0x4e60d0: cmp             x4, x0, asr #1
    //     0x4e60d4: b.eq            #0x4e60e0
    //     0x4e60d8: bl              #0x8276f8  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4e60dc: stur            x4, [x0, #7]
    // 0x4e60e0: StoreField: r2->field_13 = r0
    //     0x4e60e0: stur            w0, [x2, #0x13]
    // 0x4e60e4: r1 = Function 'toExponent':.
    //     0x4e60e4: add             x1, PP, #0x16, lsl #12  ; [pp+0x169b8] AnonymousClosure: (0x4e6488), in [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces (0x4e5f30)
    //     0x4e60e8: ldr             x1, [x1, #0x9b8]
    // 0x4e60ec: r0 = AllocateClosure()
    //     0x4e60ec: bl              #0x826750  ; AllocateClosureStub
    // 0x4e60f0: mov             x1, x0
    // 0x4e60f4: ldur            x0, [fp, #-0x28]
    // 0x4e60f8: LoadField: d0 = r0->field_7
    //     0x4e60f8: ldur            d0, [x0, #7]
    // 0x4e60fc: d1 = 9.210335
    //     0x4e60fc: add             x17, PP, #0x16, lsl #12  ; [pp+0x169c0] IMM: double(9.21033537196) from 0x40226bb113ef8538
    //     0x4e6100: ldr             d1, [x17, #0x9c0]
    // 0x4e6104: fcmp            d0, d1
    // 0x4e6108: b.lt            #0x4e612c
    // 0x4e610c: str             x1, [SP]
    // 0x4e6110: mov             x0, x1
    // 0x4e6114: ClosureCall
    //     0x4e6114: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x4e6118: ldur            x2, [x0, #0x1f]
    //     0x4e611c: blr             x2
    // 0x4e6120: LeaveFrame
    //     0x4e6120: mov             SP, fp
    //     0x4e6124: ldp             fp, lr, [SP], #0x10
    // 0x4e6128: ret
    //     0x4e6128: ret             
    // 0x4e612c: ldur            x0, [fp, #-0x20]
    // 0x4e6130: tbnz            w0, #4, #0x4e61d4
    // 0x4e6134: d1 = -2.302585
    //     0x4e6134: add             x17, PP, #0x16, lsl #12  ; [pp+0x169c8] IMM: double(-2.3025851) from 0xc0026bb1bca60e1c
    //     0x4e6138: ldr             d1, [x17, #0x9c8]
    // 0x4e613c: fcmp            d1, d0
    // 0x4e6140: b.lt            #0x4e61d4
    // 0x4e6144: mov             x0, v0.d[0]
    // 0x4e6148: and             x0, x0, #0x7fffffffffffffff
    // 0x4e614c: r17 = 9218868437227405312
    //     0x4e614c: orr             x17, xzr, #0x7ff0000000000000
    // 0x4e6150: cmp             x0, x17
    // 0x4e6154: b.ne            #0x4e61b4
    // 0x4e6158: ldur            x0, [fp, #-0x10]
    // 0x4e615c: tbnz            w0, #4, #0x4e6168
    // 0x4e6160: r0 = "0"
    //     0x4e6160: ldr             x0, [PP, #0x2c38]  ; [pp+0x2c38] "0"
    // 0x4e6164: b               #0x4e61a8
    // 0x4e6168: stp             fp, lr, [SP, #-0x10]!
    // 0x4e616c: mov             fp, SP
    // 0x4e6170: CallRuntime_LibcExp(double) -> double
    //     0x4e6170: and             SP, SP, #0xfffffffffffffff0
    //     0x4e6174: mov             sp, SP
    //     0x4e6178: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x4e617c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6180: blr             x16
    //     0x4e6184: movz            x16, #0x8
    //     0x4e6188: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e618c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e6190: sub             sp, x16, #1, lsl #12
    //     0x4e6194: mov             SP, fp
    //     0x4e6198: ldp             fp, lr, [SP], #0x10
    // 0x4e619c: ldur            x1, [fp, #-0x18]
    // 0x4e61a0: ldur            x2, [fp, #-8]
    // 0x4e61a4: r0 = DecimalManagement.maxNDecimalPlacesNoTrimming()
    //     0x4e61a4: bl              #0x4e6228  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.maxNDecimalPlacesNoTrimming
    // 0x4e61a8: LeaveFrame
    //     0x4e61a8: mov             SP, fp
    //     0x4e61ac: ldp             fp, lr, [SP], #0x10
    // 0x4e61b0: ret
    //     0x4e61b0: ret             
    // 0x4e61b4: str             x1, [SP]
    // 0x4e61b8: mov             x0, x1
    // 0x4e61bc: ClosureCall
    //     0x4e61bc: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x4e61c0: ldur            x2, [x0, #0x1f]
    //     0x4e61c4: blr             x2
    // 0x4e61c8: LeaveFrame
    //     0x4e61c8: mov             SP, fp
    //     0x4e61cc: ldp             fp, lr, [SP], #0x10
    // 0x4e61d0: ret
    //     0x4e61d0: ret             
    // 0x4e61d4: stp             fp, lr, [SP, #-0x10]!
    // 0x4e61d8: mov             fp, SP
    // 0x4e61dc: CallRuntime_LibcExp(double) -> double
    //     0x4e61dc: and             SP, SP, #0xfffffffffffffff0
    //     0x4e61e0: mov             sp, SP
    //     0x4e61e4: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x4e61e8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e61ec: blr             x16
    //     0x4e61f0: movz            x16, #0x8
    //     0x4e61f4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e61f8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e61fc: sub             sp, x16, #1, lsl #12
    //     0x4e6200: mov             SP, fp
    //     0x4e6204: ldp             fp, lr, [SP], #0x10
    // 0x4e6208: ldur            x1, [fp, #-0x18]
    // 0x4e620c: ldur            x2, [fp, #-8]
    // 0x4e6210: r0 = DecimalManagement.maxNDecimalPlacesNoTrimming()
    //     0x4e6210: bl              #0x4e6228  ; [package:pretentious/fragment/lib/Data/idle_functions_extensions.dart] ::DecimalManagement.maxNDecimalPlacesNoTrimming
    // 0x4e6214: LeaveFrame
    //     0x4e6214: mov             SP, fp
    //     0x4e6218: ldp             fp, lr, [SP], #0x10
    // 0x4e621c: ret
    //     0x4e621c: ret             
    // 0x4e6220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6220: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e6224: b               #0x4e60b4
  }
  [closure] String toExponent(dynamic) {
    // ** addr: 0x4e6488, size: 0x438
    // 0x4e6488: EnterFrame
    //     0x4e6488: stp             fp, lr, [SP, #-0x10]!
    //     0x4e648c: mov             fp, SP
    // 0x4e6490: AllocStack(0x38)
    //     0x4e6490: sub             SP, SP, #0x38
    // 0x4e6494: SetupParameters([dynamic _ /* r0 */])
    //     0x4e6494: ldr             x0, [fp, #0x10]
    //     0x4e6498: ldur            w1, [x0, #0x17]
    //     0x4e649c: add             x1, x1, HEAP, lsl #32
    //     0x4e64a0: stur            x1, [fp, #-8]
    // 0x4e64a4: CheckStackOverflow
    //     0x4e64a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4e64a8: cmp             SP, x16
    //     0x4e64ac: b.ls            #0x4e6878
    // 0x4e64b0: LoadField: r0 = r1->field_f
    //     0x4e64b0: ldur            w0, [x1, #0xf]
    // 0x4e64b4: DecompressPointer r0
    //     0x4e64b4: add             x0, x0, HEAP, lsl #32
    // 0x4e64b8: LoadField: d0 = r0->field_7
    //     0x4e64b8: ldur            d0, [x0, #7]
    // 0x4e64bc: stur            d0, [fp, #-0x20]
    // 0x4e64c0: r16 = 20
    //     0x4e64c0: movz            x16, #0x14
    // 0x4e64c4: stp             x16, NULL, [SP]
    // 0x4e64c8: r0 = _Double.fromInteger()
    //     0x4e64c8: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x4e64cc: LoadField: d0 = r0->field_7
    //     0x4e64cc: ldur            d0, [x0, #7]
    // 0x4e64d0: stp             fp, lr, [SP, #-0x10]!
    // 0x4e64d4: mov             fp, SP
    // 0x4e64d8: CallRuntime_LibcLog(double) -> double
    //     0x4e64d8: and             SP, SP, #0xfffffffffffffff0
    //     0x4e64dc: mov             sp, SP
    //     0x4e64e0: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x4e64e4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e64e8: blr             x16
    //     0x4e64ec: movz            x16, #0x8
    //     0x4e64f0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e64f4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e64f8: sub             sp, x16, #1, lsl #12
    //     0x4e64fc: mov             SP, fp
    //     0x4e6500: ldp             fp, lr, [SP], #0x10
    // 0x4e6504: mov             v1.16b, v0.16b
    // 0x4e6508: ldur            d0, [fp, #-0x20]
    // 0x4e650c: fdiv            d2, d0, d1
    // 0x4e6510: ldur            x0, [fp, #-8]
    // 0x4e6514: stur            d2, [fp, #-0x28]
    // 0x4e6518: LoadField: r1 = r0->field_13
    //     0x4e6518: ldur            w1, [x0, #0x13]
    // 0x4e651c: DecompressPointer r1
    //     0x4e651c: add             x1, x1, HEAP, lsl #32
    // 0x4e6520: stur            x1, [fp, #-0x10]
    // 0x4e6524: r16 = 2
    //     0x4e6524: movz            x16, #0x2
    // 0x4e6528: stp             x16, NULL, [SP]
    // 0x4e652c: r0 = _Double.fromInteger()
    //     0x4e652c: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x4e6530: LoadField: d1 = r0->field_7
    //     0x4e6530: ldur            d1, [x0, #7]
    // 0x4e6534: ldur            d0, [fp, #-0x28]
    // 0x4e6538: stp             fp, lr, [SP, #-0x10]!
    // 0x4e653c: mov             fp, SP
    // 0x4e6540: CallRuntime_DartModulo(double, double) -> double
    //     0x4e6540: and             SP, SP, #0xfffffffffffffff0
    //     0x4e6544: mov             sp, SP
    //     0x4e6548: ldr             x16, [THR, #0x748]  ; THR::DartModulo
    //     0x4e654c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6550: blr             x16
    //     0x4e6554: movz            x16, #0x8
    //     0x4e6558: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e655c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e6560: sub             sp, x16, #1, lsl #12
    //     0x4e6564: mov             SP, fp
    //     0x4e6568: ldp             fp, lr, [SP], #0x10
    // 0x4e656c: ldur            x0, [fp, #-0x10]
    // 0x4e6570: r1 = LoadInt32Instr(r0)
    //     0x4e6570: sbfx            x1, x0, #1, #0x1f
    //     0x4e6574: tbz             w0, #0, #0x4e657c
    //     0x4e6578: ldur            x1, [x0, #7]
    // 0x4e657c: scvtf           d1, x1
    // 0x4e6580: fadd            d2, d1, d0
    // 0x4e6584: stur            d2, [fp, #-0x20]
    // 0x4e6588: r16 = 20
    //     0x4e6588: movz            x16, #0x14
    // 0x4e658c: stp             x16, NULL, [SP]
    // 0x4e6590: r0 = _Double.fromInteger()
    //     0x4e6590: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x4e6594: LoadField: d0 = r0->field_7
    //     0x4e6594: ldur            d0, [x0, #7]
    // 0x4e6598: ldur            d1, [fp, #-0x20]
    // 0x4e659c: d30 = 0.000000
    //     0x4e659c: fmov            d30, d0
    // 0x4e65a0: d0 = 1.000000
    //     0x4e65a0: fmov            d0, #1.00000000
    // 0x4e65a4: fcmp            d1, #0.0
    // 0x4e65a8: b.vs            #0x4e65ec
    // 0x4e65ac: b.eq            #0x4e6674
    // 0x4e65b0: fcmp            d1, d0
    // 0x4e65b4: b.eq            #0x4e65dc
    // 0x4e65b8: d31 = 2.000000
    //     0x4e65b8: fmov            d31, #2.00000000
    // 0x4e65bc: fcmp            d1, d31
    // 0x4e65c0: b.eq            #0x4e65e4
    // 0x4e65c4: d31 = 3.000000
    //     0x4e65c4: fmov            d31, #3.00000000
    // 0x4e65c8: fcmp            d1, d31
    // 0x4e65cc: b.ne            #0x4e65ec
    // 0x4e65d0: fmul            d0, d30, d30
    // 0x4e65d4: fmul            d0, d0, d30
    // 0x4e65d8: b               #0x4e6674
    // 0x4e65dc: d0 = 0.000000
    //     0x4e65dc: fmov            d0, d30
    // 0x4e65e0: b               #0x4e6674
    // 0x4e65e4: fmul            d0, d30, d30
    // 0x4e65e8: b               #0x4e6674
    // 0x4e65ec: fcmp            d30, d0
    // 0x4e65f0: b.vs            #0x4e6600
    // 0x4e65f4: b.eq            #0x4e6674
    // 0x4e65f8: fcmp            d30, d1
    // 0x4e65fc: b.vc            #0x4e660c
    // 0x4e6600: d0 = nan
    //     0x4e6600: add             x17, PP, #0xc, lsl #12  ; [pp+0xce48] IMM: double(nan) from 0x7ff8000000000000
    //     0x4e6604: ldr             d0, [x17, #0xe48]
    // 0x4e6608: b               #0x4e6674
    // 0x4e660c: d0 = -inf
    //     0x4e660c: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x4e6610: fcmp            d30, d0
    // 0x4e6614: b.eq            #0x4e663c
    // 0x4e6618: d0 = 0.500000
    //     0x4e6618: fmov            d0, #0.50000000
    // 0x4e661c: fcmp            d1, d0
    // 0x4e6620: b.ne            #0x4e663c
    // 0x4e6624: fcmp            d30, #0.0
    // 0x4e6628: b.eq            #0x4e6634
    // 0x4e662c: fsqrt           d0, d30
    // 0x4e6630: b               #0x4e6674
    // 0x4e6634: d0 = 0.000000
    //     0x4e6634: eor             v0.16b, v0.16b, v0.16b
    // 0x4e6638: b               #0x4e6674
    // 0x4e663c: d0 = 0.000000
    //     0x4e663c: fmov            d0, d30
    // 0x4e6640: stp             fp, lr, [SP, #-0x10]!
    // 0x4e6644: mov             fp, SP
    // 0x4e6648: CallRuntime_LibcPow(double, double) -> double
    //     0x4e6648: and             SP, SP, #0xfffffffffffffff0
    //     0x4e664c: mov             sp, SP
    //     0x4e6650: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x4e6654: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6658: blr             x16
    //     0x4e665c: movz            x16, #0x8
    //     0x4e6660: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6664: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e6668: sub             sp, x16, #1, lsl #12
    //     0x4e666c: mov             SP, fp
    //     0x4e6670: ldp             fp, lr, [SP], #0x10
    // 0x4e6674: stp             fp, lr, [SP, #-0x10]!
    // 0x4e6678: mov             fp, SP
    // 0x4e667c: CallRuntime_LibcRound(double) -> double
    //     0x4e667c: and             SP, SP, #0xfffffffffffffff0
    //     0x4e6680: mov             sp, SP
    //     0x4e6684: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x4e6688: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e668c: blr             x16
    //     0x4e6690: movz            x16, #0x8
    //     0x4e6694: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6698: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e669c: sub             sp, x16, #1, lsl #12
    //     0x4e66a0: mov             SP, fp
    //     0x4e66a4: ldp             fp, lr, [SP], #0x10
    // 0x4e66a8: fcmp            d0, d0
    // 0x4e66ac: b.vs            #0x4e6880
    // 0x4e66b0: fcvtzs          x0, d0
    // 0x4e66b4: asr             x16, x0, #0x1e
    // 0x4e66b8: cmp             x16, x0, asr #63
    // 0x4e66bc: b.ne            #0x4e6880
    // 0x4e66c0: lsl             x0, x0, #1
    // 0x4e66c4: r1 = 60
    //     0x4e66c4: movz            x1, #0x3c
    // 0x4e66c8: branchIfSmi(r0, 0x4e66d4)
    //     0x4e66c8: tbz             w0, #0, #0x4e66d4
    // 0x4e66cc: r1 = LoadClassIdInstr(r0)
    //     0x4e66cc: ldur            x1, [x0, #-1]
    //     0x4e66d0: ubfx            x1, x1, #0xc, #0x14
    // 0x4e66d4: str             x0, [SP]
    // 0x4e66d8: mov             x0, x1
    // 0x4e66dc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4e66dc: ldr             x4, [PP, #0x400]  ; [pp+0x400] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4e66e0: r0 = GDT[cid_x0 + 0x3019]()
    //     0x4e66e0: movz            x17, #0x3019
    //     0x4e66e4: add             lr, x0, x17
    //     0x4e66e8: ldr             lr, [x21, lr, lsl #3]
    //     0x4e66ec: blr             lr
    // 0x4e66f0: LoadField: r1 = r0->field_7
    //     0x4e66f0: ldur            w1, [x0, #7]
    // 0x4e66f4: ldur            x2, [fp, #-8]
    // 0x4e66f8: LoadField: r3 = r2->field_13
    //     0x4e66f8: ldur            w3, [x2, #0x13]
    // 0x4e66fc: DecompressPointer r3
    //     0x4e66fc: add             x3, x3, HEAP, lsl #32
    // 0x4e6700: r2 = LoadInt32Instr(r3)
    //     0x4e6700: sbfx            x2, x3, #1, #0x1f
    //     0x4e6704: tbz             w3, #0, #0x4e670c
    //     0x4e6708: ldur            x2, [x3, #7]
    // 0x4e670c: add             x3, x2, #1
    // 0x4e6710: r2 = LoadInt32Instr(r1)
    //     0x4e6710: sbfx            x2, x1, #1, #0x1f
    // 0x4e6714: cmp             x2, x3
    // 0x4e6718: b.le            #0x4e6754
    // 0x4e671c: ldur            d0, [fp, #-0x28]
    // 0x4e6720: d1 = 1.000000
    //     0x4e6720: fmov            d1, #1.00000000
    // 0x4e6724: fadd            d2, d0, d1
    // 0x4e6728: stur            d2, [fp, #-0x20]
    // 0x4e672c: sub             x1, x2, #1
    // 0x4e6730: lsl             x2, x1, #1
    // 0x4e6734: str             x2, [SP]
    // 0x4e6738: mov             x1, x0
    // 0x4e673c: r2 = 0
    //     0x4e673c: movz            x2, #0
    // 0x4e6740: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x4e6740: ldr             x4, [PP, #0x2d0]  ; [pp+0x2d0] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x4e6744: r0 = substring()
    //     0x4e6744: bl              #0x338cd4  ; [dart:core] _StringBase::substring
    // 0x4e6748: ldur            d0, [fp, #-0x20]
    // 0x4e674c: mov             x1, x0
    // 0x4e6750: b               #0x4e675c
    // 0x4e6754: ldur            d0, [fp, #-0x28]
    // 0x4e6758: mov             x1, x0
    // 0x4e675c: stur            x1, [fp, #-8]
    // 0x4e6760: stur            d0, [fp, #-0x20]
    // 0x4e6764: stp             xzr, x1, [SP]
    // 0x4e6768: r0 = []()
    //     0x4e6768: bl              #0x32d4fc  ; [dart:core] _StringBase::[]
    // 0x4e676c: r1 = Null
    //     0x4e676c: mov             x1, NULL
    // 0x4e6770: r2 = 10
    //     0x4e6770: movz            x2, #0xa
    // 0x4e6774: stur            x0, [fp, #-0x10]
    // 0x4e6778: r0 = AllocateArray()
    //     0x4e6778: bl              #0x82746c  ; AllocateArrayStub
    // 0x4e677c: mov             x3, x0
    // 0x4e6780: ldur            x0, [fp, #-0x10]
    // 0x4e6784: stur            x3, [fp, #-0x18]
    // 0x4e6788: StoreField: r3->field_f = r0
    //     0x4e6788: stur            w0, [x3, #0xf]
    // 0x4e678c: r16 = "."
    //     0x4e678c: ldr             x16, [PP, #0x108]  ; [pp+0x108] "."
    // 0x4e6790: StoreField: r3->field_13 = r16
    //     0x4e6790: stur            w16, [x3, #0x13]
    // 0x4e6794: ldur            x1, [fp, #-8]
    // 0x4e6798: r2 = 1
    //     0x4e6798: movz            x2, #0x1
    // 0x4e679c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4e679c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4e67a0: r0 = substring()
    //     0x4e67a0: bl              #0x338cd4  ; [dart:core] _StringBase::substring
    // 0x4e67a4: ldur            x1, [fp, #-0x18]
    // 0x4e67a8: ArrayStore: r1[2] = r0  ; List_4
    //     0x4e67a8: add             x25, x1, #0x17
    //     0x4e67ac: str             w0, [x25]
    //     0x4e67b0: tbz             w0, #0, #0x4e67cc
    //     0x4e67b4: ldurb           w16, [x1, #-1]
    //     0x4e67b8: ldurb           w17, [x0, #-1]
    //     0x4e67bc: and             x16, x17, x16, lsr #2
    //     0x4e67c0: tst             x16, HEAP, lsr #32
    //     0x4e67c4: b.eq            #0x4e67cc
    //     0x4e67c8: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e67cc: ldur            x19, [fp, #-0x18]
    // 0x4e67d0: r16 = "e"
    //     0x4e67d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] "e"
    //     0x4e67d4: ldr             x16, [x16, #0x5c0]
    // 0x4e67d8: StoreField: r19->field_1b = r16
    //     0x4e67d8: stur            w16, [x19, #0x1b]
    // 0x4e67dc: ldur            d1, [fp, #-0x20]
    // 0x4e67e0: d0 = 0.500000
    //     0x4e67e0: fmov            d0, #0.50000000
    // 0x4e67e4: fsub            d2, d1, d0
    // 0x4e67e8: mov             v0.16b, v2.16b
    // 0x4e67ec: stp             fp, lr, [SP, #-0x10]!
    // 0x4e67f0: mov             fp, SP
    // 0x4e67f4: CallRuntime_LibcRound(double) -> double
    //     0x4e67f4: and             SP, SP, #0xfffffffffffffff0
    //     0x4e67f8: mov             sp, SP
    //     0x4e67fc: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x4e6800: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6804: blr             x16
    //     0x4e6808: movz            x16, #0x8
    //     0x4e680c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4e6810: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4e6814: sub             sp, x16, #1, lsl #12
    //     0x4e6818: mov             SP, fp
    //     0x4e681c: ldp             fp, lr, [SP], #0x10
    // 0x4e6820: fcmp            d0, d0
    // 0x4e6824: b.vs            #0x4e689c
    // 0x4e6828: fcvtzs          x0, d0
    // 0x4e682c: asr             x16, x0, #0x1e
    // 0x4e6830: cmp             x16, x0, asr #63
    // 0x4e6834: b.ne            #0x4e689c
    // 0x4e6838: lsl             x0, x0, #1
    // 0x4e683c: mov             x1, x19
    // 0x4e6840: ArrayStore: r1[4] = r0  ; List_4
    //     0x4e6840: add             x25, x1, #0x1f
    //     0x4e6844: str             w0, [x25]
    //     0x4e6848: tbz             w0, #0, #0x4e6864
    //     0x4e684c: ldurb           w16, [x1, #-1]
    //     0x4e6850: ldurb           w17, [x0, #-1]
    //     0x4e6854: and             x16, x17, x16, lsr #2
    //     0x4e6858: tst             x16, HEAP, lsr #32
    //     0x4e685c: b.eq            #0x4e6864
    //     0x4e6860: bl              #0x825694  ; ArrayWriteBarrierStub
    // 0x4e6864: str             x19, [SP]
    // 0x4e6868: r0 = _interpolate()
    //     0x4e6868: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x4e686c: LeaveFrame
    //     0x4e686c: mov             SP, fp
    //     0x4e6870: ldp             fp, lr, [SP], #0x10
    // 0x4e6874: ret
    //     0x4e6874: ret             
    // 0x4e6878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4e6878: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4e687c: b               #0x4e64b0
    // 0x4e6880: SaveReg d0
    //     0x4e6880: str             q0, [SP, #-0x10]!
    // 0x4e6884: r0 = 76
    //     0x4e6884: movz            x0, #0x4c
    // 0x4e6888: r30 = DoubleToIntegerStub
    //     0x4e6888: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x4e688c: LoadField: r30 = r30->field_7
    //     0x4e688c: ldur            lr, [lr, #7]
    // 0x4e6890: blr             lr
    // 0x4e6894: RestoreReg d0
    //     0x4e6894: ldr             q0, [SP], #0x10
    // 0x4e6898: b               #0x4e66c4
    // 0x4e689c: SaveReg d0
    //     0x4e689c: str             q0, [SP, #-0x10]!
    // 0x4e68a0: SaveReg r19
    //     0x4e68a0: str             x19, [SP, #-8]!
    // 0x4e68a4: r0 = 76
    //     0x4e68a4: movz            x0, #0x4c
    // 0x4e68a8: r30 = DoubleToIntegerStub
    //     0x4e68a8: ldr             lr, [PP, #0x3380]  ; [pp+0x3380] Stub: DoubleToInteger (0x3218e4)
    // 0x4e68ac: LoadField: r30 = r30->field_7
    //     0x4e68ac: ldur            lr, [lr, #7]
    // 0x4e68b0: blr             lr
    // 0x4e68b4: RestoreReg r19
    //     0x4e68b4: ldr             x19, [SP], #8
    // 0x4e68b8: RestoreReg d0
    //     0x4e68b8: ldr             q0, [SP], #0x10
    // 0x4e68bc: b               #0x4e683c
  }
  static _ add(/* No info */) {
    // ** addr: 0x4f974c, size: 0x1d8
    // 0x4f974c: EnterFrame
    //     0x4f974c: stp             fp, lr, [SP, #-0x10]!
    //     0x4f9750: mov             fp, SP
    // 0x4f9754: AllocStack(0x10)
    //     0x4f9754: sub             SP, SP, #0x10
    // 0x4f9758: SetupParameters(dynamic _ /* r2 => r0 */)
    //     0x4f9758: mov             x0, x2
    // 0x4f975c: CheckStackOverflow
    //     0x4f975c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4f9760: cmp             SP, x16
    //     0x4f9764: b.ls            #0x4f991c
    // 0x4f9768: LoadField: d1 = r1->field_7
    //     0x4f9768: ldur            d1, [x1, #7]
    // 0x4f976c: stur            d1, [fp, #-8]
    // 0x4f9770: mov             x2, v1.d[0]
    // 0x4f9774: and             x2, x2, #0x7fffffffffffffff
    // 0x4f9778: r17 = 9218868437227405312
    //     0x4f9778: orr             x17, xzr, #0x7ff0000000000000
    // 0x4f977c: cmp             x2, x17
    // 0x4f9780: b.ne            #0x4f97c0
    // 0x4f9784: LoadField: d0 = r0->field_7
    //     0x4f9784: ldur            d0, [x0, #7]
    // 0x4f9788: mov             x2, v0.d[0]
    // 0x4f978c: and             x2, x2, #0x7fffffffffffffff
    // 0x4f9790: r17 = 9218868437227405312
    //     0x4f9790: orr             x17, xzr, #0x7ff0000000000000
    // 0x4f9794: cmp             x2, x17
    // 0x4f9798: b.ne            #0x4f97c0
    // 0x4f979c: fcmp            d1, d0
    // 0x4f97a0: b.le            #0x4f97b4
    // 0x4f97a4: mov             x0, x1
    // 0x4f97a8: LeaveFrame
    //     0x4f97a8: mov             SP, fp
    //     0x4f97ac: ldp             fp, lr, [SP], #0x10
    // 0x4f97b0: ret
    //     0x4f97b0: ret             
    // 0x4f97b4: LeaveFrame
    //     0x4f97b4: mov             SP, fp
    //     0x4f97b8: ldp             fp, lr, [SP], #0x10
    // 0x4f97bc: ret
    //     0x4f97bc: ret             
    // 0x4f97c0: d0 = 100.000000
    //     0x4f97c0: add             x17, PP, #0xb, lsl #12  ; [pp+0xbe38] IMM: double(100) from 0x4059000000000000
    //     0x4f97c4: ldr             d0, [x17, #0xe38]
    // 0x4f97c8: LoadField: d2 = r0->field_7
    //     0x4f97c8: ldur            d2, [x0, #7]
    // 0x4f97cc: stur            d2, [fp, #-0x10]
    // 0x4f97d0: fsub            d3, d1, d2
    // 0x4f97d4: fcmp            d3, d0
    // 0x4f97d8: b.le            #0x4f9878
    // 0x4f97dc: fsub            d0, d2, d1
    // 0x4f97e0: stp             fp, lr, [SP, #-0x10]!
    // 0x4f97e4: mov             fp, SP
    // 0x4f97e8: CallRuntime_LibcExp(double) -> double
    //     0x4f97e8: and             SP, SP, #0xfffffffffffffff0
    //     0x4f97ec: mov             sp, SP
    //     0x4f97f0: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x4f97f4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f97f8: blr             x16
    //     0x4f97fc: movz            x16, #0x8
    //     0x4f9800: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f9804: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f9808: sub             sp, x16, #1, lsl #12
    //     0x4f980c: mov             SP, fp
    //     0x4f9810: ldp             fp, lr, [SP], #0x10
    // 0x4f9814: d1 = 1.000000
    //     0x4f9814: fmov            d1, #1.00000000
    // 0x4f9818: fadd            d2, d0, d1
    // 0x4f981c: mov             v0.16b, v2.16b
    // 0x4f9820: stp             fp, lr, [SP, #-0x10]!
    // 0x4f9824: mov             fp, SP
    // 0x4f9828: CallRuntime_LibcLog(double) -> double
    //     0x4f9828: and             SP, SP, #0xfffffffffffffff0
    //     0x4f982c: mov             sp, SP
    //     0x4f9830: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x4f9834: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f9838: blr             x16
    //     0x4f983c: movz            x16, #0x8
    //     0x4f9840: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f9844: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f9848: sub             sp, x16, #1, lsl #12
    //     0x4f984c: mov             SP, fp
    //     0x4f9850: ldp             fp, lr, [SP], #0x10
    // 0x4f9854: mov             v1.16b, v0.16b
    // 0x4f9858: ldur            d0, [fp, #-8]
    // 0x4f985c: fadd            d2, d0, d1
    // 0x4f9860: mov             v0.16b, v2.16b
    // 0x4f9864: r1 = Null
    //     0x4f9864: mov             x1, NULL
    // 0x4f9868: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x4f9868: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x4f986c: LeaveFrame
    //     0x4f986c: mov             SP, fp
    //     0x4f9870: ldp             fp, lr, [SP], #0x10
    // 0x4f9874: ret
    //     0x4f9874: ret             
    // 0x4f9878: d1 = 1.000000
    //     0x4f9878: fmov            d1, #1.00000000
    // 0x4f987c: mov             v0.16b, v3.16b
    // 0x4f9880: stp             fp, lr, [SP, #-0x10]!
    // 0x4f9884: mov             fp, SP
    // 0x4f9888: CallRuntime_LibcExp(double) -> double
    //     0x4f9888: and             SP, SP, #0xfffffffffffffff0
    //     0x4f988c: mov             sp, SP
    //     0x4f9890: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x4f9894: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f9898: blr             x16
    //     0x4f989c: movz            x16, #0x8
    //     0x4f98a0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f98a4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f98a8: sub             sp, x16, #1, lsl #12
    //     0x4f98ac: mov             SP, fp
    //     0x4f98b0: ldp             fp, lr, [SP], #0x10
    // 0x4f98b4: mov             v1.16b, v0.16b
    // 0x4f98b8: d0 = 1.000000
    //     0x4f98b8: fmov            d0, #1.00000000
    // 0x4f98bc: fadd            d2, d1, d0
    // 0x4f98c0: mov             v0.16b, v2.16b
    // 0x4f98c4: stp             fp, lr, [SP, #-0x10]!
    // 0x4f98c8: mov             fp, SP
    // 0x4f98cc: CallRuntime_LibcLog(double) -> double
    //     0x4f98cc: and             SP, SP, #0xfffffffffffffff0
    //     0x4f98d0: mov             sp, SP
    //     0x4f98d4: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x4f98d8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f98dc: blr             x16
    //     0x4f98e0: movz            x16, #0x8
    //     0x4f98e4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x4f98e8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x4f98ec: sub             sp, x16, #1, lsl #12
    //     0x4f98f0: mov             SP, fp
    //     0x4f98f4: ldp             fp, lr, [SP], #0x10
    // 0x4f98f8: mov             v1.16b, v0.16b
    // 0x4f98fc: ldur            d0, [fp, #-0x10]
    // 0x4f9900: fadd            d2, d0, d1
    // 0x4f9904: mov             v0.16b, v2.16b
    // 0x4f9908: r1 = Null
    //     0x4f9908: mov             x1, NULL
    // 0x4f990c: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x4f990c: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x4f9910: LeaveFrame
    //     0x4f9910: mov             SP, fp
    //     0x4f9914: ldp             fp, lr, [SP], #0x10
    // 0x4f9918: ret
    //     0x4f9918: ret             
    // 0x4f991c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4f991c: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4f9920: b               #0x4f9768
  }
  factory _ CustomNum.fromBase10(/* No info */) {
    // ** addr: 0x501258, size: 0x178
    // 0x501258: EnterFrame
    //     0x501258: stp             fp, lr, [SP, #-0x10]!
    //     0x50125c: mov             fp, SP
    // 0x501260: AllocStack(0x20)
    //     0x501260: sub             SP, SP, #0x20
    // 0x501264: d2 = 0.000000
    //     0x501264: eor             v2.16b, v2.16b, v2.16b
    // 0x501268: stur            d1, [fp, #-8]
    // 0x50126c: CheckStackOverflow
    //     0x50126c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x501270: cmp             SP, x16
    //     0x501274: b.ls            #0x5013c8
    // 0x501278: fcmp            d1, d2
    // 0x50127c: b.lt            #0x501324
    // 0x501280: stp             fp, lr, [SP, #-0x10]!
    // 0x501284: mov             fp, SP
    // 0x501288: CallRuntime_LibcLog(double) -> double
    //     0x501288: and             SP, SP, #0xfffffffffffffff0
    //     0x50128c: mov             sp, SP
    //     0x501290: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x501294: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x501298: blr             x16
    //     0x50129c: movz            x16, #0x8
    //     0x5012a0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5012a4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5012a8: sub             sp, x16, #1, lsl #12
    //     0x5012ac: mov             SP, fp
    //     0x5012b0: ldp             fp, lr, [SP], #0x10
    // 0x5012b4: stur            d0, [fp, #-0x10]
    // 0x5012b8: r16 = 20
    //     0x5012b8: movz            x16, #0x14
    // 0x5012bc: stp             x16, NULL, [SP]
    // 0x5012c0: r0 = _Double.fromInteger()
    //     0x5012c0: bl              #0x33380c  ; [dart:core] _Double::_Double.fromInteger
    // 0x5012c4: LoadField: d0 = r0->field_7
    //     0x5012c4: ldur            d0, [x0, #7]
    // 0x5012c8: stp             fp, lr, [SP, #-0x10]!
    // 0x5012cc: mov             fp, SP
    // 0x5012d0: CallRuntime_LibcLog(double) -> double
    //     0x5012d0: and             SP, SP, #0xfffffffffffffff0
    //     0x5012d4: mov             sp, SP
    //     0x5012d8: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x5012dc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5012e0: blr             x16
    //     0x5012e4: movz            x16, #0x8
    //     0x5012e8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x5012ec: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x5012f0: sub             sp, x16, #1, lsl #12
    //     0x5012f4: mov             SP, fp
    //     0x5012f8: ldp             fp, lr, [SP], #0x10
    // 0x5012fc: ldur            d1, [fp, #-8]
    // 0x501300: fmul            d2, d1, d0
    // 0x501304: ldur            d0, [fp, #-0x10]
    // 0x501308: fadd            d1, d0, d2
    // 0x50130c: mov             v0.16b, v1.16b
    // 0x501310: r1 = Null
    //     0x501310: mov             x1, NULL
    // 0x501314: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x501314: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x501318: LeaveFrame
    //     0x501318: mov             SP, fp
    //     0x50131c: ldp             fp, lr, [SP], #0x10
    // 0x501320: ret
    //     0x501320: ret             
    // 0x501324: stp             fp, lr, [SP, #-0x10]!
    // 0x501328: mov             fp, SP
    // 0x50132c: CallRuntime_LibcLog(double) -> double
    //     0x50132c: and             SP, SP, #0xfffffffffffffff0
    //     0x501330: mov             sp, SP
    //     0x501334: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x501338: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x50133c: blr             x16
    //     0x501340: movz            x16, #0x8
    //     0x501344: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x501348: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x50134c: sub             sp, x16, #1, lsl #12
    //     0x501350: mov             SP, fp
    //     0x501354: ldp             fp, lr, [SP], #0x10
    // 0x501358: mov             v1.16b, v0.16b
    // 0x50135c: d0 = 0.100000
    //     0x50135c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcc30] IMM: double(0.1) from 0x3fb999999999999a
    //     0x501360: ldr             d0, [x17, #0xc30]
    // 0x501364: stur            d1, [fp, #-0x10]
    // 0x501368: stp             fp, lr, [SP, #-0x10]!
    // 0x50136c: mov             fp, SP
    // 0x501370: CallRuntime_LibcLog(double) -> double
    //     0x501370: and             SP, SP, #0xfffffffffffffff0
    //     0x501374: mov             sp, SP
    //     0x501378: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x50137c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x501380: blr             x16
    //     0x501384: movz            x16, #0x8
    //     0x501388: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x50138c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x501390: sub             sp, x16, #1, lsl #12
    //     0x501394: mov             SP, fp
    //     0x501398: ldp             fp, lr, [SP], #0x10
    // 0x50139c: mov             v1.16b, v0.16b
    // 0x5013a0: ldur            d0, [fp, #-8]
    // 0x5013a4: fmul            d2, d0, d1
    // 0x5013a8: ldur            d0, [fp, #-0x10]
    // 0x5013ac: fsub            d1, d0, d2
    // 0x5013b0: mov             v0.16b, v1.16b
    // 0x5013b4: r1 = Null
    //     0x5013b4: mov             x1, NULL
    // 0x5013b8: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x5013b8: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x5013bc: LeaveFrame
    //     0x5013bc: mov             SP, fp
    //     0x5013c0: ldp             fp, lr, [SP], #0x10
    // 0x5013c4: ret
    //     0x5013c4: ret             
    // 0x5013c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x5013c8: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x5013cc: b               #0x501278
  }
  static _ subtract(/* No info */) {
    // ** addr: 0x539f28, size: 0x2b4
    // 0x539f28: EnterFrame
    //     0x539f28: stp             fp, lr, [SP, #-0x10]!
    //     0x539f2c: mov             fp, SP
    // 0x539f30: AllocStack(0x20)
    //     0x539f30: sub             SP, SP, #0x20
    // 0x539f34: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, {dynamic allowSubtractingFromSmaller = false /* r5 */, dynamic showErrorMessages = true /* r1 */})
    //     0x539f34: mov             x0, x1
    //     0x539f38: stur            x1, [fp, #-8]
    //     0x539f3c: ldur            w1, [x4, #0x13]
    //     0x539f40: ldur            w3, [x4, #0x1f]
    //     0x539f44: add             x3, x3, HEAP, lsl #32
    //     0x539f48: add             x16, PP, #0x17, lsl #12  ; [pp+0x17088] "allowSubtractingFromSmaller"
    //     0x539f4c: ldr             x16, [x16, #0x88]
    //     0x539f50: cmp             w3, w16
    //     0x539f54: b.ne            #0x539f78
    //     0x539f58: ldur            w3, [x4, #0x23]
    //     0x539f5c: add             x3, x3, HEAP, lsl #32
    //     0x539f60: sub             w5, w1, w3
    //     0x539f64: add             x3, fp, w5, sxtw #2
    //     0x539f68: ldr             x3, [x3, #8]
    //     0x539f6c: mov             x5, x3
    //     0x539f70: movz            x3, #0x1
    //     0x539f74: b               #0x539f80
    //     0x539f78: add             x5, NULL, #0x30  ; false
    //     0x539f7c: movz            x3, #0
    //     0x539f80: lsl             x6, x3, #1
    //     0x539f84: lsl             w3, w6, #1
    //     0x539f88: add             w6, w3, #8
    //     0x539f8c: add             x16, x4, w6, sxtw #1
    //     0x539f90: ldur            w7, [x16, #0xf]
    //     0x539f94: add             x7, x7, HEAP, lsl #32
    //     0x539f98: add             x16, PP, #0x17, lsl #12  ; [pp+0x17090] "showErrorMessages"
    //     0x539f9c: ldr             x16, [x16, #0x90]
    //     0x539fa0: cmp             w7, w16
    //     0x539fa4: b.ne            #0x539fc8
    //     0x539fa8: add             w6, w3, #0xa
    //     0x539fac: add             x16, x4, w6, sxtw #1
    //     0x539fb0: ldur            w3, [x16, #0xf]
    //     0x539fb4: add             x3, x3, HEAP, lsl #32
    //     0x539fb8: sub             w4, w1, w3
    //     0x539fbc: add             x1, fp, w4, sxtw #2
    //     0x539fc0: ldr             x1, [x1, #8]
    //     0x539fc4: b               #0x539fcc
    //     0x539fc8: add             x1, NULL, #0x20  ; true
    //     0x539fcc: ldr             d0, [PP, #0xba8]  ; [pp+0xba8] IMM: double(inf) from 0x7ff0000000000000
    // 0x539fcc: d0 = inf
    // 0x539fd0: CheckStackOverflow
    //     0x539fd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x539fd4: cmp             SP, x16
    //     0x539fd8: b.ls            #0x53a1b8
    // 0x539fdc: LoadField: d1 = r0->field_7
    //     0x539fdc: ldur            d1, [x0, #7]
    // 0x539fe0: stur            d1, [fp, #-0x18]
    // 0x539fe4: fcmp            d1, d0
    // 0x539fe8: b.ne            #0x539ff8
    // 0x539fec: LeaveFrame
    //     0x539fec: mov             SP, fp
    //     0x539ff0: ldp             fp, lr, [SP], #0x10
    // 0x539ff4: ret
    //     0x539ff4: ret             
    // 0x539ff8: LoadField: d2 = r2->field_7
    //     0x539ff8: ldur            d2, [x2, #7]
    // 0x539ffc: fcmp            d2, d0
    // 0x53a000: b.ne            #0x53a028
    // 0x53a004: r1 = "Trying to subtract infinity!"
    //     0x53a004: add             x1, PP, #0x17, lsl #12  ; [pp+0x17098] "Trying to subtract infinity!"
    //     0x53a008: ldr             x1, [x1, #0x98]
    // 0x53a00c: r2 = Null
    //     0x53a00c: mov             x2, NULL
    // 0x53a010: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x53a010: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x53a014: r0 = crashlyticsRecordError()
    //     0x53a014: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x53a018: ldur            x0, [fp, #-8]
    // 0x53a01c: LeaveFrame
    //     0x53a01c: mov             SP, fp
    //     0x53a020: ldp             fp, lr, [SP], #0x10
    // 0x53a024: ret
    //     0x53a024: ret             
    // 0x53a028: d0 = -inf
    //     0x53a028: ldr             d0, [PP, #0xc30]  ; [pp+0xc30] IMM: double(-inf) from 0xfff0000000000000
    // 0x53a02c: fcmp            d1, d0
    // 0x53a030: b.ne            #0x53a064
    // 0x53a034: tbnz            w1, #4, #0x53a054
    // 0x53a038: tbz             w5, #4, #0x53a054
    // 0x53a03c: r0 = current()
    //     0x53a03c: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x53a040: mov             x2, x0
    // 0x53a044: r1 = "Trying to subtract from 0"
    //     0x53a044: add             x1, PP, #0x17, lsl #12  ; [pp+0x170a0] "Trying to subtract from 0"
    //     0x53a048: ldr             x1, [x1, #0xa0]
    // 0x53a04c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x53a04c: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x53a050: r0 = crashlyticsRecordError()
    //     0x53a050: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x53a054: ldur            x0, [fp, #-8]
    // 0x53a058: LeaveFrame
    //     0x53a058: mov             SP, fp
    //     0x53a05c: ldp             fp, lr, [SP], #0x10
    // 0x53a060: ret
    //     0x53a060: ret             
    // 0x53a064: d0 = 0.000000
    //     0x53a064: eor             v0.16b, v0.16b, v0.16b
    // 0x53a068: fsub            d3, d2, d1
    // 0x53a06c: stur            d3, [fp, #-0x10]
    // 0x53a070: fcmp            d3, d0
    // 0x53a074: b.le            #0x53a118
    // 0x53a078: tbz             w5, #4, #0x53a104
    // 0x53a07c: d0 = 0.001000
    //     0x53a07c: ldr             d0, [PP, #0x7490]  ; [pp+0x7490] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0x53a080: fcmp            d3, d0
    // 0x53a084: b.le            #0x53a104
    // 0x53a088: tbnz            w1, #4, #0x53a104
    // 0x53a08c: r1 = Null
    //     0x53a08c: mov             x1, NULL
    // 0x53a090: r2 = 6
    //     0x53a090: movz            x2, #0x6
    // 0x53a094: r0 = AllocateArray()
    //     0x53a094: bl              #0x82746c  ; AllocateArrayStub
    // 0x53a098: r16 = "Trying to subtract a larger number from a smaller one. Delta: "
    //     0x53a098: add             x16, PP, #0x17, lsl #12  ; [pp+0x170a8] "Trying to subtract a larger number from a smaller one. Delta: "
    //     0x53a09c: ldr             x16, [x16, #0xa8]
    // 0x53a0a0: StoreField: r0->field_f = r16
    //     0x53a0a0: stur            w16, [x0, #0xf]
    // 0x53a0a4: ldur            d0, [fp, #-0x10]
    // 0x53a0a8: r1 = inline_Allocate_Double()
    //     0x53a0a8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x53a0ac: add             x1, x1, #0x10
    //     0x53a0b0: cmp             x2, x1
    //     0x53a0b4: b.ls            #0x53a1c0
    //     0x53a0b8: str             x1, [THR, #0x60]  ; THR::top
    //     0x53a0bc: sub             x1, x1, #0xf
    //     0x53a0c0: movz            x2, #0xe19c
    //     0x53a0c4: movk            x2, #0x3, lsl #16
    //     0x53a0c8: stur            x2, [x1, #-1]
    // 0x53a0cc: dmb             ishst
    // 0x53a0d0: StoreField: r1->field_7 = d0
    //     0x53a0d0: stur            d0, [x1, #7]
    // 0x53a0d4: StoreField: r0->field_13 = r1
    //     0x53a0d4: stur            w1, [x0, #0x13]
    // 0x53a0d8: r16 = "!"
    //     0x53a0d8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeab0] "!"
    //     0x53a0dc: ldr             x16, [x16, #0xab0]
    // 0x53a0e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x53a0e0: stur            w16, [x0, #0x17]
    // 0x53a0e4: str             x0, [SP]
    // 0x53a0e8: r0 = _interpolate()
    //     0x53a0e8: bl              #0x32d0b0  ; [dart:core] _StringBase::_interpolate
    // 0x53a0ec: stur            x0, [fp, #-8]
    // 0x53a0f0: r0 = current()
    //     0x53a0f0: bl              #0x34665c  ; [dart:core] StackTrace::current
    // 0x53a0f4: ldur            x1, [fp, #-8]
    // 0x53a0f8: mov             x2, x0
    // 0x53a0fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x53a0fc: ldr             x4, [PP, #0x2c8]  ; [pp+0x2c8] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x53a100: r0 = crashlyticsRecordError()
    //     0x53a100: bl              #0x3535f4  ; [package:custom_tools/BasicFunctions.dart] ::crashlyticsRecordError
    // 0x53a104: r0 = Instance_CustomNum
    //     0x53a104: add             x0, PP, #0xe, lsl #12  ; [pp+0xeaf8] Obj!CustomNum@828af1
    //     0x53a108: ldr             x0, [x0, #0xaf8]
    // 0x53a10c: LeaveFrame
    //     0x53a10c: mov             SP, fp
    //     0x53a110: ldp             fp, lr, [SP], #0x10
    // 0x53a114: ret
    //     0x53a114: ret             
    // 0x53a118: mov             v0.16b, v3.16b
    // 0x53a11c: stp             fp, lr, [SP, #-0x10]!
    // 0x53a120: mov             fp, SP
    // 0x53a124: CallRuntime_LibcExp(double) -> double
    //     0x53a124: and             SP, SP, #0xfffffffffffffff0
    //     0x53a128: mov             sp, SP
    //     0x53a12c: ldr             x16, [THR, #0x7b0]  ; THR::LibcExp
    //     0x53a130: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x53a134: blr             x16
    //     0x53a138: movz            x16, #0x8
    //     0x53a13c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x53a140: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x53a144: sub             sp, x16, #1, lsl #12
    //     0x53a148: mov             SP, fp
    //     0x53a14c: ldp             fp, lr, [SP], #0x10
    // 0x53a150: mov             v1.16b, v0.16b
    // 0x53a154: d0 = 1.000000
    //     0x53a154: fmov            d0, #1.00000000
    // 0x53a158: fsub            d2, d0, d1
    // 0x53a15c: mov             v0.16b, v2.16b
    // 0x53a160: stp             fp, lr, [SP, #-0x10]!
    // 0x53a164: mov             fp, SP
    // 0x53a168: CallRuntime_LibcLog(double) -> double
    //     0x53a168: and             SP, SP, #0xfffffffffffffff0
    //     0x53a16c: mov             sp, SP
    //     0x53a170: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x53a174: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x53a178: blr             x16
    //     0x53a17c: movz            x16, #0x8
    //     0x53a180: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x53a184: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x53a188: sub             sp, x16, #1, lsl #12
    //     0x53a18c: mov             SP, fp
    //     0x53a190: ldp             fp, lr, [SP], #0x10
    // 0x53a194: mov             v1.16b, v0.16b
    // 0x53a198: ldur            d0, [fp, #-0x18]
    // 0x53a19c: fadd            d2, d0, d1
    // 0x53a1a0: mov             v0.16b, v2.16b
    // 0x53a1a4: r1 = Null
    //     0x53a1a4: mov             x1, NULL
    // 0x53a1a8: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x53a1a8: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x53a1ac: LeaveFrame
    //     0x53a1ac: mov             SP, fp
    //     0x53a1b0: ldp             fp, lr, [SP], #0x10
    // 0x53a1b4: ret
    //     0x53a1b4: ret             
    // 0x53a1b8: r0 = StackOverflowSharedWithFPURegs()
    //     0x53a1b8: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x53a1bc: b               #0x539fdc
    // 0x53a1c0: SaveReg d0
    //     0x53a1c0: str             q0, [SP, #-0x10]!
    // 0x53a1c4: SaveReg r0
    //     0x53a1c4: str             x0, [SP, #-8]!
    // 0x53a1c8: r0 = AllocateDouble()
    //     0x53a1c8: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x53a1cc: mov             x1, x0
    // 0x53a1d0: RestoreReg r0
    //     0x53a1d0: ldr             x0, [SP], #8
    // 0x53a1d4: RestoreReg d0
    //     0x53a1d4: ldr             q0, [SP], #0x10
    // 0x53a1d8: b               #0x53a0d0
  }
  static _ mult6(/* No info */) {
    // ** addr: 0x544120, size: 0x68
    // 0x544120: EnterFrame
    //     0x544120: stp             fp, lr, [SP, #-0x10]!
    //     0x544124: mov             fp, SP
    // 0x544128: r0 = Instance_CustomNum
    //     0x544128: add             x0, PP, #0x11, lsl #12  ; [pp+0x11060] Obj!CustomNum@828b31
    //     0x54412c: ldr             x0, [x0, #0x60]
    // 0x544130: CheckStackOverflow
    //     0x544130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x544134: cmp             SP, x16
    //     0x544138: b.ls            #0x544180
    // 0x54413c: LoadField: d0 = r0->field_7
    //     0x54413c: ldur            d0, [x0, #7]
    // 0x544140: LoadField: d1 = r1->field_7
    //     0x544140: ldur            d1, [x1, #7]
    // 0x544144: fadd            d2, d0, d1
    // 0x544148: LoadField: d0 = r2->field_7
    //     0x544148: ldur            d0, [x2, #7]
    // 0x54414c: fadd            d1, d2, d0
    // 0x544150: LoadField: d0 = r3->field_7
    //     0x544150: ldur            d0, [x3, #7]
    // 0x544154: fadd            d2, d1, d0
    // 0x544158: LoadField: d0 = r5->field_7
    //     0x544158: ldur            d0, [x5, #7]
    // 0x54415c: fadd            d1, d2, d0
    // 0x544160: LoadField: d0 = r6->field_7
    //     0x544160: ldur            d0, [x6, #7]
    // 0x544164: fadd            d2, d1, d0
    // 0x544168: mov             v0.16b, v2.16b
    // 0x54416c: r1 = Null
    //     0x54416c: mov             x1, NULL
    // 0x544170: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x544170: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x544174: LeaveFrame
    //     0x544174: mov             SP, fp
    //     0x544178: ldp             fp, lr, [SP], #0x10
    // 0x54417c: ret
    //     0x54417c: ret             
    // 0x544180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x544180: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x544184: b               #0x54413c
  }
  _ root(/* No info */) {
    // ** addr: 0x54b18c, size: 0x30
    // 0x54b18c: EnterFrame
    //     0x54b18c: stp             fp, lr, [SP, #-0x10]!
    //     0x54b190: mov             fp, SP
    // 0x54b194: AllocStack(0x8)
    //     0x54b194: sub             SP, SP, #8
    // 0x54b198: LoadField: d1 = r1->field_7
    //     0x54b198: ldur            d1, [x1, #7]
    // 0x54b19c: fmul            d2, d1, d0
    // 0x54b1a0: stur            d2, [fp, #-8]
    // 0x54b1a4: r0 = CustomNum()
    //     0x54b1a4: bl              #0x3da324  ; AllocateCustomNumStub -> CustomNum (size=0x10)
    // 0x54b1a8: ldur            d0, [fp, #-8]
    // 0x54b1ac: StoreField: r0->field_7 = d0
    //     0x54b1ac: stur            d0, [x0, #7]
    // 0x54b1b0: LeaveFrame
    //     0x54b1b0: mov             SP, fp
    //     0x54b1b4: ldp             fp, lr, [SP], #0x10
    // 0x54b1b8: ret
    //     0x54b1b8: ret             
  }
  static _ mult10(/* No info */) {
    // ** addr: 0x54e548, size: 0x90
    // 0x54e548: EnterFrame
    //     0x54e548: stp             fp, lr, [SP, #-0x10]!
    //     0x54e54c: mov             fp, SP
    // 0x54e550: CheckStackOverflow
    //     0x54e550: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e554: cmp             SP, x16
    //     0x54e558: b.ls            #0x54e5d0
    // 0x54e55c: LoadField: d0 = r1->field_7
    //     0x54e55c: ldur            d0, [x1, #7]
    // 0x54e560: LoadField: d1 = r2->field_7
    //     0x54e560: ldur            d1, [x2, #7]
    // 0x54e564: fadd            d2, d0, d1
    // 0x54e568: LoadField: d0 = r3->field_7
    //     0x54e568: ldur            d0, [x3, #7]
    // 0x54e56c: fadd            d1, d2, d0
    // 0x54e570: LoadField: d0 = r5->field_7
    //     0x54e570: ldur            d0, [x5, #7]
    // 0x54e574: fadd            d2, d1, d0
    // 0x54e578: LoadField: d0 = r6->field_7
    //     0x54e578: ldur            d0, [x6, #7]
    // 0x54e57c: fadd            d1, d2, d0
    // 0x54e580: LoadField: d0 = r7->field_7
    //     0x54e580: ldur            d0, [x7, #7]
    // 0x54e584: fadd            d2, d1, d0
    // 0x54e588: ldr             x0, [fp, #0x28]
    // 0x54e58c: LoadField: d0 = r0->field_7
    //     0x54e58c: ldur            d0, [x0, #7]
    // 0x54e590: fadd            d1, d2, d0
    // 0x54e594: ldr             x0, [fp, #0x20]
    // 0x54e598: LoadField: d0 = r0->field_7
    //     0x54e598: ldur            d0, [x0, #7]
    // 0x54e59c: fadd            d2, d1, d0
    // 0x54e5a0: ldr             x0, [fp, #0x18]
    // 0x54e5a4: LoadField: d0 = r0->field_7
    //     0x54e5a4: ldur            d0, [x0, #7]
    // 0x54e5a8: fadd            d1, d2, d0
    // 0x54e5ac: ldr             x0, [fp, #0x10]
    // 0x54e5b0: LoadField: d0 = r0->field_7
    //     0x54e5b0: ldur            d0, [x0, #7]
    // 0x54e5b4: fadd            d2, d1, d0
    // 0x54e5b8: mov             v0.16b, v2.16b
    // 0x54e5bc: r1 = Null
    //     0x54e5bc: mov             x1, NULL
    // 0x54e5c0: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x54e5c0: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x54e5c4: LeaveFrame
    //     0x54e5c4: mov             SP, fp
    //     0x54e5c8: ldp             fp, lr, [SP], #0x10
    // 0x54e5cc: ret
    //     0x54e5cc: ret             
    // 0x54e5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e5d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e5d4: b               #0x54e55c
  }
  static _ mult9(/* No info */) {
    // ** addr: 0x54e5d8, size: 0x84
    // 0x54e5d8: EnterFrame
    //     0x54e5d8: stp             fp, lr, [SP, #-0x10]!
    //     0x54e5dc: mov             fp, SP
    // 0x54e5e0: CheckStackOverflow
    //     0x54e5e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x54e5e4: cmp             SP, x16
    //     0x54e5e8: b.ls            #0x54e654
    // 0x54e5ec: LoadField: d0 = r1->field_7
    //     0x54e5ec: ldur            d0, [x1, #7]
    // 0x54e5f0: LoadField: d1 = r2->field_7
    //     0x54e5f0: ldur            d1, [x2, #7]
    // 0x54e5f4: fadd            d2, d0, d1
    // 0x54e5f8: LoadField: d0 = r3->field_7
    //     0x54e5f8: ldur            d0, [x3, #7]
    // 0x54e5fc: fadd            d1, d2, d0
    // 0x54e600: LoadField: d0 = r5->field_7
    //     0x54e600: ldur            d0, [x5, #7]
    // 0x54e604: fadd            d2, d1, d0
    // 0x54e608: LoadField: d0 = r6->field_7
    //     0x54e608: ldur            d0, [x6, #7]
    // 0x54e60c: fadd            d1, d2, d0
    // 0x54e610: LoadField: d0 = r7->field_7
    //     0x54e610: ldur            d0, [x7, #7]
    // 0x54e614: fadd            d2, d1, d0
    // 0x54e618: ldr             x0, [fp, #0x20]
    // 0x54e61c: LoadField: d0 = r0->field_7
    //     0x54e61c: ldur            d0, [x0, #7]
    // 0x54e620: fadd            d1, d2, d0
    // 0x54e624: ldr             x0, [fp, #0x18]
    // 0x54e628: LoadField: d0 = r0->field_7
    //     0x54e628: ldur            d0, [x0, #7]
    // 0x54e62c: fadd            d2, d1, d0
    // 0x54e630: ldr             x0, [fp, #0x10]
    // 0x54e634: LoadField: d0 = r0->field_7
    //     0x54e634: ldur            d0, [x0, #7]
    // 0x54e638: fadd            d1, d2, d0
    // 0x54e63c: mov             v0.16b, v1.16b
    // 0x54e640: r1 = Null
    //     0x54e640: mov             x1, NULL
    // 0x54e644: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x54e644: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x54e648: LeaveFrame
    //     0x54e648: mov             SP, fp
    //     0x54e64c: ldp             fp, lr, [SP], #0x10
    // 0x54e650: ret
    //     0x54e650: ret             
    // 0x54e654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x54e654: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x54e658: b               #0x54e5ec
  }
  static _ max(/* No info */) {
    // ** addr: 0x54f61c, size: 0x20
    // 0x54f61c: LoadField: d0 = r2->field_7
    //     0x54f61c: ldur            d0, [x2, #7]
    // 0x54f620: LoadField: d1 = r1->field_7
    //     0x54f620: ldur            d1, [x1, #7]
    // 0x54f624: fcmp            d1, d0
    // 0x54f628: b.le            #0x54f634
    // 0x54f62c: mov             x0, x1
    // 0x54f630: b               #0x54f638
    // 0x54f634: mov             x0, x2
    // 0x54f638: ret
    //     0x54f638: ret             
  }
  static _ min(/* No info */) {
    // ** addr: 0x55ce40, size: 0x20
    // 0x55ce40: LoadField: d0 = r2->field_7
    //     0x55ce40: ldur            d0, [x2, #7]
    // 0x55ce44: LoadField: d1 = r1->field_7
    //     0x55ce44: ldur            d1, [x1, #7]
    // 0x55ce48: fcmp            d1, d0
    // 0x55ce4c: b.le            #0x55ce58
    // 0x55ce50: mov             x0, x2
    // 0x55ce54: b               #0x55ce5c
    // 0x55ce58: mov             x0, x1
    // 0x55ce5c: ret
    //     0x55ce5c: ret             
  }
  static _ mult7(/* No info */) {
    // ** addr: 0x55d644, size: 0x6c
    // 0x55d644: EnterFrame
    //     0x55d644: stp             fp, lr, [SP, #-0x10]!
    //     0x55d648: mov             fp, SP
    // 0x55d64c: CheckStackOverflow
    //     0x55d64c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x55d650: cmp             SP, x16
    //     0x55d654: b.ls            #0x55d6a8
    // 0x55d658: LoadField: d0 = r1->field_7
    //     0x55d658: ldur            d0, [x1, #7]
    // 0x55d65c: LoadField: d1 = r2->field_7
    //     0x55d65c: ldur            d1, [x2, #7]
    // 0x55d660: fadd            d2, d0, d1
    // 0x55d664: LoadField: d0 = r3->field_7
    //     0x55d664: ldur            d0, [x3, #7]
    // 0x55d668: fadd            d1, d2, d0
    // 0x55d66c: LoadField: d0 = r5->field_7
    //     0x55d66c: ldur            d0, [x5, #7]
    // 0x55d670: fadd            d2, d1, d0
    // 0x55d674: LoadField: d0 = r6->field_7
    //     0x55d674: ldur            d0, [x6, #7]
    // 0x55d678: fadd            d1, d2, d0
    // 0x55d67c: LoadField: d0 = r7->field_7
    //     0x55d67c: ldur            d0, [x7, #7]
    // 0x55d680: fadd            d2, d1, d0
    // 0x55d684: ldr             x0, [fp, #0x10]
    // 0x55d688: LoadField: d0 = r0->field_7
    //     0x55d688: ldur            d0, [x0, #7]
    // 0x55d68c: fadd            d1, d2, d0
    // 0x55d690: mov             v0.16b, v1.16b
    // 0x55d694: r1 = Null
    //     0x55d694: mov             x1, NULL
    // 0x55d698: r0 = CustomNum.fromExponentWithErrorChecking()
    //     0x55d698: bl              #0x3da2b4  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum.fromExponentWithErrorChecking
    // 0x55d69c: LeaveFrame
    //     0x55d69c: mov             SP, fp
    //     0x55d6a0: ldp             fp, lr, [SP], #0x10
    // 0x55d6a4: ret
    //     0x55d6a4: ret             
    // 0x55d6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55d6a8: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55d6ac: b               #0x55d658
  }
  _ naturalLogMinZero(/* No info */) {
    // ** addr: 0x6525d8, size: 0x88
    // 0x6525d8: EnterFrame
    //     0x6525d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6525dc: mov             fp, SP
    // 0x6525e0: d0 = 0.000000
    //     0x6525e0: eor             v0.16b, v0.16b, v0.16b
    // 0x6525e4: CheckStackOverflow
    //     0x6525e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6525e8: cmp             SP, x16
    //     0x6525ec: b.ls            #0x652648
    // 0x6525f0: LoadField: d1 = r1->field_7
    //     0x6525f0: ldur            d1, [x1, #7]
    // 0x6525f4: fcmp            d1, d0
    // 0x6525f8: b.le            #0x652630
    // 0x6525fc: r0 = inline_Allocate_Double()
    //     0x6525fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x652600: add             x0, x0, #0x10
    //     0x652604: cmp             x1, x0
    //     0x652608: b.ls            #0x652650
    //     0x65260c: str             x0, [THR, #0x60]  ; THR::top
    //     0x652610: sub             x0, x0, #0xf
    //     0x652614: movz            x1, #0xe19c
    //     0x652618: movk            x1, #0x3, lsl #16
    //     0x65261c: stur            x1, [x0, #-1]
    // 0x652620: dmb             ishst
    // 0x652624: StoreField: r0->field_7 = d1
    //     0x652624: stur            d1, [x0, #7]
    // 0x652628: mov             x2, x0
    // 0x65262c: b               #0x652634
    // 0x652630: r2 = 0
    //     0x652630: movz            x2, #0
    // 0x652634: r1 = Null
    //     0x652634: mov             x1, NULL
    // 0x652638: r0 = CustomNum()
    //     0x652638: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x65263c: LeaveFrame
    //     0x65263c: mov             SP, fp
    //     0x652640: ldp             fp, lr, [SP], #0x10
    // 0x652644: ret
    //     0x652644: ret             
    // 0x652648: r0 = StackOverflowSharedWithFPURegs()
    //     0x652648: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x65264c: b               #0x6525f0
    // 0x652650: SaveReg d1
    //     0x652650: str             q1, [SP, #-0x10]!
    // 0x652654: r0 = AllocateDouble()
    //     0x652654: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x652658: RestoreReg d1
    //     0x652658: ldr             q1, [SP], #0x10
    // 0x65265c: b               #0x652624
  }
  _ logMinZero(/* No info */) {
    // ** addr: 0x6a4b88, size: 0xd4
    // 0x6a4b88: EnterFrame
    //     0x6a4b88: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4b8c: mov             fp, SP
    // 0x6a4b90: AllocStack(0x8)
    //     0x6a4b90: sub             SP, SP, #8
    // 0x6a4b94: d0 = 0.000000
    //     0x6a4b94: eor             v0.16b, v0.16b, v0.16b
    // 0x6a4b98: CheckStackOverflow
    //     0x6a4b98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a4b9c: cmp             SP, x16
    //     0x6a4ba0: b.ls            #0x6a4c44
    // 0x6a4ba4: LoadField: d1 = r1->field_7
    //     0x6a4ba4: ldur            d1, [x1, #7]
    // 0x6a4ba8: stur            d1, [fp, #-8]
    // 0x6a4bac: fcmp            d1, d0
    // 0x6a4bb0: b.le            #0x6a4c2c
    // 0x6a4bb4: d0 = 10.000000
    //     0x6a4bb4: fmov            d0, #10.00000000
    // 0x6a4bb8: stp             fp, lr, [SP, #-0x10]!
    // 0x6a4bbc: mov             fp, SP
    // 0x6a4bc0: CallRuntime_LibcLog(double) -> double
    //     0x6a4bc0: and             SP, SP, #0xfffffffffffffff0
    //     0x6a4bc4: mov             sp, SP
    //     0x6a4bc8: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0x6a4bcc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6a4bd0: blr             x16
    //     0x6a4bd4: movz            x16, #0x8
    //     0x6a4bd8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x6a4bdc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x6a4be0: sub             sp, x16, #1, lsl #12
    //     0x6a4be4: mov             SP, fp
    //     0x6a4be8: ldp             fp, lr, [SP], #0x10
    // 0x6a4bec: mov             v1.16b, v0.16b
    // 0x6a4bf0: ldur            d0, [fp, #-8]
    // 0x6a4bf4: fdiv            d2, d0, d1
    // 0x6a4bf8: r0 = inline_Allocate_Double()
    //     0x6a4bf8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6a4bfc: add             x0, x0, #0x10
    //     0x6a4c00: cmp             x1, x0
    //     0x6a4c04: b.ls            #0x6a4c4c
    //     0x6a4c08: str             x0, [THR, #0x60]  ; THR::top
    //     0x6a4c0c: sub             x0, x0, #0xf
    //     0x6a4c10: movz            x1, #0xe19c
    //     0x6a4c14: movk            x1, #0x3, lsl #16
    //     0x6a4c18: stur            x1, [x0, #-1]
    // 0x6a4c1c: dmb             ishst
    // 0x6a4c20: StoreField: r0->field_7 = d2
    //     0x6a4c20: stur            d2, [x0, #7]
    // 0x6a4c24: mov             x2, x0
    // 0x6a4c28: b               #0x6a4c30
    // 0x6a4c2c: r2 = 0
    //     0x6a4c2c: movz            x2, #0
    // 0x6a4c30: r1 = Null
    //     0x6a4c30: mov             x1, NULL
    // 0x6a4c34: r0 = CustomNum()
    //     0x6a4c34: bl              #0x3dc21c  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::CustomNum
    // 0x6a4c38: LeaveFrame
    //     0x6a4c38: mov             SP, fp
    //     0x6a4c3c: ldp             fp, lr, [SP], #0x10
    // 0x6a4c40: ret
    //     0x6a4c40: ret             
    // 0x6a4c44: r0 = StackOverflowSharedWithFPURegs()
    //     0x6a4c44: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x6a4c48: b               #0x6a4ba4
    // 0x6a4c4c: SaveReg d2
    //     0x6a4c4c: str             q2, [SP, #-0x10]!
    // 0x6a4c50: r0 = AllocateDouble()
    //     0x6a4c50: bl              #0x8273bc  ; AllocateDoubleStub
    // 0x6a4c54: RestoreReg d2
    //     0x6a4c54: ldr             q2, [SP], #0x10
    // 0x6a4c58: b               #0x6a4c20
  }
  _ toStringTrimZeroes(/* No info */) {
    // ** addr: 0x719660, size: 0x40
    // 0x719660: EnterFrame
    //     0x719660: stp             fp, lr, [SP, #-0x10]!
    //     0x719664: mov             fp, SP
    // 0x719668: AllocStack(0x8)
    //     0x719668: sub             SP, SP, #8
    // 0x71966c: CheckStackOverflow
    //     0x71966c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x719670: cmp             SP, x16
    //     0x719674: b.ls            #0x719698
    // 0x719678: r16 = true
    //     0x719678: add             x16, NULL, #0x20  ; true
    // 0x71967c: str             x16, [SP]
    // 0x719680: r4 = const [0, 0x2, 0x1, 0x1, trimExtraZeros, 0x1, null]
    //     0x719680: add             x4, PP, #0x16, lsl #12  ; [pp+0x16990] List(7) [0, 0x2, 0x1, 0x1, "trimExtraZeros", 0x1, Null]
    //     0x719684: ldr             x4, [x4, #0x990]
    // 0x719688: r0 = toStringConsistentDecimalPlaces()
    //     0x719688: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x71968c: LeaveFrame
    //     0x71968c: mov             SP, fp
    //     0x719690: ldp             fp, lr, [SP], #0x10
    // 0x719694: ret
    //     0x719694: ret             
    // 0x719698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719698: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71969c: b               #0x719678
  }
  [closure] String toStringTrimZeroes(dynamic) {
    // ** addr: 0x7196a0, size: 0x38
    // 0x7196a0: EnterFrame
    //     0x7196a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7196a4: mov             fp, SP
    // 0x7196a8: ldr             x0, [fp, #0x10]
    // 0x7196ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7196ac: ldur            w1, [x0, #0x17]
    // 0x7196b0: DecompressPointer r1
    //     0x7196b0: add             x1, x1, HEAP, lsl #32
    // 0x7196b4: CheckStackOverflow
    //     0x7196b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7196b8: cmp             SP, x16
    //     0x7196bc: b.ls            #0x7196d0
    // 0x7196c0: r0 = toStringTrimZeroes()
    //     0x7196c0: bl              #0x719660  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringTrimZeroes
    // 0x7196c4: LeaveFrame
    //     0x7196c4: mov             SP, fp
    //     0x7196c8: ldp             fp, lr, [SP], #0x10
    // 0x7196cc: ret
    //     0x7196cc: ret             
    // 0x7196d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7196d0: bl              #0x827578  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7196d4: b               #0x7196c0
  }
  _ toString(/* No info */) {
    // ** addr: 0x7196d8, size: 0x60
    // 0x7196d8: EnterFrame
    //     0x7196d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7196dc: mov             fp, SP
    // 0x7196e0: AllocStack(0x8)
    //     0x7196e0: sub             SP, SP, #8
    // 0x7196e4: d0 = inf
    //     0x7196e4: ldr             d0, [PP, #0xba8]  ; [pp+0xba8] IMM: double(inf) from 0x7ff0000000000000
    // 0x7196e8: CheckStackOverflow
    //     0x7196e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7196ec: cmp             SP, x16
    //     0x7196f0: b.ls            #0x719730
    // 0x7196f4: ldr             x1, [fp, #0x10]
    // 0x7196f8: LoadField: d1 = r1->field_7
    //     0x7196f8: ldur            d1, [x1, #7]
    // 0x7196fc: fcmp            d1, d0
    // 0x719700: b.ne            #0x719710
    // 0x719704: r0 = "∞"
    //     0x719704: add             x0, PP, #0x16, lsl #12  ; [pp+0x16bf8] "∞"
    //     0x719708: ldr             x0, [x0, #0xbf8]
    // 0x71970c: b               #0x719724
    // 0x719710: r16 = true
    //     0x719710: add             x16, NULL, #0x20  ; true
    // 0x719714: str             x16, [SP]
    // 0x719718: r4 = const [0, 0x2, 0x1, 0x1, trimDecimalPlacesOnZero, 0x1, null]
    //     0x719718: add             x4, PP, #0x16, lsl #12  ; [pp+0x16c00] List(7) [0, 0x2, 0x1, 0x1, "trimDecimalPlacesOnZero", 0x1, Null]
    //     0x71971c: ldr             x4, [x4, #0xc00]
    // 0x719720: r0 = toStringConsistentDecimalPlaces()
    //     0x719720: bl              #0x4e5f30  ; [package:pretentious/fragment/lib/Data/custom_num.dart] CustomNum::toStringConsistentDecimalPlaces
    // 0x719724: LeaveFrame
    //     0x719724: mov             SP, fp
    //     0x719728: ldp             fp, lr, [SP], #0x10
    // 0x71972c: ret
    //     0x71972c: ret             
    // 0x719730: r0 = StackOverflowSharedWithFPURegs()
    //     0x719730: bl              #0x8275f8  ; StackOverflowSharedWithFPURegsStub
    // 0x719734: b               #0x7196f4
  }
  _ ==(/* No info */) {
    // ** addr: 0x7c6e68, size: 0x58
    // 0x7c6e68: ldr             x1, [SP]
    // 0x7c6e6c: cmp             w1, NULL
    // 0x7c6e70: b.ne            #0x7c6e7c
    // 0x7c6e74: r0 = false
    //     0x7c6e74: add             x0, NULL, #0x30  ; false
    // 0x7c6e78: ret
    //     0x7c6e78: ret             
    // 0x7c6e7c: r2 = 60
    //     0x7c6e7c: movz            x2, #0x3c
    // 0x7c6e80: branchIfSmi(r1, 0x7c6e8c)
    //     0x7c6e80: tbz             w1, #0, #0x7c6e8c
    // 0x7c6e84: r2 = LoadClassIdInstr(r1)
    //     0x7c6e84: ldur            x2, [x1, #-1]
    //     0x7c6e88: ubfx            x2, x2, #0xc, #0x14
    // 0x7c6e8c: cmp             x2, #0xfb
    // 0x7c6e90: b.ne            #0x7c6eb8
    // 0x7c6e94: ldr             x2, [SP, #8]
    // 0x7c6e98: LoadField: d0 = r1->field_7
    //     0x7c6e98: ldur            d0, [x1, #7]
    // 0x7c6e9c: LoadField: d1 = r2->field_7
    //     0x7c6e9c: ldur            d1, [x2, #7]
    // 0x7c6ea0: fcmp            d0, d1
    // 0x7c6ea4: r16 = true
    //     0x7c6ea4: add             x16, NULL, #0x20  ; true
    // 0x7c6ea8: r17 = false
    //     0x7c6ea8: add             x17, NULL, #0x30  ; false
    // 0x7c6eac: csel            x1, x16, x17, eq
    // 0x7c6eb0: mov             x0, x1
    // 0x7c6eb4: b               #0x7c6ebc
    // 0x7c6eb8: r0 = false
    //     0x7c6eb8: add             x0, NULL, #0x30  ; false
    // 0x7c6ebc: ret
    //     0x7c6ebc: ret             
  }
}
